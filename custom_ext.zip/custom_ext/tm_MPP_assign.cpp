#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <set>
#include <streambuf>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <fstream>
#include <sstream> 
#include <stdexcept>
#include <map>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedPtr.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <ps/ps.h>
#include <ae/dataset.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <tccore/item_msg.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_err 919002
// #include <metaframework/BusinessObjectRef.hxx>
// #include <base_utils/IFail.hxx>
// #include <base_utils/TcResultStatus.hxx>
// #include <base_utils/ScopedSmPtr.hxx>
//#include <mld/logging/TcMainLogger.hxx>
//#include <Error_Exception.hxx>
#include "MppFunctionFile.cpp"

using namespace std;
//using namespace Teamcenter;
//using Teamcenter::Main::logger;

// struct PlantInfo {
//     string plantCode;
//     string plantName;
// };

#include <nlohmann/json.hpp>
#include <cryptopp/hmac.h>
#include <cryptopp/sha.h>
#include <cryptopp/hex.h>
#include <cryptopp/base64.h>
#include <cryptopp/filters.h>
using json = nlohmann::json;

int MppToPalmsysHandler(EPM_action_message_t msg)
{
    cout << "Inside MppToPalmsysHandler"<< endl;
    json MppToPalmsysReturn;
    tag_t rootTask = NULLTAG;
    int noAttachment = 0;
    tag_t *attachments = NULLTAG;
    EPM_ask_root_task(msg.task, &rootTask);
    EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments);
    cout << "Number of attachements are : " << noAttachment << endl;
    if(noAttachment>0)
    {
        for(int i=0;i<noAttachment;i++)
        {
            char *pBOPItemId = NULL;
            char *pBOPObjectDesc = NULL;
            char *pBOPObjectType = NULL;
            string pBOPItemIdStr;
            string pBOPObjectDescStr;
            string pBOPObjectTypeStr;
            AOM_ask_value_string(attachments[i],"object_type",&pBOPObjectType);
            cout << "Object type is : " << pBOPObjectType << endl;
            pBOPObjectTypeStr = pBOPObjectType;
            if(pBOPObjectTypeStr=="MEProductBOPRevision")
            {
                AOM_ask_value_string(attachments[i],"item_id",&pBOPItemId);
                cout << "pBOP item id is : " << pBOPItemId << endl;
                AOM_ask_value_string(attachments[i],"object_desc",&pBOPObjectDesc);
                cout << "pBOP item id is : " << pBOPItemId << endl;
                pBOPItemIdStr = pBOPItemId;
                pBOPObjectDescStr = pBOPObjectDesc;
                MppToPalmsysReturn = MppToPalmsys(pBOPItemIdStr,pBOPObjectDescStr);                
                cout << MppToPalmsysReturn.dump(4) << endl;

                SendToPalmsys(MppToPalmsysReturn);

            }
            else if(pBOPObjectTypeStr=="MEProcessRevision")
            {
                AOM_ask_value_string(attachments[i],"item_id",&pBOPItemId);
                cout << "process item id is : " << pBOPItemId << endl;
                AOM_ask_value_string(attachments[i],"object_desc",&pBOPObjectDesc);
                cout << "process item id is : " << pBOPItemId << endl;
                pBOPItemIdStr = pBOPItemId;
                pBOPObjectDescStr = pBOPObjectDesc;
                MppToPalmsysReturn = MppToPalmsysProcess(pBOPItemIdStr,pBOPObjectDescStr);                
                cout << MppToPalmsysReturn.dump(4) << endl;

                SendToPalmsys(MppToPalmsysReturn);
            }
            else if(pBOPObjectTypeStr=="MEOPRevision")
            {
                AOM_ask_value_string(attachments[i],"item_id",&pBOPItemId);
                cout << "Operation item id is : " << pBOPItemId << endl;
                AOM_ask_value_string(attachments[i],"object_desc",&pBOPObjectDesc);
                cout << "Operation item id is : " << pBOPItemId << endl;
                pBOPItemIdStr = pBOPItemId;
                pBOPObjectDescStr = pBOPObjectDesc;
                MppToPalmsysReturn = MppToPalmsysOperation(pBOPItemIdStr,pBOPObjectDescStr);                
                cout << MppToPalmsysReturn.dump(4) << endl;

                SendToPalmsys(MppToPalmsysReturn);
            }
            else
            {
                cout << "Object type is not Mpp Object Type revision" << endl;
            }
        }
    } 
    return 0;
}

void setAddStrFuction1(int *count,char ***strset,char* str)
{

	*count=*count+1;

    cout << "\n setAddStrFuction "<<*count<<endl;

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
     cout << "\n setAddStrFuction value in function === "<<(*strset)[*count-1]<<endl;


}


//Aniket
extern DLLAPI int Revise_properties_post(METHOD_message_t *m, va_list args)
{


    cout<<"Process revise Function called..."<<endl;
    tag_t revIDqrytag = NULLTAG;
    QRY_find2("Control Objects...",&revIDqrytag);
    if(revIDqrytag!=NULLTAG)
    {
        char **revidValuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *revidEntries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        revidValuesp[0]="mppBOrevID";
        revidValuesp[1]="mppBOrevID";
        revidValuesp[2]="0";

        int revidqrycount = 0;
        tag_t *revidqrytag = NULLTAG;
        QRY_execute(revIDqrytag, 3, revidEntries, revidValuesp, &revidqrycount, &revidqrytag);
        if(revidqrycount>0)
        {
            cout<<"For MPP BO Control object found..."<<endl;

            tag_t source_rev = va_arg(args, tag_t);
            tag_t objTypeTag = NULLTAG;
            char *type_name = NULL;
            tag_t master = NULLTAG;
            tag_t rev = NULLTAG;
            tag_t bomrev = NULLTAG;
            int revision_count = 0;
            tag_t *revisions;
            char *rev_id = NULL;
            int rev_seq = NULL;
            char *secondlastrevid = NULL;
            int secondlastrevseq = NULL;
            int Desc_seq1 = 0;
            char *revi = NULL;
            tag_t attr_id;
            int bvr_count = 0;
            tag_t *bvr_tag =NULL;
            
            char *bvr_ObjectName	= NULL;
            char *bvritemid	= NULL;		
            char *formitemid	= NULL;	
			char *bvrrev	= NULL;	
            char *oojname = NULL;
            oojname=(char *)MEM_alloc(10);
            char *userinfo1forrevID = NULL;
            vector<string> tokens;

            if (TCTYPE_ask_object_type(source_rev, &objTypeTag) != ITK_ok);
            if (TCTYPE_ask_name2(objTypeTag, &type_name) != ITK_ok);
            cout<<"Type Name ..."<<type_name<<endl;

            AOM_ask_value_string(revidqrytag[0],"t5_Userinfo1",&userinfo1forrevID);
            cout<<"userinfo1forrevID"<<userinfo1forrevID<<endl;

            char* token = tc_strtok(userinfo1forrevID, ",");
            
            while (token != nullptr)
            {
                tokens.push_back(token);
                token = tc_strtok(nullptr, ",");
            }
            for (const auto& t : tokens)
            {
                cout << t << std::endl;
            }
            bool found = find(tokens.begin(), tokens.end(), type_name) != tokens.end();
            
            if (found)
            {

                cout<<"Target object found in Vector"<<endl;


                if (ITEM_ask_item_of_rev(source_rev, &master));
                if (ITEM_ask_latest_rev(master, &rev));
                if (ITEM_list_all_revs(master, &revision_count, &revisions));
                if (AOM_ask_value_string(rev, "item_revision_id", &rev_id) != ITK_ok);
                if (AOM_ask_value_int(rev, "sequence_id", &rev_seq) != ITK_ok);
                if (AOM_ask_value_string(revisions[revision_count - 2], "item_revision_id", &secondlastrevid) != ITK_ok);
                if (AOM_ask_value_int(revisions[revision_count - 2], "sequence_id", &secondlastrevseq) != ITK_ok);

                cout<<"Current revision ID:- "<<rev_id<<endl;
                cout<<"currwnt revision seq:- "<<rev_seq<<endl;

                cout<<"Second last revision ID:- "<<secondlastrevid<<endl;
                cout<<"Second last revision seq:- "<<secondlastrevseq<<endl;

                //Desc_seq1 = secondlastrevseq + 1;

                //cout<<"Updated seq:- "<<Desc_seq1<<endl;


                if (AOM_lock(rev));
                if (AOM_set_value_int(rev, "sequence_id", rev_seq) != ITK_ok);
                if (AOM_save_without_extensions(rev) != ITK_ok);
			    if (AOM_unlock(rev) != ITK_ok);
                revi = (char *)MEM_alloc(10);

                revi = strtok(secondlastrevid, ";");
                cout<<"revi:- "<<revi<<endl;

                //if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
                cout<<"after change class name2"<<endl;

                
                if (strcmp(revi, "NR") == 0)
				{
                    //if (AOM_lock(rev));
                    AOM_refresh(rev,1);
                    cout<<"1"<<endl;
                    //if (POM_set_attr_string(1, &rev, attr_id, "A") != ITK_ok)
                    if (AOM_UIF_set_value(rev, "item_revision_id", "A") != ITK_ok);
                    //if (AOM_UIF_set_value(rev, "current_revision_id", "A") != ITK_ok);
                    //if (AOM_set_value_string(rev, "item_revision_id", "A") != ITK_ok);
                    cout<<"2"<<endl;
                    if (AOM_save_without_extensions(rev) != ITK_ok);
                    cout<<"3"<<endl;
                    AOM_refresh(rev,0);
			        //if (AOM_unlock(rev) != ITK_ok);
                    cout<<"4"<<endl;
                    

					//strcat(oojname, "A;1");
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok);
					cout<<"bvr count:- "<<bvr_count<<endl;
					if (bvr_count >0)
					{
                        bomrev=bvr_tag[0];
                        
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok);
						printf("\nValue of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
                        char *oojname = NULL;
                        oojname=(char *)MEM_alloc(50);
                        
                        tc_strcpy(oojname,"");
                        cout<<"1"<<endl;
                        tc_strcpy(oojname,bvritemid);
                        cout<<"2"<<endl;
                        tc_strcat(oojname,"/");
                        cout<<"3"<<endl;
                        tc_strcat(oojname,"A");
                        cout<<"333"<<endl;
                        tc_strcat(oojname,"-View");
                        cout<<"3"<<oojname<<endl;
                        cout<<"oojname"<<oojname<<endl;
                        cout<<"oojname:- "<<oojname<<endl;
                        
                        
                        if(AOM_lock(bomrev)!= ITK_ok);
                        cout<<"4"<<endl;
                        if (AOM_set_value_string(bomrev, "object_name", oojname) != ITK_ok);
                        cout<<"44"<<endl;
                        if(AOM_save_without_extensions(bomrev)!=ITK_ok);
                        cout<<"444"<<endl;
                        AOM_refresh(bomrev,0);
                        cout<<"4444"<<endl;
                        
                    }
                    int cnt = 0;
                    tag_t relation_type = NULLTAG;
                    tag_t *attachments = NULLTAG;
                    tag_t dataset = NULLTAG;
                    char *ObjectClassType = NULL;
                    char *ObjectName = NULL;
                    char *formname = NULL;
                    formname=(char *)MEM_alloc(30);
                    //if(GRM_find_relation_type("IMAN_master_form",&relation_type));
                    if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok);
                    cout<<"comment Dataset count:- "<<cnt<<endl;
                    if(cnt>0)
                    {
                        for (int i = 0; i < cnt; i++)
                        {
                            dataset = attachments[i];
                            if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok);
                            cout<<"Dataset type:- "<<ObjectClassType<<endl;
                            if ((strcmp(ObjectClassType, "MEProcessRevision Master") == 0) ||(strcmp(ObjectClassType, "MEOPRevision Master") == 0)||
                            (strcmp(ObjectClassType, "Mfg0MEProcStatnRevisionMaster") == 0)||(strcmp(ObjectClassType, "Mfg0MEProcLineRevisionMaster") == 0)||(strcmp(ObjectClassType, "MEProductBOPRevMaster") == 0))
                            {
                                if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok);
                                cout<<"Previous revision master :- "<<ObjectName<<endl;

                                formitemid=tc_strtok(ObjectName,"/");
                                cout<<"formitemid:-"<<formitemid<<endl;
                                tc_strcpy(formname,"");
                                cout<<"1"<<endl;
                                tc_strcpy(formname,formitemid);
                                cout<<"2"<<endl;
                                tc_strcat(formname,"/");
                                cout<<"3"<<endl;
                                tc_strcat(formname,"A;1");
                                cout<<"3"<<formname<<endl;
                                cout<<"formname"<<formname<<endl;
                                AOM_refresh(dataset,1);
                                cout<<"checkout"<<endl;
                                if (AOM_set_value_string(dataset, "object_name", formname) != ITK_ok);
                                cout<<"value set"<<endl;
                                if(AOM_save_without_extensions(dataset)!=ITK_ok);   
                                cout<<"saved"<<endl; 
                                AOM_refresh(dataset,0);
                                cout<<"Check IN"<<endl;

                            }
                        }
                        
                    }
                    
				}

            }
            else 
            {
                cout << "Target object not found....." <<endl;   
            }

            /*if ((strcmp(type_name, "MEProcessRevision") == 0)||(strcmp(type_name, "MEOPRevision") == 0)||(strcmp(type_name, "Mfg0MEProcStatnRevision") == 0)||
            (strcmp(type_name, "Mfg0MEProcLineRevision") == 0) || (strcmp(type_name, "MEProductBOPRevision") == 0))*/
            

        }

    }
    return 0;
}

int CheckInPostAction(METHOD_message_t *msg, va_list args)
{
    cout << "Inside CheckInPostAction" << endl;
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *type_name = NULL;
    string ObjectType;

    tag_t COQueryTag = NULLTAG;
    QRY_find2("Control Objects...",&COQueryTag);
    if(COQueryTag!=NULLTAG)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="CostDriver";
        Valuesp[1]="Creation";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;
        QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp>0)
        {
            AOM_ask_value_string(objTag,"object_string",&ObjStr);
            cout << "ObjStr : "<< ObjStr << endl;
            TCTYPE_ask_object_type(objTag,&objTypeTag);
            TCTYPE_ask_name2(objTypeTag,&type_name);
            cout << "object_type : " << type_name << endl;
            ObjectType = type_name;
            if((ObjectType == "MEProcessRevision") || (ObjectType=="Process Revision"))
            {
                cout << "Process checkin code is calling successfully" << endl;

                char *ProcessItemId = NULL;
                tag_t WorkflowTemplateTag = NULLTAG;
                tag_t MppToPalmsysProcess = NULLTAG;
                int attachment_type = 1;
                AOM_ask_value_string(objTag,"item_id",&ProcessItemId);
                cout << "ProcessItemId : "<< ProcessItemId << endl;
                EPM_find_template2("MppToPalmsys",0,&WorkflowTemplateTag);
                if(WorkflowTemplateTag != NULLTAG)
                {
                    EPM_create_process("MppToPalmsys","", WorkflowTemplateTag, 1, &objTag, &attachment_type, &MppToPalmsysProcess);
                    if(MppToPalmsysProcess != NULLTAG)
                    {
                        cout << "MppToPalmsys Workflow Successfully attached" << endl;
                    }
                    else
                    {
                        cout << "MppToPalmsys Workflow attachment failed" << endl;
                    }
                } 
                else
                {
                    cout << "Template not found" << endl;
                }
            }
            else if((ObjectType == "MEOPRevision") || (ObjectType=="Operation Revision"))
            {
                cout << "Operation checkin code is calling successfully" << endl;

                // char *OperationItemId = NULL;
                // char *OperationWorkCenter = NULL;
                // tag_t ItemRevisionQryTag = NULLTAG;
                // AOM_ask_value_string(objTag,"item_id",&OperationItemId);
                // cout << "Operation Item Id : " << OperationItemId << endl;
                // AOM_ask_value_string(objTag,"t5_OP_EPOCHPEBCNo",&OperationWorkCenter);
                // cout << "Operation Work Center : " << OperationWorkCenter << endl;
                // QRY_find2("Item Revision...",&ItemRevisionQryTag);
                // if(ItemRevisionQryTag!=NULLTAG)
                // {
                //     int WorkCenterCount = 0;
                //     tag_t *WorkCenterTags = NULLTAG;
                //     char *ItemRevEntry[2] = {"Item ID","Type"};
                //     char **ItemRevValue = (char **)MEM_alloc(5 * sizeof(char *));
                //     ItemRevValue[0] = OperationWorkCenter;
                //     ItemRevValue[1] = "T5_WorkCenterRevision";
                //     QRY_execute(ItemRevisionQryTag,2,ItemRevEntry,ItemRevValue,&WorkCenterCount,&WorkCenterTags);
                //     cout << "WorkCenterCount : " << WorkCenterCount << endl;
                //     if(WorkCenterCount>0)
                //     {
                //         char *WorkCenterCostDriver = NULL;
                //         char *WorkCenterUOM = NULL;
                //         char *WorkCenterDesc = NULL;
                //         char *WorkCenterModel = NULL;
                //         AOM_ask_value_string(WorkCenterTags[0],"t5_EPOCHCostDriver",&WorkCenterCostDriver);
                //         AOM_ask_value_string(WorkCenterTags[0],"t5_EPOCHUom",&WorkCenterUOM);
                //         AOM_ask_value_string(WorkCenterTags[0],"t5_EPOCHBCDesc",&WorkCenterDesc);
                //         AOM_ask_value_string(WorkCenterTags[0],"t5_Model",&WorkCenterModel);
                //         cout << "WorkCenterCostDriver : " << WorkCenterCostDriver << endl;
                //         cout << "WorkCenterUOM        : " << WorkCenterUOM << endl;
                //         cout << "WorkCenterDesc       : " << WorkCenterDesc << endl;
                //         cout << "WorkCenterModel      : " << WorkCenterModel << endl;
                //         AOM_lock(objTag);
                //         AOM_set_value_string(objTag,"t5_OP_EPOCHCostDriver",WorkCenterCostDriver);
                //         AOM_set_value_string(objTag,"t5_OP_EPOCHUom",WorkCenterUOM);
                //         AOM_set_value_string(objTag,"t5_OP_EPOCHBCDesc",WorkCenterDesc);
                //         AOM_set_value_string(objTag,"t5_OP_PSModel",WorkCenterModel);
                //         AOM_save_without_extensions(objTag);
                //         AOM_unlock(objTag);
                //         AOM_refresh(objTag,0);
                //     }
                // }

                char *OpItemId = NULL;
                tag_t WorkflowTemplateTag = NULLTAG;
                tag_t MppToPalmsysProcess = NULLTAG;
                int attachment_type = 1;
                AOM_ask_value_string(objTag,"item_id",&OpItemId);
                cout << "OpItemId : "<< OpItemId << endl;
                EPM_find_template2("MppToPalmsys",0,&WorkflowTemplateTag);
                if(WorkflowTemplateTag != NULLTAG)
                {
                    EPM_create_process("MppToPalmsys","", WorkflowTemplateTag, 1, &objTag, &attachment_type, &MppToPalmsysProcess);
                    if(MppToPalmsysProcess != NULLTAG)
                    {
                        cout << "MppToPalmsys Workflow Successfully attached" << endl;
                    }
                    else
                    {
                        cout << "MppToPalmsys Workflow attachment failed" << endl;
                    }
                } 
                else
                {
                    cout << "Template not found" << endl;
                }
            }
            else if((ObjectType == "MEProductBOPRevision") || (ObjectType == "Product BOP Revision"))
            {
                char *ProductBOPItemId = NULL;
                tag_t WorkflowTemplateTag = NULLTAG;
                tag_t MppToPalmsysProcess = NULLTAG;
                int attachment_type = 1;
                AOM_ask_value_string(objTag,"item_id",&ProductBOPItemId);
                cout << "ProductBOPItemId : "<< ProductBOPItemId << endl;
                EPM_find_template2("MppToPalmsys",0,&WorkflowTemplateTag);
                if(WorkflowTemplateTag != NULLTAG)
                {
                    EPM_create_process("MppToPalmsys","", WorkflowTemplateTag, 1, &objTag, &attachment_type, &MppToPalmsysProcess);
                    if(MppToPalmsysProcess != NULLTAG)
                    {
                        cout << "MppToPalmsys Workflow Successfully attached" << endl;
                    }
                    else
                    {
                        cout << "MppToPalmsys Workflow attachment failed" << endl;
                    }
                } 
                else
                {
                    cout << "Template not found" << endl;
                } 
            }
        }
    }

    
    return 0;
}

//PLANT BOP CUSTOM ID GENERATION START Indira11
int PlantBOPItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside Plant bop ID generation" << endl;

    tag_t tObjTag = va_arg(args,  tag_t);

    tag_t tObjTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *cTypeName = NULL;
    string ObjectType1;
    tag_t tCOQueryTag = NULLTAG;

    char *IDofPlant = NULL;
    AOM_ask_value_string(tObjTag,"object_string",&ObjStr);
    cout << "ObjStr : "<< ObjStr << endl;
    TCTYPE_ask_object_type(tObjTag,&tObjTypeTag);
    TCTYPE_ask_name2(tObjTypeTag,&cTypeName);
    cout << "object_type : " << cTypeName << endl;
    AOM_ask_value_string(tObjTag,"item_id",&IDofPlant);
    cout << "IDofPlant is : " << IDofPlant <<endl;


    if (IDofPlant != nullptr && IDofPlant[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    }
    else
    {
        QRY_find2("Control Objects...",&tCOQueryTag);
        if(tCOQueryTag!=NULLTAG)
        {
            char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
            char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            Valuesp[0]="Plant";
            Valuesp[1]="Creation";
            Valuesp[2]="0";
            int iCOCountp = 0;
            tag_t *COTagsP = NULLTAG;
            QRY_execute(tCOQueryTag, 3, Entries, Valuesp, &iCOCountp, &COTagsP);
            if(iCOCountp>0)
            {

                ObjectType1 = cTypeName;
                if((ObjectType1 == "Mfg0MEPlantBOPRevision") || (ObjectType1=="Plant BOP Revision")||(ObjectType1 == "Mfg0MEPlantBOP"))
                {
                    cout << "Plant BOP found" << endl;
                    char *PlantObjectName = NULL;
                    char *PlantAggregateName = NULL;
                    char *PlantBOPPlantCode = NULL;
                    string PlantAggregateName_Str;
                    string PlantBOPPlantCode_Str;
                    tag_t PlantMasterTag = NULLTAG;
                    tag_t			tTaskTagrev		= NULLTAG;

                    ITEM_ask_latest_rev(tObjTag,&tTaskTagrev);
                    if(tTaskTagrev!=NULL)
                    {
                        AOM_ask_value_string(tTaskTagrev,"object_name",&PlantObjectName);
                        cout << "PlantObjectName : " << PlantObjectName <<endl;
                        AOM_ask_value_string(tTaskTagrev,"t5_PR_aggregate",&PlantAggregateName);
                        cout << "PlantAggregateName : " << PlantAggregateName <<endl;
                        AOM_ask_value_string(tTaskTagrev,"t5_PR_plantcode",&PlantBOPPlantCode);
                        cout << "PlantBOPPlantCode : " << PlantBOPPlantCode <<endl;
                        PlantAggregateName_Str = PlantAggregateName;
                        PlantBOPPlantCode_Str = PlantBOPPlantCode;

                        //START NEW ID GENERATION LOGIC WITH _1,_2 etc 1001ENG01L
					    string passedPlantID=IDofPlant;
					    string existingIdPlantCode = passedPlantID.substr(0, 4);
					    cout << "existingIdPlantCode : " << existingIdPlantCode <<endl;
					    cout << "PlantBOPPlantCode_Str : " << PlantBOPPlantCode_Str <<endl;
                        if(existingIdPlantCode.compare( PlantBOPPlantCode_Str )==0)
					    {
                            cout << "In PRE COndition it is taken case11 " << existingIdPlantCode <<endl;

						}
                        else
                        {
                            string PlantItemIdCat;
                            PlantItemIdCat = PlantBOPPlantCode_Str + PlantAggregateName_Str + "*";
                            tag_t ItemRevisinQueryTag = NULLTAG;
                            char *QueryInputEntry[2] = {"Item ID","Type"};
                            char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                            int QueryOutputCount = 0;
                            tag_t *QueryOutputTags = NULLTAG;
                            char *keys[1] = {"creation_date"};
                            int orders[1] = {2};
                            QRY_find2("Item Revision...",&ItemRevisinQueryTag);
                            if(ItemRevisinQueryTag!=NULLTAG)
                            {
                                QueryInputValue[0] = PlantItemIdCat.c_str();
                                QueryInputValue[1] = "Mfg0MEPlantBOPRevision";
                                QRY_execute_with_sort(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue,1,keys,orders,&QueryOutputCount, &QueryOutputTags);
                                cout << "Number of Plant BOP objects found with sort criteria creation_date: " << QueryOutputCount << endl;
                                if(QueryOutputCount>0)
                                {
                                    cout << "After changing qry sort criteria with Item_id........"  << endl;

                                    char *ExistingPlantItemId = NULL;
                                    AOM_ask_value_string(QueryOutputTags[0],"item_id",&ExistingPlantItemId);
                                    cout << "ExistingPlantItemId : " << ExistingPlantItemId << endl;
                                    string ExistingPlantItemId_Str = ExistingPlantItemId;
                                    string PlantNumber = ExistingPlantItemId_Str.substr(7,2);
                                    cout << "PlantNumber : " << PlantNumber << endl;
                                    int PlantNumberInt = stoi(PlantNumber);
                                    cout << "PlantNumberInt : " << PlantNumberInt << endl;
                                    int NewPlantNumberInt = PlantNumberInt + 1;
                                    cout << "NewPlantNumberInt : " << NewPlantNumberInt << endl;
                                    ostringstream oss;
                                    oss << setw(2) << setfill('0') << NewPlantNumberInt;
                                    string NewPlantNumber_Str = PlantBOPPlantCode_Str + PlantAggregateName_Str + oss.str() + "P";
                                    cout << "NewPlantNumber_Str : " << NewPlantNumber_Str << endl;
                                    //ITEM_ask_item_of_rev(objTag,&LineMasterTag);
                                    ITEM_ask_item_of_rev(tTaskTagrev,&PlantMasterTag);
                                    if(PlantMasterTag!=NULLTAG)
                                    {
                                        cout << "Plant BOP  Master Found " <<endl;

                                        //AOM_lock(LineMasterTag);
                                        AOM_refresh(PlantMasterTag,1);
                                        cout << "1" <<endl;
                                        AOM_set_value_string(PlantMasterTag,"item_id",NewPlantNumber_Str.c_str());
                                        cout << "2" <<endl;
                                        AOM_set_value_string(PlantMasterTag,"object_name",NewPlantNumber_Str.c_str());
                                        cout << "3" <<endl;
                                        AOM_save_without_extensions(PlantMasterTag);
                                        cout << "4" <<endl;
                                        AOM_refresh(PlantMasterTag,0);
                                        //AOM_set_value_string(objTag,"object_name",NewPlantNumber_Str.c_str());
                                        //AOM_set_value_string(objTag,"item_id",NewPlantNumber_Str.c_str());
                                        cout << "5" <<endl;

                                        AOM_refresh(tTaskTagrev,1);
                                        cout << "6" <<endl;
                                        AOM_set_value_string(tTaskTagrev,"object_name",NewPlantNumber_Str.c_str());
                                        cout << "7" <<endl;
                                        AOM_set_value_string(tTaskTagrev,"item_id",NewPlantNumber_Str.c_str());
                                        cout << "8" <<endl;
                                        AOM_save_without_extensions(tTaskTagrev);
                                        cout << "9" <<endl;
                                        AOM_refresh(tTaskTagrev,1);
                                        cout << "10" <<endl;
                                    }
                                }
                                else
                                {
                                    cout << "Inside else condition" <<endl;

                                    ITEM_ask_item_of_rev(tTaskTagrev,&PlantMasterTag);
                                    if(PlantMasterTag!=NULLTAG)
                                    {
                                        string NewPlantNumber_Str = PlantBOPPlantCode_Str + PlantAggregateName_Str + "01" + "P";

                                        cout << "Plant BOP Master Found " <<endl;
                                        //AOM_lock(LineMasterTag);
                                        AOM_refresh(PlantMasterTag,1);
                                        AOM_set_value_string(PlantMasterTag,"item_id",NewPlantNumber_Str.c_str());
                                        AOM_set_value_string(PlantMasterTag,"object_name",NewPlantNumber_Str.c_str());
                                        AOM_save_without_extensions(PlantMasterTag);
                                        AOM_unlock(PlantMasterTag);
                                        AOM_refresh(PlantMasterTag,0);

                                        AOM_refresh(tTaskTagrev,1);
                                        AOM_set_value_string(tTaskTagrev,"object_name",NewPlantNumber_Str.c_str());
                                        AOM_set_value_string(tTaskTagrev,"item_id",NewPlantNumber_Str.c_str());
                                        AOM_save_without_extensions(tTaskTagrev);
                                        AOM_unlock(tTaskTagrev);
                                        AOM_refresh(tTaskTagrev,0);
                                    }
                                    else
                                    {
                                        cout << "Item Master not found... " <<endl;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        cout << "Revision not created......." <<endl;

                    }
                }
            }
        }
    }
    return 0;
}
//PLANT BOP CUSTOM ID GENERATION END

//Plant ID for _1,_2,_3...Start Indira11
int PlantBOPItemIDAssignmentPre(METHOD_message_t *msg, va_list args)
{
    cout << "Inside Plant bop ID generation" << endl;

    tag_t tObjTag = va_arg(args,  tag_t);

    tag_t tObjTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *cTypeName = NULL;
    char *ExistingPlantItemId = NULL;
    string ObjectType1;
    tag_t tCOQueryTag = NULLTAG;

    char *IDofPlant = NULL;
    AOM_ask_value_string(tObjTag,"object_string",&ObjStr);
    cout << "ObjStr : "<< ObjStr << endl;
    TCTYPE_ask_object_type(tObjTag,&tObjTypeTag);
    TCTYPE_ask_name2(tObjTypeTag,&cTypeName);
    cout << "object_type : " << cTypeName << endl;
    AOM_ask_value_string(tObjTag,"item_id",&IDofPlant);
    cout << "IDofPlant is : " << IDofPlant <<endl;


    if (IDofPlant != nullptr && IDofPlant[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    }
    else
    {
        QRY_find2("Control Objects...",&tCOQueryTag);
        if(tCOQueryTag!=NULLTAG)
        {
            char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
            char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            Valuesp[0]="Plant";
            Valuesp[1]="Creation";
            Valuesp[2]="0";
            int iCOCountp = 0;
            tag_t *COTagsP = NULLTAG;
            QRY_execute(tCOQueryTag, 3, Entries, Valuesp, &iCOCountp, &COTagsP);
            if(iCOCountp>0)
            {

                ObjectType1 = cTypeName;
                if((ObjectType1 == "Mfg0MEPlantBOPRevision") || (ObjectType1=="Plant BOP Revision")||(ObjectType1 == "Mfg0MEPlantBOP"))
                {
                    cout << "11Plant BOP found" << endl;
                    string passedPlantID=IDofPlant;
					string existingIDPlantCode = passedPlantID.substr(0, 4);
					cout << " existingIDPlantCode : " << existingIDPlantCode <<endl;

					if((existingIDPlantCode.compare( "1001" )==0) ||
                       (existingIDPlantCode.compare( "1500" )==0) ||
                       (existingIDPlantCode.compare( "2001" )==0) ||
                       (existingIDPlantCode.compare( "3001" )==0) ||
                       (existingIDPlantCode.compare( "3100" )==0))
					{
                        tag_t ItemRevisinQueryTag = NULLTAG;
                        char *QueryInputEntry[2] = {"Item ID","Type"};
                        char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                        int QueryOutputCount = 0;
                        tag_t *QueryOutputTags = NULLTAG;
                        char *keys[1] = {"creation_date"};
                        int orders[1] = {2};
                        QRY_find2("Item Revision...",&ItemRevisinQueryTag);
                        if(ItemRevisinQueryTag!=NULLTAG)
                        {
                            string searchPlantID = passedPlantID + "*";
                            QueryInputValue[0] = searchPlantID.c_str();
                            QueryInputValue[1] = "Mfg0MEPlantBOPRevision";
                            QRY_execute_with_sort(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue,1,keys,orders,&QueryOutputCount, &QueryOutputTags);
                            cout << "Number of Plant BOP objects found with sort criteria creation_date: " << QueryOutputCount << endl;
                            if(QueryOutputCount>0)
                            {
                                cout << "_1,_2 Logic Started"  << endl;
                                AOM_ask_value_string(QueryOutputTags[0],"item_id",&ExistingPlantItemId);
								cout << "ExistingPlantItemId : " << ExistingPlantItemId << endl;
								string sExistingItemID = ExistingPlantItemId;
								string NewPlantItemID;
								size_t Pos = sExistingItemID.find('_');
								if (Pos != string::npos)
								{
									string BaseIdLine = sExistingItemID.substr(0, Pos);
									string suffixStrLine =sExistingItemID .substr(Pos + 1);
									cout << "11 Base id :" << BaseIdLine <<endl;
									int iSuffix = stoi(suffixStrLine);
									iSuffix++;
									NewPlantItemID = BaseIdLine + "_" + to_string(iSuffix);

								}
								else
								{
									NewPlantItemID= sExistingItemID + "_1";
									cout << "11 Inside Else condition" << endl;
								}
								tag_t  PlantNewAttrId = NULLTAG;

								POM_attr_id_of_attr("item_id", "Mfg0MEPlantBOP", &PlantNewAttrId);
								AOM_refresh(tObjTag, TRUE);
								POM_set_env_info(POM_bypass_attr_update, FALSE, 0, 0, NULLTAG, NULL);
								POM_set_attr_string(1, &tObjTag, PlantNewAttrId, NewPlantItemID.c_str());
								AOM_save_without_extensions(tObjTag);
								AOM_refresh(tObjTag, TRUE);
								cout << "END OF ID NEW ID CODE :" << NewPlantItemID <<endl;
							}

						}

					}

                }

            }

        }
    }

    return 0;
}

//Plant ID for _1,_2,_3...End


//LINE ITEM ID FOR  _1, _2 START
int LineItemIDAssignmentPre(METHOD_message_t *msg, va_list args)
{
    cout << "1111Inside LineItemIDAssignment after addition const" << endl;

    tag_t objTag = va_arg(args,  tag_t);//proc line
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
    tag_t objTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *type_name = NULL;
    char *ExistingLineItemId = NULL;
    string ObjectType;  
    tag_t COQueryTag = NULLTAG;

    char *IDofLine = NULL;
    AOM_ask_value_string(objTag,"object_string",&ObjStr);
    cout << "ObjStr : "<< ObjStr << endl;
    TCTYPE_ask_object_type(objTag,&objTypeTag);
    TCTYPE_ask_name2(objTypeTag,&type_name);
    cout << "object_type : " << type_name << endl;
    AOM_ask_value_string(objTag,"item_id",&IDofLine);
    cout << "IDofLine is : " << IDofLine <<endl;


    if (IDofLine != nullptr && IDofLine[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    }
    else
    {
        QRY_find2("Control Objects...",&COQueryTag);
        if(COQueryTag!=NULLTAG)
        {
            char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
            char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            Valuesp[0]="Line";
            Valuesp[1]="Creation";
            Valuesp[2]="0";
            int COCountp = 0;
            tag_t *COTagsP = NULLTAG;
            QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
            if(COCountp>0) 
            {
                
                ObjectType = type_name;
                if((ObjectType == "Mfg0MEProcLineRevision") || (ObjectType=="Process Line Revision")||(ObjectType == "Mfg0MEProcLine"))
                {
                    cout << "11Process Line found" << endl;
                    string passedLineID=IDofLine;
					string existingIDPlantCode = passedLineID.substr(0, 4);
					cout << " existingIDPlantCode : " << existingIDPlantCode <<endl;

					if((existingIDPlantCode.compare( "1001" )==0) || 
                       (existingIDPlantCode.compare( "1500" )==0) || 
                       (existingIDPlantCode.compare( "2001" )==0) || 
                       (existingIDPlantCode.compare( "3001" )==0) || 
                       (existingIDPlantCode.compare( "3100" )==0))
					{
                        tag_t ItemRevisinQueryTag = NULLTAG;
                        char *QueryInputEntry[2] = {"Item ID","Type"};
                        char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                        int QueryOutputCount = 0;
                        tag_t *QueryOutputTags = NULLTAG;
                        char *keys[1] = {"creation_date"};
                        int orders[1] = {2};
                        QRY_find2("Item Revision...",&ItemRevisinQueryTag);
                        if(ItemRevisinQueryTag!=NULLTAG)
                        {
                            tag_t StationMasterTag = NULLTAG;
							string searchLineID = passedLineID + "*";

                            QueryInputValue[0] = searchLineID.c_str();
                            QueryInputValue[1] = "Mfg0MEProcLineRevision";
                            QRY_execute_with_sort(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue,1,keys,orders,&QueryOutputCount, &QueryOutputTags);
                            cout << "111 Number of Process Line found with sort criteria creation_date: " << QueryOutputCount << endl;
                            if(QueryOutputCount>0)
                            {
                                //_1,_2...etc Logic
                                AOM_ask_value_string(QueryOutputTags[0],"item_id",&ExistingLineItemId);
								cout << "ExistingLineItemId : " << ExistingLineItemId << endl;
								string sExistingItemID = ExistingLineItemId;
								string NewLineItemID;
								size_t Pos = sExistingItemID.find('_');
								if (Pos != string::npos)
								{
									string BaseIdLine = sExistingItemID.substr(0, Pos);
									string suffixStrLine =sExistingItemID .substr(Pos + 1);
									cout << "11 Base id :" << BaseIdLine <<endl;
									int iSuffix = stoi(suffixStrLine);
									iSuffix++;
									NewLineItemID = BaseIdLine + "_" + to_string(iSuffix);

								}
								else
								{
									NewLineItemID= sExistingItemID + "_1";
									cout << "11 Inside Else condition" << endl;
								}
								tag_t  LineNewAttrId = NULLTAG;

								POM_attr_id_of_attr("item_id", "Mfg0MEProcLine", &LineNewAttrId);
								AOM_refresh(objTag, TRUE);           
								POM_set_env_info(POM_bypass_attr_update, FALSE, 0, 0, NULLTAG, NULL);
								POM_set_attr_string(1, &objTag, LineNewAttrId, NewLineItemID.c_str());
								AOM_save_without_extensions(objTag);
								AOM_refresh(objTag, TRUE);
								cout << "END OF ID NEW ID CODE :" << NewLineItemID <<endl;
							}
						
						}
					
					}
					
                }

            }

        }
    }

    return 0;
}
					
//LINE ITEM ID FOR  _1, _2 END

int LineItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside LineItemIDAssignment after addition const" << endl;

    tag_t objTag = va_arg(args,  tag_t);//proc line
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
    tag_t objTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *type_name = NULL;
    string ObjectType;  
    tag_t COQueryTag = NULLTAG;

    char *IDofLine = NULL;
    AOM_ask_value_string(objTag,"object_string",&ObjStr);
    cout << "ObjStr : "<< ObjStr << endl;
    TCTYPE_ask_object_type(objTag,&objTypeTag);
    TCTYPE_ask_name2(objTypeTag,&type_name);
    cout << "object_type : " << type_name << endl;
    AOM_ask_value_string(objTag,"item_id",&IDofLine);
    cout << "IDofLine is : " << IDofLine <<endl;


    if (IDofLine != nullptr && IDofLine[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    }
    else
    {
        QRY_find2("Control Objects...",&COQueryTag);
        if(COQueryTag!=NULLTAG)
        {
            char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
            char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            Valuesp[0]="Line";
            Valuesp[1]="Creation";
            Valuesp[2]="0";
            int COCountp = 0;
            tag_t *COTagsP = NULLTAG;
            QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
            if(COCountp>0) 
            {
                
                ObjectType = type_name;
                if((ObjectType == "Mfg0MEProcLineRevision") || (ObjectType=="Process Line Revision")||(ObjectType == "Mfg0MEProcLine"))
                {
                    cout << "Process Line found" << endl;
                    char *LineObjectName = NULL;
                    char *LineAggregateName = NULL;
                    char *LinePlantCode = NULL;
                    string LineAggregateName_Str;
                    string LinePlantCode_Str;
                    tag_t LineMasterTag = NULLTAG;
                    tag_t			TaskTagrev		= NULLTAG;

                    ITEM_ask_latest_rev(objTag,&TaskTagrev);
                    if(TaskTagrev!=NULL)
                    {
                        AOM_ask_value_string(TaskTagrev,"object_name",&LineObjectName);
                        cout << "LineObjectName : " << LineObjectName <<endl;
                        AOM_ask_value_string(TaskTagrev,"t5_PR_aggregate",&LineAggregateName);
                        cout << "LineAggregateName : " << LineAggregateName <<endl;
                        AOM_ask_value_string(TaskTagrev,"t5_PR_plantcode",&LinePlantCode);
                        cout << "LinePlantCode : " << LinePlantCode <<endl;
                        LineAggregateName_Str = LineAggregateName;
                        LinePlantCode_Str = LinePlantCode;

                        //START NEW ID GENERATION LOGIC WITH _1,_2 etc 1001ENG01L
					    string passedLineID=IDofLine;
					    string existingIdPlantCode = passedLineID.substr(0, 4);
					    cout << "existingIdPlantCode : " << existingIdPlantCode <<endl;
					    cout << "LinePlantCode_Str : " << LinePlantCode_Str <<endl;
                        if(existingIdPlantCode.compare( LinePlantCode_Str )==0)
					    {
                            cout << "In PRE COndition it is taken case11 " << existingIdPlantCode <<endl;
					
						}
                        else
                        {
                            string LineItemIdCat;
                            LineItemIdCat = LinePlantCode_Str + LineAggregateName_Str + "*";
                            tag_t ItemRevisinQueryTag = NULLTAG;
                            char *QueryInputEntry[2] = {"Item ID","Type"};
                            char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                            int QueryOutputCount = 0;
                            tag_t *QueryOutputTags = NULLTAG;
                            char *keys[1] = {"creation_date"};
                            int orders[1] = {2};
                            QRY_find2("Item Revision...",&ItemRevisinQueryTag);
                            if(ItemRevisinQueryTag!=NULLTAG)
                            {
                                QueryInputValue[0] = LineItemIdCat.c_str();
                                QueryInputValue[0] = LineItemIdCat.c_str();
                                QueryInputValue[1] = "Mfg0MEProcLineRevision";
                                QRY_execute_with_sort(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue,1,keys,orders,&QueryOutputCount, &QueryOutputTags);
                                cout << "Number of Process Line found with sort criteria creation_date: " << QueryOutputCount << endl;
                                if(QueryOutputCount>0)
                                {
                                    cout << "After changing qry sort criteria with Item_id........"  << endl;
                                
                                    char *ExistingLineItemId = NULL;
                                    AOM_ask_value_string(QueryOutputTags[0],"item_id",&ExistingLineItemId);
                                    cout << "ExistingLineItemId : " << ExistingLineItemId << endl;
                                    string ExistingLineItemId_Str = ExistingLineItemId;
                                    string LineNumber = ExistingLineItemId_Str.substr(7,2);
                                    cout << "LineNumber : " << LineNumber << endl;
                                    int LineNumberInt = stoi(LineNumber);
                                    cout << "LineNumberInt : " << LineNumberInt << endl;
                                    int NewLineNumberInt = LineNumberInt + 1;
                                    cout << "NewLineNumberInt : " << NewLineNumberInt << endl;                
                                    ostringstream oss;
                                    oss << setw(2) << setfill('0') << NewLineNumberInt;
                                    string NewLineNumber_Str = LinePlantCode_Str + LineAggregateName_Str + oss.str() + "L";
                                    cout << "NewLineNumber_Str : " << NewLineNumber_Str << endl;   
                                    //ITEM_ask_item_of_rev(objTag,&LineMasterTag);
                                    ITEM_ask_item_of_rev(TaskTagrev,&LineMasterTag);
                                    if(LineMasterTag!=NULLTAG)
                                    {
                                        cout << "Process Line Master Found " <<endl;
                                    
                                        //AOM_lock(LineMasterTag);
                                        AOM_refresh(LineMasterTag,1);
                                        cout << "1" <<endl;
                                        AOM_set_value_string(LineMasterTag,"item_id",NewLineNumber_Str.c_str());
                                        cout << "2" <<endl;
                                        AOM_set_value_string(LineMasterTag,"object_name",NewLineNumber_Str.c_str());
                                        cout << "3" <<endl;
                                        AOM_save_without_extensions(LineMasterTag);
                                        cout << "4" <<endl;
                                        AOM_refresh(LineMasterTag,0);
                                        //AOM_set_value_string(objTag,"object_name",NewLineNumber_Str.c_str());
                                        //AOM_set_value_string(objTag,"item_id",NewLineNumber_Str.c_str());
                                        cout << "5" <<endl;

                                        AOM_refresh(TaskTagrev,1);
                                        cout << "6" <<endl;
                                        AOM_set_value_string(TaskTagrev,"object_name",NewLineNumber_Str.c_str());
                                        cout << "7" <<endl;
                                        AOM_set_value_string(TaskTagrev,"item_id",NewLineNumber_Str.c_str());
                                        cout << "8" <<endl;
                                        AOM_save_without_extensions(TaskTagrev);
                                        cout << "9" <<endl;
                                        AOM_refresh(TaskTagrev,1);
                                        cout << "10" <<endl;                      
                                    }
                                }
                                else
                                {
                                    cout << "Inside else condition" <<endl;
                                
                                    ITEM_ask_item_of_rev(TaskTagrev,&LineMasterTag);
                                    if(LineMasterTag!=NULLTAG)
                                    {
                                        string NewLineNumber_Str = LinePlantCode_Str + LineAggregateName_Str + "01" + "L";
                                    
                                        cout << "Process Line Master Found " <<endl;
                                        //AOM_lock(LineMasterTag);
                                        AOM_refresh(LineMasterTag,1);
                                        AOM_set_value_string(LineMasterTag,"item_id",NewLineNumber_Str.c_str());
                                        AOM_set_value_string(LineMasterTag,"object_name",NewLineNumber_Str.c_str());
                                        AOM_save_without_extensions(LineMasterTag);
                                        AOM_unlock(LineMasterTag);
                                        AOM_refresh(LineMasterTag,0);
                                    
                                        AOM_refresh(TaskTagrev,1);
                                        AOM_set_value_string(TaskTagrev,"object_name",NewLineNumber_Str.c_str());
                                        AOM_set_value_string(TaskTagrev,"item_id",NewLineNumber_Str.c_str());
                                        AOM_save_without_extensions(TaskTagrev);
                                        AOM_unlock(TaskTagrev);
                                        AOM_refresh(TaskTagrev,0);
                                    }
                                    else
                                    {
                                        cout << "Item Master not found... " <<endl;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        cout << "Revision not created......." <<endl;

                    }
                }
            }
        }
    } 
    return 0;  
}


//ID GENERATION _1,_2 START

int StationItemIDAssignmentPre(METHOD_message_t *msg, va_list args)
{
    cout << "Inside StationItemIDAssignmentPre" << endl;
    tag_t ObjectTag = va_arg(args, tag_t);
    tag_t tObjectType = NULLTAG;
    char *OBJStr = NULL;
    char *TypeName = NULL;
    char *IDofstation = NULL;
    char *ExistingStationItemId = NULL;
    string OBJtype;
    string StationInput;    
    tag_t   qryTagCntrl	= NULLTAG;

    AOM_ask_value_string(ObjectTag,"object_string",&OBJStr);
    cout << "OBJStr : "<< OBJStr << endl;
	TCTYPE_ask_object_type(ObjectTag,&tObjectType);
	TCTYPE_ask_name2(tObjectType,&TypeName);
	cout << "object_type : " << TypeName << endl;
    AOM_ask_value_string(ObjectTag,"item_id",&IDofstation);
    cout << "IDofstation is : " << IDofstation <<endl;

    
    if (IDofstation != nullptr && IDofstation[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    } 
    else 
    {
        cout << "First character is not processing for the regular ID Generation..................\n";
        QRY_find2("Control Objects...", &qryTagCntrl);
        if (qryTagCntrl)
        {
            int n_entryCntrl =3;
            char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
            char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            qry_valuesCntrl[0]="station";
            qry_valuesCntrl[1]="creation";
            qry_valuesCntrl[2]="0";
            int  	control_number_found		= 0;
            tag_t 	*cntr_objects				= NULLTAG;


            printf("\n Control Object Query Found \n");fflush(stdout);
            QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
            if(control_number_found>0)
            {
                OBJtype = TypeName;
                if((OBJtype == "Mfg0MEProcStatnRevision") || (OBJtype=="Process Station Revision") || (OBJtype=="Mfg0MEProcStatn")) //doubt in Station Revision
                {
                    cout << "11 Station found" << endl;

                  //START NEW ID GENERATION LOGIC WITH _1,_2 etc.
					string passedID=IDofstation;
					string existingID = passedID.substr(0, 4);
					cout << "11existingID : " << existingID <<endl;

					if((existingID.compare( "1001" )==0) || 
                       (existingID.compare( "1500" )==0) || 
                       (existingID.compare( "2001" )==0) || 
                       (existingID.compare( "3001" )==0) || 
                       (existingID.compare( "3100" )==0))
					{
					
						tag_t ItemRevQueryTag = NULLTAG;
						char *QryIPEtry[2] = {"Item ID","Type"};
						char **QryInputVal = (char **) MEM_alloc(5 * sizeof(char *));
						int QueryOutputCnt = 0;
						tag_t *tQueryOutput = NULLTAG;
						char *cKeys[1] = {"creation_date"};
						int iOrders[1] = {2};
						QRY_find2("Item Revision...",&ItemRevQueryTag);
						if(ItemRevQueryTag!=NULLTAG)
						{
							tag_t StationMasterTag = NULLTAG;
							string searchID = passedID + "*";

							QryInputVal[0] = searchID.c_str();
							QryInputVal[1] = "Mfg0MEProcStatnRevision";
							QRY_execute_with_sort(ItemRevQueryTag, 2, QryIPEtry, QryInputVal,1,cKeys,iOrders,&QueryOutputCnt, &tQueryOutput);
							cout << "111 Number of Station Line found : " << QueryOutputCnt << endl;
							if(QueryOutputCnt>0)
							{
									//_1,_
								
								AOM_ask_value_string(tQueryOutput[0],"item_id",&ExistingStationItemId);
								cout << "ExistingStationItemId : " << ExistingStationItemId << endl;
								string ExistingItemID = ExistingStationItemId;
								string NewItemID;
								size_t Pos = ExistingItemID.find('_');
								if (Pos != string::npos)
								{
									string BaseId = ExistingItemID.substr(0, Pos);
									string suffixStr =ExistingItemID .substr(Pos + 1);
									cout << "Base id :" << BaseId <<endl;
									int suffix = stoi(suffixStr);
									suffix++;
									NewItemID = BaseId + "_" + to_string(suffix);

								}
								else
								{
									NewItemID= ExistingItemID + "_1";
									cout << "Inside Else condition" << endl;
								}
								tag_t  NewAttrId = NULLTAG;

								POM_attr_id_of_attr("item_id", "Mfg0MEProcStatn", &NewAttrId);
								AOM_refresh(ObjectTag, TRUE);           
								POM_set_env_info(POM_bypass_attr_update, FALSE, 0, 0, NULLTAG, NULL);
								POM_set_attr_string(1, &ObjectTag, NewAttrId, NewItemID.c_str());
								AOM_save_without_extensions(ObjectTag);
								AOM_refresh(ObjectTag, TRUE);
								cout << "END OF ID NEW ID CODE :" << NewItemID <<endl;
							}
						
						}
					
					}
					
                }

            }

        }
    }

    return 0;
}
//ID GENERATION _1,_2 END


// ID For station
int StationItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside StationItemIDAssignment" << endl;
    tag_t ObjectTag = va_arg(args, tag_t);
    tag_t tObjectType = NULLTAG;
    char *OBJStr = NULL;
    char *TypeName = NULL;
    char *IDofstation = NULL;
    string OBJtype;
    string StationInput;    
    tag_t   qryTagCntrl	= NULLTAG;

    AOM_ask_value_string(ObjectTag,"object_string",&OBJStr);
    cout << "OBJStr : "<< OBJStr << endl;
	TCTYPE_ask_object_type(ObjectTag,&tObjectType);
	TCTYPE_ask_name2(tObjectType,&TypeName);
	cout << "object_type : " << TypeName << endl;
    AOM_ask_value_string(ObjectTag,"item_id",&IDofstation);
    cout << "IDofstation is : " << IDofstation <<endl;

    
    if (IDofstation != nullptr && IDofstation[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    } 
    else 
    {
        cout << "First character is not processing for the regular ID Generation..................\n";
        QRY_find2("Control Objects...", &qryTagCntrl);
        if (qryTagCntrl)
        {
            int n_entryCntrl =3;
            char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
            char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            qry_valuesCntrl[0]="station";
            qry_valuesCntrl[1]="creation";
            qry_valuesCntrl[2]="0";
            int  	control_number_found		= 0;
            tag_t 	*cntr_objects				= NULLTAG;


            printf("\n Control Object Query Found \n");fflush(stdout);
            QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
            if(control_number_found>0)
            {
                OBJtype = TypeName;
                if((OBJtype == "Mfg0MEProcStatnRevision") || (OBJtype=="Process Station Revision") || (OBJtype=="Mfg0MEProcStatn")) //doubt in Station Revision
                {
                    cout << "Station found" << endl;
                    char *StationObjectName = NULL;
                    char *StationAggregateName = NULL;
                    char *StationPlantCode = NULL;
                    char *StationLineNumber = NULL;

                    char *StationType = NULL;
                    
                    string StationAggregateName_Str;
                    string StationPlantCode_Str;
                    string StationLineNumber_Str;
                    tag_t			stationTaskTagrev		= NULLTAG;

                    ITEM_ask_latest_rev(ObjectTag,&stationTaskTagrev);
                    AOM_ask_value_string(stationTaskTagrev,"object_name",&StationObjectName);
                    cout << "StationObjectName : " << StationObjectName <<endl;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_aggregate",&StationAggregateName);
                    cout << "StationAggregateName : " << StationAggregateName <<endl;
                    StationAggregateName_Str = StationAggregateName;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_plantcode",&StationPlantCode);
                    cout << "StationPlantCode : " << StationPlantCode <<endl;
                    StationPlantCode_Str = StationPlantCode;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_lineNo",&StationLineNumber);
                    cout << "StationLineNumber : " << StationLineNumber <<endl;
                    StationLineNumber_Str = StationLineNumber;

                    // StationType Code Added

                    AOM_ask_value_string(stationTaskTagrev,"t5_station_type",&StationType);
                    cout << "StationType : " << StationType <<endl;
                    string StationType_str =  StationType;

                    // Code End

                   

					//START NEW ID GENERATION LOGIC WITH _1,_2 etc.
					string passedID=IDofstation;
					string existingID = passedID.substr(0, 4);
					cout << "11existingID : " << existingID <<endl;
					cout << "StationPlantCode_Str : " << StationPlantCode_Str <<endl;

					if(existingID.compare( StationPlantCode_Str )==0)
					{
					
						cout << "In PRE COndition it is taken case " << existingID <<endl;
					
					}
					else
					{
						string StationItemIdCat; 
						StationItemIdCat = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + "*";
						// StationItemIdCat = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + "ST*";
						tag_t ItemRevQueryTag = NULLTAG;
						char *QryIPEtry[2] = {"Item ID","Type"};
						char **QryInputVal = (char **) MEM_alloc(5 * sizeof(char *));
						int QueryOutputCnt = 0;
						tag_t *tQueryOutput = NULLTAG;
						char *cKeys[1] = {"creation_date"};
						int iOrders[1] = {2};
						QRY_find2("Item Revision...",&ItemRevQueryTag);
						if(ItemRevQueryTag!=NULLTAG)
						{
							tag_t StationMasterTag = NULLTAG;
							QryInputVal[0] = StationItemIdCat.c_str();
							QryInputVal[1] = "Mfg0MEProcStatnRevision";
							QRY_execute_with_sort(ItemRevQueryTag, 2, QryIPEtry, QryInputVal,1,cKeys,iOrders,&QueryOutputCnt, &tQueryOutput);
							cout << "Number of Station Line found : " << QueryOutputCnt << endl;
							if(QueryOutputCnt>0)
							{
								char *ExistingStationItemId = NULL;
								string ExistingStationItemId_Str;
								AOM_ask_value_string(tQueryOutput[0],"item_id",&ExistingStationItemId);
								cout << "ExistingStationItemId : " << ExistingStationItemId << endl;
								ExistingStationItemId_Str = ExistingStationItemId;
								string StationNumber = ExistingStationItemId_Str.substr(11,6);
								cout << "StationNumber : " << StationNumber << endl;
								int StationNumberInt = stoi(StationNumber);
								cout << "StationNumberInt : " << StationNumberInt << endl;
								int NewStationNumberInt = StationNumberInt + 10;
								cout << "NewStationNumberInt : " << NewStationNumberInt << endl;                
								ostringstream os;
								os << setw(4) << setfill('0') << NewStationNumberInt;
								//string NewStationNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + "ST" + os.str();
								string NewStationNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + os.str();
								cout << "NewStationNumber_Str : " << NewStationNumber_Str << endl;   
								//ITEM_ask_item_of_rev(ObjectTag,&StationMasterTag);
								ITEM_ask_item_of_rev(stationTaskTagrev,&StationMasterTag);
								if(StationMasterTag!=NULLTAG)
								{
									cout << "Station Line Master Found " <<endl;
									//AOM_lock(StationMasterTag);

									AOM_refresh(StationMasterTag,1);
									AOM_set_value_string(StationMasterTag,"item_id",NewStationNumber_Str.c_str());
									AOM_set_value_string(StationMasterTag,"object_name",NewStationNumber_Str.c_str());
									AOM_save_without_extensions(StationMasterTag);
									AOM_refresh(StationMasterTag,0);

									AOM_refresh(stationTaskTagrev,1);
									AOM_set_value_string(stationTaskTagrev,"object_name",NewStationNumber_Str.c_str());
									AOM_set_value_string(stationTaskTagrev,"item_id",NewStationNumber_Str.c_str());
									AOM_save_without_extensions(stationTaskTagrev);
									AOM_refresh(stationTaskTagrev,0);
									char *ItemIDsetting = NULL;
									char *ObjectNameSetting = NULL;
									AOM_ask_value_string(stationTaskTagrev,"item_id",&ItemIDsetting);
									AOM_ask_value_string(stationTaskTagrev,"object_name",&ObjectNameSetting);
									cout << "ItemIDsetting : " << ItemIDsetting << "\n" << "ObjectNameSetting : " << ObjectNameSetting << endl;
									
									
									
								}
							}
							else
							{
								//ITEM_ask_item_of_rev(ObjectTag,&StationMasterTag);
								ITEM_ask_item_of_rev(stationTaskTagrev,&StationMasterTag);
								if(StationMasterTag!=NULLTAG)
								{
									string NewProcessNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + "0010";
									cout << "Process Line Master Found " <<endl;
								// AOM_lock(StationMasterTag);
									AOM_refresh(StationMasterTag,1);
									AOM_set_value_string(StationMasterTag,"item_id",NewProcessNumber_Str.c_str());
									AOM_set_value_string(StationMasterTag,"object_name",NewProcessNumber_Str.c_str());
									AOM_save_without_extensions(StationMasterTag);
									AOM_refresh(StationMasterTag,0);

									AOM_refresh(stationTaskTagrev,1);
									AOM_set_value_string(stationTaskTagrev,"item_id",NewProcessNumber_Str.c_str());
									AOM_set_value_string(stationTaskTagrev,"object_name",NewProcessNumber_Str.c_str());
									AOM_save_without_extensions(stationTaskTagrev);
									AOM_refresh(stationTaskTagrev,0);


									char *ItemIDsetting = NULL;
									char *ObjectNameSetting = NULL;
									AOM_ask_value_string(StationMasterTag,"item_id",&ItemIDsetting);
									AOM_ask_value_string(StationMasterTag,"object_name",&ObjectNameSetting);
									
									cout << "ItemIDsetting : " << ItemIDsetting << "\n" << "ObjectNameSetting : " << ObjectNameSetting << endl;
									
									//AOM_unlock(StationMasterTag);
									
								}
							}
						} 
					}
                }

            }

        }
    }
    return 0;
}

//Custom ID GENERATION FOR STATION END

// ID For station
/*int StationItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside StationItemIDAssignment" << endl;
    tag_t ObjectTag = va_arg(args, tag_t);
    tag_t tObjectType = NULLTAG;
    char *OBJStr = NULL;
    char *TypeName = NULL;
    char *IDofstation = NULL;
    string OBJtype;
    string StationInput;    
    tag_t   qryTagCntrl	= NULLTAG;

    AOM_ask_value_string(ObjectTag,"object_string",&OBJStr);
	cout << "OBJStr : "<< OBJStr << endl;
	TCTYPE_ask_object_type(ObjectTag,&tObjectType);
	TCTYPE_ask_name2(tObjectType,&TypeName);
	cout << "object_type : " << TypeName << endl;
    AOM_ask_value_string(ObjectTag,"item_id",&IDofstation);
    cout << "IDofstation is : " << IDofstation <<endl;

    
    if (IDofstation != nullptr && IDofstation[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";

    } 
    else 
    {
        cout << "First character is not processing for the regular ID Generation..................\n";
        QRY_find2("Control Objects...", &qryTagCntrl);
        if (qryTagCntrl)
        {
            int n_entryCntrl =3;
            char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
            char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            qry_valuesCntrl[0]="station";
            qry_valuesCntrl[1]="creation";
            qry_valuesCntrl[2]="0";
            int  	control_number_found		= 0;
            tag_t 	*cntr_objects				= NULLTAG;


            printf("\n Control Object Query Found \n");fflush(stdout);
            QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
            if(control_number_found>0)
            {
                OBJtype = TypeName;
                if((OBJtype == "Mfg0MEProcStatnRevision") || (OBJtype=="Process Station Revision") || (OBJtype=="Mfg0MEProcStatn")) //doubt in Station Revision
                {
                    cout << "Station found" << endl;
                    char *StationObjectName = NULL;
                    char *StationAggregateName = NULL;
                    char *StationPlantCode = NULL;
                    char *StationLineNumber = NULL;

                    char *StationType = NULL;
                    
                    string StationAggregateName_Str;
                    string StationPlantCode_Str;
                    string StationLineNumber_Str;
                    tag_t			stationTaskTagrev		= NULLTAG;

                    ITEM_ask_latest_rev(ObjectTag,&stationTaskTagrev);
                    AOM_ask_value_string(stationTaskTagrev,"object_name",&StationObjectName);
                    cout << "StationObjectName : " << StationObjectName <<endl;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_aggregate",&StationAggregateName);
                    cout << "StationAggregateName : " << StationAggregateName <<endl;
                    StationAggregateName_Str = StationAggregateName;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_plantcode",&StationPlantCode);
                    cout << "StationPlantCode : " << StationPlantCode <<endl;
                    StationPlantCode_Str = StationPlantCode;
                    AOM_ask_value_string(stationTaskTagrev,"t5_PR_lineNo",&StationLineNumber);
                    cout << "StationLineNumber : " << StationLineNumber <<endl;
                    StationLineNumber_Str = StationLineNumber;

                    // StationType Code Added

                    AOM_ask_value_string(stationTaskTagrev,"t5_station_type",&StationType);
                    cout << "StationType : " << StationType <<endl;
                    string StationType_str =  StationType;

                    // Code End

                    string StationItemIdCat;

                    StationItemIdCat = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + "*";
                    // StationItemIdCat = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + "ST*";
                    tag_t ItemRevQueryTag = NULLTAG;
                    char *QryIPEtry[2] = {"Item ID","Type"};
                    char **QryInputVal = (char **) MEM_alloc(5 * sizeof(char *));
                    int QueryOutputCnt = 0;
                    tag_t *tQueryOutput = NULLTAG;
                    char *cKeys[1] = {"creation_date"};
                    int iOrders[1] = {2};
                    QRY_find2("Item Revision...",&ItemRevQueryTag);
                    if(ItemRevQueryTag!=NULLTAG)
                    {
                        tag_t StationMasterTag = NULLTAG;
                        QryInputVal[0] = StationItemIdCat.c_str();
                        QryInputVal[1] = "Mfg0MEProcStatnRevision";
                        QRY_execute_with_sort(ItemRevQueryTag, 2, QryIPEtry, QryInputVal,1,cKeys,iOrders,&QueryOutputCnt, &tQueryOutput);
                        cout << "Number of Station Line found : " << QueryOutputCnt << endl;
                        if(QueryOutputCnt>0)
                        {
                            char *ExistingStationItemId = NULL;
                            string ExistingStationItemId_Str;
                            AOM_ask_value_string(tQueryOutput[0],"item_id",&ExistingStationItemId);
                            cout << "ExistingStationItemId : " << ExistingStationItemId << endl;
                            ExistingStationItemId_Str = ExistingStationItemId;
                            string StationNumber = ExistingStationItemId_Str.substr(11,6);
                            cout << "StationNumber : " << StationNumber << endl;
                            int StationNumberInt = stoi(StationNumber);
                            cout << "StationNumberInt : " << StationNumberInt << endl;
                            int NewStationNumberInt = StationNumberInt + 10;
                            cout << "NewStationNumberInt : " << NewStationNumberInt << endl;                
                            ostringstream os;
                            os << setw(4) << setfill('0') << NewStationNumberInt;
                            //string NewStationNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + "ST" + os.str();
                            string NewStationNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + os.str();
                            cout << "NewStationNumber_Str : " << NewStationNumber_Str << endl;   
                            //ITEM_ask_item_of_rev(ObjectTag,&StationMasterTag);
                            ITEM_ask_item_of_rev(stationTaskTagrev,&StationMasterTag);
                            if(StationMasterTag!=NULLTAG)
                            {
                                cout << "Station Line Master Found " <<endl;
                                //AOM_lock(StationMasterTag);

                                AOM_refresh(StationMasterTag,1);
                                AOM_set_value_string(StationMasterTag,"item_id",NewStationNumber_Str.c_str());
                                AOM_set_value_string(StationMasterTag,"object_name",NewStationNumber_Str.c_str());
                                AOM_save_without_extensions(StationMasterTag);
                                AOM_refresh(StationMasterTag,0);

                                AOM_refresh(stationTaskTagrev,1);
                                AOM_set_value_string(stationTaskTagrev,"object_name",NewStationNumber_Str.c_str());
                                AOM_set_value_string(stationTaskTagrev,"item_id",NewStationNumber_Str.c_str());
                                AOM_save_without_extensions(stationTaskTagrev);
                                AOM_refresh(stationTaskTagrev,0);
                                char *ItemIDsetting = NULL;
                                char *ObjectNameSetting = NULL;
                                AOM_ask_value_string(stationTaskTagrev,"item_id",&ItemIDsetting);
                                AOM_ask_value_string(stationTaskTagrev,"object_name",&ObjectNameSetting);
                                cout << "ItemIDsetting : " << ItemIDsetting << "\n" << "ObjectNameSetting : " << ObjectNameSetting << endl;
                                
                                
                                
                            }
                        }
                        else
                        {
                            //ITEM_ask_item_of_rev(ObjectTag,&StationMasterTag);
                            ITEM_ask_item_of_rev(stationTaskTagrev,&StationMasterTag);
                            if(StationMasterTag!=NULLTAG)
                            {
                                string NewProcessNumber_Str = StationPlantCode_Str + StationAggregateName_Str + StationLineNumber_Str + StationType_str + "0010";
                                cout << "Process Line Master Found " <<endl;
                            // AOM_lock(StationMasterTag);
                                AOM_refresh(StationMasterTag,1);
                                AOM_set_value_string(StationMasterTag,"item_id",NewProcessNumber_Str.c_str());
                                AOM_set_value_string(StationMasterTag,"object_name",NewProcessNumber_Str.c_str());
                                AOM_save_without_extensions(StationMasterTag);
                                AOM_refresh(StationMasterTag,0);

                                AOM_refresh(stationTaskTagrev,1);
                                AOM_set_value_string(stationTaskTagrev,"item_id",NewProcessNumber_Str.c_str());
                                AOM_set_value_string(stationTaskTagrev,"object_name",NewProcessNumber_Str.c_str());
                                AOM_save_without_extensions(stationTaskTagrev);
                                AOM_refresh(stationTaskTagrev,0);


                                char *ItemIDsetting = NULL;
                                char *ObjectNameSetting = NULL;
                                AOM_ask_value_string(StationMasterTag,"item_id",&ItemIDsetting);
                                AOM_ask_value_string(StationMasterTag,"object_name",&ObjectNameSetting);
                                
                                cout << "ItemIDsetting : " << ItemIDsetting << "\n" << "ObjectNameSetting : " << ObjectNameSetting << endl;
                                
                                //AOM_unlock(StationMasterTag);
                                
                            }
                        }
                    }     
                }

            }

        }
    }



    return 0;
}*/

int ProcessItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside ProcessItemIDAssignment" << endl;
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag = NULLTAG;
    char *ObjStr = NULL;
    char *type_name = NULL;
    string ObjectType;
    string Input;
    tag_t COQueryTag = NULLTAG;
    QRY_find2("Control Objects...",&COQueryTag);
    if(COQueryTag!=NULLTAG)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="Process";
        Valuesp[1]="Creation";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;
        QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp>0)
        {            
            if(COQueryTag!=NULLTAG)
            {
                char **Values = (char **) MEM_alloc(5 * sizeof(char *));
                Values[0]="pBOPAssignment";
                Values[1]="pBOPAssignment";
                Values[2]="0";
                int COCount = 0;
                tag_t *COTags = NULLTAG;
                QRY_execute(COQueryTag, 3, Entries, Values, &COCount, &COTags);
                if(COCount>0)
                {
                    char *UserInfo1 = NULL;
                    AOM_ask_value_string(COTags[0],"t5_Userinfo1",&UserInfo1);
                    cout << "Control Object User Info 1 value is : " << UserInfo1 << endl;
                    Input = UserInfo1;
                }
            }
            

            AOM_ask_value_string(objTag,"object_string",&ObjStr);
            cout << "ObjStr : "<< ObjStr << endl;
            TCTYPE_ask_object_type(objTag,&objTypeTag);
            TCTYPE_ask_name2(objTypeTag,&type_name);
            cout << "object_type : " << type_name << endl;
            ObjectType = type_name;
            if((ObjectType == "MEProcessRevision") || (ObjectType=="Process Revision")||(ObjectType=="MEProcess"))
            {
                cout << "Process found" << endl;
                char *ProcessObjectName = NULL;
                char *ProcessAggregateName = NULL;
                char *ProcessPlantCode = NULL;
                char *ProcessLineNumber = NULL;
                
                string ProcessAggregateName_Str;
                string ProcessPlantCode_Str;
                string ProcessLineNumber_Str;

                tag_t			processTaskTagrev		= NULLTAG;

                ITEM_ask_latest_rev(objTag,&processTaskTagrev);
                AOM_ask_value_string(processTaskTagrev,"object_name",&ProcessObjectName);
                cout << "ProcessObjectName : " << ProcessObjectName <<endl;
                AOM_ask_value_string(processTaskTagrev,"t5_PR_aggregate",&ProcessAggregateName);
                cout << "ProcessAggregateName : " << ProcessAggregateName <<endl;
                ProcessAggregateName_Str = ProcessAggregateName;
                AOM_ask_value_string(processTaskTagrev,"t5_PR_plantcode",&ProcessPlantCode);
                cout << "ProcessPlantCode : " << ProcessPlantCode <<endl;
                ProcessPlantCode_Str = ProcessPlantCode;
                AOM_ask_value_string(processTaskTagrev,"t5_PR_lineNo",&ProcessLineNumber);
                cout << "ProcessLineNumber : " << ProcessLineNumber <<endl;
                ProcessLineNumber_Str = ProcessLineNumber;
                vector<PlantInfo> plants = GetGroup(ProcessPlantCode,Input);    
                for (const auto& plant : plants) {
                    cout << "Plant Code: " << plant.plantCode << "\n" << "Plant Name: " << plant.plantName << endl;
                    string NameOfPlant;
                    NameOfPlant = plant.plantName;
                    string StartingLetterOfPlantName;
                    StartingLetterOfPlantName = NameOfPlant.substr(0,1);
                    cout << "StartingLetterOfPlantName : " << StartingLetterOfPlantName << endl;
                    string ProcessItemIdCat;
                    ProcessItemIdCat = StartingLetterOfPlantName + ProcessAggregateName_Str + ProcessLineNumber_Str + "PR*";
                    tag_t ItemRevisinQueryTag = NULLTAG;
                    char *QueryInputEntry[2] = {"Item ID","Type"};
                    char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                    int QueryOutputCount = 0;
                    tag_t *QueryOutputTags = NULLTAG;
                    char *keys[1] = {"creation_date"};
                    int orders[1] = {2};
                    QRY_find2("Item Revision...",&ItemRevisinQueryTag);
                    if(ItemRevisinQueryTag!=NULLTAG)
                    {
                        tag_t ProcessMasterTag = NULLTAG;
                        QueryInputValue[0] = ProcessItemIdCat.c_str();
                        QueryInputValue[1] = "MEProcessRevision";
                        QRY_execute_with_sort(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue,1,keys,orders,&QueryOutputCount, &QueryOutputTags);
                        cout << "Number of Process Line found : " << QueryOutputCount << endl;
                        if(QueryOutputCount>0)
                        {
                            char *ExistingProcessItemId = NULL;
                            string ExistingProcessItemId_Str;
                            AOM_ask_value_string(QueryOutputTags[0],"item_id",&ExistingProcessItemId);
                            cout << "ExistingProcessItemId : " << ExistingProcessItemId << endl;
                            ExistingProcessItemId_Str = ExistingProcessItemId;
                            string ProcessNumber = ExistingProcessItemId_Str.substr(8,6);
                            cout << "ProcessNumber : " << ProcessNumber << endl;
                            int ProcessNumberInt = stoi(ProcessNumber);
                            cout << "ProcessNumberInt : " << ProcessNumberInt << endl;
                            int NewProcessNumberInt = ProcessNumberInt + 10;
                            cout << "NewProcessNumberInt : " << NewProcessNumberInt << endl;                
                            ostringstream oss;
                            oss << setw(6) << setfill('0') << NewProcessNumberInt;
                            string NewProcessNumber_Str = StartingLetterOfPlantName + ProcessAggregateName_Str + ProcessLineNumber_Str + "PR" + oss.str();
                            cout << "NewProcessNumber_Str : " << NewProcessNumber_Str << endl;   
                            ITEM_ask_item_of_rev(processTaskTagrev,&ProcessMasterTag);
                            //ITEM_ask_item_of_rev(objTag,&ProcessMasterTag);
                            if(ProcessMasterTag!=NULLTAG)
                            {
                                cout << "Process Line Master Found " <<endl;
                               // AOM_lock(ProcessMasterTag);

                                AOM_refresh(ProcessMasterTag,1);
                                cout << "1" <<endl;
                                AOM_set_value_string(ProcessMasterTag,"item_id",NewProcessNumber_Str.c_str());
                                cout << "2" <<endl;
                                AOM_set_value_string(ProcessMasterTag,"object_name",NewProcessNumber_Str.c_str());
                                cout << "3" <<endl;
                                AOM_save_without_extensions(ProcessMasterTag);
                                cout << "4" <<endl;
                                AOM_refresh(ProcessMasterTag,0);
                                cout << "5" <<endl;

                                AOM_refresh(processTaskTagrev,1);
                                cout << "6" <<endl;
                                AOM_set_value_string(processTaskTagrev,"item_id",NewProcessNumber_Str.c_str());
                                cout << "7" <<endl;
                                AOM_set_value_string(processTaskTagrev,"object_name",NewProcessNumber_Str.c_str());
                                cout << "8" <<endl;
                                AOM_save_without_extensions(processTaskTagrev);
                                cout << "9" <<endl;
                                AOM_refresh(processTaskTagrev,0);
                                cout << "10" <<endl;
                                char *ItemIdSet = NULL;
                                char *ObjectNameSet = NULL;
                                AOM_ask_value_string(ProcessMasterTag,"item_id",&ItemIdSet);
                                AOM_ask_value_string(ProcessMasterTag,"object_name",&ObjectNameSet);
                                cout << "ItemIdSet : " << ItemIdSet << "\n" << "ObjectNameSet : " << ObjectNameSet << endl;
                                
                            }
                        }
                        else
                        {
                            ITEM_ask_item_of_rev(processTaskTagrev,&ProcessMasterTag);
                            //ITEM_ask_item_of_rev(objTag,&ProcessMasterTag);
                            if(ProcessMasterTag!=NULLTAG)
                            {
                                
                                string NewProcessNumber_Str = StartingLetterOfPlantName + ProcessAggregateName_Str + ProcessLineNumber_Str + "PR000010";
                                cout << "Process Line Master Found " <<endl;

                                AOM_refresh(ProcessMasterTag,0);
                                AOM_set_value_string(ProcessMasterTag,"item_id",NewProcessNumber_Str.c_str());
                                AOM_set_value_string(ProcessMasterTag,"object_name",NewProcessNumber_Str.c_str());
                                AOM_save_without_extensions(ProcessMasterTag);
                                AOM_refresh(ProcessMasterTag,0);

                                AOM_refresh(processTaskTagrev,0);
                                AOM_set_value_string(processTaskTagrev,"item_id",NewProcessNumber_Str.c_str());
                                AOM_set_value_string(processTaskTagrev,"object_name",NewProcessNumber_Str.c_str());
                                AOM_save_without_extensions(processTaskTagrev);
                                AOM_refresh(processTaskTagrev,0);
                                char *ItemIdSet = NULL;
                                char *ObjectNameSet = NULL;
                                AOM_ask_value_string(ProcessMasterTag,"item_id",&ItemIdSet);
                                AOM_ask_value_string(ProcessMasterTag,"object_name",&ObjectNameSet);
                                cout << "ItemIdSet : " << ItemIdSet << "\n" << "ObjectNameSet : " << ObjectNameSet << endl;

                               /* AOM_lock(ProcessMasterTag);
                                AOM_set_value_string(ProcessMasterTag,"item_id",NewProcessNumber_Str.c_str());
                                AOM_set_value_string(ProcessMasterTag,"object_name",NewProcessNumber_Str.c_str());
                                char *ItemIdSet = NULL;
                                char *ObjectNameSet = NULL;
                                AOM_ask_value_string(ProcessMasterTag,"item_id",&ItemIdSet);
                                AOM_ask_value_string(ProcessMasterTag,"object_name",&ObjectNameSet);
                                AOM_set_value_string(objTag,"object_name",NewProcessNumber_Str.c_str());
                                cout << "ItemIdSet : " << ItemIdSet << "\n" << "ObjectNameSet : " << ObjectNameSet << endl;
                                AOM_save_without_extensions(ProcessMasterTag);
                                AOM_unlock(ProcessMasterTag);
                                AOM_refresh(ProcessMasterTag,0);*/
                            }
                        }
                    }
                }        
            }

        }

    }
    
    return 0;
}

// Indira nomenclature for Operation start

int OperationItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "\n Inside OperationItemIDAssignment11111111\n" << endl;
    fflush(stdout);

    static bool isRunning = false;

    if (isRunning)
    {
        cout << "\n Inside isRunning Condition to check recursion \n" << endl;
        fflush(stdout);

        return 0;   // avoid recursion
        
    }

    isRunning = true;

    cout << "\n Inside OperationItemIDAssignment\n" << endl;
    fflush(stdout);
    
    tag_t tObject = va_arg(args, tag_t);
    tag_t tObjType = NULLTAG;
    char *cObject = NULL;
    char *cObjTypeNmae = NULL;
    string sObjectType;
    string OperationInput;

    tag_t COQueryTag = NULLTAG;
    QRY_find2("Control Objects...",&COQueryTag);
    if(COQueryTag!=NULLTAG)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="Operation";
        Valuesp[1]="Operation";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;
        QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp > 0)
        {
			cout << "Control Object found" << endl;
            tag_t tCOQuery = NULLTAG;
            QRY_find2("Control Objects...",&tCOQuery);
            if(tCOQuery!=NULLTAG)
            {
                char **cValues = (char **) MEM_alloc(5 * sizeof(char *));
                char *tEntries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
                cValues[0]="pBOPAssignment";
                cValues[1]="pBOPAssignment";
                cValues[2]="0";
                int iCOCount = 0;
                tag_t *tContObj = NULLTAG;
                QRY_execute(tCOQuery, 3, tEntries, cValues, &iCOCount, &tContObj);
                if(iCOCount>0)
                {
                    char *tUserInfo1 = NULL;
                    AOM_ask_value_string(tContObj[0],"t5_Userinfo1",&tUserInfo1);
                    cout << "Control Object User Info 1 value is : " << tUserInfo1 << endl;
                    OperationInput = tUserInfo1;
                }
            }

            AOM_ask_value_string(tObject,"object_string",&cObject);
	        cout << "cObject : "<< cObject << endl;
            TCTYPE_ask_object_type(tObject,&tObjType);
            TCTYPE_ask_name2(tObjType,&cObjTypeNmae);
            cout << "object_type : " << cObjTypeNmae << endl;
            sObjectType = cObjTypeNmae;
            if((sObjectType == "MEOPRevision") || (sObjectType=="Operation Revision") || (sObjectType=="MEOP")) //Operation Revision Doubt  MEOP
            {
                cout << "Operation found" << endl;
                char *OperationObjectName = NULL;
                char *OperationAggregateName = NULL;
                char *OperationPlantCode = NULL;
                char *OperationLineNumber = NULL;
                
                string OperationAggregateName_Str;
                string OperationPlantCode_Str;
                string OperationLineNumber_Str;
                AOM_ask_value_string(tObject,"object_name",&OperationObjectName);
                cout << "OperationObjectName : " << OperationObjectName <<endl;

                // ***** Skip second execution *****
                string objName = OperationObjectName;
                if (objName.length() > 8 && objName.find("OP") != string::npos)
                {
                    cout << "SKIP: Operation ID already assigned: " << objName << endl;
                    cout << "Operation Code End!!!" << endl;
                    isRunning = false;
                    return 0;
                }
                // *********************************************
                tag_t			OPTaskTagrev		= NULLTAG;

                ITEM_ask_latest_rev(tObject,&OPTaskTagrev);

                AOM_ask_value_string(OPTaskTagrev,"t5_OP_aggregate",&OperationAggregateName);
                cout << "OperationAggregateName : " << OperationAggregateName <<endl;
                OperationAggregateName_Str = OperationAggregateName;
                AOM_ask_value_string(OPTaskTagrev,"t5_OP_plantcode",&OperationPlantCode);
                cout << "OperationPlantCode : " << OperationPlantCode <<endl;
                OperationPlantCode_Str = OperationPlantCode;
                AOM_ask_value_string(OPTaskTagrev,"t5_OP_lineNo",&OperationLineNumber);
                cout << "OperationLineNumber : " << OperationLineNumber <<endl;
                OperationLineNumber_Str = OperationLineNumber;
                vector<PlantInfo> plantsList = GetGroup(OperationPlantCode,OperationInput);    
                for (const auto& Plnt : plantsList) 
                {
                    cout << "Plant Code: " << Plnt.plantCode << "\n" << "Plant Name: " << Plnt.plantName << endl;
                    string NameOfThePlant;
                    NameOfThePlant = Plnt.plantName;
                    string PlantNameStartingLetter;
                    PlantNameStartingLetter = NameOfThePlant.substr(0,1);
                    cout << "PlantNameStartingLetter : " << PlantNameStartingLetter << endl;
                    string OperationItemIdCat;
                    //OperationItemIdCat = PlantNameStartingLetter + OperationAggregateName_Str + OperationLineNumber_Str + "OP*";
                    OperationItemIdCat = PlantNameStartingLetter + OperationAggregateName_Str + "OP*";
                    tag_t ItemRevisinQRYTag = NULLTAG;
                    char *QRYInputEntry[2] = {"Item ID","Type"};
                    char **QRYInputValue = (char **) MEM_alloc(5 * sizeof(char *));
                    int QRYOutputCount = 0;
                    tag_t *QRYOutputTags = NULLTAG;
                    char *key[1] = {"creation_date"};
                    int order[1] = {2};
                    QRY_find2("Item Revision...",&ItemRevisinQRYTag);
                    if(ItemRevisinQRYTag!=NULLTAG)
                    {
                        tag_t OperationMasterTag = NULLTAG;
                        QRYInputValue[0] = OperationItemIdCat.c_str();
                        QRYInputValue[1] = "MEOPRevision";
                        QRY_execute_with_sort(ItemRevisinQRYTag, 2, QRYInputEntry, QRYInputValue,1,key,order,&QRYOutputCount, &QRYOutputTags);
                        cout << "Number of Operation Line found : " << QRYOutputCount << endl;
                        if(QRYOutputCount>0)
                        {
                            char *ExistingOperationItemId = NULL;
                            string ExistingOperationItemId_Str;
                            AOM_ask_value_string(QRYOutputTags[0],"item_id",&ExistingOperationItemId);
                            cout << "ExistingOperationItemId : " << ExistingOperationItemId << endl;
                            ExistingOperationItemId_Str = ExistingOperationItemId;
                            string OperationNumber = ExistingOperationItemId_Str.substr(8,5);
                            cout << "OperationNumber : " << OperationNumber << endl;
                            int OperationNumberInt = stoi(OperationNumber);
                            cout << "OperationNumberInt : " << OperationNumberInt << endl;
                            int NewOperationNumberInt = OperationNumberInt + 1;
                            cout << "NewOperationNumberInt : " << NewOperationNumberInt << endl;                
                            ostringstream OutPutStrStream;
                            OutPutStrStream << setw(5) << setfill('0') << NewOperationNumberInt;
                            //string NewOperationNumber_Str = PlantNameStartingLetter + OperationAggregateName_Str + OperationLineNumber_Str + "OP" + OutPutStrStream.str();
                            string NewOperationNumber_Str = PlantNameStartingLetter + OperationAggregateName_Str + "OP" + OutPutStrStream.str();
                            cout << "NewOperationNumber_Str : " << NewOperationNumber_Str << endl;   
                            ITEM_ask_item_of_rev(OPTaskTagrev,&OperationMasterTag);
                            /*
                            if(OperationMasterTag!=NULLTAG)
                            {
                                cout << "Operation Line Master Found" <<endl;
                                AOM_lock(OperationMasterTag);
                                AOM_set_value_string(OperationMasterTag,"item_id",NewOperationNumber_Str.c_str());
                                AOM_set_value_string(OperationMasterTag,"object_name",NewOperationNumber_Str.c_str());
                                AOM_set_value_string(tObject,"object_name",NewOperationNumber_Str.c_str());
                                char *SetItemID = NULL;
                                char *SetObjectName = NULL;
                                AOM_ask_value_string(OperationMasterTag,"item_id",&SetItemID);
                                AOM_ask_value_string(OperationMasterTag,"object_name",&SetObjectName);
                                cout << "SetItemID : " << SetItemID << "\n" << "SetObjectName : " << SetObjectName << endl;
                                AOM_save_without_extensions(OperationMasterTag);
                                AOM_unlock(OperationMasterTag);
                                AOM_refresh(OperationMasterTag,0);
                            }
                            */

                            if(OperationMasterTag!=NULLTAG)
                            {

                                cout << "Operation Line Master Found" <<endl;
                                AOM_refresh(OperationMasterTag,1);
                                AOM_set_value_string(OperationMasterTag,"item_id",NewOperationNumber_Str.c_str());
                                AOM_set_value_string(OperationMasterTag,"object_name",NewOperationNumber_Str.c_str());
                                AOM_save_without_extensions(OperationMasterTag);
                                AOM_refresh(OperationMasterTag,0);
                                // Set values on Revision
                                AOM_refresh(OPTaskTagrev,1);
                                AOM_set_value_string(OPTaskTagrev,"object_name",NewOperationNumber_Str.c_str());
                                AOM_save_without_extensions(OPTaskTagrev);
                                AOM_refresh(OPTaskTagrev,0);
                                char *SetItemID = NULL;
                                char *SetObjectName = NULL;
                                AOM_ask_value_string(OperationMasterTag,"item_id",&SetItemID);
                                AOM_ask_value_string(OperationMasterTag,"object_name",&SetObjectName);
                                cout << "SetItemID : " << SetItemID << "\n" << "SetObjectName : " << SetObjectName << endl;


                                cout << "Auto refresh completed for first operation" << endl;
                            }
                        }
                        else
                        {
                            ITEM_ask_item_of_rev(OPTaskTagrev,&OperationMasterTag);
                            if(OperationMasterTag!=NULLTAG)
                            {
                                string NewOperationNumber_Str = PlantNameStartingLetter + OperationAggregateName_Str + "OP00001";
                                cout << "Operation Line Master Found " <<endl;
                                // Lock both Item and Revision
                                 cout << "Operation Line Master Found" <<endl;
                                AOM_refresh(OperationMasterTag,1);
                                AOM_set_value_string(OperationMasterTag,"item_id",NewOperationNumber_Str.c_str());
                                AOM_set_value_string(OperationMasterTag,"object_name",NewOperationNumber_Str.c_str());
                                AOM_save_without_extensions(OperationMasterTag);
                                AOM_refresh(OperationMasterTag,0);
                                // Set values on Revision
                                AOM_refresh(OPTaskTagrev,1);
                                AOM_set_value_string(OPTaskTagrev,"object_name",NewOperationNumber_Str.c_str());
                                AOM_save_without_extensions(OPTaskTagrev);
                                AOM_refresh(OPTaskTagrev,0);
                                char *SetItemID = NULL;
                                char *SetObjectName = NULL;
                                AOM_ask_value_string(OperationMasterTag,"item_id",&SetItemID);
                                AOM_ask_value_string(OperationMasterTag,"object_name",&SetObjectName);
                                cout << "SetItemID : " << SetItemID << "\n" << "SetObjectName : " << SetObjectName << endl;
                                
                                
                                
                                /*AOM_lock(OperationMasterTag);
                                AOM_lock(tObject);
                                // Set values on Item
                                AOM_set_value_string(OperationMasterTag,"item_id",NewOperationNumber_Str.c_str());
                                AOM_set_value_string(OperationMasterTag,"object_name",NewOperationNumber_Str.c_str());
                                char *SetItemID = NULL;
                                char *SetObjectName = NULL;
                                AOM_ask_value_string(OperationMasterTag,"item_id",&SetItemID);
                                AOM_ask_value_string(OperationMasterTag,"object_name",&SetObjectName);
                                // Set values on Revision
                                AOM_set_value_string(tObject,"object_name",NewOperationNumber_Str.c_str());
                                cout << "SetItemID : " << SetItemID << "\n" << "SetObjectName : " << SetObjectName << endl;
                                // Save both
                                AOM_save_without_extensions(tObject);
                                AOM_save_without_extensions(OperationMasterTag);

                                // Refresh both
                                //AOM_refresh(tObject, 1);
                                AOM_refresh(tObject,0);
                                AOM_refresh(OperationMasterTag,0);

                                // Unlock both
                                AOM_unlock(tObject);
                                AOM_unlock(OperationMasterTag);*/

                                cout << "Auto refresh completed for first operation inside else condition" << endl;
                            }
                        }
                    }
                }        
            }
        }
		else
		{
			cout << "Control Object not found" << endl;
		}
   }
    
    isRunning = false;
    return 0;
}
int WorkAreaItemIDAssignment(METHOD_message_t *msg, va_list args)
{
    cout << "Inside WorkAreaItemIDAssignment" << endl;
    tag_t tObjectTag = va_arg(args, tag_t);
    tag_t tObjTyp = NULLTAG;
    char *cObjStr = NULL;
    char *cTypeName = NULL;
    string sOBJtype;
    //string StationInput;    
    char *IDofworkarea = NULL;
    tag_t WAQrytag = NULLTAG;

    AOM_ask_value_string(tObjectTag,"object_string",&cObjStr);
	cout << "cObjStr : "<< cObjStr << endl;
	TCTYPE_ask_object_type(tObjectTag,&tObjTyp);
	TCTYPE_ask_name2(tObjTyp,&cTypeName);
	cout << "object_type : " << cTypeName << endl;

    AOM_ask_value_string(tObjectTag,"item_id",&IDofworkarea);
    cout << "IDofworkarea is : " << IDofworkarea <<endl;

    //Added for Station BOM Creation.
    if (IDofworkarea != nullptr && IDofworkarea[0] == 'S')
    {
        cout << "First character is 'S'  so Skipping ID generation of Station................\n";
        
    }
    else
    {
        QRY_find2("Control Objects...",&WAQrytag);
        if(WAQrytag!=NULLTAG)
        {
            char **ValuespWA = (char **) MEM_alloc(5 * sizeof(char *));
            char *EntriesWA[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
            ValuespWA[0]="Workarea";
            ValuespWA[1]="Creation";
            ValuespWA[2]="0";
            int WACountp = 0;
            tag_t *WACOTagsP = NULLTAG;
            QRY_execute(WAQrytag, 3, EntriesWA, ValuespWA, &WACountp, &WACOTagsP);
            if(WACountp>0)
            {
                sOBJtype = cTypeName;
                if((sOBJtype == "Mfg0MEProcAreaRevision") || (sOBJtype=="Process Area Revision")|| (sOBJtype=="Mfg0MEProcArea")) //doubt in Work Area Revision
                {
                    cout << "Work area found" << endl;
                    char *WorkAreaObjectName = NULL;
                    char *WorkAreaAggregateName = NULL;
                    char *WorkAreaPlantCode = NULL;
                    char *WorkAreaLineNumber = NULL;
                    
                    string WorkAreaAggregateName_Str;
                    string WorkAreaPlantCode_Str;
                    string WorkAreaLineNumber_Str;

                    tag_t			TaskTagrev		= NULLTAG;
                    cout << "1" <<endl;
                    ITEM_ask_latest_rev(tObjectTag,&TaskTagrev);
                    cout << "2" <<endl;

                    if(TaskTagrev!=NULL)
                    {
                        cout << "get the revision" <<endl;
                        AOM_ask_value_string(TaskTagrev,"object_name",&WorkAreaObjectName);
                        cout << "WorkAreaObjectName : " << WorkAreaObjectName <<endl;
                        AOM_ask_value_string(TaskTagrev,"t5_PR_aggregate",&WorkAreaAggregateName);
                        cout << "WorkAreaAggregateName : " << WorkAreaAggregateName <<endl;
                        WorkAreaAggregateName_Str = WorkAreaAggregateName;
                        AOM_ask_value_string(TaskTagrev,"t5_PR_plantcode",&WorkAreaPlantCode);
                        cout << "WorkAreaPlantCode : " << WorkAreaPlantCode <<endl;
                        WorkAreaPlantCode_Str = WorkAreaPlantCode;
                        AOM_ask_value_string(TaskTagrev,"t5_PR_lineNo",&WorkAreaLineNumber);
                        cout << "WorkAreaLineNumber : " << WorkAreaLineNumber <<endl;
                        WorkAreaLineNumber_Str = WorkAreaLineNumber;
                        string WorkAreaItemIdCat;
                        WorkAreaItemIdCat = WorkAreaPlantCode_Str + WorkAreaAggregateName_Str + WorkAreaLineNumber_Str + "WA*";
                        cout << "WorkAreaItemIdCat: " << WorkAreaItemIdCat << endl;
                        tag_t tItemRevQuery = NULLTAG;
                        char *cQryIPEtry[2] = {"Item ID","Type"};
                        char **cQryInputVal = (char **) MEM_alloc(5 * sizeof(char *));
                        int iQueryOutputCnt = 0;
                        tag_t *tQryOutput = NULLTAG;
                        char *cKeeys[1] = {"creation_date"};
                        int iOrder[1] = {2};
                        QRY_find2("Item Revision...",&tItemRevQuery);
                        if(tItemRevQuery!=NULLTAG)
                        {
                            tag_t WorkAreaMasterTag = NULLTAG;
                            cQryInputVal[0] = WorkAreaItemIdCat.c_str();
                            cQryInputVal[1] = "Mfg0MEProcAreaRevision";
                            QRY_execute_with_sort(tItemRevQuery, 2, cQryIPEtry, cQryInputVal,1,cKeeys,iOrder,&iQueryOutputCnt, &tQryOutput);
                            cout << "Number of Work area found : " << iQueryOutputCnt << endl;
                            if(iQueryOutputCnt>0)
                            {
                                char *ExistingWorkAreaItemId = NULL;
                                string ExistingWorkAreaItemId_Str;
                                AOM_ask_value_string(tQryOutput[0],"item_id",&ExistingWorkAreaItemId);
                                cout << "ExistingWorkAreaItemId : " << ExistingWorkAreaItemId << endl;
                                ExistingWorkAreaItemId_Str = ExistingWorkAreaItemId;
                                string WorkAreaNumber = ExistingWorkAreaItemId_Str.substr(11,2);
                                cout << "WorkAreaNumber : " << WorkAreaNumber << endl;
                                int WorkAreaNumberInt = stoi(WorkAreaNumber);
                                cout << "WorkAreaNumberInt : " << WorkAreaNumberInt << endl;
                                int NewWorkAreaNumberInt = WorkAreaNumberInt + 1;
                                cout << "NewWorkAreaNumberInt : " << NewWorkAreaNumberInt << endl;                
                                ostringstream os;
                                os << setw(2) << setfill('0') << NewWorkAreaNumberInt;
                                string NewWorkAreaNumber_Str = WorkAreaPlantCode_Str + WorkAreaAggregateName_Str + WorkAreaLineNumber_Str + "WA" + os.str();
                                cout << "NewWorkAreaNumber_Str : " << NewWorkAreaNumber_Str << endl;   
                                //ITEM_ask_item_of_rev(tObjectTag,&WorkAreaMasterTag);
                                ITEM_ask_item_of_rev(TaskTagrev,&WorkAreaMasterTag);
                                if(WorkAreaMasterTag!=NULLTAG)
                                {
                                    cout << "Workarea Master Found " <<endl;
                                    //AOM_lock(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,1);
                                    AOM_set_value_string(WorkAreaMasterTag,"item_id",NewWorkAreaNumber_Str.c_str());
                                    AOM_set_value_string(WorkAreaMasterTag,"object_name",NewWorkAreaNumber_Str.c_str());
                                    AOM_save_without_extensions(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,0);


                                    AOM_refresh(TaskTagrev,1);
                                    AOM_set_value_string(TaskTagrev,"item_id",NewWorkAreaNumber_Str.c_str());
                                    AOM_set_value_string(TaskTagrev,"object_name",NewWorkAreaNumber_Str.c_str());
                                    AOM_save_without_extensions(TaskTagrev);
                                    AOM_refresh(WorkAreaMasterTag,0);

                                    char *cItemIDsetting = NULL;
                                    char *cObjectNameSetting = NULL;
                                    AOM_ask_value_string(WorkAreaMasterTag,"item_id",&cItemIDsetting);
                                    AOM_ask_value_string(WorkAreaMasterTag,"object_name",&cObjectNameSetting);
                                    cout << "cItemIDsetting : " << cItemIDsetting << "\n" << "cObjectNameSetting : " << cObjectNameSetting << endl;
                                    AOM_save_without_extensions(WorkAreaMasterTag);
                                    AOM_unlock(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,0);
                                }
                            }
                            else
                            {
                            // ITEM_ask_item_of_rev(tObjectTag,&WorkAreaMasterTag);
                                ITEM_ask_item_of_rev(TaskTagrev,&WorkAreaMasterTag);
                                if(WorkAreaMasterTag!=NULLTAG)
                                {
                                    string NewWorkAreaNumber_Str = WorkAreaPlantCode_Str + WorkAreaAggregateName_Str + WorkAreaLineNumber_Str + "WA01";
                                    cout << "Process Line Master Found " <<endl;
                                   // AOM_lock(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,1);
                                    AOM_set_value_string(WorkAreaMasterTag,"item_id",NewWorkAreaNumber_Str.c_str());
                                    AOM_set_value_string(WorkAreaMasterTag,"object_name",NewWorkAreaNumber_Str.c_str());
                                    AOM_save_without_extensions(WorkAreaMasterTag);
                                   // AOM_unlock(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,0);


                                    //AOM_lock(TaskTagrev);
                                    AOM_refresh(TaskTagrev,1);
                                    AOM_set_value_string(TaskTagrev,"item_id",NewWorkAreaNumber_Str.c_str());
                                    AOM_set_value_string(TaskTagrev,"object_name",NewWorkAreaNumber_Str.c_str());
                                    AOM_save_without_extensions(TaskTagrev);
                                   // AOM_unlock(TaskTagrev);
                                    AOM_refresh(TaskTagrev,0);
                                    char *cItemIDsetting = NULL;
                                    char *cObjectNameSetting = NULL;
                                    AOM_ask_value_string(WorkAreaMasterTag,"item_id",&cItemIDsetting);
                                    AOM_ask_value_string(WorkAreaMasterTag,"object_name",&cObjectNameSetting);
                                   // AOM_set_value_string(TaskTagrev,"object_name",NewWorkAreaNumber_Str.c_str());
                                    cout << "cItemIDsetting : " << cItemIDsetting << "\n" << "cObjectNameSetting : " << cObjectNameSetting << endl;
                                    AOM_save_without_extensions(WorkAreaMasterTag);
                                    //AOM_unlock(WorkAreaMasterTag);
                                    AOM_refresh(WorkAreaMasterTag,0);
                                }
                            }
                        }

                    }
                    else
                    {
                         cout << "There is an Issue while getting revision" <<endl;
                    }
     
                }

            }
            else
            {
                cout << "Control object not found for work area...............\n";


            }

        }

    }
   
    return 0;
}

//added by sanjay
extern EPM_decision_t DLLAPI mpp_signoff_checks_Func(EPM_rule_message_t msg)
{
	//variable decleration
	EPM_decision_t decision;
    int    ii = 0;
    int    error = 0;
    int   i_cnt = 0;
    int   cntFlag = 0;
	int error_cnt=0;
	char   *ReleaseStatus = NULL;
	char  *error_msg = NULL;
    error_msg = (char *)MEM_alloc(1000);
    tc_strcpy(error_msg, "");
	char **SetOprRelErr = NULL;
    SetOprRelErr = (char **)MEM_alloc(50 * sizeof *SetOprRelErr);
    tag_t rootTask = NULLTAG;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    tag_t target_obj = NULLTAG;
    int noAttachment =0;
    tag_t *attachments = NULLTAG;
    tag_t   qryTagCntrl	= NULLTAG;
    char *UserInfo1 = NULL;
    char *UserInfo2 = NULL;
    char *UserInfo3 = NULL;
    char *UserInfo4 = NULL;
    char *UserInfo5 = NULL;
    tag_t objTypeTag = NULLTAG;
    char *type_name = NULL;
    int  psdWrkcntLcs = 0;
    int opcount=0;
    tag_t * optag=NULLTAG;
    char *StationID=NULL;
    char *operationID=NULL;
    char *designID=NULL;
    char *designrevvID=NULL;
    char *objectdesc=NULL;
    char *traceandtrack=NULL;
    char *barcode=NULL;
    char *criticalemission=NULL;
    char *Stationtype=NULL;
    char *operationtype=NULL;
    char *operationDesc=NULL;
    int operationcount1=0;
    tag_t *operationtag1=NULLTAG;
    char *operationID1=NULL;
    char *operationtype1=NULL;
    char *operationDesc1=NULL;
    
    char *designID1=NULL;
    char *designrevvID1=NULL;
    char *objectdesc1=NULL;
    char *traceandtrack1=NULL;
    char *barcode1=NULL;
    char *criticalemission1=NULL;
    char *Stationtype1=NULL;
    char *release_statuses=NULL;
    
    cout << "-----------------------------mpp_signoff_checks_Func----------------------" <<endl;

    EPM_ask_root_task(msg.task, &rootTask);
    AOM_ask_value_string(msg.task, "object_name", &CurrentTask);
    cout << "CurrentTask is:-"<< CurrentTask <<endl;
    
    AOM_ask_value_string(rootTask, "object_name", &parent_name);
    cout << "object_name is:-"<< parent_name <<endl;
    
    EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments);
    
    cout << "Target Attachment is :"<< noAttachment <<endl;
    QRY_find2("Control Objects...", &qryTagCntrl);

    int n_entryCntrl =3;
    char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
    char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
    qry_valuesCntrl[0]="psd_rlz_chk";
    qry_valuesCntrl[1]="psd_rlz_chk";
    qry_valuesCntrl[2]="0";
    int  	control_number_found		= 0;
    tag_t 	*cntr_objects				= NULLTAG;
    cout << "Control Object Query Found"<< endl;
    QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
    if(control_number_found>0)
    {

		AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&UserInfo1);
		AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&UserInfo2);
		AOM_ask_value_string(cntr_objects[0],"t5_Userinfo3",&UserInfo3);
		AOM_ask_value_string(cntr_objects[0],"t5_Userinfo4",&UserInfo4);
		AOM_ask_value_string(cntr_objects[0],"t5_Userinfo5",&UserInfo5);
		cout << "UserInfo1 is:-"<< UserInfo1 <<endl;
        cout << "UserInfo2 is:-"<< UserInfo2 <<endl;
        cout << "UserInfo3 is:-"<< UserInfo3 <<endl;
        cout << "UserInfo4 is:-"<< UserInfo4 <<endl;
        cout << "UserInfo5 is:-"<< UserInfo5 <<endl;
		string ObjTypeName;
        char * idofstation =NULL;
        TCTYPE_ask_object_type(attachments[0], &objTypeTag);
        TCTYPE_ask_name2(objTypeTag, &type_name);
        AOM_ask_value_string(attachments[0],"item_id",&idofstation);
        cout<<"ID of the Station:- "<<idofstation<<endl;
        string stringstationID =idofstation;
        ObjTypeName = type_name;
        cout << "type_name is:-"<< ObjTypeName <<endl;
		if (noAttachment > 0)
        {
			if((ObjTypeName=="Mfg0MEProcAreaRevision") || (ObjTypeName=="Mfg0MEProcLineRevision") )
            {
                cout << "if condition start:-" <<endl;
                if (tc_strcmp(error_msg,"NULL") !=0) MEM_free(error_msg);
				tag_t stationBOM = GetBomLine(stringstationID,type_name);
                BOM_line_ask_child_lines(stationBOM,&opcount,&optag);
                cout << "opcount:-" << opcount<<endl;
                if(opcount>0)
                {
					//added for loop
                    cout << "inside opcount if loop:-" <<endl;
                    char *StationID=NULL;
                    for (int c=0;c<opcount;c++)
                    {
                        cout << "inside opcount for loop"<<endl;
                        AOM_ask_value_string(optag[c],"bl_rev_awp0Item_item_id",& StationID);
                        cout << "Station Item ID:-" << StationID<<endl;
                        string stringstationID1 =StationID;
                        int operationcount=0;
                        tag_t * operationtag=NULLTAG;
                        //string Stationtype;  // Mfg0MEProcLineRevision
                        char *Stationtype ="Mfg0MEProcStatnRevision";
                        tag_t stationBOM1 = GetBomLine(stringstationID1,Stationtype); 
                        BOM_line_ask_child_lines(stationBOM1, &operationcount, &operationtag);
                        if(operationcount>0)
                        {
                            for(int d=0;d<operationcount;d++)
                            {
                              AOM_ask_value_string(operationtag[d],"bl_rev_awp0Item_item_id",& operationID);
                              cout << "Operation ID...:-" << operationID<<endl;
                              AOM_ask_value_string(operationtag[d],"fnd0bl_line_object_type",& operationtype);
                              cout << "Operation Type:-" << operationtype<<endl;
                              AOM_ask_value_string(operationtag[d],"bl_item_object_desc",& operationDesc);
                              cout << "Operation Description:-" << operationDesc<<endl;
							  AOM_UIF_ask_value(operationtag[d],"bl_item_release_statuses",&release_statuses);
							  cout << "release_statuses...:-" << release_statuses<<endl;
							  if ((tc_strcmp(release_statuses,"PSD Working")==0) || (tc_strcmp(release_statuses,"")==0) )
							  {
								  error++;
								  cout<< "\n Operation is not released from PSD." <<endl;         
							  }
							  cout << "error-------------  "<< error << endl;
							  if (error!=0)
							  {
								  cout<<"error_msg "<<error_msg<<endl;	
								  if (error_cnt==0)
								  {
									  
									  error_cnt =1;
									  cout<<"error_msg in if condition "<<error_msg<<endl;
									  // error_msg.clear();
									  // error_msg = error_msg + "\n" + "Below operations are not PSD released \n" + designID1;
									  tc_strcpy(error_msg," ");
									  tc_strcat(error_msg,"\n");
									  tc_strcat(error_msg,"Below operations are not PSD released \n");
									  tc_strcat(error_msg,operationID);
									  cout<<"error_msg val after strcat in if loop "<<error_msg<<endl;
									  
								  }
								  else
								  {
									  cout<<"error_msg in else condition "<<error_msg<<endl;
									  tc_strcat(error_msg," , ");
									  tc_strcat(error_msg,operationID);
									  //error_msg = error_msg + " , " + operationID;
									  cout<<"error_msg val after strcat in else loop "<<error_msg<<endl;
									  
									  error_cnt = error_cnt+1;   
									  
								  }
								  cout<<"Value of error_cnt is: "<<error_cnt<<endl;
								  cout<<"error_msg is: "<<error_msg<<endl;
								  if(error_cnt==1)
								  {
									  cout<<"INSIDE if error_cnt..."<<endl;
									  setAddStrFuction1(&i_cnt,&SetOprRelErr,error_msg);
									  cntFlag = 1;
									  cout<<"After setAddStrFuction1"<<endl;
								  }
								  else
								  {
									  cout<<"INSIDE else error_cnt..."<<endl;
									  setAddStrFuction1(&i_cnt,&SetOprRelErr,error_msg);
									  cntFlag = 1;
									  cout<<"After setAddStrFuction1"<<endl;
								  }
							  }

                            } 
                        }
                    }
				}
            }
            else if(ObjTypeName=="Mfg0MEProcStatnRevision")
            {
				cout << "else if  for Mfg0MEProcStatnRevision type"<<endl;
				if (tc_strcmp(error_msg,"NULL") !=0) MEM_free(error_msg);
				tag_t stationBOM2 = GetBomLine(stringstationID,type_name);
				BOM_line_ask_child_lines(stationBOM2, &operationcount1, &operationtag1);
                if(operationcount1>0)
                {
                    for(int d1=0;d1<operationcount1;d1++)
                    {
                        AOM_ask_value_string(operationtag1[d1],"bl_rev_awp0Item_item_id",& operationID1);
                        cout << "Operation ID...:-" << operationID1<<endl;
                        AOM_ask_value_string(operationtag1[d1],"fnd0bl_line_object_type",& operationtype1);
                        cout << "Operation Type:-" << operationtype1<<endl;
                        AOM_ask_value_string(operationtag1[d1],"bl_item_object_desc",& operationDesc1);
                        cout << "Operation Description:-" << operationDesc1<<endl;
						
					    AOM_UIF_ask_value(operationtag1[d1],"bl_item_release_statuses",&release_statuses);
                        cout << "release_statuses...:-" << release_statuses<<endl;
                        if ((tc_strcmp(release_statuses,"PSD Working")==0) || (tc_strcmp(release_statuses,"")==0) )
                        {
                            error++;
                            cout<< "\n Operation is released not from PSD." <<endl;         
                        }
						cout << "error-------------  "<< error << endl;
						if (error!=0)
						{
							cout<<"error_msg "<<error_msg<<endl;	
							if (error_cnt==0)
							{
								
								error_cnt =1;
								cout<<"error_msg in if condition "<<error_msg<<endl;
								// error_msg.clear();
								// error_msg = error_msg + "\n" + "Below operations are not PSD released \n" + designID1;
								tc_strcpy(error_msg," ");
								tc_strcat(error_msg,"\n");
								tc_strcat(error_msg,"Below operations are not PSD released \n");
								tc_strcat(error_msg,operationID1);
								cout<<"error_msg val after strcat in if loop "<<error_msg<<endl;
								
							}
							else
							{
								cout<<"error_msg in else condition "<<error_msg<<endl;
								tc_strcat(error_msg," , ");
								tc_strcat(error_msg,operationID1);
								//error_msg = error_msg + " , " + operationID1;
								cout<<"error_msg val after strcat in else loop "<<error_msg<<endl;
								
								error_cnt = error_cnt+1;   
								
							}
							cout<<"Value of error_cnt is: "<<error_cnt<<endl;
							cout<<"error_msg is: "<<error_msg<<endl;
							if(error_cnt==1)
							{
								cout<<"INSIDE if error_cnt..."<<endl;
								setAddStrFuction1(&i_cnt,&SetOprRelErr,error_msg);
								cntFlag = 1;
								cout<<"After setAddStrFuction1"<<endl;
							}
							else
							{
								cout<<"INSIDE else error_cnt..."<<endl;
								setAddStrFuction1(&i_cnt,&SetOprRelErr,error_msg);
								cntFlag = 1;
								cout<<"After setAddStrFuction1"<<endl;
							}
						}

					}
			    }
            }
			else
            {
				cout << "class not found"<< endl;
            }

             cout << "-----cntFlag-------"<< cntFlag <<endl;
			if(cntFlag==0)
            {
                cout << "EPM_go decision" <<endl;

			  decision = EPM_go;
              //return ITK_ok;
            }
			else
            {
             cout << "EPM_nogo decision" <<endl;
              EMH_clear_errors();
              EMH_store_error_s1(EMH_severity_error, ITK_err, error_msg);
              decision = EPM_nogo;
              return ITK_err;	
	        }
            cout << "closing the loop" <<endl;
		}
    }
	else
    {
		cout << "control obj is Not found"<< endl;
        decision = EPM_go;
    }

    return decision;

}




extern int tm_MPP_assign_register_method(int *decision, va_list args)
{

    cout << "Welcome to MPP Customization in tm_MPP_assign" << endl;
    int ifail = 0;
    METHOD_id_t CheckInMethod;
    METHOD_id_t processRevIDMethod;
    METHOD_id_t OPIDMethod;
    METHOD_id_t LineIDMethod;
    METHOD_id_t stationIDMethod;
    METHOD_id_t productbopIDMethod;
    *decision = ALL_CUSTOMIZATIONS;
    // for MppToPalmsysWebservice calling on post action
    ifail = METHOD_find_method(RES_Type, RES_checkin_msg, &CheckInMethod);
    if(CheckInMethod.id)
    {
        ifail = METHOD_add_action(CheckInMethod, METHOD_post_action_type,(METHOD_function_t)CheckInPostAction, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }

    ////Aniket

    ifail = METHOD_find_method("MEProcessRevision", "ITEM_copy_rev", &processRevIDMethod);
    if(processRevIDMethod.id)
    {
        ifail = METHOD_add_action(processRevIDMethod, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }

    ifail = METHOD_find_method("MEOPRevision", "ITEM_copy_rev", &OPIDMethod);
    if(OPIDMethod.id)
    {
        ifail = METHOD_add_action(OPIDMethod, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }
    ifail = METHOD_find_method("Mfg0MEProcLineRevision", "ITEM_copy_rev", &LineIDMethod);
    if(LineIDMethod.id)
    {
        ifail = METHOD_add_action(LineIDMethod, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }
    ifail = METHOD_find_method("Mfg0MEProcStatnRevision", "ITEM_copy_rev", &stationIDMethod);
    if(stationIDMethod.id)
    {
        ifail = METHOD_add_action(stationIDMethod, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }
    ifail = METHOD_find_method("MEProductBOPRevision", "ITEM_copy_rev", &productbopIDMethod);
    if(productbopIDMethod.id)
    {
        ifail = METHOD_add_action(productbopIDMethod, METHOD_post_action_type,(METHOD_function_t)Revise_properties_post, NULL) != ITK_ok;
    }
    else
    {
        cout << "CheckInMethod Not found"<< endl;
    }

    //PlantBOPItemIDAssignmentPre
     METHOD_id_t SaveMethodForPlantPre;
    //calling post action for Line Nomenclature
    ifail = METHOD_find_method("Mfg0MEPlantBOPRevision", ITEM_create_msg, &SaveMethodForPlantPre);
    //ifail = METHOD_find_method("Mfg0MEProcLineRevision", TC_save_msg, &SaveMethodForLinePre);
    if(SaveMethodForPlantPre.id!=NULL)
    {
        //ifail = METHOD_add_action(SaveMethodForLinePre, METHOD_pre_action_type,(METHOD_function_t)LineItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForPlantPre, METHOD_pre_action_type,(METHOD_function_t)PlantBOPItemIDAssignmentPre, NULL) != ITK_ok;
    }
    else
    {
        cout << "create method For Plant  Method Not found"<< endl;
    }

    METHOD_id_t SaveMethodForPlant;
    //calling post action for Line Nomenclature
    ifail = METHOD_find_method("Mfg0MEPlantBOPRevision", ITEM_create_msg, &SaveMethodForPlant);
    //ifail = METHOD_find_method("Mfg0MEProcLineRevision", TC_save_msg, &SaveMethodForLine);
    if(SaveMethodForPlant.id!=NULL)
    {
        //ifail = METHOD_add_action(SaveMethodForLine, METHOD_pre_action_type,(METHOD_function_t)LineItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForPlant, METHOD_post_action_type,(METHOD_function_t)PlantBOPItemIDAssignment, NULL) != ITK_ok;
    }
    else
    {
        cout << "create method is Not found"<< endl;
    }

    //........................

    METHOD_id_t SaveMethodForLinePre;
    //calling post action for Line Nomenclature
    ifail = METHOD_find_method("Mfg0MEProcLineRevision", ITEM_create_msg, &SaveMethodForLinePre);
    //ifail = METHOD_find_method("Mfg0MEProcLineRevision", TC_save_msg, &SaveMethodForLinePre);
    if(SaveMethodForLinePre.id!=NULL)
    {
        //ifail = METHOD_add_action(SaveMethodForLinePre, METHOD_pre_action_type,(METHOD_function_t)LineItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForLinePre, METHOD_pre_action_type,(METHOD_function_t)LineItemIDAssignmentPre, NULL) != ITK_ok;
    }
    else
    {
        cout << "create method For Line Method Not found"<< endl;
    }
    
    METHOD_id_t SaveMethodForLine;
    //calling post action for Line Nomenclature
    ifail = METHOD_find_method("Mfg0MEProcLineRevision", ITEM_create_msg, &SaveMethodForLine);
    //ifail = METHOD_find_method("Mfg0MEProcLineRevision", TC_save_msg, &SaveMethodForLine);
    if(SaveMethodForLine.id!=NULL)
    {
        //ifail = METHOD_add_action(SaveMethodForLine, METHOD_pre_action_type,(METHOD_function_t)LineItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForLine, METHOD_post_action_type,(METHOD_function_t)LineItemIDAssignment, NULL) != ITK_ok;
    }
    else
    {
        cout << "create method is Not found"<< endl;
    }
    //Indira Nomenclature of Station

	 METHOD_id_t SaveMethodForStation;
    //calling post action for Operation Nomenclature
    ifail = METHOD_find_method("Mfg0MEProcStatnRevision", ITEM_create_msg, &SaveMethodForStation);
    //ifail = METHOD_find_method("Mfg0MEProcStatnRevision", TC_save_msg, &SaveMethodForStation);
    if(SaveMethodForStation.id)
    {
        //ifail = METHOD_add_action(SaveMethodForStation, METHOD_pre_action_type,(METHOD_function_t)StationItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForStation, METHOD_post_action_type,(METHOD_function_t)StationItemIDAssignment, NULL) != ITK_ok;
    }
    else
    {
        cout << "SaveMethodForStation Not found"<< endl;
    }

    METHOD_id_t SaveMethodForStationPre;
    //calling post action for Station Nomenclature
    ifail = METHOD_find_method("Mfg0MEProcStatnRevision", ITEM_create_msg, &SaveMethodForStationPre);
    //ifail = METHOD_find_method("Mfg0MEProcStatnRevision", TC_save_msg, &SaveMethodForStation);
    if(SaveMethodForStationPre.id)
    {
        //ifail = METHOD_add_action(SaveMethodForStation, METHOD_pre_action_type,(METHOD_function_t)StationItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForStationPre, METHOD_pre_action_type,(METHOD_function_t)StationItemIDAssignmentPre, NULL) != ITK_ok;
    }
    else
    {
        cout << "SaveMethodForStationPre Not found"<< endl;
    }
    
    METHOD_id_t SaveMethodForProcess;
    //calling post action for Process Nomenclature
    ifail = METHOD_find_method("MEProcessRevision", ITEM_create_msg, &SaveMethodForProcess);
    //ifail = METHOD_find_method("MEProcessRevision", TC_save_msg, &SaveMethodForProcess);
    if(SaveMethodForProcess.id)
    {
        //ifail = METHOD_add_action(SaveMethodForProcess, METHOD_pre_action_type,(METHOD_function_t)ProcessItemIDAssignment, NULL) != ITK_ok;
        ifail = METHOD_add_action(SaveMethodForProcess, METHOD_post_action_type,(METHOD_function_t)ProcessItemIDAssignment, NULL) != ITK_ok;
    }
    else
    {
        cout << "SaveMethodForProcess Not found"<< endl;
    }
    

    // Indira Nomenclature of Operation

    tag_t COQueryTag = NULLTAG;
    QRY_find2("Control Objects...",&COQueryTag);
    if(COQueryTag != NULLTAG)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="Operation";
        Valuesp[1]="Operation";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;
        QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp > 0)
        {
            cout << "MPP Operation Control Object found" << endl;
            METHOD_id_t SaveMethodForOperation;
            //calling post action for Operation Nomenclature
            ifail = METHOD_find_method("MEOPRevision", ITEM_create_msg, &SaveMethodForOperation);
           //ifail = METHOD_find_method("MEOPRevision", TC_save_msg, &SaveMethodForOperation);
            if(SaveMethodForOperation.id)
            {
                ifail = METHOD_add_action(SaveMethodForOperation, METHOD_post_action_type,(METHOD_function_t)OperationItemIDAssignment, NULL) != ITK_ok;
                //ifail = METHOD_add_action(SaveMethodForOperation, METHOD_pre_action_type,(METHOD_function_t)OperationItemIDAssignment, NULL) != ITK_ok;
            }
            else
            {
                cout << "SaveMethodForOperation Not found"<< endl;
            }
        }
		else
		{
			cout << "MPP Operation Control Object not found" << endl;
		}
    }

    if (ITK_ok == EPM_register_action_handler("MppToPalmsysHandler", "", MppToPalmsysHandler))
    {
        cout << "MppToPalmsysHandler registered"<< endl;
    }
    else
    {
        cout << "MppToPalmsysHandler not registered"<< endl;
    }

     METHOD_id_t SaveMethodForWorkArea;
    //calling post action for Operation Nomenclature
    //ifail = METHOD_find_method("Mfg0MEProcAreaRevision", TC_save_msg, &SaveMethodForWorkArea);
    ifail = METHOD_find_method("Mfg0MEProcAreaRevision", ITEM_create_msg, &SaveMethodForWorkArea);
    if(SaveMethodForWorkArea.id)
    {
        ifail = METHOD_add_action(SaveMethodForWorkArea, METHOD_post_action_type,(METHOD_function_t)WorkAreaItemIDAssignment, NULL) != ITK_ok;
    }
    else
    {
        cout << "SaveMethodForWorkArea Not found"<< endl;
    }

        //added by sanjay

    if (ITK_ok == EPM_register_rule_handler("mpp_signoff_checks_Func", "This Handler is used to display message", (EPM_rule_handler_t)mpp_signoff_checks_Func))

    {

        cout << "mpp_signoff_checks_Func registered"<< endl;

    }
    else
    {

        cout << "mpp_signoff_checks_Func not registered"<< endl;

    }


    return 0;
}
extern "C" DLLAPI int tm_MPP_assign_register_callbacks()
{
    cout << "Before registered function in MPP"<< endl;
    CUSTOM_register_exit("tm_MPP_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_MPP_assign_register_method);
    cout << "registered function tm_MPP_assign"<< endl;
    return 0;
}
