/****************************************************************************************************
*  File				: erc_dml_assign.c
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes
*	1		08/08/2018				Mohan Tayade		New DFM-A DML introduction and validations/Live for DR-validations.
*	2		12/09/2016				Mohan Tayade		Allow to attach DFM-A module under module release DML and live other validation of MRDML to DFMR.
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;


tag_t t5_UpdateRleaseStatus(tag_t object_tag)
{
		tag_t		class_id				=     NULLTAG;
		char		*class_name				=    NULL;
		tag_t		tReleaseStatusList_checkin=NULLTAG;
		logical		log1;
		int			n_values_checkin			=0;
		int			cunt1					=	0;
		tag_t*		attr_tags_checkin		=	NULLTAG;
		logical		*is_it_null_checkin		=   NULL;
		logical		*is_it_empty_checkin	=   NULL;

		int status = ITK_ok;

		status = POM_class_of_instance(object_tag,&class_id);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t class_id found......\n");
		}

		status = POM_name_of_class(class_id,&class_name);
		if(status==ITK_ok)
	    {
			printf("\n class_name is :%s\n",class_name);fflush(stdout);
		}

		status = POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin);fflush(stdout);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t release_status_list found......\n");
		}

		status =POM_unload_instances (1,&object_tag);
		status =POM_load_instances(1,&object_tag,class_id,1);
		status =POM_is_loaded(object_tag,&log1);
		if(status==ITK_ok)
	    {
			printf("\n\n\t\t status Updated......\n");
		}

		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}else
		printf("Load Failure\n"  );

		status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
		if(status==ITK_ok)
	    {
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		}

		if(n_values_checkin>0)
		{
			status = POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin);
			if(status==ITK_ok)
			{
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
			}

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);

				status =POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1);
				if(status==ITK_ok)
				{
					printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
				}

				status =POM_save_instances(1,&object_tag,1);
				status =POM_refresh_instances(1,&object_tag,class_id,2);
				status =AOM_lock(object_tag);
				status =AOM_save(object_tag);
				status =AOM_refresh(object_tag,1);
			}

			 status =AOM_unlock(object_tag);
			 if(status==ITK_ok)
			 {
				printf("\n object_tag unlocked..........\n");fflush(stdout);
			 }
		  }
	return object_tag;
}
;

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;
	int   ifail				= 0;


	CALLAPI(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		CALLAPI(POM_class_of_instance(status_list[0],&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_unload_instances (st_count,status_list));
		CALLAPI(POM_load_instances(st_count,status_list,class_id,1));
		CALLAPI(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//CALLAPI(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//CALLAPI(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			CALLAPI(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"11-MAR-2014 00:00 to UP",&eff_t));
			CALLAPI(AOM_save(status_list[0]));
			CALLAPI(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//CALLAPI(AOM_save(*itemRev));
		//CALLAPI(AOM_unlock(*itemRev));
	}
	  return ITK_ok;
}

//Added by kalpesh(26-07-2018)

int attach_dataset_on_dmlsubmit(EPM_action_message_t msg)
{	
	int				ifail				= ITK_ok;
	int				count				= 0;

	tag_t			relation1			= NULLTAG;
	tag_t			relation2			= NULLTAG;
	tag_t			root_task			= NULLTAG;
	tag_t			dataset1			= NULLTAG;
	tag_t			dataset2			= NULLTAG;
	tag_t			rel_type			= NULLTAG;
	tag_t			dml_rev_tag			= NULLTAG;
	tag_t			*attachments		= NULL;
	char			*dataset_name1		= NULL;
	char			*dataset_name2		= NULL;
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\n\t Root task found...!!");

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n\t EPM_ask_attachments of :: %d\n",count);

	ifail = AE_find_dataset2("Option/Option value addition/modification", &dataset1);
	ifail = AE_find_dataset2("Architecture Module addition", &dataset2);
	
	ifail = AOM_ask_value_string(dataset1, "object_name", &dataset_name1);
	ifail = AOM_ask_value_string(dataset2, "object_name", &dataset_name2);
	printf("\ndataset name:%s", dataset_name1);
	printf("\ndataset name:%s", dataset_name2);

	ifail = GRM_find_relation_type("CMReferences", &rel_type);

	//ifail = AOM_refresh(dataset, 1);
	ifail = GRM_create_relation(attachments[0], dataset1, rel_type, NULLTAG, &relation1);
	ifail = GRM_create_relation(attachments[0], dataset2, rel_type, NULLTAG, &relation2);
	ifail = GRM_save_relation(relation1);
	ifail = GRM_save_relation(relation2);

	//ifail = AOM_refresh(dataset, 0);

	MEM_free(attachments);
	
	return ifail;
}

//kalpesh(End)


int erc_task_breakdown( EPM_action_message_t msg )
{
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l	,cnt	=0;

		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		tag_t			*objTypeTagTask			= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		tag_t DMLTag = NULLTAG;
		tag_t AssyTag = NULLTAG;
		tag_t PrtTag = NULLTAG;
		tag_t *Dml_tasks= NULLTAG;
		tag_t *PartsTag= NULLTAG;
		tag_t attach = NULLTAG;
		tag_t   release_status =NULLTAG;
		tag_t    	    superuserTag				    =NULLTAG;
		tag_t    	    propEff_tag				    =NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		int  attype = 1,partcnt=0,k=0;

		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			task_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
		char*			Part_no					=NULL;
		char*			ReleaseStatus					=NULL;
		char*			value					=NULL;
		char			*eff_date         = NULL;
		char *FrmDate;
		char *ItemID;
		char cNextDate[20]={0};
		char cCurrentAccessDate[20]={0};
		date_t test_date_1;
		date_t cCurrent_date_1;
	    date_t DayTommorow ;
	    date_t test_date_2;
	    date_t *start_end_date = NULL;
	    //date_t *CLdate = NULL;
	    tag_t eff_d = NULLTAG;
		logical  retain_released_date =TRUE;
		logical stat  ;
		//Control Obj
		char	*DMLtype	= NULL;
		char	*info4	= NULL;
		char 	*cPartNo			= NULL;
		char	*latest_rev_Rel_Stus	= NULL;
		char 	*rev_idd				= NULL;
		char	*rel_status				= NULL;
		char 	*status_name			= NULL;
		char 	*EffvalueAfter			= NULL;
		char 	*Effvalue				= NULL;
		char	*old_to_date			= NULL;
		tag_t	*rev_list				= NULL;
		tag_t	*effectivities_tag		= NULL;
		tag_t	*status_lst				= NULL;
		tag_t	LpropEff_tag		= NULLTAG;
		tag_t	Leff_d				= NULLTAG;
		tag_t   *CntrlObjectTag      = NULLTAG;
		tag_t   qryTag     = NULLTAG;
		tag_t	AftpropEff_tag		= NULLTAG;
		tag_t	All_item_tag		= NULLTAG;
		int n_entry    = 1;
		int Item_count      =  0;
		int jj=  0;
		int j=  0;
		int ii      =  0;
		int	n_dtes 	= 0;
		int	n_effectivities 		= 0;
		int	count_status 		= 0;
		int  rsltCount      =  0;
		date_t Ltest_date_2;
		date_t Ltest_date_1;
		date_t *Rel_start_end_values	= NULL;
		date_t *Lstart_end_date			= NULL;
		char   *qry_entry[1]  = {"SYSCD"};
		char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
		WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
		logical date_is_valid  ;
		logical stat1  ;

		tag_t UpdateRlease_t1			= NULLTAG;
		tag_t UpdateRlease_t2			= NULLTAG;
		tag_t UpdateRlease_t3			= NULLTAG;

		POM_get_user(&username,&user_tag);
		printf("\nStarting for taskbreskdownnn :%s....\n",username);fflush(stdout);

		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	    printf("\nCurrentTask:%s\n",CurrentTask);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n added by :: skk - cCurrentAccessDate : %s\n",cCurrentAccessDate);

		if(strcmp(parent_name,"Change Request Life Cycle")==0 || strcmp(parent_name,"Module Release Workflow"))
		{
			//1.34:Effectivity Work for Old revisionA
			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n Eff:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Eff:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali";
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n Eff:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4));
				printf("\n Eff: info4 is  = [%s]\n", info4);fflush(stdout);
			}
			//1.34:Effectivity Work for Old revisionA
			//if(strstr(CurrentTask,"Add Solution item")!=NULL)
			CALLAPI(SA_find_user("infodba",&superuserTag));
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];
			}
			CALLAPI(AOM_lock(DMLTag));
			CALLAPI(AOM_set_value_string(DMLTag,"CMClosure","Closed"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMMaturity","Complete"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMDisposition","Approved"));
			//CALLAPI(AOM_set_value_string(DMLTag,"CMClosureDate",cCurrentAccessDate));

			if(ITK_ok != (ifail = AOM_save(DMLTag)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

			/*
			UpdateRlease_t1 = t5_UpdateRleaseStatus(DMLTag);
			if (UpdateRlease_t1)
			{
				printf("\n Status Updated NULL on DML Revision Object................\n");fflush(stdout);
			}else
			printf("\n UpdateRlease_t1 not found! ! !");  fflush(stdout);
			*/

			CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
			CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

			if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
			{
				CALLAPI(EPM_add_release_status(release_status,1,&DMLTag,retain_released_date));
			}
			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

		    CALLAPI(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&cnt,&Dml_tasks));
			printf("\n Now cnt:%d\n",cnt);fflush(stdout);

			if (cnt>0)
			{
				for (i=0;i<cnt ;i++ )
				{
					   AOM_ask_value_string(Dml_tasks[i],"object_type",&object_type);
					   printf("\n object_type is :%s\n",object_type);fflush(stdout);

					   if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
					   {
							getCurrentDateTime(cCurrentAccessDate);
							printf("\n added by :: skk - cCurrentAccessDate : %s\n",cCurrentAccessDate);

							//AOM_set_value_date

							CALLAPI(AOM_lock(Dml_tasks[i]));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosure","Closed"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMMaturity","Complete"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMDisposition","Approved"));
							//CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosureDate",cCurrentAccessDate));

							if(ITK_ok != (ifail = AOM_save(Dml_tasks[i])))
							{
								return ifail;
							}

							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

							/*
							UpdateRlease_t2 = t5_UpdateRleaseStatus(Dml_tasks[i]);
							if (UpdateRlease_t2)
							{
								printf("\n Status Updated on DML Task................\n");fflush(stdout);
							}else
							printf("\n UpdateRlease_t2 not found! ! !");  fflush(stdout);
							*/

							CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
							CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

							if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
							{
								CALLAPI(EPM_add_release_status(release_status,1,&Dml_tasks[i],retain_released_date));
							}
							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

						    CALLAPI(AOM_UIF_ask_value(Dml_tasks[i],"Analyst",&DmlAnalyst_name));
						    printf("\nDml Task Analyst_name:%s\n",DmlAnalyst_name);fflush(stdout);

						    CALLAPI(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem",&partcnt,&PartsTag));
						    printf("\n Now partcnt:%d\n",partcnt);fflush(stdout);

						   if (partcnt>0)
						   {
							 for (k=0;k<partcnt ;k++ )
							 {
								printf("\n for k =:%d\n",k);fflush(stdout);
								AssyTag=PartsTag[k];

								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n Part_no  is :%s\n",Part_no);	fflush(stdout);
								CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype));
								printf("\n Part_no:%s  and DML Type: %s\n",Part_no,DMLtype);	fflush(stdout);
								//1.34:Effectivity Work for Old revision
								if(tc_strstr(info4,"EFFECTIVITY") == NULL)
								{
									if((strcmp(DMLtype,"Veh")==0)||(strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"DFMR")==0))
									{
										printf("\n Eff:Setting effectivity on latest released revision!!\n");fflush(stdout);
										CALLAPI(AOM_UIF_ask_value (AssyTag, "item_id", &cPartNo));
										CALLAPI(AOM_UIF_ask_value (AssyTag, "release_status_list", &latest_rev_Rel_Stus));
										printf("\n Eff:Part no:[%s] latest_rev_Rel_Stus:[%s]\n",cPartNo,latest_rev_Rel_Stus);fflush(stdout);
										if(tc_strcmp(latest_rev_Rel_Stus, "ERC Released") != 0)
										{
											CALLAPI(ITEM_find_item (cPartNo, &All_item_tag));

											CALLAPI(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
											printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
											if(Item_count > 0)
											{
												for(ii=Item_count-1;ii>=0;ii--)
												{
													CALLAPI(AOM_UIF_ask_value (rev_list[ii], "release_status_list", &rel_status));
													printf("\n Eff: Release Status is:%s.", rel_status);fflush(stdout);
													if(tc_strcmp(rel_status, "ERC Released") == 0)
													{
														CALLAPI(AOM_UIF_ask_value (rev_list[ii], "item_revision_id", &rev_idd));
														printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);

														CALLAPI(WSOM_ask_release_status_list (rev_list[ii], &count_status, &status_lst));
														if(count_status > 0)
														{
															for(j=0;j<count_status;j++)
															{
																CALLAPI(AOM_ask_value_string (status_lst[j], "object_name", &status_name));
																printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
																if((tc_strcmp(status_name,"ERC Released")==0) ||tc_strcmp(status_name,"T5_LcsErcRlzd")==0)
																{
																	printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
																	if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
																	printf("\n Eff:stat1:%d",stat1);fflush(stdout);

																	if(stat1 != true)
																	{
																		printf("\n Eff:stat1 is not true .....");fflush(stdout);
																	}
																	else
																	{
																		printf("\n Eff:stat1 is  true .....");fflush(stdout);
																	}

																	if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
																	if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
																	printf("\n Eff:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

																	if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
																	printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
																	if(n_effectivities > 0)
																	{
																		for(jj=0;jj<n_effectivities;jj++)
																		{
																			if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
																			printf("\n Eff:no of Rel_start_end_value:%d\n", n_dtes);fflush(stdout);
																			if(n_dtes > 0)
																			{
																				if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
																				{
																					return ifail;
																				}
																				printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
																				if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
																				{
																					return ifail;
																				}
																				printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
																				if(date_is_valid != true)
																				{
																					printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
																				}
																				else
																				{
																					printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
																				}
																			}
																			else
																			{
																				printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
																			}
																		}
																	}
																	//Current Date
																	getCurrentDateTime(cCurrentAccessDate);
																	printf("\n Eff:cCurrentAccessDate is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
																	if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
																	{
																		return ifail;
																	}
																	printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
																	Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
																	Lstart_end_date[0] = Ltest_date_1;
																	Lstart_end_date[1] = Ltest_date_2;

																	printf("\n EFF:Clearing effectivities...");fflush(stdout);

																	if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
																	{
																		return ifail;
																	}
																	printf("\n EFF:Creating effectivities...");fflush(stdout);
																	if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
																	{
																		return ifail;
																	}
																	printf("\n EFF:Saving effectivities...");fflush(stdout);
																	if(ITK_ok != (ifail = AOM_save(Leff_d)))
																	{
																		return ifail;
																	}
																	printf("\n EFF:Saving Revision...");fflush(stdout);
																	if(ITK_ok != (ifail = AOM_save(status_lst[j])))
																	{
																		return ifail;
																	}
																	printf("\n EFF:Refreshing Revision...");fflush(stdout);
																	if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
																	{
																		return ifail;
																	}
																	printf("\n EFF:Checking effectivities txt...");fflush(stdout);
																	if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))	 return ifail;
																	if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))	 return ifail;
																	printf("\n Eff:effectivity_text EffvalueAfter : %s\n",EffvalueAfter);fflush(stdout);
																	if(ITK_ok != (ifail = AOM_refresh( rev_list[ii], 0 )))
																	{
																		return ifail;
																	}
																}
																else
																{
																	printf("\n Eff: Status name:%s for rev:%s\n", status_name, rev_idd); fflush(stdout);
																}
																MEM_free(status_name);
															}
														}
														else
														{
															printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
														}
														break;
													}
												}
											}
										}
										else
										{
											printf("\n EFF:part already released.");fflush(stdout);
										}
									}
								}
								//1.34:Effectivity Work for Old revision

								/*
								UpdateRlease_t3 = t5_UpdateRleaseStatus(AssyTag);
								if (UpdateRlease_t3)
								{
									printf("\n Status Updated on TC Part Revision................\n");fflush(stdout);
								}else
								printf("\n UpdateRlease_t2 not found! ! !");  fflush(stdout);
								*/

								CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
								CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

								if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
								{
									CALLAPI(EPM_add_release_status(release_status,1,&AssyTag,retain_released_date));
								}

		 						printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
								{
									if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;
									printf("\n stat:%d\n",stat);

									if(stat != true)
									{
										printf("\n stat is not true .....\n");
									}
									else
									{
										printf("\n stat is  true .....\n");
									}

									getCurrentDateTime(cCurrentAccessDate);
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
									printf("\n effectivity_text is value : %s\n",value);

									getNextDate(cNextDate);
									printf("\n cNextDate:%s",cNextDate);
									//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

									if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
									{
										return ifail;
									}
									start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

									printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

									start_end_date[0] = test_date_1;
									start_end_date[1] = test_date_2;

									if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(eff_d)))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
									printf("\n After setting effectivity_text value : %s\n",value);
									if(ITK_ok != (ifail = AOM_refresh( AssyTag, 0 )))
									{
										return ifail;
									}

								}
							  }

							}

						}

					 }

			 }

	  }
	  else
	  {
		printf("\n inside this loop \n");fflush(stdout);
	  }

		return ITK_ok;
}

int createCR_Task( METHOD_message_t *msg, va_list  args )
{
    tag_t	TaskTag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);

	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;

	int max_char_size = 80;
	int n_tags_found = 0;

	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	mad=0,m=0,
	ii			= 0;

	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;

	int number_found;
	tag_t *list_of_WSO_tags=NULLTAG;
	char *Proj_typ = NULL;
	char *ProjDesc = NULL;
	//char *DmlProj = NULL;
	//tag_t	Project_t		= NULLTAG;
	//tag_t	ObjTypProj	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DMLrlstype = NULL;
	char *SesUsr = NULL;
	//char *DmlDR = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char **DMLMdAddList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	WSO_search_criteria_t  	criteria;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside createCR_Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
		AOM_ask_value_string( TaskTag, "item_id", &item_id);
		AOM_ask_value_string( TaskTag, "current_id", &DML_no);
		AOM_ask_value_strings( TaskTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string( TaskTag, "t5_rlstype", &DMLrlstype);
		AOM_ask_value_strings(TaskTag,"t5_MdAddress",&mad,&DMLMdAddList);

		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n DMLrlstype : %s\n",DMLrlstype);fflush(stdout);
		printf("\n num is : %d\n",num);fflush(stdout);
		printf("\n ModuleAddress Count : %d\n",mad);fflush(stdout);

		if(num > 0)
		{
			if((tc_strcmp(DMLrlstype,"MR")==0)||(tc_strcmp(DMLrlstype,"DFMR")==0))
			{
				for(i=0;i<num;i++)
				{
					strcpy(item_id_dup,item_id);
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					printf("\n Task Name is :%s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_ChangeTaskRevision");
					status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);
					printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

					if(number_found == 0)
					 {
						ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",item_id_dup,&item,&rev);
						printf("\n Item created first time only with item_id111111------ \n");fflush(stdout);
						AOM_save(item);
						AOM_save(rev);
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_create_relation(TaskTag, rev, relation_type,  NULLTAG, &relation);
						GRM_save_relation(relation);

						if(mad>0)
						 {
							for(m=0;m<mad;m++)
							{
								printf("\nSetting..DML Module Address : %s\n",DMLMdAddList[m]);
								AOM_set_value_string_at(rev,"t5_ModuleAddress",m,DMLMdAddList[m]);
							}
							AOM_save(rev);
							AOM_refresh(rev,0);
						 }

					 }else { printf("\n item_id created twice......  \n");fflush(stdout); }
					 MEM_free(list_of_WSO_tags);
				 }
			}else
			{
				for(i=0;i<num;i++)
				{
					strcpy(item_id_dup,item_id);
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					printf("\n Task count in DB :: %s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_ChangeTaskRevision");
					status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);

					//ITEM_find_items_by_key_attributes(1, "item_id", item_id_dup, &n_tags_found, &tags_found);
					printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

					if(number_found == 0)
					{
						printf("\n item_id : %s and DML_no : %s\n ",item_id,DML_no);fflush(stdout);
						ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",item_id_dup,&item,&rev);
						printf("\n Item created first time only with item_id \n");fflush(stdout);

						AOM_save(item);
						AOM_save(rev);
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_create_relation(TaskTag, rev, relation_type,  NULLTAG, &relation);
						GRM_save_relation(relation);

						if(mad>0)
						 {
							for(m=0;m<mad;m++)
							{
								printf("\nSetting..DML Module Address : %s\n",DMLMdAddList[m]);
								AOM_set_value_string_at(rev,"t5_ModuleAddress",m,DMLMdAddList[m]);
							}
							AOM_save(rev);
							AOM_refresh(rev,0);
						 }

					}else { printf("\n Required item_id already in DB....  \n");fflush(stdout); }
					MEM_free(list_of_WSO_tags);
				 }
			}
		}else
		{
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"for Release Type TPL/Module Release Design Group is mandatory. Pls select design group.");
			return ITK_errStore1;
		}
	}

    return error_code;
}

int Pre_create_Dml( METHOD_message_t *msg, va_list  args )
{
    tag_t	DMLTag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);

	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;

	int max_char_size = 80;
	int n_tags_found = 0;

	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	mod_num=0,
	i=0,
	ij=0,
	ii			= 0;

	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	int     rsltCount      =  0;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;
	tag_t   qryTag     = NULLTAG;
	int number_found;
	tag_t *list_of_WSO_tags=NULLTAG;
	char *Proj_typ = NULL;
	char *ProjDesc = NULL;
	char *Prt_no = NULL;
	char *Prt_DR = NULL;
	char *DmlProj = NULL;
	tag_t	Project_t		= NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *DmlTypeCat = NULL;
	char *RlsType = NULL;
	char *DMLrlstype = NULL;
	char *SesUsr = NULL;
	char *DmlDR = NULL;
	char *PrtClass = NULL;
	char *DML_no = NULL;
	char **DMLMdAddrList;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	char    *qry_entry[1]  = {"SYSCD"};
	char	*PrtColInd	= NULL;
	char	*info3	= NULL;
	int     n_entry    = 1;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	int prt =0;
	int Tskcnt =0;
	int tsk =0;
	int prtcnt =0;
	int DMLSTVAL = 0;
	int PRTSTVAL = 0;
	char*	 DMLSubStr = NULL;
	char*	 Prt_Tp = NULL;
	char*	 PRTSubStr = NULL;
	tag_t *PrtsTag= NULLTAG;
	tag_t AssyTg = NULLTAG;
	tag_t  	PrtCls =	NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	char *Tsk_object_type = NULL;
	WSO_search_criteria_t  	criteria;

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
    printf("\n **************inside Pre_create_Dml***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		printf("\n  class is ChangeRequestRevision......\n");fflush(stdout);
		AOM_ask_value_string( DMLTag, "item_id", &item_id);
		AOM_ask_value_string( DMLTag, "current_id", &DML_no);
		AOM_ask_value_strings( DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string( DMLTag, "t5_rlstype", &DMLrlstype);
		printf("\n item_id : %s, DML_no : %s, DMLrlstype: %s, num is : %d",item_id,DML_no,DMLrlstype,num);fflush(stdout);

		//DR Validations 1.30-Mohan
		POM_get_user_id (&SesUsr);
		printf("\n DRCHK: Session user: %s\n",SesUsr); fflush(stdout);
		if(tc_strcmp(SesUsr,"infodba") !=0 && tc_strcmp(SesUsr,"loader") !=0)
		{
			//DML Creation validation for DML_Type
			printf("\n DML Creation validation for DML_Type...\n"); fflush(stdout);
			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali";
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n CREVali:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
				//printf("\n info3 is  = [%s]\n", info3);fflush(stdout);
				DmlTypeCat=(char *) MEM_alloc(30);
				tc_strcpy(DmlTypeCat,"");
				tc_strcpy(DmlTypeCat,",");
				tc_strcat(DmlTypeCat,DMLrlstype);
				tc_strcat(DmlTypeCat,",");
				printf("\n DRCHK:DmlTypeCat : %s",DmlTypeCat);fflush(stdout);

				if(tc_strstr(info3,DmlTypeCat) == NULL)
				{
					printf("\n DML_Type not allowed to create.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"This DML release type is not allowed to create.");
					return ITK_err;
				}
			}
			printf("\n DRCHK:1.30:CRE: DR VALIDATION START...\n"); fflush(stdout);
			if((tc_strcmp(DMLrlstype,"TPL")==0) || (tc_strcmp(DMLrlstype,"DFMR")==0)|| (tc_strcmp(DMLrlstype,"MR")==0)|| (tc_strcmp(DMLrlstype,"Veh")==0)|| (tc_strcmp(DMLrlstype,"PR")==0)|| (tc_strcmp(DMLrlstype,"CQ")==0) ||
				(tc_strcmp(DMLrlstype,"ECU")==0)|| (tc_strcmp(DMLrlstype,"WTR")==0)|| (tc_strcmp(DMLrlstype,"PPR")==0)|| (tc_strcmp(DMLrlstype,"BEC")==0))
			{
				//1.34:Checking for design group validation for Veh DML.
				if(tc_strcmp(DMLrlstype,"Veh")==0)
				{
					printf("\n num of design group:%d \n",num);fflush(stdout);
					if(num > 0)
					{
						for(ij=0;ij<num;ij++)
						{
							printf("\n DesignGroupList2:%s\n",DesignGroupList[ij]);fflush(stdout);
							if(tc_strcmp(DesignGroupList[ij],"00")!=0)
							{
								printf("\n DsgGrpERROR.\n"); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Vehicle release DML should have only '00' design group.");
								return ITK_err;
							}
						}
					}
				}
				//1.37: below validation removed and module kept optional.
				//�Module Address�  needs to be mandatory for �Module Release DML�
				/*if(tc_strcmp(DMLrlstype,"MR")==0)
				{
					AOM_ask_value_strings(DMLTag,"t5_MdAddress",&mod_num,&DMLMdAddrList);
					printf("\n mod_num:%d\n",mod_num);fflush(stdout);
					if(mod_num ==0)
					{
						printf("\n ModAddrERROR.\n"); fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Module Address is mandatory for Module release DML.\n Please update Module Address on DML.");
						return ITK_err;
					}
				}*/
				//Checking for DR validation..
				if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DmlDR)!=ITK_ok)PrintErrorStack();
				printf("\n DRCHK: DmlDR..:[%s] ",DmlDR);fflush(stdout);
				if(tc_strcmp(DmlDR,"")==0)
				{
					printf("\n DRCHK:ERROR:8.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NULL.\n Please update valid DR/AR-status.");
					return ITK_err;
				}
				if(tc_strcmp(DmlDR,"NA")==0)
				{
					printf("\n DRCHK:ERROR:9.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NA.\n Please update valid DR/AR-status.");
					return ITK_err;
				}
				if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DmlProj)!=ITK_ok)PrintErrorStack();
				printf("\n DRCHK: DmlProj:[%s]",DmlProj);fflush(stdout);
				if(ITEM_find_item(DmlProj,&Project_t)!=ITK_ok)PrintErrorStack();
				if (Project_t!=NULLTAG)
				{
					if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
					if(TCTYPE_ask_name(ObjTypProj,type_Proj));
					printf("\n MT:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
					if (tc_strcmp(type_Proj,"T5_Project")==0)
					{
						if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok)PrintErrorStack();
						printf("\n MT: ProjDesc : %s Proj_typ :[%s]\n",ProjDesc,Proj_typ);   fflush(stdout);
						//,E,G,H,A,
						if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
						{
							if((tc_strcmp(DmlDR,"AR0")!=0) && (tc_strcmp(DmlDR,"AR1")!=0)  && (tc_strcmp(DmlDR,"AR2")!=0) &&
							(tc_strcmp(DmlDR,"AR3")!=0) && (tc_strcmp(DmlDR,"AR4")!=0)  &&  (tc_strcmp(DmlDR,"AR5")!=0))
							{
								printf("\n DRCHK:ERROR:10.\n"); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid AR-status from AR0/AR1/AR2/AR3/AR4/AR5.\n DML project type-Engine/GearBox/Clutch/Axles should have AR-value");
								return ITK_err;
							}
						}
						else
						{
							if((tc_strcmp(DmlDR,"DR0")!=0) && (tc_strcmp(DmlDR,"DR1")!=0)  && (tc_strcmp(DmlDR,"DR2")!=0) &&
							(tc_strcmp(DmlDR,"DR3")!=0) && (tc_strcmp(DmlDR,"DR4")!=0)  &&  (tc_strcmp(DmlDR,"DR5")!=0))
							{
								printf("\n DRCHK:ERROR:11.\n"); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from DR0/DR1/DR2/DR3/DR4/DR5 instead of AR value.");
								return ITK_err;
							}
						}
						//Validation for dml updation:
						if(tc_strstr(info3,"DRCHK") == NULL)
						{
							//If parts attached to dml having DR-satus equal or greator than dml DR-status then allow to update.
							Tskcnt=0;
							if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
							printf("\n Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
							if (Tskcnt>0)
							{
								for (tsk=0;tsk<Tskcnt ;tsk++ )
								{
									if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
									printf("\n Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

									if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
									   if(AOM_ask_value_tags(Dml_tasks[tsk],"CMHasSolutionItem",&prtcnt,&PrtsTag)!=ITK_ok)PrintErrorStack();
									   printf("\n Now prtcnt:%d\n",prtcnt);fflush(stdout);

									   if (prtcnt>0)
									   {
											for (prt=0;prt<prtcnt ;prt++ )
											{
												PRTSTVAL=0;
												DMLSTVAL=0;
												DMLSubStr=NULL;
												PRTSubStr=NULL;
												printf("\n for k :%d\n",prt);fflush(stdout);
												AssyTg=PrtsTag[prt];
												if(AOM_ask_value_string(AssyTg,"item_id",&Prt_no)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(AssyTg,"t5_PartType",&Prt_Tp)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(AssyTg,"t5_PartStatus",&Prt_DR)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(AssyTg,"t5_ColourInd",&PrtColInd)!=ITK_ok)PrintErrorStack();
												if(POM_class_of_instance(AssyTg,&PrtCls)!=ITK_ok)PrintErrorStack();
												if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok)PrintErrorStack();
												printf("\n Part no: [%s] Prt_DR:[%s] Part type:[%s] Col:[%s] PrtClass:[%s]\n",Prt_no,Prt_DR,Prt_Tp,PrtColInd,PrtClass); fflush(stdout);

												if(((tc_strcmp(Prt_Tp,"V")==0) || (tc_strcmp(Prt_Tp,"VCCR")==0)|| (tc_strcmp(Prt_Tp,"A")==0) || (tc_strcmp(Prt_Tp,"T")==0) || (tc_strcmp(Prt_Tp,"C")==0) ||
												(tc_strcmp(Prt_Tp,"M")==0)||(tc_strcmp(Prt_Tp,"G")==0)) && ((tc_strcmp(PrtColInd,"Y")==0) || (tc_strcmp(PrtColInd,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
												{
													if((tc_strcmp(Prt_DR,"")==0)|| (tc_strcmp(Prt_DR,"NA")==0))
													{
														printf("\n DRCHK:ERROR:2.\n"); fflush(stdout);
														EMH_store_error_s1(EMH_severity_error,ITK_err,"Part DR-status should not be NA/NULL. Please update valid DR/AR-status.");
														return ITK_err;
													}
													DMLSubStr=subString(DmlDR, 2, 1);
													PRTSubStr=subString(Prt_DR, 2, 1);
													printf("\n DRCHK: DMLSubStr: %s, PRTSubStr: %s",DMLSubStr,PRTSubStr);fflush(stdout);
													DMLSTVAL=atoi(DMLSubStr);
													PRTSTVAL=atoi(PRTSubStr);
													printf("\n DRCHK: DMLDRi: %d, PRTDRi: %d",DMLSTVAL,PRTSTVAL);fflush(stdout);

													if (DMLSTVAL<=3 && PRTSTVAL>=4)
													{
														printf("\n DRCHK:ERROR:6.\n"); fflush(stdout);
														EMH_store_error_s1(EMH_severity_error,ITK_err,"Part with DR/AR-status AR4/AR5/DR4/DR5 are attached to Dml,\n so DML cannot update with AR3/DR3 status or less.");
														return ITK_err;
													}
													if (DMLSTVAL>=4 && PRTSTVAL<=3)
													{
														printf("\n DRCHK:ERROR:7.\n"); fflush(stdout);
														EMH_store_error_s1(EMH_severity_error,ITK_err,"Already attached parts are with lower DR-status than DML. Please update valid DR-status.");
														return ITK_err;
													}

													if (PRTSTVAL<DMLSTVAL)
													{
														printf("\n DRCHK:ERROR:5.\n"); fflush(stdout);
														EMH_store_error_s1(EMH_severity_error,ITK_err,"DR/AR-Status of the Part should not be less than DR/AR status of the DML.\n It should be equal or above than dml DR/AR-status.");
														return ITK_err;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
    return error_code;
}

int T5TaskToPartCreateVal( METHOD_message_t *msg, va_list  args )
{
	va_list largs;
	va_copy( largs, args );

	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	tag_t  *new_relation = va_arg(largs, tag_t *);

	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 80;

	int
	error_code	= ITK_ok,
	n_found		= 0,
	num=0,
	i=0,
	ii	,st_count1,cnt, tskcnt	,pcnt,j=0, j2=0;
	int count,count2,p1 = 0;

	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objTypeTag1=NULLTAG,
	objTypeTag2=NULLTAG,
	ObjTypDmlCRB=NULLTAG,
	ObjTypTskCRB=NULLTAG,
	item=NULLTAG,
	SpecTypeTag = NULLTAG,
	TaskTypeTag = NULLTAG,
	RefTypeTag = NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t*    status_list1=NULLTAG;
	//char *item_id_dup 	   = NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *DML_no = NULL;
	char *WSO_Name = NULL;
	char *projcode = NULL;
	char *projectname = NULL;
	char *item_id_secObj = NULL;
	char *item_id_priObj = NULL;
	char *tsk_object_type = NULL;
	char *t5fnd0Workflows = NULL;
	char **DesignGroupList;
	char *type_name1;
	int	   *instance_levels;
	int	   *instance_where_found;
	int    *class_levels;
	int    *class_where_found;
	int    n_instances		= 0;
	int    n_classes	,k	= 0;
	tag_t  *ref_classes		= NULLTAG;
	tag_t  *ref_instances	= NULLTAG;
	tag_t  *Primary_objects	= NULLTAG;
	tag_t  *PrimaryObjects	= NULLTAG;
	tag_t  task_class		= NULLTAG;
	tag_t  condition_class	= NULLTAG;
	tag_t  classId			= NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *DMLRevision2 = NULLTAG;
    tag_t DMLRevTag = NULLTAG;
    tag_t DMLRevTag2 = NULLTAG;
    tag_t TskSOTag = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t SpecRel_tag;
	tag_t RefRel_tag;
	tag_t class_id1=NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *SpecDoc_tag=NULLTAG;
	tag_t *attacheTo_tag=NULLTAG;
	tag_t *RefDoc_tag=NULLTAG;
	char*	 RevpartType		= NULL;
	tag_t reln_type =NULLTAG;
  	char* DMLtype		= NULL;
	char *sDrwInd;
	char *sRCurDes;
	char *sSpCurDes;
	char *sCurDes;
	char *username;
	char *username1;
	char *curentname;
	char *selectedname;
	char *selectedDMLname;
	tag_t   Childobject=NULLTAG;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t  	master =	NULLTAG;
	char*	 Arch_obj_str			= NULL;
	tag_t  relation_dep	= NULLTAG;
	int countConfigCtx = 0;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	 tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	tag_t *rev=NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	char*	 ContextobjName			= NULL;

	//MT start
	int jk, jkk, tsk = 0;
	int TskCRBcount = 0;
	int CRBcount = 0;
	int Tskcount = 0;
	int n_parents,n1_parents = 0;
	int *levels = 0;
	char* TskNm = NULL;
	char* projChar = NULL;
	char* DesgChar = NULL;
	char* AnaAssignee = NULL;
	char* Assignee = NULL;
	char* performer = NULL;
	char* AssigneeGrp = NULL;
	char* DsgGrp = NULL;
	char *DerRoleNme = NULL;
	char *PeerRevNm = NULL;
	char *ManAccesNm = NULL;
	char *DMUAccesNm = NULL;
	char* Part_no = NULL;
	char* LcStus = NULL;
	char* DMLReviewGrp = NULL;
	char* DMLReviewr = NULL;
	char* TskAnlyst = NULL;
	char* DMUReviewGrp = NULL;
	char* TskAnlystGrp = NULL;
	char* DMUReviewr = NULL;
	char *Task_class = NULL;
	char *TaskAnlyst = NULL;
	char *taskTempLT = NULL;
	tag_t *parents = NULLTAG;
	tag_t projTag = NULLTAG;
	//tag_t projTag;
	tag_t Ana_tag = NULLTAG;
	tag_t dml_tsk_rel_type = NULLTAG;
	tag_t tsk_CRB_rel_type = NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG;
	tag_t *TskRevision = NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t *TskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t TskRevTag = NULLTAG;
	tag_t Task_cls = NULLTAG;
	tag_t SecObjDSTag = NULLTAG;
	tag_t ProRelation_type = NULLTAG;
	tag_t *ProAsmMemberstag = NULLTAG;
	char   type_name8[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	logical is_Tsklatest;
	//MT End
	char *class_name1;
	int	ifail = 0;
	int	Speccount = 0,Refcount=0,is=0,ik=0,jr=0,intDrgCnt=0,sflag=0,rflag=0, n=0, ToTaskCnt=0, asmFlag=0;
	int result2=0 , n_attch_asm=0 , ip=0 , ProAsmChildErrorflag=0;
	char *ProObjName=NULL;
	char *ProObjId = NULL;
	char *ProObjRelSt = NULL;
    tag_t   window,rule,item_tag = null_tag,top_line;
	tag_t  *children1=NULLTAG;

	logical is_latest;

	int jd = 0;
	tag_t ArchAssyTag = NULLTAG;
	char*	 Arch_obj			= NULL;
	tag_t ArchobjTypeTag=NULLTAG;
	char *child_item_id=NULL;
	char *child_bl_formula=NULL;
	char *Rechk_bl_formula=NULL;

	char   Archtype_name[TCTYPE_name_size_c+1];

	//logical is_Design;
	//DR-Validation
	int DMLSTVAL = 0;
	int PRTSTVAL = 0;
	char*	 DMLSubStr = NULL;
	char*	 PRTSubStr = NULL;
	char*	 DmlDR = NULL;
	char*	 PrtType = NULL;
	char*	 PrtClass = NULL;
	char*	 PrtColInd = NULL;
	char*	 SesUsr = NULL;
	char*	 PrtDR = NULL;
	tag_t  	PrtCls =	NULLTAG;
	//DR-Validation
	tag_t  	Itemtag =	NULLTAG;
	tag_t	latestrev	=	NULLTAG;

	int dmlIncnt=0;
	int CmpleteVrf=0;
	//1.32: manager access
	int	jkl=0;
	int	ikk=0;
	int	numb=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	int	ManagerAccessFlag=0;
	int	Rolflag=0;
	char*	 DsgnGrp = NULL;
	char*	 DMLProj = NULL;
	char*	 ActGmName1 = NULL;
	char *parent_name	= NULL;
	char*	 ManAccesNme = NULL;
	char*	 TskNme = NULL;
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	tag_t	ActGm1 = NULLTAG;
	tag_t	Currproj = NULLTAG;
	//Control Table:
	char	*info4	= NULL;
	char	*info4r	= NULL;
	char	*info1r	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   *CntrolObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	int     rsltCount      =  0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	///1.32: manager access

	char   type_name[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   object_name[TCTYPE_name_size_c+1];
	char   Spectype_name[TCTYPE_name_size_c+1];
	char   Tasktype_name[TCTYPE_name_size_c+1];
	char   Reftype_name[TCTYPE_name_size_c+1];
	tag_t	relation	,propTag	,task_tag,taskDMLobj		= NULLTAG;
	//Qry project
	char	*info1	= NULL;
	tag_t	query_t   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	char	*DMLRelType	= NULL;
	char	*info2	= NULL;
	tag_t   *CntrlObjTag      = NULLTAG;
	tag_t   qry_t     = NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	ProjRelContObj = NULLTAG, *BypCnObj = NULL;

	int		AInpNum = 2,ByPasQCount = 0;
	char	*ANameInp[2] = {"SYSCD", "SUBSYSCD"};
	char	*AValInp[2] = {"STOPREL","PART"};
	//1.38:
	char	*Modltyp = NULL;
	char	*Prt_No	= NULL;
	int     n_entr    = 1;
	int     Manflag      =  0;
	int     PRDFlag      =  0;
	int     MangAccessFlg      =  0;
	int     rsltCunt      =  0;
	int		rsltCnt = 0;
	int		n_ent = 1;
	char	*qry_ent[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entr[1]  = {"SYSCD"};
	char    **qry_val2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_val = (char **) MEM_alloc(10 * sizeof(char *));

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	printf("\n **************inside T5TaskToPartCreateVal for DML and Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));

	printf("\n Inside Control Table for Assign Analyst/Manager..."); fflush(stdout);
	if(QRY_find("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
	}

	qry_values2[0] = "CREVali";
	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
	printf(" \n CREVali:rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
		printf("\n info4 is  = [%s]\n", info4);fflush(stdout);
	}

	if(strcmp(type_name,"T5_ChangeTaskRevision")==0)
	{
	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 for MR : %s\n",username); fflush(stdout);

	if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
    {
	printf("\n T5TaskToPartCreateVal primary_object  type_name MR:: %s\n", type_name);fflush(stdout);
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	{
	  CALLAPI(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
	  printf("\n\n\t\t DML Revision from Task for MR : %d",count);fflush(stdout);
	  for (j=0;j<count ;j++ )
	  {
		CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
		printf("\n\n\t\t is_latest MR is : %d\n",is_latest);fflush(stdout);

		if(is_latest != true)
		{
			printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
		}else
		{
			DMLRevTag = DMLRevision[j];
			CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
			CALLAPI(POM_name_of_class(class_id1,&class_name1));
			printf("\n\n\t\t class_name found1 MR :%s",class_name1);

			CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
			CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLProj));
			printf("\n\n\t\t DMLtype changingg is :%s DMLProj %s",DMLtype,DMLProj);fflush(stdout);

			//if(tc_strcmp(DMLtype,"MR")!=0)
			//{
			   if(secondary_object!=NULLTAG)
			   {
				   if(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
				   if(TCTYPE_ask_name(objTypeTag2,type_name2));
				   printf("\n T5TaskToPartCreateVal secondary_object  type_name2 :: %s\n", type_name2);fflush(stdout);

					printf("\n Inside T5_ChangeTaskRevision part to taskkk \n");fflush(stdout);
					if(relation_type != NULLTAG)
					{
						CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
					}
					printf("\n Neww relation_name  T5TaskToPartCreateVal CMHasSolutionItem:%s \n",relation_name);fflush(stdout);
						//MT: task start
					printf("\n TASK: Working for ChangeRequestRevision\n");fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(primary_object,"t5project",&projChar));
					CALLAPI(AOM_UIF_ask_value(primary_object,"item_id",&TskNm));
					CALLAPI(AOM_UIF_ask_value(primary_object,"t5designgroup",&DesgChar));
					printf("\n TASK: Task: [%s] Project:[%s] DesgChar:[%s]\n",TskNm,projChar,DesgChar);fflush(stdout);
					//CALLAPI(PROJ_find(projChar,&projTag));
					if(strcmp(relation_name,"HasParticipant")==0)
					{
						printf("\n TASK:Checking for Analyst: Relation Name:[%s] pri_object:[%s] Sec_object:[%s].\n",relation_name,type_name,type_name2);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));
						CALLAPI(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
						printf("\n TASK: AnaAssignee: %s	Assignee: %s ", AnaAssignee,Assignee);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeGroup",&AssigneeGrp));
						printf("\n TASK: AssigneeGrp: %s", AssigneeGrp);fflush(stdout);

						DsgGrp=subString(TskNm,11,2);
						printf("\n TASK: DsgGrp: %s",DsgGrp);fflush(stdout);

						//third logic
						if(strcmp(type_name2,"Analyst")==0)
						{
							projTag =NULLTAG;
							if (PROJ_find(DMLProj,&projTag) !=ITK_ok)PrintErrorStack();
							if(projTag !=NULLTAG)
							{
								if(tc_strstr(info4,"ANALYST") == NULL)
								{
									Gmcnt1=0;
									Gmcnt2=0;
									Gmcnt3=0;
									Rolflag=0;
									GmFound1 =NULLTAG;
									GmFound2 =NULLTAG;
									GmFound3 =NULLTAG;
									printf("\n TASK:Getting Project Team...\n");fflush(stdout);
									if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();
									printf("\n TASK:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
									for(jkl=0;jkl<Gmcnt1;jkl++)
									{
										ActGmName1=NULL;
										ActGm1 = GmFound1[jkl];
										if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
										//printf("\n Actual Group Member name:[%s]\n", ActGmName1);fflush(stdout);
										if(ActGmName1)
										{
											if (strcmp (ActGmName1,Assignee) == 0)
											{
											   printf("\n TASK:Valid user for Analyst...\n");fflush(stdout);
											   Rolflag++;
											   break;
											}
										}
									}
									if (Rolflag==0)
									{
											printf("\n TASK: NOT valid Analyst... \n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Analyst should have access for Project and design group. Kindly get access from TCUA Admin.");
											return ITK_err;
									}
								}

								CALLAPI(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type));
								if (dml_CRB_rel_type!=NULLTAG)
								{
									printf("\n TASK:inside HasParticipant.. \n");fflush(stdout);
									CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,dml_CRB_rel_type,&CRBcount,&DmlCRB));
									printf("\n TASK: DmlCRB count: %d",CRBcount);fflush(stdout);
									for (jk=0;jk<CRBcount ;jk++ )
									{
										//printf("\n TASK:jk: %d.\n",jk);fflush(stdout);
										DmlCRBTag = DmlCRB[jk];
										if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
										if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
										//printf("\n TASK:DML: type_name7 :: %s.", type_name7);fflush(stdout);
										if (strcmp(type_name7,"ChangeReviewBoard")==0)
										{
											CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr));
											CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMLReviewGrp));
											printf("\n TASK: DML Reviewer: [%s] Group: [%s] ",DMLReviewr,DMLReviewGrp);fflush(stdout);
										}
										if (strcmp(type_name7,"T5_DMUReviewer")==0)
										{
											CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMUReviewr));
											CALLAPI(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMUReviewGrp));
											printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
										}
									}
								}
								printf("\n TASK: DMLReviewr: [%s]	DMUReviewr: [%s] and Assignee: [%s] \n", DMLReviewr,DMUReviewr,AnaAssignee);fflush(stdout);

								if(DMLReviewr!=NULL)
								{
									printf("\n DML Reviewer Check");fflush(stdout);
									if(strcmp(DMLReviewr,AnaAssignee)==0)
									{
										printf("..ERROR:DML Reviewer and Task Analyst should not be same.!\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer and task analyst should not be same.");
										return ITK_err;
									}
								}
								if(DMUReviewr!=NULL)
								{
									printf("\n DMU Reviewer Check ");fflush(stdout);
									if(strcmp(DMUReviewr,AnaAssignee)==0)
									{
										printf("...ERROR:DMU Reviewer and Task Analyst should not be same.!\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Dml DMU reviewer and task analyst should not be same.");
										return ITK_err;
									}
								}
								printf("\n TASK:DML Reviewer and Task Analyst are not same.!!!!!!!!!!!!! \n");fflush(stdout);
								DerRoleNme=NULL;DerRoleNme=malloc(50);
								if (strlen(DsgGrp) ==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Design group is not available.");
									return ITK_err;
								}
								strcpy(DerRoleNme,DsgGrp);
								strcat(DerRoleNme,"_Designers");
								printf("\n TASK:Role name required: [%s]",DerRoleNme);fflush(stdout);
								if(strstr(Assignee,DerRoleNme)!=NULL)
								{
									printf("\n TASK: User having access for TASK project!!!!!!!!!!!!! \n");fflush(stdout);
								}
								else
								{
									printf("\n TASK: User NOT having access for Analyst. \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Analyst should have access for task design group. Kindly get access from TCUA Admin.");
									return ITK_err;
								}
							}
							else
							{
								printf("\n TASK: Project not found... \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Project not found, please contact to TCUA admin");
								return ITK_err;
							}
						}
						else if(strcmp(type_name2,"T5_PeerReviewer")==0)
						{
							printf("\n TASK: Peer reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_DMUReviewer")==0)
						{
							printf("\n TASK: DMU reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_BIWReviewer")==0)
						{
							printf("\n TASK: BIW Reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_TRIMReviewer")==0)
						{
							printf("\n TASK: TRIM Reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_CHReviewer")==0)
						{
							printf("\n TASK: Chassis reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_EEReviewer")==0)
						{
							printf("\n TASK: EE reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else if(strcmp(type_name2,"T5_PTReviewer")==0)
						{
							printf("\n TASK: Powertrain reviewer for TASK!!!!!!!!!!!!! \n");fflush(stdout);
						}
						else
						{
							printf("\n TASK: User having access for TASK project !!!!!!!!!!!!! \n");fflush(stdout);
						}
					}
					//MT task End T5_DMUReviewer

					CALLAPI(GRM_list_secondary_objects_only(primary_object,reln_type,&ToTaskCnt,&attacheTo_tag));
					printf("\n ToTaskCnt Value :-------------------->>>> Hanuman  %d\n",ToTaskCnt);fflush(stdout);
					if(ToTaskCnt > 0)
				    {
						for (ik=0;ik<ToTaskCnt;ik++ )
						{

							if(TCTYPE_ask_object_type(attacheTo_tag[ik],&TaskTypeTag));
							if(TCTYPE_ask_name(TaskTypeTag,Tasktype_name));
							printf("\n     T5TaskToPartCreateVal Having relation Name :: %s\n", Tasktype_name);fflush(stdout);
						}
				    }

					//TZ 1.28 Rajendra - Check DML owner and Session User
					if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
					{
						int BomCompleteAddPartFlag=0;
					  printf("\n     Inside attaching part to taskkk \n");fflush(stdout);
					  if(tc_strcmp(type_name2,"Design Revision")==0 || tc_strcmp(type_name2,"ItemRevision")==0 )
					  {
						 
						if(QRY_find2("ControlObjQry", &ProjRelContObj));
						if(ProjRelContObj)
						{
							 if(QRY_execute(ProjRelContObj,AInpNum,ANameInp,AValInp,&ByPasQCount, &BypCnObj));
							 printf("\nObjects for Query SYSCD=STOPREL %d", ByPasQCount);fflush(stdout);

							if(ByPasQCount >0)
							{
								if(AOM_ask_value_string(secondary_object,"t5_ProjectCode",&projcode)==ITK_ok)
								printf("\nsecondary_object ProjCode [%s]",projcode);fflush(stdout);

								if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
								printf("\nBypass Project Codes List [%s]",info1); fflush(stdout);
								if(tc_strstr(info1,projcode)!=NULL)
								{
									printf("\nAPC Project Codes Parts cannot be Released\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_warning,ITK_err,"APC Group ProjectCode Parts cannot be Released; Parts will reside in WIP Vault only");
									return ITK_err;
								}
							}
						}

						 CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						 printf("\n primary taskTempLT is .. Add Part: %s\n",taskTempLT);fflush(stdout);

						 if (tc_strstr(taskTempLT,"Run BOM completeness check")!=NULL)
						 {
							printf("\n Inside  %s\n",taskTempLT);fflush(stdout);
							char *last = strrchr(taskTempLT, ',');
							if (last != NULL)
							{
								printf("Last token: '%s'\n", last+1);fflush(stdout);
								if (tc_strstr(last+1,"Run BOM completeness check")!=NULL)
								{
									BomCompleteAddPartFlag=1;
								}
								else
								{
									BomCompleteAddPartFlag=0;
								}
							}

						 }
						  printf("BomCompleteAddPartFlag : '%d \n", BomCompleteAddPartFlag);fflush(stdout);
						  if(tc_strcmp(taskTempLT,"Add solution items")==0 || BomCompleteAddPartFlag==1)
						  {
							    CALLAPI(AOM_UIF_ask_value(primary_object,"analyst_user_id",&TaskAnlyst));
								//CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));

								printf("\n TaskAnlyst [%s] ",TaskAnlyst);fflush(stdout);

								if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
								{
									if(tc_strcmp(username,TaskAnlyst) !=0)
										{
											printf("\n Inside loop 'Add solution items'.....\n"); fflush(stdout);

											EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not Task Analyst..Only Analyst Can Add Part To DML Task.Task Analyst Is:",TaskAnlyst);

											return ITK_err;
										}
									else
										{
											printf("\n Session user is Analyst   ...:%s\n",TaskAnlyst); fflush(stdout);
										}
								}
								else
								{

									printf("\n bypass for infodba & loader   ...\n"); fflush(stdout);

								}
						  }else
						  {
							EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of Add Solution Items","You cannot add parts to SolutionItem of the task.");
							return ITK_err;
						  }

						//Added By Rajendra-End

						int TskCnt=0;
						tag_t *TskSO=NULLTAG;
						CALLAPI( GRM_list_primary_objects_only(secondary_object,relation_type,&TskCnt,&TskSO));
						printf("\n Task Count :-------------------->>>>  %d\n",TskCnt);fflush(stdout);

						if (TskCnt > 0)
						{
								TskSOTag = TskSO[0];
								printf("\n TskSOTag---------------> \n"); fflush(stdout);

								if( AOM_ask_value_string(TskSOTag,"item_revision_id",&selectedDMLname)==ITK_ok)
								printf("\n selected Task name---------------> %s\n",selectedDMLname); fflush(stdout);


								EMH_store_error_s2(EMH_severity_error,ITK_errStore1,"Design Revison is already attached to other task :: ",selectedDMLname);
								return ITK_errStore1;
						}

						if( AOM_ask_value_string(secondary_object,"object_string",&selectedname)==ITK_ok)
						printf("\n selected revision---------------> %s\n",selectedname);fflush(stdout);


						//CALLAPI(ITEM_rev_sequence_is_latest(secondary_object,&is_Design));
						//printf("\n\t select Design revision status---------> : %d\n",is_Design);fflush(stdout);

						CALLAPI(ITEM_ask_item_of_rev(secondary_object, &Itemtag));
						printf("\n ITEM_Found......");fflush(stdout);

						CALLAPI(ITEM_ask_latest_rev(Itemtag,&latestrev));

						if (latestrev!=NULLTAG)
						{
							if( AOM_ask_value_string(latestrev,"object_string",&curentname)==ITK_ok)
							printf("\n latest revision---------------> %s\n",curentname);fflush(stdout);
						}

						if(tc_strcmp(curentname,selectedname)!=0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach Latest Modules/Parts to the task.");
							return ITK_err;
						}

						CALLAPI(AOM_ask_value_string(latestrev,"t5_PartType",&RevpartType));
						printf("\n\n\t\t partType of droped object is :%s\n",RevpartType);fflush(stdout);   //M
						//1.38:start
						if (latestrev!=NULLTAG)
						{
							if( AOM_ask_value_string(latestrev,"item_id",&Prt_No)==ITK_ok)
							printf("\n latest Prt_No:[%s]",Prt_No);fflush(stdout);

							//1.38:DFM-A module should for DFMR dml only.
							printf(" partType:[%s] and DML type:[%s]\n",RevpartType,DMLtype);fflush(stdout); 
							//Below DFMR DML validation reverted in sept 2018.
							if ((tc_strcmp(RevpartType,"M")==0)&&(strlen(Prt_No) ==14))
							{
								//get the Module type t5_ModuleType	....																					
								if(AOM_ask_value_string(latestrev,"t5_ModuleType",&Modltyp)!=ITK_ok)PrintErrorStack();
								printf("\n MT:PP:Modltyp:%s ...",Modltyp);	fflush(stdout);

								if((tc_strcmp(DMLtype,"DFMR") ==0) && (tc_strcmp(Modltyp,"DFM-A")!=0))
								{
									printf("\n MR:ERROR:1.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DFM-A Module only can be attached to DFM-A Module Release DML.\n Platform/Project module should be attach to module release DML.");
									return ITK_err;
								}
								//1.38:Regular module should for MR dml only.
								/*if((tc_strcmp(DMLtype,"MR") ==0)&& (tc_strcmp(Modltyp,"DFM-A")==0))
								{
									printf("\n MR:ERROR:2.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DFM-A Module can be attached only to DFM-A Module Release DML.");
									return ITK_err;
								}*/
							}
						}
						//1.38:End

						//DR Validations 1.30-Mohan
						CALLAPI(POM_get_user_id (&SesUsr));
						printf("\n DRCHK: Session user: %s\n",SesUsr); fflush(stdout);
						if(tc_strcmp(SesUsr,"infodba") !=0 && tc_strcmp(SesUsr,"loader") !=0)
						{
							printf("\n DRCHK:1.30: DR VALIDATION LIVE FOR PART TO TASK ATTACHMENT...\n"); fflush(stdout);
							if((tc_strcmp(DMLtype,"TPL")==0) || (tc_strcmp(DMLtype,"DFMR")==0)|| (tc_strcmp(DMLtype,"MR")==0)|| (tc_strcmp(DMLtype,"Veh")==0)|| (tc_strcmp(DMLtype,"PR")==0)|| (tc_strcmp(DMLtype,"CQ")==0) ||
								(tc_strcmp(DMLtype,"ECU")==0)|| (tc_strcmp(DMLtype,"WTR")==0)|| (tc_strcmp(DMLtype,"PPR")==0)|| (tc_strcmp(DMLtype,"BEC")==0))
							{
								CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DmlDR));
								CALLAPI(AOM_ask_value_string(latestrev,"t5_PartType",&PrtType));
								CALLAPI(AOM_ask_value_string(latestrev,"t5_PartStatus",&PrtDR));
								CALLAPI(AOM_ask_value_string(latestrev,"t5_ColourInd",&PrtColInd));
								printf("\n DRCHK: DmlDR:[%s] PrtDR:[%s] PrtType:[%s]",DmlDR,PrtDR,PrtType);fflush(stdout);
								CALLAPI(POM_class_of_instance(latestrev,&PrtCls));
								CALLAPI(POM_name_of_class(PrtCls,&PrtClass));
								printf("\n DRCHK:PrtClass :%s",class_name1); fflush(stdout);
								if(((tc_strcmp(PrtType,"V")==0) || (tc_strcmp(PrtType,"VCCR")==0)|| (tc_strcmp(PrtType,"A")==0) || (tc_strcmp(PrtType,"T")==0) || (tc_strcmp(PrtType,"C")==0) ||
									(tc_strcmp(PrtType,"M")==0)||(tc_strcmp(PrtType,"G")==0)) && ((tc_strcmp(PrtColInd,"Y")==0) || (tc_strcmp(PrtColInd,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
								{
									if(tc_strcmp(DmlDR,"")==0)
									{
										printf("\n DRCHK:ERROR:1.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NULL. Please update valid DR/AR-status.");
										return ITK_err;
									}
									if(tc_strcmp(PrtDR,"")==0)
									{
										printf("\n DRCHK:ERROR:2.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Part DR-status should not be NULL. Please update valid DR/AR-status.");
										return ITK_err;
									}
									if(tc_strcmp(DmlDR,"NA")==0)
									{
										printf("\n DRCHK:ERROR:3.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML DR-status should not be NA. Please update valid DR/AR-status.");
										return ITK_err;
									}

									if(tc_strcmp(PrtDR,"NA")==0)
									{
										printf("\n DRCHK:ERROR:4.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Part DR-status should not be NA. Please update valid DR/AR-status.");
										return ITK_err;
									}
									DMLSubStr=subString(DmlDR, 2, 1);
									PRTSubStr=subString(PrtDR, 2, 1);
									printf("\n DRCHK: DMLSubStr: %s, PRTSubStr: %s",DMLSubStr,PRTSubStr);fflush(stdout);
									DMLSTVAL=atoi(DMLSubStr);
									PRTSTVAL=atoi(PRTSubStr);
									printf("\n DRCHK: DMLDRi: %d, PRTDRi: %d",DMLSTVAL,PRTSTVAL);fflush(stdout);

									if (DMLSTVAL<=3 && PRTSTVAL>=4)
									{
										printf("\n DRCHK:ERROR:6.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Part with DR/AR-status AR4/AR5/DR4/DR5 can not be attached to Dml with AR3/DR3 status or less.");
										return ITK_err;
									}
									if (DMLSTVAL>=4 && PRTSTVAL<=3)
									{
										printf("\n DRCHK:ERROR:7.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"If DML with DR/AR-status AR4/DR4, then Part status should be AR4/AR5/DR4/DR5.\n if DML having DR/AR-status AR5/DR5, then Part AR-status should be AR5/DR5.");
										return ITK_err;
									}

									if (PRTSTVAL<DMLSTVAL)
									{
										printf("\n DRCHK:ERROR:5.\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DR/AR-Status of the Part should not be less than DR/AR status of the DML.\n It should be equal or above than dml DR/AR-status.");
										return ITK_err;
									}
								}
							}
						}
						printf("\n MT:1.30: DR VALIDATION END...\n"); fflush(stdout);
						//DR Validations 1.30-Mohan

						printf("\n\t Going To Start Check Structure........\n");fflush(stdout);
						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
						if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_top_line (window, null_tag, latestrev, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

						if(BOM_line_ask_child_lines (top_line, &n, &children1));
						printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

						if(tc_strcmp(RevpartType,"M")==0)
						{
							if(n==0)
							{
								EMH_store_error_s2(EMH_severity_error,ITK_err, curentname, "Module has no structure hence can not be attached to DML");
								return ITK_err;
							}

							CALLAPI(AOM_ask_value_string(latestrev,"item_id",&Part_no));
							printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout); //003906

							CALLAPI(PS_where_used_all(latestrev,1,&n_parents,&levels,&parents));
							printf("\n\t CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1

							if(n_parents>0)
							{
							  for (jd=0;jd<n_parents;jd++ )
							  {
								ArchAssyTag=parents[jd];
								CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));    //003915
								printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

								if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
								if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name));
								printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

								if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
								{
									 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
									 if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
									 if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
									 if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
									 if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									 if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
									 if(top_line!=NULLTAG)
									 {
									    if(BOM_line_ask_child_lines(top_line, &n, &children1));
									    printf("\n\t No of child objects are n : %d",n);fflush(stdout);
										if (n >0)
										{
										  for (p1=0;p1<n ;p1++ )
										  {
											if(Childobject) Childobject=NULLTAG;
											Childobject=children1[p1];
											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

											if(tc_strcmp(Part_no,child_item_id)==0)
											{
											   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
											   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

											   CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
												CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
												printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

												CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
												}

												CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);


													if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
													{
														printf("\n CC available Variant formula not available \n"); fflush(stdout);
														EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
														return ITK_err;
													}
													else
													{
													  for (j=0;j<resultCount;j++ )
													  {
														 Optfmly_tag = rev[j];
														 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
														 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

														 if(ContextobjName)
														 {
															printf("\n\t child_bl_formula value:%s",child_bl_formula);
															printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);

															if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
															{
																printf("\n inside iff \n"); fflush(stdout);
																dmlIncnt++;
															}
															else
															 {
																printf("\n inside else \n"); fflush(stdout);
																CmpleteVrf++;
															 }
														 }
													  }

													  printf("\n dmlIncnt value is at end for loop :%d\n",dmlIncnt); fflush(stdout);
													  if (dmlIncnt>0)
													  {
														  printf("\n dmlIncnt greator than 1 :%d\n",dmlIncnt); fflush(stdout);
														  EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",child_item_id);
														  return ITK_err;
													  }

													  /*
													  if (CmpleteVrf>0)
													  {
														  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
														  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
														  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
														  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
														  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
														  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

														  if(top_line!=NULLTAG)
														  {
															if(BOM_line_ask_child_lines (top_line, &n, &children1));
															printf("\n\t No of child objects are n : %d",n);fflush(stdout);

															if (n >0)
															{
															  for (p1=0;p1<n ;p1++ )
															  {
																if(Childobject) Childobject=NULLTAG;
																Childobject=children1[p1];
																CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
																printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

															    if(tc_strcmp(Part_no,child_item_id)!=0)
																{
																	CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &Rechk_bl_formula ));
																    printf("\n\t Rechk_bl_formula--------------> %s\n",Rechk_bl_formula); fflush(stdout);

																    if(tc_strcmp(child_bl_formula,Rechk_bl_formula)==0)
																    {
																	   EMH_store_error_s4(EMH_severity_error,ITK_err, "Same variant formula is already available for Modules ",Part_no, " and ",child_item_id);
																	   return ITK_err;
																    }
																}
															  }
															}
														  }
													   }*/
													}
												}
											}
										  }
										}
									 }
								}
							  }
							}
							else //SKS Start
							{
									EMH_store_error_s2(EMH_severity_error,ITK_err, curentname, "Module not attached to any architecture node.");
									return ITK_err;
							} //SKS END
					    }

						if( AOM_ask_value_string(secondary_object,"t5_DrawingInd",&sDrwInd)==ITK_ok)
						printf("\nsDrwInd Value :-------------------->>>> Rajendra   %s\n",sDrwInd);fflush(stdout);

						CALLAPI(GRM_find_relation_type("IMAN_specification", &SpecRel_tag));

						if(SpecRel_tag)
						{
							asmFlag=0;	//Added by rrr in TZ 1.35
							sflag=0;	//Added by rrr in TZ 1.35

							CALLAPI(GRM_list_secondary_objects_only(secondary_object,SpecRel_tag,&Speccount,&SpecDoc_tag));
							printf("\n Speccount Value :-------------------->>>> Rajendra   %d\n",Speccount);fflush(stdout);

							for (is=0;is<Speccount;is++ )
							{
								SecObjDSTag = SpecDoc_tag[is];

								if(TCTYPE_ask_object_type(SecObjDSTag,&SpecTypeTag));
								if(TCTYPE_ask_name(SpecTypeTag,Spectype_name));
								printf("\n     T5TaskToPartCreateVal RefDoc_tag  Spectype_name :: %s\n", Spectype_name);fflush(stdout);

								if(!strcmp(Spectype_name,"ProDrw"))
								{
									if( AOM_ask_value_string(SecObjDSTag,"current_desc",&sSpCurDes)==ITK_ok)
									printf("\nsCurDes Value :-------------------->>>> Rajendra   %s",sSpCurDes);fflush(stdout);
									printf("\n ProDrw ");fflush(stdout);
									intDrgCnt++;
									//sflag=1;	//Modified by rrr in TZ 1.35
									sflag++;
									//break;	//Modified by rrr in TZ 1.35
								}
								else if(!strcmp(Spectype_name,"CMI2Drawing"))
								{
									if( AOM_ask_value_string(SecObjDSTag,"current_desc",&sSpCurDes)==ITK_ok)
									printf("\nsCurDes Value :-------------------->>>> Rajendra   %s",sSpCurDes);fflush(stdout);
									printf("\n CMI2Drawing");fflush(stdout);
									intDrgCnt++;
									//sflag=1;	//Modified by rrr in TZ 1.35
									sflag++;
									//break;	//Modified by rrr in TZ 1.35
								}
								else if(tc_strcmp(Spectype_name,"ProAsm")==0)	//Added by rrr in TZ 1.35
								{
									printf("\n ProAsm Dataset found.");fflush(stdout);
									
									asmFlag++;
								
									result2 = GRM_find_relation_type("Pro2_membership", &ProRelation_type);
									printf("\n rrr..GRM_find_relation_type Pro2_membership ----> %d",result2);fflush(stdout);

									if( GRM_list_secondary_objects_only(SecObjDSTag, ProRelation_type, &n_attch_asm ,&ProAsmMemberstag)==ITK_ok)
									printf("\n ProAsmMem from ProAsm dataset:: %d\n",n_attch_asm);fflush(stdout);
								}
							}

							if(sflag > 0)
							{
								if(strcmp(sSpCurDes,"")==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Drwaing Desc is NULL");
									return ITK_errStore1;
								}
							}

							printf("\n asmFlag:: %d  n_attch_asm:: %d",asmFlag,n_attch_asm);fflush(stdout);
							if((asmFlag > 0) && (n_attch_asm > 0))	//Added by rrr in TZ 1.35
							{
								if (qryTag)
								{
									printf("\n Found Query ControlObjects \n");fflush(stdout);
									qry_values2[0] = "ERCVali";
									if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
									printf(" \n ERCVali:rsltCount :%d:", rsltCount); fflush(stdout);
									if(rsltCount > 0)
									{
										if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo4",&info4r)!=ITK_ok)   PrintErrorStack();
										printf("\n info4r is = [%s]\n", info4r);fflush(stdout);
										if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo1",&info1r)!=ITK_ok)   PrintErrorStack();
										printf("   info1r is = [%s]\n", info1r);fflush(stdout);
									}
								}
								if (tc_strcmp(info4r,"ON")==0)
								{
								int status_count = 0 , rs=0 , i1=0 , TskHSIcount = 0 , ci = 0 , PartAttachtoDmlFlag = 0;
								char* ErcReviewChildList = NULL ;
								char* tsk_object_name = NULL ;
								char* TskSolutnItem = NULL ;
								char* ProProjectId = NULL ;
								tag_t owning_user = NULLTAG;
								tag_t* status_list = NULLTAG;
								tag_t tsk_HSI_rel_type = NULLTAG;
								tag_t *TskHSItems = NULLTAG;
								tag_t Child_owning_user = NULLTAG;
								char childPartOwner[SA_user_size_c+1];
								int RlzRevFlag=0;

								ErcReviewChildList = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
								tc_strcpy ( ErcReviewChildList, "\nList of child parts ,used under assembly CAD Pro-membership relation, are in 'ERC Review', but these are not attched to same DML for release.:\n");

								printf("\n\t\t DML Revision from Task : %d",count);fflush(stdout);

								CALLAPI(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks));
								printf("\n Now tskcnt : %d\n",tskcnt);fflush(stdout);

								CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &tsk_HSI_rel_type));

								for (ip = 0; ip < n_attch_asm; ip++)
								{
									//if( AOM_ask_value_string(ProAsmMemberstag[ip],"object_name",&ProObjName)==ITK_ok)
									if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_id",&ProObjName)==ITK_ok)
									if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_revision_id",&ProObjId)==ITK_ok)
									printf("\nProObjName, Id, ReleaseStatus, Owner: %s, %s , ",ProObjName,ProObjId); fflush(stdout);

									if( AOM_ask_value_string(ProAsmMemberstag[ip],"t5_ProjectCode",&ProProjectId)==ITK_ok)
									printf(" ProProjectId: [%s] ",ProProjectId); fflush(stdout);

									if ((tc_strstr(info1r,ProProjectId)==NULL) && (tc_strcmp(info1r,"")!=0))
									{
										printf("\nSkipping Carry-over Project Part from check.....%s , %s , %s\n",ProObjName,ProObjId,ProProjectId); fflush(stdout);
									}
									else
									{
										if( AOM_ask_owner( ProAsmMemberstag[ip], &Child_owning_user )==ITK_ok)
										if( SA_ask_user_identifier(Child_owning_user,childPartOwner)==ITK_ok)
										printf("  ProObjName: %s   childPartOwner: [%s] ",ProObjName,childPartOwner); fflush(stdout);

										if (tc_strcmp(childPartOwner,"loader")==0)
										{
											printf("\t Skipping loader Part from check.....%s , %s\n",ProObjName,ProObjId); fflush(stdout);
										}
										else
										{
											if (WSOM_ask_release_status_list(ProAsmMemberstag[ip],&status_count,&status_list)==ITK_ok)
											printf("  status_count: %d ", status_count);fflush(stdout);
											RlzRevFlag=0;
											for (rs = 0; rs < status_count; rs++)
											{
												if (AOM_ask_name(status_list[rs], &ProObjRelSt)==ITK_ok)
												printf("\t :%s ", ProObjRelSt);fflush(stdout);
												if ((tc_strcmp(ProObjRelSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ProObjRelSt,"ERC Released")==0) )
												{
													RlzRevFlag=1;
													break;
												}
											}

											printf("  RlzRevFlag: %d ", RlzRevFlag);fflush(stdout);
											if (RlzRevFlag==0)
											{
												PartAttachtoDmlFlag = 0;
												if (tskcnt>0)
												{
													for (i1=0;i1<tskcnt ;i1++ )
													{
														//if(AOM_ask_value_string(Dml_tasks[i1],"object_type",&tsk_object_type)==ITK_ok)
														if(AOM_ask_value_string(Dml_tasks[i1],"object_name",&tsk_object_name)==ITK_ok)
														//printf("\n tsk_object_type is :%s\n",tsk_object_type);fflush(stdout);

														if (tsk_HSI_rel_type!=NULLTAG)
														{
															CALLAPI(GRM_list_secondary_objects_only(Dml_tasks[i1], tsk_HSI_rel_type, &TskHSIcount, &TskHSItems));
															printf("\n\t i1: %d  Task: %s --->> TskHSIcount partcnt:  %d ",i1, tsk_object_name, TskHSIcount);fflush(stdout);

															if (TskHSIcount > 0)
															{
																for (ci = 0; ci < TskHSIcount ; ci ++)
																{
																	if( AOM_ask_value_string(TskHSItems[ci],"object_name",&TskSolutnItem)==ITK_ok)
																	printf("\n\t\t TskSolutnItem:  %s ",TskSolutnItem);fflush(stdout);

																	if (tc_strcmp(ProObjName,TskSolutnItem)==0)
																	{
																		PartAttachtoDmlFlag++;
																	}
																}
															}
														}
													}

													printf("\n\t\t PartAttachtoDmlFlag:  %d ",PartAttachtoDmlFlag);fflush(stdout);
													if (PartAttachtoDmlFlag == 0)
													{
														tc_strcat ( ErcReviewChildList, ProObjName );
														tc_strcat ( ErcReviewChildList, "/" );
														tc_strcat ( ErcReviewChildList, ProObjId );
														tc_strcat ( ErcReviewChildList, ",\n");
														
														ProAsmChildErrorflag=ProAsmChildErrorflag+1;
													}
												}
												else
												{
													tc_strcat ( ErcReviewChildList, ProObjName );
													tc_strcat ( ErcReviewChildList, "/" );
													tc_strcat ( ErcReviewChildList, ProObjId );
													tc_strcat ( ErcReviewChildList, ",\n");
													
													ProAsmChildErrorflag=ProAsmChildErrorflag+1;
												}
											}
										}
									}
								}

								printf("\n ProAsmChildErrorflag: %d ", ProAsmChildErrorflag);fflush(stdout);
								if ( ProAsmChildErrorflag > 0 )
								{
									tc_strcat ( ErcReviewChildList, " \n You cannot attach this assembly to DML task till above pro-assembly child(ERC Review) is not present under same DML or use ERC Released child revision in ProAsm CAD. \n\n Please either use ERC Released child Revision in CAD or attach ERC review child parts to same current DML." );
									tc_strcat ( ErcReviewChildList, " \n If ERC Review child is attached to another DML, Pls contact to DML owner for Release." );

									ErcReviewChildList[strlen(ErcReviewChildList)] = '\0';

									printf("\nList: [%s]",ErcReviewChildList);fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,ErcReviewChildList);

									//MEM_free(ErcReviewChildList);
									return ITK_errStore1;
								}
								}
								printf("\n End of validation CreoAsm. \n");fflush(stdout);
							}
						}

						CALLAPI(GRM_find_relation_type("IMAN_reference", &RefRel_tag));

						if(RefRel_tag)
						{
							CALLAPI(GRM_list_secondary_objects_only(secondary_object,RefRel_tag,&Refcount,&RefDoc_tag));
							printf("\n Refcount Value :-------------------->>>> Rajendra   %d\n",Refcount);fflush(stdout);

								for (jr=0;jr<Refcount;jr++ )
								{
									if(TCTYPE_ask_object_type(RefDoc_tag[jr],&RefTypeTag));
									if(TCTYPE_ask_name(RefTypeTag,Reftype_name));
									printf("\n     T5TaskToPartCreateVal RefDoc_tag  Reftype_name :: %s\n", Reftype_name);fflush(stdout);

										if(!strcmp(Reftype_name,"ProDrw"))
										{
											if( AOM_ask_value_string(RefDoc_tag[jr],"current_desc",&sRCurDes)==ITK_ok)
											printf("\nsRCurDes Value :-------------------->>>> Rajendra   %s\n",sRCurDes);fflush(stdout);
											printf("\n REefProDrw \n");fflush(stdout);
											intDrgCnt++;
											rflag=1;
											break;
										}
										else if(!strcmp(Reftype_name,"CMI2Drawing"))
										{
											if( AOM_ask_value_string(RefDoc_tag[jr],"current_desc",&sRCurDes)==ITK_ok)
											printf("\nsRCurDes Value :-------------------->>>> Rajendra   %s\n",sRCurDes);fflush(stdout);
											printf("\n RefCMI2Drawing \n");fflush(stdout);
											intDrgCnt++;
											rflag=1;
											break;
										}
								}

								if(rflag==1)
								{
									if(strcmp(sRCurDes,"")==0)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"RefDrwaing Desc is NULL");
										return ITK_errStore1;
									}
								}

						}

						// check dataset having  current_desc is  null

                        if(((tc_strcmp(sDrwInd,"N")==0)||(tc_strcmp(sDrwInd,"A")==0))&&(intDrgCnt>0))
						{
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1," Part having drawing but DrwInd is not D/S");
						return ITK_errStore1;

						}

                        if(((tc_strcmp(sDrwInd,"D")==0)||(tc_strcmp(sDrwInd,"S")==0))&&(intDrgCnt==0))
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"DrwInd is D/S but part do not have any drawing");
							return ITK_errStore1;
						}


						if(((tc_strcmp(sDrwInd,"D")==0)||(tc_strcmp(sDrwInd,"S")==0))&&(intDrgCnt==2))
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"part having both drwdoc and refdoc attached. ");
							return ITK_errStore1;
						}

						CALLAPI(WSOM_ask_release_status_list(secondary_object,&st_count1,&status_list1));
						printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

						if(st_count1>0)
						{
							for (cnt=0;cnt< st_count1;cnt++ )
							{
								CALLAPI(AOM_ask_name(status_list1[cnt],&WSO_Name));
								printf("\n ppWSO_Name1 is :%s\n",WSO_Name);fflush(stdout);

								if(strcmp(WSO_Name,"T5_LcsReview")!=0 && strcmp(WSO_Name,"ERC Review")!=0)
								{
									printf("\n inside loop........\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"You Can't attach Part with Life Cycle State other than ERC Review to the task.");
									return ITK_err;
								}else
								{
									printf("\n inside else loop........\n");fflush(stdout);

								}
							}
						}

						if( AOM_ask_value_string(secondary_object,"item_id",&item_id_secObj)==ITK_ok)
						printf("\n item_id_secObj : %s\n",item_id_secObj);fflush(stdout);

						if( AOM_ask_value_string(secondary_object,"t5_ProjectCode",&projcode)==ITK_ok)
						printf("\n Projectcode from rightObject : %s\n",projcode);fflush(stdout);

						if( AOM_ask_value_string(primary_object,"item_id",&item_id_priObj)==ITK_ok)
						printf("\n item_id_priObj : %s\n",item_id_priObj);fflush(stdout);

						CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
						if (tsk_dml_rel_type!=NULLTAG)
						{
							CALLAPI(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count2,&DMLRevision2));
							printf("\n\t\t DML Revision from Task : %d",count);fflush(stdout);

							for (j2=0;j2<count2 ;j2++ )
							{
								CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision2[j2],&is_latest));
								printf("\n\t is_latest : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n\t is_latest is not true .....\n");fflush(stdout);
								}else
								{
									DMLRevTag2 = DMLRevision2[j2];

									CALLAPI(POM_class_of_instance(DMLRevTag2,&class_id1));
									CALLAPI(POM_name_of_class(class_id1,&class_name1));
									printf("\n\t class_name found1 :%s",class_name1);

									if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
									{
										CALLAPI(AOM_ask_value_string(DMLRevTag2,"t5_rlstype",&DMLtype));
										printf("\n\t DMLtype is :%s",DMLtype);fflush(stdout);

										CALLAPI(AOM_UIF_ask_value(DMLRevTag2,"t5_cprojectcode",&projectname));
										printf("\n Projectname from leftObject : %s\n",projectname);fflush(stdout);

										//if(tc_strcmp(projcode,projectname)!=0 && !tc_strcmp(DMLtype,"TPL"))
										if(tc_strcmp(projcode,projectname)!=0)
										{
											printf("\n\t Inside if.....loop..........");fflush(stdout);
										//	EMH_store_error_s5(EMH_severity_warning,ITK_err,"The project code of part is ",projcode," and that of task is ",projectname, "To ensure smooth operation at APL it's preferred to attach a part with same project's task.");
										//	return ITK_err;
										}
									}

									CALLAPI(AOM_ask_value_tags(DMLRevTag2,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks));
									printf("\n Now tskcnt : %d\n",tskcnt);fflush(stdout);

									if (tskcnt>0)
									{
										for (i=0;i<tskcnt ;i++ )
										{
											   AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type);
											   printf("\n tsk_object_type is :%s\n",tsk_object_type);fflush(stdout);
										}
									}
								}
							}
						}
					}
					else
					{
						if(strcmp(relation_name,"HasParticipant")!=0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You Can not attach objects other than Design Revision to Tasks.. Pls check");
							return ITK_err;
						}
					}
				}else if (tc_strcmp(relation_name,"CMReferences")==0)
				{
					printf("\n CMReferences relation found \n");fflush(stdout);

					if(tc_strcmp(type_name2,"VariantRule")==0)
					{
						printf("\n SVR CMReferences relation found \n");fflush(stdout);
						char   type_name3[TCTYPE_name_size_c+1];
						tag_t  primaryObj	= NULLTAG;
						tag_t  *primary_objects1	= NULLTAG;
						int countDep=0,pObjCnt=0,InCmpltcnt=0,resultCount=0,Optcnt=0;
						tag_t  objTypeTagDi	= NULLTAG;
						tag_t  Optfmly_tag	= NULLTAG;
						char *Context_VariantRule=NULL;
						char *SmVCContext=NULL;
						char *SmCrIDContext=NULL;
						tag_t	queryTag	= NULLTAG;
						char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
						char *qry_entries[1] = {"ID"};
						char *OptfmlyStr = NULL;
						tag_t *Optfmly_Set=NULLTAG;



						GRM_list_primary_objects_only(secondary_object,NULLTAG,&countDep,&primary_objects1);
						printf("count found %d ",countDep);fflush(stdout);
						for (pObjCnt=0;pObjCnt<countDep;pObjCnt++)
						{

							primaryObj=primary_objects1[pObjCnt];
							TCTYPE_ask_object_type(primaryObj,&objTypeTagDi);
							TCTYPE_ask_name(objTypeTagDi,type_name3);
							printf( "\n type_name3 :%s ..\n",type_name3);
							if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
							{
								InCmpltcnt=0;
								AOM_ask_value_string(secondary_object,"cfg0VariantRuleText",&Context_VariantRule);
								printf("\n SCR VariantRule is  :: %s\n",Context_VariantRule);




								CALLAPI(AOM_ask_value_string(primaryObj,"object_string",&SmVCContext));
								printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

								CALLAPI(AOM_ask_value_string(primaryObj,"current_id",&SmCrIDContext));
								printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

								if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
								printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
								if (queryTag)
								{
								printf("\n\tFound Query");fflush(stdout);
								}else
								{
								printf("\n\tNot Found Query");fflush(stdout);
								}

								qry_values[0] = SmCrIDContext;

								if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &Optfmly_Set));
								printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

								if(tc_strcmp(Context_VariantRule,"")==0 && resultCount >0)
								{
									printf("\n CC available Variant formula not available \n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR cannot be attached to task as SVR is empty. Kindly select option value for each option family in SVR");
									return ITK_err;
								}
								else
								{
									for (Optcnt=0;Optcnt<resultCount;Optcnt++ )
									{
										Optfmly_tag = Optfmly_Set[Optcnt];
										CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyStr));
										printf("\n\t OptfmlyStr is :%s",OptfmlyStr); fflush(stdout);   //Drive, Fuel is a Name if Option family

										if(OptfmlyStr)
										{
											//printf("\n\t Context_VariantRule value:%s",Context_VariantRule);
											//printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(Context_VariantRule,ContextobjName)); fflush(stdout);

											if(tc_strstr(Context_VariantRule,OptfmlyStr)==NULL)
											{
												printf("\n inside not match condition of SVR \n"); fflush(stdout);
												InCmpltcnt++;
												break;
											}
										}
									}
									if (InCmpltcnt > 0)
									{
										printf("\n CC available Variant formula not available \n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR cannot be attached to task.Kindly please select option value for each option family");
										return ITK_err;
									}

								}
							}
						}

					}
					if(tc_strcmp(type_name2,"VariantRule")!=0  && tc_strcmp(type_name2,"T5_PlatformRevision")!=0)
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You have not attached the part to SolutionItems. This will not be considered for release");
						return ITK_err;
					}
					else
					{
						CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						printf("\n primary taskTempLT is .. Add SVR: %s\n",taskTempLT);fflush(stdout);

						if(tc_strcmp(taskTempLT,"Add Reference Item")==0 || tc_strcmp(taskTempLT,"Add Platform and SVR")==0)
						{
						}
						else
						{
							EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of 'Add Reference Items' or 'Add Platform and SVR'","You cannot add SVR/Platform to ReferenceItem of the task.");
							return ITK_err;
						}
					}
				}
				else
				{
					printf("\n MT: Inside %s relation and droping type is %s.\n",relation_name,type_name2);fflush(stdout);
					if(strcmp(relation_name,"HasParticipant")!=0)
					{
						if(strcmp(relation_name,"IMAN_reference")==0)
						{
							//In reference relation other than Design revision allowed to attach from 2 july 2018.
							if(tc_strcmp(type_name2,"Design Revision")==0 || tc_strcmp(type_name2,"ItemRevision")==0)
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You have not attached the part to SolutionItems. This will not be considered for release");
								return ITK_err;
							}
						}
						else
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You have not attached the part to SolutionItems. This will not be considered for release");
							return ITK_err;
						}
					}
				}
			//}
		}
		else
			{
				printf("\n Secondary object not found \n");fflush(stdout);
			}
	}
	}
	}
	}
	}
	else if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		printf("\n DML:Inside ChangeRequestRevision..... \n");fflush(stdout);
		CALLAPI(POM_get_user_id (&username));
		printf("\n DML:Session login User2 for MR : %s\n",username); fflush(stdout);

		if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
		{
			if(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
			if(TCTYPE_ask_name(objTypeTag2,type_name2));
			printf("\n DML: secondary_object  type_name2 :: %s\n", type_name2);fflush(stdout);
			printf("\n DML: Working for ChangeRequestRevision\n");fflush(stdout);
			CALLAPI(AOM_ask_value_string(primary_object,"t5_rlstype",&DMLRelType));
			CALLAPI(AOM_UIF_ask_value(primary_object,"t5_cprojectcode",&projChar));
			CALLAPI(AOM_UIF_ask_value(primary_object,"t5_crdesigngroup",&DesgChar));
			CALLAPI(AOM_UIF_ask_value(primary_object,"release_status_list",&LcStus));
			printf("\n DML: Project:[%s] DesgChar:[%s] LcStus:[%s] DMLRelType:[%s]\n",projChar,DesgChar,LcStus,DMLRelType);fflush(stdout);
			//CALLAPI(PROJ_find(projChar,&projTag));
			if(relation_type != NULLTAG)
			{
				CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			}
			printf("\n DML: New relation_name:%s \n",relation_name);fflush(stdout);
			if(strcmp(relation_name,"HasParticipant")==0)
			{
				if((strcmp(LcStus,"ERC Released")==0)||(strcmp(LcStus,"T5_LcsErcRlzd")==0))
				{
					printf("\n DML: DML is released, not allowing to update participants! \n");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DML is ERC Released, not allowed to update participants.");
					return ITK_err;
				}
				else
				{
					printf("\n DML:Checking for Analyst: Relation Name:[%s] pri_object:[%s].\n",relation_name,type_name);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeUser",&AnaAssignee));
					CALLAPI(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					printf("\n DML: AnaAssignee: %s	 \n", AnaAssignee);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(secondary_object,"fnd0AssigneeGroup",&AssigneeGrp));
					printf("\n DML: AssigneeGrp:: %s \n", AssigneeGrp);fflush(stdout);
					printf("\n DML: Assignee: %s \n",Assignee);fflush(stdout);

					//third logic
					if(strcmp(type_name2,"Analyst")==0)
					{
						printf("\n DML: No need to set Analyst!!!!!!!!!!!!! \n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select Analyst for task, not for DML.");
						return ITK_err;
					}
					else if(strcmp(type_name2,"T5_BOMAnalyst")==0)
					{
						printf("\n DML: Check access for BOM Analyst \n");fflush(stdout);
					}
					else if(strcmp(type_name2,"T5_CEReviewer")==0)
					{
						printf("\n DML: Check access for CE Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_VIReviewer")==0)
					{
						printf("\n DML: Check access for CE Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_PPReviewer")==0)
					{
						printf("\n DML: Check access for PP Reviewer \n");fflush(stdout);
					}
					else if (strcmp(type_name2,"T5_DMUReviewer")==0)
					{
						printf("\n DML:Veh and PRD DMls: Check access for DMU Reviewer \n");fflush(stdout);
						if(tc_strcmp(DMLRelType,"Veh")==0)
						{
							PRDFlag=1;
							printf("\n MT:.It is Veh DML: %d",PRDFlag); fflush(stdout);
						}
						else
						{
							printf("\n MT:.It is n otVeh DML:%s",projChar); fflush(stdout);
							if(projChar)
							{
								if(QRY_find("Qury_Project", &query_t));
								printf("\n MT:After QRY_find");fflush(stdout);
								if (query_t)
								{
									printf("\n MT:Found Qry.");fflush(stdout);
								}
								else
								{
									printf("\n MT:Not Found Qry.");fflush(stdout);
								}

								qry_val[0] = projChar;

								if(QRY_execute(query_t, n_ent, qry_ent, qry_val, &rsltCnt, &t5_Project));
								printf("\n MT: rsltCnt : %d\n", rsltCnt); fflush(stdout);

								if(rsltCnt > 0)
								{
									printf("\n MT:t5_Project = [%s] found in DB\n",projChar);fflush(stdout);
									Project_t = t5_Project[0];
									if (Project_t!=NULLTAG)
									{
										if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
										printf("\n MT:-ProjectClass:[%s]\n",ProjectClass);   fflush(stdout);

										if(tc_strcmp(ProjectClass,"PRD")==0)
										{
											//Query control table for PRDtoCVBU workflow project list.
											printf("\n MT:.Checking PRDtoCVBU WF project.\n"); fflush(stdout);
											if(QRY_find("ControlObjects", &qry_t));
											if (qry_t)
											{
												printf("\n PRDCVBU:.Found Query ControlObjects \n");fflush(stdout);
											}
											else
											{
												printf("\n PRDCVBU:.Not Found Query ControlObjects \n");fflush(stdout);
											}

											qry_val2[0] = "PRDCVBU";
											if(QRY_execute(qry_t, n_entr, qry_entr, qry_val2, &rsltCunt, &CntrlObjTag));
											printf(" \n PRDCVBU:rsltCunt :%d:", rsltCunt); fflush(stdout);
											if(rsltCunt > 0)
											{
												if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
												printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
												if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
												printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
												if((tc_strstr(info1,projChar)!=NULL) || (tc_strstr(info2,projChar)!=NULL))
												{
													PRDFlag=0;
													printf("\n MT:.PRD proj of CVBU found: %d.",PRDFlag); fflush(stdout);
												}
												else
												{
													PRDFlag=1;
													printf("\n MT:.No proj CVBU found: %d.",PRDFlag); fflush(stdout);
												}
											}
											else
											{
												PRDFlag=1;
												printf("\n MT:.No proj PRDCVBU found: %d.",PRDFlag); fflush(stdout);
											}
										}
										else
										{
											PRDFlag=0;
											printf("\n MT:.No PRD proj:%d.",PRDFlag); fflush(stdout);
										}
									}
								}
							}
						}
						if (PRDFlag>0)
						{
							projTag =NULLTAG;
							//1.32: manager access
							printf("\n DML: Check access for Reviewer \n");fflush(stdout);
							if (PROJ_find(projChar,&projTag) !=ITK_ok)PrintErrorStack();
							if(projTag !=NULLTAG)
							{
								DMUAccesNm=NULL;DMUAccesNm=malloc(50);
								strcpy(DMUAccesNm,"00_Managers/");
								strcat(DMUAccesNm,AnaAssignee);
								printf("\n Role name3 required:[%s]\n", DMUAccesNm);fflush(stdout);
								//DMU reviewer should be from DMU_reviewer group and should have 00_Managers access.
								if(strstr(Assignee,"DMU_Reviewer")!=NULL)
								{
									printf("\n DML: User having access for DMU_Reviewer grp. \n");fflush(stdout);
									//Checking for project base access.
									if(tc_strstr(info4,"ANALYST") == NULL)
									{
										Gmcnt1=0;
										Gmcnt2=0;
										Gmcnt3=0;
										Rolflag=0;
										GmFound1 =NULLTAG;
										GmFound2 =NULLTAG;
										GmFound3 =NULLTAG;
										printf("\n DML:Getting Project Team...\n");fflush(stdout);
										if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
										printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
										for(jkl=0;jkl<Gmcnt1;jkl++)
										{
											ActGmName1=NULL;
											ActGm1 = GmFound1[jkl];
											if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name:[%s]\n", ActGmName1);fflush(stdout);
											if(ActGmName1)
											{
												if (strcmp (ActGmName1,Assignee) == 0)
												{
												   printf("\n DML:DMU access avail...\n");fflush(stdout);
												   Rolflag++;
												}
												if(tc_strstr(ActGmName1,DMUAccesNm)!=NULL)
												{
												   printf("\n DML:00 manager access avail...\n");fflush(stdout);
												   Manflag++;

												}
											}
											if ((Rolflag >0)&&(Manflag >0))
											{
												printf("\n DML:Rolflag:%d, Manflag:%d\n",Rolflag,Manflag);fflush(stdout);
												break;
											}
										}
										if (Rolflag==0)
										{
											printf("\n DML: NOT valid DMU reviewer... \n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU Reviewer should have DMU_Reviewer and 00_manager group access for DML project. Please get access from TCUA Admin.");
											return ITK_err;
										}
										if (Manflag==0)
										{
											printf("\n DML: NOT 00 manager.\n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU Reviewer should have 00_manager group access for DML project. Please get access from TCUA Admin.");
											return ITK_err;
										}
									}
									//Checking for Task analyst and DMU reviewer.
									CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &dml_tsk_rel_type));
									if (dml_tsk_rel_type!=NULLTAG)
									{
										CALLAPI(GRM_list_secondary_objects_only(primary_object,dml_tsk_rel_type,&Tskcount,&TskRevision));
										printf("\n DML: TskRevision Tskcount: %d",Tskcount);fflush(stdout);
										for (tsk=0;tsk<Tskcount ;tsk++ )
										{
											printf("\n DML: Task no : %d ......",tsk);fflush(stdout);
											CALLAPI(ITEM_rev_sequence_is_latest(TskRevision[tsk],&is_Tsklatest));
											printf(" DML: %d\n",is_Tsklatest);fflush(stdout);

											if(is_Tsklatest != true)
											{
												printf("\n DML:is_Tsklatest is not true .....\n");fflush(stdout);
											}
											else
											{
												TskRevTag = TskRevision[tsk];
												CALLAPI(POM_class_of_instance(TskRevTag,&Task_cls));
												CALLAPI(POM_name_of_class(Task_cls,&Task_class));
												printf("\n DML: Task class :%s",Task_class);

												CALLAPI(GRM_find_relation_type("HasParticipant", &tsk_CRB_rel_type));
												if (tsk_CRB_rel_type!=NULLTAG)
												{
													printf("\n DML:TASK:inside HasParticipant.. \n");fflush(stdout);
													CALLAPI(GRM_list_secondary_objects_only(TskRevTag,tsk_CRB_rel_type,&TskCRBcount,&TskCRB));
													printf("\n DML:TASK: TskCRB count: %d",TskCRBcount);fflush(stdout);
													jkk=0;
													for (jkk=0;jkk<TskCRBcount ;jkk++ )
													{
														//printf("\n DML:TASK:jkk: %d.\n",jkk);fflush(stdout);
														TskCRBTag = TskCRB[jkk];
														if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
														if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
														//printf("\n DML:TASK: type_name8 :: %s\n", type_name8);fflush(stdout);
														if (strcmp(type_name8,"Analyst")==0)
														{
															CALLAPI(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskAnlyst));
															CALLAPI(AOM_UIF_ask_value(TskCRBTag,"assignee",&TskAnlystGrp));
															printf("\n DML:TASK: TskAnlyst: %s and AnaAssignee:%s TskAnlystGrp: [%s]",TskAnlyst,AnaAssignee,TskAnlystGrp);fflush(stdout);
															if (TskAnlyst!=NULL)
															{
																if(strcmp(TskAnlyst,AnaAssignee)==0)
																{
																	//printf("\n TASK: ERROR:DMU Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
																	EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer and task analyst should not be same.");
																	return ITK_err;
																}
															}
															break;
														}
													}
												}
											}
										}
									}
								}
								else
								{
									printf("\n DML: User NOT having access for DMU!!!!!!!!!!!!! \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer should have DMU_Reviewer group access. Please select DMU reviewer from 'DMU_Reviewer' group only.");
									return ITK_err;
								}
							}
							else
							{
								printf("\n TASK: Project not found... \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Project not found, please contact to TCUA admin.");
								return ITK_err;
							}
						}
					}
					else if (strcmp(type_name2,"ChangeReviewBoard")==0)
					{
						projTag =NULLTAG;
						//1.32: manager access
						printf("\n DML: Check access for ChangeReviewBoard.. \n");fflush(stdout);
						if (PROJ_find(projChar,&projTag) !=ITK_ok)PrintErrorStack();
						if(projTag !=NULLTAG)
						{
							if(tc_strstr(info4,"ANALYST") == NULL)
							{
								Gmcnt1=0;
								Gmcnt2=0;
								Gmcnt3=0;
								Rolflag=0;
								GmFound1 =NULLTAG;
								GmFound2 =NULLTAG;
								GmFound3 =NULLTAG;
								printf("\n DML:Getting Project Team...\n");fflush(stdout);
								if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
								printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
								for(jkl=0;jkl<Gmcnt1;jkl++)
								{
									ActGmName1=NULL;
									ActGm1 = GmFound1[jkl];
									if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
									//printf("\n Actual Group Member name:[%s]\n", ActGmName1);fflush(stdout);
									if(ActGmName1)
									{
										if (strcmp (ActGmName1,Assignee) == 0)
										{
										   printf("\n DML:Valid DML Reviewer for Analyst: %s\n",ActGmName1);fflush(stdout);
										   Rolflag++;
										   break;
										}
									}
								}
								if (Rolflag==0)
								{
									printf("\n DML: NOT valid DML reviewer... \n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DML Reviewer should have access for DML project and design group. Please get access from TCUA Admin.");
									return ITK_err;
								}
							}
							CALLAPI(AOM_ask_value_strings(primary_object,"t5_crdesigngroup",&num,&DesignGroupList));
							printf("\n DML: num :[%d]", num);fflush(stdout);
							if(num > 0)
							{
								for(ik=0;ik<num;ik++)
								{
									ManAccesNm=NULL;ManAccesNm=malloc(50);
									strcpy(ManAccesNm,DesignGroupList[ik]);
									strcat(ManAccesNm,"_Managers");
									printf("\n DML: %d Role:[%s]\n",ik,ManAccesNm);fflush(stdout);
									if(strstr(Assignee,ManAccesNm)!=NULL)
									{
										MangAccessFlg=1;
										printf("\n DML: User having Manager access. \n");fflush(stdout);
										break;
									}
								}
							}

							if(MangAccessFlg >0)
							{
								printf("\n DML: User having access for ChangeReviewBoard.. \n");fflush(stdout);
								CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &dml_tsk_rel_type));
								if (dml_tsk_rel_type!=NULLTAG)
								{
									CALLAPI(GRM_list_secondary_objects_only(primary_object,dml_tsk_rel_type,&Tskcount,&TskRevision));
									printf("\n DML: TskRevision Tskcount : %d",Tskcount);fflush(stdout);
									for (tsk=0;tsk<Tskcount ;tsk++ )
									{
										DsgnGrp=NULL;
										printf("\n DML:Task num : %d ...",tsk);fflush(stdout);
										CALLAPI(ITEM_rev_sequence_is_latest(TskRevision[tsk],&is_Tsklatest));
										printf(" DML: %d\n",is_Tsklatest);fflush(stdout);

										if(is_Tsklatest != true)
										{
											printf("\n DML:is_Tsklatest is not true .....\n");fflush(stdout);
										}
										else
										{
											TskRevTag = TskRevision[tsk];
											CALLAPI(POM_class_of_instance(TskRevTag,&Task_cls));
											CALLAPI(POM_name_of_class(Task_cls,&Task_class));
											CALLAPI(AOM_UIF_ask_value(TskRevTag,"item_id",&TskNme));
											printf("\n DML: Task :%s class :%s",TskNme,Task_class); fflush(stdout);
											DsgnGrp=subString(TskNme,11,2);
											printf(" ..and Task Grp :%s\n",DsgnGrp);fflush(stdout);
											ManAccesNme=NULL;ManAccesNme=malloc(50);
											strcpy(ManAccesNme,DsgnGrp);
											strcat(ManAccesNme,"_Managers");
											if(strstr(Assignee,ManAccesNme)!=NULL)
											{
												ManagerAccessFlag=1;
												CALLAPI(GRM_find_relation_type("HasParticipant", &tsk_CRB_rel_type));
												if (tsk_CRB_rel_type!=NULLTAG)
												{
													printf("\n DML:TASK:inside HasParticipant..");fflush(stdout);
													CALLAPI(GRM_list_secondary_objects_only(TskRevTag,tsk_CRB_rel_type,&TskCRBcount,&TskCRB));
													printf(" .TskCRB count: %d.\n",TskCRBcount);fflush(stdout);
													jkk=0;
													for (jkk=0;jkk<TskCRBcount ;jkk++ )
													{
														//printf("\n DML:TASK:jkk: %d.\n",jkk);fflush(stdout);
														TskCRBTag = TskCRB[jkk];
														if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
														if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
														//printf("\n DML:TASK: type_name8 :: %s\n", type_name8);fflush(stdout);
														if (strcmp(type_name8,"Analyst")==0)
														{
															CALLAPI(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskAnlyst));
															CALLAPI(AOM_UIF_ask_value(TskCRBTag,"assignee",&TskAnlystGrp));
															printf("\n DML:TASK: TskAnlyst: [%s] TskAnlystGrp:.. [%s] ",TskAnlyst,TskAnlystGrp);fflush(stdout);
															if (TskAnlyst!=NULL)
															{
																if(strcmp(TskAnlyst,AnaAssignee)==0)
																{
																	//printf("\n TASK: ERROR:DML Reviewer and Task Analyst should not be same.!!!!!!!!!!!!! \n");fflush(stdout);
																	EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer (Change Review Board)and task analyst should not be same.");
																	return ITK_err;
																}
															}
															break;
														}
													}
												}
											}
										}
									}
									if (ManagerAccessFlag==0)
									{
										//printf("\n DML: User NOT having access for DML Reviewer. \n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer (Change Review Board) should have manager group access.");
										return ITK_err;
									}
								}
							}
							else
							{
								printf("\n DML: User NOT having access for Reviewer!!!!!!!!!!!!! \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"DML reviewer (Change Review Board) should have manager group access.");
								return ITK_err;
							}
						}
						else
						{
							printf("\n TASK: Project not found... \n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Project not found, please contact to TCUA admin");
							return ITK_err;
						}
					}
					else
					{
						printf("\n DML: User having access for DML project !!!!!!!!!!!!! \n");fflush(stdout);
					}
				}
			}
		}
	}
	if(DMLRevision)
			MEM_free(DMLRevision);

    return error_code;
}

int erc_dml_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l,cnt		=0;
		int  attype = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;

		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;


		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Dml_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;

		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(parent_name,"Work Break Down - CN")!=NULL)
		{
		  if(strstr(CurrentTask,"Add Solution item")!=NULL)
		  {
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			 if(noAttachment > 0)
			 {
			   for(t=0;t<noAttachment;t++)
			   {
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);


				  if(strcmp(object_type,"ChangeNoticeRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));
					printf("\n Dml_no is :%s\n",Dml_no);	fflush(stdout);

					if(Dml_no)
					{
							printf("\n found part \n");fflush(stdout);
							CALLAPI(AOM_UIF_ask_value(attachments[t],"Analyst",&DmlAnalyst_name));
							printf("\n Analyst_name  of DML  is %s\n", DmlAnalyst_name);
					}
				  }

		      }

			 }
			}
	  }
		return ITK_ok;
}

extern EPM_decision_t DLLAPI SignOffCheck_Chk_Validation (EPM_rule_message_t msg)
{
  int count,i,j,r,k,t,l,k1;
  int m,n = 0;
  int jd,hp = 0;
  tag_t *attachments = NULLTAG;
  tag_t *DMLRevision = NULLTAG;
  tag_t  *secondary_objects = NULLTAG;
  char *user_name;
  char *class_name;
  char *class_name1;
  char *proj_value;
  tag_t relation_type;
  tag_t tsk_dml_rel_type;
  int   n_attchs,partcnt = 0;

  tag_t login_user_tag;
  tag_t owner_tag;
  tag_t class_id=NULLTAG;
  tag_t class_id1=NULLTAG;
  tag_t attchments1=NULLTAG;
  tag_t root_task=NULLTAG;
  tag_t *  	rev_tag	;
  int status = ITK_ok;
  char *s;

  tag_t   bom_window=NULLTAG;

  char*	 object_type		= NULL;
  char*	 Object_PartType		= NULL;

  char*	 t5current_name		= NULL;
  char*	 t5current_name1		= NULL;
  char*	 DMLtype		= NULL;
  char*	 Part_no			= NULL;
  char*	 ReChkPart_no			= NULL;

  char*	 Arch_obj			= NULL;
  char*	 Arch_obj_str			= NULL;
  char*	 SmVCContext			= NULL;
  char*	 SmCrIDContext			= NULL;
  char*	 ContextobjName			= NULL;
  char*	 CtxtrimobjName			= NULL;

  char*	 TargetThread			= NULL;
  char*	 ReleaseStatus		= NULL;
  char*	 current_name		= NULL;
  char*	 projectname		= NULL;
  tag_t  	master =	NULLTAG;
  int 	 sequence_id;
  tag_t  *children1=NULLTAG;
  tag_t  *children=NULLTAG;
  logical is_latest;

  char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
  char **values = (char **) MEM_alloc(1 * sizeof(char *));

  tag_t *PartsTag= NULLTAG;
  tag_t AssyTag = NULLTAG;
  tag_t ArchAssyTag = NULLTAG;
  tag_t CtxAssyTag = NULLTAG;
  tag_t objTypeTag=NULLTAG;
  tag_t ArchobjTypeTag=NULLTAG;
  tag_t ctxobjTypeTag=NULLTAG;
  tag_t  relation_dep	= NULLTAG;
  tag_t  relation_Ctx	= NULLTAG;

	int p1,m1 = 0;
	tag_t   Childobject=NULLTAG;
	tag_t   StrChkArchObj=NULLTAG;
	tag_t   Desobject=NULLTAG;
	char *child_item_id=NULL;
	char *StrChk_item_id=NULL;
	char *child_bl_formula=NULL;
	char *Strchk_bl_formula=NULL;
	char *Trim_bl_formula=NULL;

	tag_t ref_instancesTemp = NULLTAG;
    tag_t   window,rule,item_tag = null_tag,top_line,top_line1;

    tag_t DMLLcmTag = NULLTAG;
    tag_t DMLRevTag = NULLTAG;

    char		   *revisionID	=NULL;
    char		   *t5Des_Rev	=NULL;
    char		   *t5rlz_list	=NULL;
    char		   *DMLNumber =NULL;
    char		   *taskGrp	  =NULL;
	char *curentname;

	char*	username				=NULL;
	tag_t  objTypeTagDi1=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;

	int    n_instances	= 0;
	tag_t  *ref_instances	= NULLTAG;
	int	   *instance_levels;
	int	   *instance_where_found;
	int    n_classes		= 0;
	tag_t  *ref_classes		= NULLTAG;
	int    *class_levels;
	int    *class_where_found;
	tag_t	queryTag	= NULLTAG;
	tag_t	queryChkTag	= NULLTAG;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesChk = (char **) MEM_alloc(10 * sizeof(char *));

	int n_entries = 1;
	int n_Chkentries = 2;
	int resultCount=0;
	int ChkCount=0;
	tag_t *rev=NULLTAG;
	tag_t *Chkrev=NULLTAG;
	char *qry_entries[1] = {"ID"};
	//char *qry_entriesChk[1] = {"Name"};
	char *qry_entriesChk[2] = {"Name","Type"};

  	char   type_name[TCTYPE_name_size_c+1];
	char   type_name4[TCTYPE_name_size_c+1];
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char   Archtype_name[TCTYPE_name_size_c+1];
	char   Ctxtype_name[TCTYPE_name_size_c+1];
	char   objecttype[WSO_name_size_c+1];
	int ifail=0;
	int n_parents,n1_parents = 0;
	int cnt = 0;
	int cntFlag = 0;
	int *levels = 0;
	tag_t *parents = NULL;
	tag_t *parents1 = NULL;
	int countDep,countDep1 = 0;
	int countConfigCtx = 0;
	int countCtx =0;
	tag_t  *secondary_objects1	= NULLTAG;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  *secondary_objects2	= NULLTAG;
	tag_t  *CtxSecObject	= NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  objTypeTagDi=NULLTAG;
	char   type_name3[TCTYPE_name_size_c+1];
	char  *Context_Str=NULL;
	char *class_nameCtx=NULL;
	char*	 DMLNo		= NULL;
	tag_t Optfmly_tag = NULLTAG;
    char * ItemPType ;
    char * ItemName1 ;
	char *  HangingPrtErr = NULL;
	char *  SetHangingPrtErr = NULL;

	//sks start
	int PartNoStrucCnt =0;
	int PartStrNoParentCnt =0;
	char PartStrNoStruc[1500];
	char PartStrNoParent[1500];

	char MudleInCmpt[1500];
	char MudleCmpt[1500];
	char MudleDupcpy[1500];
	int Incmptcnt=0;
	int cmptlecnt=0;
	int flagmdl = 0;
	int DupVarFr = 0;
	int Dflag = 0;
	int Nflag = 0;

	char* NoDrawingListD = NULL ;
	char* DrawingListN = NULL ;

	//sks end

    //ref_instancesTemp = malloc( sizeof(1) );
    EPM_decision_t decision = EPM_go;
    char obj_type[WSO_name_size_c+1];


    //rpg start
	NoDrawingListD= (char* ) malloc ( 500 * sizeof ( char ) ) ;
	DrawingListN = (char* ) malloc ( 500 * sizeof ( char ) ) ;

	tc_strcpy ( NoDrawingListD, "Please attach drawing for the parts with Drawing Indicator as D:" );
	tc_strcpy ( DrawingListN, "Drawing indicator 'N' but Drwing Dataset found attached to Design Revisions:" );
	//rpg end

    CALLAPI(POM_get_user_id (&username));
    printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);

    if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
    {
	  CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	  printf("\n\n\t\t Root task found");

	  CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	  printf("\n\n\t\t EPM_ask_attachments of :: %d",count);

	  if(count > 0)
	  {
		DMLLcmTag = attachments[0];
	  }

	  status = AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name);
	  printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

	  if ( status != ITK_ok)
	  {
		 EMH_ask_error_text( status, &s);
		 printf("Error with AOM_ask_value_string : %s \n",s);
		 MEM_free(s);
		 return status;
	  }

	  CALLAPI(POM_class_of_instance(DMLLcmTag,&class_id));
	  CALLAPI(POM_name_of_class(class_id,&class_name));
	  printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);

	  CALLAPI(AOM_refresh( DMLLcmTag, 0 ));

	  if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
	  {
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		{
			tc_strcpy(PartStrNoStruc,""); //sks start end
			tc_strcpy(MudleInCmpt,""); //sks start end
			tc_strcpy(MudleCmpt,""); //sks start end
			tc_strcpy(MudleDupcpy,""); //sks start end

			CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);

			for (j=0;j<count ;j++ )
			{
				CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = DMLRevision[j];

					CALLAPI(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname));
					printf("\n Projectname from leftObject : %s\n",projectname);fflush(stdout);

					printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
					printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

					DMLNumber = strtok( current_name, "_" );
					taskGrp	  = strtok ( NULL, "_" );
					printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);

					CALLAPI(AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id));
					printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

					CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
					CALLAPI(POM_name_of_class(class_id1,&class_name1));
					printf("\n\n\t\t class_name found1 :%s",class_name1);

					CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
					printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

					if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
					{
						if(strcmp(DMLtype,"")==0)
						{
							printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
							decision = EPM_nogo;
							return decision;
						}

						if((strcmp(DMLtype,"TPL")==0)  || (strcmp(DMLtype,"MR")==0) || (strcmp(DMLtype,"DFMR")==0) || (strcmp(DMLtype,"Veh")==0))
						{
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
							if (relation_type!=NULLTAG)
							{
								CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
								printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

								if(n_attchs>0)
								{
									for (l=0;l<n_attchs ;l++ )
									{
									   status = AOM_ask_value_string(secondary_objects[l],"current_id",&t5current_name1);
									   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
									   if ( status != ITK_ok)
									   {
										 EMH_ask_error_text( status, &s);
										 printf("Error with AOM_ask_value_string2 : %s \n",s);
										 MEM_free(s);
										 return status;
									   }

									 //CALLAPI(AOM_refresh( secondary_objects[l], 0 ));
									 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));
									 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

									 if (!SetHangingPrtErr) MEM_free(SetHangingPrtErr);
									 SetHangingPrtErr=(char *)MEM_alloc(10000);

									 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
									 {
										  DMLNo=subString(t5current_name1,0,10);
										  printf("\n\n\t\t DML Number:-------> %s\n", DMLNo); fflush(stdout);

										  if(QRY_find("GetChkLst", &queryChkTag));
										  printf("\n\n\t\tAfter GetChkLst QRY_find------------>");fflush(stdout);
										  if (queryChkTag)
										  {
											printf("\n\n\t\tFound Query-------->");fflush(stdout);
										  }else
										  {
											printf("\n\n\t\tNot Found Query---->");fflush(stdout);
										  }

										  trimLeading(DMLNo);
										  qry_valuesChk[0] = DMLNo;
										  qry_valuesChk[1] = "ERC DML Checklist";
										  if(QRY_execute(queryChkTag, n_Chkentries, qry_entriesChk, qry_valuesChk, &ChkCount, &Chkrev));
										  printf("\n\n\t\tChkCount:-------> %d\n", ChkCount); fflush(stdout);

										  if(ChkCount==0)
										  {
											  EMH_clear_errors();
											  EMH_store_error_s3(EMH_severity_warning,ITK_err, "Please Create Checklist for DML=> ",current_name,"\nHelp: Select DML goto File->New->Change Classes->ERC DML CheckList");
											  decision = EPM_nogo;
											  return decision;
										  }

										  CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag));
										  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

										  if (partcnt>0)
										  {
											for (k=0;k<partcnt ;k++ )
											{
												printf("\n\n\t\t for k =:%d",k);fflush(stdout);
												AssyTag=PartsTag[k];


												CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
												printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
												//WSOM_ask_object_type(primary_objects[i],object_type);


												if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
												if(TCTYPE_ask_name(objTypeTag,type_name));
												printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

												////////////////////////////////Drawing Doc Validation start SKS///////////////////////////
												tag_t primary_DS=NULLTAG;
												tag_t DataSet_TypeTag=NULLTAG;
												tag_t reln_type=NULLTAG;
												GRM_relation_t *rellist;
												char* Object_DrwInd = NULL;
												char   DataSet_type_name[TCTYPE_name_size_c+1];
												int    n_attchs_DS =0,DrwCnt=0,AttchCnt=0;
												logical	checkout= 0;

												CALLAPI(RES_is_checked_out(AssyTag,&checkout));
												printf("\nValue of checkout Attribute : [%d]\n",checkout);fflush(stdout);
												if (checkout==1)
												{
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Check-In all items (which are in  Solution Items) to vault before signoff");
													decision = EPM_nogo;
													return decision;
												}

												CALLAPI(AOM_ask_value_string(AssyTag,"t5_DrawingInd",&Object_DrwInd));
												printf("\n\n\t\t Object_DrwInd is :<%s>\n",Object_DrwInd);fflush(stdout);

												//CALLAPI(GRM_find_relation_type("IMAN_specification",&reln_type));
												printf("\n\n\t\t IMAN_specification.........\n");fflush(stdout);

												CALLAPI(GRM_list_secondary_objects(AssyTag,reln_type,&n_attchs_DS,&rellist));

												printf("\n\n\t\t After GRM_list_secondary_objects count : %d\n",n_attchs_DS);fflush(stdout);

												if(n_attchs_DS>0)
												{
													DrwCnt=0;
													for (AttchCnt= 0; AttchCnt < n_attchs_DS; AttchCnt++)
													{
														primary_DS=rellist[AttchCnt].secondary;

														printf("\n\n\t\t primary_DS........\n");fflush(stdout);

														CALLAPI(TCTYPE_ask_object_type(primary_DS,&DataSet_TypeTag));
														CALLAPI(TCTYPE_ask_name(DataSet_TypeTag,DataSet_type_name));
														printf("\n\n\t\t DataSet_type_name : %s\n",DataSet_type_name);fflush(stdout);

														if(strcmp(DataSet_type_name,"CATDrawing")==0 || strcmp(DataSet_type_name,"CMI2Drawing")==0 || strcmp(DataSet_type_name,"ProDrw")==0)
														{
															DrwCnt++;
															printf("\n\n\t\t DrwCnt ++ : %d\n",DrwCnt);fflush(stdout);
														}
													}
												}

												if(tc_strcmp(Object_DrwInd,"D")==0)
												{
													if (DrwCnt==0)
													{
														//rpg start
														tc_strcat(NoDrawingListD,Part_no);
														tc_strcat(NoDrawingListD,",");
														Dflag = Dflag + 1;
														printf("\n Please attach drawing for the parts with Drawing Indicator as D");fflush(stdout);
												        printf("\n NoDrawingList : %s",Part_no);fflush(stdout);

														//EMH_clear_errors();
														//EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please attach drawing for the parts with Drawing Indicator as D.");
														//decision = EPM_nogo;
														//return decision;
														//rpg end
													}
												}else if (tc_strcmp(Object_DrwInd,"N")==0)
												{
													printf("\n\n\t\t DrwCnt : %d\n",DrwCnt);fflush(stdout);

													if (DrwCnt>0)
													{
														//rpg start
														tc_strcat(DrawingListN,Part_no);
														tc_strcat(DrawingListN,",");
														Nflag = Nflag + 1;
														printf("\n Drawing indicator 'N' but Drwing Dataset found attached to Design Revision");fflush(stdout);
												        printf("\n NoDrawingList : %s",Part_no);fflush(stdout);

														//EMH_clear_errors();
														//EMH_store_error_s1(EMH_severity_warning,ITK_err, "Drawing indicator 'N' but Drwing Dataset found attached to Design Revision");
														//decision = EPM_nogo;
														//return decision;
														//rpg end
													}
												}


												////////////////////////////////Drawing Doc Validation END///////////////////////////

												CALLAPI(AOM_ask_value_string(AssyTag,"object_string",&curentname));
												printf("\n\n\t\t curentname is :%s\n",curentname);fflush(stdout);

												CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&Object_PartType));
												printf("\n\n\t\t Object_PartType is :%s\n",Object_PartType);fflush(stdout);

												if((tc_strcmp(type_name,"Design Revision")==0) )
												{
													printf("\n\t Inside BOM_create........\n");fflush(stdout);
													if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
													if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window, null_tag,AssyTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();

													if(BOM_line_ask_child_lines (top_line, &n, &children1));
													printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

													if((tc_strcmp(Object_PartType,"D")==0))
													{
														/*
														if(n > 0)
														{

															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_err, "DUMMY part in TPL should not have structure");
															decision = EPM_nogo;
															return decision;
														}
														*/
													}
													else
													{
														 if((tc_strcmp(Object_PartType,"M")==0) || (tc_strcmp(Object_PartType,"T")==0)||(tc_strcmp(Object_PartType,"V")==0))
														 {
															if (n==0)
															{
																	//sks start
																	tc_strcat(PartStrNoStruc,Part_no);
																	tc_strcat(PartStrNoStruc,",");
																	PartNoStrucCnt++;
																	printf("\n\n\t\t for other parttypes Part_no : %s\n",Part_no);fflush(stdout);
																	//EMH_clear_errors();
																	//EMH_store_error_s2(EMH_severity_error,ITK_err, "Structure Not present for this part . Pls check .",Part_no);
																	//decision = EPM_nogo;
																	//return decision;

															}
														}
													}

												}

												////////////////////////////////Hanging Parts Validation start hpp///////////////////////////
												ItemPType = NULL;
												ItemName1 = NULL;

												CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&ItemPType));
												printf("\n child ItemPType:%s ..............",ItemPType);fflush(stdout);

												if(tc_strcmp(ItemPType,"V" )==0 || tc_strcmp(ItemPType,"T" )==0 ||  tc_strcmp(ItemPType,"M" )==0 || tc_strcmp(ItemPType,"VC" )==0 || tc_strcmp(ItemPType,"D" )==0 ||  tc_strcmp(ItemPType,"G" )==0)
												{
													printf("\n Part Type is V/T/M/VC/D/G[%s]--->So continue No hanging part check..............",ItemPType);fflush(stdout);
												}else
												{
													printf("\n Part Type is Other than this V/T/M/VC/D/G[%s]--->So continue for hanging part check..............",ItemPType);fflush(stdout);

													printf("\n\t AssyTag exists........\n");fflush(stdout);
													CALLAPI(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
													printf("\n\t where_used count of objects are : %d\n",n_parents); fflush(stdout);

													CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&ItemName1));
													printf("\n child ItemName1:%s ..............",ItemName1);fflush(stdout);

													CALLAPI(AOM_ask_value_string(AssyTag,"item_revision_id",&t5Des_Rev));
													printf("\n\n\t\t t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);

													revisionID = strtok( t5Des_Rev, ";" );
													printf("\n\n\t\t revisionID is :%s",revisionID); fflush(stdout);

													CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&t5rlz_list));
													printf("\n\n\t\t t5rlz_list is :%s",t5rlz_list); fflush(stdout);
													printf("\n\n\t\t DMLtype is :%s",DMLtype); fflush(stdout);

													if (tc_strcmp(HangingPrtErr,"NULL") !=0) MEM_free(HangingPrtErr);
													HangingPrtErr=(char *)MEM_alloc(500);
													tc_strcpy(HangingPrtErr," ");

													if((n_parents==0) && (tc_strcmp(revisionID,"NR")==0) && (tc_strstr(t5rlz_list,"Release")==NULL) && (tc_strcmp(DMLtype,"D")!=0))
													{
														printf("\n\n\t\t Inside Where_used count...............\n"); fflush(stdout);
														if((!tc_strcmp(DMLtype,"ECU") && !tc_strcmp(taskGrp,"16")) || (tc_strcmp(Object_PartType,"DTPL")==0))
														{
															printf("\n ## Hanging parts validation bypassed for LLP release and task 16 of ECU Parts Release.\n");fflush(stdout);
														}else
														{
															printf("\n\n\t\t Inside else loop Where_used.........\n"); fflush(stdout);
															if(cnt==0)
															{
																cnt = 1;
																tc_strcat(HangingPrtErr,"PartNumber[");
																tc_strcat(HangingPrtErr,ItemName1);
																tc_strcat(HangingPrtErr,",");
																tc_strcat(HangingPrtErr,t5Des_Rev);
																tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
																printf("\n ChildRelErr10: %s\n",HangingPrtErr);fflush(stdout);
															}
															else
															{
																tc_strcat(HangingPrtErr,"PartNumber[");
																tc_strcat(HangingPrtErr,ItemName1);
																tc_strcat(HangingPrtErr,",");
																tc_strcat(HangingPrtErr,t5Des_Rev);
																tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
																printf("\n ChildRelErr11: %s\n",HangingPrtErr);fflush(stdout);
																cnt = cnt+1;
																printf("\n ChildRelEr22r: %s\n",HangingPrtErr);fflush(stdout);
															}

															if(cnt==1)
															{
																printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);
																tc_strcpy(SetHangingPrtErr,HangingPrtErr);
																cntFlag = 1;
															}else if(cnt>1)
															{
																printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);
																tc_strcat(SetHangingPrtErr,HangingPrtErr);
																cntFlag = 1;
															}

															if(cntFlag==1)
															{
																printf("\n\n\t\t cnt values is===> %d\n",cnt); fflush(stdout);

																//EMH_clear_errors();
																//EMH_store_error_s2(EMH_severity_error,ITK_Prjerr, "The Parts attached in the resultant are not attached to any assembly.(Hanging Parts) : ",SetHangingPrtErr);
															}
														}
														printf("\n ## Hanging parts validation bypassed for LLP release and task 16 of ECU Parts Release.\n");fflush(stdout);
													}
											  }
											}
										}else
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "There is no Part attached to the Task. Please attach parts to task which you want to release with this dml or remove empty task.");
											decision = EPM_nogo;
											return decision;
										}
									 }
						    }

							 //rpg start
							if ( Dflag > 0 )
								{
									printf("\nNoDrawingListD : %s",NoDrawingListD);fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_warning,ITK_err,NoDrawingListD);
									decision = EPM_nogo;
									return decision;

								}

                            if ( Nflag > 0 )
								{
									   printf("\nDrawingListN : %s",DrawingListN);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_warning,ITK_err,DrawingListN);
										decision = EPM_nogo;
										return decision;

								}

                          //rpg end

					  }
			     }
			  }

			  if((strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"DFMR")==0))
			  {
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
				if (relation_type!=NULLTAG)
				{
				  CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
				  printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
				  tc_strcpy(PartStrNoParent,""); //sks start end
				  if(n_attchs>0)
				  {
				  	for (l=0;l<n_attchs ;l++ )
					{
					   status = AOM_ask_value_string(secondary_objects[l],"current_name",&t5current_name1);
					   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
					   if ( status != ITK_ok)
					   {
						 EMH_ask_error_text( status, &s);
						 printf("Error with AOM_ask_value_string2 : %s \n",s);
						 MEM_free(s);
						 return status;
				 	   }

					   if(strcmp(t5current_name,t5current_name1)==0)
					   {
						 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));       //12PM000003 User:hpp05653
						 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

						 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
						 {
						  CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag));
						  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

						  if (partcnt>0)
						  {
							for (k=0;k<partcnt ;k++ )
							{
							    AssyTag=PartsTag[k];
								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout);		     //003906

								if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
								if(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

								CALLAPI(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
								printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1

								if(n_parents>0)
								{
								  for (jd=0;jd<n_parents;jd++ )
								  {
									ArchAssyTag=parents[jd];
									CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));    //003915
									printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name));
									printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
									  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
									  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
									  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

									  if(top_line!=NULLTAG)
									  {
									    if(BOM_line_ask_child_lines (top_line, &n, &children1));
									    printf("\n\t No of child objects are n : %d",n);fflush(stdout);

										if (n >0)
										{
										  for (p1=0;p1<n ;p1++ )
										  {
											if(Childobject) Childobject=NULLTAG;
											Childobject=children1[p1];
											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

											if(tc_strcmp(Part_no,child_item_id)==0)
											{
											   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
											   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

												CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
												CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
												printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

												CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
												if(relation_dep != NULLTAG)
												{
													printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
												}

												CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
												printf("\n\t Configuration Context count is : %d",countConfigCtx);

												if(countConfigCtx>0)
												{
													  ConfigCtx=ConfigCtxSecObject[0];
													  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
													  CALLAPI(TCTYPE_ask_name(ConfigCtxObjTypeTag,Config_CtxType));
													  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
													  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

													  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
													  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													  if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag));
													  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													  if (queryTag)
													  {
														printf("\n\tFound Query");fflush(stdout);
													  }else
													  {
														printf("\n\tNot Found Query");fflush(stdout);
													  }

													  qry_values[0] = SmCrIDContext;

													  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
													  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);


													if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
													{
														printf("\n CC available Variant formula not available \n"); fflush(stdout);
														EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
														decision = EPM_nogo;
														return decision;
													}
													else
													{
														if(resultCount > 0)
														{
														  for (j=0;j<resultCount;j++ )
														  {
															 Optfmly_tag = rev[j];
															 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
															 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

															 if(ContextobjName)
															 {
																printf("\n\t child_bl_formula value:%s",child_bl_formula);
																printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);

																if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
																{
																	printf("\n inside iff \n"); fflush(stdout);
																	Incmptcnt++;

																	tc_strcat(MudleInCmpt,child_item_id);
																	tc_strcat(MudleInCmpt,",");
																	printf("\n\n\t\t for other parttypes MudleInCmpt : %s = %d\n",MudleInCmpt,Incmptcnt);fflush(stdout);
																}else
																 {
																	printf("\n inside else \n"); fflush(stdout);
																	cmptlecnt++;
																 }
															 }
														  }
														}
													}
												}

												if(cmptlecnt > 0)
												{
													printf("\n\t Main Part => %s with his Complete Variant formula = %s\n",Part_no,child_bl_formula); fflush(stdout);
													if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
													if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();

													if(top_line1!=NULLTAG)
													{
														if(BOM_line_ask_child_lines (top_line1, &n, &children1));
														printf("\n\t No of child objects are n : %d",n);fflush(stdout);

														if (n >0)
														{
														  for (p1=0;p1<n ;p1++ )
														  {
															if(StrChkArchObj) StrChkArchObj=NULLTAG;
															StrChkArchObj=children1[p1];
															CALLAPI(AOM_ask_value_string(StrChkArchObj, "bl_item_item_id", &StrChk_item_id ));

															if(tc_strcmp(Part_no,StrChk_item_id)!=0)
															{
																printf("\n\t StrChk_item_id Object ===> :: %s",StrChk_item_id); fflush(stdout);
																CALLAPI(AOM_ask_value_string(StrChkArchObj, "bl_formula", &Strchk_bl_formula ));
																printf("\n\t Strchk_bl_formula--------------> %s\n",Strchk_bl_formula); fflush(stdout);

																if(tc_strcmp(child_bl_formula,Strchk_bl_formula)==0)
																{
																	printf("\n inside cmptlecnt loop \n"); fflush(stdout);
																	DupVarFr++;

																	tc_strcat(MudleDupcpy,StrChk_item_id);
																	tc_strcat(MudleDupcpy,",");
																	printf("\n\n\t\t for other parttypes MudleDupcpy : %s = %d\n",MudleDupcpy,DupVarFr);fflush(stdout);
																}
															}
														  }
														}
													}
												}
											}
										  }
										}
									}
								}
							}
						}
						else//sks start
						{
							printf("\n\n\t\t Part_no : %s doesnt have any Arch module attached to it\n",Part_no);fflush(stdout);
							tc_strcat(PartStrNoParent,Part_no);
							tc_strcat(PartStrNoParent,",");
							PartStrNoParentCnt++;
						}//sks End

							printf("\n\n\t\t DupVarFr = %d \n",DupVarFr);fflush(stdout);
							if (DupVarFr>0)
							{
								EMH_clear_errors();
								EMH_store_error_s4(EMH_severity_error,ITK_err, "Same variant formula is already available for Modules ",Part_no, " and ",MudleDupcpy);
							    decision = EPM_nogo;
							    return decision;
							}
						}
					  }else
					  {
						  EMH_clear_errors();
						  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "There is no Part attached to the Module Release Task. \nPlease attach parts to Module Release task which you want to release with this dml or remove empty task.");
						  decision = EPM_nogo;
						  return decision;
					  }
					  }
					  }
					}
					}
				}
			  }
			  /*
			  else
			  {
				  EMH_clear_errors();
				  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type is should be of type TPL/Module Release, Plz update release type as TPL/Module Release");
				  decision = EPM_nogo;
			  }
			  */
			//}
		  }else
		  {
			  EMH_clear_errors();
			  EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Select valid ERC DML");
			  decision = EPM_nogo;
			  return decision;
		  }
	   }
	}
	//sks start
	if (PartNoStrucCnt >0)
	{
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err, "Structure is not present for the given list of parts. Please check.",PartStrNoStruc);
		decision = EPM_nogo;
		return decision;
	}
	if (PartStrNoParentCnt >0)
	{
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err, "Following Module or Parts are hanging.These parts should be called under Arch Node or Module or Assembly.Please check.",PartStrNoParent);
		decision = EPM_nogo;
		return decision;
	}
	//sks END

   printf("\n\n\t\t Incmptcnt = %d \n",Incmptcnt);fflush(stdout);
   if (Incmptcnt>0)
   {
	    EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Modules :: ",MudleInCmpt);
		decision = EPM_nogo;
		return decision;
   }

}
}
}
  decision = EPM_go;
  if(children1)
			MEM_free(children1);

  if(DMLRevision)
			MEM_free(DMLRevision);

  if(attachments)
			MEM_free(attachments);


  if(secondary_objects)
			MEM_free(secondary_objects);

  return decision;

 }

extern EPM_decision_t DLLAPI assign_anlst_reviwer(EPM_rule_message_t msg)
{
	int count,i = 0;
	tag_t root_task=NULLTAG;
	EPM_decision_t decision;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t    	    propEff_tag				    =NULLTAG;

	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	user_tag1				=NULLTAG;
	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char  	type_name[TCTYPE_name_size_c+1];
	char*	 DmlRevName		= NULL;
	char*	 AnalystName		= NULL;
	char*	 RequestorName		= NULL;
	char*	 ChangSpName		= NULL;
	char*	 ChangReviewName		= NULL;
	int ifail=0;
	char*	 DsgGrp		= NULL;
	char*	 Tskno		= NULL;
	char*	 DMLno		= NULL;
	char*	 DMLtp		= NULL;
	char*	 ChangReviewName1		= NULL;
	tag_t *TaskCRB = NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;
	tag_t ObjTypDmlCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t dml_Prty_rel_type = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	int j =0;
	int jkk =0;
	int jk =0;
	int Tskcount =0;
	int TskPrtycount =0;
	int Prtycount =0;
	int PTflag =0;
	int EEflag =0;
	int CHflag =0;
	int BIWflag =0;
	int TRIMflag =0;
	int DMUFlag =0;
	int DMUflag =0;
	int Peerflag =0;
	int DsgGrup = 0;
	int VIFlag = 0;
	int BOMFlag = 0;
	char   Tsk_Prty_typ[TCTYPE_name_size_c+1];
	char   Prty_typ[TCTYPE_name_size_c+1];
	logical is_latest;
	//Qry Project
	char	*ProjectID	= NULL;
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	int     rsltCount      =  0;
	int		PRDdmlFlag = 0;
	int		resultCount = 0;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *DesnGrp=",29,30,42,43,60,61,62,63,64,65,66,70,71,72,73,74,75,76,77,78,79,80,88,81,67,68,69,55,91,92,93,94,95,96,54,15,16,04,82,49,31,47,83,24,97,46,32,35,33,40,41,58";

	POM_get_user(&username,&user_tag);
	printf("\n\t Starting for username :%s....\n",username);fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\t Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

	if(strstr(CurrentTask,"Assign Analyst and Change Review Board(COC) and VI/DMU Reviewer")!=NULL)
	{
		//printf("\n MT:.DesnGrp:%s \n",DesnGrp);fflush(stdout);
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);

		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {
			  TskPrtycount =0;
			  Prtycount =0;
			  Tskcount =0;
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
			printf("\n type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));
				printf("\n Analyst Name of task :: %s \n",AnalystName);fflush(stdout);

				CALLAPI(AOM_UIF_ask_value(attachments[i],"Requestor",&RequestorName));
				printf("\n RequestorName Name of task :: %s \n",RequestorName);fflush(stdout);
				//Checking Analyst.
				if (tc_strcmp(AnalystName,"")==0)
				{
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option");
					return ITK_err;
				}
				printf("\n MT:TASK:inside Check HasParticipant.. \n");fflush(stdout);
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(attachments[i],tsk_dml_rel_type,&Tskcount,&DMLRevision));
					printf("\n MT:DML Revision from Task for MR : %d",Tskcount);fflush(stdout);
					for (j=0;j<Tskcount ;j++ )
					{
						TskPrtycount=0;
						CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
						printf("\nMT: is_latest: %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\nMT:is_latest is not true.\n");fflush(stdout);
						}
						else
						{
							DMLRevTag = DMLRevision[j];
							CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&DMLno));
							CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtp));
							printf("\n MT: DMLno:%s ,DMLtype:%s \n",DMLno,DMLtp);fflush(stdout);
							//Check DML Type: If it is vehicle DML, then no need to check for task further.
							if(tc_strcmp(DMLtp,"Veh")==0)
							{
								PRDdmlFlag=0;
								printf("\n MT:no need to check further for Veh DML.\n");fflush(stdout);
							}
							else
							{
								//if not veh DML, and project is PRD, then no need to check further.
								CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&ProjectID));
								printf("\n MT: ProjectID.: %s",ProjectID);   fflush(stdout);
								if(ProjectID)
								{
									if(QRY_find("Qury_Project", &queryTag));
									printf("\n MT:.After Prd_Project: QRY_find");fflush(stdout);
									if (queryTag)
									{
										printf("\n MT:.Found Query");fflush(stdout);
									}
									else
									{
										printf("\n MT:.Not Found Query");fflush(stdout);
									}

									qry_values[0] = ProjectID;

									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
									printf("\n MT:.resultCount : %d\n", resultCount); fflush(stdout);

									if(resultCount > 0)
									{
										printf("\n MT:.t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
										Project_t = t5_Project[0];
										if (Project_t!=NULLTAG)
										{
											if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
											printf("\n MT:.ProjectClass:[%s]\n",ProjectClass);   fflush(stdout);

											if(tc_strcmp(ProjectClass,"PRD")==0)
											{
												//Query control table for PRDtoCVBU workflow project list.
												printf("\n MT:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
												if(QRY_find("ControlObjects", &qryTag));
												if (qryTag)
												{
													printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
												}
												else
												{
													printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
												}

												qry_values2[0] = "PRDCVBU";
												if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
												printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
												if(rsltCount > 0)
												{
													if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
													printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
													if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
													printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
													if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
													{
														PRDdmlFlag=1;
														printf("\n MT:..PRD project of CVBU found: %d",PRDdmlFlag); fflush(stdout);
													}
													else
													{
														PRDdmlFlag=0;
														printf("\n MT:..No project CVBU found: %d",PRDdmlFlag); fflush(stdout);
													}
												}
												else
												{
													PRDdmlFlag=0;
													printf("\n MT:..No project PRDCVBU found: %d",PRDdmlFlag); fflush(stdout);
												}
											}
											else
											{
												PRDdmlFlag=1;
												printf("\n MT:..No PRD project: %d",PRDdmlFlag); fflush(stdout);
											}
										}
									}
								}
							}
							if (PRDdmlFlag >0)
							{
								CALLAPI(AOM_ask_value_string(attachments[i],"item_id",&Tskno));
								DsgGrp=subString(Tskno,11,2);

								printf(" MT: TASK design group: [%s]\n",DsgGrp);fflush(stdout);
								printf("\n MT: DMLno:%s DMLtp:%s\n",DMLno,DMLtp);	fflush(stdout);
								//getting Participants.
								CALLAPI(GRM_find_relation_type("HasParticipant", &task_Prty_rel_type));
								if (task_Prty_rel_type!=NULLTAG)
								{
									CALLAPI(GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB));
									printf("\n MT: TaskCRB count: %d",TskPrtycount);fflush(stdout);
									if(TskPrtycount > 0)
									{
										DMUflag=0;
										Peerflag=0;
										BIWflag=0;
										TRIMflag=0;
										PTflag=0;
										CHflag=0;
										EEflag=0;
										for (jkk=0;jkk<TskPrtycount ;jkk++ )
										{
											//printf("\n MT:jkk: %d.\n",jkk);fflush(stdout);
											TskCRBTag = TaskCRB[jkk];
											if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
											if(TCTYPE_ask_name(ObjTypTskCRB,Tsk_Prty_typ));
											//printf("\n MT:DML: Tsk_Prty_typ :: %s\n", Tsk_Prty_typ);fflush(stdout);
											if (tc_strcmp(DMLtp,"SVR")==0)
											{
												if (tc_strcmp(Tsk_Prty_typ,"T5_BIWReviewer")==0)
												{
													BIWflag=1;
												}
												else if ((tc_strcmp(Tsk_Prty_typ,"T5_TRIMReviewer")==0))
												{
													TRIMflag=1;
												}
												else if ((tc_strcmp(Tsk_Prty_typ,"T5_CHReviewer")==0))
												{
													CHflag=1;
												}
												else if ((tc_strcmp(Tsk_Prty_typ,"T5_EEReviewer")==0))
												{
													EEflag=1;
												}
												else if ((tc_strcmp(Tsk_Prty_typ,"T5_PTReviewer")==0))
												{
													PTflag=1;
												}
											}
											else if((tc_strcmp(DMLtp,"PDR")!=0)&&(tc_strcmp(DMLtp,"XO")!=0)&&(tc_strcmp(DMLtp,"TOO")!=0))
											{
												if (tc_strcmp(Tsk_Prty_typ,"T5_DMUReviewer")==0)
												{
													DMUflag=1;
												}
												else if (tc_strcmp(Tsk_Prty_typ,"T5_PeerReviewer")==0)
												{
													Peerflag=1;
												}
											}
										}
										if (tc_strcmp(DMLtp,"SVR")==0)
										{
											printf("\n MT:PTflag:%d  EEflag:%d CHflag:%d TRIMflag:%d BIWflag:%d \n",PTflag,EEflag,CHflag,TRIMflag,BIWflag);fflush(stdout);
											if((PTflag ==0)||(EEflag== 0)|| (CHflag == 0)|| (TRIMflag ==0)||(BIWflag == 0))
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR COC reviewers not assigned to the task, \nPlease get it assigned from TCUA admin support.");
												return ITK_err;
											}
										}
										else
										{
											printf("\n MT:DMUflag:%d  Peerflag:%d \n",DMUflag,Peerflag);fflush(stdout);
											if((DMUflag ==0)||(Peerflag ==0))
											{
												if(tc_strstr(DesnGrp, DsgGrp) != NULL)
												{
													EMH_store_error_s1(EMH_severity_error,ITK_err,"Peer/DMU reviewer not assigned to the task, \nPlease get it assigned from TCUA admin support.");
													return ITK_err;
												}
											}
										}
									}
									else
									{
										if (tc_strcmp(DMLtp,"SVR")==0)
										{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR COC reviewers not assigned to the task, \nPlease get it assigned from TCUA admin support.");
											return ITK_err;
										}
										else
										{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Peer/DMU reviewer not assigned to the task, \nPlease get it assigned from TCUA admin support.");
											return ITK_err;
										}
									}
								}
							}
						}
					}
				}
			}

			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(attachments[i],"t5_rlstype",&DMLtp));
				printf("\n MT:DMLtp:%s\n",DMLtp);	fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(attachments[i],"ChangeSpecialist1",&ChangSpName));
				printf("\n\n\t\t ChangeSpecialist1 :: %s \n",ChangSpName);fflush(stdout);

				CALLAPI(AOM_UIF_ask_value(attachments[i],"ChangeReviewBoard",&ChangReviewName));
				printf("\n\n\t\t ChangeReviewBoard  :: %s \n",ChangReviewName);fflush(stdout);

				//CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_BOMAnalyst",&ChangReviewName1));
				//printf("\n\n\t\t T5_BOMAnalyst Name of task :: %s \n",ChangReviewName1);fflush(stdout);
				if (tc_strcmp(DMLtp,"SVR")!=0)
				{
					if (tc_strcmp(ChangReviewName,"")==0)
					{
						printf("\n MT:.Pls Assign Change Review Board");fflush(stdout);
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign Change Review Board/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->Select Change Review Board");
						return ITK_err;
					}
				}
				//1.34: Checking DMU only for Veh/PRD DML.
				if(tc_strcmp(DMLtp,"Veh")==0)
				{
					PRDdmlFlag=0;
					printf("\n MT:Stop for Veh DML..\n");fflush(stdout);
				}
				else
				{
					CALLAPI(AOM_ask_value_string(attachments[i],"t5_cprojectcode",&ProjectID));
					printf("\n MT: ProjectID..: %s",ProjectID);   fflush(stdout);
					if(ProjectID)
					{
						if(QRY_find("Qury_Project", &queryTag));
						printf("\n MT:.After Qury_Project: QRY_find");fflush(stdout);
						if (queryTag)
						{
							printf("\n MT:.Found Qury_Project");fflush(stdout);
						}
						else
						{
							printf("\n MT:.Not Found Qury_Project");fflush(stdout);
						}

						qry_values[0] = ProjectID;

						if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
						printf("\n MT:.resultCount : %d\n", resultCount); fflush(stdout);

						if(resultCount > 0)
						{
							printf("\n MT:.t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
							Project_t = t5_Project[0];
							if (Project_t!=NULLTAG)
							{
								if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
								printf("\n MT:.ProjectClass:[%s]\n",ProjectClass);   fflush(stdout);

								if(tc_strcmp(ProjectClass,"PRD")==0)
								{
									//Query control table for PRDtoCVBU workflow project list.
									printf("\n MT:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
									if(QRY_find("ControlObjects", &qryTag));
									if (qryTag)
									{
										printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
									}
									else
									{
										printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
									}

									qry_values2[0] = "PRDCVBU";
									if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
									printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
									if(rsltCount > 0)
									{
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
										printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
										printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
										if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
										{
											PRDdmlFlag=1;
											printf("\n MT:..PRD project of CVBU found: %d",PRDdmlFlag); fflush(stdout);
										}
										else
										{
											PRDdmlFlag=0;
											printf("\n MT:..No project CVBU found: %d",PRDdmlFlag); fflush(stdout);
										}
									}
									else
									{
										PRDdmlFlag=0;
										printf("\n MT:..No project PRDCVBU found: %d",PRDdmlFlag); fflush(stdout);
									}
								}
								else
								{
									PRDdmlFlag=1;
									printf("\n MT:..No PRD project: %d",PRDdmlFlag); fflush(stdout);
								}
							}
						}
					}
				}
				//1.34: Checking DMU only for Veh/PRD DML.
				CALLAPI(GRM_find_relation_type("HasParticipant", &dml_Prty_rel_type));
				if (dml_Prty_rel_type!=NULLTAG)
				{
					printf("\n MT:inside Check HasParticipant.. \n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(attachments[i],"item_id",&DMLno));
					printf("\n MT: DMLno:%s DMLtp:%s\n",DMLno,DMLtp);	fflush(stdout);

					CALLAPI(GRM_list_secondary_objects_only(attachments[i],dml_Prty_rel_type,&Prtycount,&DmlCRB));
					printf("\n MT: DmlCRB count: %d",Prtycount);fflush(stdout);
					if(Prtycount > 0)
					{
						VIFlag=0;
						BOMFlag=0;
						for (jk=0;jk<Prtycount ;jk++ )
						{
							DmlCRBTag = DmlCRB[jk];
							if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
							if(TCTYPE_ask_name(ObjTypDmlCRB,Prty_typ));
							if (tc_strcmp(DMLtp,"SVR")==0)
							{
								if (tc_strcmp(Prty_typ,"T5_VIReviewer")==0)
								{
									VIFlag=1;
									break;
								}
							}
							else
							{
								if(PRDdmlFlag >0)
								{
									if (tc_strcmp(Prty_typ,"T5_BOMAnalyst")==0)
									{
										BOMFlag=1;
										break;
									}
								}
								else
								{
									//Veh DML/PRD DML
									if (tc_strcmp(Prty_typ,"T5_DMUReviewer")==0)
									{
										DMUFlag=1;
										break;
									}
								}
							}
						}
						printf("\n MT: VIFlag :%d BOMFlag: %d DMUFlag:%d",VIFlag,BOMFlag,DMUFlag);fflush(stdout);
						if (tc_strcmp(DMLtp,"SVR")==0)
						{
							if (VIFlag==0)
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"VI reviewer not assigned to the DML, \nPlease get it assigned from TCUA admin support.");
								return ITK_err;
							}
						}
						else
						{
							if(PRDdmlFlag >0)
							{
								if (BOMFlag==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"BOM reviewer not assigned to the DML, \nPlease get it assigned from TCUA admin support.");
									return ITK_err;
								}
							}
							else
							{
								if (DMUFlag==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer not assigned to the DML, \nPlease assign the DMU Reviewer. \nUse: Select DML : Tools->Assign Participant->Select DMU Reviewer");
									return ITK_err;
								}
							}
						}
					}
					else
					{
						if (tc_strcmp(DMLtp,"SVR")==0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,"VI reviewers not assigned to the DML, \nPlease get it assigned from TCUA admin support.");
							return ITK_err;
						}
						else
						{
							if(PRDdmlFlag >0)
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"BOM reviewer not assigned to the DML, \nPlease get it assigned from TCUA admin support.");
								return ITK_err;
							}
							else
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer not assigned to the DML, \nPlease assign the DMU Reviewer. \nUse: Select DML : Tools->Assign Participant->Select DMU Reviewer");
								return ITK_err;
							}
						}
					}
				}
			}
		  }
		}
	}

	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI ChkdmlActiveinLC(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	char*			t5current_name				=NULL;
	logical			t5InProcess;
	char*			procedure_name				=NULL;

	tag_t *attachments = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\n\t\t Root task found for CheckDMLActiveinLCCheckDMLActiveinLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n\n\t\t EPM_ask_attachments of :: %d",count);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
	}

	CALLAPI(AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name));
	printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

	/*
	CALLAPI( AOM_ask_value_logical(DMLLcmTag,"fnd0InProcess",&t5InProcess));
	printf("\n\n\t\t t5InProcess : %d\n",t5InProcess);fflush(stdout);

	if(t5InProcess == true)
	{
		printf("\n\n\t\t t5InProcess is true .....\n");fflush(stdout);
	}else
	{
		printf("\n\n\t\t t5InProcess is not true .....\n");fflush(stdout);
	}*/

	CALLAPI(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
	printf("\n EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);

	CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
	printf("\n procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);

	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML already submitted in Lifecycle ... You can not submit it again.. abort DML -check with PLM admin..");
		decision = EPM_nogo;
	}else
	{
		decision = EPM_go;
	}

	return decision;
}

int PrdAssign_assgn_prj_action_handler ( EPM_action_message_t msg)
{
		int ifail = ITK_ok;
		tag_t root_task=NULLTAG;
		tag_t job = NULL_TAG;
		tag_t *attachments = NULLTAG;
		tag_t  objTag	   = NULLTAG;
		tag_t	queryTag   = NULLTAG;
		tag_t   *t5_Project= NULLTAG;
		tag_t	Project_tag  = NULLTAG;

		char*	username				=NULL;
		tag_t	user_tag				=NULLTAG;
		char*	CurrentTask				=NULL;
		char*	task_result				=NULL;
		char*	parent_name				=NULL;
		char	current_release_level[WSO_name_size_c + 1];
		char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		char*	object_type				=NULL;
		char*	DML_project_ids			=NULL;
		char 	*ProjectID		= NULL;
		char	*DML_No 				= NULL;
		int		count,t,resultCount = 0;
		int		n_entries = 1;
		char	*qry_entries[1] = {"Name"};
		char*	ProjectClass			= NULL;
		//PRDtoCVBU
		char	*info1	= NULL;
		char	*info2	= NULL;
		tag_t   *CntrlObjectTag      = NULLTAG;
		tag_t   qryTag     = NULLTAG;
		int     n_entry    = 1;
		int     rsltCount      =  0;
		char    *qry_entry[1]  = {"SYSCD"};
		char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

		ifail = POM_get_user(&username,&user_tag);
		printf("\n\t Starting for username :%s....\n",username);fflush(stdout);

		ifail = EPM_ask_root_task(msg.task,&root_task);
		printf("\n\t Root task found");fflush(stdout);

		ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
		printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);

		ifail = AOM_ask_value_string(msg.task,"task_result",&task_result);
		printf("\n\t task_result:%s\n",task_result);fflush(stdout);

		ifail = AOM_ask_value_string(root_task,"object_name",&parent_name);
		printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

		ifail = EPM_ask_job( msg.task, &job );
		ifail = EPM_ask_review_task_name( msg.task, current_release_level );
		printf("\n\n\t\t current_release_level :: %s\n",current_release_level); fflush(stdout);

		if(tc_strcmp(parent_name,"Change Request Life Cycle")==0)
		{
			if(tc_strstr(CurrentTask,"Condition")!=NULL)
		    {
				ifail = EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
				printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count); fflush(stdout);

				if(count > 0)
			    {
				   for(t=0;t<count;t++)
				   {
					  AOM_ask_value_string(attachments[t],"object_type",&object_type);
					  printf("\n object_type is :%s\n",object_type);fflush(stdout);

					  AOM_ask_value_string(attachments[t],"item_id",&DML_No);
					  printf("\n DML_No is :%s\n",DML_No);fflush(stdout);

					  if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
					  {
						  objTag = attachments[t];
						  CALLAPI(AOM_UIF_ask_value(objTag,"t5_cprojectcode",&DML_project_ids));
						  printf("\n DML_project_ids is :%s\n",DML_project_ids);fflush(stdout);

						  if(DML_project_ids)
						  {
							  if(QRY_find("Prd_Project", &queryTag));
							  printf("\n\t After Prd_Project : QRY_find");fflush(stdout);
							  if (queryTag)
							  {
								printf("\n\tFound Query");fflush(stdout);
							  }else
							  {
								printf("\n\tNot Found Query");fflush(stdout);
							  }

                              qry_values[0] = DML_project_ids;

							  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
							  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

							  if(resultCount > 0)
							  {
								  printf("\n\t t5_Project = [%s] found in DB\n",DML_project_ids);fflush(stdout);
								  Project_tag = t5_Project[0];
								  CALLAPI(AOM_ask_value_string(Project_tag,"t5_VehicleClass",&ProjectClass));
								  printf("\n\t Project class is :%s",ProjectClass); fflush(stdout);

								  if(tc_strcmp(ProjectClass,"PRD")==0)
								  {
									  //1.34L:Query control table for PRDtoCVBU workflow project list.
									  printf("\n Checking PRD  to CVBU WF project...\n"); fflush(stdout);
									  if(QRY_find("ControlObjects", &qryTag));
									  if (qryTag)
									  {
										 printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
									  }
									  else
									  {
										 printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
									  }

									  qry_values2[0] = "PRDCVBU";
									  if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
									  printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
									  if(rsltCount > 0)
									  {
											if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
											printf("\n info1 is :[%s]\n", info1);fflush(stdout);
											if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
											printf("\n info2 is :[%s]\n", info2);fflush(stdout);
											if((tc_strstr(info1,DML_project_ids)!=NULL) || (tc_strstr(info2,DML_project_ids)!=NULL))
											{
												ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
												printf("\n EPM_RESULT_False inside PRD:P1: %d",ifail); fflush(stdout);
											}
											else
											{
												ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
												printf("\n EPM_RESULT_True inside PRD:P2: %d",ifail); fflush(stdout);
											}
									  }
									  else
									  {
										  ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
										  printf("\n EPM_RESULT_True inside PRD:P3: %d",ifail); fflush(stdout);
									  }
								  }
								  else
								  {
									  ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
									  printf("\n EPM_RESULT_False inside PRD:P4: %d",ifail); fflush(stdout);
								  }
							  }else
							  {
								      ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
									  printf("\n EPM_RESULT_False inside PRD:P5: %d",ifail); fflush(stdout);
							  }
						  }else
						  {
							printf("\n DML Project code found NULL..........\n");fflush(stdout);
						  }
					  }
				   }
				}
			}
		}

		return ifail;
}

int T5PartToTaskDeleteVal( METHOD_message_t *msg, va_list  args )
{
	//va_list largs;	//DEEPTI TZ1.34
	//va_copy( largs, args ); //DEEPTI TZ1.34

	int ifail=0;
	int n_attchs,partcnt,k,count,j = 0;
	char   *username  = NULL;
	char   *user_name = NULL;
	tag_t	tUser	  = NULLTAG;
	char ** 	name;
	char*	 object_type		= NULL;
	char*	 taskCreater		= NULL;
	char*	 lstmodUsrOfTask		= NULL;
	char*	 TaskAnlyst		= NULL;
	char*	 Task_owning_user		= NULL;
	char*	 objectString		= NULL;
	char*	 taskTempLT		= NULL;
	char*	 AliasTaskName		= NULL;
	char*	 taskAnalystId		= NULL;

	tag_t objTypeTag4 = NULLTAG;
	tag_t	priObjTag				=	NULLTAG;
	tag_t	secObjTag				=	NULLTAG;
	tag_t	priObjTypeTag				=	NULLTAG;
	tag_t	priObjTaskTag				=	NULLTAG;
	tag_t	secObjTypeTag				=	NULLTAG;
	tag_t  *secondary_objects = NULLTAG;
	tag_t  *PartsTag = NULLTAG;
    tag_t  AssyTag = NULLTAG;
	tag_t rel_type;
	tag_t *TaskDML = NULLTAG;
	tag_t TaskDML_tag = NULLTAG;

	tag_t relation_type = NULLTAG;
    tag_t tsk_dml_rel_type;
    tag_t *DMLRevision = NULLTAG;
	logical is_latest;
	  tag_t DMLRevTag = NULLTAG;
	  tag_t class_id1=NULLTAG;
	  char *class_name1;
	  char*	 DMLtype		= NULL;
	  	char*	 aplTaskNo		= NULL; //DEEPTI TZ1.34


	char  type_name1[TCTYPE_name_size_c+1];
	char  type_name2[TCTYPE_name_size_c+1];
	char  type_name3[TCTYPE_name_size_c+1];
	char  type_name4[TCTYPE_name_size_c+1];

	//tag_t object = va_arg(largs, tag_t);//DEEPTI TZ1.34
	tag_t object = va_arg(args, tag_t);

	username = NULL;
	taskCreater = NULL;
	lstmodUsrOfTask = NULL;
	taskTempLT = NULL;
	AliasTaskName = NULL;
	aplTaskNo = NULL; //DEEPTI TZ1.34

	CALLAPI(POM_get_user_id (&username));
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);

	if(TCTYPE_ask_object_type(object,&objTypeTag4));
	if(TCTYPE_ask_name(objTypeTag4,type_name4));
	printf("\n selected Object is :: %s\n", type_name4);fflush(stdout);

	if (GRM_ask_secondary (object,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	printf("\n T5PartToTaskDeleteVal::sec_type_name :%s\n", type_name2);fflush(stdout);

	if (GRM_ask_primary (object,&priObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	printf("\n T5PartToTaskDeleteVal::pri_type_name :%s\n", type_name1);fflush(stdout);

	if(tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0)
	{
		CALLAPI(AOM_UIF_ask_value(priObjTag,"fnd0ActuatedInteractiveTsks",&taskTempLT));
		printf("\n primary taskTempLT is : %s\n",taskTempLT);fflush(stdout);
	}

	if(tc_strcmp(type_name1,"T5_APLTaskRevision")==0)  //DEEPTI TZ1.34
	{
		CALLAPI(AOM_ask_value_string(priObjTag,"item_id",&aplTaskNo));
		printf("\n primary aplTaskNo is : %s\n",aplTaskNo);fflush(stdout);
	}

	if(tc_strcmp(type_name4,"HasParticipant")==0)
	{
		printf("\n HasParticipant allow to remove.....\n");fflush(stdout);
	}
	else if (tc_strcmp(type_name4,"CMReferences")==0 && ( tc_strcmp(type_name2,"VariantRule")==0 || tc_strcmp(type_name2,"T5_PlatformRevision")==0 ) )
	{
		if (tc_strcmp(taskTempLT,"Add Reference Item")==0)
		{
			printf("\n SVR Add Reference Item CMReferences allow to remove.....\n");fflush(stdout);
		}
		else if (tc_strcmp(taskTempLT,"Add Platform and SVR")==0)
		{
			printf("\n Add Platform and SVR CMReferences allow to remove.....\n");fflush(stdout);
		}
		else
		{
			CALLAPI(AOM_UIF_ask_value(priObjTag,"last_mod_user",&lstmodUsrOfTask));
			printf("\n primary lstmodUsrOfTask is : %s\n",lstmodUsrOfTask);fflush(stdout);

			if(tc_strcmp(lstmodUsrOfTask,"infodba") !=0 && tc_strcmp(lstmodUsrOfTask,"loader") !=0)
			{
				printf("\n Inside loop Delete from 'Add solution items'.....\n"); fflush(stdout);

				EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of Add Reference Items","You cannot delete SVR from ReferenceItems of the task.");

				return ITK_err;
			}else
			{
				printf("\n Bypass for infodba/Loader User...\n"); fflush(stdout);
			}
		}
	}
	else
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		{
		 CALLAPI(GRM_list_primary_objects_only(priObjTag,tsk_dml_rel_type,&count,&DMLRevision));
		 printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);

		 for (j=0;j<count ;j++ )
		 {
			CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
			printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
			}else
			{
				DMLRevTag = DMLRevision[j];
				CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
				CALLAPI(POM_name_of_class(class_id1,&class_name1));
				printf("\n\n\t\t class_name found1 :%s",class_name1);

				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
				printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

				if((tc_strcmp(DMLtype,"CP") !=0) &&  (tc_strcmp(DMLtype,"MR") !=0)&&  (tc_strcmp(DMLtype,"DFMR") !=0))
				{


					if(tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0)
					{
						//primary object
						if(AOM_ask_value_string(priObjTag,"object_type",&object_type));
						printf("\n primary object_type is :%s\n",object_type);fflush(stdout);

						if(AOM_ask_value_string(priObjTag,"object_string",&Task_owning_user));
						printf("\n primary object_string is :%s\n",Task_owning_user);fflush(stdout);

						CALLAPI(AOM_UIF_ask_value(priObjTag,"owning_user",&taskCreater));
						printf("\n primary taskCreater is : %s\n",taskCreater);fflush(stdout);

						//CALLAPI(AOM_UIF_ask_value(priObjTag,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						//printf("\n primary taskTempLT is : %s\n",taskTempLT);fflush(stdout);


					}else
					printf("\n Class is other than TaskRevision...\n"); fflush(stdout);
			}


	  //Added By Rajendra

	  //if(tc_strcmp(type_name4,"CMHasSolutionItem")!=0)

		if(tc_strcmp(type_name4,"CMHasSolutionItem")==0)
		{
		  printf("\n   Inside attaching part to taskkk111 \n");fflush(stdout);
		  if(tc_strcmp(type_name2,"Design Revision")==0 || tc_strcmp(type_name2,"ItemRevision")==0 )
		  {
				//if(tc_strcmp(taskTempLT,"Add solution items") !=0)
				if((tc_strcmp(taskTempLT,"Add solution items") !=0) && (tc_strcmp(type_name1,"T5_APLTaskRevision")!=0))//DEEPTI TZ1.34
				{
					CALLAPI(AOM_UIF_ask_value(priObjTag,"last_mod_user",&lstmodUsrOfTask));
					printf("\n primary lstmodUsrOfTask is : %s\n",lstmodUsrOfTask);fflush(stdout);

					if(tc_strcmp(lstmodUsrOfTask,"infodba") !=0 && tc_strcmp(lstmodUsrOfTask,"loader") !=0)
					{
						printf("\n Inside loop Delete from 'Add solution items'.....\n"); fflush(stdout);

						EMH_store_error_s2(EMH_severity_warning,ITK_err,"The Task Is Not For Assignment Of Add Solution Items","You cannot delete parts from SolutionItem of the task.");

						return ITK_err;
					}else
					{
						printf("\n Bypass for infodba/Loader User...\n"); fflush(stdout);
					}
				}

			 //TZ 1.28 Rajendra - Check DML owner and Session User

			//if(tc_strcmp(type_name4,"CMHasSolutionItem")==0)

			if(tc_strcmp(taskTempLT,"Add solution items") ==0)
			{

				//CALLAPI(AOM_UIF_ask_value(secObjTag,"fnd0AssigneeUser",&TaskAnlyst));
				CALLAPI(AOM_UIF_ask_value(priObjTag,"analyst_user_id",&TaskAnlyst));

				printf("\n TaskAnlyst [%s] ",TaskAnlyst);fflush(stdout);

				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
				{
					if(tc_strcmp(username,TaskAnlyst) !=0)
						{
							printf("\n Inside loop 'Add solution items'.....Delete Parts From DML Task\n"); fflush(stdout);

							EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not Task Analyst..Only Analyst Can Delete Part From DML Task.Task Analyst Is:",TaskAnlyst);

							return ITK_err;
						}
					else
						{
							printf("\n Session user is Analyst   ...:%s\n",TaskAnlyst); fflush(stdout);
						}
				}
				else
				{

					printf("\n bypass for infodba & loader   ...\n"); fflush(stdout);

				}
			}
		  }
		}

			//Added By Rajendra-End
		}
	}
	}else
	{
		printf("\n Relation DMLRevision to TaskRevision not found...\n"); fflush(stdout);
	}
	}


if(DMLRevision)
			MEM_free(DMLRevision);

 return ITK_ok;
}

extern int erc_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    METHOD_id_t  method3;

    int ifail=0;
    *decision = ALL_CUSTOMIZATIONS;

    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];

    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("erc_dml_assign", "", erc_dml_assign))
   {
		printf("\t\n Registered Action Handler erc_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler erc_user_assign_register_method\n");fflush(stdout);
   }

   //Added by kalpesh(26-07-2018)
  
   if( ITK_ok == EPM_register_action_handler("attach_dataset_on_dmlsubmit", "", attach_dataset_on_dmlsubmit))
   {
		printf("\t\n Registered Action Handler attach_dataset_on_dmlsubmit\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler attach_dataset_on_dmlsubmit\n");fflush(stdout);
   }
//kalpesh(End)


   if( ITK_ok == EPM_register_action_handler("erc_task_breakdown", "", erc_task_breakdown))
   {
		printf("\t\n Registered Action Handler erc_task_breakdown\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler erc_task_breakdown\n");fflush(stdout);
   }

   if( ITK_ok ==  EPM_register_rule_handler ("SignOffCheck","Check Validation with DesignRevision", (EPM_rule_handler_t) SignOffCheck_Chk_Validation))
   {
		printf("\t\n Registered rule  HandlerSignOffCheck\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler SignOffCheck\n");fflush(stdout);
   }

   if( ITK_ok ==  EPM_register_rule_handler ("assign-anlst-reviwer","Assign Analyst", (EPM_rule_handler_t) assign_anlst_reviwer))
   {
		printf("\t\n Registered rule  Handler assign-anlst-reviwer\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler assign-anlst-reviwer\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("activeInWorkflow","Check Validation with ActiveInWorkflow", (EPM_rule_handler_t) ChkdmlActiveinLC))
   {
		printf("\t\n Registered rule  ActiveInWorkflow.................\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler ActiveInWorkflow\n");fflush(stdout);
   }

   //added by Hanuman in TZ 1.33
   if( ITK_ok == EPM_register_action_handler("Assign_Prd_Project", "", PrdAssign_assgn_prj_action_handler))
   {
		printf("\t\n Registered Action Handler Assign_Prd_Project\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler Assign_Prd_Project\n");fflush(stdout);
   }

   ifail = METHOD_find_method("ChangeRequestRevision", TC_save_msg, &method1);
   if (method1.id != NULLTAG)
   {
		ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) createCR_Task, NULL)!=ITK_ok;
		//PrintErrorStack();
		printf("\nrrrrrrrrRegistered as Post-Action for ChangeRequestRevision Creation\n");fflush(stdout);
   }else
   {
		printf("\nMethod not found!TC_save_msg\n");fflush(stdout);
   }

   // -------------1.31
    if (method1.id != NULLTAG)
   {
		ifail = METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) Pre_create_Dml, NULL)!=ITK_ok;
		//PrintErrorStack();
		printf("\n as Pre-Action for ChangeRequestRevision Creation\n");fflush(stdout);
   }else
   {
		printf("\nMethod not found!TC_save_msg\n");fflush(stdout);
   }
   // -------------1.31


   ifail = METHOD_find_method("ImanRelation", GRM_create_msg, &method2);
   if( ifail == ITK_ok )
   {
	    printf("\n Before register method for GRM_create_msg for T5TaskToPartCreateVal \n");fflush(stdout);
	    if (method2.id != NULLTAG)
	    {
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPartCreateVal, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for T5TaskToPartCreateVal \n");fflush(stdout);
	    }else
		printf("Method not found!GRM_create_msg\n");fflush(stdout);
	}

   /***************************delete_msg*****************************************/

   ifail = METHOD_find_method("ImanRelation", TC_delete_msg, &method3);
   if( ifail == ITK_ok )
   {
	    printf("\n method TC_delete_msg is called... \n");fflush(stdout);
		if (method3.id != NULLTAG)
	    {
			if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) T5PartToTaskDeleteVal, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for T5PartToTaskDeleteVal \n");fflush(stdout);
		}else
		printf("Method not found!TC_delete_msg...\n");fflush(stdout);
   }

   /***************************end*****************************************/

   return ITK_ok;
}

extern DLLAPI int erc_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("erc_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t) erc_user_assign_register_method);

     printf("\n registered function erc_dml_assign for all DMLs\n");	fflush(stdout);

	 return ( ITK_ok );
}
