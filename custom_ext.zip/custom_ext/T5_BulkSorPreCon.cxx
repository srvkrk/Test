//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T5_BulkSorPreCon
 *
 */
#include <T5_tm_bulkPPPMPrjCodelib/T5_BulkSorPreCon.hxx>
//#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include<iostream>
#define ITK_err 919002
#define PLM_error1 (EMH_USER_error_base+26)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( const char *file, int line, const char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


using namespace Teamcenter;


int tm_check_info_control_object_BulkSorPreCon ( char *syscd, char *subsyscd)
{
	int ifail = ITK_ok;
	int n_found = 0 ;
	int n_entries = 2 ;
	char  *qry_entries[] = {(char *)"SYSCD",(char *)"SUBSYSCD"};
	char  *qry_values[] = {(char *)syscd,(char *)subsyscd};
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	//char *l_info1 = NULL ;
	//char *l_info2 = NULL ;

	ifail =  ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ifail =  ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	//if ( n_found > 0 )
	//{
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
	//	tc_strcpy( info1, l_info1 );
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
	//	tc_strcpy( info2, l_info2 );
	//
	//	printf ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//	TC_write_syslog ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//}

	return n_found ;
}



int BulkSorPreCon_PrtQuery_function(char *partno,char *Rev, char *Seq)
{

	printf("\n....Inside BulkSorPreCon_PrtQuery_function....");
	TC_write_syslog("\n....Inside BulkSorPreCon_PrtQuery_function....");


	int ifail = ITK_ok;
	int n_entries = 2;
	int resultCount = 0;
	char *RevSeq = NULL;

	RevSeq = (char *)MEM_alloc(5*sizeof(char));

	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);

	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;


	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	printf("\nBulkSorPreCon_PrtQuery_function Querying Part no [%s] Rev,Seq [%s]",partno,RevSeq);
	TC_write_syslog("\nBulkSorPreCon_PrtQuery_function Querying Part no [%s] Rev,Seq [%s]",partno,RevSeq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		printf("\nBulkSorPreCon_PrtQuery_function Unique RevSeq Query found");
		TC_write_syslog("\nBulkSorPreCon_PrtQuery_function Unique RevSeq Query found");
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
		printf("\nBulkSorPreCon_PrtQuery_function Part Count in TCUA : [%d]",resultCount);
		TC_write_syslog("\nBulkSorPreCon_PrtQuery_function Part Count in TCUA : [%d]",resultCount);

	}

	if (resultCount == 0)
	{
		return 1;
	}

	return ifail;

}

int search_next_rev_quick_sor( tag_t Part_b_Tag )
{
	printf("\nfunction search_next_rev_quick_sor");
	TC_write_syslog("\nfunction search_next_rev_quick_sor");
	int ifail = ITK_ok;
	int i_b = 0;
	int SOR_b_Count = 0;
	tag_t objType_b_Tag = NULLTAG;
	tag_t q_relation_type = NULLTAG;
	tag_t *q_SOR_Objects = NULLTAG;
	char *type_b_name = NULL;
	char *Release_status_qSOR = NULL;
	
	ifail = ( GRM_find_relation_type ( "T5_PartSorRel", &q_relation_type ) ) ;
	ifail = ( GRM_list_secondary_objects_only ( Part_b_Tag, q_relation_type, &SOR_b_Count, &q_SOR_Objects ) ) ;
	printf("\nfunction search_next_rev_quick_sor SOR_b_Count : [%d]",SOR_b_Count);
	TC_write_syslog("\nfunction search_next_rev_quick_sor SOR_b_Count : [%d]",SOR_b_Count);
			
	if ( SOR_b_Count > 0 )
	{
		for ( i_b = 0 ; i_b < SOR_b_Count  ; i_b++ )
		{
			ITK_CALL ( TCTYPE_ask_object_type ( q_SOR_Objects[i_b], &objType_b_Tag ) ) ;
			ITK_CALL ( TCTYPE_ask_name2 ( objType_b_Tag, &type_b_name ) );
			printf("\nfunction search_next_rev_quick_sor type_b_name : [%s]",type_b_name);
			TC_write_syslog("\nfunction search_next_rev_quick_sor type_b_name : [%s]",type_b_name);
			if ( tc_strcmp ( type_b_name, "T5_quicksorRevision" ) == 0 )
			{
				Release_status_qSOR = NULL;
				ITK_CALL(AOM_UIF_ask_value ( q_SOR_Objects[i_b], "release_status_list", &Release_status_qSOR ) ) ;
				printf ( "\nRelease_status_qSOR : [%s]", Release_status_qSOR ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nRelease_status_qSOR : [%s]", Release_status_qSOR ) ; fflush ( stdout) ;
				if ( tc_strstr ( Release_status_qSOR, "ERC Released" ) != NULL )
				{
					return 1;//ERC Released SOR found;
				}
				else
				{
					return 2;//nonERC Released SOR found hene ask user to first delete latest rev SOR then create sor for new Revision;
				}
				
			}
		}

	}
	else if ( SOR_b_Count == 0 )
	{
		return 0;//no sor found for part revision
	}
	
	return 0;
}

int check_part_next_revision_has_sor ( char *partno, char *inp_Rev, char *inp_Seq )
{
	char *BlkSor_Nxt_Rev = NULL;
	char *BlkSor_Nxt_Rev_status = NULL;
	int ifail = ITK_ok;
	int no_a_entries = 1;
	int i_a = 0;
	int result_a_Count = 0;
	tag_t query_a_Tag = NULLTAG;
	tag_t *part_a_Objs = NULLTAG;
	tag_t Part_a_Tag = NULLTAG;

	int	n_to_sort = 1;//The number of the class attributes to be sorted
	//char *keys[1] = {"creation_date"};	// attribute name to sort
	char** keys = NULL;
    int orders[1] = { 2 };	//descending order sort
		
	char *qry_a_entries[] = {(char *)"Item ID"};
	char  *qry_a_values[] = {(char *)partno};
	
	int match_rev_count = -1 ;//not found
	int found_sor_nxt_rev = -1;
	int n_found_BulkSor_nxt_rev = 0;
	
	keys = (char**)MEM_alloc(1 * sizeof(char*));
	keys[0] = (char*)MEM_alloc(30);
	tc_strcpy(keys[0], "creation_date");

	BlkSor_Nxt_Rev = (char *)MEM_alloc(50 *sizeof(char));
	BlkSor_Nxt_Rev_status = (char *)MEM_alloc(50 *sizeof(char));
	
	printf("\nfunction check_part_next_revision_has_sor");
	TC_write_syslog("\nfunction check_part_next_revision_has_sor");
	
	tc_strcpy(BlkSor_Nxt_Rev,"BLKSORNXTREV");
	tc_strcpy(BlkSor_Nxt_Rev_status,"ON");
	
	n_found_BulkSor_nxt_rev = tm_check_info_control_object_BulkSorPreCon ( BlkSor_Nxt_Rev,BlkSor_Nxt_Rev_status);

	printf("\nBulkSorPreAct n_found_BulkSorPreCon : [%d]",n_found_BulkSor_nxt_rev);
	TC_write_syslog("\nBulkSorPreAct n_found_n_found_BulkSorPreCon : [%d]",n_found_BulkSor_nxt_rev);


	if ( n_found_BulkSor_nxt_rev > 0 )
	{
		ifail =(QRY_find2("Item Revision...", &query_a_Tag));

		printf("\nItem Revision...Query found");
		TC_write_syslog("\nItem Revision...Query found");

		//ifail =(QRY_execute( query_a_Tag, n_a_entries, qry_a_entries, qry_a_values, &result_a_Count, &part_a_Objs ) );
		ifail =(QRY_execute_with_sort( query_a_Tag, no_a_entries, qry_a_entries, qry_a_values,n_to_sort, keys, orders, &result_a_Count, &part_a_Objs ) );
		
		
		printf("\nresult_a_Count : [%d]", result_a_Count);
		TC_write_syslog("\nresult_a_Count : [%d]", result_a_Count);
		
		if ( result_a_Count > 0 )
		{
			for ( i_a = 0 ; i_a < result_a_Count ; i_a++ )
			{
			
				char *q_a_SORPart_no = NULL;
				char *q_a_SORPart_RevSeq = NULL;
				char *q_a_SORPart_Rev = NULL;
				char *q_a_SORPart_Seq = NULL;
				
				Part_a_Tag = part_a_Objs [i_a] ; 
				
				ifail = ( AOM_ask_value_string ( Part_a_Tag, "item_id", &q_a_SORPart_no ) ) ;
				printf("\nq_a_SORPart_no : [%s]", q_a_SORPart_no);
				TC_write_syslog("\nq_a_SORPart_no : [%s]", q_a_SORPart_no);


				ifail = ( AOM_ask_value_string ( Part_a_Tag, "item_revision_id", &q_a_SORPart_RevSeq ) ) ;
				printf("\nq_a_SORPart_RevSeq : [%s]", q_a_SORPart_RevSeq);
				TC_write_syslog("\nq_a_SORPart_RevSeq : [%s]", q_a_SORPart_RevSeq);

				q_a_SORPart_Rev = strtok(q_a_SORPart_RevSeq,";");
				q_a_SORPart_Seq = strtok(NULL,"");

				printf("\nq_a_SORPart_Rev : [%s]", q_a_SORPart_Rev);
				TC_write_syslog("\nq_a_SORPart_Rev : [%s]", q_a_SORPart_Rev);

				printf("\nq_a_SORPart_Seq : [%s]", q_a_SORPart_Seq);
				TC_write_syslog("\nq_a_SORPart_Seq : [%s]", q_a_SORPart_Seq);
				
				if ( ( tc_strcmp ( inp_Rev, q_a_SORPart_Rev ) == 0 ) && ( tc_strcmp ( inp_Seq, q_a_SORPart_Seq ) == 0 ) )
				{
					//match_rev_count = i_a ;
					break;
				}
				else
				{
					found_sor_nxt_rev = search_next_rev_quick_sor( Part_a_Tag );
					//0=no quicsor found for part revision
					//1=ERC Released quickSOR found
					//2=nonerc release quicksor found
					if ( ( found_sor_nxt_rev == 1 ) || ( found_sor_nxt_rev == 2 ) )
					{
						printf("\nfound_sor_nxt_rev : [%d]", found_sor_nxt_rev);
						TC_write_syslog("\nfound_sor_nxt_rev : [%d]", found_sor_nxt_rev);
						return found_sor_nxt_rev;
					}
				}
				
			}
			
		}	
		
	}

	return 0;
}

int T5_BulkSorPreCon( METHOD_message_t *, va_list args )
{
 
	printf("\nT5_BulkSorPreCon...............");
	TC_write_syslog("\nT5_BulkSorPreCon...............");

	std::string Bulkprjcode ;
	std::string BulkPPPMprjcode ;
	std::string BulkVertical ;
	std::string BulkBusinessUnit ;
	std::vector<std::string> SOR_Part_Numbers;
	std::vector<int> lovnullist;

	bool isNull1;
	bool isNull2;
	bool isNull3;
	bool isNull4;

	int ifail = ITK_ok;
	int error_flag = 0;
	int i = 0;
	int BulkSorPreCon_PrtQuery_function_return = 0;
	int BulkSorPreCon_PrtQuery_function_counter = 0;
	int n_found_BulkSorPreCon = 0;

	char *ErrorMessage = NULL;
	char *PrtErrorMessage = NULL;

	ErrorMessage = (char *)MEM_alloc(200*sizeof(char));
	PrtErrorMessage = (char *)MEM_alloc(200*sizeof(char));


	va_list local_args;
	va_copy( local_args, args);

	char *BulkSorPreConcheck = NULL;
	char *BulkSorPreConstatus = NULL;
	
	char *next_rev_sor_erc_rel_msg = NULL;
	char *next_rev_sor_not_erc_rel_msg = NULL;
	int flag_nxt_rev_err_1 = 0;
	int flag_nxt_rev_err_2 = 0;
	int next_part_rev_has_sor = 0 ;
	
	
	BulkSorPreConcheck = (char *)MEM_alloc(50 *sizeof(char));
	BulkSorPreConstatus = (char *)MEM_alloc(50 *sizeof(char));

	tc_strcpy(BulkSorPreConcheck,"BulkSorPreCon");
	tc_strcpy(BulkSorPreConstatus,"ON");

	CreateInput *CreInput = va_arg(local_args, CreateInput*);


	n_found_BulkSorPreCon = tm_check_info_control_object_BulkSorPreCon ( BulkSorPreConcheck,BulkSorPreConstatus);

	printf("\nT5_BulkSorPreCon n_found_BulkSorPreCon : [%d]",n_found_BulkSorPreCon);
	TC_write_syslog("\nT5_BulkSorPreCon n_found_BulkSorPreCon : [%d]",n_found_BulkSorPreCon);

	if ( n_found_BulkSorPreCon > 0 )
	{

		CreInput->getString("t5_BulkPrjCode", Bulkprjcode, isNull1 );//Bulk SOR Project code
		printf("\nT5_BulkSorPreCon Bulkprjcode : [%s]",Bulkprjcode.c_str());
		TC_write_syslog("\nT5_BulkSorPreCon Bulkprjcode : [%s]",Bulkprjcode.c_str());


		CreInput->getString("t5_BulkPPPMPrjCode", BulkPPPMprjcode, isNull2 );//Bulk SOR PPPM Project code
		printf("\nT5_BulkSorPreCon BulkPPPMprjcode : [%s]",BulkPPPMprjcode.c_str());
		TC_write_syslog("\nT5_BulkSorPreCon BulkPPPMprjcode : [%s]",BulkPPPMprjcode.c_str());


		CreInput->getStringArray("t5_SOR_Part_Numbers", SOR_Part_Numbers, lovnullist );//SOR part number list
		std::cout << "\nT5_BulkSorPreCon no of SOR_Part_Numbers : " << lovnullist.size() << std::endl;\

		CreInput->getString("t5_BulkBusinessUnit", BulkBusinessUnit, isNull3 );//Bulk SOR Business Unit
		printf("\nT5_BulkSorPreCon BulkBusinessUnit :  [%s]",BulkBusinessUnit.c_str());
		TC_write_syslog("\nT5_BulkSorPreCon BulkBusinessUnit : [%s]",BulkBusinessUnit.c_str());

		
		CreInput->getString("t5_BulkVertical", BulkVertical, isNull4 );//Bulk SOR Vertical
		printf("\nT5_BulkSorPreCon BulkVertical : [%s]",BulkVertical.c_str());
		TC_write_syslog("\nT5_BulkSorPreCon BulkVertical : [%s]",BulkVertical.c_str());




		 if(lovnullist.size()==0)
		 {
		     error_flag++;
		     tc_strcat(ErrorMessage,"Select SOR Part numbers from C:>Temp>sor.csv in format Partnumber,Rev,Seq");//Error message
		 }

		 else if(isNull1 == true)
		 {
			 error_flag++;
			 tc_strcat(ErrorMessage,"Select Bulk SOR Project code");//Error message
		 }

		 else if(isNull2 == true)
		 {
			 error_flag++;
			 tc_strcat(ErrorMessage,"Select Bulk SOR PPPM Project code");//Error message
		 }

		 else if(isNull3 == true)
		 {
			 error_flag++;
			 tc_strcat(ErrorMessage,"Select Business Unit from Dropdown list");//Error message
		 }


		 else if(isNull4 == true)
		 {
			 error_flag++;
			 tc_strcat(ErrorMessage,"Select Vertical from Dropdown list");//Error message
		 }


		 if(error_flag>0)
		 {

		         EMH_clear_errors();
		         EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);//Error message
		         return(PLM_error1);
		 }

		next_rev_sor_erc_rel_msg = ( char *) MEM_alloc ( 1500 * sizeof ( char ) );
		tc_strcpy ( next_rev_sor_erc_rel_msg, "Part list as below" );
		
		next_rev_sor_not_erc_rel_msg = ( char *) MEM_alloc ( 1500 * sizeof ( char )  );
		tc_strcpy ( next_rev_sor_not_erc_rel_msg, "Part list as below" );

		for (i = 0 ; i < lovnullist.size(); i++)
		{

			printf("\nT5_BulkSorPreCon SOR Part number from the list : [%d]\t[%s]",i, SOR_Part_Numbers[i].c_str()); //SOR part number
			TC_write_syslog("\nT5_BulkSorPreCon SOR Part number from the list : [%d]\t[%s]",i, SOR_Part_Numbers[i].c_str()); //SOR part number

			char *Partno_Rev_Seq = NULL;
			Partno_Rev_Seq = (char*)MEM_alloc(50*sizeof(char));

			strcpy(Partno_Rev_Seq,SOR_Part_Numbers[i].c_str());//copying SOR part number from list
			printf("\nPartno_Rev_Seq : [%d]\t[%s]",i,Partno_Rev_Seq);

			char *partno = NULL;
			char *Rev = NULL;
			char *Seq = NULL;
			partno = strtok(Partno_Rev_Seq,",");
			Rev = strtok(NULL,",");
			Seq = strtok(NULL,",");

			BulkSorPreCon_PrtQuery_function_return = BulkSorPreCon_PrtQuery_function(partno,Rev,Seq);//Query function for SOR part number

			printf("\nT5_BulkSorPreCon BulkSorPreCon_PrtQuery_function_return : [%d]",BulkSorPreCon_PrtQuery_function_return);
			TC_write_syslog("\nT5_BulkSorPreCon BulkSorPreCon_PrtQuery_function_return : [%d]",BulkSorPreCon_PrtQuery_function_return);


			if (BulkSorPreCon_PrtQuery_function_return > 0)
			{

				BulkSorPreCon_PrtQuery_function_counter ++;
				tc_strcat(PrtErrorMessage,Partno_Rev_Seq);
				tc_strcat(PrtErrorMessage,",");

			}


			//check if any next revision of part has sor then skip SOR creation
			next_part_rev_has_sor = 0;
			next_part_rev_has_sor = check_part_next_revision_has_sor(partno,Rev,Seq);
			if ( next_part_rev_has_sor == 1 )
			{
				tc_strcat ( next_rev_sor_erc_rel_msg, partno ) ;
				tc_strcat ( next_rev_sor_erc_rel_msg, "/" ) ;
				tc_strcat ( next_rev_sor_erc_rel_msg, Rev ) ;
				tc_strcat ( next_rev_sor_erc_rel_msg, ";" ) ;
				tc_strcat ( next_rev_sor_erc_rel_msg, Seq ) ;
				tc_strcat ( next_rev_sor_erc_rel_msg, "," ) ;
				flag_nxt_rev_err_1 = flag_nxt_rev_err_1 + 1;
			}

			if ( next_part_rev_has_sor == 2 )
			{
				tc_strcat ( next_rev_sor_not_erc_rel_msg, partno ) ;
				tc_strcat ( next_rev_sor_not_erc_rel_msg, "/" ) ;
				tc_strcat ( next_rev_sor_not_erc_rel_msg, Rev ) ;
				tc_strcat ( next_rev_sor_not_erc_rel_msg, ";" ) ;
				tc_strcat ( next_rev_sor_not_erc_rel_msg, Seq ) ;
				tc_strcat ( next_rev_sor_not_erc_rel_msg, "," ) ;
				flag_nxt_rev_err_2 = flag_nxt_rev_err_2 + 1;
			}


			MEM_free(Partno_Rev_Seq);
		}

		if( BulkSorPreCon_PrtQuery_function_counter > 0 )
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_error,PLM_error1,"Parts Not found in TCUA : ",PrtErrorMessage);//Error message
			return(PLM_error1);
		}
		//dbk 22-07-2025
		if ( flag_nxt_rev_err_1 > 0 )
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_warning,ITK_err,"Can not create Quick SOR for below part as Latest revision of part has ERC Released Quick SOR : ",next_rev_sor_erc_rel_msg);
			return ITK_err;
		}

		if ( flag_nxt_rev_err_2 > 0 )
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_warning,ITK_err,"Can not create Quick SOR for below part as Latest revision of part has non ERC Released Quick SOR get it deleted and recreate Quick SOR for input revision: \n",next_rev_sor_not_erc_rel_msg);
			return ITK_err;
		}
		//dbk 22-07-2025
	}

	MEM_free(BulkSorPreConcheck);
	MEM_free(BulkSorPreConstatus);


    return ifail;

}
