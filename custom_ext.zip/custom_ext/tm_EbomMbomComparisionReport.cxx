/***************************************************************************
 * Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TTL.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 *  Author		 :   Amar Kate
 *  Module		 :   tm_EbomMbomComparisionReport
 *  Code		 :   tm_EbomMbomComparisionReport.cxx
 *  Created on	 :   April 06, 2025
 *
 *
 * Modification History :
 * S.No    Date			CR No     Modified By            Modification Notes
 ***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h> /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h> /* for dataset id and rev */
#include <ae/ae_types.h>  /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <cfm/cfm.h>


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>

#include <base_utils/ScopedPtr.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedSmPtr.hxx>

#include <cstdio> // For sprintf
#include <cstring> // For string operations

#define ITK_err 2424

using namespace std;
using namespace Teamcenter;

#define ITK_CALL(x)                                                                 \
	{                                                                               \
		int stat;                                                                   \
		char *err_string;                                                           \
		if ((stat = (x)) != ITK_ok)                                                 \
		{                                                                           \
			EMH_ask_error_text(stat, &err_string);                       \
			printf("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
			printf("\n FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
			if (err_string)                                                         \
				MEM_free(err_string);                                               \
			exit(EXIT_FAILURE);                                                     \
		}                                                                           \
	}



typedef struct PartVector
{

	int index;
	string partInf;

} PartVector_t;


//Global Decleration

char*	inp_Plant		= NULL;
char*	RptTimestamp	= NULL;
char*	timestamp       = NULL;

int   PartIndexSapQry =   0;

int UPartListCount = 0;	
tag_t *UPartList = NULLTAG;




int get_child(int count, char* PChlPrtno,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,map<string, string>& APLModuleSubChildRelation,multimap<string, string>& ERCModuleSubChildRelation,set<string>& APLModuleuniqPart,set<string>& ERCModuleuniqPart,multimap<string, string>& AplErcPartInfo,multimap<string, string>& APLModuleSubChilduniqPart,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap,multimap<string, string>& ERCParentLevelMap);
int get_top_line_property(tag_t top_line,char* InputPart, char* inp_level, char* inp_RemoveUnderscorePart, char* inp_Plant, char* inp_StopatF, char* inp_SkipZeroQty,map<string, string>& APLModuleSubChildRelation,multimap<string, string>& ERCModuleSubChildRelation,set<string>& APLModuleuniqPart,set<string>& ERCModuleuniqPart,multimap<string, string>& AplErcPartInfo,multimap<string, string>& APLModuleSubChilduniqPart,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap,multimap<string, string>& ERCParentLevelMap);

int get_aplsubchild(int count, char* PChlPrtno,char* APLParentNum,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,multimap<string, string>& APLModuleSubChildRelation,multimap<string, string>& AplErcPartInfo,map<string, string>& APLModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap);
int get_ercsubchild(int count, char* PChlPrtno,char* ERCParentNum,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,multimap<string, string>& ERCModuleSubChildRelation,multimap<string, string>& AplErcPartInfo,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& ERCParentLevelMap);

char *removeSpecialChar(char *in);
char *removeChar(char *in);

//std::map<std::string, string> APLModuleSubChildRelation;
//std::map<std::string, string> ERCModuleSubChildRelation;

//multimap<string, string> APLModuleSubChildRelation;
//multimap<string, string> ERCModuleSubChildRelation;
//
//set<string> APLModuleuniqPart;		
//set<string> ERCModuleuniqPart;	
//
//multimap<string, string> AplErcPartInfo;		
//multimap<string, string> ErcpartInfo;
//
//multimap<string, string> APLModuleSubChilduniqPart;
//multimap<string, string> ERCModuleSubChilduniqPart;
//
//multimap<string, string> APLParentLevelMap;
//multimap<string, string> ERCParentLevelMap;

//std::map<std::string, string> APLModuleSubChilduniqPart;
//std::map<std::string, string> ERCModuleSubChilduniqPart;
//
//std::map<string, string> APLParentLevelMap;
//std::map<std::string, string> ERCParentLevelMap;

void setFindTag(tag_t *objlist, int count, tag_t obj, int *found)
{
	int k = 0;
	*found = -1;

	for (k = 0; k < count; k++)
	{

		if (objlist[k] == obj)
		{
			*found = k;
			break;
		}
	}
}

/* Function to add string into a set of string */
void setuidAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void setAddTagObj(int *count, tag_t **objlist, tag_t obj)
{

	*count = *count + 1;
	if (*count == 1)
	{
		// printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count) * sizeof(tag_t));
	}
	else
	{
		// printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist), (*count) * sizeof(tag_t));
	}

	(*objlist)[*count - 1] = obj; // malloc((strlen(view_id)+1) * sizeof(char));
}


char *removeChar(char *in)
{
	//printf("\n Inside Function removeChar \n");
	fflush(stdout);
	int i, j;
	char *tmp;
	tmp = (char *)malloc(strlen(in) + 2);
	i = 0;
	j = 0;
	while (in[j])
	{
		// if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\n' && in[j] != '\r')
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i] = '\0';

	return tmp;
}

char *removeSpecialChar(char *in)
{
	//printf("\n Inside (Space Exclude) Function removeSpecialChar \n");
	fflush(stdout);
	int i, j;
	char *tmp;
	tmp = (char *)malloc(strlen(in) + 2);
	i = 0;
	j = 0;
	while (in[j])
	{
		// if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\x01' && in[j] != '\x02' && in[j] != '\x03' && in[j] != '\x04' && in[j] != '\x05' && in[j] != '\x06' && in[j] != '\x07' && in[j] != '\x08' && in[j] != '\x09' && in[j] != '\x10' && in[j] != '\x11' && in[j] != '\x12' && in[j] != '\x13' && in[j] != '\x14' && in[j] != '\x15' && in[j] != '\x16' && in[j] != '\x17' && in[j] != '\x18' && in[j] != '\x19' /*&& in[j] != '\x20'*/ && in[j] != '\x21')
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i] = '\0';

	return tmp;
}


void getPlantCSandStoreLoc(char* inp_Plant,tag_t* child,char* &PlantCS,char* &PlantStoreLoc)
{
	printf("\n Inside getPlantCSandStoreLoc \n");fflush(stdout);

	tc_strcpy(PlantCS,"");
	tc_strcpy(PlantStoreLoc,"");

	if (strcmp(inp_Plant, "DHARWAD") == 0)
	{
		printf("\n Inside DWD \n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_DwdMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_DwdStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "CVBU Pune") == 0)
	{
		printf("\n Inside CVBU Pune \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PunMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PunStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "PUVBU") == 0)
	{
		printf("\n Inside PUVBU \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PunUVMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PunUVStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "CAR") == 0)
	{
		printf("\n Inside CAR \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_CarMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_CarStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "CVBU JSR") == 0)
	{
		printf("\n Inside CVBU JSR \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_JsrMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_JsrStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "CVBU LKO") == 0)
	{
		printf("\n Inside CVBU LKO \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_LkoMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_LkoStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "AHD") == 0)
	{
		printf("\n Inside AHD \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_AhdMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_AhdStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "CVBU PNR") == 0)
	{
		printf("\n Inside CVBU PNR \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PnrMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_PnrStoreLocation", &PlantStoreLoc));
	}
	else if (strcmp(inp_Plant, "TMLDL JSR") == 0)
	{
		printf("\n Inside TMLDL JSR \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_JdlMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_JdlStoreLocation", &PlantStoreLoc));
	}
	else
	{
		printf("\n Inside other \n");
		fflush(stdout);
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_AhdMakeBuyIndicator", &PlantCS));
		ITK_CALL(AOM_ask_value_string(child, "bl_Design Revision_t5_AhdStoreLocation", &PlantStoreLoc));
	}
}


int get_top_line_property(tag_t top_line,char* InputPart, char* inp_level, char* inp_RemoveUnderscorePart, char* inp_Plant, char* inp_StopatF, char* inp_SkipZeroQty,multimap<string, string>& APLModuleSubChildRelation,multimap<string, string>& ERCModuleSubChildRelation,set<string>& APLModuleuniqPart,set<string>& ERCModuleuniqPart,multimap<string, string>& AplErcPartInfo,map<string, string>& APLModuleSubChilduniqPart,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap,multimap<string, string>& ERCParentLevelMap)
{
	char *top_line_sChlPrtno = NULL;
	char *top_line_level = NULL;
	char *top_line_revision = NULL;
	char *top_line_Description = NULL;
	char *top_line_DesignGrp = NULL;
	char *top_line_PartType = NULL;
	char *top_line_quantity = NULL;
	char *top_line_release_status_list = NULL;
	char *top_line_Description1 = NULL;
	char *top_line_Description2 = NULL;
	char *top_line_Release_Status1 = NULL;
	char *top_line_Release_Status2 = NULL;
	char *top_line_CItemRev = NULL;
	char *top_line_PlantCS = NULL;
	char *top_line_PlantStoreLoc1 = NULL;
	char *top_line_PlantStoreLoc = NULL;
	char *topobjprtno = NULL;

	tag_t top_line_bl_rev = NULLTAG;

	int top_line_StopExpand = 1;
	int found;

	printf("\n ~~~~~~~~~ Amar Inside get_top_line_property Funtion ~~~~~~~~~~~\n");fflush(stdout);

	ITK_CALL(AOM_ask_value_tag(top_line, "bl_revision", &top_line_bl_rev));

	 setFindTag(UPartList,UPartListCount,top_line_bl_rev,&found);
	 if(found==-1)
	{
		setAddTagObj(&UPartListCount,&UPartList,top_line_bl_rev);
	 }
	 else
	{
		printf("\n Already Exist \n");fflush(stdout);
	 }

	// Getting DML from top_line partnumber
	ITK_CALL(AOM_ask_value_string(top_line_bl_rev, "item_revision_id", &top_line_CItemRev));

	// Getting Plant CS for top_line
	printf("\n Now Finding CS and StoreLoc as per Input Plant For top_line ==>  %s \n", inp_Plant);fflush(stdout);

	getPlantCSandStoreLoc(inp_Plant,top_line,top_line_PlantCS,top_line_PlantStoreLoc1);

	printf("\n Amar top_line_PlantCS is ==> %s and top_line_PlantStoreLoc1 is => %s For %s Plant \n",top_line_PlantCS, top_line_PlantStoreLoc1,inp_Plant);fflush(stdout);

	STRNG_replace_str(top_line_PlantStoreLoc1,"\r\n","",&top_line_PlantStoreLoc);
	//top_line_PlantStoreLoc = removeSpecialChar(top_line_PlantStoreLoc1);
	printf("\n top_line_PlantStoreLoc => %s \n", top_line_PlantStoreLoc);

	// Stop at F
	printf("\n inp_StopatF => %s \n", inp_StopatF);
	fflush(stdout);
	top_line_StopExpand = 1;
	if (tc_strcmp(inp_StopatF, "+") == 0)
	{
		if (tc_strstr(top_line_PlantCS, "F") != NULL)
		{
			printf("\n skip F CS \n");
			fflush(stdout);
			top_line_StopExpand = 0;
		}
	}

	//printf("\n Checking TOP BOM-Line Property \n");fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_level_starting_0", &top_line_level));
	int level1 = atoi(top_line_level);

	ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &top_line_sChlPrtno));
	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_rev_item_revision_id", &top_line_revision));

	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_rev_object_desc", &top_line_Description1));

	STRNG_replace_str(top_line_Description1, ",", ";", &top_line_Description2);
	STRNG_replace_str(top_line_Description2, "\n", ";", &top_line_Description);

	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_quantity", &top_line_quantity));

	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_Design Revision_t5_DesignGrp", &top_line_DesignGrp));

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PartType",&top_line_PartType));

	ITK_CALL(AOM_UIF_ask_value(top_line, "bl_rev_release_status_list", &top_line_Release_Status1));
	STRNG_replace_str(top_line_Release_Status1, ",", ";", &top_line_Release_Status2);
	STRNG_replace_str(top_line_Release_Status2, "\n", ";", &top_line_release_status_list);
	
	printf("\n Printing TOP BOM-Line Property is -> \n");fflush(stdout);

	printf("\t InputPart		==> %s \n", InputPart);fflush(stdout);
	printf("\t top_line_sChlPrtno		==> %s \n", top_line_sChlPrtno);fflush(stdout);
	printf("\t top_line_revision		==> %s \n", top_line_revision);fflush(stdout);
	printf("\t top_line_Description		==> %s \n", top_line_Description);fflush(stdout);
	printf("\t top_line_quantity		==> %s \n", top_line_quantity);fflush(stdout);
	printf("\t top_line_PlantCS		==> %s \n", top_line_PlantCS);fflush(stdout);
	printf("\t top_line_PlantStoreLoc		==> %s \n", top_line_PlantStoreLoc);fflush(stdout);
	printf("\t top_line_DesignGrp		==> %s \n", top_line_DesignGrp);fflush(stdout);
	printf("\t top_line_release_status_list	==> %s \n", top_line_release_status_list);fflush(stdout);


	ITK_CALL(AOM_ask_value_string(top_line, "object_string", &topobjprtno));
	printf("\n topobjprtno => %s\n", topobjprtno);fflush(stdout);

	//char* mapValueTop = (char *)MEM_alloc(1000 * sizeof(char *));
	//
	//if (tc_strcmp(top_line_PartType, "Group Id") != 0)
	//{
	//
	//	tc_strcat(mapValueTop, top_line_revision);
	//	tc_strcat(mapValueTop, ",");
	//	tc_strcat(mapValueTop,top_line_PartType);
	//	tc_strcat(mapValueTop,",");
	//	tc_strcat(mapValueTop, top_line_Description);
	//	tc_strcat(mapValueTop, ",");
	//	tc_strcat(mapValueTop, top_line_PlantCS);
	//	tc_strcat(mapValueTop, ",");
	//	tc_strcat(mapValueTop, top_line_PlantStoreLoc);
	//	tc_strcat(mapValueTop, ",");
	//	tc_strcat(mapValueTop, top_line_DesignGrp);
	//	tc_strcat(mapValueTop, ",");
	//	tc_strcat(mapValueTop, top_line_release_status_list);
	//
	//	//AplErcPartInfo.insert(std::pair<std::string, std::string>(topobjprtno, mapValueTop));
	//	AplErcPartInfo.insert(std::pair<std::string, std::string>(top_line_sChlPrtno, mapValueTop));
	//
	//}

	char* mapValueTop = (char *)MEM_alloc(1000);
		if (mapValueTop != NULL) {
		    mapValueTop[0] = '\0';  // Initialize string
		
		    tc_strcat(mapValueTop, top_line_revision);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_PartType);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_Description);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_PlantCS);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_PlantStoreLoc);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_DesignGrp);
		    tc_strcat(mapValueTop, ",");
		    tc_strcat(mapValueTop, top_line_release_status_list);
		
		    AplErcPartInfo.insert(std::pair<std::string, std::string>(top_line_sChlPrtno, mapValueTop));
			printf("\n Amar mapValueTop is: %s  \n",mapValueTop);fflush(stdout);
		    MEM_free(mapValueTop);
		    mapValueTop = NULL;
		}


	if ((tc_strstr(topobjprtno, "B4Z01") != NULL) || (tc_strstr(topobjprtno, "B5Z01") != NULL))
	{
		APLModuleuniqPart.insert(std::string(topobjprtno));
	}

}

int get_aplsubchild(int count, char* PChlPrtno,char* APLParentNum,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,multimap<string, string>& APLModuleSubChildRelation,multimap<string, string>& AplErcPartInfo,map<string, string>& APLModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap)
{

	int ifail = ITK_ok;
	int i, z, count1, attr;
	int level2 = atoi(inp_level);
	
	int StopExpand		= 1;

	char *s							= NULL;
	char *sChlPrtno					= NULL;
	char *level						= NULL;
	char *revision					= NULL;
	char *revision_temp				= NULL;
	char *Description				= NULL;
	char *Description1				= NULL;
	char *Description2				= NULL;
	char *DesignGrp					= NULL;
	char *PartType					= NULL;	
	char *quantity					= NULL;
	char *release_status_list		= NULL;
	char *Release_Status1			= NULL;
	char *Release_Status2			= NULL;
	
	char *Desc2						= NULL;
	char *CItemName					= NULL;
	char *PlantCS					= NULL;
	char *PlantStoreLoc1			= NULL;
	char *PlantStoreLoc				= NULL;
	char *rules_configured_by		= NULL;
	char *objprtno					= NULL;
		
	tag_t bl_rev			= NULLTAG;
	tag_t *sub_child		= NULLTAG;
	

	printf("\n ~~~~~~~~~ Amar Inside get_aplsubchild Funtion ~~~~~~~~~~~\n");fflush(stdout);

	for (i = 0; i < count; i++)
	{

		printf("\n Inside Loop of [%d] Child \n", i + 1);fflush(stdout);

		if( AOM_ask_value_string(child[i],"bl_config_string",&rules_configured_by));
		printf("\n getChildObjectsInView:..rules_configured_by: %s \n", rules_configured_by);fflush(stdout);
		if (tc_strcmp(rules_configured_by, "No configured Revision") == 0)
		{
			printf("\n skipping as no configured revision: \n");fflush(stdout);
			continue;
		}

		ITK_CALL(AOM_ask_value_tag(child[i], "bl_revision", &bl_rev));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_PartType", &PartType));
		if ( (tc_strcmp(PartType, "Dummy") == 0) || (tc_strcmp(PartType, "Dummy Component") == 0) || (tc_strcmp(PartType, "Information Fitment Drawing") == 0) || (tc_strcmp(PartType, "CAD Module") == 0))
		{
			printf("\n Inside Skip part type is => %s \n", PartType);fflush(stdout);
			continue;
		}


		CItemName = NULL;
		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &CItemName));
		printf("\n child CItemName => %s \n", CItemName);fflush(stdout);
		

		// Getting Plant CS
		printf("\n Now Finding CS and StoreLoc as per Input Plant for Child ==>  %s \n", inp_Plant);fflush(stdout);

		getPlantCSandStoreLoc(inp_Plant,child[i],PlantCS,PlantStoreLoc1);

		printf("\n Amar PlantCS ==> %s and PlantStoreLoc1 => %s For %s Plant \n",PlantCS, PlantStoreLoc1,inp_Plant);fflush(stdout);

		STRNG_replace_str(PlantStoreLoc1,"\r\n","",&PlantStoreLoc);

		printf("\n PlantStoreLoc => %s \n", PlantStoreLoc);

		// Stop at F
		printf("\n inp_StopatF => %s \n", inp_StopatF);fflush(stdout);
		StopExpand = 1;
		if (tc_strcmp(inp_StopatF, "+") == 0)
		{
			if (tc_strstr(PlantCS, "F") != NULL)
			{	
				printf("\n skip F CS \n");fflush(stdout);
				StopExpand = 0;
			}
		}

		// Removing UnderScore Parts
		printf("\n inp_RemoveUnderscorePart => %s \n", inp_RemoveUnderscorePart);fflush(stdout);
		if (tc_strcmp(inp_RemoveUnderscorePart, "+") == 0)
		{
			if (tc_strstr(CItemName, "_") != NULL)
			{
				printf("\n Got underscorepart :%s \n", CItemName);fflush(stdout);
				continue;
			}
		}


		printf("\n Checking Child BOM-Line Property \n");fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_level_starting_0", &level));
		int level1 = atoi(level);

		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &sChlPrtno));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_item_revision_id", &revision_temp));
		printf("\n Child revision_temp is => %s\n", revision_temp);fflush(stdout);

		if (tc_strstr(revision_temp, ",") != NULL)
		{
			ITK_CALL(STRNG_replace_str(revision_temp,",",";",&revision));
			printf ( "\n revision is -------> %s\n",revision);fflush(stdout);
		}
		else
		{
			tc_strcpy(revision,revision_temp);
		}

		// Description //
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_object_desc", &Description1));
		printf("\n Before Description1 => %s \n", Description1);fflush(stdout);
		Description2 = removeSpecialChar(Description1);
		STRNG_replace_str(Description2, ",", ";", &Desc2);
		printf("\n test Desc2 => %s \n", Desc2);fflush(stdout);
		Description = removeChar(Desc2);
		printf("\n After Description => %s \n", Description);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_quantity", &quantity));
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_DesignGrp", &DesignGrp));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_release_status_list", &Release_Status1));
		STRNG_replace_str(Release_Status1, ",", ";", &Release_Status2);
		STRNG_replace_str(Release_Status2, "\n", ";", &release_status_list);

		printf("\n inp_SkipZeroQty => %s\n", inp_SkipZeroQty);fflush(stdout);
		if (tc_strcmp(inp_SkipZeroQty, "+") == 0)
		{
			if (atoi(quantity) == 0)
			{
				printf("\n Skipping 0 Qty => %s \n", sChlPrtno);fflush(stdout);
				continue;
			}
		}

		printf("\n get_aplsubchild part Details of Loop => [%d] \n", i+1);fflush(stdout);

		printf("\t APL Childs PChlPrtno		=> %s \n", PChlPrtno);fflush(stdout);
		printf("\t APL Childs sChlPrtno		=> %s \n", sChlPrtno);fflush(stdout);
		printf("\t APL Childs revision		=> %s \n", revision_temp);fflush(stdout);
		printf("\t APL Childs PartType		=> %s \n", PartType);fflush(stdout);
		printf("\t APL Childs Description		=> %s \n", Description);fflush(stdout);
		printf("\t APL Childs quantity		=> %s \n", quantity);fflush(stdout);
		printf("\t APL Childs PlantCS		=> %s \n", PlantCS);fflush(stdout);
		printf("\t APL Childs PlantStoreLoc		=> %s \n", PlantStoreLoc);fflush(stdout);
		printf("\t APL Childs DesignGrp		=> %s \n", DesignGrp);fflush(stdout);
		printf("\t APL Childs release_status_list	=> %s \n", release_status_list);fflush(stdout);
		

		ITK_CALL(AOM_ask_value_string(child[i], "object_string", &objprtno));
		printf("\n objprtno => %s\n", objprtno);fflush(stdout);
		
		//char* mapValue = NULL;
		//mapValue = (char *)MEM_alloc(1000 * sizeof(char *));
		//
		//tc_strcat(mapValue,revision_temp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PartType);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,Description);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantCS);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantStoreLoc);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,DesignGrp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,release_status_list);
		//
		////AplErcPartInfo.insert(std::pair<std::string, std::string>(objprtno, mapValue));
		//AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));

		char* mapValue = (char *)MEM_alloc(1000);
		if (mapValue != NULL) {
		    mapValue[0] = '\0';  // Initialize string
		
		    tc_strcat(mapValue, revision_temp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PartType);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, Description);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantCS);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantStoreLoc);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, DesignGrp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, release_status_list);
		
		    AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));
			printf("\n Amar mapValue is: %s  \n",mapValue);fflush(stdout);
		    MEM_free(mapValue);
		    mapValue = NULL;
		}
	
	//This For Immediate Parent and Bom Level
	//char* AplmapValue = NULL;
	//AplmapValue = (char *) MEM_alloc( 100 * sizeof(char) );
	//
	//tc_strcat(AplmapValue,level);
	//tc_strcat(AplmapValue,",");
	//tc_strcat(AplmapValue,PChlPrtno);
	//
	//printf("\n Amar test %s  \n",AplmapValue);fflush(stdout);
	//
	//APLParentLevelMap.insert(std::pair<std::string, std::string>(sChlPrtno, AplmapValue));
	//	
	//	
	//printf("\n Amar Inside Fun APLParentNum is  => %s and sChlPrtno is : %s \n", APLParentNum,sChlPrtno);fflush(stdout);

	char* AplmapValue = (char *)MEM_alloc(100);
	if (AplmapValue != NULL) {
	    AplmapValue[0] = '\0';  // Initialize the string
	
	    tc_strcat(AplmapValue, level);
	    tc_strcat(AplmapValue, ",");
	    tc_strcat(AplmapValue, PChlPrtno);
	
	    printf("\n Amar test AplmapValue : %s  \n", AplmapValue); fflush(stdout);
	
	    APLParentLevelMap.insert(std::pair<std::string, std::string>(sChlPrtno, AplmapValue));
	
	    printf("\n Amar Inside Fun APLParentNum is  => %s and sChlPrtno is : %s \n", APLParentNum, sChlPrtno); fflush(stdout);
	
	    MEM_free(AplmapValue);
	    AplmapValue = NULL;
	}
	
	//APLModuleSubChildRelation.insert(std::pair<std::string, std::string>(APLParentNum, sChlPrtno));
	APLModuleSubChildRelation.insert(std::pair<std::string, std::string>(sChlPrtno, APLParentNum));

	int newQty = std::stoi(quantity);
    if (APLModuleSubChilduniqPart.find(sChlPrtno) != APLModuleSubChilduniqPart.end()) {
        // Convert existing quantity to integer, add new quantity, and store back as string
		printf("\n Inside Already sChlPrtno in  APLModuleSubChilduniqPart \n");fflush(stdout);
        int existingQty = std::stoi(APLModuleSubChilduniqPart[sChlPrtno]);
		std::cout << "existingQty of APL is : " << existingQty << std::endl;
        APLModuleSubChilduniqPart[sChlPrtno] = std::to_string(existingQty + newQty);
    } else {
        // Insert new part with given quantity
        APLModuleSubChilduniqPart[sChlPrtno] = quantity;
    }

	//int newQty = std::stoi(quantity);
	//
	//auto range = APLModuleSubChilduniqPart.equal_range(sChlPrtno);
	// 
	//if (range.first != range.second) {
	//
	//    printf("\n Inside Already sChlPrtno in  APLModuleSubChilduniqPart \n");fflush(stdout);
	//
	//    // Assume only one value per key logically for this context
	//
	//    // So take the first and update it (or sum over all if needed)
	//
	//    auto it = range.first;
	//
	//    int existingQty = std::stoi(it->second);
	//
	//    std::cout << "existingQty of APL is : " << existingQty << std::endl;
	// 
	//    // Erase all existing entries with that key (if you want to keep only one)
	//
	//    APLModuleSubChilduniqPart.erase(sChlPrtno);
	// 
	//    // Insert the updated quantity
	//
	//    APLModuleSubChilduniqPart.insert(std::make_pair(sChlPrtno, std::to_string(existingQty + newQty)));
	//
	//} else {
	//
	//    APLModuleSubChilduniqPart.insert(std::make_pair(sChlPrtno, quantity));
	//
	//}


	// Recurrsive Function or Find Multilevel Assembly
	ITK_CALL(BOM_line_ask_all_child_lines(child[i], &count1, &sub_child));
	printf("\n Number Of Sub-Childs => %d", count1);fflush(stdout);
	printf("\n StopExpand => %d\n", StopExpand);fflush(stdout);

	printf("\n Currnt level1 => %d Input Level is %d \n", level1,level2);fflush(stdout);

		if (count1 > 0 && level1 < level2 && StopExpand == 1)
		{
			printf("\n Inside Sub-Childs \n");fflush(stdout);

			get_aplsubchild(count1, sChlPrtno,APLParentNum,sub_child, "99", inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,APLModuleSubChildRelation,AplErcPartInfo,APLModuleSubChilduniqPart,APLParentLevelMap);

		}
	
	}

	printf("\n End of Sub Child Function....\n\n");fflush(stdout);

	return ifail;
}

int get_ercsubchild(int count, char* PChlPrtno,char* ERCParentNum,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,multimap<string, string>& ERCModuleSubChildRelation,multimap<string, string>& AplErcPartInfo,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& ERCParentLevelMap)
{
	
	int ifail = ITK_ok;
	int i, z, count1, attr;
	int level2 = atoi(inp_level);
	
	int StopExpand		= 1;

	char *s							= NULL;
	char *sChlPrtno					= NULL;
	char *level						= NULL;
	char *revision					= NULL;
	char *revision_temp				= NULL;
	char *Description				= NULL;
	char *Description1				= NULL;
	char *Description2				= NULL;
	char *DesignGrp					= NULL;
	char *PartType					= NULL;	
	char *quantity					= NULL;
	char *release_status_list		= NULL;
	char *Release_Status1			= NULL;
	char *Release_Status2			= NULL;
	
	char *Desc2						= NULL;
	char *CItemName					= NULL;
	char *PlantCS					= NULL;
	char *PlantStoreLoc1			= NULL;
	char *PlantStoreLoc				= NULL;
	char *rules_configured_by		= NULL;
	char *objprtno					= NULL;
		
	tag_t bl_rev			= NULLTAG;
	tag_t *sub_child		= NULLTAG;
	
	printf("\n ~~~~~~~~~ Amar Inside get_ercsubchild Funtion ~~~~~~~~~~~\n");fflush(stdout);

	for (i = 0; i < count; i++)
	{

		printf("\n Inside Loop of [%d] Child \n", i + 1);fflush(stdout);

		if( AOM_ask_value_string(child[i],"bl_config_string",&rules_configured_by));
		printf("\n getChildObjectsInView:..rules_configured_by: %s \n", rules_configured_by);fflush(stdout);
		if (tc_strcmp(rules_configured_by, "No configured Revision") == 0)
		{
			printf("\n skipping as no configured revision: \n");fflush(stdout);
			continue;
		}

		ITK_CALL(AOM_ask_value_tag(child[i], "bl_revision", &bl_rev));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_PartType", &PartType));
		if ( (tc_strcmp(PartType, "Dummy") == 0) || (tc_strcmp(PartType, "Dummy Component") == 0) || (tc_strcmp(PartType, "Information Fitment Drawing") == 0) || (tc_strcmp(PartType, "CAD Module") == 0))
		{
			printf("\n Inside Skip part type is => %s \n", PartType);fflush(stdout);
			continue;
		}

		CItemName = NULL;
		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &CItemName));
		printf("\n child CItemName => %s \n", CItemName);
		fflush(stdout);

		// Getting Plant CS
		printf("\n Now Finding CS and StoreLoc as per Input Plant for Child ==>  %s \n", inp_Plant);fflush(stdout);

		getPlantCSandStoreLoc(inp_Plant,child[i],PlantCS,PlantStoreLoc1);

		printf("\n Amar PlantCS ==> %s and PlantStoreLoc1 => %s For %s Plant \n",PlantCS, PlantStoreLoc1,inp_Plant);fflush(stdout);

		STRNG_replace_str(PlantStoreLoc1,"\r\n","",&PlantStoreLoc);
		printf("\n PlantStoreLoc => %s \n", PlantStoreLoc);

		// Stop at F
		printf("\n inp_StopatF => %s \n", inp_StopatF);fflush(stdout);
		StopExpand = 1;
		if (tc_strcmp(inp_StopatF, "+") == 0)
		{
			if (tc_strstr(PlantCS, "F") != NULL)
			{	
				printf("\n skip F CS \n");fflush(stdout);
				StopExpand = 0;
			}
		}

		// Removing UnderScore Parts
		printf("\n inp_RemoveUnderscorePart => %s \n", inp_RemoveUnderscorePart);fflush(stdout);
		if (tc_strcmp(inp_RemoveUnderscorePart, "+") == 0)
		{
			if (tc_strstr(CItemName, "_") != NULL)
			{
				printf("\n Got underscorepart :%s \n", CItemName);fflush(stdout);
				continue;
			}
		}


		printf("\n Checking Child BOM-Line Property \n");fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_level_starting_0", &level));
		int level1 = atoi(level);

		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &sChlPrtno));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_item_revision_id", &revision_temp));
		printf("\n Child revision_temp is => %s\n", revision_temp);fflush(stdout);

		if (tc_strstr(revision_temp, ",") != NULL)
		{
			ITK_CALL(STRNG_replace_str(revision_temp,",",";",&revision));
			printf ( "\n revision is -------> %s\n",revision);fflush(stdout);
		}
		else
		{
			tc_strcpy(revision,revision_temp);
		}

		// Description //
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_object_desc", &Description1));
		printf("\n Before Description1 => %s \n", Description1);fflush(stdout);
		Description2 = removeSpecialChar(Description1);
		STRNG_replace_str(Description2, ",", ";", &Desc2);
		printf("\n test Desc2 => %s \n", Desc2);fflush(stdout);
		Description = removeChar(Desc2);
		printf("\n After Description => %s \n", Description);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_quantity", &quantity));
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_DesignGrp", &DesignGrp));

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_release_status_list", &Release_Status1));
		STRNG_replace_str(Release_Status1, ",", ";", &Release_Status2);
		STRNG_replace_str(Release_Status2, "\n", ";", &release_status_list);

		printf("\n inp_SkipZeroQty => %s\n", inp_SkipZeroQty);fflush(stdout);
		if (tc_strcmp(inp_SkipZeroQty, "+") == 0)
		{
			if (atoi(quantity) == 0)
			{
				printf("\n Skipping 0 Qty => %s \n", sChlPrtno);fflush(stdout);
				continue;
			}
		}

		printf("\n get_ercsubchild part Details of Loop => [%d] \n", i+1);fflush(stdout);

		printf("\t ERC Childs PChlPrtno		=> %s \n", PChlPrtno);fflush(stdout);
		printf("\t ERC Childs sChlPrtno		=> %s \n", sChlPrtno);fflush(stdout);
		printf("\t ERC Childs revision		=> %s \n", revision_temp);fflush(stdout);
		printf("\t ERC Childs PartType		=> %s \n", PartType);fflush(stdout);
		printf("\t ERC Childs Description		=> %s \n", Description);fflush(stdout);
		printf("\t ERC Childs quantity		=> %s \n", quantity);fflush(stdout);
		printf("\t ERC Childs PlantCS		=> %s \n", PlantCS);fflush(stdout);
		printf("\t ERC Childs PlantStoreLoc		=> %s \n", PlantStoreLoc);fflush(stdout);
		printf("\t ERC Childs DesignGrp		=> %s \n", DesignGrp);fflush(stdout);
		printf("\t ERC Childs release_status_list	=> %s \n", release_status_list);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[i], "object_string", &objprtno));
		printf("\n objprtno => %s\n", objprtno);fflush(stdout);
		
		//char* mapValue = NULL;
		//mapValue = (char *)MEM_alloc(1000 * sizeof(char *));
		//
		//tc_strcat(mapValue,revision_temp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PartType);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,Description);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantCS);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantStoreLoc);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,DesignGrp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,release_status_list);
		//	
		//AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));

		char* mapValue = (char *)MEM_alloc(1000);
		if (mapValue != NULL) {
		    mapValue[0] = '\0';  // Initialize string
		
		    tc_strcat(mapValue, revision_temp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PartType);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, Description);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantCS);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantStoreLoc);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, DesignGrp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, release_status_list);
		
		    AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));
			printf("\n Amar mapValue is: %s  \n",mapValue);fflush(stdout);
		    MEM_free(mapValue);
		    mapValue = NULL;
		}

		//This For Immediate Parent and Bom Level

		//char* ErcmapValue = NULL;
		//ErcmapValue = (char *) MEM_alloc( 100 * sizeof(char) );
		//
		//tc_strcat(ErcmapValue,level);
		//tc_strcat(ErcmapValue,",");
		//tc_strcat(ErcmapValue,PChlPrtno);
		//
		//printf("\n Amar test ErcmapValue : %s  \n",ErcmapValue);fflush(stdout);
		//
		//ERCParentLevelMap.insert(std::pair<std::string, std::string>(sChlPrtno, ErcmapValue));
		//
		//printf("\n Amar Inside Fun ERCParentNum is  => %s and sChlPrtno is : %s \n", ERCParentNum,sChlPrtno);fflush(stdout);
		

		char* ErcmapValue = (char *)MEM_alloc(100);
		if (ErcmapValue != NULL) {
		    ErcmapValue[0] = '\0';  // Initialize the string
		
		    tc_strcat(ErcmapValue, level);
		    tc_strcat(ErcmapValue, ",");
		    tc_strcat(ErcmapValue, PChlPrtno);
		
		    printf("\n Amar test ErcmapValue : %s  \n", ErcmapValue); fflush(stdout);
		
		    ERCParentLevelMap.insert(std::pair<std::string, std::string>(sChlPrtno, ErcmapValue));
		
		    printf("\n Amar Inside Fun ERCParentNum is  => %s and sChlPrtno is : %s \n", ERCParentNum, sChlPrtno); fflush(stdout);
		
		    MEM_free(ErcmapValue);
		    ErcmapValue = NULL;
		}
		
		//ERCModuleSubChildRelation.insert(std::pair<std::string, std::string>(ERCParentNum, sChlPrtno));
		ERCModuleSubChildRelation.insert(std::pair<std::string, std::string>(sChlPrtno, ERCParentNum));

		// Convert quantity string to integer
		int newQty = std::stoi(quantity);
		
		if (ERCModuleSubChilduniqPart.find(sChlPrtno) != ERCModuleSubChilduniqPart.end()) {
		    // Convert existing quantity to integer, add new quantity, and store back as string
			printf("\n Inside Already sChlPrtno in  ERCModuleSubChilduniqPart \n");fflush(stdout);
		    int existingQty = std::stoi(ERCModuleSubChilduniqPart[sChlPrtno]);
			std::cout << "existingQty of ERC is : " << existingQty << std::endl;
		    ERCModuleSubChilduniqPart[sChlPrtno] = std::to_string(existingQty + newQty);
		} else {
		    // Insert new part with given quantity
		    ERCModuleSubChilduniqPart[sChlPrtno] = quantity;
		}

		//int newQty = std::stoi(quantity);
		//
		//auto range = ERCModuleSubChilduniqPart.equal_range(sChlPrtno);
		// 
		//if (range.first != range.second) {
		//
		//    printf("\n Inside Already sChlPrtno in  ERCModuleSubChilduniqPart \n");fflush(stdout);
		//
		//    // Assume only one value per key logically for this context
		//
		//    // So take the first and update it (or sum over all if needed)
		//
		//    auto it = range.first;
		//
		//    int existingQty = std::stoi(it->second);
		//
		//    std::cout << "existingQty of APL is : " << existingQty << std::endl;
		// 
		//    // Erase all existing entries with that key (if you want to keep only one)
		//
		//    ERCModuleSubChilduniqPart.erase(sChlPrtno);
		// 
		//    // Insert the updated quantity
		//
		//    ERCModuleSubChilduniqPart.insert(std::make_pair(sChlPrtno, std::to_string(existingQty + newQty)));
		//
		//} else {
		//
		//    ERCModuleSubChilduniqPart.insert(std::make_pair(sChlPrtno, quantity));
		//
		//}
	

		// Recurrsive Function or Find Multilevel Assembly
		ITK_CALL(BOM_line_ask_all_child_lines(child[i], &count1, &sub_child));
		printf("\n Number Of Sub-Childs => %d", count1);fflush(stdout);
		printf("\n StopExpand => %d\n", StopExpand);fflush(stdout);

		printf("\n Currnt level1 => %d Input Level is %d \n", level1,level2);fflush(stdout);

		if (count1 > 0 && level1 < level2 && StopExpand == 1)
		{
			printf("\n Inside Sub-Childs \n");fflush(stdout);

			get_ercsubchild(count1, sChlPrtno,ERCParentNum,sub_child, inp_level, inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,ERCModuleSubChildRelation, AplErcPartInfo,ERCModuleSubChilduniqPart,ERCParentLevelMap);
		}

		
	}

	printf("\n End of Sub Child Function....\n\n");fflush(stdout);

	return ifail;
}

int get_child(int count, char* PChlPrtno,tag_t *child, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,multimap<string, string>& APLModuleSubChildRelation,multimap<string, string>& ERCModuleSubChildRelation,set<string>& APLModuleuniqPart,set<string>& ERCModuleuniqPart,multimap<string, string>& AplErcPartInfo,map<string, string>& APLModuleSubChilduniqPart,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap,multimap<string, string>& ERCParentLevelMap)
{
	
	int ifail = ITK_ok;
	int i, z, count1, attr;
	int level2 = atoi(inp_level);
	int CountTask		= 0;
	int iTask			= 0;
	int CountDML		= 0;
	int iDML			= 0;
	int StopExpand		= 1;
	int found			= 1;
	int CountErcDml		= 0;
	int eDml			= 0;
	int ruleConfigByID	= 0;
	int Gcount			= 0;
	int k			= 0;

	char *name						= NULL;
	char *sChlPrtno					= NULL;
	char *level						= NULL;
	char *revision					= NULL;
	char *revision_temp				= NULL;
	char *Description				= NULL;
	char *Description1				= NULL;
	char *Description2				= NULL;
	char *ProjectCode				= NULL;
	char *DesignGrp					= NULL;
	char *PartType					= NULL;
	
	
	char *quantity					= NULL;
	char *release_status_list		= NULL;
	char *Release_Status1			= NULL;
	char *Release_Status2			= NULL;
	char *Desc2						= NULL;

	char *CItemName					= NULL;
	char *PlantCS					= NULL;
	char *PlantStoreLoc1			= NULL;
	char *PlantStoreLoc				= NULL;
	char *rules_configured_by		= NULL;
	char *objprtno					= NULL;
	
	tag_t bl_rev			= NULLTAG;
	tag_t *sub_child		= NULLTAG;
	

	printf("\n ~~~~~~~~~ Amar Inside get_child Funtion ~~~~~~~~~~~\n");fflush(stdout);

	for (i = 0; i < count; i++)
	{

		printf("\n Inside Loop of [%d] Child \n", i + 1);fflush(stdout);

		if( AOM_ask_value_string(child[i],"bl_config_string",&rules_configured_by));
		printf("\n getChildObjectsInView:..rules_configured_by: %s \n", rules_configured_by);fflush(stdout);
		if (tc_strcmp(rules_configured_by, "No configured Revision") == 0)
		{
			printf("\n skipping as no configured revision: \n");fflush(stdout);
			continue;
		}

		ITK_CALL(AOM_ask_value_tag(child[i], "bl_revision", &bl_rev));

		CItemName = NULL;
		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &CItemName));
		printf("\n child CItemName => %s \n", CItemName);
		fflush(stdout);

		// Getting Plant CS
		printf("\n Now Finding CS and StoreLoc as per Input Plant for Child ==>  %s \n", inp_Plant);fflush(stdout);

		getPlantCSandStoreLoc(inp_Plant,child[i],PlantCS,PlantStoreLoc1);

		printf("\n Amar PlantCS ==> %s and PlantStoreLoc1 => %s For %s Plant \n",PlantCS, PlantStoreLoc1,inp_Plant);fflush(stdout);

		STRNG_replace_str(PlantStoreLoc1,"\r\n","",&PlantStoreLoc);

		//PlantStoreLoc = removeSpecialChar(PlantStoreLoc1);
		printf("\n PlantStoreLoc => %s \n", PlantStoreLoc);

		// Stop at F
		printf("\n inp_StopatF => %s \n", inp_StopatF);fflush(stdout);
		StopExpand = 1;
		if (tc_strcmp(inp_StopatF, "+") == 0)
		{
			if (tc_strstr(PlantCS, "F") != NULL)
			{	
								
				//poParts.insert(std::string(CItemName));
				
				printf("\n skip F CS \n");fflush(stdout);
				StopExpand = 0;
			}
		}

		// Removing UnderScore Parts
		printf("\n inp_RemoveUnderscorePart => %s \n", inp_RemoveUnderscorePart);fflush(stdout);
		if (tc_strcmp(inp_RemoveUnderscorePart, "+") == 0)
		{
			if (tc_strstr(CItemName, "_") != NULL)
			{
				printf("\n Got underscorepart :%s \n", CItemName);fflush(stdout);
				continue;
			}
		}


		printf("\n Checking Child BOM-Line Property \n");fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_level_starting_0", &level));
		int level1 = atoi(level);

		ITK_CALL(AOM_ask_value_string(child[i], "bl_item_item_id", &sChlPrtno));
		//printf("\n sChlPrtno => %s\n", sChlPrtno);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_item_revision_id", &revision_temp));
		printf("\n Child revision_temp is => %s\n", revision_temp);fflush(stdout);

		if (tc_strstr(revision_temp, ",") != NULL)
		{
			ITK_CALL(STRNG_replace_str(revision_temp,",",";",&revision));
			printf ( "\n revision is -------> %s\n",revision);fflush(stdout);
		}
		else
		{
			tc_strcpy(revision,revision_temp);
			printf("\t inside else revision	is	=> %s \n", revision);fflush(stdout);
		}

		// Description //
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_object_desc", &Description1));
		printf("\n Before Description1 => %s \n", Description1);fflush(stdout);
		Description2 = removeSpecialChar(Description1);
		STRNG_replace_str(Description2, ",", ";", &Desc2);
		printf("\n test Desc2 => %s \n", Desc2);fflush(stdout);
		Description = removeChar(Desc2);
		printf("\n After Description => %s \n", Description);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_quantity", &quantity));
		//printf("\n quantity => %s\n", quantity);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_DesignGrp", &DesignGrp));
		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_PartType", &PartType));
		//printf("\n PartType => %s\n", PartType);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i], "bl_rev_release_status_list", &Release_Status1));
		STRNG_replace_str(Release_Status1, ",", ";", &Release_Status2);
		STRNG_replace_str(Release_Status2, "\n", ";", &release_status_list);

		printf("\n inp_SkipZeroQty => %s\n", inp_SkipZeroQty);fflush(stdout);
		if (tc_strcmp(inp_SkipZeroQty, "+") == 0)
		{
			if (atoi(quantity) == 0)
			{
				printf("\n Skipping 0 Qty => %s \n", sChlPrtno);fflush(stdout);
				continue;
			}
		}

		printf("\n Child part Details of Loop => [%d] \n", i+1);fflush(stdout);

		printf("\t PChlPrtno		=> %s \n", PChlPrtno);fflush(stdout);
		printf("\t sChlPrtno		=> %s \n", sChlPrtno);fflush(stdout);
		printf("\t revision		=> %s \n", revision_temp);fflush(stdout);
		printf("\t PartType		=> %s \n", PartType);fflush(stdout);
		printf("\t Description		=> %s \n", Description);fflush(stdout);
		printf("\t quantity		=> %s \n", quantity);fflush(stdout);
		printf("\t PlantCS		=> %s \n", PlantCS);fflush(stdout);
		printf("\t PlantStoreLoc		=> %s \n", PlantStoreLoc);fflush(stdout);
		printf("\t DesignGrp		=> %s \n", DesignGrp);fflush(stdout);
		printf("\t release_status_list	=> %s \n", release_status_list);fflush(stdout);
		

		ITK_CALL(AOM_ask_value_string(child[i], "object_string", &objprtno));
		printf("\n objprtno => %s\n", objprtno);fflush(stdout);

		//char* mapValue					= NULL;
		//mapValue = (char *)MEM_alloc(1000 * sizeof(char *));
		//
		//tc_strcat(mapValue,revision_temp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PartType);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,Description);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantCS);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,PlantStoreLoc);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,DesignGrp);
		//tc_strcat(mapValue,",");
		//tc_strcat(mapValue,release_status_list);
		//
		//AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));

		char* mapValue = (char *)MEM_alloc(1000);
		if (mapValue != NULL) {
		    mapValue[0] = '\0';  // Initialize string
		
		    tc_strcat(mapValue, revision_temp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PartType);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, Description);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantCS);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, PlantStoreLoc);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, DesignGrp);
		    tc_strcat(mapValue, ",");
		    tc_strcat(mapValue, release_status_list);
		
		    AplErcPartInfo.insert(std::pair<std::string, std::string>(sChlPrtno, mapValue));
		    MEM_free(mapValue);
		    mapValue = NULL;
		}

		int AplModcount=0;
		int ErcModcount=0;
		tag_t* Aplchild=NULLTAG;
		tag_t* Ercchild=NULLTAG;

		char *APLParentNum = NULL;
		APLParentNum = (char *)MEM_alloc(20 * sizeof(char *));

		char *ERCParentNum = NULL;
		ERCParentNum = (char *)MEM_alloc(20 * sizeof(char *));
		
		if ((tc_strstr(objprtno, "B4Z01") != NULL) || (tc_strstr(objprtno, "B5Z01") != NULL))
		{
			APLModuleuniqPart.insert(std::string(objprtno));

			ITK_CALL(BOM_line_ask_all_child_lines(child[i], &AplModcount, &Aplchild));
			printf("\n Number Of APL Sub-Childs => %d of APL part %s \n", AplModcount,objprtno);fflush(stdout);

			tc_strcpy(APLParentNum,sChlPrtno);
			printf("\n Amar APLParentNum is  => %s \n", APLParentNum);fflush(stdout);
			
			get_aplsubchild(AplModcount, sChlPrtno,APLParentNum,Aplchild, "99", inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,APLModuleSubChildRelation,AplErcPartInfo,APLModuleSubChilduniqPart,APLParentLevelMap);

			printf("\n Amar Printing APL Subchild parts ....\n\n");fflush(stdout);
			//std::set<std::string>::iterator it;
			//for (it = APLModuleSubChilduniqPart.begin(); it != APLModuleSubChilduniqPart.end(); ++it) {
			//    std::cout <<" Amar APL Module Child is : "<< *it << std::endl;
			//}

			 // Print the map contents
			for (const auto& pair : APLModuleSubChilduniqPart) {
				
			    std::cout << "Amar APL Part: " << pair.first << ", Quantity: " << pair.second << std::endl;
			}
		}

		if ((tc_strstr(objprtno,"B1A01")!= NULL) || (tc_strstr(objprtno,"B1A02")!= NULL)
			|| (tc_strstr(objprtno,"B1B01")!= NULL) || (tc_strstr(objprtno,"B1B02")	!= NULL)
			|| (tc_strstr(objprtno,"B1B03")!= NULL) || (tc_strstr(objprtno,"B1B04")	!= NULL)
			|| (tc_strstr(objprtno,"B1C01")!= NULL) || (tc_strstr(objprtno,"B1C03")	!= NULL)
			|| (tc_strstr(objprtno,"B1C04")!= NULL) || (tc_strstr(objprtno,"B1C05")	!= NULL)
			|| (tc_strstr(objprtno,"B1D01")!= NULL) || (tc_strstr(objprtno,"B1E01")	!= NULL)
			|| (tc_strstr(objprtno,"B2A01")!= NULL) || (tc_strstr(objprtno,"B2A02")	!= NULL)
			|| (tc_strstr(objprtno,"B2A03")!= NULL) || (tc_strstr(objprtno,"B2B01")	!= NULL)
			|| (tc_strstr(objprtno,"B2B02")!= NULL) || (tc_strstr(objprtno,"B2B03")	!= NULL)
			|| (tc_strstr(objprtno,"B2B04")!= NULL) || (tc_strstr(objprtno,"B2C01")	!= NULL)
			|| (tc_strstr(objprtno,"B2C02")!= NULL) || (tc_strstr(objprtno,"B2D01")	!= NULL)
			|| (tc_strstr(objprtno,"B2E01")!= NULL) || (tc_strstr(objprtno,"B3A01")	!= NULL)
			|| (tc_strstr(objprtno,"B3A02")!= NULL) || (tc_strstr(objprtno,"B3A03")	!= NULL)
			|| (tc_strstr(objprtno,"B3A04")!= NULL) || (tc_strstr(objprtno,"B3A05")	!= NULL)
			|| (tc_strstr(objprtno,"B3A06")!= NULL) || (tc_strstr(objprtno,"B3A07")	!= NULL)
			|| (tc_strstr(objprtno,"B3A08")!= NULL))
		{
			printf("\n Amar Inside ERC child parts ....\n\n");fflush(stdout);
			ERCModuleuniqPart.insert(std::string(objprtno));

			ITK_CALL(BOM_line_ask_all_child_lines(child[i], &ErcModcount, &Ercchild));
			printf("\n Number Of ERC Sub-Childs => %d of ERC part %s \n", ErcModcount,objprtno);fflush(stdout);

			tc_strcpy(ERCParentNum,sChlPrtno);
			printf("\n Amar ERCParentNum is  => %s \n", ERCParentNum);fflush(stdout);

			get_ercsubchild(ErcModcount, sChlPrtno,ERCParentNum,Ercchild, "99", inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,ERCModuleSubChildRelation, AplErcPartInfo,ERCModuleSubChilduniqPart,ERCParentLevelMap);

			printf("\n Amar Printing ERC Subchild parts ....\n\n");fflush(stdout);
			//std::set<std::string>::iterator it;
			//for (it = ERCModuleSubChilduniqPart.begin(); it != ERCModuleSubChilduniqPart.end(); ++it) {
			//    std::cout <<" Amar ERC Module Child is : "<< *it << std::endl;
			//}

			 // Print the map contents
			for (const auto& pair : ERCModuleSubChilduniqPart) {

			    std::cout << "Amar ERC Part: " << pair.first << ", Quantity: " << pair.second << std::endl;
			}

		}

		// Recurrsive Function or Find Multilevel Assembly
		ITK_CALL(BOM_line_ask_all_child_lines(child[i], &count1, &sub_child));
		printf("\n Number Of Sub-Childs => %d", count1);fflush(stdout);
		printf("\n StopExpand => %d\n", StopExpand);fflush(stdout);

		if (count1 > 0 && level1 < level2 && StopExpand == 1)
		{
			printf("\n Inside Sub-Childs \n");fflush(stdout);

			get_child(count1, sChlPrtno,sub_child, inp_level, inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,APLModuleSubChildRelation,ERCModuleSubChildRelation,APLModuleuniqPart,ERCModuleuniqPart,AplErcPartInfo,APLModuleSubChilduniqPart,ERCModuleSubChilduniqPart,APLParentLevelMap,ERCParentLevelMap);
		}
	}

	printf("\n End of Child Function....\n\n");fflush(stdout);
	
	//if(child)
	 //MEM_free(child);
	//if(sub_child)
	// MEM_free(sub_child);
	//if (mapValue)
	//	MEM_free(mapValue);

	return ifail;
}

int EbomMbomComparisionReportCall_internal(tag_t rev, char *inp_closure_rule, char *inp_revRule, char *inp_level, char *inp_RemoveUnderscorePart, char *inp_Plant, char *inp_StopatF, char *inp_SkipZeroQty,char *mailLOV,multimap<string, string>& APLModuleSubChildRelation,multimap<string, string>& ERCModuleSubChildRelation,set<string>& APLModuleuniqPart,set<string>& ERCModuleuniqPart,multimap<string, string>& AplErcPartInfo,map<string, string>& APLModuleSubChilduniqPart,map<string, string>& ERCModuleSubChilduniqPart,multimap<string, string>& APLParentLevelMap,multimap<string, string>& ERCParentLevelMap)
{

	int ifail = ITK_ok;
	int count;
	int rulefound = 0;

	char *s = NULL;
	char *PartType_bl = NULL;
	char *InputPart = NULL;
	char *Inputrev_id = NULL;
	char *InputPartobjstring = NULL;
	char *InputPartDesc = NULL;
	char *InputPartType = NULL;

	tag_t item = NULLTAG;
	tag_t *child = NULLTAG;
	tag_t window = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t close_tag = NULLTAG;

	char* PlantSAPCode = NULL;
	PlantSAPCode=MEM_alloc(10);

	printf("\n ~~~~~~~~~ Amar Inside EbomMbomComparisionReportCall_internal Funtion ~~~~~~~~~~~\n");fflush(stdout);

	InputPart = NULL;
	InputPartobjstring = NULL;
	ITK_CALL(AOM_ask_value_string(rev, "item_id", &InputPart));
	
	ITK_CALL(AOM_ask_value_string(rev, "current_revision_id", &Inputrev_id));
	
	ITK_CALL(AOM_ask_value_string(rev, "object_string", &InputPartobjstring));
	
	InputPartDesc = NULL;
	ITK_CALL(AOM_ask_value_string(rev, "object_desc", &InputPartDesc));
	
	InputPartType = NULL;
	ITK_CALL(AOM_UIF_ask_value(rev, "t5_PartType", &InputPartType));

	printf("\n InputPart		=> %s \n", InputPart);fflush(stdout);
	printf(" Inputrev_id		=> %s \n", Inputrev_id);fflush(stdout);
	printf(" InputPartobjstring	=> %s\n", InputPartobjstring);fflush(stdout);
	printf(" InputPart Description	=> %s\n", InputPartDesc);fflush(stdout);
	printf(" InputPart Type		=> %s\n", InputPartType);fflush(stdout);
	printf("\n closurerulename		=> %s\n", inp_closure_rule);	fflush(stdout);
	printf(" inp_revRule			=> %s\n", inp_revRule);	fflush(stdout);
	printf(" inp_level			=> %s\n", inp_level);	fflush(stdout);
	printf(" inp_RemoveUnderscorePart	=> %s\n", inp_RemoveUnderscorePart);	fflush(stdout);
	printf(" inp_Plant			=> %s\n", inp_Plant);	fflush(stdout);
	printf(" inp_StopatF			=> %s\n", inp_StopatF);	fflush(stdout);
	printf(" inp_SkipZeroQty		=> %s\n", inp_SkipZeroQty);	fflush(stdout);

	// ITK_CALL(AOM_UIF_ask_value(rev,"t5_PartType",&PartType_bl));
	ITK_CALL(AOM_ask_value_string(rev, "t5_PartType", &PartType_bl));

	printf("\n k PartType_bl => %s \n", PartType_bl);	fflush(stdout);


	// Find out the window
	ITK_CALL(BOM_create_window(&window));

	// Find revision rule
	ITK_CALL(CFM_find(inp_revRule, &rule));

	// Set revision rule
	ITK_CALL(BOM_set_window_config_rule(window, rule));
	ITK_CALL(BOM_set_window_pack_all(window, true));

	ITK_CALL(PIE_find_closure_rules2(inp_closure_rule, PIE_TEAMCENTER, &rulefound, &closurerule)); //

	printf("\n rule count => %d \n", rulefound);	fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = closurerule[0];
		printf("\n closure rule found \n");fflush(stdout);
	}
	if (tc_strcmp(PartType_bl, "Vehicle Combination") != 0)
	{
		printf("\n Applying closure_rule \n");fflush(stdout);
		ITK_CALL(BOM_window_set_closure_rule(window, close_tag, 0, NULL, NULL));
	}

	// Find out bom line tag
	ITK_CALL(BOM_set_window_top_line(window, item, rev, NULLTAG, &top_line));
	ITK_CALL(BOM_window_hide_unconfigured(window));

	//for hide suppresse part
	//ITK_CALL(BOM_window_hide_suppressed(window));
	
	//for Show suppresse part
	ITK_CALL(BOM_window_show_suppressed(window));

	//For Pack All
	ITK_CALL(BOM_set_window_pack_all(window, true));

	// Find out the all childs
	ITK_CALL(BOM_line_ask_all_child_lines(top_line, &count, &child));

	printf("\n Number Of Parent's Children Count is => [%d] \n", count);

	// Getting Topline property
	get_top_line_property(top_line,InputPart, inp_level, inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,APLModuleSubChildRelation,ERCModuleSubChildRelation,APLModuleuniqPart,ERCModuleuniqPart,AplErcPartInfo,APLModuleSubChilduniqPart,ERCModuleSubChilduniqPart,APLParentLevelMap,ERCParentLevelMap);
	// Getting Child property
	get_child(count,InputPart,child,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty,APLModuleSubChildRelation,ERCModuleSubChildRelation,APLModuleuniqPart,ERCModuleuniqPart,AplErcPartInfo,APLModuleSubChilduniqPart,ERCModuleSubChilduniqPart,APLParentLevelMap,ERCParentLevelMap);

	//close Bom Window
	if (window != NULLTAG)
		BOM_close_window(window);

	
	printf("\n ~~~~~~~~~ End Of EbomMbomComparisionReportCall_internal Function ~~~~~~~~~~~\n");fflush(stdout);

	return ifail;
}


int tm_EbomMbomComparisionReport_Call(void *return_data)
//int ITK_user_main(int argc, char *argv[])
{
	int ifail = ITK_ok;
	int z;	

	FILE *fp;
	FILE *fps;

	char *s			= NULL;
	
	tag_t item	= NULLTAG;
	tag_t rev	= NULLTAG;

	multimap<string, string> APLModuleSubChildRelation;
	multimap<string, string> ERCModuleSubChildRelation;
	
	set<string> APLModuleuniqPart;		
	set<string> ERCModuleuniqPart;	
	
	multimap<string, string> AplErcPartInfo;		
	multimap<string, string> ErcpartInfo;
	
	map<string, string> APLModuleSubChilduniqPart;
	map<string, string> ERCModuleSubChilduniqPart;
	
	multimap<string, string> APLParentLevelMap;
	multimap<string, string> ERCParentLevelMap;

	char *AllFileName = NULL;
	AllFileName = (char *)MEM_alloc(100 * sizeof(char *));

	USERSERVICE_array_t 	array_struct;

	printf("\n ~~~~~~~~~ Amar Start Program Of tm_EbomMbomComparisionReport_Call ~~~~~~~~~~~\n");fflush(stdout);

	// Start time measurement (wall-clock time)
    std::time_t start_time = std::time(nullptr);

    std::cout << "Amar Start time is : " << std::asctime(std::localtime( & start_time)) << std::endl;

	// Taking Inputs

	char *InputVC					= NULL;
	char *inp_Plant					= NULL;
	char *inp_closure_rule			= NULL;
	char *inp_revRule				= NULL;
	char *inp_level					= NULL;
	char *inp_RemoveUnderscorePart	= NULL;
	char *inp_StopatF				= NULL;
	char *inp_SkipZeroQty			= NULL;
	char *mailLOV					= NULL;

	USERARG_get_string_argument(&InputVC);				
	USERARG_get_string_argument(&inp_Plant);					
	USERARG_get_string_argument(&inp_closure_rule);			
	USERARG_get_string_argument(&inp_revRule);				
	USERARG_get_string_argument(&inp_level);					
	USERARG_get_string_argument(&inp_RemoveUnderscorePart);	
	USERARG_get_string_argument(&inp_StopatF);				
	USERARG_get_string_argument(&inp_SkipZeroQty);			
	USERARG_get_string_argument(&mailLOV);					

	printf("\n************************ Cammand Input ************************\n");fflush(stdout);

	printf("InputVC		=> %s\n", InputVC);fflush(stdout);
	printf("inp_Plant		=> %s\n", inp_Plant);fflush(stdout);
	printf("inp_closure_rule	=> %s\n", inp_closure_rule);fflush(stdout);
	printf("inp_revRule		=> %s\n", inp_revRule);fflush(stdout);
	printf("inp_level		=> %s\n", inp_level);fflush(stdout);
	printf("inp_RemoveUnderscorePart=> %s\n", inp_RemoveUnderscorePart);fflush(stdout);
	printf("inp_StopatF		=> %s\n", inp_StopatF);fflush(stdout);
	printf("inp_SkipZeroQty		=> %s\n", inp_SkipZeroQty);fflush(stdout);
	printf("mailLOV			=> %s", mailLOV);fflush(stdout);
	printf("\n***************************** End *****************************\n");fflush(stdout);

	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm *now_tm;
	time(&now);
	now_tm = localtime(&now);
	strftime(ReportFiredDate, 26, "%d-%B-%Y-%H-%M-%S", now_tm);
	printf("\n ReportFiredDate is	=> [%s]", ReportFiredDate);fflush(stdout);

	char *FileName = NULL;
	FileName = (char *)MEM_alloc(100 * sizeof(char *));

	char *FileNameSummary = NULL;
	FileNameSummary = (char *)MEM_alloc(100 * sizeof(char *));


	int i = 0;
	char *InputVcNo		= NULL;
	char *InputVcrev	= NULL;
	char *InputVcseq	= NULL;

	char* itemRevSeq = NULL;
	tag_t queryTag	= NULLTAG;
	tag_t* VCTag			= NULLTAG;
	tag_t VCItem	= NULLTAG;
		
	char *qry_entries[2] = {"Item ID","Revision"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	int resultCount = 0;

	int n_entries = 2;
	char *InputVcrevseq	= NULL;
	InputVcrevseq=(char *) MEM_alloc(50);

	if(QRY_find2("Unique RevSeq", &queryTag));


    // Tokenize the line using commas as the delimiter
    InputVcNo = strtok(InputVC, ",");
    InputVcrev = strtok(NULL, ",");
    InputVcseq = strtok(NULL, ",");

	printf("\n InputVcNo	=> %s\n", InputVcNo);fflush(stdout);
	printf("\n InputVcrev	=> %s\n", InputVcrev);fflush(stdout);
	printf("\n InputVcseq	=> %s\n", InputVcseq);fflush(stdout);

	strcpy(InputVcrevseq,InputVcrev);
	strcat(InputVcrevseq,"*");
	strcat(InputVcrevseq,InputVcseq);

	qry_values[0] = InputVcNo ;
	qry_values[1] = InputVcrevseq ;
	
	printf("\n Input qry_values is => %s\n", qry_values[0]);fflush(stdout);
	printf("\n Input qry_values is => %s\n", qry_values[1]);fflush(stdout);


	sprintf(FileName, "/tmp/EbomMbomComparisionReport_%s_%s.csv", InputVcNo, ReportFiredDate);
	printf("\n FileName		=> %s \n", FileName);fflush(stdout);

	fp = fopen(FileName, "w");

	//Printing in CSV File
	fprintf(fp, "EBOM MBOM Validation and Compliance Check\n\n"); fflush(fp);
	fprintf(fp, "%s,%s", "InputPart",InputVcNo); fflush(fp);	
	fprintf(fp, "\n %s,%s", "InputVcrevseq",InputVcrevseq);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_closure_rule",inp_closure_rule);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_revRule",inp_revRule);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_Plant",inp_Plant);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_level",inp_level);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_StopatF",inp_StopatF);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_RemoveUnderscorePart",inp_RemoveUnderscorePart);	fflush(fp);		
	fprintf(fp, "\n %s,%s", "inp_SkipZeroQty",inp_SkipZeroQty);	fflush(fp);		
	fprintf(fp, "\n %s,%s\n", "ReportFiredDate",ReportFiredDate);fflush(fp);
	fprintf(fp, "\n");fflush(fp);

	sprintf(FileNameSummary, "/tmp/EbomMbomComparisionSummaryReport_%s_%s.csv", InputVcNo, ReportFiredDate);
	printf("\n FileNameSummary		=> %s \n", FileNameSummary);fflush(stdout);
	
	fps = fopen(FileNameSummary, "w");
	
	fprintf(fps, "EBOM MBOM Validation and Compliance Check\n\n"); fflush(fp);
	fprintf(fps, "%s,%s", "Input Vehicle",InputVcNo); fflush(fp);	
	fprintf(fps, "\n%s,%s", "Input VC Rev & seq",InputVcrevseq);fflush(fp);		
	fprintf(fps, "\n%s,%s", "Input Closure Rule",inp_closure_rule);	fflush(fp);		
	fprintf(fps, "\n%s,%s", "Input Revision Rule",inp_revRule);	fflush(fp);		
	fprintf(fps, "\n%s,%s", "Input Plant",inp_Plant);	fflush(fp);		
	fprintf(fps, "\n%s,%s\n", "ReportFiredDate",ReportFiredDate);fflush(fp);
	fprintf(fps, "\n");fflush(fp);


	if (strlen(FileNameSummary) > 0) {
           strcpy(AllFileName, FileNameSummary);  
           strcat(AllFileName, "#");  
           strcat(AllFileName, FileName);  
       }
	
	printf("\n AllFileName		=> %s \n", AllFileName);fflush(stdout);
 	
	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &VCTag));
	printf("\n Input resultCount is => %d\n", resultCount);fflush(stdout);

	//if(resultCount>0)
	//{
	//	for (i = 0; i < resultCount; i++)
	//	{
	//		rev=VCTag[i];
	//		EbomMbomComparisionReportCall_internal(rev, inp_closure_rule, inp_revRule, inp_level, inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,mailLOV);
	//		
	//		printf("\n*********************************** Start EbomMbomComparisionReportCall_internal ***********************************\n");fflush(stdout);
	//		//Expand in ERC Context
	//		EbomMbomComparisionReportCall_internal(rev, "BOMViewClosureRuleERC", "ERC release and above", inp_level, inp_RemoveUnderscorePart, inp_Plant, inp_StopatF, inp_SkipZeroQty,mailLOV);
	//	}
	//}

	if (resultCount > 0)
	{
	    std::vector<std::pair<std::string, std::string>> ruleSets = {
	        {inp_closure_rule, inp_revRule},  // First rule set
	        {"GenTPLBOMViewClosureRuleERC", "ERC release and above"}  // Second rule set
	    };
	
	    for (i = 0; i < resultCount; i++)
	    {
	        rev = VCTag[i];
	
	        for (const auto rule : ruleSets)
	        {
	            printf("\n*********************************** Start EbomMbomComparisionReportCall_internal ***********************************\n");
	            fflush(stdout);
				std:cout << " rule.first : " << rule.first << " rule.second : "<<rule.second <<endl;
	
	            EbomMbomComparisionReportCall_internal(rev, 
	                                                   rule.first.c_str(), rule.second.c_str(), 
	                                                   inp_level, inp_RemoveUnderscorePart, 
	                                                   inp_Plant, inp_StopatF, 
	                                                   inp_SkipZeroQty, mailLOV,APLModuleSubChildRelation,
													   ERCModuleSubChildRelation,APLModuleuniqPart,ERCModuleuniqPart,
													   AplErcPartInfo,APLModuleSubChilduniqPart,ERCModuleSubChilduniqPart,
													   APLParentLevelMap,ERCParentLevelMap);
	        }
	    }
	}


	printf("\n*********************************** Amar Inside Main ***********************************\n");fflush(stdout);

	//Added by Amar
	printf("\n Amar Print APLModuleuniqPart.... \n\n");fflush(stdout);
	std::set<std::string>::iterator it;
	for (it = APLModuleuniqPart.begin(); it != APLModuleuniqPart.end(); ++it) {
	    std::cout <<" Amar APL Module is : "<< *it << std::endl;
	}
	
	printf("\n Amar Print ERCModuleuniqPart.... \n\n");fflush(stdout);
	std::set<std::string>::iterator it1;
	for (it1 = ERCModuleuniqPart.begin(); it1 != ERCModuleuniqPart.end(); ++it1) {
	    std::cout <<" Amar ERC Module is : "<< *it1 << std::endl;
	}
	
	printf("\n Amar Print APLModuleSubChilduniqPart.... \n\n");fflush(stdout);

	 // Print the map contents
    for (const auto& pair : APLModuleSubChilduniqPart) {
        std::cout << "APL Part: " << pair.first << ", Quantity: " << pair.second << std::endl;
    }
	
	printf("\n Amar Print ERCModuleSubChilduniqPart.... \n\n");fflush(stdout);

	 // Print the map contents
    for (const auto& pair : ERCModuleSubChilduniqPart) {
        std::cout << "ERC Part: " << pair.first << ", Quantity: " << pair.second << std::endl;
    }

		printf("\n Amar Print APLModuleSubChildRelation.... \n\n");fflush(stdout);

	 // Print the map contents
    for (const auto& pair : APLModuleSubChildRelation) {
        std::cout << "APL Child Part: " << pair.first << ", Parent Part: " << pair.second << std::endl;
    }
	

		printf("\n Amar Print ERCModuleSubChildRelation.... \n\n");fflush(stdout);

	 // Print the map contents
    for (const auto& pair : ERCModuleSubChildRelation) {
        std::cout << "ERC Child Part: " << pair.first << ", Parent Part is : " << pair.second << std::endl;
    }


// Writing header to the CSV file
fprintf(fp, "ParentPart APL,APL BOMLevel,Immediate parentAPL,childPart APL,Qty Of APLParts,ParentPart ERC,ERC BOMLevel,Immediate parentERC,ChildPart ERC,Qty Of ERCParts,Consume Status,Revision,Part Type,Description,PLant CS,Stroe Location,Design Group,Release Status\n");

	//main map is APLModuleSubChilduniqPart and secondary is ERCModuleSubChilduniqPart
	std::cout << "\nComparing values between APLModuleSubChilduniqPart and  ERCModuleSubChilduniqPart maps...\n" << std::endl;
	// Use the correct iterator type for a std::map
	std::map<std::string, std::string>::iterator itc;
	
	for (itc = APLModuleSubChilduniqPart.begin(); itc != APLModuleSubChilduniqPart.end(); ++itc) {
	    std::string partNumber = itc->first;
	    int aplQty = std::stoi(itc->second); // Convert quantity from string to int

		std::cout << "aplQty is : " << aplQty << std::endl;
	
	    auto ercIt = ERCModuleSubChilduniqPart.find(partNumber);
	
	    if (ercIt != ERCModuleSubChilduniqPart.end()) {
	        int ercQty = std::stoi(ercIt->second); // Convert ERC map quantity from string to int

			std::cout << "ercQty is : " << ercQty << std::endl;
	
	        if (aplQty == ercQty) {
	            std::cout << "Value: " << partNumber << " -> Status: Fully Consumed" << std::endl;
	        } else if (aplQty < ercQty) {
	            std::cout << "Value: " << partNumber << " -> Status: Partially Consumed" << std::endl;
	        } else { // aplQty > ercQty
	            std::cout << "Value: " << partNumber << " -> Status: Over Consumed" << std::endl;
	        }
	    } else {
	        std::cout << "Value: " << partNumber << " -> Status: Not Found in ERC But Present in APL" << std::endl;
	    }
	}
	
	//main map is ERCModuleSubChilduniqPart and secondary is APLModuleSubChilduniqPart
	std::cout << "\nComparing values between ERCModuleSubChilduniqPart and APLModuleSubChilduniqPart maps...\n" << std::endl;

	// Use the correct iterator type for a std::map
	std::map<std::string, std::string>::iterator itec;
	
	for (itec = ERCModuleSubChilduniqPart.begin(); itec != ERCModuleSubChilduniqPart.end(); ++itec) {
	    std::string partNumber = itec->first;
	    int ercQty = std::stoi(itec->second); // Convert ERC quantity from string to int
	
	    std::cout << "ercQty is : " << ercQty << std::endl;
	
	    auto aplIt = APLModuleSubChilduniqPart.find(partNumber);
	
	    if (aplIt != APLModuleSubChilduniqPart.end()) {
	        int aplQty = std::stoi(aplIt->second); // Convert APL map quantity from string to int
	
	        std::cout << "aplQty is : " << aplQty << std::endl;
	
	        if (aplQty == ercQty) {
	            std::cout << "Value: " << partNumber << " -> Status: Fully Consumed" << std::endl;
	        } else if (aplQty < ercQty) {
	            std::cout << "Value: " << partNumber << " -> Status: Over Consumed" << std::endl;
	        } else { // aplQty > ercQty
	            std::cout << "Value: " << partNumber << " -> Status: Partially Consumed" << std::endl;
	        }
	    } else {
	        std::cout << "Value: " << partNumber << " -> Status: Not Found in APL But Present in ERC" << std::endl;
	    }
	}


	
	 multimap <string, string>::iterator itt;
	
	printf("\n~~~~~~~~~ Final Now Printing Map Values AplErcPartInfo ~~~~~~~~~~~\n\n");fflush(stdout);
	
	 for (itt = AplErcPartInfo.begin(); itt != AplErcPartInfo.end(); ++itt)
	 {
		cout <<"Final Amar APL objprtno Key = "<< itt->first << endl << endl<< "mapValue = " << itt->second << endl << endl;
										  
	 }

	 printf("\n~~~~~~~~~ Printing Map Values APLParentLevelMap ~~~~~~~~~~~\n\n");fflush(stdout);
	
	multimap <string, string>::iterator ita;
	 for (ita = APLParentLevelMap.begin(); ita != APLParentLevelMap.end(); ++ita)
	 {
		cout <<" Amar APL Child Part = "<< ita->first << endl << endl<< "AplmapValue = " << ita->second << endl << endl;
										  
	 }

	 printf("\n~~~~~~~~~ Printing Map Values ERCParentLevelMap ~~~~~~~~~~~\n\n");fflush(stdout);
	
	multimap <string, string>::iterator ite;
	 for (ite = ERCParentLevelMap.begin(); ite != ERCParentLevelMap.end(); ++ite)
	 {
		cout <<" Amar ERC Child Part = "<< ite->first << endl << endl<< "ErcmapValue = " << ite->second << endl << endl;
										  
	 }

	printf("\n Amar Print Final Map APLModuleSubChilduniqPart & ERCModuleSubChilduniqPart.... \n\n");
	fflush(stdout);


//============================================================================================//

std::map<std::string, std::vector<std::string>> finalMap;
std::string status;
std::string qtyofpartERC;
std::string qtyofpartsAPL;
std::string childPart;
std::string parentPartAPL;
std::string partProp;
std::string childPartERC;
std::string parentPartERC;

std::string aplLevel;
std::string aplImmediateParent;
std::string ercLevel;
std::string ercImmediateParent;

for (const auto &entry : APLModuleSubChildRelation)
{
	childPart = entry.first;
	parentPartAPL = entry.second;

	// Reset per-iteration values
	childPartERC = "";
	parentPartERC = "";
	qtyofpartERC = "";
	status = "";
	partProp = "";
	qtyofpartsAPL = "";
	aplLevel = "";
	aplImmediateParent = "";
	ercLevel = "";
	ercImmediateParent = "";

	auto itaplsubapl = APLModuleSubChilduniqPart.find(childPart);
	if (itaplsubapl != APLModuleSubChilduniqPart.end())
	{
		qtyofpartsAPL = itaplsubapl->second;

		auto itAPLMap = APLParentLevelMap.find(childPart);
		if (itAPLMap != APLParentLevelMap.end()) {
			std::string value = itAPLMap->second;
			size_t commaPos = value.find(',');
			if (commaPos != std::string::npos) {
				aplLevel = value.substr(0, commaPos);
				aplImmediateParent = value.substr(commaPos + 1);
			}
		}

		auto itERCMap = ERCParentLevelMap.find(childPart);
		if (itERCMap != ERCParentLevelMap.end()) {
			std::string value = itERCMap->second;
			size_t commaPos = value.find(',');
			if (commaPos != std::string::npos) {
				ercLevel = value.substr(0, commaPos);
				ercImmediateParent = value.substr(commaPos + 1);
			}
		}

		auto itaplerc = AplErcPartInfo.find(childPart);
		if (itaplerc != AplErcPartInfo.end())
		{
			partProp = itaplerc->second;

			if (tc_strstr(partProp.c_str(), "ERC Released") == NULL)
			{
				status = "NA";
			}
			else
			{
				auto itERCMod = ERCModuleSubChildRelation.find(childPart);
				if (itERCMod != ERCModuleSubChildRelation.end())
				{
					childPartERC = itERCMod->first;
					parentPartERC = itERCMod->second;

					auto itaplsuberc = ERCModuleSubChilduniqPart.find(childPart);
					if (itaplsuberc != ERCModuleSubChilduniqPart.end())
					{
						qtyofpartERC = itaplsuberc->second;

						int aplQty = std::stoi(qtyofpartsAPL);
						int ercQty = std::stoi(qtyofpartERC);

						if (aplQty == ercQty) {
							status = "Matched";
						}
						else if (aplQty < ercQty) {
							status = "MBOM Part Qty is less than EBOM";
						}
						else {
							status = "MBOM Part Qty is greater than EBOM";
						}
					}
					else
					{
						status = "Part found in MBOM ; not available in EBOM";
					}
				}
				else
				{
					status = "Part found in MBOM ; not available in EBOM";
				}
			}
		}
	}

	// Logging for debug
	std::cout << "finalMap Amar childPart = " << childPart
		<< " parentPartAPL = " << parentPartAPL
		<< " qtyofpartsAPL = " << qtyofpartsAPL
		<< " childPartERC = " << childPartERC
		<< " parentPartERC = " << parentPartERC
		<< " qtyofpartERC = " << qtyofpartERC
		<< " partProp = " << partProp
		<< " status = " << status << std::endl;

	// Store in final map (exact 10 fields as per header)
	finalMap[childPart] = {
		parentPartAPL,        // 0: ParentPart APL
		aplLevel,             // 1: APL BOMLevel
		aplImmediateParent,   // 2: Immediate parentAPL
		childPart,            // 3: childPart APL
		qtyofpartsAPL,        // 4: Qty Of APLParts
		parentPartERC,        // 5: ParentPart ERC
		ercLevel,             // 6: ERC BOMLevel
		ercImmediateParent,   // 7: Immediate parentERC
		childPartERC,         // 8: ChildPart ERC
		qtyofpartERC,         // 9: Qty Of ERCParts
		status,               // 10: Consume Status
		partProp              // 11: partProp (optional extra column)
	};
}

// Handle parts present in ERC but missing in APL
for (const auto &entry : ERCModuleSubChildRelation)
{
	std::string childPartERC = entry.first;
	std::string parentPartERC = entry.second;

	if (APLModuleSubChildRelation.find(childPartERC) == APLModuleSubChildRelation.end())
	{
		std::string qtyofpartERC = "0";
		auto iterc = ERCModuleSubChilduniqPart.find(childPartERC);
		if (iterc != ERCModuleSubChilduniqPart.end())
		{
			qtyofpartERC = iterc->second;
		}

		std::string ercLevel, ercImmediateParent;
		auto itERCMap = ERCParentLevelMap.find(childPartERC);
		if (itERCMap != ERCParentLevelMap.end()) {
			std::string value = itERCMap->second;
			size_t commaPos = value.find(',');
			if (commaPos != std::string::npos) {
				ercLevel = value.substr(0, commaPos);
				ercImmediateParent = value.substr(commaPos + 1);
			}
		}

		std::string partProp = "";
		auto itpp = AplErcPartInfo.find(childPartERC);
		if (itpp != AplErcPartInfo.end())
		{
			partProp = itpp->second;
		}

		finalMap[childPartERC] = {
			"",                 // ParentPart APL
			"",                 // APL BOMLevel
			"",                 // Immediate parentAPL
			"",                 // childPart APL
			"",                 // Qty Of APLParts
			parentPartERC,      // ParentPart ERC
			ercLevel,           // ERC BOMLevel
			ercImmediateParent, // Immediate parentERC
			childPartERC,       // ChildPart ERC
			qtyofpartERC,       // Qty Of ERCParts
			"Part found in EBOM ; not available in MBOM",
			partProp
		};
	}
}

// Final Output to file (assuming 'fp' is a valid FILE*)
//fprintf(fp, "APL BOMLevel,Immediate parentAPL,ParentPart APL,childPart APL,Qty Of APLParts,ERC BOMLevel,Immediate parentERC,ParentPart ERC,ChildPart ERC,Qty Of ERCParts,Consume Status,partProp\n");

for (const auto &entry : finalMap)
{
	const std::vector<std::string> &values = entry.second;

	if (values.size() >= 11) {
		fprintf(fp, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
			values[0].c_str(), // ParentPart APL
			values[1].c_str(), // APL BOMLevel
			values[2].c_str(), // Immediate parentAPL
			values[3].c_str(), // childPart APL
			values[4].c_str(), // Qty Of APLParts
			values[5].c_str(), // ParentPart ERC
			values[6].c_str(), // ERC BOMLevel
			values[7].c_str(), // Immediate parentERC
			values[8].c_str(), // ChildPart ERC
			values[9].c_str(), // Qty Of ERCParts
			values[10].c_str(),// Consume Status
			values[11].c_str() // partProp
		);
	}
}

fclose(fp);

//============================================================================================//
//Added for Summary sheet
std::set<std::string> EBOM_ModuleSet = {
    "B1A01", "B1A02", "B1B01", "B1B02", "B1B03", "B1B04", "B1C01", "B1C03", "B1C04", "B1C05",
    "B1D01", "B1E01", "B2A01", "B2A02", "B2A03", "B2B01", "B2B02", "B2B03", "B2B04", "B2C01",
    "B2C02", "B2D01", "B2E01", "B3A01", "B3A02", "B3A03", "B3A04", "B3A05", "B3A06", "B3A07", "B3A08"
};

std::vector<std::string> aplModules = { "B4Z01", "B5Z01" };

std::map<std::string, std::string> ercModuleMap = {
    {"B1A01", "ROOF"},
    {"B1A02", "BODY SIDE OUTER"},
    {"B1B01", "FRONT DOOR APERTURE REINFORCEMENT"},
    {"B1B02", "FRONT DOOR APERTURE INNER"},
    {"B1B03", "ROOF FRONT STRUCTURE"},
    {"B1B04", "SHOTGUN OUTER ASSY"},
    {"B1C01", "REAR QUARTER INNER ASSY"},
    {"B1C03", "ROOF REAR STRUCTURE"},
    {"B1C04", "REAR TAILGATE SILL ASSY"},
    {"B1C05", "REAR WHEEL ARCH ASSY"},
    {"B1D01", "STATIC SEALING"},
    {"B1E01", "JOINERY DETAILS"},
    {"B2A01", "FRONT UNDERBODY FRAME"},
    {"B2A02", "FRONT CRASH MEMBER"},
    {"B2A03", "FRONT SUSPENSION TOWER AND WHEEL ARCH"},
    {"B2B01", "FRONT FLOOR ASSY"},
    {"B2B02", "FIREWALL ASSY"},
    {"B2B03", "COWL/PLENUM/WATER CHANNEL"},
    {"B2B04", "A PILLAR INNER & SIDE SILL ASSY"},
    {"B2C01", "REAR FLOOR ASSY"},
    {"B2C02", "REAR FRAME ASSY"},
    {"B2D01", "FRONT END MODULE"},
    {"B2E01", "JOINERY DETAILS*"},
    {"B3A01", "FENDER ASSEMBLY"},
    {"B3A02", "HOOD ASSEMBLY WITH HINGES"},
    {"B3A03", "FRONT DOOR BIW ASSEMBLY"},
    {"B3A04", "REAR DOOR BIW ASSEMBLY"},
    {"B3A05", "TAILGATE BIW ASSEMBLY WITH HINGES"},
    {"B3A06", "DOOR HINGES & FASTENERS"},
    {"B3A07", "DOOR FITMENT PARTS"},
    {"B3A08", "PAINT SHOP SEALANT & ANTI VIBRATION SHEETS- CLOSURES"}
};

std::map<std::string, std::string> aplModuleMap = {
    {"B4Z01", "BIW ASSEMBLY FOR MFG"},
    {"B5Z01", "BIW TCF BOLTABLE PARTS FOR MFG"}
};

fprintf(fps, "Module available in EBOM,,,,,APL added module,,,,\n");
fprintf(fps, "Sr.No,ERCModule address,ERCModule Name,ERC Part Number,APLModule address,APLModule Name,APL Part Number\n");

int srNo = 1;
auto ebomIt = EBOM_ModuleSet.begin();
auto aplIt = aplModules.begin();

while (ebomIt != EBOM_ModuleSet.end() || aplIt != aplModules.end()) {
    std::string ebomModule = (ebomIt != EBOM_ModuleSet.end()) ? *ebomIt : "";
    std::string ebomName = ercModuleMap.count(ebomModule) ? ercModuleMap[ebomModule] : "";

    std::string aplModule = (aplIt != aplModules.end()) ? *aplIt : "";
    std::string aplName = aplModuleMap.count(aplModule) ? aplModuleMap[aplModule] : "";

    const char* ercCol = "";
    for (const std::string& ercModule : ERCModuleuniqPart) {
        if (tc_strstr(ercModule.c_str(), ebomModule.c_str())) {
            ercCol = ercModule.c_str();
            break;
        }
    }

    const char* aplCol = "";
    for (const std::string& aplMod : APLModuleuniqPart) {
        if (tc_strstr(aplMod.c_str(), aplModule.c_str())) {
            aplCol = aplMod.c_str();
            break;
        }
    }

    fprintf(fps, "%d,%s,%s,%s,%s,%s,%s\n",
            srNo,
            ebomModule.c_str(), ebomName.c_str(), ercCol,
            aplModule.c_str(), aplName.c_str(), aplCol);

    if (ebomIt != EBOM_ModuleSet.end()) ++ebomIt;
    if (aplIt != aplModules.end()) ++aplIt;
    ++srNo;
}

// === Status counting logic ===
std::map<std::string, int> statusCount;
for (const auto& kv : finalMap) {
    const std::vector<std::string>& values = kv.second;
    if (values.size() >= 12) {
        statusCount[values[10]]++;
    }
}

fprintf(fps, "\n\nStatus Summary Analysis :\n");
fprintf(fps, "Category,Count,Status\n");

std::vector<std::string> categories = {
    "Matched",
    "MBOM Part Qty is greater than EBOM",
    "MBOM Part Qty is less than EBOM",
    "Part found in MBOM ; not available in EBOM",
    "Part found in EBOM ; not available in MBOM"
};

for (const std::string& category : categories) {
    int count = statusCount[category];
    const char* status = (category == "Matched" || count == 0) ? "Ok" : "NOT OK";
    fprintf(fps, "%s,%d,%s\n", category.c_str(), count, status);
}

fclose(fps);

//============================================================================================//


	int y=0;
	tag_t outobj=NULLTAG;

	char *ItemRev=NULL;
	char *ItemRevId=NULL;

	// Control Object for EXE
	char *qry_entries24[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char *qry_values24[3] = {"tm_EbomMbomComparisionReport", "tm_EbomMbomComparisionReport", "0"};

	tag_t qryTag = NULLTAG;
	int query_count;
	tag_t *query_result = NULLTAG;

	ITK_CALL(QRY_find2("Control Objects...", &qryTag));

	if (qryTag)
	{
		printf("\n Control Object Query Found \n");
		fflush(stdout);

		ITK_CALL(QRY_execute(qryTag, 3, qry_entries24, qry_values24, &query_count, &query_result));

		printf("\n query_count is : %d\n", query_count);
		fflush(stdout);

		if (query_count > 0)
		{
			char *t5_Userinfo2 = NULL;
			char cmd[500];
			tag_t obj = query_result[0];
			ITK_CALL(AOM_ask_value_string(obj, "t5_Userinfo2", &t5_Userinfo2));
			sprintf(cmd, "%s/communication_EbomMbomComparisionReport.sh %s %s", t5_Userinfo2, AllFileName, mailLOV);
			// sprintf(cmd,"%s/EXE_MultiVCGenTPL.sh %s %s %s %s %s %s %s %s %s",t5_Userinfo2,rev,inp_closure_rule,inp_revRule,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty,mailLOV);
			// sprintf(cmd,"%s -if=%s -im=%s &",t5_Userinfo2,VCList,MailList);
			printf("\n Amar Excuting Command = %s\n", cmd);
			fflush(stdout);
			// exit(0);
			system(cmd);
			printf("\n Amar After executing Command\n");
			fflush(stdout);
		}
	}


//============================================================================================//

	int buff_cnt = 0;
	char **uuids = NULL;
	
	for (const auto &entry : finalMap)
	{
	    const std::vector<std::string> &values = entry.second;
	
	    // Combine only the values into a single comma-separated string
	    std::string combined;
	    for (size_t i = 0; i < values.size(); ++i)
	    {
	        if (i > 0) combined += ",";
	        combined += values[i];
	    }
	
	    // Add this combined string to the string array
	    setuidAddStr(&buff_cnt, &uuids, (char *)combined.c_str());
	}
	
	// Print collected strings
	for (int g = 0; g < buff_cnt; g++)
	{
	    printf("\n Vall=%d %s", g, uuids[g]);
	    printf("\nuuids[%d] = %p -> %s\n", g, uuids[g], uuids[g]);
	}
	
	printf("\n Amar End of tm_SearchLatestPartFromItk_Call .....\n"); fflush(stdout);

	
	// Return the array to caller
	ITK_CALL(USERSERVICE_return_string_array((const char**)uuids, buff_cnt, &array_struct));
	if (array_struct.length != 0)
	    *((USERSERVICE_array_t*) return_data) = array_struct;
	
	 //Optional cleanup
	 //for (int i = 0; i < buff_cnt; ++i) free(uuids[i]);
	 //free(uuids);
	
//============================================================================================//
// End time measurement (wall-clock time)
    std::time_t end_time = std::time(nullptr);
    std::cout << "Amar End time is : " << std::asctime(std::localtime( & end_time)) << std::endl;

	// Calculate elapsed time in seconds
    double time_taken = std::difftime(end_time, start_time);

    // Convert seconds to minutes
    double time_taken_minutes = time_taken / 60.0;

    // Display the results
    std::cout << "\nTime taken: " << time_taken << " seconds.\n";
    std::cout << "Amar New Time taken To Complete Report: " << time_taken_minutes << " minutes.\n";
//============================================================================================//


	printf("\n Amar Code Ends here..... \n");fflush(stdout);
	

	return ifail;
} 


extern int tm_EbomMbomComparisionReportinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	int nargs1 = 9;
	int retValueType1;
	int inputArgTypes1[9] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE; 
	inputArgTypes1[3] = USERARG_STRING_TYPE; 
	inputArgTypes1[4] = USERARG_STRING_TYPE; 
	inputArgTypes1[5] = USERARG_STRING_TYPE; 
	inputArgTypes1[6] = USERARG_STRING_TYPE; 
	inputArgTypes1[7] = USERARG_STRING_TYPE; 
	inputArgTypes1[8] = USERARG_STRING_TYPE;  

	retValueType1 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE; 
	
	printf("\n tm_EbomMbomComparisionReportinitmodule before....tm_EbomMbomComparisionReport_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_EbomMbomComparisionReport_Call",(USER_function_t)tm_EbomMbomComparisionReport_Call,nargs1,inputArgTypes1,retValueType1);

	return ifail;	
}

extern "C" DLLAPI int tm_EbomMbomComparisionReport_register_callbacks()
{	
	int ifail    = ITK_ok;
	printf("\n Amar Before registoring userservice....tm_EbomMbomComparisionReport");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_EbomMbomComparisionReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_EbomMbomComparisionReportinitmodule);
	printf("\n Amar After registoring userservice....tm_EbomMbomComparisionReport");fflush(stdout);
	return ( ITK_ok );
}