/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Abhilash
*  Module               :   Workflow Rule Handler to check if Manageer has filled required attributes 
*  Code                 :   CM_Checklist_Signoff.c
*  Created on			:   Jul 27th, 2020
*  Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		CM_Checklist_Signoff
	Description			:		This handler checks if manager has filled all required attributes
*/

EPM_decision_t CM_Checklist_Signoff(EPM_rule_message_t msg)
{
	int   i							= 0;
	int   attachmentCount			= 0;
	char*   obj_type=NULL;
	tag_t rootTask_t				= NULLTAG;
	tag_t *taskAttachments			= NULLTAG;
	tag_t  objTypTag				= NULLTAG;	
	char*	 combo_4		= NULL;
	char*	 combo_7		= NULL;
	char*	 combo_9		= NULL;
	char*	 combo_41		= NULL;
	char*	 combo_10		= NULL;
	char*	 combo_11		= NULL;
	char*	 combo_12		= NULL;
	char*	 combo_22		= NULL;
	char*	 combo_36		= NULL;
	char*	 combo_13		= NULL;
	char*	 combo_23		= NULL;
	char*	 combo_25		= NULL;
	char*	 combo_26		= NULL;
	char*	 combo_27		= NULL;
	char*	 combo_28		= NULL;
	char*	 combo_18		= NULL;
	char*	 combo_33		= NULL;
	char*	 DMLno			= NULL;
	char*	 DMLtp			= NULL;
	char*	 CheckListType	= NULL;
	char*	 info1_value	= NULL;
	char*	 info5_value	= NULL;
	char*	 token			= NULL;
	int		Chk_count		=0;
	int		ijk				=0;
	int		sdk				=0;
	int		kk				=0;
	int		entry_c			=1;
	int		CtrObjQryCount	=0;
	int		rlsTypeFlag 	=0;
	tag_t	DMLRevTag		= NULLTAG;
	tag_t	Mani_Relation	=NULLTAG;
	tag_t	*DMLChkListSet	=NULLTAG;
	tag_t	DMLChkList		=NULLTAG;
	tag_t	CtrObjQry		=NULLTAG;
	tag_t	*CntObj_tag		=NULLTAG;

	char		*Qry_entry[1]	= {"SYSCD"};
	char		**Qry_values    = (char **) MEM_alloc(10 * sizeof(char *));

	EPM_decision_t decision = EPM_go;
	printf("\n CM_Checklist_Signoff Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Checklist_Signoff Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	
	if(attachmentCount >0)
	{
		for(i=0;i<attachmentCount;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&obj_type));
			printf("\n ********** CM_Checklist_Signoff Workfow obj type: [%s]*************\n", obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
			{
				printf("\n\t DML_Found \n");fflush(stdout);

				DMLRevTag=taskAttachments[i];

				ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLno));
				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtp));
				printf("\n\t MT: DMLno:%s ,DMLtype:%s \n",DMLno,DMLtp);fflush(stdout);


				if(QRY_find2("ControlObjects", &CtrObjQry));
				if (CtrObjQry)
				{
					printf("\n\t ControlObjects Query_found \n");fflush(stdout);
				}
				else
				{
					printf("\n\t ControlObjects Query_Not_Found \n");fflush(stdout);
				}

				Qry_values[0] = "ChkListRlsType" ;

				if(QRY_execute(CtrObjQry, entry_c, Qry_entry, Qry_values, &CtrObjQryCount, &CntObj_tag));
				printf("\n\t ControlObjects Count = %d \n",CtrObjQryCount);fflush(stdout);

				if(CtrObjQryCount>0)
				{
					kk=0;
					rlsTypeFlag=0;
					for (sdk=0; sdk < CtrObjQryCount; sdk++)
					{
						ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo1",&info1_value));

						token= tc_strtok(info1_value,";");
					
						while (token != NULL) 
						{ 
							printf("\t\n  DML Release type's are %s\n", token);
							

							if(tc_strcmp(DMLtp,token)==0)
							{
								rlsTypeFlag=1;
							}

							token = tc_strtok(NULL,";");
							kk++;
						}
					}
				}

				printf("\n\t rlsTypeFlag  = %d \n",rlsTypeFlag);fflush(stdout);

				//if(tc_strcmp(DMLtp,"MR")==0 || tc_strcmp(DMLtp,"EP")==0 || tc_strcmp(DMLtp,"CM")==0 || tc_strcmp(DMLtp,"KSP")==0) // changes needed
				if(rlsTypeFlag==1)
				{
					printf("\n\t DML type match.\n");fflush(stdout);

					ITK_CALL(GRM_find_relation_type("IMAN_manifestation", &Mani_Relation));
					ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,Mani_Relation,&Chk_count,&DMLChkListSet));

					printf("\n\t Checklist Count = [%d] \n\n",Chk_count);  fflush(stdout);
					
					if (Chk_count>0)
					{
						for (ijk=0; ijk < Chk_count; ijk++ )
						{
						
						
							ITK_CALL(AOM_ask_value_string(DMLChkListSet[ijk],"object_type",&CheckListType));
							printf("\n\t CheckListType is %s \n\n",CheckListType);  fflush(stdout);

							ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo5",&info5_value));

							//tc_strcpy(info5_value,"Y");
							if(tc_strstr(info5_value,"checklistON")==NULL) 
							{

								if(tc_strcmp(CheckListType,"T5_ERCDMLChecklist")==0)
								{
									DMLChkList = DMLChkListSet[ijk];

									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_AddToDF",&combo_4));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_ActComplDFMEA",&combo_7));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_DesRevRec",&combo_9));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_NwDmuRptAvl",&combo_41));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_DMLSubCorrt",&combo_10));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_DMLRsnCorrt",&combo_11));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_AffDesGrpIden",&combo_12));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_ColPrtInd",&combo_22));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_SprIndDef",&combo_36));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_NwPrtCatDef",&combo_13));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_NwCorUoMSel",&combo_23));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_HazMatCont",&combo_25));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_MatClsDef",&combo_26));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_WgtDef",&combo_27));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_IntrChnDef",&combo_28));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_ModDetStatCor",&combo_18));
									ITK_CALL(AOM_ask_value_string(DMLChkList,"t5_GrpWsData",&combo_33));	
									
									
									//tc_strcpy(combo_41,"Y");
									//tc_strcpy(combo_23,"Y");
									//tc_strcpy(combo_13,"Y");
											

								

									printf("\n t5_AddToDF =[%s]\n t5_ActComplDFMEA =[%s]\n t5_DesRevRec =[%s]\n t5_NwDmuRptAvl =[%s]\n t5_DMLSubCorrt =[%s]\n t5_DMLRsnCorrt =[%s]\n t5_AffDesGrpIden =[%s]\n t5_ColPrtInd =[%s]\n t5_SprIndDef =[%s]\n t5_NwPrtCatDef =[%s]\n t5_NwCorUoMSel =[%s]\n t5_HazMatCont =[%s]\n t5_MatClsDef =[%s]\n t5_WgtDef =[%s]\n t5_IntrChnDef =[%s]\n t5_ModDetStatCor =[%s]\n t5_DesignGrpCvrd =[%s]\n",combo_4,combo_7,combo_9,combo_41,combo_10,combo_11,combo_12,combo_22,combo_36,combo_13,combo_23,combo_25,combo_26,combo_27,combo_28,combo_18,combo_33); fflush(stdout);

									if(tc_strcmp(combo_4,"")==0||tc_strcmp(combo_7,"")==0 || tc_strcmp(combo_9,"")==0||tc_strcmp(combo_41,"")==0||tc_strcmp(combo_10,"")==0||tc_strcmp(combo_11,"")==0||tc_strcmp(combo_12,"")==0||tc_strcmp(combo_22,"")==0||tc_strcmp(combo_36,"")==0||tc_strcmp(combo_13,"")==0||tc_strcmp(combo_23,"")==0||tc_strcmp(combo_25,"")==0||tc_strcmp(combo_26,"")==0||tc_strcmp(combo_27,"")==0||tc_strcmp(combo_28,"")==0||tc_strcmp(combo_18,"")==0||tc_strcmp(combo_33,"")==0)
									{
										printf("\n\t Please fill all checkpoints and singed off");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err,"Please fill all checkpoints and singed off","\n Select DML revision > go to file > change classes > ERC DML checklist");
										decision = EPM_nogo;
										return decision;
										//return ITK_err;
										
										
									}
									else
									{
										printf("\n\t All checkpoints filled");fflush(stdout);
										//return EPM_go;	
										return decision;
									}
								}
						}
						printf("\n\t Checklist control Object of OFF \n\n");  fflush(stdout);
							
						}
						
					}
					
				}
				
			}
			
		}
	}
	printf("\n CM_Checklist_Signoff Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Checklist_Signoff Function end...");
	return decision;
}