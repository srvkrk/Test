/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_APLSTDSIFuncs.c
* Created By                   : Vishal Awari
* Created On                   : 03/05/2019
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*  1      1 Jun 19                                     Vishal                         Change in Shell Script Format
   2      20 Jun 19                                    Vishal 						  change path of Shell Script file to $TC_ROOT/bin/tml_tools	
   3      25 jun 19                                    Vishal 						  Change Handler Name to Avoid conflicts with other Handler 

****************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
//#include "tm_apl_std_common_function.c"	
#define MAX_LINE_LEN 1024



#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>
		
static void ECHO(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

;
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}


extern int CreateAmDmlGmDmlFnc( void *retValue)
{
	
	int				ifail 	= ITK_ok;
	char *gmtask_item= NULL;
	char *selectedPartItemName= NULL;
	char *selectedPartRev= NULL;
	char *userName= NULL;
	char *userRoleName= NULL;
	char command[512];
	char	*ExePath			=	NULL;

	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entry   = 3;
    int  control_found=0;	 
	tag_t *list_of_cntrl_tags=NULLTAG;

	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;	

	
	char** bufferedXmlStrOut;
	int buff_cnt=0;	
	int m =0;

	USERARG_get_string_argument(&gmtask_item);
	USERARG_get_string_argument(&selectedPartItemName);
	USERARG_get_string_argument(&selectedPartRev);
	USERARG_get_string_argument(&userName);
	USERARG_get_string_argument(&userRoleName);

		
		
	printf("\nArgument Received(CreateAmDmlGmDmlFnc) gmtask_item=%s\n",gmtask_item);fflush(stdout);	
	printf("Argument Received(CreateAmDmlGmDmlFnc) selectedPartItemName=%s\n",selectedPartItemName);fflush(stdout);	
	printf("Argument Received(CreateAmDmlGmDmlFnc) selectedPart Revision=%s\n",selectedPartRev);fflush(stdout);	
	printf("Argument Received(CreateAmDmlGmDmlFnc) userName=%s\n",userName);fflush(stdout);	
	printf("Argument Received(CreateAmDmlGmDmlFnc) userRoleName=%s\n",userRoleName);fflush(stdout);	

	
	
	printf("  Client Code Calling........... To Create AMDML for GMDML\n");fflush(stdout);
	
	//API change
     if(QRY_find2("Control Objects...", &qryTagCntrl)); //sachin
     
	 if (qryTagCntrl)
			{
		         char    
	             *qry_eCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"},
	             *qry_vCntrl[3]={"CreateAMDMLFRMGM","CreateAMDMLFRMGM","0"};
				 printf("\n Control Object Query Found \n");fflush(stdout);
			
				
				if(QRY_execute(qryTagCntrl, n_entry, qry_eCntrl, qry_vCntrl, &control_found, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found  \n");fflush(stdout);
			}	
			
			printf("\n control_number_found is : %d\n",control_found);fflush(stdout);

			if(control_found>0)
			{
				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo1", &ExePath);
				printf("\n ExePath: %s\n",ExePath);fflush(stdout);

				tc_strcpy(command,ExePath);
			    tc_strcat(command," ");
			    tc_strcat(command,gmtask_item);
			    tc_strcat(command," ");
			    tc_strcat(command,selectedPartItemName);
			    tc_strcat(command," '");
			    tc_strcat(command,selectedPartRev);
			    tc_strcat(command,"' ");
			    tc_strcat(command,userName);
				tc_strcat(command," ");
				tc_strcat(command,userRoleName);

			printf("\ncommand : %s",command);fflush(stdout);
			}
		 system(command);
	   

	   	
	
	m =0;
	printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	for(m=0;m<buff_cnt;m++)
	{
		printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}	
	printf("\nBefore returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);
	printf("\nAfter returning Value=%d",array_struct.length);fflush(stdout);
	
	if (array_struct.length != 0)
		*((USERSERVICE_array_t*) retValue) = array_struct;	
	 
	printf("\nAfter returning Value*******");fflush(stdout);
	 
	 return ifail;
}



extern int find_ip_address(char *ip_addressCpy) 
{  
    
	
	printf(" Inside Get System IP Address find_ip_address Function ");
     
	unsigned char ip_address[15];
    int fd;
    struct ifreq ifr;
     
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
     
    
    ifr.ifr_addr.sa_family = AF_INET;
     
   
    memcpy(ifr.ifr_name, "eth0", IFNAMSIZ-1);
     
   
    ioctl(fd, SIOCGIFADDR, &ifr);
    
    close(fd);
     
    
    strcpy(ip_address,inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
     
    printf("System IP Address is: %s\n",ip_address);
	
	tc_strcpy(ip_addressCpy,ip_address);
	
	
     
    return 0;
}








extern int GMDMLRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 5;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;

	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n CreateAmDmlGmDmlFnc before....CreateAmDmlGmDmlFncCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("CreateAmDmlGmDmlFnc",(USER_function_t)CreateAmDmlGmDmlFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}



extern int GMDMLFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	//CALLAPI(EBOMMBOMReportRegisterServiceFnc());
	
	GMDMLRegisterServiceFnc();
	
	return ifail;
	
}

extern DLLAPI int tm_CreateAmDmlGmDml_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n ** tm_CreateAmDmlGmDml_register_callbacks ** "); 
	printf("\n Before registoring userservice....");   
	ifail=CUSTOM_register_exit ( "tm_CreateAmDmlGmDml", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)GMDMLFuncServiceFnc);
	printf("\n After registoring userservice....");
	return ( ITK_ok );
}
