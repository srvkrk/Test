#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <sa/role.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tccore/item_msg.h>
#include <pie/pie.h>
#include <qry/qry.h>


#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define POM_enquiry_desc_order 1
#define POM_enquiry_like 16001

int cnt = 0;
int cntFlag = 0;

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;

// Structure Declaration
typedef enum MAIL_to_or_cc_e
{
	MAIL_send_to,
	MAIL_send_cc
}MAIL_to_or_cc_t;


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;


/* 
extern EPM_decision_t DLLAPI tryout_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
    int status3;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char * SetPrevRevNotification=NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char*  type_name = NULL;

	char*  type_itemRev = NULL;
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char*       roleName = NULL;
	char *lcsToset=NULL;
   cnt = 0;
   cntFlag = 0;

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Calling std_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_signoff_checks_Func \n"); fflush(stdout);


	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	
//	EPM_signoff_decision_t  	ddecision;
//	char * 	comments;
//	date_t  	decision_date;
//	EPM_ask_signoff_decision(rootTask,&ddecision,&comments,&decision_date);
//	
//	if(ddecision=EPM_approve_decision)
//	{
//		printf("\n\n  Approved"); fflush(stdout);
//	}
//	else if(ddecision=EPM_reject_decision)
//	{
//		printf("\n\n  Rejected"); fflush(stdout);
//	}
//	else if(ddecision=EPM_no_decision)
//	{
//		printf("\n\n  no dec "); fflush(stdout);
//	}
//	else
//	{
//			printf("\n\n  errrrrr"); fflush(stdout);
//	}
	

 	ITKCALL( TCTYPE_find_type("T5_TryoutRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL(  TCTYPE_ask_name2( objTypeTag, &type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL ( TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);

			if (!SetStdRelErr) MEM_free(SetStdRelErr);
			SetStdRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetStdRelErr,"");

			if(tc_strcmp(type_itemRev,"T5_TryoutRevision" )==0)
			{
					char*	VQAReviewer;
					char*	ManReviewer;
					char*	TSReviewer;
					char*	VDReviewer;
					char*	QAReviewer;
					char*	STDReviewer;
					char*	QAHead;
					char*	FactHead;
					char*	SCMReviewer;
					char*	TOBatchSize;
					char*	TOVenName;
					char **TOArea;
					char*	TOTryOutDt;
					char*	TOFitment;
					char*	TOBatchSize1;
					char*	TOVinNo;
					char*	TOVinNo1;
					char*	TOVinNo2;
					char*	TOVinNo3;
					char*	TOVinNo4;
					char *  Errr = NULL;
					char	intBatchSStr[50];
					char	VinCntStr[50];
					int numarea=0;

						if (tc_strcmp(Errr,"NULL") !=0) MEM_free(Errr);
						Errr=(char *)MEM_alloc(3000);
						tc_strcpy(Errr," ");


					ITKCALL(AOM_ask_value_string(item_rev_tag, "item_id",&itemid));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVQAReviewer",&VQAReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOManReviewer",&ManReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOTSReviewer",&TSReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVDReviewer",&VDReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOQAReviewer",&QAReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOSTDReviewer",&STDReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOQAHead",&QAHead));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOFactHead",&FactHead));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOSCMReviewer",&SCMReviewer));

					printf("\n itemid %s.....\n",itemid);fflush(stdout);
					printf("\n VQAReviewer %s.....\n",VQAReviewer);fflush(stdout);
					printf("\n ManReviewer %s.....\n",ManReviewer);fflush(stdout);
					printf("\n TSReviewer %s.....\n",TSReviewer);fflush(stdout);
					printf("\n VDReviewer %s.....\n",VDReviewer);fflush(stdout);
					printf("\n QAReviewer %s.....\n",QAReviewer);fflush(stdout);
					printf("\n STDReviewer %s.....\n",STDReviewer);fflush(stdout);
					printf("\n QAHead %s.....\n",QAHead);fflush(stdout);
					printf("\n FactHead %s.....\n",FactHead);fflush(stdout);
					printf("\n SCMReviewer %s.....\n",SCMReviewer);fflush(stdout);

			
					//if( (strlen(VQAReviewer)>0) && (strlen(ManReviewer)>0) && (strlen(TSReviewer)>0) && (strlen(VDReviewer)>0) && (strlen(QAReviewer)>0) && (strlen(STDReviewer)>0) && (strlen(QAHead)>0) && (strlen(FactHead)>0) && (strlen(SCMReviewer)>0) )
					if( (strlen(VQAReviewer)>0) && (strlen(ManReviewer)>0) && (strlen(TSReviewer)>0) && (strlen(VDReviewer)>0) && (strlen(QAReviewer)>0) && (strlen(STDReviewer)>0) ) // removed QAHead,FactHead,SCM REviewer as per discussion with nana 
					{
						printf("\n All participants given.. no prob");fflush(stdout);
					}
					else
					{
						printf("\n All participants not given.. prob\n");fflush(stdout);
						EMH_clear_errors();
						status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Assign all Reviewer before Sign Off Complete\nSelect Tryout -> Right Click -> Edit Properties -> Assign Reviewer");
						decision = EPM_nogo;
						return ITK_errStore;
						printf("\ndone\n");fflush(stdout);
					}
				

					if( tc_strcmp(CurrentTask,"TryOut VD Review" )==0 || tc_strcmp(CurrentTask,"Confirm Readiness" )==0)
					{
						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOBatchSize",&TOBatchSize));
						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVenName",&TOVenName));

						printf("\n TOBatchSize %s.....\n",TOBatchSize);fflush(stdout);
						printf("\n TOVenName %s.....\n",TOVenName);fflush(stdout);

						if( (strlen(TOBatchSize)>0) )
						{
							printf("\n  Batch Size given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Batch Size not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Batch Size.(Batch Size is mandatory for VD) \nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}


						if( (strlen(TOVenName)>0) )
						{
							printf("\n  Vendor Name given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Vendor Name not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Vendor Name.(Vendor Name is mandatory for VD) \nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}

					if( tc_strcmp(CurrentTask,"TryOut TS Review" )==0 || tc_strcmp(CurrentTask,"TryOut TS/APL Review" )==0)
					{
						//ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOArea",&TOArea));
						ITKCALL(AOM_ask_value_strings(item_rev_tag,"t5_TOArea",&numarea,&TOArea));
						//printf("\n TOArea %s.....\n",TOArea);fflush(stdout);
						printf("\n numarea %d.....\n",numarea);fflush(stdout);

						if( (numarea>0) )
						{
							printf("\n  Area given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Area not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Area/Subarea and Affected Shops.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}


					if( tc_strcmp(CurrentTask,"TryOut Manufacturing Review" )==0 )
					{
						//ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOTryOutDt",&TOTryOutDt));
						ITKCALL(AOM_UIF_ask_value(item_rev_tag,"t5_TOTryOutDt",&TOTryOutDt));
						printf("\n TOTryOutDt %s.....\n",TOTryOutDt);fflush(stdout);

						if( (strlen(TOTryOutDt)>0) )
						{
							printf("\n  Tryout Date given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Tryout Date not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Tryout Date.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}


					if( tc_strcmp(CurrentTask,"TryOut CQ Review" )==0 )
					{
						int			intBatchS		= 0;

						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOFitment",&TOFitment));
						printf("\n TOFitment %s.....\n",TOFitment);fflush(stdout);

						if( (strlen(TOFitment)>0) )
						{
							printf("\n  Tryout Fitment given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Tryout Fitment not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Fitment Disposition.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOBatchSize",&TOBatchSize1));
						printf("\n TOBatchSize1 %s.....\n",TOBatchSize1);fflush(stdout);

						intBatchS=atoi(TOBatchSize1);
						printf("\n  intBatchS:[%d]",intBatchS);fflush(stdout);
						
						if(intBatchS>0)
						{
							int VinCnt=0;

							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo",&TOVinNo));
							printf("\n TOVinNo %s.....\n",TOVinNo);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo1",&TOVinNo1));
							printf("\n TOVinNo1 %s.....\n",TOVinNo1);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo2",&TOVinNo2));
							printf("\n TOVinNo2 %s.....\n",TOVinNo2);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo3",&TOVinNo3));
							printf("\n TOVinNo3 %s.....\n",TOVinNo3);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo4",&TOVinNo4));
							printf("\n TOVinNo4 %s.....\n",TOVinNo4);fflush(stdout);

							if( (strlen(TOVinNo)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo1)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo2)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo3)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo4)>0) )
							{
								VinCnt++;
							}

							printf("\n  VinCnt:[%d]",VinCnt);fflush(stdout);

							  if(intBatchS==VinCnt)
							 	{
							 		printf("\nValidation Pass For BatchSize1==VinCnt\n"); fflush(stdout);
							 	}
							 	else if(intBatchS<VinCnt)
							 	{
									printf("\nVin no are Greter Then Batch Size BatchSize1<VinCnt\n"); fflush(stdout);
									sprintf(intBatchSStr,"%d",intBatchS);
									sprintf(VinCntStr,"%d",VinCnt);
									printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
									printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

									//Softcheck
									
//									   *.TXT t5TryOutBatchSizeConfim1
//									   *.Batch Size entered is #BATCHSIZE3# and VIN NO Entered are #VIN3#.
//									   *.Batch Size is less then Number of VIN NO Entered, Still Wants to Continue.
//									   *.HLP
//									   *.For Any Query Please contact PLM Admin.
									
							 
							 	}
								else if(intBatchS>VinCnt)
								{    
									printf("\nValidation Error For BatchSize1>VinCnt\n"); fflush(stdout);
									if( intBatchS>5 && VinCnt==5 )
									 {
									 	printf("\nValidation Pass For BatchSize1>VinCnt\n"); fflush(stdout);
									 }
								    else if(intBatchS>=5&&VinCnt<5)
									{
										printf("\nYou Must Enter 5 Vin No Because Batch Size if Greter Then 5\n"); fflush(stdout);
										sprintf(intBatchSStr,"%d",intBatchS);
										sprintf(VinCntStr,"%d",VinCnt);
										printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
										printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

										tc_strcat(Errr,"\nBatch Size entered is ");
										tc_strcat(Errr,intBatchSStr);
										tc_strcat(Errr," and VIN NO Entered are ");
										tc_strcat(Errr,VinCntStr);
										tc_strcat(Errr,"\nIf Batch Size is Greater than or Equals to 5 Then You must have to Enter 5 VIN NO.");
										
										printf("\n Tryout Fitment not given.. prob");fflush(stdout);
										EMH_clear_errors();
										status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
										decision = EPM_nogo;
										return ITK_errStore;


									}else if(intBatchS<=5&&VinCnt<5)
									{
										printf("\nBatch Size and Vin No Count is not matched for Please Fill VIN No\n"); fflush(stdout);
										sprintf(intBatchSStr,"%d",intBatchS);
										sprintf(VinCntStr,"%d",VinCnt);
										printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
										printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

										tc_strcat(Errr,"\nBatch Size entered is ");
										tc_strcat(Errr,intBatchSStr);
										tc_strcat(Errr," and VIN NO Entered are ");
										tc_strcat(Errr,VinCntStr);
										tc_strcat(Errr,"\nIf Batch Size is less then or Equals to 5 Then You must have to Enter Equivalent VIN NO");

										printf("\n Tryout Fitment not given.. prob");fflush(stdout);
										EMH_clear_errors();
										status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
										decision = EPM_nogo;
										return ITK_errStore;
									}
								    else
								    {
								    	printf("\nCondition Pass\n"); fflush(stdout);
								    }
								}  
								else
								{
									printf("\nCondition Pass1\n"); fflush(stdout);
								}

						}
						else
						{
							printf("\n else ...."); fflush(stdout);
							sprintf(intBatchSStr,"%d",intBatchS);
							printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);

							//Softcheck
							
//							   *.TXT t5TryOutBatchSizeConfim2
//							   *.Batch Size entered is #BATCHSIZE4# Or Less Then Zero.
//							   *.Still Wants to Continue.
//							   *.HLP
//							   *.For Any Query Please contact PLM Admin. 
							


						}

											



					}

			}
       }
  }
 
 CLEANUP:
	 printf("\n hi ..inside cleanup");fflush(stdout);
	decision = EPM_go;
	return decision;
} 
*/


void  t5GenerateToolIndentReport(tag_t PEindenttag)
{	  

    int				ifail				= ITK_ok;
	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	char        *item_id	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 PETag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;
    char*	FileName = NULL;
	char*	FileNamepath = NULL;
	
	FILE	*fp1 = NULL;
    FileName= (char *)MEM_alloc(100 * sizeof(char));
	FileNamepath= (char *)MEM_alloc(100 * sizeof(char));
	char*	datasetFileName = NULL;
    datasetFileName=(char *) MEM_alloc(100 * sizeof(char ));
	tag_t			relation1			= NULLTAG;
	tag_t req_rel_t = NULLTAG;
	tag_t ds_req_rel_t = NULLTAG;
	tag_t wordLatestDat_t = NULLTAG;
		tag_t	tool 		= NULLTAG;
	char* indentno     = NULL;
	indentno=(char *) MEM_alloc(200 * sizeof(char *));
    int t=0;
	tag_t default_tool_tag;
	int count_dataSetrlz= 0;
	char **listrlz;
	tag_t filetag = NULLTAG;
	IMF_file_t fileDescriptor;
	date_t *Pedate = NULL;
	char* createdate     = NULL;
	char* planner     = NULL;
	char* pegrpldr     = NULL;
	char* Peplanner     = NULL;
	char* partid     = NULL;
	char* tasknum     = NULL;
	char* drawingno     = NULL;
	char* desc     = NULL;
	char* dmlnum     = NULL;
	char* projectcode     = NULL;
	tag_t	relation_type= NULLTAG;
	tag_t	ErcPartTag= NULLTAG;
	int  count = 1;
	int  i = 1;
	tag_t*		Ercpart		= NULLTAG;
	tag_t	Prt_Task_Rel_Typ= NULLTAG;
	tag_t	tasktag= NULLTAG;
	int  Tsk_count = 1;
	int  it = 1;
	tag_t*		Tsk_list		= NULLTAG;
	char* srlno     = NULL;
	srlno	=	(char	*)MEM_alloc(10);
	tag_t	IndentDummy_rel_type= NULLTAG;
	tag_t	dmmyTag= NULLTAG;
	tag_t	IndentDummy_rel= NULLTAG;
	int  dmmyPartCnt = 1;
	int  k;
	tag_t*		dmmyPartTags		= NULLTAG;
	char* dummy_id     = NULL;
	char* dmydrwgind     = NULL;
	char* dmydesc     = NULL;
	int unitqty;
	int ordrqty;
	char* Totlestcost     = NULL;
	char* peunitcost     = NULL;
	char* dmyremark     = NULL;
	char* tlpriority     = NULL;
	tag_t	pepartTag= NULLTAG;
	int  pePartCnt = 1;
	int  pk;
	tag_t*		pePartTags		= NULLTAG;
	char* pepart_id     = NULL;
	int  dmmyopratnCnt = 1;
	tag_t*		dmmyopernTags		= NULLTAG;
	char* oprtnnum     = NULL;
	char* plantcode     = NULL;
	char* plantdesc     = NULL;
	char* machinno     = NULL;
	char* machindesc     = NULL;
	char* projcttype     = NULL;
	char* indentremark     = NULL;
	char* pestatus     = NULL;
	char* ownuser     = NULL;
	char* NPIPJ     = NULL;
	char* PeWbsNo     = NULL;
	char* BCNO     = NULL;
	int				st_count_1 = 0;
	tag_t*    status_list_1=NULLTAG;
	char		   *WSO_Name	=	NULL;
	char *cstest  = NULL;
	char *pedesc  = NULL;
	char *Analyst_email_addr  = NULL;
	char* revision     = NULL;
	int sequence = 0;
	char* seqstr     = NULL;
	seqstr	=	(char	*)MEM_alloc(50);
	tag_t Analyst_person_tag  = NULLTAG;
	tag_t Analyst_user_tag  = NULLTAG;
	tag_t		envelope				= NULLTAG;
	tag_t		*recievers				= NULLTAG;
	int countenvelop=0;
	int allTotal = 0;
	float allTotalF= 0;
	char* allTotalS     = NULL;
	allTotalS	= (char *) MEM_alloc(100 * sizeof(char ));
	char* revseq     = NULL;
	revseq=(char *) MEM_alloc(50 * sizeof(char *));
    int cnt;	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time:  [%s]", GenDate);fflush(stdout);
	
	
    printf("\n **************t5GenerateToolIndentReport***************\n ");fflush(stdout);

			
			ITKCALL(AOM_ask_value_string( PEindenttag, "item_id", &item_id));
	        printf("\n  PE tool indent number is--> %s\n", item_id);fflush(stdout);
				   			   				   			
			ITKCALL(AOM_ask_value_string( PEindenttag, "t5_IdProType", &projcttype));
	        printf("\n  projcttype is--> %s\n", projcttype);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string( PEindenttag, "t5_NPIPJ", &NPIPJ));
	        printf("\n  NPIPJ is--> %s\n", NPIPJ);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string( PEindenttag, "t5_PeWbsNo", &PeWbsNo));
	        printf("\n  PeWbsNo is--> %s\n", PeWbsNo);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string( PEindenttag, "t5_PeIRL", &indentremark));
	        printf("\n  indentremark is--> %s\n", indentremark);fflush(stdout);
				   
			ITKCALL(WSOM_ask_release_status_list(PEindenttag,&st_count_1,&status_list_1));      
			printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
			
				tc_strcat(FileName,item_id);
				tc_strcat(FileName,"_APL_");
				tc_strcat(FileName,GenDate);
				tc_strcat(FileName,"_");
				tc_strcat(FileName,"Report");
				tc_strcat(FileName,".txt");
			

					tc_strcpy(FileNamepath,"/tmp/");	
					tc_strcat(FileNamepath,FileName);	
						
					fp1 = TC_fopen(FileNamepath,"w");
					if(fp1==NULL)
					{
						printf("\nFile cant be opened");
					}else
					{
										
						printf("\n Input File Opened Successfully..!!\n");fflush(stdout);
						
						fprintf(fp1,"Tata Motors,Pune                 APL TO PRODUCTION ENGINEERING                      \n");fflush(fp1);
						fprintf(fp1,"--------------------------------------------------------------------------------------------------\n");fflush(fp1);
						ITKCALL(AOM_ask_value_string( PEindenttag, "t5_PEStatus", &pestatus));
						printf("\npestatus is ",pestatus);
						fprintf(fp1,"Indent No    : %s                           Status       : %s                            \n",item_id,pestatus);fflush(fp1);
						
						GRM_find_relation_type("T5_PEToolIndentToPartRel",&relation_type);
						ITKCALL(GRM_list_secondary_objects_only(PEindenttag,relation_type,&count,&Ercpart));
						printf("\n\n\t\t pe indent to erc part : %d",count);fflush(stdout);
						for (i=0;i<count ;i++ )
						{
								
							ErcPartTag = Ercpart[i];
							ITKCALL(AOM_ask_value_string( ErcPartTag, "item_id", &partid));
							printf("\n  erc part is--> %s\n", partid);fflush(stdout);
							
							ITKCALL(AOM_ask_value_string( ErcPartTag, "current_revision_id", &revision));
							printf("\n  revision is--> %s\n", revision);fflush(stdout);												
																				
							ITKCALL(AOM_ask_value_string( ErcPartTag, "t5_DrawingNo", &drawingno));
							printf("\n  drawingno is--> %s\n", drawingno);fflush(stdout);
							
							ITKCALL(AOM_ask_value_string( ErcPartTag, "current_desc", &desc));
							printf("\n  desc is--> %s\n", desc);fflush(stdout);
						}
						
						fprintf(fp1,"Part Number  : %s                   Drawing No   : %s                                   \n",partid,drawingno);fflush(fp1);
						fprintf(fp1,"Description  : %s                                                                       \n",desc);fflush(fp1);
						
						ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&Prt_Task_Rel_Typ));
						ITKCALL(GRM_list_primary_objects_only(ErcPartTag,Prt_Task_Rel_Typ,&Tsk_count,&Tsk_list));
						printf("\n\n\t\t part to task count : %d",Tsk_count);fflush(stdout);
						for (it=0;it<Tsk_count ;it++ )
						{
							tasktag = Tsk_list[it];
							ITKCALL(AOM_ask_value_string( tasktag, "item_id", &tasknum));
							printf("\n  task num is--> %s\n", tasknum);fflush(stdout);
							dmlnum=subString(tasknum,0,10);
							
							ITKCALL(AOM_ask_value_string( tasktag, "owning_project", &projectcode));
							printf("\n  projectcode is--> %s\n", projectcode);fflush(stdout);
							break;
						}
						ITKCALL(AOM_ask_value_date( PEindenttag, "creation_date", &Pedate));
						if (ITK_ok != (ifail = DATE_date_to_string(Pedate, "%d-%b-%Y %H:%M", &createdate)))

						  printf("\n pe createdate[%s] ", createdate);fflush(stdout);
						fprintf(fp1,"DML/PMR No   : %s                                                                       \n",dmlnum);fflush(fp1);
						fprintf(fp1,"Project code : %s                                                                       \n",projectcode);fflush(fp1);
						fprintf(fp1,"Project Desc :                                                                          \n");fflush(fp1);
						fprintf(fp1,"Mod No       :  %s                   Date         : %s                                  \n",revision,createdate);fflush(fp1);
						ITKCALL(AOM_ask_value_string( PEindenttag, "t5_IndPlanner", &planner));
						printf("\n planner is ",planner);				
						ITKCALL(AOM_ask_value_string( PEindenttag, "t5_PegrpL", &pegrpldr));
						printf("\npegrpldr is ",pegrpldr);
						ITKCALL(AOM_ask_value_string( PEindenttag, "t5_IndPeReviewer", &Peplanner));
						printf("\npe planner is ",Peplanner);
						ITKCALL(AOM_ask_value_string( PEindenttag, "t5_PeIndBCNo", &BCNO));
						printf("\npe BCNO is ",BCNO);
						fprintf(fp1,"planner      : %s                                                                       \n",planner);fflush(fp1);
						fprintf(fp1,"PE Planner   : %s                                                                       \n",Peplanner);fflush(fp1);						
						fprintf(fp1,"Sr  ToolNo       AgnTo AgnFor Action BCNo  EdnStatus	   CostEst      Ord qty    Tool cost  \n");fflush(fp1);
						fprintf(fp1,"--------------------------------------------------------------------------------------------------\n");fflush(fp1);
						
                        	GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&IndentDummy_rel_type);
							ITKCALL(AOM_ask_value_tags(PEindenttag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt,&dmmyPartTags));
							printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt);fflush(stdout);
							if (dmmyPartCnt>0)
							{
								for (k=0;k<dmmyPartCnt ;k++ )
								{	
							        int qty=0;
									int est=0;
									int total=0;
									
									dummy_id=NULL;
									ordrqty=0;
									dmydrwgind=NULL;
									Totlestcost=NULL;
									peunitcost=NULL;
									dmmyTag = NULLTAG;
									dmmyTag=dmmyPartTags[k];
									
									ITKCALL(AOM_ask_value_string(dmmyTag, "item_id", &dummy_id));
									printf("\n dummy id is =:%s",dummy_id);fflush(stdout);
									
									ITKCALL(AOM_ask_value_string(dmmyTag, "t5_DmyToolDrwInd", &dmydrwgind));
									printf("\n dmydrwgind is =:%s",dmydrwgind);fflush(stdout);
									
									ITKCALL(AOM_ask_value_string(dmmyTag, "current_desc", &dmydesc));
									printf("\n dmydesc is =:%s",dmydesc);fflush(stdout);
									
									ITKCALL(AOM_ask_value_string(dmmyTag,"t5_cpriority",&tlpriority));
									printf("\n tlpriority is =:%s",tlpriority);fflush(stdout);
									
									sprintf(srlno,"%d",k+1);
									
										if(PEindenttag != NULLTAG && dmmyTag != NULLTAG && IndentDummy_rel_type != NULLTAG)
										{
											printf("\n  inside loop check\n");fflush(stdout);
											
										  ITKCALL(GRM_find_relation(PEindenttag,dmmyTag,IndentDummy_rel_type,&IndentDummy_rel));
										  printf("\n  inside loop check1111111\n");fflush(stdout);
										  ITKCALL(AOM_ask_value_int(IndentDummy_rel,"t5_Qty1",&unitqty));
										  ITKCALL(AOM_ask_value_int(IndentDummy_rel,"t5_OrdQty1",&ordrqty));

										  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_PETotalTLCost",&Totlestcost));								 
										  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_CstEst",&peunitcost));
										  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_ToolRemark",&dmyremark));

										   printf("\n  inside loop end\n");fflush(stdout);
										}
										
										printf("\n ordrqty:%d  Totlestcost:%s peunitcost:%s",ordrqty,Totlestcost,peunitcost);fflush(stdout);										
										
										 
										 est=atoi(peunitcost);
										 total  = ordrqty * est;
										 allTotal = allTotal + total;
										 allTotalF = allTotal;										 
										
										fprintf(fp1,"%s    %s                                         %s              %d           %s     \n",srlno,dummy_id,peunitcost,ordrqty,Totlestcost);fflush(fp1);
										ITKCALL(AOM_ask_value_tags(PEindenttag,"T5_PEToolIndentToPEPrtRel1",&pePartCnt,&pePartTags));
										printf("\n\n\t\t pePartCnt is:%d",pePartCnt);fflush(stdout);
										if (pePartCnt>0)
										{
											for (pk=0;pk<pePartCnt;pk++ )
											{	
												pepart_id=NULL;
												pepartTag = NULLTAG;
												pepartTag=pePartTags[pk];
												
												ITKCALL(AOM_ask_value_string(pepartTag, "item_id", &pepart_id));
												printf("\n pepart_id is =:%s",pepart_id);fflush(stdout);
												fprintf(fp1,"DrwInd         : %s                    ActualToolNo  : %s                        \n",dmydrwgind,pepart_id);fflush(fp1);
											}
										}else
										{
										 fprintf(fp1,"DrwInd           : %s                   ActualToolNo  :                               \n",dmydrwgind);fflush(fp1);
										}
										fprintf(fp1,"Tool Priority  : %s                                                                  \n",tlpriority);fflush(fp1);
										fprintf(fp1,"Tool Desc      : %s                                                                \n",dmydesc);fflush(fp1);
										fprintf(fp1,"Tool Remark    : %s                                                                \n",dmyremark);fflush(fp1);
										ITKCALL(AOM_ask_value_tags(dmmyTag,"T5_DmyToolToOperation",&dmmyopratnCnt,&dmmyopernTags));
										printf("\n dmmyopratnCnt is =:%d",dmmyopratnCnt);fflush(stdout);
										if (dmmyopratnCnt>0)
										{
											ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "item_id", &oprtnnum));
											printf("\n oprtnnum is =:%s",oprtnnum);fflush(stdout);
									
											ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEPlantCode", &plantcode));
											printf("\n plantcode is =:%s",plantcode);fflush(stdout);
											
											ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEPlantDesc", &plantdesc));
											printf("\n plantdesc is =:%s",plantdesc);fflush(stdout);
											
											ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEAplMcNo", &machinno));
											printf("\n machinno is =:%s",machinno);fflush(stdout);
											
											ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_APLMCDesc", &machindesc));
											printf("\n machindesc is =:%s",machindesc);fflush(stdout);
										}

										fprintf(fp1,"Operaton No    : %s                                                                    \n",oprtnnum);fflush(fp1);
										fprintf(fp1,"Plant Code     : %s            Plant Desc : %s                                         \n",plantcode,plantdesc);fflush(fp1);
										fprintf(fp1,"M/C No         : %s             M/C Desc  : %s                                         \n",machinno,machindesc);fflush(fp1);
										
										fprintf(fp1,"                                                                                        \n");fflush(fp1);
										fprintf(fp1,"-------------------------------------------------------------------------------------------------\n");fflush(fp1);
										fprintf(fp1,"                                                                                        \n");fflush(fp1);

						
								}
							}
							printf("\nFloat Value Of AllTotal in Rupees => %f\n",allTotalF);fflush(stdout);
							allTotalF = allTotalF/100000;
							printf("\nFloat Value Of AllTotal in Lacs => %f\n",allTotalF);fflush(stdout);
							sprintf(allTotalS ,"%.4f",allTotalF);	
							
                        fprintf(fp1,"Est.Cost in Lakhs(C) Rs: %s                                                               \n",allTotalS);fflush(fp1);
						fprintf(fp1,"APL Project            : %s                                                               \n",projcttype);fflush(fp1);
						fprintf(fp1,"NPI Project            : %s                                                               \n",NPIPJ);fflush(fp1);
						fprintf(fp1,"WBS Element            : %s                                                               \n",PeWbsNo);fflush(fp1);
						fprintf(fp1,"                                                                                          \n");fflush(fp1);

						fprintf(fp1,"Group Leader  : %s                                                                                 \n",pegrpldr);fflush(fp1);
						fprintf(fp1,"PE Planner   : %s                                                                                  \n",Peplanner);fflush(fp1);
						fprintf(fp1,"                                                                                                   \n");fflush(fp1);
						
						fprintf(fp1,"Indent Remark        : %s                                                                          \n",indentremark);fflush(fp1);
						fprintf(fp1,"Cancellation Remark  :                                                                             \n");fflush(fp1);
						fprintf(fp1,"                                                                                                   \n");fflush(fp1);
                        fprintf(fp1,"=================================END OF REPORT==================================================== \n");fflush(fp1);										

					}
					
					
					
					fclose(fp1);
					printf("\n Input File Closed Successfully..!!\n");fflush(stdout);

					tag_t datasettype, NewTextDS, Fndrelation = NULLTAG;
			
					if(AE_find_datasettype2("Text", &datasettype)==ITK_ok)
					if (datasettype == NULLTAG)
					{
						printf("\n Dataset Type 'Text' not found!\n");fflush(stdout);
						//exit (EXIT_FAILURE);
					}
					else
					{
								
						if(AE_find_tool2("Notepad", &tool));
						if(AE_create_dataset_with_id(datasettype,FileName,"", NULL, NULL, &NewTextDS));
						if(AE_set_dataset_tool(NewTextDS,tool));
						if(AE_set_dataset_format2(NewTextDS, "TEXT_REF"));
						if(AOM_save_without_extensions(NewTextDS));
						if(IMF_fmsfile_import(FileNamepath, FileName,SS_TEXT, &filetag, &fileDescriptor));
						if(filetag == NULLTAG)
						{
							printf("file tag not found.....");fflush(stdout);
						}
						if(AOM_refresh(NewTextDS, TRUE));
						if(AE_add_dataset_named_ref2(NewTextDS, "Text", AE_PART_OF, filetag));
						if(AOM_save_without_extensions(NewTextDS));
						//Attaching the dataset to Reference folder
						if(GRM_find_relation_type("IMAN_reference", &req_rel_t)!=ITK_ok);

						if(req_rel_t != NULLTAG)
						{
							if(GRM_create_relation(PEindenttag,NewTextDS,req_rel_t, NULLTAG, &ds_req_rel_t));
							if(ds_req_rel_t != NULLTAG)
							{
								printf("\nThe dataset is attached to the Reference folder of PE");fflush(stdout);
							}
							else
							{
								printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
							}
							if(GRM_save_relation(ds_req_rel_t));
						}					
						
					} 
															

}


int Save_PeToolIndent_Msg( METHOD_message_t *msg, va_list  args )
{
    tag_t	TaskTag		= va_arg(args, const tag_t);
	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *item_id 			= NULL;
	char *Plant 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *PEgroupName 	   = NULL;
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;

	char *aplplanner 	   = NULL;
	char *pecoordinator 	   = NULL;
	char *pedept 	   = NULL;
	char *aplgrpleader 	   = NULL;
	char *TOVDReviewer 	   = NULL;
	char *TOQAHead 	   = NULL;
	char *TOVQAReviewer 	   = NULL;
	char *TOSTDReviewer 	   = NULL;
	char *TOFactHead 	   = NULL;
	char *TOManReviewer 	   = NULL;
	char *TOQAReviewer 	   = NULL;
	char *TOSCMReviewer 	   = NULL;

	//const char*   CR_EM_role = "CR_ERC_EM";
    char*       roleName = NULL;
	char BIW_role[40];
	char CTEDCJFD_role[40];
	char SMTD_role[40];
	char MPS_role[40];
	char Default_role[40];
	char APLGrp[40];
	char PEGrp[40];

tag_t  CurrentRoleTag = NULLTAG;
/*
	const char*   TRYOUT_TS_role = "TRYOUT-TS";
	const char*   TRYOUT_ADMIN_role = "TRYOUT-ADMIN";
	const char*   TRYOUT_CQ_role = "TRYOUT-CQ";
	const char*   TRYOUT_FACTHEAD_role = "TRYOUT-FACTHEAD";
	const char*   TRYOUT_Manufacturing_role = "TRYOUT-Manufacturing";
	const char*   TRYOUT_QAHEAD_role = "TRYOUT-QAHEAD";
	const char*   TRYOUT_SCM_role = "TRYOUT-SCM";
	const char*   TRYOUT_VD_role = "TRYOUT-VD";
	const char*   TRYOUT_VQA_role = "TRYOUT-VQA";
*/
	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;
	tag_t			user_tag			= NULLTAG;

	char*  type_name = NULL;
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name3[TCTYPE_name_size_c+1];
	char*   userid = NULL;
	WSO_search_criteria_t  	criteria;

	PEgroupName = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(PEgroupName,"PE_");
	printf("\n MT: PEgroupName  --> %s\n",PEgroupName);   fflush(stdout);

		char *IndPlannerRole 	   = NULL;
		IndPlannerRole = (char	*)MEM_alloc(100);
		tc_strcpy(IndPlannerRole,"PE_CAD_Des");
		printf("\n MT: IndPlannerRole  --> %s\n",IndPlannerRole);   fflush(stdout);

		char *APLGrpLeaderRole 	   = NULL;
		APLGrpLeaderRole = (char	*)MEM_alloc(100);
		tc_strcpy(APLGrpLeaderRole,"PE_Grp_Leader");
		printf("\n MT: APLGrpLeaderRole  --> %s\n",APLGrpLeaderRole);   fflush(stdout);

		char *PEPlannerCoordinatorRole 	   = NULL;
		PEPlannerCoordinatorRole = (char	*)MEM_alloc(100);
		tc_strcpy(PEPlannerCoordinatorRole,"");
		printf("\n MT: PEPlannerCoordinatorRole  --> %s\n",PEPlannerCoordinatorRole);   fflush(stdout);

		char *PEReviewerRole 	   = NULL;
		PEReviewerRole = (char	*)MEM_alloc(100);
		tc_strcpy(PEReviewerRole,"");
		printf("\n MT: PEReviewerRole  --> %s\n",PEReviewerRole);   fflush(stdout);


    printf("\n **************inside Save_PeToolIndent_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if( TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject: {%s}\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
	{
		    printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskTag, "item_id", &item_id);
			printf("\n inside class T5_PEToolIndentRevision item_id......: %s",item_id);fflush(stdout);

			AOM_ask_value_string( TaskTag, "t5_ParentProductLine", &Plant);
			printf("\n inside class T5_PEToolIndentRevision Plant......: %s",Plant);fflush(stdout);

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			
	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;

	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	 	 char *Info2 	  = NULL;
	 char *aplgrpname 	  = NULL;


	char    *qry_entryCntrl1[3]  = {"SYSCD","Information-1","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

			  if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="PEToolIndent";
				qry_valuesCntrl1[1]=Plant;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);


			if(control_number_found1>0)
					{
							AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &Info2); // CAR,CVPUNE,CVJSR  //Plantsuffix used in group
							printf("\n Info1: %s\n",Info2);fflush(stdout);

							AOM_ask_value_string( list_of_WSO_cntrl_tags1[0],"t5_SubSyscd", &aplgrpname); // groupname like APLCAR, APLJSR
							printf("\n aplgrpname: %s\n",aplgrpname);fflush(stdout);
					}


			tc_strcat(PEgroupName,Info2);
			printf("\n PEgroupName: %s\n",PEgroupName);fflush(stdout);

			//GetPlantWiseTryoutRoles(roleName,TRYOUT_TS_role,TRYOUT_ADMIN_role,TRYOUT_CQ_role,TRYOUT_FACTHEAD_role,TRYOUT_Manufacturing_role,TRYOUT_QAHEAD_role,TRYOUT_SCM_role,TRYOUT_VD_role,TRYOUT_VQA_role);
			//GetPlantWiseSuffix(Grp_name,APLGrp,PEGrp);
			//GetPlantWiseIndReviewer(roleName,BIW_role,MPS_role,CTEDCJFD_role,SMTD_role,Default_role);
			printf("\n BIW_role:  %s \n",BIW_role);fflush(stdout);
			printf("\n MPS_role:  %s \n",MPS_role);fflush(stdout);
			printf("\n CTEDCJFD_role:  %s \n",CTEDCJFD_role);fflush(stdout);
			printf("\n SMTD_role:  %s \n",SMTD_role);fflush(stdout);
			printf("\n Default_role:  %s \n",Default_role);fflush(stdout);
			
			AOM_ask_value_string( TaskTag,"t5_IndPlanner", &aplplanner);
			printf("\n inside class t5_petoolindentrev aplplanner......: %s",aplplanner);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_PegrpL", &aplgrpleader);
			printf("\n inside class t5_petoolindentrev aplgrpleader......: %s",aplgrpleader);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_PePlnrCo", &pecoordinator);
			printf("\n inside class t5_petoolindentrev pecoordinator......: %s",pecoordinator);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_LOBOfPE", &pedept);
			printf("\n inside class t5_petoolindentrev pedept......: %s",pedept);fflush(stdout);


			if (tc_strstr(pedept,"BIW")!=NULL)
			{
				tc_strcat(PEPlannerCoordinatorRole,"BIW_PECord");
				tc_strcat(PEReviewerRole,"BIW_WorkOrderAssign_PE");
			}
			else if (tc_strstr(pedept,"MPS-Metal Pattern Shop")!=NULL)
			{
				tc_strcat(PEPlannerCoordinatorRole,"MPS_PECord");
				tc_strcat(PEReviewerRole,"MPS_WorkOrderAssign_PE");
			}
			else if ( (tc_strstr(pedept,"CTED-Central Tool Engineering Department")!=NULL) || (tc_strstr(pedept,"CJFD-Central Jigs and Fixture design")!=NULL)  )
			{
				tc_strcat(PEPlannerCoordinatorRole,"CTED_CJFD_PECord");
				tc_strcat(PEReviewerRole,"CTED_CJFD_WorkOrderAssign_PE");
			}
			else if (tc_strstr(pedept,"SMTD-Sheet Metal Tool Design")!=NULL)
			{
				tc_strcat(PEPlannerCoordinatorRole,"SMTD_PECord");
				tc_strcat(PEReviewerRole,"SMTD_WorkOrderAssign_PE");
			}
			else
			{
				tc_strcat(PEPlannerCoordinatorRole,"DefaultUsr_PECord");
				tc_strcat(PEReviewerRole,"DefaultUsr_WorkOrderAssign_PE");
			}

			printf("\n PEPlannerCoordinatorRole ......: %s",PEPlannerCoordinatorRole);fflush(stdout);

			
			int				count		= 0;
			int				stdCnt		= 0;
			tag_t			*ParticipantRel			= NULLTAG;
			tag_t			ParticipantRelTag		= NULLTAG;
			tag_t			ObjTypTask			= NULLTAG;
			char*			type_namee_task = NULL;
			char*			TaskAssignee		= NULL;

			GRM_find_relation_type("HasParticipant", &relation_type);
			CALLAPI(GRM_list_secondary_objects_only(TaskTag,relation_type,&count,&ParticipantRel));
			printf("\n 222 count :[%d]\n",count);fflush(stdout);

			if(count == 0) 
			{
				printf("\n No issuess...");fflush(stdout);
			}
			else
			{
				for(stdCnt=0;stdCnt<count;stdCnt++)
				{
							printf("\n Inside remving the relation...");fflush(stdout);
							ParticipantRelTag=NULLTAG;
							ParticipantRelTag = ParticipantRel[stdCnt];
							
							printf("\n 11 Inside remving the relation...");fflush(stdout);
							ObjTypTask=NULLTAG;
							if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
							if( TCTYPE_ask_name2(ObjTypTask,&type_namee_task));
							printf("\n Task: Participants Name: %s", type_namee_task);fflush(stdout);

							if ((tc_strcmp(type_namee_task,"T5_PEToolIndPlanner")==0))
							{
								printf("\n Removing T5_PEToolIndPlanner");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								
								ITKCALL(AOM_refresh(TaskTag,1));
								ITKCALL(PARTICIPANT_remove_participant(TaskTag,ParticipantRelTag)!=ITK_ok);
                                ITKCALL(AOM_save_without_extensions(TaskTag));
                                ITKCALL(AOM_refresh(TaskTag,1));
							}

							if ((tc_strcmp(type_namee_task,"T5_PEPlannerCordinator")==0))
							{
								printf("\n Removing T5_PEPlannerCordinator");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
                                ITKCALL(AOM_refresh(TaskTag,1));
								ITKCALL(PARTICIPANT_remove_participant(TaskTag,ParticipantRelTag)!=ITK_ok);
								ITKCALL(AOM_save_without_extensions(TaskTag));
                                ITKCALL(AOM_refresh(TaskTag,1));
							}

							if ((tc_strcmp(type_namee_task,"T5_PEGroupLeader")==0))
							{
								printf("\n Removing T5_PEGroupLeader");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
                                ITKCALL(AOM_refresh(TaskTag,1));
								ITKCALL(PARTICIPANT_remove_participant(TaskTag,ParticipantRelTag)!=ITK_ok);
								ITKCALL(AOM_save_without_extensions(TaskTag));
                                ITKCALL(AOM_refresh(TaskTag,1));
							}

							if ((tc_strcmp(type_namee_task,"T5_PEToolIndReviewer")==0))
							{
								printf("\n Removing T5_PEToolIndReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
                                ITKCALL(AOM_refresh(TaskTag,1));
								ITKCALL(PARTICIPANT_remove_participant(TaskTag,ParticipantRelTag)!=ITK_ok);
								ITKCALL(AOM_save_without_extensions(TaskTag));
                                ITKCALL(AOM_refresh(TaskTag,1));
							}
							
				}

			}


			if(aplplanner!=NULL)
			{
				printf("\n aplplanner ....:[%s]",aplplanner);fflush(stdout);

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(aplplanner,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n aplplanner: %s\n",aplplanner);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				//if(SA_find_group("APLCAR", &Grp_tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_group(aplgrpname, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(IndPlannerRole,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
				//if(SA_find_role2("00_APLC_Planner",&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n aplplanner CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n aplplanner CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n aplplanner member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n aplplanner userid:[%s]\n",userid);
						printf("\n aplplanner [%s]\n",aplplanner);

						//if(strcmp(member_name,aplplanner)==0)
						//if(tc_strstr(aplplanner,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside aplplanner assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_PEToolIndPlanner",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
                             ITKCALL(AOM_refresh(TaskTag,1));							
							if(PARTICIPANT_add_participant(TaskTag,true,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							ITKCALL(AOM_save_without_extensions(TaskTag));
                            ITKCALL(AOM_refresh(TaskTag,1));
							printf("\n aplplanner Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(aplgrpleader!=NULL)
			{
				printf("\n aplgrpleader ....:[%s]",aplgrpleader);fflush(stdout);

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(aplgrpleader,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n aplgrpleader: %s\n",aplgrpleader);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				//if(SA_find_group("APLCAR", &Grp_tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_group(PEgroupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(APLGrpLeaderRole,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
				//if(SA_find_role2("00_APLC_Planner",&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n aplgrpleader CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n aplgrpleader CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n aplgrpleader member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n aplgrpleader userid:[%s]\n",userid);
						printf("\n aplgrpleader [%s]\n",aplgrpleader);

						//if(strcmp(member_name,aplgrpleader)==0)
						//if(tc_strstr(aplgrpleader,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside aplgrpleader assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_PEGroupLeader",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
                             ITKCALL(AOM_refresh(TaskTag,1));						
							if(PARTICIPANT_add_participant(TaskTag,true,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							ITKCALL(AOM_save_without_extensions(TaskTag));
                            ITKCALL(AOM_refresh(TaskTag,1));
							printf("\n aplgrpleader Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}
		

			if(pecoordinator!=NULL)
			{
				printf("\n pecoordinator ....:[%s]",pecoordinator);fflush(stdout);

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(pecoordinator,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n pecoordinator: %s\n",pecoordinator);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				//if(SA_find_group("APLCAR", &Grp_tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_group(PEgroupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(PEPlannerCoordinatorRole,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
				//if(SA_find_role2("00_APLC_Planner",&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n pecoordinator CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n pecoordinator CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n pecoordinator member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n pecoordinator userid:[%s]\n",userid);
						printf("\n pecoordinator [%s]\n",pecoordinator);

						//if(strcmp(member_name,pecoordinator)==0)
						//if(tc_strstr(pecoordinator,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside pecoordinator assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_PEPlannerCordinator",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
                             ITKCALL(AOM_refresh(TaskTag,1));							
							if(PARTICIPANT_add_participant(TaskTag,true,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							ITKCALL(AOM_save_without_extensions(TaskTag));
                            ITKCALL(AOM_refresh(TaskTag,1));
							printf("\n pecoordinator Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			// assigning T5_PEToolIndReviewer
			tag_t			group_tag			= NULLTAG;
			tag_t*			role_tags			= NULLTAG;
			int				num_of_roles		= 0;
			int				num_of_members		= 0;
			char*			rolename = NULL;
			char*			userid = NULL;

			tag_t			user_tag			= NULLTAG;
			tag_t			relation			= NULLTAG;
			tag_t			participant_type	= NULLTAG;
			tag_t			participant_tag		= NULLTAG;
			tag_t			relation_type		= NULLTAG;
			tag_t			role_tag		= NULLTAG;
			tag_t*			member_tags			= NULLTAG;
			int jk=0;


			CALLAPI(SA_find_group(PEgroupName,&group_tag));
			if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

			printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
			if(num_of_roles>0)
				{
				  int ij=0;
				  for (ij=0;ij<num_of_roles ;ij++ )
					{
					  
						CALLAPI(SA_ask_role_name2(role_tags[ij],&rolename));
						printf("\nRol Name :[%d][%s]\n",ij,rolename);fflush(stdout);

						if(tc_strcmp(rolename,PEReviewerRole)==0)
						{
									printf("\n Role Match Found\n");fflush(stdout);
									role_tag = role_tags[ij];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (jk=0;jk<num_of_members ;jk++  )
										{
											CALLAPI(SA_ask_groupmember_user(member_tags[jk],&user_tag));
											CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
										
											TCTYPE_find_type("T5_PEToolIndReviewer", "T5_PEToolIndReviewer", &participant_type);
											EPM_create_participant(member_tags[jk], participant_type, &participant_tag);
											GRM_find_relation_type("HasParticipant", &relation_type);
											GRM_create_relation(TaskTag, participant_tag, relation_type,  NULLTAG, &relation);
											GRM_save_relation(relation);
											printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
																					
										}
									}

						}

					}
					
				}
	}

    return error_code;

}

int tm_PE_Report( EPM_action_message_t msg )
{
    int				ifail				= ITK_ok;
	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	char        *item_id	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 PETag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;
    char*	FileName = NULL;
	char*	FileNamepath = NULL;
	
	FILE	*fp1 = NULL;
    FileName= (char *)MEM_alloc(100 * sizeof(char));
	FileNamepath= (char *)MEM_alloc(100 * sizeof(char));
	char*	datasetFileName = NULL;
    datasetFileName=(char *) MEM_alloc(100 * sizeof(char ));
	tag_t			relation1			= NULLTAG;
	tag_t req_rel_t = NULLTAG;
	tag_t ds_req_rel_t = NULLTAG;
	tag_t wordLatestDat_t = NULLTAG;
		tag_t	tool 		= NULLTAG;
	char* indentno     = NULL;
	indentno=(char *) MEM_alloc(200 * sizeof(char *));
    int t=0;
	tag_t default_tool_tag;
	int count_dataSetrlz= 0;
	char **listrlz;
	tag_t filetag = NULLTAG;
	IMF_file_t fileDescriptor;
	date_t *Pedate = NULL;
	char* createdate     = NULL;
	char* planner     = NULL;
	char* pegrpldr     = NULL;
	char* Peplanner     = NULL;
	char* partid     = NULL;
	char* revision     = NULL;
	int sequence;
	char* revseq     = NULL;
	char* seqstr     = NULL;
	seqstr        = MEM_alloc(15);
	char* tasknum     = NULL;
	char* drawingno     = NULL;
	char* desc     = NULL;
	char* dmlnum     = NULL;
	char* projectcode     = NULL;
	tag_t	relation_type= NULLTAG;
	tag_t	ErcPartTag= NULLTAG;
	int  count = 1;
	int  i = 1;
	tag_t*		Ercpart		= NULLTAG;
	tag_t	Prt_Task_Rel_Typ= NULLTAG;
	tag_t	tasktag= NULLTAG;
	int  Tsk_count = 1;
	int  it = 1;
	tag_t*		Tsk_list		= NULLTAG;
	char* srlno     = NULL;
	srlno	=	(char	*)MEM_alloc(10);
	tag_t	IndentDummy_rel_type= NULLTAG;
	tag_t	dmmyTag= NULLTAG;
	tag_t	IndentDummy_rel= NULLTAG;
	int  dmmyPartCnt = 1;
	int  k;
	tag_t*		dmmyPartTags		= NULLTAG;
	char* dummy_id     = NULL;
	char* dmydrwgind     = NULL;
	char* dmydesc     = NULL;
	int unitqty;
	int ordrqty;
	char* Totlestcost     = NULL;
	char* peunitcost     = NULL;
	char* dmyremark     = NULL;
	tag_t	pepartTag= NULLTAG;
	int  pePartCnt = 1;
	int  pk;
	tag_t*		pePartTags		= NULLTAG;
	char* pepart_id     = NULL;
	int  dmmyopratnCnt = 1;
	tag_t*		dmmyopernTags		= NULLTAG;
	char* oprtnnum     = NULL;
	char* plantcode     = NULL;
	char* plantdesc     = NULL;
	char* machinno     = NULL;
	char* machindesc     = NULL;
	char* projcttype     = NULL;
	char* indentremark     = NULL;
	char* pestatus     = NULL;
	char* ownuser     = NULL;
	int				st_count_1 = 0;
	tag_t*    status_list_1=NULLTAG;
	char		   *WSO_Name	=	NULL;
	char *cstest  = NULL;
	char *pedesc  = NULL;
	char *Analyst_email_addr  = NULL;
	tag_t Analyst_person_tag  = NULLTAG;
	tag_t Analyst_user_tag  = NULLTAG;
	tag_t		envelope				= NULLTAG;
	tag_t		*recievers				= NULLTAG;
	int countenvelop=0;
	//char env_subject[500] = {'\0'};
	//char env_body[90000]= {'\0'};
		char* env_subject	= NULL;
		char* env_body		= NULL;							
		
		env_subject	= (char *) MEM_alloc(500 * sizeof(char ));
		env_body		= (char *) MEM_alloc(50000 * sizeof(char ));
	
    int cnt;	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time:  [%s]", GenDate);fflush(stdout);
	
	
    printf("\n **************inside tm_PE_Report***************\n ");fflush(stdout);

		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	    printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			 if(noAttachment > 0)
			{
			   for(t=0;t<noAttachment;t++)
			   {
				   PETag = attachments[t];
                   ITKCALL(AOM_ask_value_string( PETag, "item_id", &item_id));
	               printf("\n  PE tool indent number is--> %s\n", item_id);fflush(stdout);
				  
			   }
			}
			
			ITKCALL(AOM_ask_value_string( PETag, "t5_IdProType", &projcttype));
	        printf("\n  projcttype is--> %s\n", projcttype);fflush(stdout);
				   
			ITKCALL(AOM_ask_value_string( PETag, "t5_PeIRL", &indentremark));
	        printf("\n  indentremark is--> %s\n", indentremark);fflush(stdout);
				   
			ITKCALL(WSOM_ask_release_status_list(PETag,&st_count_1,&status_list_1));      
			printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
			
		if(st_count_1>0)
		{
			for (cnt=0;cnt< st_count_1;cnt++ )
			{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list_1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
				if(tc_strcmp(WSO_Name,"")!=0)
				{
					if (tc_strcmp(WSO_Name,"T5_LcsEstApp")!=0)
					{
											
					  if (tc_strcmp(WSO_Name,"T5_LcsAPLWrkg_1")==0)
						{
							tc_strcat(FileName,item_id);
							tc_strcat(FileName,"_Before_CstEst_");
							tc_strcat(FileName,GenDate);
							tc_strcat(FileName,"_");
							tc_strcat(FileName,"Report");
							tc_strcat(FileName,".txt");
						}
						else if(tc_strcmp(WSO_Name,"T5_LcsPEWrkg_1")==0)
						    {
								tc_strcat(FileName,item_id);
								tc_strcat(FileName,"_After_CstEst_");
								tc_strcat(FileName,GenDate);
								tc_strcat(FileName,"_");
								tc_strcat(FileName,"Report");
								tc_strcat(FileName,".txt");
						    }
							else if(tc_strcmp(WSO_Name,"T5_LcsPERlzd_1")==0)
						    {
								tc_strcat(FileName,item_id);
								tc_strcat(FileName,"_AfterWorkOrder_CstEst_");
								tc_strcat(FileName,GenDate);
								tc_strcat(FileName,"_");
								tc_strcat(FileName,"Report");
								tc_strcat(FileName,".txt");
						    }
							else
								{
									tc_strcat(FileName,item_id);
									tc_strcat(FileName,"_CstEst_");
									tc_strcat(FileName,GenDate);
									tc_strcat(FileName,"_");
									tc_strcat(FileName,"Report");
									tc_strcat(FileName,".txt");
								}
			
      		

								tc_strcpy(FileNamepath,"/tmp/");	
								tc_strcat(FileNamepath,FileName);	
									
								fp1 = TC_fopen(FileNamepath,"w");
								if(fp1==NULL)
								{
									printf("\nFile cant be opened");
								}else
								{
													
									printf("\n Input File Opened Successfully..!!\n");fflush(stdout);
									
									fprintf(fp1,"                  PE Tool Indent Cost Estimation Sheet                                   \n");fflush(fp1);
									fprintf(fp1,"-----------------------------------------------------------------------------------------\n");fflush(fp1);
									fprintf(fp1,"To : DGM  (PE Planning)                                       Req_No :                   \n");fflush(fp1);
									fprintf(fp1,"                                                                                         \n");fflush(fp1);				
									fprintf(fp1,"                        Final_Req_No :                                                   \n");fflush(fp1);
									fprintf(fp1,"                                                                                         \n");fflush(fp1);				
									AOM_ask_value_date( PETag, "creation_date", &Pedate);
									if (ITK_ok != (ifail = DATE_date_to_string(Pedate, "%d-%b-%Y %H:%M", &createdate)))
									{
									  return ifail;
									}
									  printf("\n pe createdate[%s] ", createdate);
									  fflush(stdout);
									ITKCALL(AOM_ask_value_string( PETag, "t5_IndPlanner", &planner));
									printf("\n planner is ",planner);				
									fprintf(fp1,"Date         : %s                           Planner    : %s                              \n",createdate,planner);fflush(fp1);
									ITKCALL(AOM_ask_value_string( PETag, "t5_PegrpL", &pegrpldr));
									printf("\npegrpldr is ",pegrpldr);
									ITKCALL(AOM_ask_value_string( PETag, "t5_PePlnrCo", &Peplanner));
									printf("\npe planner is ",Peplanner);
									fprintf(fp1,"Group Leader  : %s                 PE Planner   : %s                                     \n",pegrpldr,Peplanner);fflush(fp1);
									fprintf(fp1,"-----------------------------------------------------------------------------------------\n");fflush(fp1);
									fprintf(fp1,"                                                                                         \n");fflush(fp1);
									ITKCALL(AOM_ask_value_string( PETag, "t5_PEStatus", &pestatus));
									printf("\npestatus is ",pestatus);
									fprintf(fp1,"Indent No    : %s                           Status       : %s                            \n",item_id,pestatus);fflush(fp1);
									
									GRM_find_relation_type("T5_PEToolIndentToPartRel",&relation_type);
									ITKCALL(GRM_list_secondary_objects_only(PETag,relation_type,&count,&Ercpart));
									printf("\n\n\t\t pe indent to erc part : %d",count);fflush(stdout);
									for (i=0;i<count ;i++ )
									{
                                        revseq = NULL;
										ErcPartTag=NULLTAG;
										ErcPartTag = Ercpart[i];
										ITKCALL(AOM_ask_value_string( ErcPartTag, "item_id", &partid));
										printf("\n  erc part is--> %s\n", partid);fflush(stdout);
										
										ITKCALL(AOM_ask_value_string( ErcPartTag, "current_revision_id", &revision));
										printf("\n  revision is--> %s\n", revision);fflush(stdout);																			
										
										ITKCALL(AOM_ask_value_string( ErcPartTag, "t5_DrawingNo", &drawingno));
										printf("\n  drawingno is--> %s\n", drawingno);fflush(stdout);
										
										ITKCALL(AOM_ask_value_string( ErcPartTag, "current_desc", &desc));
										printf("\n  desc is--> %s\n", desc);fflush(stdout);
									}

									fprintf(fp1,"Part Number  : %s                   Drawing No   : %s                                   \n",partid,drawingno);fflush(fp1);
									fprintf(fp1,"Description  : %s                                                                       \n",desc);fflush(fp1);
									
									ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&Prt_Task_Rel_Typ));
									ITKCALL(GRM_list_primary_objects_only(ErcPartTag,Prt_Task_Rel_Typ,&Tsk_count,&Tsk_list));
													printf("\n\n\t\t part to task count : %d",Tsk_count);fflush(stdout);
									for (it=0;it<Tsk_count ;it++ )
									{
										tasktag = Tsk_list[it];
										ITKCALL(AOM_ask_value_string( tasktag, "item_id", &tasknum));
										printf("\n  task num is--> %s\n", tasknum);fflush(stdout);
										dmlnum=subString(tasknum,0,10);
										
										ITKCALL(AOM_ask_value_string( tasktag, "owning_project", &projectcode));
										printf("\n  projectcode is--> %s\n", projectcode);fflush(stdout);
										break;
									}
									fprintf(fp1,"DML/PMR No   : %s                                                                       \n",dmlnum);fflush(fp1);
									fprintf(fp1,"Project code : %s                                                                       \n",projectcode);fflush(fp1);
									fprintf(fp1,"Project Desc :                                                                          \n");fflush(fp1);
									fprintf(fp1,"Mod No       : %s                                                                       \n",revision);fflush(fp1);
									fprintf(fp1,"                                                                                        \n");fflush(fp1);
									fprintf(fp1,"----------------------------------------------------------------------------------------\n");fflush(fp1);
									fprintf(fp1,"Sr         ToolNo        AgnTo      AgnFor       Action      BCNo                       \n");fflush(fp1);
									fprintf(fp1,"----------------------------------------------------------------------------------------\n");fflush(fp1);
									
											ITKCALL(AOM_ask_value_string( PETag, "owning_user", &ownuser));
											printf("\n ownuser is %s",ownuser);
										/*
											tc_strcpy(env_subject,"Review estimated cost of Indent ");
											tc_strcat(env_subject,item_id);
											tc_strcpy(env_body,"Dear Sir,\n\nEstimated cost for tools in indent ");
											tc_strcat(env_body,item_id);
											tc_strcat(env_body,"  are as follows:");
										*/						
																
										GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&IndentDummy_rel_type);
										ITKCALL(AOM_ask_value_tags(PETag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt,&dmmyPartTags));
										printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt);fflush(stdout);
										if (dmmyPartCnt>0)
										{
											for (k=0;k<dmmyPartCnt ;k++ )
											{	
												dummy_id=NULL;
												dmydrwgind=NULL;
												dmmyTag = NULLTAG;
												dmmyTag=dmmyPartTags[k];
												
												ITKCALL(AOM_ask_value_string(dmmyTag, "item_id", &dummy_id));
												printf("\n dummy id is =:%s",dummy_id);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(dmmyTag, "t5_DmyToolDrwInd", &dmydrwgind));
												printf("\n dmydrwgind is =:%s",dmydrwgind);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(dmmyTag, "current_desc", &dmydesc));
												printf("\n dmydesc is =:%s",dmydesc);fflush(stdout);
												
												
												sprintf(srlno,"%d",k+1);
												
													if(PETag != NULLTAG && dmmyTag != NULLTAG && IndentDummy_rel_type != NULLTAG)
													{
														printf("\n  inside loop check\n");fflush(stdout);
														
													  ITKCALL(GRM_find_relation(PETag,dmmyTag,IndentDummy_rel_type,&IndentDummy_rel));
													  printf("\n  inside loop check1111111\n");fflush(stdout);
													  ITKCALL(AOM_ask_value_int(IndentDummy_rel,"t5_Qty1",&unitqty));
													  ITKCALL(AOM_ask_value_int(IndentDummy_rel,"t5_OrdQty1",&ordrqty));

													  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_PETotalTLCost",&Totlestcost));								 
													  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_CstEst",&peunitcost));
													  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_ToolRemark",&dmyremark));
													   printf("\n  inside loop end\n");fflush(stdout);
													}
													
													printf("\n ordrqty:%d  Totlestcost:%s peunitcost:%s",ordrqty,Totlestcost,peunitcost);fflush(stdout);
													
													fprintf(fp1,"%s    %s                                                                             \n",srlno,dummy_id);fflush(fp1);
													fprintf(fp1,"DrwInd         : %s                                                                  \n",dmydrwgind);fflush(fp1);
													fprintf(fp1,"Unit Quantity  : %d                   Unit Tool Cost: %s                             \n",unitqty,peunitcost);fflush(fp1);
													fprintf(fp1,"Order Quantity : %d                                                                    \n",ordrqty);fflush(fp1);
													
													ITKCALL(AOM_ask_value_tags(PETag,"T5_PEToolIndentToPEPrtRel1",&pePartCnt,&pePartTags));
													printf("\n\n\t\t pePartCnt is:%d",pePartCnt);fflush(stdout);
													if (pePartCnt>0)
													{
														for (pk=0;pk<pePartCnt;pk++ )
														{	
															pepart_id=NULL;
															pepartTag = NULLTAG;
															pepartTag=pePartTags[pk];
															
															ITKCALL(AOM_ask_value_string(pepartTag, "item_id", &pepart_id));
															printf("\n pepart_id is =:%s",pepart_id);fflush(stdout);
															fprintf(fp1,"Total Tool Cost: %s                    ActualToolNo  : %s                        \n",Totlestcost,pepart_id);fflush(fp1);
														}
													}else
													{
													 fprintf(fp1,"Total Tool Cost: %s                   ActualToolNo  :                             \n",Totlestcost);fflush(fp1);
													}
													
													fprintf(fp1,"Tool Desc      : %s                                                                \n",dmydesc);fflush(fp1);
													fprintf(fp1,"Tool Remark    : %s                                                                \n",dmyremark);fflush(fp1);
													ITKCALL(AOM_ask_value_tags(dmmyTag,"T5_DmyToolToOperation",&dmmyopratnCnt,&dmmyopernTags));
													if (dmmyopratnCnt>0)
													{
														ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "item_id", &oprtnnum));
														printf("\n oprtnnum is =:%s",oprtnnum);fflush(stdout);
												
														ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEPlantCode", &plantcode));
														printf("\n plantcode is =:%s",plantcode);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEPlantDesc", &plantdesc));
														printf("\n plantdesc is =:%s",plantdesc);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_PEAplMcNo", &machinno));
														printf("\n machinno is =:%s",machinno);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(dmmyopernTags[0], "t5_APLMCDesc", &machindesc));
														printf("\n machindesc is =:%s",machindesc);fflush(stdout);
													}

													fprintf(fp1,"Operaton No    : %s                                                                    \n",oprtnnum);fflush(fp1);
													fprintf(fp1,"Plant Code     : %s            Plant Desc : %s                                         \n",plantcode,plantdesc);fflush(fp1);
													fprintf(fp1,"M/C No         : %s             M/C Desc  : %s                                         \n",machinno,machindesc);fflush(fp1);
													
													fprintf(fp1,"                                                                                        \n");fflush(fp1);
													fprintf(fp1,"----------------------------------------------------------------------------------------\n");fflush(fp1);
													fprintf(fp1,"                                                                                        \n");fflush(fp1);
													

											}
										}				   
								
									   fprintf(fp1,"APL Project          : %s                                                               \n",projcttype);fflush(fp1);
									   fprintf(fp1,"Indent Remark        : %s                                                               \n",indentremark);fflush(fp1);
									   fprintf(fp1,"Cancellation Remark  :                                                                  \n");fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"      %s                                                %s                              \n",pegrpldr,Peplanner);fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"      Group Leader                                         PE Planner                   \n");fflush(fp1);
									   fprintf(fp1,"                                                                                        \n");fflush(fp1);
									   fprintf(fp1,"=================================END OF REPORT========================================= \n");fflush(fp1);
								}
								
								
								
								fclose(fp1);
								printf("\n Input File Closed Successfully..!!\n");fflush(stdout);

								tag_t datasettype, NewTextDS, Fndrelation = NULLTAG;
						
								if(AE_find_datasettype2("Text", &datasettype)==ITK_ok)
								if (datasettype == NULLTAG)
								{
									printf("\n Dataset Type 'Text' not found!\n");fflush(stdout);
									//exit (EXIT_FAILURE);
								}
								else
								{
											
									if(AE_find_tool2("Notepad", &tool));
									if(AE_create_dataset_with_id(datasettype,FileName,"", NULL, NULL, &NewTextDS));
									if(AE_set_dataset_tool(NewTextDS,tool));
									if(AE_set_dataset_format2(NewTextDS, "TEXT_REF"));
									if(AOM_save_without_extensions(NewTextDS));
									if(IMF_fmsfile_import(FileNamepath, FileName,SS_TEXT, &filetag, &fileDescriptor));
									if(filetag == NULLTAG)
									{
										printf("file tag not found.....");fflush(stdout);
									}
									if(AOM_refresh(NewTextDS, TRUE));
									if(AE_add_dataset_named_ref2(NewTextDS, "Text", AE_PART_OF, filetag));
									if(AOM_save_without_extensions(NewTextDS));
									//Attaching the dataset to Reference folder
									if(GRM_find_relation_type("IMAN_reference", &req_rel_t)!=ITK_ok);

									if(req_rel_t != NULLTAG)
									{
										if(GRM_create_relation(PETag,NewTextDS,req_rel_t, NULLTAG, &ds_req_rel_t));
										if(ds_req_rel_t != NULLTAG)
										{
											printf("\nThe dataset is attached to the Reference folder of PE");fflush(stdout);
										}
										else
										{
											printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
										}
										if(GRM_save_relation(ds_req_rel_t));
									}					
									
								} 
							/*	
							printf("\n indent release status is =%s",WSO_Name);fflush(stdout);
							
							if(tc_strcmp(WSO_Name,"T5_LcsEstimated")==0)
							{	
									printf(" inside mail start...");fflush(stdout);
									ITKCALL(SA_find_user (Peplanner, &Analyst_user_tag));
									if(Analyst_user_tag != NULLTAG)
									{
									  ITKCALL(AOM_ask_value_tag(Analyst_user_tag,"person",&Analyst_person_tag));

									  ITKCALL(SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr));
									  printf("\n Person EMAIL Address =%s",Analyst_email_addr);fflush(stdout);
									}
								
								printf(" Mail Body String :%s",env_body);fflush(stdout);
								ITKCALL(MAIL_create_envelope(env_subject, env_body, &envelope));

								if(envelope != NULLTAG)
								{
									ITKCALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
									if(Analyst_email_addr!=NULL)
									{
									   ITKCALL(MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr));

									}
									
									ITKCALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"deeptim.ttl@tatamotors.com"));
									ITKCALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"sachind1.ttl@tatamotors.com"));
									ITKCALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
									printf("\n countenvelop %d\n",countenvelop);fflush(stdout);
									ITKCALL(MAIL_send_envelope(envelope));
									printf("\n Mail Send Successfully");fflush(stdout);
									
											MEM_free(env_body);
											MEM_free(env_subject);
								}
								else
								{
									printf("\n Unable to  Send MAil");fflush(stdout);
								}
							}
							*/
				    }
					else
					{
						t5GenerateToolIndentReport(PETag);
					}
							
				}

			}

		}				
	
	return error_code;

}


extern int tm_petoolindent_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method;
    int ifail=0;  

 
  
  /*
  if ( METHOD_find_method("T5_TryoutRevision", ITEM_create_msg, &method1) !=ITK_ok);PrintErrorStack();
  

   if (method1.id != NULLTAG)
   {
			if( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) create_Tryout, NULL)!=ITK_ok);PrintErrorStack();
			printf("\n rrrrrrrrRegistered as Post-Action for create_Tryout_Msg  Creation create_Tryout_Msg\n");fflush(stdout);
   }else
		{
			printf("\nMethod not found!create_Tryout_Msg\n");fflush(stdout);
		}
 */


   ifail = METHOD_find_method("T5_PEToolIndentRevision", TC_save_msg, &method);
   if (method.id != NULLTAG)
   {
			ifail = METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Save_PeToolIndent_Msg, NULL)!=ITK_ok;
			printf("\nrrrrrrrrRegistered as Post-Action for T5_PEToolIndentRevision Save\n");fflush(stdout);
   }else
		{
			printf("\nMethod not found!TC_save_msg T5_PEToolIndentRevision\n");fflush(stdout);
		}

/*

	  if( ITK_ok == EPM_register_rule_handler ("tryout_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)tryout_signoff_checks_Func))
	   {
			printf("\t\n Registered Rule Handler tryout_signoff_checks_Func\n");fflush(stdout);
	   }else
	   {
			printf("\t FAILED to register Rule Handler tryout_signoff_checks_Func\n");fflush(stdout);
	   }

  */

   if( ITK_ok == EPM_register_action_handler("tm_PE_Report", "", tm_PE_Report))
   {
		printf("\t\n Registered Action Handler tm_PE_Report_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_PE_Report\n");fflush(stdout);
   }
   
    return ITK_ok;

}

extern DLLAPI int tm_petoolindent_register_callbacks()
{
	 CUSTOM_register_exit("tm_petoolindent", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_petoolindent_register_method);

     printf("\n registered function tm_petoolindent \n");	fflush(stdout);

	 return ( ITK_ok );
}
