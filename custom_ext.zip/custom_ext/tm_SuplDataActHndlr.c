/*
#include <stdarg.h>
#include <tccore/custom.h>
#include <user_exits/user_exits.h>
#include <ug_va_copy.h>
#include <epm/epm.h>
#include <tcinit/tcinit.h>
#include <epm/epm_task_template_itk.h>

*/
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#include <pie/pie.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

int tm_SuplDataActHndlr_action_handler(EPM_action_message_t msg)
{
	int ifail=0;
	tag_t root_task = NULLTAG ;
	tag_t* attachment_tag = NULLTAG ;
	tag_t Package_Type_tag = NULLTAG ;
	tag_t Package_tag = NULLTAG ;
	char* Package_object_name = NULL ;
	char* SuppDataExeDir = NULL ;
	char* ExeCommandLine = NULL;
	char* SesUser = NULL;

	//char ObjectType[TCTYPE_name_size_c+1] ;
	char *ObjectType=NULL ;
	int no_attachment = 0 ;

	ExeCommandLine = (char *) MEM_alloc(1000*sizeof(char ));

	POM_get_user_id (&SesUser);
	printf("\n : Session user: %s\n",SesUser); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task, &root_task));
	ITK_CALL(EPM_ask_attachments(root_task,EPM_target_attachment,&no_attachment,&attachment_tag));
	if ( no_attachment > 0 )
	{
		Package_tag = attachment_tag[0] ;
		ITK_CALL(TCTYPE_ask_object_type(Package_tag,&Package_Type_tag));
		//ITK_CALL(TCTYPE_ask_name(Package_Type_tag,ObjectType)) ;
		ITK_CALL(TCTYPE_ask_name2(Package_Type_tag,&ObjectType)) ;
		printf("ObjectType:%s\n",ObjectType);
		TC_write_syslog("ObjectType:%s\n",ObjectType);
		if ( tc_strcmp ( ObjectType,"T5_Package" )  == 0 )
		{
			ITK_CALL(AOM_UIF_ask_value(Package_tag,"object_name",&Package_object_name));
			printf ( "Package_object_name:%s\n", Package_object_name ) ;fflush(stdout);
			TC_write_syslog ( "Package_object_name:%s\n", Package_object_name ) ;

			ITK_CALL( PREF_ask_char_value("SuppDataDownExeDir", 0 , &SuppDataExeDir ) );
			printf("\nSuppDataExeDir**:%s",SuppDataExeDir ) ;fflush(stdout);

			if( SuppDataExeDir == NULL )
			{
				printf("\npreference not found hence default value is /tmp");fflush(stdout);
				SuppDataExeDir=(char *) MEM_alloc(50 * sizeof(char ));
				tc_strcpy(SuppDataExeDir,"/tmp/");
			}

			tc_strcpy(ExeCommandLine,SuppDataExeDir);
			tc_strcat(ExeCommandLine,"tm_DownloadSupplierData.sh");
			tc_strcat(ExeCommandLine," ");
			tc_strcat(ExeCommandLine,"\"");
			tc_strcat(ExeCommandLine,Package_object_name);
			tc_strcat(ExeCommandLine,"\"");
			tc_strcat(ExeCommandLine," ");
			tc_strcat(ExeCommandLine,SesUser);
			tc_strcat(ExeCommandLine," ");
			tc_strcat(ExeCommandLine,"&");

			//system("/home/uadev/devgroups/dbk/ActionHandler/SupplierDataActionHandler2/a.out &");
			printf("\nExeCommandLine : %s",ExeCommandLine);fflush(stdout);
			system(ExeCommandLine);
		}
	}

	return ifail; 
}
int tm_SuplDataActHndlr_register_action_handler(int *decision, va_list args)
{
	int ifail = ITK_ok;
	printf("SuplDataActHndlr_register_action_handler\n");
	TC_write_syslog ("SuplDataActHndlr_register_action_handler\n");
	ifail = EPM_register_action_handler("tm_SuplDataActHndlr-action-handler", "", tm_SuplDataActHndlr_action_handler);
	if (ifail == ITK_ok)        
		TC_write_syslog("\tRegistered SuplDataActHndlr_action_handler!\n");
	else    
		TC_write_syslog("\tFAILED to register SuplDataActHndlr_action_handler\n");
	return ifail;
}
       
                   
extern DLLAPI int tm_SuplDataActHndlr_register_callbacks ()
{
	printf("\n SuplDataActHndlr_register_callbacks \n");
	TC_write_syslog ("\n SuplDataActHndlr_register_callbacks \n");
	CUSTOM_register_exit ( "tm_SuplDataActHndlr", "USER_init_module",(CUSTOM_EXIT_ftn_t) tm_SuplDataActHndlr_register_action_handler );
	return ITK_ok;
}
