/*****************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   DML release letter in DML WF..
*  Code                 :   tm_ERC_DML_Release_Report.c
*  Created on			:   26/03/2023
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		26/03/2023				Mohan Tayade		DML release letter in DML WF..
*******************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_ERC_DML_Release_Report(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int      no_attach      =  0;
	int error_code = ITK_ok;
	tag_t *taskAttachments=NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t   DMLqryTag     = NULLTAG;
	tag_t	objTag		= NULLTAG;
	char	*DML_info1		= NULL;
	char	*DML_info2		= NULL;
	char	*DMLType	= NULL;
	char	*DML_info3	= NULL;
	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	int      i      =  0;
	int    transfermodeCnt=0;
	char	*revId			=  NULL;
	char	*ReportName			=  NULL;
	char	*sDMLrlstype			=  NULL;
	char	*dmlNumber			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=  NULL;
	tag_t dml_Ref_Rel	= NULLTAG;
	tag_t dml_Ref_Rel_t	= NULLTAG;
	/*char *mainFile =  NULL;
	char *command =  NULL;
	char *docFile =  NULL;*/

	char	mainFile[500];
	char	command[900];
	char	docFile[500];
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	tag_t *transfermodes=NULLTAG;
	int     DML_rsltCount      =  0;
	int     DML_n_entry    = 1;
	char    *DML_qry_entry[1]  = {"SYSCD"};
	char    **DML_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	//const char *attrs2[1];
	//const char *values2[1];
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	//attrs2[0] ="item_id";
	//attrs2[1] ="object_type";
	//values2[0] = (char *)Input_id;
	//values2[1] = "Design";
	/*command=(char *)MEM_alloc(800);
	mainFile=(char *)MEM_alloc(500);
	docFile=(char *)MEM_alloc(500);*/
	ReportName=(char *)MEM_alloc(100);
	
	printf("\n tm_ERC_DML_Release_Report Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ERC_DML_Release_Report Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control Table for Assign dynamic party
				printf("\n L1:.Control Table for Assign dynamic party....\n"); fflush(stdout);
				if(QRY_find2("ControlObjects", &DMLqryTag));
				if (DMLqryTag)
				{
					printf("\n L2:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n L3:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DML_qry_values2[0] = "DMLRLZD";
				if(QRY_execute(DMLqryTag, DML_n_entry, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
				printf(" \n L4:DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
				if(DML_rsltCount > 0)
				{
					//ONOFF
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo1",&DML_info1)!=ITK_ok)   PrintErrorStack();
					printf("\n L5:DML_info1 is.:[%s]\n", DML_info1);fflush(stdout);
					//All eligible DML Types: ,TSKR,MR,TODR,EP,RBQU,Veh,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo2",&DML_info2)!=ITK_ok)   PrintErrorStack();
					printf("\n L6:DML_info2 is.:[%s]\n", DML_info2);fflush(stdout);
					//Path: shell path:/home/mtt07979/DMLReport/DMLRelRptUaprod.sh
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo3",&DML_info3)!=ITK_ok)   PrintErrorStack();
					printf("\n L7:DML_info3 is.:[%s]\n", DML_info3);fflush(stdout);
					if(tc_strstr(DML_info1,"S1") == NULL)
					{
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&dmlNumber)!=ITK_ok)PrintErrorStack();
						printf("\n L8:DML Number: [%s]", dmlNumber);fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"item_revision_id",&revId)!=ITK_ok)PrintErrorStack();
						printf(" and revId: [%s]", revId);fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						printf(" and DMLType: [%s]", DMLType);fflush(stdout);
						sDMLrlstype=(char *)MEM_alloc(20);
						tc_strcpy(sDMLrlstype,"");
						tc_strcpy(sDMLrlstype,",");
						tc_strcat(sDMLrlstype,DMLType);
						tc_strcat(sDMLrlstype,",");
						printf("\n L9:sDMLrlstype: [%s]",sDMLrlstype);fflush(stdout);

						if(tc_strstr(DML_info2,sDMLrlstype) != NULL)
						{
							tc_strcpy(mainFile,"");
							tc_strcat(mainFile,"/tmp/");
							tc_strcat(mainFile,dmlNumber);
							tc_strcat(mainFile,"_");
							tc_strcat(mainFile,revId);
							tc_strcat(mainFile,".xml");
							TC_write_syslog("Main File = %s\n",mainFile);
							printf("\n L10:mainFile: [%s]", mainFile);fflush(stdout);
							//Report name
							tc_strcpy(ReportName,"");
							tc_strcpy(ReportName,dmlNumber);
							tc_strcat(ReportName,"_DML_Release_Letter_Report");
							TC_write_syslog("ReportName = %s\n",ReportName);
							printf("\n L11:ReportName: [%s]", ReportName);fflush(stdout);

							tc_strcpy(docFile,"");
							tc_strcat(docFile,"/tmp/");
							tc_strcat(docFile,dmlNumber);
							tc_strcat(docFile,"_DML_");
							tc_strcat(docFile,revId);
							tc_strcat(docFile,".doc");
							TC_write_syslog("Doc File = %s\n",docFile);
							printf("\n L12:docFile: [%s]", docFile);fflush(stdout);

							if(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel)!=ITK_ok)PrintErrorStack();
							if(PIE_create_session(&PLMSession)!=ITK_ok)PrintErrorStack();
							if(PIE_session_set_file(PLMSession,mainFile)!=ITK_ok)PrintErrorStack();
							if(PIE_find_transfer_mode2("T5_DML_Release_Letter_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes)!=ITK_ok)PrintErrorStack();
							TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);
							if(PIE_session_set_transfer_mode(PLMSession,transfermodes[0])!=ITK_ok)PrintErrorStack();
							if(PIE_session_export_objects(PLMSession,1,&taskAttachments[i])!=ITK_ok)PrintErrorStack();
							//sprintf(command,"java -classpath /home/uadev/TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadev/TC_ROOT/bin/tml_tools/DML_print_report_template.xsl >/tmp/wfout.log",mainFile,dmlNumber);
							//sprintf(command,"java -classpath /home/uadev/TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadev/TC_ROOT/bin/tml_tools/DML_print_report_template.xsl >/tmp/wfout.log",mainFile,dmlNumber);
							//sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/apply.sh %s %s",mainFile,docFile);
							//CMITEST
							//sprintf(command,"/user/testcmi/Dev/devgroups/mohan/Report/tm_ERC_DML_Release_Report/DMLRelRpt.sh %s %s",mainFile,docFile);
							//UAPROD
							if(tc_strstr(DML_info1,"S2") == NULL)
							{
								sprintf(command,"%s %s %s",DML_info3,mainFile,docFile);
							}
							else
							{
								sprintf(command,"/home/mtt07979/DMLReport/DMLRelRptUaprod.sh %s %s",mainFile,docFile);
							}
							TC_write_syslog("Command = %s\n",command);
							printf("\n L13:going to run java command.. ");fflush(stdout);
							//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
							system(command);

							TC_write_syslog("Doc file created successfully\n");
							if(AE_find_datasettype2("MSWord",&msWordType)!=ITK_ok)PrintErrorStack();
							if(msWordType == NULLTAG)
							{
								TC_write_syslog("Could not find Dataset Type MSWord. Please check data model\n");
								//continue;
							}
							if(AE_create_dataset_with_id(msWordType,ReportName,"DML Release Report for DML","","",&wordDataset)!=ITK_ok)PrintErrorStack();
							printf("\n L14:create dataset done..");fflush(stdout);
							//if(AE_create_dataset_with_id(msWordType,dmlNumber,"DML Release Report for DML","","",&wordDataset)!=ITK_ok)PrintErrorStack();
							if(AE_save_myself(wordDataset));
							printf(" and saved.");fflush(stdout);
							if(GRM_create_relation(taskAttachments[i],wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
							printf("\n L15:create relation done..");fflush(stdout);
							if(AOM_load(dml_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
							printf(" and load.");fflush(stdout);
							if(GRM_save_relation(dml_Ref_Rel_t)!=ITK_ok)PrintErrorStack();
							printf(" and saved..");fflush(stdout);
							if(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
							printf("\n L16:get dataset_latest_rev..");fflush(stdout);
							if(AOM_refresh(wordLatestDat_t,TRUE)!=ITK_ok)PrintErrorStack();
							printf(" and refreshed..");fflush(stdout);
							if(AE_import_named_ref(wordLatestDat_t,"word",docFile,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
							printf("\n L17:Import data..");fflush(stdout);
							//if(AE_save_myself(wordLatestDat_t)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(wordLatestDat_t)!=ITK_ok)PrintErrorStack();
							if(AOM_refresh(wordLatestDat_t, FALSE)!=ITK_ok)PrintErrorStack();
							if(AOM_unload(wordLatestDat_t)!=ITK_ok)PrintErrorStack();
							printf(" and save dataset..");fflush(stdout);
							//Send mail logic
							if(tc_strstr(DML_info1,"K11") != NULL)
							{
								remove(docFile);
							}
							printf("\n L18:process completed.....");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_ERC_DML_Release_Report Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ERC_DML_Release_Report Function end...");

	//return error_code;
	return 0;
}