#include "TMLLibrary_server_exits.h"

int tm_assign_Ecertreviewer(EPM_action_message_t msg)
{
	tag_t	roottask                 =  NULLTAG;
	tag_t	DMLRevTag			         =  NULLTAG;
	tag_t	queryTag			     =  NULLTAG;
	tag_t	qryTag			         =  NULLTAG;
	tag_t	Project_t			     =  NULLTAG;
	tag_t	EcertReviewer_Party		 =  NULLTAG;
	tag_t	EcertReviewer_Patri_type =  NULLTAG;
	tag_t	EcertRole_tag			 =  NULLTAG;
	tag_t	EcertGrp_tag			 =  NULLTAG;
	tag_t	objTypTag		         = NULLTAG;
	tag_t   *attachment              =  NULLTAG;
	tag_t   *t5_Project              =  NULLTAG;
	tag_t   *CntrlObjectTag          =  NULLTAG;
	tag_t   *EcertReviewer_tag       =  NULLTAG;
	int      no_attach               =  0;
	int      n_entries               =  1;
	int      i                       =  0;
	int      iii                     =  0;
	int      n_entry                 =  1;
	int      rsltCount               =  0;
	int      No_EcertReviewer        =  0;
	int      resultCount             =  0;
	int      ifail             =  ITK_ok;
	char	*DMLType		         =  NULL;
	char	*DMLNo			         =  NULL;
	char	*groupName		         = NULL;
	char	*DsgGrp			         = NULL;
	char	*Task_name		         = NULL;
	char	*sDMLBU		             = NULL;
	char	*ProjectID		         = NULL;
	char	*Proj_PltFrm		     = NULL;
	char	*EcertReviewer		     = NULL;
	char	*ErrorText		         = NULL;
	char *qry_entries[1]             = {"Name"};
	char *qry_entry[1]               = {"SYSCD"};
	char **qry_values                =(char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values2               = (char **) MEM_alloc(20 * sizeof(char *));
	qry_values2[0]                   = "ECert_PVBU";
	char*   ObjTyp= NULL;;
	logical hasbypass =true;
	groupName = (char	*)MEM_alloc(100);

	printf("\n tm_assign_Ecertreviewer Function started...");fflush(stdout);
	TC_write_syslog("\n tm_assign_Ecertreviewer Function started...");

	tc_strcpy(groupName,"ECert_Approver");
	printf("\n PD: groupName  --> %s\n",groupName);   fflush(stdout);

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PD:No of Attachements: [%d]", no_attach);fflush(stdout);
	
	if(no_attach >0)
	{
	for(i=0;i<no_attach;i++)
    {
		DMLRevTag=attachment[i];
		if(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
		if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
		printf("\n PD: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

		if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
		{
			if(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
			printf("\n PD:DML/Task Number: [%s].", DMLNo);fflush(stdout);
			if(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&sDMLBU)!=ITK_ok)PrintErrorStack();
			printf("\n CH:sDMLBU is :%s\n",sDMLBU);fflush(stdout);
			if(tc_strstr(sDMLBU,"CV") != NULL)
			{
				printf("\n PD:Assign dynamic Party handler bypassed for CVBU..");fflush(stdout);
			}
			else
			{
				if(QRY_find2("ControlObjects", &qryTag));
				if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
				printf(" \n PDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
				if(rsltCount > 0)
				{
						if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
						printf("\n PD: ProjectID : %s",ProjectID);   fflush(stdout);
					  if(ProjectID)
						{
							if(QRY_find2("Qury_Project", &queryTag));
							printf("\n PD:After Prd_Project: QRY_find2");fflush(stdout);
							qry_values[0] = ProjectID;
		
							if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
							printf("\n PD: resultCount : %d\n", resultCount); fflush(stdout);
		
							if(resultCount > 0)
							{
								printf("\n PD:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
								Project_t = t5_Project[0];
								if (Project_t!=NULLTAG)
								{
									
									if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
									printf("\n PD: Proj_PltFrm :[%s]\n",Proj_PltFrm);   fflush(stdout);
									//Query control table for PRDtoCVBU workflow project list.
									printf("\n PD:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
									
										  EcertReviewer = (char	*)MEM_alloc(100);
															tc_strcpy(EcertReviewer,"");
															tc_strcpy(EcertReviewer,Proj_PltFrm);
															tc_strcat(EcertReviewer,"_");
															tc_strcat(EcertReviewer,"ECertReview");
													//VI Reviewer for SVR only.
													printf("\n PD:PCBU: Certification Reviewer...");fflush(stdout);
													if(SA_find_group(groupName, &EcertGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(EcertReviewer,&EcertRole_tag)!=ITK_ok)PrintErrorStack();
													if(EcertRole_tag ==NULLTAG)
													{
												printf("\n PD:PCBU: Project Role not found Assigning from generic role...");fflush(stdout);
														if(SA_find_role2("Gen_ECertReview",&EcertRole_tag)!=ITK_ok)PrintErrorStack();
													}
													if(SA_find_groupmember_by_role(EcertRole_tag,EcertGrp_tag,&No_EcertReviewer,&EcertReviewer_tag)!=ITK_ok)PrintErrorStack();
													printf("\n PD:PCBU:No_EcertReviewer :[%d]",No_EcertReviewer);  fflush(stdout);
													if(No_EcertReviewer>0)
													{
														for(iii=0;iii<No_EcertReviewer;iii++)
														{	
														printf("\n PD:PCBU: No_EcertReviewer: [%d]",iii);fflush(stdout);
														if(EPM_get_participanttype ("T5_CertificatnReviewer",&EcertReviewer_Patri_type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(EcertReviewer_tag[iii],EcertReviewer_Patri_type,&EcertReviewer_Party)!=ITK_ok)PrintErrorStack();
														ifail=AOM_lock(DMLRevTag);			
														//ifail=ITEM_rev_add_participant(DMLRevTag,EcertReviewer_Party);
														ITK_CALL(PARTICIPANT_add_participant(DMLRevTag,hasbypass,EcertReviewer_Party));
														if(ifail != ITK_ok)
															{
															AOM_unlock(DMLRevTag);
															EMH_ask_error_text(ifail,&ErrorText);
															}
															else
															{
															AOM_save_without_extensions(DMLRevTag);
															AOM_refresh(DMLRevTag,0);
															AOM_unlock(DMLRevTag);
															}
															
														}
													}
													
													/*if(EcertReviewer)
													{
													MEM_free(EcertReviewer);
													}*/
									}
														  
								}
												
							}
					
				}
			}
		}
		else
		{
			 printf("\n Not a valid Type. \n");fflush(stdout);
			 return 0;
		}
	}
	printf("\n tm_assign_Ecertreviewer Function end...");fflush(stdout);
	TC_write_syslog("\n tm_assign_Ecertreviewer Function end...");
	/*if(DMLNo)
	{
	MEM_free(DMLNo);
	}
	if(sDMLBU)
	{
	MEM_free(sDMLBU);
	}
	if(ProjectID)
	{
	MEM_free(ProjectID);
	}
	if(Proj_PltFrm)
	{
	MEM_free(Proj_PltFrm);
	}*/
	}
	//return ITK_ok;
	return 0;
}


