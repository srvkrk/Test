#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ReadFile.h>
#include <ft.h>
#include <tel.h>

int main(int argc,char *argv[])
{	
	int stat=0;	
	int i = 0;
	FILE			*fp_logt				= NULL;
	string LoginS = NULL;
	string PassWordS = NULL;
	string selectedVaultS = NULL;
    string     EventObjIdS		= NULL;
	string     EventObjIdDupS		= NULL;
	string     Indent		= NULL;
	string			out		= NULL;
	string			CreationDate		= NULL;
	string			ToDateS		= NULL;
	string			DesignDupS		= NULL;
	string			DesignS		= NULL;
	ObjectPtr	EventObject			= NULL;
	SetOfObjects	EventObjectSO		= NULL;
	SetOfObjects	ProcHistSO		= NULL;
	SetOfObjects	ProcHistRelSO		= NULL;
	string     FromDateDupS		= NULL;
	string     ToDateDupS		= NULL;
	SqlPtr QueryPartSql		= NULL;
	string			filename_WIPt		= NULL;
	time_t now;
	struct tm *tm;
   string           year	= NULL;
   string           month	= NULL;
   string           date	= NULL;
   string           hour	= NULL;
   string           hour1	= NULL;
   string           min	= NULL;
   string           sec	= NULL;
   string           Newdate	= NULL;
   string           todate1	= NULL;
   string	tok =	NULL;
   string	tok1 =	NULL;
   string	PartFmyDupS =	NULL;
   string	PartFmyS =	NULL;
    string docobjst	= NULL;
    string NewHr	= NULL;
    string NewHr2	= NULL;
	int ii = 0;
	int length = 0;
	int length2 = 0;
	SetOfStrings      dbScpe	=          NULL;
	t5MethodInitWMD("DeleteWorkLoc");
	
	LoginS=nlsStrAlloc(100);
	PassWordS=nlsStrAlloc(100);
	out = nlsStrAlloc(100);
	Indent = nlsStrAlloc(100);
	selectedVaultS=nlsStrAlloc(50);
	CreationDate=nlsStrAlloc(100);
	Newdate=nlsStrAlloc(100);
	filename_WIPt=nlsStrAlloc(50000);

	CreationDate=argv[1];
	ToDateS=argv[2];
	printf("\nArg1:[%s]",CreationDate);
	printf("\nArg2:[%s]",ToDateS);

	// enable multibyte features of Metaphase 
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	// Check to see if the Metaphase network is available. If not, set dstat.
	t5CheckDstat(clTestNetwork ());

	//  Initialize the command line session.    
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 ("super user","abc123",&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PassWordS);  fflush(stdout);
		goto CLEANUP;
	}

	printf("\nConnection Successful\n");	

	/////////////DB Preference //////////////////////////
    t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScpe,mfail));
	for (ii=0;ii<setSize(dbScpe) ; ii++)
	{
		docobjst=low_set_get(dbScpe,ii);
		printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	t5CheckDstat(getDataBaseSetByUser(&dbScpe,"+,+,-,-,-",mfail));
	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScpe,mfail));	
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScpe,mfail));
	for (ii=0;ii<low_set_size(dbScpe) ; ii++)
	{
		docobjst=low_set_get(dbScpe,ii);
		printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}
	//////////////////////////////////////////////////////////

			FromDateDupS=nlsStrAlloc(200);
				
			nlsStrCpy(FromDateDupS,CreationDate);
				
			nlsStrCat(FromDateDupS,"-20:00:01");

			printf("\n\n Input From Date After Append  is: %s \n",FromDateDupS);

			ToDateDupS=nlsStrAlloc(200);
			
			nlsStrCpy(ToDateDupS,ToDateS);
			nlsStrCat(ToDateDupS,"-23:59:59");
				
			printf("\n\n Input To Date After Append is: %s \n",ToDateDupS);

			//getting current time/

			  now = time(0);
			  if ((tm = localtime (&now)) == NULL) {printf ("Error extracting time \n");fflush(stdout);}
			
			  year = nlsStrAlloc(10);
			  month = nlsStrAlloc(10);
			  date = nlsStrAlloc(10);
			  hour = nlsStrAlloc(10);
			 hour1 = nlsStrAlloc(10);
			  min = nlsStrAlloc(10);
			  sec = nlsStrAlloc(10);
			
			  nlsStrCpy(year,"");
			  nlsStrCpy(month,"");
			  nlsStrCpy(date,"");
			  nlsStrCpy(hour,"");
			  nlsStrCpy(min,"");
			  nlsStrCpy(sec,"");
		   
			  sprintf(year,"%d",tm->tm_year+1900-2000);
			  sprintf(month,"%d",tm->tm_mon+1);
			  sprintf(date,"%d",tm->tm_mday);
			  sprintf(hour,"%d",tm->tm_hour);
			  sprintf(hour1,"%d",tm->tm_hour-6);
			  sprintf(min,"%d",tm->tm_min);
			  sprintf(sec,"%d",tm->tm_sec);
			printf("\n CURRENT HR  - %s\n",hour);fflush(stdout);
			printf("\n REVISED HR  - %s\n",hour1);fflush(stdout);
			printf("\nMIN - %s\n",min);fflush(stdout);
			printf("\nSEC - %s\n",sec);fflush(stdout);

			printf("\n 77777777777777777777777  \n");fflush(stdout);

			length = nlsStrLen(hour1);
			printf("\n length value of hour1 is ----> %d \n",length);fflush(stdout);

			if(length == 1)
	        {		
      		    NewHr = nlsStrAlloc(100);
				nlsStrCpy(NewHr,"0");
				nlsStrCat(NewHr,hour1);
						
				printf("\n In IF NewHr value is ----> %s \n",NewHr);fflush(stdout);			
	        }
			else
			{
				NewHr = nlsStrAlloc(100);
				nlsStrCpy(NewHr,hour1);
				printf("\n In else  NewHr value is ----> %s \n",NewHr);fflush(stdout);
			}


			
			length2 = nlsStrLen(hour);
			printf("\n length value of length2 is ----> %d \n",length2);fflush(stdout);
			
			if(length2 == 1)
	        {		
      		    NewHr2 = nlsStrAlloc(100);
				nlsStrCpy(NewHr2,"0");
				nlsStrCat(NewHr2,hour);
						
				printf("\n In IF NewHr2 value is ----> %s \n",NewHr2);fflush(stdout);			
	        }
			else
			{
				printf("\n in else value of hr2 \n");fflush(stdout);
				NewHr2 = nlsStrAlloc(100);
				nlsStrCpy(NewHr2,hour);
				printf("\n In else  NewHr2 value is ----> %s \n",NewHr2);fflush(stdout);
			}


			nlsStrCat(NewHr,":00:00");//11:00:00
			nlsStrCat(NewHr2,":00:00");//11:00:00

			
			tok = strtok(FromDateDupS, "-");
			Newdate = tok; 
			printf("\n Newdate    -->>>> %s \n",Newdate);

			tok1 = strtok(ToDateDupS, "-");
			todate1 = tok1; 
			printf("\n todate    -->>>> %s \n",todate1);

			printf("\n $$$$$$$$$ updated from date: %s \n",FromDateDupS);
			printf("\n!!!!!!!!!!!!!!!!!! updated to date: %s \n",ToDateDupS);

			nlsStrCat(FromDateDupS,"-");
			nlsStrCat(FromDateDupS,NewHr);

			nlsStrCat(ToDateDupS,"-");
			nlsStrCat(ToDateDupS,NewHr2);

			
		 oiSqlCreateSelect(&QueryPartSql);
		 oiSqlWhereBegParen(QueryPartSql);
		 if(dstat = oiSqlWhereGT(QueryPartSql,LastUpdateAttr,FromDateDupS));
		 oiSqlWhereAND (QueryPartSql);
		 if(dstat = oiSqlWhereLT(QueryPartSql,LastUpdateAttr,ToDateDupS));
		 oiSqlWhereEndParen(QueryPartSql);
		 oiSqlPrint(QueryPartSql);

		QueryWhere(ModElemClass,QueryPartSql,&EventObjectSO,mfail);
		printf("\nNo. of Keyword Module are %d\n",setSize(EventObjectSO));fflush(stdout);

		if(setSize(EventObjectSO) > 0)
		{
			for (i=0;i< setSize(EventObjectSO); i++ )
			{
				EventObject = low_set_get(EventObjectSO,i);
		
				t5CheckDstat(objGetAttribute(EventObject,t5ModuleDescAttr,&EventObjIdDupS));
				if(!nlsIsStrNull(EventObjIdDupS))EventObjIdS = nlsStrDup(EventObjIdDupS);
				printf("\n kEYWORD FOUND IS -->  [%s]\n",EventObjIdS); fflush(stdout);
				
				t5CheckDstat(objGetAttribute(EventObject,t5ModuleOwnGrpAttr,&DesignDupS));
				if(!nlsIsStrNull(DesignDupS))DesignS = nlsStrDup(DesignDupS);
				printf("\n Design group -->  [%s]\n",DesignS); fflush(stdout);

				t5CheckDstat(objGetAttribute(EventObject,t5PartFamilyAttr,&PartFmyDupS));
				if(!nlsIsStrNull(PartFmyDupS))PartFmyS = nlsStrDup(PartFmyDupS);
				printf("\n Design group -->  [%s]\n",PartFmyS); fflush(stdout);

				nlsStrCpy(filename_WIPt,"/user/omfprod/devgroups/Ajinkya/CronKey/");
				nlsStrCat(filename_WIPt,"partlist");
				nlsStrCat(filename_WIPt,".txt");
			   
				fp_logt = fopen(filename_WIPt,"a");

				//printf("\n File name is -->  [%s]\n",filename_WIPt); fflush(stdout);
				fprintf(fp_logt,"%s^%s^%s^ \n" ,DesignS,EventObjIdS,PartFmyS);fflush(stdout);
					
			}
			fclose(fp_logt);
		}
		else
		{
			printf("\nIn else as no Keyword Module are %d\n",setSize(EventObjectSO));fflush(stdout);
		}

	printf("\n outside the main function of keyword  \n"); fflush(stdout);
	

	CLEANUP:
		printf("\n Inside CLEANUP:");
		if(ProcHistSO) objDisposeAll(ProcHistSO);
		if(ProcHistRelSO) objDisposeAll(ProcHistRelSO);
		if(QueryPartSql) oiSqlDispose(QueryPartSql);
			
	EXIT:
		printf("\n Inside EXIT:");
		t5CheckDstatAndReturn;
}
;
