//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_ModuleTypeImpl
//

#include <T5_newpartreq/T5_ModuleTypeImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_ModuleTypeImpl::T5_ModuleTypeImpl(T5_ModuleType& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_ModuleTypeImpl::T5_ModuleTypeImpl( T5_ModuleType& busObj )
   : T5_ModuleTypeGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_ModuleTypeImpl::~T5_ModuleTypeImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_ModuleTypeImpl::~T5_ModuleTypeImpl()
{
}

//----------------------------------------------------------------------------------
// T5_ModuleTypeImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_ModuleTypeImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_ModuleTypeGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int FunCntrlObjForModuleInformation(const char *aggregates, int* count, tag_t** items)
{
        int ifail = ITK_ok;
        *count = 0;
		int i=0;


        int    	num_to_sort =	1;
        char 	*keys[1] 	= 	{(char *)"t5_Userinfo2"};
        int  	orders[1]  	=	{1};

        tag_t  query    = NULLTAG;
        tag_t  *t_item1 = NULLTAG;
        int             n_found = 0;
        
        printf("\n\n FunCntrlObjForModuleInformation::aggregates==%s \n",aggregates);fflush(stdout);
         

        char	*aggregatesqryentries[] = {(char *)"SYSCD", (char *)"SUBSYSCD",(char *)"Information-1"};
        char	*aggregatesqryvalues[] = {(char *)"Aggregate",(char *)"ModuleGrp",(char *)aggregates};

        QRY_find2("Control Objects...", &query);
		QRY_execute_with_sort(query, 3, aggregatesqryentries, aggregatesqryvalues, num_to_sort, keys, orders, &n_found, &t_item1);

		printf("\n\n FunCntrlObjForModuleInformation::Rows555==%s %d\n",aggregates,n_found);fflush(stdout);
		*count = n_found;
		printf("\n\n FunCntrlObjForModuleInformation::VAL= %d\n",*count);fflush(stdout);
		(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
		
		for(i=0;i<*count;i++)
		{
			(*items)[i] = t_item1[i];
		}
return ifail;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_ModuleTypeImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;
	bool isNull1=false;
	bool isNull2=false;
	char *ErrorMessage = NULL;
	int error_flag = 0;

	std::string obj_val1;
	std::string obj_val2;

    // Call the parent Implementation
	ErrorMessage = (char *)MEM_alloc(300);
	if( JOURNAL_is_journaling() )
	{
		JOURNAL_routine_start( "T5_ModuleTypeImpl::fnd0askLOVValuesBase" );
	   // JOURNAL_address_in( impl );
		JOURNAL_routine_call();
	}
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation
	printf("\n  T5_ModuleTypeImpl Starting Testing !!!>>\n");fflush(stdout);
	try
	{
			//  list_displayable_properties_with_value(operationInputTag);
			Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
			(Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
			if( refOprtnInput!=NULL )
			{
					refOprtnInput->getString("t5_AggregateGrp", obj_val1, isNull1 ); ///get properties from the object
					refOprtnInput->getString("t5_Aggregates", obj_val2, isNull2 ); ///get properties from the object
					

					tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Reason!\n");

					if(isNull1==true)
					{

						error_flag++;
						tc_strcat(ErrorMessage,"Aggregate Group Is not Selected");
					}
					if(isNull2==true)
					{

						error_flag++;
						tc_strcat(ErrorMessage,"Aggregates Is not Selected");
					}
					printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
					if(error_flag>0)
					{
						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);
						(*results)=NULLTAG;
						*nResults=0;
						return PLM_error1;
					}
					if(error_flag==0)
					{
						printf("\n Before Call T5_ModuleTypeImpl::FunCntrlObjForModuleInformation");fflush(stdout);				
						printf("\nGiven AggreGate Group  -->[%s] >>\n",obj_val1.c_str());fflush(stdout);
						printf("\nGiven AggreGates  -->[%s] >>\n",obj_val2.c_str());fflush(stdout);
						
						(*results)=NULLTAG;
						*nResults=0;
						(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
						FunCntrlObjForModuleInformation(obj_val2.c_str(),nResults, results);
						printf("\n After Call T5_ModuleTypeImpl::FunCntrlObjForModuleInformation");fflush(stdout);
					}
			}
			else
			{
				printf("\n--->>>>> T5_AggregatesLOVType::In  NULL refinputtag");fflush(stdout);
			}

		}
		catch( const IFail& ex )
		{
			ifail = ex.ifail();
		}

    return ifail;
}
