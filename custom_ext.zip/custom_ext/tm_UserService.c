#include<tccore/item.h>
#include<tccore/item_errors.h>
#include<ae/ae.h>
#include<ae/ae_types.h>
#include<ae/dataset.h>
#include<ae/dataset_msg.h>
#include<ae/datasettype.h>
#include<ae/vm_errors.h>
#include<ai/sample_err.h>
#include<bom/bom.h>
#include<bom/bom_attr.h>
#include<cfm/cfm.h>
#include<common/emh_const.h>
#include<ecm/ecm.h>
#include<epm/cr.h>
#include<epm/cr_action_handlers.h>
#include<epm/cr_effectivity.h>
#include<epm/cr_errors.h>
#include<epm/epm.h>
#include<epm/epm_errors.h>
#include<epm/epm_toolkit_iman_utils.h>
#include<epm/releasestatus.h>
#include<fclasses/iman_stdlib.h>
#include<fclasses/iman_string.h>
#include<fclasses/iman_time.h>
#include<fclasses/tc_stdlib.h>
#include<fclasses/tc_string.h>
#include<fclasses/tc_time.h>
#include<form/form.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>
#include<ict/ict_userservice.h>
#include<itk/mem.h>
#include<lov/lov.h>
#include<lov/lov_msg.h>
#include<pie/pie.h>
#include<pom/pom/pom.h>
#include<pom/pom/pom_errors.h>
#include<property/prop.h>
#include<ps/ps.h>
#include<ps/ps_errors.h>
#include<publication/ods_itk.h>
#include<res/res_itk.h>
#include<res/reservation.h>
#include<sa/imanfile.h>
#include<sa/sa.h>
#include<sa/tcfile.h>
#include<sa/user.h>
#include<ss/ss_const.h>
#include<ss/ss_errors.h>
#include<stdarg.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include<tc/aliaslist.h>
#include<tc/distributionlist.h>
#include<tc/emh.h>
#include<tc/emh_errors.h>
#include<tc/envelope.h>
#include<tc/folder.h>
#include<tc/iman.h>
#include<tc/iman_arguments.h>
#include<tc/iman_util.h>
#include<tc/preferences.h>
#include<tc/tc.h>
#include<tc/wsouif_errors.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tccore/custom.h>
#include<tccore/grm.h>
#include<tccore/grm_msg.h>
#include<tccore/iman_msg.h>
#include<tccore/imantype.h>
#include<tccore/item.h>
#include<tccore/item_errors.h>
#include<tccore/item_msg.h>
#include<tccore/method.h>
#include<tccore/tcaehelper.h>
#include<tccore/tctype.h>
#include<tccore/workspaceobject.h>
#include<tcinit/tcinit.h>
#include<textsrv/textserver.h>
#include<time.h>
#include<unidefs.h>
#include<user_exits/aiws_ext.h>
#include<user_exits/epm_toolkit_utils.h>
#include<user_exits/user_exits.h>
#define ITK_err 910001
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

#define HANDLE_ERROR_S1(E,S) \
{ EMH_store_initial_error_s1(EMH_severity_error,(E),(S)); return(E); }

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
char	*ClrSchmToVf	= NULL;

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

int ERC_GenerateclrBOM(void* retValue)
{
		int		status;	
		char	*ShellPath	= NULL;
		char	*Platform	= NULL;
		char	*Vrule	= NULL;
		char	*Clrscheme	= NULL;
		char	*CpyClrscheme	= NULL;
		char	*DMLNo	= NULL;
		char	*AliasName	= NULL;
		char	*ClrOwnerName	= NULL;
		char	*ClrVCName	= NULL;
		int		result=0,resultDMLNo	= 0;
		char    command[512];
		tag_t ERCDMLTag = NULLTAG;
		int n_entriesDML = 1;
		char *qry_entries5[1] = {"ID"};
		tag_t *DMLNotags=NULLTAG;
		tag_t ERCDMLObjtag = NULLTAG;
		tag_t ERCDMLTypeTag=NULLTAG;
		tag_t ClrTypeTag=NULLTAG;
		char  ERCDML_name[TCTYPE_name_size_c+1];
		char  Clr_name[TCTYPE_name_size_c+1];
		tag_t relation_type;
		int n_attchs,l =0;
		tag_t  *secondary_objects = NULLTAG;
		tag_t  *ClrPart_objects = NULLTAG;
		char*  Object_id		= NULL;
		tag_t taskRevTag = NULLTAG;
		tag_t CCVSolutionItem;
		int n_ClrPartattchs,k=0;
		char *user_name_string = NULL;
		char *shellpathname = NULL;
		tag_t user_tag = NULLTAG;
		tag_t group = NULLTAG;
		char *AliasDesc = NULL;
		AliasDesc=(char *) MEM_alloc(100 * sizeof(char ));

		char **valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
		shellpathname=MEM_alloc(150);
	
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login( ));
		ITK_CALL(ITK_set_journalling( TRUE ));
		printf("\n ITK_auto_login success---->\n");fflush(stdout);
		
		USERARG_get_string_argument(&ShellPath);
		USERARG_get_string_argument(&Platform);
		USERARG_get_string_argument(&Vrule);
		USERARG_get_string_argument(&Clrscheme);
		USERARG_get_string_argument(&DMLNo);
		USERARG_get_string_argument(&AliasName);
		USERARG_get_string_argument(&ClrVCName);
				
		printf("\n ShellPath-------->  : %s",ShellPath);fflush(stdout);
		printf("\n Platform-------->  : %s",Platform);fflush(stdout);
		printf("\n Vrule-------->  : %s",Vrule);fflush(stdout);
		printf("\n Clrscheme-------->  : %s",Clrscheme);fflush(stdout);
		printf("\n DMLNo-------->  : %s",DMLNo);fflush(stdout);
		printf("\n AliasName-------->  : %s\n",AliasName);fflush(stdout);
		printf("\n ClrVCName-------->  : %s\n",ClrVCName);fflush(stdout);
		
		tc_strcpy(AliasDesc,"'");
		tc_strcat(AliasDesc,AliasName);
		tc_strcat(AliasDesc,"'");
		printf("\n AliasDesc-------->  : %s\n",AliasDesc);fflush(stdout);		
		
		ITK_CALL(POM_get_user_id(&user_name_string));
		printf("\n Session user_name_string : %s",user_name_string);fflush(stdout);

		CpyClrscheme =  strtok(Clrscheme,",");
		printf ("\n CpyClrscheme --> [%s]\n", CpyClrscheme); fflush(stdout);

		strcpy(shellpathname,ShellPath);
		printf("\n shellpathname-------->  : %s\n",shellpathname);fflush(stdout);
		
		printf("\n%s %s %s %s %s %s %s %s\n",shellpathname,Platform,Vrule,CpyClrscheme,DMLNo,AliasDesc,ClrVCName,user_name_string);fflush(stdout);
		sprintf(command,"%s %s %s %s %s %s %s %s",shellpathname,Platform,Vrule,CpyClrscheme,DMLNo,AliasDesc,ClrVCName,user_name_string);
		
		system(command);
		printf("\n ERC_GenerateclrBOM function return successfully---->\n");fflush(stdout);	

		return result;
}

extern DLLAPI int ClrBom_register_userservices(METHOD_message_t *msg, va_list args)
{   
 	int nargs=7;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	inputArgTypes[2]=USERARG_STRING_TYPE;
	inputArgTypes[3]=USERARG_STRING_TYPE;
	inputArgTypes[4]=USERARG_STRING_TYPE;
	inputArgTypes[5]=USERARG_STRING_TYPE;
	inputArgTypes[6]=USERARG_STRING_TYPE;
	retValueType=USERARG_TAG_TYPE;
	
	printf("\n User Service tm_UserService get Call....");fflush(stdout);
	Write_To_Log("\n User Service tm_UserService get Call....\n");    

	USERSERVICE_register_method("GenerateclrBom",(USER_function_t) ERC_GenerateclrBOM, nargs, inputArgTypes, retValueType);

    return ITK_ok;
}

extern DLLAPI int tm_UserService_register_callbacks()
{
   CUSTOM_register_exit("tm_UserService","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t) ClrBom_register_userservices);     

   Write_To_Log("\n Registering Common tm_UserService..........\n");   

   return ITK_ok;
}
