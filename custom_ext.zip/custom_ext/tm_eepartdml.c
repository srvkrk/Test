
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2020 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_eepartdml.c
*
* Description	: > Server side code for EE part and EE DML
*				  > 
* Module  		:	EE Part DML Management
* Since		    :   01-09-2025
* ENVIRONMENT	:   ITK
*
* History
*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 01-09-2025   	 Rajesh Raman Basak			    Server code for EE part and EE DML

* -----------------------------------------------------------------------------
*
*****************************************************************************/


#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <fclasses/tc_time.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <ps/ps_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_basic.h>
#include<ics/ics.h>
#include<ics/ics2.h>
#include<ics/ics_defines.h>
#include<ics/ics_errors.h>
#include <bom/bom_errors.h>
#include <bom/bom_msg.h>
#include <bom/bomlines.h>
#include <common/tc_deprecation_macros.h>
	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}
	#define ITK_EE_Err01 (EMH_USER_error_base +1)
	#define ITK_EE_Err02 (EMH_USER_error_base+2)
	#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
	#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
	static int report_error(char *file, int line, char *call, int status,
	    logical exit_on_error)
	{
	    if (status != ITK_ok)
	    {
		/*int
		    n_errors = 0,
		    *severities = NULL,
		    *statuses = NULL;
			*/
			int n_errors = 0;
			const int 
				*severities=NULL,
				*statuses=NULL;
		const char
		    **messages;
			


		EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
		if (n_errors > 0)
		{
		    ECHO("\n%s\n", messages[n_errors-1]);
		    EMH_clear_errors();
		}
		else
		{
		    char *error_message_string;
		   // EMH_get_error_string (NULLTAG, status, &error_message_string);
		   EMH_ask_error_text(status,&error_message_string);
		    ECHO("\n%s\n", error_message_string);
		}

		ECHO("error %d at line %d in %s\n", status, line, file);
		ECHO("%s\n", call);

		if (exit_on_error)
		{
		    ECHO("Exiting program!\n");
		    exit (status);
		}
	    }

	    return status;
	}

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text(stat,&err_string);				\
		printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/*C substring function: It returns a pointer to the substring */
 
char *substring(char *string, int position, int length)
{
   char *pointer;
   int c;
 
   pointer = malloc(length+1);
   
   if (pointer == NULL)
   {
      printf("Unable to allocate memory.\n");
      exit(1);
   }
 
   for (c = 0 ; c < length ; c++)
   {
      *(pointer+c) = *(string+position-1);      
      string++;  
   }
 
   *(pointer+c) = '\0';
 
   return pointer;
}
//funtion to remove trailing space
void trimleadingandTrailing(char *s)
{
	int  i,j;
 
	for(i=0;s[i]==' '||s[i]=='\t';i++);
		
	for(j=0;s[i];i++)
	{
		s[j++]=s[i];
	}
	s[j]='\0';
	for(i=0;s[i]!='\0';i++)
	{
		if(s[i]!=' '&& s[i]!='\t')
				j=i;
	}
	s[j+1]='\0';
}	
int printObject(tag_t objtag)
{

               int                prop_count=0;
               char**             prop_names=NULL;
               int        num_values=0;
               char**     values =NULL;
               tag_t                   class_tag=NULLTAG;
               char                     *class_name=NULL;
               int j=0,k=0;

               logical propConstReqBool=false;

               int ifail=ITK_ok;

               printf("\n printObject()->");fflush(stdout);

     if(objtag==NULLTAG)
     {
                printf("\nNULLTAG");fflush(stdout);
                return ifail;
     }
               /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
               ITK_CALL(POM_name_of_class(class_tag, &class_name) );

*/
     char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

     ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



               ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
               printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
               // printf("\n printObject2 %d",prop_count);fflush(stdout);

               for (k=0;k<prop_count;k++)
               {
               //ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values)); //hashed for Teamcenter14 recommendation
			   ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values)); //similar new API for Teamcenter14
               tag_t prop_tag = NULLTAG;
               ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
               printf("\n %s:{,[",prop_names[k]);fflush(stdout);

               propConstReqBool=false;
               char *prop_dispay_name=NULL;
               PROP_value_type_t valtype;
               char *valtypeName=NULL;
               ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

                                                                           printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
                                                                           printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
                                                                           printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
                                                                           printf("\n]\n");fflush(stdout);

               for(j=0;j<num_values;j++)
               {
               printf("\n\t%s,",values[j]);fflush(stdout);
               }

               printf("\n },");fflush(stdout);

               }
               printf("\n]");fflush(stdout);
return ifail;
}

void setFindStr(char **view_list,int count,char *str,int *found)
{


	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

void setFindStrFrom(char **view_list,int count,char *str,int start,int *found)
{


	int k=0;
	*found=0;
	for(k=start;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}


//Funtion to get new EeECN number

	int EEDMLCreFunc(char **RetEEDmlNo)
	{
				int ifail = ITK_ok;
	           /* tag_t    itemrev = NULLTAG;
				char *srcview=NULL;
				char *desview=NULL;
				char *status=NULL;*/
				tag_t createInputTag = NULLTAG;
				tag_t createRevInputTag = NULLTAG;
				tag_t type = NULLTAG;
				tag_t revtype = NULLTAG;
			    tag_t item = NULLTAG;
				char *tspartnum=NULL;
				char *tempnum =NULL;
				const char *select_attrs[]={"item_id"};
				int n_rows;
				int n_cols;
				int row;
				int column;
				void ***report;
				char vals[30];
				char *EEDMLNoToBeDup=NULL;
				//const char *str_list[15];
				 char FinalItemId[15];
	            
				
				printf("\nInside EEDMLCreFunc*******");
				char *basepart=(char *) MEM_alloc(10 * sizeof(char *));
				tspartnum=MEM_alloc(30);
				//tempnum=MEM_alloc(30);
				//printf("\n Input Parameters projcode=%s OwnerDesDept=%s OwnerDesUnit=%s VcClass=%s Desc=%s ProjClass=%s",projcode,OwnerDesDept,OwnerDesUnit,VcClass,Desc,ProjClass);
				
				
				time_t 	now;
				struct 	tm	when;
				char 	CurrYear[6]		= "";
				char* from2 = CurrYear;  
				char *YearCode = MEM_alloc(10);
				time(&now);
				when = *localtime(&now);
				
				strftime(CurrYear,100,"%y",&when);	
				strncpy(YearCode, from2+2,2);
				printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
				printf("\n--->>>>> EEDMLCreFunc Current Year >> %s  ",CurrYear);fflush(stdout);
				
				
				tc_strcpy(FinalItemId,CurrYear);
				tc_strcat(FinalItemId,"EE");
				tc_strcpy(basepart,CurrYear);
				tc_strcat(basepart,"EE");
				tc_strcat(FinalItemId,"*");
				printf("\n FinalItemId=%s",FinalItemId);
				
				
				const char *str_list[15]={FinalItemId};
				printf("\nstr_list[0]=%s",str_list[0]);
				//Create Start
				
				      printf("\nB4 query Build FinalItemId=%s",FinalItemId);
					ERROR_CHECK(POM_enquiry_create ("find_EeECN_by_type"));
					ERROR_CHECK(POM_enquiry_add_select_attrs ("find_EeECN_by_type","T5_EeECN", 1, select_attrs));
					ERROR_CHECK(POM_enquiry_set_string_value ("find_EeECN_by_type","attrval",1,str_list,POM_enquiry_bind_value));
					ERROR_CHECK(POM_enquiry_set_attr_expr ("find_EeECN_by_type","expr1", "T5_EeECN","item_id",POM_enquiry_like, "attrval"));
					ERROR_CHECK(POM_enquiry_set_where_expr ("find_EeECN_by_type","expr1"));
					ERROR_CHECK(POM_enquiry_add_order_attr( "find_EeECN_by_type", "T5_EeECN", "item_id", POM_enquiry_desc_order ));
					ERROR_CHECK(POM_enquiry_execute("find_EeECN_by_type", &n_rows, &n_cols, &report));
					ERROR_CHECK(POM_enquiry_delete("find_EeECN_by_type")); 
					
							printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",FinalItemId,n_rows,n_cols,report);
						for (row = 0; row < n_rows; row++)
						{
						for (column = 0; column < n_cols; column++)
						printf("\n Query return=%s\t", report[row][column]);
					
						}
						printf("\n Row =%d Column =%d\t", n_rows,n_cols);
						if(n_rows==0 )
						{
						printf("\nInside start Base EE DML=%s",basepart);
						strcat(basepart,"000001");
						}
						else
						{
							printf("\nInside Base EE DML increment condition=%s ",basepart);
							char *tmpStr=report[0][0];
							printf("\ntmpStr=%s",tmpStr);
							//char *str=TS_subString(tmpStr,9,tc_strlen(tmpStr));
							int last6dig=atoi(substring(tmpStr,5,tc_strlen(tmpStr)));
							last6dig=last6dig+1;
							printf("\n str=%d",last6dig);
							sprintf(vals,"%.6d",last6dig);
							printf("\nInside vals=%s",vals);
					     	strcat(basepart,vals);
						} 
				
					printf("\nto be create EE DML=%s",basepart);
					
					
			if(basepart)
			{
				 tc_strdup(basepart,&EEDMLNoToBeDup);
				*RetEEDmlNo=EEDMLNoToBeDup;
				 //tc_strdup(basepart,&EEDMLNoToBeDup);
				printf( "EEDMLNoToBeDup:%s RetEEDmlNo=%s\n", EEDMLNoToBeDup,*RetEEDmlNo);fflush(stdout);
			}
				//create End
				
				

			
			return 	ifail;
	   
	   
	}

//function to decide whether Pre/Post/AH/RH required or not
	int EEProcDecsFunc(char *syscd)
	{
		tag_t *cntrlObjSet=NULLTAG;
		tag_t   qryTagCntrl     = NULLTAG;
		int     n_entryCntrl    = 3;
		int ifail=0;
		char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
		int  control_number_found=0;
		
				printf("\n start func EEProcDecsFunc Calling qry to decide whether this Pre/Post/AH/RH will required or not with input syscd=%s\n",syscd);
				//if(QRY_find("Control Objects...", &qryTagCntrl));
				if(QRY_find2("Control Objects...", &qryTagCntrl));
				if (qryTagCntrl)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrl[0]=syscd;
					qry_valuesCntrl[1]="Live";
					qry_valuesCntrl[2]="0";
					
					if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
				}
				else
				{
					printf("\n Control Object Query not Found .... \n");fflush(stdout);
					
				}	
				
				printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
				if(control_number_found>0)
				{
				printf("\n EEProcDecsFunc is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
				ifail= control_number_found;
				 //return ifail;
				}
			
	printf("\n end the function EEProcDecsFunc with ifail [%d]\n",ifail);fflush(stdout);		
	return ifail;
	}


int Post_create_EEDML_func( METHOD_message_t *msg, va_list  args )
{
	//signature for tc_save_Msg Pre Action
	
	// tag_t	EEDMLTag		= va_arg(args, const tag_t);
	// int*	n_values	= va_arg(args, int*);
	// char	***values	= va_arg(args, char***);	
	//End signature for tc_save_Msg Pre Action

	//signature for item create
	va_list largs;
	va_copy( largs, args );    
	const char* item_id  = va_arg(largs, char*);
    const char* item_name = va_arg(largs, char*);
    const char* type_name = va_arg(largs, char*);
    const char* rev_id = va_arg(largs, char*);
    tag_t*      EEDMLTag = va_arg(largs, tag_t*);
    tag_t*      item_rev_tag = va_arg(largs, tag_t*);
    tag_t       item_master_form = va_arg(largs, tag_t);
    tag_t       item_rev_master_form = va_arg(largs, tag_t);
	va_end( largs );
	//end signature for item create
	
	
	int		status;

	int max_char_size = 80;
	int n_tags_found = 0;
	tag_t
	objTypeTag=NULLTAG;
	//char *item_id 	   = NULL;
	//char*   type_name=NULL;
	char *SesUsr=NULL;
	int ifail = ITK_ok;
	int results = 0;
	char *RetToBeEEDmlNo=NULL;
	char *EEtaskID=NULL;
	int EEbypassFlg=0;
		printf("\ninside Post_create_EEDML_func	\n ");fflush(stdout);

	//if(TCTYPE_ask_object_type(EEDMLTag,&objTypeTag));
	//if(TCTYPE_ask_name2(objTypeTag,type_name));14.3
	//if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     Post_create_EEDML_func type_name= %s\n", type_name);fflush(stdout);
	
	EEbypassFlg=EEProcDecsFunc("PreT5_EeECNProc");
	if(EEbypassFlg>0)
	{
		printf("\n  Post_create_EEDML_func is bypassed for class T5_EeECN\n");fflush(stdout);
		return 0;
	}
	if(strcmp(type_name,"T5_EeECN")==0)
	{
		printf("\n  class is T5_EeECN......\n");fflush(stdout);
		//AOM_ask_value_string( EEDMLTag, "item_id",&item_id);
		
		printf("\ninside Post_create_EEDML_func item_id : %s",item_id);fflush(stdout);

		
		POM_get_user_id (&SesUsr);
		printf("\n Post_create_EEDML_func: Session user: %s\n",SesUsr); fflush(stdout);
		if(tc_strcmp(SesUsr,"infodba") !=0 && tc_strcmp(SesUsr,"loader") !=0)
		{
			//EEDML Creation validation for EEDML_Type
			printf("\n EEDML number generation process ...\n"); fflush(stdout);
			
			//printf("\n EEDML Project Code %s\n",EEDML_Project_Code); fflush(stdout);
			ITK_CALL(AOM_ask_value_string(*item_rev_tag, "item_id",&EEtaskID));
			printf("\n\n inside EEDML_item_create_Func EEtaskID : %s\n",EEtaskID); fflush(stdout);
			if(tc_strstr(EEtaskID,"EE")==NULL)
			{
				ITK_CALL(EEDMLCreFunc(&RetToBeEEDmlNo));
				printf("\n\n inside EEDML_item_create_Func RetToBeEEDmlNo : %s\n",RetToBeEEDmlNo); fflush(stdout);
				if(RetToBeEEDmlNo)
				{
					printf("\n EEDML number before set with RetToBeEEDmlNo=%s\n",RetToBeEEDmlNo); fflush(stdout);
					ITK_CALL(AOM_set_value_string(*EEDMLTag,"item_id",RetToBeEEDmlNo));
					ITK_CALL(AOM_set_value_string(item_master_form,"object_name",RetToBeEEDmlNo));
					ITK_CALL(AOM_set_value_string(item_rev_master_form,"object_name",RetToBeEEDmlNo));
					ITK_CALL(AOM_save_with_extensions(*EEDMLTag));
					ITK_CALL(AOM_save_with_extensions(item_master_form));
					ITK_CALL(AOM_save_with_extensions(item_rev_master_form));
					printf("\n EEDML number after set with RetToBeEEDmlNo=%s\n",RetToBeEEDmlNo); fflush(stdout);
						
					
					//ITK_CALL(AOM_save_without_extensions(*item_rev_tag));
				}
			}
			
		}
		
					
	}

	printf ("\n--------------Post_create_EEDML_func Completed--------------------\n");fflush(stdout);

	
	return 0;
}

int EEDML_item_create_Func( METHOD_message_t *msg, va_list args )
{

	printf("\n 1111Start EEDML Update *****EEDML_item_create_Func for CreateItempost\n");fflush(stdout);
	

	int ifail = ITK_ok;
	// va_list for item save 
		// va_list largs;
		// va_copy( largs, args );               
		// tag_t item_tag = va_arg(largs, tag_t);
		// tag_t item_rev_tag = va_arg(largs, tag_t);
		// logical  isNew = va_arg(args, int);	
	//End item save signature
	

	tag_t Attachrelation_type=NULLTAG;
	tag_t Attach_type_rel=NULLTAG;
	tag_t *attachments1;
	tag_t		filetag = NULLTAG;
	tag_t		datasettype = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t  	itemrev= NULLTAG;
	tag_t project	 = NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType	= 1;
	char *item_ids=NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *RetToBeEEDmlNo=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	char *TSRevid=NULL;
	int count;
	int cnt1;
	int count1;
	int j;
	tag_t projtag = NULLTAG;
	tag_t *Ownprojtag = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		dataset = NULLTAG;
	logical active = TRUE;
	// char *item_type=NULL;
	// char *design_grp=NULL;
	// char *part_type=NULL;
	// char full_group[20];

	// logical hasBypass=false;
	// logical part_found=false;

	tag_t userSession=NULLTAG;
	
	//signature for item create
	
	va_list largs;
	va_copy( largs, args );    
	const char* item_id  = va_arg(largs, char*);
    const char* item_name = va_arg(largs, char*);
    const char* type_name = va_arg(largs, char*);
    const char* rev_id = va_arg(largs, char*);
    tag_t*      item_tag = va_arg(largs, tag_t*);
    tag_t*      item_rev_tag = va_arg(largs, tag_t*);
    tag_t       item_master_form = va_arg(largs, tag_t);
    tag_t       item_rev_master_form = va_arg(largs, tag_t);
	va_end( largs );
	//end signature for item create
	
	printf("\n 1111Start EEDML Update *****EEDML_item_create_Func for Createpost\n");fflush(stdout);
	//char *Type = va_arg(largs, char *);
			   //tag_t *newBomline_tag = va_arg(largs, tag_t *);
			   //va_end( args );
			   itemrev=*item_rev_tag;
			   printf("\n Start EEDML Update *****EEDML_item_create_Func action\n");fflush(stdout);
			   ITK_CALL( AOM_ask_value_string(*item_tag,"item_id",&item_ids));
				ITK_CALL( AOM_ask_value_string(*item_tag,"object_name",&Desc));
				ITK_CALL( AOM_ask_value_string(itemrev,"t5_cprojectcode",&ProjName));
				//ITEM_ask_latest_rev(item_tag,&itemrev);
				ITK_CALL( AOM_ask_value_string(itemrev, "item_revision_id",&Itemrevid));
				//ITK_CALL( AOM_ask_value_string(itemrev, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tag(item_rev_tag, "item_revision_id",&TSRevid));
				//ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
				printf("\n EEDML item_id=%s Desc=%s Itemrevid=%s  ProjName=%s \n",item_ids,Desc,Itemrevid,ProjName);fflush(stdout);
				//printf("\n tslEEDML TSRevid=%s \n",TSRevid);fflush(stdout);
				// if(isNew==0)
				// {
					// printf("\n EEDML has already created\n");fflush(stdout);
					// return ifail;
					
				// }
				//ITK_CALL(EEDMLCreFunc(&RetToBeEEDmlNo));
						printf("\n\n inside EEDML_item_create_Func RetToBeEEDmlNo : %s\n",item_ids); fflush(stdout);
					if(item_ids)
					{
						ITK_CALL(AOM_set_value_string(*item_tag,"item_id",item_ids));
						ITK_CALL(AOM_save_with_extensions(*item_tag));
						//ITK_CALL(AOM_set_value_string(*item_rev_tag,"item_id",RetToBeEEDmlNo));	
						
						//ITK_CALL(AOM_save_without_extensions(*item_rev_tag));
					}
					
											
/*
				
				 				//Assign project process 
				printf("\n Inside Assign project process with ProjName=%s",ProjName);fflush(stdout);
				//ifail = AOM_lock(item_tag);
				ifail = PROJ_find(ProjName, &projtag);
				printf("\n After PROJ_find");fflush(stdout);
				ifail = PROJ_is_project_active(projtag, &active);	
				printf("\n After PROJ_is_project_active");fflush(stdout);							
				tag_t projtag1[]={projtag};		
				tag_t itemtag1[]={*item_tag};									
				printf("\n Before PROJ_assign_objects");fflush(stdout);	
				ifail = PROJ_assign_objects(1, projtag1, 1, itemtag1);
				printf("\n After PROJ_assign_objects");fflush(stdout);	
				ifail = WSOM_assign_to_owning_project(*item_tag,projtag);//set owning_project	
				printf("\n After WSOM_assign_to_owning_project");fflush(stdout);								
				//ifail = AOM_save(&item_tag);
				//ifail = AOM_unlock(item_tag);
				printf("\n End Assign project process");fflush(stdout);	
				
				//start status assign process
				if(itemrev)
				{
					char *Release_status = NULL;
					tag_t rel_status		   = NULLTAG;
					logical retain_released_date= TRUE;
					//ITK_CALL (CR_create_release_status("T5_LcsWorking",&rel_status));
					//ITK_CALL(EPM_add_release_status(rel_status,1,&itemrev ,retain_released_date));
					
					ITK_CALL(RELSTAT_create_release_status("T5_LcsWorking",&rel_status)); //similar new API for Teamcenter14
						if(rel_status)
						ITK_CALL(RELSTAT_add_release_status(rel_status,1,&itemrev,retain_released_date));  
					ITK_CALL(AOM_UIF_ask_value(itemrev,"release_status_list",&Release_status));
					printf ( "\nRelease_status_EEDML : [%s]", Release_status ) ; fflush ( stdout) ;

				}			
				//End status assign process				
				
				*/
				
			   
			 //  printf("\n End*****EEDML_item_create_Func for Createpost with item_id=%s projcode=%s \n",item_ids,ProjName);fflush(stdout);
			 printf("\n End*****EEDML_item_create_Func");fflush(stdout);
			   return 0;

}

int eedmlcreprevalidation(METHOD_message_t *msg, va_list args)
{
	printf("\n ***** INSIDE eedmlcreprevalidation function ***** \n");fflush(stdout);

	int ifail=0;
	tag_t primary_object= va_arg(args, tag_t);
	tag_t primary_obj_type_tag= NULLTAG;
	tag_t user_tag1=NULLTAG;
	char* type_name= NULL;
	char *DMLrlstype = NULL;
	char *DMLrlstypedup = NULL;
	char *user_Name = NULL;
	char **DesignGroupList;
	int num=0;
	int i=0;
	int desgrpflg=0;
	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name);
	printf("\n eedmlcreprevalidation--SVR_Relese_pre_condition Primary_object type_name is ::  %s --------\n",type_name);fflush(stdout);
	ifail=POM_get_user(&user_Name,&user_tag1);
	printf("\n\t eedmlcreprevalidation--Starting for user_Name :%s>>>>>>>\n",user_Name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_EeECNRevision")==0)
	{
		printf("\n eedmlcreprevalidation--:: INSIDE ERC DML SVR cluster Release \n");fflush(stdout);
		
		//ass
		ifail=AOM_ask_value_string( primary_object, "t5_rlstype",&DMLrlstype);
		if(DMLrlstype)
		{
			tc_strdup(DMLrlstype,&DMLrlstypedup);
		}
		printf("\n eedmlcreprevalidation--ERC DML release type:: t5_rlstype ::  %s DMLrlstypedup=%s\n",DMLrlstype,DMLrlstypedup);fflush(stdout);
		
		
		if ((tc_strcmp(DMLrlstypedup,"TPL")!=0) && (tc_strcmp(DMLrlstypedup,"MR")!=0))
	//	if (tc_strcmp(DMLrlstypedup,"TPL")!=0)
			{
				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,ITK_EE_Err01,"EEDML:ERR01-Release Type must be TPL/Module/EE Release for EE DML creation","Please enter valid release type as suggested  and proceed");
				return(ITK_EE_Err01);
				//return ifail;
			}

		ifail=AOM_ask_value_strings( primary_object,"t5_crdesigngroup",&num,&DesignGroupList);
		printf("\n eedmlcreprevalidation--EE DML t5_crdesigngroup::  ::desgrp size=%d  desgrp=%s\n",num,DesignGroupList[0]);fflush(stdout);
		if(num>0)
		{
			for(i=0;i<num;i++)
			{
				if(tc_strcmp(DesignGroupList[i],"0E")==0)
				{
					printf("\n eedmlcreprevalidation--EE desgrp found ::  %s\n",DesignGroupList[i]);fflush(stdout);
					desgrpflg=1;
					break;
				}
			}
		}
		printf("\n eedmlcreprevalidation--desgrpflg ::  %d\n",desgrpflg);fflush(stdout);
		if(desgrpflg<=0)
		{
			EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,ITK_EE_Err01,"EEDML:ERR02-Design Group must be 0E for EE DML creation","Please enter valid 0E design group as suggested  and proceed");
				return(ITK_EE_Err01);
			
		}
		
	}
	return ifail;
}
//Auto EE task creation logic start.
int CreateEETask( METHOD_message_t *msg, va_list  args )
{
	tag_t	TaskTag		= va_arg(args, const tag_t);
	int*	n_values	= va_arg(args, int*);
	char	***values	= va_arg(args, char***);
	logical  isNew = va_arg(args, int);
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	char	*DMLTypeinfo1=NULL;
	int		status;

	int max_char_size = 80;
	int n_tags_found = 0;
	int n_entryy = 1;
	int  rsltCountt      =  0;

	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	mad=0,m=0,sp=0,
	ii			= 0;

	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	item_SP=NULLTAG,
	rev_SP=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	tag_t *tags_found = NULL;

	int number_found;
	int number_found_SP;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_tags_SP=NULLTAG;
	char *Proj_typ = NULL;
	char *ProjDesc = NULL;
	//char *DmlProj = NULL;
	//tag_t	Project_t		= NULLTAG;
	//tag_t	ObjTypProj	= NULLTAG;
	char*   type_Proj=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *sDMLVertical = NULL;
	char *DMLrlstype = NULL;
	char *SesUsr = NULL;
	//char *DmlDR = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char **DMLMdAddList;
	char*   type_name=NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t	relation_type_SP,relation_SP  = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_SP;
	//task
	int				n_strings			=	1;
	int				l_strings			=	500;
	int				it				=	0;
	int				index				=	0;
	char**			stringArrayEET		=	NULL;
	char*			tempStringt			= NULL;
	char*			Tskitem_id			= NULL;

	tag_t			EEDmlTypeTag			= NULLTAG;
	tag_t			EETCreInTag		= NULLTAG;
	tag_t			EETRevTypeTag		= NULLTAG;
	tag_t			EETRevCreInTag		= NULLTAG;
	tag_t			TaskTagMstr			= NULLTAG;
	tag_t 			TaskRevTag	    = NULLTAG;
	//task
	int Deg_count=0;
	int piStringCount=0;
	char **	Deg_StringList =NULL;
	char*	sDMLBUnit	= NULL;

	char*	scprojectcode	= NULL;
	char*	Deg_info1	= NULL;
	char*	Deg_info2	= NULL;
	char*	Deg_info3	= NULL;
	char*	Deg_info4	= NULL;
	char*	Deg_info5	= NULL;
	char*	Deg_info6	= NULL;
	char*	Deg_info7	= NULL;
	char*	RetToBeEEDmlNo	= NULL;
	tag_t   DegqryTag   = NULLTAG;
	tag_t   qryTagg   = NULLTAG;
	tag_t   EEDMLTaskRelTag      = NULLTAG;
	int     Deg_rsltCount      =  0;
	int     Deg_n_entry    = 1;
	char    *Deg_qry_entry[1]  = {"SYSCD"};
	char    **Deg_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char* DegGrp = NULL;
	char* sTaskGroups = NULL;
	sTaskGroups     =  (char *) MEM_alloc(10000 * sizeof(char));


	char   *qry_entryy[1]  = {"SYSCD"};
	char   *qry_entryMDM[1]  = {"SYSCD"};
	tag_t   *CntrlObjectTagg      = NULLTAG;
	char   **qry_valuess2     =  (char **) MEM_alloc(10 * sizeof(char *));

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dup_sp = (char *)MEM_alloc(max_char_size * sizeof(char));
	printf("\n **************inside CreateEETask****************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	//if(TCTYPE_ask_name2(objTypeTag,type_name));14.3
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n CreateEETask type_name  :[%s] isNew=%d\n", type_name,isNew);fflush(stdout);

	if(isNew<=0)
	{
		printf("\n T5_EeECNRevision revision is not for new creation\n");fflush(stdout);
		return 0;
		
	}
	if(strcmp(type_name,"T5_EeECNRevision")==0)
	{
		printf("\n CreateEETask:inside task creation......");fflush(stdout);
		AOM_ask_value_string( TaskTag, "item_id",&item_id);
		AOM_ask_value_string( TaskTag, "current_id",&DML_no);
		AOM_ask_value_strings( TaskTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string( TaskTag, "t5_rlstype",&DMLrlstype);
		//AOM_ask_value_string( TaskTag, "t5_ProductLine",&sDMLVertical);
		AOM_ask_value_strings(TaskTag,"t5_MdAddress",&mad,&DMLMdAddList);
		//AOM_ask_value_string( TaskTag, "t5_ERCBusiUt",&sDMLBUnit);
		AOM_ask_value_string( TaskTag, "t5_cprojectcode",&scprojectcode);
		//AOM_ask_value_string( TaskTag, "t5_cprojectcode",&Proj_ID);
		printf("\n CreateEETask:item_id:[%s] DML_no:[%s] DMLrlstype:[%s] Desgnum:[%d]  scprojectcode:[%s]  \n",item_id,DML_no,DMLrlstype,num,scprojectcode);fflush(stdout);
		if(tc_strstr(item_id,"EE")==NULL)
		{
		ITK_CALL(EEDMLCreFunc(&RetToBeEEDmlNo));
		}
		printf("\n\n inside CreateEETask RetToBeEEDmlNo : %s\n",RetToBeEEDmlNo); fflush(stdout);
		if(num > 0)
		{
			printf(" CreateEETask 1.. ");fflush(stdout);
			if((tc_strcmp(DMLrlstype,"TPL")==0 || tc_strcmp(DMLrlstype,"MR")==0) )
			{
				for(i=0;i<num;i++)
				{
					if(tc_strstr(item_id,"EE")!=NULL)
					{
					strcpy(item_id_dup,item_id);
					}
					else
					{
					strcpy(item_id_dup,RetToBeEEDmlNo);
					}
					strcat (item_id_dup,"_");
					strcat (item_id_dup,DesignGroupList[i]);
					printf("\n CreateEETask:Task Name is :%s\n",item_id_dup);fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,item_id_dup);
					strcpy(criteria.class_name,"T5_ChangeTaskRevision");
					status	= WSOM_search(criteria,&number_found,&list_of_WSO_tags);
					printf("\n CreateEETask:Item_id count in DB is : %d\n",number_found);fflush(stdout);

					if(number_found == 0)
					{
						stringArrayEET = (char**)malloc( n_strings * sizeof *stringArrayEET );
						for( index=0; index<n_strings; index++ )
						{
							stringArrayEET[index] = (char*)malloc( l_strings + 1 );
						}
						TCTYPE_find_type( "T5_ChangeTask", NULL,&EEDmlTypeTag) ;
						TCTYPE_construct_create_input( EEDmlTypeTag,&EETCreInTag) ;

						TCTYPE_find_type( "T5_ChangeTaskRevision", NULL,&EETRevTypeTag) ;
						 TCTYPE_construct_create_input( EETRevTypeTag,&EETRevCreInTag) ;

						tc_strcpy( stringArrayEET[0], item_id_dup);
						TCTYPE_set_create_display_value( EETCreInTag, "item_id", 1,(const char**)stringArrayEET) ;

						tc_strcpy( stringArrayEET[0], item_id_dup);

						 TCTYPE_set_create_display_value( EETCreInTag, "object_name", 1,(const char**)stringArrayEET) ;

						tc_strcpy( stringArrayEET[0], item_id_dup);
						 TCTYPE_set_create_display_value( EETCreInTag, "object_desc", 1,(const char**)stringArrayEET) ;

						AOM_tag_to_string(EETRevCreInTag,&tempStringt) ;
						tc_strcpy( stringArrayEET[0], tempStringt);
						printf("\n CreateEETask:Test0.4..[%s]\n",stringArrayEET[0]);fflush(stdout);
						TCTYPE_set_create_display_value( EETCreInTag, "revision", 1,(const char**) stringArrayEET) ;
						tc_strcpy( stringArrayEET[0], "A");
						TCTYPE_set_create_display_value( EETRevCreInTag, "item_revision_id", 1,(const char**)stringArrayEET) ;
						/*tc_strcpy( stringArrayEET[0], DesignGroupList[i]);
						TCTYPE_set_create_display_value( EETRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayEET) ;
						tc_strcpy( stringArrayEET[0], Proj_ID);
						TCTYPE_set_create_display_value( EETRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayEET) ;*/

						//AOM_set_value_string(EETCreInTag,"item_id",item_id_dup);
						//AOM_set_value_string(EETCreInTag,"object_name",item_id_dup);
						//AOM_set_value_string(EETCreInTag,"object_desc",item_id_dup);
						printf("\n CreateEETask::for create taskkk\n");fflush(stdout);

						//printf("\n CreateEETask:Value to set in EE_task_number %s:%s:%s:%s:%s:\n",item_id_dup,item_id,tempStringt,DesignGroupList[i]);fflush(stdout);
						 TCTYPE_create_object( EETCreInTag,&TaskTagMstr) ;
						AOM_save_with_extensions(TaskTagMstr) ;

						ITEM_ask_latest_rev(TaskTagMstr,&TaskRevTag);
						//
						printf("\n CreateEETask:Save EE TASK ITEM AND REV\n");fflush(stdout);
						if (TaskTagMstr!=NULLTAG)
						{
							printf("\n CreateEETask:TASK ITEM IS CREATED ");fflush(stdout);
							AOM_ask_value_string( TaskTagMstr, "item_id",&Tskitem_id);
							printf(" and TASK ITEM ID is:[%s] \n",Tskitem_id);fflush(stdout);
						}
						else
						{
							printf("\n CreateEETask:TASK ITEM IS NOT CREATED\n");fflush(stdout);
						}
						if (TaskRevTag!=NULLTAG)
						{
							printf("\n CreateEETask:TASK ITEM REV IS CREATED\n");fflush(stdout);
							AOM_ask_value_string( TaskRevTag, "item_id",&Tskitem_id);
							printf(" and TASK ITEM REV is:%s \n",Tskitem_id);fflush(stdout);
						}
						else
						{
							printf("\n CreateEETask:TASK ITEM REV IS NOT CREATED\n");fflush(stdout);
						}
						AOM_save_with_extensions(TaskTagMstr);
						AOM_save_with_extensions(TaskRevTag);
						printf("\n CreateEETask:for task..\n");fflush(stdout);
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_create_relation(TaskTag, TaskRevTag, relation_type,  NULLTAG,&relation);

						if (relation==NULLTAG)
						{
							printf("\n CreateEETask:Nrelation does not exist \n");fflush(stdout);
						}
						else
						{
							GRM_save_relation(relation);
							printf("\n CreateEETask:Relation save1.. \n");fflush(stdout);
						}

						if(mad>0)
						 {
							for(m=0;m<mad;m++)
							{
								printf("\n CreateEETask:Setting..DML Module Address : %s\n",DMLMdAddList[m]);
								AOM_set_value_string_at(TaskRevTag,"t5_ModuleAddress",m,DMLMdAddList[m]);
							}
							AOM_save_with_extensions(TaskRevTag);
							AOM_refresh(TaskRevTag,0);
						 }

					}
					else
					{
						printf("\n CreateEETask:EE Task is already available   \n");fflush(stdout);
						
						
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_find_relation(TaskTag, list_of_WSO_tags[0], relation_type, &EEDMLTaskRelTag);
						if(EEDMLTaskRelTag==NULLTAG)
						{
							GRM_create_relation(TaskTag, list_of_WSO_tags[0], relation_type,  NULLTAG,&relation);
							if (relation==NULLTAG)
							{
								printf("\n CreateEETask:Nrelation does not exist \n");fflush(stdout);
							}
							else
							{
								GRM_save_relation(relation);
								printf("\n CreateEETask:Relation save1.. \n");fflush(stdout);
							}
						}
						else
						{
							printf("\n CreateEETask:EE DML and EE Task Relation already available.. \n");fflush(stdout);
						}
						
					}
					 MEM_free(list_of_WSO_tags);
				 }
			}
			
		}
	}

	printf ("\n--------------CreateEETask=Completed--------------------\n");fflush(stdout);

	return error_code;
}

int EEPartDML_register_action_handlers() //this is used to register action handler
{
	TC_write_syslog("Inside EEPartDML_register_action_handlers\n");
	//ERROR_CHECK(EPM_register_action_handler("CM_Check_CCVForeepartdml","Action Handler to create Tech Spec in SVR WF",( EPM_action_handler_t) CM_Check_CCVForeepartdml));
	
	//TC_write_syslog("Registered Action Handler CM_Check_CCVForeepartdml..\n");
	
	
	
	
	return ITK_ok;
}

int EEPartDML_register_rule_handlers() //this is used to register action handler
{
	TC_write_syslog("Inside EEPartDML_register_rule_handlers\n");
	//ERROR_CHECK(EPM_register_action_handler("CM_Check_CCVForeepartdml","Action Handler to create Tech Spec in SVR WF",( EPM_action_handler_t) CM_Check_CCVForeepartdml));
	
	//TC_write_syslog("Registered Action Handler CM_Check_CCVForeepartdml..\n");
	
	
	
	
	return ITK_ok;
}

extern int EEPartDML_register_methods(int *decision, va_list args)
{
                            

         printf("\n Start  *****EEPartDML_register_methods\n");fflush(stdout);       
		int ifail = ITK_ok;
		METHOD_id_t  method1;
		METHOD_id_t EEDML_item_create;
		*decision = ALL_CUSTOMIZATIONS;
				
				 //Registering Action handler with method which will build with same tm_EEPartDML.so
				 ERROR_CHECK(EEPartDML_register_action_handlers());
				 //End Action handler 
				 
				 //Registering Rule handler with method which will build with same tm_EEPartDML.so
				 ERROR_CHECK(EEPartDML_register_rule_handlers());
				 //End Rule handler 
				 
					ifail=(METHOD_find_method("T5_EeECN", "ITEM_create", &EEDML_item_create));
			
					if (EEDML_item_create.id != 0)
					{	
						 printf("\n  before Register EEDML_item_create Pre\n");fflush(stdout);    
						TC_write_syslog("\n before Register EEDML_item_create Pre");
						ERROR_CHECK(METHOD_add_action(EEDML_item_create,METHOD_post_action_type,(METHOD_function_t)Post_create_EEDML_func,NULL));
						TC_write_syslog("\n IN After Register EEDML_item_create Pre");
						 printf("\n  End Register EEDML_item_create Pre\n");fflush(stdout);   
					}
					else
					{
						printf("\n failed to Register EEDML_item_create Pre == NULL");fflush(stdout);
					}
				 
				 
				ifail = METHOD_find_method("T5_EeECNRevision", TC_save_msg,&method1);
			   if (method1.id != 0)
			   {
					//printf("\n :: INSIDE EE DML Preaction \n");fflush(stdout);
					ERROR_CHECK(METHOD_add_pre_condition(method1,(METHOD_function_t)eedmlcreprevalidation,NULL) );
					
					printf("\n :: EE DML METHOD_add_pre_condition method1 registered :: \n"); fflush(stdout);
			   }
			   else
			   {
					printf("\n :: method1 not found :: \n"); fflush(stdout);
			   }
			   
			   if (method1.id != 0)
			   {
					ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) CreateEETask, NULL)!=ITK_ok;
					//PrintErrorStack();
					printf("\nrrrrrrrrRegistered as Post-Action for T5_EeECNRevision Creation\n");fflush(stdout);
			   }else
			   {
					printf("\nMethod not found!TC_save_msg\n");fflush(stdout);
			   }
			   
		TC_write_syslog("\n  End EEPartDML_register_methods \n");			
return ifail;
}


extern DLLAPI int tm_eepartdml_register_callbacks ()
{
    //ECHO("eepartdml_register_callbacks\n");

	printf("\neepartdml_register_callbacks initaited");fflush(stdout);

	ERROR_CHECK(CUSTOM_register_exit ( "tm_eepartdml", "USER_init_module",(CUSTOM_EXIT_ftn_t) EEPartDML_register_methods ));
	//ERROR_CHECK(CUSTOM_register_exit ( "tm_eepartdml", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  IcsLovUpdateServiceFunc));
	//ERROR_CHECK(CUSTOM_register_exit ( "tm_eepartdml", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  eepartdmlhUsrServCall));
TC_write_syslog("\n  *****After EEPartDML_register_methods registered\n");
    return ITK_ok;
}
//End
