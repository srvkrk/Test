//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_KeyWrdDescLovImpl
//

#include <T5_tm_keywordlov/T5_KeyWrdDescLovImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define PLM_error1 (EMH_USER_error_base+26)


using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_KeyWrdDescLovImpl::T5_KeyWrdDescLovImpl(T5_KeyWrdDescLov& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_KeyWrdDescLovImpl::T5_KeyWrdDescLovImpl( T5_KeyWrdDescLov& busObj )
   : T5_KeyWrdDescLovGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_KeyWrdDescLovImpl::~T5_KeyWrdDescLovImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_KeyWrdDescLovImpl::~T5_KeyWrdDescLovImpl()
{
}

//----------------------------------------------------------------------------------
// T5_KeyWrdDescLovImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_KeyWrdDescLovImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_KeyWrdDescLovGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int FunForKeyWord(const char *aggregate_group, const char *keywordStr, int* count, tag_t** items)
{
	int ifail = ITK_ok;
	*count = 0;
	int i=0;

	int num_to_sort =	1;
	char *keys[1] 	= 	{(char *)"Name"};
	int orders[1]  	=	{1};

	tag_t  query    = NULLTAG;
	tag_t  *t_item1 = NULLTAG;
	int n_found = 0;

	char *KeywordTmp = NULL;
	KeywordTmp=(char *)MEM_alloc(200);

	printf("\n\n FunForKeyWord::Design Group==[%s]  keywordStr: [%s] ",aggregate_group,keywordStr);fflush(stdout);

	tc_strcpy(KeywordTmp,"");

	if (tc_strlen(keywordStr)>0)
	{
		tc_strcpy(KeywordTmp,"*");
		tc_strcat(KeywordTmp,keywordStr);
		tc_strcat(KeywordTmp,"*");
	}
	else
	{
		tc_strcpy(KeywordTmp,"*");
	}

	printf("\n FunForKeyWord::KeywordTmp==[%s] ",KeywordTmp);fflush(stdout);

	char	*aggregatesqryentries[] = {(char *)"Name", (char *)"ext_1"};
	//char	*aggregatesqryvalues[] = {(char *)"*",(char *)aggregate_group};
	char	*aggregatesqryvalues[] = {(char *)KeywordTmp,(char *)aggregate_group};

	printf("\n\n FunForKeyWord::aggregatesqryvalues==[%s] ",aggregatesqryvalues[0]);fflush(stdout);
	printf("\n\n FunForKeyWord::aggregatesqryvalues==[%s] ",aggregatesqryvalues[1]);fflush(stdout);

	QRY_find2("KeyWordQryforDR", &query);
	QRY_execute(query, 2, aggregatesqryentries, aggregatesqryvalues, &n_found, &t_item1);

	printf("\n FunForKeyWord::Rows555==%s %d ",aggregate_group,n_found);fflush(stdout);
	*count = n_found;
	printf("\n FunForKeyWord::VAL= %d ",*count);fflush(stdout);
	(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));

	for(i=0;i<*count;i++)
	{
		(*items)[i] = t_item1[i];
	}

	return ifail;
}

///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_KeyWrdDescLovImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;

	bool isNull=false;
	bool isNull2=false;

	char *ErrorMessage = NULL;

	int error_flag = 0;

	std::string obj_val;
	std::string obj_val2;

	// Call the parent Implementation

	ErrorMessage = (char *)MEM_alloc(300);

    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation
    printf("\n  T5_KeyWordDescLOVList Starting Testing !!!>>\n");fflush(stdout);

	try
	{
		//  list_displayable_properties_with_value(operationInputTag);
		Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
		(Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
		if( refOprtnInput!=NULL )
		{
			refOprtnInput->getString("t5_DesignGrp", obj_val, isNull ); ///get properties from the object
			refOprtnInput->getString("t5_KeywordSearch", obj_val2, isNull2 ); ///get properties from the object

			tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Design Group!\n");

			if(isNull==true)
			{
				error_flag++;
				tc_strcat(ErrorMessage,"Design Group Is not Selected");
			}
			printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
			if(error_flag>0)
			{
				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);
				(*results)=NULLTAG;
				*nResults=0;
				return PLM_error1;
			}
			if(error_flag==0)
			{
				printf("\n Before Call T5_KeyWordDescLOVList::FunForKeyWord");fflush(stdout);
				printf("\n Given Design Group-->[%s]  keywordDesc: [%s] >>\n",obj_val.c_str(),obj_val2.c_str());fflush(stdout);

				(*results)=NULLTAG;
				*nResults=0;
				(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
				FunForKeyWord(obj_val.c_str(),obj_val2.c_str(),nResults, results);
				printf("\n After Call T5_KeyWordDescLOVList::FunForKeyWord");fflush(stdout);
			}
		}
		else
		{
			printf("\n--->>>>> T5_KeyWordDescLOVList::In  NULL refinputtag");fflush(stdout);
		}
	}
	catch( const IFail& ex )
	{
		ifail = ex.ifail();
	}

    return ifail;
}
