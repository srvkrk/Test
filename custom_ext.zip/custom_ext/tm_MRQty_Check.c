/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   tm_MRQty_Check.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_MRQty_Check(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int n_BL				= 0;
	int QTYFLAG				= 0;
	int PRTTYPEFLAG			= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int itemid_attribute	= 0;
	int qty_attribute		= 0;
	int rev_prttype_attr	= 0;
	int DR_n_entry    = 1;
	int DR_rsltCount    = 0;
	int strct1    = 0;
	int Qty    = 0;
	int CPmoduleFlag    = 0;
	tag_t  roottask				= NULLTAG;
	tag_t  *taskAttachments		= NULLTAG;
	tag_t  objTypTag			= NULLTAG;
	tag_t  DmlItemsRelation		= NULLTAG;
	tag_t  *SecObject			= NULLTAG;
	tag_t  Taskrelation_type	= NULLTAG;
	tag_t  *taskObject			= NULLTAG;
	tag_t   DMLObject			= NULLTAG;
	tag_t   window				= NULLTAG;
	tag_t   rule				= NULLTAG;
	tag_t   top_line			= NULLTAG;
	tag_t	ModuleTag			= NULLTAG;
	tag_t	*children1			= NULLTAG;
	tag_t	*DRCntrlObjectTag			= NULLTAG;
	tag_t   Childobject			= NULLTAG;
	tag_t   user_tag			= NULLTAG;
	tag_t   MRqtyqryTag			= NULLTAG;
	char   *objectId			=NULL;
	char   *Part_type			=NULL;
	char   *value				=NULL;
	char   *child_item_id		=NULL;
	//char   *child_item_qty		=NULL;14.3
	char   **child_item_qty		=NULL;
	char   *child_item_prttype	=NULL;
	char   *TaskPerfInfo1	=NULL;
	char   *TaskPerfInfo4	=NULL;
	char   *sChildMdlAdd	=NULL;
	char   *username;
	char   *userid;
	char   *sep					= ",";
	char*   ObjTyp=NULL;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char   *test1 = (char*)MEM_alloc(sizeof(char) * 500000);
	tc_strcpy(test1,"");

	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_MRQty_Check Function started...");fflush(stdout);
	TC_write_syslog("\n tm_MRQty_Check Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_MRQty_Check Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* tm_MRQty_Check INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** tm_MRQty_Check Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			//Query Control table.
			if(QRY_find2("ControlObjects", &MRqtyqryTag));
			if (MRqtyqryTag)
			{
			printf("\n Veh:P7:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
			printf("\n Veh:P8:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "MRQTY";
			if(QRY_execute(MRqtyqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Veh:P9:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);

			if(DR_rsltCount > 0)
			{
				//ON/OFF for CV Veh DML
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&TaskPerfInfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n tm_MRQty_Check:[%s]:",TaskPerfInfo1); fflush(stdout);

				//DML project which skipped for validation.
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&TaskPerfInfo4)!=ITK_ok)   PrintErrorStack();
				printf(" \n tm_MRQty_Check:[%s]:",TaskPerfInfo4); fflush(stdout);

				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					if(GRM_find_relation_type("T5_DMLTaskRelation",&Taskrelation_type));
					if(Taskrelation_type != NULLTAG)
					{
						if(GRM_list_primary_objects_only(taskAttachments[i],Taskrelation_type,&taskcount,&taskObject)!=ITK_ok)PrintErrorStack();
						printf("\n tm_MRQty_Check DML Count :>>>>  %d\n",taskcount);fflush(stdout);
						if(taskcount >0)
						{
							DMLObject=taskObject[0];
							if(AOM_ask_value_string(DMLObject,"t5_rlstype",&value));
							printf("\n tm_MRQty_Check t5_rlstype = [%s]\n",value);fflush(stdout);
							if(tc_strcmp(value,"MR")==0)
							{
								if(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation));
								if(DmlItemsRelation != NULLTAG)
								{
									printf("\n\t tm_MRQty_Check DmlItemsRelation relation found......");fflush(stdout);
									if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
									printf("\n\t tm_MRQty_Check count is : %d",count);
									if(count >0)
									{
										for(j=0;j<count;j++)
										{
											if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
											if(AOM_ask_value_string(SecObject[j],"t5_PartType",&Part_type));
											
											printf("\n\t tm_MRQty_Check SecObject objectId = [%s]\n",objectId);fflush(stdout);
											printf("\n\t tm_MRQty_Check SecObject Part_no = [%s]\n",Part_type);	fflush(stdout);

											//if(tc_strstr(TaskPerfInfo4,sChildMdlAdd)==0)
											
											if(strcmp(Part_type,"M")==0)
											{
												
											  sChildMdlAdd=NULL;
											  sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
											  tc_strcpy (sChildMdlAdd,"" );
											  sChildMdlAdd = subString(objectId,4,5);
											  printf("\n m_MRQty_Check TaskPerfInfo4:[%s] and  sChildMdlAdd:[%s]\n",TaskPerfInfo4,sChildMdlAdd);fflush(stdout);

											  if(tc_strstr(TaskPerfInfo4,sChildMdlAdd)==NULL)
											  {

												  ModuleTag=SecObject[j];

												  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
												  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_pack_all (window,true)!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_top_line (window, null_tag,ModuleTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
												  if(top_line!=NULLTAG)
												  {
													  printf("\n\t tm_MRQty_Check Inside Module BOM........");fflush(stdout);
													  if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
													  printf("\n\t tm_MRQty_Check child objects are n_BL : [%d]",n_BL);fflush(stdout);
													  if (n_BL >0)
													  {
															CPmoduleFlag=0;
															for (k=0;k<n_BL ;k++ )
															{
																if(Childobject) Childobject=NULLTAG;
																Childobject=children1[k];

																if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
																printf("\n\t Design Object ===> :: %s\n",child_item_id); fflush(stdout);
																if(AOM_ask_value_string(Childobject, "bl_Design_t5_RevPartType", &child_item_prttype ))PrintErrorStack();
																printf("\n\t tm_MRQty_Check rev_prttype_attr ===> :: %s\n",child_item_prttype); fflush(stdout);

																AOM_ask_displayable_values(Childobject,"bl_quantity",&strct1,&child_item_qty);
																printf("\n\t tm_MRQty_Check qty_attribute ===> :: %s\n",child_item_qty[0]); fflush(stdout);
																if(strct1>0)
																{
																  Qty = atoi(child_item_qty[0]); 
																}
																//QTYFLAG++;
																if (Qty != 0)
																{
																	printf("\n******* tm_MRQty_Check INSIDE Qty !=0  ********\n");fflush(stdout);
																	//if (tc_strcmp(child_item_prttype,"Dummy")==0)
																	if((tc_strstr(child_item_prttype,"Dummy") == NULL))
																	{
																		printf("\n tm_MRQty_Check [%s] part having Quantity > 0 and part_type is not Dummy \n",child_item_id);
																		PRTTYPEFLAG++;
																	}														
																}
																else
																{
																	//check if part type other than CP module then fail it otherwise pass it.
																	if((tc_strstr(child_item_prttype,"CAD Module") == NULL))
																	{
																		CPmoduleFlag++;
																		printf("\n CPmoduleFlag:%d \n",CPmoduleFlag);fflush(stdout);
																	}
																}
																
															}
															if (PRTTYPEFLAG == 0) 
															{
																if (CPmoduleFlag >0)
																{
																	tc_strcpy(test1,objectId);
																	tc_strcat(test1,sep);
																}
															}
													  }
												  }
												  printf("\n tm_MRQty_Check PRTTYPEFLAG ===============>>>>>> %d\n",PRTTYPEFLAG);fflush(stdout);
												  if (PRTTYPEFLAG > 0)
												  {
													    printf("\n *********** ::tm_MRQty_Check Module has no 0 Quantity parts and no Dummy part type:: **********");fflush(stdout);
												  }
												  else
												  {
													  if (CPmoduleFlag >0)
													  {
															POM_get_user(&username,&user_tag);
															SA_ask_user_identifier2	(user_tag,&userid)	;
															printf ("Logged in user Inside control OBJ ON-->:%s %s\n",userid,username);fflush(stdout);

															if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba") !=0) && (tc_strcmp(userid,"loader") !=0) && (tc_strcmp(userid,"ercpsup") !=0))
															{
																printf("\n tm_MRQty_Check Inside error \n"); fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s3(EMH_severity_error,ITK_err,"Each module should have atleast one Non-Dummy/Non-zero quantity part.Its mandatory for releasing the Module",test1,"does not qualify the above criteria.");
																decision = EPM_nogo;
																return decision;
															}
													  }
													  else
													  {
														  printf("\n All CP modules with 0 qty bypassed...");fflush(stdout);
													  }
												  }
											  }
											}	
										}								
									}
								}
							}
						}
					}
				}
			}
		}
	}
	/*	if(TaskPerfInfo1){MEM_free(TaskPerfInfo1);}
	if(TaskPerfInfo4){MEM_free(TaskPerfInfo4);}
	if(value){MEM_free(value);}
	if(objectId){MEM_free(objectId);}
	if(Part_type){MEM_free(Part_type);}
	if(child_item_id){MEM_free(child_item_id);}
	if(child_item_prttype){MEM_free(child_item_prttype);}*/
	printf("\n tm_MRQty_Check Function end...");fflush(stdout);
	TC_write_syslog("\n tm_MRQty_Check Function end...");
	return decision;
}