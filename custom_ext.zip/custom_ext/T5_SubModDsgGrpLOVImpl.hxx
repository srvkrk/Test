//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_SubModDsgGrpLOVImpl
//

#ifndef TRL001__T5_SUBMODDSGGRPLOVIMPL_HXX
#define TRL001__T5_SUBMODDSGGRPLOVIMPL_HXX

#include <T5_newpartreq/T5_SubModDsgGrpLOVGenImpl.hxx>

#include <T5_newpartreq/libt5_newpartreq_exports.h>


namespace TRL001
{
    class T5_SubModDsgGrpLOVImpl; 
    class T5_SubModDsgGrpLOVDelegate;
}

class  T5_NEWPARTREQ_API TRL001::T5_SubModDsgGrpLOVImpl
    : public TRL001::T5_SubModDsgGrpLOVGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_SubModDsgGrpLOV
    explicit T5_SubModDsgGrpLOVImpl( T5_SubModDsgGrpLOV& busObj );

    ///
    /// Destructor
    virtual ~T5_SubModDsgGrpLOVImpl();

private:
    ///
    /// Default Constructor for the class
    T5_SubModDsgGrpLOVImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_SubModDsgGrpLOVImpl( const T5_SubModDsgGrpLOVImpl& );

    ///
    /// Copy constructor
    T5_SubModDsgGrpLOVImpl& operator=( const T5_SubModDsgGrpLOVImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_SubModDsgGrpLOVDelegate;

};

#include <T5_newpartreq/libt5_newpartreq_undef.h>
#endif // TRL001__T5_SUBMODDSGGRPLOVIMPL_HXX
