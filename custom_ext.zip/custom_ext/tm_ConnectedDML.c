/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler to update latest released revisin of parts attached to GMD.
*  Code                 :   tm_ConnectedDML.c
*  Created on			:   12/04/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		14/04/2020				Mohan Tayade		Connected DML logic in TCUA.
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_ConnectedDML(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *PathInfo8		= NULL;
	char *DMlid		= NULL;
	char *VCDMLcommand		= NULL;
	char *plnttoplnt		= NULL;
	char *DMLrlstype		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n tm_ConnectedDML Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ConnectedDML Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n DD:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n DD: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n DD:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n DD:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "POCHCK";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n DD:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n DD:POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo8",&PathInfo8)!=ITK_ok)   PrintErrorStack();
					printf("\n DD:PathInfo8 is :[%s]\n", PathInfo8);fflush(stdout);
					if(strstr(POinfo3,"DEPDMLOFF3")==NULL)
					{
						if(AOM_ask_value_string(taskAttachments[i], "t5_rlstype", &DMLrlstype)!=ITK_ok)   PrintErrorStack();
						printf(" \n DD:DMLrlstype:%s:", DMLrlstype); fflush(stdout);
						if(tc_strcmp(DMLrlstype,"TODR")==0)
						{
							if(AOM_ask_value_string(taskAttachments[i], "t5_PlntToPlnt", &plnttoplnt)!=ITK_ok)   PrintErrorStack();
							if((plnttoplnt==NULL)|| (tc_strcmp(plnttoplnt,"")==0))
							{
								printf("\n DD:plnttoplnt is NULL. \n");fflush(stdout);
							}
							else
							{
								if(strstr(POinfo3,"DEPDMLOFF1")==NULL)
								{
									if(strstr(POinfo3,"DEPDMLUAPROD")==NULL)
									{
										if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n DD:UAPROD:DML no : %s ", DMlid);fflush(stdout);
										//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/conectdml.sh %s ",DMlid);
										sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/conectdml.sh %s ",DMlid);
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else if(strstr(POinfo3,"DEPDMLCVPROD")==NULL)
									{
										if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n DD:CVPROD:DML no : %s ", DMlid);fflush(stdout);
										//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/conectdml.sh %s ",DMlid);
										sprintf(command,"/user/cvprod/shells/DML_DCR/conectdml.sh %s ",DMlid);
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else if(strstr(POinfo3,"DEPDMLCMITEST")==NULL)
									{
										if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n DD:CMITEST:DML no : %s ", DMlid);fflush(stdout);
										sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/conectdml.sh %s ",DMlid);
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else if(strstr(POinfo3,"DEPDMLUADEV")==NULL)
									{
										if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n DD:UADEV:DML no : %s ", DMlid);fflush(stdout);
										sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/conectdml.sh %s ",DMlid);
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else
									{
										printf("\n DD:other client \n");fflush(stdout);
									}
								}
								else if(strstr(POinfo3,"DEPDMLOFF2")==NULL)
								{
									printf("\n DEPDDML:PATHBase:command.. \n");fflush(stdout);
									if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n DEPDDML:UADEV:DML no : %s ", DMlid);fflush(stdout);
									VCDMLcommand = (char	*)MEM_alloc(500);
									tc_strcpy(VCDMLcommand,"");
									tc_strcpy(VCDMLcommand,PathInfo8);
									tc_strcat(VCDMLcommand," ");
									tc_strcat(VCDMLcommand,DMlid);
									//tc_strcat(VCDMLcommand," ");
									printf("\n DEPDDML::VCDMLcommand: %s \n",VCDMLcommand);fflush(stdout);
									TC_write_syslog("VCDMLcommand = %s\n",VCDMLcommand);
									system(VCDMLcommand);
									printf("\n DEPDDML::PATHBase:. successfully.. \n");fflush(stdout);
								}
								else
								{
									printf("\n DD:other off \n");fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n DD:other DML type \n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_ConnectedDML Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ConnectedDML Function end...");
	//return error_code;
	return 0;
}