#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <fclasses/tc_date.h>
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
date_t		   ObjectClassType2;
//PrintErrorStack();

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
//    	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Part Type"
//	 919003: error_919003, "Part Type"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"

    return ITK_ok;
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}


#define ITK_CALL(X) 							\
		printf(#X);								\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			printf("\tSUCCESS\n");				\
		}										\


GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return strlen( pInput );
}


int ITK_user_main(int argc, char* argv[])
{
	int		BUFFER_SIZE			= 500;
	int		status				= 0;
	int		flag				= 0;
	int     retcode				= ITK_ok;  /* Function return code */
	int		ifail				= ITK_ok;
	int		month				= 0;
	int		Item_SeqI			= 0;
    int		n_partsI			= 0;
	int		i					= 0;
	int		n_tags_found		= 0;
	int		result				= 0;
	int		ref_count			= 0;
	int		NoOfWeldSpotI		= 0;
	
	char*	InputPathS			= NULL;
	char*	PartNumberS			= NULL;
    char*	NoOfWeldSpotS		= NULL;
    char*	InputFileNameS		= NULL;
    char*	InputFilePathS		= NULL;
    char*	PLMProrpathS		= NULL;
    char*	WeldspotFileNameS	= NULL;
    char*	CsvFileNameS		= NULL;

    char*	Item_IdS			= NULL;
    char*	Item_RevS			= NULL;
    char*	PatSeqS				= NULL;
	char*	DsObjNameS			= NULL;
	char*	DsDescS				= NULL;
	char*	prttokens			= NULL;
	char*	chldtokens			= NULL;
	char*	chldtokens1			= NULL;
	char*	tempS				= NULL;
	char*	username			= NULL;
	char*	group				= NULL;

	char	buffer [33];
	char	buf[1000];
	char	**ref_list;
	int nameRef_cnt = 0;
	tag_t *namRefObject = NULL;



	tag_t item_tags_found		= NULLTAG;
	tag_t latest_item_rev_tag	= NULLTAG;
	tag_t reln_type_tag			= NULLTAG;
	tag_t relation_tag			= NULLTAG;
	tag_t datasettype			= NULLTAG;
	tag_t Newdataset			= NULLTAG;
	tag_t tool					= NULLTAG;
	tag_t relation				= NULLTAG;
	tag_t filetag				= NULLTAG;
	tag_t relation_type			= NULLTAG;
	tag_t CO_User_t				= NULLTAG;
	tag_t CO_User_Grp_t			= NULLTAG;
	tag_t Loader_t				= NULLTAG;
	tag_t Loader_Grp_t			= NULLTAG;

	tag_t *secondary_obj_tag	= NULLTAG;
	
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType		= 1;

	FILE* fpABFPanelNo = NULL;


	ITK_initialize_text_services (0);
	
	//ITK_CALL(ITK_auto_login ());
	if( ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;


    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

	InputPathS		= ITK_ask_cli_argument("-InputPathS=");
    PartNumberS		= ITK_ask_cli_argument("-PartNumberS="); 
    NoOfWeldSpotS	= ITK_ask_cli_argument("-NoOfWeldSpot=");
   
	printf("\n InputPathS    %s",InputPathS);fflush(stdout);
	printf("\n PartNumberS   %s",PartNumberS);fflush(stdout);
	printf("\n NoOfWeldSpotS %s \n\n",NoOfWeldSpotS);fflush(stdout);
	NoOfWeldSpotI=atoi(NoOfWeldSpotS);
	printf("\n NoOfWeldSpotI %d \n\n",NoOfWeldSpotI);fflush(stdout);
	
	InputFileNameS=( char * )MEM_alloc(200);
	strcpy(InputFileNameS,"");
	InputFileNameS=strcat(InputFileNameS,PartNumberS);
	InputFileNameS=strcat(InputFileNameS,"_ABFPanelNo.txt");
	printf("\n\n InputFileNameS for Has Welded Relation Creation [%s] ",InputFileNameS);fflush(stdout);
	
	InputFilePathS = ( char * ) MEM_alloc(500);
	strcpy(InputFilePathS,"");
	InputFilePathS=strcat(InputFilePathS,InputPathS);
	InputFilePathS=strcat(InputFilePathS,"/");
	InputFilePathS=strcat(InputFilePathS,InputFileNameS);
	printf("\n InputFilePathS for Has Welded Relation Creation [%s] \n\n",InputFilePathS);fflush(stdout);
	
	PLMProrpathS = ( char * ) MEM_alloc(300);
	strcpy(PLMProrpathS,"");
	PLMProrpathS=strcat(PLMProrpathS,InputPathS);
	PLMProrpathS=strcat(PLMProrpathS,"/");
	PLMProrpathS=strcat(PLMProrpathS,"PLMProperties.txt");
	printf("\n PLMProrpathS	[%s] ",PLMProrpathS);fflush(stdout);


	// Find Latest Item Revision 

	ifail = ITEM_find_item( PartNumberS,&item_tags_found );	
	if (item_tags_found != NULLTAG)
	{
		printf("\n Now finding the latest Revision ");
		ifail = ITEM_ask_latest_rev(item_tags_found, &latest_item_rev_tag);

		if (AOM_ask_value_string(latest_item_rev_tag,"item_id",&Item_IdS)!=ITK_ok)   PrintErrorStack();
		printf("\n Item_IdS : %s",Item_IdS);fflush(stdout);
		if (AOM_ask_value_string(latest_item_rev_tag,"item_revision_id",&Item_RevS)!=ITK_ok)   PrintErrorStack();
		printf("\n Item_RevS : %s",Item_RevS);fflush(stdout);
		if (AOM_ask_value_int(latest_item_rev_tag,"sequence_id",&Item_SeqI)!=ITK_ok)   PrintErrorStack();
		printf("\n Item_SeqS : %d",Item_SeqI);fflush(stdout);
		PatSeqS=malloc(3);
	    sprintf(PatSeqS,"%d",Item_SeqI);
		printf("\n PatSeqS : %s",PatSeqS);fflush(stdout);
	}
	else
		printf("\n Part Not Found in PLM ! ! !\n");
	

	// Creating CSV File Name and Full Path for the CSV file.

	CsvFileNameS = ( char * ) MEM_alloc(200);
	strcpy(CsvFileNameS,"");
	CsvFileNameS=strcat(CsvFileNameS,Item_IdS);
	CsvFileNameS=strcat(CsvFileNameS,"_");
	CsvFileNameS=strcat(CsvFileNameS,Item_RevS);
	CsvFileNameS=strcat(CsvFileNameS,"_");
	CsvFileNameS=strcat(CsvFileNameS,PatSeqS);
	CsvFileNameS=strcat(CsvFileNameS,"_Weld_Report.csv");
	printf("\n CsvFileNameS	[%s] ",CsvFileNameS);fflush(stdout);

	WeldspotFileNameS = ( char * ) MEM_alloc(500);
	strcpy(WeldspotFileNameS,"");
	WeldspotFileNameS=strcat(WeldspotFileNameS,InputPathS);
	WeldspotFileNameS=strcat(WeldspotFileNameS,"/");
	WeldspotFileNameS=strcat(WeldspotFileNameS,Item_IdS);
	WeldspotFileNameS=strcat(WeldspotFileNameS,"_");
	WeldspotFileNameS=strcat(WeldspotFileNameS,Item_RevS);
	WeldspotFileNameS=strcat(WeldspotFileNameS,"_");
	WeldspotFileNameS=strcat(WeldspotFileNameS,PatSeqS);
	WeldspotFileNameS=strcat(WeldspotFileNameS,"_Weld_Report.csv");
	printf("\n WeldspotFileNameS	[%s] ",WeldspotFileNameS);fflush(stdout);

	// Change the Ownership to loader user and then revert it.

	printf("\n 1111 Finding Who Checked Out the Item Revision.");fflush(stdout);
	RES_who_checked_object_out(latest_item_rev_tag, &CO_User_t, &CO_User_Grp_t);
	
	printf("\n Finding Loader Tag and Group Tag.");fflush(stdout);
	POM_get_user(&username,&Loader_t);		
	POM_ask_group(&group,&Loader_Grp_t);

	printf("\n Transfer checkout to Loader Login for Attaching CSV file to Design Rev.");fflush(stdout);
	RES_transfer_checkout(latest_item_rev_tag, Loader_t, Loader_Grp_t);

	CALLAPI(AOM_lock(latest_item_rev_tag));
	if( AOM_set_value_int(latest_item_rev_tag,"t5_NoOfWeldSpots",NoOfWeldSpotI)) PrintErrorStack();
	AOM_save(latest_item_rev_tag);
	AOM_unlock(latest_item_rev_tag);
	// Registering the CSV File and Attaching it to the Design Revision with IMAN_specification Relationship.
	
	if( GRM_find_relation_type("IMAN_specification",&reln_type_tag)) PrintErrorStack();
	if( reln_type_tag != NULLTAG )
	{			
		if ( (ifail = GRM_list_secondary_objects_only( latest_item_rev_tag, reln_type_tag, &n_partsI, &secondary_obj_tag )) != ITK_ok )
		{
			return ifail;
		}
		printf("\n IMAN_specification for [%d] parts found ! ! ",n_partsI); fflush(stdout);
		for (i=0;i<n_partsI ;i++)
		{
			if ( GRM_find_relation(latest_item_rev_tag, secondary_obj_tag[i], reln_type_tag, &relation_tag) )PrintErrorStack();
			if (relation_tag != NULLTAG)
			{
				if( AOM_ask_value_string(secondary_obj_tag[i],"object_name",&DsObjNameS))PrintErrorStack(); 
				printf("\n DsObjNameS %s", DsObjNameS);fflush(stdout);
				if(strstr(DsObjNameS,".csv")!=NULL)
				{						
					if ( ifail = GRM_delete_relation(relation_tag) != ITK_ok )
					{
						PrintErrorStack();
						return ifail;
					}
					printf("\n IMAN_specification for [%s, %s, %d] Deleted ! ! ",Item_IdS,Item_RevS,Item_SeqI); fflush(stdout);
				}
			}
		}

		result = AE_find_datasettype("MSExcel",&datasettype);
		printf("\n Type found---->%d",result);fflush(stdout);

		result = AE_create_dataset_with_id(datasettype,WeldspotFileNameS,DsDescS,NULL,NULL,&Newdataset);
		printf("\n Dataset created--->%s",WeldspotFileNameS);fflush(stdout);

		result = AE_set_dataset_format(Newdataset,"BINARY_REF");
		printf("\n Dataset format set--->%d",result);fflush(stdout);						

		result = AE_set_dataset_tool(Newdataset,tool);
		printf("\n Tool set--->%d",result);fflush(stdout);fflush(stdout);

		result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
		printf("\n\t namRefObject Count--->%d\n",nameRef_cnt);fflush(stdout);

		if (nameRef_cnt == 0)
		{
			result = AE_ask_datasettype_refs(datasettype,&ref_count,&ref_list);
			printf("\n Got reference list--->%d",result);fflush(stdout);	

			result = IMF_import_file(WeldspotFileNameS,NULL,SS_BINARY,&filetag,&fileDescriptor);
			printf("\n File Imported--->%d",result);fflush(stdout);						

			result = AOM_save(filetag);
			printf("\n File saved--->%d",result);fflush(stdout);

			result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
			printf("\n AE_add_dataset_named_ref--->%d",result);fflush(stdout);

			AE_set_dataset_tool(Newdataset,tool);
			printf("\n Tool set--->%d",result);fflush(stdout);fflush(stdout);

			AOM_set_value_string(Newdataset, "object_name", CsvFileNameS);

			result = AOM_save(Newdataset);
		}
		result = GRM_find_relation_type("IMAN_specification", &relation_type);
		printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);		
		
		printf("\n Creating Relations.");fflush(stdout);
		result = GRM_create_relation(latest_item_rev_tag,Newdataset,relation_type,NULLTAG,&relation);
		printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
		
		if (relation != NULLTAG)
		{
			result = GRM_save_relation(relation);
			printf("\n GRM_save_relation ---->%d",result);fflush(stdout);	
		}
	}
	

	// Reading the ABFPanelNo.txt file from the Input Folder and creating the Has-Welded-Parts Relationship.

	printf("\n\n InputFileNameS for Has Welded Relation Creation [%s] ",InputFileNameS);fflush(stdout);
	printf("\n InputFilePathS for Has Welded Relation Creation [%s] \n\n",InputFilePathS);fflush(stdout);
	fflush(fpABFPanelNo);
	fpABFPanelNo = fopen(InputFilePathS,"r");

	prttokens = ( char * ) MEM_alloc(3000);
	chldtokens = ( char * ) MEM_alloc(3000);
	chldtokens1 = ( char * ) MEM_alloc(3000);


	while(fgets(buf, BUFFER_SIZE, fpABFPanelNo) != NULL)
	{
		printf("\n buf - %s",buf);fflush(stdout);
		
		prttokens = strtok(buf,"::");
		
		while (tempS = strtok( NULL, "::" ))
		{
			strcpy(chldtokens,tempS);
			//printf("\n chldtokens - %s ",chldtokens);fflush(stdout);
		}
		chldtokens1=strtok(chldtokens,".");

		printf("\n PartTokens1 - [%s]",prttokens);fflush(stdout);
		printf("\n chldtokens1 - [%s] \n",chldtokens1);fflush(stdout);
		

		// Creating Has Welded Parts Relationship between Design Rev and Design Master
		
		relation			=	NULLTAG;
		relation_tag		=	NULLTAG;
		reln_type_tag		=	NULLTAG;
		item_tags_found		=	NULLTAG;
		secondary_obj_tag	=	NULLTAG;
		n_partsI			=	0;		


		if( GRM_find_relation_type("T5_HasWeldParts",&reln_type_tag)) PrintErrorStack();
		if( reln_type_tag != NULLTAG )
		{
			if ( (ifail = GRM_list_secondary_objects_only( latest_item_rev_tag, reln_type_tag, &n_partsI, &secondary_obj_tag )) != ITK_ok )
			{
				return ifail;
			}

			printf("\n Welded Relation for [%d] parts found ! ! ",n_partsI); fflush(stdout);
			
			ifail = ITEM_find_item( chldtokens1,&item_tags_found );	
			if (item_tags_found != NULLTAG && n_partsI == 0)
			{
				result = GRM_create_relation(latest_item_rev_tag,item_tags_found,reln_type_tag,NULLTAG,&relation);PrintErrorStack();
				printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
				
				if (relation != NULLTAG)
				{
					result = GRM_save_relation(relation);PrintErrorStack();
					printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
				}
			}
			else
				printf("\n Welded Parts Already Found ! ! "); fflush(stdout);
		}
	}

	printf("\n Transfering back to the original checkout user \n");fflush(stdout);
	RES_transfer_checkout(latest_item_rev_tag, CO_User_t, CO_User_Grp_t);



CLEANUP :



EXIT :
	ITK_exit_module (TRUE);
	return status;
}