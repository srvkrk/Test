/*******************
*  File            :   EstCreMulOpr.c
*  Created By      :   Vijay Khandare
*  Created On      :   07-Sept-2023
*  Purpose         :   Create multiple operations on newly created estimate sheet using .txt/.csv in TCUA same as TCE.
*  TZ			   :   
*******************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

//API changed for 12.2 to 14.3 upgrade...
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;

char * StringTrimEstCre(char** pointerToString)
{
    int start=0, length=0;

        // Trim.Start:
        length = strlen(*pointerToString);
        while ((*pointerToString)[start]==' ') start++;
        (*pointerToString) += start;

        if (start < length) // Required for empty (ex. "    ") input
        {
            // Trim.End:
            int end = strlen(*pointerToString)-1; // Get string length again (after Trim.Start)
            while ((*pointerToString)[end]==' ') end--;
            (*pointerToString)[end+1] = 0;
        }

    return *pointerToString;
}

int tm_CreateMulOprs(char *EstimateNO,char *Infiledata)
{
	int ifail = ITK_ok;

    int           noofEst                = 0;
    tag_t         *ESTSheetSet           = NULLTAG;
    tag_t         EstQrtag               = NULLTAG;
    char          *StringLine            = NULL;
	
	char*         StorOprInfo[1000]      ;

    StringLine = (char *) MEM_alloc(1 * sizeof(Infiledata));
	StringLine = strtok(Infiledata,"\n");
	int StorIdx = 0;
	while(StringLine!=NULL)
	{
		StorOprInfo[StorIdx] = (char*)malloc(300);
		strcpy(StorOprInfo[StorIdx],StringLine);
		StringLine = strtok(NULL,"\n");
		StorIdx ++;
	}
	
	printf(" Total StorIdx.... = %d\n",StorIdx);fflush(stdout);


    printf("Input Estimate sheet number is = %s\n",EstimateNO);fflush(stdout);

    if(QRY_find2("Item Revision...", &EstQrtag));//API changed for 12.2 to 14.3 upgrade...
	if(EstQrtag != NULLTAG)
	{
		printf("General query found\n");fflush(stdout);
	} 
	else
		printf("General Query not found\n");fflush(stdout);

    char *attribute[2] = {"Item ID","Type"};
    char *values[2]; 
    values[0] = EstimateNO;
    values[1] = "Estimate Sheet Revision";

    ITK_CALL(QRY_execute(EstQrtag,2,attribute,values,&noofEst,&ESTSheetSet));

    if(noofEst > 0)
    {
        printf("Estimate sheet found.....\n");fflush(stdout);

        tag_t     EstimateObj    = NULLTAG;
        tag_t     EstOperRel     = NULLTAG;
        int       NoofOper       = 0;
        tag_t     *EstOperSet    = NULLTAG;
        char      *EstObjName    = NULL;
        char      *EstRevId      = NULL;

        EstimateObj = ESTSheetSet[0];

        ITK_CALL(AOM_ask_value_string(EstimateObj,"object_name",&EstObjName));
        printf("Estimate sheet Number = %s\n",EstObjName);fflush(stdout);

        ITK_CALL(AOM_ask_value_string(EstimateObj,"item_revision_id",&EstRevId));
        
		printf("Estimate revision id is = %s\n",EstRevId);fflush(stdout);

        ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&EstOperRel));
        ITK_CALL(GRM_list_secondary_objects_only(EstimateObj,EstOperRel,&NoofOper,&EstOperSet));
		
		printf(" No of Operation present under estimate sheet is = %d\n", NoofOper);fflush(stdout);
		
        if(NoofOper > 0)
        {
            printf("Estimate sheet already have operations .....\n");fflush(stdout);

            int EsOpItr = 0;

            for(EsOpItr = 0 ; EsOpItr < NoofOper ; EsOpItr++)
            {
                tag_t      EstOperation    = NULLTAG;
                char       *EstOperID      = NULL;                
                EstOperation = EstOperSet[EsOpItr];                
                ITK_CALL(AOM_ask_value_string(EstOperation,"current_id",&EstOperID));
                printf("Estimate Operation no present under estimate sheet  = %s\n",EstOperID);fflush(stdout);

            }

        }
        else
        {
            printf("Estimate Operation not found .... \n");fflush(stdout);
            printf("Need to create new operations.....\n");fflush(stdout);

            int      ItrOprInpt   = 0;
            for(ItrOprInpt = 0 ; ItrOprInpt < StorIdx ; ItrOprInpt++)
            {
                tag_t         EstOpTypTag             = NULLTAG;
                tag_t         EstOpInputTag           = NULLTAG;
                tag_t         ESTObjCreate            = NULLTAG;
                tag_t         EstOpTypTagRev          = NULLTAG;
                tag_t         EstOpInputTagRev        = NULLTAG;
                tag_t         EstOperLatRev           = NULLTAG;
                tag_t         ESTOprRelV              = NULLTAG;
                tag_t         ESTOprEstRelV           = NULLTAG;

                char          *EstOperationV          = NULL;
                char          *EstOperDesc            = NULL;
                char          *EstOperStation         = NULL;
                char          *EstOpWrkCnt            = NULL;
                char          *EstOperLine            = NULL;
                char          *EstOprAPLstdTime       = NULL;
                char          *EstOprGang             = NULL;
                char          *EstOprValue            = NULL;
                char          *PartperCycle           = NULL;
				
				char          *RevisionV              = NULL;
				
				char          *StringLine1            = NULL;
			
				tc_strcpy(RevisionV,"NR;1");

                EstOperationV = (char *) MEM_alloc(100 * sizeof(char *));
                EstOperDesc = (char *) MEM_alloc(100 * sizeof(char *));
                EstOperStation = (char *) MEM_alloc(100 * sizeof(char *));
                EstOpWrkCnt = (char *) MEM_alloc(100 * sizeof(char *));
                EstOperLine = (char *) MEM_alloc(100 * sizeof(char *));
                EstOprAPLstdTime = (char *) MEM_alloc(100 * sizeof(char *));
                EstOprGang = (char *) MEM_alloc(100 * sizeof(char *));
                EstOprValue = (char *) MEM_alloc(100 * sizeof(char *));
                PartperCycle = (char *) MEM_alloc(100 * sizeof(char *));
				
                StringLine1 = (char *) MEM_alloc(100 * sizeof(char *));
				
				tc_strcpy(StringLine1,StorOprInfo[ItrOprInpt]);
				
				printf("StringLine1 is.... = %s\n",StringLine1);fflush(stdout);

                tc_strcpy(EstOperationV,strsep(&StringLine1,","));
		        tc_strcpy(EstOperDesc,strsep(&StringLine1,","));
		        tc_strcpy(EstOperStation,strsep(&StringLine1,","));
                tc_strcpy(EstOpWrkCnt,strsep(&StringLine1,","));
		        tc_strcpy(EstOperLine,strsep(&StringLine1,","));
		        tc_strcpy(EstOprAPLstdTime,strsep(&StringLine1,","));
		        tc_strcpy(EstOprGang,strsep(&StringLine1,","));
		        tc_strcpy(EstOprValue,strsep(&StringLine1,","));
		        tc_strcpy(PartperCycle,strsep(&StringLine1,","));
				
				StringTrimEstCre(&EstOperationV);
		        StringTrimEstCre(&EstOperDesc);
		        StringTrimEstCre(&EstOperStation);
		        StringTrimEstCre(&EstOpWrkCnt);
		        StringTrimEstCre(&EstOperLine);
		        StringTrimEstCre(&EstOprAPLstdTime);
		        StringTrimEstCre(&EstOprGang);
		        StringTrimEstCre(&EstOprValue);
		        StringTrimEstCre(&PartperCycle);         
				
				//Estimate Operation Query...................
	            tag_t    EstOprQryTag        = NULLTAG;
	            tag_t    *EstOprSet          = NULLTAG;
	            int      NoOfEntry           = 2;
	            int      NoOfEstOpr          = 0;
	            char* OprEntry[2]            = {"ID","t5_EstimateNumber"};
	            char* OprValue[2]            = {EstOperationV,EstimateNO};
				
				printf("Entry is  = [%s] [%s]\n",OprEntry[0],OprEntry[1]);fflush(stdout);
				printf("Value is  = [%s] [%s]\n",OprValue[0],OprValue[1]);fflush(stdout);
	            
	            ITK_CALL(QRY_find2("EstimateOperationQry", &EstOprQryTag));//API changed for 12.2 to 14.3 upgrade...
	            printf("\n found EstOprQryTag \n");fflush(stdout);
	            
	            ITK_CALL(QRY_execute(EstOprQryTag,NoOfEntry,OprEntry,OprValue,&NoOfEstOpr,&EstOprSet));
				
				printf(" Operation Exist is = %d\n", NoOfEstOpr);fflush(stdout);
				
				if(NoOfEstOpr > 0)
                {
                    tag_t      PreEstOpr             = NULLTAG;
                    char       *PreEstOperID         = NULL;  
                    tag_t      EstOperRel1V          = NULLTAG;
                    tag_t      ESTOprRelSav          = NULLTAG;						
		            
                    PreEstOpr = EstOprSet[0];   
		            
		            ITK_CALL(AOM_ask_value_string(PreEstOpr,"current_id",&PreEstOperID));
                    printf("Existing Estimate Operation id  = %s\n",PreEstOperID);fflush(stdout);

		            
		            ITK_CALL(AOM_lock(PreEstOpr));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_PEOpnNumber",EstOperationV));
		            
		            ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_PEOpnDesc",EstOperDesc));
		            
		            ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_EstStation",EstOperStation));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_EPOCHPEBCNo",EstOpWrkCnt));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_EstLine",EstOperLine));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_PETimeOpnApl",EstOprAPLstdTime));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_PEAplGangSize",EstOprGang));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_EPOCHValue",EstOprValue));
		            
                    ITK_CALL(AOM_set_value_string(PreEstOpr,"t5_PEPartPerCycle",PartperCycle));
		            
		            
                    ITK_CALL(AOM_save_with_extensions(PreEstOpr));//API changed for 12.2 to 14.3 upgrade...
		            ITK_CALL(AOM_unlock(PreEstOpr));
		            
		            ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&EstOperRel1V));
		            
		            ITK_CALL(GRM_create_relation(EstimateObj,PreEstOpr,EstOperRel1V,NULLTAG,&ESTOprRelSav)); 
		            
		            GRM_save_relation(ESTOprRelSav);
                    printf("Pre Opr Relation are created successfully ..... \n");fflush(stdout);
					
				}
				else
				{
					
				    //ITK_CALL(ITEM_create_item(EstOperationV,EstOperDesc,"T5_EstimateOprtn",RevisionV,&ESTObjCreate,&EstOperLatRev));
					
					//API changed for 12.2 to 14.3 upgrade...
					
					ITK_CALL(TCTYPE_find_type("T5_EstimateOprtn",NULL,&EstOpTypTag));

                    ITK_CALL(TCTYPE_construct_create_input(EstOpTypTag,&EstOpInputTag));
				    
                    ITK_CALL(AOM_set_value_string(EstOpInputTag,"item_id",EstOperationV));
				    
                    ITK_CALL(AOM_set_value_string(EstOpInputTag,"object_name",EstOperDesc));
				    
			        ITK_CALL(AOM_set_value_string(EstOpInputTag,"object_desc",EstOperDesc));
					
					ITK_CALL(TCTYPE_create_object(EstOpInputTag,&ESTObjCreate));
					
					ITK_CALL(AOM_set_value_string(ESTObjCreate,"t5_EstimateNumber",EstimateNO));
					
					AOM_save_with_extensions(ESTObjCreate);//API changed for 12.2 to 14.3 upgrade...
                    AOM_unlock(ESTObjCreate);
					
					ITK_CALL(ITEM_ask_latest_rev(ESTObjCreate,&EstOperLatRev));
				    
                    if((ESTObjCreate != NULLTAG) && (EstOperLatRev != NULLTAG))
                    {

                        printf("Operations are created successfully..... \n");fflush(stdout);
				    
                        tag_t       EstOperRel1         = NULLTAG;
                        tag_t       EstOperToEstRel1    = NULLTAG;
				    
				    	printf("Operations revision are created successfully..... \n");fflush(stdout);
				    
                        //..........................................................................
				    	
				    	ITK_CALL(AOM_lock(EstOperLatRev));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_PEOpnNumber",EstOperationV));			
				    
			            ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_PEOpnDesc",EstOperDesc));
				    
			            ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_EstStation",EstOperStation));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_EPOCHPEBCNo",EstOpWrkCnt));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_EstLine",EstOperLine));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_PETimeOpnApl",EstOprAPLstdTime));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_PEAplGangSize",EstOprGang));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_EPOCHValue",EstOprValue));
				    
                        ITK_CALL(AOM_set_value_string(EstOperLatRev,"t5_PEPartPerCycle",PartperCycle));
                        
                     
                        ITK_CALL(AOM_save_with_extensions(EstOperLatRev));//API changed for 12.2 to 14.3 upgrade...
				     	ITK_CALL(AOM_unlock(EstOperLatRev));
				    
                        ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&EstOperRel1));
                        ITK_CALL(GRM_find_relation_type("T5_OperationToEstimateRel",&EstOperToEstRel1));
                        
				    
                        if((EstOperRel1 != NULLTAG) && (EstOperToEstRel1 != NULLTAG))
                        {
                            printf("Both Relation found....... \n");fflush(stdout);
                        }
                        
                        ITK_CALL(GRM_create_relation(EstimateObj,EstOperLatRev,EstOperRel1,NULLTAG,&ESTOprRelV)); 
				    
                        ITK_CALL(GRM_create_relation(EstOperLatRev,EstimateObj,EstOperToEstRel1,NULLTAG,&ESTOprEstRelV)); 
				    
				    
                        if((ESTOprRelV != NULLTAG) && (ESTOprEstRelV != NULLTAG))
                        {
                            GRM_save_relation(ESTOprRelV);
                            GRM_save_relation(ESTOprEstRelV);
                            printf("Relation are created successfully ..... \n");fflush(stdout);  
                        }
                        else
                        {
                            printf("Relation are not created successfully ..... \n");fflush(stdout);
                        }        
                    }
                    else
                    {
                        printf("Estimate Operation Item not created ....\n");fflush(stdout);
                    }
				}
				
            }
            
        }
    }
    else
    {
        printf("Estimate sheet not found......\n");fflush(stdout);
    }
    return ITK_ok;
}

int EstCreMulOpr()
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *EstimateNO         = NULL;
	char     *Infiledata         = NULL;		

	printf("\n inside the function DML_ImplosionRpt .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&EstimateNO);
	USERARG_get_string_argument(&Infiledata);

	printf("\n Input Estimate number :: %s \n",EstimateNO);fflush(stdout);
	printf("\n Input File data is   :: %s \n",Infiledata);fflush(stdout);

	//..........................................................
		
	tm_CreateMulOprs(EstimateNO,Infiledata);

    return ifail;
}

extern int AllUserServiceFnEstCreMulOprFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 2;
    int retValueType;
    int inputArgTypes[2] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE;// Estimate Number 
    inputArgTypes[1] = USERARG_STRING_TYPE;// file data 

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("EstCreMulOpr",(USER_function_t)EstCreMulOpr,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_EstCreMulOpr_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_EstCreMulOpr", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnEstCreMulOprFn);
    return ifail;
}