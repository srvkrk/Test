/************************************************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*	Client Code	: WCQ_DATA_UPLOADER.c
*	Author		: Sumit Radotra
*	Created On	: 15/07/2020
*	PURPOSE		: WCQ DATA UPLOADER.
*
*	Modification History :
*	S.No    Date			CR No					Modified By					Modification Notes
*	1.		25/05/2021		CR/ERC/PLM/20/0214  	Sumit Radotra				WCQ DATA UPLOADER
*************************************************************************************************************/

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <fclasses/tc_date.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>


#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
date_t		   ObjectClassType2;
//PrintErrorStack();


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }

    return ITK_ok;
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}

#define ITK_CALL(X) 							\
		printf(#X);								\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			printf("\tSUCCESS\n");				\
		}										\


GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return strlen( pInput );
}


Registerdataset(tag_t TDM_rev_tag,char* FileStr,char* docFile)
{

	int	  status= 0;
	int	  ifail = ITK_ok;
	printf("Doc file created successfully %s %s \n",docFile,FileStr);fflush(stdout);
	if(access(docFile,F_OK)!=-1)
	{	
//		if (strstr(docFile,".pdf")!=NULL)
//		{
			tag_t specRelationType_t=NULLTAG;
			tag_t PdfType=NULLTAG;
			tag_t PdfDataset=NULLTAG;
			tag_t PdfLatestDat_t=NULLTAG;
			tag_t specificationRel_t=NULLTAG;
			tag_t *DATASET=NULL;
			char* PdfObjdesc=NULL;
			char* PdfObjName=NULL;
			int DsCnt=0;

			printf("Doc file created successfully\n");fflush(stdout);
			//CALLAPI(AE_find_datasettype2("PDF",&PdfType));
			CALLAPI(AE_find_datasettype2("MSExcel",&PdfType));
			if(PdfType == NULLTAG)
			{
				printf("Could not find Dataset Type PDF/MSExcel/MSWord/PPT. Please check data model\n");fflush(stdout);
				
			}
			int Icnt=0;
			tag_t RelationDS=NULLTAG;
			
			CALLAPI(GRM_find_relation_type("IMAN_reference",&specRelationType_t));

			CALLAPI(AE_create_dataset_with_id(PdfType,FileStr,"wcq","","",&PdfDataset));
			CALLAPI(AE_save_myself(PdfDataset));
			CALLAPI(GRM_create_relation(TDM_rev_tag,PdfDataset,specRelationType_t,NULLTAG,&specificationRel_t));
			CALLAPI(AOM_load(specificationRel_t));
			CALLAPI(GRM_save_relation(specificationRel_t));
			CALLAPI(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
			CALLAPI(AOM_refresh(PdfLatestDat_t,TRUE));
			//CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
			CALLAPI(AE_import_named_ref(PdfLatestDat_t,"msword",docFile,NULL,SS_BINARY));
			//CALLAPI(AE_save_myself(PdfLatestDat_t));

			AOM_save(PdfLatestDat_t);
			AOM_refresh(PdfLatestDat_t, FALSE);
			AOM_unload(PdfLatestDat_t);
			//remove(docFile);
			printf("\n file object done \n");fflush(stdout);
		//}
	}			
	else
	{
		  printf("\n file object not found \n");fflush(stdout);
		 
	}
}
int CreateWCQ(char* t5StdDocNo,char* Revision,char* Sequence,char* t5StdDocDesc,char* t5KeywordDesc,char* Docname,char* FullPath,FILE *fperror )
{
	tag_t Wcq_tag_Rev=NULLTAG;
	tag_t WCQ_tag=NULLTAG;
	tag_t specificationRel_t=NULLTAG;

	int	  status= 0;
	int	  ifail = ITK_ok;
		int ref_count;



	char* itemRevSeq = NULL;
	char* AddOnDesc  = NULL;
	char* stddoc_id  = NULL;
	char* result     = NULL;
	char* FileStr	 = NULL;
    char **ref_list;
	tag_t tool       =  NULLTAG;
	int   nameRef_cnt;
	//char *fullPath   =  NULL;
	tag_t filetag    =  NULLTAG;
	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;

	tag_t Newdataset =  NULLTAG;
	tag_t *namRefObject = NULL;
	tag_t datasettype   =  NULLTAG;



	//char docFile[300];


	FileStr=MEM_alloc(1000);

	itemRevSeq=(char *) MEM_alloc(32);
	strcpy(itemRevSeq,Revision);
	strcat(itemRevSeq,";");
	strcat(itemRevSeq,Sequence);

    stddoc_id=(char *) MEM_alloc(32);
	strcpy(stddoc_id,t5StdDocNo);
	strcat(stddoc_id,";");
	strcat(stddoc_id,Revision);
	strcat(stddoc_id,";");
	strcat(stddoc_id,Sequence);

	printf("\n STD DOC NUMBER :%s ", t5StdDocNo,itemRevSeq);fflush(stdout);

	int n_tags_found2=0;
	tag_t* tags_found2=NULL;
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)t5StdDocNo;
	values2[1] = "T5_Std_Wcq";

	ITK_CALL(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2));
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	
	int  		number_of_types1;
	int  		number_of_types2;
	tag_t * 	type_tag3;
	tag_t * 	type_tag3_R;
	
	tag_t	object_create_input_tag3		    = NULLTAG;
	tag_t	object_create_input_tag3_R		    = NULLTAG;
	tag_t	WCQ_tag_Rev							= NULLTAG;
	tag_t   PdfDataset							= NULLTAG;
	tag_t   PdfLatestDat_t						= NULLTAG;

	if (n_tags_found2==0)
	{

		ITK_CALL(TCTYPE_find_types_for_class("T5_Std_Wcq",&number_of_types1,&type_tag3));
		printf("\n number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);
		printf("\n Document Name-------->  : %s\n",Docname);fflush(stdout);
		printf("\n Full path of dataset -------->  : %s\n",FullPath);fflush(stdout);

		ITK_CALL(TCTYPE_find_types_for_class("T5_Std_WcqRevision",&number_of_types2,&type_tag3_R));
		ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

		ITK_CALL(AOM_set_value_string(object_create_input_tag3_R,"t5_AddOnDesc",AddOnDesc));
		//ITK_CALL(AOM_set_value_string(object_create_input_tag3_R,"object_name",t5StdDocNo));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3_R,"item_revision_id",itemRevSeq));

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",t5StdDocNo));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",t5StdDocNo));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",t5StdDocDesc));
		ITK_CALL(AOM_set_value_tag(object_create_input_tag3,"revision",object_create_input_tag3_R));

		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &WCQ_tag));

		AOM_save(WCQ_tag);
		AOM_unlock(WCQ_tag);

		printf("\n Here aaa -------->  : %s\n",FullPath);fflush(stdout);

		if(WCQ_tag!=NULLTAG) 
		{
			tag_t DataSetType=NULLTAG;
			tag_t specRelationType_t=NULLTAG;
			tag_t *DATASET=NULL;
			char* PdfObjdesc=NULL;
			char* PdfObjName=NULL;

			int DsCnt=0;
			
			CALLAPI(ITEM_ask_latest_rev (WCQ_tag, &WCQ_tag_Rev)) ;
			printf("\n Here bbb \n");fflush(stdout);

			Registerdataset(WCQ_tag_Rev,Docname,FullPath);

//			CALLAPI(AE_find_datasettype2("PDF",&DataSetType));
//			if(DataSetType == NULLTAG)
//			{
//				printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
//				
//			}
			//CALLAPI(GRM_find_relation_type("IMAN_reference",&specRelationType_t));
			//CALLAPI(GRM_list_secondary_objects_only(WCQ_tag_Rev,specRelationType_t,&DsCnt,&DATASET));
			//printf("\n WCQ Doc DsCnt: %d\n",DsCnt);fflush(stdout);
			
			//CALLAPI(AE_create_dataset_with_id(DataSetType,Docname,"WCQ Pdf Doc","","",&PdfDataset));
//			AE_set_dataset_format(Newdataset, "BINARY_REF");
//			AE_set_dataset_tool(Newdataset,tool);
//			AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
//			printf("\n\t ****pdf..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);
//			if (nameRef_cnt == 0)
//			{
//				AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
//				printf("\n\t Got reference list--->%d",result); fflush(stdout);			 
//
//				IMF_import_file(FullPath,NULL, SS_BINARY, &filetag, &fileDescriptor); //Fullpath
//				printf("\n\t File Imported--->%d",result); fflush(stdout);	 
//
//				AOM_save(filetag);
//				AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
//				AE_set_dataset_tool(Newdataset,tool);
//				AOM_save(Newdataset);
//			}
//			CALLAPI(AE_save_myself(Newdataset));
//			CALLAPI(GRM_create_relation(WCQ_tag_Rev,Newdataset,specRelationType_t,NULLTAG,&specificationRel_t));
//			CALLAPI(AOM_load(specificationRel_t));
//			CALLAPI(GRM_save_relation(specificationRel_t));
//			CALLAPI(AE_ask_dataset_latest_rev(Newdataset,&PdfLatestDat_t));
//			CALLAPI(AOM_refresh(PdfLatestDat_t,TRUE));
//			//CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference","/user/uaprod/sumit/WCQ_DATA_UPLOADER/PA20_F456.pdf",NULL,SS_BINARY)); //docFile =Fullpath of that file
//			CALLAPI(AE_save_myself(PdfLatestDat_t));
//			//remove(docFile);
//			
//			ITK_CALL(AOM_save(WCQ_tag_Rev));
//			ITK_CALL(AOM_refresh(WCQ_tag_Rev,0));
//			ITK_CALL(AOM_unlock(WCQ_tag_Rev));
//			printf("\n Option Value is created......\n"); fflush(stdout);
		}

	}
}
typedef struct  
{
	char* t5StdDocNo; 
	char* Revision;
	char* Sequence;
	char* t5StdDocDesc;	
	char* t5KeywordDesc;	
	char* Docname;	
	char* FullPath;	

} WcqInputFile;

int ITK_user_main(int argc, char* argv[])
{
	int BUFFER_SIZE	  =	500;
	int status		  = 0;
	int flag		  = 0;
	int retcode       = ITK_ok;  /* Function return code */
	int ifail	      = ITK_ok;
	int month         = 0;
	int day           = 0;
	int year          = 0;
	int hour          = 0;
	int minute        = 0;
	int second        = 0;

	 FILE* fperror=NULL;


	char	*inputline			= NULL;
	char*	 argstring;

	char**	stringArray			= NULL;
	char*	tempString			= NULL;
    char*	testS				= NULL;
    char*	ObjectClassType3	= NULL;
    char*	ObjectClassType4	= NULL;
    char*	Year				= NULL;
    char*	Month				= NULL;
    char*	Day					= NULL;
    char*	Hours				= NULL;
    char*	Min					= NULL;
    char*	Sec					= NULL;
    char*	MicroSec			= NULL;
    char*	DateS				= NULL;
    char*	DateTempS			= NULL;
    char*	OutputFileNameS	= "Parts_Not_Found.txt";

	WcqInputFile WcqStruct;
	int n_tags_found = 0;

	tag_t	itemTypeTag		= NULLTAG;
	tag_t	newItemTag		= NULLTAG;
	tag_t	itemCreInTag	= NULLTAG;
	tag_t	itemRevCreInTag	= NULLTAG;
	tag_t	itemRevTypeTag	= NULLTAG;
	tag_t	newDmlTag		= NULLTAG;
	tag_t	newDmlRevTag	= NULLTAG;
	tag_t	newTaskTag		= NULLTAG;
	tag_t	newTaskRevTag	= NULLTAG;
	tag_t	tRelationFind	= NULLTAG;
	tag_t	Rel_task		= NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	tag_t	PartRel_task	= NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t	item_tag_Rev	= NULLTAG;
	tag_t	tPartRelationExist	= NULLTAG;

	tag_t template_tag	= NULLTAG;
	tag_t test_job_a	= NULLTAG;
	int attachment_types    = 1;
	
	ITK_initialize_text_services (0);

	tag_t *tags_left = NULLTAG;
	tag_t *tags_right = NULLTAG;

	date_t    closureDate_D;
    logical   date_is_valid   = FALSE;   /* Date Validation */
	
	DateS = ( char * ) MEM_alloc(100);
	DateS=strcpy(DateS,"");
	DateTempS = ( char * ) MEM_alloc(100);

	FILE *fp1;
	FILE *fp_NotFound;

	//ITK_CALL(ITK_auto_login ());
	if( ITK_init_module("loader" ,"loader123","dba")!=ITK_ok) ;


    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

	argstring=ITK_ask_cli_argument("-i=");
	printf("\n Either Wrong Argument or Missed Argument ... Please Enter Correct Argument \n");fflush(stdout);

	fp1			= fopen(argstring,"r");
	fp_NotFound = fopen(OutputFileNameS,"a+");

	if (argstring != 0)
    {
        /* user has given an fp1 file, rather then using stdin */
        if( !(fp1 = fopen( argstring, "rt" )))
        {
            fprintf(stderr, "\n Cannot open fp1 file %s\n",argstring);
            exit( EXIT_FAILURE );
        }
        else
            printf("\nUsing input file %s\n",argstring);
    }
    else
    {
        printf("\nInput from Standard Input (stdin)\n");
    }

	if(fp1!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,BUFFER_SIZE,fp1)!=NULL)
		{
			fputs(inputline,stdout);
			
			//START : WCQ Attributes

			//t5StdDocNo
			WcqStruct.t5StdDocNo=strtok(inputline,"^");
			printf("\n t5StdDocNo :%s",WcqStruct.t5StdDocNo); fflush(stdout);				
			
			//Revision
			WcqStruct.Revision=strtok(NULL,"^");
			printf("\n Revision :%s",WcqStruct.Revision); fflush(stdout);

			//Sequence
			WcqStruct.Sequence=strtok(NULL,"^");
			printf("\n Sequence :%s",WcqStruct.Sequence); fflush(stdout);

			//t5StdDocDesc
			WcqStruct.t5StdDocDesc=strtok(NULL,"^");
			printf("\n t5StdDocDesc :%s",WcqStruct.t5StdDocDesc); fflush(stdout);

			//t5KeywordDesc
			WcqStruct.t5KeywordDesc=strtok(NULL,"^");
			printf("\n t5KeywordDesc :%s",WcqStruct.t5KeywordDesc); fflush(stdout);

			//Docname
			WcqStruct.Docname=strtok(NULL,"^");
			printf("\n Docname :%s",WcqStruct.Docname); fflush(stdout);

			//FullPath
			WcqStruct.FullPath=strtok(NULL,"^");
			printf("\n FullPath :%s",WcqStruct.FullPath); fflush(stdout);

			CreateWCQ(WcqStruct.t5StdDocNo,WcqStruct.Revision,WcqStruct.Sequence,WcqStruct.t5StdDocDesc,WcqStruct.t5KeywordDesc,WcqStruct.Docname,WcqStruct.FullPath,fperror);
						
		}	

	}
		
	
CLEANUP : 
	fclose(fp_NotFound);
EXIT:
	ITK_exit_module (TRUE);
	return status;
}