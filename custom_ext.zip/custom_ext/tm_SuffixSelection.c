#include<tccore/item.h>
#include<tccore/item_errors.h>
#include<ae/ae.h>
#include<ae/ae_types.h>
#include<ae/dataset.h>
#include<ae/dataset_msg.h>
#include<ae/datasettype.h>
#include<ae/vm_errors.h>
#include<ai/sample_err.h>
#include<bom/bom.h>
#include<bom/bom_attr.h>
#include<cfm/cfm.h>
#include<common/emh_const.h>
#include<ecm/ecm.h>
#include<epm/cr.h>
#include<epm/cr_action_handlers.h>
#include<epm/cr_effectivity.h>
#include<epm/cr_errors.h>
#include<epm/epm.h>
#include<epm/epm_errors.h>
#include<epm/epm_toolkit_iman_utils.h>
#include<epm/releasestatus.h>
#include<fclasses/iman_stdlib.h>
#include<fclasses/iman_string.h>
#include<fclasses/iman_time.h>
#include<fclasses/tc_stdlib.h>
#include<fclasses/tc_string.h>
#include<fclasses/tc_time.h>
#include<form/form.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>
#include<ict/ict_userservice.h>
#include<itk/mem.h>
#include<lov/lov.h>
#include<lov/lov_msg.h>
#include<pie/pie.h>
#include<pom/pom/pom.h>
#include<pom/pom/pom_errors.h>
#include<property/prop.h>
#include<ps/ps.h>
#include<ps/ps_errors.h>
#include<publication/ods_itk.h>
#include<res/res_itk.h>
#include<res/reservation.h>
#include<sa/imanfile.h>
#include<sa/sa.h>
#include<sa/tcfile.h>
#include<sa/user.h>
#include<ss/ss_const.h>
#include<ss/ss_errors.h>
#include<stdarg.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include<tc/aliaslist.h>
#include<tc/distributionlist.h>
#include<tc/emh.h>
#include<tc/emh_errors.h>
#include<tc/envelope.h>
#include<tc/folder.h>
#include<tc/iman.h>
#include<tc/iman_arguments.h>
#include<tc/iman_util.h>
#include<tc/preferences.h>
#include<tc/tc.h>
#include<tc/wsouif_errors.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<tccore/custom.h>
#include<tccore/grm.h>
#include<tccore/grm_msg.h>
#include<tccore/iman_msg.h>
#include<tccore/imantype.h>
#include<tccore/item.h>
#include<tccore/item_errors.h>
#include<tccore/item_msg.h>
#include<tccore/method.h>
#include<tccore/tcaehelper.h>
#include<tccore/tctype.h>
#include<tccore/workspaceobject.h>
#include<tcinit/tcinit.h>
#include<textsrv/textserver.h>
#include<time.h>
#include<unidefs.h>
#include<user_exits/aiws_ext.h>
#include<user_exits/epm_toolkit_utils.h>
#include<user_exits/user_exits.h>
#define ITK_err 910001
#define ITK_errStore (EMH_USER_error_base + 3)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

#define HANDLE_ERROR_S1(E,S) \
{ EMH_store_initial_error_s1(EMH_severity_error,(E),(S)); return(E); }

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

struct BomChldStrut_Col
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut_Col;

/*tm_getCompCode(tag_t line,char *CompCodeStr)
{
	
		ITK_CALL(BOM_line_ask_child_lines (line, &n, &children));
		for (k = 0; k < n; k++)
		{
			ITK_CALL(ITEM_ask_type2 (children[k], &item_type));
			printf("\n children item_typeS [%s] \n",item_type);  fflush(stdout);
			tm_getCompCode (children[k],line,depth,fdf,fus,req_item,FilePath,DepthInput);
		}
}*/

void Multi_Get_Part_BOM_Lvl_Col(tag_t inputPart,int reqLevel,int level,tag_t revRule,struct BomChldStrut_Col BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n_Cnt=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t   t_itemTag;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;

	char*			partColInd					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	char* PrtCmpCode 	= NULL;
	char* sItem_id 		= NULL;
	char* sItem_id_rev 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(AOM_ask_value_string(inputPart,"t5_ColourInd",&partColInd));
	printf("\n partColInd===>%s\n",partColInd);fflush(stdout);

	if( tc_strcmp(partColInd,"Y"))
	{
		goto CLEANUP;
	}



	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	//ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));

		BOM_set_window_top_line(window, null_tag,inputPart ,null_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 3.42 Backend
		ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n_Cnt);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n_Cnt; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);

			ITKCALL(AOM_ask_value_string(children[k], "bl_item_item_id", &sItem_id));
			ITKCALL(AOM_ask_value_string(children[k], "bl_rev_item_revision_id", &sItem_id_rev));
			printf("\n\n TCUA 14.3 bl_rev_item_revision_id 1---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);
			ITKCALL(ITEM_find_item(sItem_id,&t_itemTag));
			ITKCALL(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));

			
			if(t_ChildItemRev!=NULLTAG)
			{

				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				

				Multi_Get_Part_BOM_Lvl_Col(t_ChildItemRev,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}

int GetSuffixFromClassification(char* CCA_ParentCompCode,char** ChilDCompCodeArray,int ChilDCompCodeArrayCnt, char** suffix )
{
	int j=0,k=0,p=0,i=0;
	int  	chkflag =0,Flag=0;
	int status;
	int  	theCount =0;
	int * 	theIds;
	char ** 	theNames;
	char ** 	theShortNames;
	char ** 	theAnnotations;
	int * 	theArraySize;
	int * 	theFormat;
	char ** 	theUnit;
	char ** 	theMinValues;
	char ** 	theMaxValues;
	char ** 	theDefaultValues;
	char ** 	theDescriptions;
	int * 	theOptions1 ;

	int *InputIdsArr1;
	char **InputValuesArr1=NULL;
	char **StrConcatenatedMaster=NULL;
	char * 	StrConcatenatedinput=NULL;

	tag_t   	view;
	tag_t   	theClassTag	; 
	int   	nInstances99=0;
	tag_t *  	instances99;
	char * 	atrValue=NULL;
	char * 	atrValueReturn=NULL;
	printf("\n TOTAL ARRAY COUNT IS %d \n PARENT COMP CODE IS %s",ChilDCompCodeArrayCnt,CCA_ParentCompCode);fflush(stdout);
	char* Class_ID_Suffix=NULL;
	//char* Class_ID_Suffix="SAM0101";
	*suffix = malloc(10*sizeof(char));

	tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
	int	n_entries = 2;
	int n_found = 0;

	char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_values[2] = {"SUFSEL", "CLSID"};

	 if(QRY_find22("ControlObjQry", &TagQryContObj));

	 if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	 printf("\n Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

	 if(n_found==1)
	 {
		 if( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&Class_ID_Suffix));
		 printf("\n Information 10 Value == [%s] and", Class_ID_Suffix);fflush(stdout);
	 }
	 else
	{
		  printf("\n Control object not found \n");fflush(stdout);
	}

	for(j=0;j<ChilDCompCodeArrayCnt;j++)                        
	{                                              
		printf("\n CHILD COMP CODE IS %s",ChilDCompCodeArray[j]);fflush(stdout);

	}      

	ITK_CALL(ICS_class_describe_attributes(Class_ID_Suffix,
	&theCount,
	&theIds,
	&theNames,
	&theShortNames,
	&theAnnotations,
	&theArraySize,
	&theFormat,
	&theUnit,
	&theMinValues,
	&theMaxValues,
	&theDefaultValues,
	&theDescriptions,
	&theOptions1))

	InputValuesArr1=(char**) malloc(theCount * sizeof(char*) );	  ////// INPUT
	StrConcatenatedinput= malloc(1500 * sizeof(char) );
	for(i=0;i<theCount;i++)
	{
		InputValuesArr1[i]= malloc(99 * sizeof(char) );;
	}
		for(i=0;i<theCount;i++)
	{
		if (i==0)
		{
			strcpy(InputValuesArr1[i],CCA_ParentCompCode);////// INPUT
		}
		else
		{
			strcpy(InputValuesArr1[i],"");
		}
	}

	ITK_CALL(  ICS_view_ask_tag ( "defaultView",&view ) );
	ITK_CALL(ICS_class_ask_tag 	(Class_ID_Suffix,&theClassTag));

	for(j=0;j<theCount;j++)
		{
			printf("\n ID : %d",theIds[j]);fflush(stdout);
		}
	ITK_CALL(ICS_ico_search (theClassTag,
		view,
		theCount,
		theIds,
		InputValuesArr1,
		&nInstances99,
		&instances99	 
	));

	printf("\n after  nInstances99 by ICS_search_instances .......%d\n",nInstances99);

	if(nInstances99>0)
	{
		StrConcatenatedMaster=(char**) malloc(nInstances99 * sizeof(char*) );
	}
	
	for(k=0;k<nInstances99;k++)
	{ 
		chkflag=0;
		StrConcatenatedMaster[k]= malloc(1500 * sizeof(char) );		
		strcpy(StrConcatenatedMaster[k],"");
		strcpy(StrConcatenatedinput,"");
		for (j=0;j<theCount ;j++ )
		{
			atrValue=NULL;
			ICS_ask_attribute_value	((instances99[k]),theNames[j],&atrValue );
			printf("\ncount %d  \t AttrName :%s \t atrValue : %s\n",j,theNames[j],atrValue);fflush(stdout);
					
			if (j>1)
			{
				strcat(StrConcatenatedMaster[k],atrValue);
			}		
		}

		printf("\nStrConcatenatedMaster :%s\n",StrConcatenatedMaster[k]);fflush(stdout);

		for(p=0;p<ChilDCompCodeArrayCnt;p++)
		{
			strcat(StrConcatenatedinput,ChilDCompCodeArray[p]);
			if(tc_strstr(StrConcatenatedMaster[k],ChilDCompCodeArray[p])==NULL)
			{
				chkflag=1;
				printf("\n Child Comp Code %s Match not found in StrConcatenatedMaster :%s\n",ChilDCompCodeArray[p],StrConcatenatedMaster[k]);fflush(stdout);
				break;
			}					
			
		}
		
		printf("\n String concat length %d == %d\n",tc_strlen(StrConcatenatedMaster[k]),tc_strlen(StrConcatenatedinput));fflush(stdout);
		if (chkflag==0 && (tc_strlen(StrConcatenatedMaster[k])==tc_strlen(StrConcatenatedinput)))
		{
			atrValueReturn=NULL;
			ICS_ask_attribute_value	((instances99[k]),theNames[1],&atrValueReturn );
			printf("\nFinal Output colour code is :%s\n",atrValueReturn);   //// OUTPUT
			if (atrValueReturn)
			{
				tc_strcpy(*suffix,atrValueReturn);
				Flag=1;
			}
			break;
		}

	}
	if (Flag==0)
	{
		tc_strcpy(*suffix,"##");
	}
}

int set_Suffix_Scheme(char* SchmName, char* SchmRev,char* SchmSeq,char* SchmCompCode,char* Schmsuffix)
{
	int status;
	tag_t queryTag=NULLTAG;
	tag_t queryTagClMaster=NULLTAG;
	tag_t ClrData=NULLTAG;
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values_CM = (char **) MEM_alloc(50 * sizeof(char *));


	if(QRY_find2("ClrSchm_Data", &queryTag));
	if (queryTag)
	{
		printf("Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
	}
	else
	{
		printf("Not Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
		return status;

	}

	printf ( "\n Query input %s %s %s %s %s\n",SchmName,SchmRev,SchmSeq,SchmCompCode,Schmsuffix);fflush(stdout);
	qry_values[0] = SchmSeq ;
	qry_values[1] = SchmName;
	qry_values[2] = SchmRev;
	qry_values[3] = SchmCompCode;
	int n_entries = 4;
	int resultCount = 0;
	tag_t *Clr_Schm_Data=NULL;
	char *qry_entries[4] = {"Sequence Id","ID","Revision","Comp Code"};
	char* ColorID=NULL;
	char* Col_Schm_ClSrl=NULL;
	Col_Schm_ClSrl= (char *) MEM_alloc ( 100);
	

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &Clr_Schm_Data));
	printf ( "\n Comp code found in scheme is %d \n",resultCount);fflush(stdout);
	if (resultCount == 0)
	{
		printf ("\n No items matched with ClrSchm_Data query\n");fflush(stdout);
		
	}
	else if (resultCount > 0)
	{
		printf ( "\n More than one items matched with ClrSchm_Data query \n");fflush(stdout);

		if(QRY_find2("Colour_Master_Suffix", &queryTagClMaster));
		if (queryTagClMaster)
		{
			printf("Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
		}
		else
		{
			printf("Not Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
			return status;

		}
		qry_values_CM[0] = Schmsuffix ;
		int n_entries_CM = 1;
		int resultCount_CM = 0;
		tag_t *Clr_Master_CM=NULL;
		char *qry_entries_CM[1] = {"Colour Serial"};

		if(QRY_execute(queryTagClMaster, n_entries_CM, qry_entries_CM, qry_values_CM, &resultCount_CM, &Clr_Master_CM));
		printf ( "\n Comp master found in PLM is %d \n",resultCount_CM);fflush(stdout);

		



		if (resultCount_CM >0)
		{
			ITK_CALL(AOM_ask_value_string(Clr_Master_CM[0],"t5_ColourId",&ColorID));
			printf ( "\n color ID  is %s \n",ColorID);fflush(stdout);
			
			tc_strcpy(Col_Schm_ClSrl,Schmsuffix);
			tc_strcat(Col_Schm_ClSrl,";");
			tc_strcat(Col_Schm_ClSrl,ColorID);
			printf ( "\n Col_Schm_ClSrl is %s \n",Col_Schm_ClSrl);fflush(stdout);
			ClrData=Clr_Schm_Data[0];
			ITK_CALL(AOM_refresh(ClrData,TRUE));
			ITK_CALL(AOM_set_value_string(ClrData,"t5_ClSrl",Col_Schm_ClSrl));
			
			ITK_CALL(AOM_save_without_extensions(ClrData));
			ITK_CALL(AOM_refresh(ClrData,FALSE));
		}
	}

}

int SuffixSelectionFun(void* retValue)
{    		
		char	*ClsChmName	= NULL;
		char	*Revision_id	= NULL;
		char	*Sequence_id	= NULL;
		char	*ItemName	= NULL;
		char	*c_Qty	= NULL;
		char	*child_CmpCode	= NULL;
		int		status;	
		int		result	= 0;
		int		n_SVR	= 0,number_found=0,vcount=0,ModuleCnt=0,n_ArchNod=0,n_module=0,i,k,countDep=0,cnt=0,countDep1=0,l=0,iChildItemTag,cnt_M=0;
		tag_t   clSchm_tag =NULLTAG;
		tag_t   clSchm_Rev_tag =NULLTAG;
		tag_t   SVR_tag =NULLTAG;
		tag_t   PlatformTagRev =NULLTAG;
		tag_t   *SVR_obj_tags =NULL;
		tag_t   *list_of_WSO_tags =NULL;
		tag_t reln_type_tag				= NULLTAG;
		tag_t top_line				= NULLTAG;
		tag_t bom_window				=NULLTAG ;
		tag_t *bomvariantlist				= NULL;
		tag_t ModuleArray[300];
		tag_t ModuleArray_Out[300];
		tag_t *child_ArchNod				= NULL;
		tag_t *child_Module				= NULL;
		tag_t *Primary_objects2				= NULL;
		tag_t *Primary_objects1				= NULL;
		tag_t PrdConfigTag				= NULLTAG;
		tag_t primaryTag				= NULLTAG;
		tag_t			rule					=NULLTAG;
		tag_t			objTypeTagDi					=NULLTAG;
		tag_t			PlatformTag					=NULLTAG;
		tag_t			t_ChildItemRev					=NULLTAG;
		tag_t			t_itemTag					=NULLTAG;
		char   *type_name3=NULL;
		WSO_search_criteria_t  	criteria;
		logical modB=FALSE;
		char* mod_name=NULL;
		char* mod_name_ColInd=NULL;
		char* ClSrl_suffix=NULL;
		char* Suffix_compcode=NULL;
		char* ColorSerial=NULL;
		char* AppSvrName=NULL;
		char* sItem_id=NULL;
		char* sItem_id_rev=NULL;
		int        StructChldCnt   =    0;
		int        StructChldCnt_Child   =    0;
		struct			BomChldStrut_Col	ChldStrutBdySh[5000];
		struct			BomChldStrut_Col	ChldStrutBdySh_Child[5000];
		tag_t	objChild			= NULLTAG;
		tag_t	objChild_bvr			= NULLTAG;
		tag_t	queryTag			= NULLTAG;
		tag_t	queryTag_svr			= NULLTAG;

		int n_entries_svr = 1;
		int resultCount_svr = 0;
		char *qry_entries_svr[] = {"Name"};
		char **qry_values_svr = (char **) MEM_alloc(10 * sizeof(char *));
		int child_lvl=0;
		
		//char** SuffixCompCodeArray;
		char **SuffixCompCodeArray = (char **) MEM_alloc(500 * sizeof(char *));
		char *qry_entries[4] = {"Sequence Id","ID","Revision","Comp Code"};
		char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

		Suffix_compcode= (char *) MEM_alloc (100);
		
		ColorSerial= (char *) MEM_alloc ( 100);
		tc_strcpy(ColorSerial,"");
		
		
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login( ));
		ITK_CALL(ITK_set_journalling( TRUE ));
		printf("\n ITK_auto_login success---->\n");fflush(stdout);
		
		USERARG_get_string_argument(&ClsChmName);
		USERARG_get_string_argument(&Revision_id);
		USERARG_get_string_argument(&Sequence_id);
				
		printf("\n ClsChmName-------->  : %s",ClsChmName);fflush(stdout);
		printf("\n Revision_id-------->  : %s",Revision_id);fflush(stdout);
		printf("\n Sequence_id-------->  : %s",Sequence_id);fflush(stdout);

		ITK_CALL(ITEM_find_item( ClsChmName, &clSchm_tag ));

		if (clSchm_tag != NULLTAG)
		{
			printf("\n Color scheme master found");fflush(stdout);
			ITK_CALL(ITEM_find_revision(clSchm_tag,Revision_id,&clSchm_Rev_tag));
			if (clSchm_Rev_tag != NULLTAG)
			{
				printf("\n Color scheme revision found");fflush(stdout);

				ITK_CALL(AOM_ask_value_string(clSchm_Rev_tag,"t5_VehNO",&AppSvrName));	
				printf("\n APPLICABLE svr  found %s",AppSvrName);fflush(stdout);
				qry_values_svr[0]= AppSvrName;

				if(QRY_find2("VariantRule", &queryTag_svr));
				printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);
				if (queryTag_svr)
				{
					printf("queryTag_svr Found Query \n");fflush(stdout);
				}
				else
				{
					printf("queryTag_svr Not Found Query");fflush(stdout);
				}

				if(QRY_execute(queryTag_svr, n_entries_svr, qry_entries_svr, qry_values_svr, &resultCount_svr, &SVR_obj_tags));
				printf(" \n resultCount_svr : %d\n", resultCount_svr); fflush(stdout);

				//ITK_CALL(GRM_find_relation_type("T5_Applicable_SVR",&reln_type_tag));
				//if (reln_type_tag	!=	NULLTAG)
				//{
					//ITK_CALL(GRM_list_secondary_objects_only( clSchm_Rev_tag, reln_type_tag, &n_SVR, &SVR_obj_tags ));
				if (resultCount_svr > 0)
				{
					SVR_tag=SVR_obj_tags[0];


					ITK_CALL(GRM_list_primary_objects_only(SVR_tag,NULLTAG,&countDep,&Primary_objects1));
					printf(" \n count found %d \n",countDep);fflush(stdout);
					for (cnt=0;cnt < countDep;cnt++ )
					{
						PrdConfigTag=Primary_objects1[cnt];							
						ITK_CALL(TCTYPE_ask_object_type(PrdConfigTag,&objTypeTagDi));
						ITK_CALL(TCTYPE_ask_name2(objTypeTagDi,&type_name3));	  
						printf( "\n type_name3 :%s ..\n",type_name3);
						if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
						{
							ITK_CALL(GRM_list_primary_objects_only(PrdConfigTag,NULLTAG,&countDep1,&Primary_objects2));
							for (l=0;l < countDep1;l++ )
							{
								primaryTag=Primary_objects2[l];
								ITK_CALL(TCTYPE_ask_object_type(primaryTag,&objTypeTagDi));
								ITK_CALL(TCTYPE_ask_name2(objTypeTagDi,&type_name3));	  
								printf( "\n type_name3 :%s ..\n",type_name3);
								if (tc_strcmp(type_name3,"T5_Platform")==0)
								{
									//ITK_CALL ( ITEM_ask_latest_rev( primaryTag, &PlatformRevTag ));
									PlatformTag=Primary_objects2[l];
									ITK_CALL ( ITEM_ask_latest_rev( PlatformTag, &PlatformTagRev ));
									break;
									
								}
							}
							if (PlatformTag)
							{
								break;
							}

						}
					}

					//WSOM_clear_search_criteria(&criteria);
					//tc_strcpy(criteria.name,"X4");
					//tc_strcpy(criteria.class_name,"T5_PlatformRevision");
					//ITK_CALL(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
					//printf("\n\n\t\t Platform Count1 -->: %d\n",number_found);fflush(stdout);

					printf( "\n Going to expand Arch1_1\n");fflush(stdout);
					if (PlatformTagRev && SVR_tag)
					{
						
						ITK_CALL(BOM_create_window(&bom_window));
						
						ITK_CALL(CFM_find( "ERC release and above", &rule));
						//ITK_CALL(CFM_find( "Latest Working", &rule));
						
						ITK_CALL(BOM_set_window_config_rule( bom_window, rule));
						
						ITK_CALL(BOM_set_window_pack_all(bom_window, TRUE)); 
						
						ITK_CALL(BOM_set_window_top_line( bom_window, NULLTAG, PlatformTagRev, NULLTAG, &top_line));
						
						ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,&SVR_tag));
						
						ITK_CALL(BOM_window_hide_unconfigured(bom_window));	
						
						ITK_CALL(BOM_window_hide_variants(bom_window)); 
						
						
						ITK_CALL(BOM_window_ask_variant_rules(bom_window,&vcount,&bomvariantlist)); 
						if(bomvariantlist != NULLTAG)
						{													
												    printf( "\n SVR is applied:..\n");	fflush(stdout);																	 
													printf("\nSVR count -->:%d\n",vcount);	fflush(stdout);
						}
						else
						{
													printf( "\n NO SVR applied in BOM window ..\n");fflush(stdout);
						}		
									
//						ITK_CALL(BOM_window_ask_is_modified(bom_window,&modB));
//						if(modB)
//						{
//													printf( "\n modified bom window:..\n");
//						}
//						else
//						{
//													printf( "\n not modfiifed ..\n");
//						}
						//tm_getCompCode(top_line1,&Comp_Code_Str);
						ModuleCnt=0;
						printf( "\n Going to expand Arch\n");fflush(stdout);
						ITK_CALL(BOM_line_ask_all_child_lines (top_line, &n_ArchNod, &child_ArchNod));
						printf( "\n Going to expand Arrch Node %d\n",n_ArchNod);fflush(stdout);				
						for (k = 0; k < n_ArchNod; k++)
						{
							ITK_CALL(AOM_ask_value_string(child_ArchNod[k],"bl_line_name",&mod_name));	
							printf("\n ARch node :%s\n",mod_name);	fflush(stdout);
							ITK_CALL(BOM_line_ask_child_lines (child_ArchNod[k], &n_module, &child_Module));
							printf( "\n Going to expand module\n");fflush(stdout);
							for (i = 0; i < n_module; i++)
							{
								ITK_CALL(AOM_ask_value_string(child_Module[i],"bl_T5_ClrPartRevision_t5_ColourInd",&mod_name_ColInd));	
								printf("\n Color Indicator is  :%s\n",mod_name_ColInd);	fflush(stdout);
								if (tc_strcmp(mod_name_ColInd,"Y")==0)
								{
									ModuleArray[ModuleCnt]=child_Module[i];
									ModuleCnt++;
								}
							}
						
						}
						//ITK_CALL(CFM_find( "Latest Working", &rule));
						ITK_CALL(CFM_find( "ERC release and above", &rule));
						printf( "\n module count %d \n",ModuleCnt);fflush(stdout);
						for (cnt_M = 0; cnt_M < ModuleCnt; cnt_M++)
						{
							ITK_CALL(AOM_ask_value_string(ModuleArray[cnt_M],"bl_line_name",&mod_name));	
							printf("\n mod_name:%s\n",mod_name);	fflush(stdout);


							//BOM_line_look_up_attribute ( "bl_line_object", &iChildItemTag);
							//BOM_line_ask_attribute_tag(ModuleArray[cnt_M], iChildItemTag, &t_ChildItemRev);
                           	  ITKCALL(AOM_ask_value_string(ModuleArray[cnt_M],"bl_item_item_id", &sItem_id));
							 ITKCALL(AOM_ask_value_string(ModuleArray[cnt_M], "bl_rev_item_revision_id", &sItem_id_rev));
							 printf("\n\n TCUA 14.3 bl_rev_item_revision_id---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);
							 ITKCALL(ITEM_find_item(sItem_id,&t_itemTag));
							 ITKCALL(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
							ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&mod_name));	
							printf("\n TCUA 14.3 Item Id :%s\n",mod_name);	fflush(stdout);
							int level 				= 0;
							//printf("\n Before expansion     =====>>>>>>>>1 \n");	fflush(stdout);
							StructChldCnt   =    0;
							
							//printf("\n Before expansion     =====>>>>>>>>2 \n");	fflush(stdout);
							ChldStrutBdySh[StructChldCnt].child_objs = t_ChildItemRev;
							//BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
							ChldStrutBdySh[StructChldCnt].child_objs_lvl=level;
							Multi_Get_Part_BOM_Lvl_Col(t_ChildItemRev,99,level,rule,ChldStrutBdySh,&StructChldCnt);

							//printf("\n Total Child of  %s ==================>%d\n",mod_name,StructChldCnt);fflush(stdout);
							int j;
							for (j=StructChldCnt;j >= 0;j-- )
							{
								objChild		= NULLTAG;
								objChild_bvr	= NULLTAG;
								c_Qty			= NULL;
								child_lvl       =0;
								level 				= 0;

								printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

								objChild=ChldStrutBdySh[j].child_objs;
								objChild_bvr=ChldStrutBdySh[j].child_objs_bvr;
								child_lvl=ChldStrutBdySh[j].child_objs_lvl;
								
								AOM_ask_value_string(objChild,"item_id",&ItemName);
								AOM_ask_value_string(objChild,"t5_PrtCatCode",&child_CmpCode);
								printf("\nItemName==>%s  child_CmpCode==>%s\n",ItemName,child_CmpCode);fflush(stdout);

								//printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);
								//printf("\n child_CmpCode==>%s\n",child_CmpCode);fflush(stdout);
								if (tc_strstr(child_CmpCode,"CCA_"))
								{
									printf("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>ItemName==>%s  child_CmpCode==>%s <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n",ItemName,child_CmpCode);fflush(stdout);
									StructChldCnt_Child=0;
									Multi_Get_Part_BOM_Lvl_Col(objChild,1,level,rule,ChldStrutBdySh_Child,&StructChldCnt_Child);
									int suffixCnt=0;
									int CCA_n=0;
									char* CCA_child_CmpCode=NULL;
									char* CCA_child_ItemName=NULL;
									tag_t CCA_objChild=NULLTAG;
									printf("\n CCA _CHILD _COUNT %d\n",StructChldCnt_Child);fflush(stdout);

									if(QRY_find2("ClrSchm_Data", &queryTag));
									if (queryTag)
									{
										printf("Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
									}
									else
									{
										printf("Not Found Query 'ClrSchm_Data' \n\t"); fflush(stdout);
										return status;
									
									}

									printf ( "\n Query input %s %s %s %s \n",ClsChmName,Revision_id,Sequence_id,CCA_child_CmpCode);fflush(stdout);
									qry_values[0] = Sequence_id ;
									qry_values[1] = ClsChmName;
									qry_values[2] = Revision_id;
									qry_values[3] = child_CmpCode;
									int n_entries = 4;
									int resultCount_CCA = 0;
									tag_t *Clr_Schm_Data_CCA=NULL;
				
									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount_CCA, &Clr_Schm_Data_CCA));
									printf ( "\n Comp code found in scheme is %d \n",resultCount_CCA);fflush(stdout);
									if (resultCount_CCA == 0)
									{
										printf ("\n No items matched with ClrSchm_Data query for <%s>\n",child_CmpCode);fflush(stdout);
										
									}
									else if (resultCount_CCA > 0)
									{
										printf ( "\n items matched with ClrSchm_Data query \n");fflush(stdout);
										if (ColorSerial)ColorSerial="";

										AOM_ask_value_string(Clr_Schm_Data_CCA[0],"t5_ClSrl",&ColorSerial);
										printf ( "\n Color serial is %s \n",ColorSerial);fflush(stdout);
										if (!tc_strstr(ColorSerial,"##"))
										{
											printf ( "\n Color scheme value already updated for <%s> . continuing to next CCA comp code\n",child_CmpCode);fflush(stdout);
											continue;
										}
									}

									for (CCA_n=1;CCA_n <= StructChldCnt_Child;CCA_n++ )
									{
										CCA_objChild=ChldStrutBdySh_Child[CCA_n].child_objs;
										AOM_ask_value_string(CCA_objChild,"t5_PrtCatCode",&CCA_child_CmpCode);
										AOM_ask_value_string(CCA_objChild,"item_id",&CCA_child_ItemName);
										
										printf("\n CCA child_CmpCode of %s==============================>%s\n",CCA_child_ItemName,CCA_child_CmpCode);fflush(stdout);


										printf ( "\n Query input %s %s %s %s \n",ClsChmName,Revision_id,Sequence_id,CCA_child_CmpCode);fflush(stdout);
										qry_values[0] = Sequence_id ;
										qry_values[1] = ClsChmName;
										qry_values[2] = Revision_id;
										qry_values[3] = CCA_child_CmpCode;
										int n_entries = 4;
										int resultCount = 0;
										tag_t *Clr_Schm_Data=NULL;
										

										if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &Clr_Schm_Data));
										printf ( "\n Comp code found in scheme is %d \n",resultCount);fflush(stdout);
										if (resultCount == 0)
										{
											printf ("\n No items matched with ClrSchm_Data query for <%s>\n",CCA_child_CmpCode);fflush(stdout);
											
										}
										else if (resultCount > 0)
										{
											printf ( "\n items matched with ClrSchm_Data query \n");fflush(stdout);
											if (ColorSerial)ColorSerial="";

											AOM_ask_value_string(Clr_Schm_Data[0],"t5_ClSrl",&ColorSerial);
											printf ( "\n Color serial is %s \n",ColorSerial);fflush(stdout);
											if (tc_strstr(ColorSerial,"##"))
											{
												printf ( "\n Color scheme value not updated for <%s> . Kindly please check\n",CCA_child_CmpCode);fflush(stdout);
											}
											else
											{
												ClSrl_suffix = tc_strtok(ColorSerial,";");
												printf ( "\n Color serial is -->> %s \n",ClSrl_suffix);fflush(stdout);
												if (Suffix_compcode)tc_strcpy(Suffix_compcode,"");
												tc_strcat(Suffix_compcode,CCA_child_CmpCode);
												tc_strcat(Suffix_compcode,"/");
												tc_strcat(Suffix_compcode,ClSrl_suffix);
												
												printf ( "\n ]]]]]]]]]]]]]]Suffix comp code is %s  %d [[[[[[[[[[[[[[\n",Suffix_compcode,suffixCnt);fflush(stdout);
												//SuffixCompCodeArray[suffixCnt]=Suffix_compcode;
												SuffixCompCodeArray[suffixCnt]=(char *) MEM_alloc(tc_strlen(Suffix_compcode)* sizeof(char ));
												tc_strcpy(SuffixCompCodeArray[suffixCnt],Suffix_compcode);
												suffixCnt++;
											}


											
										}

									}

									printf ( "\n Suffix comp code count is  %d\n",suffixCnt);fflush(stdout);

									//function to be called for
									char* Suffix=NULL;
									GetSuffixFromClassification(child_CmpCode,SuffixCompCodeArray,suffixCnt,&Suffix);
									printf ( "\n Suffix found is ================>>> %s\n",Suffix);fflush(stdout);

									printf ( "\n Function  input to set_Suffix_Scheme %s %s %s %s %s\n",ClsChmName,Revision_id,Sequence_id,child_CmpCode,Suffix);fflush(stdout);
									set_Suffix_Scheme(ClsChmName,Revision_id,Sequence_id,child_CmpCode,Suffix);

								}

								//AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
								printf("\n SKIPPING\n");fflush(stdout);

							}
					}

						


						


					}
					printf("\n END IF PlatformTag\n");	fflush(stdout);

				}
					
				//}
			}
		}
		else
		{
			printf("\n Color scheme master not found");fflush(stdout);
		}

		
		
		
		
	return result;
}

extern DLLAPI int Suffix_register_userservices(METHOD_message_t *msg, va_list args)
{   
 	int nargs=3;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	inputArgTypes[2]=USERARG_STRING_TYPE;
	retValueType=USERARG_TAG_TYPE;
	
	printf("\n User Service Call SuffixSelection....");fflush(stdout);
	Write_To_Log("\n User Service Call SuffixSelection....\n");
    
	USERSERVICE_register_method("SuffixSelectionUsrSer",(USER_function_t) SuffixSelectionFun, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}

extern DLLAPI int tm_SuffixSelection_register_callbacks()
{
   CUSTOM_register_exit("tm_SuffixSelection","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t) Suffix_register_userservices);   
   Write_To_Log("\n Registering Common tm_SuffixSelection..........\n");   
   return ITK_ok;
}
