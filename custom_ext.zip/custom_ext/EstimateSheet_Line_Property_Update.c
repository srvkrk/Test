/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   EstimateSheet_Line_Property_Update.c
*  Author		 :   Nilesh
*  Module		 :   Code to update property in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <time.h>
#include <tccore/item.h>

	
int UpdateEstimateSheetLineProperty(void *return_data){
    printf("\n Inside UpdateEstimateSheetLineProperty");fflush(stdout);
	
	int ifail = ITK_ok;
	
	tag_t SelectedEstimateSheet    			= NULLTAG;
    char*   productionLineNumber          	= NULL;
    char*   lineDescription          		= NULL;
    char*   prodSloc         				= NULL;
    char*   issueSloc        				= NULL;
    char*   recvSloc          				= NULL;

    ifail   =   USERARG_get_tag_argument(&SelectedEstimateSheet);
    ifail   =   USERARG_get_string_argument(&productionLineNumber);
    ifail   =   USERARG_get_string_argument(&lineDescription);
    ifail   =   USERARG_get_string_argument(&prodSloc);
    ifail   =   USERARG_get_string_argument(&issueSloc);
    ifail   =   USERARG_get_string_argument(&recvSloc);
    char*   EstimateSheetNumber = NULL;
    ITKCALL(AOM_UIF_ask_value (SelectedEstimateSheet, "current_id", &EstimateSheetNumber));


    printf("\n EstimateSheetNumber : %s",EstimateSheetNumber);fflush(stdout);
    printf("\n productionLineNumber : %s",productionLineNumber);fflush(stdout);
    printf("\n lineDescription : %s",lineDescription);fflush(stdout);
    printf("\n prodSloc : %s",prodSloc);fflush(stdout);
    printf("\n issueSloc : %s",issueSloc);fflush(stdout);
    printf("\n recvSloc : %s",recvSloc);fflush(stdout);
    printf("\n recvSloc 1: %s",recvSloc);fflush(stdout);


	if(AOM_lock(SelectedEstimateSheet) != ITK_ok ) return ifail;

	ITKCALL(AOM_set_value_string(SelectedEstimateSheet, "t5_ProdLineNumber",productionLineNumber));
	ITKCALL(AOM_set_value_string(SelectedEstimateSheet, "t5_LineWiseDesc",lineDescription));
	ITKCALL(AOM_set_value_string(SelectedEstimateSheet, "t5_ProdStorageLoc",prodSloc));
	ITKCALL(AOM_set_value_string(SelectedEstimateSheet, "t5_IssueStorageLoc",issueSloc));
	ITKCALL(AOM_set_value_string(SelectedEstimateSheet, "t5_ReceivingLoc",recvSloc));

	ITKCALL(AOM_save_without_extensions(SelectedEstimateSheet));
	ITKCALL(AOM_unlock(SelectedEstimateSheet));
	ITKCALL(AOM_refresh(SelectedEstimateSheet, FALSE));

    if(ifail != 0 ){
        printf("ifail : %d", ifail);fflush(stdout);
    }
    else{
        printf("ifail %d",ifail);fflush(stdout);
    }
    return ITK_ok;
}

extern int EstimateSheet_Update_Property_List() {
    int ifail = ITK_ok;
    int retValueType;

    int UpdateArgs = 6;
    int UpdateArgsValues[6] = {0};

    retValueType = USERARG_STRING_TYPE;

    UpdateArgsValues[0] = USERARG_TAG_TYPE;
    UpdateArgsValues[1] = USERARG_STRING_TYPE;
    UpdateArgsValues[2] = USERARG_STRING_TYPE;
    UpdateArgsValues[3] = USERARG_STRING_TYPE;
    UpdateArgsValues[4] = USERARG_STRING_TYPE;
    UpdateArgsValues[5] = USERARG_STRING_TYPE;
    
    printf("\n Before Registering Method New Export Request");fflush(stdout);
    ifail = USERSERVICE_register_method("UpdateEstimateSheetLineProperty", (USER_function_t)UpdateEstimateSheetLineProperty, UpdateArgs, UpdateArgsValues, retValueType);
    printf("\n After Registering Method New Export Request");fflush(stdout);

    return ifail;
}

extern int EstSheetLineUpdateUserService(int *decision, va_list args) {
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    printf("Before Registering Method EstimateSheet_Update_Property_List");fflush(stdout);
    ITKCALL(EstimateSheet_Update_Property_List());
    printf("After Registering Method EstimateSheet_Update_Property_List");fflush(stdout);

    return ifail;
}

extern DLLAPI int EstimateSheet_Line_Property_Update_register_callbacks() {
    int ifail = ITK_ok;
    printf("\n Before Registering Method EstimateSheet_Update_Property_List");fflush(stdout);
    ifail = CUSTOM_register_exit("EstimateSheet_Line_Property_Update", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)EstSheetLineUpdateUserService);
    printf("\n After Registering Method EstimateSheet_Update_Property_List");fflush(stdout);
    return (ITK_ok);
}