#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h> 
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
//#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
//#include <bom/bom.h>
#include <tccore/aom_prop.h>
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)
#include <tc/folder.h>


#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


//ITK code start for remove release status of passed object
int remove_release_status(tag_t wso_tag)
{
    int ifail = ITK_ok;
	int status;
    int rstat; 
    int n_statuses = 0;
	tag_t*    statuses=NULLTAG;

		ITK_CALL(WSOM_ask_release_status_list(wso_tag,&n_statuses,&statuses));
		printf("\n No of rel_statuses :%d is\n",n_statuses);fflush(stdout);

        if (n_statuses > 0)
        {
          //ITK_CALL(ITK_set_bypass(true));   
          tag_t attr = NULLTAG;
          ITKCALL(POM_attr_id_of_attr( "release_status_list", "WorkspaceObject", &attr));
            
         for (int ii = 0; ii < n_statuses; ii++)
          {
                char* name=NULL;
                ITK_CALL(AOM_ask_value_string(statuses[ii], "name", &name));
				printf("\n Rel_status name = %s \n",name);fflush(stdout);

				//This is for kept privious Abort status
                if (strcmp(name, "T5_aborted") != 0)
                {
                    printf("\n Rel_status name = %s \n",name);fflush(stdout);
                    tag_t status_to_delete = statuses[ii];
                    ITK_CALL(POM_refresh_instances_any_class(1, &wso_tag,POM_modify_lock));
                    ITK_CALL(POM_remove_from_attr(1, &wso_tag, attr, ii, 1));
            
                    logical unload = true; 
                    ITK_CALL(POM_save_instances(1, &wso_tag,unload));                        
                    
                    ITK_CALL(POM_refresh_instances_any_class(1, &status_to_delete,POM_delete_lock));
                    ITK_CALL(POM_delete_instances(1,&status_to_delete));      
                }
            }       
           
        }
    
    
    return ifail;
}

//
int ServiceForEPAAbort(void *return_data)
{	
	//int 			status;
	int				ifail 				=	ITK_ok;
	char 			*selectedTask		= 	NULL;
	char 			*userName			= 	NULL;
	//getting abort reason from RAC
	char            *abortReason        =NULL;
	char            *taskcomment       =NULL;
	char	*ModPartNo				=	NULL;
	char	command[1000]; 
	taskcomment = (char*) malloc(200);  // memory allocation
	printf("\n I am in main program");fflush(stdout);	
	USERARG_get_string_argument(&selectedTask);
	USERARG_get_string_argument(&userName);
	USERARG_get_string_argument(&abortReason);
	
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	printf("\n Input userName :: %s ",userName);fflush(stdout);
	printf("\n Abort Reason :: %s ",abortReason);fflush(stdout);
	
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char     *qry_valuesCntrl1[3]= {"EPA","Abort","0"};

    ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
       if (qryTagCntrl1)
       {
            printf("\n EPA Abort\n");fflush(stdout);
		    printf("\n Control Object EPA Abort process Query Found \n");fflush(stdout);
			
			ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		    printf("\n No of Control Object EPA Abort process  Found %d ",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
		    {
				tag_t qryTagCntrl1 = NULLTAG;
			    tag_t qryTag1 = NULLTAG;
			    tag_t qryTag = NULLTAG;
			    qryTag = NULLTAG;
			    qryTag1 = NULLTAG;
			    int m=0;
                int Task_found1=0;
			    tag_t *STDStask_tags = NULLTAG;
			    int mm=0;
			    char *Mjob_name =NULL;
			    char *Mobj_name =NULL;
			    int mmm =0;
			    int n_entry=0;
			    int n_entry1 = 2;
			 
			    char *qry_entry1[2] = {"Name", "Type"};
			    int FlderSize =0;
			    int     FlderObjCount =  0;
			    tag_t  *MFolderObj_tag	= NULLTAG;
			    tag_t  *FolderObj_tag	= NULLTAG;
			    //EPM_signoff_decision_t 	decision = EPM_approve_decision;
			    tag_t *Mattachments = NULLTAG;
			    tag_t *signoff_tags = NULL;
			    char*			username	=NULL;
			    tag_t			user_tag	=NULLTAG;
                tag_t			user_tag1	=NULLTAG;
		        char *Usr_name =NULL;
			    tag_t partStatusTask = NULLTAG;
			    logical retain=false;
	
	ITK_CALL(QRY_find2("General...", &qryTag1));

				if (qryTag1 != NULLTAG)
				{
					printf("\n General... Query Found \n");fflush(stdout);
					printf("\n userName = %s \n",userName);fflush(stdout);
			
				    //	POM_get_user(&username,&user_tag);
				    // getting usertag from username using below API

					ifail = POM_get_user(&username,&user_tag1);
	                printf("\n\t Starting for username :%s....\n",username);fflush(stdout);

					AOM_ask_value_string(user_tag1, "object_string", &Usr_name);
				    printf("\n Usr_name: %s\n", Usr_name);fflush(stdout);

					char *STDSqry_values[2] = {Usr_name, "Tasks To Perform"};
					ITK_CALL(QRY_execute(qryTag1, n_entry1, qry_entry1, STDSqry_values, &Task_found1, &STDStask_tags));

					printf("\n EPA Task_found1: %d\n", Task_found1);fflush(stdout);

					if (Task_found1>0)
					{
						for(mm=0; mm<Task_found1; mm++)
						{
						  FlderSize =0;
	                      FlderObjCount =  0;
	                      tag_t  *MFolderObj_tag	= NULLTAG;
	
						  ITK_CALL(FL_ask_size(STDStask_tags[mm],&FlderSize));
						  printf("\n  FlderSize is:   %d \n",FlderSize);fflush(stdout);

						  ITK_CALL(FL_ask_references(STDStask_tags[mm],FL_fsc_by_date_modified,&FlderObjCount,&MFolderObj_tag));
						  printf("\n EPA FlderObjCount is:   %d \n",FlderObjCount);fflush(stdout);

						  if (FlderObjCount>0)
						  {
							  for(mmm=0; mmm<FlderObjCount; mmm++)
							  {
							  
									  tag_t *Mattachments = NULLTAG;
									  tag_t	queryPart	  =	NULLTAG;
									  int     n_entryCntrl1   =2;
									  int number_found =0;
									  tag_t	*result	=	NULLTAG;
	                                  int	ifail=0;
									//cancatinate the comments string
                                      tc_strcpy(taskcomment,"");
                                      tc_strcat(taskcomment,"Auto signoff by ITK : ");
	                                  tc_strcat(taskcomment,abortReason); 
                                   // getting job_name,object_name from below API
									  ITK_CALL(AOM_ask_value_string(MFolderObj_tag[mmm], "job_name", &Mjob_name));
									  ITK_CALL(AOM_ask_value_string(MFolderObj_tag[mmm], "object_name", &Mobj_name));                  
									  printf("\n Mjob_name: %s\n", Mjob_name);fflush(stdout);
									  printf("\n Mobj_name: %s\n", Mobj_name);fflush(stdout);
									  
									  if((tc_strcmp(Mobj_name,"Finalize the EPA")==0 || tc_strcmp(Mobj_name,"EPA WorkFlow")==0 ) &&(tc_strstr(Mjob_name,selectedTask)!=NULL))
								          //if((tc_strstr(Mjob_name,selectedTask)!=NULL))

									      {
										  printf("\n condition pass for selected EPA_rev- kkkumar \n",userName);fflush(stdout);
                                          //This API use to set task result 
										  ITK_CALL(EPM_set_task_result(MFolderObj_tag[mmm],EPM_RESULT_Completed));

                                          //ITK_CALL(EPM_trigger_action(MFolderObj_tag[mmm],EPM_abort_action ,"Auto signoff by ITK"));
                                          ITK_CALL(EPM_trigger_action(MFolderObj_tag[mmm],EPM_abort_action ,taskcomment));

                                           // query for serching ITEM ID & its type
										   char 	*qry_part_entries[2] = {"Item ID","Type"};
										   char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));

									       //  char 	*qry_part_values[2] = {selectedTask,"EPA Revision"};
										   qry_valuesCntrl1[0]=selectedTask;
										   qry_valuesCntrl1[1]="EPA Revision";
										   ITKCALL(QRY_find2("Item Revision...", &queryPart));
																			
											QRY_execute(queryPart, n_entryCntrl1, qry_part_entries, qry_valuesCntrl1, &number_found, &result);
											printf("\n number found : %d",number_found);fflush(stdout);

											//Added function call for remove release status
											remove_release_status(result[0]);

										    //Add Abort release status
										  ITKCALL( RELSTAT_create_release_status("T5_aborted", &partStatusTask));
										  printf("\nLCS Updated on task1111");fflush(stdout);
										  ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &result[0], retain));
							  }
							  else
								  {

								  printf(" \n Finalize the EPA condition not found \n");
							  
							  }
						  }
						}
					}
				}
		    }
			
		    else
		    {
				printf(" \n Control Object Not Found \n");
		    }
	   }
	return ifail;	

}
}


extern int tm_ServiceForEPAAbort(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	int nargs = 3;//To be recieved from RAC
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE; //EPA task revision
	inputArgTypes[1] = USERARG_STRING_TYPE; //UserName
    inputArgTypes[2] = USERARG_STRING_TYPE; //AbortReason 
		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n tm_ServiceForEPAAbort before....tm_ServiceForEPAAbort");fflush(stdout);  
	ifail=USERSERVICE_register_method("ServiceForEPAAbort",(USER_function_t)ServiceForEPAAbort,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

extern DLLAPI int tm_ServiceForEPAAbort_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ServiceForEPAAbort");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ServiceForEPAAbort", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_ServiceForEPAAbort);
	printf("\n After registering userservice....tm_ServiceForEPAAbort");fflush(stdout);
	return ( ITK_ok );
}


