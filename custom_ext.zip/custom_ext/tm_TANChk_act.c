#include "TMLLibrary_server_exits.h"


int tm_TANChk_act(EPM_action_message_t msg)
{

    printf("\n *********** ::start here:: **********");fflush(stdout);
	printf("inside tm_TANChk_act handler");fflush(stdout);
    int r,Xp,l;
	int revcount;
	int ifail                = ITK_ok;
	int error_code			 = ITK_ok;
	int i					 = 0;
	int j					 = 0;
	int k					 = 0;
	int count				 = 0;
	int taskcount			 = 0;
	int flagVC				 = 0;
	int notsk				 = 0;
	int dmlCnt				 = 0;
	int o				     = 0;
	int a				     = 0;
    int	Breakdowncount       = 0;
	int	Xpartcount           = 0;
	int	countt               = 0;
	int DR2_flag             = 0;
	int NPIHistoryFlag       = 0;
	int cnt_ccvcls           = 0;
	int no_attach			 = 0;
	int Vehattached 		= 0;
	int TScount			     = 0;

	char *objecttype		 = NULL;
	char *objectId		     = NULL;
	char *objectdesc		 = NULL;
	char *objectrelstatus	 = NULL;
	char *objectDRstatus	 = NULL;
	char *DMLDRstauts		 = NULL;
	char *value			     = NULL;
	char *objTypeofTask      = NULL;
	char *relation_name      = NULL;

	tag_t Xpartcount1        = NULLTAG;
	tag_t XPartTags1         = NULLTAG;
	tag_t item               = NULLTAG;
	tag_t reltiontype        = NULLTAG;
	tag_t techspecobjs1      = NULLTAG;
	tag_t DMLTaskTag         = NULLTAG;
	tag_t DMLtsk_tag         = NULLTAG;
	tag_t DMLtaskRevTag      = NULLTAG;
	tag_t tsk_dml_rel_type   = NULLTAG;
	tag_t DMLRevTg           = NULLTAG;
	tag_t veh_tsk_rel        = NULLTAG;
	tag_t task_dml_rel       = NULLTAG;
	tag_t query			     = NULLTAG;
	tag_t rev_list1          = NULLTAG;
	tag_t DmlItemsRelation	 = NULLTAG;
	tag_t Taskrelation_type  = NULLTAG;
	tag_t DMLObject		     = NULLTAG;
	tag_t DMLRevTag          = NULLTAG;
	tag_t roottask			 = NULLTAG;
	tag_t objTypTag		     = NULLTAG;
    tag_t ClsObj             = NULLTAG;
	tag_t DMLTag		     = NULLTAG;
	tag_t relation_type_tag  = NULLTAG;
	tag_t TechSpecObjTag     = NULLTAG;

	tag_t *BreakdowncountTags= NULLTAG;
	tag_t *XPartTags         = NULLTAG;
	tag_t *rev_list          = NULLTAG;
	tag_t *techspecobjs      = NULLTAG;
	tag_t *DMLTsk            = NULLTAG;
	tag_t *tsk_rev           = NULLTAG;
	tag_t *dml_rev           = NULLTAG;
	tag_t *SecObject		 = NULLTAG;
	tag_t *taskObject		 = NULLTAG;
	tag_t *Attachments	     = NULLTAG;
	tag_t *contrlObjs	     = NULLTAG;
	tag_t *ClsObjTag	     = NULLTAG;
	tag_t *primaryobjs	     = NULLTAG;
	char *DMLNo              = NULL;
	char *sDMLno             = NULL;
	char *objType            = NULL;
	char *item_id            = NULL;
	char *objTypeofDML       = NULL;
	char *DMLtype            = NULL;
	char *Breakdownobj       = NULL;
	char *partid             = NULL;
	char *classofobj         = NULL;
	char *revid              = NULL;
	char *DRattri            = NULL;
	char *releasestatus      = NULL;
	char *PartStatus         = NULL;
	char *parttype           = NULL;
	char *sDMLToGate         = NULL;
	char *attrivalue         = NULL;
	char *dmldr              = NULL;
	char *fromtostatus       = NULL;
	char *dmlreltype         = NULL;
	char *dmlreltype2        = NULL;
	char *sTanInfo1          = NULL;
	char *sTanInfo2          = NULL;
	char *sTanInfo3          = NULL;
	char *sTanInfo4          = NULL;
	char *sDMLDR             = NULL;
	char *dmltskNo           = NULL;
	char *AttrKeyValue       = NULL;
	char *TechSpecNum        = NULL;
	char *VCBusUnit          = NULL;
	char *sErcDmlBU          = NULL;
	char *taskid             = NULL;
	char *VCBusUnitDup       = NULL;

	logical     is_latest;

	//EPM_decision_t decision = EPM_nogo;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_TANChk_act Function started...");fflush(stdout);
	TC_write_syslog("\n tm_TANChk_act Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_NPIFirstTimeDR2:INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="TANCHK";
				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sTanInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sTanInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sTanInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sTanInfo4));
					printf("\n L1:sTanInfo1 is : [%s]  L2:sTanInfo2 is : [%s]  L3:sTanInfo3 is : [%s] L4:sTanInfo4 is : [%s]\n",sTanInfo1,sTanInfo2,sTanInfo3,sTanInfo4);fflush(stdout);

					if(tc_strstr(sTanInfo1,"TANOFF1") == NULL)
					{
						//ITK_CALL(ITEM_ask_latest_rev(DMLtsk_tag,&DMLtaskRevTag));
						//printf("\n DML task tag is not null ");

						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n  object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&objType));
							printf("\n  item_id is %s\n", objType);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
							printf("\n  t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
							printf("\n  sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&sDMLToGate));
							printf("\n  sDMLToGate is %s\n", sDMLToGate);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&sErcDmlBU));
							printf("\n  sErcDmlBU is %s\n", sErcDmlBU);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_Tan_code--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n tm_Tan_code--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								if((tc_strcmp(DMLtype,"Veh")==0) && ((tc_strcmp(sDMLDR,"DR3")==0) || (tc_strcmp(sDMLDR,"DR4")==0) || (tc_strcmp(sDMLDR,"DR5")==0)))
								{
								   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
								   if (tsk_dml_rel_type!=NULLTAG)
								   {
										//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
										ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,tsk_dml_rel_type,&countt,&DMLTsk));
										printf("\n tm_Tan_code:DML Revision from Task for : %d",countt);fflush(stdout);

										for (j=0;j<countt ;j++)
										{
											DMLtsk_tag=DMLTsk[j];

											ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid));
											printf("\n taskid = %s \n",taskid);fflush(stdout);

											if (tc_strstr(taskid,"_00")!=NULL)
											{

												ITK_CALL(AOM_ask_value_tags(DMLtsk_tag,"CMHasSolutionItem",&Xpartcount,&XPartTags)); //Change References
												printf("\n inside1 ---------------> : \n",DMLtype); fflush(stdout);
												printf("\n 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);

												printf("\n inside for loop");fflush(stdout);

												for(Xp=0;Xp<Xpartcount;Xp++)
												{
													Xpartcount1=XPartTags[Xp];

													ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
													printf("\n partid = %s \n",partid);fflush(stdout);

													//ITK_CALL(ITEM_find(Xpartcount1,&revcount,&rev_list));
													//ITK_CALL(ITEM_find_revisions(Xpartcount1,NULL,&revcount,&rev_list));
													ITK_CALL(ITEM_ask_item_of_rev(XPartTags[Xp],&item));

													ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));


													ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
													printf("\n partid = %s \n",partid);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(XPartTags[Xp],"t5_PartType",&parttype));
													printf("\n parttype = %s \n",parttype);fflush(stdout);

													   //Check NPI code assigned or not?
													   //if Yes, then PASSSSS
													  //If not assigned, ned to send to NPI.
													if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
													{

														ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
														printf("\n after T5_VCSpec relation find"); fflush(stdout);
														if(relation_type_tag != NULLTAG)
														{
															printf("\n inside T5_VCSpec relation found"); fflush(stdout);
															ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
															printf("\n relation_name[%s]",relation_name); fflush(stdout);
															ITK_CALL(GRM_list_secondary_objects_only(XPartTags[Xp],relation_type_tag,&TScount,&primaryobjs));
															printf("\n TScount: %d\n", TScount);fflush(stdout);
															if(TScount>0)
															{
																TechSpecObjTag=primaryobjs[0];
																printf("\nDlgTanCodeValuDup");fflush(stdout);
																ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																if(VCBusUnit)
																{
																	tc_strdup(VCBusUnit,&VCBusUnitDup);
																}
																printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
															}
														}
														//char *VCClsAddress=NULL
														//char *TobeUpdAttrId=NULL;
														if (VCBusUnitDup!=NULL)
														{
															char TobeUpdAttrId[30];
															int retcount;
															int ClsAttrId=0 ;
															printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
															ITK_CALL(getTANCodeAttrNoWrtTSBU(VCBusUnitDup,&retcount));
															printf("\n after call getTANCodeAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
															ClsAttrId=retcount;
															printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
															if(ClsAttrId>0)
															{

																sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																printf("\n inside sprintf TobeUpdAttrId[%s] for NPI Code \n",TobeUpdAttrId);fflush(stdout);
																//key_lov_id=theKeyLOVId;
															}
															printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);
															ITK_CALL(AOM_ask_value_tags(item,"IMAN_classification",&cnt_ccvcls,&ClsObjTag));
															printf("\n CV_CE:P322:Classification relation: %d.",cnt_ccvcls); fflush(stdout);



															if (cnt_ccvcls>0)
															{

																ClsObj=*ClsObjTag;

															    if (tc_strstr(sTanInfo2,"TANNME3") == NULL)
															    {
																	ITK_CALL(ICS_ask_attribute_value(ClsObj,TobeUpdAttrId,&AttrKeyValue));
																	printf("\n TAN regular"); fflush(stdout);

															    }
															    else
															    {
																	  CALLAPI(getClsValueFrmICSTagActTAN(ClsObj,&AttrKeyValue));
																      printf("\nTAN outside function to get value from name"); fflush(stdout);
																	
															    }

																printf("\n AttrKeyValue=%s",AttrKeyValue);fflush(stdout);

																//if((tc_strcmp(AttrKeyValue,"")==0) || (tc_strcmp(AttrKeyValue,"NA")==0))//(AttrKeyValue==NULL) ||
																if(tc_strstr(AttrKeyValue,"EXPORT")==NULL)
																{
																	/*printf("\n tm_TANReview--TAN value is null \n"); fflush(stdout);

																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Please Update TAN code");
																	decision = EPM_nogo;
																	printf("\n need to send to TAN\n");fflush(stdout);*/

																	return 0;
																}
																else
																{
																	//decision = EPM_go;

																	return 10005;
																	printf("\n NO need to send \n");fflush(stdout);

																}

															}
														}
													}
												}

											}
										}
								   }
								}
								else if((tc_strcmp(DMLtype,"TODR")==0) && ((tc_strcmp(sDMLToGate,"DR2 to DR3")==0) || (tc_strcmp(sDMLToGate,"DR3P to DR4")==0) || (tc_strcmp(sDMLToGate,"DR3 to DR4")==0) || (tc_strcmp(sDMLToGate,"DR4 to DR5")==0)))
								{

								   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
								   if (tsk_dml_rel_type!=NULLTAG)
								   {
										//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
										ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,tsk_dml_rel_type,&countt,&DMLTsk));
										printf("\n :DML Revision from Task for : %d",countt);fflush(stdout);

										for (j=0;j<countt ;j++)
										{
											DMLtsk_tag=DMLTsk[j];

											ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid));
											printf("\n taskid = %s \n",taskid);fflush(stdout);

											if (tc_strstr(taskid,"_00")!=NULL)
											{
												ITK_CALL(AOM_ask_value_tags(DMLtsk_tag,"CMReferences",&Xpartcount,&XPartTags)); //Change References
												printf("\n inside1 ---------------> : \n",DMLtype); fflush(stdout);
												printf("\n 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);

												printf("\n inside for loop");fflush(stdout);
												Vehattached =0;
												for(Xp=0;Xp<Xpartcount;Xp++)
												{
													Xpartcount1=XPartTags[Xp];

													ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
													printf("\n partid = %s \n",partid);fflush(stdout);

													//ITK_CALL(ITEM_find(Xpartcount1,&revcount,&rev_list));
													//ITK_CALL(ITEM_find_revisions(Xpartcount1,NULL,&revcount,&rev_list));
													ITK_CALL(ITEM_ask_item_of_rev(XPartTags[Xp],&item));

													ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));


													ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
													printf("\n partid = %s \n",partid);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(XPartTags[Xp],"t5_PartType",&parttype));
													printf("\n parttype = %s \n",parttype);fflush(stdout);

													   //Check TAN code assigned or not?
													   //if Yes, then PASSSSS
													  //If not assigned, ned to send to TAN.
													if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
													{
														Vehattached =1;
														ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
														printf("\n after T5_VCSpec relation find"); fflush(stdout);
														if(relation_type_tag != NULLTAG)
														{
															printf("\n inside T5_VCSpec relation found"); fflush(stdout);
															ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
															printf("\n relation_name[%s]",relation_name); fflush(stdout);
															ITK_CALL(GRM_list_secondary_objects_only(XPartTags[Xp],relation_type_tag,&TScount,&primaryobjs));
															printf("\n TScount: %d\n", TScount);fflush(stdout);
															if(TScount>0)
															{
																TechSpecObjTag=primaryobjs[0];
																printf("\nDlgTanCodeValuDup");fflush(stdout);
																ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																if(VCBusUnit)
																{
																	tc_strdup(VCBusUnit,&VCBusUnitDup);
																}
																printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
															}
														}
														//char *VCClsAddress=NULL
														//char *TobeUpdAttrId=NULL;
														if (VCBusUnitDup!=NULL)
														{
															char TobeUpdAttrId[30];
															int retcount;
															int ClsAttrId=0 ;
															printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
															ITK_CALL(getTANCodeAttrNoWrtTSBU(VCBusUnitDup,&retcount));
															printf("\n after call getTANCodeAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
															ClsAttrId=retcount;
															printf("\n ClsAttrId[%d] for TAN Code \n",ClsAttrId);fflush(stdout);
															if(ClsAttrId>0)
															{

																sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																printf("\n inside sprintf TobeUpdAttrId[%s] for TAN Code \n",TobeUpdAttrId);fflush(stdout);
																//key_lov_id=theKeyLOVId;
															}
															printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);
															ITK_CALL(AOM_ask_value_tags(item,"IMAN_classification",&cnt_ccvcls,&ClsObjTag));
															printf("\n CV_CE:P322:Classification relation: %d.",cnt_ccvcls); fflush(stdout);



														if (cnt_ccvcls>0)
														{

															ClsObj=*ClsObjTag;
															if (tc_strstr(sTanInfo2,"TANNME4") == NULL)
															{
																ITK_CALL(ICS_ask_attribute_value(ClsObj,TobeUpdAttrId,&AttrKeyValue));
																printf("\n TAN regular"); fflush(stdout);

															}
															else
															{
																  CALLAPI(getClsValueFrmICSTagActTAN(ClsObj,&AttrKeyValue));
																  printf("\nTAN outside function to get value from name"); fflush(stdout);
																
															}
															printf("\n AttrKeyValue=%s",AttrKeyValue);fflush(stdout);

															//if((tc_strcmp(AttrKeyValue,"")==0) || (tc_strcmp(AttrKeyValue,"NA")==0))//(AttrKeyValue==NULL) ||
															if(tc_strstr(AttrKeyValue,"EXPORT")==NULL)
															{
																/*printf("\n tm_TANReview--TAN value is null \n");fflush(stdout);

																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Please Update TAN code");
																decision = EPM_nogo;
																printf("\n need to send to TAN \n");fflush(stdout);*/

																return 0;
															}
															else
															{
																//decision = EPM_go;

																//NO need to send
																return 10005;
																printf("\n NO need to send \n");fflush(stdout);

															}

														}
														}
													}
												}
												if (Vehattached==0)
												{
													return 10005;
													printf("\n DML not applicable \n");fflush(stdout);
												}
											}
										}
								   }
								}
								else
								{
									return 10005;
						            printf("\n DML not applicable \n");fflush(stdout);
								}

							}
						}
					}
					else
					{
						return 10005;
						printf("\n control object off \n");fflush(stdout);
					}
				}
			}
		}
	}

	printf("\n tm_TANChk_act Function end...");fflush(stdout);
	TC_write_syslog("\n tm_TANChk_act Function end...");
	return 10005;
}





int getClsValueFrmICSTagActTAN( tag_t  IcsClsTag ,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;
	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;
	char** attributeNames	= NULL;
	char** attributeValues	= NULL;
	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;
	int theAttributeCount =0;
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;
	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;

    printf("\n getClsValueFrmICSTagActTAN Function started...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagActTAN Function started...");

	ITK_CALL( ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount>0)
	{
		for(i=0;i<theAttributeCount;i++)
		{
			TotVCAttrCount=TotVCAttrCount+theAttributeCount;

			sprintf(attrId,"%d",theAttributeIds[i]);
			//printf("\n attrId:[%s]",attrId);fflush(stdout);

			tc_strcpy(attributeNameDup,"");
			tc_strcpy(attributeNameDup,theAttributeNames[i]);

			printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

			if(tc_strcmp(attributeNameDup,"CMVR_TYP_APPRVL_NO")==0)
			{
				
				tc_strcpy(attributeValueDup,"");

				for(x=0;x<theAttributeValCounts[i];x++)
				{
					//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
					tc_strcat(attributeValueDup,theAttributeValues[i][x]);
					//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
				}
				printf("\n theAttribute Name TAN :[%s]",attributeNameDup,i);fflush(stdout);
				printf("\n attrId:[%s]",attrId);fflush(stdout);
				printf("\n theAttribute value TAN:[%s] ",attributeValueDup);fflush(stdout);
				*AttrVal=attributeValueDup;

			}

		}
			//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
			//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
	}

	printf("\n attributeValueDup TAN=%s ",attributeValueDup); fflush(stdout);
			
     printf("\n getClsValueFrmICSTagActTAN Function end...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagActTAN Function end...");
	//return ITK_ok;
	return 0;

}

int getTANCodeAttrNoWrtTSBU( char *TechSpecBusunit,int   *retTanCodeattrno )
{
    int ifail = ITK_ok;
    //tag_t        query           = NULLTAG;
    tag_t    *RetICOTanAttrNoContrlObjs=NULLTAG;
    char *CntrlObjName=NULL;
    char *TanAttrid=NULL;
    int TanAttridInt=0;
    int retCntrlObjcount=0;

	 printf("\n getTANCodeAttrNoWrtTSBU Function started...");fflush(stdout);
	TC_write_syslog("\n getTANCodeAttrNoWrtTSBU Function started...");

    if(TechSpecBusunit)
    {

        retCntrlObjcount=0;
        //ITKCALL(getNPIAttrObj(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
        ITKCALL(getTanICOUpdCO(TechSpecBusunit,"ICOTanAttrNo",&retCntrlObjcount,&RetICOTanAttrNoContrlObjs));
        printf("\n after call getTANCodeAttrNoWrtTSBU count: %d \n",retCntrlObjcount);fflush(stdout);
        if(retCntrlObjcount>0)
        {
            ITKCALL( AOM_ask_value_string(RetICOTanAttrNoContrlObjs[0], "object_name", &CntrlObjName));
            printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
            AOM_ask_value_string(RetICOTanAttrNoContrlObjs[0], "t5_Userinfo1", &TanAttrid);
            printf("\n after getTanAttrid: info1[%s] \n",TanAttrid);fflush(stdout);
        }
    }
    printf("\n 22getTANAttrObj: info1[%s] \n",TanAttrid);fflush(stdout);
    if(TanAttrid!=NULL)
    {
         TanAttridInt=atoi(TanAttrid);
    }
    if(TanAttridInt>0)
    {
         *retTanCodeattrno =TanAttridInt;
    }
    else
    {
        TanAttridInt=8171;
        printf("\n TanAttridInt=%d\n",TanAttridInt);fflush(stdout);
         *retTanCodeattrno =TanAttridInt;

    }
    printf("\n\n End Qry for getTANCodeAttrNoWrtTSBU control object size ==%d with retTanCodeattrno=%d\n",retCntrlObjcount,*retTanCodeattrno);fflush(stdout);

    printf("\n getTANCodeAttrNoWrtTSBU Function end...");fflush(stdout);
	TC_write_syslog("\n getTANCodeAttrNoWrtTSBU Function end...");

    //return ifail;
	return 0;
}


int getTanICOUpdCO( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	tag_t        query           = NULLTAG;
	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n in getTanICOUpdCO func");fflush(stdout);
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);

	printf("\n getTanICOUpdCO Function started...");fflush(stdout);
	TC_write_syslog("\n getTanICOUpdCO Function started...");

	printf("\n b4 Qry getTanICOUpdCO");fflush(stdout);

	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getTanICOUpdCO");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);
	printf("\n\n End Qry for getTanICOUpdCO control object size ==%d \n",*n_found);fflush(stdout);

	printf("\n getTanICOUpdCO Function end...");fflush(stdout);
	TC_write_syslog("\n getTanICOUpdCO Function end...");

	//return ifail;
	return 0;
}

