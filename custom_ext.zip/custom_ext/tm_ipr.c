/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_ipr.c
* Created By                   : Sudhir
* Created On                   : 01-Aug-2019
* Project                      : TML/New Part Request
* Methods Defined              : CUSTOM_EXIT
* Description                  : On TML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
//#define _CRT_SECURE_NO_DEPRECATE
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64
#define PROJ_name_size_c   32
#define PLM_error (EMH_USER_error_base+25)

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

char *newval = (char*) malloc(12);

strncpy(newval, val,11);
printf("\n newval=%s",newval);fflush(stdout);

return newval;

}
char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(30);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}


/****************************************************************************
Function:       NewIPR_Create_postaction
Description:    This function used to assign project while create an assembly
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int NewIPR_Create_postaction(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;


	tag_t	master		=	NULLTAG;
	tag_t	*t_item1		=	NULLTAG;
	tag_t	*q_item1		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t	latestitemrev	=	NULLTAG;
	tag_t		relation_type_three = NULLTAG;
	tag_t		relation_three = NULLTAG;



	char   *newpartreqnumber=NULL;
	char   *itemId=NULL;
	char   *IPRReqd=NULL;

	int n_tags_found = 0;



	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name=NULL;

	int error_code = ITK_ok;

	printf("\n In NewIPR_Create_postaction In Custom Message Code\n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();

	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n In NewIPR_Create_postaction In Message Code Type Of Selected Item Is= [%s]\n",type_name);fflush(stdout);

	//POM_get_user_id(&user_id);
	//SA_find_user(user_id, &user_tag);

	if(strcmp(type_name,"T5_IPRRevision")==0)
	{
		int num = 0;
		int prt = 0;
		int Part_Not_Found = 0;
		int Part_Found_IPRNOT = 0;
		char		**PartNumberList;
		char *ERROR_MESSAGE_1 = NULL; // Error Message
		char *ERROR_MESSAGE_2 = NULL; // Error Message
		if(ITEM_ask_item_of_rev  ( objTag,&master) );
		if(ITEM_ask_latest_rev(master,&latestitemrev));
		AOM_ask_value_string(latestitemrev,"item_id",&itemId);
		printf("\n In NewIPR_Create_postaction In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);
		ERROR_MESSAGE_1=(char *)MEM_alloc(2000);
		ERROR_MESSAGE_2=(char *)MEM_alloc(2000);

		AOM_ask_value_string(objTag,"item_id",&newpartreqnumber);
		printf("\n In NewIPR_Create_postaction In Message Code ::NewPartReq NEW-PART-REQUEST-NUMBER [%s]\n",newpartreqnumber);fflush(stdout);

		AOM_ask_value_strings(objTag,"t5_PartNumber",&num,&PartNumberList);
		printf("\n In NewIPR_Create_postaction In Message Code ::num [%d]\n",num);fflush(stdout);
		values[1] = "Design";
		if(num>0)
		{
			GRM_find_relation_type("T5_IPRHasPart", &relation_type_three);
			for(prt=0;prt<num;prt++)
			{
				char	*Part_Num	= NULL;
				tag_t		iprpartrel_tag = NULLTAG;
				Part_Num = PartNumberList[prt];
				printf("\n In NewIPR_Create_postaction In Message Code ::Part_Num [%s]\n",Part_Num);fflush(stdout);
				values[0] = Part_Num;
				ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &t_item1);
				printf("\n n_tags_found [%d]", n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					if(ITEM_ask_latest_rev(t_item1[0],&latestrev));
					if(latestrev!=NULLTAG)
					{
						AOM_ask_value_string(latestrev,"t5_Patient",&IPRReqd);
						printf("\n In NewIPR_Create_postaction In Message Code ::IPRReqd [%s]\n",IPRReqd);fflush(stdout);
						if(tc_strlen(IPRReqd)>0 && tc_strcmp(IPRReqd,"YES")==0)
						{
							GRM_find_relation(objTag, latestrev, relation_type_three, &iprpartrel_tag);
							if(iprpartrel_tag!=NULLTAG)
							{
								printf("\n IPR and Part Relation Exist");fflush(stdout);
							}
							else
							{
								GRM_create_relation(objTag, latestrev, relation_type_three, NULLTAG, &relation_three);
								GRM_save_relation(relation_three);
							}
						}
						else
						{
							Part_Found_IPRNOT++;
							tc_strcpy(ERROR_MESSAGE_1,Part_Num);
							tc_strcat(ERROR_MESSAGE_1,",");
							//EMH_clear_errors();
							//EMH_store_error_s1(EMH_severity_error,PLM_error,"Given Part's Patient Value is not YES");
							//return(PLM_error);
						}

					}
				}
				else
				{
					Part_Not_Found++;
					tc_strcpy(ERROR_MESSAGE_2,Part_Num);
					tc_strcat(ERROR_MESSAGE_2,",");
					//EMH_clear_errors();
					//EMH_store_error_s1(EMH_severity_error,PLM_error,"Given Part Does not Exist");
					//return(PLM_error);
				}
			}
		}
		printf("\n In NewIPR_Create_postaction In Message Code ::Part_Not_Found [%d]\n",Part_Not_Found);fflush(stdout);
		printf("\n In NewIPR_Create_postaction In Message Code ::Part_Found_IPRNOT [%d]\n",Part_Found_IPRNOT);fflush(stdout);
		if(Part_Not_Found>0)
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_error,PLM_error,"Below Given Part Does not Exist.\n",ERROR_MESSAGE_2);
			return(PLM_error);
		}
		if(Part_Not_Found>0)
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_error,PLM_error,"Below Given Part's Patient Value is not YES.\n",ERROR_MESSAGE_1);
			return(PLM_error);
		}

	}

return error_code;
}

/****************************************************************************
Function:       NewWorkInsGuide_Create_postaction
Description:    This function used to assign project while create an assembly
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int NewWorkInsGuide_Create_postaction(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	//char   mastertype_name[TCTYPE_name_size_c+1];

	tag_t masterTypeTag = NULLTAG;
	tag_t master = NULLTAG;
	tag_t relation_type_form = NULLTAG;
	tag_t *masterForm = NULLTAG;
	tag_t *revmasterForm = NULLTAG;

	char   *DocType=NULL;
	char   *newpartreqnumber=NULL;
	char   *type_name=NULL;
	char   *mastertype_name=NULL;

	int masterFormcount =0;
	int revmasterFormcount =0;

	int error_code = ITK_ok;
	printf("\n In NewWorkInsGuide_Create_postaction In Custom Message Code=>[%d]\n",isNew);fflush(stdout);
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();

	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected Item Is= [%s]\n",type_name);fflush(stdout);
	if(isNew==true || isNew==1)
	{
	if(strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
	{
		ITEM_ask_item_of_rev(objTag,&master);
		if(TCTYPE_ask_object_type(master,&masterTypeTag)!=ITK_ok) PrintErrorStack();
		if(TCTYPE_ask_name2(masterTypeTag,&mastertype_name)!=ITK_ok) PrintErrorStack();
		AOM_ask_value_string(objTag,"t5_DocumentType",&DocType);
		AOM_ask_value_string(objTag,"item_id",&newpartreqnumber);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::DocumentType [%s]\n",DocType);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected mastertype_name Is= [%s]\n",mastertype_name);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected newpartreqnumber Is= [%s]\n",newpartreqnumber);fflush(stdout);
		if(strcmp(mastertype_name,"T5_WorkInsGdLine")==0 || strcmp(mastertype_name,"Work Instruction and  Guide Line")==0)
		{
			GRM_find_relation_type("IMAN_master_form", &relation_type_form);
			if(relation_type_form!=NULLTAG)
			{
				GRM_list_secondary_objects_only(master,relation_type_form,&masterFormcount,&masterForm);
				GRM_list_secondary_objects_only(objTag,relation_type_form,&revmasterFormcount,&revmasterForm);
			}
			printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected masterFormcount Is= [%d]\n",masterFormcount);fflush(stdout);
			printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected revmasterFormcount Is= [%d]\n",revmasterFormcount);fflush(stdout);
			if(tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
			{
				if(masterFormcount>0 && masterForm!=NULLTAG)
				{
					AOM_refresh( masterForm[0], TRUE);
					AOM_set_value_string(masterForm[0],"object_name",newpartreqnumber);
					//AOM_save(masterForm[0]);
					AOM_save_without_extensions(masterForm[0]);
					AOM_refresh(masterForm[0],FALSE);
				}
				if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
				{
					AOM_refresh( revmasterForm[0], TRUE);
					AOM_set_value_string(revmasterForm[0],"object_name",newpartreqnumber);
					//AOM_save(revmasterForm[0]);
					AOM_save_without_extensions(revmasterForm[0]);
					AOM_refresh(revmasterForm[0],FALSE);
				}
			}
			if(tc_strcmp(DocType,"WI")==0 || tc_strcmp(DocType,"Work Instruction")==0)
			{
				if(masterFormcount>0 && masterForm!=NULLTAG)
				{
					AOM_refresh( masterForm[0], TRUE);
					AOM_set_value_string(masterForm[0],"object_name",newpartreqnumber);
					//AOM_save(masterForm[0]);
					AOM_save_without_extensions(masterForm[0]);
					AOM_refresh(masterForm[0],FALSE);
				}
				if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
				{
					AOM_refresh( revmasterForm[0], TRUE);
					AOM_set_value_string(revmasterForm[0],"object_name",newpartreqnumber);
					//AOM_save(revmasterForm[0]);
					AOM_save_without_extensions(revmasterForm[0]);
					AOM_refresh(revmasterForm[0],FALSE);
				}
			}
		}
	}
	}
	return error_code;
}
/*
int NewWorkInsGuide_Create_postaction(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t *Groupmemlist = NULLTAG;
	tag_t *EngGroupmemlist = NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;


	char   *newpartreqnumber=NULL;
	char   *DocType=NULL;
	char   *CustomRole=NULL;
	char   *user_id=NULL;

	int number_found = 0;
	int number_engfound = 0;


	char   type_name[TCTYPE_name_size_c+1];
	char   roleNameVal[SA_name_size_c+1];

	int error_code = ITK_ok;

	printf("\n In NewWorkInsGuide_Create_postaction In Custom Message Code=>[%d]\n",isNew);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();

	if(TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok) PrintErrorStack();

	printf("\n In NewWorkInsGuide_Create_postaction In Message Code Type Of Selected Item Is= [%s]\n",type_name);fflush(stdout);

	POM_get_user_id(&user_id);
	SA_find_user(user_id, &user_tag);

	SA_ask_current_role(&CurrentRoleTag);
	SA_ask_role_name(CurrentRoleTag,roleNameVal);
	printf("\n In NewWorkInsGuide_Create_postaction In Message roleNameVal Is= [%s]\n",roleNameVal);fflush(stdout);
	if(isNew==true)
	{
	if(strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
	{
		AOM_ask_value_string(objTag,"item_id",&newpartreqnumber);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::WorkInsGdLine [%s]\n",newpartreqnumber);fflush(stdout);

		AOM_ask_value_string(objTag,"t5_DocumentType",&DocType);
		AOM_ask_value_string(objTag,"t5_CustomRole",&CustomRole);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::DocumentType [%s]\n",DocType);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::CustomRole [%s]\n",CustomRole);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::user_id [%s]\n",user_id);fflush(stdout);
		SA_find_groupmember_by_rolename("Superviser","ERC_Designers_Group",user_id,&number_found,&Groupmemlist);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::number_found [%d]\n",number_found);fflush(stdout);

		SA_find_groupmember_by_rolename("Engineer","ERC_Designers_Group",user_id,&number_engfound,&EngGroupmemlist);
		printf("\n In NewWorkInsGuide_Create_postaction In Message Code ::number_engfound [%d]\n",number_engfound);fflush(stdout);

		if(number_found>0 && number_engfound>0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Logged User is added in Superviser and Engineer Role,Which is not allowed");
			return(PLM_error);
		}

		if(tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
		{
			if(tc_strstr(newpartreqnumber,"WI")!=NULL)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You Have selected Document Type Work GuideLine\nAnd\nDocument Number assigned for Work Instruction.\n if Document Type is Work GuideLine Then Doc Number should assign for Work Guide Line.\nif Document Type is Work Instruction Then Doc Number should assign for Work Instruction.");
				return(PLM_error);
			}

			if(number_found>0)
			{
				AOM_set_value_string(objTag,"t5_CustomRole","Superviser");
				AOM_save(objTag);
			}
			else
			{
				AOM_set_value_string(objTag,"t5_CustomRole","Engineer");
				AOM_save(objTag);
			}

		}
		if(tc_strcmp(DocType,"WI")==0)
		{
			if(tc_strstr(newpartreqnumber,"WG")!=NULL)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You Have selected Document Type Work Instruction\nAnd\nDocument Number assigned for Work Guide Line.\n if Document Type is Work GuideLine Then Doc Number should assign for Work Guide Line.\nif Document Type is Work Instruction Then Doc Number should assign for Work Instruction.");
				return(PLM_error);
			}

			if(number_engfound>0 && number_found==0)
			{
				AOM_set_value_string(objTag,"t5_CustomRole","Engineer");
				AOM_save(objTag);
			}
			if(number_found>0 && number_engfound==0)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You are not allowed to create Work Instruction Document Type");
				return(PLM_error);
			}
		}

	}
	}

return error_code;
}
*/

/****************************************************************************
Function:       NewWorkInsGuide_Create_pre_action
Description:    This function used to assign project while create an assembly
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int NewWorkInsGuide_Create_pre_action(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t *Groupmemlist = NULLTAG;
	tag_t *EngGroupmemlist = NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;
	tag_t master = NULLTAG;
	tag_t masterTypeTag = NULLTAG;
	tag_t designquery = NULLTAG;
	tag_t *t_item1 = NULLTAG;
	tag_t relation_type_form = NULLTAG;
	tag_t *masterForm = NULLTAG;
	tag_t *revmasterForm = NULLTAG;


	char   *newpartreqnumber=NULL;
	char   *DocType=NULL;
	char   *CustomRole=NULL;
	char   *user_id=NULL;
	char   *DocNameS=NULL;
	char   *NewDocNameS=NULL;
	char   *tempSerial=NULL;
	char   *vstr=NULL;

	char *keys[1] = {"creation_date"};
	int  	 orders[1]  ={2};
	int  num_to_sort = 1;

	int number_found = 0;
	int number_engfound = 0;
	int n_tags_found = 0;
	int IncrementPartNumber = 0;
	int IncrementPartNumber_design = 0;
	int masterFormcount = 0;
	int revmasterFormcount = 0;

	logical CREATE_ALLOWED = false;


	//char   type_name[TCTYPE_name_size_c+1];
	//char   mastertype_name[TCTYPE_name_size_c+1];
	//char   roleNameVal[SA_name_size_c+1];

	char   *type_name=NULL;
	char   *mastertype_name=NULL;
	char   *roleNameVal=NULL;

	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};

	int error_code = ITK_ok;

	printf("\n In NewWorkInsGuide_Create_pre_action In Custom Message Code=>[%d]\n",isNew);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();

	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n In NewWorkInsGuide_Create_pre_action In Message Code Type Of Selected Item Is= [%s]\n",type_name);fflush(stdout);

	POM_get_user_id(&user_id);
	SA_find_user2(user_id, &user_tag);

	SA_ask_current_role(&CurrentRoleTag);
	SA_ask_role_name2(CurrentRoleTag,&roleNameVal);
	printf("\n In NewWorkInsGuide_Create_pre_action In Message roleNameVal Is= [%s]\n",roleNameVal);fflush(stdout);
	if(isNew==true || isNew==1)
	{
	if(strcmp(type_name,"T5_WorkInsGdLineRevision")==0 || strcmp(type_name,"Work Instruction and  Guide Line Revision")==0)
	{
		ITEM_ask_item_of_rev(objTag,&master);
		if(TCTYPE_ask_object_type(master,&masterTypeTag)!=ITK_ok) PrintErrorStack();
		if(TCTYPE_ask_name2(masterTypeTag,&mastertype_name)!=ITK_ok) PrintErrorStack();
		AOM_ask_value_string(objTag,"t5_DocumentType",&DocType);
		AOM_ask_value_string(objTag,"t5_CustomRole",&CustomRole);
		GRM_find_relation_type("IMAN_master_form", &relation_type_form);
		if(tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
		{
			if(tc_strcmp(roleNameVal,"Superviser")==0 || tc_strcmp(roleNameVal,"Engineer")==0)
			{
				CREATE_ALLOWED = true;
			}
		}
		if(tc_strcmp(DocType,"WI")==0 || tc_strcmp(DocType,"Work Instruction")==0)
		{
			if(tc_strcmp(roleNameVal,"Engineer")==0)
			{
				CREATE_ALLOWED = true;
			}
			if(tc_strcmp(roleNameVal,"Superviser")==0)
			{
				CREATE_ALLOWED = false;
			}
		}
		if(CREATE_ALLOWED==false)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Superviser Role can be allowed only for Work GuideLine. Please change Role");
			return(PLM_error);
		}
		if(relation_type_form!=NULLTAG)
		{
			GRM_list_secondary_objects_only(master,relation_type_form,&masterFormcount,&masterForm);
			GRM_list_secondary_objects_only(objTag,relation_type_form,&revmasterFormcount,&revmasterForm);
		}		
		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code Type Of Selected Item Type Is= [%s]\n",mastertype_name);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::DocumentType [%s]\n",DocType);fflush(stdout);
		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::CustomRole [%s]\n",CustomRole);fflush(stdout);
		if(strcmp(mastertype_name,"T5_WorkInsGdLine")==0 || strcmp(mastertype_name,"Work Instruction and  Guide Line")==0)
		{
			if(tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
			{
				DocNameS = NULL;
				NewDocNameS = NULL;
				vstr = NULL;

				DocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
				NewDocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
				vstr = (char *) MEM_alloc(10 * sizeof(char) );
				strcpy(DocNameS,"TST-TS-WG-");
				strcpy(NewDocNameS,"TST-TS-WG-");
				strcat(DocNameS,"*");
				qry_values[0]	= DocNameS;
				qry_values[1]	= "Work Instruction and  Guide Line";
				QRY_find2("Item...", &designquery);
				QRY_execute_with_sort(designquery, 2, qry_entries, qry_values, num_to_sort, keys, orders, &n_tags_found, &t_item1);
				printf("\n NewWorkInsGuide_Create_pre_action:: n_tags_found====>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					AOM_ask_value_string(t_item1[0],"item_id",&newpartreqnumber);
					printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::newpartreqnumber [%s]\n",newpartreqnumber);fflush(stdout);
					tempSerial = strtok(newpartreqnumber, "TST-TS-WG-");
					printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::tempSerial [%s]\n",tempSerial);fflush(stdout);
					IncrementPartNumber = atoi(tempSerial);
					printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
					if(IncrementPartNumber<9)
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"00000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=9 && IncrementPartNumber<=98 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"0000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=99 && IncrementPartNumber<=998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=999 && IncrementPartNumber<=9998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"00");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=9999 && IncrementPartNumber<=99998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"0");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=99999)
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=999999)
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,PLM_error,"Series is fulled from 000001  to 999999");
						return(PLM_error);
					}
				}
				else
				{
					strcpy(NewDocNameS,"TST-TS-WG-000001");
				}

				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::NewDocNameS [%s]\n",NewDocNameS);fflush(stdout);
				AOM_refresh( master, TRUE);
				AOM_refresh( objTag, TRUE);
				AOM_set_value_string(master,"item_id",NewDocNameS);
				AOM_set_value_string(objTag,"item_id",NewDocNameS);
				AOM_save_without_extensions(master);
				AOM_save_without_extensions(objTag);
				AOM_refresh( master, FALSE);
				AOM_refresh( objTag, FALSE);
				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::masterFormcount [%d]\n",masterFormcount);fflush(stdout);
				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::revmasterFormcount [%d]\n",revmasterFormcount);fflush(stdout);
				if(masterFormcount>0 && masterForm!=NULLTAG)
				{
					AOM_refresh( masterForm[0], TRUE);
					AOM_set_value_string(masterForm[0],"object_name",NewDocNameS);
					AOM_save_without_extensions(masterForm[0]);
					AOM_refresh(masterForm[0],FALSE);
				}
				if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
				{
					AOM_refresh( revmasterForm[0], TRUE);
					AOM_set_value_string(revmasterForm[0],"object_name",NewDocNameS);
					AOM_save_without_extensions(revmasterForm[0]);
					AOM_refresh(revmasterForm[0],FALSE);
				}				
			}

			if(tc_strcmp(DocType,"WI")==0 || tc_strcmp(DocType,"Work Instruction")==0)
			{
				DocNameS = NULL;
				NewDocNameS = NULL;
				vstr = NULL;

				DocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
				NewDocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
				vstr = (char *) MEM_alloc(10 * sizeof(char) );
				strcpy(DocNameS,"TST-TS-WI-");
				strcpy(NewDocNameS,"TST-TS-WI-");
				strcat(DocNameS,"*");
				qry_values[0]	= DocNameS;
				qry_values[1]	= "Work Instruction and  Guide Line";
				QRY_find2("Item...", &designquery);
				QRY_execute_with_sort(designquery, 2, qry_entries, qry_values, num_to_sort, keys, orders, &n_tags_found, &t_item1);
				printf("\n NewWorkInsGuide_Create_pre_action:: n_tags_found====>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					AOM_ask_value_string(t_item1[0],"item_id",&newpartreqnumber);
					printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::newpartreqnumber [%s]\n",newpartreqnumber);fflush(stdout);
					tempSerial = strtok(newpartreqnumber, "TST-TS-WI-");
					printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::tempSerial [%s]\n",tempSerial);fflush(stdout);
					IncrementPartNumber = atoi(tempSerial);
					printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
					if(IncrementPartNumber<9)
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"00000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=9 && IncrementPartNumber<=98 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"0000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=99 && IncrementPartNumber<=998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"000");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=999 && IncrementPartNumber<=9998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"00");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=9999 && IncrementPartNumber<=99998 )
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,"0");
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=99999)
					{
						IncrementPartNumber_design = IncrementPartNumber+1;
						printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
						sprintf(vstr,"%d",IncrementPartNumber_design);
						printf("\n vstr [%s] ",vstr);fflush(stdout);
						tc_strcat(NewDocNameS,vstr);
						printf("\n NewDocNameS [%s] ",NewDocNameS);fflush(stdout);
					}
					if(IncrementPartNumber>=999999)
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,PLM_error,"Series is fulled from 000001  to 999999");
						return(PLM_error);
					}
				}
				else
				{
					strcpy(NewDocNameS,"TST-TS-WI-000001");
				}

				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::NewDocNameS [%s]\n",NewDocNameS);fflush(stdout);
				AOM_refresh( master, TRUE);
				AOM_refresh( objTag, TRUE);
				AOM_set_value_string(master,"item_id",NewDocNameS);
				AOM_set_value_string(objTag,"item_id",NewDocNameS);
				AOM_save_without_extensions(master);
				AOM_save_without_extensions(objTag);
				AOM_refresh( master, FALSE);
				AOM_refresh( objTag, FALSE);
				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::masterFormcount [%d]\n",masterFormcount);fflush(stdout);
				printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::revmasterFormcount [%d]\n",revmasterFormcount);fflush(stdout);
				if(masterFormcount>0 && masterForm!=NULLTAG)
				{					
					AOM_refresh( masterForm[0], TRUE);
					AOM_set_value_string(masterForm[0],"object_name",NewDocNameS);
					AOM_save_without_extensions(masterForm[0]);
					AOM_refresh(masterForm[0],FALSE);
				}
				if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
				{
					AOM_refresh( revmasterForm[0], TRUE);
					AOM_set_value_string(revmasterForm[0],"object_name",NewDocNameS);
					AOM_save_without_extensions(revmasterForm[0]);
					AOM_refresh(revmasterForm[0],FALSE);
				}
			}
			
		}
		//AOM_ask_value_string(objTag,"item_id",&newpartreqnumber);
		//printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::WorkInsGdLine [%s]\n",newpartreqnumber);fflush(stdout);



		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::user_id [%s]\n",user_id);fflush(stdout);
		SA_find_groupmember_by_rolename("Superviser","ERC_Designers_Group",user_id,&number_found,&Groupmemlist);
		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::number_found [%d]\n",number_found);fflush(stdout);

		SA_find_groupmember_by_rolename("Engineer","ERC_Designers_Group",user_id,&number_engfound,&EngGroupmemlist);
		printf("\n In NewWorkInsGuide_Create_pre_action In Message Code ::number_engfound [%d]\n",number_engfound);fflush(stdout);

		if(number_found>0 && number_engfound>0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Logged User is added in Superviser and Engineer Role,Which is not allowed");
			return(PLM_error);
		}

		if(tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
		{
			if(tc_strstr(newpartreqnumber,"WI")!=NULL)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You Have selected Document Type Work GuideLine\nAnd\nDocument Number assigned for Work Instruction.\n if Document Type is Work GuideLine Then Doc Number should assign for Work Guide Line.\nif Document Type is Work Instruction Then Doc Number should assign for Work Instruction.");
				return(PLM_error);
			}

			if(number_found>0)
			{
				AOM_refresh( objTag, TRUE);
				AOM_set_value_string(objTag,"t5_CustomRole","Superviser");
				//AOM_save(objTag);
				AOM_save_without_extensions(objTag);
				AOM_refresh(objTag,FALSE);
			}
			else
			{
				AOM_refresh( objTag, TRUE);
				AOM_set_value_string(objTag,"t5_CustomRole","Engineer");
				//AOM_save(objTag);
				AOM_save_without_extensions(objTag);
				AOM_refresh(objTag,FALSE);
			}

		}
		if(tc_strcmp(DocType,"WI")==0)
		{
			if(tc_strstr(newpartreqnumber,"WG")!=NULL)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You Have selected Document Type Work Instruction\nAnd\nDocument Number assigned for Work Guide Line.\n if Document Type is Work GuideLine Then Doc Number should assign for Work Guide Line.\nif Document Type is Work Instruction Then Doc Number should assign for Work Instruction.");
				return(PLM_error);
			}

			if(number_engfound>0 && number_found==0)
			{
				AOM_refresh( objTag, TRUE);
				AOM_set_value_string(objTag,"t5_CustomRole","Engineer");
				//AOM_save(objTag);
				AOM_save_without_extensions(objTag);
				AOM_refresh(objTag,FALSE);
			}
			if(number_found>0 && number_engfound==0)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"You are not allowed to create Work Instruction Document Type");
				return(PLM_error);
			}
		}

	}
	}

return error_code;
}

int strategy_doc_pre_action(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE strategy_doc_pre_actionfunction*** \n");fflush(stdout);

	int		ifail							= 0;
	tag_t	objTag					= va_arg(args, tag_t);
	tag_t	obj_type_tag			= NULLTAG;
	tag_t	masterTypeTag			= NULLTAG;
	char*	Document_number	=NULL;
	char   *DocNameS=NULL;
	int 	masterFormcount = 0;
	tag_t *masterForm = NULLTAG;
	tag_t *revmasterForm = NULLTAG;
	
	tag_t	master =NULLTAG;
	int revmasterFormcount = 0;
	
	tag_t relation_type_form =NULLTAG;
	
	//char	obj_type_name[WSO_name_size_c+1];
	//char	mastertype_name[WSO_name_size_c+1];

	char   *obj_type_name=NULL;
	char   *mastertype_name=NULL;
	
	int error_code = ITK_ok;
	
	TCTYPE_ask_object_type(objTag,&obj_type_tag);
	TCTYPE_ask_name2(obj_type_tag,&obj_type_name);
	printf("\nobj_type_name is:%s",obj_type_name);fflush(stdout);
	
	
	if(tc_strcmp(obj_type_name,"CPThemeBoardRevision") == 0)
	{
		DocNameS = NULL;
		
		DocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
		
		ITEM_ask_item_of_rev(objTag,&master);
		TCTYPE_ask_object_type(master,&masterTypeTag);
		TCTYPE_ask_name2(masterTypeTag,&mastertype_name);
		AOM_ask_value_string(master,"t5_str_doc_no",&Document_number);
		printf("\n Document_number => %s\n",Document_number);fflush(stdout);
		GRM_find_relation_type("IMAN_master_form", &relation_type_form);
		
			
			strcpy(DocNameS,"SD_");
			strcat(DocNameS,Document_number);
			
			printf("\n the concatenated document number is %s",DocNameS);fflush(stdout);
			
			if(relation_type_form!=NULLTAG)
			{
				printf("\n inside the if condition of IMAN_master_form relation");fflush(stdout);
			GRM_list_secondary_objects_only(master,relation_type_form,&masterFormcount,&masterForm);
			GRM_list_secondary_objects_only(objTag,relation_type_form,&revmasterFormcount,&revmasterForm);
			}
			
			AOM_refresh( master, TRUE);
			AOM_refresh( objTag, TRUE);
			AOM_set_value_string(master,"item_id",DocNameS);
			AOM_set_value_string(objTag,"item_id",DocNameS);
			AOM_save_without_extensions(master);
			AOM_save_without_extensions(objTag);
			AOM_refresh(master,FALSE);
			AOM_refresh(objTag,FALSE);
			
			printf("\n In t5_strategy_doc_Create_pre_action In Message Code ::masterFormcount [%d]\n",masterFormcount);fflush(stdout);
			printf("\n In t5_strategy_doc_Create_pre_action In Message Code ::revmasterFormcount [%d]\n",revmasterFormcount);fflush(stdout);
			
			if(masterFormcount>0 && masterForm!=NULLTAG)
			{
				AOM_refresh( masterForm[0], TRUE);
				AOM_set_value_string(masterForm[0],"object_name",DocNameS);
				AOM_save_without_extensions(masterForm[0]);
				AOM_refresh(masterForm[0],FALSE);
			
			}
			
			if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
			{
				AOM_refresh( revmasterForm[0], TRUE);
				AOM_set_value_string(revmasterForm[0],"object_name",DocNameS);
				AOM_save_without_extensions(revmasterForm[0]);
				AOM_refresh(revmasterForm[0],FALSE);
			
			}
		
	}
	
	return error_code;
	
}


int strategy_doc_Create_postaction(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE strategy_doc_Create_postaction*** \n");fflush(stdout);
	
	int		ifail							= 0;
	tag_t	objTag					= va_arg(args, tag_t);
	tag_t	obj_type_tag			= NULLTAG;
	tag_t	masterTypeTag			= NULLTAG;
	char*	Document_number	=NULL;
	char   *DocNameS=NULL;
	int 	masterFormcount = 0;
	tag_t *masterForm = NULLTAG;
	tag_t *revmasterForm = NULLTAG;
	
	tag_t	master =NULLTAG;
	int revmasterFormcount = 0;
	
	tag_t relation_type_form =NULLTAG;
	
	//char	obj_type_name[WSO_name_size_c+1];
	//char	mastertype_name[WSO_name_size_c+1];
	char   *obj_type_name=NULL;
	char   *mastertype_name=NULL;
	
	int error_code = ITK_ok;
	
	TCTYPE_ask_object_type(objTag,&obj_type_tag);
	TCTYPE_ask_name2(obj_type_tag,&obj_type_name);
	printf("\nobj_type_name is:%s",obj_type_name);fflush(stdout);
	
	
	if(tc_strcmp(obj_type_name,"CPThemeBoardRevision") == 0)
	{
		DocNameS = NULL;
		
		DocNameS = (char *) MEM_alloc( 100 * sizeof(char) );
		
		ITEM_ask_item_of_rev(objTag,&master);
		TCTYPE_ask_object_type(master,&masterTypeTag);
		TCTYPE_ask_name2(masterTypeTag,&mastertype_name);
		AOM_ask_value_string(master,"t5_str_doc_no",&Document_number);
		printf("\n Document_number => %s\n",Document_number);fflush(stdout);
		GRM_find_relation_type("IMAN_master_form", &relation_type_form);
		
			
			strcpy(DocNameS,"SD_");
			strcat(DocNameS,Document_number);
			
			printf("\n the concatenated document number is %s",DocNameS);fflush(stdout);
			
			if(relation_type_form!=NULLTAG)
			{
			printf("\n inside the if condition of IMAN_master_form relation");fflush(stdout);
			GRM_list_secondary_objects_only(master,relation_type_form,&masterFormcount,&masterForm);
			GRM_list_secondary_objects_only(objTag,relation_type_form,&revmasterFormcount,&revmasterForm);
			}
			
			printf("\n In t5_strategy_doc_Create_pre_action In Message Code ::masterFormcount [%d]\n",masterFormcount);fflush(stdout);
			printf("\n In t5_strategy_doc_Create_pre_action In Message Code ::revmasterFormcount [%d]\n",revmasterFormcount);fflush(stdout);
			
			if(masterFormcount>0 && masterForm!=NULLTAG)
			{
				AOM_refresh( masterForm[0], TRUE);
				AOM_set_value_string(masterForm[0],"object_name",DocNameS);
				//AOM_save(masterForm[0]);
				AOM_save_without_extensions(masterForm[0]);
				AOM_refresh(masterForm[0],FALSE);
			}
			
			if(revmasterFormcount>0 && revmasterForm!=NULLTAG)
			{
				AOM_refresh( revmasterForm[0], TRUE);
				AOM_set_value_string(revmasterForm[0],"object_name",DocNameS);
				//AOM_save(revmasterForm[0]);
				AOM_save_without_extensions(revmasterForm[0]);
				AOM_refresh(revmasterForm[0],FALSE);
			}
		
	}
	
	return error_code;
}

int strategy_doc_pre_condition(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE strategy_doc_pre_conditionFunc*** \n");fflush(stdout);

	int		ifail							= 0;
	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	
	
	//char	primary_obj_type_name[WSO_name_size_c+1];
	
	tag_t project =NULLTAG;
	tag_t CurrentRoleTag =NULLTAG;
	
	char*	roleName	=NULL;
	char*	groupName	=NULL;
	char*	project_name	=NULL;
	char*	DesignGrp	=NULL;
	char*	project_code	=NULL;
	tag_t	userTag 	=NULLTAG;
	tag_t	groupTag 	=NULLTAG;
	tag_t	userSession 	=NULLTAG;

	char *grpName=NULL;
    char *projectName=NULL;
    char *role_Name=NULL;
    char *primary_obj_type_name=NULL;
	
	
	TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	TCTYPE_ask_name2(primary_obj_type_tag,&primary_obj_type_name);
	printf("\nPrimary_object type_name is:%s",primary_obj_type_name);fflush(stdout);

	if((tc_strcmp(primary_obj_type_name,"CPThemeBoard") == 0))
	{

		CE_current_user_session_tag(&userSession);

		AOM_ask_value_string(userSession,"group_name",&grpName);
		printf("\n strategy_doc_pre_condition::grpName====>[%s]", grpName);fflush(stdout);

		AOM_ask_value_string(userSession,"project_name",&projectName);
		printf("\n strategy_doc_pre_condition::projectName====>[%s]", projectName);fflush(stdout);

		AOM_ask_value_string(userSession,"role_name",&role_Name);
		printf("\n strategy_doc_pre_condition::role_Name====>[%s]", role_Name);fflush(stdout);
		
		
		if((tc_strcmp(grpName,"ERC_Designers_Group")==0) || (tc_strcmp(grpName,"DML_Participants_Group")==0) || (tc_strcmp(grpName,"DML_Participants_Group_CV")==0))
		{

		
			AOM_ask_value_string(primary_object,"t5_DesignGrp",&DesignGrp);
			printf("\n DesignGrp => %s\n",DesignGrp);fflush(stdout);
			
			AOM_ask_value_string(primary_object,"t5_ProjectCode",&project_code);
			printf("\n project_code => %s\n",project_code);fflush(stdout);
			
			
			if(tc_strstr(role_Name,DesignGrp)!=NULL || tc_strstr(role_Name,"DMU_Reviewer")!=NULL)
			{
				if(strstr(projectName,project_code)==NULL)
					
				{
					printf("\n under project code matching");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Select the same project code in session user");
					return ITK_err;
				}
			}
			
			else
			{
				printf("\n  user role is  not matching");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Select the same role in session user");
				return ITK_err;
			}
		}
		else
		{
			printf("\n group is not matching");fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select the current group is ERC_Designers_Group or DMU_Reviewer ");
			return ITK_err;
		}	
	}
	
	return ifail;
		
}

extern EPM_decision_t DLLAPI assign_manager_teamreviewer(EPM_rule_message_t msg)
{
	tag_t root_task=NULLTAG;
	EPM_decision_t decision;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t *TaskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;

	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*	DocType				=NULL;
	char*	CustomRole				=NULL;
	char*	Doc_Type				=NULL;
	char*	Custom_Role				=NULL;
	char*	DocNum				=NULL;
	char*	type_name				=NULL;
	char*	Tsk_Prty_typ				=NULL;

	//char  	type_name[TCTYPE_name_size_c+1];
	//char  	Tsk_Prty_typ[TCTYPE_name_size_c+1];

	int	count,i	=	0;
	int	TskPrtycount,jkk	=	0;
	int	GroupHeadflag	=	0;
	int	TeamHeadflag	=	0;
	int	EngReviewflag	=	0;

	int ifail=0;

	EPM_ask_root_task(msg.task,&root_task);
	printf("\n assign_manager_teamreviewer:Root task found");fflush(stdout);

	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n assign_manager_teamreviewer:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n assign_manager_teamreviewer:Parent Name:%s\n",parent_name);fflush(stdout);
	if(strstr(CurrentTask,"Assign Manager and TeamReviewer")!=NULL)
	{
		EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
		printf("\n assign_manager_teamreviewer: EPM_ask_attachments of :: %d\n",count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				TCTYPE_ask_object_type (attachments[i], &objTypeTag);
				TCTYPE_ask_name2( objTypeTag,&type_name);
				printf("\n type_name ==> %s\n", type_name);fflush(stdout);
				AOM_ask_value_string(attachments[i],"item_id",&DocNum);
				printf("\n DocNum ==> %s\n", DocNum);fflush(stdout);
				if(tc_strcmp(type_name,"T5_IPRRevision")==0 || tc_strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
				{
					//printf("\n Analyst Name of task :: %s \n",AnalystName);fflush(stdout);
					//getting Participants.
					GRM_find_relation_type("HasParticipant", &task_Prty_rel_type);
					if (task_Prty_rel_type!=NULLTAG)
					{
						GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB);
						printf("\n MT: TaskCRB count: %d",TskPrtycount);fflush(stdout);
						{
							GroupHeadflag=0;
							TeamHeadflag=0;
							EngReviewflag=0;
							for(jkk=0;jkk<TskPrtycount;jkk++)
							{
								TskCRBTag = TaskCRB[jkk];
								if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
								if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
								if (tc_strcmp(Tsk_Prty_typ,"T5_GroupHead")==0)
								{
									GroupHeadflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_TeamHead")==0)
								{
									TeamHeadflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_EngReview")==0)
								{
									if(tc_strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
									{
										AOM_ask_value_string(attachments[i],"t5_DocumentType",&DocType);
										AOM_ask_value_string(attachments[i],"t5_CustomRole",&CustomRole);
										printf("\n MT: DocType: %s",DocType);fflush(stdout);
										printf("\n MT: CustomRole: %s",CustomRole);fflush(stdout);
										if((tc_strcmp(DocType,"WG")==0 || tc_strcmp(DocType,"Work GuideLine")==0)
											&& tc_strcmp(CustomRole,"Superviser")==0)
										{
											EngReviewflag=1;
										}
									}

								}
							}
						}
					}
				}
			}
			printf("\n assign_manager_teamreviewer: GroupHeadflag of :: %d\n",GroupHeadflag);fflush(stdout);
			printf("\n assign_manager_teamreviewer: TeamHeadflag of :: %d\n",TeamHeadflag);fflush(stdout);
			printf("\n assign_manager_teamreviewer: EngReviewflag of :: %d\n",EngReviewflag);fflush(stdout);

			if(EngReviewflag==0)
			{
				if(tc_strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
				{
					AOM_ask_value_string(attachments[0],"t5_DocumentType",&Doc_Type);
					AOM_ask_value_string(attachments[0],"t5_CustomRole",&Custom_Role);
					printf("\n MT: Doc_Type: %s",Doc_Type);fflush(stdout);
					printf("\n MT: Custom_Role: %s",Custom_Role);fflush(stdout);
					if((tc_strcmp(Doc_Type,"WG")==0 || tc_strcmp(Doc_Type,"Work GuideLine")==0)
						&& tc_strcmp(Custom_Role,"Superviser")==0)
					{
						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Engineer Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant->Eng Review option");
						return ITK_err;
					}

				}
			}

			if(GroupHeadflag==0)
			{
				if(tc_strcmp(type_name,"T5_IPRRevision")==0 || tc_strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign GroupHead, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant->GroupHead option");
					return ITK_err;
				}
			}

			if(TeamHeadflag==0)
			{
				if(tc_strcmp(type_name,"T5_IPRRevision")==0 || tc_strcmp(type_name,"T5_WorkInsGdLineRevision")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign TeamHead, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant->Team Head option");
					return ITK_err;
				}
			}
		}
	}

	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI check_assign_analyst_cocreviewer(EPM_rule_message_t msg)
{
	int count,i = 0;
	tag_t root_task=NULLTAG;
	EPM_decision_t decision;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t    	    propEff_tag				    =NULLTAG;

	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*  	type_name= NULL;
	char*	 AnalystName		= NULL;
	char*	 ChangReviewName		= NULL;
	int	TskPrtycount =0;
	
	int ifail=0;
		


	POM_get_user(&username,&user_tag);
	printf("\n DMLPARTY1: Starting for username :%s....\n",username);fflush(stdout);

	EPM_ask_root_task(msg.task,&root_task);
	printf("\n DMLPARTY2:Root task found");fflush(stdout);

	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n DMLPARTY3:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n DMLPARTY4:Parent Name:%s\n",parent_name);fflush(stdout);

	if(tc_strstr(CurrentTask,"Assign Analyst and Change Review Board(COC)")!=NULL)
	{
		printf("\n DMLPARTY5:DML participant Check...\n"); fflush(stdout);
		
		//printf("\n MT:.DesnGrp:%s \n",DesnGrp);fflush(stdout);
		EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
		printf("\n EPM_ask_attachments of :: %d\n",count);

		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				TskPrtycount =0;
				
				
				TCTYPE_ask_object_type (attachments[i],&objTypeTag);
				TCTYPE_ask_name2(objTypeTag,&type_name);
				printf("\n type_name ==> %s\n", type_name);fflush(stdout);
				
					printf("\n Task based HasParticipant check..... \n");fflush(stdout);
					if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
					{
						AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName);
						printf("\n Analyst Name of task :: %s \n",AnalystName);fflush(stdout);

							//Checking Analyst.
							if (tc_strcmp(AnalystName,"")==0)
							{
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option");
								return ITK_err;
							}
							
					}
					
					if(tc_strcmp(type_name,"ChangeRequestRevision")==0)
					{	

						printf("\n MT:TASK:inside Check HasParticipant.. \n");fflush(stdout);
						
						AOM_UIF_ask_value(attachments[i],"ChangeReviewBoard",&ChangReviewName);
						printf("\n\n\t\t ChangeReviewBoard  :: %s \n",ChangReviewName);fflush(stdout);
						
						//Checking COC Reviewer.
							if (tc_strcmp(ChangReviewName,"")==0)
							{
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign Change Review Board/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->Select Change Review Board");
								return ITK_err;
							}
					}
			}
		}
	}
	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI check_Wrkshp_Tool_Release_ActiveinLC(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	char*			procedure_name				= NULL;

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t *parents = NULLTAG;



	EPM_decision_t decision = EPM_go;
	int ifail=0,count,n_parents=0;

	EPM_ask_root_task(msg.task,&root_task);
	printf("\n\n\t\t Root task found for check_Wrkshp_Tool_Release_ActiveinLC"); fflush(stdout);

	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);

	EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments);
	printf("\n\n\t\t EPM_ask_attachments of :: %d",count);fflush(stdout);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
	}

	TCTYPE_ask_object_type(DMLLcmTag,&primary_obj_type_tag);
	TCTYPE_ask_name2(primary_obj_type_tag, &type_name1);
	printf("\nPrimary_object type_name is:%s",type_name1);fflush(stdout);

	if(tc_strcmp(type_name1,"ChangeRequest")==0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "ERC DML cannot submit in Lifecycle. Kindly Submit DML Revision in workflow.");
		decision = EPM_nogo;
		return decision;
	}

	EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents);
	printf("\n EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);
	EPM_ask_procedure_name2(parents[0],&procedure_name);
	printf("\n procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML Revision is already submitted in Lifecycle ... You can not submit it again.");
		decision = EPM_nogo;
	}
	else
	{
		decision = EPM_go;
	}

	return decision;
}

extern EPM_decision_t DLLAPI SignOffCheck_Validation (EPM_rule_message_t msg)
{


	  tag_t *attachments = NULLTAG;
	  tag_t *DMLRevision = NULLTAG;
	  tag_t  *secondary_objects = NULLTAG;
	  tag_t DMLLcmTag = NULLTAG;
	  char *user_name;
	  char *class_name;
	  
	  char *PartNum 				=NULL;
	  char	*tempId					=  NULL;
	  char*	username		= NULL;
	  
	  int i,j,r,k;
	  
	  int		Total_Tsk_part_Cnt	=	0;
	  int		Tsk_part_Counter =0;
	  int 		count 	=	0;
	  tag_t		Task_Part			=	NULLTAG;
	  tag_t root_task=NULLTAG;
	  tag_t   class_id            =NULLTAG;
	  tag_t	*Task_Parts			=	NULLTAG;
	  EPM_decision_t decision = EPM_go;
	  char*			parent_name				=NULL;
	  char*			CurrentTask				=NULL;

		POM_get_user_id (&username);
		printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);
		
		if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
		{
		
			EPM_ask_root_task(msg.task,&root_task);
			printf("\n\n\t\t Root task found");
			
			AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
			printf("\nCurrentTask:%s\n",CurrentTask);

			AOM_ask_value_string(root_task,"object_name",&parent_name);
			printf("\nParent Name:%s\n",parent_name);fflush(stdout);
			
			if(tc_strstr(parent_name,"Workshop Tool Task Workflow")!=NULL)
			{
				if(tc_strstr(CurrentTask,"Add solution items")!=NULL)
				{
			
					EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
					printf("\n\n\t\t EPM_ask_attachments of :: %d",count);
		
					if(count > 0)
					{
						DMLLcmTag = attachments[0];
					}
		
					POM_class_of_instance(DMLLcmTag,&class_id);
					POM_name_of_class(class_id,&class_name);
					printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);
		
					if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
					{
		
						AOM_ask_value_tags(DMLLcmTag,"CMHasSolutionItem",&Total_Tsk_part_Cnt,&Task_Parts);
						printf("\n Total_Tsk_part_Cnt :%d:", Total_Tsk_part_Cnt); fflush(stdout);
			
						if(Total_Tsk_part_Cnt>0)
						{
							for(Tsk_part_Counter=0;Tsk_part_Counter<Total_Tsk_part_Cnt;Tsk_part_Counter++)
							{
								Task_Part = Task_Parts[Tsk_part_Counter];
					
								AOM_ask_value_string(Task_Part,"item_id",&PartNum);
								printf("\n item id of part is %s",PartNum);fflush(stdout);
					
								if(tc_strlen(PartNum)==12)
								{
									tempId = (char *) MEM_alloc(10 * sizeof(char) );
									tempId= NewPartsubString(PartNum,4,4);
						
									printf("\n the value of TempId is %s",tempId);fflush(stdout);
						
									if((tc_strcmp(tempId,"5899")==0) || (tc_strcmp(tempId,"5890")==0))
									{
										printf("\n parts are matched");fflush(stdout);
										decision = EPM_go;
									}
									else
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Only  Spare kit number with 5th – 8th digits for 5899 &  special workshop tool part numbers with 5th – 8th digits for 5890 can be atatched");
										decision = EPM_nogo;
										return decision;
									}
								}
							}
						}
					}
				}
			}
		}
		//decision = EPM_go;
		return decision;
}

/****************************************************************************
Function:       MYTPE_New_IPR
Description:    This function used for register custom method/handler
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

extern int MYTPE_New_IPR(int *decision, va_list args)
{
    int          ifail = ITK_ok;
   	METHOD_id_t  method1;
   	METHOD_id_t  method2;
	METHOD_id_t  method3;
   	METHOD_id_t  method4;


	TC_argument_list_t
        *myArgs;
	//METHOD_function_t ;
	char *lov_type=NULL;
	char *DGrp=NULL;
	int i=0;
    *decision = ALL_CUSTOMIZATIONS;





	lov_type=(char *) MEM_alloc(100);
	DGrp=(char *) MEM_alloc(10);

    /* Create the method by registering the base action.
    */
	printf("\n MYTPE_New_IPR - ");fflush(stdout);
	ifail = (METHOD_find_method("T5_IPRRevision", "IMAN_save", &method2));
	ifail = (METHOD_find_method("T5_WorkInsGdLineRevision", "IMAN_save", &method1));
	ifail = (METHOD_find_method("CPThemeBoardRevision", "IMAN_save", &method3));
	ifail = (METHOD_find_method("CPThemeBoard", "IMAN_save", &method4));


    if( ifail != ITK_ok )
	{
		EMH_store_error( EMH_severity_error, ifail );
	}

	if (method2.id != NULLTAG)
	{

		printf("\nbefore Method is NewIPR_Create_postaction added now");fflush(stdout);
		ifail = ( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) NewIPR_Create_postaction, NULL));
		printf("\nafter Method is NewIPR_Create_postaction added now");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}

	if (method1.id != NULLTAG)
	{

		//printf("\nbefore Method is NewWorkInsGuide_Create_postaction added now");fflush(stdout);
		ifail = ( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) NewWorkInsGuide_Create_postaction, NULL));
		//printf("\nafter Method is NewWorkInsGuide_Create_postaction added now");fflush(stdout);
		ifail = ( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) NewWorkInsGuide_Create_pre_action, NULL));
		printf("\nafter Method is NewWorkInsGuide_Create_pre_action added now");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	
	if (method3.id != NULLTAG)
	{
		printf("\nbefore Method is strategy_doc_Create_postaction added now");fflush(stdout);
		ifail = ( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) strategy_doc_Create_postaction, NULL));
		printf("\nafter Method is strategy_doc_Create_postaction added now");fflush(stdout);
		
		printf("\nbefore Method is strategic document pre_action added now");fflush(stdout);
		ifail = ( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) strategy_doc_pre_action, NULL));
		printf("\nafter Method is strategic document_pre_action added now");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	
	if (method4.id != NULLTAG)
	{
	printf("\nbefore Method 4 is strategic document  pre condition added now");fflush(stdout);	
	ifail = ( METHOD_add_pre_condition(method4, (METHOD_function_t) strategy_doc_pre_condition, NULL));
	printf("\nafter Method is strategic document_precondition added now");fflush(stdout);
		if( ifail != ITK_ok )
		{
		EMH_store_error( EMH_severity_error, ifail );
		}
	
	}

	if( ITK_ok ==  EPM_register_rule_handler ("assign-manager-teamreviewer","Assign manager", (EPM_rule_handler_t) assign_manager_teamreviewer))
	
	if( ITK_ok ==  EPM_register_rule_handler ("assign-analyst-cocreviewer","Assign Analyst and COC", (EPM_rule_handler_t) check_assign_analyst_cocreviewer))
	
	if( ITK_ok ==  EPM_register_rule_handler ("check-Wrkshp-Tool-Release-ActiveinLC","Check Active LC", (EPM_rule_handler_t) check_Wrkshp_Tool_Release_ActiveinLC))
	
	if( ITK_ok ==  EPM_register_rule_handler ("Sign-Off-Check-Validation","Check signoff validation", (EPM_rule_handler_t) SignOffCheck_Validation))



    return ifail;
}

extern DLLAPI int tm_ipr_register_callbacks ()
{
    int ifail    = ITK_ok;
    printf("\n tm_ipr_register_callbacks:before Revise_register_callbacks");fflush(stdout);

    ifail=CUSTOM_register_exit ( "tm_ipr", "USER_init_module", (CUSTOM_EXIT_ftn_t)  MYTPE_New_IPR);
    printf("\n after calling MYTPE_New_IPR\n");fflush(stdout);

  return ( ITK_ok );
}