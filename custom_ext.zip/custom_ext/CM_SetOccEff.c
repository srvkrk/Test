/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_SetOccEff.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar		VC_Handler
* 2.	 23/06/2023				Rupali Rane				sprintf added to convert int to str
***************************************************************************/

#include "TMLLibrary_server_exits.h"

void  getcurentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int tdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

struct modstruct
 {
	   //part details

		char SapUID[100];
		char transmat[1000];

 } childstr[100];

void NextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= tdays( month, year );//calling tdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "\n CM_SetOccEff--Given date is %d:%d:%d ", day, month, year );fflush(stdout);
    printf( "\n CM_SetOccEff--Next days date is %d:%d:%d ", nd, nm, ny );fflush(stdout);
	getcurentMonth(nm,cMonth);
	printf( "\n CM_SetOccEff--cMonth:%s ", cMonth);fflush(stdout);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n CM_SetOccEff--cnextAccessDate:%s ",cnextAccessDate);fflush(stdout);
}

void CurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n CM_SetOccEff--CurrentDateTime calling.......... ");fflush(stdout);
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n CM_SetOccEff--cCurrentAccessDate:%s ",cCurrentAccessDate);fflush(stdout);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("\n CM_SetOccEff--Date:%d ",(timeptr->tm_mday));fflush(stdout);
	printf(" Month:%d ",(timeptr->tm_mon)+1);fflush(stdout);
	printf(" Year:%d ",(timeptr->tm_year+1900));fflush(stdout);
}

int CM_SetOccEff(EPM_action_message_t msg)
{
	int Flag =0;
	int ifail = ITK_ok;
	int i = 0;
	int j = 0;
	int k = 0;
	int no_attach = 0;
	int count = 0;
	int countDep = 0;

	tag_t roottask = NULLTAG;
	tag_t objTypTag = NULLTAG;
	tag_t DmlItemsRelation	= NULLTAG;
	tag_t primaryObj = NULLTAG;
	tag_t childObjTag = NULLTAG;
	tag_t ArchobjTypeTag =NULLTAG;
	tag_t ArchAssyTag =NULLTAG;
	tag_t primaryobjtype = NULLTAG;
	tag_t probj = NULLTAG;
	tag_t user_tag=NULLTAG;

	tag_t *taskAttachments	= NULLTAG;
	tag_t *SecObject = NULLTAG;
	tag_t *primary_obj = NULLTAG;
	tag_t *parents = NULLTAG;

	char* ObjTyp =NULL;
	char* Archtype_name =NULL;
	char* primaryobj_name =NULL;

	char *objecttype =NULL;
	char *objectId =NULL;
	char *objectrevId =NULL;
	char *objectdesc =NULL;
	char *objectrelstatus	=NULL;
	char *objectDRstatus =NULL;
	char *type_name =NULL;
	char *archId =NULL;
	char *OccUIDattr = NULL;

	date_t date_start = NULLDATE;
	date_t date_end = NULLDATE;

	int n_parents=0;
	int *levels = 0;

	char *username = NULL;
	char *userid = NULL;
	//EPM_decision_t decision = EPM_go;

	printf("\n CM_SetOccEff Function started...");fflush(stdout);
	TC_write_syslog("\n CM_SetOccEff Function started...");

	ifail = EPM_ask_root_task(msg.task, &roottask);
	ifail = EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments);
	printf("\n CM_SetOccEff--No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n CM_SetOccEff--******* INSIDE Attachments  ******** ");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n CM_SetOccEff--********** Workfow obj type: [%s]************* ", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				ifail = GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation);
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t CM_SetOccEff--DmlItemsRelation relation found......");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject);
					printf("\n\t CM_SetOccEff--count is : %d",count);
					if(count >0)
					{
						for(j=0;j<count;j++)
						{
						  ifail = AOM_ask_value_string(SecObject[j],"t5_PartType",&objecttype);
						  ifail = AOM_ask_value_string(SecObject[j],"item_revision_id",&objectrevId);
						  ifail = AOM_ask_value_string(SecObject[j],"item_id",&objectId);
						  ifail = AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus);

						  printf("\n CM_SetOccEff--SecObject objecttype = [%s] ",objecttype);fflush(stdout);
						  printf("\n CM_SetOccEff--SecObject objectId = [%s] ",objectId);fflush(stdout);
						  printf("\n CM_SetOccEff--SecObject objectrevId = [%s] ",objectrevId);fflush(stdout);
						  printf("\n CM_SetOccEff--SecObject objectrelstatus = [%s] ",objectrelstatus);fflush(stdout);
						  //if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && (tc_strstr(objectrevId,"NR")== NULL) && (tc_strcmp(objecttype,"M")==0 ))
						  if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && (tc_strcmp(objecttype,"M")==0 ))
						  {
	    					  if(GRM_find_relation(taskAttachments[i],SecObject[j],DmlItemsRelation,&probj));
    						  if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
							  if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
							  printf("\n CM_SetOccEff primaryobj_name -------->  :%s ", primaryobj_name);fflush(stdout);
							  if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0)
							  {
								  printf("\n\t CM_SetOccEff--Inside getting BOMUID Attr  "); fflush(stdout);
								  ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
								  printf("\n CM_SetOccEff--Set_OccUID OccUIDattr--------> :%s ",OccUIDattr);fflush(stdout);
							  }

							  if(PS_where_used_all(SecObject[j],1,&n_parents,&levels,&parents));
							  printf("\n\t CM_SetOccEff--CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
							  if(n_parents >0)
							  {
								  for (k=0;k<n_parents;k++)
								  {
									 // primaryObj=primary_obj[k];
									 //TCTYPE_ask_object_type(primaryObj,&objTypeTag);
									 // TCTYPE_ask_name2(objTypeTag,&type_name);

									 ArchAssyTag=parents[k];

									  ifail = AOM_UIF_ask_value(ArchAssyTag,"object_type",&type_name);

									  if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									  if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
									  printf("\n\t CM_SetOccEff--Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										  printf("\n\t CM_SetOccEff--Inside T5_ArchModuleRevision........");fflush(stdout);
										//									  printf( "\n type_name :%s .. ",type_name);
										//									  if (tc_strcmp(type_name,"T5_ArchModuleRevision")==0)
										//									  {

										 // childObjTag=SecObject[j];

										 ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&archId);

										  printf("\n\t CM_SetOccEff--Architecture ID is := %s", archId);fflush(stdout); //ItemRevision

										  ifail = ITEM_find_item(objectId, &childObjTag);

										  if((ArchAssyTag != NULLTAG) && (childObjTag != NULLTAG))
										  {
											  printf("\n CM_SetOccEff--To call FUNCTION...!!");fflush(stdout);
											  ifail = ITK_string_to_date("24-May-2019 00:00", &date_start);
											  ifail = ITK_string_to_date("31-Dec-9999 00:00", &date_end);

												POM_get_user(&username,&user_tag);
												SA_ask_user_identifier2	(user_tag,&userid)	;
												printf ("\n CM_SetOccEff--Logged in user:%s %s ",userid,username);fflush(stdout);
												if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0 && tc_strcmp(userid,"infodba")!=0)
												{

												  ifail = Create_occurance_effectivity(ArchAssyTag, childObjTag, date_start,date_end,OccUIDattr);
												  break;
												}
										  }
									  }
								  }
							  }
						  }
						}
					}
				}
			}
		}
	}
	printf("\n CM_SetOccEff Function end...");fflush(stdout);
	TC_write_syslog("\n CM_SetOccEff Function end...");
	//return ifail;
	return 0;
}

int Create_occurance_effectivity(tag_t primaryObj,tag_t childObjTag, date_t date_start, date_t date_end, char* OccUIDattr)
{
	int ifail = ITK_ok;
	int bvr_count = 0;
	int g = 0;
	int effcnt = 0;
	int effcnt1 = 0;
	int	in = 0;
	int iy = 0;
	int	cnt = 0;
	int	cnt1 = 0;
	int PrtRelStus_cnt;
	int ii,n;
	int n_occs=0;
	int n_occs1=0;
	int gy=0;
	int z=0;
	int noocc=0;
	int Occuidfl=0;
	int Effocc=0;
	int NRFlag =0;
	int mulocc =0;
	int incmul =0;

	date_t *Rel_start_end_values = NULL;

	char cNextDate[20]={0};
	char EffecName[200];
	char EffecName1[200];
	char EffecRange[200];
	char EffecRange1[200];

	char *mycusdate1 = NULL;
	char *dataset_name1 = NULL;
	char *child_item_id = NULL;
	char *dataset_name12 = NULL;
	char *dataset_name123 = NULL;
	char *t5Des_Rev = NULL;
	char *t5Des_Rev1 = NULL;
	char *Effeids = NULL;
	char *Effeid = NULL;
	char *tempmat=NULL;
	char *PrtRelStus = NULL;
	char *note_name = NULL;

	tag_t *bomchild=NULLTAG;
	tag_t *Effobbj=NULLTAG;
	tag_t *Effobbj1=NULLTAG;
	tag_t *Crevsn_list = NULLTAG;

	tag_t bom_window=NULLTAG;
	tag_t EffecTag = NULLTAG;
	tag_t EffecTag1 = NULLTAG;
	tag_t revTag1 = NULLTAG;
	tag_t revTag12 = NULLTAG;
	tag_t EffecTagrr = NULLTAG;
	tag_t *EffecTagrrww = NULLTAG;
	tag_t bvr = NULLTAG;
	tag_t ChildItem = NULLTAG;
	tag_t bom_rule = NULLTAG , bomtop_line = NULLTAG;
	tag_t *PrtRelStusTg     = NULLTAG;
	tag_t bvrchild = NULLTAG;
	tag_t note_type = NULLTAG;
	tag_t clientdata = NULLTAG;
	tag_t *bvrs  = NULLTAG;

	date_t test_date_1	= NULLDATE;
	date_t test_date_2	= NULLDATE;
	date_t test_date_3	= NULLDATE;
	date_t Ltest_date_2	= NULLDATE;
	date_t Ltest_date_1	= NULLDATE;
	
	WSOM_open_ended_status_t EFFECTIVITY_closed  ;
	
	char cCurrentAccessDate[20]={0};
	char	*old_to_date			= NULL;
	char	*current_to_date			= NULL;
	char	*NextDateS			= NULL;
	char	*UPdateS			= NULL;
	char	*UPdateSe			= NULL;
	char	*note_text			= NULL;

	char* EffecEnd = NULL;
	char* Effecsta = NULL;
	char* Effecsta1 = NULL;
	char* EffecEnd1 = NULL;

	char* Effecoccname = NULL;
	char* Effecid = NULL;
	char *tempmat1=NULL;
	char *Rev=NULL;
	char *itemid=NULL;
	char *subseq=NULL;

	char* EFF_OLD = NULL;
	char* EFF_CURRENT = NULL;
	char * 	id ;
	char * 	olduid =NULL;
	logical date_is_valid  ;
	logical effext  ;
	logical isalleff  ;
	tag_t  *occs=NULL;
	WSOM_effectivity_info_t** effeinf;

	date_t  *eff_dates_arr;
	date_t  *eff_dates_arr1;
	date_t  *eff_dates_arr2;
	date_t  *Lstart_end_date;


	tag_t *occsal;
	tag_t *occsal1;

	//for updation
	int	   j = 0;
	int	   Updflg = 0;
	int	   nooccret = 0;
	int	   Updcnt = 0;
	int    bl_config=0;
	int    fndid=0;
	int    uidType=0;
	int    uidTypenew=0;
	int    fndidlatest=0;
	int    Uidlatest=0;
	int	   Updchldcnt=0;
	int	   count=0;
	int    Uidkey=0;
	int xform_matrix1 = 0;
	char PartNum[300];
	char transcpy[1000];

	tag_t   window=NULLTAG;
	tag_t	rule;
	tag_t	line;

	tag_t   Updbom_window=NULLTAG;
	tag_t	Updbom_rule;
	tag_t	Updbom_line;
	tag_t  *Updbomchild=NULLTAG;
	tag_t  *child=NULLTAG;
	tag_t  uidTag=NULLTAG;
	double mat[4][4];
	//double * mat1;
	double divInt=1000;
	int imat=0;
	int jmat=0;
	int strcnt1=0;
	int strcnt2=0;
	int strcnt3=0;
	int strcnt4=0;
	int strcnt5=0;
	int strcnt6=0;
	int strcnt7=0;

	char			**child_fndid				= NULL;
	char			**child_fndid_latest				= NULL;
	char			**child_Uidlatest				= NULL;
	char			*Updchld				= NULL;
	char			*chldid				= NULL;
	char *			newuid =NULL;
	char * 			uidltswrk =NULL;
	char * 			uidocc =NULL;
	char			**child_Uidkey				= NULL;
	char **xform_matrix_str = NULL;

	char** ChildUID=NULL;
	char* EffecIdsub=NULL;
	char** ChildUIDNEW=NULL;
	char str[20];    //create an empty string to store number
	char intseqstr[20];    //create an empty string to store number
	//float number;

	char		*sep				= "_";
	char 		*test 				= (char*)MEM_alloc(sizeof(char) * 3000);
	//char		*final				= (char*)MEM_alloc(sizeof(char) * 3000);
	//const char *uid[1];

	logical bl_config_log;

	printf("\n Create_occurance_effectivity Function started...");fflush(stdout);
	TC_write_syslog("\n Create_occurance_effectivity Function started...");
	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);

	printf("\n CM_SetOccEff--bvr count is...%d",bvr_count);fflush(stdout);

	printf("\n CM_SetOccEff--Revision not found1144...!! ");fflush(stdout);

	CurrentDateTime(cCurrentAccessDate);
	printf("\n CM_SetOccEff--Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	NextDate(cNextDate);
	printf("\n CM_SetOccEff--cNextDate:%s",cNextDate);
	//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

	if(ITK_ok != (ifail = ITK_string_to_date("01-Jan-2017 00:00", &test_date_1 )))
	{
		return ifail;
	}
	if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-2099 00:00", &test_date_3 )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &test_date_2 )))
	//if(ITK_ok != (ifail = DATE_string_to_date_t(cCurrentAccessDate,&date_is_valid, &Ltest_date_2 )))
	{
		return ifail;
	}

	eff_dates_arr = (date_t*)malloc(sizeof(date_start) * 2);

	//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object   ");

	eff_dates_arr[0] = test_date_1;
	eff_dates_arr[1] = test_date_2;

	eff_dates_arr2 = (date_t*)malloc(sizeof(date_start) * 2);

	//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object   ");

	eff_dates_arr2[0] = test_date_2;
	eff_dates_arr2[1] = test_date_3;

	if(ITK_ok != (ifail = DATE_date_to_string(test_date_1,"%d-%b-%Y %H:%M", &NextDateS )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = DATE_date_to_string(test_date_2,"%d-%b-%Y %H:%M", &UPdateS )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = DATE_date_to_string(test_date_3,"%d-%b-%Y %H:%M", &UPdateSe )))
	{
		return ifail;
	}

	//ifail = ITK_date_to_string(date_start, &mycusdate1);
	//printf("\n date_start is :%s ",mycusdate1);fflush(stdout);
	//ifail = CFM_effectivity_find("Test",&EffecTag);
	//ifail = CFM_effectivity_ask_date_ranges(EffecTag,&cnt,&date_start1,&date_end1);
	//printf("\n count is...%d",&cnt);fflush(stdout);
	//ifail = ITK_date_to_string(date_start1, &mycusdate1);
	//printf("\n date_start is :%s ",mycusdate1);fflush(stdout);
	
	ifail = ITEM_ask_latest_rev(childObjTag, &revTag1);
	if (revTag1)
	{
		//NRFlag=NRFlag+1;
		ifail = AOM_ask_value_string(revTag1, "item_id", &dataset_name12);
		printf("\n CM_SetOccEff--Revi master name is first :>>>>>%s ",dataset_name12);fflush(stdout);

		ifail = AOM_ask_value_string(revTag1,"item_revision_id",&t5Des_Rev);
		printf("\n CM_SetOccEff--t5Des_Rev is first :>>>>>%s",t5Des_Rev); fflush(stdout);

		tc_strcpy(EffecName,"");
		tc_strcat(EffecName,dataset_name12);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,t5Des_Rev);
	}
	else
	{
		ifail = ITEM_ask_latest_rev(childObjTag, &revTag1);
		ifail = AOM_ask_value_string(revTag1, "item_id", &dataset_name12);
		printf("\n CM_SetOccEff--Revi master name is  :%s ",dataset_name12);fflush(stdout);

		ifail = AOM_ask_value_string(revTag1,"item_revision_id",&t5Des_Rev);
		printf("\n CM_SetOccEff--t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);

		tc_strcpy(EffecName,"");
		tc_strcat(EffecName,dataset_name12);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,t5Des_Rev);
	}

	printf("\n CM_SetOccEff--EFFECTIVITY NAME IS BEFORE EXPANSION :::>>>>>>> [%s] ",EffecName);fflush(stdout);

	//	ifail = CFM_effectivity_create(EffecName,&EffecTag);

	if (EffecTag)
	{
		printf("\n CM_SetOccEff--Revision not found11444...!! ");fflush(stdout);

		//ifail = CFM_effectivity_set_date_ranges(EffecTag,1,eff_dates_arr,eff_dates_arr1);
		//ifail = AOM_save_without_extensions(EffecTag);
		//ifail = AOM_refresh(EffecTag, 0);
	}

	//ifail = CFM_effectivity_set_date_ranges(EffecTag,1,&date_start,&date_end);

	if (bvr_count)
	{
		bvr = bvrs[0];
		// ifail =  AOM_lock( bvr );
		//  ifail =  AOM_lock( childObjTag );
		//  ifail =  AOM_lock( primaryObj );
		//printf("\nRevision not found22...!! ");fflush(stdout);

		// for getting uid
		if(BOM_create_window(&window)!=ITK_ok);
		if(CFM_find( "Latest Working", &rule )!=ITK_ok);
		if(BOM_set_window_config_rule(window,rule )!=ITK_ok);
		if(BOM_set_window_pack_all(window, false)!=ITK_ok);
		if(BOM_set_window_top_line(window, null_tag,primaryObj , null_tag, &line)!=ITK_ok);

		if(BOM_set_window_top_line_bvr(window,bvr,&line));

		if(BOM_line_ask_all_child_lines(line,&count,&child));
		printf("\n CM_SetOccEff--count::::::::>>>>>>>> %d ",count);fflush(stdout);

		for (j = 0; j<count; j++)
		{
			if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));

			printf("\n\t CM_SetOccEff--t5childitems_id in Update loop ===> :: %s <<>> %s  ",chldid,dataset_name12); fflush(stdout);

			if	(tc_strcmp(chldid,dataset_name12)==0)
			{
				ITK__convert_tag_to_uid(child[j],&uidltswrk);
				printf("\n CM_SetOccEff--uidltswrk... [%s] ",uidltswrk);fflush(stdout);

				
				if( AOM_ask_displayable_values(child[j],"bl_occ_t5_uidsap",&strcnt1,&child_fndid))PrintErrorStack();
				
				printf("\n CM_SetOccEff--child_fndid===============>>>>>>1111 %s ",child_fndid[0]);fflush(stdout);

				
				if( AOM_ask_displayable_values(child[j],"bl_occurrence_uid",&strcnt2,&ChildUID))PrintErrorStack();
				printf("\n CM_SetOccEff--ChildUID ===============>>>>>>1111 %s  ",ChildUID[0]);fflush(stdout);
				
            if(strcnt1>0&& strcnt2>0 )
            {
				if (strlen(child_fndid[0])==0)
				{
				    ifail = AOM_refresh(child[j],1);
					if( AOM_UIF_set_value(child[j],"bl_occ_t5_uidsap",ChildUID[0]));
				ifail = AOM_save_without_extensions(child[j]);
					ifail = AOM_refresh(child[j],0);
					
				}
				else
				{
					if ((tc_strstr(OccUIDattr,ChildUID[0])!= NULL))
					{
						printf("\n CM_SetOccEff--Inside comparing uid 1 ChildUID & OccUIDattr  ");fflush(stdout);

						 xform_matrix1=0;

						 
						 if( AOM_ask_displayable_values(child[j],"bl_plmxml_abs_xform",&strcnt3,&xform_matrix_str))PrintErrorStack();
						 
						 printf( "\n CM_SetOccEff--child xform matrix 11--------------> %s ",xform_matrix_str[0]);fflush(stdout);


                        if(strcnt3>0)
						{
						tc_strcpy(childstr[Occuidfl].SapUID,ChildUID[0]);
						tc_strcpy(childstr[Occuidfl].transmat,xform_matrix_str[0]);
						//childstr[p1].child=n_lines2;
						printf("\n CM_SetOccEff--structure IS: %s %s  ",childstr[j].SapUID,childstr[j].transmat);fflush(stdout);
						Occuidfl++;
						}
					}
				}
            } 
			}
		}
		printf("\n CM_SetOccEff--Occuidfl===============>>>>>> %d ",Occuidfl);fflush(stdout);

		if (Occuidfl > 0)
		{
			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );

			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				printf("\n CM_SetOccEff--Master name is  :%s ",dataset_name1);fflush(stdout);

				ITK__convert_tag_to_uid(occsal[iy],&uidocc);
				printf("\n CM_SetOccEff--uidocc... [%s] ",uidocc);fflush(stdout);

				if (tc_strstr(OccUIDattr,uidocc)!= NULL)
				{
					if(tc_strcmp(dataset_name1,dataset_name12)==0)
					{
						ifail =  AOM_lock( bvr );
						//ifail = CFM_occ_set_effectivity(bvr,occsal[iy],EffecTag);
						printf("\n CM_SetOccEff--Revision not found33...!! ");fflush(stdout);

						ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

						printf("\n CM_SetOccEff--count is...%d",effcnt);fflush(stdout);

						if (effcnt == 0)
						{
							ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);
							ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);
							ifail = AOM_save_without_extensions(EffecTag);
							ifail = AOM_refresh(EffecTag, 0);

							//ifail = PS_occ_eff_add_eff(bvr,occsal[iy],EffecTag);

							if (EffecTag)
							{
								ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);
								ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);

								printf("\n CM_SetOccEff--setting effe 2...%d",effcnt);fflush(stdout);

								//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,2,eff_dates_arr,EFFECTIVITY_closed,false);

								printf("\n CM_SetOccEff--setting effe 3...%d",effcnt);fflush(stdout);

								//ifail = AOM_refresh(bvr, 1);
								ifail = AOM_save_without_extensions(bvr);
								ifail = AOM_unlock( bvr );
								//ifail = AOM_refresh(bvr, 0);

								ifail = AOM_refresh(childObjTag, 1);
								ifail = AOM_save_without_extensions(childObjTag);
								ifail = AOM_unlock( childObjTag );
								ifail = AOM_refresh(childObjTag, 0);

								ifail = AOM_refresh(primaryObj, 1);
								ifail = AOM_save_without_extensions(primaryObj);
								ifail = AOM_unlock( primaryObj );
								ifail = AOM_refresh(primaryObj, 0);
							}
						}
						else
						{
							ifail = PS_occ_eff_ask_dates(bvr, occsal[iy], Effobbj[0], &g, &Rel_start_end_values, &EFFECTIVITY_closed);

							ifail = PS_occ_eff_ask_id(bvr,occsal[iy],Effobbj[0],&Effecid);
							printf("\n CM_SetOccEff--Effecid >>>>>>>>>>>>>> %s",Effecid);fflush(stdout);

							ifail = PS_ask_occurrence_name(bvr,Effobbj[0],&Effecoccname);
							printf("\n CM_SetOccEff--Effecoccname >>>>>>>>>>>>>> %s",Effecoccname);fflush(stdout);

							//ifail = PS_occ_eff_remove_eff(bvr,occsal[iy],Effobbj[0]);
							//ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);
							//ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);
							//ifail = AOM_save_without_extensions(EffecTag);
							//ifail = AOM_refresh(EffecTag, 0);

							if(g > 0)
							{
								if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
								{
									return ifail;
								}
								printf("\n CM_SetOccEff--Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
								
								if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
								{
									return ifail;
								}
								printf(" and  DATE_string_to_date_t.. ");fflush(stdout);
								
								if(date_is_valid != true)
								{
									printf("\n CM_SetOccEff--EFF1:date_is_valid is not true .....");fflush(stdout);
								}
								else
								{
									printf("\n CM_SetOccEff--EFF1:date_is_valid is  true .....");fflush(stdout);
									printf("\n CM_SetOccEff--Eff:cCurrentAccessDate:[%s] ",cCurrentAccessDate);fflush(stdout);

									EFF_OLD=subString(old_to_date,0,11);
									EFF_CURRENT=subString(cCurrentAccessDate,0,11);

									printf("\n CM_SetOccEff--new old andcurrent dates are:[%s %s] ",EFF_OLD,EFF_CURRENT);fflush(stdout);

									if ((tc_strcmp(EFF_OLD,EFF_CURRENT)==0))
									{
										printf("\n CM_SetOccEff--CC available Variant formula not available  "); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err, "Cannot Create Multiple Occurance on same day",dataset_name12);
										return ITK_err;
									}
								}
							}

							printf("\n CM_SetOccEff--EffecName is: >>>>>>>>>>>>>>>>>> [%s] ",EffecName);fflush(stdout);

							EffecIdsub=subString(Effecid,0,18);
							printf("\n CM_SetOccEff--Eff:EffecIdsub Value is:>>>>>>>>>>>>>>> [%s] ",EffecIdsub);fflush(stdout);
							
							if ((tc_strcmp(EffecName,EffecIdsub)==0) || (tc_strcmp(EffecName,Effecoccname)==0))
							{
								Effocc++;
							}

							//if (Effocc > 0)
							//{
							//		printf("\n INSIDE Effocc++++++++++++++  "); fflush(stdout);
							//		EMH_clear_errors();
							//		EMH_store_error_s2(EMH_severity_error,ITK_err, "Old Occurance id already exist",dataset_name12);
							//		return ITK_err;
							//}
							//if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
							//if(ITK_ok != (ifail = DATE_string_to_date_t(cCurrentAccessDate,&date_is_valid, &Ltest_date_2 )))
							//{
							//	return ifail;
							//}


							Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
							Lstart_end_date[0] = Ltest_date_1;
							Lstart_end_date[1] = Ltest_date_2;

							Effecsta=subString(old_to_date,0,11);
							EffecEnd=subString(cCurrentAccessDate,0,11);

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,Effecsta);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EffecEnd);

							printf("\n CM_SetOccEff--Eff:ctest is..:[%s]",EffecRange);fflush(stdout);

							ifail = AOM_lock( bvr );
							ifail = AOM_lock( Effobbj[0] );

							//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],Effobbj[0],2,Lstart_end_date,EFFECTIVITY_closed,true);

							ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],Effobbj[0],EffecRange,false);

							ifail = AOM_save_without_extensions(Effobbj[0]);
							ifail = AOM_refresh(Effobbj[0], 0);

							ifail = AOM_save_without_extensions(bvr);
							ifail = AOM_unlock( bvr );
							//ifail = AOM_refresh(bvr, 0);

							ifail = AOM_refresh(childObjTag, 1);
							ifail = AOM_save_without_extensions(childObjTag);
							ifail = AOM_unlock( childObjTag );
							ifail = AOM_refresh(childObjTag, 0);

							ifail = AOM_refresh(primaryObj, 1);
							ifail = AOM_save_without_extensions(primaryObj);
							ifail = AOM_unlock( primaryObj );
							ifail = AOM_refresh(primaryObj, 0);
						}

						//to handle multiple occurrence
						mulocc++;
					}
				}
			}
			printf("\n CM_SetOccEff--mulocc count is :%d ",mulocc);fflush(stdout);
			nooccret=0;

			// for adding new occurrence
			for (incmul = 0; incmul<mulocc; incmul++)
			{
				ifail = PS_list_occurrences_of_bvr( bvr,&n_occs1, &occsal1 );
				printf("\n\t CM_SetOccEff--n_occs1=======> :: %d",n_occs1); fflush(stdout);

				if(BOM_create_window(&bom_window)!=ITK_ok);
				if(CFM_find( "Latest Working", &bom_rule )!=ITK_ok);
				if(BOM_set_window_config_rule(bom_window, bom_rule )!=ITK_ok);
				if(BOM_set_window_pack_all(bom_window, false)!=ITK_ok);
				if(BOM_set_window_top_line(bom_window, null_tag,primaryObj , null_tag, &bomtop_line)!=ITK_ok);

				if(BOM_set_window_top_line_bvr(bom_window,bvr,&bomtop_line));

				ifail = ITEM_ask_latest_rev(childObjTag, &revTag12);

				if (revTag12)
				{
					ifail = AOM_ask_value_string(revTag12, "item_id", &dataset_name123);
					printf("\n CM_SetOccEff--Revi master name is  second :%s ",dataset_name123);fflush(stdout);

					ifail = AOM_ask_value_string(revTag12,"item_revision_id",&t5Des_Rev1);
					printf("\n CM_SetOccEff--t5Des_Rev is second :%s",t5Des_Rev1); fflush(stdout);

					if (mulocc==1)
					{
						tc_strcpy(EffecName1,"");
						tc_strcat(EffecName1,dataset_name123);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,t5Des_Rev1);
					}

					else if (Effocc>0)
					{
						int intseq = 0;

						itemid = tc_strtok(EffecName, "_");
						printf("\n CM_SetOccEff--Input Item_id:%s",itemid);fflush(stdout);

						Rev = tc_strtok(NULL, "_");
						printf("\n CM_SetOccEff--Input Plant:%s",Rev);fflush(stdout);

						if ((strlen(EffecName) ==18) || (strlen(EffecName) ==19))
						{
							intseq++;

							sprintf(intseqstr, "%d", intseq);
							printf("\n CM_SetOccEff--1.intseq= [%d]  string value intseqstr: [%s] ",intseq, intseqstr);fflush(stdout);

							tc_strcpy(EffecName1,"");
							tc_strcat(EffecName1,dataset_name123);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,t5Des_Rev1);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,intseqstr);
						}
						else if (tc_strstr(Rev,"NR")!=NULL)
						{
							subseq=subString(EffecName,20,21);

							intseq = atoi(subseq);
							intseq++;

							sprintf(intseqstr, "%d", intseq);
							printf("\n CM_SetOccEff--2.intseq= [%d]  string value intseqstr: [%s] ",intseq, intseqstr);fflush(stdout);

							tc_strcpy(EffecName1,"");
							tc_strcat(EffecName1,dataset_name123);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,t5Des_Rev1);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,intseqstr);
						}
						else
						{
							subseq=subString(EffecName,19,20);

							intseq = atoi(subseq);
							intseq++;

							sprintf(intseqstr, "%d", intseq);
							printf("\n CM_SetOccEff--3.intseq= [%d]  string value intseqstr: [%s] ",intseq, intseqstr);fflush(stdout);

							tc_strcpy(EffecName1,"");
							tc_strcat(EffecName1,dataset_name123);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,t5Des_Rev1);
							tc_strcat(EffecName1,"_");
							tc_strcat(EffecName1,intseqstr);
						}
					}
					else
					{
						printf("\n CM_SetOccEff--incmul count is :%d ",incmul);fflush(stdout);

						sprintf(str, "%d", incmul);
						printf("\n CM_SetOccEff--string count is :%s ",str);fflush(stdout);

						tc_strcpy(EffecName1,"");
						tc_strcat(EffecName1,dataset_name123);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,t5Des_Rev1);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,str);
					}
				}

				if(BOM_line_ask_all_child_lines(bomtop_line,&gy,&bomchild));
				printf("\n CM_SetOccEff--BOM_line_ask_all_child_lines %d ",gy);fflush(stdout);
				printf("\n CM_SetOccEff--EffecName1===============>>>>>> %s ",EffecName1);fflush(stdout);

				noocc=0;
				for (cnt = 0; cnt<gy; cnt++)
				{
					//if(bomChildobject) bomChildobject=NULLTAG;
					//bomChildobject=bomchild[iy];

					if(AOM_ask_value_string(bomchild[cnt], "bl_item_item_id", &dataset_name1));
					//printf("\n\t t5childitems_id ===> :: %s",dataset_name1); fflush(stdout);

					printf("\n\t CM_SetOccEff--t5childitems_id in 0th loop ===> :: %s,%s  ",dataset_name1,dataset_name12); fflush(stdout);

					if	(tc_strcmp(dataset_name1,dataset_name12)==0)
					{
						printf("\n\t CM_SetOccEff--t5childitems_id in 1st loop ===> :: %s,%s  ",dataset_name1,dataset_name12); fflush(stdout);

						noocc++;

						ifail = BOM_line_ask_unit_occurrence_effectivity(bomchild[cnt],false,&effext,&isalleff,&effcnt1,&effeinf);
						printf("\n\t CM_SetOccEff--effcnt1=======> :: %d",effcnt1); fflush(stdout);
					}
				}
				printf("\n\t CM_SetOccEff--noocc=======> :: %d",noocc); fflush(stdout);
				printf("\n\t CM_SetOccEff--nooccret=======> :: %d",nooccret); fflush(stdout);
				if ((noocc == 0) || (nooccret > 0))
				{
					// for getting trans matrix

					tc_strcpy(transcpy,childstr[nooccret].transmat);

					printf("\n\t CM_SetOccEff--trans before stamp=======> :: %s",transcpy); fflush(stdout);

					tempmat1=tc_strtok(transcpy," ");

					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							if(imat==0 && jmat==0)
							{
								printf("\n CM_SetOccEff--inside if"); fflush(stdout);
								mat[imat][jmat]=strtod(tempmat1,NULL);
							}
							else
							{
								printf("\n CM_SetOccEff--inside else"); fflush(stdout);
								tempmat=tc_strtok(NULL," ");
								mat[imat][jmat]=strtod(tempmat,NULL);
							}
						}
					}

					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							printf("%10lf,",mat[imat][jmat]);
						}
						printf(" ");
					}
					// end trans matrix


					ifail = AOM_lock( bvr );

					if  (PS_create_occurrences( bvr, revTag12, NULLTAG,1, &occs ));
					if(PS_set_plmxml_transform(bvr, occs[0], *mat));
					// if (PS_set_occurrence_qty(bvr, occs[0], 1));
					//  ifail = AOM_save_without_extensions(bvr);
					//  ifail = AOM_refresh(bvr,1);
					//  ifail = AOM_unlock( bvr );

					ifail = PS_occ_eff_create(bvr,occs[0],&EffecTag1);
					ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,EffecName1);

					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);


					Effecsta1=subString(cCurrentAccessDate,0,11);
					EffecEnd1=subString(UPdateSe,0,11);

					tc_strcpy(EffecRange1,"");

					tc_strcat(EffecRange1,Effecsta1);
					tc_strcat(EffecRange1," to ");
					tc_strcat(EffecRange1,EffecEnd1);

					printf("\n CM_SetOccEff--Eff:ctest is range is ..:[%s]",EffecRange1);fflush(stdout);

					ifail = PS_occ_eff_set_date_range(bvr,occs[0],EffecTag1,EffecRange1,false);

					//ifail = PS_occ_eff_set_dates(bvr,occs[0],EffecTag1,2,eff_dates_arr2,EFFECTIVITY_closed,false);

					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);

					ifail = AOM_save_without_extensions(bvr);
					ifail = AOM_refresh(bvr,1);
					ifail = AOM_unlock( bvr );

					ifail = AOM_refresh(childObjTag, 1);
					ifail = AOM_save_without_extensions(childObjTag);
					ifail = AOM_unlock( childObjTag );
					ifail = AOM_refresh(childObjTag, 0);

					ifail = AOM_refresh(primaryObj, 1);
					ifail = AOM_save_without_extensions(primaryObj);
					ifail = AOM_unlock( primaryObj );
					ifail = AOM_refresh(primaryObj, 0);

					nooccret++;
				}
				// for adding new occurrence end

				// for Updating attribute Value
				Updflg=0;
				if(BOM_create_window(&Updbom_window)!=ITK_ok);
				if(CFM_find( "Latest Working", &Updbom_rule )!=ITK_ok);
				if(BOM_set_window_config_rule(Updbom_window, bom_rule )!=ITK_ok);
				if(BOM_set_window_pack_all(Updbom_window, false)!=ITK_ok);
				if(BOM_set_window_top_line(Updbom_window, null_tag,primaryObj , null_tag, &Updbom_line)!=ITK_ok);
				if(BOM_set_window_top_line_bvr(Updbom_window,bvr,&Updbom_line));
				if(BOM_line_ask_all_child_lines(Updbom_line,&Updchldcnt,&Updbomchild));
				printf("\n CM_SetOccEff--BOM_line_ask_all_child_lines22222222222 %d ",Updchldcnt);fflush(stdout);

				for (Updcnt = 0; Updcnt<Updchldcnt; Updcnt++)
				{
					if(AOM_ask_value_string(Updbomchild[Updcnt], "bl_item_item_id", &Updchld));

					printf("\n\t CM_SetOccEff--t5childitems_id in Update loop ===> :: %s <<>> %s  ",Updchld,dataset_name12); fflush(stdout);

					if	(tc_strcmp(Updchld,dataset_name12)==0)
					{
						//setting UID
						ITK__convert_tag_to_uid(Updbomchild[Updcnt],&newuid);
						printf("\n CM_SetOccEff--newuid... [%s] ",newuid);fflush(stdout);

						
             if( AOM_ask_displayable_values(Updbomchild[Updcnt],"bl_occ_t5_uidsap",&strcnt4,&child_Uidlatest))PrintErrorStack();

						printf("\n CM_SetOccEff--child_Uidlatest===============>>>>>> %s ",child_Uidlatest[0]);fflush(stdout);

						
						
						 if( AOM_ask_displayable_values(Updbomchild[Updcnt],"bl_occurrence_uid",&strcnt5,&ChildUIDNEW))PrintErrorStack();
						printf("\n CM_SetOccEff--ChildUIDNEW ===============>>>>>> %s  ",ChildUIDNEW[0]);fflush(stdout);

						printf("\n CM_SetOccEff--child_fndid in last expansion ===============>>>>>> %s ",child_fndid[0]);fflush(stdout);

						//if(BOM_line_set_attribute_string(Updbomchild[Updcnt],Uidlatest,ChildUIDNEW[0]));
						if(strcnt5>0)
						{
					ifail = AOM_refresh(Updbomchild[Updcnt],1);
					if( AOM_UIF_set_value(Updbomchild[Updcnt],"bl_occ_t5_uidsap",ChildUIDNEW[0]));
					ifail = AOM_save_without_extensions(Updbomchild[Updcnt]);
					ifail = AOM_refresh(Updbomchild[Updcnt],0);
					
						if((childstr[Updflg].SapUID)!=NULL)
						tc_strcpy(PartNum,childstr[Updflg].SapUID);

						tc_strcpy(test,"");
						tc_strcpy(test,PartNum);
						tc_strcat(test,sep);
						tc_strcat(test,ChildUIDNEW[0]);

						Updflg++;
						

						if( AOM_ask_displayable_values(Updbomchild[Updcnt],"bl_occ_t5_uidsapkey",&strcnt6,&child_Uidkey))PrintErrorStack();
						
						printf("\n CM_SetOccEff--child_Uidkey===============>>>>>> %s ",child_Uidkey[0]);fflush(stdout);

						//if(BOM_line_set_attribute_string(Updbomchild[Updcnt],Uidkey,test));
						
						
					ifail = AOM_refresh(Updbomchild[Updcnt],1);
					if(AOM_UIF_set_value(Updbomchild[Updcnt],"bl_occ_t5_uidsapkey",test));
					ifail = AOM_save_without_extensions(Updbomchild[Updcnt]);
					ifail = AOM_refresh(Updbomchild[Updcnt],0);
						}

						// setting Attribute False
						
						if( AOM_ask_displayable_values(Updbomchild[Updcnt],"bl_occ_t5_upd_vf_form",&strcnt7,&child_fndid_latest))PrintErrorStack();
						
						printf("\n CM_SetOccEff--child_fndid_latest===============>>>>>> %s ",child_fndid_latest[0]);fflush(stdout);
                        if(strcnt7>0)
                        {
			            			if	(tc_strcmp(child_fndid_latest[0],"False")==0)
			            			{
			            				printf("\n CM_SetOccEff--child_fndid_latest value ==>>[%s] Value Update not needed ",child_fndid_latest[0]);fflush(stdout);
			            			}
			            			else
			            			{
			            				printf("\n CM_SetOccEff--child_fndid_latest value ==>>[%s] Value Changing to False ",child_fndid_latest[0]);fflush(stdout);
			            				//if(BOM_line_set_attribute_string(Updbomchild[Updcnt], fndidlatest,"False"));
											ifail = AOM_refresh(Updbomchild[Updcnt],1);
					                       if(AOM_UIF_set_value(Updbomchild[Updcnt],"bl_occ_t5_upd_vf_form","False"));
					                        ifail = AOM_save_without_extensions(Updbomchild[Updcnt]);
					                        ifail = AOM_refresh(Updbomchild[Updcnt],0);
			            				
										
			            			}
			            }
					}
					
				}

				ifail = AOM_save_without_extensions(bvr);
				ifail = AOM_refresh(bvr,1);
				ifail = AOM_unlock( bvr );

				ifail = AOM_refresh(Updbomchild[Updcnt], 1);
				ifail = AOM_save_without_extensions(Updbomchild[Updcnt]);
				ifail = AOM_unlock( Updbomchild[Updcnt] );
				ifail = AOM_refresh(Updbomchild[Updcnt], 0);

				ifail = AOM_refresh(primaryObj, 1);
				ifail = AOM_save_without_extensions(primaryObj);
				ifail = AOM_unlock( primaryObj );
				ifail = AOM_refresh(primaryObj, 0);

				// for Updating attribute Value end
			}
			MEM_free(bvrs);
			MEM_free(test);

			if(ifail == ITK_ok)
			{
				printf("\n CM_SetOccEff--Value updated...!!");fflush(stdout);
			}
		}
	}

	printf("\n Create_occurance_effectivity Function end...");fflush(stdout);
	TC_write_syslog("\n Create_occurance_effectivity Function end...");

	//return ifail;
	return 0;
}
