/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   
*  Code                 :   tm_VC_DR_status_AH.c
*  Created on			:   04/01/2024
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_VC_DR_status_AH(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *task_id		= NULL;
	char *VCDMLcommand		= NULL;
	char *VCInfo1		= NULL;
	char *VCInfo2		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     VCDR_rsltCount	= 0;
	char    *VCDR_qry_entry[1]  = {"SYSCD"};
	tag_t   *VCDRCntrlObjectTag   = NULLTAG;
	char    **VCDR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n tm_VC_DR_status_AH Function started...");fflush(stdout);
	TC_write_syslog("\n tm_VC_DR_status_AH Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n VCDRST::No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n VCDRST:: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n VCDRST:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n VCDRST:Not Found Query ControlObjects \n");fflush(stdout);
				}

				VCDR_qry_values2[0] = "VCDRST";
				if(QRY_execute(DRqryTag, DR_n_entry, VCDR_qry_entry, VCDR_qry_values2, &VCDR_rsltCount, &VCDRCntrlObjectTag));
				printf("\n VCDRST:VCDR_rsltCount:%d:", VCDR_rsltCount); fflush(stdout);
				if(VCDR_rsltCount > 0)
				{
					//ON/OFF
					if (AOM_ask_value_string(VCDRCntrlObjectTag[0],"t5_Userinfo1",&VCInfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n VCDRST:VCInfo1 is :[%s]\n", VCInfo1);fflush(stdout);
					//Path
					if (AOM_ask_value_string(VCDRCntrlObjectTag[0],"t5_Userinfo2",&VCInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n VCDRST:VCInfo2 Path: [%s]\n", VCInfo2);fflush(stdout);
					if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &task_id));
					printf("\n VCDRST:DML number-: %s ", task_id);fflush(stdout);
					if(strstr(VCInfo1,"VC001")==NULL)
					{
						if(strstr(VCInfo1,"UAPRODOFF")==NULL)
						{
							printf("\n VCDRST:UAPROD:VC DR status check. \n");fflush(stdout);
							sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/tm_VCDR_PVSH.sh %s ",task_id);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(VCInfo1,"CVPRODOFF")==NULL)
						{
							printf("\n VCDRST:CVPROD:VC DR status check \n");fflush(stdout);
							sprintf(command,"/user/cvprod/shells/DML_DCR/tm_VCDR_CVSH.sh %s ",task_id);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(VCInfo1,"CMITESTOFF")==NULL)
						{
							printf("\n VCDRST:CMITEST:VC DR status check \n");fflush(stdout);
							sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/tm_VCDR_PVSH.sh %s ",task_id);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(VCInfo1,"UADEVOFF")==NULL)
						{
							printf("\n VCDRST:UADEV:VC DR status check \n");fflush(stdout);
							sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/tm_VCDR_PVSH.sh %s ",task_id);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else
						{
							printf("\n VCDRST:Other case.. \n");fflush(stdout);
						}
					}
					else if(strstr(VCInfo1,"VC002")==NULL)
					{
						printf("\n VCDRST:PATHBase:command.. \n");fflush(stdout);
						VCDMLcommand = (char	*)MEM_alloc(500);
						tc_strcpy(VCDMLcommand,"");
						tc_strcpy(VCDMLcommand,VCInfo2);
						tc_strcat(VCDMLcommand," ");
						tc_strcat(VCDMLcommand,task_id);
						tc_strcat(VCDMLcommand," ");
						printf("\n REF:VCDMLcommand: %s \n",VCDMLcommand);fflush(stdout);
						TC_write_syslog("VCDMLcommand = %s\n",VCDMLcommand);
						system(VCDMLcommand);
						printf("\n VCDRST:PATHBase:. successfully.. \n");fflush(stdout);
					}
					else
					{
						printf("\n VCDRST:nothing.... \n");fflush(stdout);
					}
				}
			}
		}
	}
    printf("\n tm_VC_DR_status_AH Function end...");fflush(stdout);
	TC_write_syslog("\n tm_VC_DR_status_AH Function end...");
	//return error_code;
	return 0;
}