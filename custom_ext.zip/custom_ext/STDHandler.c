#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
//#define ITK_Prjerr (EMH_USER_error_base + 8)

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	printf("\n pAccessDate:%s\n",pAccessDate);

	tc_strcpy(cCurrentAccessDate,pAccessDate);
	//printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


extern EPM_decision_t DLLAPI STDHandler_Check_Func(EPM_rule_message_t msg)
{

	int status;
	EPM_decision_t dec = EPM_go;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int cnt = 0;
	char*	itemid;
	char*	ChildDml;

	char *  IsPPPPMRlzErr1 = NULL;
	char *  SetIsPPPPMRlzErr1 = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	char*	 current_name		= NULL;	
	char*	 creationdate		= NULL;	
    char*	 ClosureDate		= NULL;	
    char*	 ClosureDateDup		= NULL;	
	char   type_eff[TCTYPE_name_size_c+1];
	char  	rev_id[ITEM_id_size_c+1];
	  char  	rev_id1[ITEM_id_size_c+1];
	tag_t  	objTypeTag_eff;
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line						= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag						= NULLTAG;
	tag_t	item_rev_tag_p						= NULLTAG;
	tag_t	item_rev_task						= NULLTAG;
	tag_t	reln_type_tag						= NULLTAG;
	tag_t tsk_dml_rel_type;
	  tag_t DMLLcmTag = NULLTAG;
  tag_t DMLRevTag = NULLTAG;
     tag_t *  rev_list;
	  tag_t *DMLRevision = NULLTAG;


	tag_t	itemTypeTag_cdss					= NULLTAG;
	tag_t	itemclass							= NULLTAG;
	//tag_t	itemclassp							= NULLTAG;
	tag_t	itemclass_task						= NULLTAG;
	tag_t	itemcldclass						= NULLTAG;
	tag_t	value_child_details					= NULLTAG;
	tag_t	objTypeRefTag						= NULLTAG;
	tag_t itemcMstr = NULLTAG;

	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			task_obj_tag		= NULLTAG;
	tag_t *attachments = NULLTAG;

	int				PartCnt				= 0;
	int				taskCnt				= 0;
	int             st_count			= 0;
	int				n_refs				= 0;
	int				count1				= 0;
	WSO_description_t desc;
		tag_t			PartDmlTag				= NULLTAG;



	int				AttCnt				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			task_Tag			= NULLTAG;
	tag_t			task_rev_tag		= NULLTAG;
	tag_t			APL_item_rev_tag		= NULLTAG;


	char*			Part_no				= NULL;
	char*			Part_type			= NULL;
	char*			Part_CS				= NULL;
	char*			task_no				= NULL;
	char*			inp_task_no			= NULL;
	char			*inp_Plant			= NULL;
	char			*task_Plant			= NULL;
	char            *desid				= NULL;
	char			*dml_type			= NULL;
	char			type_name_ref[TCTYPE_name_size_c+1];
	 char *s;
	 char*	DmlId;
	 char pAccessDateDup[20];
	 char pAccessDate[20];
	 char cCurrentAccessDate[20]={0};
	 EPM_decision_t decision;



	int				task_len=0;
	int				inp_len=0;
	int				cntErr=0;

	int				ifail				= ITK_ok;
	int				 *levels			= 0;
	int	   ii=0;
	int	   jj=0;
	tag_t			*referencers		= NULLTAG;
	logical is_latest;

	char			**relations			= NULL;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
		tag_t	relation_type = NULLTAG;
			tag_t*			PartDmlTags			= NULLTAG;


	char* class_name=NULL;

   	printf("\n Inside STDHandler_Check_Func %d.....\n",iNumAttch);
	if (!SetIsPPPPMRlzErr1) MEM_free(SetIsPPPPMRlzErr1);
	SetIsPPPPMRlzErr1=(char *)MEM_alloc(1000);
	tc_strcpy(SetIsPPPPMRlzErr1,"");
	cntErr = 0;

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n STDHandler_Check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


    if(tc_strcmp(CurrentTask,"Work On DML" )==0)//workdesc
	{
 		//ITKCALL( TCTYPE_find_type("A9_APLTaskRevision", NULL, &ItemTypeTag));
 		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
			{
				tag_t objTypeTag = NULLTAG;
				tag_t objChildRevTag = NULLTAG;

				ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
				printf("\n itemid %s.....\n",itemid);		
				printf("\n\n\t\t APL DML Cre:itemid  is :%s",itemid);fflush(stdout);//task
				printf("\n itemid %s \n",itemid);
				ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
				ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
				printf("\t  type_name ...%s\n", type_name);
				if( objTypeTag == ItemTypeTag )
					{
						printf("\t \n objTypeTag == ItemTypeTag \n");

						ITKCALL (TCTYPE_ask_object_type(pTagAttch[i],&itemTypeTag_cdss));
						ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

						printf("\t  type_itemRev ...%s\n", type_itemRev);//task
						task_len=0;
						task_len=strlen(itemid);
						printf("\t  task_len ...%d\n", task_len);// length task
						inp_Plant=subString(itemid,14,task_len);
                        printf("\t  inp_Plant after  ...%s\n", inp_Plant);//task
						//if(tc_strcmp(type_itemRev,"A9_APLTaskRevision" )==0)//cmtaskit
						if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)//cmtaskit
						{

    						ITKCALL(AOM_ask_value_tags(pTagAttch[i],"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);//product plan item
							if (PartCnt>0)
							{
								GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
								for (k=0;k<PartCnt ;k++ )
								{
									const char *attrs[1];
									const char *values[1];
									int n_tags_found=0;
									tag_t	*itemclassp	= NULLTAG;
									 tag_t item = NULLTAG;
									printf("\n\n\t\t for k =:%d",k);fflush(stdout);
									AssyTag=PartTags[k];

									ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
									 attrs[0] ="item_id";
									 values[0] = (char *)Part_no;
									ITKCALL(ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found, &itemclassp));
									item = itemclassp[0];
									if(item != NULLTAG )
									ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag_p));
											
									ITK_CALL (TCTYPE_ask_object_type(item_rev_tag_p,&objTypeTag_eff));
									ITK_CALL (TCTYPE_ask_name(objTypeTag_eff,type_eff));

									printf("\n type_eff class is  ---->%s\n", type_eff);fflush(stdout);

									ITEM_ask_rev_id 	( item_rev_tag_p, rev_id);

									printf("\n rev_id is  ---->%s\n", rev_id);fflush(stdout);
									ITEM_list_all_revs  (item, &count1,  &rev_list ); 
									printf("\n\n\t\tWSOM count1:- %d\n\n",count1);
									for (ii = 0; ii < count1; ii++)
									{
										ITEM_ask_rev_id 	( rev_list[ii], rev_id1);

										printf("\n rev_id1 is  ---->%s\n", rev_id1);fflush(stdout);//diplay the previous revision

										printf("\n\n\t\t ii:%d:\n",ii);


									GRM_find_relation_type("CMHasSolutionItem",&relation_type);
									GRM_list_primary_objects_only(rev_list[ii],relation_type,&count,&PartDmlTags);

									printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
									printf("\n\n\t\t PREVIOUS REVISIOON TASK : %s",PartDmlTags);fflush(stdout);
									if(count >0)
									{
								   for (cnt=0;cnt<count ;cnt++ )
								   {
									PartDmlTag=PartDmlTags[cnt];//task pointer
									printf("\n\n\t\t INSIDE: ");fflush(stdout);

									
														
										ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
										ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
										printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
//														
									
										  //if (strcmp(type_name_ref,"A9_APLTaskRevision")==0)
										  if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
											{
												CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
												if (tsk_dml_rel_type!=NULLTAG)
												 {
													
													CALLAPI(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count1,&DMLRevision));
													printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml	
														
													for (j=0;j<count1 ;j++ )
													{	
														CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
														printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

														if(is_latest != true)
														{
															printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
														}else
														{	
															ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
															printf("\n DmlId %s.....\n",DmlId);//previous revision's task
															DMLRevTag = DMLRevision[j];//DML
															CALLAPI(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
															printf("\n\n\t\t dml is :%s\n",current_name);fflush(stdout);
															task_len=0;
															task_len=strlen(DmlId);
															task_Plant=subString(DmlId,14,task_len);
															printf("\n task_Plant is : %s\n",task_Plant);fflush(stdout);

															if(tc_strcmp(inp_Plant,task_Plant)==0)
															{
																printf("\n inside plant check is :\n");fflush(stdout);

																CALLAPI(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
																printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

																ClosureDateDup = subString(ClosureDate,0,11);
																printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
																getCurrentDateTime(cCurrentAccessDate);
																printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
																char * pAccessDateDup = subString(cCurrentAccessDate,0,11);
																printf("\n  todays date is: %s\n",pAccessDateDup);

																if (tc_strcmp(IsPPPPMRlzErr1,"NULL")==0) MEM_free(IsPPPPMRlzErr1);
																IsPPPPMRlzErr1=(char *)MEM_alloc(100);
																tc_strcpy(IsPPPPMRlzErr1,"");
																if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
																{
															
																	if(cntErr==0)
																	{																			
																		cntErr = 1;
																		
																		tc_strcat(IsPPPPMRlzErr1,"Two revision of part ");
																		tc_strcat(IsPPPPMRlzErr1,Part_no);
																		tc_strcat(IsPPPPMRlzErr1," cannot be released on same day.\n");
																		printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr1);fflush(stdout);
																		
																	}
																	else
																	{																			
																		tc_strcat(IsPPPPMRlzErr1,"Two revision of part ");
																		tc_strcat(IsPPPPMRlzErr1,Part_no);
																		tc_strcat(IsPPPPMRlzErr1," cannot be released on same day..\n");
																		cntErr=cntErr+1;
																		printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr1);fflush(stdout);
																	}
												
																	}
																				
																}
																printf("\n cntErr: %d\n",cntErr);fflush(stdout);

																if(cntErr==1)
																{
																	tc_strcpy(SetIsPPPPMRlzErr1,IsPPPPMRlzErr1);
																}
																else
																{
																	tc_strcat(SetIsPPPPMRlzErr1,IsPPPPMRlzErr1);
																}

														}

//															

																
												}
											  }

										  }
								
				
							  }
					 }	
				}

	  
			}

									printf("\n SetIsPPPPMRlzErr: %s\n",SetIsPPPPMRlzErr1);fflush(stdout);
									printf("\nstrlen(IsPPPPMRlzErr):%d",strlen(SetIsPPPPMRlzErr1));fflush(stdout);
									if(strlen(IsPPPPMRlzErr1)>0)
									{
										printf("\n inside error message  %s \n",SetIsPPPPMRlzErr1);
										EMH_clear_errors();
										status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetIsPPPPMRlzErr1);
										decision = EPM_nogo;
										return ITK_errStore;
									}
									else
									{
										decision = EPM_go;
									}
								}
							
			
			         }
	         }	    
	
	
		}
}

	return decision;
}
	

extern int TwoRevisionReleasedOnSameDay(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

  
	if( ITK_ok == EPM_register_rule_handler ("Two_Revision_released_OnSameDay_Check","This Handler is used to display message",(EPM_rule_handler_t)STDHandler_Check_Func))
   {
		printf("\t\n inside TwoRevisionReleasedOnSameDayCheck:Rulehandler\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler TwoRevisionReleasedOnSameDayCheck\n");fflush(stdout);
   }

    return ITK_ok;
}

extern DLLAPI int STDHandler_register_callbacks()
{
	 CUSTOM_register_exit("STDHandler", "USER_init_module", (CUSTOM_EXIT_ftn_t)TwoRevisionReleasedOnSameDay);

     printf("\n inside TwoRevisionReleasedOnSameDayCheck:registered\n");	fflush(stdout);

	 return ( ITK_ok );
}
