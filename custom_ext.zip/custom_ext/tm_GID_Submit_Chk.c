/******************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :  Prasad Sagare
*  Module               :   
*  Code                 :   
*  Created on			:   24-04-2024
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*********************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

#define ECU_err 919002

EPM_decision_t tm_GID_Submit_Chk(EPM_rule_message_t msg)
{
	int i =  0;
	int no_attach	=  0;
	int DR_n_entry		= 1;
	int DR_rsltCount	= 0;
	int error_code	= ITK_ok;
	char *sDMLReltyp	= NULL;
	char *sDMLSUBInfo1	= NULL;
	char *DMLRlztp		= NULL;
	char *sDMLno		= NULL;
	char* CurrentTask	= NULL;
	char* ObjTyp= NULL;
	char *DR_qry_entry[1] = {"SYSCD"};
	char **DR_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t objTypTag = NULLTAG;
	tag_t DRqryTag = NULLTAG;
	tag_t roottask = NULLTAG;
	tag_t *DRCntrlObjectTag = NULLTAG;
	tag_t *taskAttachments = NULLTAG;

	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_GID_Submit_Chk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_GID_Submit_Chk Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n DMLSUB:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n DMLSUB: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
				printf("\n sDMLno:%s.",sDMLno);fflush(stdout);
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n DMLSUB:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n DMLSUB:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "GroupIDDML";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n GroupIDDML:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//PO bypass
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&sDMLSUBInfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n GroupIDDML:  sDMLSUBInfo1:%s\n",sDMLSUBInfo1);fflush(stdout);
					if(strstr(sDMLSUBInfo1,"GID001")==NULL)
					{
						if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&sDMLReltyp)!=ITK_ok)PrintErrorStack();
						printf("\n GroupIDDML:sDMLReltyp:%s.",sDMLReltyp);fflush(stdout);
						DMLRlztp = MEM_alloc(100);
						tc_strcpy(DMLRlztp,"");
						tc_strcpy(DMLRlztp,",");
						tc_strcat(DMLRlztp,sDMLReltyp);
						tc_strcat(DMLRlztp,",");
						printf("\n GroupIDDML::DMLRlztp.:%s \n",DMLRlztp);fflush(stdout);
						if(tc_strstr(sDMLSUBInfo1,DMLRlztp) == NULL)
						{
							printf("\n GroupIDDML::DML submition not alowed.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:This release type of DML if not allowed to submit to 'Group ID Release' or 'IFD Release Workflow' workflow.\n Please ensure DML Release Type and Workflow Template Name.\n If still any query, please raise ticket in TMS under DML workflow category.",sDMLno);	
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							printf("\n GroupIDDML:Allow to submit this DML type.. \n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	
	/*	if(CurrentTask){MEM_free(CurrentTask);}
	if(sDMLno){MEM_free(sDMLno);}
	if(sDMLSUBInfo1){MEM_free(sDMLSUBInfo1);}
	if(sDMLReltyp){MEM_free(sDMLReltyp);}*/
	printf("\n tm_GID_Submit_Chk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_GID_Submit_Chk Function end...");
	return decision;
}