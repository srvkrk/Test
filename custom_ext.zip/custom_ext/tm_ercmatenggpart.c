/****************************************************************************************************
*  File            :   tm_ercmatenggpart.c
*  Created By      :   Alokesh Ghosh
*  Created On      :   28-July-2022
*  Purpose         :   Used for ERC-Material Engineering Part Creation
******************************************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>


#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextMinute(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays,Hour,Minute,nHr,nMin;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;

	struct tm *timeptr1;
	char pAccessDate[30];
	char pAccessDate1[30];
	char cMonth[30];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	strHr[20];
	char	strMin[20];

	temp = time(NULL);
	struct tm* timeptr;
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);

	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);


	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	Hour=(timeptr->tm_hour);
	Minute=(timeptr->tm_min);


	printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);

	ny= year;
	nm= month;
	nd= day;
	nHr=Hour;
	if (Minute==59)
	{
		if (Hour==23)
		{
			nHr=0;
			nMin=0;
			ndays= days( month, year );//calling days function
			if( ++nd > ndays )
			{
			   nd= 1;
			   if ( ++nm > 12 )
			   {
				 nm= 1;
				 ++ny;
				}
			}
		}
		else
		{
			nHr=Hour+1;
			nMin=0;
		}
	}
	else
	{
		nMin=Minute+1;
	}
    printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);
    printf( "Next days date is %d:%d:%d  %d:%d\n", nd, nm, ny ,nHr,nMin);

	sprintf(strDay,"%d",nd);
	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);
	sprintf(strHr,"%d",nHr);
	sprintf(strMin,"%d",nMin);

	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,strHr);
	tc_strcat(cnextAccessDate,":");
	tc_strcat(cnextAccessDate,strMin);
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int tm_validate_matenggprtCrte( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	
	if(new_item != NULLTAG && isnew ==1)
	{
		char *prjCode = NULL;
		char *matNo = NULL;
		char *matGrd = NULL;
		char *suppNo = NULL;
		char *suppGrd = NULL;
		char *partNo = NULL;
		char *prtType = NULL;
		char *projNumStr = NULL;
		char* username;
        tag_t user_tag=NULLTAG;
		tag_t ProjectNum = NULLTAG;
		int Rolflag = 0;
		char *item_id = NULL;
		tag_t primary_item         = NULLTAG;
		
		if( AOM_ask_value_string( new_item, "t5_ProjectCode", &prjCode)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_PartType", &prtType)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngMatNo", &matNo)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngMatGrd", &matGrd)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngSuppNo", &suppNo)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngSuppMatGrd", &suppGrd)!=ITK_ok) PrintErrorStack();
		
		if(prjCode == NULL || matNo == NULL || matGrd == NULL || suppNo == NULL || suppGrd == NULL || prtType == NULL){
			printf("\nPlease enter all madetory fields"); fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Please enter all mandatory data");
			return ITK_err;
		}
		else{
			if(tc_strcmp(prjCode, "") == 0 || tc_strcmp(matNo, "") == 0 || tc_strcmp(matGrd, "") == 0 || tc_strcmp(suppNo, "") == 0 || tc_strcmp(suppGrd, "") == 0 || tc_strcmp(prtType, "") == 0)
			{
				printf("\nPlease enter all madetory fields"); fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Please enter all mandatory data");
				return ITK_err;
			}
		}
		
		if(tc_strcmp(prtType, "D") != 0)
		{
			printf("\nPart type must be Dummy"); fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Part type must be Dummy");
			return ITK_err;
		}
		
		if(tc_strcmp(prjCode, "2926") != 0)
		{
			printf("\nProject Code Not allowed"); fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Project must be : 2926");
			return ITK_err;
		}
		if ((POM_get_user(&username,&user_tag))!=ITK_ok)PrintErrorStack();
		if ((SA_ask_current_project(&ProjectNum))!=ITK_ok)PrintErrorStack();
		if(ProjectNum !=NULLTAG)
		{
			if (AOM_ask_value_string(ProjectNum,"object_name",&projNumStr)!=ITK_ok)PrintErrorStack();
			printf("\nProject for login user session : %s\n",projNumStr);fflush(stdout);
			
			if ((strcmp(projNumStr,"2926")!=0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Project Code. kindly get access from TCUA Admin and set same project in session details");
				return ITK_err;
			}
		}					
		else if((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Project Code. kindly get access from TCUA Admin and set same project in session details");
			return ITK_err;
		}
						
		partNo = (char	*)MEM_alloc(100);
		tc_strcpy(partNo, prjCode);
		tc_strcat(partNo, matNo);
		tc_strcat(partNo, matGrd);
		tc_strcat(partNo, suppNo);
		tc_strcat(partNo, suppGrd);
		
		tag_t	Cntl_obj_Qtag11	=	NULLTAG;
		char *qry_entries11[2] = {"Type","Item ID"};
		char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
		int resultCount11=0;
		tag_t *qry_cntrlobj11= NULLTAG;
		if(QRY_find2("Item...", &Cntl_obj_Qtag11)) PrintErrorStack();
		qry_values11[0] = "ERC Material Engineering Part" ;
		qry_values11[1] = partNo ;
		if(QRY_execute(Cntl_obj_Qtag11, 2, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11)) PrintErrorStack();
		printf("\n ERC Material Engineering Part count---------->%d\n",resultCount11); fflush(stdout);
		if(resultCount11>0)
		{
			printf("\nThis part already exists"); fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err, "This part number already exists");
			return ITK_err;
		}

		char *oojname = NULL;
	    oojname = (char	*)MEM_alloc(100);
	    tc_strcpy(oojname, partNo);
        tc_strcat(oojname,"/");
        tc_strcat(oojname,"NR;1");
		
		if(ITEM_ask_item_of_rev(new_item, &primary_item)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string( primary_item, "item_id", &item_id)!=ITK_ok) PrintErrorStack();
		printf("\nMaster Item : %s\n",item_id); fflush(stdout);
		printf("\nFinal Part Number: %s\n",partNo); fflush(stdout);
		if(AOM_lock(primary_item)) PrintErrorStack();
		if(AOM_set_value_string(primary_item, "item_id", partNo)!=ITK_ok) PrintErrorStack();
		if(AOM_save_with_extensions(primary_item)) PrintErrorStack();
		if(AOM_unlock(primary_item)) PrintErrorStack();
		if(AOM_refresh(primary_item,1))PrintErrorStack();
		
		
		char *projcodeList=NULL;
		char *projcode=NULL;
		tag_t   projobj1;
		if( AOM_ask_value_string(new_item,"project_ids",&projcodeList)==ITK_ok)
		if( AOM_ask_value_string(new_item,"t5_ProjectCode",&projcode)==ITK_ok)
		printf("\n Save Validation 10 Project : <%s> ProjectList : <%s> %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n Save Validation 10 Project is  NULL \n");fflush(stdout);
			}
			else
			{
				printf("\n Save Validation 10 TCDCProject from Object in else : %s\n",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();

				if(projobj1 != NULLTAG)
				{
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&new_item )!=ITK_ok)PrintErrorStack();
					printf("\n Save Validation 10 Assigned to Project\n");fflush(stdout);
				}
				else
				{
					printf("\n Save Validation 10 Project not found\n");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n Projectlist already assigned Project : <%s> ProjectList : <%s>\n",projcode,projcodeList);fflush(stdout);
		}
		
		tag_t attr_id ;
		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();
		if(AOM_ask_value_string( new_item, "item_revision_id", &item_id)!=ITK_ok) PrintErrorStack();
		printf("\n Item Revision : %s\n",item_id); fflush(stdout);
		if(AOM_lock(new_item)) PrintErrorStack();
		if(POM_set_attr_string(1,&new_item,attr_id,"NR;1")) PrintErrorStack();
		if(AOM_set_value_int(new_item,"sequence_id",1)) PrintErrorStack();
		if(AOM_save_with_extensions(new_item)) PrintErrorStack();
		if(AOM_unlock(new_item)) PrintErrorStack();
		if(AOM_refresh(new_item,1))PrintErrorStack();
		
		tag_t		status_rel             = NULLTAG;
		logical		retain					= 0;
		//if (CR_create_release_status2("ERC Review",&status_rel))PrintErrorStack();
		if(RELSTAT_create_release_status("ERC Review", &status_rel)) PrintErrorStack();
	    //if(EPM_add_release_status(status_rel,1,&new_item,retain))PrintErrorStack();
	    if(RELSTAT_add_release_status(status_rel, 1, &new_item, retain)) PrintErrorStack();
		
	}
	return ifail;
}

int tm_create_matenggprtCrte( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	logical is_reserved    = 0;
	
	if(new_item != NULLTAG && isnew ==1)
	{
		char *prjCode = NULL;
		char *matNo = NULL;
		char *matGrd = NULL;
		char *suppNo = NULL;
		char *suppGrd = NULL;
		char *partNo = NULL;
		char *item_id = NULL;
		tag_t primary_item         = NULLTAG;
		
		if( AOM_ask_value_string( new_item, "t5_ProjectCode", &prjCode)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngMatNo", &matNo)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngMatGrd", &matGrd)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngSuppNo", &suppNo)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string( new_item, "t5_MatEngSuppMatGrd", &suppGrd)!=ITK_ok) PrintErrorStack();
						
		partNo = (char	*)MEM_alloc(100);
		tc_strcpy(partNo, prjCode);
		tc_strcat(partNo, matNo);
		tc_strcat(partNo, matGrd);
		tc_strcat(partNo, suppNo);
		tc_strcat(partNo, suppGrd);
		
		char *oojname = NULL;
	    oojname = (char	*)MEM_alloc(100);
	    tc_strcpy(oojname, partNo);
        tc_strcat(oojname,"/");
        tc_strcat(oojname,"NR;1");
		
		tag_t relation_type = NULLTAG;
		tag_t *attachments = NULLTAG;
		char *ObjectClassType = NULL;
		char *ObjectName = NULL;
		int count = 0;
		int ij = 0;
		int cnt = 0;
		tag_t dataset = NULLTAG;

		if(GRM_list_secondary_objects_only(new_item,relation_type,&cnt,&attachments))PrintErrorStack();
		for(ij=0;ij<cnt;ij++)
        {
        	dataset = attachments[ij];
	        if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
	        printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

	        if (strcmp(ObjectClassType,"T5_MatEnggPartRevisionMaster")==0)
	        {
                if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
                printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);

                if(AOM_lock(dataset)) PrintErrorStack();
                if(AOM_set_value_string(dataset, "object_name", oojname)!=ITK_ok) PrintErrorStack();
				if(AOM_save_with_extensions(dataset)) PrintErrorStack();
				if(AOM_unlock(dataset)) PrintErrorStack();
				if(AOM_refresh(dataset,1))PrintErrorStack();
				break;
            }
        }

        if(GRM_list_secondary_objects_only(primary_item,relation_type,&cnt,&attachments))PrintErrorStack();
		for(ij=0;ij<cnt;ij++)
        {
        	dataset = attachments[ij];
	        if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
	        printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

	        if (strcmp(ObjectClassType,"T5_MatEnggPartMaster")==0)
	        {
                if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
                printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);

                if(AOM_lock(dataset)) PrintErrorStack();
                if(AOM_set_value_string(dataset, "object_name", oojname)!=ITK_ok) PrintErrorStack();
				if(AOM_save_with_extensions(dataset)) PrintErrorStack();
				if(AOM_unlock(dataset)) PrintErrorStack();
				if(AOM_refresh(dataset,1))PrintErrorStack();
				break;
            }
        }
					
	}
		
	return ifail;
}

extern EPM_decision_t DLLAPI assign_anlst_reviwer_matengg(EPM_rule_message_t msg)
{
	int count,i = 0;
	tag_t root_task=NULLTAG;
	EPM_decision_t decision;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;

	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*  	type_name = NULL;
	int ifail=0;
	char*	 DMLno		= NULL;
	char*	 DMLtp		= NULL;
	tag_t *DmlCRB = NULLTAG;
	tag_t ObjTypDmlCRB = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t dml_Prty_rel_type = NULLTAG;
	int jk =0;
	int Tskcount =0;
	int TskPrtycount =0;
	int Prtycount =0;
	int DMUFlag =0;
	int VIFlag = 0;
	int BOMFlag = 0;
	int PrincipleEngFlag = 0;
	char*   Prty_typ = NULL;

	POM_get_user(&username,&user_tag);
	printf("\n\t Starting for username :%s....\n",username);fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\t Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);
	
	if(strstr(CurrentTask,"Assign Analyst and DMU Reviewer")!=NULL)
	{
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);

		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {
			TskPrtycount =0;
			Prtycount =0;
			Tskcount =0;
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n type_name ==> %s\n", type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(attachments[i],"t5_rlstype",&DMLtp));
				printf("\n MT:DMLtp:%s\n",DMLtp);	fflush(stdout);

				CALLAPI(GRM_find_relation_type("HasParticipant", &dml_Prty_rel_type));
				if (dml_Prty_rel_type!=NULLTAG)
				{
					printf("\n MT:inside Check HasParticipant.. \n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(attachments[i],"item_id",&DMLno));
					printf("\n MT: DMLno:%s DMLtp:%s\n",DMLno,DMLtp);	fflush(stdout);

					CALLAPI(GRM_list_secondary_objects_only(attachments[i],dml_Prty_rel_type,&Prtycount,&DmlCRB));
					printf("\n MT: DmlCRB count: %d",Prtycount);fflush(stdout);
					if(Prtycount > 0)
					{
						VIFlag=0;
						BOMFlag=0;
						PrincipleEngFlag=0;
						for (jk=0;jk<Prtycount ;jk++ )
						{
							DmlCRBTag = DmlCRB[jk];
							if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
							if(TCTYPE_ask_name2(ObjTypDmlCRB,&Prty_typ));
							if (tc_strcmp(Prty_typ,"T5_DMUReviewer")==0)
							{
								DMUFlag = 1;
								printf("\n\n----------------------- T5_DMUReviewer Found\n\n"); fflush(stdout);
							}
						}
					}
				}
				
				if(DMUFlag == 0){
					EMH_store_error_s1(EMH_severity_error,ITK_err,"DMU reviewer not assigned to the DML, \nPlease assign the DMU Reviewer. \nUse: Select DML : Tools->Assign Participant->Select DMU Reviewer");
					return ITK_err;
				}
				
			}
		  }
		}
	}
	
	decision = EPM_go;
	return decision;
}

extern int erc_mat_engg_register_method(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	tag_t objTag = va_arg(args, tag_t); 
	METHOD_id_t  matengg_iman_save;
	
	if( ITK_ok ==  EPM_register_rule_handler ("assign-anlst-reviwer-matengg","Assign Analyst", (EPM_rule_handler_t) assign_anlst_reviwer_matengg))
   {
		printf("\t\n Registered rule  Handler assign-anlst-reviwer\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler assign-anlst-reviwer\n");fflush(stdout);
   }
	
	/* Overriding IMAN_Save of ERC Mat Engg Part  */	
    if ( METHOD_find_method("T5_MatEnggPartRevision", "IMAN_save", &matengg_iman_save) != ITK_ok) PrintErrorStack();	
	if (matengg_iman_save.id != NULLTAG)
    {	
		int ifail    = ITK_ok;
		//printf("\n before Rigister pre_action tm_validate_matenggprtCrte");fflush(stdout);
		ifail=METHOD_add_action(matengg_iman_save, METHOD_pre_action_type,(METHOD_function_t)tm_validate_matenggprtCrte,NULL);
		//printf("\n  After Rigister pre_action tm_validate_matenggprtCrte");fflush(stdout);
		
		//printf("\n before Rigister post_action tm_create_matenggprtCrte");fflush(stdout);
		ifail=METHOD_add_action(matengg_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_create_matenggprtCrte,NULL);
		//printf("\n  After Rigister post_action tm_create_matenggprtCrte");fflush(stdout);
		return ifail;
    }
	else
	{
		printf("\n T5_MatEnggPartRevision is not found");fflush(stdout);
	}
	/* End overriden */
	
	return ifail;
}

extern DLLAPI int tm_ercmatenggpart_register_callbacks ()
{
	int ifail    = ITK_ok;
	//printf("\n Before register userservice....tm_ercmatenggpart");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ercmatenggpart", "USER_init_module", (CUSTOM_EXIT_ftn_t)erc_mat_engg_register_method);
	//printf("\n After register userservice....tm_ercmatenggpart");fflush(stdout);
	return ( ifail );
}
