/********************************************************************************************************
*  File			: Set_OccUID.c
*  Created By	: Abhilash
*  Created On	: 08-Jan-2019
*  Project		: TCUA 	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
					(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
					(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

extern DLLAPI int Set_OccUID(METHOD_message_t *msg, va_list args)
{
	int ifail				= ITK_ok;
	int k					= 0;
	int l					= 0;
	int m					= 0;
	int jd					= 0;
	int n_BL				= 0;
	int num					= 0;
	int Uidlatest			= 0;
	int BLid			= 0;
	int n_parents			= 0;
	int *levels				= 0;
	int    fndid=0;
	
	tag_t  primary_object			= va_arg(args, tag_t);
	tag_t  secondary_object			= va_arg(args, tag_t);
	tag_t  relation_type			= va_arg(args, tag_t);

	tag_t  objTypeTag				= NULLTAG;
	tag_t  objTypeTag1				= NULLTAG;
	tag_t  RelationType				= NULLTAG;
	tag_t  *sec_obj					= NULLTAG;
	tag_t  secondaryobj				= NULLTAG;
	tag_t  secondaryobjtype			= NULLTAG;

	char   *objname					= NULL;
	char   *objid					= NULL;
	char   *OccUIDattr				= NULL;
	char   *OccUIDflag				= NULL;
	char   *chdesc					= NULL;
	char   *Part_type				= NULL;
	char   **BOMOccUid				= NULL;
	char   **BOMOccUid1				= NULL;
	char   *Arch_obj				= NULL;
	char   *child_fndid				= NULL;
	char   *ErrorText				= NULL;

	char*	type_name= NULL;
	char*	type_name1= NULL;
	char*	relation_name= NULL;
	char*    Archtype_name= NULL;

	// BOM LINE
	tag_t *children1				= NULL;
	tag_t *parents					= NULL;
	tag_t window					= NULLTAG;
	tag_t rule						= NULLTAG;
	tag_t top_line					= NULLTAG;
	tag_t Childobject				= NULLTAG;
	tag_t ArchAssyTag				= NULLTAG;
	tag_t ArchobjTypeTag			= NULLTAG;

	//user details 
	char *username;
	char *userid;
	tag_t user_tag=NULLTAG;
		char			**BOMBLid				= NULL;
	
	int suffixCnt=0;
	int strcnt1=0;
	int strcnt2=0;
	char **CompCodeData = (char **) MEM_alloc(1 * sizeof(char *));
	BOMOccUid1= (char *) MEM_alloc (100);


	printf("\n Set_OccUID Function started...");fflush(stdout);
	TC_write_syslog("\n Set_OccUID Function started...");

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n Set_OccUID type_name -------->  : %s\n", type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_ModuleVF_to_Change")==0) 
	{
		ifail = AOM_UIF_ask_value(primary_object,"t5_Occurance_UID",&OccUIDattr);
		printf("\n Set_OccUID OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);

		ifail = AOM_UIF_ask_value(primary_object,"t5_Occcurance_Flag",&OccUIDflag);
		printf("\n Set_OccUID OccUIDflag--------> :%s\n",OccUIDflag);fflush(stdout);
		
//		if(tc_strcmp(OccUIDflag,"True")==0)
//		{
//			printf("\n\t bypasssssssssssss \n"); fflush(stdout);
//			ifail = AOM_lock( primary_object );
//			ifail = AOM_UIF_set_value(primary_object,"t5_Occcurance_Flag","False");
//			ifail = AOM_save_without_extensions(primary_object);
//			ifail = AOM_refresh(primary_object,1);
//			ifail = AOM_unlock( primary_object );
//		}
//		else if(tc_strcmp(OccUIDflag,"False")==0)
//		{
//			POM_get_user(&username,&user_tag);
//			SA_ask_user_identifier2	(user_tag,&userid)	;
//			printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
//			if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0)
//			{
//				printf("\n Set_OccUID Inside because OccUIDflag--------> :%s NOT Allowed\n",OccUIDflag);fflush(stdout);
//				EMH_clear_errors();
//				EMH_store_error_s2(EMH_severity_error,ITK_err,"Cannot update Module (VF Change) Relation","Please contact to DML support team if you want to make changes in Module (VF Change) Relation");
//				return ITK_err;
//			}
//		}
//		else if (tc_strlen(OccUIDflag) == 0)
//		//else
//		{
			ifail = GRM_ask_secondary (primary_object,&secondaryobj);
			if (TCTYPE_ask_object_type(secondaryobj,&secondaryobjtype)!=ITK_ok);
			if (TCTYPE_ask_name2(secondaryobjtype,&type_name1)!=ITK_ok);
			printf("\n Set_Chasis_details type_name1 -------->  :%s\n", type_name1);fflush(stdout);
			if(tc_strcmp(type_name1,"Design Revision")==0) 
			{
				ifail = AOM_UIF_ask_value(secondaryobj,"item_id",&objid);
				printf("\n Set_OccUID objid-------> :[%s]\n",objid);fflush(stdout);
				ifail = AOM_UIF_ask_value(secondaryobj,"t5_PartType",&Part_type);
				printf("\n Set_OccUID Part_type--------> :[%s]\n",Part_type);fflush(stdout);
				if(strcmp(Part_type,"Module")==0)
				{
					if(PS_where_used_all(secondaryobj,1,&n_parents,&levels,&parents));
					printf("\n\t Set_OccUID where_used--------> : %d",n_parents); fflush(stdout);
					if(n_parents>0)
					{
						for (jd=0;jd<n_parents;jd++ )
						{
							ArchAssyTag=parents[jd];
							if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
							printf("\n\tSet_OccUID Architecture Arch_obj---------> :%s",Arch_obj);	fflush(stdout);

							if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
							if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name))PrintErrorStack();
							printf("\n\t Set_OccUID Archtype_name---------> : %s", Archtype_name);fflush(stdout);
							if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
							{
								printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
								if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
								if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
								if(top_line!=NULLTAG)
								{
									if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
									printf("\n\tSet_OccUID No of child objects are n : %d",n_BL);fflush(stdout);
									if (n_BL >0)
									{
										for (l=0;l<n_BL ;l++ )
										{
											if(Childobject) Childobject=NULLTAG;
											Childobject=children1[l];

											
											if( AOM_ask_displayable_values(Childobject,"bl_item_item_id",&strcnt1,&BOMBLid))PrintErrorStack();
											
											printf("\n BOMBLid===============>>>>>> %s\n",BOMBLid[0]);
											printf("\n objid=================>>>>>> %s\n",objid);
									    if(strcnt1>0)
									    {
											if(tc_strcmp(BOMBLid[0],objid)==0)
											{											
		//										if(AOM_ask_value_strings(Childobject,"bl_occ_t5_uidsap",&num,&BOMOccUid))PrintErrorStack();
		//										printf("\n\tSet_OccUID num-------> :: %s\n",num); fflush(stdout);
		//										if (num > 0)  
		//										{
		//											for (m=0;m<num;m++ )
		//											{
		//											}
		//										}
												
												
												
												if( AOM_ask_displayable_values(Childobject,"bl_occ_t5_uidsap",&strcnt2,&BOMOccUid1))PrintErrorStack();
												printf("\n BOMOccUid1===============>>>>>> %s\n",BOMOccUid1[0]);
												if(strcnt2>0)
												{
												setAddStr(&suffixCnt,&CompCodeData,BOMOccUid1[0]);

												printf("\n\tSet_OccUID BOMOccUid -------> :: %s\n",BOMOccUid1[0]); fflush(stdout);
												ifail = AOM_lock( primary_object );
												ifail = AOM_set_value_strings(primary_object,"t5_Occurance_UID",suffixCnt,CompCodeData);
												if(ifail != ITK_ok)
                                                   {
                                                    ITK_CALL(AOM_unlock(primary_object));
                                                   EMH_ask_error_text(ifail,&ErrorText);
                                                   }
                                                   else
                                                   {
                                                   ITK_CALL(AOM_save_without_extensions(primary_object));
                                                   ITK_CALL(AOM_refresh(primary_object,0));
                                                   ITK_CALL(AOM_unlock(primary_object));
                                                   }
												}
												
											}
										}
										}
									}
								}
							}
						}
					}
				}
			}
		//}
	}
	printf("\n Set_OccUID Function end...");fflush(stdout);
	TC_write_syslog("\n Set_OccUID Function end...");
	//return ifail;
	return 0;
}
