/*******************************************************************************************
*
*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*  01	   19.4.22   -      Prasad				Uploaded Data from Bhaskar Folder to DV
*
********************************************************************************************/

extern DLLAPI int  SnapShotFormSave(METHOD_message_t *msg, va_list args)
	{
		int error_code = ITK_ok;
		tag_t	objTag = va_arg(args, tag_t);
		//logical flag = va_arg(args, logical);
		tag_t	item_tag = NULLTAG;
		int		i=0,j=0,k=0,kl=0,status=ITK_ok;
        int		found,Dcrcnt = 0;
        int		ifail=0;
        int		Refcount=0;
		tag_t	RefRel_tag =NULLTAG;
        int		Itemscnt=0;
        int		dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
        int		DcrItemscnt=0;
        int		attachmentCount=0,qryRetCnt=0;
        int    n_bom_views=0;
        int    bom_view_index=0;
        int    noAttachment=0;

        char	*obj_type=NULL;
        char*    FileDown    =NULL;
        char*    filename    =NULL;
        char	*dmlNumber=NULL;
        char	*revId=NULL;
        char	**qryEntries=NULL;
        char	**qryValues=NULL;
        char	*Platform=NULL;
        char	*SVR=NULL;
        char	*RevRule=NULL;
        char	*View=NULL;
        char	*usrInfo2=NULL;
        char	*Module=NULL;
        char	*ItemNumberwithDml=NULL;
        tag_t	msWordType=NULLTAG;
        tag_t	wordDataset=NULLTAG;
        tag_t	wordLatestDat_t=NULLTAG;

		tag_t	rev=NULLTAG;
		tag_t	rev1=NULLTAG;
        tag_t	view_type= NULLTAG;
        tag_t	rootTask_t=NULLTAG;
        tag_t	primary1=NULLTAG;
        tag_t	ItemObj = NULLTAG;
        tag_t	DcrItemObj=NULLTAG;
        tag_t	ctrlObjQry=NULLTAG;
        tag_t	implemRelationType_t=NULLTAG;
        tag_t	DcrProblmItemsRelType=NULLTAG;
        tag_t	DmlTaskRelationType_t=NULLTAG;
        tag_t	DmlItemsRelation_t=NULLTAG;
        tag_t	*taskAttachments=NULLTAG;
        tag_t	*qryResults=NULLTAG;
        tag_t	*DcrList=NULLTAG;
        tag_t	*taskList=NULLTAG;
        tag_t	*ItemsList=NULLTAG;
        tag_t	*DcrItemsList=NULLTAG;
        tag_t	*bom_views=NULLTAG;
        tag_t	bom_view_type=NULLTAG;
        tag_t	item=NULLTAG;
        tag_t	bom_view= NULLTAG;
		tag_t   plat=NULLTAG;

        char        *ItemId                 = NULL;
		char        *RevId                  = NULL;
        char        *VCItemId                 = NULL;
        char        *SVRType                  = NULL;
		FILE        *fd;

		time_t now;
		struct tm *timeinfo;

        tag_t   e_block=NULLTAG;
        tag_t DMLTag = NULLTAG;
        tag_t   bom_window=NULLTAG;
        tag_t   snapshot=NULLTAG;
        tag_t   window2=NULLTAG;
        tag_t   top_line=NULLTAG;
        tag_t   top_line1=NULLTAG;
        tag_t   rule    =NULLTAG;
        tag_t   Childobject=NULLTAG;
        tag_t   Childobject1=NULLTAG;
        tag_t   Childobject3=NULLTAG;
        tag_t   Childobject4=NULLTAG;
        tag_t   Childobject33=NULLTAG;
        tag_t   dataset   = NULLTAG;
        int     n_saved_variant_rules=0;
        tag_t  *saved_variant_rules=NULLTAG;
        tag_t   bom_variant_rule=NULLTAG;
        logical list_changed=FALSE;
        int     n_options=0;
        int     errorflag=0;
        int     errorflag4=0;
        int     errorflag1=0;
        int     errorflag2=0;
        int     errorflag34=0;
        tag_t  *options=NULLTAG;
        char   *v2_text=NULL;
        //tag_t  *option_revs=NULL;
        int     option_value_index=-1;
        tag_t   option1=NULLTAG;
        tag_t  *option1_rev=NULLTAG;
        int    *option1_value_index=NULL;
        tag_t   option2=NULLTAG;
        tag_t  *option2_rev=NULLTAG;
        int    *option2_value_index=NULL;
        int     inx, jnx, knx;
        int     n_option_data=0,p1=0;
        tag_t topline = NULLTAG;
        void  **option_data=NULL;
		tag_t VariqueryTag = NULLTAG;
		char **valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
		int n_entriesV = 1;
		int resultCountVNCol = 0;
		char *qry_entries3[1] = {"Name"},
		*qry_values3[1]	= {SVR};

        logical invalid_option_value_combination=TRUE;
        logical soft_abort=FALSE;
        logical option_excl=FALSE;
        int     n_ves_2_save=0;
        int     n_lines2=0;
        int     n_lines3=0;
        int     jr=0;
        int     n_lines4=0;
        int		rulefound= 0;
        int     p2=0;
        int     ss=0;
        int     p36=0;
        char	**rulename = NULL;
		char	**rulevalue = NULL;
        char	*desc = NULL;
        char	*varrul = NULL;
        tag_t  *option_revs=NULLTAG;
        char	*CurrentRelStatus = NULL;
        tag_t	dml_Ref_Rel       = NULLTAG;
        tag_t	dml_Ref_Rel_t     = NULLTAG;
        int     p4=0;
		tag_t	*outputVNCol_tags=NULLTAG;
        tag_t	*ves_2_save=NULLTAG;
        tag_t   toggle_ve=NULLTAG;
        int		n_lines,n_lines1,Item_ID = 0;
        tag_t	*lines = NULLTAG;
        tag_t	*lines2 = NULLTAG;
        tag_t	*lines3 = NULLTAG;
        tag_t	*lines4 = NULLTAG;
        tag_t	*Newlines = NULLTAG;
		tag_t	RefTypeTag = NULLTAG;
        char	*Item_ID_str=NULL;
		tag_t	VarientRuletag=NULLTAG;
		
        tag_t   relation_type      = NULLTAG;
        tag_t   relation_type1     = NULLTAG;
        char    relation_name[TCTYPE_name_size_c+1];
        char	*child_item_id=NULL;
        char	*child_item_id1=NULL;
        char	*child_item_id15=NULL;
        char	*child_item_revision_id=NULL;
		tag_t	relation_dep	= NULLTAG;
        char	*child_item_id_new=NULL;
        tag_t	*closurerule = NULLTAG;
        char	*child_bl_formula=NULL;
        tag_t   objTypeTag=NULLTAG;
        char	*child_bl_formula23=NULL;
		tag_t	*RefDoc_tag=NULLTAG;
		char	*username=NULL;
		tag_t	user_tag=NULLTAG;
		char	*user_id    = NULL;
		int		countConfigCtx = 0;
		tag_t	*ConfigCtxSecObject	= NULLTAG;
		char* Reftype_name=NULL;
        int		IntAtr5=0;
        char	*objecttype=NULL;
        char   *TempVal     =NULL;
        char   *TempVal1    =NULL;
        //char   *TempVal2  =NULL;
        tag_t	close_tag;
        char	*objectname=NULL;
        char	*childsvrname=NULL;
        char	*SVRName=NULL;
		char	*timestamp = NULL;
		char	docFile[100];
        logical modB=FALSE;
        int		structcount=0;
        char* type_name=NULL;
		timestamp = (char *) MEM_alloc(20 * sizeof(char ));
        char	*tempmat=NULL;
		date_t	DateEff;
		int		SVR_Found = 0;

		TempVal = (char *) MEM_alloc (sizeof (char) * 128);
		TempVal1 = (char *) MEM_alloc (sizeof (char) * 256);
		//TempVal2 = (char *) MEM_alloc (sizeof (char) * 2048);

		printf("\n SnapShotFormSave Function started...");fflush(stdout);
	    TC_write_syslog("\n SnapShotFormSave Function started...");

		if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
		if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);

		POM_get_user(&username,&user_tag);
		if((POM_ask_user_id(user_tag, &user_id))!=ITK_ok);
		printf("\nStarting for taskbreskdownnn :%s....\n",user_id);fflush(stdout);
		time(&now);
		timeinfo = localtime(&now);
		strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);

	/*if(strcmp(type_name,"T5_SnapShot")==0)
	{
		
		if( AOM_ask_value_string(objTag,"t5_SavedVariantRule",&SVR)==ITK_ok); 
		if( AOM_ask_value_string(objTag,"t5_Platform",&Platform)==ITK_ok) ; 
		if( AOM_ask_value_string(objTag,"t5_RevisionRule",&RevRule)==ITK_ok) ;
		if( AOM_ask_value_string(objTag,"t5_View",&View)==ITK_ok) ;
		if( AOM_ask_value_string(objTag,"t5_Module",&Module)==ITK_ok) ;
		if( AOM_ask_value_date(objTag,"t5_DateEffectivity",&DateEff)==ITK_ok) 

		printf ("\n SVR-VarientRule name is  [%s]\n", SVR); fflush(stdout);

        if(tc_strlen(Platform) != 0  && tc_strlen(Module) != 0 )
			{
				printf("\n Both module and Platform cannot be input\n", Platform);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Either provide input as 'Platform and SVR' OR only 'Module'");
				return ITK_err;
			}*/

			if (tc_strlen(Platform) != 0 && tc_strlen(SVR) != 0)  
			{

				ITK_CALL(ITEM_find_item(Platform, &plat));
		
				ITK_CALL(ITEM_ask_latest_rev(plat, &rev));

				ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
				if(relation_dep != NULLTAG)
					{
						printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
					}

				ITK_CALL(GRM_list_secondary_objects_only(plat,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
				printf("\n\t Count  Config :%d",countConfigCtx);fflush(stdout);
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &RefRel_tag));
			
						SVR_Found = 0;
						if((RefRel_tag != NULLTAG) && (ConfigCtxSecObject != NULLTAG))
						{
							CALLAPI(GRM_list_secondary_objects_only(ConfigCtxSecObject[0],RefRel_tag,&Refcount,&RefDoc_tag));
							printf("\n no of SVR's  %d\n",Refcount);fflush(stdout);
							//tc_strcpy(TempVal2,"");

								for (jr=0;jr<Refcount;jr++ )
							{
									printf("\n\t Cycle count is %d",jr+1);	fflush(stdout);
									if(TCTYPE_ask_object_type(RefDoc_tag[jr],&RefTypeTag));
									if(TCTYPE_ask_name2(RefTypeTag,&Reftype_name));
									if( AOM_ask_value_string(RefDoc_tag[jr],"object_name",&SVRName)==ITK_ok) ;
									//printf("\n     T5TaskToPartCreateVal RefDoc_tag  Reftype_name :: %s\n", Reftype_name);fflush(stdout);
									printf("\t Object name is %s",SVRName);fflush(stdout);
										if(!strcmp(Reftype_name,"VariantRule"))
										{
											//tc_strcat(TempVal2," ");
										 //tc_strcat(TempVal2,SVRName);
										 //tc_strcat(TempVal2,",");
											
											if(tc_strstr(SVRName, SVR) != NULL)
												{
													SVR_Found = 1;
													break;
												}
										}
							}
						}

						printf("\n value of  SVR's  %s  SVR_Found %d\n",SVR,SVR_Found);fflush(stdout);
						if (SVR_Found == 1)
							{	

							if(QRY_find2("VariantRule", &VariqueryTag));
							printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);

							if (VariqueryTag)
								{
									printf("Found Query 'VariantRule' \n\t"); fflush(stdout);
								}
							else
								{
									printf("Not Found Query 'VariantRule' \n\t"); fflush(stdout);
									//ITK_CALL(POM_logout(false));
									//return status;
								}

								valuesNonColSvr[0] = SVR ;

								if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
								printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);

								if (resultCountVNCol > 0)
									{
										VarientRuletag = outputVNCol_tags[0];
									}
								else
									{
										printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
										exit (0);
									}

								ITK_CALL(CFM_find( RevRule, &rule ));
								ITK_CALL(CFM_rule_set_date( rule, DateEff ));

							   if ( rev !=NULLTAG )
							   {
									   if ( PS_find_view_type( "view", &view_type ));
									   printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

									   if ( view_type != NULLTAG )
									   {
											   if ( ITEM_ask_item_of_rev( rev, &item ));
											   if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
											   bom_view = bom_views[0];
									   }
									   else
									   printf("\nView not found check.......\n"); fflush(stdout);
							   }

								if ( bom_view != NULLTAG )
								{
									printf(" before BOM_create_window..\n");        fflush(stdout);
									if ( BOM_create_window( &bom_window ));
									 //if(CFM_find( "ERC release and above", &rule ))
														
									if(BOM_set_window_config_rule( bom_window, rule ));

									if(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
									printf ("rule count %d \n",rulefound);fflush(stdout);
									   if (rulefound > 0)
									   {
											  close_tag = closurerule[0];
											  printf ("closure rule found \n");fflush(stdout);
											  // MEM_free(tags_found);
									   }
										if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

										if(BOM_set_window_pack_all(bom_window, TRUE));
										if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
										printf( " After BOM_set_window_top_line..\n");fflush(stdout);

										if (top_line!=NULLTAG )
												{
													fprintf( stderr, "\n print Master second .\n");                

													tc_strcpy(TempVal,SVR);
													
													tc_strcat(TempVal,"_");
													tc_strcat(TempVal,View);
													tc_strcat(TempVal,"_");
															
													tc_strcat(TempVal,user_id);
													tc_strcat(TempVal,"_");
													tc_strcat(TempVal,timestamp);

													tc_strcpy(TempVal1,"SnapShot for");
													
													tc_strcat(TempVal1," ");
													tc_strcat(TempVal1,SVR);
													tc_strcat(TempVal1," with Revision rule ");
															
													tc_strcat(TempVal1,RevRule);
													tc_strcat(TempVal1," created on ");
													tc_strcat(TempVal1,timestamp);

													printf("\n After inside bom_window-----\n"); fflush(stdout);
												   // if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
													if(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
													printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

													//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
													if(BOM_window_hide_variants(bom_window))   ;
													if(BOM_create_snapshot(bom_window,TempVal,TempVal1,&snapshot));
													if(snapshot)
														{
														if(AOM_save_without_extensions( snapshot) );
														if(AOM_refresh(snapshot,1));
														if(AOM_unlock(snapshot));
														if( FL_user_update_newstuff_folder(snapshot) );
														printf("\n Snapshot created with name %s\n",TempVal1); fflush(stdout);
														}
												   
												}
								}
							}
			/*else
			{
			printf("\n SVR is not valid \n");fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Selected SVR is not belongs to platform");
			return ITK_err;
			}*/

			}
				else
				{
					if (Module != NULL)
					{
					ITK_CALL(ITEM_find_item(Module, &plat));
					ITK_CALL(ITEM_ask_latest_rev(plat, &rev));
					ITK_CALL(CFM_find( RevRule, &rule ));
					ITK_CALL(CFM_rule_set_date( rule, DateEff ));

				   if ( rev !=NULLTAG )
				   {
					   if ( PS_find_view_type( "view", &view_type ));
					   printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

					   if ( view_type != NULLTAG )
					   {
							   if ( ITEM_ask_item_of_rev( rev, &item ));
							   if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							   bom_view = bom_views[0];
					   }
					   else
					   printf("\nView not found check.......\n"); fflush(stdout);
				   }

					if ( bom_view != NULLTAG )
						{
							printf(" before BOM_create_window..\n");fflush(stdout);
							if ( BOM_create_window( &bom_window ));
							//if(CFM_find( "ERC release and above", &rule ))

							if(BOM_set_window_config_rule( bom_window, rule ));
							if(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

							printf ("rule count %d \n",rulefound);fflush(stdout);
							if (rulefound > 0)
								{
									close_tag = closurerule[0];
									printf ("closure rule found \n");fflush(stdout);
									// MEM_free(tags_found);
								}
							if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
							if(BOM_set_window_pack_all(bom_window, TRUE));
							if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
							printf( " After BOM_set_window_top_line..\n");fflush(stdout);

							if ( top_line!=NULLTAG )
								{
									fprintf( stderr, "\n print Master second .\n");

									tc_strcpy(TempVal,Module);

									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,View);
									tc_strcat(TempVal,"_");

									tc_strcat(TempVal,user_id);
									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,timestamp);

									tc_strcpy(TempVal1,"SnapShot for");

									tc_strcat(TempVal1," ");
									tc_strcat(TempVal1,Module);
									tc_strcat(TempVal1," with Revision rule ");

									tc_strcat(TempVal1,RevRule);
									tc_strcat(TempVal1," created on ");
									tc_strcat(TempVal1,timestamp);

									printf("\n After inside bom_window-----\n"); fflush(stdout);
									// if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
									//if(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
									printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

									//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									//if(BOM_window_hide_variants(bom_window))   ;
									if(BOM_create_snapshot(bom_window,TempVal,TempVal1,&snapshot));
									if(snapshot)
										{
											if(AOM_save_without_extensions( snapshot) )
											if(AOM_refresh(snapshot,1));
											if(AOM_unlock(snapshot));
											if( FL_user_update_newstuff_folder(snapshot) );
										}
								}
						}
				}
	}	
	printf("\n SnapShotFormSave Function end...");fflush(stdout);
	 TC_write_syslog("\n SnapShotFormSave Function end...");
	/*if(SVRName){MEM_free(SVRName);}
	if(ConfigCtxSecObject){MEM_free(ConfigCtxSecObject);}
	if(RefDoc_tag){MEM_free(RefDoc_tag);}*/
	
//return ITK_ok;
return 0;
}
