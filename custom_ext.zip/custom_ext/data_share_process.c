/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Dhiraj
*  Module               :   Action Handler to trasnfer date thru share data utility
*  Code                 :   data_share_process.c
*  Created on			:   
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"


/*
	Action Handler		:		data_share_process
	Description			:		Action Handler to trasnfer date thru share data utility
*/


int data_share_process(EPM_action_message_t msg)
{
	int status=ITK_ok;
	int			attachmentCount		= 0;
	tag_t		rootTask_t				= NULLTAG;
	tag_t		objTag					= NULLTAG;
	tag_t		ObjTypeTag				= NULLTAG;
	tag_t		obj_class_id			= NULLTAG;
	tag_t*		taskAttachments			= NULLTAG;
	char*		type_name				= NULL;
	char*		TransferObject			= NULL;
	char*		item_id					= NULL;
	char*		obj_class_name			= NULL;

	printf("\n data_share_process Function started...");fflush(stdout);
	TC_write_syslog("\n data_share_process Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	TC_write_syslog("attachmentCount = %d\n",attachmentCount);
	
	if(attachmentCount > 0)
	{
		objTag = taskAttachments[0];
	}
	if(attachmentCount > 0)
	{
		//if (TCTYPE_ask_object_type(objTag,&ObjTypeTag)!=ITK_ok);
		//if (TCTYPE_ask_name(ObjTypeTag,type_name)!=ITK_ok);
		AOM_ask_value_string(objTag,"object_type",&type_name);
		TC_write_syslog("type_name ::  %s\n", type_name);
		
		POM_class_of_instance(objTag, &obj_class_id);

		if(obj_class_id != NULLTAG)
		{
			POM_name_of_class(obj_class_id, &obj_class_name);
			TC_write_syslog("obj_class_name ::  %s\n", obj_class_name);
		}

		if(tc_strcmp(type_name,"Design Revision") == 0)
		{
			AOM_ask_value_string(objTag,"item_id",&item_id);
			TC_write_syslog("item_id ::  %s\n", item_id);
			TransferObject=malloc(2000);
			strcpy(TransferObject,"nohup data_share -u=infodba -p=INfoDBA -g=dba -f=send -site=CMITESTJSR -item_id=");
			strcat(TransferObject,item_id);
			strcat(TransferObject," -latest_revision ");
			strcat(TransferObject," -latest_ds_version ");
			strcat(TransferObject," > /tmp/");
			strcat(TransferObject,item_id);
			strcat(TransferObject,".log &");
			TC_write_syslog("TransferObject final string is  ::  %s\n", TransferObject);
			system(TransferObject);
		}
	}
	printf("\n data_share_process Function end...");fflush(stdout);
	TC_write_syslog("\n data_share_process Function end...");

	//return status;
	return 0;
}