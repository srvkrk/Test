
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_DigitalValidation.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for Digital Validation Document
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 29/08/2024   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/grm_msg.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tccore/iman_msg.h>
#include <tc/envelope.h>

#define MAX_LINE_LEN 1024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001

#define T5_WorkFlowHandlerDVErr (EMH_USER_error_base + 751)

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


/*****************************Start Generic Functions*********************************/
char *trimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}


void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}

int getItemTagByItemId(char* itemid, int *cnt, tag_t **items)
{
	int ifail = ITK_ok;
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	const char *attrs[1];
	const char *values[1];
	attrs[0]	= "item_id";
	values[0]	= itemid;


	ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
	//printf("\n1111 No of tags ==>%d\n",n_tags_found);fflush(stdout);
	
	*cnt = n_tags_found;
	*items = tags_found;

	return ifail;
}


void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\nDigVld:t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	fflush(stdout);
}

//Function to add ERC Released Status to a Part Tag
int T5_AddERCReleasedStatus(tag_t partTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
	CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

	if((tc_strcmp(ReleaseStatus,"ERC Released")==0)||tc_strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		/*char cCurrentDate[20]={0};
		date_t start_date;
		date_t end_date;
		t5GetCurrentDateTime(cCurrentDate);
		printf("\nDigVld:Current date  is..:[%s]\n",cCurrentDate);fflush(stdout);
		ifail = ITK_string_to_date(cCurrentDate, &start_date );
		ifail = ITK_string_to_date("31-Dec-2099 00:00", &end_date );	
		CALLAPI(RELSTAT_set_date_effectivity(release_status,start_date,end_date));*/		
		CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
	}	
	
	return ifail;
}


int T5_RemoveStatus(tag_t partTag)
{
	int ifail = ITK_ok;
	tag_t class_id = NULLTAG;
	char* class_name = NULL;
	tag_t tRelStatId = NULLTAG;
	logical isLoaded = FALSE;
	int n_values = 0;
	
	CALLAPI(POM_class_of_instance(partTag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\nDigVld: class_name is :[%s]\n",class_name);fflush(stdout);
	
	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tRelStatId));fflush(stdout);
	printf("\nDigVld:after getting rel stat...");fflush(stdout);
	
	CALLAPI(POM_unload_instances(1,&partTag));
	CALLAPI(POM_load_instances(1,&partTag,class_id,1));
	CALLAPI(POM_is_loaded(partTag,&isLoaded));
	
	if(isLoaded)
	{
		printf("\nDigVld:Load Success\n " );fflush(stdout);
	}
	else
	{
		printf("\nDigVld:Load failure\n " );fflush(stdout);
	}
	
	CALLAPI(POM_length_of_attr(partTag, tRelStatId, &n_values) );
	printf("\nDigVld: n_values is :[%d]\n",n_values);fflush(stdout);
	
	if(n_values > 0)
	{
		logical	*is_it_null		=   NULL; 
		logical	*is_it_empty	=   NULL;
		tag_t* values = NULLTAG;
		int i = 0;
		
		CALLAPI(POM_ask_attr_tags(partTag,tRelStatId,0,n_values,&values,&is_it_null,&is_it_empty ));
		
		printf("\nDigVld:n_values -1 is :%d\n",n_values);fflush(stdout);
		
		for (i= 0;i<n_values;i++)
		{
			CALLAPI(POM_remove_from_attr(1,&partTag,tRelStatId,i,1));
			CALLAPI(POM_save_instances(1,&partTag,1));
			CALLAPI(AOM_lock(partTag));
			CALLAPI(AOM_save_without_extensions(partTag));
			CALLAPI(AOM_refresh(partTag,1));
			CALLAPI(AOM_unlock(partTag));
		}
		
	}
	
	return ifail;
}



/*****************************End Generic Functions*********************************/


/***********************Start - UTILITY Functions ****************************/

//Get Digital Validation Control Object
int getDigitalValidationDocControlObj(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	printf("\nDigVld: Check for control object DigitalVld-DigitalVld....\n");fflush(stdout);
	
	int  count 	= 0;
	tag_t *contrlObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "DigitalVld";
	qry_values[1] = "DigitalVld";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nDigVld:Control objects DigitalVld: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nDigVld: Control object ===>%s", cntrlStr);fflush(stdout);
						
			
			*contrlTag = cntrlObj;
			printf("\nDigVld: Live for Digital Validation Doc validation\n");fflush(stdout);
			
		}
		
	}
	
	return ifail;
}


//Function to Create Digital Validation Document with input as Dataset Name
int createDigitalValiDocDataSet(char* datasetName, tag_t * digiValdDocTag)
{
	int ifail = ITK_ok;
	tag_t datasettype = NULLTAG;
	tag_t digValdTypeTag = NULLTAG;
	tag_t create_input_tag = NULLTAG;
	tag_t datasettag = NULLTAG;
	tag_t tool = NULLTAG;
	logical checkout;
	const char *reason	= "";
	const char *change_id	= "";
	const char *dir_name = "";
	
	
	ifail = AE_find_datasettype2("T5_DigitalVldDoc", &datasettype);
	
	if(datasettype == NULLTAG) 
	{
		printf("\nDigVld:Error: datasettype is NULL\n");fflush(stdout);
		//return ITK_ok;
	}
	
	ifail = TCTYPE_find_type("T5_DigitalVldDoc", NULL, &digValdTypeTag) ;
	ifail = TCTYPE_construct_create_input(digValdTypeTag, &create_input_tag);
	ifail = AOM_set_value_string(create_input_tag,"object_name",datasetName);
	ifail = AOM_set_value_string(create_input_tag,"object_desc",datasetName);
	ifail = TCTYPE_create_object(create_input_tag,&datasettag);
	ifail = AOM_lock(datasettag);
	ifail = AE_set_dataset_tool(datasettag, tool);
	ifail = AE_set_dataset_format2(datasettag, "BINARY_REF");  
	ifail = AOM_save_with_extensions(datasettag);
	ifail = AOM_refresh(datasettag,0);
	ifail = AOM_unlock(datasettag);
	
	ifail = RES_is_checked_out(datasettag,&checkout);
	if (!checkout)
	{
		ifail = RES_checkout2(datasettag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE);
		printf("\nDigVld:Digital Vald doc:[%s]DataSet Checked Out\n",datasetName);fflush(stdout);
	}	
	
	return ifail;
}

//Methods to create Digital Validation Document for given Vehicle.
int T5CreateDigitalValidationDoc(tag_t partTag,char* partNumber,char* partRev,char* partDR,char** resultStr)
{
	int ifail = ITK_ok;
	
	char* datasetName = NULL;
    
	datasetName = (char*)MEM_alloc(200*sizeof(char*));
	
	//Creating Digital Validation Doc DR0
	tag_t digiValdDocTag1 = NULLTAG;
	tc_strcpy(datasetName,"");
	tc_strcat(datasetName,"DV DVP@DR0_");
	tc_strcat(datasetName,partNumber);
	tc_strcat(datasetName,"_");
	tc_strcat(datasetName,partRev);
	
	ifail = createDigitalValiDocDataSet(datasetName, &digiValdDocTag1);
	
	//Creating Digital Validation Doc DR1
	tag_t digiValdDocTag2 = NULLTAG;
	
	tc_strcpy(datasetName,"");
	tc_strcat(datasetName,"DV V0 Report @DR1_");
	tc_strcat(datasetName,partNumber);
	tc_strcat(datasetName,"_");
	tc_strcat(datasetName,partRev);
	
	ifail = createDigitalValiDocDataSet(datasetName,&digiValdDocTag2);
	
	//Creating Digital Validation Doc DR2
	tag_t digiValdDocTag3 = NULLTAG;
	
	tc_strcpy(datasetName,"");
	tc_strcat(datasetName,"DV V1 Report @DR2_");
	tc_strcat(datasetName,partNumber);
	tc_strcat(datasetName,"_");
	tc_strcat(datasetName,partRev);
	
	ifail = createDigitalValiDocDataSet(datasetName,&digiValdDocTag3);
	
   
	//Creating Digital Validation Doc DR3
	tag_t digiValdDocTag4 = NULLTAG;
	
	tc_strcpy(datasetName,"");
	tc_strcat(datasetName,"DV V2 Report @DR3_");
	tc_strcat(datasetName,partNumber);
	tc_strcat(datasetName,"_");
	tc_strcat(datasetName,partRev);
	
	ifail = createDigitalValiDocDataSet(datasetName,&digiValdDocTag4);
	
	if(datasetName!=NULL) MEM_free(datasetName);
	
	
	return ITK_ok;
}



int tmDigitalValidDocCreServ(void *retValue)
{
	printf("\nDigVld: Service:Start----tmDigitalValidDocCreServ....\n");fflush(stdout);
	
	const char	*prog_name 	="tmDigitalValidDocCreServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partTag = NULLTAG;
	char* partNumber = NULL;
	char* partRev = NULL;
	char* partDR = NULL;
	

	char *resultStr = NULL;
	char * resultStr1 = NULL;	
	
	USERARG_get_tag_argument(&partTag);
	USERARG_get_string_argument(&partNumber);
	USERARG_get_string_argument(&partRev);
	USERARG_get_string_argument(&partDR);
	
	
	printf("\nDigVld: Part No,Rev,DR Status:[%s,%s,%s]",partNumber,partRev,partDR);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	if(partTag !=NULLTAG)
	{
		
		printf("\nDigVld:Got the part tag object");fflush(stdout);
		
		ifail = T5CreateDigitalValidationDoc(partTag,partNumber,partRev,partDR,&resultStr);
		
		resultStr = "PASS";
					
	}

	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nDigVld:Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("\nDigVld:After returning Value\n");fflush(stdout);	
	printf("\nDigVld:Service:End----tmDigitalValidDocCreServ....\n");fflush(stdout);
	return ifail;	
	
}


int tmDigitalValidDocCreServNew(void *retValue)
{
	printf("\nDigVld: Service:Start----tmDigitalValidDocCreServNew....\n");fflush(stdout);
	
	const char	*prog_name 	="tmDigitalValidDocCreServNew";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partTag = NULLTAG;
	char** datasetName = NULL;
	int length = 0;
	tag_t digiValdDocTag = NULL;

	char *resultStr = NULL;
	char * resultStr1 = NULL;	
	
	USERARG_get_tag_argument(&partTag);
	USERARG_get_string_array_argument(&length,&datasetName);
	
	
	
	printf("\nDigVld: Size of Dataset [%d]",length);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	if(partTag !=NULLTAG)
	{
		
		printf("\nDigVld:Got the part tag object");fflush(stdout);
		
		int i = 0;
		for(i=0;i<length;i++)
		{
			ifail = createDigitalValiDocDataSet(datasetName[i], &digiValdDocTag);
		}
			
		if(ifail == ITK_ok)
		{
			resultStr = "PASS";
		}
		
					
	}

	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nDigVld: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("\nDigVld:After returning Value\n");fflush(stdout);	
	printf("\nDigVld:Service:End----tmDigitalValidDocCreServNew....\n");fflush(stdout);
	return ifail;	
	
}


/***********************End - UTILITY Functions ****************************/

/***************START- Extensions Functions *****************************/

/***************Start - Validation at checkin*******************/
int digitalValidCheckinValidation(METHOD_message_t* msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	char *type_name = NULL;
	
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	
	printf("\nDigVld:In digitalValidCheckinValidation objTypeTag [%s]\n",type_name);fflush(stdout);
	
	return ifail;
	
}



int digitalValidCheckinPreCondValidation(METHOD_message_t* msg, va_list args)
{
	
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	char *type_name = NULL;
	
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	
	printf("\nDigVld:In digitalValidCheckinPreCondValidation objTypeTag [%s]\n",type_name);fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_DigitalVldDoc")==0)
	{
		tag_t sessionUserTag = NULLTAG;
		char* sessionUserName = NULL;
		char* userid = NULL;
		tag_t current_role_tag = NULLTAG;
		char* rolename = NULL;
		
		tag_t groupTag = NULLTAG;
		char* groupname = NULL;
		
		POM_get_user(&sessionUserName,&sessionUserTag);
		SA_ask_user_identifier2	(sessionUserTag,&userid);		
		SA_ask_current_role(&current_role_tag);			
		SA_ask_role_name2(current_role_tag, &rolename);
		printf ("\nDigVld: Logged in user:%s, %s\n",userid,sessionUserName);fflush(stdout);	

		POM_ask_group(&groupname, &groupTag);
		
		
		tag_t cntrlObj = NULLTAG;
		char* userInfo3 = NULL;
		char* userInfo4 = NULL;
		ifail = getDigitalValidationDocControlObj(&cntrlObj);
		
		if(cntrlObj != NULLTAG)
		{
			ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3);
			ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4);
		}
		if(userInfo3 == NULL) userInfo3 = "";
		if(userInfo4 == NULL) userInfo4 = "";
		printf("\nDigVld:Role Name: [%s]Group Name: [%s]\n",rolename,groupname);fflush(stdout);
		printf("\nDigVld:userInfo3: [%s]userInfo4: [%s]\n",userInfo3,userInfo4);fflush(stdout);
		
		if(tc_strcmp(rolename,"Digital_Validation_Role")==0 || tc_strstr(userInfo4,rolename)!=NULL || tc_strstr(userInfo3,groupname)!=NULL )
		{
			printf("\nDigVld: Allowed to checkin\n");fflush(stdout);
			
			//check if word file is attached.
			char  *refname = NULL;
			AE_reference_type_t	reftype;
			tag_t	refobject = NULLTAG;
			
			ifail =AE_find_dataset_named_ref2(objTag,0,&refname, &reftype,&refobject);
			
			if(refobject==NULLTAG)
			{
				printf("\nDigVld:System will not allow to check in without word file attachment...\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"\nPlease attach file and check into release vault.");
				return ITK_err;	
			}
			else
			{
				char* orig_name = NULL;
				char* partRelzState = NULL;
				ifail = IMF_ask_original_file_name2(refobject , &orig_name);
				printf("\nDigVld:original file name is :%s\n",orig_name);fflush(stdout);
				
				//Get the release status list of objTag(Digital valid doc)
				
				ifail = AOM_UIF_ask_value(objTag,"release_status_list",&partRelzState);
				printf("\nDigVld:Existing ReleaseStatus : [%s]",partRelzState);
				
				if(tc_strcmp(partRelzState,"ERC Released")==0 || tc_strcmp(partRelzState,"T5_LcsErcRlzd")==0)
				{
					printf("\nAlready in ERC Released status\n");fflush(stdout);
				}
				else
				{
					printf("\nDigVld:Remove status and then add ERC Released state\n");fflush(stdout);
					ifail = T5_RemoveStatus(objTag);
					ifail = T5_AddERCReleasedStatus(objTag);
				}
				
				
			}
			
			
		}
		else
		{
			printf("\nDigVld Should not be able to checkin...\n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"\nCheckin Access Denied.\nDigital_Validation_Group member should only be able to checkin \"Digital Validation Document\"");
			return ITK_err;	
		}
	}
	
	return ifail;
	
}


/***************End - Validation at checkin*******************/

/***************Start - Validation at checkout*******************/
int digitalValidCheckOutValidation(METHOD_message_t *msg, va_list args)
{
	
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	char *type_name = NULL;
	
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	
	printf("\nDigVld:In digitalValidCheckOutValidation objTypeTag [%s]\n",type_name);fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_DigitalVldDoc")==0)
	{
		tag_t sessionUserTag = NULLTAG;
		char* sessionUserName = NULL;
		char* userid = NULL;
		tag_t current_role_tag = NULLTAG;
		char* rolename = NULL;
		
		tag_t groupTag = NULLTAG;
		char* groupname = NULL;
		
		POM_get_user(&sessionUserName,&sessionUserTag);
		SA_ask_user_identifier2	(sessionUserTag,&userid);		
		SA_ask_current_role(&current_role_tag);			
		SA_ask_role_name2(current_role_tag, &rolename);
		printf ("\nDigVld: Logged in user:%s, %s\n",userid,sessionUserName);fflush(stdout);	

		POM_ask_group(&groupname, &groupTag);
		
		
		tag_t cntrlObj = NULLTAG;
		char* userInfo5 = NULL;
		char* userInfo6 = NULL;
		ifail = getDigitalValidationDocControlObj(&cntrlObj);
		
		if(cntrlObj != NULLTAG)
		{
			ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5);
			ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6);
		}
		if(userInfo5 == NULL) userInfo5 = "";
		if(userInfo6 == NULL) userInfo6 = "";
		printf("\nDigVld:Role Name: [%s]Group Name: [%s]\n",rolename,groupname);fflush(stdout);
		printf("\nDigVld:userInfo5:[%s]userInfo6:[%s]\n",userInfo5,userInfo6);fflush(stdout);
		
		if(tc_strcmp(userid,"loader")==0 && tc_strcmp(userid,"infodba")==0 ||tc_strcmp(groupname,"PLM_Support_Group")==0 ||tc_strstr(userInfo5,rolename)!=NULL || tc_strstr(userInfo6,groupname)!=NULL )
		{
			
			printf("\nDigVld: Allowed to checkout released digital vald doc\n");fflush(stdout);
			//Allowed check-out. Once checked out remove the status.
			ifail = T5_RemoveStatus(objTag);
			
		}
		else
		{
			
			char* partRelzState = NULL;
			char* digiValdDocID = NULL;
			printf("\nDigVld: Allowed to checkout.Checking for Release Status\n");fflush(stdout);
			
			ifail = AOM_ask_value_string(objTag,"object_name",&digiValdDocID);			
			ifail = AOM_UIF_ask_value(objTag,"release_status_list",&partRelzState);
			printf("\nDigVld: %s ReleaseStatus : %s",digiValdDocID,partRelzState);
			
			if(tc_strstr(partRelzState,"Released")!=NULL)
			{
				printf("\nDigVld:Digital Validation Document %s Already ERC Released. You don't have access to edit ERC Released Digital Validation Doc\n",digiValdDocID);fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Digital Validation Doc is ERC Released, You don't have access to checkout");
				return ITK_err;
			}
			else
			{
				//Allowed check-out. Once checked out remove the status.
				ifail = T5_RemoveStatus(objTag);
			}
		}
	}
	
	return ifail;

}

/***************End - Validation at checkout*******************/


/************Validation during attaching digital valid doc to vehicle ******************/
int T5VehHasDigitalVldRelationCreateVal(METHOD_message_t *msg,va_list args )
{
	int ifail = ITK_ok;
	va_list largs;
	va_copy( largs, args );

	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	tag_t  *new_relation = va_arg(largs, tag_t *);
	
	
	
	
	tag_t priObjTypeTag = NULLTAG;
	char* pri_type_name = NULL;	
	tag_t secObjTypeTag = NULLTAG;
	char* sec_type_name = NULL;	
	char* name_relation = NULL;	
	tag_t relObjTypeTag = NULLTAG;
	char* rel_type_name = NULL;
	
	
	CALLAPI(TCTYPE_ask_object_type(primary_object,&priObjTypeTag));
	CALLAPI(TCTYPE_ask_name2(priObjTypeTag,&pri_type_name));
	
	
	CALLAPI(TCTYPE_ask_object_type(secondary_object,&secObjTypeTag));	
	CALLAPI(TCTYPE_ask_name2(secObjTypeTag,&sec_type_name));
	
	CALLAPI(TCTYPE_ask_name2(relation_type,&name_relation));
	
	CALLAPI(TCTYPE_ask_object_type(relation_type,&relObjTypeTag));
	CALLAPI(TCTYPE_ask_name2(relObjTypeTag,&rel_type_name));
	printf("\nDigVld:Start---T5VehHasDigitalVldRelationCreateVal------\n");fflush(stdout);
	printf("\nDigVld:pri_type_name:[%s],sec_type_name:[%s],rel_type_name:[%s],name_relation:[%s]\n",pri_type_name,sec_type_name,rel_type_name,name_relation);fflush(stdout);
	
	
	if(tc_strcmp(name_relation,"T5_HasDigitalValidDoc")==0)
	{
		tag_t cntrlObj = NULLTAG;
		char* info7 = NULL;
		char* info8 = NULL;
		ifail = getDigitalValidationDocControlObj(&cntrlObj);
		
		if(cntrlObj == NULLTAG)
		{
			//Not live;
			printf("\nDigVld: Not live for create validation\n");
			return ITK_ok;
		}
		else
		{
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&info7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&info8));
			printf("\nDigVld:info7:[%s], info8[%s]\n",info7,info8);fflush(stdout);
		}
		
		
		if(tc_strcmp(sec_type_name,"T5_DigitalVldDoc")==0 && tc_strcmp(pri_type_name,"Design Revision")==0)
		{
			//ok to proceed
			tag_t partToTaskRel = NULLTAG;
			int DmlTaskCnt = 0;
			tag_t* DmlTaskTags = NULLTAG;
			int i = 0;
			char* digiDocRelStatus = NULL;
			//Only released doc should be allowed to attach
			CALLAPI(AOM_UIF_ask_value(secondary_object,"release_status_list",&digiDocRelStatus));
			printf("\nDigVld:Rel Status of Dig Vld Doc:[%s]\n",digiDocRelStatus);fflush(stdout);
			if(tc_strstr(digiDocRelStatus,"ERC Released")!=NULL)
			{
				//ok released doc
			}
			else
			{
				//error
				printf("\nDigVld:Error!!! Only Released Digital validation Document allowed to be attached here...\n");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach release digital validation document only");
				return ITK_err;
			}
			
			//Get the ERC DML Task attached to the Vehicle.
			CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&partToTaskRel));
			CALLAPI(GRM_list_primary_objects_only(primary_object,partToTaskRel,&DmlTaskCnt,&DmlTaskTags));
			
			if(DmlTaskCnt <=0)
			{
				CALLAPI(GRM_find_relation_type("CMReferences",&partToTaskRel));
				CALLAPI(GRM_list_primary_objects_only(primary_object,partToTaskRel,&DmlTaskCnt,&DmlTaskTags));
			}
			
			printf("\nDigVld:No of ERC DML Task attached to the Vehicle:[%d]\n",DmlTaskCnt);fflush(stdout);
			
			
			
			int cnt = 0;
			tag_t* ErcTaskTags = NULLTAG;
			
			for(i=0;i<DmlTaskCnt;i++)
			{
				char* objTypeStr = NULL;
				tag_t dmlTaskTag = NULLTAG;				
				dmlTaskTag = DmlTaskTags[i];				
				CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&objTypeStr));
				if(objTypeStr == NULL)
				{
					printf("\nDigVld:Some very fatal error. Null value of object_type.Skip it.\n");fflush(stdout);
				}
				
				if(tc_strcmp(objTypeStr,"T5_ChangeTaskRevision")==0 || tc_strcmp(objTypeStr,"ERC Task Revision")==0)
				{
					//ERC DML Task
					char* dmlTaskReleaseStatusStr = NULL;
					char* dmlTaskNo = NULL;
					CALLAPI(AOM_UIF_ask_value(dmlTaskTag,"release_status_list",&dmlTaskReleaseStatusStr));
					CALLAPI(AOM_ask_value_string(dmlTaskTag,"item_id",&dmlTaskNo));					
					printf("\nDigVld:DML Task [%s] release status:[%s]\n",dmlTaskNo,dmlTaskReleaseStatusStr);fflush(stdout);

					if(dmlTaskReleaseStatusStr != NULL)
					{
						if(tc_strstr(dmlTaskReleaseStatusStr,"Released")!=NULL)
						{
							//Released dml skip this.
							continue;
						}
						else
						{
							
							//get the dml from dml task.
							tag_t tsktodmlrel = NULLTAG;
							tag_t* DMLRevs = NULLTAG;
							int tsktodmlrelcount = 0;
							
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
							if (tsktodmlrel!=NULLTAG)
							{
								CALLAPI(GRM_list_primary_objects_only(dmlTaskTag,tsktodmlrel,&tsktodmlrelcount,&DMLRevs));
							}
							
							if(tsktodmlrelcount > 0)
							{
								int s = 0;
								for (s=0;s<tsktodmlrelcount;s++ )
								{
									tag_t DMLRev = NULLTAG;
									logical islatest = FALSE;
									CALLAPI(ITEM_rev_sequence_is_latest(DMLRevs[s],&islatest));
									printf("\nDigVld:\tislatest= [%d] ",islatest);fflush(stdout);

									if(islatest != TRUE)
									{
										printf("\nDigVld:\tislatest is not true .....");fflush(stdout);
									}
									else
									{
										DMLRev = DMLRevs[s];
										char* dmlNo = NULL;
										char* dmlRelsType = NULL;
										CALLAPI(AOM_ask_value_string(DMLRev,"item_id",&dmlNo));
										CALLAPI(AOM_UIF_ask_value(DMLRev,"t5_rlstype",&dmlRelsType));
										printf("\nDigVld:DML No:[%s], Release Type:[%s]\n",dmlNo,dmlRelsType);fflush(stdout);
										if(tc_strcmp(dmlRelsType,"Veh")==0 || tc_strcmp(dmlRelsType,"Vehicle Release")==0 || tc_strcmp(dmlRelsType,"TODR")==0 || tc_strcmp(dmlRelsType,"Gate Maturation")==0)
										{
											setAddTagObj(&cnt,&ErcTaskTags,dmlTaskTag);
										}
									}
									
									
								}
								
								
							}
							
							//dmlTask = dmlTaskTag;
							//break;
							
						}
					}
					else
					{
						//skip the dml.
						continue;
					}	
					
				}
					
				
			}
						
			printf("\nDigVld:No of ERC Task:[%d]\n",cnt);fflush(stdout);
			if(cnt>0)
			{	int j = 0;
				int allowedFlag = 0;
				for(j=0;j<cnt;j++)
				{
					tag_t dmlTask = NULLTAG;
					dmlTask = ErcTaskTags[j];
					char* dmlTaskReleaseStatusStr = NULL;
					char* dmlTaskNo = NULL;
					CALLAPI(AOM_UIF_ask_value(dmlTask,"release_status_list",&dmlTaskReleaseStatusStr));
					CALLAPI(AOM_ask_value_string(dmlTask,"item_id",&dmlTaskNo));
					
					printf("\nDigVld:111---DML Task [%s] release status:[%s]\n",dmlTaskNo,dmlTaskReleaseStatusStr);fflush(stdout);
					//check the lc step of ERC dml task.
					tag_t  	taskjob         = NULLTAG;
					tag_t  	task_job_type   = NULLTAG;
					tag_t  	roottask        = NULLTAG;				
					CALLAPI(EPM_get_current_job(dmlTask,&taskjob,&task_job_type));			
					if (taskjob != NULLTAG)
					{
						int taskcount = 0;
						char* nameofroot = NULL;
						tag_t* subtasks = NULLTAG;
						CALLAPI(EPM_ask_root_task(taskjob,&roottask));
						
						CALLAPI(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks));
						CALLAPI(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
						printf("\nDigVld:Name of Root task:[%s]\n",nameofroot);fflush(stdout);
						if (taskcount>0)
						{
							printf("\nDigVld:taskcount:[%d]\n",taskcount);fflush(stdout);
							int k = 0;
							for(k=0;k<taskcount;k++)
							{
								char* taskstatus = NULL;
								char* SubtaskType = NULL;
								CALLAPI(AOM_UIF_ask_value(subtasks[k],"task_state",&taskstatus));
								CALLAPI(AOM_ask_value_string(subtasks[k],"task_type",&SubtaskType));
								
								printf("\nDigVld:taskstatus:[%s], subtasktype:[%s]\n",taskstatus,SubtaskType);fflush(stdout);
								if(tc_strstr(taskstatus,"Started")!=NULL)
								{
									char* lcStepName = NULL;
									
									
									CALLAPI(AOM_UIF_ask_value(subtasks[k],"object_name",&lcStepName));
									printf("\nDigVld:Assignment Name is  [%s] \n",lcStepName);fflush(stdout);
									char* lcStepName1 = (char*)MEM_alloc(300*sizeof(char*) + tc_strlen(lcStepName)*sizeof(char*));
									tc_strcpy(lcStepName1,",");
									tc_strcat(lcStepName1,lcStepName);
									tc_strcat(lcStepName1,",");
									printf("\nDigVld:Assignment Name is lcStepName1:[%s] \n",lcStepName);fflush(stdout);
									if((tc_strcmp(lcStepName,"Add Items for Gate maturation")==0)|| (tc_strcmp(lcStepName,"Add solution items")==0) || (tc_strcmp(lcStepName,"Check for VC BOM from solution Items and Attach VOD")==0)|| (tc_strstr(info7,lcStepName1)!=NULL) )
									{
										allowedFlag = 1;
										break;
									}
								}
							}
							
						}
						
						
					}
					
				}

			
			
				printf("\nDigVld:allowedFlag ===>[%d]\n",allowedFlag);fflush(stdout);
				if(allowedFlag !=1)
				{
					//throw error
					printf("\nDigVld:Error!!!.Please attach document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"\n");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"");
					return ITK_err;
				}
				else
				{
					printf("\nDigVld:Allowed to attach digital valid doc.\n");fflush(stdout);
				}
			}
			else
			{
				//throw error
				printf("\nDigVld:Error!!!No DML attached to the Vehicle.Please attach document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"\n");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"");
				return ITK_err;
				
			}
		}
		else
		{
			//error
			printf("\nDigVld:Error!!! Only Digital validation Document allowed to be attached here...\n");
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach only Digital Validation Document dataset.");
			return ITK_err;
			
		}
	}
	
	printf("\nDigVld:End---T5VehHasDigitalVldRelationCreateVal------\n");fflush(stdout);
	return ifail;
}


int T5VehHasDigitalVldRelationDelVal(METHOD_message_t *msg,va_list args)
{
	int ifail = ITK_ok;
	
	tag_t object = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	char* name_relation = NULL;
	tag_t secondary_object = NULLTAG;
	tag_t secObjTypeTag = NULLTAG;
	char* sec_type_name = NULL;
	
	tag_t primary_object = NULLTAG;
	tag_t priObjTypeTag = NULLTAG;
	char* pri_type_name = NULL;
	
	printf("\nDigVld:Start---T5VehHasDigitalVldRelationDelVal------\n");fflush(stdout);
	//Get selected object
	CALLAPI(TCTYPE_ask_object_type(object,&objTypeTag));
	CALLAPI(TCTYPE_ask_name2(objTypeTag,&name_relation));
	printf("\nDigVld:Selected Object Type[%s]\n", name_relation);fflush(stdout);
	
	//Get SXecondary object
	CALLAPI(GRM_ask_secondary(object,&secondary_object));
	CALLAPI(TCTYPE_ask_object_type(secondary_object,&secObjTypeTag));
	CALLAPI(TCTYPE_ask_name2(secObjTypeTag,&sec_type_name));
	printf("\nDigVld:sec_type_name:[%s]\n", sec_type_name);fflush(stdout);

	//Get the primary object
	CALLAPI(GRM_ask_primary(object,&primary_object));
	CALLAPI(TCTYPE_ask_object_type(primary_object,&priObjTypeTag));
	CALLAPI(TCTYPE_ask_name2(priObjTypeTag,&pri_type_name));
	printf("\nDigVld:pri_type_name:[%s]\n", pri_type_name);fflush(stdout);
	
	
	
	if(tc_strcmp(name_relation,"T5_HasDigitalValidDoc")==0)
	{
		tag_t cntrlObj = NULLTAG;
		char* info7 = NULL;
		char* info8 = NULL;
		ifail = getDigitalValidationDocControlObj(&cntrlObj);
		
		if(cntrlObj == NULLTAG)
		{
			//Not live;
			printf("\nDigVld: Not live for create validation\n");
			return ITK_ok;
		}
		else
		{
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&info7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&info8));
			printf("\nDigVld:info7:[%s], info8[%s]\n",info7,info8);fflush(stdout);
		}
		
		
		if(tc_strcmp(sec_type_name,"T5_DigitalVldDoc")==0 && tc_strcmp(pri_type_name,"Design Revision")==0)
		{
			//ok to proceed
			tag_t partToTaskRel = NULLTAG;
			int DmlTaskCnt = 0;
			tag_t* DmlTaskTags = NULLTAG;
			int i = 0;
			
			//Get the ERC DML Task attached to the Vehicle.
			CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&partToTaskRel));
			CALLAPI(GRM_list_primary_objects_only(primary_object,partToTaskRel,&DmlTaskCnt,&DmlTaskTags));
			
			if(DmlTaskCnt <=0)
			{
				CALLAPI(GRM_find_relation_type("CMReferences",&partToTaskRel));
				CALLAPI(GRM_list_primary_objects_only(primary_object,partToTaskRel,&DmlTaskCnt,&DmlTaskTags));
			}
			
			printf("\nDigVld:No of ERC DML Task attached to the Vehicle:[%d]\n",DmlTaskCnt);fflush(stdout);
			
			
			
			int cnt = 0;
			tag_t* ErcTaskTags = NULLTAG;
			
			for(i=0;i<DmlTaskCnt;i++)
			{
				char* objTypeStr = NULL;
				tag_t dmlTaskTag = NULLTAG;				
				dmlTaskTag = DmlTaskTags[i];				
				CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&objTypeStr));
				if(objTypeStr == NULL)
				{
					printf("\nDigVld:Some very fatal error. Null value of object_type.Skip it.\n");fflush(stdout);
				}
				
				if(tc_strcmp(objTypeStr,"T5_ChangeTaskRevision")==0 || tc_strcmp(objTypeStr,"ERC Task Revision")==0)
				{
					//ERC DML Task
					char* dmlTaskReleaseStatusStr = NULL;
					char* dmlTaskNo = NULL;
					CALLAPI(AOM_UIF_ask_value(dmlTaskTag,"release_status_list",&dmlTaskReleaseStatusStr));
					CALLAPI(AOM_ask_value_string(dmlTaskTag,"item_id",&dmlTaskNo));					
					printf("\nDigVld:DML Task [%s] release status:[%s]\n",dmlTaskNo,dmlTaskReleaseStatusStr);fflush(stdout);

					if(dmlTaskReleaseStatusStr != NULL)
					{
						if(tc_strstr(dmlTaskReleaseStatusStr,"Released")!=NULL)
						{
							//Released dml skip this.
							continue;
						}
						else
						{
							
							//get the dml from dml task.
							tag_t tsktodmlrel = NULLTAG;
							tag_t* DMLRevs = NULLTAG;
							int tsktodmlrelcount = 0;
							
							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
							if (tsktodmlrel!=NULLTAG)
							{
								CALLAPI(GRM_list_primary_objects_only(dmlTaskTag,tsktodmlrel,&tsktodmlrelcount,&DMLRevs));
							}
							
							if(tsktodmlrelcount > 0)
							{
								int s = 0;
								for (s=0;s<tsktodmlrelcount;s++ )
								{
									tag_t DMLRev = NULLTAG;
									logical islatest = FALSE;
									CALLAPI(ITEM_rev_sequence_is_latest(DMLRevs[s],&islatest));
									printf("\nDigVld:\tislatest= [%d] ",islatest);fflush(stdout);

									if(islatest != TRUE)
									{
										printf("\nDigVld:\tislatest is not true .....");fflush(stdout);
									}
									else
									{
										DMLRev = DMLRevs[s];
										char* dmlNo = NULL;
										char* dmlRelsType = NULL;
										CALLAPI(AOM_ask_value_string(DMLRev,"item_id",&dmlNo));
										CALLAPI(AOM_UIF_ask_value(DMLRev,"t5_rlstype",&dmlRelsType));
										printf("\nDigVld:DML No:[%s], Release Type:[%s]\n",dmlNo,dmlRelsType);fflush(stdout);
										if(tc_strcmp(dmlRelsType,"Veh")==0 || tc_strcmp(dmlRelsType,"Vehicle Release")==0 || tc_strcmp(dmlRelsType,"TODR")==0 || tc_strcmp(dmlRelsType,"Gate Maturation")==0)
										{
											setAddTagObj(&cnt,&ErcTaskTags,dmlTaskTag);
										}
									}
									
									
								}
								
								
							}
							
							//dmlTask = dmlTaskTag;
							//break;
							
						}
					}
					else
					{
						//skip the dml.
						continue;
					}	
					
				}
					
				
			}
						
			printf("\nDigVld:No of ERC Task:[%d]\n",cnt);fflush(stdout);
			if(cnt>0)
			{	int j = 0;
				int allowedFlag = 0;
				for(j=0;j<cnt;j++)
				{
					tag_t dmlTask = NULLTAG;
					dmlTask = ErcTaskTags[j];
					char* dmlTaskReleaseStatusStr = NULL;
					char* dmlTaskNo = NULL;
					CALLAPI(AOM_UIF_ask_value(dmlTask,"release_status_list",&dmlTaskReleaseStatusStr));
					CALLAPI(AOM_ask_value_string(dmlTask,"item_id",&dmlTaskNo));
					
					printf("\nDigVld:111---DML Task [%s] release status:[%s]\n",dmlTaskNo,dmlTaskReleaseStatusStr);fflush(stdout);
					//check the lc step of ERC dml task.
					tag_t  	taskjob         = NULLTAG;
					tag_t  	task_job_type   = NULLTAG;
					tag_t  	roottask        = NULLTAG;				
					CALLAPI(EPM_get_current_job(dmlTask,&taskjob,&task_job_type));			
					if (taskjob != NULLTAG)
					{
						int taskcount = 0;
						char* nameofroot = NULL;
						tag_t* subtasks = NULLTAG;
						CALLAPI(EPM_ask_root_task(taskjob,&roottask));
						
						CALLAPI(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks));
						CALLAPI(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
						printf("\nDigVld:Name of Root task:[%s]\n",nameofroot);fflush(stdout);
						if (taskcount>0)
						{
							printf("\nDigVld:taskcount:[%d]\n",taskcount);fflush(stdout);
							int k = 0;
							for(k=0;k<taskcount;k++)
							{
								char* taskstatus = NULL;
								char* SubtaskType = NULL;
								CALLAPI(AOM_UIF_ask_value(subtasks[k],"task_state",&taskstatus));
								CALLAPI(AOM_ask_value_string(subtasks[k],"task_type",&SubtaskType));
								
								printf("\nDigVld:taskstatus:[%s], subtasktype:[%s]\n",taskstatus,SubtaskType);fflush(stdout);
								if(tc_strstr(taskstatus,"Started")!=NULL)
								{
									char* lcStepName = NULL;
									
									
									CALLAPI(AOM_UIF_ask_value(subtasks[k],"object_name",&lcStepName));
									printf("\nDigVld:Assignment Name is  [%s] \n",lcStepName);fflush(stdout);
									char* lcStepName1 = (char*)MEM_alloc(300*sizeof(char*) + tc_strlen(lcStepName)*sizeof(char*));
									tc_strcpy(lcStepName1,",");
									tc_strcat(lcStepName1,lcStepName);
									tc_strcat(lcStepName1,",");
									printf("\nDigVld:Assignment Name is lcStepName1:[%s] \n",lcStepName);fflush(stdout);
									if((tc_strcmp(lcStepName,"Add Items for Gate maturation")==0)|| (tc_strcmp(lcStepName,"Add solution items")==0) || (tc_strcmp(lcStepName,"Check for VC BOM from solution Items and Attach VOD")==0)|| (tc_strstr(info7,lcStepName1)!=NULL) )
									{
										allowedFlag = 1;
										break;
									}
								}
							}
							
						}
						
						
					}
					
				}

			
			
				printf("\nDigVld:allowedFlag ===>[%d]\n",allowedFlag);fflush(stdout);
				if(allowedFlag !=1)
				{
					//throw error
					printf("\nDigVld:Error!!!.Please delete document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"\n");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please delete document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"");
					return ITK_err;
				}
				else
				{
					printf("\nDigVld:Allowed to attach digital valid doc.\n");fflush(stdout);
				}
			}
			else
			{
				//throw error
				printf("\nDigVld:Error!!!No DML attached to the Vehicle.Please delete document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"\n");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please delete document only at \"Add solution items\" or \"Check for VC BOM from solution Items and Attach VOD\" or \"Add Items for Gate maturation\"");
				return ITK_err;
				
			}
		}
		else
		{
			//error
			printf("\nDigVld:Error!!! Only Digital validation Document allowed to be attached here...\n");
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach only Digital Validation Document dataset.");
			return ITK_err;
			
		}
	}
	
	
	
	printf("\nDigVld:End---T5VehHasDigitalVldRelationDelVal------\n");fflush(stdout);
	return ifail;
}

/***************END- Extensions Functions *****************************/



/*************User Services ***************/
extern int tm_DigitalValidationFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	//Digital validation Document creation logic starts
	
	int n_args = 4;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//Selected vehicle
	input_arg_type[1]=USERARG_STRING_TYPE;//Part No
	input_arg_type[2]=USERARG_STRING_TYPE;//Revision
	input_arg_type[3]=USERARG_STRING_TYPE;//DR Status
	ret_value_type = USERARG_STRING_TYPE;

	ifail=USERSERVICE_register_method("tmDigitalValidDocCreServ",(USER_function_t)tmDigitalValidDocCreServ,n_args,input_arg_type,ret_value_type);
	
	
	int n_args1 = 2;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args1 * sizeof(int));
	
	input_arg_type1[0]=USERARG_TAG_TYPE;//Selected vehicle
	input_arg_type1[1]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//Dataset array
	ret_value_type1 = USERARG_STRING_TYPE;

	ifail=USERSERVICE_register_method("tmDigitalValidDocCreServNew",(USER_function_t)tmDigitalValidDocCreServNew,n_args1,input_arg_type1,ret_value_type1);
	
	
	return ifail;
}
/************End user services******************/


int getDMLDRStatus(tag_t dmlTag, char **drStatus)
{
	int ifail = ITK_ok;
	if(dmlTag != NULLTAG)
	{
		char* objTyp = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&objTyp));
		printf("\nDigVld:DML object type: [%s]", objTyp);fflush(stdout);
		if(tc_strcmp(objTyp,"ChangeRequestRevision")==0)
		{
			char* relzType = NULL;
			char* plntToPlnt = NULL;
			char* dmlDrStatus = NULL;
			
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&relzType));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_PlntToPlnt",&plntToPlnt));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDrStatus));
			printf("\nDigVld:Release Type:[%s], FromPlantToPlant:[%s], Dml Dr Status:[%s]\n",relzType,plntToPlnt,dmlDrStatus);fflush(stdout);
			
			if(tc_strcmp(relzType,"TODR")==0)
			{
				
				if(plntToPlnt!=NULL)
				{
					char* plntToPlntStr = NULL;
					char* fromDr = NULL;
					char* toDr = NULL;
					plntToPlntStr = (char*)MEM_alloc(tc_strlen(plntToPlnt)*sizeof(char*) +50);
					
					tc_strcpy(plntToPlntStr,plntToPlnt);
					
					
					
					printf("\nDigVld:plntToPlntStr:[%s]\n",plntToPlntStr);fflush(stdout);
					
					CALLAPI(STRNG_replace_str(plntToPlntStr," to ",";",&plntToPlntStr));
					printf("\nDigVld:After replace: plntToPlntStr:[%s]\n",plntToPlntStr);fflush(stdout);
					
					fromDr = tc_strtok(plntToPlntStr,";");
					toDr = tc_strtok(NULL,";");
					
					printf("\nDigVld:After tokenization: fromDr:[%s], toDr:[%s]\n",fromDr,toDr);fflush(stdout);
					
					*drStatus = toDr;
					if(plntToPlntStr!=NULL) MEM_free(plntToPlntStr);
				}
				else
				{
					*drStatus = dmlDrStatus;
				}
				
			}
			else 
			{
				*drStatus = dmlDrStatus;
			}

			
		}
		else
		{
			printf("\nDigVld:Not a valid DML Revision object\n");fflush(stdout);
		}
	}		
	
	
	return ifail;
}


int getERCDmlRevTag(tag_t dmlTask,tag_t* dmlRevTag)
{
	int ifail = ITK_ok;
	tag_t tsk_dml_rel_type = NULLTAG;
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	
	if (tsk_dml_rel_type!=NULLTAG)
	{
		tag_t* dmlTags = NULLTAG;
		int dmlCnt = 0;
		int i = 0;
		tag_t dmlTag = NULLTAG;
		CALLAPI(GRM_list_primary_objects_only(dmlTask,tsk_dml_rel_type,&dmlCnt,&dmlTags));
		
		for (i=0;i<dmlCnt ;i++ )
		{
			logical is_latest = false;
			
			if(ITEM_rev_sequence_is_latest(dmlTags[i],&is_latest));
			printf("\nDigVld: is_latest:[%d]\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\nDigVld: is_latest is not true .....\n");fflush(stdout);
			}
			else
			{
				dmlTag = dmlTags[i];

			}
		}
		
		*dmlRevTag = dmlTag;
	}
	
	return ifail;
}

int checkCorrectDVDocAttached(tag_t* dvDocTags,int dvDocCnt,char* dvDocNameReq,logical *isCorrect)
{
	int ifail = ITK_ok;
	int k = 0;
	*isCorrect = FALSE;
	for(k=0;k<dvDocCnt;k++)
	{
		tag_t dvDocObj = NULLTAG;
		char* dsName = NULL;
		char* relzStatus = NULL;
		dvDocObj = dvDocTags[k];
		CALLAPI(AOM_ask_value_string(dvDocObj,"object_name",&dsName));
		CALLAPI(AOM_UIF_ask_value(dvDocObj,"release_status_list",&relzStatus));
		printf("\nDigVld:dsName:[%s], relzStatus:[%s]\n",dsName,relzStatus);fflush(stdout);
		
		if(tc_strcmp(dvDocNameReq,dsName)==0 && tc_strstr(relzStatus,"ERC Released")!=NULL)
		{
			printf("\nDigVld:Valid DV doc[%s] attached\n",dvDocNameReq);fflush(stdout);
			*isCorrect = TRUE;
			break;
		}
		
		
	}
	
	return ifail;
}

EPM_decision_t tm_IsDigitalValidationDocAttachedFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	const char * prog_name ="tm_IsDigitalValidationDocAttachedFn";
	tag_t cntrlObj = NULLTAG;
	int ifail = ITK_ok;
	
	printf("\nDigVld***START----tm_IsDigitalValidationDocAttachedFn******\n");fflush(stdout);
	ifail = getDigitalValidationDocControlObj(&cntrlObj);
	
	if(cntrlObj != NULLTAG)
	{
		char* info8 = NULL;
		char* info9 = NULL;
		char* info10 = NULL;
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&info8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&info9));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&info10));
		printf("\nDigVld:info8:[%s],info9[%s],info10[%s]\n",info8,info9,info10);fflush(stdout);
		
		if(tc_strcmp(info8,"YES")==0)
		{
			printf("\nDigVld:LIVE for Sign off Validation\n");fflush(stdout);
			tag_t	rootTask = NULLTAG;
			tag_t *targetobjects = NULLTAG;
			int targetobjects_count = 0;
			
			
			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects));
			
			if(targetobjects_count > 0)
			{
				int i =0;
				tag_t objectTypeTag = NULLTAG;
				char *type_name = NULL;
				tag_t dmlTaskTag = NULLTAG;
				
				for(i=0;i<targetobjects_count;i++)
				{
					CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
					CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
					printf("\nDigVld:type_name ==> %s\n", type_name);fflush(stdout);
					if (tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
					{
					    dmlTaskTag = targetobjects[i];
						break;										
							
					}
				}
			
			
				if(dmlTaskTag != NULLTAG)
				{
					char* object_type = NULL;

					CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
					printf("\nDigVld: DML Task object_type is :%s\n",object_type);fflush(stdout);
					if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
					{
						//Get ERC DML object.
						tag_t dmlTag = NULLTAG;
						CALLAPI(getERCDmlRevTag(dmlTaskTag,&dmlTag));
						
						if(dmlTag != NULLTAG)
						{
							char* dmlReleaseType = NULL;
							char* dmlRelTypeDisplayStr = NULL;
							char* dmlBusUnit = NULL;
							char* dmlBusUnitStr = NULL;
				
							CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
							CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
							CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
							CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
							printf("\nDigVld: DML Release Type:[%s]===>[%s]\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
							printf("\nDigVld: DML Business Unit:[%s]===>[%s]\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
							
							char* dmlBusUnitS = NULL;
							dmlBusUnitS = (char*)MEM_alloc(200);
							tc_strcpy(dmlBusUnitS,",");
							tc_strcat(dmlBusUnitS,dmlBusUnit);
							tc_strcat(dmlBusUnitS,",");
							printf("\nDigVld:dmlBusUnitS:[%s]\n",dmlBusUnitS);fflush(stdout);
							
							if(tc_strstr(info9,dmlBusUnitS)!=NULL || tc_strstr(info9,",ALL,")!=NULL)
							{
								int partRevCnt =0;
								tag_t* partRevTags = NULLTAG;
								char* dmlDRStatus = NULL;
								
								ifail = getDMLDRStatus(dmlTag,&dmlDRStatus);
								printf("\nDigVld:dmlDRStatus:[%s]\n",dmlDRStatus);fflush(stdout);
								
								if(tc_strcmp(dmlReleaseType,"Veh")==0)
								{
									printf("\nDigVld:For Vehicle Release DML .......\n");fflush(stdout);			
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partRevCnt,&partRevTags));
									
								}
								else if(tc_strcmp(dmlReleaseType,"TODR")==0)
								{
									printf("\nDigVld:For Gate Maturation Release DML .......\n");fflush(stdout);
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partRevCnt,&partRevTags));
								}
								else
								{
									printf("\nDigVld:Invalid DML Release Type. Skip .......\n");fflush(stdout);
								}
								
								printf("\nDigVld:Part Rev Count:[%d]\n",partRevCnt);fflush(stdout);
								if(partRevCnt > 0)
								{
									int j = 0;
									for(j=0;j<partRevCnt; j++)
									{
										tag_t partRevTag = NULLTAG;
										char* objType = NULL;
										char* partType = NULL;
										char* partTypeStr = NULL;
										char* partNo = NULL;
										char* partRevS = NULL;
										char* revStr = NULL;
										char* seqStr = NULL;
										partRevTag = partRevTags[j];
										CALLAPI(AOM_ask_value_string(partRevTag,"object_type",&objType));
										CALLAPI(AOM_ask_value_string(partRevTag,"t5_PartType",&partType));
										
										
										
										partTypeStr = (char*)MEM_alloc(tc_strlen(partType)*sizeof(char) + 10);
										tc_strcpy(partTypeStr,",");
										tc_strcat(partTypeStr,partType);
										tc_strcat(partTypeStr,",");
										
										printf("\nDigVld:partType:[%s], partTypeStr:[%s]\n",partType,partTypeStr);fflush(stdout);
										if(tc_strcmp(objType,"Design Revision")==0 && (tc_strstr(info10,partTypeStr)!=NULL || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCV")==0))
										{
											char* partNoStr = NULL;
											partNoStr = (char*)MEM_alloc(50*sizeof(char));
											printf("\nDigVld:Valid Part type of the Part. It should be vehicle\n");fflush(stdout);
											CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&partNo));
											CALLAPI (AOM_UIF_ask_value(partRevTag,"item_revision_id",&partRevS));
											tc_strcpy(partNoStr,partNo);
											tc_strcat(partNoStr,"/");
											tc_strcat(partNoStr,partRevS);
											printf("\nDigVld:PartNo:[%s/%s], partNoStr:[%s]\n",partNo,partRevS,partNoStr); fflush(stdout);
											
											
											if(tc_strstr(partRevS,";") != NULL)
											{
												revStr = tc_strtok ( partRevS,";") ;
												seqStr = tc_strtok ( NULL,";") ;	
											}
											printf("\nDigVld:Rev:[%s], Seq:[%s]\n",revStr,seqStr); fflush(stdout);
											
											
											tag_t * dvDocTags = NULLTAG;
											int dvDocCnt = 0;
											CALLAPI(AOM_ask_value_tags(partRevTag,"T5_HasDigitalValidDoc",&dvDocCnt,&dvDocTags));
											
											printf("\nDigVld:Digital Vald Doc,dvDocCnt Count:[%d]\n",partRevCnt);fflush(stdout);
											if(tc_strcmp(dmlReleaseType,"Veh")==0 || tc_strcmp(dmlReleaseType,"TODR")==0)
											{
												char* dvDocNameReq = NULL;
												dvDocNameReq = (char*)MEM_alloc(200*sizeof(char));
												
												if(dvDocCnt>0)
												{
													logical isCorrect = FALSE;
													
													if(tc_strcmp(dmlDRStatus,"DR0")==0 && tc_strcmp(dmlReleaseType,"Veh")==0 )
													{
														tc_strcpy(dvDocNameReq,"");
														tc_strcat(dvDocNameReq,"DV DVP@DR0_");
														tc_strcat(dvDocNameReq,partNo);
														tc_strcat(dvDocNameReq,"_");
														tc_strcat(dvDocNameReq,revStr);
														//Check for DV DVP@DR0_Vehicle number_NR
														
														printf("\nDigVld:dvDocNameReq:[%s]\n",dvDocNameReq);fflush(stdout);
														printf("\nDigVld:Check for \"DV DVP@DR0_Vehicle number_NR\"\n");fflush(stdout);
														
														ifail = checkCorrectDVDocAttached(dvDocTags,dvDocCnt,dvDocNameReq,&isCorrect);
														printf("\nDigVld:Is Valid DV Doc:[%d]\n",isCorrect);fflush(stdout);
														
														if(!isCorrect)
														{
															printf("\nDigVld: %s does not has Digital Validation Document[%s]. Please attach release Digital Validation Doc\n",partNoStr,dvDocNameReq);fflush(stdout);
															char* buff = NULL;
															ifail=T5_WorkFlowHandlerDVErr;
															buff = (char*)MEM_alloc(300*sizeof(char));
															sprintf(buff, "Please attach release digital validation document[%s] to vehicle [%s] in relation \"Has Digital Validation\"", dvDocNameReq,partNoStr);
															EMH_store_error_s1(EMH_severity_error,ifail,buff);
															decision = EPM_nogo;
															if(buff)MEM_free(buff);
															return decision;
														}
													}
													else
													{
														if(tc_strcmp(dmlDRStatus,"DR1")==0)
														{
															tc_strcpy(dvDocNameReq,"");
															tc_strcat(dvDocNameReq,"DV VO Report @DR1_");
															tc_strcat(dvDocNameReq,partNo);
															tc_strcat(dvDocNameReq,"_");
															tc_strcat(dvDocNameReq,revStr);
															//Check for DV DVP@DR0_Vehicle number_NR
															
															printf("\nDigVld:dvDocNameReq:[%s]\n",dvDocNameReq);fflush(stdout);
															//DV VO Report @DR1_Vehicle number_NR
															printf("\nDigVld:Check for \"DV VO Report @DR1_Vehicle number_NR\"\n");fflush(stdout);
															ifail = checkCorrectDVDocAttached(dvDocTags,dvDocCnt,dvDocNameReq,&isCorrect);
															printf("\nDigVld:Is Valid DV Doc:[%d]\n",isCorrect);fflush(stdout);
															
															if(!isCorrect)
															{
																printf("\nDigVld: %s does not has Digital Validation Document[%s]. Please attach release Digital Validation Doc\n",partNoStr,dvDocNameReq);fflush(stdout);
																char* buff = NULL;
																ifail=T5_WorkFlowHandlerDVErr;
																buff = (char*)MEM_alloc(300*sizeof(char));
																sprintf(buff, "Please attach release digital validation document[%s] to vehicle [%s] in relation \"Has Digital Validation\"", dvDocNameReq,partNoStr);
																EMH_store_error_s1(EMH_severity_error,ifail,buff);
																decision = EPM_nogo;
																if(buff)MEM_free(buff);
																return decision;
															}
														}
														else if(tc_strcmp(dmlDRStatus,"DR2")==0)
														{
															tc_strcpy(dvDocNameReq,"");
															tc_strcat(dvDocNameReq,"DV V1 Report @DR2_");
															tc_strcat(dvDocNameReq,partNo);
															tc_strcat(dvDocNameReq,"_");
															tc_strcat(dvDocNameReq,revStr);
															//Check for DV DVP@DR0_Vehicle number_NR
															
															printf("\nDigVld:dvDocNameReq:[%s]\n",dvDocNameReq);fflush(stdout);															
															//DV V1 Report @DR2_Vehicle number_NR
															printf("\nDigVld:Check for \"DV V1 Report @DR2_Vehicle number_NR\"\n");fflush(stdout);
															
															ifail = checkCorrectDVDocAttached(dvDocTags,dvDocCnt,dvDocNameReq,&isCorrect);
															printf("\nDigVld:Is Valid DV Doc:[%d]\n",isCorrect);fflush(stdout);
															
															if(!isCorrect)
															{
																printf("\nDigVld: %s does not has Digital Validation Document[%s]. Please attach release Digital Validation Doc\n",partNoStr,dvDocNameReq);fflush(stdout);
																char* buff = NULL;
																ifail=T5_WorkFlowHandlerDVErr;
																buff = (char*)MEM_alloc(300*sizeof(char));
																sprintf(buff, "Please attach release digital validation document[%s] to vehicle [%s] in relation \"Has Digital Validation\"", dvDocNameReq,partNoStr);
																EMH_store_error_s1(EMH_severity_error,ifail,buff);
																decision = EPM_nogo;
																if(buff)MEM_free(buff);
																return decision;
															}															
														}
														else if(tc_strcmp(dmlDRStatus,"DR3")==0)
														{
															tc_strcpy(dvDocNameReq,"");
															tc_strcat(dvDocNameReq,"DV V2 Report @DR3_");
															tc_strcat(dvDocNameReq,partNo);
															tc_strcat(dvDocNameReq,"_");
															tc_strcat(dvDocNameReq,revStr);
															//Check for DV DVP@DR0_Vehicle number_NR
															
															printf("\nDigVld:dvDocNameReq:[%s]\n",dvDocNameReq);fflush(stdout);															
															//DV V2 Report @DR3_Vehicle number_NR
															printf("\nDigVld:Check for \"DV V2 Report @DR3_Vehicle number_NR\"\n");fflush(stdout);
															
															ifail = checkCorrectDVDocAttached(dvDocTags,dvDocCnt,dvDocNameReq,&isCorrect);
															printf("\nDigVld:Is Valid DV Doc:[%d]\n",isCorrect);fflush(stdout);
															
															if(!isCorrect)
															{
																printf("\nDigVld: %s does not has Digital Validation Document[%s]. Please attach release Digital Validation Doc\n",partNoStr,dvDocNameReq);fflush(stdout);
																char* buff = NULL;
																ifail=T5_WorkFlowHandlerDVErr;
																buff = (char*)MEM_alloc(300*sizeof(char));
																sprintf(buff, "Please attach release digital validation document[%s] to vehicle [%s] in relation \"Has Digital Validation\"", dvDocNameReq,partNoStr);
																EMH_store_error_s1(EMH_severity_error,ifail,buff);
																decision = EPM_nogo;
																if(buff)MEM_free(buff);
																return decision;
															}
														}
														else
														{
															printf("\nDigVld:Not valid DR Status\n");fflush(stdout);
														}
													}
												}
												else
												{
													if(tc_strcmp(dmlDRStatus,"DR0")==0 || tc_strcmp(dmlDRStatus,"DR1")==0 || tc_strcmp(dmlDRStatus,"DR2")==0 || tc_strcmp(dmlDRStatus,"DR3")==0)
													{
														printf("\nDigVld: %s does not has Digital Validation Document. Please attach release Digital Validation Doc\n",partNoStr);fflush(stdout);
														char* buff = NULL;
														ifail=T5_WorkFlowHandlerDVErr;
														buff = (char*)MEM_alloc(300*sizeof(char));
														sprintf(buff, "Please attach release digital validation document to vehicle [%s] in relation \"Has Digital Validation\"", partNoStr);
														EMH_store_error_s1(EMH_severity_error,ifail,buff);
														decision = EPM_nogo;
														if(buff)MEM_free(buff);
														return decision;
													}
													else
													{
														//not applicable
													}
													
												}
												
												
												
												if(dvDocNameReq!= NULL) MEM_free(dvDocNameReq);
											}
											else
											{
												printf("\nInvalid DML Release Type. Skip\n");fflush(stdout);
											}
											
											if(partNoStr!= NULL)MEM_free(partNoStr);
											
										}
										if(partTypeStr!= NULL)MEM_free(partTypeStr);
									}
								}
								
							}
						
							MEM_free(dmlBusUnitS);
						}
					}
				}
			}
			
		}
		else
		{
			printf("\nDigVld:NOT LIVE for Sign off Validation\n");fflush(stdout);
		}
	}
	else
	{
		printf("\nDigVld:Not live for sign off validation\n");fflush(stdout);
	}
	printf("\nDigVld**************END----tm_IsDigitalValidationDocAttachedFn******\n");fflush(stdout);
	
	return decision;
}


/*************Extensions ***************/
extern int tm_DigitalValidation_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
	/* Validation during checkin of Digital Validation Document */
	METHOD_id_t  dvCheckinMethod;
	METHOD_id_t  dvCheckinMethodPreCond;
	
	ifail = METHOD_find_method(RES_Type, RES_checkin_msg,&dvCheckinMethod);
	
	ifail = METHOD_find_method(RES_Type, RES_checkin_msg,&dvCheckinMethodPreCond);
  
	if (dvCheckinMethod.id != NULLTAG)
	{
		//printf("\nDigVld:Inside dvCheckinMethod cond\n");	fflush(stdout);
		ifail = METHOD_add_action(dvCheckinMethod, METHOD_pre_action_type, (METHOD_function_t) digitalValidCheckinValidation, NULL);
	}
	
	if (dvCheckinMethodPreCond.id != NULLTAG)
	{
		//printf("\nDigVld:Inside dvCheckinMethod - pre condition\n");	fflush(stdout);
		ifail = METHOD_add_pre_condition(dvCheckinMethodPreCond, (METHOD_function_t) digitalValidCheckinPreCondValidation, NULL);
		
	}
	
	
	/*********Validation at checkout *****************/
	METHOD_id_t digiVldCheckOutValMethod;
	ifail = METHOD_find_method(RES_Type, RES_checkout_msg,&digiVldCheckOutValMethod);
  
	if (digiVldCheckOutValMethod.id != NULLTAG)
	{
		//printf("\nInside digiVldCheckOutValMethod\n");	fflush(stdout);
		ifail = METHOD_add_action(digiVldCheckOutValMethod, METHOD_pre_action_type, (METHOD_function_t) digitalValidCheckOutValidation, NULL);
	}
	
	/***************Validation during attaching Digital validation doc to Has Digital validation folder **************/
	METHOD_id_t hasDigVldRelCreateMethod;
	ifail = METHOD_find_method("T5_HasDigitalValidDoc", GRM_create_msg,&hasDigVldRelCreateMethod);
	
	if (hasDigVldRelCreateMethod.id != NULLTAG)
	{
		ifail = METHOD_add_action(hasDigVldRelCreateMethod, METHOD_pre_action_type, (METHOD_function_t) T5VehHasDigitalVldRelationCreateVal, NULL);
		//printf("\nDigVld:Registered as METHOD_pre_action_type for T5VehHasDigitalVldRelationCreateVal \n");fflush(stdout);
	}
	
	
	/***************Validation during deleting the relation ****************/
	METHOD_id_t hasDigVldRelDelMethod;
	ifail = METHOD_find_method("T5_HasDigitalValidDoc", TC_delete_msg,&hasDigVldRelDelMethod);

	if(hasDigVldRelDelMethod.id != NULLTAG)
	{
		ifail = METHOD_add_action(hasDigVldRelDelMethod, METHOD_pre_action_type, (METHOD_function_t) T5VehHasDigitalVldRelationDelVal, NULL);
		//printf("\nDigVld:Registered as METHOD_pre_action_type for T5VehHasDigitalVldRelationDelVal \n");fflush(stdout);
	}

   
   /****************Rule Handler for validation *****************************/
   
   	ifail = EPM_register_rule_handler (
							"tm_IsDigitalValidationDocAttached",
							"tm_IsDigitalValidationDocAttached",
							(EPM_rule_handler_t)tm_IsDigitalValidationDocAttachedFn
							);
	
	
    return ifail;
}

/*************End Extensions ***************/

extern DLLAPI int tm_DigitalValidation_register_callbacks ()
{	
    int ifail    = ITK_ok; 
    ifail=CUSTOM_register_exit ( "tm_DigitalValidation", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_DigitalValidation_register_method);
	
	ifail=CUSTOM_register_exit ( "tm_DigitalValidation", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_DigitalValidationFn);
	
  return ( ITK_ok );
}

