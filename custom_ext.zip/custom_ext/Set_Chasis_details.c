/********************************************************************************************************
*  File			: Set_Chasis_details.c
*  Created By	: Bhaskar Dimble
*  Created On	: 07-Jan-2019
*  Project		: TCUA 	 
*  Purpose		: Custom user exit for - SVR adn Child SVR relation creation
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"

extern DLLAPI int Set_Chasis_details(METHOD_message_t *msg, va_list args)
{
	int ifail				= ITK_ok;
	int count				= 0;
	int k				= 0;
	
	tag_t  primary_object			= va_arg(args, tag_t);
	tag_t  secondary_object			= va_arg(args, tag_t);
	tag_t  relation_type			= va_arg(args, tag_t);

	tag_t  objTypeTag				= NULLTAG;
	tag_t  objTypeTag1				= NULLTAG;
	tag_t  RelationType				= NULLTAG;
	tag_t  *sec_obj					= NULLTAG;
	tag_t  secondaryobj				= NULLTAG;
	tag_t  secondaryobjtype			= NULLTAG;

	char   *objname					= NULL;
	char   *objid				= NULL;
	char	*vehspec				= NULL;
	char	*chdesc					= NULL;
	char	*ErrorText					= NULL;

	char*	type_name= NULL;
	char*	type_name1= NULL;


	printf("\n Set_Chasis_details Function started...");fflush(stdout);
	TC_write_syslog("\n Set_Chasis_details Function started...");
	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n Set_Chasis_details type_name -------->  : %s\n", type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_HasChassisTypeNo")==0) 
	{
		ifail = AOM_UIF_ask_value(primary_object,"t5_VehSpecNo",&vehspec);
		printf("\n vehspec:%s\n",vehspec);fflush(stdout);
		ifail = AOM_UIF_ask_value(primary_object,"t5_ChassisDescription",&chdesc);
		printf("\n chdesc:%s\n",chdesc);fflush(stdout);

		ifail = GRM_ask_secondary (primary_object,&secondaryobj);
		if (TCTYPE_ask_object_type(secondaryobj,&secondaryobjtype)!=ITK_ok);
		if (TCTYPE_ask_name2(secondaryobjtype,&type_name1)!=ITK_ok);
		printf("\n Set_Chasis_details type_name1 -------->  :%s\n", type_name1);fflush(stdout);
		if(tc_strcmp(type_name1,"Design Revision")==0) 
		{
			ifail = AOM_UIF_ask_value(secondaryobj,"item_id",&objid);
			printf("\n objid:[%s]\n",objid);fflush(stdout);
			if(tc_strlen(objid) > 0)
			{
				ifail = AOM_lock( primary_object );
				//ifail = AOM_refresh(primary_object,0);
				ifail = AOM_UIF_set_value(primary_object,"t5_ChassisDescription",objid);
				
				  if(ifail != ITK_ok)
                  {
                  ITK_CALL(AOM_unlock(primary_object));
                  EMH_ask_error_text(ifail,&ErrorText);
                  }
                  else
                  {
                  ITK_CALL(AOM_save_without_extensions(primary_object));
                  ITK_CALL(AOM_refresh(primary_object,0));
                  ITK_CALL(AOM_unlock(primary_object));
                  }
			}
		}
	}
	printf("\n Set_Chasis_details Function end...");fflush(stdout);
	TC_write_syslog("\n Set_Chasis_details Function end...");
	//return ifail;
	return 0;
}
