/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       tm_OneStopSolution.c
*
* Description   : > This register custom user service. Implemented Custom ITK functions for the betterment of Developer easy support
*                                 > This ITK functions are called in Rich Client
* Module
* Since             :   05-04-2024
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 22/05/2023     Manindra Praharaj                    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
         EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

/* Global Declaration of Attribute required for UPL Report Generation*/
char*       objName            = NULL;
char*       objDesc            = NULL;
char*       objRev             = NULL;
char*   output      =       NULL;
//output	=(char *) MEM_alloc(10);
static FILE *fp1;

void  getpathvalue( char *businessunit ,char pathname[200],char filestorepathname[200],char Mailto[400])
{
	char *syscd			= NULL;
	char *subsyscd			= NULL;
	char *delind			= NULL;
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 2;
	char *Shellpath			= NULL;
	char *filestorepath			= NULL;
	char *PlantOneChar		= NULL;
	char* viewtocpy		= NULL;
	char *syscdval			= NULL;
	char *subsyscdval			= NULL;
	char *mailtosend			= NULL;
	char *mailtocc			= NULL;
	int max_char_size = 80;
	syscd = (char *)MEM_alloc(max_char_size * sizeof(char));
	subsyscd = (char *)MEM_alloc(max_char_size * sizeof(char));
	delind = (char *)MEM_alloc(max_char_size * sizeof(char));
	syscdval = (char *)MEM_alloc(max_char_size * sizeof(char));
	subsyscdval = (char *)MEM_alloc(max_char_size * sizeof(char));
	//delindval = (char *)MEM_alloc(max_char_size * sizeof(char));
	

	
	tc_strcpy(syscd,"SYSCD");
	tc_strcpy(subsyscd,"SUBSYSCD");


	char *qry_entryCntrl1[] = {syscd,subsyscd};

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		tc_strcpy(syscdval,"OneStopSolution");
		tc_strcpy(subsyscdval,"OneStopSolutionManin");
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]=syscdval;
		qry_valuesCntrl1[1]=subsyscdval;

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n  inside NO Control Object Query not Found \n");fflush(stdout);
	}	
	if(control_number_found1>0)
	{
		

		if(tc_strcmp(businessunit,"CVBU")==0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &Shellpath);
			printf("\nSo the CVBU shell path is : %s\n",Shellpath);fflush(stdout);
			
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &filestorepath);
			printf("\nSo the CVBU file store path is : %s\n",filestorepath);fflush(stdout);
			
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &mailtosend);
			printf("\nTo be in mail is : %s\n",mailtosend);fflush(stdout);
			
	
		}
		if(tc_strcmp(businessunit,"PVBU")==0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &Shellpath);
			printf("\nSo the PVBU shell path is: %s\n",Shellpath);fflush(stdout);
			
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &filestorepath);
			printf("\nSo the PVBU file store path is : %s\n",filestorepath);fflush(stdout);
			
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &mailtosend);
			printf("\nTo be in mail is : %s\n",mailtosend);fflush(stdout);
		}
		if(tc_strlen(Shellpath)>0) 
		{
			printf("\ninside  retruning Shellpath: %s\n",Shellpath);fflush(stdout);
			tc_strcpy(pathname,Shellpath);
			tc_strcpy(filestorepathname,filestorepath);
			tc_strcpy(Mailto,mailtosend);
			
		}
	} 
		
}

int OneStopSolnFuncsvr(void *return_data)
{
    int     status;
    int     Sysreturn      = 	   0;
	int     ifail          =       ITK_ok;
    char    *PartNumber    =       NULL;
    char    *PartRev       =       NULL;
    char    *PartSeq       =       NULL;
    char    *BusinessUnit  =       NULL;
    char    *UserName  =       NULL;
    char    *Rule  =       NULL;
    char    *FunctionalityName  =       NULL;
	tag_t   ObTag          =       NULLTAG;
    tag_t   ObTagRev       =       NULLTAG;
	char*   Itemline       =       NULL;
	Itemline	=(char *) MEM_alloc(22000);
	char*   Itemline2      =       NULL;
	Itemline2	=(char *) MEM_alloc(100);
	BusinessUnit	=(char *) MEM_alloc(20);
	char *CSvalue =       NULL;; // Pointer for strtok
    char *Partnumber1 =       NULL;; // Pointer for strtok
	CSvalue	=(char *) MEM_alloc(30);
	Partnumber1	=(char *) MEM_alloc(30);
	
	//fp1= fopen("/home/praharaj.ttl/NONERCMetaDataFrmTCE/PartListNONERC.txt","w");
	
	
   //printf("\n I am in main program");fflush(stdout);


    USERARG_get_string_argument(&PartNumber);
    USERARG_get_string_argument(&PartRev);
    USERARG_get_string_argument(&PartSeq);
    USERARG_get_string_argument(&BusinessUnit);
    USERARG_get_string_argument(&UserName);
    USERARG_get_string_argument(&Rule);
    USERARG_get_string_argument(&FunctionalityName);
   
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n Input PartNumber :: %s ",PartNumber);fflush(stdout);
    printf("\n Input PartRev :: %s ",PartRev);fflush(stdout);
    printf("\n Input PartSeq :: %s ",PartSeq);fflush(stdout);
    printf("\n Input Business Unit is  :: %s ",BusinessUnit);fflush(stdout);
    printf("\n Input User Name is  :: %s ",UserName);fflush(stdout);
    printf("\n Input User Rule is  :: %s ",Rule);fflush(stdout);
    printf("\n Input FunctionalityName :: %s ",FunctionalityName);fflush(stdout);
	if(tc_strcmp(PartRev,"NA")==0)
	{
		strcpy(Itemline,PartNumber);
		printf("\n Inside Multiple part logic \nBefore TXT format for Rewrite ::%s",Itemline);fflush(stdout);
		int len;
		len		= strlen(Itemline);
		int     i;
		for (i = 0; i < len; i++)
		{
			printf("\n Inside For Loop");fflush(stdout);
			if (Itemline[i] == ';') 
			{
				//printf("\n Inside For loop of IF condition");fflush(stdout);
				Itemline[i] = '\n';
				printf("\n For writing correct STR::%s",Itemline);fflush(stdout);
			}
		}
	
		printf("\n Final TXT format for Rewrite ::%s",Itemline);fflush(stdout);
		
	}
	else
	{
		printf("\n Inside single part logic \nBefore TXT format for Rewrite ::%s",Itemline);fflush(stdout);
		strcpy(Itemline, FunctionalityName);
		strcat(Itemline, "\n");
		strcat(Itemline, PartNumber);
		strcat(Itemline,",");
		strcat(Itemline,PartRev);
		strcat(Itemline,",");
		strcat(Itemline,PartSeq);
		printf("\n Final TXT format is ::%s",Itemline);fflush(stdout);
	}
	
	//fprintf(fp1,"%s,%s,%s\n",Parentpart,PartRev1,PartSeq2);fflush(fp1);
	char shellpathname[200];
	char filestorepath[200];
	char tomail[400];

	getpathvalue(BusinessUnit,shellpathname,filestorepath,tomail);
	printf("\n Shell path name is ::-%s",shellpathname);fflush(stdout);
	printf("\n filestore path name is ::-%s",filestorepath);fflush(stdout);
	printf("\n To mail Name is::-%s",tomail);fflush(stdout);

	//fp1= fopen("/user/cvprod/NONERC_METADATA_TRANSFER/PartListNONERC.txt","w");
	fp1= fopen(filestorepath,"w");
	output	=(char *) MEM_alloc(10);
	fprintf(fp1,"%s",Itemline);fflush(fp1);
	
	
	//strcpy(Itemline2,"/user/cvprod/NONERC_METADATA_TRANSFER/NONERC_Metadata.sh");
	strcpy(Itemline2,shellpathname);
	printf("\n I am in main program");fflush(stdout);
	Sysreturn = system(Itemline2);
	if(Sysreturn == -1)
	{	
		strcpy(output,"No");
		printf("\n sysExecuteAsyn Call Failed For OneStopSolnFuncsvr........... \n");fflush(stdout);
		printf("\n  Mail Portion ....\n");
		if(tc_strcmp(PartRev,"NA")!=0)
		{
			char* Sampleuser1 =NULL;
			char* Sampleuser2 =NULL;
			char* mailcommand =NULL;
			char* dynamicString1 =NULL;
			char* dynamicString2 =NULL;
			char* dynamicString3 =NULL;
			char* dynamicString4 =NULL;
			char* dynamicString5 =NULL;
			char* dynamicString6 =NULL;
			//char* mailcommand =NULL;
			
			Sampleuser1 = (char*) MEM_alloc(500);
			Sampleuser2 = (char*) MEM_alloc(500);
			mailcommand = (char*) MEM_alloc(1000);
			dynamicString1 = (char*) MEM_alloc(50);
			dynamicString2 = (char*) MEM_alloc(50);
			dynamicString3 = (char*) MEM_alloc(50);
			dynamicString4 = (char*) MEM_alloc(50);
			dynamicString5 = (char*) MEM_alloc(50);
			dynamicString6 = (char*) MEM_alloc(50);
			tc_strcpy(dynamicString1,"PartNumber :: ");
			tc_strcat(dynamicString1,Partnumber1);
			tc_strcpy(dynamicString2,"Revision :: ");
			tc_strcat(dynamicString2,PartRev);
			tc_strcpy(dynamicString3,"Sequence :: ");
			tc_strcat(dynamicString3,PartSeq);
			tc_strcpy(dynamicString4,"Fired By :: ");
			tc_strcat(dynamicString4,UserName);
			tc_strcpy(dynamicString5,"User's Group Name :: ");
			tc_strcat(dynamicString5,Rule);
			tc_strcpy(dynamicString6,"Business Unit :: ");
			tc_strcat(dynamicString6,BusinessUnit);
			tc_strcpy(Sampleuser1,"manindrap.ttl@tatamotors.com");
	
			
			if(tc_strcmp(BusinessUnit,"PVBU")==0)
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nPVBU Metadata Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Failed.\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***FAILED UAPROD SYNCH:: TCE-TCUA METADATA STAMPING ***\" -c \" manindrap.ttl@tatamotors.com\" %s", dynamicString1, dynamicString2, dynamicString3, dynamicString4,dynamicString5,dynamicString6, Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
			else
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nCVBU Metada Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Failed\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***FAILED CVPROD SYNCH:: TCE-TCUA METADATA STAMPING***\" -c \"manindrap.ttl@tatamotors.com\" %s", dynamicString1, dynamicString2, dynamicString3, dynamicString4,dynamicString5,dynamicString6,Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
		}
		else
		{
			char* Sampleuser1 =NULL;
			char* Sampleuser2 =NULL;
			char* mailcommand =NULL;
			char* dynamicString1 =NULL;
			char* dynamicString2 =NULL;
			char* dynamicString3 =NULL;
			char* dynamicString4 =NULL;
			char* dynamicString5 =NULL;
			char* dynamicString6 =NULL;
			//char* mailcommand =NULL;
			Sampleuser1 = (char*) MEM_alloc(500);
			Sampleuser2 = (char*) MEM_alloc(500);
			mailcommand = (char*) MEM_alloc(1000);
			dynamicString1 = (char*) MEM_alloc(50);
			dynamicString2 = (char*) MEM_alloc(50);
			dynamicString3 = (char*) MEM_alloc(50);
			dynamicString4 = (char*) MEM_alloc(50);
			dynamicString5 = (char*) MEM_alloc(50);
			dynamicString6 = (char*) MEM_alloc(50);
			tc_strcpy(dynamicString1,"\n PartNumber :: Multiple Parts option Selected by User ");
			tc_strcpy(dynamicString4,"\n Fired By :: ");
			tc_strcat(dynamicString4,UserName);
			tc_strcpy(dynamicString5,"\n User's Group Name :: ");
			tc_strcat(dynamicString5,Rule);
			tc_strcpy(dynamicString6,"\n Business Unit :: ");
			tc_strcat(dynamicString6,BusinessUnit);
			tc_strcpy(Sampleuser1,"manindrap.ttl@tatamotors.com");

			if(tc_strcmp(BusinessUnit,"PVBU")==0)
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nPVBU Metadata Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Failed.\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***FAILED UAPROD SYNCH:: TCE-TCUA METADATA STAMPING ***\" -c \" manindrap.ttl@tatamotors.com\" %s", dynamicString1, dynamicString4,dynamicString5,dynamicString6, Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
			else
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nCVBU Metada Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Failed\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***FAILED CVPROD SYNCH:: TCE-TCUA METADATA STAMPING***\" -c \"manindrap.ttl@tatamotors.com\" %s", dynamicString1, dynamicString4,dynamicString5,dynamicString6,Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
		}
		
	}
	else
	{
		strcpy(output,"Yes");
		printf("\n sysExecuteAsyn Call Success ForNONERCMetadataFuncsvr ....... \n");fflush(stdout);
		// Mail writte body
		if(tc_strcmp(PartRev,"NA")!=0)
		{
			printf("\n  Mail Portion ....\n");
			char* Sampleuser1 =NULL;
			char* Sampleuser2 =NULL;
			char* mailcommand =NULL;
			char* dynamicString1 =NULL;
			char* dynamicString2 =NULL;
			char* dynamicString3 =NULL;
			char* dynamicString4 =NULL;
			char* dynamicString5 =NULL;
			char* dynamicString6 =NULL;
			char* dynamicString7 =NULL;
			//char* mailcommand =NULL;
			Sampleuser1 = (char*) MEM_alloc(500);
			Sampleuser2 = (char*) MEM_alloc(500);
			mailcommand = (char*) MEM_alloc(1000);
			dynamicString1 = (char*) MEM_alloc(50);
			dynamicString2 = (char*) MEM_alloc(50);
			dynamicString3 = (char*) MEM_alloc(50);
			dynamicString4 = (char*) MEM_alloc(50);
			dynamicString5 = (char*) MEM_alloc(50);
			dynamicString6 = (char*) MEM_alloc(50);
			dynamicString7 = (char*) MEM_alloc(100);
			tc_strcpy(dynamicString1,"PartNumber :: ");
			tc_strcat(dynamicString1,Partnumber1);
			tc_strcpy(dynamicString2,"Revision :: ");
			tc_strcat(dynamicString2,PartRev);
			tc_strcpy(dynamicString3,"Sequence :: ");
			tc_strcat(dynamicString3,PartSeq);
			tc_strcpy(dynamicString7,"Functionality Used :: ");
			tc_strcat(dynamicString7,FunctionalityName);
			tc_strcpy(dynamicString4,"Fired By :: ");
			tc_strcat(dynamicString4,UserName);
			tc_strcpy(dynamicString5,"User's Group Name :: ");
			tc_strcat(dynamicString5,Rule);
			tc_strcpy(dynamicString6,"Business Unit :: ");
			tc_strcat(dynamicString6,BusinessUnit);
			tc_strcpy(Sampleuser1,tomail);
			//tc_strcpy(Sampleuser2,ccmail);
			
			if(tc_strcmp(BusinessUnit,"PVBU")==0)
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nPVBU One Stop Solution Utility Used.\nExecution has been Completed and updated Successfully.\nFYI Pls check below details Useability.\nExecution has been Completed and updated Successfully.\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"$$$UAPROD:: ONE STOP SOLUTION UTILITY USED$$$\" -c \" monazirn.ttl@tatamotors.com ac.ttl@tatamotors.com dhrubak.ttl@tatamotors.com\" %s", dynamicString1, dynamicString2, dynamicString3, FunctionalityName, dynamicString4,dynamicString5,dynamicString6, Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
			else
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nCVBU One Stop Solution Utility Used.\nExecution has been Completed and updated Successfully.\nFYI Pls check below details Useability.\n\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"$$$CVPROD:: ONE STOP SOLUTION UTILITY USED$$$\" -c \" monazirn.ttl@tatamotors.com dhrubak.ttl@tatamotors.com\" %s", dynamicString1, dynamicString2, dynamicString3, FunctionalityName, dynamicString4,dynamicString5,dynamicString6,Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}			
		}
		else
		{
			printf("\n  Mail Portion ....\n");
			char* Sampleuser1 =NULL;
			char* Sampleuser2 =NULL;
			char* mailcommand =NULL;
			char* dynamicString1 =NULL;
			char* dynamicString2 =NULL;
			char* dynamicString3 =NULL;
			char* dynamicString4 =NULL;
			char* dynamicString5 =NULL;
			char* dynamicString6 =NULL;
			//char* mailcommand =NULL;
			Sampleuser1 = (char*) MEM_alloc(500);
			Sampleuser2 = (char*) MEM_alloc(500);
			mailcommand = (char*) MEM_alloc(1000);
			dynamicString1 = (char*) MEM_alloc(50);
			dynamicString2 = (char*) MEM_alloc(50);
			dynamicString3 = (char*) MEM_alloc(50);
			dynamicString4 = (char*) MEM_alloc(50);
			dynamicString5 = (char*) MEM_alloc(50);
			dynamicString6 = (char*) MEM_alloc(50);
			tc_strcpy(dynamicString1,"\n PartNumber :: Multiple Parts option Selected by User ");
			tc_strcpy(dynamicString4,"\n Fired By :: ");
			tc_strcat(dynamicString4,UserName);
			tc_strcpy(dynamicString5,"\n User's Group Name :: ");
			tc_strcat(dynamicString5,Rule);
			tc_strcpy(dynamicString6,"\n Business Unit :: ");
			tc_strcat(dynamicString6,BusinessUnit);
			tc_strcpy(Sampleuser1,tomail);
			//tc_strcpy(Sampleuser2,ccmail);
			
			if(tc_strcmp(BusinessUnit,"PVBU")==0)
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nPVBU Metadata Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Completed and updated Successfully.\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***UAPROD SYNCH:: TCE-TCUA METADATA STAMPING SUCCESS***\" -c \" monazirn.ttl@tatamotors.com ac.ttl@tatamotors.com dhrubak.ttl@tatamotors.com\" %s", dynamicString1, dynamicString4,dynamicString5,dynamicString6, Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
			else
			{
				sprintf(mailcommand, "echo -e \"Hello Team,\n\nCVBU Metada Migration Service Invoked from TCUA for Data transfer from TCE.\nExecution has been Completed and updated Successfully.\nFYI Pls check below migration details .\n\n%s\n%s\n%s\n%s\n\nRegards,\nManindra Praharaj\" | Mail -s \"***CVPROD SYNCH:: TCE-TCUA METADATA STAMPING SUCCESS***\" -c \" monazirn.ttl@tatamotors.com dhrubak.ttl@tatamotors.com\" %s", dynamicString1, dynamicString4, dynamicString5, dynamicString6, Sampleuser1);
				system(mailcommand);
				printf("\n Mail send successfudl  ..\n");
			}
		}
		
		
	
	}
	printf("Final output for SHELL Completely Executed(YES/No)::%s",output);
	
	*((char **) return_data) = 
			   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output);
	

/* 	MEM_free(output);
	MEM_free(Itemline);
	MEM_free(CSvalue);
	MEM_free(Partnumber1);
	MEM_free(Sampleuser1);
	MEM_free(Sampleuser2);
	MEM_free(mailcommand);
	MEM_free(dynamicString1);
	MEM_free(dynamicString2);
	MEM_free(dynamicString3);
	MEM_free(dynamicString4);
	MEM_free(dynamicString5);
	MEM_free(dynamicString6); */
	
    return ifail;
}

extern int OneStopSolnUserServiceFntFn()
{
    int ifail = ITK_ok;
    int nargs = 6;
    int retValueType;
    int inputArgTypes[6] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //PartNumber
    inputArgTypes[1] = USERARG_STRING_TYPE; //PartRev
    inputArgTypes[2] = USERARG_STRING_TYPE; //PartSeq
    inputArgTypes[3] = USERARG_STRING_TYPE; //Business Unit
    inputArgTypes[4] = USERARG_STRING_TYPE; //User Name
    inputArgTypes[5] = USERARG_STRING_TYPE; //Rule
    inputArgTypes[6] = USERARG_STRING_TYPE; //Functionality name
 
    retValueType = USERARG_STRING_TYPE ;
 //   printf("\n OneStopSolnUserServiceFntFn before....OneStopSolnFuncsvr");fflush(stdout);
    ifail=USERSERVICE_register_method("OneStopSolnFuncsvr",(USER_function_t)OneStopSolnFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceOneStopSolnFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(OneStopSolnUserServiceFntFn());

    return ifail;
}

extern DLLAPI int tm_OneStopSolution_register_callbacks ()
{

    int ifail    = ITK_ok;
  //  printf("\n Before registering userservice....tm_OneStopSolution");fflush(stdout);
    ifail = CUSTOM_register_exit("tm_OneStopSolution", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceOneStopSolnFn);
 //   printf("\n After registering userservice....tm_OneStopSolution");fflush(stdout);
    return(ITK_ok);
}

