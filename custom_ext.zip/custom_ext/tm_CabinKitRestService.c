
	/******************************************************************************
	* CVS: $Id
	*
	* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
	*
	*
	* *------------------------------------------------------------------------------
	** Filename		:	tm_CabinKitRestService.c
	*
	* Description	: > This register custom user service. Implemented Custom ITK functions for Cabin Kit Restructuring.
	*				  > This ITK functions are called in Rich Client 
	* Module  		        
	* Since		    :   7/18/2023
	* ENVIRONMENT	:   C++, ITK

	*
	* History

	*------------------------------------------------------------------------------
	* Date         	 Name									Description of Change
	* 7/18/2023   	 Nishant Pandey						    Base Code
	* 			

	* -----------------------------------------------------------------------------
	*
	*****************************************************************************/

	#include <time.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <tc/tc.h>
	#include <tc/emh.h>
	#include <bom/bom.h>
	#include <tc/folder.h>
	#include <tccore/aom.h>
	#include <tccore/grm.h>
	#include <tccore/item.h>
	#include <pom/pom/pom.h>
	#include <tc/tc_macros.h>
	#include <bom/bom_attr.h>
	#include <tc/tc_startup.h> 
	#include <pie/pie.h>
	#include <tcinit/tcinit.h>
	#include <tc/preferences.h>
	#include <tccore/aom_prop.h>
	#include <fclasses/tc_string.h>
	#include <tccore/workspaceobject.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	#include <ug_va_copy.h>
	#include <itk/mem.h>
	#include <user_exits/user_exits.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	

	#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

	#define ITK_CALL(x) {           \
		int stat;                     \
		char *err_string;             \
		if( (stat = (x)) != ITK_ok)   \
		{                             \
		EMH_get_error_string (NULLTAG, stat, &err_string);                 \
		printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
		printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
		if(err_string) MEM_free(err_string);                                \
		exit (EXIT_FAILURE);                                                   \
		}                                                                    \
	}



int CabinKitRestFunc(void *return_data)
{
	int 			status;
	int				ifail 				=	ITK_ok;
//	char 			*selectedVehicle	=	NULL;
	char 			*selectedVehicle	=	NULL;
	char 			*selectedVehRev		=	NULL;
	char 			*selectedVehSeq		=	NULL;
	char 			*selectedTask		= 	NULL;
	char 			*userName			= 	NULL;
	
	printf("\n I am in main program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);	
//	USERARG_get_string_argument(&selectedVehicle);	
//	USERARG_get_string_argument(&selectedVehRev);	
//	USERARG_get_string_argument(&selectedVehSeq);	
//	USERARG_get_string_argument(&selectedTask);
//	USERARG_get_string_argument(&userName);
	
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
//	printf("\n Input selectedVehRev :: %s ",selectedVehRev);fflush(stdout);
//	printf("\n Input selectedVehSeq :: %s ",selectedVehSeq);fflush(stdout);
//	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
//	printf("\n Input userName :: %s ",userName);fflush(stdout);

	return ifail;
}



extern int tm_CabinKitRestServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 1;
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE; //vehicle Number
//	inputArgTypes[1] = USERARG_STRING_TYPE; //Rev
//	inputArgTypes[2] = USERARG_STRING_TYPE; //Seq
//	inputArgTypes[3] = USERARG_STRING_TYPE; //Selected Task
//	inputArgTypes[4] = USERARG_STRING_TYPE; //UserName
		
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE; ; 
	printf("\n tm_CabinKitRestServiceCalling before....CabinKitRestFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method("CabinKitRestFunc",(USER_function_t)CabinKitRestFunc,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

extern int tm_CabinKitRestService(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITK_CALL(tm_CabinKitRestServiceCalling());

	return ifail;
}

extern DLLAPI int tm_CabinKitBomRest_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_CabinKitBomRest");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_CabinKitBomRest", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_CabinKitRestService);
	printf("\n After registering userservice....tm_CabinKitBomRest");fflush(stdout);
	return(ITK_ok);
}
