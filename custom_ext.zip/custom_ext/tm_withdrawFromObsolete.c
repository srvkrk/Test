/****************************************************************************************************
*  File				: tm_withdrawFromObsolete.c
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes 
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
//Abhistart
#define PLM_error (EMH_USER_error_base+25)
#define PLM_error1 (EMH_USER_error_base+26)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PLM_error2 (EMH_USER_error_base+26)
#define PLM_error3 (EMH_USER_error_base+26)
#define PLM_error4 (EMH_USER_error_base+26)
//Abhiend

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

char	*DRMismtchPrts = NULL;
tag_t ClrPartQryTag = NULLTAG;
tag_t tsk_HSI_rel_type = NULLTAG;
tag_t tRelationFind = NULLTAG;
tag_t windowClr = NULLTAG;
tag_t ruleClr = NULLTAG;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;



void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;
	int   ifail				= 0;


	CALLAPI(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		CALLAPI(POM_class_of_instance(status_list[0],&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_unload_instances (st_count,status_list));
		CALLAPI(POM_load_instances(st_count,status_list,class_id,1));
		CALLAPI(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//CALLAPI(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//CALLAPI(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//CALLAPI(WSOM_eff_create_with_date_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			CALLAPI(WSOM_eff_create_with_date_text(status_list[0],NULLTAG,"11-MAR-2014 00:00 to UP",&eff_t));
			CALLAPI(AOM_save_with_extensions(status_list[0]));
			CALLAPI(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//CALLAPI(AOM_save_with_extensions(*itemRev));
		//CALLAPI(AOM_unlock(*itemRev));
	}
	  return ITK_ok;
}

int Chg_rlz_Status_Upd_DR_Stutus_WO_DML( EPM_action_message_t msg )
{
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l	,cnt	=0;

		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		tag_t			*objTypeTagTask			= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		tag_t DMLTag = NULLTAG;
		tag_t AssyTag = NULLTAG;
		tag_t PrtTag = NULLTAG;
		tag_t *Dml_tasks= NULLTAG;
		tag_t *PartsTag= NULLTAG;
		tag_t attach = NULLTAG;
		tag_t   release_status =NULLTAG;
		tag_t    	    superuserTag				    =NULLTAG;
		tag_t    	    propEff_tag				    =NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		int  attype = 1,partcnt=0,k=0;

		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			task_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
		char*			Part_no					=NULL;
		char*			PartDRStatus					=NULL;
		char*			ReleaseStatus					=NULL;
		char*			value					=NULL;
		char			*eff_date         = NULL;
		char *FrmDate;
		char *ItemID;
		char *ReviewStartDate=NULL;
		char cNextDate[20]={0};
		char cCurrentAccessDate[20]={0};
		date_t test_date_1;
		date_t cCurrent_date_1;
	    date_t DayTommorow ;
	    date_t test_date_2;
	    date_t *start_end_date = NULL;
	    //date_t *CLdate = NULL;
	    tag_t eff_d = NULLTAG;
		logical  retain_released_date =TRUE;
		logical stat  ;
		//Control Obj
		char	*DMLtype	= NULL;
		char	*info4	= NULL;
		char 	*cPartNo			= NULL;
		char	*latest_rev_Rel_Stus	= NULL;
		char 	*rev_idd				= NULL;
		char	*rel_status				= NULL;
		char 	*status_name			= NULL;
		char 	*EffvalueAfter			= NULL;
		char 	*Effvalue				= NULL;
		char	*old_to_date			= NULL;
		tag_t	*rev_list				= NULL;
		tag_t	*effectivities_tag		= NULL;
		tag_t	*status_lst				= NULL;
		tag_t	LpropEff_tag		= NULLTAG;
		tag_t	Leff_d				= NULLTAG;
		tag_t   *CntrlObjectTag      = NULLTAG;
		tag_t   qryTag     = NULLTAG;
		tag_t	AftpropEff_tag		= NULLTAG;
		tag_t	All_item_tag		= NULLTAG;
		int n_entry    = 1;
		int Item_count      =  0;
		int jj=  0;
		int j=  0;
		int ii      =  0;
		int	n_dtes 	= 0;
		int	n_effectivities 		= 0;
		int	count_status 		= 0;
		int  rsltCount      =  0;
		date_t Ltest_date_2;
		date_t Ltest_date_1;
		date_t *Rel_start_end_values	= NULL;
		date_t *Lstart_end_date			= NULL;
		char   *qry_entry[1]  = {"SYSCD"};
		char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
		WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
		logical date_is_valid  ;
		logical stat1  ;

		tag_t UpdateRlease_t1			= NULLTAG;
		tag_t UpdateRlease_t2			= NULLTAG;
		tag_t UpdateRlease_t3			= NULLTAG;

		POM_get_user(&username,&user_tag);
		printf("\nStarting for taskbreskdownnn :%s....\n",username);fflush(stdout);

		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n WO DML............. \n"); fflush(stdout);

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	    printf("\n CurrentTask: %s\n",CurrentTask);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\n Parent Name: %s\n",parent_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n cCurrentAccessDate : %s\n",cCurrentAccessDate);

		if(strcmp(parent_name,"Withdraw From Obsolete")==0)
		{
			
			CALLAPI(SA_find_user2("infodba",&superuserTag));
			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
				
				for (i=0;i<noAttachment ;i++ )
				{
					char*			object_type1				=NULL;
					DMLTag = attachments[i];
					AOM_ask_value_string(DMLTag,"object_type",&object_type1);
					printf("Target Attachment object_type1:%s\n",object_type1);fflush(stdout);
					
					if(strcmp(object_type1,"ChangeRequestRevision")==0)
					{
						printf("hhhhhhhhhhhhhhhh:%s\n",object_type1);fflush(stdout);
						CALLAPI(AOM_lock(DMLTag));
						CALLAPI(AOM_set_value_string(DMLTag,"CMClosure","Closed"));
						CALLAPI(AOM_set_value_string(DMLTag,"CMMaturity","Complete"));
						CALLAPI(AOM_set_value_string(DMLTag,"CMDisposition","Approved"));
			
						if(ITK_ok != (ifail = AOM_save_with_extensions(DMLTag)))
						{
							return ifail;
						}

						if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
						{
							return ifail;
						}

						CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
						CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

						if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
						{
							CALLAPI(RELSTAT_add_release_status(release_status,1,&DMLTag,retain_released_date));
						}
						if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
						{
							return ifail;
						}
						CALLAPI(AOM_unlock(DMLTag));

						CALLAPI(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&cnt,&Dml_tasks));
						printf("\n Now cnt:%d\n",cnt);fflush(stdout);

						if (cnt>0)
						{
							for (i=0;i<cnt ;i++ )
							{
								 AOM_ask_value_string(Dml_tasks[i],"object_type",&object_type);
								 printf("\n object_type is :%s\n",object_type);fflush(stdout);

								 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
								 {
									getCurrentDateTime(cCurrentAccessDate);
									printf("\n cCurrentAccessDate : %s\n",cCurrentAccessDate);

										
									CALLAPI(AOM_lock(Dml_tasks[i]));
									CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosure","Closed"));
									CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMMaturity","Complete"));
									CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMDisposition","Approved"));
									//CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosureDate",cCurrentAccessDate));

									if(ITK_ok != (ifail = AOM_save_with_extensions(Dml_tasks[i])))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
									{
										return ifail;
									}
									CALLAPI(AOM_unlock(Dml_tasks[i]));


									CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
									CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

									if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
									{
										CALLAPI(RELSTAT_add_release_status(release_status,1,&Dml_tasks[i],retain_released_date));
									}
									if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
									{
										return ifail;
									}

									CALLAPI(AOM_UIF_ask_value(Dml_tasks[i],"Analyst",&DmlAnalyst_name));
									printf("\nDml Task Analyst_name:%s\n",DmlAnalyst_name);fflush(stdout);

									CALLAPI(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem",&partcnt,&PartsTag));
									printf("\n Now partcnt:%d\n",partcnt);fflush(stdout);

							     if (partcnt>0)
							    {
									for (k=0;k<partcnt ;k++ )
									{
										 char*			Partype				=NULL;
										printf("\n for k= %d\n",k);fflush(stdout);
										AssyTag=PartsTag[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n Part_no  is :%s\n",Part_no);	fflush(stdout);
										
										CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&Partype));
										printf("\n Partype  is :%s\n",Partype);	fflush(stdout);
										
										CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartStatus",&PartDRStatus));
										printf("\n PartDRStatus  is :%s\n",PartDRStatus);	fflush(stdout);
										
										CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype));
										printf("\n Part_no:%s  and DML Type: %s\n",Part_no,DMLtype);	fflush(stdout);
										
										tag_t* rlzStatus_list = NULLTAG;
										int rlzStsCount=0;
										int ss =0;
										char	*Prt_Rel_Status	= NULL;
									   CALLAPI(WSOM_ask_release_status_list(AssyTag, &rlzStsCount, &rlzStatus_list));
									   if (rlzStsCount > 0)
										{
											for(ss=0; ss<rlzStsCount ; ss++)
											{
												CALLAPI(AOM_ask_value_string(rlzStatus_list[ss],"object_name",&Prt_Rel_Status));
												printf("\n Prt_Rel_Status: %s",Prt_Rel_Status);fflush(stdout);

												if(strcmp(Prt_Rel_Status,"Obsolete")==0)
												{
													EPM_remove_release_status(AssyTag,rlzStatus_list[ss]);	
													printf("\n Status removed: %s",Prt_Rel_Status);fflush(stdout);
												}
											}
										}
										
										tag_t			tReleaseStatusList_checkin	= NULLTAG;
										char			*class_name					= NULL;
										tag_t			class_id					= NULLTAG;
										
										CALLAPI(POM_class_of_instance(AssyTag,&class_id));
										CALLAPI(POM_name_of_class(class_id,&class_name));
										printf("\n class_name is :%s\n",class_name);fflush(stdout);
										int				n_values_checkin			= 0;
										tag_t*			attr_tags_checkin			= NULLTAG;
			
										logical			*is_it_null_checkin			=   NULL;
										logical			*is_it_empty_checkin		=   NULL;
											int				cunt1						= 0;
											char			*Release_Status				= NULL;
											logical			log1;
											
										int             st_count1					= 0;
										tag_t*			status_list1				= NULLTAG;
											
										CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
										CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1));
										printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
											
										CALLAPI(POM_unload_instances (1,&AssyTag));
										CALLAPI(POM_load_instances(1,&AssyTag,class_id,1));
										CALLAPI(POM_is_loaded(AssyTag,&log1));
										if(log1 == 1)
										{
											 printf("For EPA Rlzd Load Success\n " );fflush(stdout);
										}
										else
										printf("For EPA Rlzd  Load Failure\n"  );fflush(stdout);
										
										CALLAPI( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
										printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
										if(n_values_checkin>0)
										{
											CALLAPI( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
											printf("\n For EPA Rlzd n_values11 is :%d\n",n_values_checkin);fflush(stdout);

											for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
											{
												printf("\n For EPA Rlzd Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
												
												CALLAPI(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
												printf("\n  For EPA Rlzd Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
												
												if(tc_strcmp(Release_Status,"Obsolete")==0 )
												{
													CALLAPI(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));
													printf("\n For EPA Rlzd cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

													CALLAPI(POM_save_instances(1,&AssyTag,1));

													CALLAPI(POM_refresh_instances(1,&AssyTag,class_id,2));

													CALLAPI(AOM_lock(AssyTag));

													CALLAPI(AOM_save_with_extensions(AssyTag));
													CALLAPI(AOM_refresh(AssyTag,1));
													CALLAPI(AOM_unlock(AssyTag));
												}

											}


										}



										CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
										CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

										//if((strcmp(ReleaseStatus,Obsolete")==0))
										//{
											CALLAPI(RELSTAT_add_release_status(release_status,1,&AssyTag,retain_released_date));
										//}
										printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
										
										if (( tc_strcmp(Partype,"VC") == 0 ) || ( tc_strcmp(Partype,"VCCR") == 0 ) )
											{
												if ( ( tc_strcmp(PartDRStatus,"DR4") == 0 ) || ( tc_strcmp(PartDRStatus,"DR5") == 0 )
												|| ( tc_strcmp(PartDRStatus,"AR4") == 0 ) || ( tc_strcmp(PartDRStatus,"AR5") == 0 ) )
												{
													
													CALLAPI(AOM_lock(AssyTag));
													CALLAPI(AOM_set_value_string(AssyTag,"t5_PartStatus","DR3"));
													CALLAPI(AOM_save_with_extensions(AssyTag));
													CALLAPI(AOM_refresh(AssyTag,0));
													CALLAPI(AOM_unlock(AssyTag));
													
													logical havingWriteAccess = false;
													CALLAPI(AM_check_users_privilege(user_tag,AssyTag,"WRITE",&havingWriteAccess));
													CALLAPI(AM_check_users_privilege(user_tag,AssyTag,"WRITE",&havingWriteAccess));
													if(havingWriteAccess==true)
													{
														printf("\nHave write access:\n");fflush(stdout);
													}
													else
													{
														printf("\nHave NO write access:\n");fflush(stdout);
													}
													
													
													CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartStatus",&PartDRStatus));
													printf("\nPart No:%s\n",Part_no);fflush(stdout);
													printf("\nNew Part Comp Code:%s\n",PartDRStatus);fflush(stdout);
												}
											}
									 }

									}

								}

							}

						}
					}
					else
					{
						printf("else Target Attachment object_type1:%s\n",object_type1);fflush(stdout);
					}
				}
			}
		

		 }
		 else
		 {
			printf("\n inside this loop \n");fflush(stdout);
		 }

		return ITK_ok;
}



extern int tm_withdrawFromObsolete_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    METHOD_id_t  method3;
	METHOD_id_t  method4;

    int ifail=0;
    *decision = ALL_CUSTOMIZATIONS;

    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];

    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("Chg_rlz_Status_Upd_DR_Stutus_WO_DML", "", Chg_rlz_Status_Upd_DR_Stutus_WO_DML))
   {
		printf("\t\n Registered Action Handler Chg_rlz_Status_Upd_DR_Stutus_WO_DML\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler Chg_rlz_Status_Upd_DR_Stutus_WO_DML\n");fflush(stdout);
   }




   return ITK_ok;
}

extern DLLAPI int tm_withdrawFromObsolete_register_callbacks()
{
	 CUSTOM_register_exit("tm_withdrawFromObsolete", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_withdrawFromObsolete_register_method);

     printf("\n registered function tm_withdrawFromObsolete_register_method for all DMLs\n");	fflush(stdout);

	 return ( ITK_ok );
}
