
//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Business Object T5_SupSpcImpl

*/

#ifndef TRL001__T5_SUPSPCIMPL_HXX
#define TRL001__T5_SUPSPCIMPL_HXX

#include <T5_tm_mcnlib/T5_SupSpcGenImpl.hxx>

#include <T5_tm_mcnlib/libt5_tm_mcnlib_exports.h>

#define T5_SupSpcPomClassName "T5_SupSpc"

namespace TRL001
{
   class T5_SupSpcImpl; 
   class T5_SupSpcDelegate;
}
 
class  T5_TM_MCNLIB_API TRL001::T5_SupSpcImpl
           : public TRL001::T5_SupSpcGenImpl 
{
public:


   /**
    * Description for the Finalize Create Input
    * @param creInput - desc for  creInput parameter
    * @return - Return desc for Initialize for Create
    */
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    // Constructor for a T5_SupSpc
    explicit T5_SupSpcImpl( T5_SupSpc& busObj );

    // Destructor
    ~T5_SupSpcImpl();


private:
    // Default Constructor for the class
    T5_SupSpcImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_SupSpcImpl( const T5_SupSpcImpl& );

    // Copy constructor
    T5_SupSpcImpl& operator=( const T5_SupSpcImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class TRL001::T5_SupSpcDelegate;

};

#include <T5_tm_mcnlib/libt5_tm_mcnlib_undef.h>
#endif // TRL001__T5_SUPSPCIMPL_HXX
