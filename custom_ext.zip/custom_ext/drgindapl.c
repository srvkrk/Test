#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_Prjerr1 (EMH_USER_error_base + 8)
#define ITK_Prjerr2 (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);fflush(stdout);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);fflush(stdout);	\
			}																\
			return status;													\
		}																	\
	;

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");fflush(stdout);
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);fflush(stdout);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));fflush(stdout);
	printf("Month:%d\n",(timeptr->tm_mon)+1);fflush(stdout);
	printf("Year:%d\n",(timeptr->tm_year+1900));fflush(stdout);
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );fflush(stdout);
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );fflush(stdout);
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);fflush(stdout);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);fflush(stdout);
}

extern EPM_decision_t DLLAPI drgindapl_Check_Func(EPM_rule_message_t msg)
{

	int status;
	int status1;
	int status2;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int cnt = 0;
	int cntErr = 0;
	int AMDrwcntErr = 0;
	int PrtcntErr = 0;
	int DrwcntErr = 0;
	char*	itemid;
	char*	ChildDml;

	char *  IsPPPPMRlzErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line						= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag						= NULLTAG;
	tag_t	item_rev_tag_p						= NULLTAG;
	tag_t	item_rev_task						= NULLTAG;
	tag_t	reln_type_tag						= NULLTAG;


	tag_t	itemTypeTag_cdss					= NULLTAG;
	tag_t	itemclass							= NULLTAG;
	//tag_t	itemclassp							= NULLTAG;
	tag_t	itemclass_task						= NULLTAG;
	tag_t	itemcldclass						= NULLTAG;
	tag_t	value_child_details					= NULLTAG;
	tag_t	objTypeRefTag						= NULLTAG;

	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			task_obj_tag		= NULLTAG;

	int				PartCnt				= 0;
	int				taskCnt				= 0;
	int             st_count			= 0;
	int				n_refs				= 0;
	WSO_description_t desc;


	int				AttCnt				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			task_Tag			= NULLTAG;
	tag_t			task_rev_tag		= NULLTAG;


	char*			Part_no				= NULL;
	char*			Part_type			= NULL;
	char*			Part_DrgNum				= NULL;
	char*			task_no				= NULL;
	char*			inp_task_no			= NULL;
	char			*inp_Plant			= NULL;
	char			*task_Plant			= NULL;
	char            *desid				= NULL;
	char			*dml_type			= NULL;
	char			type_name_ref[TCTYPE_name_size_c+1];
	//char *relationstr;
	char *  PrtWithDrgnull = NULL;
	char *  SetPrtCheckOut = NULL;
	char *  SetAmDrgChk = NULL;
	char *  SetDrwCheckOut = NULL;

	tag_t  datasettype	= NULLTAG;
	tag_t  reln_type = NULLTAG;
	int    n_attchs =0;
	GRM_relation_t *rellist;


	int				task_len=0;
	int				inp_len=0;

	int				ifail				= ITK_ok;
	int				 *levels			= 0;
	tag_t			*referencers		= NULLTAG;

	char			**relations			= NULL;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	int result=0;
	logical isCheckOut=false;
	logical isDrwCheckOut=false;
	int Prt_len=0;
	char*			Part_CmpCode				= NULL;
	char*			Part_Creator				= NULL;
	char*			SpareCriteriaDup				= NULL;

   	printf("\n Inside drgindapl_Check_Func %d.....\n",iNumAttch);fflush(stdout);

if (!SetPrtCheckOut) MEM_free(SetPrtCheckOut);
SetPrtCheckOut=(char *)MEM_alloc(1000);
tc_strcpy(SetPrtCheckOut,"");

if (!SetDrwCheckOut) MEM_free(SetDrwCheckOut);
SetDrwCheckOut=(char *)MEM_alloc(1000);
tc_strcpy(SetDrwCheckOut,"");

if (!PrtWithDrgnull) MEM_free(PrtWithDrgnull);
PrtWithDrgnull=(char *)MEM_alloc(1000);
tc_strcpy(PrtWithDrgnull,"");

if (!SetAmDrgChk) MEM_free(SetAmDrgChk);
SetAmDrgChk=(char *)MEM_alloc(1000);
tc_strcpy(SetAmDrgChk,"");

cntErr=0;
AMDrwcntErr=0;
PrtcntErr=0;
DrwcntErr=0;


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n drgindapl_Check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


    if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
 		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n drgindapl_Check_Func iNumAttch %d.....\n",iNumAttch);fflush(stdout);
		for (i=0; i < iNumAttch; i++)
			{
				tag_t objTypeTag = NULLTAG;
				tag_t objChildRevTag = NULLTAG;

				ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
				printf("\n drgindapl_Check_Func itemid %s.....\n",itemid);fflush(stdout);		

				//ITKCALL(ITEM_find_item(itemid,&itemclass));
				//ITKCALL(ITEM_ask_latest_rev(itemclass,&item_rev_tag));
				//ITKCALL(AOM_ask_value_string(item_rev_tag,"item_id",&inp_task_no));
				printf("\n\n\t\t APL DML Cre:itemid  is :%s",itemid);fflush(stdout);
		
				//if(strstr(inp_task_no,"AM"))
				//{
				inp_len=0;
				inp_len=strlen(itemid);
				if(strstr(itemid,"NONERC"))
				{		
					inp_Plant=subString(itemid,18,inp_len);
				}
				else
				{
					inp_Plant=subString(itemid,14,inp_len);
				}

				printf("\n drgindapl_Check_Func itemid %s \n",itemid);fflush(stdout);
				ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
				ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
				printf("\t  drgindapl_Check_Func type_name ...%s\n", type_name);fflush(stdout);
				if( objTypeTag == ItemTypeTag )
					{
						printf("\t \n drgindapl_Check_Func objTypeTag == ItemTypeTag \n");fflush(stdout);

						ITKCALL (TCTYPE_ask_object_type(pTagAttch[i],&itemTypeTag_cdss));
						ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

						printf("\t  drgindapl_Check_Func type_itemRev ...%s\n", type_itemRev);fflush(stdout);

						if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
						{

    						ITKCALL(AOM_ask_value_tags(pTagAttch[i],"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
							if (PartCnt>0)
							{
								GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
								for (k=0;k<PartCnt ;k++ )
								{
									 char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
									 char **values = (char **) MEM_alloc(1 * sizeof(char *));

									int n_tags_found=0;
									tag_t	*itemclassp	= NULLTAG;
									 tag_t item = NULLTAG;
									printf("\n\n\t\t for k =:%d",k);fflush(stdout);
									AssyTag=PartTags[k];

									ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									printf("\n\n\t\t drgindapl_Check_Func Part_no  is :%s",Part_no);fflush(stdout);
									Prt_len=0;
									Prt_len=strlen(Part_no);
									printf("\n\n\t\t Prt_len is :%d",Prt_len);fflush(stdout);

									 attrs[0] ="item_id";
									 values[0] = (char *)Part_no;
									ITKCALL(ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found, &itemclassp));
									//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
									item = itemclassp[0];
									if(item != NULLTAG )
									ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag_p));


							//	if(nlsStrLen(PartNumberSS)==14 && (nlsStrCmp(OrganizationIDDup,"APLPUNE")==0 || nlsStrCmp(OrganizationIDDup,"APLAHD")==0 || nlsStrCmp(OrganizationIDDup,"APLJSR")==0 || nlsStrCmp(OrganizationIDDup,"APLLKO")==0 || nlsStrCmp(OrganizationIDDup,"APLPNR")==0 || nlsStrCmp(OrganizationIDDup,"APLDWD")==0))
								if( Prt_len==16) // && (nlsStrCmp(OrganizationIDDup,"APLPUNE")==0 || nlsStrCmp(OrganizationIDDup,"APLAHD")==0 || nlsStrCmp(OrganizationIDDup,"APLJSR")==0 || nlsStrCmp(OrganizationIDDup,"APLLKO")==0 || nlsStrCmp(OrganizationIDDup,"APLPNR")==0 || nlsStrCmp(OrganizationIDDup,"APLDWD")==0))
							//	if( Prt_len==6) // && (nlsStrCmp(OrganizationIDDup,"APLPUNE")==0 || nlsStrCmp(OrganizationIDDup,"APLAHD")==0 || nlsStrCmp(OrganizationIDDup,"APLJSR")==0 || nlsStrCmp(OrganizationIDDup,"APLLKO")==0 || nlsStrCmp(OrganizationIDDup,"APLPNR")==0 || nlsStrCmp(OrganizationIDDup,"APLDWD")==0))
								{
									ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type));
									printf("\n\n\t\t drgindapl_Check_Func Part_type  is :%s",Part_type);fflush(stdout);

									ITKCALL(AOM_ask_value_string(AssyTag,"t5_DrawingInd",&Part_DrgNum));
									printf("\n\n\t\t drgindapl_Check_Func Part_DrgNum  is :%s",Part_DrgNum);fflush(stdout);

									ITKCALL(AOM_ask_value_string(AssyTag,"t5_PrtCatCode",&Part_CmpCode));
									printf("\n\n\t\t drgindapl_Check_Func Part_CmpCode  is :%s",Part_CmpCode);fflush(stdout);

									//ITKCALL(AOM_ask_value_string(AssyTag,"owning_user",&Part_Creator));
									ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_user",&Part_Creator));
									printf("\n\n\t\t drgindapl_Check_Func Part_Creator  is :%s",Part_Creator);fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(AssyTag,"t5_SpareCriteria",&SpareCriteriaDup));
									printf("\n\n\t\t drgindapl_Check_Func SpareCriteriaDup  is :%s",SpareCriteriaDup);fflush(stdout);


									//if( (nlsStrCmp(Part_type,"SA") == 0 && nlsStrCmp(SpareCriteriaDup,"PHN") == 0 ) ||  (nlsStrCmp(PrtCatCodeDup,"VC") == 0 &&  (nlsStrCmp(PrtCreatorDup,"Loader") == 0 ||   nlsStrCmp(PrtCreatorDup,"super user") == 0)  ) || (nlsStrCmp(PrtClassDup,"t5SpKit") == 0 ) )
									if( (strcmp(Part_type,"SA") == 0 && strcmp(SpareCriteriaDup,"PHN") == 0 )  ||  ( strcmp(Part_CmpCode,"VC") == 0 &&  (strstr(Part_Creator,"loader")) ) )
									{
										printf("\n For system generated 14 digit parts like 35/36 CED coated parts Parts ,Drawing should not be com:"); fflush(stdout);
										continue ;
									}

									if(strcmp(Part_DrgNum,"D")!=0 && strstr(itemid,"AM")!=NULL) 
									{

										printf("\n Task Number [%s] is : ",itemid);fflush(stdout);
										if(AMDrwcntErr==0)
										{
											AMDrwcntErr=1;
											tc_strcat(SetAmDrgChk,"Below Part is 16 digit part and must have Drawing attachment and Drawing Indicator 'D'");
											tc_strcat(SetAmDrgChk,"\n");
											tc_strcat(SetAmDrgChk,Part_no);

										}
										else
										{
											tc_strcat(SetAmDrgChk,"\n");
											tc_strcat(SetAmDrgChk,Part_no);
											AMDrwcntErr=AMDrwcntErr+1;
											printf("\n SetAmDrgChk: %s\n",SetAmDrgChk);fflush(stdout);
										}

									}

									if( strcmp(Part_DrgNum,"D")==0)
									{
										//FlagDrg=0;
										printf("\n\n\t\t Idrgindapl_Check_Func iside Drawing Number D");fflush(stdout);
										ITKCALL(GRM_find_relation_type("IMAN_specification",&reln_type));
										if(reln_type != NULLTAG)
										{
												//int cnt = 0;
												int atchmt = 0;
												tag_t  primary,objTypeTag=NULLTAG;

												//tag_t	*attachments				= NULLTAG;
												//tag_t	dataset						= NULLTAG;
												//tag_t	refobject						= NULLTAG;
												//tag_t secObjTypeTag	= NULLTAG;

												//char   refname[AE_reference_size_c + 1];
												//AE_reference_type_t     reftype;
												//char   path_name1[SS_MAXPATHLEN]={""};
												//char type_name2[TCTYPE_name_size_c+1];

											//ITK_CALL(GRM_list_secondary_objects_only(AssyTag,reln_type,&cnt,&attachments));
											//printf("\nTotal no of attches =%d\n",cnt);fflush(stdout);
		
											ITK_CALL(GRM_list_secondary_objects(AssyTag,reln_type,&n_attchs,&rellist));
											printf("\n Total n attches =%d\n",n_attchs);fflush(stdout);

											if(n_attchs>0)
											{
												isCheckOut=false;
												ITK_CALL(RES_is_checked_out(AssyTag,&isCheckOut));
												if(isCheckOut)
												{
													printf("\n Part [%s] is  check out....",Part_no);fflush(stdout);
													if(PrtcntErr==0)
													{
														PrtcntErr=1;
														tc_strcat(SetPrtCheckOut,"Drwing Indicator for Below Part is D which is in Checkout State, Please Checkin Part before Release and then proceed");
														tc_strcat(SetPrtCheckOut,"\n");
														tc_strcat(SetPrtCheckOut,Part_no);

													}
													else
													{
														tc_strcat(SetPrtCheckOut,"\n");
														tc_strcat(SetPrtCheckOut,Part_no);
														PrtcntErr=PrtcntErr+1;
														printf("\n SetPrtCheckOut: %s\n",SetPrtCheckOut);fflush(stdout);
													}

												}

												for (atchmt= 0; atchmt < n_attchs; atchmt++)
												{
													printf("\n Inside loop ..............");fflush(stdout);
													//primary=secondary_objects[atchmt];
													primary=rellist[atchmt].secondary;
													//relationstr=rellist[atchmt].the_relation;

													ITKCALL(TCTYPE_ask_object_type(primary,&objTypeTag));
													ITKCALL(TCTYPE_ask_name(objTypeTag,type_name));
													printf("\n Type Name:%s ..............",type_name);fflush(stdout);
													if(strcmp(type_name,"ImanFile")==0)
													continue;

													result = AE_find_datasettype("CMI2Drawing", &datasettype);
													printf("\nType found---->%d",result);fflush(stdout);

													ITKCALL(AOM_ask_value_string(primary,"object_name",&parent_name));
													printf("\n parent_name:%s ..............",parent_name);fflush(stdout);

													if( strcmp(type_name,"CMI2Drawing") ==0 )
													{

														isDrwCheckOut=false;
														ITK_CALL(RES_is_checked_out(primary,&isDrwCheckOut));
														if(isDrwCheckOut)
														{
															if(DrwcntErr==0)
															{
																DrwcntErr=1;
																tc_strcat(SetDrwCheckOut,"Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);

															}
															else
															{
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);
																DrwcntErr=DrwcntErr+1;
																printf("\n SetDrwCheckOut: %s\n",SetDrwCheckOut);fflush(stdout);
															}

														}
									
														
													}

													if( strcmp(type_name,"ProDrw") ==0 ) // Creo drawing
													{
														isDrwCheckOut=false;
														ITK_CALL(RES_is_checked_out(primary,&isDrwCheckOut));
														if(isDrwCheckOut)
														{
															if(DrwcntErr==0)
															{
																DrwcntErr=1;
																tc_strcat(SetDrwCheckOut,"Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);

															}
															else
															{
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);
																DrwcntErr=DrwcntErr+1;
																printf("\n SetDrwCheckOut: %s\n",SetDrwCheckOut);fflush(stdout);
															}

														}
													}


													if( strcmp(type_name,"PDF") ==0 )
													{
														isDrwCheckOut=false;
														ITK_CALL(RES_is_checked_out(primary,&isDrwCheckOut));
														if(isDrwCheckOut)
														{
															if(DrwcntErr==0)
															{
																DrwcntErr=1;
																tc_strcat(SetDrwCheckOut,"Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);

															}
															else
															{
																tc_strcat(SetDrwCheckOut,"\n");
																tc_strcat(SetDrwCheckOut,Part_no);
																DrwcntErr=DrwcntErr+1;
																printf("\n SetDrwCheckOut: %s\n",SetDrwCheckOut);fflush(stdout);
															}

														}
													}

												}
											}
											else
											{
												printf("\n No of Attaches are zeroooo");fflush(stdout);
												
												if(cntErr==0)
												{
													cntErr=1;
													tc_strcat(PrtWithDrgnull,"Drwing Indicator for Below Part is D, Please attached Drawing to it and then Proceed:");
													tc_strcat(PrtWithDrgnull,"\n");
													tc_strcat(PrtWithDrgnull,Part_no);

												}
												else
												{
													tc_strcat(PrtWithDrgnull,"\n");
													tc_strcat(PrtWithDrgnull,Part_no);
													cntErr=cntErr+1;
													printf("\n PrtWithDrgnull: %s\n",PrtWithDrgnull);fflush(stdout);
												}


											
											}
										}

										//printf("\n cntErr: %d\n",cntErr);fflush(stdout);

//										if(cntErr>0)
//										{
//											tc_strcat(SetPrtWithDrgnull,PrtWithDrgnull);
//										}

										
									}
								}
//									else
//									{
//										decision = EPM_go;
//										//return decision;
//									}
													
								}
							}			


									printf("\n PrtWithDrgnull: %s\n",PrtWithDrgnull);fflush(stdout);
									printf("\nstrlen(PrtWithDrgnull):%d",strlen(PrtWithDrgnull));fflush(stdout);
									if(strlen(PrtWithDrgnull)>0)
									{
										printf("\n inside error message  %s \n",PrtWithDrgnull);
										//EMH_clear_errors();
										//status=ITK_ok;
										status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr1,PrtWithDrgnull);
										//decision = EPM_nogo;
										//return ITK_errStore;
									}

									printf("\n SetPrtCheckOut: %s\n",SetPrtCheckOut);fflush(stdout);
									printf("\nstrlen(SetPrtCheckOut):%d",strlen(SetPrtCheckOut));fflush(stdout);
									if(strlen(SetPrtCheckOut)>0)
									{
										printf("\n inside error message  %s \n",SetPrtCheckOut);
										//EMH_clear_errors();
										//status=ITK_ok;
										status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr1,SetPrtCheckOut);
										//decision = EPM_nogo;
										//return ITK_errStore;
									}

									printf("\n SetDrwCheckOut: %s\n",SetDrwCheckOut);fflush(stdout);
									printf("\nstrlen(SetDrwCheckOut):%d",strlen(SetDrwCheckOut));fflush(stdout);
									if(strlen(SetDrwCheckOut)>0)
									{
										printf("\n inside error message  %s \n",SetDrwCheckOut);
										//EMH_clear_errors();
										//status=ITK_ok;
										status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr1,SetDrwCheckOut);
										//decision = EPM_nogo;
										//return ITK_errStore;
									}
										
									printf("\n SetAmDrgChk: %s\n",SetAmDrgChk);fflush(stdout);
									printf("\nstrlen(SetAmDrgChk):%d",strlen(SetAmDrgChk));fflush(stdout);
									if(strlen(SetAmDrgChk)>0)
									{
										printf("\n inside error message  %s \n",SetAmDrgChk);
										//EMH_clear_errors();
										//status=ITK_ok;
										status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr1,SetAmDrgChk);
										//decision = EPM_nogo;
										//return ITK_errStore;
									}

														  
						}
					}
			
			}
	}


if( (strlen(SetDrwCheckOut)>0) || (strlen(SetPrtCheckOut)>0) || (strlen(PrtWithDrgnull)>0) || (strlen(SetAmDrgChk)>0))
{
	decision = EPM_nogo;
	return ITK_errStore;
	printf("\n\n Value of errorrrrrrrr \n");fflush(stdout);
	
}
else
{
	printf("\n\n No Error ");fflush(stdout);
	decision = EPM_go;
}

  //	decision = EPM_go;
	return decision;
}

extern int drgindapl_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

  
	if( ITK_ok == EPM_register_rule_handler ("drgindapl_Check","This Handler is used to display message",(EPM_rule_handler_t)drgindapl_Check_Func))
   {
		printf("\t\n Registered Rule Handler drgindapl_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler drgindapl_register_method\n");fflush(stdout);
   }

    return ITK_ok;
}

extern DLLAPI int drgindapl_register_callbacks()
{
	 CUSTOM_register_exit("drgindapl", "USER_init_module", (CUSTOM_EXIT_ftn_t)drgindapl_register_method);

     printf("\n registered function drgindapl\n");	fflush(stdout);

	 return ( ITK_ok );
}
