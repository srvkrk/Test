/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Deepti Meshram
*  Module		 :   TCUA Desing Rev BOM Uploader
*  Code			 :   t5APLPartBOMCreation.c
*  Created on	 :   March 28, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"



#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

static int initialise_attribute (char *name,  int *attribute)
{

	int mode;
    int status;

	ITK_CALL(BOM_line_look_up_attribute (name, attribute));
	ITK_CALL(BOM_line_ask_attribute_mode (*attribute, &mode));
	if (mode != BOM_attribute_mode_string)
	{ 
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
		exit(0);
	}
	return status;
}

int convertDate(char* date,char* rDate)
{
	int status;

}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		Monthas;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char*	strDay;
	char*	strMon;
	char*	strYear;
	char	DateS[20];
	char* cMonth ;
	char CCMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
//	timeptr = (struct tm *)localtime(&temp);
//	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

//	day=timeptr->tm_mday;
//	month=(timeptr->tm_mon)+1;
//	year=(timeptr->tm_year+1900);

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear);fflush(stdout);
	printf("\n CCMonth:%s\n",CCMonth);fflush(stdout);
	printf("\n strDay:%s\n",strDay);fflush(stdout);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);fflush(stdout);
}


int APLDMLLCSDateStamp(tag_t itemrev,char *lifeCycleS,char *APLRlzdDate,char *STDRlzdDate,FILE *fperror)
{

		int status;
		char* lcsToset=NULL;
		char* erclcsToset=NULL;
		char* aplWrklcsToset=NULL;
		char* aplRlzdlcsToset=NULL;
		char* stdWrklcsToset=NULL;
		char* stdRlzdlcsToset=NULL;
		char* aplReviewlcsToset=NULL;
		char* ercFlag=NULL;
		char* item_seq_upd=NULL;
		char* item_revision_id_upd=NULL;
		char* item_id_upd=NULL;
		char* class_name=NULL;
		char* newSTDIRlzDT=NULL;
    	int	   status_count=0;
    	int	   StatusFlg=0;
    	int	   ss=0;
    	int	   ercStatusFlg=0;
    	int	   aplWrkStatusFlg=0;
    	int	   aplRlzdStatusFlg=0;
    	int	   stdWrkStatusFlg=0;
    	int	   stdRlzdStatusFlg=0;
    	int	   StatusNoFlg=0;
		tag_t* status_list = NULLTAG;
		tag_t apl_release_status = NULLTAG;
		tag_t std_release_status = NULLTAG;
		logical retain_apl_released_date=false;
		logical retain_std_released_date=false;
		tag_t   status_rel                                      = NULLTAG;
		date_t test_date_1;
		date_t test_date_2;
		tag_t apl_eff_d = NULLTAG;
		char FrmNextDate[20]={0};
		char APLRlzDDateCon[20]={0};
		char STDRlzDDateCon[20]={0};
		char ToNextDate[20]={0};
		date_t *start_end_date = NULL;
		date_t *start_end_date_1 = NULL;
		date_t test_date_11;
		date_t test_date_21;
		tag_t std_eff_d = NULLTAG;
		char FrmNextDate1[20]={0};
		char ToNextDate1[20]={0};
		date_t *start_end_date1 = NULL;
		tag_t  DMLClosureDtAttrId = NULLTAG;


		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		erclcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		aplWrklcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		aplRlzdlcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		stdWrklcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		stdRlzdlcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		aplReviewlcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		ercFlag =(char *) MEM_alloc(20 * sizeof(char *));

		printf("\n Inside APLDMLLCSDateStamp\n");fflush(stdout);

		if(strcmp(lifeCycleS,"LcsAPLWrkg")==0)
		{
			printf("\n This is apl wrk...");fflush(stdout);
			strcpy(lcsToset,APLWORKING);
		}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0)
		{
			printf("\n This is apl rel...");fflush(stdout);
			strcpy(lcsToset,APLRELEASED);
		}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0)
		{
			printf("\n This is std wrk...");fflush(stdout);
			strcpy(lcsToset,STDWORKING);
		}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
			printf("\n This is std rel...");fflush(stdout);
			strcpy(lcsToset,STDRELEASED);
		}

		strcpy(erclcsToset,ERCRELEASED);
		strcpy(aplWrklcsToset,APLWORKING);
		strcpy(aplRlzdlcsToset,APLRELEASED);
		strcpy(stdWrklcsToset,STDWORKING);
		strcpy(stdRlzdlcsToset,STDRELEASED);
		strcpy(aplReviewlcsToset,APLREVIEW);


		strcpy(ercFlag,"ERC");

		ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&item_revision_id_upd));
		printf("\n Ckd Out Rev is -->%s\n",item_revision_id_upd); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&item_id_upd));

		
		ITK_CALL( WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
		printf("\n REV status_count: %d\n",status_count);fflush(stdout);
		if (status_count == 0)  /* No Status, so the Item is not yet Released */
		{
			printf("\n No Status, so the Item is not yet Released \n");fflush(stdout);
			StatusNoFlg ++;

		}
		else
		{
			for(ss=0; ss<status_count ; ss++)
			{
				ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
				printf("\n class_name: %s\n",class_name);fflush(stdout);
				if(strcmp(class_name,lcsToset)==0)
				{
					StatusFlg ++;
				}
				else if(strcmp(class_name,erclcsToset)==0)
				{
					ercStatusFlg ++;
				}
				else if(strcmp(class_name,aplWrklcsToset)==0)
				{
					aplWrkStatusFlg ++;
				}
				else if(strcmp(class_name,aplRlzdlcsToset)==0)
				{
					aplRlzdStatusFlg ++;
				}
				else if(strcmp(class_name,stdWrklcsToset)==0)
				{
					stdWrkStatusFlg ++;
				}
				else if(strcmp(class_name,stdRlzdlcsToset)==0)
				{
					stdRlzdStatusFlg ++;
				}
				else if(strcmp(class_name,aplReviewlcsToset)==0)
				{
					aplWrkStatusFlg ++;
				}

			}
		}
		printf("\n StatusFlg: %d\n",StatusFlg);fflush(stdout);
		if(StatusFlg > 0)
		{
			printf("\n 22 StatusFlg: %d\n",StatusFlg);fflush(stdout);
			return status;
		}
		else
		{
			printf("\n11 StatusNoFlg: %d\n",StatusNoFlg);fflush(stdout);
			printf("\n11 StatusNoFlg: %s\n",lcsToset);fflush(stdout);
			if(StatusNoFlg>0)
			{
				if((strcmp(lcsToset,"T5_LcsAPLWrkg")==0))
				{
					printf("\n Inside T5_LcsAPLWrkg Stamping ..");fflush(stdout);
					ITK_CALL(CR_create_release_status(lcsToset,&apl_release_status));
					ITK_CALL(EPM_add_release_status(apl_release_status,1,&itemrev,retain_apl_released_date));
					

				}
				if((strcmp(lcsToset,"T5_LcsAplRlzd")==0))
				{
					
					printf("\n Inside T5_LcsAplRlzd Stamping ..");fflush(stdout);
					ITK_CALL(CR_create_release_status(lcsToset,&apl_release_status));
					ITK_CALL(EPM_add_release_status(apl_release_status,1,&itemrev,retain_apl_released_date));
					
					if(tc_strcmp(APLRlzdDate,"-")!=0)
					{
						getNextDate(APLRlzdDate,APLRlzDDateCon);
						printf("\n APLRlzDDateCon:%s",APLRlzDDateCon);fflush(stdout);
						
						ITK_CALL(ITK_string_to_date(APLRlzDDateCon, &test_date_1 ));						
						
						ITK_CALL(AOM_lock(itemrev));
						ITK_CALL(AOM_set_value_date(itemrev,"t5_APLReleaseDate",test_date_1));
						ITK_CALL(AOM_save(itemrev));
						ITK_CALL(AOM_unlock(itemrev));

					}
					
			

				}
				if((strcmp(lcsToset,"T5_LcsSTDWrkg")==0))
				{
					
					printf("\n Inside T5_LcsSTDWrkg Stamping ..");fflush(stdout);
					ITK_CALL(CR_create_release_status("T5_LcsAplRlzd",&apl_release_status));
					ITK_CALL(EPM_add_release_status(apl_release_status,1,&itemrev,retain_apl_released_date));
					
					if(tc_strcmp(APLRlzdDate,"-")!=0)
					{
						getNextDate(APLRlzdDate,APLRlzDDateCon);
						printf("\n APLRlzDDateCon:%s",APLRlzDDateCon);fflush(stdout);
						
						ITK_CALL(ITK_string_to_date(APLRlzDDateCon, &test_date_1 ));						

						ITK_CALL(AOM_lock(itemrev));
						ITK_CALL(AOM_set_value_date	(itemrev,"t5_APLReleaseDate",test_date_1));
						ITK_CALL(AOM_save(itemrev));
						ITK_CALL(AOM_unlock(itemrev));

					}
					
					printf("\n APL Eff and Release status stamped ..");fflush(stdout);
				

					ITK_CALL(CR_create_release_status(lcsToset,&std_release_status));
					ITK_CALL(EPM_add_release_status(std_release_status,1,&itemrev,retain_std_released_date));

					
				}
				if((strcmp(lcsToset,"T5_LcsStdRlzd")==0))
				{
				
					printf("\n Inside T5_LcsStdRlzd Stamping ..");fflush(stdout);
					

					ITK_CALL(CR_create_release_status("T5_LcsAplRlzd",&apl_release_status));
					ITK_CALL(EPM_add_release_status(apl_release_status,1,&itemrev,retain_apl_released_date));

					if(tc_strcmp(APLRlzdDate,"-")!=0)
					{
						getNextDate(APLRlzdDate,APLRlzDDateCon);
						printf("\n APLRlzDDateCon:%s",APLRlzDDateCon);fflush(stdout);
						
						ITK_CALL(AOM_lock(itemrev));
						ITK_CALL(ITK_string_to_date(APLRlzDDateCon, &test_date_1 ));						
						ITK_CALL(AOM_set_value_date	(itemrev,"t5_APLReleaseDate",test_date_1));
						ITK_CALL(AOM_save(itemrev));
						ITK_CALL(AOM_unlock(itemrev));
						

					}

					ITK_CALL(CR_create_release_status(lcsToset,&std_release_status));
					ITK_CALL(EPM_add_release_status(std_release_status,1,&itemrev,retain_std_released_date));

					if(tc_strcmp(STDRlzdDate,"-")!=0)
					{
						newSTDIRlzDT=strtok(STDRlzdDate,"-");

						getNextDate(newSTDIRlzDT,STDRlzDDateCon);
						printf("\n STDRlzDDateCon:%s",STDRlzDDateCon);fflush(stdout);
						
						ITK_CALL(AOM_lock(itemrev));
						ITK_CALL(ITK_string_to_date(STDRlzDDateCon, &test_date_2 ));						
						//ITK_CALL(AOM_set_value_date	(itemrev,"date_released",test_date_2));

						ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
						ITK_CALL(AOM_refresh(itemrev,TRUE));
						ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

						ITK_CALL(AOM_save(itemrev));
						ITK_CALL(AOM_unlock(itemrev));

						/*if(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&NewDMLAttrId));
						if(AOM_refresh(APLDMLTag,TRUE));
						if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						if(POM_set_attr_string(1,&APLDMLTag,NewDMLAttrId,apldmlno));
						if(AOM_save(APLDMLTag));
						if(AOM_refresh(APLDMLTag,TRUE));*/

					}
					printf("\n STD Eff and Release status stamped ..");fflush(stdout);

					
				}

					
			}
			else
			{
				fprintf(fperror,"ERC Release Status not found on Part :[%s],[%s]\n",item_id_upd,item_revision_id_upd);
				//printf("ERC Release Status not found on Part :[%s],[%s],[%s]\n",item_id_upd,item_revision_id_upd,item_seq_upd);
				printf("ERC Release Status not found on Part :[%s],[%s]",item_id_upd,item_revision_id_upd);fflush(stdout);
			}
		
		
		
		}
		

		

		
  return status;
}

extern int ITK_user_main (int argc, char ** argv )
{    
	
	int status;
	char *inputfile=NULL;
	char *PlantName=NULL;
	char *dmlNo=NULL;
	char *designGrp=NULL;
	char *dmlNoLCS=NULL;
	char *dmlAPLRlzdDt=NULL;
	char *dmlSTDSIRlzdDt=NULL;
	char *dmlTaskNo=NULL;
	char *dmlTaskLCS=NULL;
	char *dmlTaskAPLRlzdDt=NULL;
	char *dmlTaskSTDRlzdDt=NULL;
	char *PartNo=NULL;
	char *PartNoRev=NULL;
	char *PartNoSeq=NULL;
	char *dmlNoCpy=NULL;
	char *inputline=NULL;
	char *ercdmlNo=NULL;
	char *apldmlno=NULL;
	char *item_id=NULL;
	char *DML_no=NULL;
	char *Proj_Code=NULL;
	char *erc_dml_name=NULL;
	char *erc_dml_desc=NULL;
	char *erc_dml_rlzType=NULL;
	char *DmlNoRule=NULL;
	char *sPlntNmeDup1=NULL;
	char *itemRevSeq=NULL;
	char *ercdmlNo1=NULL;

	char *aplAMDmlCreatorDup=NULL;
	char *apldmlNoCpy=NULL;
	//char *Proj_Code=NULL;
	char *aplAMDmlDriverVCDup=NULL;
	//char *erc_dml_desc=NULL;
	char *aplAMLastUpDtDup=NULL;
	char *aplAMLastUpByDup=NULL;
	char *aplDmlNoEcnTypeDup=NULL;
	char *aplDmlNoDRStatusDup=NULL;

	char  dml_type[TCTYPE_name_size_c+1];
	char **DesignGroupList;
	WSO_search_criteria_t  	criteria_erc;

	FILE *fp=NULL;
	FILE *fperror=NULL;
	FILE *fpexception=NULL;
	const char		*erc_dml_qry_entries[1];
	const char		*erc_dml_qry_values[1];
	char			erc_dml_rev_id[TCTYPE_name_size_c+1]="NR";
	char			apl_dml_rev_id[TCTYPE_name_size_c+1]="A";
	char			apl_dml_task_rev_id[TCTYPE_name_size_c+1]="A";
	const char		*apl_dml_qry_entries[1];
	const char		*apl_dml_qry_values[1];
	const char		*apl_dml_task_qry_entries[1];
	const char		*apl_dml_task_qry_values[1];
	int				ercdml_tags_found	= 0;
	tag_t ERCDMLTag = NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	tag_t			*erc_dml_tag	= NULLTAG;
	tag_t	ERCObjTypProj	= NULLTAG;
	int  apl_number_found=0;
	tag_t *list_of_WSO_apl_tags=NULLTAG;
	tag_t *list_of_WSO_apl_task_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	int num=0;	
	char*			tempString			= NULL;
	char*			aplTaskno			= NULL;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t	relation_type= NULLTAG;
	char**			stringArrayAPLD		= NULL;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	int			    	n_strings			= 1;
	int			    	index			= 0;
	int			    	apl_task_number_found			= 0;
	int			    	i			= 0;
		int				l_strings			= 300;
    tag_t  NewDMLAttrId = NULLTAG;
    tag_t  NewDMLRevAttrId = NULLTAG;
	WSO_search_criteria_t  	criteria;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	char*			tempStringt			= NULL;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	char**			stringArrayAPLT		= NULL;
	tag_t  apltaskrelation = NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	const char *attrs[1];
	const char *values[1];
	tag_t *tags_found = NULL;
	int n_tags_found=0;
	tag_t item=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t         Fndrelation = NULLTAG;
	tag_t         FndDMLTaskrelation = NULLTAG;
	tag_t         FndAPLERCDMLrelation = NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	char ChangeaplAMLastUpDtDup[20]={0};
	date_t apl_last_md_dt ;
	date_t *apl_last_md_dt_cpy = NULL;
	

	inputfile = ITK_ask_cli_argument("-i=");
	PlantName = ITK_ask_cli_argument("-plname=");

	ITK_CALL(ITK_auto_login( ));  
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}

	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}

	
	if((tc_strcmp(PlantName,"PlantName1")==0) || (tc_strcmp(PlantName,"PlantName4")==0))
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);

		tc_strcpy(DmlNoRule,"APLC");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName13")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLV");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName2")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLU");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName3")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLP");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName6")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLS");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName8")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLJ");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName9")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLL");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName11")==0)
	{
		DmlNoRule=NULL;
		DmlNoRule=(char *) MEM_alloc(100);
		tc_strcpy(DmlNoRule,"APLD");
		printf("Plant Name After Conversion ==> [%s],[%s]\n",sPlntNmeDup1,DmlNoRule);fflush(stdout);
	}
	else
	{
		printf("\nSYNTEX ERROR :: \n");
		printf("\n PLEASE ENTER CORRECT PLANTNAME(EX:PlantName1,PlantName13,PlantName2 etc..)\n");
		printf("\nTRY AGAIN !!!\n");
		return status;
	}
	
	fp=fopen(inputfile,"r");
	fperror=fopen("error_APLDMLCreation.log","a+");
	fpexception=fopen("Exception_APLDMLCreation.log","a+");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n File rease.");fflush(stdout);
			fputs(inputline,stdout);
			
			//17AM901567_APL^LcsSTDRlzd^2017/02/15^ ^17AM901567_26_APL^LcsSTDRlzd^2017/02/15^ ^285326257907^B^5^

			dmlNo=NULL;
			dmlNoLCS=NULL;
			dmlAPLRlzdDt=NULL;
			dmlSTDSIRlzdDt=NULL;
			dmlTaskNo=NULL;
			designGrp=NULL;
			dmlTaskLCS=NULL;
			dmlTaskAPLRlzdDt=NULL;
			dmlTaskSTDRlzdDt=NULL;
			PartNo=NULL;
			PartNoRev=NULL;
			PartNoSeq=NULL;
			aplAMDmlCreatorDup=NULL;
			erc_dml_name=NULL;
			Proj_Code=NULL;
			aplAMDmlDriverVCDup=NULL;
			erc_dml_desc=NULL;
			aplAMLastUpDtDup=NULL;
			aplAMLastUpByDup=NULL;
			aplDmlNoEcnTypeDup=NULL;
			aplDmlNoDRStatusDup=NULL;
			
			dmlNo=strtok(inputline,"^");
			dmlNoLCS=strtok(NULL,"^");
			dmlAPLRlzdDt=strtok(NULL,"^");
			dmlSTDSIRlzdDt=strtok(NULL,"^");
			dmlTaskNo=strtok(NULL,"^");
			designGrp=strtok(NULL,"^");
			dmlTaskLCS=strtok(NULL,"^");
			dmlTaskAPLRlzdDt=strtok(NULL,"^");
			dmlTaskSTDRlzdDt=strtok(NULL,"^");
			PartNo=strtok(NULL,"^");
			PartNoRev=strtok(NULL,"^");
			PartNoSeq=strtok(NULL,"^");

			printf("\n mod_Part .......%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",dmlNo,dmlNoLCS,dmlAPLRlzdDt,dmlSTDSIRlzdDt,dmlTaskNo,dmlTaskLCS,
			dmlTaskAPLRlzdDt,dmlTaskSTDRlzdDt,PartNo,PartNoRev,PartNoSeq);fflush(stdout);

			ERCDMLTag=NULLTAG;
			if(tc_strstr(dmlNo,"AM")!=NULL)
			{
				printf("\n Inside AM DML dmlNo  :[%s]\n",dmlNo);fflush(stdout);

				aplAMDmlCreatorDup=strtok(NULL,"^");
				erc_dml_name=strtok(NULL,"^");
				Proj_Code=strtok(NULL,"^");
				aplAMDmlDriverVCDup=strtok(NULL,"^");
				erc_dml_desc=strtok(NULL,"^");
				aplAMLastUpDtDup=strtok(NULL,"^");
				aplAMLastUpByDup=strtok(NULL,"^");
				aplDmlNoEcnTypeDup=strtok(NULL,"^");
				aplDmlNoDRStatusDup=strtok(NULL,"^");

				printf("\n aplAMDmlCreatorDup %s:%s:%s:%s:%s:%s:%s:%s:%s\n",aplAMDmlCreatorDup,erc_dml_name,Proj_Code,aplAMDmlDriverVCDup,erc_dml_desc,aplAMLastUpDtDup,
				aplAMLastUpByDup,aplDmlNoEcnTypeDup,aplDmlNoDRStatusDup);fflush(stdout);


				dmlNoCpy=NULL;
				dmlNoCpy=(char *) MEM_alloc(1000);
				tc_strcpy(dmlNoCpy,dmlNo);

				ercdmlNo=strtok(dmlNoCpy,"_");

				apldmlno=NULL;
				apldmlno=(char *) MEM_alloc(1000);

				tc_strcpy(apldmlno,ercdmlNo);
				tc_strcat(apldmlno,"_");
				tc_strcat(apldmlno,DmlNoRule);

				aplTaskno=NULL;
				aplTaskno=(char *) MEM_alloc(1000);

				apldmlNoCpy=NULL;
				apldmlNoCpy=(char *) MEM_alloc(1000);
				tc_strcpy(apldmlNoCpy,dmlNo);

				ercdmlNo1=strtok(apldmlNoCpy,"_");

//				tc_strcpy(aplTaskno,ercdmlNo1);
//				tc_strcat(aplTaskno,"_");
//				tc_strcat(aplTaskno,designGrp);
//				tc_strcat(aplTaskno,"_");
//				tc_strcat(aplTaskno,DmlNoRule);

				tc_strcpy(aplTaskno,dmlTaskNo);
				tc_strcat(aplTaskno,"C");

				printf("\n FOR AMDML aplTaskno is : %s\n",aplTaskno);fflush(stdout);
				ercdml_tags_found=1;
								
			}
			else
			{
				
				ercdml_tags_found=0;
				dmlNoCpy=NULL;
				dmlNoCpy=(char *) MEM_alloc(1000);
				tc_strcpy(dmlNoCpy,dmlNo);

				ercdmlNo=strtok(dmlNoCpy,"_");

				apldmlno=NULL;
				apldmlno=(char *) MEM_alloc(1000);

				tc_strcpy(apldmlno,ercdmlNo);
				tc_strcat(apldmlno,"_");
				tc_strcat(apldmlno,DmlNoRule);

				erc_dml_qry_entries[0] ="item_id";
				erc_dml_qry_values[0] = ercdmlNo;

				erc_dml_tag=NULLTAG;

				ITKCALL(ITEM_find_item_revs_by_key_attributes(1,erc_dml_qry_entries,erc_dml_qry_values,erc_dml_rev_id,&ercdml_tags_found,&erc_dml_tag));
				printf("\n ercdml_tags_found......%d\n",ercdml_tags_found);fflush(stdout);
				if(ercdml_tags_found>0)
				{
					ERCDMLTag=NULLTAG;
					ERCDMLTag = erc_dml_tag[0];
				
					if (ERCDMLTag!=NULLTAG)
					{
						ITKCALL(TCTYPE_ask_object_type(ERCDMLTag,&ERCObjTypProj));
						ITKCALL(TCTYPE_ask_name(ERCObjTypProj,dml_type));
						printf("\n dml_type :: %s\n", dml_type);fflush(stdout);
						if (tc_strcmp(dml_type,"ChangeRequestRevision")==0)
						{
							printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
							
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "item_id", &item_id));
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "current_id", &DML_no));
							ITKCALL(AOM_ask_value_strings(ERCDMLTag,"t5_crdesigngroup",&num,&DesignGroupList));
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "t5_cprojectcode", &Proj_Code));
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "object_name", &erc_dml_name));
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "object_desc", &erc_dml_desc));
							ITKCALL(AOM_ask_value_string( ERCDMLTag, "t5_rlstype", &erc_dml_rlzType));

							printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
							printf("\n item_id : %s\n",item_id);fflush(stdout);
							printf("\n DML_no : %s\n",DML_no);fflush(stdout);
							printf("\n num is : %d\n",num);fflush(stdout);
							printf("\n erc_dml_name is : %s\n",erc_dml_name);fflush(stdout);
							printf("\n erc_dml_desc is : %s\n",erc_dml_desc);fflush(stdout);
							printf("\n apldmlno is : %s\n",apldmlno);fflush(stdout);

							aplTaskno=NULL;
							aplTaskno=(char *) MEM_alloc(1000);

//							tc_strcpy(aplTaskno,item_id);
//							tc_strcat(aplTaskno,"_");
//							tc_strcat(aplTaskno,designGrp);
//							tc_strcat(aplTaskno,"_");
//							tc_strcat(aplTaskno,DmlNoRule);
							
							tc_strcpy(aplTaskno,dmlTaskNo);
							tc_strcat(aplTaskno,"C");

							printf("\n aplTaskno is : %s\n",aplTaskno);fflush(stdout);
						}
					}
				}
			}
							
				
				if(ercdml_tags_found>0)
				{
					apl_dml_qry_entries[0] ="item_id";
					apl_dml_qry_values[0] = apldmlno;
					ITKCALL(ITEM_find_item_revs_by_key_attributes(1,apl_dml_qry_entries,apl_dml_qry_values,apl_dml_rev_id,&apl_number_found,&list_of_WSO_apl_tags));
					
					printf("\n apl_number_found is :[%d]\n",apl_number_found);fflush(stdout);
					if(apl_number_found == 0)
					{
						ITKCALL( TCTYPE_find_type( "T5_APLDML", NULL, &APLDTypeTag) );
						ITKCALL( TCTYPE_construct_create_input( APLDTypeTag, &APLDCreInTag) );

						ITKCALL( TCTYPE_find_type( "T5_APLDMLRevision", NULL, &APLDRevTypeTag) );
						ITKCALL( TCTYPE_construct_create_input( APLDRevTypeTag, &APLDRevCreInTag) );
						
						printf("\n 11erc_dml_name is : %s\n",erc_dml_name);fflush(stdout);
						printf("\n 11erc_dml_desc is : %s\n",erc_dml_desc);fflush(stdout);
						printf("\n 11apldmlno is : %s\n",apldmlno);fflush(stdout);

						//tc_strcpy( stringArrayAPLD[0], apldmlno);
						//ITKCALL( TCTYPE_set_create_display_value(APLDCreInTag, "item_id", 1,(const char**)stringArrayAPLD) );
					
						tc_strcpy( stringArrayAPLD[0], erc_dml_name);
						printf("\n 11erc_dml_name is : %s\n",erc_dml_name);fflush(stdout);
						ITKCALL( TCTYPE_set_create_display_value( APLDCreInTag, "object_name", 1, (const char**)stringArrayAPLD) );
						tc_strcpy( stringArrayAPLD[0], erc_dml_desc);
						printf("\n 11erc_dml_desc is : %s\n",erc_dml_desc);fflush(stdout);
						ITKCALL( TCTYPE_set_create_display_value( APLDCreInTag, "object_desc", 1, (const char**)stringArrayAPLD) );

						ITKCALL( AOM_tag_to_string(APLDRevCreInTag, &tempString) );
						tc_strcpy( stringArrayAPLD[0], tempString);
						printf("\nTest0.D1..[%s]\n",stringArrayAPLD[0]);fflush(stdout);
						ITKCALL( TCTYPE_set_create_display_value( APLDCreInTag, "revision", 1,(const char**)stringArrayAPLD) );

						tc_strcpy( stringArrayAPLD[0], "A");
						ITKCALL( TCTYPE_set_create_display_value( APLDRevCreInTag, "item_revision_id", 1, (const char**)stringArrayAPLD) );

						printf("\nTest1..\n");fflush(stdout);
						ITKCALL( TCTYPE_create_object(APLDCreInTag, &APLDMLTag) );
						printf("\nTest2..\n");fflush(stdout);

						AOM_save(APLDMLTag);

						ITKCALL(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));								

						if (APLDMLTag != NULLTAG)
						{
							if(POM_attr_id_of_attr("item_id","T5_APLDML",&NewDMLAttrId));
							if(AOM_refresh(APLDMLTag,TRUE));
							if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							if(POM_set_attr_string(1,&APLDMLTag,NewDMLAttrId,apldmlno));
							if(AOM_save(APLDMLTag));
							if(AOM_refresh(APLDMLTag,TRUE));


						}

						if (APLDMLRevTag != NULLTAG)
						{
							if(POM_attr_id_of_attr("item_id","T5_APLDMLRevision",&NewDMLRevAttrId));
							if(AOM_refresh(APLDMLRevTag,TRUE));
							if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							if(POM_set_attr_string(1,&APLDMLRevTag,NewDMLRevAttrId,apldmlno));
							if(AOM_save(APLDMLRevTag));
							if(AOM_refresh(APLDMLRevTag,TRUE));

							ITKCALL(AOM_lock(APLDMLRevTag));
							ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_cprojectcode",Proj_Code));
							
							if(tc_strstr(dmlNo,"AM")!=NULL)
							{
								
								if(tc_strcmp(aplAMLastUpDtDup,"-")==0)
								{
									printf("\n Inside if date conversion..");fflush(stdout);	
								}
								else
								{	
									printf("\n Inside else date conversion..");fflush(stdout);
									getNextDate(aplAMLastUpDtDup,ChangeaplAMLastUpDtDup);

									ITK_CALL(ITK_string_to_date(ChangeaplAMLastUpDtDup, &apl_last_md_dt ));

									apl_last_md_dt_cpy = (date_t *)MEM_alloc(sizeof(date_t)*2);
									apl_last_md_dt_cpy[0] = apl_last_md_dt;
									ITKCALL(AOM_set_value_date(APLDMLRevTag,"last_mod_date",apl_last_md_dt_cpy));
								}

								

								printf("\n Inside AMDML data updated\n");fflush(stdout);
								ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_DriverVC",aplAMDmlDriverVCDup));
								ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_EcnType",aplDmlNoEcnTypeDup));							
								//ITKCALL(AOM_set_value_string(APLDMLRevTag,"last_mod_user",aplAMLastUpByDup));
								ITKCALL(AOM_set_value_string_at(APLDMLRevTag,"t5_crdesigngroup",0,designGrp));
								ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_cDRstatus",aplDmlNoDRStatusDup));

							}
							else
							{
								ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_rlstype",erc_dml_rlzType));
								if(num>0)
								{
									for(i=0;i<num;i++)
									{
										ITKCALL(AOM_set_value_string_at(APLDMLRevTag,"t5_crdesigngroup",i,DesignGroupList[i]));
									}
								}
							}
							

							ITKCALL( AOM_save(APLDMLRevTag) );
							ITKCALL( AOM_unlock(APLDMLRevTag) );
						}

						if (ERCDMLTag != NULLTAG && APLDMLRevTag != NULLTAG)
						{
							printf("\n Inside creating relation of APL DML & ERC DML  : %s\n",dmlNo);fflush(stdout);

							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
							ITK_CALL(GRM_find_relation(ERCDMLTag, APLDMLRevTag, relation_type ,&FndAPLERCDMLrelation));
							if(FndAPLERCDMLrelation)
							{
								printf("\n\t  Relation Already Exist b/w ERCDML & APLDML :[%s],[%s]\n",ercdmlNo,apldmlno);fflush(stdout);
								fprintf(fpexception,"\n\t  Relation Already Exist b/w ERCDML & APLDML :[%s],[%s]\n",ercdmlNo,apldmlno);
							}
							else
							{									
								ITKCALL(GRM_create_relation(ERCDMLTag, APLDMLRevTag, relation_type,  NULLTAG, &aplrelation));
								ITKCALL(GRM_save_relation(aplrelation));
								printf("\n APL DML Created for ERC DML  : %s\n",dmlNo);fflush(stdout);
							}									
							

						}

						if (APLDMLRevTag != NULLTAG) 
						{
							printf("\n Calling APLDMLLCSDateStamp for DML Stamping..\n");fflush(stdout);
							
							ITK_CALL(APLDMLLCSDateStamp(APLDMLRevTag,dmlTaskLCS,dmlTaskAPLRlzdDt,dmlTaskSTDRlzdDt,fperror));
						
						}

						

						printf("\n aplTaskno %s\n",aplTaskno);fflush(stdout);

						if((tc_strstr(aplTaskno,"CO")!=NULL)|| (tc_strstr(aplTaskno,"NONERC")!=NULL)|| (tc_strstr(aplTaskno,"PR")!=NULL))
						{
							fprintf(fperror,"\n\t APLDML :[%s] having Task [%s] is not created..\n",apldmlno,aplTaskno);	
							printf("\n\t APLDML :[%s] having Task [%s] is not created..\n",apldmlno,aplTaskno);fflush(stdout);
						}
						else
						{	
							
							WSOM_clear_search_criteria(&criteria);
							strcpy(criteria.name,aplTaskno);
							strcpy(criteria.class_name,"T5_APLTaskRevision");
							status	= WSOM_search(criteria, &apl_task_number_found, &list_of_WSO_tags);

							printf("\n apl_task_number_found %d\n",apl_task_number_found);fflush(stdout);
							if(apl_task_number_found==0)
							{
								ITKCALL( TCTYPE_find_type( "T5_APLTask", NULL, &APLTTypeTag) );
								ITKCALL( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

								ITKCALL( TCTYPE_find_type( "T5_APLTaskRevision", NULL, &APLTRevTypeTag) );
								ITKCALL( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );


								tc_strcpy( stringArrayAPLT[0], aplTaskno);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], erc_dml_name);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );

								ITKCALL( AOM_tag_to_string(APLTRevCreInTag, &tempStringt) );
								tc_strcpy( stringArrayAPLT[0], tempStringt);
								printf("\nTest0.4..[%s]\n",stringArrayAPLT[0]);fflush(stdout);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], "A");
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], designGrp);
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], Proj_Code);
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );

								ITKCALL( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
								ITKCALL( AOM_save(APLTaskTag) );

								ITKCALL(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));

								if (APLTaskRevTag != NULLTAG) 
								{
									printf("\n Calling APLDMLLCSDateStamp for stamping the task...\n");fflush(stdout);
									ITKCALL(APLDMLLCSDateStamp(APLTaskRevTag,dmlNoLCS,dmlAPLRlzdDt,dmlSTDSIRlzdDt,fperror));
								}
								
								
								if ((APLDMLRevTag != NULLTAG) && (APLTaskRevTag != NULLTAG))
								{
									
									printf("\n CREATING REL OF APL DML & TASK...\n");fflush(stdout);

									ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
									ITK_CALL(GRM_find_relation(APLDMLRevTag, APLTaskRevTag, relation_type ,&FndDMLTaskrelation));
									if(FndDMLTaskrelation)
									{
										printf("\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",apldmlno,aplTaskno);fflush(stdout);
										fprintf(fpexception,"\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",apldmlno,aplTaskno);
									}
									else
									{
										ITK_CALL(GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation));
										ITK_CALL(GRM_save_relation(apltaskrelation));
									}

									ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type));

									attrs[0] ="item_id";
									values[0] = (char *)PartNo;

									printf("Part seraching:[%s],[%s],[%s],[%s],[%s]\n",PartNo,PartNoRev,PartNoSeq,attrs[0],values[0]);

									ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
									printf("\n n_tags_found %d...\n",n_tags_found);fflush(stdout);
									if(n_tags_found==0)
									{
										fprintf(fperror,"Part not found  :[%s],[%s],[%s]\n",PartNo,PartNoRev,PartNoSeq);
						
									}
									else
									{
										item = tags_found[0];
										printf("Item already exists\n");fflush(stdout);

										itemRevSeq = NULL;
										itemRevSeq=(char *) MEM_alloc(32);
										strcpy(itemRevSeq,PartNoRev);
										strcat(itemRevSeq,";");
										strcat(itemRevSeq,PartNoSeq);

										printf(" itemRevSeq [%s]\n",itemRevSeq);fflush(stdout);

										ITK_CALL(ITEM_find_revision(item,itemRevSeq,&rev));
										if(rev != NULLTAG)
										{
											ITK_CALL(GRM_find_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type ,&Fndrelation));
											if(Fndrelation)
											{
												printf("\n\t Relation Already Exist:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);fflush(stdout);
												fprintf(fpexception,"\n\t Relation Already Exist:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);
											}
											else
											{
												ITK_CALL(GRM_create_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type,  NULLTAG, &tsk_part_APL_rel));
												ITK_CALL(GRM_save_relation(tsk_part_APL_rel));
											}									
																					
										}
									}

									
								}

								
							
							}
						}

						
					}
					else
					{
						printf("111 DML %s already created .So checking for dml task for processing..\n",apldmlno);
						APLDMLRevTag=list_of_WSO_apl_tags[0];

						printf("\n 1111 aplTaskno %s\n",aplTaskno);fflush(stdout);
						if((tc_strstr(aplTaskno,"CO")!=NULL)|| (tc_strstr(aplTaskno,"NONERC")!=NULL)|| (tc_strstr(aplTaskno,"PR")!=NULL))
						{							
							fprintf(fperror,"\n\t APLDML :[%s] having Task [%s] is not created..\n",apldmlno,aplTaskno);	
							printf("\n\t APLDML :[%s] having Task [%s] is not created..\n",apldmlno,aplTaskno);fflush(stdout);
						}
						else
						{
							apl_dml_task_qry_entries[0] ="item_id";
							apl_dml_task_qry_values[0] = aplTaskno;
							ITKCALL(ITEM_find_item_revs_by_key_attributes(1,apl_dml_task_qry_entries,apl_dml_task_qry_values,apl_dml_task_rev_id,&apl_task_number_found,&list_of_WSO_apl_task_tags));
							
							printf("\n 111 apl_task_number_found %d\n",apl_task_number_found);fflush(stdout);
							if(apl_task_number_found==0)
							{
								ITKCALL( TCTYPE_find_type( "T5_APLTask", NULL, &APLTTypeTag) );
								ITKCALL( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

								ITKCALL( TCTYPE_find_type( "T5_APLTaskRevision", NULL, &APLTRevTypeTag) );
								ITKCALL( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );

								tc_strcpy( stringArrayAPLT[0], aplTaskno);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], erc_dml_name);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );

								ITKCALL( AOM_tag_to_string(APLTRevCreInTag, &tempStringt) );
								tc_strcpy( stringArrayAPLT[0], tempStringt);
								printf("\n 111 Test0.4..[%s]\n",stringArrayAPLT[0]);fflush(stdout);
								ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], "A");
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], designGrp);
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
								tc_strcpy( stringArrayAPLT[0], Proj_Code);
								ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );

								ITKCALL( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
								ITKCALL( AOM_save(APLTaskTag) );
								//ITKCALL( AOM_unlock(APLTaskTag) );


								ITKCALL(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));

								if (APLTaskRevTag != NULLTAG) 
								{
									printf("\n Calling APLDMLLCSDateStamp for stamping the task...\n");fflush(stdout);
									ITKCALL(APLDMLLCSDateStamp(APLTaskRevTag,dmlNoLCS,dmlAPLRlzdDt,dmlSTDSIRlzdDt,fperror));
								}
								
								
								if ((APLDMLRevTag != NULLTAG) && (APLTaskRevTag != NULLTAG))
								{
									ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
									
									ITK_CALL(GRM_find_relation(APLTaskRevTag, APLTaskRevTag, relation_type ,&FndDMLTaskrelation));

									if(FndDMLTaskrelation)
									{
										printf("\n\t 111 Relation Already Exist b/w DML & Task:[%s],[%s]\n",apldmlno,aplTaskno);fflush(stdout);
										fprintf(fpexception,"\n\t Relation Already Exist b/w DML & Task:[%s],[%s]\n",apldmlno,aplTaskno);
									}
									else
									{
										ITK_CALL(GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation));
										ITK_CALL(GRM_save_relation(apltaskrelation));
									}

									ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type));

									attrs[0] ="item_id";
									values[0] = (char *)PartNo;
									ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
									if(n_tags_found==0)
									{
										fprintf(fperror,"Part not found  :[%s],[%s],[%s]\n",PartNo,PartNoRev,PartNoSeq);
						
									}
									else
									{
										item = tags_found[0];
										printf("111 Item already exists\n");fflush(stdout);

										itemRevSeq = NULL;
										itemRevSeq=(char *) MEM_alloc(32);
										strcpy(itemRevSeq,PartNoRev);
										strcat(itemRevSeq,";");
										strcat(itemRevSeq,PartNoSeq);

										printf(" 111 itemRevSeq [%s]\n",itemRevSeq);fflush(stdout);

										ITK_CALL(ITEM_find_revision(item,itemRevSeq,&rev));
										if(rev != NULLTAG)
										{
											ITK_CALL(GRM_find_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type ,&Fndrelation));
											if(Fndrelation)
											{
												printf("\n\t 111 Relation Already Exist b/w task & part:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);fflush(stdout);
												fprintf(fpexception,"\n\t Relation Already Exist b/w task & part:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);
											}
											else
											{
												ITK_CALL(GRM_create_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type,  NULLTAG, &tsk_part_APL_rel));
												ITK_CALL(GRM_save_relation(tsk_part_APL_rel));
											}									
																					
										}
									}
								}

													
							
							}
							else
							{
							
									APLTaskRevTag=list_of_WSO_apl_task_tags[0];
									
									if ((APLDMLRevTag != NULLTAG) && (APLTaskRevTag != NULLTAG))
									{
										GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
										
										ITK_CALL(GRM_find_relation(APLDMLRevTag, APLTaskRevTag, relation_type ,&FndDMLTaskrelation));

										if(FndDMLTaskrelation)
										{
											printf("\n\t 222 Relation Already Exist b/w DML & Task:[%s],[%s]\n",apldmlno,aplTaskno);fflush(stdout);
											fprintf(fpexception,"\n\t Relation Already Exist b/w DML & Task:[%s],[%s]\n",apldmlno,aplTaskno);
										}
										else
										{
											ITK_CALL(GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation));
											ITK_CALL(GRM_save_relation(apltaskrelation));
										}

										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type));

										attrs[0] ="item_id";
										values[0] = (char *)PartNo;
										ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
										if(n_tags_found==0)
										{
											fprintf(fperror,"Part not found  :[%s],[%s],[%s]\n",PartNo,PartNoRev,PartNoSeq);
							
										}
										else
										{
											item = tags_found[0];
											printf("222 Item already exists\n");fflush(stdout);

											itemRevSeq = NULL;
											itemRevSeq=(char *) MEM_alloc(32);
											strcpy(itemRevSeq,PartNoRev);
											strcat(itemRevSeq,";");
											strcat(itemRevSeq,PartNoSeq);

											printf(" 222 itemRevSeq [%s]\n",itemRevSeq);fflush(stdout);

											ITK_CALL(ITEM_find_revision(item,itemRevSeq,&rev));
											if(rev != NULLTAG)
											{
												ITK_CALL(GRM_find_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type ,&Fndrelation));
												if(Fndrelation)
												{
													printf("\n\t 222 Relation Already Exist:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);fflush(stdout);
													fprintf(fpexception,"\n\t Relation Already Exist:[%s],[%s],[%s],[%s]\n",aplTaskno,PartNo,PartNoRev,PartNoSeq);
												}
												else
												{
													ITK_CALL(GRM_create_relation(APLTaskRevTag, rev, tsk_part_sol_rel_type,  NULLTAG, &tsk_part_APL_rel));
													ITK_CALL(GRM_save_relation(tsk_part_APL_rel));
												}									
																						
											}
										}
									}								
							
							}
						}
							
					}
				}
				else
				{
					fprintf(fperror,"\n\t ERC DML Not found : %s.Not not created APLDML\n",ercdmlNo);
	
				
				}
							
			}
		}
				
			


	//ITK_CALL(POM_logout(true));

	if (inputline)MEM_free(inputline);inputline=NULL;
	if (PlantName)MEM_free(PlantName);PlantName=NULL;
	if(dmlNo)MEM_free(dmlNo);dmlNo=NULL;
	if(designGrp)MEM_free(designGrp);designGrp=NULL;
	if(dmlNoLCS)MEM_free(dmlNoLCS);dmlNoLCS=NULL;
	if(dmlAPLRlzdDt)MEM_free(dmlAPLRlzdDt);dmlAPLRlzdDt=NULL;
	if(dmlSTDSIRlzdDt)MEM_free(dmlSTDSIRlzdDt);dmlSTDSIRlzdDt=NULL;
	if(dmlTaskNo)MEM_free(dmlTaskNo);dmlTaskNo=NULL;
	if(dmlTaskLCS)MEM_free(dmlTaskLCS);dmlTaskLCS=NULL;
	if(dmlTaskAPLRlzdDt)MEM_free(dmlTaskAPLRlzdDt);dmlTaskAPLRlzdDt=NULL;
	if(dmlTaskSTDRlzdDt)MEM_free(dmlTaskSTDRlzdDt);dmlTaskSTDRlzdDt=NULL;
	
	
	if(fp)fclose(fp);fp=NULL;
	if(fperror)fclose(fperror);fperror=NULL;
	if(fpexception)fclose(fpexception);fpexception=NULL;
	
	return status;

}
