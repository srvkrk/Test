//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_ControlObjectImpl
//

#ifndef TRL001__T5_CONTROLOBJECTIMPL_HXX
#define TRL001__T5_CONTROLOBJECTIMPL_HXX

#include <T5_tm_controlObj/T5_ControlObjectGenImpl.hxx>

#include <T5_tm_controlObj/libt5_tm_controlobj_exports.h>


namespace TRL001
{
    class T5_ControlObjectImpl; 
    class T5_ControlObjectDelegate;
}

class  T5_TM_CONTROLOBJ_API TRL001::T5_ControlObjectImpl
    : public TRL001::T5_ControlObjectGenImpl
{
public:


    ///
    /// desc for validate for create
    /// @param creInput - desc for creInput parameter
    /// @return - ret desc for validate for create
    ///
    int  validateCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a T5_ControlObject
    explicit T5_ControlObjectImpl( T5_ControlObject& busObj );

    ///
    /// Destructor
    virtual ~T5_ControlObjectImpl();

private:
    ///
    /// Default Constructor for the class
    T5_ControlObjectImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_ControlObjectImpl( const T5_ControlObjectImpl& );

    ///
    /// Copy constructor
    T5_ControlObjectImpl& operator=( const T5_ControlObjectImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_ControlObjectDelegate;

};

#include <T5_tm_controlObj/libt5_tm_controlobj_undef.h>
#endif // TRL001__T5_CONTROLOBJECTIMPL_HXX
