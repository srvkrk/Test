
		/******************************************************************************
		* CVS: $Id
		*
		* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
		*
		*
		* *------------------------------------------------------------------------------
		** Filename		:	GateWayReport.c
		*
		* Description	: > This register custom user service. Implemented Custom ITK functions for generating GateWay Reports
		*				  > This ITK functions are called in Rich Client 
		* Module  		        
		* Since		    :   15-09-2018
		* ENVIRONMENT	:   C++, ITK

		*
		* History

		*------------------------------------------------------------------------------
		* Date         	 Name						Description of Change
		* 15/09/2018   	 Dhrubajyoti/Manoj Kumar			    Base Code
		* 			

		* -----------------------------------------------------------------------------
		*
		*****************************************************************************/

		#include <time.h>
		#include <stdio.h>
		#include <stdlib.h>
		#include <string.h>
		#include <tc/emh.h>
		#include <bom/bom.h>
		#include <tc/folder.h>
		#include <tccore/aom.h>
		#include <tccore/grm.h>
		#include <tccore/item.h>
		#include <pom/pom/pom.h>
		#include <tc/tc_macros.h>
		#include <bom/bom_attr.h>
		#include <tc/tc_startup.h> 
		#include <pie/pie.h>
		#include <tcinit/tcinit.h>
		#include <tc/preferences.h>
		#include <tccore/aom_prop.h>
		#include <fclasses/tc_string.h>
		#include <tccore/workspaceobject.h>
		#include <ss/ss_errors.h>
		#include <sa/user.h>
		#include <stdarg.h>
		#include <tccore/custom.h>
		#include <ict/ict_userservice.h>
		#include <ug_va_copy.h>
		#include <user_exits/user_exits.h>
		#include <user_exits/user_exit_msg.h>
		#include <pom/enq/enq.h>
		#include <cfm/cfm.h>
		#include <ics/ics.h>
		#include <tccore/tctype.h>

		#define _XOPEN_SOURCE 700
		#include <time.h>
		

		#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
		#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

		#define ITK_CALL(x) {           \
			int stat;                     \
			char *err_string;             \
			if( (stat = (x)) != ITK_ok)   \
			{                             \
			EMH_ask_error_text (stat, &err_string);                 \
			printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
			if(err_string) MEM_free(err_string);                                \
			exit (EXIT_FAILURE);                                                   \
			}                                                                    \
		}


		typedef struct
		{
			int     size;
			int     capacity;
			int     increment;
			void  **content;
		} vector_t;

		static vector_t *vector_new( int capacity, int increment );
		static vector_t *vector_add( vector_t *v, void *element );
		static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
		static vector_t *vector_ensure_capacity( vector_t *v, int n );
		static vector_t *vector_free( vector_t *v );
		static vector_t *vector_insert( vector_t *in, void *element );
		static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
		static void *vector_get( const vector_t *v, int index );
		static int vector_size( const vector_t *v );
		static int vector_rem_at( vector_t *in, int n );
		static int vector_rem_n_at( vector_t *in, int n, int at );

		int getAllReleasedPartDML(tag_t query ,char *partNumber,char *object_type, tag_t *latestdml,tag_t *latestPart,tag_t *prevrevpartObj,vector_t **alldmllist,vector_t **allpartlist,int *allpart_dml_cnt,char* FrmDt, char* ToDt,int *total_cnt);

		
		typedef struct BOMHolder
		{

		char VC[40];
		int childCount;
		tag_t *Children;
		//char **childRevModList;
		int *counter;

		}BOMHolder;
		static  unsigned int mHeapOrigin;
		static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
		static void initialise (void);
		static void initialise_attribute (char *name,  int *attribute);
		
		static void  printBom(tag_t query,int bomdepth,tag_t line, int depth,vector_t **ChildTagListGlobal,int *ChildTagList_cntGlobal, vector_t **ChildTagList, int *ChildTagList_cnt, int *BomLvl_cnt, vector_t **bomLevel, vector_t **bom_counter,char* FrmDt, char* ToDt,vector_t **part_dml_vec,int *part_dml_count,vector_t **childRevStrList,tag_t rule,vector_t **global_bom_flag);
		static void print_average (tag_t top_line);
		void dousage()
		{
		printf("\n USAGE: template -u=user -p=password -g=\"\" \n");
		return;
		}
		
		//////////////////VECTOR//////////////



		/*==================================================================================================
			  vector stuff
		==================================================================================================*/
		/**********************************************************************************
		 * Function:          vector_new
		 *
		 * Purpose:           allocates new vector, inital capacity=`capacity'
		 *
		 * Description:       returns a pointer to a dynamically allocated vector or
		 *                    NULL if no memory can be allocated. On success, the
		 *                    vector has a initial capacity of `capacity' and will
		 *                    grow in steps of `increment'.
		 *
		 * Parameters:        int capacity;    initial capacity
		 *                    int increment;    incremental growth rate when needed
		 *
		 * Example:           v = vector_new ( 100, 10 );
		 *
		 * Return Value:      pointer to a dynamically allocated vector
		 *                    NULL if no memory can be allocated
		 *
		 *********************************************************************************/
		static vector_t *vector_new ( int capacity, int increment )
		{
			vector_t *vector;

			vector = (vector_t *)MEM_alloc( sizeof ( vector_t ) );
			if ( vector == NULL ) {
				return NULL;
			}
			vector->size = 0;
			vector->capacity = capacity;
			vector->increment = increment;
			vector->content = (void **)MEM_alloc( capacity * sizeof ( void * ) );
			if ( vector->content == NULL ) {
				MEM_free( vector );
				return NULL;
			}
			return vector;
		}

		/***********************************************************************************
		 * Function:          vector_add
		 *
		 * Purpose:           appaends one pointer at the end of the vector
		 *
		 * Description:       convenient form of vector_add_n(), calls vector_add_n().
		 *
		 * Parameters:        vector_t *in;    vector to which the element is added
		 *                    void *element;    pointer to the element to be added
		 *
		 * Example:           v = vector_add ( v, "line 1" );
		 *
		 * Return Value:      pointer to a potentially dynamically reallocated vector
		 *                    NULL if capacity was not sufficient and no memory can be
		 *                    allocated
		 *
		 ***********************************************************************************/
		static vector_t *vector_add ( vector_t *in, void *element )
		{
			return vector_add_n ( in, 1, &element );
		}

		/***********************************************************************************
		 * Function:          vector_add_n
		 *
		 * Purpose:           appaends n pointers at the end of the vector
		 *
		 * Description:       extend vector `in' if necessary and append n pointers
		 *                    to the (possibly reallocated) vector `in'.
		 *
		 * Parameters:        vector_t *in;        vector to which the element is added
		 *                    int n;                number of elements to append
		 *                    void *elements[];    array of pointers to elements to add
		 *
		 * Example:           v = vector_add_n ( v, argc, (void **)argv );
		 *
		 * Return Value:      pointer to a potentially dynamically reallocated vector
		 *                    NULL if capacity was not sufficient and no memory can be
		 *                    allocated
		 *
		 ***********************************************************************************/
		static vector_t *vector_add_n ( vector_t *in, int n, void *elements[] )
		{
			vector_t *out;

			out = vector_ensure_capacity ( in, n );
			if ( out == NULL ) {
				return NULL;
			}
			memcpy ( &out->content[out->size], elements, n * sizeof ( void * ) );
			out->size += n;
			out->capacity -= n;
			return out;
		}

		/***********************************************************************************
		 * Function:          vector_rem_at
		 *
		 * Purpose:           removes 1 pointer at position `at'
		 *
		 * Description:       convenient form of vector_rem_n_at, calls vector_rem_n_at()
		 *
		 * Parameters:        vector_t *in;        vector of which the element is removed
		 *                    int at;                position of the element to be removed
		 *
		 * Example:           v = vector_add_n ( v, 0 );
		 *
		 * Return Value:      0     if `at' is within bounds [0,`size')
		 *                    2     if `at' is out of bounds [0,`size')
		 *
		 ***********************************************************************************/
		static int vector_rem_at ( vector_t *in, int at )
		{
			return vector_rem_n_at ( in, 1, at );
		}

		/***********************************************************************************
		 * Function:          vector_rem_n_at
		 *
		 * Purpose:           removes n pointers from position `at' on
		 *
		 * Description:       removes `n' pointers beginning at position `at'. Elements
		 *                    beyond position `n'+`at' are block moved upward so that
		 *                    their sequence is not changed.
		 *
		 * Parameters:        vector_t *in;        vector of which the elements are removed
		 *                    int n;                number of elements to remove
		 *                    int at;                position of 1st element to remove
		 *
		 * Example:           v = vector_add_n ( v, 1, 0 );
		 *
		 * Return Value:      0   if `at' is within bounds [0,`size')
		 *                    2   if `at' is out of bounds [0,`size')
		 *
		 ***********************************************************************************/
		static int vector_rem_n_at ( vector_t *in, int n, int at )
		{
			int ret;

			if ( at + n <= in->size ) {
				int i;

				for ( i=at; i<in->size - n; i++ ) {
					in->content[i] = in->content[i+n];
				}
				in->size -= n;
				in->capacity += n;
				ret = 0;
			}
			else {
				fprintf( stderr, "vector_rem_n_at: cannot remove %d elements from position %d in a vector of %d elements\n",
							n, at, in->size );
				ret = 2;
			}
			return ret;
		}

		/***********************************************************************************
		 * Function:          vector_insert
		 *
		 * Purpose:           inserts 1 pointer at position 0
		 *
		 * Description:       inserts 1 pointer at position 0
		 *
		 * Parameters:        vector_t *in;        vector the elements are to be inserted in
		 *                    void *elements;      element to insert
		 *
		 * Example:           v = vector_insert ( v, (void *)argv[1] );
		 *
		 * Return Value:      pointer to a potentially dynamically reallocated vector
		 *                    NULL if capacity was not sufficient and no memory can be
		 *                    allocated
		 *
		 ***********************************************************************************/
		static vector_t *vector_insert ( vector_t *in, void *element )
		{
			return vector_insert_n_at ( in, 1, &element, 0 );
		}

		/***********************************************************************************
		 * Function:          vector_insert_n_at
		 *
		 * Purpose:           inserts `n' pointers at position `at'.
		 *
		 * Description:       inserts `n' pointers at position `at'.
		 *
		 * Parameters:        vector_t *in;        vector the elements are to be inserted in
		 *                    int n;               number of elements to insert
		 *                    void *elements[];    elements to insert
		 *                    int at;              position of 1st element to insert
		 *
		 * Example:           v = vector_add_n ( v, argc, (void **)argv, 0 );
		 *
		 * Return Value:      pointer to a potentially dynamically reallocated vector
		 *                    NULL if capacity was not sufficient and no memory can be
		 *                    allocated
		 *
		 ***********************************************************************************/
		static vector_t *vector_insert_n_at ( vector_t *in, int n, void *elements[], int at )
		{
			vector_t *out;

			if ( at <= in->size ) {
				int i;

				out = vector_ensure_capacity ( in, n );
				for ( i=in->size-1; i>=at; i-- ) {
					out->content[i+n] = out->content[i];
				}
				for ( i=0; i<n; i++ ) {
					out->content[i+at] = elements[i];
				}
				out->size += n;
				out->capacity -= n;
			}
			else {
				fprintf( stderr, "vector_rem_n_at: cannot add %d elements from position %d in a vector of %d elements\n",
							n, at, in->size );
				out = in;
			}
			return out;
		}

		/***********************************************************************************
		 * Function:          vector_ensure_capacity
		 *
		 * Purpose:           ensures capacity for `n' more elements
		 *
		 * Description:       If the current capacity does not allow for `n' more elements
		 *                    the vector is reallocated with the minimum amount of more
		 *                    memory to allow for `n' more elements.
		 *
		 * Parameters:        vector_t *in;        vector of which the elements are removed
		 *                    int n;                number of elements to remove
		 *                    int at;                position of 1st element to remove
		 *
		 * Example:           v = vector_ensure_capacity( v, 5 );
		 *
		 * Return Value:      0   if `at' is within bounds [0,`size')
		 *                    2   if `at' is out of bounds [0,`size')
		 *
		 ***********************************************************************************/
		static vector_t *vector_ensure_capacity ( vector_t *in, int n )
		{
			vector_t *out;

			if ( in->capacity < n ) {
				n = ( n + in->increment - 1 ) / in->increment;
				out = vector_new ( in->size + ( n * in->increment ), in->increment );
				if ( out == NULL ) {
					return NULL;
				}
				out->size = in->size;
				out->capacity = n * in->increment;
				memcpy ( out->content, in->content, in->size * sizeof ( void * ) );
				vector_free ( in );
			}
			else {
				out = in;
			}
			return out;
		}

		/***********************************************************************************
		 * Function:          vector_get
		 *
		 * Purpose:           returns element at position `index'
		 *
		 * Description:       returns element at position `index'
		 *
		 * Parameters:        vector_t *in;        vector of which the elements is returned
		 *                    int index;            position of the elements to return
		 *
		 * Example:           printf ( "Element is: %s\n", (char *)vector_get ( v, 0 ) );
		 *
		 * Return Value:      pointer to the element at position `index'
		 *
		 ***********************************************************************************/
		static void *vector_get ( const vector_t *in, int index )
		{
			return in->content[index];
		}

		/***********************************************************************************
		 * Function:          vector_size
		 *
		 * Purpose:           returns the current number of stored elements in the vector
		 *
		 * Description:       returns the current number of stored elements in the vector
		 *
		 * Parameters:        vector_t *in;        vector of which the size is returned
		 *
		 * Example:           for ( i=0; i<vector_size ( v ); i++ ) ;
		 *
		 * Return Value:      current number of stored elements in the vector
		 *
		 ***********************************************************************************/
		static int vector_size ( const vector_t *in )
		{
			return in->size;
		}

		/***********************************************************************************
		 * Function:          vector_free
		 *
		 * Purpose:           frees memory of a vector (does not free the elements!)
		 *
		 * Description:       frees all dynamically allocated memory in structure
		 *                    vector_t for the vector `in'. This does not free the
		 *                    memory for the elements for which this vector held
		 *                    pointers!
		 *
		 * Parameters:        vector_t *in;        vector to be freed
		 *
		 * Example:           v = vector_free ( v );
		 *
		 * Return Value:      NULL
		 *
		 ***********************************************************************************/
		static vector_t *vector_free ( vector_t *in )
		{
			if ( in != NULL )
			{
				MEM_free( in->content );
				MEM_free( in );
			}
			return NULL;
		}



		////////////END VECTOR//////////////

		void vector_find_tag(vector_t* v, void *e,int *idx)
	{
		int i;
		*idx=-1;
		tag_t* tofind=NULLTAG;
		tofind=(tag_t *)e;
		//char *uidtofind;
		//ITK__convert_tag_to_uid(*tofind,&uidtofind);
		int count =vector_size(v);
		 for ( i = 0; i <count; i++) {
			 tag_t* tempfind=NULLTAG;
			 tempfind=(tag_t *)vector_get(v,i);
			 
		//	 char *uidbefind;
			//ITK__convert_tag_to_uid(*tempfind,&uidbefind);
			 
		   if(/*tc_strcmp(uidbefind,uidtofind)==0*/*tempfind==*tofind)
			{
			*idx=i;
			return ;
			}
		}
		
		
		
	}
		void vector_find_str(vector_t* v, void *e,int *idx)
	{
		
		
			int i;
			*idx=-1;
		int count =vector_size(v);
		 for ( i = 0; i <count; i++) {
		   if(strcmp((char *)vector_get(v,i), (char *)e)==0)
			{
			*idx=i;
			return ;
			}
		}
		

	}
		void setFindStr_GWR(char **view_list,int count,char *str,int *found)
		{
			int k=0;
			*found=-1;
			for(k=0;k<count;k++)
			{
				//printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{
					*found=k;
					break;
				}
			}
		}

		void copyData(void *to,void *from)
		{


		memcpy(to,from,sizeof(*from));

		}
		void copyObjTAG(int count,tag_t* objlist,tag_t **destobj )
		{
			
			
			(*destobj) = (tag_t *)MEM_alloc(count  * sizeof(tag_t ));
			
			int i;
			for(i=0;i<count;i++)
			{
				(*destobj)[i] = objlist[i];
			}
			
			
		}



		void setAddTAG(int *count,tag_t **objlist,tag_t obj )
		{
			if(obj==NULLTAG)
				return;
			*count=*count+1;
			if(*count==1)
			{
			(*objlist) = (tag_t *)MEM_alloc((*count ) * sizeof(tag_t ));
			}
			else
			{
				(*objlist) = (tag_t *)MEM_realloc((*objlist),(*count ) * sizeof(tag_t ));
			}
			(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

		}

		void incrAtIndexInt(int index,int **levelList )
		{
			
			(*levelList)[index] = (*levelList)[index] +1; //malloc((strlen(view_id)+1) * sizeof(char));

		}

		void setAddInt(int *count,int **levelList,int level )
		{
			*count=*count+1;
			if(*count==1)
			{
			(*levelList) = (int *)malloc((*count ) * sizeof(int ));
			}
			else
			{
				(*levelList) = (int *)realloc((*levelList),(*count ) * sizeof(int ));
			}
			(*levelList)[*count-1] = level; //malloc((strlen(view_id)+1) * sizeof(char));

		}


		void setFindTag(tag_t *objlist,int count,tag_t obj,int *found)
		{
			int k=0;
			*found=-1;
			
			for(k=0;k<count;k++)
			{		
				
				
				if(objlist[k]==obj)
				{
					*found=k;
					break;
				}
			}
		}
		
		void setFindTag1(tag_t *objlist,int count,tag_t obj,int *found)
		{
			int k=0;
			*found=-1;
			char *uidtofind;
			ITK__convert_tag_to_uid(obj,&uidtofind);
			for(k=0;k<count;k++)
			{		
				char *uidbefind;
				ITK__convert_tag_to_uid(objlist[k],&uidbefind);
				
				if(tc_strcmp(uidbefind,uidtofind)==0)
				{
					*found=k;
					break;
				}
			}
		}
		void setAddStr(int *count,char ***strset,char* str)
		{
			*count=*count+1;
			printf("\n setAddStr1 %d",*count);fflush(stdout);
			if(*count==1)
			{
				(*strset) = (char **)malloc((*count ) * sizeof(char *));
			}
			else
			{
				(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
			}
			(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
			 tc_strcpy((*strset)[*count-1],str);
			//printf("\n Added in Set ===%s",(*strset)[*count-1]);fflush(stdout);
		}

		int getRelationS2P(tag_t secondary,tag_t** primary_objects,const char *relname,int filtername,int *countRet)
		{
			int ifail = ITK_ok;
			tag_t relType = NULLTAG;
			//tag_t* primary_objects = NULL;
			ITK_CALL(GRM_find_relation_type(relname,&relType));		
		//filter =T5_ChangeTaskRevision	
			if( relType != NULLTAG )
			{
				/*if(filtername==1)
				{
					printf("\n filtername==%d",filtername);fflush(stdout);
					GRM_list_primary_objects_with_primary_object_type_only(secondary,relType,"ChangeRequestRevision",countRet,primary_objects);
								printf("\n 1filtername==%s",filtername);fflush(stdout);
				}
				else*/
				ITK_CALL(GRM_list_primary_objects_only(secondary,relType,countRet,primary_objects));
				//printf("\n DML attaced in part count=%d \n",*countRet);fflush(stdout);
			}
			return ifail;
		}

		int getTCDate(char* date,date_t *tc_date)
		{
		  int ifail=ITK_ok;  
		  struct tm tm;  
		  char tempdate[100];
		  
		  printf("\n !!!!!!!!!!!!!!!!! befoe confirmarion PrintBOM Date is %s",date);fflush(stdout);
		  
		  //strptime(date, "%d-%m-%Y", &tm);
		  
		  
		  strftime(tempdate, strlen("DD-MMM-YYYY")+1, "%d-%b-%Y", &tm);

		  
			printf("\n !!!!!!!!!!!!!!!!! tempdate=%s\n",tempdate);fflush(stdout);
		  
		  ITK_CALL(ITK_string_to_date(tempdate, tc_date));
		  return ifail;
		}

		void stripChar(char *src,char **dest)
		{
			

		int i;
		int len=tc_strlen(src);
		for(i = 0;i<len; i++) {
		  if(src[i] == '\r' || src[i] == '\n' || src[i] == ',') {
			src[i] = ';';
		   
		  }
		}
		/*
		char *temp;	
		char *strval=NULL;
		len=tc_strlen(src);
		for(i = 0;i<len; i++) {
		  if(src[i] == '\r') {
			src[i] = ';';
		   
		  }
		}
		do{
		STRNG_replace_str(src,",",";",&temp);
		strval=NULL;
		strval=strchr(temp,',');
		}while(strval!=NULL);



		do{
		STRNG_replace_str(temp,"\n",";",dest);	
		strval=NULL;
		strval=strchr(*dest,'\n');
		}while(strval!=NULL);	
			*/
			
			tc_strdup(src,dest);
		}


		int queryobject(char* propName ,char* value, int* n_found, tag_t** items)
		{
			int ifail = ITK_ok;
			//int n_found = 0;
			//tag_t* items = NULL;

			printf("\n\n Inside queryobject......");fflush(stdout);

			tag_t        query           = NULLTAG;

			char
			   *qry_entries[] = {"Type","Name"},
			   *qry_values[]  = {(char *)propName, (char *)value};
			   
			ITK_CALL(QRY_find2("General...", &query));

			ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, n_found, items));

			printf("\n queryobject n_found==%d",*n_found);fflush(stdout);
			

			return ifail;


		} 


		int queryobjectItem(char* propName ,char* value, int* n_found, tag_t** items)
		{
			int ifail = ITK_ok;
			//int n_found = 0;
			//tag_t* items = NULL;

			printf("\n\n Inside queryobject......");fflush(stdout);

			tag_t        query           = NULLTAG;

			char
			   *qry_entries[] = {"Type","Item ID"},
			   *qry_values[]  = {(char *)propName, (char *)value};
			   
			ITK_CALL(QRY_find2("Item Revision...", &query));

			ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, n_found, items));

			printf("\n queryobject n_found==%d",*n_found);fflush(stdout);
			

			return ifail;


		} 

		void autoresizestrcat(char **src,char* dest)
		{
			
			// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
			 char * desc = dest ? dest : "NA";
			
			//printf("\n autoresizestrcat src len==%d",strlen(*src));
			//printf("\n autoresizestrcat desc len==%d",strlen(desc));
			const size_t a = strlen(*src);
			const size_t b = strlen(desc);
			const size_t size_ab = a + b + 2;

		   // src = MEM_realloc(src, size_ab);
			
			*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

			tc_strcat(*src , desc);


		}

		
			int getGateMaturationDML(tag_t query,char* partNumber,char* object_type,tag_t relGMType,tag_t relTypeDMLTask,tag_t *gmdmlobj)
			{

			
			
			 int ifail = ITK_ok;
			int  count 	= 0,count1=0;
			
			tag_t *itemrevs = NULLTAG;	
			tag_t *itemrevs1 = NULLTAG;	
			//char *relstat="T5_LcsErcRlzd";
		char **qry_entries = (char **) MEM_alloc(3 * sizeof(char *));
			char **qry_values = (char **) MEM_alloc(3 * sizeof(char *));

		//char *qry_entries[] ={"Item ID","Type","Release Status"};
			//char *qry_values[] = {partNumber,object_type,relstat};
			int            num_to_sort=0;
			char**         keys=(char **) MEM_alloc(1 * sizeof(char *));//={"creation_date"};
			int orders[]={1};
			
			TC_write_syslog("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);	

			
			
			
			printf("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);fflush(stdout);
			
			
			qry_entries[0] = (char *)MEM_alloc(50);
			qry_entries[1] = (char *)MEM_alloc(50);
			qry_entries[2] = (char *)MEM_alloc(50);
			
			qry_values[0] = (char *)MEM_alloc(50);
			qry_values[1] = (char *)MEM_alloc(50);
			qry_values[2] = (char *)MEM_alloc(50);
					   



			strcpy(qry_entries[0],  "Item ID");
			strcpy(qry_entries[1],  "Type");
			strcpy(qry_entries[2],  "Release Status");	
			
			strcpy(qry_values[0],  partNumber);
			strcpy(qry_values[1],  object_type);
			strcpy(qry_values[2],  "T5_LcsErcRlzd");
			
			
			keys[0] = (char *)MEM_alloc(50);
			strcpy(keys[0],  "creation_date");
			
			//tag_t query = NULLTAG;	
			//ITK_CALL(QRY_find2("Item Revision...", &query));
			ITK_CALL(QRY_execute_with_sort(query, 3, qry_entries, qry_values,num_to_sort,keys,orders, &count1, &itemrevs1));
			MEM_free(qry_entries);
			MEM_free(qry_values);
			MEM_free(keys);
			
			if(count1>0)
			{
			tag_t type_tag;
			ITK_CALL(TCTYPE_ask_object_type(itemrevs1[0],&type_tag));
			tag_t prop_tag = NULLTAG;
			ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"creation_date",&prop_tag));
			tag_t prop_tags[] = {prop_tag};
			const int          sort_orders[]={1};//            /**< (I) n_props Sort order: 0 = ascending, 1 = descending */
			ITK_CALL(AOM_sort_tags_by_properties(count1,itemrevs1,1 ,prop_tags,sort_orders,&count,&itemrevs));
			
			}
			int f;
			for( f=0;f<count;f++)
			{
				tag_t itemrevtag=itemrevs[f];
			tag_t tItemTaskPr=NULLTAG;
			tag_t* gmtasklist=NULLTAG;
			int gmtaskcount;
			int gmdmlcount;
			tag_t *gmdmllist=NULLTAG;
							
			if( relGMType != NULLTAG )
			{
			
				ITK_CALL(GRM_list_primary_objects_only(itemrevtag,relGMType,&gmtaskcount,&gmtasklist));
		//	ITK_CALL(GRM_list_primary_objects_with_primary_object_type_only(itemrevtag,relType,"T5_ChangeTaskRevision",&countRet,&primary));
				//printf("\n DML attaced in part count=%d \n",*countRet);fflush(stdout);
				
				
				
								int u;
							for(u=0;u<gmtaskcount;u++)
							{						
								char *obtyp;
								ITK_CALL(AOM_ask_value_string(gmtasklist[u],"object_type",&obtyp));
								if(tc_strcmp(obtyp,"T5_ChangeTaskRevision")!=0)
									continue;
								else
								{
									tItemTaskPr=gmtasklist[u];
								}
									
							}  
								
				if( tItemTaskPr!=NULLTAG &&relTypeDMLTask != NULLTAG )
			{
				
				ITK_CALL(GRM_list_primary_objects_only(tItemTaskPr,relTypeDMLTask,&gmdmlcount,&gmdmllist));
				if(gmdmlcount>0)
				{
					*gmdmlobj=gmdmllist[0];
					break;
				}
			}	
			}
			}
			return ifail;
			}
			
			
		void autoresizestrcat1(char *src,char* desc)
		{
			printf("\n autoresizestrcat len==%d",strlen(src));
			if(desc==NULL)
				tc_strcat(src,"NA");
				else
					tc_strcat(src,desc);
		/*
		const size_t a = strlen(src);
			const size_t b = strlen(desc);
			const size_t size_ab = a + b + 1;

			src = realloc(src, size_ab);

			memcpy(src + a, desc, b + 1);
		*/

		}
		
		
		int compareBOM(int n,tag_t* soObjs,char *sVHeadrRevDup,char *parttypeDup,tag_t prevrevpartObj,tag_t rule,char** bom_flag)
		{
			int ifail=ITK_ok;
			
			tag_t window=NULLTAG;
			tag_t top_line=NULLTAG;
			int n1;
			tag_t *soPrevObjs=NULLTAG;
			char *parttype;
			int sNORevLvlPO_count=0;
			vector_t *sNORevLvlPO=vector_new(1,1);
			tag_t ChildPrtObjP=NULLTAG;
			int StruChangeFlag;
			char *sChlPrtnoDup=NULL;
			char *sChlPrtno=NULL;
			char *sChPrtnoDup=NULL;
			char *sChPrtno=NULL;
			char *sRLPPrt=NULL;
			char *sNOPORvlstr = (char *) MEM_alloc( 1 * sizeof(char) );
			tc_strcpy(sNOPORvlstr,"");
			
			
			if(tc_strstr(sVHeadrRevDup,"NR")!=NULL)
	{
		printf("\n No Structure change...... NR revision");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"NO");
		tc_strcpy(*bom_flag,"New Generation");
		//free(sNOPORvlstr);
		//tc_strcat(*bom_flag,parttypeDup);
	//tc_strcat(*bom_flag,"=");
	//tc_strcat(*bom_flag,sVHeadrRevDup);
		return 0;
	}
			if(prevrevpartObj==NULLTAG)
			{
		printf("\n No Structure change...... NR revision");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"NO");
		tc_strcpy(*bom_flag,"NO Previous Rev");
		//free(sNOPORvlstr);
		//tc_strcat(*bom_flag,parttypeDup);
	//tc_strcat(*bom_flag,"-");
	//tc_strcat(*bom_flag,sVHeadrRevDup);
		return 0;
	}	
			//printObject(prevrevpartObj);	
			ITK_CALL(BOM_create_window (&window));
			ITK_CALL(BOM_set_window_config_rule( window, rule ));
			ITK_CALL(BOM_set_window_pack_all (window, true));
			ITK_CALL(BOM_set_window_top_line (window, NULLTAG, prevrevpartObj, NULLTAG, &top_line));
						
			ITK_CALL( BOM_line_ask_child_lines (top_line, &n1, &soPrevObjs));
			
			if(((n1==0)&& (n==0)) && (tc_strcmp(parttypeDup,"C")==0))
	{
		//no BOM
		printf("\n,NO BOM available.");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"NO BOM");
		tc_strcpy(*bom_flag,"Component Modified");
		//fprintf(fp1,"\n'%s,'%s,'%s,NO BOM available.",PartNo,TskName2,tpartNo);fflush(fp1);
	}

	else if (((n1==0)&& (n==0)) && (tc_strcmp(parttypeDup,"D")==0))
	{
		//no BOM
		printf("\n,NO BOM available.");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"NO BOM");
		tc_strcpy(*bom_flag,"IFD Or Table drawing Or Dummy part Modified");
		//fprintf(fp1,"\n'%s,'%s,'%s,NO BOM available.",PartNo,TskName2,tpartNo);fflush(fp1);
	}
	else if(((n1>0)&& (n==0)) && ((tc_strcmp(parttypeDup,"M")==0)||(tc_strcmp(parttypeDup,"A")==0) || (tc_strcmp(parttypeDup,"T")==0) || (tc_strcmp(parttypeDup,"V")==0) || (tc_strcmp(parttypeDup,"G")==0)))
	{
		//fprintf(fp1,"\n'%s,'%s,'%s,YES-Structure change, NO BOM to current revision",PartNo,TskName2,tpartNo);fflush(fp1);
		printf("\n,Structure change.");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		tc_strcpy(*bom_flag,"Assembly Structure Modified");
		//tc_strcpy(*bom_flag,"YES");
	}
	else if(((n1==0)&& (n>0))  && ((tc_strcmp(parttypeDup,"M")==0)||(tc_strcmp(parttypeDup,"A")==0) || (tc_strcmp(parttypeDup,"T")==0) || (tc_strcmp(parttypeDup,"V")==0) || (tc_strcmp(parttypeDup,"G")==0)))
	{
		//fprintf(fp1,"\n'%s,'%s,'%s,YES-Structure change, NO BOM to Previous revision",PartNo,TskName2,tpartNo);fflush(fp1);
		printf("\n,Structure change.");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"YES");
		tc_strcpy(*bom_flag,"Assembly Structure Modified");
	}
	else if(((n1>0)&& (n>0))  && ((tc_strcmp(parttypeDup,"M")==0)||(tc_strcmp(parttypeDup,"A")==0) || (tc_strcmp(parttypeDup,"T")==0) || (tc_strcmp(parttypeDup,"V")==0) || (tc_strcmp(parttypeDup,"G")==0)))
	{
		if(((n1) > (n))||((n1) < (n)))
		{
			//fprintf(fp1,"\n'%s,'%s,'%s,YES-Structure change",PartNo,TskName2,tpartNo);fflush(fp1);
			printf("\n,Structure change.");fflush(stdout);
			tc_strcpy(*bom_flag,"");
			tc_strcpy(*bom_flag,"Assembly Structure Modified");
		}
		else if ((n1) == (n))
		{
			//prev BOM
			if(n1 >0)
			{
			int	ikk=0;
				for(ikk=0;ikk<n1;ikk++)
				{
					sChlPrtnoDup=NULL;
					sChlPrtno=NULL;
					ChildPrtObjP=NULLTAG;
					ChildPrtObjP=soPrevObjs[ikk];
					//printObject(ChildPrtObjP);
					ITK_CALL(AOM_ask_value_string(ChildPrtObjP,"bl_item_item_id",&sChlPrtno));
					//if(sChlPrtno!=NULL) tc_strdup(sChlPrtno,&sChlPrtnoDup);
					printf("\n sChlPrtno:%s \n",sChlPrtno); fflush(stdout);
					int found=0;
					vector_find_str(sNORevLvlPO,sChlPrtno,&found);
					if(found>0)
					{
						sNORevLvlPO=vector_add(sNORevLvlPO,MEM_string_copy(sChlPrtno) );
						printf("\n adding sChlPrtno:[%s] \n",sChlPrtno);fflush(stdout);
						
					}
					
					/*if (sChlPrtnoDup!=NULL)
					free(sChlPrtnoDup);*/
				}
				//list of prev BOM
				if(sNORevLvlPO_count>0)
				{
					int pn;
					tc_strcpy(sNOPORvlstr,"");
					for(pn=0;pn<sNORevLvlPO_count;pn++)
					{
						sRLPPrt=NULL;
						sRLPPrt =(char *)vector_get(sNORevLvlPO,pn);
						autoresizestrcat(&sNOPORvlstr,sRLPPrt);
						autoresizestrcat(&sNOPORvlstr,",");

					}
					printf("\n POCHCK: list of Prev BOM: %s\n",sNOPORvlstr);fflush(stdout);
				}
			}
			//Comparing laste parts in prev BOM.
			if(n)
			{
				int ik=0;
			//	sNORevLvlPO = NULL;
				//sNORevLvlPO                 = setCreate(9000);
				StruChangeFlag=0;
				for(ik=0;ik<n;ik++)
				{
					sChPrtnoDup=NULL;
					sChPrtno=NULL;
					ChildPrtObjP=NULLTAG;
					ChildPrtObjP=soObjs[ik];
					ITK_CALL(AOM_ask_value_string(ChildPrtObjP,"bl_item_item_id",&sChPrtno)) ;
					//if(sChPrtno!=NULL)  tc_strdup(sChPrtno,&sChPrtnoDup);
					printf("\n sChPrtno:%s \n",sChPrtno); fflush(stdout);
					if (sChPrtnoDup!=NULL && tc_strstr(sNOPORvlstr,sChPrtno)==NULL)
					{
						//Difference in BOM
						StruChangeFlag=1;
						
						break;
					}
					/*if (sChPrtnoDup!=NULL)
					free(sChPrtnoDup);*/
				}
				if (StruChangeFlag >0)
				{
					//fprintf(fp1,"\n'%s,'%s,'%s,YES-Structure Change",PartNo,TskName2,tpartNo);fflush(fp1);
					printf("\n,Structure change.");fflush(stdout);
					tc_strcpy(*bom_flag,"");
					//tc_strcpy(*bom_flag,"YES");
					tc_strcpy(*bom_flag,"Assembly Structure Modified");
				}

				else if (StruChangeFlag = 0)
				{
					tc_strcpy(*bom_flag,"");
					//tc_strcpy(*bom_flag,"NO");
					tc_strcpy(*bom_flag,"No Structure Modified");
				}
				else
				{
					//fprintf(fp1,"\n'%s,'%s,'%s,NO-Structure Change",PartNo,TskName2,tpartNo);fflush(fp1);
					printf("\n No Structure change.");fflush(stdout);
					tc_strcpy(*bom_flag,"");
					//tc_strcpy(*bom_flag,"NO");
					tc_strcpy(*bom_flag,"No Structure Modified");
				}
			}
		}
	}
	else
	{
		//fprintf(fp1,"\n'%s,'%s,'%s,NO-Structure Change",PartNo,TskName2,tpartNo);fflush(fp1);
		printf("\n No Structure change.");fflush(stdout);
		tc_strcpy(*bom_flag,"");
		//tc_strcpy(*bom_flag,"NO");
		tc_strcpy(*bom_flag,"No Structure Modified");
	}

	//tc_strcat(*bom_flag,parttypeDup);
	//tc_strcat(*bom_flag,"+");
	//tc_strcat(*bom_flag,sVHeadrRevDup);
				if(window!=NULLTAG)
					{
					ITK_CALL(BOM_close_window(window));
					window=NULLTAG;
					}
	printf("\n 11111.");fflush(stdout);
	//free(sNOPORvlstr);
	printf("\n 22222.");fflush(stdout);
	if(n1>0 && soPrevObjs!=NULL)
	{
		printf("\n 3333.");fflush(stdout);
	MEM_free(soPrevObjs);
	printf("\n 4444.");fflush(stdout);
	}

	if(sNORevLvlPO_count>0)
	{
		printf("\n 55555.");fflush(stdout);
	//MEM_free(sNORevLvlPO);
	printf("\n 6666.");fflush(stdout);
	}
	return 0; 
		
		}
		
		
		
		static void  printBom (tag_t query,int bomdepth ,tag_t line, int depth,vector_t **ChildTagListGlobal,int *ChildTagList_cntGlobal, vector_t **ChildTagList, int *ChildTagList_cnt, int *BomLvl_cnt, vector_t **bomLevel, vector_t **bom_counter,char* FrmDt, char* ToDt,vector_t **part_dml_vec,int *part_dml_count,vector_t **childRevStrList,tag_t rule,vector_t **global_bom_flag)
		{
			int ifail;
			int i, n, toadd;
			tag_t *children;
			tag_t *latestdml;
			tag_t *latestPart;
			vector_t *alldmllist=vector_new(1,1);
			vector_t *allpartlist=vector_new(1,1);
			int allpart_dml_cnt;
			
			char* 			PartNo 					= NULL;
				char*			part_rev				=NULL;
				char*			part_type				=NULL;
				tag_t			partObj1				= NULLTAG;
				tag_t			prevrevpartObj				= NULLTAG;
				tag_t			dmlObj1				= NULLTAG;
				
				
			
			int bomsetcnt=-1;
			char *bomflag=(char *) MEM_alloc( 100 * sizeof(char) );
				
			depth ++;
			int bl_item_item_id=0;
			char *bl_item_item_id_val;	
			int bl_sequence_no=0;
			char *bl_sequence_no_val;		
			int bl_line_object=0;
			tag_t bl_line_object_val = NULLTAG;
			// ITK_CALL(BOM_line_look_up_attribute( "bl_item_item_id", &bl_item_item_id));
			// ITK_CALL( BOM_line_ask_attribute_string (line, bl_item_item_id, &bl_item_item_id_val));
			
			// ITK_CALL(BOM_line_look_up_attribute( "bl_line_object", &bl_line_object));
			ITK_CALL(  AOM_ask_value_tag(line, "bl_line_object", &bl_line_object_val));
			
			// ITK_CALL(BOM_line_look_up_attribute( "bl_sequence_no", &bl_sequence_no));
			// ITK_CALL(BOM_line_ask_attribute_string (line, bl_sequence_no, &bl_sequence_no_val));

			AOM_UIF_ask_value(line,"bl_item_item_id", &bl_item_item_id_val);
			AOM_UIF_ask_value(line,"bl_sequence_no", &bl_sequence_no_val);


			 printf("\n bl_sequence_no_val==%s bl_item_item_id_val==%s",bl_sequence_no_val,bl_item_item_id_val);fflush(stdout);
			   if(bl_line_object_val==NULLTAG)
			{
			   printf("\n bl_line_object_val==NULL");fflush(stdout);
			return ;

			}
			
			if(depth>1)
			{		
				printf ("%3d", depth);
				for (i = 0; i < depth; i++)
				printf ("  ");		
				printf ("%-20s\n", bl_item_item_id_val);	
				
				
				ITK_CALL(AOM_ask_value_string(bl_line_object_val,"item_id",&PartNo));
				ITK_CALL(AOM_ask_value_string(bl_line_object_val,"item_revision_id",&part_rev));
				ITK_CALL(AOM_ask_value_string(bl_line_object_val,"t5_PartType",&part_type));
			
				int total_cnt=0;
				//getLatestReleasedPart(query,PartNo,"Design Revision", &partObj1,FrmDt,ToDt,&total_cnt);
				 getAllReleasedPartDML(query,PartNo,"Design Revision", latestdml,latestPart,&prevrevpartObj,&alldmllist,&allpartlist,&allpart_dml_cnt,FrmDt,ToDt,&total_cnt);
				 printf("\n allpart_dml_cntallpart_total_cnt=%d",total_cnt);fflush(stdout);
				
		printf("\n bl_item_item_id_val==%s total count==%d",bl_item_item_id_val,total_cnt);
			if(total_cnt>0)
		{		

				int f;
				char *allmovrev=(char *) MEM_alloc( 1 * sizeof(char) );
				tc_strcpy(allmovrev,"");
				allpart_dml_cnt=vector_size(alldmllist);
				 printf("\n allpart_dml_cntallpart_dml_cnt=%d",allpart_dml_cnt);fflush(stdout);
				for(f=0;f<allpart_dml_cnt;f++)
				{
				 tag_t *tpartObj1=NULLTAG;
				 tpartObj1=((tag_t*)vector_get(allpartlist,f));//allpartlist[f];
				 partObj1=*tpartObj1;
				//alldmllist[f];
			//	 printObject(partObj1);
			//	  printObject(dmlObj1);
				 char *d1;
				 char* p1;
				 
				 char *d2;
				 char* p2;
				 
				 char *d3;
				 char* p3;
				 
				 char *p4;
				 
				 ITK_CALL(AOM_UIF_ask_value(partObj1,"object_string",&p1));
				 ITK_CALL(AOM_UIF_ask_value(partObj1,"date_released",&p2));
				 ITK_CALL(AOM_UIF_ask_value(partObj1,"creation_date",&p3));
				 ITK_CALL(AOM_UIF_ask_value(partObj1,"item_revision_id",&p4));
				 autoresizestrcat(&allmovrev,p4);
				 autoresizestrcat(&allmovrev,"  ");
				  tag_t *tdmlObj1=NULLTAG;
				  tdmlObj1=((tag_t*)vector_get(alldmllist,f));
				  dmlObj1=*tdmlObj1;
				  //printObject(dmlObj1);
				 ITK_CALL(AOM_UIF_ask_value(dmlObj1,"object_string",&d1));
				 ITK_CALL(AOM_UIF_ask_value(dmlObj1,"date_released",&d2));
				 ITK_CALL(AOM_UIF_ask_value(dmlObj1,"creation_date",&d3));
				 printf("\n mapping part==%s[%s][%s] dml==%s[%s][%s]",p1,p2,p3,d1,d2,d3);fflush(stdout);
				 //MEM_free(tpartObj1);
				 //MEM_free(tdmlObj1);
				 
				}
				tag_t *tdml_obj = (tag_t *)MEM_alloc( sizeof ( tag_t ) );
				tdml_obj=(tag_t *)vector_get(alldmllist,allpart_dml_cnt-1);
				  // memcpy(tdml_obj ,(tag_t *)vector_get(alldmllist,allpart_dml_cnt-1),sizeof(tag_t));
				 *part_dml_vec=vector_add ( *part_dml_vec ,tdml_obj);
				vector_find_tag(*ChildTagList,&bl_line_object_val,&toadd);
				 tag_t *tbl_line_object_val = (tag_t *)MEM_alloc( sizeof ( tag_t ) );
					*tbl_line_object_val = bl_line_object_val;
				if(toadd==-1)
				{
					
					*ChildTagList=vector_add(*ChildTagList,tbl_line_object_val);	
						
				}
						
				vector_find_tag(*ChildTagListGlobal,tbl_line_object_val,&toadd);
				
				if(toadd==-1)
				{	
						int tempcnt=*ChildTagList_cntGlobal;
						bomsetcnt	=tempcnt;				
					*ChildTagListGlobal=vector_add(*ChildTagListGlobal,tbl_line_object_val);			
					int tempBomLvl_cnt=tempcnt;//*BomLvl_cnt;
					int tempBomLvl_cnt1=tempcnt;//*BomLvl_cnt;
					int countrevmod=tempcnt;
					printf ("\n Index :::: %d temp level %d tempBomLvl_cnt1==%d BomLvl_cnt==%d", toadd,tempBomLvl_cnt,tempBomLvl_cnt1,*BomLvl_cnt);	fflush(stdout);	
					int *tdepth=(int *)MEM_alloc( sizeof ( int ) );
					*tdepth=depth;
					*bomLevel=vector_add(*bomLevel,tdepth);
					int *ttotal_cnt=(int *)MEM_alloc( sizeof ( int ) );
					*ttotal_cnt=total_cnt;
					printf ("\n bom_counter0 ::::%d",toadd);fflush(stdout);
					*bom_counter=vector_add(*bom_counter,ttotal_cnt);	
					*childRevStrList=vector_add(*childRevStrList,MEM_string_copy(allmovrev));
					//(*bom_counter)[] = total_cnt;		
					//MEM_free(tdepth);		
					//MEM_free(ttotal_cnt);						
				}
				else
				{
					//incrAtIndexInt(toadd,bom_counter);			
					//(*bom_counter)[toadd] = total_cnt;
					//bom_counter->content[toadd]=total_cnt;
					int *ttotal_cnt=(int *)MEM_alloc( sizeof ( int ) );
					*ttotal_cnt=total_cnt; 
					printf ("\n bom_counter1 toadd ::::%d",toadd);fflush(stdout);
					printf ("\n bom_counter11 ::::%d",*((int *)vector_get(*bom_counter,toadd)));fflush(stdout);
					(*bom_counter)->content[toadd]= ttotal_cnt;
					 //MEM_free(ttotal_cnt);
					// memcpy ( &bom_counter->content[toadd], ttotal_cnt, 1 * sizeof ( int * ) );
					
					
				}		
				// MEM_free(tbl_line_object_val);
			}
			}
			
			
			vector_free(allpartlist);
			vector_free(alldmllist);
			ITK_CALL( BOM_line_ask_child_lines (line, &n, &children));
			if(bomsetcnt>=0)
			{
			tc_strcpy(bomflag,"");
			compareBOM(n,children,part_rev,part_type,prevrevpartObj,rule,&bomflag);
			printf("\n BOMFlag==%s",bomflag);fflush(stdout);
			*global_bom_flag=vector_add(*global_bom_flag,MEM_string_copy(bomflag));
			printf("\n added BOMFlag==%s",bomflag);fflush(stdout);		
			//MEM_free(bomflag);
			}
			//compareBOM(int n,tag_t* soObjs,char *sVHeadrRevDup,tag_t prevrevpartObj,tag_t rule,char** bom_flag)
			printf("\n [dep==%d]AllBOM Childcount==%s[%d]",depth,bl_item_item_id_val,n);fflush(stdout);
			
			//free(bl_line_object_val);
			//free(line);
		if(bomdepth<=1 || (bomdepth>1 && depth<bomdepth))
		{
			for (i = 0; i < n; i++)
			{
				//if(depth<2)
				 printBom (query,bomdepth,children[i], depth,ChildTagListGlobal,ChildTagList_cntGlobal, ChildTagList, ChildTagList_cnt,BomLvl_cnt,bomLevel,bom_counter,FrmDt,ToDt, part_dml_vec,part_dml_count,childRevStrList,rule,global_bom_flag);
			  
			}
		}
			//MEM_free (children);
		}




		//printBom (tag_t line, int depth,tag_t **ChildTagListGlobal,int *ChildTagList_cntGlobal, tag_t **ChildTagList, int *ChildTagList_cnt, int *BomLvl_cnt, int **bomLevel, int **bom_counter,char* FrmDt, char* ToDt)
		int printBomBVRDetail(tag_t	window,tag_t line, tag_t varient,tag_t **ChildTagListGlobal,int *ChildTagList_cntGlobal, tag_t **ChildTagList, int *ChildTagList_cnt, int *BomLvl_cnt, int **bomLevel, int **bom_counter,char* FrmDt, char* ToDt)
		{
			
			*BomLvl_cnt = 0;
			tag_t varrule_tags[]={varient};
			
			*bomLevel[0]= 1;
			*bomLevel[1]= 2;
			ITK_CALL(BOM_window_hide_variants (window));
			ITK_CALL(BOM_window_hide_unconfigured(window));
			ITK_CALL(BOM_window_apply_variant_configuration(window,1,varrule_tags))   ;
			ITK_CALL(BOM_window_hide_variants (window));
			ITK_CALL(BOM_window_hide_unconfigured(window));
			
			int rule_count = 0;
			int k = 0;
			tag_t* bom_variant_rules = NULL;
			
			ITK_CALL(BOM_window_ask_variant_rules(window,&rule_count,&bom_variant_rules));

			printf("\n RULE COUNT===%d", rule_count); fflush(stdout);

			for(k=0;k<rule_count;k++)
			{
				char* vname = NULL;
				tag_t variantRuleTag = NULLTAG;
				
				variantRuleTag=bom_variant_rules[k];
				ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_string", &vname));
				printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
			}
			
			
			int n_lines1 = 0;
			int x = 0;
			tag_t* lines = NULL;
			
			if(BOM_line_ask_child_lines(line, &n_lines1, &lines));
			printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
			for(x=0;x<n_lines1;x++)
			{

				tag_t childline=lines[x];
				
				//setAddTAG(&moduleTagList_cnt,&globChild,lines[x]);
				
				//globChild=lines;               //Returning the modules of CCV
				tag_t child_item;
				char *bl_item_id;
				ITK_CALL(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
				printf("\n [%d] bl_item_id1=%s",x,bl_item_id);fflush(stdout);
				tag_t bom_window1;
				tag_t top_line1;
				int n_lines2;
				tag_t *lines2;
				if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
				printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
				int y;
				for(y=0;y<   n_lines2;y++)
				{
					tag_t childline2=lines2[y];
					char *bl_item_id2 = NULL;
					ITK_CALL(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
					
					int result = 0;
					
					if(*ChildTagList_cntGlobal > 0)
					{
						int yy = 0;
						for(yy=0;yy<*ChildTagList_cntGlobal;yy++)
						{										
							char *child_itm_id = NULL;
							ITK_CALL(AOM_ask_value_string(*ChildTagListGlobal[yy], "bl_item_item_id", &child_itm_id ));
							
							if(tc_strcmp(child_itm_id,bl_item_id2)==0)
							{
								printf("\n object [%s] found",child_itm_id);fflush(stdout);
								result = 1; //object found so not to add in array
								break;
							}
						}
						
						printf("\n result [%d]",result);fflush(stdout);
						
						if(result==0) //adding object into array as is not found in tag*
						{
							;//ChildTagListGlobal=vector_add(ChildTagListGlobal,&childline2);
						}
					}
					else //first time entering
					{
						if(y==0)
						{
							printf("\n entering for fisrt time");fflush(stdout);
						}
						;//ChildTagListGlobal=vector_add(ChildTagListGlobal,&childline2);
					}
					
					
					char *parent_child=NULL;
					parent_child=(char *)MEM_alloc( 100 );

					
					
					tc_strcpy(parent_child,"");
					tc_strcat(parent_child,bl_item_id);
					tc_strcat(parent_child,"#");
					tc_strcat(parent_child,bl_item_id2);
					
					//collection_add(&v, parent_child);
					
					printf("\n[%d] bl_item_id2=%s %s",y,bl_item_id2, parent_child);fflush(stdout);
				}

			}  
			return 0;
		}



		int CheckPartInRange1(tag_t PartRev,char* FrmDt, char* ToDt,tag_t *dmlrev,int *found)
		{
			int ifail;
			
			date_t 	tc_date_Frm;
			date_t 	tc_date_to;	
			int 	answerDate1			= 0;
			int 	answerDate2			= 0;
			char*	ReleaseDt1			= NULL;
			*found=0;
			getTCDate(FrmDt,&tc_date_Frm);
			getTCDate(ToDt,&tc_date_to);							
			int		countRet		= 0;
			int		countRetD		= 0;
			
			tag_t 	*primary		= NULLTAG;			
			tag_t 	*primaryDML		= NULLTAG;			
			tag_t 	ItemTaskPr		= NULLTAG;	
			date_t 	tc_date_DML;
			const char *relname="CMHasSolutionItem";
			const char *relnameDMLTask="T5_DMLTaskRelation";
			const char* filter="T5_ChangeTaskRevision";
			getRelationS2P(PartRev,&primary,relname,0,&countRet);
			if(countRet>0)
			{
				
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ DML Task Item ID is=%s \n",objecttype);fflush(stdout);
				int y;
				for(y=0;y<countRet;y++)
				{
					char*	objecttype  = NULL;
				
				AOM_ask_value_string(primary[y],"object_type",&objecttype);
				if(tc_strcmp(objecttype,"T5_ChangeTaskRevision")==0)
				{
					ItemTaskPr=primary[y];
					break;
				}
				}
				if(ItemTaskPr!=NULLTAG)
				{
					getRelationS2P(ItemTaskPr,&primaryDML,relnameDMLTask,1,&countRetD);
					if(countRetD>0)
					{
						tag_t 	ItemDML		= NULLTAG;	
						char*	ReleaseDt1	= NULL;
						char*	DMLNumber1	= NULL;
						ItemDML=primaryDML[0];
						AOM_ask_value_string(ItemDML,"item_id",&DMLNumber1);
						AOM_UIF_ask_value(ItemDML,"date_released",&ReleaseDt1);
						printf("\n DML1 %s Release Date == %s\n",DMLNumber1,ReleaseDt1);fflush(stdout);				
						ReleaseDt1			= strtok (ReleaseDt1," ");
						ITK_string_to_date(ReleaseDt1, &tc_date_DML);
						//getTCDate(ReleaseDt1,&tc_date_DML);
						
						POM_compare_dates(tc_date_Frm,tc_date_DML,&answerDate1); 
						POM_compare_dates(tc_date_to,tc_date_DML,&answerDate2); 
						
						printf("\n date1 == %d  date2 == %d \n",answerDate1,answerDate2);fflush(stdout);
						
						if((answerDate1<0 || answerDate1==0) && (answerDate2==1 || answerDate2==0))
						{
							*found	= 1;
							*dmlrev=ItemDML;
							char *dml2;
							ITK_CALL(AOM_ask_value_string(ItemDML,"item_id",&dml2));
							char *dml3;
							ITK_CALL(AOM_ask_value_string(*dmlrev,"item_id",&dml3));
							printf("\n dml3 DML1 %s \n",dml3);fflush(stdout);	
						}	
						
						//MEM_free(primaryDML);
						//MEM_free(primary);
					}
				}
			}	
		}

		int CheckPartInRange(tag_t PartRev,char* FrmDt, char* ToDt,int *found)
		{
			int ifail;
			
			date_t 	tc_date_Frm;
			date_t 	tc_date_to;	
			int 	answerDate1			= 0;
			int 	answerDate2			= 0;
			char*	ReleaseDt1			= NULL;
			
			getTCDate(FrmDt,&tc_date_Frm);
			getTCDate(ToDt,&tc_date_to);							
			int		countRet		= 0;
			int		countRetD		= 0;
			
			tag_t 	*primary		= NULLTAG;			
			tag_t 	*primaryDML		= NULLTAG;			
			tag_t 	ItemTaskPr		= NULLTAG;	
			date_t 	tc_date_DML;
			const char *relname="CMHasSolutionItem";
			const char *relnameDMLTask="T5_DMLTaskRelation";
			const char* filter="T5_ChangeTaskRevision";
			getRelationS2P(PartRev,&primary,relname,1,&countRet);
			if(countRet>0)
			{
				char*	ERCDMLTaskNo  = NULL;
				ItemTaskPr=primary[0];
				AOM_ask_value_string(ItemTaskPr,"item_id",&ERCDMLTaskNo);
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@ DML Task Item ID is=%s \n",ERCDMLTaskNo);fflush(stdout);
				if(tc_strlen(ERCDMLTaskNo)==13)
				{
					getRelationS2P(ItemTaskPr,&primaryDML,relnameDMLTask,0,&countRetD);
					if(countRet>0)
					{
						tag_t 	ItemDML		= NULLTAG;	
						char*	ReleaseDt1	= NULL;
						char*	DMLNumber1	= NULL;
						ItemDML=primaryDML[0];
						AOM_ask_value_string(ItemDML,"item_id",&DMLNumber1);
						AOM_UIF_ask_value(ItemDML,"date_released",&ReleaseDt1);
						printf("\n DML1 %s Release Date == %s\n",DMLNumber1,ReleaseDt1);fflush(stdout);				
						ReleaseDt1			= strtok (ReleaseDt1," ");
						ITK_string_to_date(ReleaseDt1, &tc_date_DML);
						//getTCDate(ReleaseDt1,&tc_date_DML);
						
						POM_compare_dates(tc_date_Frm,tc_date_DML,&answerDate1); 
						POM_compare_dates(tc_date_to,tc_date_DML,&answerDate2); 
						
						printf("\n date1 == %d  date2 == %d \n",answerDate1,answerDate2);fflush(stdout);
						
						if((answerDate1<0 || answerDate1==0) && (answerDate2==1 || answerDate2==0))
						{
							*found	= 1;
							
						}	
						
						MEM_free(primaryDML);
						MEM_free(primary);
					}
				}
			}	
		}
		 





		int getLatestReleasedPartSVR(char *partNumber,char *rev,char *object_type, tag_t *latestPart,char* FrmDt, char* ToDt,int *total_cnt)
		{
			int ifail = ITK_ok;
			int  count 	= 0;
			tag_t *itemrevs = NULLTAG;	
			char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
			char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
			tag_t query = NULLTAG;
			char* revid=(char *)MEM_alloc(10 * sizeof(char *));
			tc_strcpy(revid,rev);
			tc_strcat(revid,"*");
			
			
			printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
			
			qry_entries[0] = "Release Status";
			qry_entries[1] = "Type";
			qry_entries[2] = "Item ID";
			qry_entries[3] = "Revision";
			
			qry_values[0] = "T5_LcsErcRlzd"; // STD Released state
			qry_values[1] = object_type;
			qry_values[2] = partNumber;
			qry_values[3] = revid;
				
			ITK_CALL(QRY_find2("Item Revision...", &query));
			ITK_CALL(QRY_execute(query, 4, qry_entries, qry_values, &count, &itemrevs));
			
			MEM_free(qry_entries);
			MEM_free(qry_values);
			
			printf("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
			
			//get the latest released object by creation date
			int i=0;
			int	j=0;
			int max =0;
			int found =0;
			long days=0;
			long days1 =0;
			char* partRev;
			char* creationDate;
			date_t creation_dt;
			date_t creation_dt1;
			int ans =0;
			if(count>0)
			{
				for(i=0; i<count;i++)
				{
					ITK_CALL(AOM_ask_value_string(itemrevs[i],"item_revision_id",&partRev))	
					printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(itemrevs[i],"creation_date",&creationDate));
					printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
					ITK_CALL(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
			
					CheckPartInRange(itemrevs[i],FrmDt,ToDt,&found);
					if(found==1)
					{
						*total_cnt=*total_cnt+1;
					}
					max = i;
					for(j=i;j<count;j++)
					{
						ITK_CALL(AOM_ask_value_string(itemrevs[j],"item_revision_id",&partRev))	
						printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(itemrevs[j],"creation_date",&creationDate));
						printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
						ITK_CALL(AOM_ask_value_date(itemrevs[j],"creation_date",&creation_dt1));
						ITK_CALL(POM_compare_dates(creation_dt1, creation_dt, &ans));
						if(ans ==1) max =j;
					}
					
				}
				*latestPart = itemrevs[max];
				ITK_CALL(AOM_ask_value_string(*latestPart,"item_revision_id",&partRev))
				printf("\ngetLatestStandardReleasedPart: Latest Part Revision: %s",partRev);fflush(stdout);
				MEM_free(itemrevs);
			}
			return ifail;
		}

		void pom_query(char* partno,vector_t *item_list,int *cnt)
		{
			int ifail = 0;
			int rows = 0;
			int cols = 0;  
			void ***ppReport = NULL;
			char *pQry1 = "QueryItemRevASC";
			//const char *partnumber[]={"5445B1B0263001"};
			const char *partnumber[]={partno};
			const char *objecttype[]={"Design Revision"};

			char *pClass = "ItemRevision";
			const char *select_attrs_ItemRev[] = { "puid", "creation_date" };
			const char *select_attrs_Item[] = { "item_id" };

			const char *value_list[] = { "T5_LcsErcRlzd" };
			
			
				ITK_CALL(POM_enquiry_create(pQry1));
				
				ITK_CALL(POM_enquiry_add_select_attrs(pQry1, "ItemRevision", 1,select_attrs_ItemRev));
				
				
				 ITK_CALL(POM_enquiry_set_string_value (pQry1,"partnumber_expr",1,partnumber,POM_enquiry_bind_value));
				
				ITK_CALL(POM_enquiry_set_attr_expr (pQry1,"expr_part","Item","item_id",POM_enquiry_equal,"partnumber_expr"));
				
				ITK_CALL(POM_enquiry_set_string_value (pQry1,"objecttype_expr",1,objecttype,POM_enquiry_bind_value));
				
				ITK_CALL(POM_enquiry_set_attr_expr (pQry1,"expr_objecttype","ItemRevision","object_type",POM_enquiry_equal,"objecttype_expr"));
				
				

				ITK_CALL(POM_enquiry_set_string_value(pQry1, "str_val1", 1,value_list, POM_enquiry_bind_value));

				/* limit ItemRevision.items_tag == item.puid */
					ITK_CALL(POM_enquiry_set_join_expr(pQry1, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
				/* limit ItemRevision.release_status_list == ReleaseStatus.puid
		*/
				ITK_CALL(POM_enquiry_set_join_expr(pQry1, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
				/* limit 'ReleaseStatus.name' in { "Released", "Issued",
		"Superseded" } */
				ITK_CALL(POM_enquiry_set_attr_expr(pQry1, "attr_expr1","ReleaseStatus", "name", POM_enquiry_in, "str_val1"));
				
				/* combine expressions */
				ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
				ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr1","expr_part", POM_enquiry_and, "expr_objecttype"));
				ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr_2","combine_expr1", POM_enquiry_and, "combine_expr"));
				ITK_CALL(POM_enquiry_set_expr(pQry1, "combine_expr2","combine_expr_2", POM_enquiry_and, "attr_expr1"));
				ITK_CALL(POM_enquiry_set_where_expr(pQry1, "combine_expr2"));

				
				ITK_CALL(POM_enquiry_add_order_attr(pQry1, "ItemRevision", "creation_date", POM_enquiry_asc_order));
				ITK_CALL(POM_enquiry_execute(pQry1, &rows, &cols, &ppReport));
				ITK_CALL(POM_enquiry_delete(pQry1));
			//	MEM_free(pQry1);

				int objcount=0;		

				int i,j;
				for(i = 0; i < rows; i++)
				{
					void** col = ppReport[i];
					
					item_list=vector_add(item_list,(tag_t*)col[0]);

					printf("\n");
				}

				printf("Total rows: %d", rows);
				
			*cnt=objcount;

			if(ppReport != NULL)
				MEM_free(ppReport);

		}
		 int printObject(tag_t objtag)
		{

					   int                prop_count=0;
					   char**             prop_names=NULL;
					   int        num_values=0;
					   char**     values =NULL;
					   tag_t                   class_tag=NULLTAG;
					   char                     *class_name=NULL;
					   int j=0,k=0;

					   logical propConstReqBool=false;

					   int ifail=ITK_ok;

					   printf("\n printObject()->");fflush(stdout);

			 if(objtag==NULLTAG)
			 {
						printf("\nNULLTAG");fflush(stdout);
						return ifail;
			 }
					   /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
					   ITK_CALL(POM_name_of_class(class_tag, &class_name) );

		*/
			 char *type_name=NULL;
			 tag_t type_tag = NULLTAG;
			 ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

			 ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



					   ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
					   printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
					   // printf("\n printObject2 %d",prop_count);fflush(stdout);

					   for (k=0;k<prop_count;k++)
					   {
					   ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values));

		 tag_t prop_tag = NULLTAG;
					   ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
					   printf("\n %s:{,[",prop_names[k]);fflush(stdout);

					   propConstReqBool=false;
					   char *prop_dispay_name=NULL;
					   PROP_value_type_t valtype;
					   char *valtypeName=NULL;
					   ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

																				   printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
																				   ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
																				   printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
																				   ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
																				   printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
																				   printf("\n]\n");fflush(stdout);

					   for(j=0;j<num_values;j++)
					   {
					   printf("\n\t%s,",values[j]);fflush(stdout);
					   }

					   printf("\n },");fflush(stdout);

					   }
					   printf("\n]");fflush(stdout);
		return ifail;
		}

		 int getAllReleasedPartDML(tag_t query ,char *partNumber,char *object_type, tag_t *latestdml,tag_t *latestPart,tag_t *prevrevpartObj,vector_t **alldmllist,vector_t **allpartlist,int *allpart_dml_cnt,char* FrmDt, char* ToDt,int *total_cnt)
		 {
			 
			 tag_t *latestPart1=NULLTAG;
			 int ifail = ITK_ok;
			int  count 	= 0,count1=0;
			*total_cnt=0;
			tag_t *itemrevs = NULLTAG;	
			tag_t *itemrevs1 = NULLTAG;	
			tag_t tmpprevrevpartObj=NULLTAG;
			//char *relstat="T5_LcsErcRlzd";
		char **qry_entries = (char **) MEM_alloc(3 * sizeof(char *));
			char **qry_values = (char **) MEM_alloc(3 * sizeof(char *));

		//char *qry_entries[] ={"Item ID","Type","Release Status"};
			//char *qry_values[] = {partNumber,object_type,relstat};
			int            num_to_sort=0;
			char**         keys=(char **) MEM_alloc(1 * sizeof(char *));//={"creation_date"};
			int orders[]={1};
			
			TC_write_syslog("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);	

			
			
			
			printf("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);fflush(stdout);
			
			
			qry_entries[0] = (char *)MEM_alloc(50);
			qry_entries[1] = (char *)MEM_alloc(50);
			qry_entries[2] = (char *)MEM_alloc(50);
			
			qry_values[0] = (char *)MEM_alloc(50);
			qry_values[1] = (char *)MEM_alloc(50);
			qry_values[2] = (char *)MEM_alloc(50);
					   



			strcpy(qry_entries[0],  "Item ID");
			strcpy(qry_entries[1],  "Type");
			strcpy(qry_entries[2],  "Release Status");	
			
			strcpy(qry_values[0],  partNumber);
			strcpy(qry_values[1],  object_type);
			strcpy(qry_values[2],  "T5_LcsErcRlzd");
			
			
			keys[0] = (char *)MEM_alloc(50);
			strcpy(keys[0],  "creation_date");
			
			//tag_t query = NULLTAG;	
			//ITK_CALL(QRY_find2("Item Revision...", &query));
			ITK_CALL(QRY_execute_with_sort(query, 3, qry_entries, qry_values,num_to_sort,keys,orders, &count1, &itemrevs1));
			MEM_free(qry_entries);
			MEM_free(qry_values);
			MEM_free(keys);
			
			if(count1>0)
			{
			tag_t type_tag;
			ITK_CALL(TCTYPE_ask_object_type(itemrevs1[0],&type_tag));
			tag_t prop_tag = NULLTAG;
			ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"creation_date",&prop_tag));
			tag_t prop_tags[] = {prop_tag};
			const int          sort_orders[]={0};//            /**< (I) n_props Sort order: 0 = ascending, 1 = descending */
			ITK_CALL(AOM_sort_tags_by_properties(count1,itemrevs1,1 ,prop_tags,sort_orders,&count,&itemrevs));
			
			}
			//pom_query(partNumber,&itemrevs,&count);
			printf("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
			
			TC_write_syslog("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
			
			//get the latest released object by creation date
			int i=0;
			int	j=0;
			int max =0;
			int found =0;
			long days=0;
			long days1 =0;
			char* part_no;
			char* partRev;
			char* creationDate;
			date_t creation_dt;
			date_t creation_dt1;
			int alldmllist_cnt=0;
			int allpartlist_cnt=0;
			
			int ans =0;
			if(count>0)
			{
				for(i=0; i<count;i++)
				{
					//printObject(itemrevs[i]);
					int prevrevidx=i-1;
					if(prevrevidx>=0)
					{
						tmpprevrevpartObj=itemrevs[prevrevidx];
					}
					ITK_CALL(AOM_ask_value_string(itemrevs[i],"item_id",&part_no))	
					ITK_CALL(AOM_ask_value_string(itemrevs[i],"item_revision_id",&partRev))	
					printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s/%s",i,part_no,partRev);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(itemrevs[i],"creation_date",&creationDate));
					printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
					ITK_CALL(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
			
					tag_t dmltag=NULLTAG;
					CheckPartInRange1(itemrevs[i],FrmDt,ToDt,&dmltag,&found);
					if(found==1)
					{
						*total_cnt=*total_cnt+1;
						printf("\ncollection_add : DMLTAG");fflush(stdout);
						if(dmltag==NULLTAG)
							printf("\ncollection_add : NULL DMLTAG");fflush(stdout);
						tag_t *tdml_tag=(tag_t *)MEM_alloc( sizeof ( tag_t ) );
						 *tdml_tag= dmltag;
						*alldmllist=vector_add(*alldmllist,tdml_tag);
						printf("\ncollection_add 1: DMLTAG");fflush(stdout);
						tag_t *tpart_tag=(tag_t *)MEM_alloc( sizeof ( tag_t ) );
						 *tpart_tag= itemrevs[i];
						*allpartlist=vector_add(*allpartlist,tpart_tag);	
	printf("\ncollection_add2 : DMLTAG");fflush(stdout);					
					}
					/*if(i==0)
					{
									printf("\n11getLatestStandardReleasedPart");fflush(stdout);
					*latestPart = itemrevs[i];
					printf("\n22getLatestStandardReleasedPart");fflush(stdout);
					if(dmltag!=NULLTAG)
					{
						printf("\n33getLatestStandardReleasedPart");fflush(stdout);
					*latestdml =dmltag;
					}
					printf("\n44getLatestStandardReleasedPart");fflush(stdout);
					}
				else{
					ITK_CALL(AOM_ask_value_date(*latestPart,"creation_date",&creation_dt1));
					ITK_CALL(POM_compare_dates(creation_dt, creation_dt1, &ans));
					if(ans==1)
					{
						*latestPart = itemrevs[i];
									if(dmltag!=NULLTAG)
									*latestdml =dmltag;
					}
					
				}*/
				}
				//}
				//*latestPart = itemrevs[max];
				//ITK_CALL(AOM_ask_value_string(*latestPart,"item_revision_id",&partRev));
				//printf("\ngetLatestStandardReleasedPart: Latest Part Revision: %s",partRev);fflush(stdout);
			}
			
			*allpart_dml_cnt=alldmllist_cnt;
			//*total_cnt=count;
			
			if(tmpprevrevpartObj!=NULLTAG)
			{
				memcpy(prevrevpartObj,&tmpprevrevpartObj,sizeof(tmpprevrevpartObj));
			}
			
			if(itemrevs!=NULL&&count>0 )
			{
			MEM_free(itemrevs);
			itemrevs=NULLTAG ;
			}
			
			int allpart_dml_cnt1=vector_size(*allpartlist);
			int f;
				for(f=0;f<allpart_dml_cnt1;f++)
				{
					printf("\n [%d]goig MAPPPPPPP ",f);fflush(stdout);
				 tag_t *tpartObj1=NULLTAG;
				 tpartObj1=((tag_t*)vector_get(*allpartlist,f));//allpartlist[f];
				  tag_t *tdmlobj1=NULLTAG;
				  tdmlobj1=((tag_t*)vector_get(*alldmllist,f));//allpartlist[f];
				  char *item1;
				  char *item2;
				  ITK_CALL(AOM_UIF_ask_value(*tpartObj1,"item_id", &item1));
				  ITK_CALL(AOM_UIF_ask_value(*tdmlobj1,"item_id", &item2));
				  printf("\n [%d]MAPPPPPPP %s===>%s",f,item1,item2);fflush(stdout);
				 // MEM_free(tpartObj1);
				  //MEM_free(tdmlobj1);
	//printObject( *tpartObj1);
				}
				
				/* allpart_dml_cnt1=vector_size(*alldmllist);
			
				for(f=0;f<allpart_dml_cnt1;f++)
				{
				 tag_t *tpartObj1=((tag_t*)vector_get(*alldmllist,f));//allpartlist[f];
				 printObject( *tpartObj1);
				}*/
			return ifail;
			 
			 
			 
		 }
		 
		 
		 
		 int getAllReleasedPartDML1(tag_t query ,char *partNumber,char *object_type)
		 {
			 
			 
			 int ifail = ITK_ok;
			int  count 	= 0;
			tag_t *itemrevs = NULLTAG;	
			char *relstat="T5_LcsErcRlzd";

			char *qry_entries[] ={"Item ID","Type","Release Status"};
			char *qry_values[] = {partNumber,object_type,relstat};
			int            num_to_sort=0;
			char*         keys[]={"creation_date"};
			int orders[]={1};
			
			TC_write_syslog("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);	

			
			//tag_t query = NULLTAG;
			
			printf("\n\n xxobject_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);fflush(stdout);
			
			
			//ITK_CALL(QRY_find2("Item Revision...", &query));
			//if(query!=NULLTAG)
			ITK_CALL(QRY_execute_with_sort(query, 3, qry_entries, qry_values,num_to_sort,keys,orders, &count, &itemrevs));
			//MEM_free(qry_entries);
			//MEM_free(qry_values);
			
			//pom_query(partNumber,&itemrevs,&count);
			printf("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
			
			
			
			return ifail;
			 
			 
			 
		 }
		 
		 
		 
		int getLatestReleasedPart(tag_t query,char *partNumber,char *object_type, tag_t *latestPart,char* FrmDt, char* ToDt,int *total_cnt)
		{
			int ifail = ITK_ok;
			int  count 	= 0;
			tag_t *itemrevs = NULLTAG;	
			
			
			char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
			
			char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
			
			//tag_t query = NULLTAG;
			
			printf("\n\n object_type ===> [%s] partNumber==>[%s]\n",object_type,partNumber);fflush(stdout);
			
			qry_entries[0] = "Release Status";
			qry_entries[1] = "Type";
			qry_entries[2] = "Item ID";
			
			qry_values[0] = "T5_LcsErcRlzd"; // STD Released state
			qry_values[1] = object_type;
			qry_values[2] = partNumber;
				
			//ITK_CALL(QRY_find2("Item Revision...", &query));
			ITK_CALL(QRY_execute(query, 3, qry_entries, qry_values, &count, &itemrevs));
			
			printf("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
			MEM_free(qry_entries);
			MEM_free(qry_values);
			
			//get the latest released object by creation date
			int i=0;
			int	j=0;
			int max =0;
			int found =0;
			long days=0;
			long days1 =0;
			char* partRev;
			char* creationDate;
			date_t creation_dt;
			date_t creation_dt1;
			int ans =0;
			
			if(count>0)
			{
				
				for(i=0; i<count;i++)
				{
					
					ITK_CALL(AOM_ask_value_string(itemrevs[i],"item_revision_id",&partRev))	
					printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(itemrevs[i],"creation_date",&creationDate));
					printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
					ITK_CALL(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
			
					CheckPartInRange(itemrevs[i],FrmDt,ToDt,&found);
					if(found==1)
					{
						*total_cnt=*total_cnt+1;
					}
					max = i;
					
					for(j=i;j<count;j++)
					{
						ITK_CALL(AOM_ask_value_string(itemrevs[j],"item_revision_id",&partRev))	
						printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(itemrevs[j],"creation_date",&creationDate));
						printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
						ITK_CALL(AOM_ask_value_date(itemrevs[j],"creation_date",&creation_dt1));
						ITK_CALL(POM_compare_dates(creation_dt1, creation_dt, &ans));
						if(ans ==1) max =j;
					}
					
				}
				
				*latestPart = itemrevs[max];
				ITK_CALL(AOM_ask_value_string(*latestPart,"item_revision_id",&partRev))
				printf("\ngetLatestStandardReleasedPart: Latest Part Revision: %s",partRev);fflush(stdout);
				
			}
			
			if(count>0&&itemrevs!=NULL)
			{
				
				MEM_free(itemrevs);
			}
			
			return ifail;
		}


		int GatewayRptFunc( void *return_data )
		{
			int status;
			int				ifail 						= ITK_ok;
			printf("\n I am in main program");fflush(stdout);
			char 			*output 				= NULL;
			char			*FrmDt					= NULL;
			char			*ToDt					= NULL;
			char			*VCData					= NULL;
			char			*VCCtnt					= NULL;
			int				VCAttrName_cnt			= 0;
			vector_t 		*VCAttrName				=vector_new(1,1);
			
			output = (char *) MEM_alloc( 5000 * sizeof(char) );
			
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]MAJORMODEL"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]VEH_APPLN(VEH_APPLN)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Emission Norms"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Fuel"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("VEHICLE_CLASS"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]MASCOT"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]Wheel Base(WHEEL_BASE_IN_MM)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Other Features"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("BI FUEL ENGINE/MOTOR POWER (KW)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("LOAD_BODY_TYPE"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]Seating Capacity(SEATING_CAP)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("PSG_CAPECITY"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("VAHAN SEATING CAPACITY (INCLUDING DRIVER)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("CH_CAB_LB_SW_TO"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Project_Date"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("SOP_Target"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Part_Status"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Directive"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Country"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Vehicle"));
			
			int				VCAttrVal_cnt			= 0;
			vector_t      *VCAttrVal=vector_new(1,1);
			
			int  			VCSet_cnt		= 0;
			vector_t 		*VCSet=	vector_new(1,1);
			int 			AddFlg			= 0;
			int 			i,i1			= 0;
			char			*OutPutLoc		= NULL;
			/* Output File Creation Start*/
			char 	Data[100]			= "";
			char 	CurrDate[100]		= "";
			char	OutputFile[200]		= "";
			time_t 	now;
			struct 	tm	when;
			BOMHolder *vcs;
			
			time(&now);
			when = *localtime(&now);
			
			strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
			strftime(CurrDate,100,"%d-%m-%Y",&when);
			//sprintf(OutputFile,"GateWayReport_%s.csv",Data);	
			
			char 			*FrmDateF			= 	NULL;
			char 			*ToDateF			= 	NULL;
			tag_t query=NULLTAG;
			ITK_CALL(QRY_find2("Item Revision...", &query));
			
			USERARG_get_string_argument(&OutPutLoc);
			int bomdepth=-1;
			int n_objects = 0;
			tag_t *objects = NULL;
			ifail = USERARG_get_tag_array_argument(&n_objects, &objects); 
			vector_t *part_dml_vec;
			int part_dml_count=0;
			//USERARG_get_string_argument(&VCData);
			USERARG_get_string_argument(&VCCtnt);
			USERARG_get_string_argument(&FrmDateF);
			USERARG_get_string_argument(&ToDateF);
			
			FrmDt			= strtok (FrmDateF," ");
			ToDt  			= strtok (ToDateF," ");	
			
			printf("\n Recieved Args ~ Output Location := %s , VC Data =:= %s, VC Count := %s, From Date := %s, To Date:= %s",OutPutLoc,VCData,VCCtnt,FrmDt,ToDt);
			
			int 	x = 0;
			for(x=0;x<n_objects;x++)
			{
				char* 		vehNo 	= NULL;
				ITK_CALL(AOM_ask_value_string(objects[x],"item_id",&vehNo));
				VCSet=vector_add(VCSet,MEM_string_copy(vehNo));
			}

			tc_strcpy(output,"");	
			tc_strcat(output,"\n,,,GATEWAY REPORT,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\n,,,******************,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\n,,,Date of report  :");
			tc_strcat(output,CurrDate);
			tc_strcat(output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\n,,,From Date  :");
			tc_strcat(output,FrmDt);
			tc_strcat(output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\n,,,To Date  :");
			tc_strcat(output,ToDt);
			tc_strcat(output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\nVC NO,MAJOR_MODEL,VEH_APPLN,EMISSION_NORMS,FUEL,VEH_CLASS,MASCOT,WHEEL_BASE,OTHER,ENGINE_MODEL,LOAD_BODY_TYPE,SEATS,PSG_CAPACITY,SEAT_CAPACITY,CAB BODY,Project_Date,SOP_Target,Part_Status,Directive,Country,Vehicle,,,,,,,,,,");
			//tc_strcat(output,"\nVehicle,1,17,36,37,52,66,68,104,15,177,23,35,70,8,Planned Release Date,Planned Effective Date,Vehicle's DR status,Dir Reg,Country of Export,Hlg Veh Type,,,,,,,,,,");
			tc_strcat(output,"\n********************,********************,**************,  **************, ********************,*********************,*****************,************************,***************,********************,********************,*****************,*******************,*******************,****************,***************,***************,*******************,****************,***************,***************,,,,,,,,,,");
			if(VCSet_cnt>0)
			{
				for (i1=0;i1<VCSet_cnt ;i1++)
				{
					char *VCNum1 = NULL;
					char			*object_type1			= "Design Revision"; //change to Design Revision
					VCNum1=(char *) MEM_alloc(100 * sizeof(char *));
					VCNum1 = (char *)vector_get(VCSet,i1);
					tag_t	partObj1 						= NULLTAG;
					char* 	vehicleNumber1 					= NULL;
					char* 	PDRStat1 						= NULL;
					int 			nAttributes				= 0;
					char 			**attributeNames;
					char 			**attributeValues;
					int				ii						= 0;
					int				total_Count				= 0;
					tag_t			classificationObject;
					tag_t			cObject					= NULLTAG;	
					char* 			vehNo 					= NULL;
					ITK_CALL(AOM_ask_value_string(objects[i1],"item_id",&vehNo));
					ITK_CALL(getLatestReleasedPart(query,vehNo,object_type1, &partObj1,FrmDt,ToDt,&total_Count));
					//partObj1 = objects[i1];
					if(partObj1==NULLTAG)
					{	
						tc_strcat(output,"\n");
						tc_strcat(output,vehNo);
						tc_strcat(output,",");
						tc_strcat(output,"Not Released From ERC");
						printf("\n No released revision found for this VC %s\n",vehNo);
						continue;				
					}
					 tag_t VehPartMaster=NULLTAG;
								ITK_CALL(ITEM_ask_item_of_rev(partObj1, &VehPartMaster));
					ITK_CALL(AOM_ask_value_string(partObj1,"item_id",&vehicleNumber1));
					ITK_CALL(AOM_ask_value_string(partObj1,"t5_PartStatus",&PDRStat1));
					ITK_CALL(ICS_ask_classification_object(VehPartMaster,&classificationObject));
					ITK_CALL(ICS_ask_attributes_of_classification_obj(classificationObject,&nAttributes, &attributeNames, &attributeValues));
					printf("### ICS_ask_attributes_of_classification_obj nAttributes = %d\n", nAttributes);
					tc_strcat(output,"\n");
					tc_strcat(output,vehicleNumber1);
					tc_strcat(output,",");
					char			**AttrVals            = NULL;
					int 			i2					  = 0;
					
					AttrVals = (char **)MEM_alloc(VCAttrName_cnt  * sizeof(char *));
				
					for(i2=0;i2<VCAttrName_cnt;i2++)
					{
					
					AttrVals[i2] = MEM_alloc(100 * sizeof(char));
					tc_strcpy(AttrVals[i2],"NA");
					}
				
					for(ii = 0; ii < nAttributes; ii++)
					{
						//printf("\t%s - %s\n", attributeNames[ii], attributeValues[ii]);
						int AttrFound = 0;
						vector_find_str(VCAttrName,attributeNames[ii],&AttrFound);
						//printf("\n Found Val for AttrFound = %d",AttrFound);fflush(stdout);
						if(AttrFound>=0)
						{					
							if(attributeValues[ii]!=NULL || attributeValues[ii]!="")
							{												
								//printf("\t~~%s - %s\n", attributeNames[ii], attributeValues[ii]);
								tc_strcpy(AttrVals[AttrFound],attributeValues[ii]);
							}					
						}
					}
					MEM_free(attributeNames);
					MEM_free(attributeValues);  
					
					for(ii = 0; ii<VCAttrName_cnt; ii++)
					{	
						//printf("\n Found vals AttrVals[ii] = %s",AttrVals[ii]);fflush(stdout);
						tc_strcat(output,AttrVals[ii]);
						tc_strcat(output,",");
					}
					MEM_free(AttrVals);
				}
			}
			
			tc_strcat(output,"\n,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\n********************,**************,**************,**************,**************,*******************************************************************************************************************************************,*********************,*****************,************************,***************,********************,********************,*****************,*******************,*******************,****************,***************,***************,*******************,****************,***************,***************,***************,,,,,,,,,,");
			tc_strcat(output,"\n,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			tc_strcat(output,"\nLevel,PART NUMBER,PART TYPE,DESC,REVISION,SEQ, MODFN DESCRIPTION,DESIGN GRP,OWNERNAME,Part DR Status,DML DR Status,Gate Maturation DML, Gate Maturation ClosureDate,DML NO,DML RLS DATE,DML DR Status,SYNOPSIS,DML PROJECT,RELEASE TYPE,REASON, LIFECYCLESTATE, DML CREATOR,CREATOR NAME,AUTHORISED BY,AUTHOR NAME,DMU REVIEWER ,DML AGGR,KEYWORD DESC,PART FAMILY,Counter,BOM CHANGE,");
			for (i=0;i<VCSet_cnt ;i++)
			{
				tc_strcat(output,(char *)vector_get(VCSet,i));
				tc_strcat(output,",");
			}
			tc_strcat(output,"\n********************,********************,********************,********************,*************************************,**************, **************, **************,  **************************************,*********************,*****************,*******************,************************,,*******************,************************,***************,******************************,********************,*****************,*******************,*******************,****************,****************,****************,****************,****************,****************,****************,****************,****************,");
			for (i=0;i<VCSet_cnt ;i++)
			{
				tc_strcat(output,"***************,");
			}
			
			if(VCSet_cnt>0)
			{
				vcs =(BOMHolder *) malloc(sizeof(BOMHolder)*VCSet_cnt);
				vector_t *ChildTagListGlobal 	;
				int 	ChildTagList_cntGlobal 	= 0;
				int	  	BomLvl_cnt				= 0;
				vector_t	  	*bomLevel			;
				vector_t	 	*bom_counter;
				for (i=0;i<VCSet_cnt ;i++)
				{		
					char *VCNum = NULL;
					VCNum=(char *) MEM_alloc(100 * sizeof(char *));
					VCNum =(char *)vector_get( VCSet,i);
					char	*object_type 	= "Design Revision"; //change to Design Revision
					tag_t	partObj 		= NULLTAG;
					tag_t	top_line		= NULLTAG;
					tag_t	window			= NULLTAG;
					tag_t	rule			= NULLTAG;
					tag_t	item_tag 		= null_tag;
					int 	n_bom_views     = 0;
					int 	total_Count     = 0;
					tag_t 	*bom_views      = NULL;
					printf("\n Processing VC String (%d,%s)",i,VCNum);fflush(stdout);			
					ITK_CALL(getLatestReleasedPart(query,VCNum,object_type, &partObj,FrmDt,ToDt,&total_Count));			
					if(partObj!=NULLTAG)
					{				
						printf("\n Tag returned from function..\n");
						tag_t VehMaster 		= NULLTAG;
						tag_t *bom_views        = NULL;
						char* vehicleNumber 	= NULL;
						char *view_type_name    = NULL;
						vector_t *ChildTagList	    = NULLTAG;
						int	  ChildTagList_cnt,k= 0;		
						tag_t view_type 		= NULLTAG;		
						tag_t erc_view 			= NULLTAG;
						tag_t apl_view 			= NULLTAG;
						tag_t dfma_view 		= NULLTAG;
						ITK_CALL(ITEM_ask_item_of_rev(partObj, &VehMaster)); // Get the Item from the revision
						ITK_CALL(ITEM_list_bom_views(VehMaster, &n_bom_views, &bom_views )); //Get the bom views
						ITK_CALL(AOM_ask_value_string(partObj,"item_id",&vehicleNumber));
						printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);		
						
						ifail = BOM_create_window (&window);
						CHECK_FAIL;
						ifail = CFM_find( "Latest Working", &rule );
						CHECK_FAIL;
						ifail = BOM_set_window_config_rule( window, rule );
						CHECK_FAIL;
						ifail = BOM_set_window_pack_all (window, true);
						CHECK_FAIL;
						
						ifail = BOM_set_window_top_line (window, VehMaster, partObj, NULLTAG, &top_line);
						CHECK_FAIL;
						vector_t *childRevStrList;
						vector_t *global_bom_flag;
						
						ChildTagList_cnt = 0;
						//bom_counter  = 0;
						printBom(query,bomdepth,top_line, -1,&ChildTagListGlobal,&ChildTagList_cntGlobal,&ChildTagList,&ChildTagList_cnt,&BomLvl_cnt,&bomLevel,&bom_counter,FrmDt,ToDt, &part_dml_vec,&part_dml_count,&childRevStrList, rule,&global_bom_flag);
						tc_strcpy(vcs[i].VC,vehicleNumber);
						vcs[i].childCount=ChildTagList_cnt;
						vcs[i].Children=(tag_t *)ChildTagList->content;				
						vcs[i].counter=(int *)bom_counter->content;
						
						for(k=0;k<ChildTagList_cnt;k++)
						{
							tag_t	itemrevtag	= NULLTAG;
							int		BLvl		= 0;
							char	*ChldPartNo = NULL;					
							tag_t *titemrevtag=NULLTAG;
							titemrevtag=((tag_t*) vector_get(ChildTagList,k));
							itemrevtag=*titemrevtag;						
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_id",&ChldPartNo));
							printf("\n Part Added in Set : %s",ChldPartNo);
						}				
						for(k=0;k<vcs[i].childCount;k++)
						{
							tag_t	itemrevtag	= NULLTAG;
							int		BLvl		= 0;
							char	*ChldPartNo = NULL;					
							itemrevtag=vcs[i].Children[k];
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_id",&ChldPartNo));
							printf("\n VC holder Part Added in Set : %s",ChldPartNo);					
						}
					}
					else
					{
						printf("\n No released revision found for this VC for further part part processing%s\n",VCNum);
						continue;		
					}
				}
				
				if(ChildTagList_cntGlobal>0)
				{
					for(i=0;i<ChildTagList_cntGlobal;i++)
					{
						int bc1=*((int *)vector_get(bom_counter,i));
						if(bc1>0)
						{
							tag_t	itemrevtag		= NULLTAG;
							int		BLvl			= 0;
							char	*ChldPartNo 	= NULL;					
							char	*Description	= NULL;					
							char	*PartType		= NULL;					
							char	*Revision 		= NULL;					
							char	*RevisionTk		= NULL;					
							int		Sequence		= 0;					
							int		countRet		= 0;					
							int		countRetD		= 0;					
							char	*ModDescription = NULL;					
							char	*PDesignGrp		= NULL;					
							char	*POwnerName		= NULL;					
							char	*PDRStat		= NULL;
							char	*KeyworkDesc	= NULL;
							tag_t 	*primary		= NULLTAG;			
							tag_t 	*primaryDML		= NULLTAG;			
							tag_t 	ItemTaskPr		= NULLTAG;			
							tag_t *titemrevtag=NULLTAG;
							titemrevtag=((tag_t*)vector_get(ChildTagListGlobal,i));
							itemrevtag=*titemrevtag;
							BLvl=*((int *)vector_get(bomLevel,i));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_id",&ChldPartNo));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_PartType",&PartType));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"object_desc",&Description));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_revision_id",&Revision));
							ITK_CALL(AOM_ask_value_int(itemrevtag,"sequence_id",&Sequence));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_DocRemarks",&ModDescription));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_DesignGrp",&PDesignGrp));
							ITK_CALL(AOM_UIF_ask_value(itemrevtag,"owning_user",&POwnerName));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_PartStatus",&PDRStat));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_CategoryName",&KeyworkDesc));
							//printf("\n Part Added in Global Set : %d %s",BLvl,ChldPartNo);
							char BOMLev[10];				
							sprintf(BOMLev, "%d",BLvl);
							char Seqnc[10];				
							sprintf(Seqnc, "%d",Sequence);
							tc_strcat(output,"\n");
							tc_strcat(output,BOMLev);
							tc_strcat(output,",'");
							tc_strcat(output,ChldPartNo);
							tc_strcat(output,",");
							tc_strcat(output,PartType);
							tc_strcat(output,",");
							tc_strcat(output,Description);
							tc_strcat(output,",");
							RevisionTk	= strtok (Revision,";");
							tc_strcat(output,RevisionTk);
							tc_strcat(output,",");
							tc_strcat(output,Seqnc);
							tc_strcat(output,",");
							tc_strcat(output,ModDescription);
							tc_strcat(output,",");
							tc_strcat(output,PDesignGrp);
							tc_strcat(output,",");
							tc_strcat(output,POwnerName);
							tc_strcat(output,",");
							tc_strcat(output,PDRStat);
							tc_strcat(output,",");
							tc_strcat(output,",");
							tc_strcat(output,",");
							tc_strcat(output,",");
							
							const char *relname="CMHasSolutionItem";
							const char *relnameDMLTask="T5_DMLTaskRelation";
							

							
							getRelationS2P(itemrevtag,&primary,relname,0,&countRet);
							if(countRet>0)
							{
								char*	ERCDMLTaskNo  = NULL;
								ItemTaskPr=primary[0];
								ITK_CALL(AOM_ask_value_string(ItemTaskPr,"item_id",&ERCDMLTaskNo));
								if(tc_strlen(ERCDMLTaskNo)==13)
								{
									getRelationS2P(ItemTaskPr,&primaryDML,relnameDMLTask,1,&countRetD);
									if(countRet>0)
									{
										tag_t 	ItemDML		= NULLTAG;	
										ItemDML=primaryDML[0];
										char	*DMLNumber	= NULL;
										char	*ReleaseDt	= NULL;
										char	*DMLDrStat	= NULL;
										char	*Synopsis	= NULL;
										char	*DPrjCode	= NULL;
										char	*RelType	= NULL;
										char	*Reason		= NULL;
										char	*WSO_Name	= NULL;
										tag_t	*ReleaseStat= NULLTAG;				
										int 	st_count	= 0;	
										char	*DCreator	= NULL;
										char	*AuthBy		= NULL;
										
										int     num  		= 0;     
										char**  DMLDesGroup = NULL;
										char 	DesGrpDML[5]	= "NA";

										ITK_CALL(AOM_ask_value_strings(ItemDML,"t5_crdesigngroup",&num,&DMLDesGroup)); 	
										if(num>0)
										{
											tc_strcpy(DesGrpDML,DMLDesGroup[0]);
										}
										ITK_CALL(AOM_ask_value_string(ItemDML,"item_id",&DMLNumber));
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"date_released",&ReleaseDt));
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"t5_cDRstatus",&DMLDrStat));
										ITK_CALL(AOM_ask_value_string(ItemDML,"object_name",&Synopsis));					
										ITK_CALL(AOM_ask_value_string(ItemDML,"t5_cprojectcode",&DPrjCode));					
										ITK_CALL(AOM_ask_value_string(ItemDML,"t5_rlstype",&RelType));					
										ITK_CALL(AOM_ask_value_string(ItemDML,"t5_reason",&Reason));					
										ITK_CALL(WSOM_ask_release_status_list(ItemDML,&st_count,&ReleaseStat));	
										ITK_CALL(AOM_ask_name(ReleaseStat[0],&WSO_Name));					
										ITK_CALL(AOM_ask_value_string(ItemDML,"requestor_user_id",&DCreator));					
										printf("\n DML found for task %s and creator %s",DMLNumber,DCreator);			
										
										tc_strcat(output,DMLNumber);
										tc_strcat(output,",");
										tc_strcat(output,ReleaseDt);
										tc_strcat(output,",");
										tc_strcat(output,DMLDrStat);
										tc_strcat(output,",");
										tc_strcat(output,Synopsis);
										tc_strcat(output,",");
										tc_strcat(output,DPrjCode);
										tc_strcat(output,",");
										tc_strcat(output,RelType);
										tc_strcat(output,",");
										tc_strcat(output,Reason);
										tc_strcat(output,",");
										tc_strcat(output,WSO_Name);
										tc_strcat(output,",");
										tc_strcat(output,DCreator);
										tc_strcat(output,",");
										
										char 		*respPartySm;	
										respPartySm=(char *) MEM_alloc(100 * sizeof(char *));
										tag_t		qryTagAPLWFSM			= NULLTAG;
										char		*ArgName2[1];
										char		*ArgVal2[1];
										tc_strcpy(respPartySm,"");			
										tc_strcat(respPartySm,DCreator);			
										if(QRY_find2("Admin - Employee Information", &qryTagAPLWFSM));
										if (qryTagAPLWFSM)
										{
											printf("\n Here:Found Query Admin - Employee Information.. \n");fflush(stdout);
										}
										else
										{
											printf("\n Here:Not Found Query Admin - Employee Information.. \n");fflush(stdout);
										}
										
										ArgName2[0] = "User ID";
										ArgVal2[0]  = respPartySm;	
										tag_t		user_tag				= NULLTAG;
										int 		resultsQryWFActSM		= 0;
										tag_t 		*ObjsWFActSM			= NULLTAG;
										if(QRY_execute(qryTagAPLWFSM, 1, ArgName2, ArgVal2, &resultsQryWFActSM, &ObjsWFActSM));
										if(resultsQryWFActSM>0)
										{
											char 		*username;		
											user_tag = ObjsWFActSM[0];
											ITK_CALL(AOM_ask_value_string(user_tag,"user_name",&username));
											printf("\n record found for user %s Name --> %s... ",respPartySm,username);fflush(stdout);
											tc_strcat(output,username);
											tc_strcat(output,",");
										}
										else
										{
											tc_strcat(output,",");
										}
										
										ITK_CALL(AOM_ask_value_string(ItemDML,"t5_authorisedby",&AuthBy));
										{
											resultsQryWFActSM		= 0;
											tc_strcpy(respPartySm,"");
											tc_strcat(respPartySm,AuthBy);
											ArgName2[0] = "User ID";
											ArgVal2[0]  = respPartySm;	
											if(QRY_execute(qryTagAPLWFSM, 1, ArgName2, ArgVal2, &resultsQryWFActSM, &ObjsWFActSM));
											{
												if(resultsQryWFActSM>0)
												{
													char 		*AuthName;	
													user_tag = ObjsWFActSM[0];
													
													ITK_CALL(AOM_ask_value_string(user_tag,"user_name",&AuthName));								
													printf("\n record found for user %s Name --> %s... ",respPartySm,AuthName);fflush(stdout);
													tc_strcat(output,AuthBy);							
													tc_strcat(output,",");							
													tc_strcat(output,AuthName);
													tc_strcat(output,",");										
												}
												else
												{
													tc_strcat(output,",,");
												}
											}
										}
										// For DMU Reviewer
										tc_strcat(output,",");
										
										tag_t	itemMstr;
										char	*PartFalimy = NULL;
										ITK_CALL(ITEM_ask_item_of_rev(itemrevtag,&itemMstr));
										//tag_t	itemMstrtag = itemMstr[0];
										ITK_CALL(AOM_ask_value_string(itemMstr,"t5_EngineType",&PartFalimy));	
										tc_strcat(output,DesGrpDML);				
										tc_strcat(output,",");		
										tc_strcat(output,KeyworkDesc);	
										tc_strcat(output,",");		
										tc_strcat(output,PartFalimy);	
										tc_strcat(output,",");	
										printf("\n VCs DML DesGrp	.....!!",DesGrpDML);
									}
									else
									{
										tc_strcat(output,",,,,,,,,,,,,,,,,");
									}
								}
								else
								{
									tc_strcat(output,",,,,,,,,,,,,,,,,");
								}				
							}
							else
							{
								tc_strcat(output,",,,,,,,,,,,,,,,,");
							}
							int k0 = 0;	
							char BOMCntrC[10];	
							sprintf(BOMCntrC, "%d", bom_counter[i]);
							tc_strcat(output,BOMCntrC);
							tc_strcat(output,",");
							//For BOM CHANGE Logic
							tc_strcat(output,",");
							for(k0=0;k0<VCSet_cnt;k0++)
							{
								int found = 0;
								printf("\n Here in Code for part search logic .....!!");
								setFindTag(vcs[k0].Children,vcs[k0].childCount,itemrevtag,&found);					
								if(found>=0)
								{					
									tc_strcat(output,"Y,");				
								}
								else
								{
									tc_strcat(output,"N,");		
								}
							}
							tag_t *latestdml=NULLTAG;
							tag_t *latestPart=NULLTAG;
							vector_t *alldmllist=NULLTAG;
							vector_t *allpartlist=NULLTAG;
							tag_t prevrevpartObj;
							int allpart_dml_cnt=0;
							int total_cnt1=0;
							 getAllReleasedPartDML(query,ChldPartNo,"Design Revision", latestdml,latestPart,&prevrevpartObj,&alldmllist,&allpartlist,&allpart_dml_cnt,FrmDt,ToDt,&total_cnt1);

						}
					}				
				}
				else
				{
					printf("\n No Global VCs child/part set found.....!!\n\n");
				}
			}
			else
			{
				printf("\n No VCs Selected for report.....!!\n\n");
			}
			printf("\n End of program.....!!\n\n");
			
			//printf("\n Final Output == %s.....!!\n\n",output);
			
			//output = "NULL";
			
			*((char **) return_data) = 
			   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output); 
			
			return ifail;
			/* Program Logic End*/
		}




		int GatewayRptFuncsvr( void *return_data ) //tag_t pltfrm, tag_t* svrObj,int n_objects,char *clos_rule,char *revrule,char *FrmDateF,char *ToDateF,char* OutPutLoc,int bomdepth)
		{
			int status;
			int				ifail 						= ITK_ok;
			FILE*   fpbomsolve=NULL;
			printf("\n I am in main program");fflush(stdout);
			char 			*output 			= NULL;
			char			*FrmDt					= NULL;
			char			*ToDt					= NULL;
			char			*VCData					= NULL;
			char			*VCCtnt					= NULL;
			int				VCAttrName_cnt			= 0;
			vector_t 		*VCAttrName	=vector_new(1,1);
			char* 			Reason1=NULL;
			char* 			Reason2=NULL;
			
			tag_t 	ItemDML		= NULLTAG;	
										
			char	*DMLNumber	= NULL;
			char	*ReleaseDt	= NULL;
			char	*DMLDrStat	= NULL;
			char	*Synopsis	= NULL;
			char	*DPrjCode	= NULL;
			char	*RelType	= NULL;
			char	*Reason		= NULL;
			char	*WSO_Name	= NULL;
			tag_t	*ReleaseStat= NULLTAG;				
			int 	st_count	= 0;	
			char	*DCreator	= NULL;
			char	*AuthBy		= NULL;
										
			int     num  		= 0;     
			char**  DMLDesGroup = NULL;
										
			
			tag_t relType = NULLTAG;
			tag_t relTypeDMLTask = NULLTAG;
			const char *filter="T5_ChangeTaskRevision";
			
			int rl;
			int relstatno;
			char **relstatval=NULL;
			
			
			int				VCAttrVal_cnt			= 0;
			vector_t 			*VCAttrVal	=vector_new(1,1);
			
			int  			VCSet_cnt		= 0;
			vector_t 			*VCSet	=vector_new(1,1);
			
			int  			VCRevSet_cnt		= 0;
			vector_t 			*VCRevSet=	vector_new(1,1);
			int SVRVCObjs_cnt=0;
			vector_t *SVRVCObjs=vector_new(1,1);
			char BOMCntrC[10];
				
			int 			AddFlg			= 0;
			int 			i,i1			= 0;
			char			bomsolveFileName[200];
			/* Output File Creation Start*/
			char 	Data[100]			= "";
			char 	CurrDate[100]		= "";
			char	OutputFile[200]		= "";
			time_t 	now;
			struct 	tm	when;
			BOMHolder *vcs;
			char*	ERCDMLTaskNo  = NULL;
			char 	DesGrpDML[5]	= "NA";
			tag_t latestdml=NULLTAG;
			tag_t latestPart=NULLTAG;
			tag_t *alldmllist=NULLTAG;
			tag_t *allpartlist=NULLTAG;
			int allpart_dml_cnt=0;
			int total_cnt1=0;
							
							
			tag_t	itemrevtag		= NULLTAG;
			int		BLvl			= 0;
			char	*ChldPartNo 	= NULL;					
			char	*Description	= NULL;					
			char	*PartType		= NULL;					
			char	*Revision 		= NULL;					
			char	*RevisionTk		= NULL;					
			int		Sequence		= 0;					
			int		countRet		= 0;					
			int		countRetD		= 0;					
			char	*ModDescription = NULL;					
			char	*PDesignGrp		= NULL;					
			char	*POwnerName		= NULL;					
			char	*PDRStat		= NULL;
			char	*KeyworkDesc	= NULL;
			tag_t 	*primary		= NULLTAG;			
			tag_t 	*primaryDML		= NULLTAG;			
			tag_t 	ItemTaskPr		= NULLTAG;
			tag_t   POwnerNametag   = NULLTAG;
			char*   ModDescription1=NULL;
			char*   ModDescription2=NULL;
			char* Description1=NULL;
			char* Description2=NULL;
			char* Synopsis2=NULL;
			char Seqnc[10];	
			char BOMLev[10];
							
			const char *relname="CMHasSolutionItem";
			const char *relnameDMLTask="T5_DMLTaskRelation";
			const char *relCMRef="CMReferences";
							
			tag_t *gmtasklist=NULL;
			int gmtaskcount=0;
			tag_t *gmdmllist=NULL;
			int gmdmlcount=0;
							
			char* KeyworkDesc1=NULL;
			char* KeyworkDesc2=NULL;
							
			tag_t relGMType=NULLTAG;
			tag_t* globChild = NULL;
							
			int 	x = 0;
			tag_t rule = NULLTAG;
			tag_t close_tag = NULLTAG;
			tag_t bom_window = NULLTAG;
			tag_t bom_variant_rule = NULLTAG;
			tag_t *bom_variant_rule1 = NULLTAG;
			int bomVar = 0;
			tag_t top_line = NULLTAG;
			tag_t* closurerule = NULL;
			tag_t query=NULLTAG;
			vector_t *part_dml_vec =	vector_new(1,1);
			int   part_dml_count=0;
			vector_t *childRevStrList =	vector_new(1,1);
			
			vector_t *global_bom_flag =	vector_new(1,1);
		
			output = (char *) MEM_alloc( 1 * sizeof(char) );
			FrmDt= (char *) MEM_alloc( 50 * sizeof(char) );	
			ToDt= (char *) MEM_alloc( 50 * sizeof(char) );	
			
			
			time(&now);
			when = *localtime(&now);
			
			strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
			strftime(CurrDate,100,"%d-%m-%Y",&when);
			
			
			sprintf(OutputFile,"/tmp/GateWayReport_%s.csv",Data);
			sprintf(bomsolveFileName,"/tmp/GateWayReportBOMSolve_%s.csv",Data);			
			fpbomsolve=fopen(bomsolveFileName,"w");
			
			/*************VC Attribute Name ************************/
			
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]MAJORMODEL"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]VEH_APPLN(VEH_APPLN)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Emission Norms"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Fuel"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("VEHICLE_CLASS"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]MASCOT"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]Wheel Base(WHEEL_BASE_IN_MM)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Other Features"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("BI FUEL ENGINE/MOTOR POWER (KW)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("LOAD_BODY_TYPE"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("[VC]Seating Capacity(SEATING_CAP)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("PSG_CAPECITY"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("VAHAN SEATING CAPACITY (INCLUDING DRIVER)"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("CH_CAB_LB_SW_TO"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Project_Date"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("SOP_Target"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Part_Status"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Directive"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Country"));
			VCAttrName=vector_add(VCAttrName,MEM_string_copy("Vehicle"));
			
			/*************VC Attribute Name ************************/
							
			
			
			
			ITK_CALL(GRM_find_relation_type(relname,&relType));	
			ITK_CALL(GRM_find_relation_type(relnameDMLTask,&relTypeDMLTask));
			ITK_CALL(GRM_find_relation_type(relCMRef,&relGMType));		
			
			//char 			*FrmDateF			= 	NULL;
			//char 			*ToDateF			= 	NULL;
			

			
			//int n_objects = 0;
		  //  tag_t *objects = NULL;
			
			
			//tag_t pltfrm = NULLTAG;
			
			//tag_t *svrObj = NULL;
			//char *revrule=NULL;
			//char *clos_rule=NULL;
			
			/*
			USERARG_get_tag_argument(&pltfrm);
			USERARG_get_tag_array_argument(&n_objects, &svrObj); 
			USERARG_get_string_argument(&revrule);
			USERARG_get_string_argument(&clos_rule);
			USERARG_get_string_argument(&FrmDateF);
			USERARG_get_string_argument(&ToDateF);
			USERARG_get_string_argument(&OutPutLoc);
			*/
			
			
			int n_objects = 0;
		  tag_t *objects = NULL;
			tag_t pltfrm = NULLTAG;
			tag_t *svrObj = NULL;
			char *revrule=NULL;
			char *clos_rule=NULL;
      char 			*FrmDateF			= 	NULL;
	    char 			*ToDateF			= 	NULL;      
      int bomdepth;    
			
			
			USERARG_get_tag_argument(&pltfrm);
			USERARG_get_tag_array_argument(&n_objects, &svrObj); 
			USERARG_get_string_argument(&revrule);
			USERARG_get_string_argument(&clos_rule);
			USERARG_get_string_argument(&FrmDateF);
			USERARG_get_string_argument(&ToDateF);
			USERARG_get_int_argument(&bomdepth);
			
			printf("\n number of SVR Object [%d]",n_objects);fflush(stdout);
			printf("\n1 %s %s",FrmDateF,ToDateF);fflush(stdout);	
			
		//	FrmDt			= strtok (FrmDateF," ");
		//	ToDt  			= strtok (ToDateF," ");	
			
			tc_strcpy(FrmDt,FrmDateF);
			tc_strcpy(ToDt,ToDateF);

		char 		*respPartySm;	
		respPartySm=(char *) MEM_alloc(100 * sizeof(char *));
		//	printf("\n Recieved Args ~ Output Location := %s , VC Data =:= %s, VC Count := %s, From Date := %s, To Date:= %s",OutPutLoc,VCData,VCCtnt,FrmDt,ToDt);
			
			
				
		printf("\n1");fflush(stdout);	
		ITK_CALL(CFM_find( revrule, &rule ));
				if(rule==NULLTAG)
				{
				printf("\n2");fflush(stdout);
				ITK_CALL(CFM_find( "ERC release and above", &rule ));
				}
				
		printf("\n1");fflush(stdout);	
				int rulefound = 0;
				
				ITK_CALL(PIE_find_closure_rules2( clos_rule,PIE_TEAMCENTER, &rulefound, &closurerule ));
				if(closurerule==NULL)
				ITK_CALL(PIE_find_closure_rules2( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule ));
				
				printf ("rule count %d \n",rulefound);fflush(stdout);
					if (rulefound > 0)
					{
						close_tag = closurerule[0];
						printf ("closure rule found \n");fflush(stdout);
						// MEM_free(tags_found);
					}
					
		ITK_CALL(QRY_find2("Item Revision...", &query));	
		printf("\n1");fflush(stdout);	
		char svr_input[500];
		char *VCNum = NULL;
					
					VCNum=(char *) MEM_alloc(100 * sizeof(char *));
		char *VCNum1 = NULL;	
		VCNum1=(char *) MEM_alloc(100 * sizeof(char *));
		tc_strcpy(svr_input,"");
			for(x=0;x<n_objects;x++)
			{
				char* 		vehNo 	= NULL;
				char* 		svr_no 	= NULL;
		   char* veh_rev=NULL;
		printf("\n2");fflush(stdout);	
				ITK_CALL(AOM_ask_value_string(svrObj[x],"object_name",&svr_no));
				printf("\n svr_no=%s",svr_no);fflush(stdout);
				tc_strcat(svr_input,svr_no);
				tc_strcat(svr_input,",");
				vehNo=strtok (svr_no,"_");
				veh_rev=strtok (NULL,"_");
				VCSet=vector_add(VCSet,MEM_string_copy(vehNo));
				VCRevSet=vector_add(VCRevSet,MEM_string_copy(veh_rev));
			}
			char bmdepth[4];
			sprintf(bmdepth,"%d",bomdepth);
			char* platformno=NULL;
			ITK_CALL(AOM_ask_value_string(pltfrm,"item_id",&platformno));
			tc_strcpy(output,"");	
			autoresizestrcat(&output,"\n,,,GATEWAY REPORT,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\n,,,******************,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\n,,,PlatForm  :");
			autoresizestrcat(&output,platformno);
			autoresizestrcat(&output,"\n,,,SVRS  :");
			autoresizestrcat(&output,svr_input);
			autoresizestrcat(&output,"\n,,,Date of report  :");
			autoresizestrcat(&output,CurrDate);
			autoresizestrcat(&output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\n,,,From Date  :");
			autoresizestrcat(&output,FrmDt);
			autoresizestrcat(&output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\n,,,To Date  :");
			autoresizestrcat(&output,ToDt);
			autoresizestrcat(&output,"\n,,,Expand Depth  :");
			autoresizestrcat(&output,bmdepth);
			autoresizestrcat(&output,",,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\nVC NO,MAJOR_MODEL,VEH_APPLN,EMISSION_NORMS,FUEL,VEH_CLASS,MASCOT,WHEEL_BASE,OTHER,ENGINE_MODEL,LOAD_BODY_TYPE,SEATS,PSG_CAPACITY,SEAT_CAPACITY,CAB BODY,Project_Date,SOP_Target,Part_Status,Directive,Country,Vehicle,,,,,,,,,,");
			//autoresizestrcat(&output,"\nVehicle,1,17,36,37,52,66,68,104,15,177,23,35,70,8,Planned Release Date,Planned Effective Date,Vehicle's DR status,Dir Reg,Country of Export,Hlg Veh Type,,,,,,,,,,");
			autoresizestrcat(&output,"\n********************,********************,**************,  **************, ********************,*********************,*****************,************************,***************,********************,********************,*****************,*******************,*******************,****************,***************,***************,*******************,****************,***************,***************,,,,,,,,,,");
			VCSet_cnt=vector_size(VCSet);
			if(VCSet_cnt>0)
			{
				for (i1=0;i1<VCSet_cnt ;i1++)
				{
					//char *VCNum1 = NULL;
					char			*object_type1			= "Design Revision"; //change to Design Revision
					
					tc_strcpy(VCNum1 , (char*)vector_get(VCSet,i1));
					tag_t	partObj1 						= NULLTAG;
					char* 	vehicleNumber1 					= NULL;
					char* 	PDRStat1 						= NULL;
					int 			nAttributes				= 0;
					char 			**attributeNames;
					char 			**attributeValues;
					int				ii						= 0;
					int				total_Count				= 0;
					tag_t			classificationObject;
					tag_t			cObject					= NULLTAG;	
					char* 			vehNo 					= NULL;
					char *			svr_no				=NULL;
					char *			veh_rev				=NULL;	
					int 			svrpartcnt=0;
					tag_t* 			svrpartObj=NULLTAG;
					//char* vehicleNumber 	= NULL;
					char* derived_vc 	= NULL;
					ITK_CALL(AOM_ask_value_tags(svrObj[i1],"T5_SVRDerivesCCV",&svrpartcnt ,&svrpartObj));	
					if(svrpartcnt>0)
						partObj1=svrpartObj[0];
					/*
					ITK_CALL(AOM_ask_value_string(svrObj[i1],"object_name",&svr_no));
					ITK_CALL(AOM_UIF_ask_value(partObj1,"object_string",&derived_vc));
					ITK_CALL(AOM_ask_value_string(partObj1,"item_id",&vehNo));
					ITK_CALL(AOM_ask_value_string(partObj1,"item_revision_id",&veh_rev));*/
					//vehNo=strtok (svr_no,"_");
					//veh_rev=strtok (NULL,"_");
					//ITK_CALL(getLatestReleasedPartSVR(vehNo,veh_rev,object_type1, &partObj1,FrmDt,ToDt,&total_Count));
					
					//partObj1 = objects[i1];
					if(partObj1==NULLTAG)
					{	
				
						ITK_CALL(AOM_ask_value_string(svrObj[i1],"object_name",&svr_no));
						
						autoresizestrcat(&output,"\n");
						autoresizestrcat(&output,svr_no);
						autoresizestrcat(&output,",");
						autoresizestrcat(&output,"Not Released From ERC");
						printf("\n No released revision found for this VC %s\n",svr_no);
						tag_t *tpartObj1=(tag_t *)MEM_alloc( sizeof ( tag_t ) );
						 *tpartObj1= svrObj[i1];
						SVRVCObjs=vector_add(SVRVCObjs,tpartObj1);				
					}
					else
					{
					ITK_CALL(AOM_ask_value_string(svrObj[i1],"object_name",&svr_no));
					ITK_CALL(AOM_UIF_ask_value(partObj1,"object_string",&derived_vc));
					ITK_CALL(AOM_ask_value_string(partObj1,"item_id",&vehNo));
					ITK_CALL(AOM_ask_value_string(partObj1,"item_revision_id",&veh_rev));
						
						tag_t *tpartObj1=(tag_t *)MEM_alloc( sizeof ( tag_t ) );
						 *tpartObj1= partObj1;
						SVRVCObjs=vector_add(SVRVCObjs,tpartObj1);
					//}
					tag_t VehPartMaster=NULLTAG;
					ITK_CALL(ITEM_ask_item_of_rev(partObj1, &VehPartMaster)); 
					ITK_CALL(AOM_ask_value_string(partObj1,"item_id",&vehicleNumber1));
					ITK_CALL(AOM_ask_value_string(partObj1,"t5_PartStatus",&PDRStat1));
					ITK_CALL(ICS_ask_classification_object(VehPartMaster,&classificationObject));
					ITK_CALL(ICS_ask_attributes_of_classification_obj(classificationObject,&nAttributes, &attributeNames, &attributeValues));
					printf("### ICS_ask_attributes_of_classification_obj nAttributes = %d\n", nAttributes);
					autoresizestrcat(&output,"\n");
					autoresizestrcat(&output,derived_vc);
					autoresizestrcat(&output,",");
					char			**AttrVals            = NULL;
					int 			i2					  = 0;
					VCAttrName_cnt=vector_size(VCAttrName);
					AttrVals = (char **)MEM_alloc(VCAttrName_cnt  * sizeof(char *));
				
					for(i2=0;i2<VCAttrName_cnt;i2++)
					{
					
					AttrVals[i2] = MEM_alloc(100 * sizeof(char));
					tc_strcpy(AttrVals[i2],"NA");
					}
				
					for(ii = 0; ii < nAttributes; ii++)
					{
						//printf("\t%s - %s\n", attributeNames[ii], attributeValues[ii]);
						int AttrFound = 0;
						vector_find_str(VCAttrName,attributeNames[ii],&AttrFound);
						//printf("\n Found Val for AttrFound = %d",AttrFound);fflush(stdout);
						if(AttrFound>=0)
						{					
							if(attributeValues[ii]!=NULL || attributeValues[ii]!="")
							{												
								//printf("\t~~%s - %s\n", attributeNames[ii], attributeValues[ii]);
								tc_strcpy(AttrVals[AttrFound],attributeValues[ii]);
							}					
						}
					}
					MEM_free(attributeNames);
					MEM_free(attributeValues);  
					
					for(ii = 0; ii<VCAttrName_cnt; ii++)
					{	
						//printf("\n Found vals AttrVals[ii] = %s",AttrVals[ii]);fflush(stdout);
						autoresizestrcat(&output,AttrVals[ii]);
						autoresizestrcat(&output,",");
						MEM_free(AttrVals[ii]);
					}
					MEM_free(AttrVals);
					//MEM_free(classificationObject);
					//MEM_free(VCNum1);
				}
			}
			}
			
			autoresizestrcat(&output,"\n,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\n********************,**************,**************,**************,**************,*******************************************************************************************************************************************,*********************,*****************,************************,***************,********************,********************,*****************,*******************,*******************,****************,***************,***************,*******************,****************,***************,***************,***************,,,,,,,,,,");
			autoresizestrcat(&output,"\n,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
			autoresizestrcat(&output,"\nLevel,PART NUMBER,PART TYPE,DESC,REVISION,SEQ, MODFN DESCRIPTION,DESIGN GRP,OWNERNAME,Part DR Status,DML DR Status,Gate Maturation DML, Gate Maturation ClosureDate,DML NO,DML RLS DATE,DML DR Status,SYNOPSIS,DML PROJECT,RELEASE TYPE,REASON, LIFECYCLESTATE, DML CREATOR,CREATOR NAME,AUTHORISED BY,AUTHOR NAME,DMU REVIEWER ,DML AGGR,KEYWORD DESC,PART FAMILY,Counter,REV CHANGE,BOM CHANGE,");
			for (i=0;i<VCSet_cnt ;i++)
			{
				autoresizestrcat(&output,(char*)vector_get(VCSet,i));
				autoresizestrcat(&output,",");
			}
			autoresizestrcat(&output,"\n********************,********************,********************,********************,*************************************,**************, **************, **************,  **************************************,*********************,*****************,*******************,************************,,*******************,************************,***************,******************************,********************,*****************,*******************,*******************,****************,****************,****************,****************,****************,****************,****************,****************,****************,");
			for (i=0;i<VCSet_cnt ;i++)
			{
				autoresizestrcat(&output,"***************,");
			}
			
			if(VCSet_cnt>0)
			{
				
				vcs =(BOMHolder *) MEM_alloc(sizeof(BOMHolder)*VCSet_cnt);
				vector_t *ChildTagListGlobal 	 =	vector_new(1,1);
				
				int 	ChildTagList_cntGlobal 	= 0;
				int	  	BomLvl_cnt				= 0;
				vector_t *bomLevel		 =	vector_new(1,1);
				vector_t *bom_counter =	vector_new(1,1);
				
				for (i=0;i<VCSet_cnt ;i++)
				{		
					
					tc_strcpy(VCNum ,(char*)vector_get(VCSet,i));
					char	*object_type 	= "Design Revision"; //change to Design Revision
					tag_t	partObj 		= NULLTAG;
					tag_t	top_line		= NULLTAG;
					tag_t	window			= NULLTAG;
					//tag_t	rule			= NULLTAG;
					tag_t	item_tag 		= null_tag;
					int 	n_bom_views     = 0;
					int 	total_Count     = 0;
					tag_t 	*bom_views      = NULL;
					printf("\n Processing VC String (%d,%s)",i,(char*)vector_get(VCSet,i));fflush(stdout);	
		printf("\n BEF");fflush(stdout);
								
					//ITK_CALL(getLatestReleasedPart(query,VCNum,object_type, &partObj,FrmDt,ToDt,&total_Count));
					printf("\n AFTER");fflush(stdout);
					
					tag_t *tpartObj=NULLTAG;
					tpartObj=((tag_t*)vector_get(SVRVCObjs,i));			
					partObj=*tpartObj;
					if(partObj!=NULLTAG)
					{				
						printf("\n Tag returned from function..\n");
						tag_t VehMaster 		= NULLTAG;
						tag_t *bom_views        = NULL;
						
						char *view_type_name    = NULL;
						vector_t *ChildTagList =	vector_new(1,1);
						
						
						int	  ChildTagList_cnt,k= 0;		
						tag_t view_type 		= NULLTAG;		
						tag_t erc_view 			= NULLTAG;
						tag_t apl_view 			= NULLTAG;
						tag_t dfma_view 		= NULLTAG;
						tag_t objTypeTag=NULLTAG;
						char *vehicleNumber=NULL;
						char *type_name1=NULL;
						
						ITK_CALL(TCTYPE_ask_object_type(partObj,&objTypeTag));
						ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name1));

						if(strcmp(type_name1,"Design Revision")==0)
						{
						ITK_CALL(AOM_ask_value_string(partObj,"item_id",&vehicleNumber));
						}
						else
						{
						ITK_CALL(AOM_ask_value_string(partObj,"object_name",&vehicleNumber));
						}
						printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);	
						/*ITK_CALL(ITEM_ask_item_of_rev(partObj, &VehMaster)); // Get the Item from the revision
						ITK_CALL(ITEM_list_bom_views(VehMaster, &n_bom_views, &bom_views )); //Get the bom views
						ITK_CALL(AOM_ask_value_string(partObj,"item_id",&vehicleNumber));
						printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);		
						
						ifail = BOM_create_window (&window);
						CHECK_FAIL;
						ifail = CFM_find( "Latest Working", &rule );
						CHECK_FAIL;
						ifail = BOM_set_window_config_rule( window, rule );
						CHECK_FAIL;
						ifail = BOM_set_window_pack_all (window, true);
						CHECK_FAIL;
						
						ifail = BOM_set_window_top_line (window, VehMaster, partObj, NULLTAG, &top_line);
						CHECK_FAIL;
						*/
						
						
						///SET UP SVR

						
						
						ITK_CALL(BOM_create_window (&bom_window)); 
						ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, pltfrm, NULLTAG, &top_line));
						ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
						ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
						ITK_CALL( BOM_window_ask_variant_rules( bom_window, &bomVar,&bom_variant_rule1 ));

						bom_variant_rule = bom_variant_rule1[0];
								
								if(bom_variant_rule==NULLTAG)
								{
									printf("\n  bom_variant_rule==NULLTAG");fflush(stdout);

								} 
								else 
								{
									printf("\n  bom_variant_rule NOT NULLTAG");fflush(stdout);
								}
								
								
								printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);
								
								
								tag_t varrule_tags[]={svrObj[i]};
								char *svr_name=NULL;
								ITK_CALL(AOM_ask_value_string(svrObj[i],"object_name",&svr_name));
								TC_write_syslog("\n SVR APPLY: %s\n", svr_name);
								ITK_CALL(BOM_window_hide_variants (bom_window));
								ITK_CALL(BOM_window_hide_unconfigured(bom_window));
								ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
								ITK_CALL(BOM_window_hide_variants (bom_window));
								ITK_CALL(BOM_window_hide_unconfigured(bom_window));
								
								
								
						//END SVR
						
						
						
						//childRevStrList=NULL;
						//ChildTagList = NULLTAG;
						//vector_free(ChildTagList);
						//ChildTagList=	vector_new(1,1);
						ChildTagList_cnt = 0;
						//bom_counter  = 0;
						printBom(query,bomdepth,top_line, -1,&ChildTagListGlobal,&ChildTagList_cntGlobal,&ChildTagList,&ChildTagList_cnt,&BomLvl_cnt,&bomLevel,&bom_counter,FrmDt,ToDt,&part_dml_vec,&part_dml_count,&childRevStrList,rule,&global_bom_flag);
						//tag_t* childtaglist=NULLTAG;
						//copyObjTAG(ChildTagList_cnt,ChildTagList,&childtaglist);
						//printBomSVR(platform,svr_obj,rev_rule,_close_tag, -1,&ChildTagListGlobal,&ChildTagList_cntGlobal,&ChildTagList,&ChildTagList_cnt,&BomLvl_cnt,&bomLevel,&bom_counter,FrmDt,ToDt);
						tc_strcpy(vcs[i].VC,vehicleNumber);
						vcs[i].childCount=ChildTagList->size;
						vcs[i].Children=(tag_t *)MEM_alloc( (ChildTagList->size)*sizeof ( tag_t ));
						
						//memcpy(vcs[i].Children,ChildTagList->content,vector_size(ChildTagList)*sizeof((tag_t *)ChildTagList->content));	
						//vcs[i].childRevModList=childRevStrList;
						vcs[i].counter=(int *)MEM_alloc( (bom_counter->size)*sizeof ( int ));
						//memcpy(vcs[i].counter,bom_counter->content,vector_size(bom_counter)*sizeof((int *)bom_counter->content));
						ChildTagList_cnt=vector_size(ChildTagList);
						printf("\n &vcs[i].Children==%u vcs[i].Children==%u vcs[i].Children[0]==%u &vcs[i].Children[0]==%u ",&vcs[i].Children,vcs[i].Children,vcs[i].Children[0], &vcs[i].Children[0]);fflush(stdout);
						
						printf("\n Part-Name sizeSet : %d",ChildTagList_cnt);fflush(stdout);
						
						
						for(k=0;k<ChildTagList_cnt;k++)
						{
							tag_t	itemrevtag1	= NULLTAG;
							int		BLvl		= 0;
							char	*ChldPartNo = NULL;	
							int *bomcn;
							bomcn=((int*)vector_get(bom_counter,k));						
							tag_t *titemrevtag=NULLTAG;
							titemrevtag=((tag_t*)vector_get(ChildTagList,k));	
							itemrevtag1=*titemrevtag;
							//printObject(itemrevtag1);
								if(itemrevtag1==NULLTAG)
									{		
									 printf("\n Part-Name NULLLTAGs");fflush(stdout);
										continue;	
									}
									vcs[i].Children[k]=*titemrevtag;
									vcs[i].counter[k]=*bomcn;
							char* ChldPartName=NULL;				
							ITK_CALL(AOM_ask_value_string(itemrevtag1,"object_name",&ChldPartName));
							
							printf("\n Part-Name Added in Set : %s",ChldPartName);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(itemrevtag1,"item_id",&ChldPartNo));
							printf("\n Part Added in Set : %s",ChldPartNo);
						}	
					
						printf("\n Going to print VCHolder Set");fflush(stdout);
						for(k=0;k<vcs[i].childCount;k++)
						{
							tag_t	itemrevtag1	= NULLTAG;
							int		BLvl		= 0;
							char	*ChldPartNo = NULL;					
							itemrevtag1=vcs[i].Children[k];
							if(itemrevtag1==NULLTAG)
																{
																 printf("\n Part-Name NULLLTAGs1");fflush(stdout);
																		continue;
																}
							ITK_CALL(AOM_ask_value_string(itemrevtag1,"item_id",&ChldPartNo));
							printf("\n VC holder Part Added in Set : %s",ChldPartNo);					
						}
						
						vector_free(ChildTagList);
					}
					else
					{
						printf("\n No released revision found for this VC for further part part processing%s\n",VCNum);
						continue;		
					}
					if(bom_window!=NULLTAG)
					{
					ITK_CALL(BOM_close_window(bom_window));
					bom_window=NULLTAG;
					}
				}
				

		for (i=0;i<VCSet_cnt ;i++)
						{
		int k;
		fprintf(fpbomsolve,"\n%s",vcs[i].VC);fflush(fpbomsolve);
		for(k=0;k<vcs[i].childCount;k++)
										{
												tag_t   itemrevtag1      = NULLTAG;
												int             BLvl            = 0;
												char    *ChldPartNo = NULL;
												itemrevtag1=vcs[i].Children[k];
							BLvl=vcs[i].counter[k];
												if(itemrevtag1==NULLTAG)
																{
																 printf("\n Part-Name NULLLTAGs1");fflush(stdout);
																		continue;
																}
												ITK_CALL(AOM_ask_value_string(itemrevtag1,"object_string",&ChldPartNo));
												
												fprintf(fpbomsolve,"\n%s,%s",vcs[i].VC,ChldPartNo);fflush(fpbomsolve);
												
												printf("\nXXXX VC holder Part Added in Set : %s BOMCntr==%d",ChldPartNo,BLvl);
										}
		}

		fclose(fpbomsolve);
	ChildTagList_cntGlobal=vector_size(ChildTagListGlobal);
			 if(ChildTagList_cntGlobal>0)
						{
								for(i=0;i<ChildTagList_cntGlobal;i++)
								{
						tag_t *titemrevtag=NULLTAG;
						titemrevtag=((tag_t*)vector_get(ChildTagListGlobal,i));
						tag_t itemrevtag1=*titemrevtag;
							char* ChldPartNo=NULL;
							int *tp1;
							tp1=((int*)vector_get(bom_counter,i));
							int p1=*tp1;
												ITK_CALL(AOM_ask_value_string(itemrevtag1,"item_id",&ChldPartNo));
														printf("\n Global Part No item_id==%s BOM CO==%d",ChldPartNo,p1);fflush(stdout);

					}

		}

				

				if(ChildTagList_cntGlobal>0)
				{
					for(i=0;i<ChildTagList_cntGlobal;i++)
					{
						int *tbc1;
						tbc1=((int*)vector_get(bom_counter,i));
						int bc1=*tbc1;
						if(bc1>0)
						{
							
								
							tag_t *titemrevtag=NULLTAG;
							titemrevtag=((tag_t*)vector_get(ChildTagListGlobal,i));
							itemrevtag=*titemrevtag;
							int *tBLvl;
							tBLvl=((int*)vector_get(bomLevel,i));//bomLevel[i];
							BLvl=*tBLvl;
							
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_id",&ChldPartNo));
							//ITK_CALL(getAllReleasedPartDML(query,ChldPartNo,"Design Revision", &latestdml,&latestPart,&alldmllist,&allpartlist,&allpart_dml_cnt,FrmDt,ToDt,&total_cnt1));
							 printf("\n After getAllReleasedPartDML==%d",allpart_dml_cnt);fflush(stdout);
								printf("\n DML ID Part No item_id==%s",ChldPartNo);fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(itemrevtag,"t5_PartType",&PartType));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"object_desc",&Description));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"item_revision_id",&Revision));
							ITK_CALL(AOM_ask_value_int(itemrevtag,"sequence_id",&Sequence));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_DocRemarks",&ModDescription));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_DesignGrp",&PDesignGrp));
							
						//	ITK_CALL(AOM_ask_value_tag(itemrevtag,"owning_user",&POwnerNametag));
						//	ITK_CALL(AOM_ask_value_string(POwnerNametag,"user_name",&POwnerName));
							(AOM_UIF_ask_value(itemrevtag,"owning_user",&POwnerName));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_PartStatus",&PDRStat));
							ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_CategoryName",&KeyworkDesc));
							//printf("\n Part Added in Global Set : %d %s",BLvl,ChldPartNo);
											
							sprintf(BOMLev, "%d",BLvl);
									
								
																	   /* STRNG_replace_str(ModDescription,",",";",&ModDescription1);
																		STRNG_replace_str(ModDescription1,"\n",";",&ModDescription2);

							
																		STRNG_replace_str(Description,",",";",&Description1);
																		STRNG_replace_str(Description1,"\n",";",&Description2);	
																		*/
																		
																		stripChar(ModDescription,&ModDescription2);
																		stripChar(Description,&Description2);
							sprintf(Seqnc, "%d",Sequence);
							autoresizestrcat(&output,"\n");
							autoresizestrcat(&output,BOMLev);
							autoresizestrcat(&output,",'");
							autoresizestrcat(&output,ChldPartNo);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,PartType);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,Description2);
							autoresizestrcat(&output,",");
							RevisionTk	= strtok (Revision,";");
							autoresizestrcat(&output,RevisionTk);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,Seqnc);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,ModDescription2);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,PDesignGrp);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,POwnerName);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,PDRStat);
							autoresizestrcat(&output,",");
							
							
							
							
							//

							

							//countRet=1;
						//	ITK_CALL(getRelationS2P(itemrevtag,&primary,relname,0,&countRet));
						
						//	tag_t relType = NULLTAG;
			//tag_t* primary_objects = NULL;
			
		//filter =T5_ChangeTaskRevision	
		tag_t gmdmlobj=NULLTAG;
		getGateMaturationDML( query,ChldPartNo,"Design Revision",relGMType,relTypeDMLTask,&gmdmlobj);

				if(gmdmlobj!=NULLTAG)
				{
					char *gmdmlno=NULL;
					char *gmdmlreldate=NULL;
					char *gmdmldrstatus=NULL;
				ITK_CALL(AOM_ask_value_string(gmdmlobj,"item_id",&gmdmlno));
				ITK_CALL(AOM_UIF_ask_value(gmdmlobj,"date_released",&gmdmlreldate));
				ITK_CALL(AOM_UIF_ask_value(gmdmlobj,"t5_cDRstatus",&gmdmldrstatus));
				
				autoresizestrcat(&output,gmdmldrstatus);
				autoresizestrcat(&output,",");
				
				autoresizestrcat(&output,gmdmlno);
				autoresizestrcat(&output,",");
				
				autoresizestrcat(&output,gmdmlreldate);
				autoresizestrcat(&output,",");
				
			
				}
				else{
					
					autoresizestrcat(&output,",");
					autoresizestrcat(&output,",");
					autoresizestrcat(&output,",");
				}
				//printf("\n DML attaced in part count=%d \n",*countRet);fflush(stdout);
				
		

			if( relType != NULLTAG )
			{
			
				ITK_CALL(GRM_list_primary_objects_only(itemrevtag,relType,&countRet,&primary));
		//	ITK_CALL(GRM_list_primary_objects_with_primary_object_type_only(itemrevtag,relType,"T5_ChangeTaskRevision",&countRet,&primary));
				//printf("\n DML attaced in part count=%d \n",*countRet);fflush(stdout);
			}
						
							
							if(countRet>0)
							{
								ItemTaskPr=NULLTAG;
								int u;
							for(u=0;u<countRet;u++)
							{						
								
								ITK_CALL(AOM_ask_value_string(primary[u],"object_type",&ERCDMLTaskNo));
								if(tc_strcmp(ERCDMLTaskNo,"T5_ChangeTaskRevision")!=0)
									continue;
								else
								{
									ItemTaskPr=primary[u];
								}
									
							}  
								if(ItemTaskPr!=NULLTAG)
								{
									
								//	ITK_CALL(getRelationS2P(ItemTaskPr,&primaryDML,relnameDMLTask,1,&countRetD));
								//ITK_CALL(GRM_find_relation_type(relnameDMLTask,&relType));		
		//filter =T5_ChangeTaskRevision	
			if( relTypeDMLTask != NULLTAG )
			{
				
				ITK_CALL(GRM_list_primary_objects_only(ItemTaskPr,relTypeDMLTask,&countRetD,&primaryDML));
				//printf("\n DML attaced in part count=%d \n",*countRet);fflush(stdout);
			}
									//countRetD=1;
									if(countRetD>0)
									{
										ItemDML=primaryDML[0];
										
										//DesGrpDML="NA";
										ITK_CALL(AOM_ask_value_strings(ItemDML,"t5_crdesigngroup",&num,&DMLDesGroup)); 	
										if(num>0)
										{
											tc_strcpy(DesGrpDML,DMLDesGroup[0]);
											MEM_free(DMLDesGroup);
										}
										
										ITK_CALL(AOM_ask_value_string(ItemDML,"item_id",&DMLNumber));
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"date_released",&ReleaseDt));
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"t5_cDRstatus",&DMLDrStat));
										ITK_CALL(AOM_ask_value_string(ItemDML,"object_name",&Synopsis));					
										ITK_CALL(AOM_ask_value_string(ItemDML,"t5_cprojectcode",&DPrjCode));					
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"t5_rlstype",&RelType));					
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"t5_reason",&Reason));
										ITK_CALL(AOM_ask_displayable_values(ItemDML,"release_status_list",&relstatno,&relstatval));
										
										ITK_CALL(WSOM_ask_release_status_list(ItemDML,&st_count,&ReleaseStat));	
										
									
										if(st_count>0)
										{
										ITK_CALL(AOM_ask_name(ReleaseStat[0],&WSO_Name));	
											MEM_free(ReleaseStat);
										}
										
											
										printf("\n DMLNumberXX==%s",DMLNumber);fflush(stdout);
										(AOM_UIF_ask_value(ItemDML,"Requestor",&DCreator));					
									//	(AOM_ask_value_string(ItemDML,"requestor_user_id",&DCreator));					
									printf("\n DML found for task %s and creator %s",DMLNumber,DCreator);			
										
										/*STRNG_replace_str(Reason,",",";",&Reason1);
										STRNG_replace_str(Reason1,"\n",";",&Reason2);*/
										stripChar(Synopsis,&Synopsis2);
										stripChar(Reason,&Reason2);
										
										printf("\n DMLNumber==%s",DMLNumber);fflush(stdout);
										printf("\n ReleaseDt==%s",ReleaseDt);fflush(stdout);
										printf("\n DMLDrStat==%s",DMLDrStat);fflush(stdout);
										printf("\n Synopsis==%s",Synopsis);fflush(stdout);
										printf("\n DPrjCode==%s",DPrjCode);fflush(stdout);
										printf("\n RelType==%s",RelType);fflush(stdout);
										printf("\n WSO_Name==%s",WSO_Name);fflush(stdout);
										
										autoresizestrcat(&output,DMLNumber);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,ReleaseDt);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,DMLDrStat);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,Synopsis2);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,DPrjCode);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,RelType);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,Reason2);
										autoresizestrcat(&output,",");
										for(rl=0;rl<relstatno;rl++)
										autoresizestrcat(&output,relstatval[rl]);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,DCreator);
										autoresizestrcat(&output,",");
										autoresizestrcat(&output,",");
										MEM_free(relstatval);
										
										/*tag_t		qryTagAPLWFSM			= NULLTAG;
										//char		*ArgName2[1];
										//char		*ArgVal2[1];
										tc_strcpy(respPartySm,"");			
										tc_strcat(respPartySm,DCreator);			
										tag_t user_tag=NULLTAG;
										ITK_CALL(SA_find_user2(DCreator,&user_tag));
											char 		*username;		
											if(user_tag!=NULLTAG)
												{
											ITK_CALL(AOM_ask_value_string(user_tag,"user_name",&username));
											printf("\n record found for user %s Name --> %s... ",respPartySm,username);fflush(stdout);
											autoresizestrcat(&output,username);
											autoresizestrcat(&output,",");
											//MEM_free(ObjsWFActSM);
										}
										else
										{
											autoresizestrcat(&output,",");
										}*/
										ITK_CALL(AOM_UIF_ask_value(ItemDML,"t5_authorisedby",&AuthBy));
										{
											//resultsQryWFActSM		= 0;
											tc_strcpy(respPartySm,"");
											tc_strcat(respPartySm,AuthBy);
										tag_t user_tag=NULLTAG;
											ITK_CALL(SA_find_user2(AuthBy,&user_tag));
													char 		*AuthName;	
													if(user_tag!=NULLTAG)
													{	
													ITK_CALL(AOM_UIF_ask_value(user_tag,"user_name",&AuthName));								
													printf("\n record found for user %s Name --> %s... ",respPartySm,AuthName);fflush(stdout);
													autoresizestrcat(&output,AuthBy);							
													autoresizestrcat(&output,",");							
													autoresizestrcat(&output,AuthName);
													autoresizestrcat(&output,",");
												// 	MEM_free(ObjsWFActSM);														
												}
												else
												{
													autoresizestrcat(&output,",,");
												}
										//	}
										}
										// For DMU Reviewer
										autoresizestrcat(&output,",");
										tag_t	itemMstr;
										char	*PartFalimy = NULL;
										ITK_CALL(ITEM_ask_item_of_rev(itemrevtag,&itemMstr));
										//tag_t	itemMstrtag = itemMstr[0];
										ITK_CALL(AOM_UIF_ask_value(itemMstr,"t5_EngineType",&PartFalimy));	
										autoresizestrcat(&output,DesGrpDML);				
										autoresizestrcat(&output,",");
										
																	   /* STRNG_replace_str(KeyworkDesc,",",";",&KeyworkDesc1);
																		STRNG_replace_str(KeyworkDesc1,"\n",";",&KeyworkDesc2);
																		*/
																		stripChar(KeyworkDesc,&KeyworkDesc2);
				
										autoresizestrcat(&output,KeyworkDesc2);	
										autoresizestrcat(&output,",");		
										autoresizestrcat(&output,PartFalimy);	
										autoresizestrcat(&output,",");	
										printf("\n VCs DML DesGrp	.....!!",DesGrpDML);
									
										MEM_free(primaryDML);
									}
									else
									{
										autoresizestrcat(&output,",,,,,,,,,,,,,,,,");
									}
								}
								else
								{
									autoresizestrcat(&output,",,,,,,,,,,,,,,,,");
								}
		MEM_free(primary);						
							}
							else
							{
								autoresizestrcat(&output,",,,,,,,,,,,,,,,,");
							}
							
							
							// printf("\n Before getAllReleasedPartDML==%s",ChldPartNo);fflush(stdout);
							//int g;
							// getAllReleasedPartDML1(query,ChldPartNo,"Design Revision");
							//char *type1="Design Revision";
							int g;
							
							//report_mem_leak();
							/*ITK_CALL(getAllReleasedPartDML(query,ChldPartNo,"Design Revision", &latestdml,&latestPart,&alldmllist,&allpartlist,&allpart_dml_cnt,FrmDt,ToDt,&total_cnt1));
							 //printf("\n After getAllReleasedPartDML==%d",allpart_dml_cnt);fflush(stdout);
							for(g=0;g<allpart_dml_cnt;g++)
							 {
								 
								tag_t dml_tag=alldmllist[g];
								tag_t part_tag=allpartlist[g];	
									char* dml1=NULL;
								//	if(dml_tag!=NULLTAG)
									if(dml_tag==NULLTAG)
										printf("\n NULL dml_tag");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(dml_tag,"item_id",&dml1));
									
									char* part1=NULL;
									if(part_tag==NULLTAG)
										printf("\n NULL part_tag");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(part_tag,"item_id",&part1));
									if(part1!=NULL)
									printf("\n Part No11 =%s",part1);fflush(stdout);
									if(dml1!=NULL)
									printf("\n dml1=%s",dml1);fflush(stdout);
								 
							 }
							 if(alldmllist!=NULLTAG)
							 MEM_free(alldmllist);
							if(allpartlist!=NULLTAG)
							MEM_free(allpartlist);
							 //MEM_free(latestdml);
							 //MEM_free(latestPart);
						*/
							int k0 = 0;	
								
							sprintf(BOMCntrC, "%d", *((int *)vector_get(bom_counter,i)));
							autoresizestrcat(&output,BOMCntrC);
							autoresizestrcat(&output,",");
							autoresizestrcat(&output,(char*)vector_get(childRevStrList,i));
							autoresizestrcat(&output,",");
							//For BOM CHANGE Logic
							
							autoresizestrcat(&output,(char*)vector_get(global_bom_flag,i));
							autoresizestrcat(&output,",");
							
							for(k0=0;k0<VCSet_cnt;k0++)
							{
								int found = -1;
								printf("\n Here in Code for part search logic .....!!");
								setFindTag(vcs[k0].Children,vcs[k0].childCount,itemrevtag,&found);	
	/*
	int k;
		for(k=0;k<vcs[k0].childCount;k++)
										{
												tag_t   itemrevtag1      = NULLTAG;
												int             BLvl            = 0;
												char    *ChldPartNo = NULL;
												itemrevtag1=vcs[k0].Children[k];
							BLvl=vcs[k0].counter[k];
												if(itemrevtag1==NULLTAG)
																{
																 printf("\n Part-Name NULLLTAGs1");fflush(stdout);
																		continue;
																}
												ITK_CALL(AOM_ask_value_string(itemrevtag1,"object_string",&ChldPartNo));
											
												
												printf("\nXXXX VC holder Part Added in Set : %s BOMCntr==%d",ChldPartNo,BLvl);
												if(itemrevtag1==itemrevtag)
												{
													found=k;
													break;
												}
										}

	ITK_CALL(AOM_ask_value_string(itemrevtag,"object_string",&ChldPartNo));

	printf("\nend vc : %s",ChldPartNo);
								*/
								if(found>=0)
								{					
									autoresizestrcat(&output,"Y,");				
								}
								else
								{
									autoresizestrcat(&output,"N,");		
								}
							}
						}
					}				
				}
				else
				{
					printf("\n No Global VCs child/part set found.....!!\n\n");
				}
			}
			else
			{
				printf("\n No VCs Selected for report.....!!\n\n");
			}
			printf("\n End of program.....!!\n\n");
			
			//printf("\n Final Output == %s.....!!\n\n",output);
			
			//output = "NULL";
			
		
			int q;
			part_dml_count=vector_size(part_dml_vec);
			for(q=0;q<part_dml_count;q++)
			{
			tag_t *tdml_vec=NULLTAG;
			tdml_vec=((tag_t*)vector_get(part_dml_vec,q));
			tag_t dml_vec=*tdml_vec;
			char* dml_dis;
				ITK_CALL(AOM_UIF_ask_value(dml_vec,"object_string",&dml_dis));
				printf("\n DML-VEC [%d]->[%s]",q,dml_dis);fflush(stdout);
			}
			// void *return_data;
			
			
			
			
			FILE* foutput=fopen(OutputFile,"w");
			fprintf(foutput,"%s", output);
			fclose(foutput);
			
			*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output); 
			
			return ifail;
			/* Program Logic End*/
		}

extern int UnitBOMUserServiceFnGateWarReportFn()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE ; 
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n AllUserServiceFnGateWarReportFn before....GatewayRptFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method("GatewayRptFunc",(USER_function_t)GatewayRptFunc,nargs,inputArgTypes,retValueType);
	return ifail;
	
}



extern int SVRBOMUserServiceFnGateWarReportFn()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 7;
	int retValueType;
	int inputArgTypes[7] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE; //platform
	inputArgTypes[1] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE ; //svr
	inputArgTypes[2] = USERARG_STRING_TYPE ; //Rev Rule
	inputArgTypes[3] = USERARG_STRING_TYPE ; //Closure Rule
	inputArgTypes[4] = USERARG_STRING_TYPE;//from date
	inputArgTypes[5] = USERARG_STRING_TYPE;//to date
	inputArgTypes[6] = USERARG_INT_TYPE;//depth
		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n SVRBOMUserServiceFnGateWarReportFn before....GatewayRptFuncsvr");fflush(stdout);  
	ifail=USERSERVICE_register_method("GatewayRptFuncsvr",(USER_function_t)GatewayRptFuncsvr,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

int tm_GateWayReport_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	combinedAllowString				= NULL;
	char*	closureRule						= NULL;
	char*	revisionrule					= NULL;
	char*	InputLevel						= NULL;
	char*	removeUnderscoreValue			= NULL;
	char*	cmbPlantData					= NULL;
	char*	removeExternalProcValue			= NULL;
	char*	skpZeroQuantityValue			= NULL;
	char*	showsuppressValue				= NULL;
	char*	mailLOV							= NULL;
	char*	fromDateStr						= NULL;
	char*	toDateStr						= NULL;


	printf("\n Amar Inside tm_GateWayReport_Call .....\n");
	
	USERARG_get_string_argument(&combinedAllowString);
	USERARG_get_string_argument(&closureRule);
	USERARG_get_string_argument(&revisionrule);
	USERARG_get_string_argument(&InputLevel);
	USERARG_get_string_argument(&removeUnderscoreValue);
	USERARG_get_string_argument(&cmbPlantData);
	USERARG_get_string_argument(&removeExternalProcValue);
	USERARG_get_string_argument(&skpZeroQuantityValue);
	USERARG_get_string_argument(&showsuppressValue);
	USERARG_get_string_argument(&mailLOV);
	USERARG_get_string_argument(&fromDateStr);
	USERARG_get_string_argument(&toDateStr);
            	 
	printf("\n Amar combinedAllowString => %s\n",combinedAllowString);fflush(stdout);		
	printf("\n Amar closureRule => %s\n",closureRule);fflush(stdout);		
	printf("\n Amar revisionrule => %s\n",revisionrule);fflush(stdout);		
	printf("\n Amar InputLevel => %s\n",InputLevel);fflush(stdout);		
	printf("\n Amar removeUnderscoreValue => %s\n",removeUnderscoreValue);fflush(stdout);		
	printf("\n Amar cmbPlantData => %s\n",cmbPlantData);fflush(stdout);		
	printf("\n Amar removeExternalProcValue => %s\n",removeExternalProcValue);fflush(stdout);		
	printf("\n Amar skpZeroQuantityValue => %s\n",skpZeroQuantityValue);fflush(stdout);		
	printf("\n Amar showsuppressValue => %s\n",showsuppressValue);fflush(stdout);		
	printf("\n Amar mailLOV => %s\n",mailLOV);fflush(stdout);		
	printf("\n Amar fromDateStr => %s\n",fromDateStr);fflush(stdout);		
	printf("\n Amar toDateStr => %s\n",toDateStr);fflush(stdout);		

	
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"GateWayReportSo","GateWayReportSo","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;
	
	int n_entryCntrl1=3;
	
	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	
		printf("\n Amar control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			sprintf(cmd,"%s/GateWayReportSo.sh %s %s %s %s %s %s %s %s %s %s %s %s &",t5_Userinfo1,combinedAllowString,closureRule,revisionrule,InputLevel,removeUnderscoreValue,cmbPlantData,removeExternalProcValue,skpZeroQuantityValue,showsuppressValue,mailLOV,fromDateStr,toDateStr);
			printf("\nAmar Excuting For ReassignAllTask Command = %s\n",cmd);fflush(stdout);
			system(cmd);
			printf("\nAfter executing Command\n");fflush(stdout);
	   }
	}
	return ifail;
}

extern int GateWayReportReportFn()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	
	int nargs1 = 12;
	int retValueType1;
	int inputArgTypes1[12] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE;   
	inputArgTypes1[3] = USERARG_STRING_TYPE;   
	inputArgTypes1[4] = USERARG_STRING_TYPE;   
	inputArgTypes1[5] = USERARG_STRING_TYPE;   
	inputArgTypes1[6] = USERARG_STRING_TYPE;   
	inputArgTypes1[7] = USERARG_STRING_TYPE;   
	inputArgTypes1[8] = USERARG_STRING_TYPE;   
	inputArgTypes1[9] = USERARG_STRING_TYPE;   
	inputArgTypes1[10] = USERARG_STRING_TYPE;   
	inputArgTypes1[11] = USERARG_STRING_TYPE;   

	retValueType1 = USERARG_STRING_TYPE ; 
	
	printf("\n GateWayReportReportFn before....tm_GateWayReport_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_GateWayReport_Call",(USER_function_t)tm_GateWayReport_Call,nargs1,inputArgTypes1,retValueType1);


	return ifail;	
}


extern int AllUserServiceFnGateWarReportFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
 
 ITK_CALL(UnitBOMUserServiceFnGateWarReportFn());
 ITK_CALL(SVRBOMUserServiceFnGateWarReportFn());

 ITK_CALL(GateWayReportReportFn());
 
 return ifail;
 
}


extern DLLAPI int tm_GateWayReport_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_GateWayReport");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_GateWayReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnGateWarReportFn);
	printf("\n After registoring userservice....tm_GateWayReport");fflush(stdout);
	return ( ITK_ok );
}

		//main function
		/*
		int ITK_user_main( int argc , char* argv[] )
		{
			int 	Z 					= 0;
			int 	childCount			= 0;
			int 	varientCount			= 0;
			int 	bvrCount			= 0;
			
			
			char* output = NULL;
			char** bvrStrSet = NULL;

			
			char* inputline=NULL;
			char* inputline2=NULL;
			FILE* fp=NULL;
			
			tag_t* bomVarient = NULL;
			tag_t* retModules = NULL;
			
			ITK_set_journalling (TRUE);
			
			
			
			//char* property[10];
			char **property = (char **) MEM_alloc(10 * sizeof(char *));
			char **propertyVal = (char **) MEM_alloc(10 * sizeof(char *));
			
			 char* fileName = ITK_ask_cli_argument("-f=");
			 char* platform = ITK_ask_cli_argument("-platform=");
			 char* fromdt = ITK_ask_cli_argument("-from=");
			 char* todt = ITK_ask_cli_argument("-to=");
			 char* depthstr = ITK_ask_cli_argument("-d=");
			 
			 printf("\n FRom Date=%s, To date=%s",fromdt,todt);fflush(stdout);
			
			//ITK_CALL(ITK_init_module("infodba","infodba","dba"));	
			//error(z,"login success\n");
			
			int depth=atoi(depthstr);
			
			output = (char *) MEM_alloc( 5000 * sizeof(char) );
			
			ITK_CALL(ITK_auto_login());
			printf("login Pratik \n");fflush(stdout);
			
			
				inputline=(char *) MEM_alloc(500);
			
			int 	fileLine 				= 0;
			
			fp=fopen(fileName,"r");
			if(fp!=NULL)
			{
				
				
				inputline2=(char *) MEM_alloc(500);
				
				
				int numOfProp = 0;
				int loop =0;
				
				tag_t* varientObject ;
				
				
				
				
				int plt_frmCount = 0;
				tag_t* pltFrmObj = NULL;
			
			
				ITK_CALL(queryobjectItem("Platform Revision",platform, &plt_frmCount, &pltFrmObj));
				printf("\n plt_frmCount[%d]",plt_frmCount);fflush(stdout);
				
				while(fgets(inputline,500,fp)!=NULL)
				{
					int count = 0;
					tag_t* varient = NULL;
					char* varientRule = NULL;
					
					varientRule = tc_strtok (inputline,",") ;
					
					
					
					printf("\n varientRule [%s]",varientRule);fflush(stdout);
					//char *qry_values[]  = {"VariantRule",inputline};
					ITK_CALL(queryobject("VariantRule",varientRule, &count, &varient));
					
					printf("\n count[%d]",count);fflush(stdout);
					if(count>0)
					{
						tag_t varientTag = NULLTAG;
						
						varientTag = varient[0];
						
						setAddTAG(&varientCount,&varientObject,varientTag);
						
						
					}
				}		
			
		//	GatewayRptFuncsvr(pltFrmObj[0], varientObject,varientCount,"BOMViewClosureRuleERC","ERC release and above", fromdt,todt,depth);
			ITK_CALL(POM_logout(false))	;
			return 0;
		}
		}*/
