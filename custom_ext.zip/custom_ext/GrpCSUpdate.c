#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <pom/pom/pom.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <epm/cr_effectivity.h>
#include <tccore/tc_msg.h>
#include <property/prop.h>
#include <tc/emh.h>
#include <tc/tc_arguments.h>
#include <tccore/item_msg.h>
#include <tccore/workspaceobject.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <epm/epm_task_template_itk.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 4
#define TE_MAXLINELEN  128
#define ITK_err 919002
#define ITK_errStore 91900002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
static void handle_ifail(char *file, int line);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;
static void handle_ifail( char * file, int line )

/*  Prints out the full error stack.
**
*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf("%6d: %s\n", ifails[i], messages[i] );
    }
    exit(EXIT_FAILURE);
}
;
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void  getPlantDetailsAttr( char * RoleName ,char  getPlantCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
	  char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,0,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if(strcmp(PlantName,"APLJ")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}
;

extern EPM_decision_t DLLAPI APL_Grp_CS_Upd(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;

	int			status			=	0;
	char*		s;
	char*		class_name;
	char*		t5Task_name		=	NULL;
	char*		Part_no			=	NULL;
	char*		Part_Type		=	NULL;
	char*		type_name		=	NULL;//Need to free at end
	char*		username		=	NULL;
	char*		CurrentTask		=	NULL;
	char*		PlantName 		=	NULL;
	char*		SubSyscd 		=	NULL;
	char		roleName[SA_name_size_c+1];
	char*		GChldName ;
	char*		GChldRev ;
	char*		GChildPuneCS ;
	char PlantCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];

	tag_t		root_task		=	NULLTAG;
	tag_t*		attachmentsTask	=	NULLTAG;
	tag_t		taskTag			=	NULLTAG;
	tag_t*		PartsTags		=	NULLTAG;
	tag_t*		GrpChld			=	NULLTAG;
	tag_t		class_id		=	NULLTAG;
	tag_t		DesignTag		=	NULLTAG;
	tag_t		objTypeTag		=	NULLTAG;
	tag_t		CurrentRoleTag	=	NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;
	tag_t		window,top_line;
	tag_t		t_GChldItemRev;

	WSO_search_criteria_t  	criteria_Gcontrol;

	int	count=0,partcnt=0,iPrt=0,nClhd=0,FlagGrpNA = 0,iCntl=0,cntCntrl=0,stampingdone=0,iGChld=0;
	int control_number_found;
	int ifail = ITK_ok;
	int iChildItemTag;

	//Get username
	username = NULL;
	ITKCALL(POM_get_user_id (&username));
	printf("\n\n GRP Session login User1 : %s\n",username); fflush(stdout);

	//Get role of current user
	//Get role tag and then find its value
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n GRP roleName : %s\n",roleName); fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\nROOT TASK FOUND");fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachmentsTask));
	printf("\nNo of Attached task found : %d",count);fflush(stdout);

	if (count>0)
	{
		taskTag	=	attachmentsTask[0];
	}

	status = AOM_ask_value_string(taskTag,"current_name",&t5Task_name);
	printf("\nTask Name : %s",t5Task_name);fflush(stdout);

	if ( status != ITK_ok)
	{
	 EMH_ask_error_text( status, &s);
	 printf("Error with AOM_ask_value_string : %s \n",s);
	 MEM_free(s);
	 return status;
	}
	CALLAPI(POM_class_of_instance(taskTag,&class_id));//Finds out the class to which the instance belongs
	CALLAPI(POM_name_of_class(class_id,&class_name));//Find the name of class

	printf("\n\nclass_name of Task :%s",class_name);fflush(stdout);

	CALLAPI(AOM_refresh( taskTag, 0 ));

	if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		//if(tc_strcmp(class_name,"A9_APLTaskRevision")==0)
		if(tc_strcmp(class_name,"T5_APLTaskRevision")==0)
		{
			getPlantDetailsAttr(roleName,PlantCS,PlantIA,PlantStore,UserAgency);
			printf("\n PlantCS %s \n",PlantCS);
			printf("\n PlantAgency %s \n",PlantIA);
			printf("\n PlantStore %s \n",PlantStore);
			printf("\n UserAgency %s \n",UserAgency);

			CALLAPI(AOM_ask_value_tags(taskTag,"CMHasSolutionItem",&partcnt,&PartsTags));//Find the parts attached with task

			printf("\n\n Nopartcnt:%d",partcnt);fflush(stdout);

			if (partcnt>0)
			{
				for (iPrt=0;iPrt<partcnt ;iPrt++ )
				{
					printf("\n%d",iPrt);fflush(stdout);
					DesignTag	=	PartsTags[iPrt];

					if(TCTYPE_ask_object_type(DesignTag,&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name));
					printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

					CALLAPI(AOM_ask_value_string(DesignTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					CALLAPI(AOM_ask_value_string(DesignTag,"t5_PartType",&Part_Type));
					printf("\n\n\t\t Part_no  is :%s",Part_Type);	fflush(stdout);

					if((tc_strcmp(type_name,"Design Revision")==0) && (tc_strcmp(Part_Type,"G")==0))
					{

						//Get the child of Group Part
						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_pack_all (window, true)!=ITK_ok)PrintErrorStack();//Pack the BOM Line
						if(BOM_set_window_top_line (window, null_tag,DesignTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();//Find the child of the BOM line

						if(BOM_line_ask_child_lines (top_line, &nClhd, &GrpChld));
						printf("\nNo of Child Found : %d",nClhd);fflush(stdout);
						if (nClhd>0)
						{
							//Check the CS of Child Parts, If all child having CS as 'NA' then stamp Group Part CS as 'NA'
							FlagGrpNA	=	0;
							for (iGChld=0;iGChld<nClhd ;iGChld++)
							{
								ITKCALL(BOM_line_unpack (GrpChld[iGChld]));
								ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
								ITKCALL(BOM_line_ask_attribute_tag(GrpChld[iGChld], iChildItemTag, &t_GChldItemRev));

								ITKCALL(AOM_ask_value_string(t_GChldItemRev,"item_id",&GChldName));
								printf("\n child GChldName:%s ..............",GChldName);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_GChldItemRev,"item_revision_id",&GChldRev));
								printf("\n child GChldRev:%s ..............",GChldRev);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_GChldItemRev,PlantCS,&GChildPuneCS));
								printf("\n child GChildPuneCS:%s ..............",GChildPuneCS);fflush(stdout);

								if(tc_strcmp(GChildPuneCS,"NA (Not Applicable For plant)" )==0)
								{
									FlagGrpNA++;
								}
							}
							printf("\n\nFlagGrpNA : %d, chilcnt : %d",FlagGrpNA,nClhd);fflush(stdout);
							if (FlagGrpNA==nClhd)
							{
								//Update the Group Part CS as "NA"
								printf("\n\nAll child having NA CS,so Group CS is NA.\n");fflush(stdout);
								CALLAPI(AOM_lock(DesignTag));//Locks an object against modification by another process.
								CALLAPI(AOM_set_value_string(DesignTag,PlantCS,"NA"));//Sets value on a single-valued property.
								CALLAPI(AOM_save(DesignTag));//Saves an application object to the database.
								CALLAPI(AOM_refresh(DesignTag,0));//Reload the object in Database
								CALLAPI(AOM_unlock(DesignTag));
							}
							else
							{
								cntCntrl	=	0;
								//Query the control object, if found stamped Group part CS as "E50"
								printf("\nNot all part having NA CS.");fflush(stdout);
								WSOM_clear_search_criteria(&criteria_Gcontrol);
								strcpy(criteria_Gcontrol.name,"AutoStmGrp");
								strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
								status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
								printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
								if (control_number_found>0)
								{
									cntCntrl	=	0;
									for (iCntl=0;iCntl<control_number_found;iCntl++ )
									{
										//Find the subsysd and plantname
										AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
										AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_Userinfo1", &PlantName);
										printf("\n\nSubSyscd : %s, Plant Name : %s, UserAgency : %s",SubSyscd,PlantName,UserAgency);fflush(stdout);
										if ((tc_strcmp(SubSyscd,"Live")==0) && (tc_strcmp(PlantName,UserAgency)==0))
										{
											cntCntrl++;
											MEM_free(list_of_WSO_cntrl_tags);
											break;
										}
									}
								}
								printf("\n\ncntCntrl : %d",cntCntrl);fflush(stdout);
								if (cntCntrl>0)
								{
									printf("\ncontrol object found,So update the CS as E50.");fflush(stdout);
									//Update the Group Part CS as "E50"
									CALLAPI(AOM_lock(DesignTag));//Locks an object against modification by another process.
									CALLAPI(AOM_set_value_string(DesignTag,PlantCS,"E50"));//Sets value on a single-valued property.
									CALLAPI(AOM_save(DesignTag));//Saves an application object to the database.
									CALLAPI(AOM_refresh(DesignTag,0));//Reload the object in Database
									CALLAPI(AOM_unlock(DesignTag));
								}
								else
								{
									//Update the CS base on Child Part and User location
									printf("\nNo control object found.");fflush(stdout);
									stampingdone=0;
									for (iGChld=0;iGChld<nClhd ;iGChld++)
									{
										ITKCALL(BOM_line_unpack (GrpChld[iGChld]));
										ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
										ITKCALL(BOM_line_ask_attribute_tag(GrpChld[iGChld], iChildItemTag, &t_GChldItemRev));
										ITKCALL(AOM_ask_value_string(t_GChldItemRev,"item_id",&GChldName));
										printf("\n child GChldName:%s ..............",GChldName);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_GChldItemRev,"item_revision_id",&GChldRev));
										printf("\n child GChldRev:%s ..............",GChldRev);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_GChldItemRev,PlantCS,&GChildPuneCS));
										printf("\n child GChildPuneCS:%s ..............",GChildPuneCS);fflush(stdout);

										//Check CS as E50 and Location as JSR/JDL/PNR
										if ((tc_strcmp(GChildPuneCS,"E50")==0) && ((tc_strcmp(UserAgency,"JSR")==0) || (tc_strcmp(UserAgency,"JDL")==0)|| (tc_strcmp(UserAgency,"PNR")==0)))
										{
											printf("\nInside %s(JSR/JDL/PNR) CS update as E50 for Grp part\n",UserAgency);fflush(stdout);
											//Update the Group Part CS as "E50"
											CALLAPI(AOM_lock(DesignTag));//Locks an object against modification by another process.
											CALLAPI(AOM_set_value_string(DesignTag,PlantCS,"E50"));//Sets value on a single-valued property.
											CALLAPI(AOM_save(DesignTag));//Saves an application object to the database.
											CALLAPI(AOM_refresh(DesignTag,0));//Reload the object in Database
											CALLAPI(AOM_unlock(DesignTag));
											break;
										}
										else if (((tc_strcmp(GChildPuneCS,"E50 ")==0) || (tc_strcmp(GChildPuneCS,"E99")==0) ) && ((tc_strcmp(UserAgency,"JSR")!=0) || (tc_strcmp(UserAgency,"JDL")!=0)|| (tc_strcmp(UserAgency,"PNR")!=0)))
										{
											//Update the Group Part CS as "E50"
											printf("\nInside %s(not JSR/JDL/PNR) CS update as E50 for Grp part\n",UserAgency);fflush(stdout);
											CALLAPI(AOM_lock(DesignTag));//Locks an object against modification by another process.
											CALLAPI(AOM_set_value_string(DesignTag,PlantCS,"E50"));//Sets value on a single-valued property.
											CALLAPI(AOM_save(DesignTag));//Saves an application object to the database.
											CALLAPI(AOM_refresh(DesignTag,0));//Reload the object in Database
											CALLAPI(AOM_unlock(DesignTag));
											break;
										}
										else
										{
											stampingdone++;
											printf("\nGroup Id Will Update as E [%d]\n",  stampingdone);fflush(stdout);
											if (stampingdone==1)
											{
												CALLAPI(AOM_lock(DesignTag));//Locks an object against modification by another process.
												CALLAPI(AOM_set_value_string(DesignTag,PlantCS,"E"));//Sets value on a single-valued property.
												CALLAPI(AOM_save(DesignTag));//Saves an application object to the database.
												CALLAPI(AOM_refresh(DesignTag,0));//Reload the object in Database
												CALLAPI(AOM_unlock(DesignTag));
											}

										}

									}
								}
								//Free list_of_WSO_cntrl_tags

							}

						}
						else
						{
							MEM_free(PartsTags);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "No child found under Group Part");
							decision = EPM_nogo;
							return decision;
						}

					}
				}
				MEM_free(PartsTags);
			}
			else
			{
				printf("\n No parts attached to task.");fflush(stdout);
			}
		}
	}

	decision = EPM_go;
	return decision;
}
;

extern EPM_decision_t DLLAPI AssyCSBOMCheck(EPM_rule_message_t msg)
{
	EPM_decision_t decision			=	EPM_go;
	int			status				=	0;
	char*		s					=	NULL;
	char*		username			=	NULL;
	char*		class_name			=	NULL;
	char*		CurrentTask			=	NULL;
	char*		t5Task_name			=	NULL;
	char*		Part_no				=	NULL;
	char*		Part_Type			=	NULL;
	char*		Part_Proj			=	NULL;
	char*		SubSyscd 			=	NULL;
	char*		PlantName 			=	NULL;
	char*		prtPlantCS 			=	NULL;
	char*		prtCoatedInd		=	NULL;
	char*		prtClrInd			=	NULL;
	char*		AssyNoBOMErr		=	NULL;
	char*		FullBomErrString	=	NULL;
	char*		SetAssyNoBOMErr		=	NULL;
	char*		type_name			=	NULL;
	char*		prtTask_type		=	NULL;
	char*		prtTaskName			=	NULL;
	char		roleName[SA_name_size_c+1];
	char		PlantCS[40];
	char		PlantIA[40];
	char		PlantStore[40];
	char		UserAgency[40];

	tag_t		CurrentRoleTag		=	NULLTAG;
	tag_t		root_task			=	NULLTAG;
	tag_t		top_line			=	NULLTAG;
	tag_t*		attachmentsTask		=	NULLTAG;
	tag_t		taskTag				=	NULLTAG;
	tag_t		class_id			=	NULLTAG;
	tag_t		DesignTag			=	NULLTAG;
	tag_t		objTypeTag			=	NULLTAG;
	tag_t*		PartsTags			=	NULLTAG;
	tag_t		window				=	NULLTAG;
	tag_t		rule				=	NULLTAG;
	tag_t*		DgnChld				=	NULLTAG;
	tag_t	  	relation_type		=	NULLTAG;
	tag_t*  	prtTasks			=	NULLTAG;
	tag_t  		prtTask				=	NULLTAG;
	tag_t  		prtTask_Class		=	NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;

	int count=0,partcnt=0,cntCntrl=0,nClhd=0,errCnt=0,iPrt=0,iCntl=0,cntTask=0,iTask=0;
	int control_number_found;
	int ifail = ITK_ok;

	size_t	prtTaskLen	=	0;

	WSO_search_criteria_t  	criteria_CARDML;

	printf("\n\n INSIDE RULE HANDLER AssyCSBOMCheck \n"); fflush(stdout);
	//Get username
	username = NULL;
	ITKCALL(POM_get_user_id (&username));
	printf("\n\n Assy Session login User1 : %s\n",username); fflush(stdout);
	//Get role of current user
	//Get role tag and then find its value
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n GRP roleName : %s\n",roleName); fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\nROOT TASK FOUND");fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachmentsTask));
	printf("\nNo of Attached task found : %d",count);fflush(stdout);

	if (count>0)
	{
		taskTag	=	attachmentsTask[0];
	}

	status = AOM_ask_value_string(taskTag,"current_name",&t5Task_name);
	printf("\nTask Name : %s",t5Task_name);fflush(stdout);

	if ( status != ITK_ok)
	{
	 EMH_ask_error_text( status, &s);
	 printf("Error with AOM_ask_value_string : %s \n",s);
	 MEM_free(s);
	 return status;
	}

	CALLAPI(POM_class_of_instance(taskTag,&class_id));//Finds out the class to which the instance belongs
	CALLAPI(POM_name_of_class(class_id,&class_name));//Find the name of class

	printf("\n\nclass_name of Task :%s",class_name);fflush(stdout);

	CALLAPI(AOM_refresh(taskTag, 0 ));

	if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
		//if(tc_strcmp(class_name,"A9_APLTaskRevision")==0)
		if(tc_strcmp(class_name,"T5_APLTaskRevision")==0)
		{
			getPlantDetailsAttr(roleName,PlantCS,PlantIA,PlantStore,UserAgency);
			printf("\n PlantCS %s \n",PlantCS);
			printf("\n PlantAgency %s \n",PlantIA);
			printf("\n PlantStore %s \n",PlantStore);
			printf("\n UserAgency %s \n",UserAgency);

			CALLAPI(AOM_ask_value_tags(taskTag,"CMHasSolutionItem",&partcnt,&PartsTags));//Find the parts attached with task

			printf("\n\n Nopartcnt:%d",partcnt);fflush(stdout);

			if (partcnt>0)
			{
				errCnt	=	0;
				if (!SetAssyNoBOMErr) MEM_free(SetAssyNoBOMErr);
				SetAssyNoBOMErr=(char *)MEM_alloc(2500);

				FullBomErrString = (char *)MEM_alloc(2500);
				tc_strcpy(FullBomErrString,"PART_BOM_ERROR_MISMATCH :: ");
				tc_strcpy(SetAssyNoBOMErr,FullBomErrString);

				for (iPrt=0;iPrt<partcnt ;iPrt++ )
				{
					printf("\n%d",iPrt);fflush(stdout);
					DesignTag	=	PartsTags[iPrt];

					if(TCTYPE_ask_object_type(DesignTag,&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name));
					printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

					CALLAPI(AOM_ask_value_string(DesignTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					CALLAPI(AOM_ask_value_string(DesignTag,"t5_PartType",&Part_Type));
					printf("\n\n\t\t Part_no  is :%s",Part_Type);	fflush(stdout);

					if (tc_strcmp(type_name,"Design Revision")==0)
					{
						//t5_ProjectCode
						CALLAPI(AOM_ask_value_string(DesignTag,"t5_ProjectCode",&Part_Proj));
						printf("\n\n\t\t Part_Proj  is :%s",Part_Proj);	fflush(stdout);

						//QUERY THE CARDML CONTROL OBJECT BASED ON PROJECT CODE
						//IF FOUND BYPASS THE BOM CHECK FOR THAT PART
						WSOM_clear_search_criteria(&criteria_CARDML);
						tc_strcpy(criteria_CARDML.name,"CARDML");
						tc_strcpy(criteria_CARDML.class_name,"T5_ControlObject");
						status	= WSOM_search(criteria_CARDML, &control_number_found, &list_of_WSO_cntrl_tags);
						printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
						if (control_number_found>0)
						{
							cntCntrl	=	0;
							for (iCntl=0;iCntl<control_number_found;iCntl++ )
							{
								//Find the subsysd and plantname
								AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
								AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_Userinfo1", &PlantName);
								printf("\n\nSubSyscd : %s, Plant Name : %s, UserAgency : %s",SubSyscd,PlantName,UserAgency);fflush(stdout);
								if ((tc_strcmp(SubSyscd,Part_Proj)==0) && (tc_strcmp(PlantName,"X1")==0))
								{
									cntCntrl++;
									break;
								}
							}
						}
						if (cntCntrl>0)
						{
							printf("\n\n cntCntrl : %d, Bypass the CS E50/E99/E98 check for Car Plant.\n",cntCntrl);fflush(stdout);
							continue;
						}
						//t5_PartType
						//if (tc_strcmp(Part_Type,"t5SpKit")!=0) need to check this condition for class. as in TCE check class t5SpKit
						{
							ITKCALL(AOM_ask_value_string(DesignTag,PlantCS,&prtPlantCS));
							printf("\n Parent prtPlantCS:%s ..............",prtPlantCS);fflush(stdout);

							if ((tc_strcmp(prtPlantCS,"E50")==0 || tc_strcmp(prtPlantCS,"E99")==0 || tc_strcmp(prtPlantCS,"E98")==0 || tc_strcmp(prtPlantCS,"F30")==0) && (tc_strcmp(Part_Type,"A")==0 || tc_strcmp(Part_Type,"C")==0))
							{
								printf("\n CS E50, E99 ,E98 or F30 part found...\n");fflush(stdout);
								if (tc_strcmp(prtPlantCS,"F30")==0 && tc_strcmp(UserAgency,"JDL")==0)
								{
									printf("\nCS F30 and Location JDL, Bypass check...!!!");fflush(stdout);
									continue;
								}
							//}

								ITKCALL(AOM_ask_value_string(DesignTag,"t5_Coated",&prtCoatedInd));
								printf("\n Parent prtCoatedInd:%s ..............",prtCoatedInd);fflush(stdout);

								ITKCALL(AOM_ask_value_string(DesignTag,"t5_ColourInd",&prtClrInd));
								printf("\n Parent prtClrInd:%s ..............",prtClrInd);fflush(stdout);

								if (tc_strcmp(prtCoatedInd,"C")!=0 && tc_strcmp(prtClrInd,"C")!=0)
								{
									nClhd	=	0;
									ITKCALL(BOM_create_window (&window));
									ITKCALL(CFM_find( "Latest Working", &rule));
									ITKCALL(BOM_set_window_config_rule( window, rule ));
									ITKCALL(BOM_set_window_top_line(window, null_tag,DesignTag , null_tag, &top_line));
									ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &DgnChld));
									printf("\nNo of Child Found : %d",nClhd);fflush(stdout);
									if (nClhd<=0)
									{
										//If the part is componet, then
										//Query the supersed part based on orgnazaion ID(APL%) and explode the BOM
										//If BOM found, the set the counter = 1
										//Find the DML, if APL STR DML set counter = 1
										ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
										ITKCALL( GRM_list_primary_objects_only(DesignTag,relation_type,&cntTask,&prtTasks));
										printf("\nNo Of Task Found : %d",cntTask);fflush(stdout);
										if (cntTask>0)
										{
											for (iTask=0;iTask<cntTask;iTask++)
											{
												prtTask	=	prtTasks[iTask];
												ITKCALL (TCTYPE_ask_object_type(prtTask,&prtTask_Class));
												ITKCALL (TCTYPE_ask_name2(prtTask_Class,&prtTask_type));

												printf("\nprtTask_type : %s",prtTask_type);fflush(stdout);

												//if(tc_strcmp(type_class,"A9_APLTaskRevision")==0)
												if(tc_strcmp(prtTask_type,"T5_APLTaskRevision")==0)
												{
													prtTaskName	=	NULL;
													ITKCALL( AOM_ask_value_string(prtTask,"item_id",&prtTaskName));
													printf("\nprtTaskName : %s",prtTaskName);fflush(stdout);
													if (tc_strstr(prtTaskName,"AM")!=NULL)
													{
														printf("\nAM TASK FOUND...!!!");fflush(stdout);
														//NOW CHECK FOR DML

													}
													prtTaskLen	=	tc_strlen(prtTaskName);
													if (prtTaskLen>0)
													{
														MEM_free(prtTaskName);
													}
												}
											}
											if (cntTask>0)
											{
												MEM_free(prtTasks);
											}
										}

										//Free outut tags
										//Find the raw part, attached with part
										//check the plant, if plant match set the RPFoundFlg=1
										//if above all condition failed, give error msg

										AssyNoBOMErr=(char *)MEM_alloc(500);
										//tc_strcpy(AssyNoBOMErr,"");
										sprintf(AssyNoBOMErr,"\nAssy [%s] Has CS As E50/E99/E98/F30, But It Neither Has Any BOM Under It Nor Has Raw Parts.\n", Part_no);
										printf("\nAssy [%s] Has CS As E50/E99/E98/F30, But It Neither Has Any BOM Under It Nor Has Raw Parts.\n", Part_no);
										tc_strcat(FullBomErrString,AssyNoBOMErr);
										tc_strcat(SetAssyNoBOMErr,FullBomErrString);
										errCnt	=	1;
									}

								}

							}
						}
					}
				}
				MEM_free(PartsTags);
				if (errCnt>0)
				{
					printf("\n %s \n",SetAssyNoBOMErr);
					status=EMH_store_error_s1(EMH_severity_error,ITK_errStore,SetAssyNoBOMErr);
					decision = EPM_nogo;
					return ITK_errStore;
				}
			}
		}
	}

	//MEM_free(PartsTags);
	decision = EPM_go;
	return decision;
}

extern int Grp_Prt_CS_Upd_register_method(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;
	//METHOD_id_t  method ;
	//EPM_register_rule_handler --> Used to register the name of Handler
	//2nd parameter is description of Handler
	//3rd is function pointer
	//status = EPM_register_action_handler("APLGrpCSUpd","This Handler is used to display message",(EPM_action_handler_t) APL_Grp_CS_Upd);
//	if( ITK_ok == EPM_register_action_handler("GrpPrtCSUpd", "", GrpPrtCSUpd))
//	{
//		printf("\n\nAPL Group CS action handler registered successfully....\n\n");fflush(stdout);
//	}
//	else
//	{
//		printf("\n\nAPL Group CS action handler not registered....\n\n");fflush(stdout);
//	}

	if( ITK_ok == EPM_register_rule_handler ("GrpPrtCSUpd","This Handler is used to display message",(EPM_rule_handler_t)APL_Grp_CS_Upd))
	{
		printf("\t\n Registered Rule Handler GrpPrtCSUpd\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Rule Handler GrpPrtCSUpd\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_rule_handler ("AssyCSBOMCheck","This Handler is used to Check BOM under E50/E99/E98/F30",(EPM_rule_handler_t)AssyCSBOMCheck))
	{
		printf("\t\n Registered Rule Handler AssyCSBOMCheck\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Rule Handler GrpPrtCSUpd\n");fflush(stdout);
	}

	return ITK_ok;
}
;
extern DLLAPI int GrpPrtCSUpd_register_callbacks()
{
	int			status				=	0;
	status = CUSTOM_register_exit("GrpPrtCSUpd","USER_init_module",(CUSTOM_EXIT_ftn_t)Grp_Prt_CS_Upd_register_method);

	if(status == ITK_ok)
	{
		printf("\n\nAPL Group CS action Handler is Working..................\n\n");fflush(stdout);
	}
	return status;
}