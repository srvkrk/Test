/*******************
*  File            :   tm_ProjCoMapRpt.c
*  Created By      :   Vijay Khandare
*  Created On      :   10-06-2024
*  Purpose         :   Project code mapping report....
*  TZ			   :   
*******************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdbool.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define MAX_SIZE 1000
#define STRING_LENGTH 10000

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;

int ProjCoMapRpt()
{
	char           *UserId           = NULL;
	char           *PlantAgency      = NULL;
	
	char	command[1000];

	USERARG_get_string_argument(&UserId);
    USERARG_get_string_argument(&PlantAgency);
	
	printf("Input user id is ... = %s\n",UserId);fflush(stdout);
	
	printf("Input user id is ... = %s\n",PlantAgency);fflush(stdout);
	
	sprintf(command,"/user/cvprod/shells/STD/ProjCoMapRpt.sh  %s %s",UserId,PlantAgency);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	return ITK_ok;
}

extern int tm_ProjCoMapRpttfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 2;
	int retValueType;
	int inputArgTypes[2] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //user id
	inputArgTypes[1] = USERARG_STRING_TYPE; //plnt agency
	
	retValueType = USERARG_STRING_TYPE ;
	
	ifail=USERSERVICE_register_method("ProjCoMapRpt",(USER_function_t)ProjCoMapRpt,nargs,inputArgTypes,retValueType);
	
	return ifail;
}

extern DLLAPI int tm_ProjCoMapRpt_register_callbacks ()
{	
	int ifail    = ITK_ok;
	ifail = CUSTOM_register_exit("tm_ProjCoMapRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ProjCoMapRpttfncalling);
	return(ITK_ok);
}