/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_SetAttr.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int CM_SetAttr(EPM_action_message_t msg)
{
	int Flag				=0;
	int ifail				= ITK_ok;
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int countDep			= 0;
	int    fndid=0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *primary_obj		= NULLTAG;
	tag_t  primaryObj		= NULLTAG;
	tag_t  childObjTag		= NULLTAG;
	tag_t  ArchobjTypeTag	=NULLTAG;
	tag_t ArchAssyTag =NULLTAG;

	char*	ObjTyp=NULL;
	char*   Archtype_name=NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectrevId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *type_name		=NULL;
	char			*child_item_id				= NULL;
	char   *archId		=NULL;
	char			**child_fndid				= NULL;

	tag_t window=NULLTAG;
	tag_t  rule=NULLTAG;
	tag_t top_line =NULLTAG;
	int n_BL=0;
	int p1=0;
	tag_t *children1= NULL;
	tag_t Childobject=NULLTAG;
	int    bl_config=0;
	int    strcnt1=0;
	logical bl_config_log;

	date_t			date_start				= NULLDATE;
	date_t			date_end				= NULLDATE;

	int n_parents=0;
	int *levels = 0;
	tag_t *parents = NULL;
	
	char *username;
	tag_t user_tag=NULLTAG;
	char *userid;
	//EPM_decision_t decision = EPM_go;
	
	printf("\n CM_SetAttr Function started...");fflush(stdout);
	TC_write_syslog("\n CM_SetAttr Function started...");

	ifail = EPM_ask_root_task(msg.task, &roottask);
	ifail = EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments);
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				ifail = GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation);
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject);
					printf("\n\t count is : %d",count);
					if(count >0)
					{
						for(j=0;j<count;j++)
						{
						  ifail = AOM_ask_value_string(SecObject[j],"t5_PartType",&objecttype);
						  ifail = AOM_ask_value_string(SecObject[j],"item_revision_id",&objectrevId);
						  ifail = AOM_ask_value_string(SecObject[j],"item_id",&objectId);
						  ifail = AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus);

						  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
						  printf("SecObject objectrevId = [%s]\n",objectrevId);fflush(stdout);
						  printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  							 		  
						  if(PS_where_used_all(SecObject[j],1,&n_parents,&levels,&parents));
						  printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
						  if(n_parents >0)
						  {
							  for (k=0;k<n_parents;k++)
							  {
								ArchAssyTag=parents[k];

								if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
								if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
							    printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

								if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
								{
									  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);								  

									 ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&archId);

									  printf("\n\tArchitecture ID is := %s", archId);fflush(stdout); //ItemRevision
				  
									  if((ArchAssyTag != NULLTAG))
									  {
										if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
										if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
										if(top_line!=NULLTAG)
										{
											if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
											printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
											if (n_BL >0)
											{
												
												for (p1=0;p1<n_BL ;p1++ )
												{
													if(Childobject) Childobject=NULLTAG;
													Childobject=children1[p1];

													if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
													printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

													if (tc_strcmp(objectId,child_item_id)==0)
													{
														
														if( AOM_ask_displayable_values(Childobject,"bl_occ_t5_upd_vf_form",&strcnt1,&child_fndid))PrintErrorStack();
														
														printf("\n child_fndid===============>>>>>> %s\n",child_fndid[0]);
													if(strcnt1>0)	
													{
														if	(tc_strcmp(child_fndid[0],"False")==0)
														{
															ifail = AOM_lock( ArchAssyTag );
															ifail = AOM_lock( Childobject );

															printf("\n child_fndid value ==>>[%s] Value Changing to True\n",child_fndid[0]);
															//ifail = BOM_line_set_attribute_logical(Childobject,bl_config,true);
															//if(BOM_line_set_attribute_string(Childobject,fndid, "True"));
															if(AOM_UIF_set_value(Childobject,"bl_occ_t5_upd_vf_form","True"));

															ifail = AOM_save_without_extensions(Childobject);
															ifail = AOM_refresh(Childobject,1);
															ifail = AOM_unlock( Childobject );

															ifail = AOM_refresh(ArchAssyTag, 1);
															ifail = AOM_save_without_extensions(ArchAssyTag);
															ifail = AOM_unlock( ArchAssyTag );
															ifail = AOM_refresh(ArchAssyTag, 0);
														}
														else
														{
															printf("\n child_fndid value ==>>[%s] Value Update not needed \n",child_fndid[0]);																		
														}
													}
													
													}
												}
											}
										}
										  
									  }
								  }
							  }
						  }
						}
					}
				}
			}
		}
	}
	printf("\n CM_SetAttr Function end...");fflush(stdout);
	TC_write_syslog("\n CM_SetAttr Function end...");
	//return ifail;
	return 0;
		
}	
