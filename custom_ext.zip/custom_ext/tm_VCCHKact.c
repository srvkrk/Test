#include "TMLLibrary_server_exits.h"

int tm_VCCHKact(EPM_action_message_t msg)
{
    printf("\n *********** ::start here:: **********");fflush(stdout);
	printf("inside tm_VCCHKact handler");fflush(stdout);

    int ifail=ITK_ok;
    int r,Xp,l;
	int revcount;
	int error_code			 = ITK_ok;
	int i					 = 0;
	int j					 = 0;
	int k					 = 0;
	int count				 = 0;
	int taskcount			 = 0;
	int flagVC				 = 0;
	int notsk				 = 0;
	int dmlCnt				 = 0;
	int o				     = 0;
	int a				     = 0;
    int	Breakdowncount       = 0;
	int	Xpartcount           = 0;
	int	countt               = 0;
	int DR2_flag             = 0;
	int cnt_ccvcls           = 0;
	int no_attach			 = 0;
	int drflag			     = 0;
	char *objecttype		 = NULL;
	char *objectId		     = NULL;
	char *objectdesc		 = NULL;
	char *objectrelstatus	 = NULL;
	char *objectDRstatus	 = NULL;
	char *DMLDRstauts		 = NULL;
	char *value			     = NULL;
	char *objTypeofTask      = NULL;
	tag_t Xpartcount1        = NULLTAG;
	tag_t XPartTags1         = NULLTAG;
	tag_t item               = NULLTAG;
	tag_t reltiontype        = NULLTAG;
	tag_t techspecobjs1      = NULLTAG;
	tag_t DMLTaskTag         = NULLTAG;
	tag_t DMLtsk_tag         = NULLTAG;
	tag_t DMLtaskRevTag       = NULLTAG;
	tag_t tsk_dml_rel_type   = NULLTAG;
	tag_t DMLRevTg           = NULLTAG;
	tag_t veh_tsk_rel        = NULLTAG;
	tag_t task_dml_rel       = NULLTAG;
	tag_t query			     = NULLTAG;
	tag_t rev_list1          = NULLTAG;
	tag_t DmlItemsRelation	 = NULLTAG;
	tag_t Taskrelation_type  = NULLTAG;
	tag_t DMLObject		     = NULLTAG;
	tag_t roottask			 = NULLTAG;
	tag_t objTypTag		     = NULLTAG;
    tag_t   ClsObj           = NULLTAG;
	tag_t DMLRevTag            = NULLTAG;
	tag_t *BreakdowncountTags= NULLTAG;
	tag_t *XPartTags         = NULLTAG;
	tag_t *rev_list          = NULLTAG;
	tag_t *techspecobjs      = NULLTAG;
	tag_t *DMLRevision       = NULLTAG;
	tag_t *tsk_rev           = NULLTAG;
	tag_t *SecObject		 = NULLTAG;
	tag_t *taskObject		 = NULLTAG;
	tag_t *Attachments	     = NULLTAG;
	tag_t *contrlObjs	     = NULLTAG;
	tag_t *ClsObjTag	     = NULLTAG;
	tag_t *taskAttachments	 = NULLTAG;
	char *DMLNo              = NULL;
	char *sDMLno             = NULL;
	char *objType            = NULL;
	char *item_id            = NULL;
	char *objTypeofDML       = NULL;
	char *DMLtype            = NULL;
	char *Breakdownobj       = NULL;
	char *partid             = NULL;
	char *classofobj         = NULL;
	char *revid              = NULL;
	char *DRattri            = NULL;
	char *releasestatus      = NULL;
	char *PartStatus         = NULL;
	char *parttype           = NULL;
	char *attrivalue         = NULL;
	char *dmldr              = NULL;
	char *fromtostatus       = NULL;
	char *dmlreltype         = NULL;
	char *dmlreltype2        = NULL;
	char *sVCInfo1          = NULL;
	char *sVCInfo2          = NULL;
	char *sVCInfo3          = NULL;
	char *sVCInfo4          = NULL;
	char *sDMLDR             = NULL;
	char *dmltskNo           = NULL;
	char *AttrKeyValue           = NULL;
	char *Tsk_object_type              = NULL;
	char *relation_name              = NULL;
	char *TechSpecNum        = NULL;
	char *VCBusUnit          = NULL;
	char  *VCBusUnitDup          = NULL;
	char  *partDR          = NULL;
	char  *partStat          = NULL;
	//char  *partStat          = NULL;
	tag_t *TskTags	 = NULLTAG;
	tag_t *PrtsTag	 = NULLTAG;
	tag_t *primaryobjs           = NULLTAG;
    tag_t TechSpecObjTag            = NULLTAG;
	tag_t relation_type_tag            = NULLTAG;
	tag_t TskTags1            = NULLTAG;
	int TScount			 = 0;
	int Tskcount			 = 0;
	int p			 = 0;
	int prtcnt			 = 0;
	int hp			 = 0;

	logical is_latest;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_VCCHKact Function started...");fflush(stdout);
	TC_write_syslog("\n tm_VCCHKact Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>>tm_VCCHKact [%d]", no_attach);fflush(stdout);

	char *dmlTaskNo =(char *) MEM_alloc(sizeof(char)* 50);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_VCCHKact:INSIDE Attachments.");fflush(stdout);
			//DMLtsk_tag=taskAttachments[i];

			DMLRevTag=taskAttachments[i];

			printf("\n tm_VCCHKact:INSIDE not null tag.");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="VCCHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_VCCHKact Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sVCInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sVCInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sVCInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sVCInfo4));
					printf("\n L1:sVCInfo1 is : [%s]  L2:sVCInfo2 is : [%s]  L3:sVCInfo3 is : [%s] L4:sVCInfo4 is : [%s]\n",sVCInfo1,sVCInfo2,sVCInfo3,sVCInfo4);fflush(stdout);

					if(tc_strstr(sVCInfo1,"VC1") != NULL)
					{
					    return 0;
					}
					if(tc_strstr(sVCInfo1,"VC2") == NULL)
					{
						//ITK_CALL(ITEM_ask_latest_rev(DMLtsk_tag,&DMLtaskRevTag));
						//printf("\n DML task tag is not null ");

						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_VCCHKact objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n tm_VCCHKact object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&objType));
						    printf("\n tm_VCCHKact item_id is %s\n", objType);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_VCCHKact--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
							   printf("\n tm_VCCHKact--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\n  tm_VCCHKact :t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
								printf("\n  tm_VCCHKact:sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

								DR2_flag =0;
								if(tc_strstr(sVCInfo1,"VC3") == NULL)
								{
									if(tc_strcmp(DMLtype,"Veh")==0)
									{
										if(tc_strstr(sVCInfo1,"VC4") == NULL)
										{
											if((tc_strcmp(sDMLDR,"DR0")==0) || (tc_strcmp(sDMLDR,"AR0")==0))
											{
												printf("\n tm_VCCHKact inside for condition");fflush(stdout);
												printf("\n tm_VCCHKact DR2_flag is %d",DR2_flag);fflush(stdout);
												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n tm_VCCHKact 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];
													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n tm_VCCHKact P60:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{
														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n tm_VCCHKact DML DR from-to status is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(AOM_ask_value_tags(TskTags1,"CMHasSolutionItem",&prtcnt,&PrtsTag));
															printf("\n tm_VCCHKact P61:Now prtcnt:%d.",prtcnt);fflush(stdout);

															if (prtcnt>0)
															{
																for (k=0; k<prtcnt; k++)
																{
																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n tm_VCCHKact partid = %s \n",partid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n tm_VCCHKact parttype = %s \n",parttype);fflush(stdout);

																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"item_revision_id",&revid));
																	printf("\n tm_VCCHKact revid = %s \n",revid);fflush(stdout);

																	if (tc_strstr(revid,"NR")!=NULL)
																	{
																		printf("\n tm_VCCHKact revid11111111= %s \n",revid);fflush(stdout);
																		return 0;
																	}
																	else
																	{
																		printf("\n tm_VCCHKact revid222222222= %s \n",revid);fflush(stdout);
																		return 1;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_VCCHKact Function end...");fflush(stdout);
	TC_write_syslog("\n tm_VCCHKact Function end...");
	return 1;
}