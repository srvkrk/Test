/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Awari Vishal 
*  Module               :   Workflow Action Handler to generate impact analysis report
*  Code                 :   CM_ImpactAnalysisReport.c
*  Created on                   :   Feb 1st, 2019
* Modification History :
* S.No    Date              CR No         Modified By           Modification Notes
   1      3  jun 19 	   CR-FY19-0122     Vishal Awari			1) Added Ip Address Check  
   2      11 Jun 19                         Vishal                  2) /home/cmitest/TC_ROOT_10/bin/tml_tools added 
   3      13 Jun 19                         Vishal                  3) cmitest Server IP Changed to 22
   4      16 July 19                         Vishal Awari            4) Change the report Generation to task level
 

***************************************************************************/


#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>
//#include "TMLLibrary_server_exits.h"

//#include "tm_apl_std_common_function.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;
int F_OK=0;


#define ITK_CALL(X)	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

int CM_APLImpactAnalysisReport(EPM_action_message_t msg)
{
        int i=0,j=0,k=0,kl=0,status=ITK_ok;
        int found,Dcrcnt = 0;
        int ifail=0;
        int Itemscnt=0;
        int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
        int DcrItemscnt=0;
        int attachmentCount=0,qryRetCnt=0;
        int    n_bom_views=0;
        int    bom_view_index=0;
        int    noAttachment=0;

        char *obj_type=NULL;
        char*                   FileDown                                =NULL;
        char*                   filename                                =NULL;
        char *dmlNumber=NULL;
        char *revId=NULL;
        char **qryEntries=NULL;
        char **qryValues=NULL;
        char *dmlProjID=NULL;
        char *DMLDRstatus=NULL;
        char *dmlRelType=NULL;
        char *usrInfo1=NULL;
        char *usrInfo2=NULL;
        char *ItemNumber=NULL;
        char *ItemNumberwithDml=NULL;
        tag_t msWordType=NULLTAG;
        tag_t wordDataset=NULLTAG;
        tag_t wordLatestDat_t=NULLTAG;

    tag_t  rev=NULLTAG;
    tag_t  rev1=NULLTAG;
        tag_t  view_type= NULLTAG;
        tag_t  rootTask_t=NULLTAG;
        tag_t  primary1=NULLTAG;
        tag_t  ItemObj = NULLTAG;
        tag_t  DcrItemObj=NULLTAG;
        tag_t  ctrlObjQry=NULLTAG;
        tag_t  implemRelationType_t  =NULLTAG;
        tag_t  DcrProblmItemsRelType =NULLTAG;
        tag_t  DmlTaskRelationType_t =NULLTAG;
        tag_t  DmlItemsRelation_t	 =NULLTAG;
		tag_t  relation_type_task      = NULLTAG;
		
        tag_t  *taskAttachments		 =NULLTAG;
		tag_t  *DMLRevisionTags	     =NULLTAG;
        tag_t  *qryResults=NULLTAG;
        tag_t  *DcrList=NULLTAG;
        tag_t  *taskList=NULLTAG;
        tag_t  *ItemsList=NULLTAG;
        tag_t  *DcrItemsList=NULLTAG;
        tag_t *bom_views=NULL;
        tag_t  bom_view_type=NULLTAG;
        tag_t  item=NULLTAG;
        tag_t  bom_view= NULLTAG;

        char        *ItemId                 = NULL;
        char        *RevId                  = NULL;
        char        *VCItemId                 = NULL;
        char        *SVRType                  = NULL;
        FILE        *fd;
	    int     PltFrmPartFlg          =  0;





        tag_t   e_block=NULLTAG;
        tag_t DMLTag = NULLTAG;
        tag_t   bom_window=NULLTAG;
        tag_t   window2=NULLTAG;
        tag_t   top_line=NULLTAG;
        tag_t   top_line1=NULLTAG;
        tag_t   rule    =NULLTAG;
        tag_t   Childobject=NULLTAG;
        tag_t   Childobject1=NULLTAG;
        tag_t   Childobject3=NULLTAG;
        tag_t   Childobject4=NULLTAG;
        tag_t   Childobject33=NULLTAG;
        tag_t                   dataset                                                                 = NULLTAG;
        int     n_saved_variant_rules=0;
        tag_t  *saved_variant_rules=NULLTAG;
        tag_t   bom_variant_rule=NULLTAG;
        logical list_changed=FALSE;
        int     n_options=0;
        int     errorflag=0;
        int     errorflag4=0;
        int     errorflag1=0;
        int     errorflag2=0;
        int     errorflag34=0;
        tag_t  *options=NULL;
        char   *v2_text=NULL;
        //tag_t  *option_revs=NULL;
        int     option_value_index=-1;
        tag_t   option1=NULLTAG;
        tag_t  *option1_rev=NULL;
        int    *option1_value_index=NULL;
        tag_t   option2=NULLTAG;
        tag_t  *option2_rev=NULL;
        int    *option2_value_index=NULL;
        int     inx, jnx, knx;
        int     n_option_data=0,p1=0;
        tag_t topline = NULLTAG;
        void  **option_data=NULL;

        logical invalid_option_value_combination=TRUE;
        logical soft_abort=FALSE;
        logical option_excl=FALSE;
        int     n_ves_2_save=0;
        int     n_lines2=0;
        int     n_lines3=0;
        int     n_lines4=0;
        int rulefound= 0;
        int     p2=0;
        int     ss=0;
        int     p36=0;
        char **rulename = NULL;
    char **rulevalue = NULL;
        char *desc = NULL;
        char *varrul = NULL;
         tag_t  *option_revs=NULL;
        char *CurrentRelStatus = NULL;
        tag_t dml_Ref_Rel       = NULLTAG;
        tag_t dml_Ref_Rel_t     = NULLTAG;
        int     p4=0;
        tag_t  *ves_2_save=NULL;
        tag_t   toggle_ve=NULLTAG;
        int n_lines,n_lines1,Item_ID = 0;
        tag_t *lines = NULL;
        tag_t *lines2 = NULL;
        tag_t *lines3 = NULL;
        tag_t *lines4 = NULL;
        tag_t *Newlines = NULL;
        char *Item_ID_str=NULL;
        tag_t                   relation_type                                                   = NULLTAG;
        tag_t                   relation_type1                                                  = NULLTAG;
        char                    relation_name[TCTYPE_name_size_c+1];
        char *child_item_id=NULL;
        char *child_item_id1=NULL;
        char *child_item_id15=NULL;
        char *child_item_revision_id=NULL;
        char *child_item_id_new=NULL;
        tag_t *closurerule = NULL;
        char *child_bl_formula=NULL;
        tag_t   objTypeTag=NULLTAG;
        char *child_bl_formula23=NULL;
                int IntAtr5=0;
        char *objecttype=NULL;
                char   *TempVal                 =NULL;
                tag_t close_tag;
        char *objectname=NULL;
        char *childsvrname=NULL;
		char docFile[100];
        logical modB=FALSE;
        int structcount=0;
        char   type_name2[TCTYPE_name_size_c+1];
        char   type_name[TCTYPE_name_size_c+1];
        char   type_name1[TCTYPE_name_size_c+1];
        char *tempmat=NULL;
		char command[512];
        char MulModule[1900] = { 0 };
        char MulChild[1900] = { 0 };
        int p34=0;
        int p3=0;
		int count_dml=0;
        //char *MulModule= NULL;
        char Fresh[1900];
        char NoModule[1900];
        char RevMisMatch[900];
		char ip_address[15];
        struct modstruct
		 {
				   //part details

						char parent_part[100];
						int child;

		 } childstr[10000];

FileDown = (char *) MEM_alloc (sizeof (char) * 128);
TempVal = (char *) MEM_alloc (sizeof (char) * 128);
filename = (char *) MEM_alloc (sizeof (char) * 128);

			

			
			
		find_ip_address(ip_address);	
		
		printf("Current IP Address is %s",ip_address);

        ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
        ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
		//ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&count_dml,&DMLRevisionTags));
		
        //ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
        ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
        ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
        ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
        //ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
		
		//Commented by Vishal For UA1.47 TZ

		/*
		if(count_dml>0)
		{	
			
			GRM_find_relation_type("T5_DMLTaskRelation",&relation_type_task);
			GRM_list_secondary_objects_only(DMLRevisionTags[0],relation_type_task,&attachmentCount,&taskAttachments);
			
        }	
        else{
			
			printf("\n DML Does not contains Task"); fflush(stdout);
			
			return ITK_ok;
		}		
		
		*/

	printf(" \n Total Task Found in DML  = %d \n",attachmentCount);fflush(stdout);

        for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
        {
                ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
                printf("Object Type = %s\n",obj_type);fflush(stdout);
                if(tc_strcasecmp(obj_type,"T5_APLTaskRevision")==0)
                {
                        //ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
                        //ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
                        //ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));


                                        if(DcrProblmItemsRelType != NULLTAG)
                                        {
                                                ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));
                                             
											 
											   // Get Variant From task 
                                                for(i=0;i<Dcrcnt;i++)
                                                {
                                                  printf("\n to find impacted items\n");fflush(stdout);
                                                  rev1 = DcrList[i];
                                                          if(AOM_ask_value_string(rev1,"object_type",&objecttype));
                                                          if(AOM_ask_value_string(rev1,"object_name",&objectname));
                                                          printf("Object Type in loop = %s\n",objecttype);fflush(stdout);
                                                          if (tc_strcmp(objecttype,"VariantRule")==0)
                                                        {
                                                                  tc_strcpy(TempVal,objectname);
                                                                  primary1=rev1;

                                                                        tc_strcpy(FileDown,"/tmp/");
																		tc_strcat(FileDown,TempVal);
                                                                        tc_strcat(FileDown,"_BomCompare.csv");

                                                                        fd=fopen(FileDown,"w");
                                                                        if(fd==NULL)
                                                                        {
                                                                                printf("\nError in opening the file \n");fflush(stdout);
                                                                        }
                                                                        fprintf(fd,"\n,Super SVR Name ==> %s\n\n",TempVal);

																		tc_strcpy(docFile,"");
																		tc_strcat(docFile,"/tmp/");
																		tc_strcat(docFile,TempVal);
																		tc_strcat(docFile,"_ImpactAnalysis.csv");
																		
																		TC_write_syslog("Doc File = %s\n",docFile);

                                                        }
                                                }

										
										
										//Get Platform from Task
										
									   for(j=0;j<Dcrcnt;j++)
											{
												  
												  
												  
												  printf("\n to find impacted items\n");fflush(stdout);
												  rev = DcrList[j];
												  if(AOM_ask_value_string(rev,"object_type",&objecttype));
												  if(AOM_ask_value_string(rev,"object_name",&objectname));


									                //if(AOM_ask_value_string(rev,"object_type",&objecttype));


												if (strcmp(objecttype,"T5_PlatformRevision")==0)
												{
													   printf( "\n INside platform\n"); fflush(stdout);

														if ( rev !=NULLTAG )
														{
																if ( PS_find_view_type( "view", &view_type ));
																printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

																if ( view_type != NULLTAG )
																{
																		if ( ITEM_ask_item_of_rev( rev, &item ));
																		if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

																		bom_view = bom_views[0];
																}
																else
																printf("\nView not found check.......\n"); fflush(stdout);
														}

										    	    if ( bom_view != NULLTAG )
												       {
															printf(" before BOM_create_window..\n");        fflush(stdout);
															if ( BOM_create_window( &bom_window ));
															//if(CFM_find( "ERC release and above", &rule ))
															if(CFM_find( "ERC release and above", &rule ));
															if(BOM_set_window_config_rule( bom_window, rule ));


															//if(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
															
															
															if(PIE_find_closure_rules( "BOMLineskipforunconfiguredAPLC",PIE_TEAMCENTER, &rulefound, &closurerule ));
															
															printf ("rule count %d \n",rulefound);fflush(stdout);
															 if (rulefound > 0)
															 {
																							close_tag = closurerule[0];
																							printf ("closure rule found \n");fflush(stdout);
																					   // MEM_free(tags_found);
															 }
															 if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

															if(BOM_set_window_pack_all(bom_window, TRUE));
															if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
															printf( " After BOM_set_window_top_line..\n");fflush(stdout);

															if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
															printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);

															//ITK ( ITEM_ask_rev_variants ( rev, &e_block ) )

															if(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
															if(TCTYPE_ask_name(objTypeTag,type_name));


													//      if(AOM_UIF_ask_value(primary1,"expression_block",&rulename));
													//      fprintf( stderr, " BOM_window_ask_variant_rule..%s\n",rulename);

															if ( ITEM_ask_rev_variants ( rev, &e_block ));
															printf(  " ITEM_ask_rev_variants..\n");fflush(stdout);






															// start

															//if(CFM_find( "ERC release and above", &rule ));
															//if(CFM_find( "Latest Working", &rule ))
															//if(BOM_set_window_config_rule( bom_window, rule ));


												if ( top_line!=NULLTAG )
													{



														fprintf( stderr, "\n print Master second .\n");

														if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
														printf("\n before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
														if(bom_window != NULLTAG)
														{
																printf("\n before inside bom_window-----\n"); fflush(stdout);
																if(BOM_window_hide_unconfigured(bom_window))   ;
																if(BOM_window_show_variants(bom_window))   ;


															if(DmlTaskRelationType_t != NULLTAG)

																	ITK_CALL(GRM_list_secondary_objects_only(primary1,DmlTaskRelationType_t,&ItmCnt,&taskList));

																	tc_strcpy(MulModule,"");
																	tc_strcpy(NoModule,"");
																	tc_strcpy(RevMisMatch,"");

																	for(k=0;k<ItmCnt;k++)
																	{
																	  
																	  
																			  printf("\n to find impacted items\n");fflush(stdout);
																			  ItemObj = taskList[k];
																			  if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));

																			  fprintf(fd,"\t");

																			  fprintf(fd,childsvrname);
																			  fprintf(fd,",");
																			   fprintf(fd,"\t");
																															

                                                                                printf("\n After inside bom_window-----\n"); fflush(stdout);
                                                                               // if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
                                                                                if(BOM_window_apply_variant_configuration(bom_window,1,&primary1))   ;
                                                                                printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

                                                                                //if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
                                                                                if(BOM_window_hide_variants(bom_window))   ;
                                                                                if(BOM_window_ask_is_modified(bom_window,&modB))   ;
                                                                                if(modB)
                                                                                {
                                                                                        fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
                                                                                }
                                                                                else
                                                                                {
                                                                                        fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
                                                                                }

                                                                                if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));



                                                                                printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

                                                                                printf("\n.....mulmodule is start..%s\n",MulModule);fflush(stdout);

                                                                                //EMH_clear_errors();

                                                                                if (n_lines1 >0)
                                                                                {
                                                                                        //MulModule = (char *)MEM_alloc (1024 * sizeof(char));

                                                                                        for (p3=0;p3<n_lines1 ;p3++ )
                                                                                        {
                                                                                                if(Childobject1) Childobject1=NULLTAG;
                                                                                                Childobject1=lines[p3];
                                                                                                if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
                                                                                                //fprintf( stderr, " child_item_id ..:%s\n",child_item_id);



                                                                                                if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

                                                                                                fprintf( stderr, " child_item_no ..:%d\n",n_lines3);fflush(stdout);



																								if (n_lines3 >0)
																								{

																										for (p34=0;p34<n_lines3 ;p34++ )
																										{
																											if(Childobject33) Childobject33=NULLTAG;
																											Childobject33=lines3[p34];
																											if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
																											if(AOM_ask_value_string(Childobject33, "bl_rev_item_revision_id", &child_item_revision_id ));

																											fprintf(fd,"\t");
																											fprintf(fd,child_item_id15);
																											fprintf(fd,"/");
																											fprintf(fd,child_item_revision_id);
																											fprintf(fd,",");
																											//fprintf(fd,"\t");


																										}
																								}


                                                                                        }

                                                                                        fprintf(fd,"\n");
                                                                                }
                                                                     }

														 if (fd)
															{
																	fclose(fd);
															}


                                         // for getting child SVR information
										 FILE *ff [ ItmCnt ] ;
										 PltFrmPartFlg=0;

										 for(kl=0;kl<ItmCnt;kl++)
                                                 {
											             
                                                         printf("\n to find impacted items\n");fflush(stdout);

														 //char filename [ 100 ] ;
                                                         ItemObj = taskList[kl];
                                                         if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));

														  tc_strcpy(filename,"/tmp/");
																		tc_strcat(filename,childsvrname);
                                                                        tc_strcat(filename,"_Module.csv");

                                                                        ff [kl]=fopen(filename,"w");
                                                                        if(ff [kl]==NULL)
                                                                        {
                                                                                printf("\nError in opening the file \n");fflush(stdout);
                                                                        }
                                     
	                                  				//	  fprintf(ff [kl],"\n");
                                     
                                                    //     fprintf(ff [kl],childsvrname);
                                                     //                          fprintf(ff [kl],"\n");

													 fprintf(ff [kl],"\n,Child SVR Name ==>%s\n",childsvrname);
                                                                               //fprintf(fd,"\n");
                                     
                                     
                                     
													 
													 
													   printf("\n After inside bom_window-----\n"); fflush(stdout);
													  // if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
													   if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
													   printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
													 
													   //if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
													   if(BOM_window_hide_variants(bom_window))   ;
													   if(BOM_window_ask_is_modified(bom_window,&modB))   ;
													   if(modB)
													   {
															   fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
													   }
													   else
													   {
															   fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
													   }
													 
													   if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
													 
													 
													 
													   printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);
													 
													   printf("\n.....mulmodule is start..%s\n",MulModule);fflush(stdout);
													 
													   //EMH_clear_errors();
													 
													   if (n_lines1 >0)
													   {
															   //MulModule = (char *)MEM_alloc (1024 * sizeof(char));
													 
																for (p3=0;p3<n_lines1 ;p3++ )
																	{
																	   
																		if(Childobject1) Childobject1=NULLTAG;
																		Childobject1=lines[p3];
																		if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																	   //fprintf( stderr, " child_item_id ..:%s\n",child_item_id);
													 
													 
													 
																		 if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));
													 
																		 fprintf( stderr, " child_item_no ..:%d\n",n_lines3);fflush(stdout);
													 
													 
										 
																		   if (n_lines3 >0)
																		   {
										 
																				   for (p34=0;p34<n_lines3 ;p34++ )
																				   {
																					   if(Childobject33) Childobject33=NULLTAG;
																					   Childobject33=lines3[p34];
																					   if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
											 
																					   fprintf(ff [kl],"\n");
																					   fprintf(ff [kl],child_item_id15);
																					  // fprintf(ff [kl],",");
																					   //fprintf(fd,"\t");
											 
										 
																				   }
																			}
													 
													 
																	 }
																 
																 fprintf(ff [kl],"\n");
																		   
														}
														   fclose ( ff [kl]) ;
														   PltFrmPartFlg++;
																   
																   
															 //Edited by Vishal  for UA1.47 TZ			   
													 sprintf(command,"$TC_ROOT/bin/tml_tools/ClusterSVRImpact.sh %s %s",FileDown,filename,ItmCnt,PltFrmPartFlg);			   
													
												  /*
													   if(tc_strcmp(ip_address,"172.22.97.94")==0)
														{
															printf("\n EXECUTING 172.22.97.94 Shell"); fflush(stdout);
														    sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/ClusterSVRImpact.sh %s %s",FileDown,filename,ItmCnt,PltFrmPartFlg);
														}
														else if(tc_strcmp(ip_address,"172.22.97.22")==0)
														{
															 
															printf("\n EXECUTING 172.22.97.22 Shell");  fflush(stdout);
															sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/ClusterSVRImpact.sh %s %s",FileDown,filename,ItmCnt,PltFrmPartFlg);													 
														
														}
														else{
															
															 printf("\n EXECUTING uaprod shell Script");  fflush(stdout);
															sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/ClusterSVRImpact.sh  %s %s",FileDown,filename,ItmCnt,PltFrmPartFlg);
														}
															
													*/														
													   TC_write_syslog("Command = %s\n",command);
													   system(command);
                                                }
                                     
	                                  					// child SVR info finish
                                                   
                                                       //ITK ( VOO_show_wso( Childobject ));
                                              }

											else
											{
													fprintf( stderr, "\n no bom window found here \n");
											}

												//break;
                                          }
                                     }
                                }
                          }

                    }
					
					
					
                   //if(access(docFile,F_OK)!=-1)
			            //{
				                printf("\n KKKKKK\n");fflush(stdout);
                                if(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel)!=ITK_ok);
                                printf("\n LLLLLLLL\n");fflush(stdout);
                                TC_write_syslog("Doc file created successfully\n");
                                //if(AE_find_datasettype2("MSWord",&msWordType)!=ITK_ok);
                                //if(AE_find_datasettype2("Text",&msWordType)!=ITK_ok);
                                //if(AE_find_datasettype2("MS Excel",&msWordType)!=ITK_ok);
                                if(AE_find_datasettype2("MSExcel",&msWordType)!=ITK_ok);
                                printf("\n MMMMMMMMMM\n");fflush(stdout);
                                if(msWordType == NULLTAG)
                                {
                                        printf("\n NNNNNNNNNN\n");fflush(stdout);
                                        TC_write_syslog("Could not find Dataset Type Text. Please check data model\n");
                                        //continue;
                                }

                                if(AE_create_dataset_with_id(msWordType,TempVal,"Impact Analysis for SuperSVR","","",&wordDataset)!=ITK_ok);
                                printf("\n AAAAAAAAA\n");fflush(stdout);
                                if(AE_save_myself(wordDataset));
                                printf("\n BBBBBBBBB\n");fflush(stdout);
                                if(GRM_create_relation(taskAttachments[Itemscnt],wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t)!=ITK_ok);
                                printf("\n CCCCCCC\n");fflush(stdout);
                                if(AOM_load(dml_Ref_Rel_t)!=ITK_ok);
                                printf("\n DDDDD\n");fflush(stdout);
                                if(GRM_save_relation(dml_Ref_Rel_t)!=ITK_ok);
                                printf("\n EEEEEE\n");fflush(stdout);
                                if(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
                                printf("\n FFFFFF\n");fflush(stdout);
                                if(AOM_refresh(wordLatestDat_t,TRUE)!=ITK_ok);
                                printf("\n GGGGG\n");fflush(stdout);
                                //if(AE_import_named_ref(wordLatestDat_t,"word",FileDown,NULL,SS_BINARY)!=ITK_ok);
                                if(AE_import_named_ref(wordLatestDat_t,"excel",docFile,NULL,SS_BINARY)!=ITK_ok);
                                //if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok);
                                printf("\n HHHHH\n");fflush(stdout);
                                if(AE_save_myself(wordLatestDat_t)!=ITK_ok);
                                printf("\n IIIII\n");fflush(stdout);
                                remove(docFile);
                                printf("\n JJJJJ\n");fflush(stdout);
                               // if(docFile) MEM_free(docFile);
			          //}
					
					
								
					
                }

       }
  
         
        return ITK_ok;

}


int find_ip_address(char *ip_addressCpy) 
{  
    
	
	printf(" Inside Get System IP Address find_ip_address Function ");
     
	unsigned char ip_address[15];
    int fd;
    struct ifreq ifr;
     
    /*AF_INET - to define network interface IPv4*/
    /*Creating soket for it.*/
    fd = socket(AF_INET, SOCK_DGRAM, 0);
     
    /*AF_INET - to define IPv4 Address type.*/
    ifr.ifr_addr.sa_family = AF_INET;
     
    /*eth0 - define the ifr_name - port name
    where network attached.*/
    memcpy(ifr.ifr_name, "eth0", IFNAMSIZ-1);
     
    /*Accessing network interface information by
    passing address using ioctl.*/
    ioctl(fd, SIOCGIFADDR, &ifr);
    /*closing fd*/
    close(fd);
     
    /*Extract IP Address*/
    strcpy(ip_address,inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
     
    printf("System IP Address is: %s\n",ip_address);
	
	tc_strcpy(ip_addressCpy,ip_address);
	
	
     
    return 0;
}


extern int tm_AplImpactAnalysisReport_custom_exit(int *decision, va_list args)
{
	
		METHOD_id_t  method1;
		METHOD_id_t  method2;
		int ifail=0;
	    *decision = ALL_CUSTOMIZATIONS ;
		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		tag_t objTag = va_arg(args, tag_t);
		tag_t objTypeTag=NULLTAG;
		
		 if( ITK_ok == EPM_register_action_handler("CM_APLImpactAnalysisReport", "", CM_APLImpactAnalysisReport))
		   {
				printf("\t\n Registered Action Handler APL Impact Analysis Report \n");fflush(stdout);
				
		   }else
		   {
				printf("\t FAILED to register Action Handler apl_user_assign_register_method\n");fflush(stdout);
		   }
				
		
	return ITK_ok;
	
}



extern DLLAPI int tm_AplImpactAnalysisReport_register_callbacks()
{
        CUSTOM_register_exit ("tm_AplImpactAnalysisReport","USER_init_module",(CUSTOM_EXIT_ftn_t) tm_AplImpactAnalysisReport_custom_exit);

        return(ITK_ok);
}

