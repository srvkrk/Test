#include "TMLLibrary_server_exits.h"

#define DRCHK_err 919002

EPM_decision_t tm_DRGatewayChk(EPM_rule_message_t msg)
{
    int seccount         =0;
    int i                =0;
    int j                =0;
    int DRGatewayFlag    =0;
    int no_attach        =0;
    int DR_rsltCount     =0;
    int countt           =0;
	int DR_n_entry       =1;
	int vehtypeflag       =1;
	int prtcount       =0;
	int k       =0;
    tag_t DMLTag            = NULLTAG;
    tag_t DMLRevTag         = NULLTAG;
    tag_t rel_type          = NULLTAG;
	tag_t roottask          =  NULLTAG;
	tag_t objTypTag         =  NULLTAG;
	tag_t DRqryTag          =  NULLTAG;
	tag_t tsk_dml_rel_type  =  NULLTAG;
	tag_t DMLRevTg          =  NULLTAG;
	tag_t chreltype          =  NULLTAG;
	tag_t *secobjects       = NULLTAG;
	tag_t *taskAttachments  = NULLTAG;
	tag_t *DRCntrlObjectTag  = NULLTAG;
	tag_t *DMLRevision       = NULLTAG;
	tag_t *cmparts       = NULLTAG;
    char *drstatus    = NULL;
    char *item_id     = NULL;
    char *Chklistvar  = NULL;
    char *scopedoc    = NULL;
    char *docname     = NULL;
    char *doctype     = NULL;
	char *DMLNo       = NULL;
	char *CurrentTask = NULL;
	char *ObjTyp      = NULL;
	char *BomComInfo1 = NULL;
	char *BomComInfo2 = NULL;
	char *sDMLtaskno  = NULL;
	char *sDMLno      = NULL;
	char *rlstype      = NULL;
	char *DesgTyp      = NULL;
	char **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	logical is_latest;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	
	printf("\n tm_DRGatewayChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DRGatewayChk Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n Wt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Wt::Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Wt::Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "CHKLIST";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Wt::DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&BomComInfo1)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt:A:BomComInfo1: %s \n",BomComInfo1);fflush(stdout);
				//
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&BomComInfo2)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt:A:BomComInfo2: %s \n",BomComInfo2);fflush(stdout);
			}
			if(tc_strstr(BomComInfo1,"CHKLISTOFF")==NULL)
			{
				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					printf("\n Wt::This is for veh DML submission.\n");fflush(stdout);
					if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
					printf("\n Wt:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
					if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
					if (tsk_dml_rel_type!=NULLTAG)
					{
						if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
						printf("\n Wt:DML Revision from Task for MR : %d",countt);fflush(stdout);
						for (j=0;j<countt ;j++ )
						{
							if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
							printf("\n Wt: is_latest MR is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n Wt:is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								vehtypeflag=0;
								DMLRevTg = DMLRevision[j];
								if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
								printf("\n Wt:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);

								if(AOM_UIF_ask_value(DMLRevTg,"t5_cDRstatus",&drstatus)!=ITK_ok)PrintErrorStack();;
								printf("\n drstatus is: %s \n",drstatus);fflush(stdout);

								if(AOM_UIF_ask_value(DMLRevTg,"t5_rlstype",&rlstype)!=ITK_ok)PrintErrorStack();;
								printf("\n rlstype is: %s \n",rlstype);fflush(stdout);

								if((tc_strcmp(rlstype,"TODR")==0) || (tc_strcmp(rlstype,"Gate Maturation")==0))
								{
									ITK_CALL(GRM_find_relation_type("CMReferences",&chreltype));

									ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[i],chreltype,&prtcount,&cmparts));
									for (k=0;k<prtcount;k++ )
									{
										if (AOM_ask_value_string(cmparts[k],"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
										printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);

										if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"Vehicle")==0))
										{
											printf(" inside gate maturation DR gateway");fflush(stdout);
											vehtypeflag=1;
											printf(" vehtypeflag: [%d]\n", vehtypeflag);fflush(stdout);
											break;
										}
									}
								}
								else if ((tc_strcmp(rlstype,"Veh")==0) || (tc_strcmp(rlstype,"Vehicle Release")==0))
								{
									printf(" inside Vehicle Release DR gateway");fflush(stdout);
									vehtypeflag=1;
									printf(" vehtypeflag: [%d]\n", vehtypeflag);fflush(stdout);
									//break;
								}
								else
								{
									printf(" inside Other DMl Type DR gateway");fflush(stdout);
									vehtypeflag=0;
									printf(" vehtypeflag: [%d]\n", vehtypeflag);fflush(stdout);
									//break;
								}

								if (vehtypeflag>0)
								{
									Chklistvar = MEM_alloc(50);
									tc_strcat(Chklistvar,sDMLno);
									tc_strcat(Chklistvar,"_");
									tc_strcat(Chklistvar,drstatus);
									tc_strcat(Chklistvar,"_Gateway_Checklist");
									printf("\n Chklistvar is: %s \n",Chklistvar);fflush(stdout);

									ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
		  
									ITK_CALL(GRM_list_secondary_objects_only(DMLRevTg,rel_type,&seccount,&secobjects));

									if (seccount>0)
									{
										DRGatewayFlag = 0;
										for(i=0;i<seccount;i++)
										{
											ITK_CALL(AOM_UIF_ask_value(secobjects[i],"object_type",&doctype));
											printf("\n doctype is: %s \n",doctype);fflush(stdout);
											if (tc_strstr(doctype,"PDF")!=NULL)
											{
												ITK_CALL(AOM_UIF_ask_value(secobjects[i],"current_name",&docname));
												printf("\n docname is: %s \n",docname);fflush(stdout);
												//if ((tc_strstr(docname,Chklistvar)!=NULL)) //&& 
												if(tc_strstr(docname,Chklistvar)!=NULL)
												{
													printf("\n Gateway check list is attached... \n");fflush(stdout);
													DRGatewayFlag = 1;
													printf("\n DRGatewayFlag found",DRGatewayFlag); fflush(stdout);
													break;
												}
											}
										}
									}
									if (DRGatewayFlag == 1)
									{
										printf("\n************************ EPM_GO***************************** \n"); fflush(stdout);  
									}
									else
									{
										  printf("\n Condition 3 found"); fflush(stdout);
										  printf("\n************************ checklist is not present***************************** \n"); fflush(stdout);
										  printf("\n************************ EPM_NOGO***************************** \n"); fflush(stdout);
										  EMH_clear_errors();
										  EMH_store_error_s2(EMH_severity_error,DRCHK_err,"ERROR:Please attach DR Gateway Checklist in 'References' relation to DML in the format:",Chklistvar);
										  decision = EPM_nogo;
										  return decision;	  
									}
								}
								break;
							}
						}
					}
				}
			}
		}
	}
	
	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(BomComInfo1){MEM_free(BomComInfo1);}
	if(BomComInfo2){MEM_free(BomComInfo2);}
	if(sDMLtaskno){MEM_free(sDMLtaskno);}
	if(sDMLno){MEM_free(sDMLno);}
	if(drstatus){MEM_free(drstatus);}
	if(rlstype){MEM_free(rlstype);}
	if(doctype){MEM_free(doctype);}
	if(docname){MEM_free(docname);}*/
	printf("\n tm_DRGatewayChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_DRGatewayChk Function end...");
	return decision;
}