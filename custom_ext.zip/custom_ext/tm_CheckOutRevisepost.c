/*****************************************************************************************************
*Created By      :   Muktesh Girdhani
*  Created On      :   11-Jan-2014
*  Purpose         :   ERC Review to be Stamped on the Design Revision after Revise
*
Modified : 04-05-2016 : Modfied checkout functionality, Revise is called and Revision attribute is updated.
******************************************************************************************************/

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/releasestatus.h>
#include <tccore/aom_prop.h>

#define CLI_OPTION_BYPASS "-bypass"

#define ERROR_CALL(x)                                                                                                               \
	{                                                                                                                               \
		int stat;                                                                                                                   \
		char *err_string = NULL;                                                                                                    \
		if ((stat = (x)) != ITK_ok)                                                                                                 \
		{                                                                                                                           \
			EMH_ask_error_text(stat, &err_string);                                                                                  \
			if (err_string != NULL)                                                                                                 \
			{                                                                                                                       \
				printf("ERROR: %d ERROR MSG: %s \n", stat, err_string);                                                             \
				printf("Function: %s FILE: %s LINE: %d \n", #x, __FILE__, __LINE__);                                                \
				TC_write_syslog("FORM Property Migiration[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__); \
				MEM_free(err_string);                                                                                               \
				err_string = NULL;                                                                                                  \
			}                                                                                                                       \
			return (stat);                                                                                                          \
		}                                                                                                                           \
	}
#define ITK_CALL(X)
#define ITK_errStore 91900002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define CALLAPI(expr)      \
	ITKCALL(ifail = expr); \
	if (ifail != ITK_ok)   \
	{                      \
		PrintErrorStack(); \
		return ifail;      \
	}

char *numToASCII(int num)
{
	/*
	 * Use malloc to allocate an array in the heap, instead of using a
	 * local array. The memory space of local array will be freed after
	 * the invocation of numToASCII.
	 */
	char *string = malloc(2);
	if (!string)
		return 0;
	string[0] = num;
	string[1] = 0;
	return string;
}
static void Write_To_Log(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}

char *subString(char *mainStringf, int fromCharf, int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char *)malloc(200);
	for (i = 0; i < toCharf; i++)
		*(retStringf + i) = *(mainStringf + i + fromCharf);
	*(retStringf + i) = '\0';
	return retStringf;
};

static int PrintErrorStack(void)
/*
 *
 * PURPOSE : Function to dump the ITK error stack
 *
 * RETURN : causes program termination. If you made it here
 *          you're not coming back modified for cust.c to not call exit()
 *          but to just print the error stack
 *
 * NOTES : This version will always return ITK_ok, which is quite strange
 *           actually. But if the error reporting was "OK" then that makes
 *           sense
 *
 */
{
	int iNumErrs = 0;
	const int *pSevLst = NULL;
	const int *pErrCdeLst = NULL;
	const char **pMsgLst = NULL;
	register int i = 0;

	EMH_ask_errors(&iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst);

	fprintf(stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
	for (i = 0; i < iNumErrs; i++)
	{
		fprintf(stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
		fprintf(stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	}
	return ITK_ok;
}

int t5removeAllReleaseStatus(tag_t rev)
{

	int status_count;
	tag_t *status_list;
	int st_relList_count = 0;
	int Rel_cnt = 0;
	tag_t *relstatus_list = NULLTAG;
	char *WSO_Name_RelVal = NULL;
	tag_t tReleaseStatusList = NULLTAG;
	int n_values = 0;
	int cunt1 = 0;
	tag_t *attr_tags = NULLTAG;
	logical *is_it_null = NULL;
	logical *is_it_empty = NULL;
	tag_t class_id = NULLTAG;
	char *class_name = NULL;
	logical log1;
	int ifail = 0;

	ERROR_CALL(WSOM_ask_release_status_list(rev, &status_count, &status_list));

	printf("\n no of Status==%d\n", status_count);
	fflush(stdout);
	if (status_count > 0)
	{
		// ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");
		fflush(stdout);

		CALLAPI(POM_class_of_instance(rev, &class_id));
		CALLAPI(POM_name_of_class(class_id, &class_name));
		printf("\n class_name is :%s\n", class_name);
		fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list", class_name, &tReleaseStatusList));
		fflush(stdout);

		CALLAPI(POM_unload_instances(1, &rev));
		CALLAPI(POM_load_instances(1, &rev, class_id, 1));
		CALLAPI(POM_is_loaded(rev, &log1));
		if (log1 == 1)
		{
			printf(" Load Success\n ");
		}
		else
			printf("Load Failure\n");

		CALLAPI(POM_length_of_attr(rev, tReleaseStatusList, &n_values));
		printf("\n n_values is :%d\n", n_values);
		fflush(stdout);
		if (n_values > 0)
		{
			CALLAPI(POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty));
			printf("\n n_values11 is :%d\n", n_values);
			fflush(stdout);

			for (cunt1 = 0; cunt1 < n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n", cunt1);
				fflush(stdout);

				CALLAPI(POM_remove_from_attr(1, &rev, tReleaseStatusList, 0, 1));
				printf("\n cunt1 == 0 removedd is :%d\n", cunt1);
				fflush(stdout);

				CALLAPI(POM_save_instances(1, &rev, 1));

				CALLAPI(POM_refresh_instances(1, &rev, class_id, 2));

				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save_without_extensions(rev));
				CALLAPI(AOM_refresh(rev, 1));
			}

			CALLAPI(AOM_unlock(rev));
		}
		printf("\n Status removed");
		fflush(stdout);
	}
	/*ERROR_CALL (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
	ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));
	//ERROR_CALL(ITK_set_bypass(TRUE));

	ERROR_CALL(AOM_refresh(rev,1));
	ERROR_CALL(AOM_save_without_extensions(rev));
*/
	ERROR_CALL(AOM_unlock(rev));

	return 0;
}

// MBOM implementation for CV TZ-1.69  Start
void get_CtrlVal_RelStateInfoRev(char *Plt_Code, char RevwLC[40], char RevwLCActVal[40], char WrkngLC[40], char WrkngLCActVal[40], char RlzdLC[40], char RlzdLCActVal[40], char StdWrkLC[40], char StdWrkLCActVal[40], char StdRlzdLC[40], char StdRlzdLCActVal[40], char View[40])
{
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));

	int cntrlcnt = 0;
	int control_number_found1 = 0;

	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	tag_t qryTagCntrl1 = NULLTAG;
	int n_entryCntrl1 = 3;
	char *RevwVal = NULL;
	char *WrkngVal = NULL;
	char *RlzdVal = NULL;
	char *BvrVal = NULL;
	char *RevwActVal = NULL;
	char *RlzdActVal = NULL;
	char *WrkngActVal = NULL;
	char *StdRlzdActVal = NULL;
	char *StdWrkActVal = NULL;
	char *stdRlzdVal = NULL;
	char *stdWrkVal = NULL;
	char *stdWrkVal1 = NULL;
	char *stdRlzdVal1 = NULL;

	printf("\n Inside get_CtrlVal_RelStateInfoRev Plt_Code:%s", Plt_Code);
	fflush(stdout);

	if (QRY_find2("Control Objects...", &qryTagCntrl1))
		;
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");
		fflush(stdout);
		qry_valuesCntrl1[0] = "ReleaseStateInf";
		qry_valuesCntrl1[1] = Plt_Code;
		qry_valuesCntrl1[2] = "0";

		if (QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1))
			;
	}
	else
	{
		printf("\n Control Object Query not Found \n");
		fflush(stdout);
	}

	printf("\n control_number_found1 is : %d\n", control_number_found1);
	fflush(stdout);

	if (control_number_found1 > 0)
	{
		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevwVal) != ITK_ok)
			PrintErrorStack();
		printf("\n RevwVal: %s\n", RevwVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &WrkngVal) != ITK_ok)
			PrintErrorStack();
		printf("\n WrkngVal: %s\n", WrkngVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &RlzdVal) != ITK_ok)
			PrintErrorStack();
		printf("\n RlzdVal: %s\n", RlzdVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &BvrVal) != ITK_ok)
			PrintErrorStack();
		printf("\n BvrVal: %s\n", BvrVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &RevwActVal) != ITK_ok)
			PrintErrorStack();
		printf("\n RevwActVal: %s\n", RevwActVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &WrkngActVal) != ITK_ok)
			PrintErrorStack();
		printf("\n WrkngActVal: %s\n", WrkngActVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &RlzdActVal) != ITK_ok)
			PrintErrorStack();
		printf("\n RlzdActVal: %s\n", RlzdActVal);
		fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &StdWrkActVal) != ITK_ok)PrintErrorStack();
		printf("\n StdWrkActVal: %s\n", StdWrkActVal);fflush(stdout);

		if (AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &StdRlzdActVal) != ITK_ok)PrintErrorStack();
		printf("\n StdRlzdActVal: %s\n", StdRlzdActVal);fflush(stdout);

		if (tc_strlen(RevwVal) > 0)
		{
			tc_strcpy(RevwLC, RevwVal);
		}
		if (tc_strlen(WrkngVal) > 0)
		{
			tc_strcpy(WrkngLC, WrkngVal);
		}
		if (tc_strlen(RlzdVal) > 0)
		{
			tc_strcpy(RlzdLC, RlzdVal);
		}
		if (tc_strlen(BvrVal) > 0)
		{
			tc_strcpy(View, BvrVal);
		}
		if (tc_strlen(RevwActVal) > 0)
		{
			tc_strcpy(RevwLCActVal, RevwActVal);
		}
		if (tc_strlen(WrkngActVal) > 0)
		{
			tc_strcpy(WrkngLCActVal, WrkngActVal);
		}
		if (tc_strlen(RlzdActVal) > 0)
		{
			tc_strcpy(RlzdLCActVal, RlzdActVal);
		}
		if (tc_strlen(StdWrkActVal) > 0)
		{
			printf("\n StdWrkActVal:%s", StdWrkActVal);fflush(stdout);

			if (tc_strstr(StdWrkActVal, "/") != NULL)
			{
				stdWrkVal = strtok(StdWrkActVal, "/");
				stdWrkVal1 = strtok(NULL, "/");

				tc_strcpy(StdWrkLC, stdWrkVal);
				tc_strcpy(StdWrkLCActVal, stdWrkVal1);

				printf("\n StdWrkLC:%s,StdWrkLCActVal:%s,stdWrkVal:%s,stdWrkVal1:%s", StdWrkLC, StdWrkLCActVal, stdWrkVal, stdWrkVal1);	fflush(stdout);
			}
			else
			{
				tc_strcpy(StdWrkLC, "-");
				tc_strcpy(StdWrkLCActVal, "-");
				printf("\n Inside else StdWrkLC:%s,StdWrkLCActVal:%s", StdWrkLC, StdWrkLCActVal);
				fflush(stdout);
			}
		}
		if (tc_strlen(StdRlzdActVal) > 0)
		{
			if (tc_strstr(StdRlzdActVal, "/") != NULL)
			{
				stdRlzdVal = strtok(StdRlzdActVal, "/");
				stdRlzdVal1 = strtok(NULL, "/");

				tc_strcpy(StdRlzdLC, stdRlzdVal);
				tc_strcpy(StdRlzdLCActVal, stdRlzdVal1);

				printf("\n stdRlzdVal:%s,stdRlzdVal1:%s,StdRlzdLC:%s,StdRlzdLCActVal:%s", stdRlzdVal, stdRlzdVal1, StdRlzdLC, StdRlzdLCActVal);
				fflush(stdout);
			}
			else
			{
				tc_strcpy(StdRlzdLC, "-");
				tc_strcpy(StdRlzdLCActVal, "-");
			}

			printf("\n StdRlzdLC:%s,StdRlzdLCActVal:%s", StdRlzdLC, StdRlzdLCActVal);
			fflush(stdout);
		}
		printf("\n Inside get_CtrlVal_RelStateInfoRev StdWrkLC:%s,StdWrkLCActVal:%s,StdRlzdLC:%s,StdRlzdLCActVal:%s", StdWrkLC, StdWrkLCActVal, StdRlzdLC, StdRlzdLCActVal);
		fflush(stdout);
	}
}
// MBOM implementation for CV TZ-1.69  End

extern DLLAPI int Checkout_Pre_action(METHOD_message_t *m, va_list args)
{
	int ifail = 0;
	int status;
	int n_entry = 1;
	int rsltCount = 0;
	int SpecCount = 0;
	int ii = 0;
	int n_attchsGen = 0;
	int j = 0;

	logical checkout = 0;

	char *checkout_info6 = NULL;
	char *qry_entry[1] = {"SYSCD"};
	char **qry_values2 = (char **)MEM_alloc(10 * sizeof(char *));

	tag_t source_rev = va_arg(args, tag_t);

	tag_t *CntrolObjectTag = NULLTAG;
	tag_t *SpecDoc_tags = NULLTAG;
	tag_t *secondary_objectsGen = NULLTAG;

	tag_t CurrentRoleTag = NULLTAG;
	tag_t SpecRel_tag = NULLTAG;
	tag_t SecObjDSTag = NULLTAG;
	tag_t SpecTypeTag = NULLTAG;
	tag_t qryTag = NULLTAG;
	tag_t GenRelation_type = NULLTAG;
	tag_t CreoGenRev = NULLTAG;
	tag_t Itemtag = NULLTAG;
	tag_t latestGenRev = NULLTAG;

	// char roleName[SA_name_size_c+1];
	// char Spectype_name[TCTYPE_name_size_c+1];

	char *roleName = NULL;
	char *Spectype_name = NULL;

	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name2(CurrentRoleTag, &roleName));
	printf("\n\n  Checkout_Pre_action---roleName : %s\n", roleName);
	fflush(stdout);

	if (QRY_find2("ControlObjects", &qryTag))
		;
	if (qryTag)
	{
		printf("\n Checkout_Pre_action--PROASM:Found Query ControlObjects \n");
		fflush(stdout);
		qry_values2[0] = "ERCVali";
		if (QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag))
			;
		printf(" \n ERCVali:rsltCount :%d:", rsltCount);
		fflush(stdout);
		if (rsltCount > 0)
		{
			if (AOM_ask_value_string(CntrolObjectTag[0], "t5_Userinfo6", &checkout_info6) != ITK_ok)
				PrintErrorStack();
			printf("\n checkout_info6 is = [%s]\n", checkout_info6);
			fflush(stdout);
		}
	}
	else
	{
		printf("\n Checkout_Pre_action--PROASM:Not Found Query ControlObjects \n");
		fflush(stdout);
	}

	if (tc_strcmp(checkout_info6, "PreCheckOutON") == 0)
	{
		if ((tc_strstr(roleName, "APL") == NULL) && (tc_strstr(roleName, "STD") == NULL) && (tc_strstr(roleName, "MBOM") == NULL)) // ERC USer Start only//MBOM implementation for CV TZ-1.69
		{
			printf("\n\n  Checkout_Pre_action---ERC\n");
			fflush(stdout);

			CALLAPI(GRM_find_relation_type("IMAN_specification", &SpecRel_tag));

			if (GRM_list_secondary_objects_only(source_rev, SpecRel_tag, &SpecCount, &SpecDoc_tags) != ITK_ok)
				PrintErrorStack();
			printf("\n SpecCount--Attached Datasets2: %d\n", SpecCount);
			fflush(stdout);

			for (ii = 0; ii < SpecCount; ii++)
			{
				SecObjDSTag = SpecDoc_tags[ii];

				if (TCTYPE_ask_object_type(SecObjDSTag, &SpecTypeTag))
					;
				if (TCTYPE_ask_name2(SpecTypeTag, &Spectype_name))
					;
				printf("\n     Checkout_Pre_action--Spectype_name :: %s\n", Spectype_name);
				fflush(stdout);

				if ((tc_strcmp(Spectype_name, "ProAsm") == 0) || (tc_strcmp(Spectype_name, "ProPrt") == 0))
				{
					printf("\n ProAsm/ProPrt Dataset found.");
					fflush(stdout);

					CALLAPI(GRM_find_relation_type("IPEM_master_dependency", &GenRelation_type));
					// printf("\n GRM_find_relation_type IPEM_master_dependency ");fflush(stdout);

					if (GenRelation_type != NULLTAG)
					{
						if (GRM_list_secondary_objects_only(SecObjDSTag, GenRelation_type, &n_attchsGen, &secondary_objectsGen))
							;
						printf("\n\t n_attchsGen: [%d] ", n_attchsGen);
						fflush(stdout);

						if (n_attchsGen > 0)
						{
							printf("\n\t Part is an Instance and has found Generic relation...");
							fflush(stdout);
							for (j = 0; j < n_attchsGen; j++)
							{
								CreoGenRev = secondary_objectsGen[j];

								CALLAPI(RES_is_checked_out(CreoGenRev, &checkout));
								printf("\n 1--checkout status: [%d]\n", checkout);
								fflush(stdout);

								if (checkout <= 0)
								{
									checkout = 0;

									CALLAPI(ITEM_ask_item_of_rev(CreoGenRev, &Itemtag));
									CALLAPI(ITEM_ask_latest_rev(Itemtag, &latestGenRev));
									if (latestGenRev != NULLTAG)
									{
										CALLAPI(RES_is_checked_out(latestGenRev, &checkout));
										printf("\n 2--checkout status: [%d]\n", checkout);
										fflush(stdout);
										if (checkout <= 0)
										{
											EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Please Check-Out Generic of this Instance and proceed for modification.");
											return ITK_errStore1;
										}
									}
								}
							}
						}
						else
						{
							printf("\n\t Part is not a Instance ...");
							fflush(stdout);
						}
					}
					printf("\n\t Proasm validated...");
					fflush(stdout);
					break;
				}
			}
		}
	}
	printf("\n\t At the end of function  Checkout_Pre_action ....");
	fflush(stdout);
	return ITK_ok;
}

// PD // Date - 03/06/2025

extern DLLAPI int Revise_OperationFunForTechspec(METHOD_message_t *m, va_list args)
{
	printf("\n ************* Revise Operation Started on Design Revision with Revise_OperationFunForTechspec function ************* ");
	
	tag_t sourceRev = va_arg(args, tag_t);
	char *revId     = va_arg(args, char *);
	tag_t *new_rev  = va_arg(args, tag_t *);
	
	char *itemId     = NULL;
	char *objectStr  = NULL; 
	char *objectName = NULL;
	
	char *itemRevId  = NULL;
	
	char *latestItemRevId = NULL;
	
	int objCount = 0;
	int i = 0;
	
	tag_t relationTag      = NULLTAG;
	tag_t *objList         = NULLTAG;
	
	tag_t newRev           = NULLTAG;
	tag_t existingRelation = NULLTAG;
	tag_t newRelation      = NULLTAG;
	
	tag_t itemTag = NULLTAG;
	tag_t latestRevisedRev = NULLTAG;
	
	int qryObjCount;

    tag_t queryTag    = NULLTAG;
    tag_t *qryObjTags = NULLTAG;
    
    char *qryEntry[3] = {"Name","SYSCD", "SUBSYSCD"};
    char *qryValues[3] = {"ECUTPReviseOperation","ECUTPReviseOperation", "ECUTPReviseOperation"};
	
	
	AOM_ask_value_string(sourceRev,"item_id",&itemId);
	AOM_ask_value_string(sourceRev,"object_string",&objectStr);
	AOM_ask_value_string(sourceRev,"object_name",&objectName);
	
	printf("\n ****** - itemId     = %s ",itemId);
	printf("\n ****** - objectStr  = %s ",objectStr);
	printf("\n ****** - objectName = %s ",objectName);
	printf("\n ****** - revId      = %s ",revId);
	
	GRM_find_relation_type("T5_Has_ECU_Tech_Spec",&relationTag);
	GRM_list_secondary_objects_only(sourceRev,relationTag,&objCount,&objList);
	
	printf("\n ****** - objCount     = %d ",objCount);
	
	QRY_find2("Control Objects...", &queryTag);
    if(queryTag!=NULLTAG)
    {
        printf("\n Query found for Revise_OperationFunForTechspec");
    	
    	QRY_execute(queryTag,3,qryEntry,qryValues,&qryObjCount,&qryObjTags);
    	printf("\n ***************** - qryObjCount = %d",qryObjCount );
    	
    	if(qryObjCount > 0)
    	{
    	    printf("\n ****************** ECUTPReviseOperation Control Object found so revise operation started");
    	    if(objCount == 1)
	        {
	        	printf("Executing if condition where objCount ==  1"); 
	        			
	        	AOM_ask_value_string(objList[0],"item_revision_id",&itemRevId);
	        	
	        	printf("\n ****** - itemRevId     = %s ",itemRevId);
	        	
	            if(tc_strstr(itemRevId,"NR")!=NULL)
	        	{
	        		ITEM_copy_rev(objList[i],"A",&newRev);
	        		if(newRev != NULLTAG)
	        		{
	        			printf("\n ********** Revise opeation successfull on Techspec Obj with NR**********");
	        			
	        			printf("\n ITEM_find_item = %d " ,ITEM_find_item(itemId,&itemTag));
	        			if(itemTag != NULLTAG)
	        			{
	        				printf("\n ITEM_ask_latest_rev = %d ",ITEM_ask_latest_rev(itemTag,&latestRevisedRev));  
	        				
	        				AOM_ask_value_string(latestRevisedRev,"item_revision_id",&latestItemRevId);
	        				
	        				printf("\n ********** - latestItemRevId = %s ",latestItemRevId);
	        				
	        				
	        			    printf("\n GRM_find_relation = %d ",GRM_find_relation(latestRevisedRev,objList[0],relationTag,&existingRelation));
	        			    printf("\n GRM_delete_relation = %d ",GRM_delete_relation(existingRelation)); 
	        			    printf("\n GRM_create_relation = %d ",GRM_create_relation(latestRevisedRev,newRev,relationTag,NULLTAG,&newRelation));
	                        printf("\n GRM_save_relation = %d ",GRM_save_relation(newRelation));
	        			}
	        			else
	        			{
	        				printf("\n ITEMTAG Not found ");
	        			}
	        		}	
	        	}
	        	else
	        	{
	        		ITEM_copy_rev(objList[i],NULL,&newRev);
	        		if(newRev != NULLTAG)
	        		{
	        			printf("\n ********** Revise opeation successfull on Techspec Obj with NR**********");
	        			
	        			printf("\n ITEM_find_item = %d " ,ITEM_find_item(itemId,&itemTag));
	        			if(itemTag != NULLTAG)
	        			{
	        				printf("\n ITEM_ask_latest_rev = %d ",ITEM_ask_latest_rev(itemTag,&latestRevisedRev));  
	        				
	        				AOM_ask_value_string(latestRevisedRev,"item_revision_id",&latestItemRevId);
	        				
	        				printf("\n ********** - latestItemRevId = %s ",latestItemRevId);
	        				
	        			    printf("\n GRM_find_relation = %d ",GRM_find_relation(latestRevisedRev,objList[0],relationTag,&existingRelation));
	        			    printf("\n GRM_delete_relation = %d ",GRM_delete_relation(existingRelation)); 
	        			    printf("\n GRM_create_relation = %d ",GRM_create_relation(latestRevisedRev,newRev,relationTag,NULLTAG,&newRelation));
	                        printf("\n GRM_save_relation = %d ",GRM_save_relation(newRelation));
	        			}
	        			else
	        			{
	        				printf("\n ITEMTAG Not found ");
	        			}
	        		}	
	        	}	
	        }
	        else
	        {
	        	printf(" objCount == 0 or Greater than one. Executing else condition");
	        }	
		}
    	else
    	{
    	    printf("\n ****************** Error : ECUTPReviseOperation Control Object not found so revise operation Skipped");
    	}
    }
    else
    {
       printf("\n Error : Control Objects... Query not found for Revise_OperationFunForTechspec ");
    }
		
	printf("\n ************* Revise Operation Ended on Design Revision with Revise_OperationFunForTechspec function **************** ");		
	return ITK_ok;
}

extern DLLAPI int Revise_properties_post(METHOD_message_t *m, va_list args)
{
	char *ReleaseStatus = NULL;
	char *type_name = NULL;
	// char   type_name[TCTYPE_name_size_c+1];
	tag_t source_rev_Type_Tag = NULLTAG;
	tag_t *status_list = NULLTAG;
	int ifail = 0;
	int ii = 0;
	char *text = NULL;
	int status_count = 0;
	char *Item_string = NULL;
	logical retain = 0;
	int status;
	int Desc_seq = 0;
	int Desc_seq9 = 0;
	int Desc_seq1 = 0;
	int Desc_seq2 = 0;
	char *Desc_obj = NULL;
	char *Desc_obj9 = NULL;
	char *Desc_obj2 = NULL;
	// char			*Desc_seq3	= NULL;
	char Desc_seq3[10];
	tag_t objTypeTag = NULLTAG;
	tag_t status_rel = NULLTAG;
	tag_t rev = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t master = NULLTAG;
	logical bypass = FALSE;
	tag_t source_rev = va_arg(args, tag_t);
	char *rev_id = va_arg(args, char *);
	tag_t *new_rev = va_arg(args, tag_t *);
	tag_t item_rev_master_form = va_arg(args, tag_t);
	char *ReplacedRevision = NULL;
	char *ObjectClassType = NULL;
	char *ObjectName = NULL;
	tag_t dataset = NULLTAG;
	tag_t *attachments = NULLTAG;
	int revlength = 0;
	tag_t *revisions;
	int revision_count = 0;
	tag_t attr_id;
	tag_t form_attr_id;
	tag_t relation_type = NULLTAG;
	char relation_name[TCTYPE_name_size_c + 1];

	const char *reason = NULL;
	const char *change_id = NULL;
	const char *dir_name = NULL;
	const char *reason1 = NULL;
	const char *change_id1 = NULL;
	const char *dir_name1 = NULL;
	char *revi = NULL;
	char *oojname = NULL;
	char revi1[20];
	int cnt = 0;
	int i = 0;
	logical checkout = 0;
	tag_t CurrentRoleTag = NULLTAG;
	// char       roleName[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
	// char       roleNameVal[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
	char *PlantName = NULL;
	char *roleNameVal = NULL;

	/******Deepti Start Variable initialisation***********/
	int st_relList_count = 0;
	int Rel_cnt = 0;
	tag_t *relstatus_list = NULLTAG;
	char *WSO_Name_RelVal = NULL;
	tag_t tReleaseStatusList = NULLTAG;
	int n_values = 0;
	int cunt1 = 0;
	tag_t *attr_tags = NULLTAG;
	logical *is_it_null = NULL;
	logical *is_it_empty = NULL;
	tag_t class_id = NULLTAG;
	char *class_name = NULL;
	logical log1;
	char RelStat[200] = {0};

	/******Deepti End ariable initialisation***********/
	int Ap_owner_Nt_fnd = 0, Valid_Ch_Dataset = 0;
	char *dt_typ_nm = NULL;
	char *Ap_owner = NULL;

	char RvwLCVal[40];			   // MBOM implementation for CV TZ-1.69
	char WrkngLCVal[40];		   // MBOM implementation for CV TZ-1.69
	char WrkngActLCVal[40];		   // MBOM implementation for CV TZ-1.69
	char RlzdLcVal[40];			   // MBOM implementation for CV TZ-1.69
	char RlzdActLcVal[40];		   // MBOM implementation for CV TZ-1.69
	char RvwLCActVal[40];		   // MBOM implementation for CV TZ-1.69
	char StdWrkLcActVal[40];	   // MBOM implementation for CV TZ-1.69
	char StdRlzdActLcVal[40];	   // MBOM implementation for CV TZ-1.69
	char StdWrkLcVal[40];		   // MBOM implementation for CV TZ-1.69
	char StdRlzdLcVal[40];		   // MBOM implementation for CV TZ-1.69
	char View[40];				   // MBOM implementation for CV TZ-1.69
	char roleName[100];			   // MBOM implementation for CV TZ-1.69
	char *dsgModAddressVal = NULL; // MBOM implementation for CV TZ-1.69

	printf("\n Inside Revise_properties_post Function.... \n");	fflush(stdout);

	if (TCTYPE_ask_object_type(source_rev, &objTypeTag) != ITK_ok);
	if (TCTYPE_ask_name2(objTypeTag, &type_name) != ITK_ok);

	printf("\n type_name => %s \n",type_name );

	if (strcmp(type_name, "T5_PeDesignRevision") == 0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***Revise_properties_post***");
		fflush(stdout);
		return ITK_ok;
	}

	if (ITEM_ask_item_of_rev(source_rev, &master));
	if (ITEM_ask_latest_rev(master, &rev));
	
	char*	Part_Type = NULL;
	ITKCALL(AOM_ask_value_string(rev, "t5_PartType", &Part_Type));
	printf("\n Ketan Part_Type => %s \n", Part_Type);fflush(stdout); 

	CALLAPI(SA_ask_current_role(&CurrentRoleTag)); // Dayanand TZ1.37
	// CALLAPI(SA_ask_role_name2(CurrentRoleTag,roleName));//Dayanand TZ1.37
	CALLAPI(SA_ask_role_name2(CurrentRoleTag, &roleNameVal)); // MBOM implementation for CV TZ-1.69
	tc_strcpy(roleName, roleNameVal);						  // MBOM implementation for CV TZ-1.69
	printf("\n\n  roleNameVal : %s,roleName : %s\n", roleNameVal, roleName);
	fflush(stdout); // MBOM implementation for CV TZ-1.69

	if (tc_strstr(roleName, "MBOM") != NULL) // MBOM implementation for CV TZ-1.69
	{
		dsgModAddressVal = strtok(roleNameVal, "_"); // MBOM implementation for CV TZ-1.69
		PlantName = strtok(NULL, "_");
		printf("dsgModAddressVal:%s\n", dsgModAddressVal);
		fflush(stdout);
		printf("PlantName:%s\n", PlantName);
		fflush(stdout); // MBOM implementation for CV TZ-1.69
	}
	else
	{
		PlantName = subString(roleName, 3, 4); // MBOM implementation for CV TZ-1.69
	}
	printf("PlantName:%s\n", PlantName);
	fflush(stdout);

	if (ITEM_list_all_revs(master, &revision_count, &revisions));
	// MEM_free (revisions);
	printf("\nNumber of revision : %d\n", revision_count);
	fflush(stdout);

	if (WSOM_ask_release_status_list(revisions[revision_count - 2], &status_count, &status_list) != ITK_ok)
		PrintErrorStack();
	tc_strcpy(RelStat, "");
	printf("\n number of statuses: %d \n", status_count);
	fflush(stdout);
	for (ii = 0; ii < status_count; ii++)
	{
		AOM_ask_name(status_list[ii], &ReleaseStatus);
		printf("\t ReleaseStatus: %s\n", ReleaseStatus);
		fflush(stdout);
		tc_strcat(RelStat, "[");
		tc_strcat(RelStat, ReleaseStatus);
		tc_strcat(RelStat, "]");
		tc_strcat(RelStat, ",");
	}
	printf("\t RelStat: %s\n", RelStat);
	fflush(stdout); // MBOM implementation for CV TZ-1.69 Backend

	if (AOM_ask_value_string(revisions[revision_count - 2], "item_revision_id", &Desc_obj2) != ITK_ok)
		PrintErrorStack();
	printf("\n Desc_obj2  = [%s]\n", Desc_obj2);	fflush(stdout);

	if (AOM_ask_value_int(revisions[revision_count - 2], "sequence_id", &Desc_seq2) != ITK_ok)PrintErrorStack();
	printf("\n Desc_seq2  = [%d]\n", Desc_seq2);	fflush(stdout);

	if ((tc_strstr(roleName, "APL") != NULL) || (tc_strstr(roleName, "MBOM") != NULL)) // APL USer STart //MBOM implementation for CV TZ-1.69
	{
		printf("\n APL User Start \n");
		fflush(stdout);

		get_CtrlVal_RelStateInfoRev(PlantName, RvwLCVal, RvwLCActVal, WrkngLCVal, WrkngActLCVal, RlzdLcVal, RlzdActLcVal, StdWrkLcVal, StdWrkLcActVal, StdRlzdLcVal, StdRlzdActLcVal, View); // MBOM implementation for CV TZ-1.69

		printf("\n Inside Revise RvwLCVal:%s ,RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s,RlzdActLcVal :%s,StdWrkLcVal :%s,StdWrkLcActVal : %s,StdRlzdLcVal :%s,StdRlzdActLcVal :%s,View:%s\n", RvwLCVal, RvwLCActVal, WrkngLCVal, WrkngActLCVal, RlzdLcVal, RlzdActLcVal, StdWrkLcVal, StdWrkLcActVal, StdRlzdLcVal, StdRlzdActLcVal, View);
		fflush(stdout); // MBOM implementation for CV TZ-1.69

		// if((strcmp(ReleaseStatus,"APLC Review")==0)  || (strcmp(ReleaseStatus,"APL Review")==0)  || (strcmp(ReleaseStatus,"T5_LcsAplReview")==0)
		//|| (strcmp(ReleaseStatus,"APLV Review")==0)  || (strcmp(ReleaseStatus,"T5_LcsAplvReview")==0)) //MBOM implementation for CV TZ-1.69,Line commented
		if ((tc_strcmp(ReleaseStatus, RvwLCActVal) == 0) || (tc_strcmp(ReleaseStatus, RvwLCVal) == 0)) // MBOM implementation for CV TZ-1.69
		{
			if (AOM_ask_value_string(rev, "item_revision_id", &Desc_obj) != ITK_ok)
				PrintErrorStack();
			printf("\n type_name  = [%s]\n", type_name);
			fflush(stdout);
			printf("\n revision  = [%s]\n", Desc_obj);
			fflush(stdout);

			if (AOM_ask_value_int(rev, "sequence_id", &Desc_seq) != ITK_ok)
				PrintErrorStack();
			printf("\n sequence  = [%d]\n", Desc_seq);
			fflush(stdout);

			Desc_seq1 = Desc_seq2 + 1;
			printf("\n sequence1  = [%d]\n", Desc_seq1);
			fflush(stdout);

			if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
				PrintErrorStack();

			//	if(strcmp(Desc_obj2,"NR")==0)
			//		{
			//			if(POM_set_attr_string(1, &rev, attr_id, "NR;2")) PrintErrorStack();
			//		}

			//	else
			//		{
			printf("\nValue of Desc_obj : %s\n", Desc_obj2);
			fflush(stdout);
			revi = strtok(Desc_obj2, ";");
			printf("\nValue of revi : %s\n", revi);
			fflush(stdout);
			strcat(revi, ";");
			printf("\nValue of revi : %s\n", revi);
			fflush(stdout);

			sprintf(revi1, "%d", Desc_seq1);
			printf("\nValue of revi : %s\n", revi);
			fflush(stdout);

			strcat(revi, revi1);
			printf("\nValue of revi : %s\n", revi);
			fflush(stdout);

			if (POM_set_attr_string(1, &rev, attr_id, revi) != ITK_ok)
				PrintErrorStack();
			//		}

			// if(POM_save_instances(1, &rev, true)) PrintErrorStack();

			// Desc_seq1 = Desc_seq2 + 1;
			// printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

			printf("\nUpdating start2\n");
			fflush(stdout);
			if (AOM_lock(rev))
				;
			if (AOM_set_value_int(rev, "sequence_id", Desc_seq1) != ITK_ok)
				PrintErrorStack();
			if (AOM_save_without_extensions(rev) != ITK_ok)
				PrintErrorStack();
			if (AOM_unlock(rev) != ITK_ok)
				PrintErrorStack();
			printf("\nUpdating end2\n");
			fflush(stdout);

			// if (RES_checkout2(rev,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();

			printf("\n**********After Check Out***************\n");
			fflush(stdout);
			//	if (AOM_lock(rev))PrintErrorStack();

			printf("\n############After lock muktesh\n");
			fflush(stdout);

			// if(GRM_find_relation_type("IMAN_master_form_rtype",&relation_type));

			//	if(TCTYPE_ask_name2( relation_type, relation_name))PrintErrorStack();
			//	printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);

			//	if(relation_type = NULLTAG)
			//	{
			// if(TCTYPE_ask_name2( relation_type, relation_name))PrintErrorStack();
			// printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);

			//					if(ITEM_ask_latest_rev(master,&rev1))PrintErrorStack();
			//					if (AOM_ask_value_string(rev1,"item_revision_id",&Desc_obj9)!=ITK_ok)   PrintErrorStack();

			//					printf("\n revision  = [%s]\n", Desc_obj9);fflush(stdout);
			//
			//					if (AOM_ask_value_int(rev1,"sequence_id",&Desc_seq9)!=ITK_ok)   PrintErrorStack();
			//					printf("\n sequence  = [%d]\n", Desc_seq9);fflush(stdout);
			//
			//					if(GRM_list_secondary_objects_only(revisions[revision_count-2],relation_type,&cnt,&attachments))PrintErrorStack();
			//					printf("\n Attached Datasets1:%d\n",cnt);fflush(stdout);

			if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)
				PrintErrorStack();
			printf("\n Attached Datasets2: %d\n", cnt);
			fflush(stdout);

			if (RES_checkout2(rev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE) != ITK_ok)
				PrintErrorStack();

			// if(GRM_list_secondary_objects_only(rev1,relation_type,&cnt,&attachments))PrintErrorStack();
			// printf("\n Attached Datasets3:%d\n",cnt);fflush(stdout);

			for (i = 0; i < cnt; i++)
			{
				Ap_owner_Nt_fnd = 0;
				Valid_Ch_Dataset = 0;
				dt_typ_nm = NULL;
				dataset = attachments[i];

				if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
					PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
				fflush(stdout);

				if (strcmp(ObjectClassType, "Design Revision Master") == 0 || strcmp(ObjectClassType, "T5_SparKitRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_clschmRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") == 0)
				{
					if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
						PrintErrorStack();
					printf("\n\n Revision Master Name :%s\n", ObjectName);
					fflush(stdout);
					oojname = strtok(ObjectName, "/");
					strcat(oojname, "/");
					strcat(oojname, revi);
					printf("\n\n Name of Revision Master:%s\n", oojname);
					fflush(stdout);

					if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
						PrintErrorStack();

					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					// if(AOM_lock(dataset));
					// if( AOM_set_value_string(dataset,"sequence_id",Desc_seq1))PrintErrorStack();
					// if(AOM_save_without_extensions(dataset))PrintErrorStack();
					// if(AOM_unlock(dataset))PrintErrorStack();
				}

				if ((strcmp(ObjectClassType, "Design Revision") != 0) && (strcmp(ObjectClassType, "T5_SparKitRevision") != 0) && (strcmp(ObjectClassType, "T5_clschmRevision") != 0) && (strcmp(ObjectClassType, "T5_EE_PartRevision") != 0) && (strcmp(ObjectClassType, "T5_MatEnggPartRevision") != 0))
				{
					if ((strcmp(ObjectClassType, "Design Revision Master") != 0) && (strcmp(ObjectClassType, "T5_SparKitRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_clschmRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") != 0))
					{
						printf("\n\n Dataset ObjectClassType1 :%s\n", ObjectClassType);
						fflush(stdout);

						if (RES_is_checked_out(dataset, &checkout) != ITK_ok)
							PrintErrorStack();
						if (AOM_ask_value_string(dataset, "object_type", &dt_typ_nm) != ITK_ok)
							PrintErrorStack();
						printf("\n dt_typ_nm of checkout : %s \n", dt_typ_nm);
						fflush(stdout);
						printf("\n Value of checkout : %d \n", checkout);
						fflush(stdout);

						if (checkout == 0)
						{
							tag_t *relation_list = NULLTAG;
							int relcount = 0;
							tag_t relation_type1 = NULLTAG;
							if (GRM_find_relation_type("IMAN_reference", &relation_type1) != ITK_ok)
								PrintErrorStack();
							if (GRM_list_relations(rev, dataset, relation_type1, NULLTAG, &relcount, &relation_list) != ITK_ok)
								PrintErrorStack();
							printf("\nIMAN_references count : %d", relcount);
							printf("\n\n going to checkout :%s\n", ObjectClassType);
							fflush(stdout);
							printf("\nCommented checkout of dataset by Devkant");
							fflush(stdout);
							printf("\nCommented checkout of dataset SO");
							fflush(stdout);
							if (relcount <= 0)
							{
								/******** TEsting appOwnerCheckOutValidation*/
								if (AOM_ask_value_string(rev, "t5_ApplicationOwner", &Ap_owner) != ITK_ok)
									PrintErrorStack();
								printf("\n Application owner %s", Ap_owner);
								fflush(stdout);
								if ((tc_strcmp(Ap_owner, "NULL") != 0))
								{
									if (((tc_strcmp(Ap_owner, "ProEAsm") == 0) && (tc_strcmp(dt_typ_nm, "ProAsm") == 0 || tc_strcmp(dt_typ_nm, "ProDrw") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEPart") == 0) && (tc_strcmp(dt_typ_nm, "ProPrt") == 0 || tc_strcmp(dt_typ_nm, "ProDrw") == 0)) ||
										((tc_strcmp(Ap_owner, "Cat-Product") == 0) && (tc_strcmp(dt_typ_nm, "CMI2Product") == 0 || tc_strcmp(dt_typ_nm, "CMI2Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "Cat-Part") == 0) && (tc_strcmp(dt_typ_nm, "CMI2Part") == 0 || tc_strcmp(dt_typ_nm, "CMI2Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEngineer-Part") == 0) && (tc_strcmp(dt_typ_nm, "Creo Part") == 0 || tc_strcmp(dt_typ_nm, "Creo Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEngineer-Asm") == 0) && (tc_strcmp(dt_typ_nm, "Creo assembly") == 0 || tc_strcmp(dt_typ_nm, "Creo Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "Alias") == 0) && (tc_strcmp(dt_typ_nm, "T5_Alias") == 0))) // Adi
									{
										printf("\n RevisePOst");
										fflush(stdout);

										printf("\n Application RevisePOstowner %s and Dataset is  %s", Ap_owner, dt_typ_nm);
										fflush(stdout);
										printf("\n setting RevisePOstvalid_ch_dataset flag");
										fflush(stdout);
										Valid_Ch_Dataset = 1;
									}
								}
								else
								{
									printf("\n setting RevisePOstApplication owner not found flag");
									fflush(stdout);
									Ap_owner_Nt_fnd = 1;
								}
								/********/
								printf("\nValid_Ch_Dataset RevisePOstDatadet %d and Ap_owner_Nt_fnd %d RevisePOstDatadet \n", Valid_Ch_Dataset, Ap_owner_Nt_fnd);
								fflush(stdout);

								if (Valid_Ch_Dataset == 1 || Ap_owner_Nt_fnd == 1)
								{
									printf("\n RevisePOstDatadet check out AppOwner");
									fflush(stdout);
									if (RES_checkout2(dataset, reason1, change_id1, dir_name1, RES_EXCLUSIVE_RESERVE) != ITK_ok)
										PrintErrorStack();
									printf("\n %d DataSet Checked Out \n", dataset);
								}
							}
							else
							{
								printf("\nSkipping IMAN_reference relation checkout");
							}
						}
					}
				}
				// ObjectClassType,"Design Revision") loop ends
			}
			//}
		}

	} // APL USer End	
	else // ERC USer Start
	{
		printf("\n Release status for check out : %s\n", ReleaseStatus);
		fflush(stdout);
		if ((strcmp(ReleaseStatus, "ERC Review") == 0) || (strcmp(ReleaseStatus, "T5_LcsReview") == 0))
		{

			if (AOM_ask_value_string(rev, "item_revision_id", &Desc_obj) != ITK_ok)
				PrintErrorStack();
			printf("\n type_name  = [%s]\n", type_name);
			fflush(stdout);
			printf("\n revision  = [%s]\n", Desc_obj);
			fflush(stdout);

			if (AOM_ask_value_int(rev, "sequence_id", &Desc_seq) != ITK_ok)
				PrintErrorStack();
			printf("\n sequence  = [%d]\n", Desc_seq);
			fflush(stdout);

			Desc_seq1 = Desc_seq2 + 1;
			printf("\n sequence1  = [%d]\n", Desc_seq1);
			fflush(stdout);

			if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
				PrintErrorStack();

			//	if(strcmp(Desc_obj2,"NR")==0)
			//		{
			//			if(POM_set_attr_string(1, &rev, attr_id, "NR;2")) PrintErrorStack();
			//		}

			//	else
			//		{
			char *revi_Temp = NULL;
			revi = (char *)MEM_alloc(10);
			printf("\nValue of Desc_obj : %s\n", Desc_obj2);
			fflush(stdout);
			revi_Temp = strtok(Desc_obj2, ";");
			printf("\nValue of revi_Temp : %s\n", revi_Temp);
			fflush(stdout);
			tc_strcpy(revi, revi_Temp);
			printf("\nValue of revi : %s\n", revi);
			fflush(stdout);
			tc_strcat(revi, ";");
			sprintf(revi1, "%d", Desc_seq1);
			printf("\nValue of revi1 : %s\n", revi1);
			fflush(stdout);
			tc_strcat(revi, revi1);
			printf("\nValue of revi-F : %s\n", revi);
			fflush(stdout);

			if (POM_set_attr_string(1, &rev, attr_id, revi) != ITK_ok)
				PrintErrorStack();
			//		}

			// if(POM_save_instances(1, &rev, true)) PrintErrorStack();

			// Desc_seq1 = Desc_seq2 + 1;
			// printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

			printf("\nUpdating start2\n");
			fflush(stdout);
			if (AOM_lock(rev))
				;
			if (AOM_set_value_int(rev, "sequence_id", Desc_seq1) != ITK_ok)
				PrintErrorStack();
			if (AOM_save_without_extensions(rev) != ITK_ok)
				PrintErrorStack();
			if (AOM_unlock(rev) != ITK_ok)
				PrintErrorStack();
			printf("\nUpdating end2\n");
			fflush(stdout);

			// if (RES_checkout2(rev,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
			
			printf("\n SOR_CUT_Paste: RSS-START  AFter Checkout \n");
			//int n_found = 0;
			int n_Ctrlfound = 0;
			int n_Ctrlentries = 1;
			char *qry_entries[1] = {"SUBSYSCD"};
			char *qry_values[1] = {"SorCutPasteChkOut"};
			tag_t query = NULLTAG;
			tag_t *cntr_objects = NULL;
			int sorCutPateFlag = 0;
			int iFail = 0;
			char *NewDesRevID = NULL;
			char *source_rev = NULL;
			char *oldDesRevID = NULL;
			char *NewDesRevSeq = NULL;
			char *oldDesRevSeq = NULL;
			char *inp_id_str = NULL;
			char *newItemId = NULL;
			char *inp_id_strDup = NULL;
			char *newItemIdDup = NULL;
			char *RevId = NULL;
			char *newRevId = NULL;
			char *RevIdDup = NULL;
			char *newRevIdDup = NULL;
			char *NewSOR_id = NULL;
			char *OldSOR_id = NULL;
			tag_t tRelPrtSor = NULLTAG;
			tag_t tNewRelPrtToSor = NULLTAG;
			int OldsorCnt = 0;
			int sorCntAftrCkOut = 0;
			int NewsorCnt = 0;
			tag_t *tOldSorRev = NULLTAG;
			tag_t *tSorNew = NULLTAG;
			tag_t *tNewSorRev = NULLTAG;
			// tag_t *relation = NULLTAG;
			tag_t relation = NULLTAG;
			tag_t *targetObj = NULLTAG;
			int z = 0;
			tag_t tRelfound = NULLTAG;
			tag_t tSor = NULLTAG;
			tag_t tagSorNew = NULLTAG;
			tag_t newRevTag = NULLTAG;
			tag_t oldRevTag = NULLTAG;
			tag_t Stat_tag = NULLTAG;
			char *message;
			char *loggedInUser = NULL;
			int n_entries = 2;
			int new_entries = 2;
			int n_itemobj_found = 0;
			int new_itemobj_found = 0;
			tag_t *titemobj_results = NULLTAG;
			tag_t *newitemobj_results = NULLTAG;
			tag_t *tSorAftrCkout = NULLTAG;
			tag_t tItemobj = NULLTAG;
			tag_t sor_obj_type_tag = NULLTAG;
			tag_t Oldsor_obj_type_tag = NULLTAG;
			char *sor_type_name = NULL;
			char *Newsor_type_name = NULL;
			char *SorAftrCkOut = NULL;
			char *Oldsor_type_name = NULL;
			tag_t deletedSorObjects[100]; // Store deleted objects (assuming max 100)
			int deletedSorCnt = 0;		  // Counter for deleted objects
			tag_t tagSorAftrCkOut = NULLTAG;
			tag_t tSorToAdd = NULLTAG;
			char *ERCInf1 = NULL;
			char *ERCInf2 = NULL;
			char *ERCInf3 = NULL;
			char *ERCInf4 = NULL;
			char *ERCInf5 = NULL;
			char *ERCInf6 = NULL;
			char *ERCInf7 = NULL;
			char *ERCInf8 = NULL;
			char *ERCInf9 = NULL;
			char *ERCInf10 = NULL;
			printf("\n SOR_CUT_Paste: control_object_Checking>>>>>>>>>>");fflush(stdout);
			CALLAPI(QRY_find2("Control Objects...", &query));
			CALLAPI(QRY_execute(query, n_Ctrlentries, qry_entries, qry_values, &n_Ctrlfound, &cntr_objects));
			printf("\nSOR_CUT_Paste: n_Ctrlfound : [%d]\n", n_Ctrlfound);fflush(stdout);
			TC_write_syslog("SOR_CUT_Paste: n_Ctrlfound : [%d]", n_Ctrlfound);fflush(stdout);
			if (n_Ctrlfound > 0)
			{
				// CALLAPI(AOM_ask_value_logical(cntr_objects[0], "t5_DelInd", &deleteInd));
				ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo1", &ERCInf1));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo2", &ERCInf2));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo3", &ERCInf3));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo4", &ERCInf4));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo5", &ERCInf5));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo6", &ERCInf6));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo7", &ERCInf7));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo8", &ERCInf8));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo9", &ERCInf9));
				CALLAPI(AOM_ask_value_string(cntr_objects[0], "t5_userinfo10", &ERCInf10));
				printf("\n SOR_CUT_Paste: Information 1 for SorCutPasteChkOut  is [%s] \n", ERCInf1);fflush(stdout);
				printf("\n SOR_CUT_Paste: Information 2 for SorCutPasteChkOut  is [%s] \n", ERCInf2);fflush(stdout);
				//if (tc_strstr(ERCInf1, "ON") != NULL)
				if ((ERCInf1 && tc_strstr(ERCInf1, "ON") != NULL) || (ERCInf2 && tc_strstr(ERCInf2, "ON") != NULL))
				{
					sorCutPateFlag = 1;
					printf("\n SOR_CUT_Paste: Information 1/2 is >>> ON >>> Continue execution\n"); fflush(stdout);
				}
			}

			if (sorCutPateFlag > 0)
			{
				if (revisions[revision_count - 2])
				{
					oldRevTag = revisions[revision_count - 2];
					newRevTag = rev;

					if (AOM_ask_value_string(oldRevTag, "item_id", &oldDesRevID));
					if (AOM_ask_value_string(oldRevTag, "item_revision_id", &oldDesRevSeq));
					if (AOM_ask_value_string(newRevTag, "item_id", &NewDesRevID));
					if (AOM_ask_value_string(newRevTag, "item_revision_id", &NewDesRevSeq));
					printf("\n SOR_CUT_Paste: ------>Old Design Revision Found [%s] [%s]\n", oldDesRevID, oldDesRevSeq); fflush(stdout);
					TC_write_syslog("\n SOR_CUT_Paste: ------>Old Design Revision Found [%s] [%s]", oldDesRevID, oldDesRevSeq);fflush(stdout);
					printf("\n SOR_CUT_Paste: ------>New Design Revision Found [%s] [%s]\n", NewDesRevID, NewDesRevSeq); fflush(stdout);
					TC_write_syslog("\n SOR_CUT_Paste: ------>New Design Revision Found [%s] [%s]", NewDesRevID, NewDesRevSeq);fflush(stdout);

					if (GRM_find_relation_type("T5_PartSorRel", &tRelPrtSor));
					if (GRM_list_secondary_objects_only(oldRevTag, tRelPrtSor, &OldsorCnt, &tOldSorRev));
					if (GRM_list_secondary_objects_only(newRevTag, tRelPrtSor, &NewsorCnt, &tNewSorRev));
					if (OldsorCnt >= 1 && NewsorCnt == 0)
					{
						//for (z = 0; z < OldsorCnt; z++)
						//{
							tSorToAdd = tOldSorRev[0];
							CALLAPI(TCTYPE_ask_object_type(tSorToAdd, &Oldsor_obj_type_tag));
							CALLAPI(TCTYPE_ask_name2(Oldsor_obj_type_tag, &Oldsor_type_name));
							printf("\n SOR_CUT_Paste: *******sor_type_name>>>>>>>> : [%s] **********************\n", Oldsor_type_name);fflush(stdout);
							if (AOM_UIF_ask_value(tSorToAdd, "item_id", &OldSOR_id));
							printf("\n SOR_CUT_Paste: OldSOR_id>>>>>>>> : [%s]\n", OldSOR_id);fflush(stdout);
							
							if (GRM_create_relation(newRevTag, tSorToAdd, tRelPrtSor, NULLTAG, &relation) == ITK_ok)
							{
								CALLAPI(GRM_save_relation(relation));
								//printf("\nADD BACK: Successfully Re-Added Object %d/%d\n", i + 1, deletedSorCnt);
								printf("\n SOR_CUT_Paste: ADD BACK: Successfully Re-Added Object \n");fflush(stdout);							
								if (GRM_find_relation(oldRevTag, tSorToAdd, tRelPrtSor, &tRelfound));
								if (tRelfound != NULLTAG)
								{
									if (GRM_delete_relation(tRelfound));
									printf("\n SOR_CUT_Paste: ------>RELATION IS DELTETED \n");fflush(stdout);
									TC_write_syslog("\n SOR_CUT_Paste: ------>RELATION IS DELTETED\n");fflush(stdout);
								}
								else
								{
									printf("\n SOR_CUT_Paste: ------> DELETE Failed ! RELATION NOT FOUND \n");fflush(stdout);
									TC_write_syslog("\n SOR_CUT_Paste:  ------> DELETE Failed ! RELATION NOT FOUNDD\n");fflush(stdout);
								}

								CALLAPI(GRM_list_secondary_objects_only(newRevTag, tRelPrtSor, &sorCntAftrCkOut, &tSorAftrCkout));
								if (sorCntAftrCkOut > 0)
								{
									tagSorAftrCkOut = tSorAftrCkout[0];
									CALLAPI(TCTYPE_ask_object_type(tagSorAftrCkOut, &sor_obj_type_tag));
									CALLAPI(TCTYPE_ask_name2(sor_obj_type_tag, &Newsor_type_name));
									printf("\n SOR_CUT_Paste:*********After Add New sor_type_name>>>>>>>> : [%s] **********************\n", Newsor_type_name);fflush(stdout);
									if (tc_strcmp(Newsor_type_name, "T5_AutoSorRevision") == 0)
									{
										if (AOM_UIF_ask_value(tagSorAftrCkOut, "item_id", &SorAftrCkOut) == ITK_ok)
										 printf("\n SOR_CUT_Paste: After Checkout -  New SOR_id>>>>>>>> : [%s]\n", SorAftrCkOut);fflush(stdout);
									}
								}
							}
							else
							{
								//printf("\nADD BACK: Failed to Add Object %d/%d\n", i + 1, deletedSorCnt);
								printf("\n SOR_CUT_Paste: ADD BACK: Failed to Add Object\n"); fflush(stdout);
							}
						//}
					}
					else
					{
						printf("\n SOR_CUT_Paste: ------>  Old_Sor_Count : [%d] & New_SOR_Count : [%d] \n", OldsorCnt,NewsorCnt); fflush(stdout);
						TC_write_syslog("\n SOR_CUT_Paste: ------> Old_Sor_Count : [%d] & New_SOR_Count : [%d] \n", OldsorCnt,NewsorCnt); fflush(stdout);
						
					}
					
				}
				else
				{
					printf("\n SOR_CUT_Paste: SourceTag Not Found ------> revisions[revision_count - 2] \n"); fflush(stdout);
					TC_write_syslog("\n SOR_CUT_Paste: SourceTag Not Found ------> revisions[revision_count - 2] \n"); fflush(stdout);
				}
			}
			else
			{
				printf("\n SOR_CUT_Paste: control_object_Check OFF or not found :\n");fflush(stdout);
				TC_write_syslog("\n SOR_CUT_Paste: control_object_Check OFF or not found : \n");fflush(stdout);
			}

			printf("\n**********After Check Out***************\n");
			fflush(stdout);
			//	if (AOM_lock(rev))PrintErrorStack();

			printf("\n############After lock muktesh\n");
			fflush(stdout);

			// if(GRM_find_relation_type("IMAN_master_form_rtype",&relation_type));

			//	if(TCTYPE_ask_name2( relation_type, relation_name))PrintErrorStack();
			//	printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);

			//	if(relation_type = NULLTAG)
			//	{
			// if(TCTYPE_ask_name2( relation_type, relation_name))PrintErrorStack();
			// printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);

			//					if(ITEM_ask_latest_rev(master,&rev1))PrintErrorStack();
			//					if (AOM_ask_value_string(rev1,"item_revision_id",&Desc_obj9)!=ITK_ok)   PrintErrorStack();

			//					printf("\n revision  = [%s]\n", Desc_obj9);fflush(stdout);
			//
			//					if (AOM_ask_value_int(rev1,"sequence_id",&Desc_seq9)!=ITK_ok)   PrintErrorStack();
			//					printf("\n sequence  = [%d]\n", Desc_seq9);fflush(stdout);
			//
			//					if(GRM_list_secondary_objects_only(revisions[revision_count-2],relation_type,&cnt,&attachments))PrintErrorStack();
			//					printf("\n Attached Datasets1:%d\n",cnt);fflush(stdout);

			if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)
				PrintErrorStack();
			printf("\n Attached Datasets2: %d\n", cnt);
			fflush(stdout);

			if (RES_checkout2(rev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE) != ITK_ok)
				PrintErrorStack();

			// if(GRM_list_secondary_objects_only(rev1,relation_type,&cnt,&attachments))PrintErrorStack();
			// printf("\n Attached Datasets3:%d\n",cnt);fflush(stdout);

			for (i = 0; i < cnt; i++)
			{
				Ap_owner_Nt_fnd = 0;
				Valid_Ch_Dataset = 0;
				dt_typ_nm = NULL;
				dataset = attachments[i];

				if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
					PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
				fflush(stdout);

				if ((strcmp(ObjectClassType, "Design Revision Master") == 0) || (strcmp(ObjectClassType, "T5_SparKitRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_clschmRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") == 0))
				{
					if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
						PrintErrorStack();
					printf("\n\n Revision Master Name :%s\n", ObjectName);
					fflush(stdout);
					oojname = strtok(ObjectName, "/");
					strcat(oojname, "/");
					strcat(oojname, revi);
					printf("\n\n Name of Revision Master:%s\n", oojname);
					fflush(stdout);

					if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
						PrintErrorStack();

					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					// if(AOM_lock(dataset));
					// if( AOM_set_value_string(dataset,"sequence_id",Desc_seq1))PrintErrorStack();
					// if(AOM_save_without_extensions(dataset))PrintErrorStack();
					// if(AOM_unlock(dataset))PrintErrorStack();
				}

				if ((strcmp(ObjectClassType, "Design Revision") != 0) && (strcmp(ObjectClassType, "T5_SparKitRevision") != 0) && (strcmp(ObjectClassType, "T5_clschmRevision") != 0) && (strcmp(ObjectClassType, "T5_EE_PartRevision") != 0) && (strcmp(ObjectClassType, "T5_MatEnggPartRevision") != 0))
				{
					if ((strcmp(ObjectClassType, "Design Revision Master") != 0) && (strcmp(ObjectClassType, "T5_SparKitRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_clschmRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") != 0) && (strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") != 0))
					{
						printf("\n\n Dataset ObjectClassType1 :%s\n", ObjectClassType);
						fflush(stdout);

						if (RES_is_checked_out(dataset, &checkout) != ITK_ok)
							PrintErrorStack();
						if (AOM_ask_value_string(dataset, "object_type", &dt_typ_nm) != ITK_ok)
							PrintErrorStack();
						printf("\n dt_typ_nm of checkout : %s \n", dt_typ_nm);
						fflush(stdout);
						printf("\n Value of checkout : %d \n", checkout);
						fflush(stdout);

						if (checkout == 0)
						{
							tag_t *relation_list = NULLTAG;
							int relcount = 0;
							tag_t relation_type1 = NULLTAG;
							if (GRM_find_relation_type("IMAN_reference", &relation_type1) != ITK_ok)
								PrintErrorStack();
							if (GRM_list_relations(rev, dataset, relation_type1, NULLTAG, &relcount, &relation_list) != ITK_ok)
								PrintErrorStack();
							printf("\nIMAN_references count : %d", relcount);
							printf("\n\n going to checkout :%s\n", ObjectClassType);
							fflush(stdout);
							printf("\nCommented checkout of dataset by Devkant");
							fflush(stdout);
							printf("\nCommented checkout of dataset SO");
							fflush(stdout);
							if (relcount <= 0)
							{
								/******** TEsting appOwnerCheckOutValidation*/
								if (AOM_ask_value_string(rev, "t5_ApplicationOwner", &Ap_owner) != ITK_ok)
									PrintErrorStack();
								printf("\n Application owner %s", Ap_owner);
								fflush(stdout);
								if ((tc_strcmp(Ap_owner, "NULL") != 0))
								{
									if (((tc_strcmp(Ap_owner, "ProEAsm") == 0) && (tc_strcmp(dt_typ_nm, "ProAsm") == 0 || tc_strcmp(dt_typ_nm, "ProDrw") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEPart") == 0) && (tc_strcmp(dt_typ_nm, "ProPrt") == 0 || tc_strcmp(dt_typ_nm, "ProDrw") == 0)) ||
										((tc_strcmp(Ap_owner, "Cat-Product") == 0) && (tc_strcmp(dt_typ_nm, "CMI2Product") == 0 || tc_strcmp(dt_typ_nm, "CMI2Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "Cat-Part") == 0) && (tc_strcmp(dt_typ_nm, "CMI2Part") == 0 || tc_strcmp(dt_typ_nm, "CMI2Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEngineer-Part") == 0) && (tc_strcmp(dt_typ_nm, "Creo Part") == 0 || tc_strcmp(dt_typ_nm, "Creo Drawing") == 0)) ||
										((tc_strcmp(Ap_owner, "ProEngineer-Asm") == 0) && (tc_strcmp(dt_typ_nm, "Creo assembly") == 0 || tc_strcmp(dt_typ_nm, "Creo Drawing") == 0)))
									{
										printf("\n RevisePOst");
										fflush(stdout);

										printf("\n Application RevisePOstowner %s and Dataset is  %s", Ap_owner, dt_typ_nm);
										fflush(stdout);
										printf("\n setting RevisePOstvalid_ch_dataset flag");
										fflush(stdout);
										Valid_Ch_Dataset = 1;
									}
								}
								else
								{
									printf("\n setting RevisePOstApplication owner not found flag");
									fflush(stdout);
									Ap_owner_Nt_fnd = 1;
								}
								/********/
								printf("\nValid_Ch_Dataset RevisePOstDatadet %d and Ap_owner_Nt_fnd %d RevisePOstDatadet \n", Valid_Ch_Dataset, Ap_owner_Nt_fnd);
								fflush(stdout);

								if (Valid_Ch_Dataset == 1 || Ap_owner_Nt_fnd == 1)
								{
									printf("\n RevisePOstDatadet check out AppOwner");
									fflush(stdout);
									if (RES_checkout2(dataset, reason1, change_id1, dir_name1, RES_EXCLUSIVE_RESERVE) != ITK_ok)
										PrintErrorStack();
									printf("\n %d DataSet Checked Out \n", dataset);
								}
							}
							else
							{
								printf("\nSkipping IMAN_reference relation checkout");
							}
						}
					}
				}
				// ObjectClassType,"Design Revision") loop ends
			}
			//}
		}

		char *ObjectClassTypeMatEngg = NULL;
		char *lifecycle_stateMatEngg = NULL;
		int updRelStatStamp = 0;
		if (AOM_UIF_ask_value(rev, "release_status_list", &lifecycle_stateMatEngg) != ITK_ok)
			PrintErrorStack();
		if (lifecycle_stateMatEngg != NULL)
		{
			if (tc_strcmp(lifecycle_stateMatEngg, "") == 0)
			{
				updRelStatStamp = 1;
			}
		}
		else
		{
			updRelStatStamp = 1;
		}
		if (updRelStatStamp == 1)
		{
			if (AOM_ask_value_string(rev, "object_type", &ObjectClassTypeMatEngg) != ITK_ok)
				PrintErrorStack();
			printf("\n\n Dataset ObjectClassType : 0%s0\n", ObjectClassTypeMatEngg);
			fflush(stdout);
			if (strcmp(ObjectClassTypeMatEngg, "T5_MatEnggPartRevision") == 0)
			{
				printf("\nInside Release Status Stamp\n");
				fflush(stdout);
				tag_t status_relMatEngg = NULLTAG;
				logical retainMatEngg = 0;
				char *ReleaseStatusMatEngg = NULL;

				ITKCALL(RELSTAT_create_release_status("T5_LcsReview", &status_relMatEngg));
				CALLAPI(AOM_ask_name(status_relMatEngg, &ReleaseStatusMatEngg));
				ITKCALL(RELSTAT_add_release_status(status_relMatEngg, 1, &rev, retainMatEngg));
				printf("\nAfter Release Status Stamp\n");
				fflush(stdout);
			}
		}
	}

	// For Revising Part
	//	if((strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) )
	// AmolPLJ
	{
		if ((tc_strstr(roleName, "APL") != NULL) || (tc_strstr(roleName, "MBOM") != NULL)) // APL USer STart //MBOM implementation for CV TZ-1.69
		{
			// if((strcmp(ReleaseStatus,"T5_LcsAplRlzd")==0)  || (strcmp(ReleaseStatus,"APLC Released")==0) || (strcmp(ReleaseStatus,"T5_LcsSTDWrkg")==0)  || (strcmp(ReleaseStatus,"STDSIC Working")==0)
			//|| (strcmp(ReleaseStatus,"T5_LcsStdRlzd")==0)  || (strcmp(ReleaseStatus,"STDSIC Released")==0)
			//|| (strcmp(ReleaseStatus,"T5_LcsAplvRlzd")==0)  || (strcmp(ReleaseStatus,"APLV Released")==0) || (strcmp(ReleaseStatus,"T5_LcsSTDvWrkg")==0)  || (strcmp(ReleaseStatus,"STDSIV Working")==0)
			//|| (strcmp(ReleaseStatus,"T5_LcsStdvRlzd")==0)  || (strcmp(ReleaseStatus,"STDSIV Released")==0))
			printf("\n 111 RelStat %s ,Revise RvwLCVal:%s ,RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s,RlzdActLcVal :%s,StdWrkLcVal :%s,StdWrkLcActVal : %s,StdRlzdLcVal :%s,StdRlzdActLcVal :%s,View:%s\n", RelStat, RvwLCVal, RvwLCActVal, WrkngLCVal, WrkngActLCVal, RlzdLcVal, RlzdActLcVal, StdWrkLcVal, StdWrkLcActVal, StdRlzdLcVal, StdRlzdActLcVal, View);
			fflush(stdout); // MBOM implementation for CV TZ-1.69
			// if((tc_strcmp(ReleaseStatus,RlzdActLcVal)==0) || (tc_strcmp(ReleaseStatus,RlzdLcVal)==0) || (tc_strstr(ReleaseStatus,StdWrkLcVal)!=NULL) || (tc_strstr(ReleaseStatus,StdRlzdLcVal)!=NULL) )  //MBOM implementation for CV TZ-1.69
			if ((tc_strstr(RelStat, RlzdActLcVal) != NULL) || (tc_strstr(RelStat, RlzdLcVal) != NULL) || (tc_strstr(RelStat, StdWrkLcVal) != NULL) || (tc_strstr(RelStat, StdWrkLcActVal) != NULL) || (tc_strstr(RelStat, StdRlzdLcVal) != NULL) || (tc_strstr(RelStat, StdRlzdActLcVal) != NULL)) // MBOM implementation for CV TZ-1.69 Backend 17-05-2023
			{
				if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)PrintErrorStack();
				printf("\n Attached Datasets2: %d\n", cnt);fflush(stdout);
				for (i = 0; i < cnt; i++)
				{
					dataset = attachments[i];

					if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
						PrintErrorStack();
					printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);fflush(stdout);

					if ((strcmp(ObjectClassType, "Design Revision Master") == 0) || strcmp(ObjectClassType, "T5_SparKitRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_clschmRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") == 0 || strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") == 0)
					{
						if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
							PrintErrorStack();
						printf("\n\n Revision Master Name :%s\n", ObjectName);
						fflush(stdout);
						oojname = strtok(ObjectName, "/");
						strcat(oojname, "/");
						printf("\n\n Name of Revision Master:%s\n", oojname);
						fflush(stdout);
						break;
					}
				}

				revi = strtok(Desc_obj2, ";");
				printf("\nValue of revi in revision : %s\n", revi);
				fflush(stdout);
				if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
					PrintErrorStack();
				if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
					PrintErrorStack();

				int bvr_count = 0;					//amm
				int viewcount = 0;					//amm
				tag_t *bvr_tag =NULL;				//amm
				char *bvr_ObjectName	= NULL;		//amm
				char *bvritemid	= NULL;				//amm
				char *bvrrev	= NULL;				//amm

				if (AOM_lock(rev))
					;

				if (strcmp(revi, "NR") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "A;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "A;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset));
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is A= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"A;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision A: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

							
							}
						}
				}
				if (strcmp(revi, "A") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "B;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "B;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is B= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for B_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for B rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"B;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision B: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "B") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "C;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "C;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is C= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for C_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for C rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"C;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision C: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "C") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "D;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "D;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is D= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for D_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for D rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"D;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision D: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "D") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "E;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "E;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is E= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for E_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for E rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"E;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision E: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "E") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "F;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "F;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is F= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for F_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for F rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"F;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision F: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "F") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "G;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "G;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is G= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for G_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for G rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"G;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision G: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "G") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "H;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "H;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is H= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for H_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for H rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"H;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision H: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "H") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "I;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "I;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is I= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for I_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for I rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"I;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision I: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);			
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "I") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "J;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "J;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is J= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for J_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for J rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"J;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision J: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "J") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "K;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "K;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is K= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for K_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for K rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"K;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision K: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "K") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "L;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "L;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is L= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for L_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for L rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"L;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision L: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "L") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "M;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "M;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is M= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for M_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for M rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"M;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision M: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "M") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "N;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "N;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is N= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for N_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for N rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"N;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision N: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "N") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "O;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "O;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is O= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for O_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for O rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"O;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision O: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "O") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "P;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "P;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is P= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for P_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for P rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"P;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision P: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "P") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Q;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Q;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is Q= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for Q_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Q rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Q;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Q: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "Q") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "R;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "R;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is R= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for R_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for R rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"R;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision R: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "R") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "S;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "S;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is S= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for S_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for S rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"S;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision S: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "S") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "T;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "T;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is T= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for T_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for T rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"T;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision T: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "T") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "U;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "U;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is U= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for U_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for U rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"U;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision U: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{
							
							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "U") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "V;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "V;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is V= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for V_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for V rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"V;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision V: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "V") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "W;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "W;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is W= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for W_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for W rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"W;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision W: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "W") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "X;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "X;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is X= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for X_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for X rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"X;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision X: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "X") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Y;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Y;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is Y= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for Y_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Y rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Y;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Y: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}
				}
				if (strcmp(revi, "Y") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Z;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Z;1");
					//strcat(oojname,"-MBOM View");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();

					//Code added by amm - for BVR revise for sequence1- A1 to Z1 object_name
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
						PrintErrorStack();

						printf("\nValue of BVR revi in---bvr_count is Z= : %d\n",bvr_count);fflush(stdout);

					if (bvr_count >0)
						{

						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nValue of revi in BVR revision for Z_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Z rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Z;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Z: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else{

							strcat(oojname,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();

										
							}
						}

				}
				//							if (strcmp(revi,"Z")==0)
				//							{
				//								if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack();
				//								strcat(oojname,"AA;1");
				//								if(AOM_lock(dataset));
				//								if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
				//								if(AOM_save_without_extensions(dataset))PrintErrorStack();
				//								if(AOM_unlock(dataset))PrintErrorStack();
				//							}

				printf("\n APL revi: [%d]\n", *revi);
				fflush(stdout);

				char Irevi[2];

				Irevi[0] = *revi;

				printf("\n APL Irevi[0]: [%d]\n", Irevi[0]);
				fflush(stdout);

				if ((Irevi[0]) == 90) // Z==090
				{
					if (POM_set_attr_string(1, &rev, attr_id, "a1;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "a1;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if ((strlen(revi) > 1) && (strcmp(revi, "NR") != 0)) // a1
				{
					char *sRevID = NULL;
					int IntRevID = 0;
					char *sSRevID = NULL;
					char *sNwRevID = NULL;
					char *sNwevID = NULL;
					char IreviN[2];

					sNwRevID = (char *)MEM_alloc(10);
					sNwevID = (char *)MEM_alloc(10);

					sRevID = subString(revi, 0, 1); //
					printf("\n  APL sRevID: [%d]\n", sRevID);
					fflush(stdout);

					strcpy(sNwevID, "");
					strcpy(sNwevID, sRevID);

					IreviN[0] = *sRevID;

					printf("\n APL IreviN[0]: [%d]\n", IreviN[0]);
					fflush(stdout);

					if ((IreviN[0]) >= 97)
					{
						printf("\n   APL sNwevID: [%d]\n", *sNwevID);
						fflush(stdout);

						// IntRevID = atoi(*sNwevID);
						printf("\n APL :: IntRevID is :: %d\n", IntRevID);
						fflush(stdout);
						IntRevID = *sNwevID + 1;
						printf("\n APL :: IntRevID after append :: %d\n", IntRevID);
						fflush(stdout);
						// sprintf(sSRevID, "%d",IntRevID);//b

						sSRevID = numToASCII(IntRevID);

						printf("\n APL :: sSRevID is :: %s\n", sSRevID);
						fflush(stdout);

						strcpy(sNwRevID, "");
						strcat(sNwRevID, sSRevID);
						strcat(sNwRevID, "1"); // b1
						strcat(sNwRevID, ";"); // b1;
						strcat(sNwRevID, "1"); // b1;1

						printf("\n APL :: sNwRevID is :: %s\n", sNwRevID);
						fflush(stdout);

						if (POM_set_attr_string(1, &rev, attr_id, sNwRevID) != ITK_ok)
							PrintErrorStack();
						strcat(oojname, sNwRevID);
						if (AOM_lock(dataset))
							;
						if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
							PrintErrorStack();
						if (AOM_save_without_extensions(dataset) != ITK_ok)
							PrintErrorStack();
						if (AOM_unlock(dataset) != ITK_ok)
							PrintErrorStack();
					}
				}

				/*
								if (strcmp(revi,"A")==0) if(POM_set_attr_string(1, &rev, attr_id, "B;1")) PrintErrorStack();
								if (strcmp(revi,"B")==0) if(POM_set_attr_string(1, &rev, attr_id, "C;1")) PrintErrorStack();
								if (strcmp(revi,"C")==0) if(POM_set_attr_string(1, &rev, attr_id, "D;1")) PrintErrorStack();
								if (strcmp(revi,"D")==0) if(POM_set_attr_string(1, &rev, attr_id, "E;1")) PrintErrorStack();
								if (strcmp(revi,"E")==0) if(POM_set_attr_string(1, &rev, attr_id, "F;1")) PrintErrorStack();
								if (strcmp(revi,"F")==0) if(POM_set_attr_string(1, &rev, attr_id, "G;1")) PrintErrorStack();
								if (strcmp(revi,"G")==0) if(POM_set_attr_string(1, &rev, attr_id, "H;1")) PrintErrorStack();
								if (strcmp(revi,"H")==0) if(POM_set_attr_string(1, &rev, attr_id, "I;1")) PrintErrorStack();
								if (strcmp(revi,"I")==0) if(POM_set_attr_string(1, &rev, attr_id, "J;1")) PrintErrorStack();
								if (strcmp(revi,"J")==0) if(POM_set_attr_string(1, &rev, attr_id, "K;1")) PrintErrorStack();
								if (strcmp(revi,"K")==0) if(POM_set_attr_string(1, &rev, attr_id, "L;1")) PrintErrorStack();
								if (strcmp(revi,"L")==0) if(POM_set_attr_string(1, &rev, attr_id, "M;1")) PrintErrorStack();
								if (strcmp(revi,"M")==0) if(POM_set_attr_string(1, &rev, attr_id, "N;1")) PrintErrorStack();
								if (strcmp(revi,"N")==0) if(POM_set_attr_string(1, &rev, attr_id, "O;1")) PrintErrorStack();
								if (strcmp(revi,"O")==0) if(POM_set_attr_string(1, &rev, attr_id, "P;1")) PrintErrorStack();
								if (strcmp(revi,"P")==0) if(POM_set_attr_string(1, &rev, attr_id, "Q;1")) PrintErrorStack();
								if (strcmp(revi,"Q")==0) if(POM_set_attr_string(1, &rev, attr_id, "R;1")) PrintErrorStack();
								if (strcmp(revi,"R")==0) if(POM_set_attr_string(1, &rev, attr_id, "S;1")) PrintErrorStack();
								if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "T;1")) PrintErrorStack();
								if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "U;1")) PrintErrorStack();
								if (strcmp(revi,"U")==0) if(POM_set_attr_string(1, &rev, attr_id, "V;1")) PrintErrorStack();
								if (strcmp(revi,"V")==0) if(POM_set_attr_string(1, &rev, attr_id, "W;1")) PrintErrorStack();
								if (strcmp(revi,"W")==0) if(POM_set_attr_string(1, &rev, attr_id, "X;1")) PrintErrorStack();
								if (strcmp(revi,"X")==0) if(POM_set_attr_string(1, &rev, attr_id, "Y;1")) PrintErrorStack();
								if (strcmp(revi,"Y")==0) if(POM_set_attr_string(1, &rev, attr_id, "Z;1")) PrintErrorStack();
								if (strcmp(revi,"Z")==0) if(POM_set_attr_string(1, &rev, attr_id, "AA;1")) PrintErrorStack();
				*/

				if (AOM_save_without_extensions(dataset) != ITK_ok)
					PrintErrorStack();
				if (AOM_unlock(dataset) != ITK_ok)
					PrintErrorStack();

				if (AOM_save_without_extensions(rev) != ITK_ok)
					PrintErrorStack();
				if (AOM_unlock(rev) != ITK_ok)
					PrintErrorStack();

				// Upendra
				printf("\n Upendra \n");
				fflush(stdout);
				t5removeAllReleaseStatus(rev);
				// MBOM implementation for CV TZ-1.69,Commented If block for multiplant logic implementation
				/*if(strcmp(PlantName,"APLC")==0)
			   {
			   ERROR_CALL (RELSTAT_create_release_status("T5_LcsAplReview",&status_rel));
			   }else  if(strcmp(PlantName,"APLV")==0)
			   {
			   ERROR_CALL (RELSTAT_create_release_status("T5_LcsAplvReview",&status_rel));
			   }
			   ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));*/
				ITKCALL(RELSTAT_create_release_status(RvwLCVal, &status_rel));	  // MBOM implementation for CV TZ-1.69
				ITKCALL(RELSTAT_add_release_status(status_rel, 1, &rev, retain)); // MBOM implementation for CV TZ-1.69
				// ERROR_CALL(ITK_set_bypass(TRUE));
				// MBOM implementation for CV TZ-1.69
				ERROR_CALL(AOM_refresh(rev, 1));
				ERROR_CALL(AOM_save_without_extensions(rev));

				ERROR_CALL(AOM_unlock(rev));

				// Dayanand
			}
		}
		//else if ((tc_strstr(roleName,"STD") != NULL) && (tc_strcmp(type_name,"T5_CkdDmyRevision") == 0)) // Added By Ketan 
		else if ((tc_strstr(roleName,"STD") != NULL) && ((tc_strcmp(type_name,"T5_CkdDmyRevision") == 0) || (tc_strcmp(Part_Type,"CKDVC") == 0))) // Added By Ketan 
		{
			printf("\n Ketan CKD Revise :  Inside Role STD and type_name => [%s] || Part_Type => [%s]\n",type_name,Part_Type);			

			printf("\n STD User Start \n");	fflush(stdout);

			get_CtrlVal_RelStateInfoRev(PlantName, RvwLCVal, RvwLCActVal, WrkngLCVal, WrkngActLCVal, RlzdLcVal, RlzdActLcVal, StdWrkLcVal, StdWrkLcActVal, StdRlzdLcVal, StdRlzdActLcVal, View); // MBOM implementation for CV TZ-1.69

			printf("\n 111 RelStat %s ,Revise RvwLCVal:%s ,RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s,RlzdActLcVal :%s,StdWrkLcVal :%s,StdWrkLcActVal : %s,StdRlzdLcVal :%s,StdRlzdActLcVal :%s,View:%s\n", RelStat, RvwLCVal, RvwLCActVal, WrkngLCVal, WrkngActLCVal, RlzdLcVal, RlzdActLcVal, StdWrkLcVal, StdWrkLcActVal, StdRlzdLcVal, StdRlzdActLcVal, View);fflush(stdout);
			
			if ((tc_strstr(RelStat, RlzdActLcVal) != NULL) || (tc_strstr(RelStat, RlzdLcVal) != NULL) || (tc_strstr(RelStat, StdWrkLcVal) != NULL) || (tc_strstr(RelStat, StdWrkLcActVal) != NULL) || (tc_strstr(RelStat, StdRlzdLcVal) != NULL) || (tc_strstr(RelStat, StdRlzdActLcVal) != NULL)) // MBOM implementation for CV TZ-1.69 Backend 17-05-2023
			{
				printf("\n Ketan CKD Revise: Test 1 \n");
			
				revi = strtok(Desc_obj2, ";");
				printf("\n Value of revi in revision : %s\n", revi);fflush(stdout);
				if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)PrintErrorStack();
				if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)PrintErrorStack();
			
				int bvr_count = 0;					
				int viewcount = 0;					
				tag_t *bvr_tag =NULL;				
				char *bvr_ObjectName	= NULL;		
				char *bvritemid	= NULL;				
				char *bvrrev	= NULL;
			
				char oojname_CKD[40];
			
				if (AOM_lock(rev));
			
				if (strcmp(revi,"NR") == 0)
				{
					printf("\n Inside NR \n");
					if (POM_set_attr_string(1, &rev, attr_id, "A;1") != ITK_ok)	PrintErrorStack();
					printf("\n Before oojname_CKD => %s \n",oojname_CKD);fflush(stdout);
					tc_strcpy(oojname_CKD, "A;1");
					printf("\n After oojname_CKD => %s \n",oojname_CKD);fflush(stdout);
					
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\n Value of BVR revi in---bvr_count is A= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"A;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision A: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();				
						}
					}
				}
				if (strcmp(revi, "A") == 0)
				{
					printf("\n Inside A \n");
					if (POM_set_attr_string(1, &rev, attr_id, "B;1") != ITK_ok)PrintErrorStack();
					printf("\n Before oojname_CKD => %s \n",oojname_CKD);fflush(stdout);
					tc_strcpy(oojname_CKD, "B;1");
					printf("\n After oojname_CKD => %s \n",oojname_CKD);fflush(stdout);
			
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is B= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for B_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for B rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"B;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision B: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();							
						}
					}
				}
				if (strcmp(revi, "B") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "C;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "C;1");	
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is C= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for C_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for C rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"C;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision C: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "C") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "D;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "D;1");		
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is D= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for D_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for D rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"D;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision D: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "D") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "E;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "E;1");
										
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is E= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for E_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for E rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"E;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision E: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "E") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "F;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "F;1");
										
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is F= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for F_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for F rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"F;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision F: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "F") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "G;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "G;1");
					
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is G= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for G_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for G rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"G;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision G: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "G") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "H;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "H;1");
										
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is H= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for H_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for H rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"H;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision H: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "H") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "I;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "I;1");
										
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is I= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for I_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for I rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"I;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision I: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);			
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "I") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "J;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "J;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is J= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for J_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for J rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"J;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision J: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "J") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "K;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "K;1");
					
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is K= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for K_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for K rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"K;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision K: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "K") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "L;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "L;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is L= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for L_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for L rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"L;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision L: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "L") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "M;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "M;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is M= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for M_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for M rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"M;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision M: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "M") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "N;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "N;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is N= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for N_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for N rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"N;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision N: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "N") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "O;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "O;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is O= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for O_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for O rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"O;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision O: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "O") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "P;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "P;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is P= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for P_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for P rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"P;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision P: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "P") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Q;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "Q;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
						printf("\nValue of BVR revi in---bvr_count is Q= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for Q_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Q rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Q;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Q: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "Q") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "R;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "R;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is R= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for R_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for R rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"R;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision R: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "R") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "S;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "S;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is S= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for S_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for S rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"S;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision S: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);	
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "S") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "T;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "T;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is T= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for T_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for T rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"T;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision T: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "T") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "U;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "U;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is U= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for U_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for U rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"U;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision U: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{							
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "U") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "V;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "V;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is V= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for V_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for V rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"V;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision V: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "V") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "W;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "W;1");
								
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is W= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for W_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for W rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"W;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision W: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "W") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "X;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "X;1");

					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is X= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for X_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for X rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"X;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision X: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "X") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Y;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "Y;1");
					
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();			
					printf("\nValue of BVR revi in---bvr_count is Y= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for Y_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Y rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Y;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Y: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{			
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}
				}
				if (strcmp(revi, "Y") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Z;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "Z;1");
					
					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)PrintErrorStack();
			
					printf("\nValue of BVR revi in---bvr_count is Z= : %d\n",bvr_count);fflush(stdout);
			
					if (bvr_count >0)
					{			
						if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)PrintErrorStack();
						printf("\nValue of revi in BVR revision for Z_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev=strtok(NULL,"_");
						printf("\nValue of revi in BVR revision for Z rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						if (strcmp(bvrrev,"Z;1")==0)
						{
							printf("\n alredy bvr is present Value of revi in revision Z: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
						}
						else
						{		
							tc_strcpy(oojname_CKD,"-MBOM View");
							printf("\n esle alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_CKD);fflush(stdout);
							if(AOM_lock(bvr_tag[0]));
							if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_CKD)!=ITK_ok)PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();										
						}
					}			
				}
				
				printf("\n APL revi: [%d]\n", *revi);fflush(stdout);
			
				char Irevi[2];			
				Irevi[0] = *revi;
			
				printf("\n APL Irevi[0]: [%d]\n", Irevi[0]);	fflush(stdout);
			
				if ((Irevi[0]) == 90) // Z==090
				{
					if (POM_set_attr_string(1, &rev, attr_id, "a1;1") != ITK_ok)PrintErrorStack();
					tc_strcpy(oojname_CKD, "a1;1");					
				}
				if ((strlen(revi) > 1) && (strcmp(revi, "NR") != 0)) // a1
				{
					char *sRevID = NULL;
					int IntRevID = 0;
					char *sSRevID = NULL;
					char *sNwRevID = NULL;
					char *sNwevID = NULL;
					char IreviN[2];
			
					sNwRevID = (char *)MEM_alloc(10);
					sNwevID = (char *)MEM_alloc(10);
			
					sRevID = subString(revi, 0, 1); //
					printf("\n  APL sRevID: [%d]\n", sRevID);fflush(stdout);
			
					strcpy(sNwevID, "");
					strcpy(sNwevID, sRevID);
			
					IreviN[0] = *sRevID;
			
					printf("\n APL IreviN[0]: [%d]\n", IreviN[0]);fflush(stdout);
			
					if ((IreviN[0]) >= 97)
					{
						printf("\n   APL sNwevID: [%d]\n", *sNwevID);fflush(stdout);
			
						printf("\n APL :: IntRevID is :: %d\n", IntRevID);fflush(stdout);
						IntRevID = *sNwevID + 1;
						printf("\n APL :: IntRevID after append :: %d\n", IntRevID);fflush(stdout);
						
						sSRevID = numToASCII(IntRevID);
			
						printf("\n APL :: sSRevID is :: %s\n", sSRevID);fflush(stdout);
			
						strcpy(sNwRevID, "");
						strcat(sNwRevID, sSRevID);
						strcat(sNwRevID, "1"); // b1
						strcat(sNwRevID, ";"); // b1;
						strcat(sNwRevID, "1"); // b1;1
			
						printf("\n APL :: sNwRevID is :: %s\n", sNwRevID);fflush(stdout);
			
						if (POM_set_attr_string(1, &rev, attr_id, sNwRevID) != ITK_ok)PrintErrorStack();
						strcat(oojname_CKD, sNwRevID);							
					}
				}
			
				if (AOM_save_without_extensions(rev) != ITK_ok)PrintErrorStack();
				if (AOM_unlock(rev) != ITK_ok)PrintErrorStack();
			
				printf("\n Ketannnnnnnnnnnnnnn \n");			fflush(stdout);
				ERROR_CALL(AOM_refresh(rev, 1));
				ERROR_CALL(AOM_save_without_extensions(rev));
			
				ERROR_CALL(AOM_unlock(rev));
				
			}
		}
		else // ERC USer Start
		{
			printf("\n Release status for revising : %s\n", ReleaseStatus);fflush(stdout);
			// If releasestatus string contains Released word then proceed..

			// if(tc_strstr(ReleaseStatus,"Rlzd")!=NULL)//RelStat
			if (tc_strstr(RelStat, "T5_LcsErcRlzd") != NULL)
			{
				// Added by Ayush
				tag_t *old_bvr_list = NULL;			// Ayush
				int bvr_count1 = 0;					// Ayush
				tag_t new_bvr = NULLTAG;			// Ayush
														
				int viewcount = 0;					// Ayush
				tag_t *bvr_tag1 =NULL;				// Ayush
				char *bvr_ObjectName	= NULL;		// Ayush
				char *bvritemid	= NULL;				// Ayush
				char *bvrrev1	= NULL;				// Ayush
				char *oojname_bvr	= NULL;				// Ayush

				oojname_bvr = (char *)MEM_alloc(50);

				if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)PrintErrorStack();
				printf("\n Attached Datasets2: %d\n", cnt);fflush(stdout);
				for (i = 0; i < cnt; i++)
				{
					dataset = attachments[i];

					if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
						PrintErrorStack();
					printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
					fflush(stdout);

					if ((strcmp(ObjectClassType, "Design Revision Master") == 0) || (strcmp(ObjectClassType, "T5_SparKitRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_clschmRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_EE_PartRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_MatEnggPartRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_Std_WcqRevisionMaster") == 0) || (strcmp(ObjectClassType, "T5_VODRevisionMaster") == 0))
					{
						if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
							PrintErrorStack();
						printf("\n\n Revision Master Name :%s\n", ObjectName);
						fflush(stdout);
						oojname = strtok(ObjectName, "/");
						strcat(oojname, "/");
						printf("\n\n Name of Revision Master:%s\n", oojname);
						fflush(stdout);
						break;
					}
				}

				revi = strtok(Desc_obj2, ";");
				printf("\nValue of revi in revision : %s\n", revi);
				fflush(stdout);

				if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
					PrintErrorStack();
				printf("\nitem_revision_id spa \n");
				fflush(stdout);
				if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
					PrintErrorStack();
				printf("\nobject_name form spa \n");
				fflush(stdout);

				if (AOM_lock(rev))
					;

				if (strcmp(revi, "NR") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "A;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "A;1");

					// Added by Ayush

					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count1, &bvr_tag1) != ITK_ok)
					PrintErrorStack();

					printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count1);fflush(stdout);

					if (bvr_count1 >0)
					{
						//oojname_bvr = (char **)MEM_alloc(5 * sizeof(char *));

						if (AOM_ask_value_string(bvr_tag1[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nERC-UA1.89--Value of revi in BVR revision for NR_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev1=strtok(NULL,"-");
						printf("\nERC-UA1.89--Value of revi in BVR revision for NR rev : %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						if (strcmp(bvrrev1,"A;1")==0)
						{
							printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision : %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						}
						else{
							strcpy(oojname_bvr, bvritemid);
							strcat(oojname_bvr, "/A;1");
							strcat(oojname_bvr,"-View");
							printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev1,oojname_bvr);fflush(stdout);
							if(AOM_lock(bvr_tag1[0])) PrintErrorStack();
							if(POM_set_attr_string(1, &bvr_tag1[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
						}
					}

					// ****************

					if (AOM_lock(dataset))
						PrintErrorStack();
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "A") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "B;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "B;1");

					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count1, &bvr_tag1) != ITK_ok)PrintErrorStack();

					printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count1);fflush(stdout);

					if (bvr_count1 >0)
					{

						if (AOM_ask_value_string(bvr_tag1[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nERC-UA1.89--Value of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev1=strtok(NULL,"-");
						printf("\nERC-UA1.89--Value of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						if (strcmp(bvrrev1,"A;1")==0)
						{
							printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision A: %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						}
						else{
							strcpy(oojname_bvr, bvritemid);
							strcat(oojname_bvr, "/B;1");
							strcat(oojname_bvr,"-View");
							printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev1,oojname_bvr);fflush(stdout);
							if(AOM_lock(bvr_tag1[0])) PrintErrorStack();
							if(POM_set_attr_string(1, &bvr_tag1[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
						}
					}

					if (AOM_lock(dataset))
						PrintErrorStack();
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "B") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "C;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "C;1");

					if (ITEM_rev_list_bom_view_revs(rev,&bvr_count1, &bvr_tag1) != ITK_ok) PrintErrorStack();

					printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count1);fflush(stdout);

					if (bvr_count1 >0)
					{

						if (AOM_ask_value_string(bvr_tag1[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\nERC-UA1.89--Value of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
						bvritemid=strtok(bvr_ObjectName,"/");
						bvrrev1=strtok(NULL,"-");
						printf("\nERC-UA1.89--Value of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						if (strcmp(bvrrev1,"B;1")==0)
						{
							printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision : %s :%s\n",bvritemid,bvrrev1);fflush(stdout);
						}
						else{
							strcpy(oojname_bvr, bvritemid);
							strcat(oojname_bvr, "/C;1");
							strcat(oojname_bvr,"-View");
							printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev1,oojname_bvr);fflush(stdout);
							if(AOM_lock(bvr_tag1[0]))PrintErrorStack();
							if(POM_set_attr_string(1, &bvr_tag1[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
							if(AOM_save_without_extensions(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
							if(AOM_unlock(bvr_tag1[0])!=ITK_ok)PrintErrorStack();
						}
					}

					if (AOM_lock(dataset))
						PrintErrorStack();
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "C") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "D;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "D;1");
					if (AOM_lock(dataset))
						PrintErrorStack();
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "D") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "E;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "E;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "E") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "F;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "F;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "F") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "G;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "G;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "G") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "H;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "H;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "H") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "I;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "I;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "I") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "J;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "J;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "J") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "K;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "K;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "K") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "L;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "L;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "L") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "M;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "M;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "M") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "N;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "N;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "N") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "O;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "O;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "O") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "P;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "P;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "P") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Q;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Q;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "Q") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "R;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "R;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "R") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "S;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "S;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "S") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "T;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "T;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "T") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "U;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "U;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "U") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "V;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "V;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "V") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "W;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "W;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "W") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "X;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "X;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "X") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Y;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Y;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if (strcmp(revi, "Y") == 0)
				{
					if (POM_set_attr_string(1, &rev, attr_id, "Z;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "Z;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				//				if (strcmp(revi,"Z")==0)
				//				{
				//					if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack();
				//					strcat(oojname,"AA;1");
				//					if(AOM_lock(dataset));
				//					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
				//					if(AOM_save_without_extensions(dataset))PrintErrorStack();
				//					if(AOM_unlock(dataset))PrintErrorStack();
				//				}

				printf("\n revi: [%d]\n", *revi);
				fflush(stdout);

				char Irevi[2];

				Irevi[0] = *revi;

				printf("\n Irevi[0]: [%d]\n", Irevi[0]);
				fflush(stdout);

				if ((Irevi[0]) == 90) // Z==090
				{
					if (POM_set_attr_string(1, &rev, attr_id, "a1;1") != ITK_ok)
						PrintErrorStack();
					strcat(oojname, "a1;1");
					if (AOM_lock(dataset))
						;
					if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
						PrintErrorStack();
					if (AOM_save_without_extensions(dataset) != ITK_ok)
						PrintErrorStack();
					if (AOM_unlock(dataset) != ITK_ok)
						PrintErrorStack();
				}
				if ((strlen(revi) > 1) && (strcmp(revi, "NR") != 0)) // a1
				{
					char *sRevID = NULL;
					int IntRevID = 0;
					char *sSRevID = NULL;
					char *sNwRevID = NULL;
					char *sNwevID = NULL;
					char IreviN[2];

					sNwRevID = (char *)MEM_alloc(10);
					sNwevID = (char *)MEM_alloc(10);

					sRevID = subString(revi, 0, 1); //
					printf("\n sRevID: [%d]\n", sRevID);
					fflush(stdout);

					strcpy(sNwevID, "");
					strcpy(sNwevID, sRevID);

					IreviN[0] = *sRevID;

					printf("\n IreviN[0]: [%d]\n", IreviN[0]);
					fflush(stdout);

					if ((IreviN[0]) >= 97)
					{
						printf("\n sNwevID: [%d]\n", *sNwevID);
						fflush(stdout);

						// IntRevID = atoi(*sNwevID);
						printf("\n :: IntRevID is :: %d\n", IntRevID);
						fflush(stdout);
						IntRevID = *sNwevID + 1;
						printf("\n :: IntRevID after append :: %d\n", IntRevID);
						fflush(stdout);
						// sprintf(sSRevID, "%d",IntRevID);//b

						sSRevID = numToASCII(IntRevID);

						printf("\n :: sSRevID is :: %s\n", sSRevID);
						fflush(stdout);

						strcpy(sNwRevID, "");
						strcat(sNwRevID, sSRevID);
						strcat(sNwRevID, "1"); // b1
						strcat(sNwRevID, ";"); // b1;
						strcat(sNwRevID, "1"); // b1;1

						printf("\n :: sNwRevID is :: %s\n", sNwRevID);
						fflush(stdout);

						if (POM_set_attr_string(1, &rev, attr_id, sNwRevID) != ITK_ok)
							PrintErrorStack();
						strcat(oojname, sNwRevID);
						if (AOM_lock(dataset))
							;
						if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
							PrintErrorStack();
						if (AOM_save_without_extensions(dataset) != ITK_ok)
							PrintErrorStack();
						if (AOM_unlock(dataset) != ITK_ok)
							PrintErrorStack();
					}
				}

				/*
								if (strcmp(revi,"A")==0) if(POM_set_attr_string(1, &rev, attr_id, "B;1")) PrintErrorStack();
								if (strcmp(revi,"B")==0) if(POM_set_attr_string(1, &rev, attr_id, "C;1")) PrintErrorStack();
								if (strcmp(revi,"C")==0) if(POM_set_attr_string(1, &rev, attr_id, "D;1")) PrintErrorStack();
								if (strcmp(revi,"D")==0) if(POM_set_attr_string(1, &rev, attr_id, "E;1")) PrintErrorStack();
								if (strcmp(revi,"E")==0) if(POM_set_attr_string(1, &rev, attr_id, "F;1")) PrintErrorStack();
								if (strcmp(revi,"F")==0) if(POM_set_attr_string(1, &rev, attr_id, "G;1")) PrintErrorStack();
								if (strcmp(revi,"G")==0) if(POM_set_attr_string(1, &rev, attr_id, "H;1")) PrintErrorStack();
								if (strcmp(revi,"H")==0) if(POM_set_attr_string(1, &rev, attr_id, "I;1")) PrintErrorStack();
								if (strcmp(revi,"I")==0) if(POM_set_attr_string(1, &rev, attr_id, "J;1")) PrintErrorStack();
								if (strcmp(revi,"J")==0) if(POM_set_attr_string(1, &rev, attr_id, "K;1")) PrintErrorStack();
								if (strcmp(revi,"K")==0) if(POM_set_attr_string(1, &rev, attr_id, "L;1")) PrintErrorStack();
								if (strcmp(revi,"L")==0) if(POM_set_attr_string(1, &rev, attr_id, "M;1")) PrintErrorStack();
								if (strcmp(revi,"M")==0) if(POM_set_attr_string(1, &rev, attr_id, "N;1")) PrintErrorStack();
								if (strcmp(revi,"N")==0) if(POM_set_attr_string(1, &rev, attr_id, "O;1")) PrintErrorStack();
								if (strcmp(revi,"O")==0) if(POM_set_attr_string(1, &rev, attr_id, "P;1")) PrintErrorStack();
								if (strcmp(revi,"P")==0) if(POM_set_attr_string(1, &rev, attr_id, "Q;1")) PrintErrorStack();
								if (strcmp(revi,"Q")==0) if(POM_set_attr_string(1, &rev, attr_id, "R;1")) PrintErrorStack();
								if (strcmp(revi,"R")==0) if(POM_set_attr_string(1, &rev, attr_id, "S;1")) PrintErrorStack();
								if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "T;1")) PrintErrorStack();
								if (strcmp(revi,"S")==0) if(POM_set_attr_string(1, &rev, attr_id, "U;1")) PrintErrorStack();
								if (strcmp(revi,"U")==0) if(POM_set_attr_string(1, &rev, attr_id, "V;1")) PrintErrorStack();
								if (strcmp(revi,"V")==0) if(POM_set_attr_string(1, &rev, attr_id, "W;1")) PrintErrorStack();
								if (strcmp(revi,"W")==0) if(POM_set_attr_string(1, &rev, attr_id, "X;1")) PrintErrorStack();
								if (strcmp(revi,"X")==0) if(POM_set_attr_string(1, &rev, attr_id, "Y;1")) PrintErrorStack();
								if (strcmp(revi,"Y")==0) if(POM_set_attr_string(1, &rev, attr_id, "Z;1")) PrintErrorStack();
								if (strcmp(revi,"Z")==0) if(POM_set_attr_string(1, &rev, attr_id, "AA;1")) PrintErrorStack();
				*/

				//if (AOM_save_without_extensions(dataset) != ITK_ok) PrintErrorStack();  //Commented due to error of instance is not locked on date 25.08.2026
				//if (AOM_unlock(dataset) != ITK_ok) PrintErrorStack();

				if (AOM_save_without_extensions(rev) != ITK_ok) PrintErrorStack();
				if (AOM_unlock(rev) != ITK_ok)PrintErrorStack();

				// remove relation of color scheme and it's attached svr with applicable svr
				TC_write_syslog("\n remove relation of color scheme and it's attached svr with applicable svr \n");

				tag_t dataset_relation_type = NULLTAG;
				int dataset_cnt = 0;
				tag_t *DatasetList = NULLTAG;
				char *clr_rev_id = NULL;
				int t = 0;
				tag_t relation_tag = NULLTAG;

				if (GRM_find_relation_type("T5_Applicable_SVR", &dataset_relation_type) != ITK_ok)
					PrintErrorStack();

				if (GRM_list_secondary_objects_only(rev, dataset_relation_type, &dataset_cnt, &DatasetList) != ITK_ok)
					PrintErrorStack();
				TC_write_syslog("dataset_cnt ::  %d\n", dataset_cnt);

				if (AOM_ask_value_string(rev, "item_revision_id", &clr_rev_id) != ITK_ok)
					PrintErrorStack();
				TC_write_syslog("clr_rev_id ==  %s\n", clr_rev_id);

				if (tc_strcmp(clr_rev_id, "NR;1") != 0)
				{
					for (t = 0; t < dataset_cnt; t++)
					{
						TC_write_syslog("t==  %d\n", t);

						if (GRM_find_relation(rev, DatasetList[t], dataset_relation_type, &relation_tag) != ITK_ok)
							PrintErrorStack();
						TC_write_syslog("\n clr schm and svr relation found\n");

						if (GRM_delete_relation(relation_tag) != ITK_ok)
							PrintErrorStack();
						TC_write_syslog("\n clr schm and svr relation deleted \n");
					}
				}

				if (AOM_save_without_extensions(rev) != ITK_ok) PrintErrorStack();
				if (AOM_unlock(rev) != ITK_ok) PrintErrorStack();

				// Upendra
				printf("\n Before Revise/Check-out release status set \n");fflush(stdout);
				

				t5removeAllReleaseStatus(rev);
				ITKCALL(RELSTAT_create_release_status("T5_LcsReview", &status_rel));
				ITKCALL(RELSTAT_add_release_status(status_rel, 1, &rev, retain));
				// ERROR_CALL(ITK_set_bypass(TRUE));
				ERROR_CALL(AOM_refresh(rev, 1));
				ERROR_CALL(AOM_save_without_extensions(rev));
				ERROR_CALL(AOM_unlock(rev));

				// Upendra

				// Adi add 4D Doc rel status START here 2021

				tag_t RelationFind4D = NULLTAG;
				tag_t RelationFindDfmea = NULLTAG;
				tag_t relationTag4D = NULLTAG;
				tag_t relationTagDfmea = NULLTAG;
				int sec_count4D = 0;
				int sec_countDfmea = 0;
				int iQ = 0;
				int dQ = 0;
				tag_t *sec_objects4D = NULLTAG;
				tag_t *sec_objectsDfmea = NULLTAG;
				logical retain_released_date4D = TRUE;
				logical retain_released_dateDfmea = TRUE;
				tag_t release_status4D = NULLTAG;
				tag_t release_statusDfmea = NULLTAG;
				tag_t status_rel4D = NULLTAG;
				tag_t status_relDfmea = NULLTAG;
				char *ReleaseStatus4D = NULL;
				char *ReleaseStatusDfmea = NULL;

				if (GRM_find_relation_type("T5_PartHas4D", &RelationFind4D))
					;

				if (RelationFind4D != NULLTAG)
				{
					printf("\n Revise Post Inside for 4D After finding RelType \n");
					fflush(stdout);
					CALLAPI(GRM_list_secondary_objects_only(rev, RelationFind4D, &sec_count4D, &sec_objects4D));
					printf("\n for 4D Total objects found---------------%d \n", sec_count4D);
					if (sec_count4D > 0)

					{
						printf("\n inside sec_count4D revise post  find - --------- %d\n", sec_count4D);
						fflush(stdout);
						for (iQ = 0; iQ < sec_count4D; iQ++)
						{
							relationTag4D = sec_objects4D[iQ];
							printf("\n For loop inside sec count find---------\n");
							fflush(stdout);
							// CALLAPI(GRM_find_relation(rev, sec_objects[iQ], RelationFind4D, &relationTag4D));

							if (relationTag4D != NULLTAG)
							{
								CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd", &release_status4D));
								CALLAPI(AOM_ask_name(release_status4D, &ReleaseStatus4D));

								if ((strcmp(ReleaseStatus4D, "ERC Released") == 0) || strcmp(ReleaseStatus4D, "T5_LcsErcRlzd") == 0)
								{
									printf("\n before removing all rel status ---------\n");
									fflush(stdout);
									t5removeAllReleaseStatus(relationTag4D);
									ITKCALL(RELSTAT_create_release_status("T5_LcsReview", &status_rel4D));
									ITKCALL(RELSTAT_add_release_status(status_rel4D, 1, &relationTag4D, retain_released_date4D));
									printf("\n after adding rel status ERC Review---------\n");
									fflush(stdout);
									// ERROR_CALL(ITK_set_bypass(TRUE));

									ERROR_CALL(AOM_refresh(relationTag4D, 1));
									ERROR_CALL(AOM_save_without_extensions(relationTag4D));

									ERROR_CALL(AOM_unlock(relationTag4D));
								}
							}
						}
					}
				}

				if (GRM_find_relation_type("T5_PartHasDfmea", &RelationFindDfmea))
					;

				if (RelationFindDfmea != NULLTAG)
				{
					printf("\n Revise Post Inside for 4D After finding RelType \n");
					fflush(stdout);
					CALLAPI(GRM_list_secondary_objects_only(rev, RelationFindDfmea, &sec_countDfmea, &sec_objectsDfmea));
					printf("\n for 4D Total objects found---------------%d \n", sec_countDfmea);
					if (sec_countDfmea > 0)
					{
						printf("\n inside sec_countDfmea revise post  find - --------- %d\n", sec_countDfmea);
						fflush(stdout);
						for (dQ = 0; dQ < sec_countDfmea; dQ++)
						{
							relationTagDfmea = sec_objectsDfmea[dQ];
							printf("\n For loop inside sec count find---------\n");
							fflush(stdout);
							// CALLAPI(GRM_find_relation(rev, sec_objects[iQ], RelationFindDfmea, &relationTag4D));

							if (relationTagDfmea != NULLTAG)
							{
								CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd", &release_statusDfmea));
								CALLAPI(AOM_ask_name(release_statusDfmea, &ReleaseStatusDfmea));

								if ((tc_strcmp(ReleaseStatusDfmea, "ERC Released") == 0) || tc_strcmp(ReleaseStatusDfmea, "T5_LcsErcRlzd") == 0)
								{
									printf("\n before removing all rel status ---------\n");
									fflush(stdout);
									t5removeAllReleaseStatus(relationTagDfmea);
									ITKCALL(RELSTAT_create_release_status("T5_LcsReview", &status_relDfmea));
									ITKCALL(RELSTAT_add_release_status(status_relDfmea, 1, &relationTagDfmea, retain_released_dateDfmea));
									printf("\n after adding rel status ERC Review---------\n");
									fflush(stdout);
									// ERROR_CALL(ITK_set_bypass(TRUE));

									ITKCALL(AOM_refresh(relationTagDfmea, 1));
									ITKCALL(AOM_save_without_extensions(relationTagDfmea));

									ITKCALL(AOM_unlock(relationTagDfmea));
								}
							}
						}
					}
				}

				// Rohit Start

				tag_t tRelationFindRepFor = NULLTAG;
				tag_t tRelationFindRepForPrimary = NULLTAG;
				tag_t Rep_relation = NULLTAG;
				tag_t Primary_relation = NULLTAG;
				tag_t *sec_objectsRepFor = NULLTAG;
				tag_t tag_primaryobj = NULLTAG;
				tag_t latest_rev = NULLTAG;
				int sec_countRepFor = 0;
				int IR = 0;
				int IP = 0;
				int primary_count = 0;
				tag_t relationTagRepFor = NULLTAG;
				tag_t primary_objsfast = NULLTAG;
				char *Color_Ind = NULL;
				tag_t *primary_gobjects = NULLTAG;

				char *revID_REV1 = NULL;
				char *revID_REV2 = NULL;
				char *revID_REV3 = NULL;
				char *revID_REV4 = NULL;
				char *ID_REV2 = NULL;
				char *ID_REV = NULL;
				char *item_idfast = NULL;
				char *Clr_Part_Type = NULL;
				char *Source_ID = NULL;
				char *rev_ID = NULL;
				char *rev_seq = NULL;
				char *primaryobj_ID = NULL;
				char *latest_rev_ID = NULL;
				char *latest_rev_seq = NULL;

				tag_t repfor_CntrlOBJ = NULLTAG;
				int repfor_entries = 1;
				int repfor_found = 0;
				tag_t *CntrlObject_repfor = NULLTAG;

				if (QRY_find2("Control Objects...", &repfor_CntrlOBJ))
					;
				printf("\n\nFastCVBUCntrlObj Query Found\n\n");
				fflush(stdout);

				char *qry_repforcntrl[1] = {"SYSCD"};

				char **qry_valuesrepfor = (char **)MEM_alloc(10 * sizeof(char *));

				qry_valuesrepfor[0] = "RepForControlObj";

				if (QRY_execute(repfor_CntrlOBJ, repfor_entries, qry_repforcntrl, qry_valuesrepfor, &repfor_found, &CntrlObject_repfor))
					;
				printf("\n\n  Representation For SYSCD :%d\n", repfor_found);
				fflush(stdout);
				if (repfor_found > 0)

				{

					printf("\n\nInside Representation For Code\n\n");
					fflush(stdout);
					if (AOM_ask_value_string(rev, "t5_ColourInd", &Color_Ind))
						; // Get Color Indicator for Base Part
					printf("\nColor Indicator is :%s", Color_Ind);
					fflush(stdout);

					// if(AOM_ask_value_string(rev,"item_revision_id",&revID_REV1));
					// printf("\nRevision ID for rev is [%s]",revID_REV1);	fflush(stdout);

					if (AOM_ask_value_string(rev1, "item_revision_id", &revID_REV2))
						;
					// printf("\nRevision ID for rev1 is [%s]",revID_REV2);	fflush(stdout);

					if (AOM_ask_value_string(source_rev, "item_revision_id", &revID_REV3))
						;
					if (AOM_ask_value_string(source_rev, "item_id", &Source_ID))
						;
					printf("\nRevision ID and seq for source_rev is [%s] and [%s]", Source_ID, revID_REV3);
					fflush(stdout);

					// if(AOM_ask_value_string(revi,"item_revision_id",&revID_REV4));
					// printf("\nRevision ID for revi is [%s]",revID_REV4);	fflush(stdout);

					if ((strcmp(ObjectClassType, "Design Revision") == 0) || (strcmp(ObjectClassType, "Design Revision Master") == 0))
					{
						printf("\nCurrent Object type is Design Revision\n");
						fflush(stdout);
						if (strcmp(Color_Ind, "Y") == 0)
						{
							printf("\nCurrent Object type is Design Revision with Color Indicator as [Y]\n");
							fflush(stdout);
							if (GRM_find_relation_type("TC_Is_Represented_By", &tRelationFindRepFor))
								;
							printf("\nRepresentation relation is found OUTSIDE...........\n");

							if (tRelationFindRepFor != NULLTAG)
							{
								if (AOM_ask_value_string(source_rev, "item_id", &ID_REV2) != ITK_ok)
									PrintErrorStack();
								if (AOM_ask_value_string(source_rev, "item_revision_id", &ID_REV) != ITK_ok)
									PrintErrorStack();
								printf("\nItem ID and Revision Sequcence for Source REV is [%s] [%s]", ID_REV2, ID_REV);
								fflush(stdout);

								printf("\nRepresentation relation is found INSIDE..........\n");
								printf("\n Revise Post Inside for Representation For After finding RelType \n");
								fflush(stdout);
								//							if(GRM_list_secondary_objects_only(source_rev, tRelationFindRepFor, &sec_countRepFor, &sec_objectsRepFor));
								//							printf("\n for Representation For Total objects found =====> [%d] \n", sec_countRepFor);
								//							if(sec_countRepFor > 0)
								//							{
								//								printf("\n INSIDE Representation For revise post  find - --------- %d\n", sec_objectsRepFor);fflush(stdout);
								//
								//								for(IR=0;IR<sec_countRepFor;IR++)
								//								{
								//									relationTagRepFor=sec_objectsRepFor[IR];
								//									printf("\n For loop inside sec count find---------\n");fflush(stdout);
								//									//CALLAPI(GRM_find_relation(rev, sec_objects[IR], tRelationFindRepFor, &relationTagRepFor));
								//
								//									if (relationTagRepFor != NULLTAG)
								//									{
								//										if(GRM_create_relation(rev,relationTagRepFor,tRelationFindRepFor,NULLTAG,&Rep_relation));
								//										if(GRM_save_relation(Rep_relation));
								//									}
								//								}
								//							}

								if (GRM_list_primary_objects_only(source_rev, tRelationFindRepFor, &primary_count, &primary_gobjects) != ITK_ok)
									PrintErrorStack();
								if (primary_count > 0)
								{
									printf("\n INSIDE Primary API - --------- \n");
									fflush(stdout);
									printf("\n Number of Objects in REPRESENTED BY relation is [%d] \n", primary_count);
									fflush(stdout);
									for (IP = 0; IP < primary_count; IP++)
									{
										primary_objsfast = primary_gobjects[IP];

										if (AOM_ask_value_string(primary_objsfast, "current_id", &item_idfast) != ITK_ok)
											PrintErrorStack();
										printf("\nPrimary Object is : [%s]", item_idfast);
										fflush(stdout);

										if (AOM_ask_value_string(primary_objsfast, "object_type", &Clr_Part_Type) != ITK_ok)
											PrintErrorStack();
										// printf("TYPE of color part is [%s]",Clr_Part_Type); fflush(stdout);

										if (tc_strcmp(Clr_Part_Type, "T5_ClrPartRevision") == 0)
										{
											// if (primary_objsfast != NULLTAG)
											//{
											// if(ITEM_ask_latest_rev(master,&rev));

											if (AOM_ask_value_string(primary_objsfast, "item_id", &primaryobj_ID) != ITK_ok)
												PrintErrorStack();
											printf("\nItem ID for rev is [%s]", primaryobj_ID);
											fflush(stdout);

											if (ITEM_find_item(primaryobj_ID, &tag_primaryobj))
												;
											if (ITEM_ask_latest_rev(tag_primaryobj, &latest_rev))
												;

											if (AOM_ask_value_string(tag_primaryobj, "item_id", &latest_rev_ID))
												;
											if (AOM_ask_value_string(latest_rev, "item_revision_id", &latest_rev_seq))
												;
											printf("\nRevision ID for rev is [%s] and [%s]", latest_rev_ID, latest_rev_seq);
											fflush(stdout);

											if (GRM_find_relation_type("TC_Is_Represented_By", &tRelationFindRepForPrimary))
												;

											printf("\nInside Create relation by ROHIT\n");
											fflush(stdout);
											if (GRM_create_relation(latest_rev, rev, tRelationFindRepForPrimary, NULLTAG, &Primary_relation) != ITK_ok)
												PrintErrorStack();
											if (GRM_save_relation(Primary_relation) != ITK_ok)
												PrintErrorStack();

											if (AOM_load(Primary_relation))
												;
											printf("\nInside Create relation by ROHIT after SAVE\n");
											fflush(stdout);
											if (AOM_refresh(Primary_relation, 0) != ITK_ok)
												PrintErrorStack();

											// if(AOM_save_without_extensions(rev))PrintErrorStack();
											// if(AOM_refresh(rev,0))PrintErrorStack();
											printf("\nAfter REFRESH ROHIT\n");
											fflush(stdout);
											//}
										}
									}
								}
							}
						}
					}
				}

				// Rohit End

				/****************************************ROHIT Stamping ERC Review on BVR Starts*********************************/

				printf("\nRohit's Code Started to stamp ERC Review on BVR when performing REVISE action\n");
				fflush(stdout);

				tag_t CntrlOBJ_reviseBVR = NULLTAG;
				tag_t *CntrlObject_reviseBVR = NULLTAG;
				tag_t *bvrs;
				tag_t bvr_tag = NULLTAG;
				tag_t status_reviewBVR = NULLTAG;

				char *qry_cntrl_reviseBVR[1] = {"SYSCD"};
				char **qry_values_reviseBVR = (char **)MEM_alloc(10 * sizeof(char *));
				qry_values_reviseBVR[0] = "Revise_BVR_Stamping_ControlObj";

				int entries_reviseBVR = 1;
				int found_reviseBVR = 0;
				int bvr_count = 0;

				if (QRY_find2("Control Objects...", &CntrlOBJ_reviseBVR))
					;
				printf("\n\nStamping Review status on BVR while revising Query Found\n\n");
				fflush(stdout);

				if (QRY_execute(CntrlOBJ_reviseBVR, entries_reviseBVR, qry_cntrl_reviseBVR, qry_values_reviseBVR, &found_reviseBVR, &CntrlObject_reviseBVR))
					;
				printf("\n\nStamping Review status on BVR while revising control object count is :%d\n", found_reviseBVR);
				fflush(stdout);
				if (found_reviseBVR > 0)
				{

					char *reviseBVR_item_id = NULL;
					char *reviseBVR_itemrevid = NULL;
					char *BVR_Rlstatus = NULL;

					if (AOM_ask_value_string(new_rev[0], "item_id", &reviseBVR_item_id))
						;
					if (AOM_ask_value_string(new_rev[0], "item_revision_id", &reviseBVR_itemrevid))
						;
					printf("\nRevise revision on whose BVR we are going to stamp ERC Review is [%s] and [%s]\n", reviseBVR_item_id, reviseBVR_itemrevid);
					fflush(stdout);

					if (ITEM_rev_list_bom_view_revs(new_rev[0], &bvr_count, &bvrs))
						;
					if (bvr_count > 0)
					{
						printf("\nTag of BVR found\n");
						fflush(stdout);

						bvr_tag = bvrs[0];

						if (AOM_UIF_ask_value(bvr_tag, "release_status_list", &BVR_Rlstatus))
							;
						if (tc_strlen(BVR_Rlstatus) == 0)
						{
							if (AOM_lock(bvr_tag))
								;

							logical retain_released_date = TRUE;

							printf("\n BEFORE stamping Review status on BVR\n");
							fflush(stdout);
							if (RELSTAT_create_release_status("T5_LcsReview", &status_reviewBVR))
								;
							if (RELSTAT_add_release_status(status_reviewBVR, 1, &bvr_tag, retain_released_date))
								;
							printf("\n After stamping Review status on BVR\n");
							fflush(stdout);

							if (AOM_save_without_extensions(bvr_tag))
								;
							printf("\n Print for testing AOM_SAVE for 14.3\n");
							fflush(stdout);
							if (AOM_unlock(bvr_tag))
								;
						}
					}

					printf("\nRohit's Code Ended to stamp ERC Review on BVR when performing REVISE action\n");
					fflush(stdout);
				}

				/****************************************ROHIT Stamping ERC Review on BVR Ends*********************************/

				/****************************************Rohit Validation starts for JT/PDF carryover attribute*********************************/

				// source_rev - tag of the revision on which user is performing REVISE action
				// new_rev - tag of the new revision after performing REVISE action

				/****************************************Rohit Validation ENDS for JT/PDF carryover attribute*********************************/

				// shrivardhan start

				// tag_t	source_rev				 =va_arg (args, tag_t);
				// char*	rev_id					 = va_arg(args, char*);
				// tag_t*	new_rev					 = va_arg(args, tag_t*);
				// tag_t	item_rev_master_form	 = va_arg(args, tag_t);

				char *newDesRevID = NULL;
				char *newDesRevSeq = NULL;
				tag_t tRelPrtToSor = NULLTAG;
				int sorCnt = 0;
				tag_t *tSorRev = NULLTAG;
				int z = 0;
				tag_t tRelfound = NULLTAG;
				tag_t tSor = NULLTAG;
				tag_t newRevTag = NULLTAG;

				if (new_rev)
				{
					newRevTag = new_rev[0];

					printf("\nDELETE RELATION ------>In for SOR relation break with design Revision\n");
					fflush(stdout);
					TC_write_syslog("\nDELETE RELATION ------>In for SOR relation break with design Revision");
					fflush(stdout);

					if (AOM_ask_value_string(newRevTag, "item_id", &newDesRevID))
						;
					if (AOM_ask_value_string(newRevTag, "item_revision_id", &newDesRevSeq))
						;

					printf("\nDELETE RELATION ------>New Design Revision Found [%s] [%s]\n", newDesRevID, newDesRevSeq);
					fflush(stdout);
					TC_write_syslog("\nDELETE RELATION ------>New Design Revision Found [%s] [%s]", newDesRevID, newDesRevSeq);
					fflush(stdout);

					if (GRM_find_relation_type("T5_PartSorRel", &tRelPrtToSor))
						;
					if (GRM_list_secondary_objects_only(newRevTag, tRelPrtToSor, &sorCnt, &tSorRev))
						;

					printf("\nDELETE RELATION ------>SOR Count is [%d]\n", sorCnt);
					fflush(stdout);
					TC_write_syslog("\nDELETE RELATION ------>SOR Count is [%d]\n", sorCnt);
					fflush(stdout);

					if (sorCnt > 0)
					{
						for (z = 0; z < sorCnt; z++)
						{
							tSor = tSorRev[z];

							printf("\nDELETE RELATION ------>tRelationExist DELETING SOR RELATION WITH NEW REVISION \n");
							fflush(stdout);
							TC_write_syslog("\nDELETE RELATION ------>tRelationExist DELETING SOR RELATION WITH NEW REVISION \n");
							fflush(stdout);

							if (GRM_find_relation(newRevTag, tSor, tRelPrtToSor, &tRelfound))
								;

							if (tRelfound != NULLTAG)
							{
								if (GRM_delete_relation(tRelfound))
									;

								printf("\nDELETE RELATION ------>RELATION IS DELTETED \n");
								fflush(stdout);
								TC_write_syslog("\nDELETE RELATION ------>RELATION IS DELTETED\n");
								fflush(stdout);
							}
							else
							{
								printf("\nDELETE RELATION ------>RELATION NOT FOUND \n");
								fflush(stdout);
								TC_write_syslog("\nDELETE RELATION ------>RELATION NOT FOUNDD\n");
								fflush(stdout);
							}
						}
					}
					else
					{
						printf("\nDELETE RELATION ------>COUNT IS : [%d]\n", sorCnt);
						fflush(stdout);
						TC_write_syslog("\nDELETE RELATION ------>COUNT IS : [%d] \n", sorCnt);
						fflush(stdout);
					}
				}
				else
				{
					printf("\nDELETE RELATION ------>NEW REVISION NOT FOUND\n", sorCnt);
					fflush(stdout);
					TC_write_syslog("\nDELETE RELATION ------>NEW REVISION NOT FOUND \n", sorCnt);
					fflush(stdout);
				}

				// Shrivardhan END

				// Adi add 4D Doc rel status END HERE 2021
			}
		} // ERC USer End AmolPLJ

		//////

		printf("\nRohit's Code started to carry forward JT/PDF relation while performing REVISE action\n");
		fflush(stdout);
		char *jtpdf_item_id = NULL;
		char *jtpdf_item_id1 = NULL;
		char *jtpdf_item_id2 = NULL;
		char *jtpdf_itemrevid1 = NULL;
		char *jtpdf_itemrevid = NULL;
		char *jtpdf_itemrevid2 = NULL;
		int jtpdf_revid = 0;
		int jtpdf_revid1 = 0;
		int jtpdf_revid2 = 0;
		// char  pjobject_type1[WSO_name_size_c+1] ;
		// char  pjobject_type2[WSO_name_size_c+1] ;
		char *pjobject_type1 = NULL;
		char *pjobject_type2 = NULL;
		char *tok_JTPDF_REV = NULL;
		char *tok_JTPDF_Seq = NULL;

		tag_t tRelationRenPDF = NULLTAG;
		tag_t tRelationRenJT = NULLTAG;
		tag_t *pdf_gobjects = NULLTAG;
		tag_t *jt_gobjects = NULLTAG;
		tag_t pdfrelation = NULLTAG;
		tag_t jtrelation = NULLTAG;
		tag_t Primarypdf_relation = NULLTAG;
		tag_t Primaryjt_relation = NULLTAG;
		tag_t newRevTagJT_PDF = NULLTAG;
		tag_t relation_pdfjt = NULLTAG;

		int pdf_count = 0;
		int jt_count = 0;
		int pdf = 0;
		int jt = 0;
		int pdfi = 0;
		int jti = 0;

		char *qry_repforcntrl_jtpdf[1] = {"SYSCD"};

		char **qry_valuesrepfor_jtpdf = (char **)MEM_alloc(10 * sizeof(char *));

		qry_valuesrepfor_jtpdf[0] = "JT_PDF_ControlObj";
		tag_t repfor_CntrlOBJ_jtpdf = NULLTAG;
		int repfor_entries_jtpdf = 1;
		int repfor_found_jtpdf = 0;
		tag_t *CntrlObject_repfor_jtpdf = NULLTAG;

		if (QRY_find2("Control Objects...", &repfor_CntrlOBJ_jtpdf))
			;
		printf("\n\nFastCVBUCntrlObj Query Found\n\n");
		fflush(stdout);

		if (QRY_execute(repfor_CntrlOBJ_jtpdf, repfor_entries_jtpdf, qry_repforcntrl_jtpdf, qry_valuesrepfor_jtpdf, &repfor_found_jtpdf, &CntrlObject_repfor_jtpdf))
			;
		printf("\n\n  Caryy Forward For JT/PDF SYSCD :%d\n", repfor_found_jtpdf);
		fflush(stdout);
		if (repfor_found_jtpdf > 0)
		{
			// if(AOM_ask_value_int(source_rev,"sequence_id",&jtpdf_revid));
			if (AOM_ask_value_string(source_rev, "item_id", &jtpdf_item_id))
				;
			if (AOM_ask_value_string(source_rev, "item_revision_id", &jtpdf_itemrevid))
				;
			printf("\nItem ID of source rev : [%s] and [%s]", jtpdf_item_id, jtpdf_itemrevid);

			// if(AOM_ask_value_int(new_rev,"sequence_id",&jtpdf_revid1));
			if (AOM_ask_value_string(new_rev[0], "item_id", &jtpdf_item_id1))
				;
			if (AOM_ask_value_string(new_rev[0], "item_revision_id", &jtpdf_itemrevid1))
				;
			// if(AOM_ask_value_int(revi,"item_id",&jtpdf_item_id2));
			// if(AOM_ask_value_int(revi,"sequence_id",&jtpdf_revid2));
			// if(AOM_ask_value_int(revi,"item_revision_id",&jtpdf_itemrevid2));
			printf("\nItem ID of newly created rev : [%s] and [%s]", jtpdf_item_id1, jtpdf_itemrevid1);
			// printf("Item ID of newly created rev1 : [%s][%d] and [%s]",jtpdf_item_id2,jtpdf_revid2,jtpdf_itemrevid2);
			tok_JTPDF_REV=tc_strtok(jtpdf_itemrevid1,";");
			tok_JTPDF_Seq=tc_strtok(NULL,";");
			printf("\n value of tok_JTPDF_REV is : [%s] and tok_JTPDF_Seq [%s]", tok_JTPDF_REV, tok_JTPDF_Seq);
			// if(AOM_ask_value_string(source_rev,"sequence_id",&jtpdf_revid)); //Add revision char*

			// if (jtpdf_revid == 1) //Add revision char*
			if (tc_strcmp(tok_JTPDF_Seq, "1") ==0)
			{
				// printf("\nItem ID and its revision ID for JT/PDF relation is [%s][%s]",jtpdf_item_id,jtpdf_revid); fflush(stdout);

				newRevTagJT_PDF = new_rev[0];

				if (GRM_find_relation_type("IMAN_Rendering", &tRelationRenPDF))
					; // To get datasets attached in rendering relation
				if (tRelationRenPDF != NULLTAG)
				{
					// if(GRM_list_primary_objects_only(source_rev,tRelationRenPDF,&pdf_count,&pdf_gobjects))PrintErrorStack();
					if (GRM_list_secondary_objects_only(source_rev, tRelationRenPDF, &pdf_count, &pdf_gobjects))
						;
					if (pdf_count > 0)
					{
						for (pdf = 0; pdf < pdf_count; pdf++)
						{
							pdfrelation = pdf_gobjects[pdf];

							if (WSOM_ask_object_type2(pdfrelation, &pjobject_type1))
								;
							printf("\nType of dataset is [%s] of total : [%d]\n", pjobject_type1, pdf_count);
							fflush(stdout);

							if ((strcmp(pjobject_type1, "PDF") == 0) || (strcmp(pjobject_type1, "DirectModel") == 0))
							// if (strcmp(pjobject_type1,"DirectModel")==0)
							// if (strcmp(pjobject_type1,"PDF")==0)
							{
								printf("\ndataset type is JT or RENDERING relation\n");
								fflush(stdout);
								if (AOM_refresh(newRevTagJT_PDF, 1))
									;

								// if(GRM_find_relation(newRevTagJT_PDF,))
								// if(GRM_find_relation == NULLTAG) //Rohit
								if (GRM_find_relation(newRevTagJT_PDF, pdfrelation, tRelationRenPDF, &relation_pdfjt))
									;
								if (relation_pdfjt == NULLTAG)
								{
									// if(AOM_refresh(pdfrelation,1));
									// if(GRM_create_relation(pdfrelation,newRevTagJT_PDF,tRelationRenPDF,NULLTAG,&Primarypdf_relation));
									if (GRM_create_relation(newRevTagJT_PDF, pdfrelation, tRelationRenPDF, NULLTAG, &Primarypdf_relation))
										; // Working API
									if (Primarypdf_relation != NULLTAG)
									{
										printf("\nFor saving rendering relation\n");
										fflush(stdout);
										if (GRM_save_relation(Primarypdf_relation) != ITK_ok)
											PrintErrorStack();
										if (AOM_load(Primarypdf_relation))
											;
										if (AOM_refresh(Primarypdf_relation, 0))
											;
									}

									if (AOM_refresh(newRevTagJT_PDF, 0))
										;
									printf("\nAfter creating relation of PDF\n");
									fflush(stdout);
								}
								else
								{
									printf("\nRelation is already available\n");
									fflush(stdout);
								}
							}
							// MEM_free (Primarypdf_relation);
							// MEM_free (newRevTagJT_PDF);
						}
					}
				}

				// if(GRM_find_relation_type("IMAN_reference",&tRelationRenJT)); //To get datasets attached in references relation
				// if (tRelationRenJT!=NULLTAG)
				//{
				//	//if(GRM_list_primary_objects_only(source_rev,tRelationRenJT,&jt_count,&jt_gobjects))PrintErrorStack();
				//	if(GRM_list_secondary_objects_only(source_rev,tRelationRenJT,&jt_count,&jt_gobjects));
				//	if(jt_count > 0)
				//	{
				//		for(jt = 0 ; jt <= jt_count ; jt++)
				//		{
				//			jtrelation=jt_gobjects[jt];
				//
				//			if(WSOM_ask_object_type(jtrelation,pjobject_type2));
				//
				//			if ((strcmp(pjobject_type2,"PDF")==0) || (strcmp(pjobject_type2,"DirectModel")==0))
				//			{
				//				printf("\ndataset type is PDF/JT for REFERENCES relation\n");fflush(stdout);
				//				if(AOM_refresh(newRevTagJT_PDF,1));
				//				if(GRM_create_relation(newRevTagJT_PDF,jtrelation,tRelationRenJT,NULLTAG,&Primaryjt_relation));
				//				if(Primaryjt_relation != NULLTAG)
				//				{
				//					if(GRM_save_relation(Primaryjt_relation))PrintErrorStack();
				//					if(AOM_load(Primaryjt_relation));
				//					if(AOM_refresh(Primaryjt_relation,0));
				//
				//				}
				//				if(AOM_refresh(newRevTagJT_PDF,0));
				//				printf("\nAfter creating relation of JT\n");fflush(stdout);
				//			}
				//		}
				//
				//	}
				// }
			}
			else
			{
				printf("\nRevision Sequence is not 1 . Hence no need to carry forward\n");
				fflush(stdout);
			}
		}
	}

	// revlength = strlen(Desc_seq);
	// printf("\n revlength  = [%d]\n", revlength);fflush(stdout);

	//	ReplacedRevision = (char *)MEM_alloc (2 * sizeof(char));
	//	strcpy(ReplacedRevision,Desc_obj);
	/*
		printf("\n Desc_obj  = [%s]\n", Desc_obj);fflush(stdout);

		printf("\nUpdating start1\n");fflush(stdout);
		printf("\nUpdating start1 Z\n");fflush(stdout);
		if(AOM_lock(rev));
		if( AOM_set_value_string(rev,"item_revision_id",Desc_obj2))PrintErrorStack();
		if(AOM_save_without_extensions(rev))PrintErrorStack();
		if(AOM_unlock(rev))PrintErrorStack();
		printf("\nUpdating end1\n");fflush(stdout);



		//POM_refresh_instances_any_class(1, &instance, POM_no_lock);

		ERROR_CALL(AOM_lock(rev));
	*/
	// ITK_set_bypass
	//  bypass = ITK_ask_cli_argument( CLI_OPTION_BYPASS ) != NULL;
	/* if ( bypass )
	{
		ITK ( ITK_set_bypass ( bypass ) );
		ITK ( POM_set_env_info ( POM_bypass_access_check, bypass, 0, 0.0, NULLTAG, "" ) );
	}*/
	// ERROR_CALL (RELSTAT_create_release_status("ERC Review",&status_rel));

	/*
		if (strcmp(type_name,"Design Revision") == 0)
		{
			CALLAPI(POM_class_of_instance(rev,&class_id));
			CALLAPI(POM_name_of_class(class_id,&class_name));
			printf("\n class_name is :%s\n",class_name);fflush(stdout);

			CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

			CALLAPI(POM_unload_instances (1,&rev));
			CALLAPI(POM_load_instances(1,&rev,class_id,1));
			CALLAPI(POM_is_loaded(rev,&log1));
			if(log1 == 1)
			{
				 printf(" Load Success\n " );
			}
			else
			printf("Load Failure\n"  );

			CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
			printf("\n n_values is :%d\n",n_values);fflush(stdout);
			if(n_values>0)
			{
				CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

				for (cunt1 =  0; cunt1 <n_values; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
					printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_save_instances(1,&rev,1));

					CALLAPI(POM_refresh_instances(1,&rev,class_id,2));

					CALLAPI(AOM_lock(rev));

					CALLAPI(AOM_save_without_extensions(rev));
					CALLAPI(AOM_refresh(rev,1));

				}

				 CALLAPI(AOM_unlock(rev));
			}

			ERROR_CALL (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
			ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));
			//ERROR_CALL(ITK_set_bypass(TRUE));

			ERROR_CALL(AOM_refresh(rev,1));
			ERROR_CALL(AOM_save_without_extensions(rev));

			ERROR_CALL(AOM_unlock(rev));
		}

		*/

	//	ERROR_CALL (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
	//	ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));
	//	//ERROR_CALL(ITK_set_bypass(TRUE));
	//
	//	ERROR_CALL(AOM_refresh(rev,1));
	//	ERROR_CALL(AOM_save_without_extensions(rev));
	//
	//    ERROR_CALL(AOM_unlock(rev));
	printf("\n After ERC Review.... \n");
	fflush(stdout);

	return ITK_ok;
}

// TMCAE ITEM
extern DLLAPI int Revise_Post_Action_TMCAE(METHOD_message_t *m, va_list args)
{
	char *ReleaseStatus = NULL;
	char *type_name = NULL;
	// char   type_name[TCTYPE_name_size_c+1];
	tag_t source_rev_Type_Tag = NULLTAG;
	tag_t *status_list = NULLTAG;
	int ifail = 0;
	int ii = 0;
	char *text = NULL;
	int status_count = 0;
	char *Item_string = NULL;
	logical retain = 0;
	int status;
	int Desc_seq = 0;
	int Desc_seq9 = 0;
	int Desc_seq1 = 0;
	int Desc_seq2 = 0;
	char *Desc_obj = NULL;
	char *Desc_obj9 = NULL;
	char *Desc_obj2 = NULL;
	// char			*Desc_seq3	= NULL;
	char Desc_seq3[10];
	tag_t objTypeTag = NULLTAG;
	tag_t status_rel = NULLTAG;
	tag_t rev = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t master = NULLTAG;
	logical bypass = FALSE;
	tag_t source_rev = va_arg(args, tag_t);
	char *rev_id = va_arg(args, char *);
	tag_t *new_rev = va_arg(args, tag_t *);
	tag_t item_rev_master_form = va_arg(args, tag_t);
	char *ReplacedRevision = NULL;
	char *ObjectClassType = NULL;
	char *ObjectName = NULL;
	tag_t dataset = NULLTAG;
	tag_t *attachments = NULLTAG;
	int revlength = 0;
	tag_t *revisions;
	int revision_count = 0;
	tag_t attr_id;
	tag_t form_attr_id;
	tag_t relation_type = NULLTAG;
	char relation_name[TCTYPE_name_size_c + 1];

	// Added by Ayush
	tag_t *old_bvr_list = NULL;			// Ayush
	int bvr_count = 0;					// Ayush
	tag_t new_bvr = NULLTAG;			// Ayush
											
	int viewcount = 0;					// Ayush
	tag_t *bvr_tag =NULL;				// Ayush
	char *bvr_ObjectName	= NULL;		// Ayush
	char *bvritemid	= NULL;				// Ayush
	char *bvrrev	= NULL;				// Ayush


	const char *reason = NULL;
	const char *change_id = NULL;
	const char *dir_name = NULL;
	const char *reason1 = NULL;
	const char *change_id1 = NULL;
	const char *dir_name1 = NULL;
	char *revi = NULL;
	char *oojname = NULL;
	char *oojname_bvr = NULL;
	char revi1[20];
	int cnt = 0;
	int i = 0;
	logical checkout = 0;

	oojname_bvr = (char *)MEM_alloc(50);

	/******Deepti Start Variable initialisation***********/
	int st_relList_count = 0;
	int Rel_cnt = 0;
	tag_t *relstatus_list = NULLTAG;
	char *WSO_Name_RelVal = NULL;
	tag_t tReleaseStatusList = NULLTAG;
	int n_values = 0;
	int cunt1 = 0;
	tag_t *attr_tags = NULLTAG;
	logical *is_it_null = NULL;
	logical *is_it_empty = NULL;
	tag_t class_id = NULLTAG;
	char *class_name = NULL;
	logical log1;

	printf("\n Inside Revise_Post_Action_TMCAE Function.... \n");
	fflush(stdout);

	if (TCTYPE_ask_object_type(source_rev, &objTypeTag) != ITK_ok)
		;
	if (TCTYPE_ask_name2(objTypeTag, &type_name) != ITK_ok)
		;
	if (ITEM_ask_item_of_rev(source_rev, &master))
		;
	if (ITEM_ask_latest_rev(master, &rev))
		;

	if (ITEM_list_all_revs(master, &revision_count, &revisions))
		;
	// MEM_free (revisions);
	printf("\nNumber of revision : %d\n", revision_count);
	fflush(stdout);
	if (WSOM_ask_release_status_list(revisions[revision_count - 2], &status_count, &status_list) != ITK_ok)
		PrintErrorStack();
	printf("\n number of statuses: %d \n", status_count);
	fflush(stdout);
	for (ii = 0; ii < status_count; ii++)
	{
		AOM_ask_name(status_list[ii], &ReleaseStatus);
		printf("\t ReleaseStatus: %s\n", ReleaseStatus);
		fflush(stdout);
	}

	if (AOM_ask_value_string(revisions[revision_count - 2], "item_revision_id", &Desc_obj2) != ITK_ok)
		PrintErrorStack();
	printf("\n Desc_obj2  = [%s]\n", Desc_obj2);
	fflush(stdout);

	if (AOM_ask_value_int(revisions[revision_count - 2], "sequence_id", &Desc_seq2) != ITK_ok)
		PrintErrorStack();
	printf("\n Desc_seq2  = [%d]\n", Desc_seq2);
	fflush(stdout);

	if ((strcmp(ReleaseStatus, "ERC Review") == 0) || (strcmp(ReleaseStatus, "T5_LcsReview") == 0))
	{

		if (AOM_ask_value_string(source_rev, "item_revision_id", &Desc_obj) != ITK_ok)
			PrintErrorStack();
		printf("\n type_name  = [%s]\n", type_name);
		fflush(stdout);
		printf("\n revision  = [%s]\n", Desc_obj);
		fflush(stdout);

		if (AOM_ask_value_int(rev, "sequence_id", &Desc_seq) != ITK_ok)
			PrintErrorStack();
		printf("\n sequence  = [%d]\n", Desc_seq);
		fflush(stdout);

		Desc_seq1 = Desc_seq2 + 1;
		printf("\n sequence1  = [%d]\n", Desc_seq1);
		fflush(stdout);
		if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
			PrintErrorStack();
		printf("\nValue of Desc_obj : %s\n", Desc_obj2);
		fflush(stdout);
		revi = strtok(Desc_obj2, ";");
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);
		strcat(revi, ";");
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		sprintf(revi1, "%d", Desc_seq1);
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		strcat(revi, revi1);
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		if (POM_set_attr_string(1, &rev, attr_id, revi) != ITK_ok)
			PrintErrorStack();

		printf("\n sequence1 before the set  = [%d]\n", Desc_seq1);
		fflush(stdout);

		printf("\nUpdating start2\n");
		fflush(stdout);
		if (AOM_lock(rev))
			;

		if (AOM_save_without_extensions(rev) != ITK_ok)
			PrintErrorStack();
		if (AOM_unlock(rev) != ITK_ok)
			PrintErrorStack();
		printf("\nUpdating end2\n");
		fflush(stdout);

		if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)
			PrintErrorStack();
		printf("\n Attached Datasets2: %d\n", cnt);
		fflush(stdout);
		if (RES_checkout2(rev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE) != ITK_ok)
			PrintErrorStack();

		for (i = 0; i < cnt; i++)
		{
			dataset = attachments[i];

			if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
				PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
			fflush(stdout);

			if (strcmp(ObjectClassType, "T5_TMCAEModelRevisionMaster") == 0)
			{
				if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
					PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n", ObjectName);
				fflush(stdout);
				oojname = strtok(ObjectName, "/");
				strcat(oojname, "/");
				strcat(oojname, revi);
				printf("\n\n Name of Revision Master:%s\n", oojname);
				fflush(stdout);

				if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
					PrintErrorStack();

				if (AOM_lock(dataset))
					;
				if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
					PrintErrorStack();
				if (AOM_save_without_extensions(dataset) != ITK_ok)
					PrintErrorStack();
				if (AOM_unlock(dataset) != ITK_ok)
					PrintErrorStack();
			}
			if (strcmp(ObjectClassType, "T5_TMCAEModelRevision") != 0)
			{
				if (strcmp(ObjectClassType, "T5_TMCAEModelRevisionMaster") != 0)
				{
					printf("\n\n Dataset ObjectClassType1 :%s\n", ObjectClassType);
					fflush(stdout);
					if (RES_is_checked_out(dataset, &checkout) != ITK_ok)
						PrintErrorStack();
					printf("\nValue of checkout : %d\n", checkout);
					fflush(stdout);

					if (checkout == 0)
					{
						tag_t *relation_list = NULLTAG;
						int relcount = 0;
						tag_t relation_type1 = NULLTAG;
						if (GRM_find_relation_type("IMAN_reference", &relation_type1) != ITK_ok)
							PrintErrorStack();
						if (GRM_list_relations(rev, dataset, relation_type1, NULLTAG, &relcount, &relation_list) != ITK_ok)
							PrintErrorStack();
						printf("\nIMAN_references count : %d", relcount);
						printf("\n\n going to checkout :%s\n", ObjectClassType);
						fflush(stdout);
						printf("\n Commented checkout of dataset by ");
						fflush(stdout);
						if (relcount > 0)
						{
							if (RES_checkout2(dataset, reason1, change_id1, dir_name1, RES_EXCLUSIVE_RESERVE) != ITK_ok)
								PrintErrorStack();
							printf("\n %d DataSet Checked Out \n", dataset);
						}
						else
						{
							printf("\nSkipping IMAN_reference relation checkout");
						}
					}
				}
			}
		}
	}

	// For Revising Part
	if ((strcmp(ReleaseStatus, "ERC Released") == 0) || (strcmp(ReleaseStatus, "T5_LcsErcRlzd") == 0))
	{
		if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)
			PrintErrorStack();
		printf("\n Attached Datasets2: %d\n", cnt);
		fflush(stdout);
		for (i = 0; i < cnt; i++)
		{
			dataset = attachments[i];

			if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
				PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
			fflush(stdout);

			if (strcmp(ObjectClassType, "T5_TMCAEModelRevisionMaster") == 0)
			{
				if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
					PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n", ObjectName);
				fflush(stdout);
				oojname = strtok(ObjectName, "/");
				strcat(oojname, "/");
				printf("\n\n Name of Revision Master:%s\n", oojname);
				fflush(stdout);
				break;
			}
		}

		revi = strtok(Desc_obj2, ";");
		printf("\nValue of revi in revision : %s\n", revi);
		fflush(stdout);
		if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
			PrintErrorStack();
		if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
			PrintErrorStack();

		if (AOM_lock(rev)) PrintErrorStack();
		if (true)
		{
			if (strcmp(revi, "NR") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "A;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "A;1");

				if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
				PrintErrorStack();

				printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count);fflush(stdout);

				if (bvr_count >0)
				{
					//oojname_bvr = (char **)MEM_alloc(5 * sizeof(char *));

					if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
					printf("\nERC-UA1.89--Value of revi in BVR revision for NR_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
					bvritemid=strtok(bvr_ObjectName,"/");
					bvrrev=strtok(NULL,"-");
					printf("\nERC-UA1.89--Value of revi in BVR revision for NR rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					if (strcmp(bvrrev,"A;1")==0)
					{
						printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					}
					else{
						strcpy(oojname_bvr, bvritemid);
						strcat(oojname_bvr, "/A;1");
						strcat(oojname_bvr,"-View");
						printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_bvr);fflush(stdout);
						if(AOM_lock(bvr_tag[0]));
						if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
						if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
						if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();
					}
				}

			}
			if (strcmp(revi, "A") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "B;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "B;1");
				
				if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
				PrintErrorStack();

				printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count);fflush(stdout);

				if (bvr_count >0)
				{

					if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
					printf("\nERC-UA1.89--Value of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
					bvritemid=strtok(bvr_ObjectName,"/");
					bvrrev=strtok(NULL,"-");
					printf("\nERC-UA1.89--Value of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					if (strcmp(bvrrev,"A;1")==0)
					{
						printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision A: %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					}
					else{
						strcpy(oojname_bvr, bvritemid);
						strcat(oojname_bvr, "/B;1");
						strcat(oojname_bvr,"-View");
						printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_bvr);fflush(stdout);
						if(AOM_lock(bvr_tag[0]));
						if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
						if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
						if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();
					}
				}
			}
			if (strcmp(revi, "B") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "C;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "C;1");
				
				if (ITEM_rev_list_bom_view_revs(rev,&bvr_count, &bvr_tag) != ITK_ok)
				PrintErrorStack();

				printf("\nERC-UA1.89--Value of BVR revi in---bvr_count is = : %d\n",bvr_count);fflush(stdout);

				if (bvr_count >0)
				{

					if (AOM_ask_value_string(bvr_tag[0],"object_name",&bvr_ObjectName)!=ITK_ok)   PrintErrorStack();
					printf("\nERC-UA1.89--Value of revi in BVR revision for A_1 rev : %s\n",bvr_ObjectName);fflush(stdout);
					bvritemid=strtok(bvr_ObjectName,"/");
					bvrrev=strtok(NULL,"-");
					printf("\nERC-UA1.89--Value of revi in BVR revision for A rev : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					if (strcmp(bvrrev,"B;1")==0)
					{
						printf("\nERC-UA1.89-- alredy bvr is present Value of revi in revision : %s :%s\n",bvritemid,bvrrev);fflush(stdout);
					}
					else{
						strcpy(oojname_bvr, bvritemid);
						strcat(oojname_bvr, "/C;1");
						strcat(oojname_bvr,"-View");
						printf("\nERC-UA1.89-- else alredy bvr is present Value of revi in revision : %s :%s :%s\n",bvritemid,bvrrev,oojname_bvr);fflush(stdout);
						if(AOM_lock(bvr_tag[0]));
						if(POM_set_attr_string(1, &bvr_tag[0], form_attr_id,oojname_bvr)!=ITK_ok)  PrintErrorStack();
						if(AOM_save_without_extensions(bvr_tag[0])!=ITK_ok)PrintErrorStack();
						if(AOM_unlock(bvr_tag[0])!=ITK_ok)PrintErrorStack();
					}
				}
			}
			if (strcmp(revi, "C") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "D;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "D;1");
			}
			if (strcmp(revi, "D") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "E;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "E;1");
			}
			if (strcmp(revi, "E") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "F;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "F;1");
			}
			if (strcmp(revi, "F") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "G;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "G;1");
			}
			if (strcmp(revi, "G") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "H;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "H;1");
			}
			if (strcmp(revi, "H") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "I;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "I;1");
			}
			if (strcmp(revi, "I") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "J;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "J;1");
			}
			if (strcmp(revi, "J") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "K;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "K;1");
			}
			if (strcmp(revi, "K") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "L;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "L;1");
			}
			if (strcmp(revi, "L") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "M;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "M;1");
			}
			if (strcmp(revi, "M") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "N;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "N;1");
			}
			if (strcmp(revi, "N") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "O;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "O;1");
			}
			if (strcmp(revi, "O") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "P;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "P;1");
			}
			if (strcmp(revi, "P") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "Q;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "Q;1");
			}
			if (strcmp(revi, "Q") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "R;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "R;1");
			}
			if (strcmp(revi, "R") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "S;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "S;1");
			}
			if (strcmp(revi, "S") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "T;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "T;1");
			}
			if (strcmp(revi, "T") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "U;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "U;1");
			}
			if (strcmp(revi, "U") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "V;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "V;1");
			}
			if (strcmp(revi, "V") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "W;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "W;1");
			}
			if (strcmp(revi, "W") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "X;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "X;1");
			}
			if (strcmp(revi, "X") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "Y;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "Y;1");
			}
			if (strcmp(revi, "Y") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "Z;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "Z;1");
			}
			if (strcmp(revi, "Z") == 0)
			{
				if (POM_set_attr_string(1, &rev, attr_id, "AA;1") != ITK_ok)
					PrintErrorStack();
				strcat(oojname, "AA;1");
			}
			if (AOM_lock(dataset))
				;
			if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
				PrintErrorStack();
			if (AOM_save_without_extensions(dataset) != ITK_ok)
				PrintErrorStack();
			if (AOM_unlock(dataset) != ITK_ok)
				PrintErrorStack();
		}
		if (AOM_save_without_extensions(rev) != ITK_ok)
			PrintErrorStack();
		if (AOM_unlock(rev) != ITK_ok)
			PrintErrorStack();

		t5removeAllReleaseStatus(rev);
		ITKCALL(RELSTAT_create_release_status("T5_LcsReview", &status_rel));
		ITKCALL(RELSTAT_add_release_status(status_rel, 1, &rev, retain));
		ITKCALL(AOM_refresh(rev, 1));
		ITKCALL(AOM_save_without_extensions(rev));
		ITKCALL(AOM_unlock(rev));

		
		if (AOM_lock(new_bvr) == ITK_ok)
		{
		    POM_set_attr_string(1, &new_bvr, form_attr_id, oojname); // same name logic
		    AOM_save_without_extensions(new_bvr);
		    AOM_unlock(new_bvr);
		}

	}
	printf("\n After ERC Review.... \n");
	fflush(stdout);
	return ITK_ok;
}
//
/************ Adi ********************/

extern DLLAPI int Revise_Post_Action_TMCAEAna(METHOD_message_t *m, va_list args)
{
	char *ReleaseStatus = NULL;
	char *type_name = NULL;
	// char   type_name[TCTYPE_name_size_c+1];
	tag_t source_rev_Type_Tag = NULLTAG;
	tag_t *status_list = NULLTAG;
	int ifail = 0;
	int ii = 0;
	char *text = NULL;
	int status_count = 0;
	char *Item_string = NULL;
	logical retain = 0;
	int status;
	int Desc_seq = 0;
	int Desc_seq9 = 0;
	int Desc_seq1 = 0;
	int Desc_seq2 = 0;
	char *Desc_obj = NULL;
	char *Desc_obj9 = NULL;
	char *Desc_obj2 = NULL;
	// char			*Desc_seq3	= NULL;
	char Desc_seq3[10];
	tag_t objTypeTag = NULLTAG;
	tag_t status_rel = NULLTAG;
	tag_t rev = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t master = NULLTAG;
	logical bypass = FALSE;
	tag_t source_rev = va_arg(args, tag_t);
	char *rev_id = va_arg(args, char *);
	tag_t *new_rev = va_arg(args, tag_t *);
	tag_t item_rev_master_form = va_arg(args, tag_t);
	char *ReplacedRevision = NULL;
	char *ObjectClassType = NULL;
	char *ObjectName = NULL;
	tag_t dataset = NULLTAG;
	tag_t *attachments = NULLTAG;
	int revlength = 0;
	tag_t *revisions;
	int revision_count = 0;
	tag_t attr_id;
	tag_t form_attr_id;
	tag_t relation_type = NULLTAG;
	char relation_name[TCTYPE_name_size_c + 1];

	const char *reason = NULL;
	const char *change_id = NULL;
	const char *dir_name = NULL;
	const char *reason1 = NULL;
	const char *change_id1 = NULL;
	const char *dir_name1 = NULL;
	char *revi = NULL;
	char *oojname = NULL;
	char revi1[20];
	int cnt = 0;
	int i = 0;
	logical checkout = 0;

	printf("\n Inside Revise_Post_Action_TMCAEAna Function.... \n");
	fflush(stdout);

	if (TCTYPE_ask_object_type(source_rev, &objTypeTag) != ITK_ok)
		;
	if (TCTYPE_ask_name2(objTypeTag, &type_name) != ITK_ok)
		;
	if (ITEM_ask_item_of_rev(source_rev, &master))
		;
	if (ITEM_ask_latest_rev(master, &rev))
		;

	if (ITEM_list_all_revs(master, &revision_count, &revisions))
		;
	// MEM_free (revisions);
	printf("\nNumber of revision : %d\n", revision_count);
	fflush(stdout);
	if (WSOM_ask_release_status_list(revisions[revision_count - 2], &status_count, &status_list) != ITK_ok)
		PrintErrorStack();
	printf("\n number of statuses: %d \n", status_count);
	fflush(stdout);
	for (ii = 0; ii < status_count; ii++)
	{
		AOM_ask_name(status_list[ii], &ReleaseStatus);
		printf("\t ReleaseStatus: %s\n", ReleaseStatus);
		fflush(stdout);
	}

	if (AOM_ask_value_string(revisions[revision_count - 2], "item_revision_id", &Desc_obj2) != ITK_ok)
		PrintErrorStack();
	printf("\n Desc_obj2  = [%s]\n", Desc_obj2);
	fflush(stdout);

	if (AOM_ask_value_int(revisions[revision_count - 2], "sequence_id", &Desc_seq2) != ITK_ok)
		PrintErrorStack();
	printf("\n Desc_seq2  = [%d]\n", Desc_seq2);
	fflush(stdout);

	if ((tc_strcmp(ReleaseStatus, "ERC Review") == 0) || (tc_strcmp(ReleaseStatus, "T5_LcsReview") == 0))
	{

		if (AOM_ask_value_string(source_rev, "item_revision_id", &Desc_obj) != ITK_ok)
			PrintErrorStack();
		printf("\n type_name  = [%s]\n", type_name);
		fflush(stdout);
		printf("\n revision  = [%s]\n", Desc_obj);
		fflush(stdout);

		if (AOM_ask_value_int(rev, "sequence_id", &Desc_seq) != ITK_ok)
			PrintErrorStack();
		printf("\n sequence  = [%d]\n", Desc_seq);
		fflush(stdout);

		Desc_seq1 = Desc_seq2 + 1;
		printf("\n sequence1  = [%d]\n", Desc_seq1);
		fflush(stdout);
		if (POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id) != ITK_ok)
			PrintErrorStack();
		printf("\nValue of Desc_obj : %s\n", Desc_obj2);
		fflush(stdout);
		revi = strtok(Desc_obj2, ";");
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);
		strcat(revi, ";");
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		sprintf(revi1, "%d", Desc_seq1);
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		strcat(revi, revi1);
		printf("\nValue of revi : %s\n", revi);
		fflush(stdout);

		if (POM_set_attr_string(1, &rev, attr_id, revi) != ITK_ok)
			PrintErrorStack();

		printf("\n sequence1 before the set  = [%d]\n", Desc_seq1);
		fflush(stdout);

		printf("\nUpdating start2\n");
		fflush(stdout);
		if (AOM_lock(rev))
			;

		if (AOM_save_without_extensions(rev) != ITK_ok)
			PrintErrorStack();
		if (AOM_unlock(rev) != ITK_ok)
			PrintErrorStack();
		printf("\nUpdating end2\n");
		fflush(stdout);

		if (GRM_list_secondary_objects_only(rev, relation_type, &cnt, &attachments) != ITK_ok)
			PrintErrorStack();
		printf("\n Attached Datasets2: %d\n", cnt);
		fflush(stdout);
		if (RES_checkout2(rev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE) != ITK_ok)
			PrintErrorStack();

		for (i = 0; i < cnt; i++)
		{
			dataset = attachments[i];

			if (AOM_ask_value_string(dataset, "object_type", &ObjectClassType) != ITK_ok)
				PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n", ObjectClassType);
			fflush(stdout);

			if (tc_strcmp(ObjectClassType, "T5_TMCAEAnalysisRevisionMaster") == 0)
			{
				if (AOM_ask_value_string(dataset, "object_name", &ObjectName) != ITK_ok)
					PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n", ObjectName);
				fflush(stdout);
				oojname = strtok(ObjectName, "/");
				strcat(oojname, "/");
				strcat(oojname, revi);
				printf("\n\n Name of Revision Master:%s\n", oojname);
				fflush(stdout);

				if (POM_attr_id_of_attr("object_name", "Form", &form_attr_id) != ITK_ok)
					PrintErrorStack();

				if (AOM_lock(dataset))
					;
				if (POM_set_attr_string(1, &dataset, form_attr_id, oojname) != ITK_ok)
					PrintErrorStack();
				if (AOM_save_without_extensions(dataset) != ITK_ok)
					PrintErrorStack();
				if (AOM_unlock(dataset) != ITK_ok)
					PrintErrorStack();
			}
			if (tc_strcmp(ObjectClassType, "T5_TMCAEAnalysisRevision") != 0)
			{
				if (tc_strcmp(ObjectClassType, "T5_TMCAEAnalysisRevisionMaster") != 0)
				{
					printf("\n\n Dataset ObjectClassType1 :%s\n", ObjectClassType);
					fflush(stdout);
					if (RES_is_checked_out(dataset, &checkout) != ITK_ok)
						PrintErrorStack();
					printf("\nValue of checkout : %d\n", checkout);
					fflush(stdout);

					if (checkout == 0)
					{
						tag_t *relation_list = NULLTAG;
						int relcount = 0;
						tag_t relation_type1 = NULLTAG;
						if (GRM_find_relation_type("IMAN_specification", &relation_type1) != ITK_ok)
							PrintErrorStack();
						if (GRM_list_relations(rev, dataset, relation_type1, NULLTAG, &relcount, &relation_list) != ITK_ok)
							PrintErrorStack();
						printf("\n IMAN_specification count : %d", relcount);
						printf("\n\n going to checkout :%s\n", ObjectClassType);
						fflush(stdout);
						printf("\n Commented checkout of dataset by ");
						fflush(stdout);
						if (relcount > 0)
						{
							if (RES_checkout2(dataset, reason1, change_id1, dir_name1, RES_EXCLUSIVE_RESERVE) != ITK_ok)
								PrintErrorStack();
							printf("\n %d DataSet Checked Out \n", dataset);
							t5removeAllReleaseStatus(rev);
							ITKCALL(RELSTAT_create_release_status("T5_LcsWorking", &status_rel));
							ITKCALL(RELSTAT_add_release_status(status_rel, 1, &rev, retain));
						}
						else
						{
							printf("\n  IMAN_specification relation checkout nothing available");
						}
					}
				}
			}
		}
	}

	return ITK_ok;
}
//


/************ Adi ********************/

extern int tm_CheckOutRevisepost_register_post_condition(int *decision, va_list args)
{
	METHOD_id_t method;
	METHOD_id_t methodNewPD;			 
	METHOD_id_t method_TMCAE;
	METHOD_id_t method_TMCAEAna; // Adi
	METHOD_id_t method_SpareKit; // Amol
	METHOD_id_t method_ColSchm;
	METHOD_id_t method_EE;
	METHOD_id_t method_MatEngg;
	METHOD_id_t method_StdWcq;
	METHOD_id_t method_VOD;

	int ifail = 0;
	*decision = ALL_CUSTOMIZATIONS;

	printf("\n Inside tm_CheckOutRevisepost_register_post_condition  \n");
	fflush(stdout);

	CALLAPI(METHOD_find_method("Design Revision", "ITEM_copy_rev", &method));
	if (method.id)
	{
		// CALLAPI(METHOD_call_post_action(method, (METHOD_function_t)Revise_properties_post,NULL));
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\nAfter Register Revisepost\n");
		printf("\n Registered as tm_CheckOutRevisepost_register_post_condition for Creation \n");
		fflush(stdout);
	}
	else
		printf("\n Method not found! \n");
	fflush(stdout);

	if (method.id)
	{
		printf("\n Registered as Pre-Action for Design Revision Checkout\n");
		fflush(stdout);
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t)Checkout_Pre_action, NULL));
	}
	else
	{
		printf("\nCheckout_Pre_action--Method not found! \n");
		fflush(stdout);
	}
    
	// PD	
	
	CALLAPI(METHOD_find_method("Design Revision", "ITEM_copy_rev", &methodNewPD));
	if (methodNewPD.id)
	{
		// CALLAPI(METHOD_call_post_action(method, (METHOD_function_t)Revise_properties_post,NULL));
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t)Revise_OperationFunForTechspec, NULL));
		TC_write_syslog("\n\nAfter Register Revisepost\n");
		printf("\n Registered as tm_CheckOutRevisepost_register_post_condition for Creation \n");
		fflush(stdout);
	}
	else
		printf("\n Method not found! \n");
	fflush(stdout);
	
	CALLAPI(METHOD_find_method("T5_TMCAEModelRevision", "ITEM_copy_rev", &method_TMCAE));
	if (method_TMCAE.id)
	{
		CALLAPI(METHOD_add_action(method_TMCAE, METHOD_post_action_type, (METHOD_function_t)Revise_Post_Action_TMCAE, NULL));
		TC_write_syslog("\n\nAfter Register Revise_Post_Action_TMCAE\n");
		printf("\n Registered as Revise_Post_Action_TMCAE for Creation \n");
		fflush(stdout);
	}
	else
		printf("\n Method not found! \n");
	fflush(stdout);

	/********** Adi**************/
	CALLAPI(METHOD_find_method("T5_TMCAEAnalysisRevision", "ITEM_copy_rev", &method_TMCAEAna));
	if (method_TMCAEAna.id)
	{
		CALLAPI(METHOD_add_action(method_TMCAEAna, METHOD_post_action_type, (METHOD_function_t)Revise_Post_Action_TMCAEAna, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_TMCAEAna \n");
		printf("\n Registered as Revise_Post_Action_TMCAEAna for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method not found! \n");
		fflush(stdout);
	}
	/********** Adi**************/

	CALLAPI(METHOD_find_method("T5_SparKitRevision", "ITEM_copy_rev", &method_SpareKit));
	if (method_SpareKit.id)
	{
		CALLAPI(METHOD_add_action(method_SpareKit, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_SpareKit \n");
		printf("\n Registered as Revise_Post_Action_SpareKit for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method not found! \n");
		fflush(stdout);
	}

	CALLAPI(METHOD_find_method("T5_EE_PartRevision", "ITEM_copy_rev", &method_EE));
	if (method_EE.id)
	{
		CALLAPI(METHOD_add_action(method_EE, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_EE_Part \n");
		printf("\n Registered as Revise_Post_Action_EE_Part for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method EE not found! \n");
		fflush(stdout);
	}

	// color scheme

	CALLAPI(METHOD_find_method("T5_clschmRevision", "ITEM_copy_rev", &method_ColSchm));
	if (method_ColSchm.id)
	{
		CALLAPI(METHOD_add_action(method_ColSchm, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_properties_post \n");
		printf("\n Registered as Revise_properties_post for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method not found! \n");
		fflush(stdout);
	}

	CALLAPI(METHOD_find_method("T5_MatEnggPartRevision", "ITEM_copy_rev", &method_MatEngg));
	if (method_MatEngg.id)
	{
		CALLAPI(METHOD_add_action(method_MatEngg, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_MatEngg_Part \n");
		printf("\n Registered as Revise_Post_Action_MatEngg_Part for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method MatEngg not found! \n");
		fflush(stdout);
	}

	CALLAPI(METHOD_find_method("T5_Std_WcqRevision", "ITEM_copy_rev", &method_StdWcq));
	if (method_StdWcq.id)
	{
		CALLAPI(METHOD_add_action(method_StdWcq, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_method_StdWcq \n");
		printf("\n Registered as Revise_Post_Action method_StdWcq for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method MatEngg not found! \n");
		fflush(stdout);
	}
	CALLAPI(METHOD_find_method("T5_VODRevision", "ITEM_copy_rev", &method_VOD));
	if (method_VOD.id)
	{
		CALLAPI(METHOD_add_action(method_VOD, METHOD_post_action_type, (METHOD_function_t)Revise_properties_post, NULL));
		TC_write_syslog("\n\n After Register Revise_Post_Action_method_VODRevision \n");
		printf("\n Registered as Revise_Post_Action method_VODRevision for Creation \n");
		fflush(stdout);
	}
	else
	{
		printf("\n Method MatEngg not found! \n");
		fflush(stdout);
	}

	return ifail;
}

extern DLLAPI int tm_CheckOutRevisepost_register_callbacks() // libRevisepost replaced by tm_CheckOutRevisepost from TZ 1.40 onwards..
{
	printf("\n Inside tm_CheckOutRevisepost_register_callbacks  \n");
	fflush(stdout);
	CUSTOM_register_exit("tm_CheckOutRevisepost", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_CheckOutRevisepost_register_post_condition);
	TC_write_syslog("\nRegister tm_CheckOutRevisepost_register_callbacks \n");
	printf("\n tm_CheckOutRevisepost_register_callbacks called.   \n");
	fflush(stdout);
	return ITK_ok;
}