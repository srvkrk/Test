/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_DM_SetEff.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

void  DMgetcurentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int DMtdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void DMNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= DMtdays( month, year );//calling DMtdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	DMgetcurentMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void DMCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n DMCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int CM_DM_SetEff(EPM_action_message_t msg)
{
	int Flag				=0;
	int ifail				= ITK_ok;
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int countDep			= 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *primary_obj		= NULLTAG;
	tag_t  primaryObj		= NULLTAG;
	tag_t  childObjTag		= NULLTAG;
	tag_t  ArchobjTypeTag	=NULLTAG;
	tag_t ArchAssyTag =NULLTAG;
	tag_t  primaryobjtype			= NULLTAG;
	tag_t  probj			= NULLTAG;
	

	char*	ObjTyp=NULL;
	char*   Archtype_name=NULL;
	char*   primaryobj_name=NULL;
	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectrevId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *type_name		=NULL;
	char   *archId		=NULL;
	char   *OccUIDattr				= NULL;

	date_t			date_start				= NULLDATE;
	date_t			date_end				= NULLDATE;

	int n_parents=0;
	int *levels = 0;
	tag_t *parents = NULL;
	
	char *username;
	tag_t user_tag=NULLTAG;
	char *userid;
	//EPM_decision_t decision = EPM_go;
	
	printf("\n CM_DM_SetEff Function started...");fflush(stdout);
	TC_write_syslog("\n CM_DM_SetEff Function started...");

	ifail = EPM_ask_root_task(msg.task, &roottask);
	ifail = EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments);
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* CM_DM_SetEff INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** CM_DM_SetEff Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				ifail = GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation);
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t CM_DM_SetEff DmlItemsRelation relation found......");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject);
					printf("\n\t CM_DM_SetEff count is : %d",count);
					if(count >0)
					{
						for(j=0;j<count;j++)
						{
						  ifail = AOM_ask_value_string(SecObject[j],"t5_PartType",&objecttype);
						  ifail = AOM_ask_value_string(SecObject[j],"item_revision_id",&objectrevId);
						  ifail = AOM_ask_value_string(SecObject[j],"item_id",&objectId);
						  ifail = AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus);

						  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
						  printf("SecObject objectrevId = [%s]\n",objectrevId);fflush(stdout);
						  printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && (tc_strcmp(objecttype,"M")==0 ))
						  {	  
	    					  if(GRM_find_relation(taskAttachments[i],SecObject[j],DmlItemsRelation,&probj));
    						  if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
							  if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
							  printf("\n CM_DM_SetEff primaryobj_name -------->  :%s\n", primaryobj_name);fflush(stdout);
							  if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
							  {
								  printf("\n\tC M_DM_SetEff Inside getting BOMUID Attr \n"); fflush(stdout);
								  ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
								  printf("\n CM_DM_SetEff OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
							  }
							  
							  if(PS_where_used_all(SecObject[j],1,&n_parents,&levels,&parents));
							  printf("\n\t CM_DM_SetEff where_used count of objects are : %d",n_parents); fflush(stdout); // 1
							  if(n_parents >0)
							  {
								  for (k=0;k<n_parents;k++)
								  {
									 ArchAssyTag=parents[k];

									  ifail = AOM_UIF_ask_value(ArchAssyTag,"object_type",&type_name);
									 
									  if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									  if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
									  printf("\n\t CM_DM_SetEff Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										  printf("\n\t CM_DM_SetEff Inside T5_ArchModuleRevision........");fflush(stdout);

										 ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&archId);

										  printf("\n\t CM_DM_SetEff Architecture ID is := %s", archId);fflush(stdout); //ItemRevision

										  ifail = ITEM_find_item(objectId, &childObjTag);
										  
										  if((ArchAssyTag != NULLTAG) && (childObjTag != NULLTAG))
										  {
											printf("\n CM_DM_SetEff ...To call FUNCTION...!!");fflush(stdout);

											POM_get_user(&username,&user_tag);
											SA_ask_user_identifier2	(user_tag,&userid)	;
											printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
											if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0 && tc_strcmp(userid,"infodba")!=0)
											{

											  ifail = Delete_occurance_effectivity(ArchAssyTag, childObjTag,OccUIDattr,objectId);
											  break;
											}
										  }
									  }
								  }
							  }
						  }
						}
					}
				}
			}
		}
		
	}
	printf("\n CM_DM_SetEff Function end...");fflush(stdout);
	TC_write_syslog("\n CM_DM_SetEff Function end...");
	//return ifail;		
	return 0;		
}	

int Delete_occurance_effectivity(tag_t primaryObj,tag_t childObjTag,char* OccUIDattr,char* objectId)
{
	int		ifail		= ITK_ok;
	int		bvr_count = 0;	
	int		g = 0;	
	int		effcnt = 0;	
	int		effcnt1 = 0;	
	int	in = 0;	
	tag_t   bom_window=NULLTAG;
	tag_t  *bomchild=NULLTAG;
	
	tag_t  *Effobbj=NULLTAG;
	tag_t  *Effobbj1=NULLTAG;
	int		iy = 0;	
	int	cnt = 0;	
	int	cnt1 = 0;	
	int PrtRelStus_cnt;
	int ii,n;
	int n_occs=0;
	int n_occs1=0;
	int gy=0;
	int z=0;
	int noocc=0;
	int Occuidfl=0;
	int Effocc=0;
	char cNextDate[20]={0};
	char EffecName[200];
	char EffecName1[200];
	char EffecRange[200];
	char EffecRange1[200];
	date_t *Rel_start_end_values	= NULL;
	tag_t			EffecTag						= NULLTAG;
	tag_t			EffecTag1						= NULLTAG;
	tag_t *Crevsn_list		= NULLTAG;
	tag_t			revTag1						= NULLTAG;
	tag_t			revTag12						= NULLTAG;
	tag_t			EffecTagrr						= NULLTAG;
	tag_t			*EffecTagrrww						= NULLTAG;
	tag_t			bvr						= NULLTAG;
	tag_t			ChildItem						= NULLTAG;
	tag_t			bom_rule,bomtop_line;
	char			*mycusdate1				= NULL;
	char			*dataset_name1				= NULL;
	char			*child_item_id				= NULL;
	char			*dataset_name12				= NULL;
	char			*dataset_name123				= NULL;
	char			*t5Des_Rev				= NULL;
	char			*t5Des_Rev1				= NULL;
	char			*Effeids				= NULL;
	char			*Effeid				= NULL;
	int rev_count;
	char *tempmat=NULL;
	tag_t *PrtRelStusTg     = NULLTAG;
	tag_t			bvrchild						= NULLTAG;
	tag_t			note_type						= NULLTAG;
	tag_t			clientdata						= NULLTAG;
	tag_t			*bvrs ;	
	char*	 PrtRelStus		= NULL;
	char	*note_name			= NULL;
	int NRFlag =0;
	int mulocc =0;
	int incmul =0;

	date_t			test_date_1				= NULLDATE;
	date_t			test_date_2				= NULLDATE;
	date_t			test_date_3				= NULLDATE;
	date_t			Ltest_date_2				= NULLDATE;
	date_t			Ltest_date_1				= NULLDATE;
	int  	EFFECTIVITY_closed  ;
	char cCurrentAccessDate[20]={0};
	char	*old_to_date			= NULL;
	char	*current_to_date			= NULL;
	char	*NextDateS			= NULL;
	char	*UPdateS			= NULL;
	char	*UPdateSe			= NULL;
	char	*note_text			= NULL;

	char* EffecEnd = NULL;
	char* Effecsta = NULL;
	char* Effecsta1 = NULL;
	char* EffecEnd1 = NULL;

	char* Effecoccname = NULL;
	char* Effecid = NULL;
	char *tempmat1=NULL;

	char* EFF_OLD = NULL;
	char* EFF_CURRENT = NULL;
	char * 	id ;
	char * 	olduid =NULL;
	logical date_is_valid  ;
	logical effext  ;
	logical isalleff  ;
	tag_t  *occs=NULL;
	WSOM_effectivity_info_t** effeinf;

	date_t  *eff_dates_arr;
	date_t  *eff_dates_arr1;
	date_t  *eff_dates_arr2;
	date_t  *Lstart_end_date;


	tag_t *occsal;
	tag_t *occsal1;
	
	int	   j = 0;
	int	   Updflg = 0;
	int	   nooccret = 0;
	int	   Updcnt = 0;
	int    bl_config=0;
	int    fndid=0;
	int    uidType=0;
	int    uidTypenew=0;
	int    fndidlatest=0;
	int    Uidlatest=0;
	int	   Updchldcnt=0;
	int	   count=0;
	int    Uidkey=0;
	int    strcnt1=0;
	int xform_matrix1 = 0;
	char PartNum[300];
	char transcpy[1000];

	tag_t   window=NULLTAG;
	tag_t	rule;
	tag_t	line;

	tag_t   Updbom_window=NULLTAG;
	tag_t	Updbom_rule;
	tag_t	Updbom_line;
	tag_t  *Updbomchild=NULLTAG;
	tag_t  *child=NULLTAG;
	tag_t  uidTag=NULLTAG;
	double mat[4][4];
	double divInt=1000;
	int imat=0;
	int jmat=0;

	char			**child_fndid				= NULL;
	char			*ErrorText				    = NULL;
	char			*child_fndid_latest				= NULL;
	char			*child_Uidlatest				= NULL;
	char			*Updchld				= NULL;
	char			*chldid				= NULL;
	char *			newuid =NULL;
	char * 			uidltswrk =NULL;
	char * 			uidocc =NULL;
	char			*child_Uidkey				= NULL;
	char *xform_matrix_str = NULL;

	char** ChildUID=NULL;
	char* EffecIdsub=NULL;
	char* ChildUIDNEW=NULL;
	char str[20];    //create an empty string to store number	
	char		*sep				= "_";
	char 		*test 				= (char*)MEM_alloc(sizeof(char) * 3000);
	

	logical bl_config_log;

	printf("\n Delete_occurance_effectivity Function started...");fflush(stdout);
	TC_write_syslog("\n Delete_occurance_effectivity Function started...");

	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);

	printf("\n CM_DM_SetEff bvr count is...%d",bvr_count);fflush(stdout);

    DMCurrentDateTime(cCurrentAccessDate);
	printf("\n CM_DM_SetEff Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	DMNextDate(cNextDate);
	printf("\n CM_DM_SetEff cNextDate:%s",cNextDate);

	if (bvr_count)
	{
		bvr = bvrs[0];
		
		if(BOM_create_window(&window)!=ITK_ok);
		if(CFM_find( "Latest Working", &rule )!=ITK_ok);
		if(BOM_set_window_config_rule(window,rule )!=ITK_ok);
		if(BOM_set_window_pack_all(window, false)!=ITK_ok);
		if(BOM_set_window_top_line(window, null_tag,primaryObj , null_tag, &line)!=ITK_ok);

		if(BOM_set_window_top_line_bvr(window,bvr,&line));

		if(BOM_line_ask_all_child_lines(line,&count,&child));
		printf("\n CM_DM_SetEff count::::::::>>>>>>>> %d\n",count);

		for (j = 0; j<count; j++)
		{
			if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
			
			printf("\n CM_DM_SetEff t5childitems_id in Update loop ===> :: %s <<>> %s \n",chldid,objectId); fflush(stdout);

			if	(tc_strcmp(chldid,objectId)==0)
			{
				ITK__convert_tag_to_uid(child[j],&uidltswrk);
				printf("\n CM_DM_SetEff uidltswrk... [%s]\n",uidltswrk);fflush(stdout);

				
			   if( AOM_ask_displayable_values(child[j],"bl_occ_t5_uidsap",&strcnt1,&child_fndid))PrintErrorStack();
				printf("\n CM_DM_SetEff child_fndid===============>>>>>>1111 %s\n",child_fndid[0]);

				
				
				 if( AOM_ask_displayable_values(child[j],"bl_occ_t5_uidsap",&strcnt1,&ChildUID))PrintErrorStack();
				printf("\n CM_DM_SetEff ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);

                if(strcnt1>0)
				{
				    if ((tc_strstr(OccUIDattr,ChildUID[0])!= NULL))
				    {
				    	printf("\n Inside CM_DM_SetEff comparing uid 1 ChildUID & OccUIDattr \n");fflush(stdout);						 
				    	Occuidfl++;
				    }
				}
			}					
		}

		printf("\n CM_DM_SetEff Occuidfl===============>>>>>> %d\n",Occuidfl);
		
		if (Occuidfl > 0)
		{
			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
			printf("\n CM_DM_SetEff n_occs count is...%d",n_occs);fflush(stdout);

			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				printf("\n CM_DM_SetEff Master name is  :%s ",dataset_name1);fflush(stdout);

				ITK__convert_tag_to_uid(occsal[iy],&uidocc);
				printf("\n CM_DM_SetEff uidocc... [%s]\n",uidocc);fflush(stdout);

				if (tc_strstr(OccUIDattr,uidocc)!= NULL)
				{
					if	(tc_strcmp(dataset_name1,objectId)==0)
					{
						ifail =  AOM_lock( bvr );

						ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);
						printf("\n CM_DM_SetEff count is...%d",effcnt);fflush(stdout);

						if (effcnt > 0)
						{
							ifail = PS_occ_eff_ask_dates(bvr,occsal[iy],Effobbj[0],&g,&Rel_start_end_values,&EFFECTIVITY_closed); //Prajakta--changed declaration of EFFECTIVITY_closed 
							
							if(g > 0)
							{
								if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
								{
									return ifail;
								}
								printf("\n CM_DM_SetEff Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
							}

							printf("\n CM_DM_SetEff Eff:cCurrentAccessDate:[%s] ",cCurrentAccessDate);fflush(stdout);

							EFF_OLD=subString(old_to_date,0,11);
							EFF_CURRENT=subString(cCurrentAccessDate,0,11);

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,EFF_OLD);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EFF_CURRENT);

							printf("\n CM_DM_SetEff Eff:ctest is..:[%s]",EffecRange);fflush(stdout);

                            ifail = AOM_lock( bvr );
							ifail = AOM_lock( Effobbj[0] );

							ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],Effobbj[0],EffecRange,false);
							if(ifail != ITK_ok)
                             {
                              AOM_unlock(Effobbj[0]);
                             EMH_ask_error_text(ifail,&ErrorText);
                             }
                             else
                             {
                             AOM_save_without_extensions(Effobbj[0]);
                             AOM_refresh(Effobbj[0],0);
                             AOM_unlock(Effobbj[0]);
                             }

                               if(ifail != ITK_ok)
                               {
                                AOM_unlock(bvr);
                               EMH_ask_error_text(ifail,&ErrorText);
                               }
                               else
                               {
                               AOM_save_without_extensions(bvr);
                               AOM_refresh(bvr,0);
                               AOM_unlock(bvr);
                               }
							
							ifail = AOM_refresh(childObjTag, 1);
							ifail = AOM_save_without_extensions(childObjTag);
							  if(ifail != ITK_ok)
                               {
                                AOM_unlock(childObjTag);
                               EMH_ask_error_text(ifail,&ErrorText);
                               }
                               else
                               {
                               AOM_save_without_extensions(childObjTag);
                               AOM_refresh(childObjTag,0);
                               AOM_unlock(childObjTag);
                               }
							ifail = AOM_refresh(primaryObj, 1);
							ifail = AOM_save_without_extensions(primaryObj);
							if(ifail != ITK_ok)
                             {
                              AOM_unlock(primaryObj);
                             EMH_ask_error_text(ifail,&ErrorText);
                             }
                             else
                             {
                             AOM_save_without_extensions(primaryObj);
                             AOM_refresh(primaryObj,0);
                             AOM_unlock(primaryObj);
                             }
							
						}
					}
				}
			}
		}
	}
	printf("\n Delete_occurance_effectivity Function end...");fflush(stdout);
	TC_write_syslog("\n Delete_occurance_effectivity Function end...");
	//return ifail;
	return 0;
}

