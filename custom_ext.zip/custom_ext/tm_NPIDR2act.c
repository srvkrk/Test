#include "TMLLibrary_server_exits.h"

int tm_NPIDR2act(EPM_action_message_t msg)
{
    printf("\n *********** ::start here:: **********");fflush(stdout);
	printf("inside tm_NPIDR2act handler");fflush(stdout);

    int ifail=ITK_ok;
    int r,Xp,l;
	int revcount;
	int error_code			 = ITK_ok;
	int i					 = 0;
	int j					 = 0;
	int k					 = 0;
	int count				 = 0;
	int taskcount			 = 0;
	int flagVC				 = 0;
	int notsk				 = 0;
	int dmlCnt				 = 0;
	int o				     = 0;
	int a				     = 0;
    int	Breakdowncount       = 0;
	int	Xpartcount           = 0;
	int	countt               = 0;
	int DR2_flag             = 0;
	int NPIHistoryFlag       = 0;
	int cnt_ccvcls           = 0;
	int no_attach			 = 0;
	int drflag			     = 0;
	int CheckAssignFlag			     = 0;
	int ProcessNPIAssFlag			     = 0;
	int prttotskrelcount			     = 0;
	int s			     = 0;
	int tsktodmlrelcount			     = 0;
	int wflcount			     = 0;
	int t			     = 0;
	//int a			     = 0;

	char *objecttype		 = NULL;
	char *objectId		     = NULL;
	char *objectdesc		 = NULL;
	char *objectrelstatus	 = NULL;
	char *objectDRstatus	 = NULL;
	char *DMLDRstauts		 = NULL;
	char *value			     = NULL;
	char *objTypeofTask      = NULL;
	char *revpartid      = NULL;
	char *prtrlsts      = NULL;
	char *objtype      = NULL;
	char *sDMLtyp      = NULL;
	char *Dml_DR_stat      = NULL;
	char *NPITask      = NULL;

	tag_t Xpartcount1        = NULLTAG;
	tag_t XPartTags1         = NULLTAG;
	tag_t item               = NULLTAG;
	tag_t reltiontype        = NULLTAG;
	tag_t techspecobjs1      = NULLTAG;
	tag_t DMLTaskTag         = NULLTAG;
	tag_t DMLtsk_tag         = NULLTAG;
	tag_t DMLtaskRevTag       = NULLTAG;
	tag_t tsk_dml_rel_type   = NULLTAG;
	tag_t DMLRevTg           = NULLTAG;
	tag_t veh_tsk_rel        = NULLTAG;
	tag_t task_dml_rel       = NULLTAG;
	tag_t query			     = NULLTAG;
	tag_t rev_list1          = NULLTAG;
	tag_t DmlItemsRelation	 = NULLTAG;
	tag_t Taskrelation_type  = NULLTAG;
	tag_t DMLObject		     = NULLTAG;
	tag_t prttotskrel		     = NULLTAG;
	tag_t TskReviTag		     = NULLTAG;
	tag_t tsktodmlrel		     = NULLTAG;
	tag_t swfltag		     = NULLTAG;

	tag_t roottask			 = NULLTAG;
	tag_t objTypTag		     = NULLTAG;
    tag_t   ClsObj           = NULLTAG;
	tag_t DMLRevTag            = NULLTAG;
	tag_t DMLReviTag            = NULLTAG;

	tag_t *BreakdowncountTags= NULLTAG;
	tag_t *XPartTags         = NULLTAG;
	tag_t *rev_list          = NULLTAG;
	tag_t *techspecobjs      = NULLTAG;
	tag_t *DMLRevision       = NULLTAG;
	tag_t *tsk_rev           = NULLTAG;
	tag_t *TskRev           = NULLTAG;
	tag_t *DMLRev           = NULLTAG;

	tag_t *SecObject		 = NULLTAG;
	tag_t *taskObject		 = NULLTAG;
	tag_t *Attachments	     = NULLTAG;
	tag_t *contrlObjs	     = NULLTAG;
	tag_t *ClsObjTag	     = NULLTAG;
	tag_t *taskAttachments	 = NULLTAG;
	tag_t *wfltag	 = NULLTAG;


	char *DMLNo              = NULL;
	char *sDMLno             = NULL;
	char *objType            = NULL;
	char *item_id            = NULL;
	char *objTypeofDML       = NULL;
	char *DMLtype            = NULL;
	char *Breakdownobj       = NULL;
	char *partid             = NULL;
	char *classofobj         = NULL;
	char *revid              = NULL;
	char *DRattri            = NULL;
	char *releasestatus      = NULL;
	char *PartStatus         = NULL;
	char *parttype           = NULL;
	char *attrivalue         = NULL;
	char *dmldr              = NULL;
	char *fromtostatus       = NULL;
	char *dmlreltype         = NULL;
	char *dmlreltype2        = NULL;
	char *sNpiInfo1          = NULL;
	char *sNpiInfo2          = NULL;
	char *sNpiInfo3          = NULL;
	char *sNpiInfo4          = NULL;
	char *sDMLDR             = NULL;
	char *dmltskNo           = NULL;
	char *AttrKeyValue           = NULL;
	char *Tsk_object_type              = NULL;
	char *relation_name              = NULL;

	char *TechSpecNum        = NULL;
	char *VCBusUnit          = NULL;
	char  *VCBusUnitDup          = NULL;
	char  *partDR          = NULL;
	char  *partStat          = NULL;
	//char  *partStat          = NULL;
	

	tag_t *TskTags	 = NULLTAG;
	tag_t *PrtsTag	 = NULLTAG;
	tag_t *primaryobjs           = NULLTAG;

    tag_t TechSpecObjTag            = NULLTAG;

	tag_t relation_type_tag            = NULLTAG;
	tag_t TskTags1            = NULLTAG;

	int TScount			 = 0;
	int Tskcount			 = 0;
	int p			 = 0;
	int prtcnt			 = 0;
	int hp			 = 0;

	logical islatest;
	logical is_latest;

	EPM_decision_t decision = EPM_nogo;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_NPIDR2act Function started...");fflush(stdout);
	TC_write_syslog("\n tm_NPIDR2act Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	char *dmlTaskNo =(char *) MEM_alloc(sizeof(char)* 50);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_NPIDR2act:INSIDE Attachments.");fflush(stdout);
			//DMLtsk_tag=taskAttachments[i];

			DMLRevTag=taskAttachments[i];

			printf("\n tm_NPIDR2act:INSIDE not null tag.");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="NPICHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sNpiInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sNpiInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sNpiInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sNpiInfo4));
					printf("\n L1:sNpiInfo1 is : [%s]  L2:sNpiInfo2 is : [%s]  L3:sNpiInfo3 is : [%s] L4:sNpiInfo4 is : [%s]\n",sNpiInfo1,sNpiInfo2,sNpiInfo3,sNpiInfo4);fflush(stdout);

					if(tc_strstr(sNpiInfo1,"NPIOFF5") != NULL)
					{
					    return 0;
					}
					if(tc_strstr(sNpiInfo1,"NPIOFF1") == NULL)
					{
						//ITK_CALL(ITEM_ask_latest_rev(DMLtsk_tag,&DMLtaskRevTag));
						//printf("\n DML task tag is not null ");


						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n  object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&objType));
						    printf("\n  item_id is %s\n", objType);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_NPIDR2act--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
							   printf("\n tm_NPIDR2act--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\n  t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
								printf("\n  sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

								DR2_flag =0;
								if(tc_strstr(sNpiInfo1,"NPIOFF3") == NULL)
								{
									if(tc_strcmp(DMLtype,"Veh")==0)
									{
										if(tc_strstr(sNpiInfo1,"NPIOFF6") != NULL)
										{
											if((tc_strcmp(sDMLDR,"DR2")==0) || (tc_strcmp(sDMLDR,"AR2")==0))
											{
												DR2_flag=1;
												printf("\n inside for condition");fflush(stdout);
												printf("\n DR2_flag is %d",DR2_flag);fflush(stdout);
												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];
													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n P60:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{
														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n DML DR from-to status is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(AOM_ask_value_tags(TskTags1,"CMHasSolutionItem",&prtcnt,&PrtsTag));
															printf("\n P61:Now prtcnt:%d.",prtcnt);fflush(stdout);

															if (prtcnt>0)
															{
																for (k=0; k<prtcnt; k++)
																{
																	ITK_CALL(ITEM_ask_item_of_rev(PrtsTag[k],&item));

																	ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));

																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n partid = %s \n",partid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n parttype = %s \n",parttype);fflush(stdout);
																	if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
																	{

																		ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																		printf("\n after T5_VCSpec relation find"); fflush(stdout);
																		if(relation_type_tag != NULLTAG)
																		{
																			printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																			ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																			printf("\n relation_name[%s]",relation_name); fflush(stdout);

																			ITK_CALL(GRM_list_secondary_objects_only(PrtsTag[k],relation_type_tag,&TScount,&primaryobjs));
																			printf("\n TScount: %d\n", TScount);fflush(stdout);
																			if(TScount>0)
																			{
																				TechSpecObjTag=primaryobjs[0];
																				printf("\nDlgNpiCodeValuDup");fflush(stdout);
																				ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																				printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																				ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));//14.3
																				if(VCBusUnit)
																				{
																					tc_strdup(VCBusUnit,&VCBusUnitDup);
																				}
																				printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																			}
																		}
																		if (VCBusUnitDup!=NULL)
																		{
																			char TobeUpdAttrId[30];
																			int retcount;
																			int ClsAttrId=0 ;
																			printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																			ITK_CALL(getNPICodeAttrNoWrtTSBU(VCBusUnitDup,&retcount));
																			printf("\n after call getNPICodeAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
																			ClsAttrId=retcount;
																			printf("\n ClsAttrId[%d] for NPI Code \n",ClsAttrId);fflush(stdout);
																			if(ClsAttrId>0)
																			{

																				sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																				printf("\n inside sprintf TobeUpdAttrId[%s] for NPI Code \n",TobeUpdAttrId);fflush(stdout);
																				//key_lov_id=theKeyLOVId;
																			}
																			printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);
																			ITK_CALL(AOM_ask_value_tags(item,"IMAN_classification",&cnt_ccvcls,&ClsObjTag));
																			printf("\n CV_CE:P322:Classification relation: %d.",cnt_ccvcls); fflush(stdout);

																		   if (cnt_ccvcls>0)
																		   {
																			   ClsObj=*ClsObjTag;

																			   if (tc_strstr(sNpiInfo2,"NPINME3") == NULL)
																			   {
																				   CALLAPI(getClsValueFrmICSTagAct(ClsObj,&AttrKeyValue));
																					printf("\n outside function to get value from name"); fflush(stdout);
																			   }
																			   else
																			   {
																					ITK_CALL(ICS_ask_attribute_value(ClsObj,TobeUpdAttrId,&AttrKeyValue));
																					 printf("\n regular "); fflush(stdout);
																			   }


																			   printf("\n AttrKeyValue=%s",AttrKeyValue);fflush(stdout);

																				if ((tc_strcmp(AttrKeyValue,"NA")==0) || (tc_strcmp(AttrKeyValue,"")==0))
																				{
																					//break;
																					//printf("\n tm_NPICode_Review--NPI value is null \n"); fflush(stdout);

																					/*EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,ITK_err,"\nPlease add NPI_code. It is mandatory for each DR2 release. Update NPI code using option:\n Select Vehicle Revision->Tools->Product Structure Classes->Update NPI Code");
																					decision = EPM_nogo;*/
																					printf("\n need to send to NPI \n");fflush(stdout);
																					//return 10002;
																					return 0;
																				}
																				else
																				{
																					//decision = EPM_go;

																					//NO need to send
																					printf("\n NO need to send \n");fflush(stdout);
																					return 10002;

																				}
																		   }
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										else
										{
											if((tc_strcmp(sDMLDR,"DR2")==0) || (tc_strcmp(sDMLDR,"AR2")==0))
											{
												DR2_flag=1;
												printf("\n inside for condition");fflush(stdout);
												printf("\n DR2_flag is %d",DR2_flag);fflush(stdout);
												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];
													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n P60:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{
														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n DML DR from-to status is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(AOM_ask_value_tags(TskTags1,"CMHasSolutionItem",&prtcnt,&PrtsTag));
															printf("\n P61:Now prtcnt:%d.",prtcnt);fflush(stdout);

															if (prtcnt>0)
															{
																drflag = 0;
																for (k=0; k<prtcnt; k++)
																{
																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n partid = %s \n",partid);fflush(stdout);

																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_revision_id",&revpartid));
											                        printf("\n revpartid = %s \n",revpartid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n parttype = %s \n",parttype);fflush(stdout);

																	if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
																	{
																		ITK_CALL(ITEM_ask_item_of_rev(PrtsTag[k],&item));

																		ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));
																		drflag=0;
																		if (tc_strstr(revpartid,"NR")!=NULL)
																		{
																			printf("\n Sending DML to NPI for NR revision :%s \n",partid); fflush(stdout);
																			return 0;
																		}
																		else
																		{
																			CheckAssignFlag=0;
																			ProcessNPIAssFlag=0;
																			//for(hp=revcount-2;hp>=0;hp--)
																			for(hp=0;hp<revcount;hp++)
																			{
																				ITK_CALL(AOM_UIF_ask_value(rev_list[hp],"t5_PartStatus",&partDR));
																				printf("\n partDR = %s \n",partDR);fflush(stdout);

																				ITK_CALL(AOM_UIF_ask_value(rev_list[hp],"current_revision_id",&revid));
																				printf("\n revid = %s \n",revid);fflush(stdout);

																				CALLAPI(AOM_UIF_ask_value(rev_list[hp],"release_status_list",&prtrlsts));
																				printf("\n prtrlsts = %s \n",prtrlsts);fflush(stdout);

																				if ((tc_strcmp(partDR,"DR0")!=0)&&(tc_strcmp(partDR,"DR1")!=0))
																				{
																					//Get release DML(Veh) > check its DR-status> if DR2 then check for assignment
																					//If no rele DML, then check for DR2 GM DML > check for assignment.
																					//in above both cases , if assignment not found , then send to NPI
																					//in above both cases , if assignment found , then check for NPI code availability.
																					CheckAssignFlag=1;
																					//ProcessNPIAssFlag=1;
																					printf("\n Processing for NPI assignment DR2 above case"); fflush(stdout);

																					CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&prttotskrel));
																					if (prttotskrel!=NULLTAG)
																					{
																						CALLAPI(GRM_list_primary_objects_only(rev_list[hp],prttotskrel,&prttotskrelcount,&TskRev));
																						printf("\n\t prttotskrelcount : %d",prttotskrelcount);fflush(stdout);
																						for (s=0;s<prttotskrelcount ;s++ )
																						{
																							TskReviTag = TskRev[s];

																							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
																							if (tsktodmlrel!=NULLTAG)
																							{
																								CALLAPI(GRM_list_primary_objects_only(TskReviTag,tsktodmlrel,&tsktodmlrelcount,&DMLRev));
																								printf("\n  tsktodmlrelcount : %d",tsktodmlrelcount);fflush(stdout);

																								for (a=0;a<tsktodmlrelcount;a++ )
																								{
																									
																									DMLReviTag = DMLRev[a];

																									CALLAPI(AOM_ask_value_string(DMLReviTag,"object_type",&objtype));
																									printf("\n objtype name %s \n",objtype);fflush(stdout);

																									if (tc_strcmp(objtype,"ChangeRequestRevision")==0)
																									{
																										CALLAPI(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&sDMLtyp));
																										CALLAPI(AOM_ask_value_string(DMLReviTag,"item_id",&sDMLno));
																										if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&Dml_DR_stat));
																										printf("\n DMLtype is %s sDMLno:%s Dml_DR_stat %s",sDMLtyp,sDMLno,Dml_DR_stat);fflush(stdout);

																										if(((tc_strcmp(sDMLtyp,"Veh")==0)|| (tc_strcmp(sDMLtyp,"TODR")==0)) && (tc_strcmp(Dml_DR_stat,"DR2")==0))
																										{
																											//if(EPM_get_current_job(DMLReviTag,&taskjob,&task_job_type));
																											if(AOM_ask_value_tags(DMLReviTag,"fnd0AllWorkflows",&wflcount,&wfltag));
																											printf("\n wflcount %d \n",wflcount);fflush(stdout);
																											for (t=0;t<wflcount;t++)
																											{
																												//if(EPM_ask_root_task(taskjob,&roottask));
																												swfltag=wfltag[t];

																												if(AOM_UIF_ask_value(swfltag,"fnd0ActuatedInteractiveTsks",&NPITask));
																												printf("\n NPITask name %s \n",NPITask);fflush(stdout);

																												if (tc_strstr(NPITask,"NPI Code Review")!=NULL)
																												{
																													ProcessNPIAssFlag=1;
																													printf("\n ProcessNPIAssFlag %d \n",ProcessNPIAssFlag);fflush(stdout);
																													break;
																												}
																											}
																										}
																									}	
																								}
																							}
																							
																						}
																					}
																					if(ProcessNPIAssFlag >0)
																					{
																						printf("\n ProcessNPIAssFlag1111111111111 %d \n",ProcessNPIAssFlag);fflush(stdout);
																						break;
																					}
																					else
																					{
																						CALLAPI(GRM_find_relation_type("CMReferences",&prttotskrel));
																						if (prttotskrel!=NULLTAG)
																						{
																							CALLAPI(GRM_list_primary_objects_only(rev_list[hp],prttotskrel,&prttotskrelcount,&TskRev));
																							printf("\n\t prttotskrelcount : %d",prttotskrelcount);fflush(stdout);
																							for (s=0;s<prttotskrelcount ;s++ )
																							{
																								TskReviTag = TskRev[s];

																								CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
																								if (tsktodmlrel!=NULLTAG)
																								{
																									CALLAPI(GRM_list_primary_objects_only(TskReviTag,tsktodmlrel,&tsktodmlrelcount,&DMLRev));
																									printf("\n  tsktodmlrelcount : %d",tsktodmlrelcount);fflush(stdout);

																									for (a=0;a<tsktodmlrelcount ;a++ )
																									{
																										
																										DMLReviTag = DMLRev[a];

																										CALLAPI(AOM_ask_value_string(DMLReviTag,"object_type",&objtype));
																										printf("\n objtype name %s \n",objtype);fflush(stdout);

																										if (tc_strcmp(objtype,"ChangeRequestRevision")==0)
																										{
																											CALLAPI(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&sDMLtyp));
																											CALLAPI(AOM_ask_value_string(DMLReviTag,"item_id",&sDMLno));
																											if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&Dml_DR_stat));
																											printf("\n DMLtype is %s sDMLno:%s Dml_DR_stat %s",sDMLtyp,sDMLno,Dml_DR_stat);fflush(stdout);

																											if(((tc_strcmp(sDMLtyp,"Veh")==0)|| (tc_strcmp(sDMLtyp,"TODR")==0)) && (tc_strcmp(Dml_DR_stat,"DR2")==0))
																											{
																												//if(EPM_get_current_job(DMLReviTag,&taskjob,&task_job_type));
																												if(AOM_ask_value_tags(DMLReviTag,"fnd0AllWorkflows",&wflcount,&wfltag));
																												printf("\n wflcount %d \n",wflcount);fflush(stdout);
																												for (t=0;t<wflcount;t++)
																												{
																													//if(EPM_ask_root_task(taskjob,&roottask));
																													swfltag=wfltag[t];

																													if(AOM_UIF_ask_value(swfltag,"fnd0ActuatedInteractiveTsks",&NPITask));
																													printf("\n NPITask name %s \n",NPITask);fflush(stdout);

																													if (tc_strstr(NPITask,"NPI Code Review")!=NULL)
																													{
																														ProcessNPIAssFlag=1;
																														printf("\n ProcessNPIAssFlag %d \n",ProcessNPIAssFlag);fflush(stdout);
																														break;
																													}
																												}
																											}
																										}	
																									}
																								}
																								
																							}
																						}
																					}
																				}
																			}
																			if (CheckAssignFlag==0)
																			{
																				printf("\n CheckAssignFlag %d \n",CheckAssignFlag);fflush(stdout);
																				printf("\n First time DR2 case "); fflush(stdout);
																				return 0;
																			}
																			else if ((CheckAssignFlag >0) && (ProcessNPIAssFlag ==0))
																			{
																				printf("\n DR2 bove rev found but no NPI assignment, so sending."); fflush(stdout);
																				return 0;
																			}
																			else
																			{
                                                                                printf("\n condition not met for NPI"); fflush(stdout);
																				return 10002;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}

								//Checking for GMD NPI assignment.
								if(tc_strstr(sNpiInfo1,"NPIOFF2")==NULL)
								{
									//Get GMDs from vehicle revision.
									//Check for DR1 to DR2 GMDs.
									//Check for Task NPI assignment history. not for current DML.

									if (tc_strcmp(DMLtype,"TODR")==0)
									{
										ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"t5_PlntToPlnt",&fromtostatus));

										printf("\n DML DR from-to status is = %s \n",fromtostatus);fflush(stdout);


										if(tc_strstr(sNpiInfo1,"NPIOFF7") != NULL)
										{
											if ((tc_strcmp(fromtostatus,"DR1 to DR2")==0) || (tc_strcmp(fromtostatus,"AR1 to AR2")==0))
											{
												printf("\n go to task");fflush(stdout);
												printf("\n go to Part change ref relation");fflush(stdout);
												printf("\n check part type/Part no and REVISION, if vehicle then process.");fflush(stdout);
												printf("\n go to tech spec and check NPI code");fflush(stdout);
												DR2_flag=1;
												printf("\n inside for condition");fflush(stdout);

												printf("\n DR2_flag for GMD is %d",DR2_flag);fflush(stdout);

												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];

													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n P11:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);


													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{

														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n DML DR from-to status is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(AOM_ask_value_tags(TskTags1,"CMReferences",&prtcnt,&PrtsTag));
															printf("\n P61:Now prtcnt:%d.",prtcnt);fflush(stdout);


															if (prtcnt>0)
															{
																for (k=0; k<prtcnt; k++)
																{

																	ITK_CALL(ITEM_ask_item_of_rev(PrtsTag[k],&item));

																	ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));

																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n partid = %s \n",partid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n parttype = %s \n",parttype);fflush(stdout);
																	if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
																	{

																		ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																		printf("\n after T5_VCSpec relation find"); fflush(stdout);
																		if(relation_type_tag != NULLTAG)
																		{
																			printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																			ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																			printf("\n relation_name[%s]",relation_name); fflush(stdout);
																			ITK_CALL(GRM_list_secondary_objects_only(PrtsTag[k],relation_type_tag,&TScount,&primaryobjs));
																			printf("\n TScount: %d\n", TScount);fflush(stdout);
																			if(TScount>0)
																			{
																				TechSpecObjTag=primaryobjs[0];
																				printf("\nDlgNpiCodeValuDup");fflush(stdout);
																				ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																				printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																				ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));//14.3
																				if(VCBusUnit)
																				{
																					tc_strdup(VCBusUnit,&VCBusUnitDup);
																				}
																				printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																			}
																		}
																		if (VCBusUnitDup!=NULL)
																		{
																			char TobeUpdAttrId[30];
																			int retcount;
																			int ClsAttrId=0 ;
																			printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																			ITK_CALL(getNPICodeAttrNoWrtTSBUNew(VCBusUnitDup,&retcount));
																			printf("\n after call getNPICodeAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
																			ClsAttrId=retcount;
																			printf("\n ClsAttrId[%d] for NPI Code \n",ClsAttrId);fflush(stdout);
																			if(ClsAttrId>0)
																			{

																				sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																				printf("\n inside sprintf TobeUpdAttrId[%s] for NPI Code \n",TobeUpdAttrId);fflush(stdout);
																				//key_lov_id=theKeyLOVId;
																			}
																			printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);
																			ITK_CALL(AOM_ask_value_tags(item,"IMAN_classification",&cnt_ccvcls,&ClsObjTag));
																		   printf("\n CV_CE:P322:Classification relation: %d.",cnt_ccvcls); fflush(stdout);

																		   if (cnt_ccvcls>0)
																		   {
																			   ClsObj=*ClsObjTag;
																			   if (tc_strstr(sNpiInfo2,"NPINME4") == NULL)
																			   {
																				   CALLAPI(getClsValueFrmICSTagAct(ClsObj,&AttrKeyValue));
																				   printf("\n outside function to get value from name"); fflush(stdout);


																			   }
																			   else
																			   {
																					ITK_CALL(ICS_ask_attribute_value(ClsObj,TobeUpdAttrId,&AttrKeyValue));
																					  printf("\n regular"); fflush(stdout);
																			   }
																			   printf("\n AttrKeyValue=%s",AttrKeyValue);fflush(stdout);

																				if ((tc_strcmp(AttrKeyValue,"NA")==0) || (tc_strcmp(AttrKeyValue,"")==0))
																				{
																					//break;
																					//printf("\n tm_NPICode_Review--NPI value is null \n"); fflush(stdout);

																					/*EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,ITK_err,"\nPlease add NPI_code. It is mandatory for each DR2 release. Update NPI code using option:\n Select Vehicle Revision->Tools->Product Structure Classes->Update NPI Code");
																					decision = EPM_nogo;*/
																					printf("\n need to send to NPI \n");fflush(stdout);
																					return 0;
																				}
																				else
																				{
																					//decision = EPM_go;
																					//NO need to send
																					printf("\n NO need to send \n");fflush(stdout);
																					return 10002;
																				}
																		   }
																		}
																	}
																}
															}
														}
													}
												}
											}
											else
											{
												printf("\n DML DR is not applicable \n");fflush(stdout);
												return 10002;
											}
										}
										else
										{
											if((tc_strcmp(sDMLDR,"DR2")==0) || (tc_strcmp(sDMLDR,"AR2")==0))
											{
												printf("\n go to task");fflush(stdout);
												printf("\n go to Part change ref relation");fflush(stdout);
												printf("\n check part type/Part no and REVISION, if vehicle then process.");fflush(stdout);
												printf("\n go to tech spec and check NPI code");fflush(stdout);
												DR2_flag=1;
												printf("\n inside for condition");fflush(stdout);

												printf("\n DR2_flag for GMD is %d",DR2_flag);fflush(stdout);

												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];
													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n P60:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{
														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n DML DR from-to status is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(AOM_ask_value_tags(TskTags1,"CMReferences",&prtcnt,&PrtsTag));
															printf("\n P61:Now prtcnt:%d.",prtcnt);fflush(stdout);

															if (prtcnt>0)
															{
																drflag = 0;
																for (k=0; k<prtcnt; k++)
																{
																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n partid = %s \n",partid);fflush(stdout);

																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_revision_id",&revpartid));
																	printf("\n revpartid = %s \n",revpartid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n parttype = %s \n",parttype);fflush(stdout);
																	if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
																	{
																		ITK_CALL(ITEM_ask_item_of_rev(PrtsTag[k],&item));

																		ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));
																		drflag=0;
																		if (tc_strstr(revpartid,"NR")!=NULL)
																		{
																			printf("\n Sending DML to NPI for NR revision :%s \n",partid); fflush(stdout);
																			return 0;
																		}
																		else
																		{
																			CheckAssignFlag=0;
																			ProcessNPIAssFlag=0;
																			//for(hp=revcount-2;hp>=0;hp--)
																			for(hp=0;hp<revcount;hp++)
																			{
																				ITK_CALL(AOM_UIF_ask_value(rev_list[hp],"t5_PartStatus",&partDR));
																				printf("\n partDR = %s \n",partDR);fflush(stdout);

																				ITK_CALL(AOM_UIF_ask_value(rev_list[hp],"current_revision_id",&revid));
																				printf("\n revid = %s \n",revid);fflush(stdout);

																				CALLAPI(AOM_UIF_ask_value(rev_list[hp],"release_status_list",&prtrlsts));
																				printf("\n prtrlsts = %s \n",prtrlsts);fflush(stdout);

																				if ((tc_strcmp(partDR,"DR0")!=0)&&(tc_strcmp(partDR,"DR1")!=0))
																				{
																					//Get release DML(Veh) > check its DR-status> if DR2 then check for assignment
																					//If no rele DML, then check for DR2 GM DML > check for assignment.
																					//in above both cases , if assignment not found , then send to NPI
																					//in above both cases , if assignment found , then check for NPI code availability.
																					CheckAssignFlag=1;
																					//ProcessNPIAssFlag=1;
																					printf("\n Processing for NPI assignment DR2 above case"); fflush(stdout);

																					CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&prttotskrel));
																					if (prttotskrel!=NULLTAG)
																					{
																						CALLAPI(GRM_list_primary_objects_only(rev_list[hp],prttotskrel,&prttotskrelcount,&TskRev));
																						printf("\n\t prttotskrelcount : %d",prttotskrelcount);fflush(stdout);
																						for (s=0;s<prttotskrelcount ;s++ )
																						{
																							TskReviTag = TskRev[s];

																							CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
																							if (tsktodmlrel!=NULLTAG)
																							{
																								CALLAPI(GRM_list_primary_objects_only(TskReviTag,tsktodmlrel,&tsktodmlrelcount,&DMLRev));
																								printf("\n  tsktodmlrelcount : %d",tsktodmlrelcount);fflush(stdout);

																								for (a=0;a<tsktodmlrelcount ;a++ )
																								{
																									
																									DMLReviTag = DMLRev[p];

																									CALLAPI(AOM_ask_value_string(DMLReviTag,"object_type",&objtype));
																									printf("\n objtype name %s \n",objtype);fflush(stdout);

																									if (tc_strcmp(objtype,"ChangeRequestRevision")==0)
																									{
																										CALLAPI(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&sDMLtyp));
																										CALLAPI(AOM_ask_value_string(DMLReviTag,"item_id",&sDMLno));
																										if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&Dml_DR_stat));
																										printf("\n DMLtype is %s sDMLno:%s Dml_DR_stat %s",sDMLtyp,sDMLno,Dml_DR_stat);fflush(stdout);

																										if(((tc_strcmp(sDMLtyp,"Veh")==0)|| (tc_strcmp(sDMLtyp,"TODR")==0)) && (tc_strcmp(Dml_DR_stat,"DR2")==0))
																										{
																											//if(EPM_get_current_job(DMLReviTag,&taskjob,&task_job_type));
																											if(AOM_ask_value_tags(DMLReviTag,"fnd0AllWorkflows",&wflcount,&wfltag));
																											printf("\n wflcount %d \n",wflcount);fflush(stdout);
																											for (t=0;t<wflcount;t++)
																											{
																												//if(EPM_ask_root_task(taskjob,&roottask));
																												swfltag=wfltag[t];

																												if(AOM_UIF_ask_value(swfltag,"fnd0ActuatedInteractiveTsks",&NPITask));
																												printf("\n NPITask name %s \n",NPITask);fflush(stdout);

																												if (tc_strstr(NPITask,"NPI Code Review")!=NULL)
																												{
																													ProcessNPIAssFlag=1;
																													printf("\n ProcessNPIAssFlag %d \n",ProcessNPIAssFlag);fflush(stdout);
																													break;
																												}
																											}
																										}
																									}	
																								}
																							}
																							
																						}
																					}
																					if(ProcessNPIAssFlag >0)
																					{
																						printf("\n ProcessNPIAssFlag1111111111111 %d \n",ProcessNPIAssFlag);fflush(stdout);
																						break;
																					}
																					else
																					{
																						CALLAPI(GRM_find_relation_type("CMReferences",&prttotskrel));
																						if (prttotskrel!=NULLTAG)
																						{
																							CALLAPI(GRM_list_primary_objects_only(rev_list[hp],prttotskrel,&prttotskrelcount,&TskRev));
																							printf("\n\t prttotskrelcount : %d",prttotskrelcount);fflush(stdout);
																							for (s=0;s<prttotskrelcount ;s++ )
																							{
																								TskReviTag = TskRev[s];

																								CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel));
																								if (tsktodmlrel!=NULLTAG)
																								{
																									CALLAPI(GRM_list_primary_objects_only(TskReviTag,tsktodmlrel,&tsktodmlrelcount,&DMLRev));
																									printf("\n  tsktodmlrelcount : %d",tsktodmlrelcount);fflush(stdout);

																									for (a=0;a<tsktodmlrelcount ;a++ )
																									{
																										
																										DMLReviTag = DMLRev[a];

																										CALLAPI(AOM_ask_value_string(DMLReviTag,"object_type",&objtype));
																										printf("\n objtype name %s \n",objtype);fflush(stdout);

																										if (tc_strcmp(objtype,"ChangeRequestRevision")==0)
																										{
																											CALLAPI(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&sDMLtyp));
																											CALLAPI(AOM_ask_value_string(DMLReviTag,"item_id",&sDMLno));
																											if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&Dml_DR_stat));
																											printf("\n DMLtype is %s sDMLno:%s Dml_DR_stat %s",sDMLtyp,sDMLno,Dml_DR_stat);fflush(stdout);

																											if(((tc_strcmp(sDMLtyp,"Veh")==0)|| (tc_strcmp(sDMLtyp,"TODR")==0)) && (tc_strcmp(Dml_DR_stat,"DR2")==0))
																											{
																												//if(EPM_get_current_job(DMLReviTag,&taskjob,&task_job_type));
																												if(AOM_ask_value_tags(DMLReviTag,"fnd0AllWorkflows",&wflcount,&wfltag));
																												printf("\n wflcount %d \n",wflcount);fflush(stdout);
																												for (t=0;t<wflcount;t++)
																												{
																													//if(EPM_ask_root_task(taskjob,&roottask));
																													swfltag=wfltag[t];

																													if(AOM_UIF_ask_value(swfltag,"fnd0ActuatedInteractiveTsks",&NPITask));
																													printf("\n NPITask name %s \n",NPITask);fflush(stdout);

																													if (tc_strstr(NPITask,"NPI Code Review")!=NULL)
																													{
																														ProcessNPIAssFlag=1;
																														printf("\n ProcessNPIAssFlag %d \n",ProcessNPIAssFlag);fflush(stdout);
																														break;
																													}
																												}
																											}
																										}	
																									}
																								}	
																							}
																						}
																					}
																				}
																			}
																			if (CheckAssignFlag==0)
																			{
																				printf("\n CheckAssignFlag %d \n",CheckAssignFlag);fflush(stdout);
																				printf("\n First time DR2 case "); fflush(stdout);
																				return 0;
																			}
																			else if ((CheckAssignFlag >0) && (ProcessNPIAssFlag ==0))
																			{
																				printf("\n DR2 bove rev found but no NPI assignment, so sending."); fflush(stdout);
																				return 0;
																			}
																			else
																			{
																				printf("\n condition not met for NPI"); fflush(stdout);
																				return 10002;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
											else
											{
												printf("\n DML DR is not applicable \n");fflush(stdout);
												return 10002;
											}
										}
									}
									else
									{
										printf("\n release type is not applicable \n");fflush(stdout);
										return 10002;
									}
								}
								else
								{
									printf("\n Control Obj off \n");fflush(stdout);
									return 10002;
								}
							}
						}
					}
					else
					{
						printf("\n Control objects :Off");fflush(stdout);
						return 10002;
					}
				}
			}
		}
	}
	printf("\n tm_NPIDR2act Function end...");fflush(stdout);
	TC_write_syslog("\n tm_NPIDR2act Function end...");

	 return 10002;
}


int getClsValueFrmICSTagAct( tag_t  IcsClsTag ,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;
	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;
	char** attributeNames	= NULL;
	char** attributeValues	= NULL;

	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;

	int theAttributeCount =0;
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;
	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;

    printf("\n getClsValueFrmICSTagAct Function started...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagAct Function started...");

	ITK_CALL( ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount>0)
	{
			for(i=0;i<theAttributeCount;i++)
			{
				TotVCAttrCount=TotVCAttrCount+theAttributeCount;

				sprintf(attrId,"%d",theAttributeIds[i]);
				//printf("\n attrId:[%s]",attrId);fflush(stdout);

				tc_strcpy(attributeNameDup,"");
				tc_strcpy(attributeNameDup,theAttributeNames[i]);

				printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

				if((tc_strcmp(attributeNameDup,"NPI Code")==0)||(tc_strcmp(attributeNameDup,"NPI_CODE")==0))
				{

					tc_strcpy(attributeValueDup,"");

					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}
					printf("\n theAttribute Name :[%s]",attributeNameDup,i);fflush(stdout);
					printf("\n attrId:[%s]",attrId);fflush(stdout);
					printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
					*AttrVal=attributeValueDup;

				}

			}
			//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
			//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
	}

	printf("\n attributeValueDup=%s ",attributeValueDup); fflush(stdout);

	printf("\n getClsValueFrmICSTagAct Function end...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagAct Function end...");

	//return ITK_ok;
	return 0;

}



int getNPICodeAttrNoWrtTSBUNew( char *TechSpecBusunit,int   *retNpiCodeattrno )
{
    int ifail = ITK_ok;

    //tag_t        query           = NULLTAG;
    tag_t    *RetICONpiAttrNoContrlObjs=NULLTAG;
    char *CntrlObjName=NULL;
    char *NpiAttrid=NULL;
    int NpiAttridInt=0;
    int retCntrlObjcount=0;

	printf("\n getNPICodeAttrNoWrtTSBUNew Function started...");fflush(stdout);
	TC_write_syslog("\n getNPICodeAttrNoWrtTSBUNew Function started...");

    if(TechSpecBusunit)
    {
        retCntrlObjcount=0;
        //ITKCALL(getNPIAttrObj(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
        ITKCALL(getICOUpdCONew(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
        printf("\n after call getNPICodeAttrNoWrtTSBUNew count: %d \n",retCntrlObjcount);fflush(stdout);
        if(retCntrlObjcount>0)
        {
            ITKCALL( AOM_ask_value_string(RetICONpiAttrNoContrlObjs[0], "object_name", &CntrlObjName));
            printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
            AOM_ask_value_string( RetICONpiAttrNoContrlObjs[0], "t5_Userinfo1", &NpiAttrid);
            printf("\n after getNpiAttrid: info1[%s] \n",NpiAttrid);fflush(stdout);
        }
    }
    printf("\n 22getNPIAttrObj: info1[%s] \n",NpiAttrid);fflush(stdout);
    if(NpiAttrid!=NULL)
    {
         NpiAttridInt=atoi(NpiAttrid);
    }
    if(NpiAttridInt>0)
    {
         *retNpiCodeattrno =NpiAttridInt;
    }
    else
    {
        NpiAttridInt=8172;
        printf("\n NpiAttridInt=%d\n",NpiAttridInt);fflush(stdout);
         *retNpiCodeattrno =NpiAttridInt;
    }
    printf("\n\n End Qry for getNPICodeAttrNoWrtTSBU control object size ==%d with retNpiCodeattrno=%d\n",retCntrlObjcount,*retNpiCodeattrno);fflush(stdout);

    printf("\n getNPICodeAttrNoWrtTSBUNew Function end...");fflush(stdout);
	TC_write_syslog("\n getNPICodeAttrNoWrtTSBUNew Function end...");
    //return ifail;
	return 0;
}


int getICOUpdCONew( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	tag_t        query           = NULLTAG;
	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n in getICOUpdCONew func");fflush(stdout);
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);

	printf("\n getICOUpdCONew Function started...");fflush(stdout);

	TC_write_syslog("\n getICOUpdCONew Function started...");

	printf("\n b4 Qry getICOUpdCONew");fflush(stdout);

	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getICOUpdCONewgetICOUpdCONew");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);
	printf("\n\n End Qry for getICOUpdCONew control object size ==%d \n",*n_found);fflush(stdout);

	printf("\n getICOUpdCONew Function end...");fflush(stdout);
	TC_write_syslog("\n getICOUpdCONew Function end...");

	//return ifail;
	return 0;
}