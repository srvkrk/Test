/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_VcListReport.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating VC List Report.
*				  > This ITK functions will calle in Rich Client for generating report.
* Module  		     

* Since		    :   30-06-2023
* ENVIRONMENT	:   C,ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 13/06/2023  	 Vaibhav Bodkhe						    Base Code
* 10/07/2024  	 Vaibhav Bodkhe						    Custom Register Printf Removed
* 25/02/2026 	 Gopal Raj						        Added the reinforcement section
* 			
* -----------------------------------------------------------------------------
* 
*****************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
//#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov_msg.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>  
//#include <tccore/tc_errors.h>
#include <errno.h>
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <tie/tie_errors.h>
#include <tccore/grmtype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tc/wsouif_errors.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
//#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <epm/cr.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
int VcListReport(void *return_data)
{
	
	int 				n_tags_found				= 0;
    tag_t				*tags_found 				= NULLTAG;
    tag_t				item_id 					= NULLTAG;
	const char 			*attrs[1];
    const char 			*values[1];
	char 				*InputVcs					= NULL;
	char 				*OutFile					= NULL;
	char 				*TRIM						= false;
	char 				*BIW						= false;
	char 				*Engine						= false;
	char 				*Frame						= false;
	char 				*LongMem					= false;
	char 				*Reinforcement			    = false;
	FILE				*uservclist					= NULL;
	FILE				*Report						= NULL;
	char*   			itemid	     		     	= NULL;
	char*   			vc_number     		    	= NULL;
	char*   			UserName     		    	= NULL;
	char	command[1000];
	OutFile = (char *) MEM_alloc(100 * sizeof(char *));
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&InputVcs);
    USERARG_get_string_argument(&TRIM);
    USERARG_get_string_argument(&BIW);
    USERARG_get_string_argument(&Engine);
    USERARG_get_string_argument(&Frame);
    USERARG_get_string_argument(&LongMem);
    USERARG_get_string_argument(&Reinforcement);
    USERARG_get_string_argument(&UserName);
	printf("\n InputVcs Number :: %s ",InputVcs);fflush(stdout);
	printf("\n Input  Trim :: %s ",TRIM);fflush(stdout);
	printf("\n Input  BIW :: %s ",BIW);fflush(stdout);
	printf("\n Input  Engine :: %s ",Engine);fflush(stdout);
	printf("\n Input  Frame :: %s ",Frame);fflush(stdout);
	printf("\n Input  LongMem :: %s ",LongMem);fflush(stdout);
	printf("\n Input  Reinforcement :: %s ",Reinforcement);fflush(stdout);
	printf("\n Login user :: %s ",UserName);fflush(stdout);
	printf("\n Going to call Exe");fflush(stdout);
	sprintf(command,"/user/cvprod/shells/APL/VcListReport.sh  %s %s %s %s %s %s %s %s",InputVcs,TRIM,BIW,Engine,Frame,LongMem,Reinforcement,UserName);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	return ITK_ok;
}
extern int tm_VcListReportfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 8;
	int retValueType;
	int inputArgTypes[8] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //InputVcs
	inputArgTypes[1] = USERARG_STRING_TYPE; //TRIM
	inputArgTypes[2] = USERARG_STRING_TYPE; //BIW
	inputArgTypes[3] = USERARG_STRING_TYPE; //Engine
	inputArgTypes[4] = USERARG_STRING_TYPE; //Frame
	inputArgTypes[5] = USERARG_STRING_TYPE; //LongMem
	inputArgTypes[6] = USERARG_STRING_TYPE; //Reinforcement
	inputArgTypes[7] = USERARG_STRING_TYPE; //UserName
	retValueType = USERARG_STRING_TYPE ;  
	ifail=USERSERVICE_register_method("VcListReport",(USER_function_t)VcListReport,nargs,inputArgTypes,retValueType);
	
	return ifail;
}
extern DLLAPI int tm_VcListReport_register_callbacks ()
{	
	int ifail    = ITK_ok;
	ifail = CUSTOM_register_exit("tm_VcListReport", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_VcListReportfncalling);
	//printf("\n After registering userservice....tm_VcListReport");fflush(stdout);
	return(ITK_ok);
}
