#include "TMLLibrary_server_exits.h"

int tm_ChkDR(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int error_code			= ITK_ok;
	int	taskflag            = 0;
	int	count            = 0;
	int	DRFlag            = 0;
	tag_t  roottask			= NULLTAG;
	tag_t  objTypTag        = NULLTAG;
	tag_t  DMLRevTg         = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLTaskTag       = NULLTAG;
	tag_t  query            = NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  *DMLRevision     = NULLTAG;
	tag_t  *contrlObjs     = NULLTAG;

	char *dmlTaskNo   = NULL;
	char *DMLtype     = NULL;
	char *sDMLno      = NULL;
	char *DMLprirty   = NULL;
	char *sDRInfo1   = NULL;
	char *sDRInfo2   = NULL;
	char *sDRInfo3   = NULL;
	char *sDRInfo4   = NULL;
	char *fromtostatus   = NULL;
	char*	ObjTyp = NULL;
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	logical is_latest;

	//EPM_decision_t decision = EPM_go;

	printf("\n tm_ChkDR Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ChkDR Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_ChkDR:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_ChkDR:INSIDE Attachments.");fflush(stdout);
			DMLTaskTag=taskAttachments[i];

			if (DMLTaskTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="DRCHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_ChkDR Control objects : count==>%d \n",count);fflush(stdout);

				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sDRInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sDRInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sDRInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sDRInfo4));
					printf("\n L1:sDRInfo1 is : [%s]  L2:sDRInfo2 is : [%s]  L3:sDRInfo3 is : [%s] L4:sDRInfo4 is : [%s]\n",sDRInfo1,sDRInfo2,sDRInfo3,sDRInfo4);fflush(stdout);

                    if(tc_strstr(sDRInfo2,"DRON0") != NULL)
					{
						return 1;
					}

					if(tc_strstr(sDRInfo2,"DROFF1") == NULL)
					{
						if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
						if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n tm_ChkDR: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

						if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
						{
							if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
							printf("\n tm_ChkDR--DML Task No: [%s] \n", dmlTaskNo);fflush(stdout);
							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n tm_ChkDR--DML Revision from Task for : %d",countt);fflush(stdout);


								for (j=0;j<countt ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n tm_ChkDR--is_latest  is : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
									    printf("\n tm_ChkDR--is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];

										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										printf("\n tm_ChkDR--for sDMLno : [%s] ",sDMLno);fflush(stdout);

										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										printf(" tm_ChkDR Release Type: [%s]", DMLtype); fflush(stdout);


										ITK_CALL(AOM_UIF_ask_value(DMLRevTg,"t5_PlntToPlnt",&fromtostatus));
										printf("\n tm_ChkDR DML DR from-to status is = %s \n",fromtostatus);fflush(stdout);

										if((tc_strcmp(fromtostatus,"DR3 to DR3P")==0)  || (tc_strcmp(fromtostatus,"DR3 to DR4")==0) || (tc_strcmp(fromtostatus,"DR3P to DR4")==0) || (tc_strcmp(fromtostatus,"DR4 to DR5")==0) )
										{
											DRFlag=1;
											break;
										}
									}
								}
								if (DRFlag>0)
								{
								  return 0;
								}
								else
								{
								  return 1;
								}
							}
						}
					}
					else
					{
						return 1;
					}
				}
			}
		}
	}
	printf("\n tm_ChkDR Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ChkDR Function end...");

	//return error_code;
	return 0;
}