
//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Business Object T5_ERCWBSLOVImpl

*/

#ifndef TRL001__T5_ERCWBSLOVIMPL_HXX
#define TRL001__T5_ERCWBSLOVIMPL_HXX

#include <T5_tm_cmlib/T5_ERCWBSLOVGenImpl.hxx>

#include <T5_tm_cmlib/libt5_tm_cmlib_exports.h>

#define T5_ERCWBSLOVPomClassName "Fnd0ListOfValuesDynamic"

namespace TRL001
{
   class T5_ERCWBSLOVImpl; 
   class T5_ERCWBSLOVDelegate;
}
 
class  T5_TM_CMLIB_API TRL001::T5_ERCWBSLOVImpl
           : public TRL001::T5_ERCWBSLOVGenImpl 
{
public:


   /**
    * Returns List Of Values based on Dynamic LOV definition and user search criteria.
    * @param operationInputTag - Operation Input containing the modified values.
    * @param propertyName - Name of the selected property.
    * @param searchString - User entered search string.
    * @param sortByProp - Property to use for sorting.
    * @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    * @param nResults - Number of returned results.
    * @param results - Returned Values for LOV.
    * @return - Zero (0) if everything is alright otherwise the error code.
    */
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    // Constructor for a T5_ERCWBSLOV
    explicit T5_ERCWBSLOVImpl( T5_ERCWBSLOV& busObj );

    // Destructor
    ~T5_ERCWBSLOVImpl();


private:
    // Default Constructor for the class
    T5_ERCWBSLOVImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_ERCWBSLOVImpl( const T5_ERCWBSLOVImpl& );

    // Copy constructor
    T5_ERCWBSLOVImpl& operator=( const T5_ERCWBSLOVImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class TRL001::T5_ERCWBSLOVDelegate;

};

#include <T5_tm_cmlib/libt5_tm_cmlib_undef.h>
#endif // TRL001__T5_ERCWBSLOVIMPL_HXX
