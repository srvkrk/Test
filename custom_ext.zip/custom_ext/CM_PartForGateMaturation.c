/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Ritesh
*  Module               :   Workflow Rule Handler to check if Part for gate maturation folder to Gate Maturation DML
*  Code                 :   CM_PartForGateMaturation.c
*  Created on			:   Jul 27th, 2020
*  Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		CM_PartForGateMaturation
	Description			:		This handler checks if Part for gate maturation folder o Gate Maturation DML
*/

EPM_decision_t CM_PartForGateMaturation(EPM_rule_message_t msg)
{
	int   i							= 0;
	int   attachmentCount			= 0;
	char*   obj_type=NULL;
	tag_t rootTask_t				= NULLTAG;
	tag_t *taskAttachments			= NULLTAG;
	tag_t  objTypTag				= NULLTAG;	
	char*	 combo_4		= NULL;
	char*	 combo_7		= NULL;
	char*	 combo_9		= NULL;
	char*	 combo_41		= NULL;
	char*	 combo_10		= NULL;
	char*	 combo_11		= NULL;
	char*	 combo_12		= NULL;
	char*	 combo_22		= NULL;
	char*	 combo_36		= NULL;
	char*	 combo_13		= NULL;
	char*	 combo_23		= NULL;
	char*	 combo_25		= NULL;
	char*	 combo_26		= NULL;
	char*	 combo_27		= NULL;
	char*	 combo_28		= NULL;
	char*	 combo_18		= NULL;
	char*	 combo_33		= NULL;
	char*	 DMLno			= NULL;
	char*	 DMLtp			= NULL;
	char*	 CheckListType	= NULL;
	char*	 info1_value	= NULL;
	char*	 info5_value	= NULL;
	char*	 token			= NULL;
	char*	 FldrName			= NULL;
	int		Chk_count		=0;
	int		ijk				=0;
	int		FOlderflag				=0;
	int		taskcount				=0;
	int		partcount				=0;
	int		sdk				=0;
	int		tt				=0;
	int		t				=0;
	int		kk				=0;
	int		entry_c			=1;
	int		CtrObjQryCount	=0;
	int		rlsTypeFlag 	=0;
	tag_t	DMLRevTag		= NULLTAG;
	tag_t	Mani_Relation	=NULLTAG;
	tag_t	*DmlTasksTags	=NULLTAG;
	tag_t	*PartTags	=NULLTAG;
	tag_t	DMLChkList		=NULLTAG;
	tag_t	CtrObjQry		=NULLTAG;
	tag_t	*CntObj_tag		=NULLTAG;

	char		*Qry_entry[1]	= {"SYSCD"};
	char		**Qry_values    = (char **) MEM_alloc(10 * sizeof(char *));

	EPM_decision_t decision = EPM_go;
	printf("\n CM_PartForGateMaturation Function started...");fflush(stdout);
	TC_write_syslog("\n CM_PartForGateMaturation Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	
	if(attachmentCount >0)
	{
		for(i=0;i<attachmentCount;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&obj_type));
			printf("\n ********** CM_PartForGateMaturation Workfow obj type: [%s]*************\n", obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
			{
				printf("\n\t DML_Found \n");fflush(stdout);

				DMLRevTag=taskAttachments[i];

				ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLno));
				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtp));
				printf("\n\t MT: DMLno:%s ,DMLtype:%s \n",DMLno,DMLtp);fflush(stdout);


				if(QRY_find2("ControlObjects", &CtrObjQry));
				if (CtrObjQry)
				{
					printf("\n\t ControlObjects Query_found \n");fflush(stdout);
				}
				else
				{
					printf("\n\t ControlObjects Query_Not_Found \n");fflush(stdout);
				}

				Qry_values[0] = "GMDFLODER" ;

				if(QRY_execute(CtrObjQry, entry_c, Qry_entry, Qry_values, &CtrObjQryCount, &CntObj_tag));
				printf("\n\t ControlObjects Count = %d \n",CtrObjQryCount);fflush(stdout);

				if(CtrObjQryCount>0)
				{
					kk=0;
					rlsTypeFlag=0;
					for (sdk=0; sdk < CtrObjQryCount; sdk++)
					{
						ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo1",&info1_value));
						printf("\n ControlObjects Value1 = %s \n",info1_value);fflush(stdout);

						if(tc_strstr(info1_value,"FLD01")==NULL)
						{
							if(tc_strcmp(DMLtp,"TODR")==0)
							{
								if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
								printf("\nDML Task Count : %d",taskcount);fflush(stdout);
								if (taskcount>0)
								{	
									for(t=0;t<taskcount;t++)
									{		
										if(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags)); //Change References
										printf("1.partcount  is %d\n", partcount);fflush(stdout);

										if(partcount>0)
										{
											for(tt=0;tt<partcount;tt++)
											{
												if(AOM_ask_value_string(PartTags[tt],"object_name",&FldrName)!=ITK_ok)PrintErrorStack();
												printf("\n GMD:FldrName:: %s\n", FldrName);fflush(stdout);
												if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
												{
													FOlderflag=1;
													break;
												}
											}
											if (FOlderflag >0)
											{
												break;
											}
										}
									}
								}
							}
							if (FOlderflag ==0)
							{
								printf("\n GMD folder not available.");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,Rollup_err,"ERROR: - Each task of gate maturation DML should have Parts for Gate Maturation folder. Please do GMD Re-run at your end , please do refresh the CO task  \n If still issue Please connect to DML support team.");	
								decision = EPM_nogo;
								return decision;
							}
						}				
					}
				}
			}
		}
	}
	printf("\n CM_PartForGateMaturation Function end...");fflush(stdout);
	TC_write_syslog("\n CM_PartForGateMaturation Function end...");
	return decision;
}