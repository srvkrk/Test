
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	FindLatestRevSO.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   06-02-2025
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 22-01-2025  	 Amar Kate				    FindLatestRevSO

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#define _XOPEN_SOURCE 700  // Enable X/Open and POSIX APIs
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>

int InputVCLimitInt = 0;


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


/* Function to add string into a set of string */
void setuidAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

struct PartData {
    char partNumber[50];
    char revId[50];
    char uid[TCTYPE_name_size_c + 1];
};

/* Structure to store revision and release date */
struct RevisionInfo {
    tag_t revTag;
    char revId[50];
    time_t releaseDate;
    char formattedDate[50];
};

/* Function to convert date string to time_t for comparison */
time_t convert_date_string(const char *date_str, char *formatted_date) {
    struct tm tm_time = {0};
    if (strptime(date_str, "%d-%b-%Y %H:%M", &tm_time) == NULL) {
        printf("Error parsing date: %s\n", date_str);
        return 0;
    }
    time_t epoch_time = mktime(&tm_time);

    // Convert back to human-readable format for display
    strftime(formatted_date, 50, "%d-%b-%Y %H:%M", &tm_time);

    return epoch_time;
}

/* Compare function for sorting in ascending order */
int compareByDate(const void *a, const void *b) {
    struct RevisionInfo *revA = (struct RevisionInfo *)a;
    struct RevisionInfo *revB = (struct RevisionInfo *)b;

    if (revA->releaseDate < revB->releaseDate) return -1;
    if (revA->releaseDate > revB->releaseDate) return 1;
    return 0;
}

//void FindOutLatestRev( char *InputPartNumber,  char *Input_PartType,  char *Input_releaseStatus,struct PartData partData[MAX_PARTS], int *uid_count) {
void FindOutLatestRev( char *InputPartNumber,  char *Input_releaseStatus,struct PartData partData[InputVCLimitInt], int *uid_count) {
    int status;
    tag_t qryTag = NULLTAG;
    tag_t *Object_tags = NULL;
    int PartObj_count = 0;
    struct RevisionInfo *revisionsList = NULL; // Array to store released revisions
    int rev_count = 0;

	printf("\n Searching for released revisions...\n");

    printf("\n Input Part Number is : %s\n", InputPartNumber);
    //printf("\n Input_PartType: %s\n", Input_PartType);
    printf("\n Input_releaseStatus: %s\n", Input_releaseStatus);

    /* Execute Item Revision Query */
    char *qry_entryCntrl1[] = {"Item ID", "Type", "Release Status"};
    char *qry_valuesCntrl1[] = {InputPartNumber, "*", Input_releaseStatus};

    if (QRY_find2("Item Revision...", &qryTag) == ITK_ok && qryTag != NULLTAG) {
        ITK_CALL(QRY_execute(qryTag, 3, qry_entryCntrl1, qry_valuesCntrl1, &PartObj_count, &Object_tags));

        printf("\n PartObj_count is : %d\n", PartObj_count);

        if (PartObj_count > 0) {
            revisionsList = (struct RevisionInfo *)malloc(PartObj_count * sizeof(struct RevisionInfo));

            for (int i = 0; i < PartObj_count; i++) {
                tag_t InputPartRevTag = Object_tags[i];
                char *InputPartRev = NULL, *rel_status = NULL;

                ITK_CALL(AOM_ask_value_string(InputPartRevTag, "item_revision_id", &InputPartRev));
                strcpy(revisionsList[rev_count].revId, InputPartRev);
                revisionsList[rev_count].revTag = InputPartRevTag;  // Store tag

                printf("\n InputPartRev: %s\n", InputPartRev);

                ITK_CALL(AOM_UIF_ask_value(InputPartRevTag, "release_status_list", &rel_status));
                printf("\n Release Status: %s\n", rel_status);

                /* Check if revision has required release status */ 
                if (strstr(rel_status, Input_releaseStatus) != NULL) {
                    int numOfReleaseStatus = 0;
					tag_t *valuesOfReleaseStatus = NULLTAG;
					char* releaseStatusListOnPart=NULL;

					ITKCALL(AOM_ask_value_tags(InputPartRevTag, "release_status_list", &numOfReleaseStatus, &valuesOfReleaseStatus ));
					printf("\n Amar Total Release Status  %d ",numOfReleaseStatus);fflush(stdout);

					if (numOfReleaseStatus > 0) {
                        for (int j = 0; j < numOfReleaseStatus; j++) {
                            char *date_released = NULL;
     
							ITKCALL(AOM_UIF_ask_value(valuesOfReleaseStatus[j],"name",&releaseStatusListOnPart));
							printf("\n Amar Display Name releaseStatusListOnPart is : %s \n",releaseStatusListOnPart);fflush(stdout);

							printf("\n Amar Display Name releaseStatusListOnPart is : %s and Input_releaseStatus is : %s \n",releaseStatusListOnPart,Input_releaseStatus);fflush(stdout);

							if(tc_strcmp(releaseStatusListOnPart,Input_releaseStatus)==0)
							{
								ITK_CALL(AOM_UIF_ask_value(valuesOfReleaseStatus[j], "date_released", &date_released));
								printf("\n Release Date: %s\n", date_released);fflush(stdout);
								revisionsList[rev_count].releaseDate = convert_date_string(date_released, revisionsList[rev_count].formattedDate);
							} 
                        }
                        rev_count++;
                    }

                    //if (st_count > 0) {
                    //    for (int j = 0; j < st_count; j++) {
                    //        char *date_released = NULL;
                    //        ITK_CALL(AOM_UIF_ask_value(status_list[j], "date_released", &date_released));
                    //        printf("\n Release Date: %s\n", date_released);
					//
                    //        /* Convert date string to time_t and formatted date */
                    //        revisionsList[rev_count].releaseDate = convert_date_string(date_released, revisionsList[rev_count].formattedDate);
                    //    }
                    //    rev_count++;
                    //}
                }
            }
			
			/* Sort revisions by ascending release date */
			 qsort(revisionsList, rev_count, sizeof(struct RevisionInfo), compareByDate);

			 printf("\n rev_count : %d\n", rev_count);

			 /* Print sorted revisions */
			 printf("\n\n Sorted Released Revisions (Ascending Order): \n");
			 for (int i = 0; i < rev_count; i++) {
			     printf("Revision: %s | Release Date: %s\n", revisionsList[i].revId, revisionsList[i].formattedDate);
			 }

			if (rev_count > 0 && *uid_count < InputVCLimitInt) {
                char *latest_rev_uid;
                tag_t latest_rev_tag = revisionsList[rev_count - 1].revTag;

                if (latest_rev_tag != NULLTAG) {
                    (ITK__convert_tag_to_uid(latest_rev_tag, &latest_rev_uid));
                    strcpy(partData[*uid_count].partNumber, InputPartNumber);
                    strcpy(partData[*uid_count].revId, revisionsList[rev_count - 1].revId);
                    strcpy(partData[*uid_count].uid, latest_rev_uid);

                    printf("\n Latest Released Revision: %s | Release Date: %s | UID: %s\n",
                           revisionsList[rev_count - 1].revId, revisionsList[rev_count - 1].formattedDate, latest_rev_uid);
                    (*uid_count)++;
                }
            }

            free(revisionsList);
			
        }
		else
		{
			 printf("\n Amar Part Not Found in Teamcenter : %s\n", InputPartNumber);

		}
    }

}

int tm_SearchLatestPartFromItk_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	listVCString				= NULL;
	//char*	Input_PartType					= NULL;
	char*	Input_releaseStatus					= NULL;
	//char 	*retValue			= 	NULL;
	USERSERVICE_array_t 	array_struct;

	tag_t qryTag=NULLTAG;
	tag_t* Object_tags=NULLTAG;
	char* strVCLimit=NULL;
	int PartObj_count=0;
	//int InputVCLimitInt = 0;

	int buf_cnt=0;
	

	printf("\n Amar Inside tm_SearchLatestPartFromItk_Call .....\n");
	
	USERARG_get_string_argument(&listVCString);          
	//USERARG_get_string_argument(&Input_PartType); 
	USERARG_get_string_argument(&Input_releaseStatus); 
	
	printf("\n Amar listVCString => %s\n",listVCString);fflush(stdout);	
	//printf("\n Amar Input_PartType => %s\n",Input_PartType);fflush(stdout);
	printf("\n Amar Input_releaseStatus => %s\n",Input_releaseStatus);fflush(stdout);

	printf("DEBUG: listVCString length = %ld\n", strlen(listVCString));fflush(stdout);

	char *qry_entryCntrl1[] = {"SUBSYSCD", "SYSCD", "Delete Indicator"};
    char *qry_valuesCntrl1[] = {"SearchThrITK", "SearchLatestItemRev","False"};

    if (QRY_find2("Control Objects...", &qryTag) == ITK_ok && qryTag != NULLTAG) {
        ITK_CALL(QRY_execute(qryTag, 3, qry_entryCntrl1, qry_valuesCntrl1, &PartObj_count, &Object_tags));

        printf("\n PartObj_count is : %d\n", PartObj_count);

		if (PartObj_count>0)
		{
			AOM_ask_value_string(Object_tags[0], "t5_Userinfo1", &strVCLimit);
            printf("\n Amar strVCLimit: %s\n", strVCLimit);fflush(stdout);

			if (strVCLimit != NULL) {
		    InputVCLimitInt = atoi(strVCLimit);  // or use sscanf for more control
			} else {
			    printf("Error: InputVCLimit string is NULL\n");
			    InputVCLimitInt = 1000;  // fallback/default value
			}
            
		}
	}

	//Amar listVCString => "544661800108#544232807702"

	 // Make a copy of listVCString before using strtok()
	char input[50000];
	strncpy(input, listVCString, sizeof(input) - 1);
	input[sizeof(input) - 1] = '\0';
	
	char *partToken;
	char InputPartNumber[InputVCLimitInt][50];
	int count = 0;
	
	struct PartData partData[InputVCLimitInt];  // Ensure MAX_PARTS is large enough too
	int uid_count = 0;

    // Tokenize using '#'
    partToken = strtok(input, "#");

	while (partToken != NULL && count < InputVCLimitInt) {
    size_t len = strlen(partToken);
    if (len >= sizeof(InputPartNumber[count])) len = sizeof(InputPartNumber[count]) - 1;
    strncpy(InputPartNumber[count], partToken, len);
    InputPartNumber[count][len] = '\0';
    count++;
    partToken = strtok(NULL, "#");
}

printf("\n Amar Total parts tokenized: %d\n", count);fflush(stdout);

	
	for (int i = 0; i < count; i++) {
	    printf("\n Amar Processing [%d] Of PartNumber is : %s\n", i + 1, InputPartNumber[i]);
	    FindOutLatestRev(InputPartNumber[i], Input_releaseStatus, partData, &uid_count);
	}
	
	int buff_cnt = 0;
	char **uuids = NULL;
	
	printf("\nCollected Data (Part Number | Revision | UID):\n");
	for (int i = 0; i < uid_count; i++) {
	    printf("%s | %s | %s\n", partData[i].partNumber, partData[i].revId, partData[i].uid);
	    setuidAddStr(&buff_cnt, &uuids, partData[i].uid);
	}
	
	for (int g = 0; g < buff_cnt; g++) {
	    printf("\n Vall=%d %s", g, uuids[g]);
	}
	
	printf("\n Amar uuids .....\n"); fflush(stdout);
	printf("\n Amar End of tm_SearchLatestPartFromItk_Call .....\n"); fflush(stdout);	

   ITK_CALL(USERSERVICE_return_string_array((const char**)uuids, buff_cnt, &array_struct));
	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) return_data) = array_struct;
	//MEM_free(uuids);
	printf("After returning Value\n");fflush(stdout);	

	printf("\n Amar End----tm_SearchLatestPartFromItk....\n");fflush(stdout);



	return ifail;
}

extern int tm_SearchLatestPartFromItkinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for Action Plan Report

	int nargs1 = 2;
	int retValueType1;
	int inputArgTypes1[2] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	//inputArgTypes1[2] = USERARG_STRING_TYPE;  

	//retValueType1 = USERARG_STRING_TYPE ; 
	retValueType1 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE; ; 

	
	
	printf("\n tm_SearchLatestPartFromItkinitmodule before....tm_SearchLatestPartFromItk_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_SearchLatestPartFromItk_Call",(USER_function_t)tm_SearchLatestPartFromItk_Call,nargs1,inputArgTypes1,retValueType1);
	printf("\n End--tm_SearchLatestPartFromItk service call...");fflush(stdout);	

	return ifail;	
}

extern DLLAPI int tm_SearchLatestPartFromItk_register_callbacks()
{	
	int ifail    = ITK_ok;
	printf("\n Amar Before registoring userservice....tm_SearchLatestPartFromItk");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_SearchLatestPartFromItk", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_SearchLatestPartFromItkinitmodule);
	printf("\n Amar After registoring userservice....tm_SearchLatestPartFromItk");fflush(stdout);
	return ( ITK_ok );
}