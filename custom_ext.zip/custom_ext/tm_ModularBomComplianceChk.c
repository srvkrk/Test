/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ModularBomComplianceChk.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating Modular MBOM Accuracy check report for VC.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Venkat Mesala						    Base Code
* 			

* -----------------------------------------------------------------------------
* 
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
//#include <bom/bom_attr.h>
//#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <string.h>
#include <sys/stat.h>
//#include <epm/cr_effectivity.h>
#include "tm_apl_std_common_function.c"


//#define ITK_CALL 	 \
//status=X; 	 \
//if (status != ITK_ok)  	 \
//{	 \
//int	 index = 0;	 \
//int	 n_ifails = 0;	 \
//const int*	 severities = 0;	 \
//const int*	 ifails = 0;	 \
//const char**	texts = NULL;	 \
//\
//EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
//printf("%3d error with #X\n", n_ifails);	 \
//for( index=0; index<n_ifails; index++)	 \
//{	 \
//printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//}	 \
//return status;	 \
//}	 \
//;



/***/
FILE*   	 FP_Report       	  	  = NULL;
char*        stamptime        	  	  = NULL;
int      	 MBOMIndex     	     	  = 0;

/*void setAddStrFuction(int *count,char ***strset,char* str)
{
	*count=*count+1;
	
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrFuction===%s",(*strset)[*count-1]);fflush(stdout);

}*/

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;

	for(j=0;j<*count;j++)
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this

		return j;

	}
	return -1;
 }

int ReportMBomModCompliance(char *selectedTask, int n_tags_found, tag_t* tags_found)
{
	int 			status;
	int				ifail 								= ITK_ok;
	int				tsk 								= 0;
	int				stamptaskstatus						= 0;
	
	tag_t    		Task  								= NULLTAG;
	tag_t  			*vcPartTags 						= NULLTAG;
	tag_t  			vcpart  							= NULLTAG;
	tag_t			window								= NULLTAG;
	tag_t			top_bom_line						= NULLTAG;
	tag_t			*vcchild							= NULLTAG;
	tag_t			*D9Z01child							= NULLTAG;


	int 			vcpartcount							= 0;
	int 			prt      							= 0;
	int				VCNPrntctr_count					= 0;
	int				VCFrntRarAxl_count					= 0;
	int				VCAllMfg_count					= 0;
	

	char*      		taskid         	  		   			= NULL;
	char*       	partid         	    				= NULL;
	char*       	VehicleDes         	    			= NULL;
	char*       	Proj_Code         	    			= NULL;
	char*       	partrevid      	    				= NULL;
	char*       	ParttypeName         				= NULL;
	char*			ClosureRule							= NULL;
	char*			RevisionRule						= NULL;
	char*			BVRInfo								= NULL;

	char		*VehNtPrsnt01				= NULL;
	char		*VehNtPrsnt02				= NULL;
	char		*VehNtPrsnt03				= NULL;
	char		*VehNtPrsnt04				= NULL;
	char		*VehNtPrsnt05				= NULL;
	char		*VehNtPrsnt06				= NULL;
	char		*VehNtPrsnt07				= NULL;
	char		*VehNtPrsntD1D06Exp			= NULL;

	char		*VehDupAdd01				= NULL;
	char		*VehDupAdd02				= NULL;
	char		*VehDupAdd03				= NULL;
	char		*VehDupAdd04				= NULL;
	char		*VehDupAdd05				= NULL;
	char		*VehDupAdd06				= NULL;
	char		*VehDupAdd07				= NULL;
	char		*VehDupAdd08				= NULL;
	char		*VehDupAdd09				= NULL;
	char		*VehDupAdd10				= NULL;

	char		*FrontAxle				= NULL;
	char		*FrontH2D03Axle			= NULL;
	char		*RearAxle				= NULL;
	char		*PaintBdyShl		= NULL;
	char		*PaintFit		= NULL;
	char		*LoadBdyFit		= NULL;
	char		*Cockpit		= NULL;
	char		*GearBx		= NULL;

	char*      	 F1A01childobjMBOM[10000];
	char*      	 DupChildPrts[10000];
	char*      	 MbomlevelChld[10000];
	char*      	 ALLVcCldParts[10000];
	char*      	 MBOMTotalParts[10000];
	char*      	 MBOMParts[5000];
	char*      	 EBOMNtPrsentpart[5000];
	char*      	 MBOMNtPrsentpart[5000];
	char*      	 ERCParts[5000];

	tag_t 		queryFound             		= NULLTAG;
	tag_t		MBOMtop_bom_line			= NULLTAG;
	tag_t		Revrule						= NULLTAG;																	
	tag_t		vcchildMBOM					= NULLTAG;
	tag_t		D9Z01childMBOM				= NULLTAG;
	tag_t 		closer_tag     				= NULLTAG;

	tag_t			tDataSetType			= NULLTAG;
	tag_t			tDataSet				= NULLTAG;
	tag_t			tRelation				= NULLTAG;
	tag_t			PRelation				= NULLTAG;
	tag_t			taskRevTag				= NULLTAG;
	tag_t			tRlnWithDataSet			= NULLTAG;

	tag_t		*ByPsAccChk_tag				= NULLTAG;
	tag_t		*VehDupAdd_tag				= NULLTAG;			
	tag_t 		*VCNPrntctr_tag				= NULLTAG;
	tag_t 		*VCFrntRarAxl_tag			= NULLTAG;
	tag_t 		*VCAllMfg_tag			= NULLTAG;
	tag_t 		*F9Y01EXP_tag			= NULLTAG;
	tag_t 		*tClosurerule  				= NULLTAG;
	tag_t 		*Prjtags  					= NULLTAG;
	tag_t 		Project  					= NULLTAG;

	char    	*qentryCtr[3]				= {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char		**qvaluesCtr= (char **) MEM_alloc(5 * sizeof(char *));

	int			iCCID					 = 0;
	int      	 IsRearAxlePrsnt     	 = 0;
	int      	 IsFrontAxlePrsnt     	 = 0;
	int      	 IsH2D03Prsnt	     	 = 0;
	int      	 IsPaintBdyShlPrsnt      = 0;
	int      	 IsPaintFitPrsnt     	 = 0;
	int      	 IsCabCowlPrsnt     	 = 0;
	int			 kk						 = 0;
	int				 VC_count			 = 0;
	int				 VC					 = 0;
	
	int				 MBOMc_count		 = 0;
	int 			 rulefound 			 = 0;
	int 			 MBOMc 				 = 0;
	int				 BypassProg			 = 0;
	int				 F1ACnt				 = 0;
	int				 Mblevl1			 = 0;
	int				 ByPsAccChk_cnt		 = 0;
	int				 ByPsAccChkVehile	 = 0;
	int				 D9Z01_count		 = 0;
	int				 DD					 = 0;
	int				 DuplevelCnt		 = 0;
	int				 index	   			 = 0;
	int				 Dupcnt	   			 = 0;
	int				 Lvlcnt	   			 = 0;
	int				 count	   			 = 0;
	int				 VehDupAdd_Count	 = 0;
	int				 vehdup				 = 0;
	int				 SDtxtCount			 = 0;	
	int				ii				     = 0;	
	int				InCrctPrts			 = 0;
	int				p					 = 0;
	int				n_Prj_Cnt			 = 0;
	int				TotalCnt			 = 0;
	int				FrstAndSecLvlCnt	 = 0;
	int				MBOMSL				 = 0;
	int				ERCFrstLvlCnt		 = 0;
	int				ERCc				 = 0;
	int				F9Y01EXP_count		 = 0;
	int				ExceptionFlg		 = 0;
	int				MBNtPrsnt			 = 0;
	int				IsFrontRearPaintFitBdyFlag			 = 0;
		 
									

	
	
	tag_t  			Taskrev  			  = NULLTAG;
	tag_t  			Tsk_rev_tag  		  = NULLTAG;
	tag_t  			DrftSpecTypeTag	 	  = NULLTAG;

	char*		DuF1Ao1ChildobjMBOM	= NULL;
	char*       FilePath			= NULL;
	char*       taskdisc			= NULL;
	char*       obj_name			= NULL;
	char* 		datasetItemId 		= NULL;
	char*       reference_nameDS	= NULL;
	char**       DuplicatedAddSoS	= NULL;
	char*       D9Z01CldpartID		= NULL;
	char*       D9Z01parttype		= NULL;
	char*       Lvl1PrtAddress		= NULL;
	char**      Level1AllAddressSS  = NULL;
	char*		DupPrtsaddss		= NULL;
	char		*MBOMpartID			= NULL;
	char		*revseq				= NULL;												
	char		*MBOMpartModAddrs	= NULL;
	char		*PrjPlatform		= NULL;
	char		*BOMlineparttype	= NULL;
	char		*MBOMparttype		= NULL;
	char		*MBOMChldpartID		= NULL;
	char		*Chldparttype		= NULL;
	char		*MBOMSkipChldpartID		= NULL;
	char		*ChldSkipparttype		= NULL;
	char		*ERCparttype		= NULL;
	char		*ERCChldpartID		= NULL;
	char		*infoF9Y01EXP		= NULL;
	char		*infoD1D06PrjExp	= NULL;
	char		*infoD1D06ACEPrjExp	= NULL;
	char		*IsF5A04Exception	= NULL;
	char		*infoF1AY01EXP		= NULL;
	char		*AllMfgModules		= NULL;

	char		Rept_Spectype_name[TCTYPE_name_size_c+1];
	const char *Prjattrs[1];
    const char *Prjvalues[1];
	
	tag_t	SecObjctDSTag		  = NULLTAG;		
	tag_t 		file_tag    	  = NULLTAG;
	tag_t	objChild_Vhcle		  =	NULLTAG;
	tag_t	objChild_Vhclebvr	  =	NULLTAG;
	tag_t	objChild_MdlVhcle	  =	NULLTAG;
	tag_t	objChild_mdlVhclebvr  =	NULLTAG;
	tag_t	Chld_objs			  =	NULLTAG;
	tag_t	ChldObbj_Bvr		  =	NULLTAG;
	tag_t	Chld_objs_Skip		  =	NULLTAG;
	tag_t	ChldObbj_Skip_Bvr	  =	NULLTAG;
	tag_t	Chld_objs_ERC		  =	NULLTAG;
	tag_t	ChldObbj_ERC_Bvr	  =	NULLTAG;

	int		StructCntVC2ProdPlan	= 0;
	struct	BomChldStrut	ChldVC2Strut[5000];

	IMF_file_t 	file_descriptor;
	AE_reference_type_t			tagRefTypeText	= 1;
	
	printf("\n Inside ReportMBomModCompliance.......\n");fflush(stdout);		

	//Date & Time
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	char str1[100]; 
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	stamptime = (char *) MEM_alloc (sizeof (char) * 128);
	sprintf(str1, "%d", tm.tm_mday);
	sprintf(str2, "%d", tm.tm_mon + 1);
	sprintf(str3, "%d", tm.tm_year + 1900);
	sprintf(str4, "%d", tm.tm_hour);
	sprintf(str5, "%d", tm.tm_min);
	tc_strcpy(stamptime, str1);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str2);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str3);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str4);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str5);
	
	char*       MBOMReportFileName					= NULL;
	char*       FileLocation					= NULL;

	char*       A9Z01MfgModule					= NULL;
	char*       ErcRevnRul					= NULL;
	char*       ErcClslRul						= NULL;
	char*       MbomRevRul						= NULL;
	char*       MbomClsrRul						= NULL;


	char* ERCRevisionRule	= NULL;
	char* ERCClosureRule		= NULL;

	int	IsA1B01flag			= 0;	
	int	IsA1B05flag			= 0;	
	int	BypassLoadBody		= 0;	
	int	IsA9Z01MBOMflag			= 0;	


	char*	ERCBOMpartModAddrs	= NULL;
	char*	infoA1BO1Exp		= NULL;
	char*	infoA1BO5Exp		= NULL;
	char*	IsF3C04Exception		= NULL;
	char*	infoF3C04PrjExp		= NULL;

	

	tag_t	objChild_VhcleA9Z01	  =	NULLTAG;
	tag_t	objChild_VhclebvrA9Z01	  =	NULLTAG;

	MBOMReportFileName = (char *) MEM_alloc(100 * sizeof(char *));
	FileLocation = (char *) MEM_alloc(100 * sizeof(char *));

	tc_strcpy(MBOMReportFileName,"");
	tc_strcat(MBOMReportFileName,selectedTask);
	tc_strcat(MBOMReportFileName,"_");
	tc_strcat(MBOMReportFileName,stamptime);
	tc_strcat(MBOMReportFileName,".txt");
	printf("\n File Name is :- %s",MBOMReportFileName);fflush(stdout);

	int				Site_cnt	= 0;
	tag_t			*Path_tag	= NULLTAG;
	char			*File_Path		= NULL;

	ITKCALL(QRY_find2("Control Objects...",&queryFound));

	if (queryFound!=NULLTAG)
	{
		printf("\nFile Path Control Object Found\n");fflush(stdout);		
		qvaluesCtr[0]="MBOMAccuracy";
		qvaluesCtr[1]="MBOMPATH";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &Site_cnt, &Path_tag));
		if (Site_cnt>0)
		{
			ITKCALL(AOM_ask_value_string( Path_tag[0],"t5_Userinfo1", &File_Path));  
			printf("\n File Path33 : %s \n",File_Path);fflush(stdout);
		}
		else
		{
			printf("\n BOMAccuracyPath Control Object not Found \n");fflush(stdout);	
		}
	}

	tc_strcpy(FileLocation,"");
	tc_strcpy(FileLocation,File_Path);
	tc_strcat(FileLocation,MBOMReportFileName);
	printf("\nFileLocation 33: %s\t",FileLocation);fflush(stdout);
	
	if(queryFound!=NULLTAG)
	{
		printf("\n VehNtPrsnt Control Object Found22\n");fflush(stdout);
		qvaluesCtr[0]="VehNtPrsnt"; 
		qvaluesCtr[1]="EBOMList";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &VCNPrntctr_count, &VCNPrntctr_tag));
		printf("\n VehNtPrsnt Number of query found %d",VCNPrntctr_count);fflush(stdout);
		if(VCNPrntctr_count>0)
		{
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo1", &VehNtPrsnt01));  
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo2", &VehNtPrsnt02));    
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo3", &VehNtPrsnt03));
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo4", &VehNtPrsnt04));
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo5", &VehNtPrsnt05));
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo6", &VehNtPrsnt06));
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo7", &VehNtPrsnt07));
			ITKCALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo8", &VehNtPrsntD1D06Exp));
			printf("\n VehNtPrsnt User info 1 %s",VehNtPrsnt01);fflush(stdout);//D1A01;D1A02;D1A03;D1A04;D1A05;D1A06;D1A07;D1A08;D1A09; 
			printf("\n VehNtPrsnt User info 2 %s",VehNtPrsnt02);fflush(stdout);//D1A10;D1A11;D1A12;D1A13;D1A14;D1A15;D1A16;D1A17;D1A18; 
			printf("\n VehNtPrsnt User info 3 %s",VehNtPrsnt03);fflush(stdout);//D1A20;D1A22;D1A23;D1B01;D1B02;D1B03;D1B04;D1B06; 
			printf("\n VehNtPrsnt User info 4 %s",VehNtPrsnt04);fflush(stdout);//F2A01;F2A02;F2A03;F2A04;F2A05;F2A06;F5A01;F5A02;H2B01; 
			printf("\n VehNtPrsnt User info 5 %s",VehNtPrsnt05);fflush(stdout);//F1A01;F4A01;F4B01; 
			printf("\n VehNtPrsnt User info 6 %s",VehNtPrsnt06);fflush(stdout);//H2D01;H2D02;F5A03;F5A04;F5A05;F5A06;
			printf("\n VehNtPrsnt User info 7 %s",VehNtPrsnt07);fflush(stdout);//A1B01;A1B05;D1D06;D1D01;D1D02;D1D03;D1D04;D1D05;D1D07;D1D08;F3C04;D9Y01;
			printf("\n VehNtPrsnt User info 8 %s",VehNtPrsntD1D06Exp);fflush(stdout);//D1D06;
		}
		else
		{
			printf("\n VehNtPrsnt control object NOT found ");fflush(stdout);
		}
	}
	if(queryFound!=NULLTAG)
	{
		printf("\n FrontRearAxlePrsnt Control Object Found\n");fflush(stdout);
//		qvaluesCtr[0]="RearFrontAxlePrsnt"; //
//		qvaluesCtr[1]="";
		qvaluesCtr[0]="VehPrsnt"; 
		qvaluesCtr[1]="MFGModules";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &VCFrntRarAxl_count, &VCFrntRarAxl_tag));
		printf("\n FrontRearAxlePrsnt Number of query found %d",VCFrntRarAxl_count);fflush(stdout);
		if(VCFrntRarAxl_count>0)
		{
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo1", &FrontAxle));  
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo2", &RearAxle));    
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo3", &PaintBdyShl));    
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo4", &PaintFit));    
			//ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo5", &LoadBdyFit));    
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo5", &FrontH2D03Axle));    
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo6", &Cockpit));    
			ITKCALL(AOM_ask_value_string( VCFrntRarAxl_tag[0],"t5_Userinfo7", &GearBx));    
			printf("\n VCFrntRarAxl_tag User info 1 %s",FrontAxle);fflush(stdout);//H9W01;H9W02;H2D03;; 
			printf("\n VCFrntRarAxl_tag User info 2 %s",RearAxle);fflush(stdout);//H9X01;H9X02;
			printf("\n VCFrntRarAxl_tag User info 3 %s",PaintBdyShl);fflush(stdout);
			printf("\n VCFrntRarAxl_tag User info 4 %s",PaintFit);fflush(stdout);
			//printf("\n VCFrntRarAxl_tag User info 5 %s",LoadBdyFit);fflush(stdout);
			printf("\n VCFrntRarAxl_tag User info 5 %s",FrontH2D03Axle);fflush(stdout);//H2D03
			printf("\n VCFrntRarAxl_tag User info 6 %s",Cockpit);fflush(stdout);
			printf("\n VCFrntRarAxl_tag User info 7 %s",GearBx);fflush(stdout);
		}
		else
		{
			printf("\n VCFrntRarAxl_tag control object NOT found ");fflush(stdout);
		}
	}
	if(queryFound!=NULLTAG)
	{
		printf("\n Found\n");fflush(stdout);

		qvaluesCtr[0]="VehPrsnt"; 
		qvaluesCtr[1]="ALLMFGModules";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &VCAllMfg_count, &VCAllMfg_tag));
		printf("\n Veh AllMfg of query found %d",VCAllMfg_count);fflush(stdout);
		if(VCAllMfg_count>0)
		{
			ITKCALL(AOM_ask_value_string( VCAllMfg_tag[0],"t5_Userinfo1", &AllMfgModules));  
			ITKCALL(AOM_ask_value_string( VCAllMfg_tag[0],"t5_Userinfo2", &A9Z01MfgModule)); 

			printf("\n VC AllMfg_tag User info 2 %s",A9Z01MfgModule);fflush(stdout); 
			 
			printf("\n VC AllMfg_tag User info 1 %s",AllMfgModules);fflush(stdout);//H9W01;H9W02;H2D03;F9Y01;D9Y01; 
			
		}
		else
		{
			printf("\n VCAllMfg_tag control object NOT found ");fflush(stdout);
		}
	}
	if(queryFound!=NULLTAG)
	{
		printf("\n Control Objects for Some project code Exception\n");fflush(stdout);
		qvaluesCtr[0]="F9Y01EXP"; 
		qvaluesCtr[1]="CV";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &F9Y01EXP_count, &F9Y01EXP_tag));
		printf("\n VehNtPrsnt Number of query found %d",VCNPrntctr_count);fflush(stdout);
		if(F9Y01EXP_count>0)
		{
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo1", &infoF9Y01EXP));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo2", &infoF1AY01EXP));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo3", &infoD1D06PrjExp));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo4", &IsF5A04Exception));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo5", &infoD1D06ACEPrjExp));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo6", &infoA1BO1Exp));  
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo7", &infoA1BO5Exp));
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo8", &IsF3C04Exception));//F3C04
			ITKCALL(AOM_ask_value_string( F9Y01EXP_tag[0],"t5_Userinfo9", &infoF3C04PrjExp));//MHCV-T13
			 
			printf("\n  F9Y01EXPinfo 1 : %s",infoF9Y01EXP);fflush(stdout); 
			printf("\n  infoF1AY01EXP 2 : %s",infoF1AY01EXP);fflush(stdout); 
			printf("\n  infoD1D06PrjExp 3 : %s",infoD1D06PrjExp);fflush(stdout); 
			printf("\n  infoD1D06ACEPrjExp 5 : %s",infoD1D06ACEPrjExp);fflush(stdout); 
			printf("\n  IsF5A04Exception 4 : %s",IsF5A04Exception);fflush(stdout); 
			printf("\n  IsF5A04Exception 6 : %s",infoA1BO1Exp);fflush(stdout); 
			printf("\n  IsF5A04Exception 7 : %s",infoA1BO5Exp);fflush(stdout); 
			printf("\n  IsF3C04Exception 8 : %s",IsF3C04Exception);fflush(stdout); //F3c04
			printf("\n  infoF3C04PrjExp 9 : %s",infoF3C04PrjExp);fflush(stdout); //MHCV-t13
			
		}
		else
		{
			printf("\n VCF9Y01EXP_tag control object NOT found ");fflush(stdout);
		}
	}


	if(queryFound!=NULLTAG) //those are the dublicate modules, Below control objects compare child objects 
	{
		//qvaluesCtr[0]="VehDupAdd";
		//qvaluesCtr[1]="*";

		qvaluesCtr[0]="VehPrsnt"; 
		qvaluesCtr[1]="Duplicity";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &VehDupAdd_Count, &VehDupAdd_tag));
		printf("\n VehDupAdd_Count Number of query found11 %d",VehDupAdd_Count);fflush(stdout);
		if(VehDupAdd_tag[0] !=NULLTAG)
		{
			for(vehdup = 0; vehdup < VehDupAdd_Count; vehdup++)
			{
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo1", &VehDupAdd01));  
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo2", &VehDupAdd02));    
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo3", &VehDupAdd03));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo4", &VehDupAdd04));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo5", &VehDupAdd05));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo6", &VehDupAdd06));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo7", &VehDupAdd07));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo8", &VehDupAdd08));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo9", &VehDupAdd09));
				ITKCALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_userinfo10", &VehDupAdd10));
				printf("\n VehDupAdd User info 1 %s",VehDupAdd01);fflush(stdout);
				printf("\n VehDupAdd User info 2 %s",VehDupAdd02);fflush(stdout);
				printf("\n VehDupAdd User info 3 %s",VehDupAdd03);fflush(stdout);
				printf("\n VehDupAdd User info 4 %s",VehDupAdd04);fflush(stdout);
				printf("\n VehDupAdd User info 5 %s",VehDupAdd05);fflush(stdout);
				printf("\n VehDupAdd User info 6 %s",VehDupAdd06);fflush(stdout);
				printf("\n VehDupAdd User info 7 %s",VehDupAdd07);fflush(stdout);
				printf("\n VehDupAdd User info 8 %s",VehDupAdd08);fflush(stdout);
				printf("\n VehDupAdd User info 9 %s",VehDupAdd09);fflush(stdout);
				printf("\n VehDupAdd User info 10 %s",VehDupAdd10);fflush(stdout); 
			}
			
		} //B1B01
		else
		{
			printf("\n VehDupAdd control object NOT found ");fflush(stdout);
		}

	}

	if(queryFound!=NULLTAG)
	{
		printf("\n control object Found\n");fflush(stdout);

		int RulesCount	= 0;
		tag_t*	Rev_rulTag	= NULLTAG;

		qvaluesCtr[0]="ClosureRule"; 
		qvaluesCtr[1]="RevisionRule";
		qvaluesCtr[2]="0";
		ITKCALL(QRY_execute(queryFound, 3, qentryCtr, qvaluesCtr, &RulesCount, &Rev_rulTag));
		printf("\n revision and closure rule query found %d",RulesCount);fflush(stdout);
		if(RulesCount>0)
		{
			ITKCALL(AOM_ask_value_string( Rev_rulTag[0],"t5_Userinfo1", &ErcRevnRul));  
			ITKCALL(AOM_ask_value_string( Rev_rulTag[0],"t5_Userinfo2", &ErcClslRul)); 
			ITKCALL(AOM_ask_value_string( Rev_rulTag[0],"t5_Userinfo3", &MbomRevRul)); 
			ITKCALL(AOM_ask_value_string( Rev_rulTag[0],"t5_Userinfo4", &MbomClsrRul)); 

			printf("\n ERC Revision Rule: %s\n",ErcRevnRul);fflush(stdout); 
			printf("\n ERC Colosure Rule: %s\n",ErcClslRul);fflush(stdout); 
			printf("\n MBOM Revision Rule: %s\n",MbomRevRul);fflush(stdout); 
			printf("\n MBOM Closure Rule: %s\n",MbomClsrRul);fflush(stdout); 
			 
			
			
		}
		else
		{
			printf("\n VCAllMfg_tag control object NOT found ");fflush(stdout);
		}
	}
	
	char    	*qentryCtr1[3]				= {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char		**qvaluesCtr1= (char **) MEM_alloc(5 * sizeof(char *));

	
	

	if(n_tags_found >0)
	{	
	
		
		FP_Report = fopen(FileLocation,"w+");fflush(FP_Report); //user/tcuaadev/devgroups/venkat/ModBomAccryChk/tsk_time.txt

		fprintf(FP_Report,"****************************************MODULAR BOM ACCURACY CHECK****************************************\t\t");fflush(FP_Report);
		fprintf(FP_Report,"\n\n	TaskNum : %s\t",selectedTask);fflush(FP_Report);
		
		printf("\n	TaskNum11 : %s\t",selectedTask);fflush(stdout);
					
		for(tsk = 0 ;tsk < n_tags_found; tsk++)
		{	
			Task=NULLTAG;	
			Task=tags_found[tsk];

			ITKCALL(AOM_ask_value_string(Task,"item_id",&taskid));
			printf("\n Task id is : %s ",taskid);fflush(stdout);
			
			ITKCALL(ITEM_ask_latest_rev(Task,&Taskrev));
			//Get part from task
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&PRelation));
			ITKCALL(GRM_list_secondary_objects_only(Taskrev,PRelation,&vcpartcount,&vcPartTags));
			printf("\n no of parts attached to task :%d \n",vcpartcount);fflush(stdout);

			stamptaskstatus=0;

			if(vcpartcount > 0)
			{
				for(VC = 0; VC < vcpartcount;VC++)
				{ 
					printf("\n Inside VC \n");fflush(stdout);

					ByPsAccChkVehile=0; //Added by Deepti to handle if multiple V is there

					vcpart=NULLTAG;					
					vcpart=vcPartTags[VC];

					ITKCALL(AOM_ask_value_string(vcpart,"item_id",&partid));
					ITKCALL(AOM_ask_value_string(vcpart,"t5_PartType",&ParttypeName));
					ITKCALL(AOM_ask_value_string(vcpart,"item_revision_id",&partrevid));
					ITKCALL(AOM_ask_value_string(vcpart,"t5_ProjectCode", &Proj_Code));
					//ITKCALL(AOM_ask_value_string(vcpart,"object_desc", &VehicleDes)); //venkat

					printf("\n Vehicle Project code [%s] :[%s] :[%s]:[%s]",Proj_Code,ParttypeName,partid,partrevid);fflush(stdout);
					//stamptaskstatus=0;
					if (FP_Report==NULL)
					{
						printf("\n File not opened\n ");fflush(stdout);

					}
					else
					{
						printf("\n File opened\n ");fflush(stdout);
					
						if((tc_strcmp(ParttypeName, "V") == 0)||(tc_strcmp(ParttypeName,"VCCR") == 0))
						{

							
							fprintf(FP_Report,"\n\n Vehicle item id: %s\t Revision : %s ",partid,partrevid );fflush(FP_Report);
							printf("\n Vehicle item id: %s\t Revision : %s ",partid,partrevid );fflush(stdout);
							ITKCALL(AOM_ask_value_string(vcpart,"object_desc", &VehicleDes)); //venkat

							Prjattrs[0] ="item_id";
							Prjvalues[0] = Proj_Code;
							ITKCALL(ITEM_find_items_by_key_attributes(1,Prjattrs, Prjvalues, &n_Prj_Cnt, &Prjtags));
							printf("\nProject found  count:%d\n",n_Prj_Cnt);fflush(stdout);
							for (p=0;p<n_Prj_Cnt;p++ ) //54420724R
							{
								Project	=NULLTAG;

								Project=Prjtags[0];
								ITKCALL(AOM_ask_value_string(Project,"t5_Program",&PrjPlatform));
								printf("\n  Project Platform :[%s] ",PrjPlatform);fflush(stdout);
							}

							if (queryFound!=NULLTAG)
							{
								qvaluesCtr1[0]="ByPsAccChk";
								qvaluesCtr1[1]=partid;
								qvaluesCtr1[2]="0";
								ITKCALL(QRY_execute(queryFound,3, qentryCtr1, qvaluesCtr1,&ByPsAccChk_cnt,&ByPsAccChk_tag));
								if (ByPsAccChk_cnt>0)
								{
								  ByPsAccChkVehile++;
								}

							}

							if (ByPsAccChkVehile>0)
							{
								printf("\n ByPass is given for vehicle %s \n", partid);fflush(stdout);
								continue;
							}
							else
							{	

								
									int StructErcChldProdPlanerc	 =0;
									struct	BomChldStrut	ChldStrutERCChldc[5000];
								
									int ERCcc		= 0;

									if (tc_strcmp(ERCRevisionRule,"NULL")==0) MEM_free(ERCRevisionRule);
									ERCRevisionRule=(char *)MEM_alloc(100);
								
									if (tc_strcmp(ERCClosureRule,"NULL")==0) MEM_free(ERCClosureRule);
									ERCClosureRule=(char *)MEM_alloc(100);

									tc_strcpy(ERCRevisionRule,ErcRevnRul);
									tc_strcpy(ERCClosureRule,ErcClslRul);

									

										//ITKCALL(Get_Part_BOM_Lvl(vcpart,1,"BOMViewClosureRuleERC",ERCRevisionRule,"View",ChldStrutERCChldc,&StructErcChldProdPlanerc));
										printf("\n ERC Closure Rule is %s & Revision Rule111 is %s ",ERCClosureRule,ERCRevisionRule);fflush(stdout);

										ITKCALL(Get_Part_BOM_Lvl(vcpart,1,ERCClosureRule,ERCRevisionRule,"View",ChldStrutERCChldc,&StructErcChldProdPlanerc));

										printf("\nEBOM VC Childs parts Count: %d \n",StructErcChldProdPlanerc);fflush(stdout);
											IsA1B01flag =	0;
											IsA1B05flag =	0;
											BypassLoadBody	= 0;
										for (ERCcc=1; ERCcc <= StructErcChldProdPlanerc;ERCcc++)
										{

											ERCChldpartID	= NULL ;
											ERCBOMpartModAddrs	= NULL ;
											ERCparttype		= NULL ;
											Chld_objs_ERC	 =	NULLTAG;
											ChldObbj_ERC_Bvr =	NULLTAG;
											//IsA1B01flag =	0;
											//IsA1B05flag =	0;
											//BypassLoadBody	= 0;
											Chld_objs_ERC=ChldStrutERCChldc[ERCcc].child_objs;
											ChldObbj_ERC_Bvr=ChldStrutERCChldc[ERCcc].child_objs_bvr;

											ITKCALL(AOM_ask_value_string(Chld_objs_ERC,"item_id",&ERCChldpartID));
											ITKCALL(AOM_ask_value_string(Chld_objs_ERC,"t5_PartType",&ERCparttype));
											ERCBOMpartModAddrs=subString(ERCChldpartID,4,5);
											printf("\n VEHICLE A1BO1 and A1BO5 checking part type and Part id:=%s:%s AND %s\n",ERCparttype,ERCChldpartID,ERCBOMpartModAddrs);fflush(stdout);

											if ((tc_strcmp(ERCparttype,"M")==0) || (tc_strcmp(ERCparttype,"T")==0)) //TCE-Sunset related changes
											{
												printf("\n VEHICLE A1BO1 and A1BO5 checking part type and Part id:%s",ERCChldpartID);fflush(stdout);

												if ((tc_strstr(infoA1BO1Exp,ERCBOMpartModAddrs) != NULL)) //A1BO1 A1BO5
												{
													printf("\n VEHICLE A1BO1 and A1BO5 checking part type and Part id11:=%s:%s\n",ERCparttype,ERCChldpartID);fflush(stdout);
													IsA1B01flag++;
												}
												if ((tc_strstr(infoA1BO5Exp,ERCBOMpartModAddrs) != NULL)) //A1BO1 A1BO5
												{
													printf("\n VEHICLE A1BO1 and A1BO5 checking part type and Part id33:=%s:%s\n",ERCparttype,ERCChldpartID);fflush(stdout);
													IsA1B05flag++;
												}
											}


										}



								
								printf("\n Inside MBOM view BOM Expansion \n");fflush(stdout);					
								
								if (tc_strcmp(ClosureRule,"NULL")==0) MEM_free(ClosureRule);
								ClosureRule=(char *)MEM_alloc(100);
								
								if (tc_strcmp(RevisionRule,"NULL")==0) MEM_free(RevisionRule);
								RevisionRule=(char *)MEM_alloc(100);

								if (tc_strcmp(BVRInfo,"NULL")==0) MEM_free(BVRInfo);
								BVRInfo=(char *)MEM_alloc(100);
								
								if (tc_strstr(taskid,"MBOM") !=NULL) //23MM901055_00MM_MBOM
								{
									//tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM"); //BOMViewClosureRuleMBOM
									//tc_strcpy(RevisionRule,"MBOM Working and Above");

									tc_strcpy(ClosureRule,MbomClsrRul); //BOMViewClosureRuleMBOM
									tc_strcpy(RevisionRule,MbomRevRul);	
									tc_strcpy(BVRInfo,"View");	
								}
								else  
								{
									tc_strcpy(ClosureRule,"");
									tc_strcpy(RevisionRule,"");
									tc_strcpy(BVRInfo,"");
									
								}
								printf("\n Closure Rule is %s & Revision Rule111 is %s ",ClosureRule,RevisionRule);fflush(stdout);	

									int		StructCntBoltedProdPlan	= 0;
									struct	BomChldStrut	ChldStrutBlt[5000];

									int		A9Z01Cnt	= 0;

									
									char	*MBOMA9Z01partID	= NULL;
									char	*BOMlineA9Z01parttype	= NULL;
									char	*MBOMparta9Z01ModAddrs	= NULL;
									
									IsA9Z01MBOMflag	= 0;

									objChild_VhcleA9Z01		= NULLTAG;
									objChild_VhclebvrA9Z01	= NULLTAG;

									ITKCALL(Get_Part_BOM_Lvl(vcpart,1,ClosureRule,RevisionRule,BVRInfo,ChldStrutBlt,&StructCntBoltedProdPlan));
									printf("\n\t\t StructCntBoltedProdPlan:%d",StructCntBoltedProdPlan);fflush(stdout);
									if (StructCntBoltedProdPlan>0)
									{
										MBOMA9Z01partID	= NULL;
										BOMlineA9Z01parttype	= NULL;
										for (A9Z01Cnt =1; A9Z01Cnt <= StructCntBoltedProdPlan; A9Z01Cnt ++)
										{
											
											objChild_VhcleA9Z01=ChldStrutBlt[A9Z01Cnt].child_objs;
											objChild_VhclebvrA9Z01=ChldStrutBlt[A9Z01Cnt].child_objs_bvr;
											ITKCALL(AOM_ask_value_string(objChild_VhcleA9Z01,"item_id",&MBOMA9Z01partID));
											ITKCALL(AOM_ask_value_string(objChild_VhcleA9Z01,"t5_PartType",&BOMlineA9Z01parttype));
											printf("\n VEHICLE Child part type and Part id for A9Z01 part:=%s:%s\n",BOMlineA9Z01parttype,MBOMA9Z01partID);fflush(stdout);
											MBOMparta9Z01ModAddrs=subString(MBOMA9Z01partID,4,5);	
											if((tc_strcmp(BOMlineA9Z01parttype,"M")==0) || (tc_strcmp(BOMlineA9Z01parttype,"T")==0)) //TCE-Sunset related changes
											{
												if ((tc_strstr(A9Z01MfgModule,MBOMparta9Z01ModAddrs) != NULL)) //A9Z01
												{
													IsA9Z01MBOMflag++;
												}
												
											}
										

										}
									}
									BypassLoadBody  = 0;
									printf("\n A1B05flag A1B01flag and A9Z01MBOMflag :=%d:%d :%d\n",IsA1B05flag,IsA1B01flag,IsA9Z01MBOMflag);fflush(stdout);
									if ((IsA1B01flag > 0) && (IsA1B05flag > 0) && (IsA9Z01MBOMflag > 0))
									 {
										 BypassLoadBody++;
									 }
									 if( (IsA1B01flag > 0 )&& (IsA1B05flag == 0))
									{
										 BypassLoadBody++;
									}
									if ((IsA1B01flag == 0 )&& (IsA1B05flag > 0))
									{
										 BypassLoadBody++;
									}

									printf("\n  BypassLoadBody:%d\n",BypassLoadBody);fflush(stdout);



									int QuantityLvl	 =	0;
									char* bl_quantityLvl	=	NULL;

									F1ACnt					= 0;
									IsRearAxlePrsnt			= 0;
									IsFrontAxlePrsnt		= 0;
									IsH2D03Prsnt			= 0;
									IsPaintBdyShlPrsnt		= 0;
									IsPaintFitPrsnt			= 0;
									FrstAndSecLvlCnt		= 0;
									TotalCnt				= 0;
									ExceptionFlg			= 0;

									for (MBOMc = 1; MBOMc <= StructCntBoltedProdPlan; MBOMc++)
									{
										MBOMpartID	 =	NULL;
										BOMlineparttype	 =	NULL;
										QuantityLvl		= 0 ;
										
										objChild_Vhcle	 =	NULLTAG;
										objChild_Vhclebvr =	NULLTAG;
										
										objChild_Vhcle=ChldStrutBlt[MBOMc].child_objs;
										objChild_Vhclebvr=ChldStrutBlt[MBOMc].child_objs_bvr;
										
										

										ITKCALL(AOM_ask_value_string(objChild_Vhcle,"item_id",&MBOMpartID));
										ITKCALL(AOM_ask_value_string(objChild_Vhcle,"t5_PartType",&BOMlineparttype));
										printf("\n VEHICLE Child part type and Part id:=%s:%s\n",BOMlineparttype,MBOMpartID);fflush(stdout);
										ITKCALL(AOM_ask_value_string(objChild_Vhclebvr,"bl_quantity",&bl_quantityLvl));
										QuantityLvl= atoi(bl_quantityLvl);
										printf("\n part quantity :=%s And %d\n",BOMlineparttype,QuantityLvl);fflush(stdout);
										

										if(((tc_strcmp(BOMlineparttype,"M")==0) || (tc_strcmp(BOMlineparttype,"T")==0))  && (QuantityLvl > 0)) //TCE-Sunset related changes
										{
											

											MbomlevelChld[Mblevl1]=MBOMpartID;  //Separate First level parts
											Mblevl1=Mblevl1+1;

											MBOMTotalParts[TotalCnt]=MBOMpartID; //MBOM comparission Parts Set store All-MFG Modules As considered.
											TotalCnt=TotalCnt+1;

											MBOMpartModAddrs=subString(MBOMpartID,4,5);

											if (tc_strstr(infoA1BO1Exp,MBOMpartModAddrs)!=NULL || tc_strstr(infoA1BO5Exp,MBOMpartModAddrs)!=NULL) // A9Z01 A1B05 A1B01
											{
												if (BypassLoadBody > 0)
												{
													printf("\n In ERC, single address is present so bypass \n");fflush(stdout);
													continue;
												}
											}

											
											if (QuantityLvl >0)
											{
											
												MBOMParts[FrstAndSecLvlCnt]=MBOMpartID; // 27-07-23 Duplicity Checking Parts,here store the fisrt and Second Level parts and set compare with Control objects
												FrstAndSecLvlCnt	=FrstAndSecLvlCnt+1;

											}

											if ((tc_strstr(IsF3C04Exception,MBOMpartModAddrs)!=NULL) && (tc_strstr(infoF3C04PrjExp,PrjPlatform)!=NULL) ) //F3C04 and MHCV-T13
											{
												printf("\n MBOM Module Address:=%s  and Project Platform := %s",MBOMpartModAddrs,PrjPlatform);fflush(stdout);
												
												printf("\n Some Modules like F3C04 and Platform MHCV-T13 single address is present so bypass \n");fflush(stdout);
												continue;
												
											}

												
											
											//////////////////////// THis check is to check whether all parts which should get deleted from vehicle in MBOM View is deleted or not

											ITKCALL(AOM_ask_value_string(objChild_Vhcle,"item_revision_id",&revseq));  
											printf("\n MBOM Module Address:=%s  and MBOM part id := %s",MBOMpartModAddrs,MBOMpartID);fflush(stdout);
											if(tc_strstr(VehNtPrsnt01,MBOMpartModAddrs) != NULL || 
											tc_strstr(VehNtPrsnt02,MBOMpartModAddrs) != NULL || 
											tc_strstr(VehNtPrsnt03,MBOMpartModAddrs) != NULL ||
											tc_strstr(VehNtPrsnt04,MBOMpartModAddrs) != NULL ||
											tc_strstr(VehNtPrsnt05,MBOMpartModAddrs) != NULL || 
											tc_strstr(VehNtPrsnt06,MBOMpartModAddrs) != NULL || 
											tc_strstr(VehNtPrsntD1D06Exp,MBOMpartModAddrs) != NULL || 
											tc_strstr(VehNtPrsnt07,MBOMpartModAddrs) != NULL) 
											{
												//Checking Project Platform or Program

												//if (tc_strcmp(PrjPlatform,"Panel/Van") == 0 || D1D06;B5Z01;B1A02;B1B01;
												//tc_strcmp(PrjPlatform,"Pick-Up") == 0 ||
												//tc_strcmp(PrjPlatform,"LMV") == 0 ||
												//tc_strcmp(PrjPlatform,"SCV") == 0 || 
												//tc_strcmp(PrjPlatform,"ACE") == 0 ||
												//tc_strcmp(PrjPlatform,"SCV_EV") == 0) 

												//if((tc_strstr(taskNumDup,"APLU")!=NULL) || ((!nlsIsStrNull(projClassDup)) && ((nlsStrStr(infovalF9Y01,projClassDup)!=NULL)))
												//if(tc_strcmp(infoF9Y01EXP,PrjPlatform) == 0) //Panel/Van,Pick-Up,LMV,SCV,ACE,SCV_EV //

												//if(tc_strstr(infoF9Y01EXP,PrjPlatform) != NULL) //Panel/Van,Pick-Up,LMV,SCV,ACE,SCV_EV //
												printf("\n exempted case 1 : %s : %s : %s  : %s :%s \n ",VehNtPrsntD1D06Exp,MBOMpartModAddrs,VehicleDes,infoD1D06PrjExp,infoD1D06ACEPrjExp);fflush(stdout); //venkat
												if( (tc_strstr(VehNtPrsntD1D06Exp,MBOMpartModAddrs)!=NULL ) &&( (tc_strstr(VehicleDes,infoD1D06PrjExp)!=NULL)|| (tc_strstr(VehicleDes,infoD1D06ACEPrjExp)!=NULL)))
 												{
													 printf("\n  Bypass the Modules D1D06 present after Restructuring MBOM View under Vehicle and project description : %s : %s and %s \n",MBOMpartID,VehicleDes,infoD1D06PrjExp);fflush(stdout);
													continue;
													
 												}
												/*if( (tc_strstr(VehNtPrsntD1D06Exp,MBOMpartModAddrs)!=NULL ) && (tc_strstr(VehicleDes,infoD1D06ACEPrjExp)!=NULL))
 												{
													 printf("\n  Bypass ACE desription the Modules D1D06 present after Restructuring MBOM View under Vehicle and project description : %s : %s and %s \n",MBOMpartID,VehicleDes,infoD1D06PrjExp);fflush(stdout);
													continue;
													
 												}*/
													BypassProg = 0;

												if(tc_strstr(infoF9Y01EXP,PrjPlatform) != NULL) //Panel/Van,Pick-Up,LMV,SCV,ACE,SCV_EV 
												{
													printf("\n Bypassing as Program of Project Platform :%s \n", PrjPlatform);fflush(stdout);

													ExceptionFlg	=ExceptionFlg+1;

													//if (tc_strcmp(MBOMpartModAddrs,"F1A01")==0 || tc_strcmp(MBOMpartModAddrs,"F4B01")==0 || tc_strcmp(MBOMpartModAddrs,"F4A01")==0)
													if(tc_strstr(infoF1AY01EXP,MBOMpartModAddrs) != NULL)
													{
														printf("\n Bypassing as Program of Project code is and F1A01,F4B01,F4A01 : %s \n", MBOMpartModAddrs);fflush(stdout);
														BypassProg++;
													}
													
													
												}
												printf("\n Bypassing as Program of Project code is and F1A01,F4B01,F4A01 for falg : %s and %d \n", MBOMpartModAddrs,BypassProg);fflush(stdout);

												if (BypassProg == 0)		// Added by Deepti
												{	
												
													F1A01childobjMBOM[F1ACnt]=MBOMpartID;
													printf("\n Modules not present after Restructuring MBOM View under Vehicle count : %s \n",MBOMpartID);fflush(stdout);
													F1ACnt=F1ACnt +1;
												}
											}

											//printf("\n Modules not present after Restructuring MBOM View under Vehicle count :F1ACnt %d \n",F1ACnt);fflush(stdout);
											
											// [check 2] Module Should Present in after restructuring in  MBOM View
												printf("\n  Module Sholud Present under Vehicle in MBOM View %s \n", MBOMpartModAddrs);fflush(stdout);

												IsFrontRearPaintFitBdyFlag = 0;

												if(tc_strstr(FrontH2D03Axle,MBOMpartModAddrs) != NULL) //H2D03;
												{
													printf("\n MBOM H2D03 and is present\n");fflush(stdout);
													
													IsH2D03Prsnt++;
												}
												if(tc_strstr(FrontAxle,MBOMpartModAddrs) != NULL) ///H9W01;H9W02;H2D03;
												{
													printf("\n MBOM  H9W01 H2D03 and H9W02 are present\n");fflush(stdout);
													
													IsFrontAxlePrsnt++;
													IsFrontRearPaintFitBdyFlag++;
												}
												if(tc_strstr(RearAxle,MBOMpartModAddrs)!= NULL) ////H9X01;H9X02;H2B02;
												{
													printf("\n MBOM  H9X01 and H9X02 are present\n");fflush(stdout);
													IsRearAxlePrsnt++;
													IsFrontRearPaintFitBdyFlag++;
												}

												//if((tc_strstr(taskNumDup,"APLU")!=NULL) || ((!nlsIsStrNull(projClassDup)) && ((nlsStrStr(infovalF9Y01,projClassDup)!=NULL)))

												//if (tc_strstr(infoF9Y01EXP,PrjPlatform) != NULL) //27-07-2023 how to check plant name this is MBOM
												//{
													//ExceptionFlg= 1;
													
												//}
												printf("\nProjet platform Exception Flag:%d\n",ExceptionFlg);fflush(stdout);

												if (ExceptionFlg ==0)
												{
													if(tc_strstr(PaintFit,MBOMpartModAddrs) != NULL) //F9Y01
													{
														printf("\n MBOM Paint F9Y01 frame with fitment  are present\n");fflush(stdout);
													
														IsPaintFitPrsnt++;
														IsFrontRearPaintFitBdyFlag++;
													}
												}
												
												if(tc_strstr(PaintBdyShl,MBOMpartModAddrs) != NULL) //D9Y01
												{
													printf("\n  MBOM  D9Y01 Paint Body Shell are present\n");fflush(stdout);
													
													IsPaintBdyShlPrsnt++;
													IsFrontRearPaintFitBdyFlag++;

												}
												printf("\n MBOM  FrontAxle Count :%d\n",IsFrontAxlePrsnt);fflush(stdout); //H9W01;H9W02;H2D03;	Flagcnt
												printf("\n MBOM  RearAxle Count :%d\n",IsRearAxlePrsnt);fflush(stdout); //H9X01;H9X02;H2B02;	Flagcnt
												printf("\n MBOM  Paint Body Shell Count :%d\n",IsPaintBdyShlPrsnt);fflush(stdout); //D9Y01;	Flagcnt
												printf("\n MBOM  Paint frame with fitment Count :%d\n",IsPaintFitPrsnt);fflush(stdout); //F9Y01;		Flagcnt 
												printf("\n MBOM common flag :%d\n",IsFrontRearPaintFitBdyFlag);fflush(stdout); //F9Y01;		Flagcnt 

												//if((IsFrontAxlePrsnt>0)||(IsRearAxlePrsnt>0)||(IsPaintBdyShlPrsnt>0)||(IsPaintFitPrsnt>0)) 
												if (IsFrontRearPaintFitBdyFlag  > 0)
												{
													printf("\n Second level expansion Child Part\n");fflush(stdout);

													int StructChldProdPlan	= 0;
													struct	BomChldStrut	ChldStrutChld[5000];
													int ChldCnt	= 0;

													ITKCALL(Get_Part_BOM_Lvl(objChild_Vhcle,1,ClosureRule,RevisionRule,BVRInfo,ChldStrutChld,&StructChldProdPlan));

													printf("\n Second level Child Part count : %d\n",StructChldProdPlan);fflush(stdout);
													for (ChldCnt=1;ChldCnt<= StructChldProdPlan;ChldCnt++ )
													{
														
														MBOMChldpartID	 =	NULL;
														Chldparttype	 =	NULL;
														
														Chld_objs	 =	NULLTAG;
														ChldObbj_Bvr =	NULLTAG;
														char*	bl_quantity		= NULL;
														int		Quantity		= 0;
														
														Chld_objs=ChldStrutChld[ChldCnt].child_objs;
														ChldObbj_Bvr=ChldStrutChld[ChldCnt].child_objs_bvr;
														

														ITKCALL(AOM_ask_value_string(Chld_objs,"item_id",&MBOMChldpartID));
														ITKCALL(AOM_ask_value_string(Chld_objs,"t5_PartType",&Chldparttype));
														printf("\n VEHICLE Child part type and Part id:=%s:%s\n",Chldparttype,MBOMChldpartID);fflush(stdout);
														Quantity =0;
														bl_quantity =NULL;
														ITKCALL(AOM_ask_value_string(ChldObbj_Bvr,"bl_quantity",&bl_quantity));
														Quantity= atoi(bl_quantity);
														printf("\n VEHICLE Child part Quantity:=%d\n",Quantity);fflush(stdout);
														printf("\n VEHICLE Child part type  Part id and Quantity:=%s:%s :%s :%d\n",Chldparttype,MBOMChldpartID,bl_quantity,Quantity);fflush(stdout);

														if ((tc_strcmp(BOMlineparttype,"M")==0) || (tc_strcmp(BOMlineparttype,"T")==0)) //TCE-Sunset related changes
														{
															
															if (Quantity > 0)
															{
															
																MBOMParts[FrstAndSecLvlCnt]=MBOMChldpartID;
																FrstAndSecLvlCnt	=FrstAndSecLvlCnt+1;
															}

														}

													}


												}

												//if(tc_strstr(RearAxle,MBOMpartModAddrs) != NULL || 
												//tc_strstr(FrontAxle,MBOMpartModAddrs) != NULL || 
												//tc_strstr(LoadBdyFit,MBOMpartModAddrs) != NULL ||
												//tc_strstr(GearBx,MBOMpartModAddrs) != NULL ||
												//tc_strstr(Cockpit,MBOMpartModAddrs) != NULL)
												
												if(tc_strstr(AllMfgModules,MBOMpartModAddrs)!= NULL) // 27-07-23
												{

													int StructChldSkipProdPlan	= 0;
													struct	BomChldStrut	ChldStrutSkipChld[5000];

													printf("\nSkiping the PaintFit and PaintBdyShl Parts Expansion\n");fflush(stdout);

													ITKCALL(Get_Part_BOM_Lvl(objChild_Vhcle,1,ClosureRule,RevisionRule,BVRInfo,ChldStrutSkipChld,&StructChldSkipProdPlan));

													printf("\n Second level Child Part Skip count : %d\n",StructChldSkipProdPlan);fflush(stdout);
													for (MBOMSL=1;MBOMSL<=StructChldSkipProdPlan ;MBOMSL++ )
													{
														MBOMSkipChldpartID	= NULL ;
														ChldSkipparttype	= NULL ;
														Chld_objs_Skip	 =	NULLTAG;
														ChldObbj_Skip_Bvr =	NULLTAG;
														
														Chld_objs_Skip=ChldStrutSkipChld[MBOMSL].child_objs;
														ChldObbj_Skip_Bvr=ChldStrutSkipChld[MBOMSL].child_objs_bvr;

														ITKCALL(AOM_ask_value_string(Chld_objs_Skip,"item_id",&MBOMSkipChldpartID));
														ITKCALL(AOM_ask_value_string(Chld_objs_Skip,"t5_PartType",&ChldSkipparttype));
														printf("\n VEHICLE Second Child part type and Part id:=%s:%s\n",ChldSkipparttype,MBOMSkipChldpartID);fflush(stdout);
														if ((tc_strcmp(ChldSkipparttype,"M")==0) || (tc_strcmp(ChldSkipparttype,"T")==0)) //TCE-Sunset related changes
														{
															

															MBOMTotalParts[TotalCnt]=MBOMSkipChldpartID;
															TotalCnt=TotalCnt+1;

														}

													}

												}
												printf("\n Total Child Parts count : %d\n",TotalCnt);fflush(stdout);
																																												
										}
										else
										{
											 printf("\nVehicle Child Part type is : %s \n",BOMlineparttype);fflush(stdout);
										}
								   }
									//Duplicity Checking
								
									char	*MBOMPartDup			= NULL;
									char	*FrstMBOMPart			= NULL;
									char	*SendMBOMPart			= NULL;
									//char	*DuplicateSet[5000];
									char	**Duplicateparts	= NULL;
									int		FrstLvlCnt				= 0;
									int		DupCnt					= 0;
									char	*MBOMpartDupModAddrs	= NULL;
									int		kkk						= 0;
									int		indupcnt				= 0;
									int		DupSetCnt				= 0;


									Duplicateparts	= (char**)MEM_alloc( 1 * sizeof *Duplicateparts );
									//int		iiii				= 0;

									//Duplicity Checking
									printf("\nFirst and Second Level VC Child parts count : %d \n",FrstAndSecLvlCnt);fflush(stdout);
									for (kkk=0;kkk<FrstAndSecLvlCnt;kkk++ )
									{
										DupCnt			= 0;
										FrstMBOMPart=NULL;
										FrstMBOMPart=MBOMParts[kkk];  

										printf("\nFirst time VC child Part : %s\n",FrstMBOMPart);fflush(stdout);
										for (indupcnt=0;indupcnt<FrstAndSecLvlCnt;indupcnt++)
										{
											SendMBOMPart=NULL;
											SendMBOMPart=MBOMParts[indupcnt];
											printf("\ninside for compare First time VC child Part : %s\n",SendMBOMPart);fflush(stdout);
											if (tc_strcmp(FrstMBOMPart,SendMBOMPart)==0) //xyz xyz xyz
											{
												printf("\n VC Child part Present Both levels : %s \n",FrstMBOMPart);fflush(stdout);
													MBOMpartDupModAddrs=NULL;
													MBOMpartDupModAddrs=subString(SendMBOMPart,4,5);	

													printf("\nBefore Duplicity check Child Address and Child part id :%s  and  %s : %s\n",MBOMpartDupModAddrs,SendMBOMPart,FrstMBOMPart);fflush(stdout);
													if(tc_strstr(VehDupAdd01,MBOMpartDupModAddrs) != NULL || 
													tc_strstr(VehDupAdd02,MBOMpartDupModAddrs) != NULL || 
													tc_strstr(VehDupAdd03,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd04,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd05,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd06,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd07,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd08,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd09,MBOMpartDupModAddrs) != NULL ||
													tc_strstr(VehDupAdd10,MBOMpartDupModAddrs) !=NULL)
													{
														DupCnt=DupCnt+1;
														if(DupCnt>1)
														{
															//Duplicateparts[DupSetCnt]=FrstMBOMPart;
															//DupSetCnt=DupSetCnt+1;
															//printf("\n add part Duuplicity allowed \n");fflush(stdout);
															//break;

															if(setFindStr1(&DupSetCnt,&Duplicateparts,FrstMBOMPart)==-1)
															{
																setAddStrFuction(&DupSetCnt,&Duplicateparts,FrstMBOMPart);
																printf("\n   module [%s] added directly11 \n",FrstMBOMPart);fflush(stdout);
														    }
															else
															{
																printf("\n module [%s] already exists in set \n",FrstMBOMPart);fflush(stdout);

															}

														
														}
														//printf("\nDuuplicity allowed \n");fflush(stdout);
														//printf("\nDuuplicity allowed11 \n");fflush(stdout);
													
													}
												

											}
											printf("\n VC Child parts Duplicity set count : %d \n",DupSetCnt);fflush(stdout);


										}
									}
									printf("\n Out side of loop Orginal VCDuplicate Parts Count DupSetCnt: %d \n",DupSetCnt);fflush(stdout);
									
									
									printf("\n after resize the  VCDuplicate Parts  DupSetCnt count: %d \n",DupSetCnt);fflush(stdout);

									/**ERC EXPANSION**/
									int StructErcChldProdPlan	 =0;
									struct	BomChldStrut	ChldStrutERCChld[5000];
									ERCFrstLvlCnt	= 0;

									//ITKCALL(Get_Part_BOM_Lvl(vcpart,1,"BOMViewClosureRuleERC","ERC release and above","View",ChldStrutERCChld,&StructErcChldProdPlan));
									ITKCALL(Get_Part_BOM_Lvl(vcpart,1,ERCClosureRule,ERCRevisionRule,"View",ChldStrutERCChld,&StructErcChldProdPlan));

										printf("\nEBOM VC Childs parts Count: %d \n",StructErcChldProdPlan);fflush(stdout);
										for (ERCc=1; ERCc <= StructErcChldProdPlan;ERCc++)
										{

											ERCChldpartID	= NULL ;
											ERCparttype		= NULL ;
											Chld_objs_ERC	 =	NULLTAG;
											ChldObbj_ERC_Bvr =	NULLTAG;
														
											Chld_objs_ERC=ChldStrutERCChld[ERCc].child_objs;
											ChldObbj_ERC_Bvr=ChldStrutERCChld[ERCc].child_objs_bvr;

											ITKCALL(AOM_ask_value_string(Chld_objs_ERC,"item_id",&ERCChldpartID));
											ITKCALL(AOM_ask_value_string(Chld_objs_ERC,"t5_PartType",&ERCparttype));
											printf("\n VEHICLE Second Child part type and Part id:=%s:%s\n",ERCparttype,ERCChldpartID);fflush(stdout);
											if ((tc_strcmp(ERCparttype,"M")==0) || (tc_strcmp(ERCparttype,"T")==0)) //TCE-Sunset related changes
											{
												ERCParts[ERCFrstLvlCnt]=ERCChldpartID;
												ERCFrstLvlCnt	=ERCFrstLvlCnt+1;
											}


										}
										printf("\nEBOM VC Childs parts type Modules count : %d \n",ERCFrstLvlCnt);fflush(stdout);


										//EBOM V/S MBOM
										char *ERCPartDup	= NULL;
										char *MBOMTotalPartsDup	= NULL;
										int		EBOMFLCnt	= 0;
										int		EBOMPartNtPrsentCnt	= 0;
										int		NtPrsnt	= 0;
										int		MBOMCnt	= 0;
										printf("\nEBOM V/S MBOM VC Childs Total count : %d \n",TotalCnt);fflush(stdout);
										printf("\nEBOM V/S MBOM VC Childs ERC Parts count : %d \n",ERCFrstLvlCnt);fflush(stdout);

										if (ERCFrstLvlCnt>0)
										{
											for (EBOMFLCnt=0;EBOMFLCnt<ERCFrstLvlCnt ;EBOMFLCnt++ )
											{
												ERCPartDup	= NULL;
												EBOMPartNtPrsentCnt = 0;
												

												ERCPartDup=ERCParts[EBOMFLCnt];
												printf("\nEBOM Dup part id : %s \n",ERCPartDup);fflush(stdout);
												for (MBOMCnt=0;MBOMCnt<TotalCnt ;MBOMCnt++ )
												{
													MBOMTotalPartsDup	= NULL;
													MBOMTotalPartsDup=MBOMTotalParts[MBOMCnt];
													printf("\n MBOM Dup part id : %s \n",MBOMTotalPartsDup);fflush(stdout);
													if(tc_strcmp(ERCPartDup,MBOMTotalPartsDup)==0)
													{	
														printf("\n Part is in both EBOM and MBOM View : %s and %s\n",ERCPartDup,MBOMTotalPartsDup);fflush(stdout);
														EBOMPartNtPrsentCnt	=EBOMPartNtPrsentCnt+1;
														break;
													}
												}
												if (EBOMPartNtPrsentCnt==0)
												{
													EBOMNtPrsentpart[NtPrsnt]=ERCPartDup;
													NtPrsnt	= NtPrsnt+1;
												}
											}
										}
										printf("\nEBOM Parts not present Count : %d \n",NtPrsnt);fflush(stdout);

										//MBOM V/S EBOM
										int	MBOMFLCnt	= 0;
										int	NtPrsntMC	= 0;
										int	MBOMPartNtPrsentCnt	= 0;
										int	EMBOMCnt	= 0;

										printf("\n MBOM V/S EBOM VC Childs Total count : %d \n",TotalCnt);fflush(stdout);
										printf("\n MBOM V/S EBOM VC Childs ERC Parts count : %d \n",ERCFrstLvlCnt);fflush(stdout);

										if (TotalCnt>0)
										{
											for (MBOMFLCnt=0;MBOMFLCnt<TotalCnt ;MBOMFLCnt++ )
											{
												MBOMTotalPartsDup	= NULL;
												MBOMPartNtPrsentCnt	= 0;

												MBOMTotalPartsDup=MBOMTotalParts[MBOMFLCnt];
												printf("\nMBOM Dup part id : %s \n",ERCPartDup);fflush(stdout);
												for (EMBOMCnt=0;EMBOMCnt<ERCFrstLvlCnt ;EMBOMCnt++ )
												{
													ERCPartDup	= NULL;
													
													ERCPartDup=ERCParts[EMBOMCnt];
													printf("\nEBOM Dup part id : %s \n",MBOMTotalPartsDup);fflush(stdout);
													if (tc_strcmp(ERCPartDup,MBOMTotalPartsDup)==0)
													{
														printf("\n MBOM Part is in both EBOM and EBOM View : %s and %s\n",ERCPartDup,MBOMTotalPartsDup);fflush(stdout);
														MBOMPartNtPrsentCnt	=MBOMPartNtPrsentCnt+1;
														break;
													}
												}
												if (MBOMPartNtPrsentCnt==0)
												{
													MBOMNtPrsentpart[NtPrsntMC]=MBOMTotalPartsDup;
													NtPrsntMC = NtPrsntMC+1;
												}
											}
										}
											printf("\nMBOM Parts not present Count : %d\n",NtPrsntMC);fflush(stdout);



								   																																																																							
								printf (" \n Report Start Here222.......... \n");fflush(stdout);	
								
								fprintf(FP_Report,"\n\n\n CHECK 1 : Modules Should NOT be present under vehicle after restructuring in MBOM VIEW");fflush(FP_Report);
								fprintf(FP_Report,"\n============================================================================");fflush(FP_Report);
								
								char* Chck1MbomAddress= NULL;

								if (F1ACnt>0)
								{
									for (InCrctPrts=0; InCrctPrts<F1ACnt; InCrctPrts++)
									{
										DuF1Ao1ChildobjMBOM=NULL;
										DuF1Ao1ChildobjMBOM=F1A01childobjMBOM[InCrctPrts];
										Chck1MbomAddress = subString(DuF1Ao1ChildobjMBOM,4,5);
										printf(" \n  Modules Should NOT be present under vehicle after restructuring at MBOM VIEW [%s] AND %s\n",DuF1Ao1ChildobjMBOM,Chck1MbomAddress);fflush(stdout);
										if (IsH2D03Prsnt >0)
										{
											if (tc_strstr(IsF5A04Exception,Chck1MbomAddress) != NULL) //F5A04
											{
												printf(" \n  Modules F5A04 is present so skipping the module   [%s] \n",Chck1MbomAddress);fflush(stdout);
												//fprintf(" \n  Modules is F5A04 skipping  because of H2D03 present  [%s] \n",Chck1MbomAddress);fflush(stdout);
												continue;

											}
											else
											{
												fprintf(FP_Report,"\n%s\t\t",F1A01childobjMBOM[InCrctPrts]);fflush(FP_Report);
												stamptaskstatus++;
											}
										}
										else
										{
											fprintf(FP_Report,"\n%s\t\t",F1A01childobjMBOM[InCrctPrts]);fflush(FP_Report);
											stamptaskstatus++;
										}

											
									}
								}
								else
								{
									fprintf(FP_Report,"\n");fflush(FP_Report);
									fprintf(FP_Report,"No Issue");fflush(FP_Report);
								}

								///[ Check 2]
								fprintf(FP_Report,"\n\n\n CHECK 2 : Modules Should be present under vehicle after restructuring in MBOM View");fflush(FP_Report);
								fprintf(FP_Report,"\n============================================================================");fflush(FP_Report);

								 if(IsFrontAxlePrsnt == 0)
								 {
									printf("\n Part with Address H9W01 or H9W02 or H2D03(Rear Axle) Not Present \n");fflush(stdout); //H9W01/H9W02/H2D03
									fprintf(FP_Report,"\n");fflush(FP_Report);
									fprintf(FP_Report,"Part with Address H9W01 or H9W02 or H2D03(Rear Axle) Not Present");fflush(FP_Report);
									stamptaskstatus++;
								 }
								 if(IsRearAxlePrsnt == 0)
								 {
									 printf("\n Part with Address H9X01 or H9X02 or H2B02(Front Axle) Not Present \n");fflush(stdout); //H9X01/H9X02/H2B02
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"Part with Address H9X01 or H9X02 or H2B02(Front Axle) Not Present");fflush(FP_Report);
									 stamptaskstatus++;
								 }
								  if(IsPaintBdyShlPrsnt == 0)
								 {
									 printf("\nPart with Address D9Y01 (PAINTED BODY SHELL-MFG) Not Present \n");fflush(stdout);
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"Part with Address D9Y01 (PAINTED BODY SHELL-MFG) Not Present");fflush(FP_Report);
									 //stamptaskstatus++;
								 }
								 if(ExceptionFlg >0)
								 {
									 printf("\n  Checking F9Y01 (PAINTED FRAME WITH FITMENT- MFG) do not cosidered exception for project and platform  \n");fflush(stdout);
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"Do not check for Painted Frame F9Y01 Modules Exception for project's platform ");fflush(FP_Report);
									// stamptaskstatus++;
								 }
								 else
								 {
									 if (IsPaintFitPrsnt==0)
									 {
										 printf("\nPart with Address F9Y01 (PAINTED FRAME WITH FITMENT- MFG) Not Present \n");fflush(stdout);
										fprintf(FP_Report,"\n");fflush(FP_Report);
										fprintf(FP_Report,"Part with Address F9Y01 (PAINTED FRAME WITH FITMENT- MFG) Not Present");fflush(FP_Report);
									 }
								 
								 }
								
								 if((IsRearAxlePrsnt > 0 )&&(IsFrontAxlePrsnt > 0))
								 {
									  fprintf(FP_Report,"\n");fflush(FP_Report);
									  fprintf(FP_Report,"No Issue");fflush(FP_Report);
								 }
								 
								 int iii	= 0;

									//Check 3 Duplicate parts under Vehicle 
								fprintf(FP_Report,"\n\n\n CHECK 3 : Below parts are duplicated under vehicle");fflush(FP_Report); //TCE code Address printing (Parts)
								fprintf(FP_Report,"\n============================================================================");fflush(FP_Report);
								if (DupSetCnt>0)
								{
									for (iii=0;iii<DupSetCnt;iii++ )
									{
										 fprintf(FP_Report,"\n");fflush(FP_Report);
										fprintf(FP_Report,"\n%s\t\t",Duplicateparts[iii]);fflush(FP_Report);


									}

								
								}
								else
								{
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"No Issue");fflush(FP_Report);
								}

								DupSetCnt=0;

								int	ENtPrsnt	= 0;

								fprintf(FP_Report,"\n\n\n CHECK 4 : Below EBOM parts are not Present under MBOM View");fflush(FP_Report); //TCE code Address printing (Parts)
								fprintf(FP_Report,"\n============================================================================");fflush(FP_Report);
								if (NtPrsnt>0)
								{
									for (ENtPrsnt=0;ENtPrsnt<NtPrsnt;ENtPrsnt++ )
									{
										fprintf(FP_Report,"\n");fflush(FP_Report);
										fprintf(FP_Report,"\n%s\t\t",EBOMNtPrsentpart[ENtPrsnt]);fflush(FP_Report);

									}


								}
								else
								{
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"No Issue");fflush(FP_Report);
								}
								NtPrsnt	= 0;
								
								int	MBNtPrsnt	= 0;

								fprintf(FP_Report,"\n\n\n CHECK 5 : Below MBOM parts are not Present under EBOM View");fflush(FP_Report); //TCE code Address printing (Parts)
								fprintf(FP_Report,"\n============================================================================");fflush(FP_Report);
								if (NtPrsntMC>0)
								{
									for (MBNtPrsnt=0;MBNtPrsnt<NtPrsntMC;MBNtPrsnt++ )
									{
										fprintf(FP_Report,"\n");fflush(FP_Report);
										fprintf(FP_Report,"\n%s\t\t",MBOMNtPrsentpart[MBNtPrsnt]);fflush(FP_Report);

									}


								}
								else
								{
									 fprintf(FP_Report,"\n");fflush(FP_Report);
									 fprintf(FP_Report,"No Issue");fflush(FP_Report);
								}
								NtPrsntMC	= 0;
								
							}		
						}// vc part
						else
						{
							  printf("\n Part type is Empty or not vehicle\n");fflush(stdout);	
						}
					}//fclose(FP_Report);
				}// VC for loop 
				fclose(FP_Report);
				
				
				datasetItemId=(char *) MEM_alloc(100 * sizeof(char ));
				reference_nameDS= (char *) MEM_alloc(100);
				FilePath = (char *) MEM_alloc(100);					
				tag_t *SecDtTag=NULLTAG;
				
				tc_strcpy(datasetItemId,"");
				tc_strcpy(datasetItemId,MBOMReportFileName);
				//tc_strcat(datasetItemId,"_report");						
				printf("\n Before Adding Text Dataset11");fflush(stdout);


				tc_strcpy(FilePath,"");
				tc_strcpy(FilePath,File_Path);
				tc_strcat(FilePath,MBOMReportFileName);
				printf("\n File path11: %s",FilePath);fflush(stdout);
				ITKCALL(AE_find_datasettype2("Text",&tDataSetType));	
				tc_strcpy(reference_nameDS,"Text");
				printf("\n DataSet Name: %s",datasetItemId);fflush(stdout);
				printf("\n reference_nameDS Name: %s",reference_nameDS);fflush(stdout);
				printf("\n  Before dataset create1907........");fflush(stdout);
				ITKCALL(AE_find_dataset2(datasetItemId,&tDataSet));
				ITKCALL(GRM_find_relation_type("CMReferences",&tRelation));//CMReferences   TC_Attaches
				ITKCALL(GRM_list_secondary_objects_only(Taskrev,tRelation,&SDtxtCount,&SecDtTag));
				printf("\nSecondary objects count: %d\n",SDtxtCount);fflush(stdout);
				if(tRelation !=0)
				{
					printf("\n dataset Not available Hence Inside create.........");fflush(stdout);
					ITKCALL(AE_create_dataset_with_id(tDataSetType,datasetItemId,"","","",&tDataSet));
					printf("\n dataset created.........");fflush(stdout);
					ITKCALL(AE_save_myself(tDataSet));
					ITKCALL(IMF_import_file(FilePath,NULL, SS_TEXT, &file_tag, &file_descriptor));
					ITKCALL(AOM_save_with_extensions(file_tag));
					ITKCALL(AOM_lock(tDataSet));	
					printf("\n\t after AOM_save_with_extensions FIRST TIME -  \n"); fflush(stdout);
					ITKCALL(AE_add_dataset_named_ref2(tDataSet,reference_nameDS,tagRefTypeText,file_tag));
					printf("\n\t after named reference ADD \n"); fflush(stdout);											
					ITKCALL(AOM_save_with_extensions(tDataSet));
					printf("\n\t AOM_save_with_extensions Dataset \n"); fflush(stdout);
					ITKCALL(AOM_unlock(tDataSet));
					ITKCALL(GRM_create_relation(Taskrev,tDataSet,tRelation,NULLTAG,&tRlnWithDataSet));
					ITKCALL(GRM_save_relation(tRlnWithDataSet));
					ITKCALL(AOM_refresh(Taskrev,0));
					printf("\n Text file attached to task succesfully111 ");fflush(stdout);
					if(MBOMReportFileName) 
					MEM_free(MBOMReportFileName);
					if(FileLocation)
					MEM_free(FileLocation);
				}
				if(FilePath) 
				MEM_free(FilePath);
				if(datasetItemId) 
				MEM_free(datasetItemId);
				if(reference_nameDS) 
				MEM_free(reference_nameDS);
				printf("\n stamptaskstatus flag : %d \n",stamptaskstatus);fflush(stdout);
				if (stamptaskstatus==0)
				{
					ITKCALL(AOM_lock(Taskrev));
					ITKCALL(AOM_set_value_string(Taskrev,"t5_mbomAccuracyChk","PASS"));
					ITKCALL(AOM_save_with_extensions(Taskrev));
					ITKCALL(AOM_refresh(Taskrev,1));
					ITKCALL(AOM_unlock(Taskrev));	
				}
				else
				{
					ITKCALL(AOM_lock(Taskrev));
					ITKCALL(AOM_set_value_string(Taskrev,"t5_mbomAccuracyChk","FAIL"));
					ITKCALL(AOM_save_with_extensions(Taskrev));
					ITKCALL(AOM_refresh(Taskrev,1));
					ITKCALL(AOM_unlock(Taskrev));
				}
				
			} //Vc count if condition loop
			else
			{
			  printf("\n Part not Found in task ");fflush(stdout);
			}
					
		}

	}
	
	return ifail;
}

int ModularMBOMAccChk(void *return_data)
{	
	int ifail = ITK_ok;
	char 			*selectedTask		= 	NULL;
	int n_tags_found					=0;
    tag_t* tags_found 					= NULL;
	int retValueType	=0;
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	const char *attrs[1];
    const char *values[1];
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	attrs[0] ="item_id";
	values[0] = (char *)selectedTask;
	ITKCALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);

	ReportMBomModCompliance(selectedTask,n_tags_found ,tags_found);
	////////////////////////////////////

	tag_t * docn_best = (tag_t *) MEM_alloc (1 * sizeof (tag_t));
	int n_docn_best = 1;
	USERSERVICE_array_t arrayStruct;
	docn_best=NULLTAG;

	ifail = USERSERVICE_return_tag_array(docn_best, n_docn_best, &arrayStruct);
	printf("\nModular Bom returning Value=%d",arrayStruct.length);fflush(stdout);

	if (arrayStruct.length != 0)
	{
	*((USERSERVICE_array_t*) return_data) = arrayStruct;	
	}

	printf("\nModular Bom  After returning Value*******");fflush(stdout);
	

	return ifail;
}

extern int tm_ModularMBomAccuracyChkcalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 1;
	int retValueType;
	int inputArgTypes[1] = {0};

	inputArgTypes[0] = USERARG_STRING_TYPE; //Selected Task

		
	//retValueType = USERARG_STRING_TYPE ;
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n tm_ModularBomAccuracyChkcalling before....ModularMBOMAccChk");fflush(stdout);  
	ifail=USERSERVICE_register_method("ModularMBOMAccChk",(USER_function_t)ModularMBOMAccChk,nargs,inputArgTypes,retValueType);
	
	
	return ifail;
}

extern DLLAPI int tm_ModularBomComplianceChk_register_callbacks ()
{	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ModularBomComplianceChk");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_ModularBomComplianceChk", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ModularMBomAccuracyChkcalling);
	printf("\n After registering userservice....tm_ModularBomComplianceChk");fflush(stdout);
	return(ITK_ok);
}