/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_DVAcalculations.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for DVA calculation of VC.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   2023-07-24 15:33:16
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Anvesh Bujule					    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>



int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}



//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}


char* DVACalulate()
{
	char* ptr = NULL;
	float percentage;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);



	printf("\n\n DVACalulate--DFQApplcbltyCnt: [%d]  PDFAttachedCnt: [%d]  DFQMeetExpNoCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);


	if ((DFQApplCntflag != 0)&&(DFQpdfCount != 0))
	{

		percentage = (float)(MeetexpectationCnt) / DFQApplCntflag * 100.0;

		printf("\n  after calculation: Percentage = %.2f%%", percentage); fflush(stdout);
		sprintf(ptr,"%10lf",percentage);


		if(DFQApplCntflag>0)
		{
			DFQApplCntflag=0;
		}

		if(falseflagg>0)
		{
			falseflagg =0;
		}

		if(DFQpdfCount>0)
		{
			DFQpdfCount=0;
		}

		if(DFQexcelsCount>0)
		{
			DFQexcelsCount=0;
		}

		if(MeetexpectationCnt>0)
		{
			MeetexpectationCnt=0;
		}

		printf("\n\n DVACalulate--DFQApplcbltyCnt4: [%d]  PDFAttachedCnt4: [%d]  DFQMeetExpNoCnt4: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);



		printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}



char* GetDemeritScoreRating(char* DvloName , int DemeritScore)
{
	char* ptr = NULL;
	int dvr=0;


	ptr = (char *) MEM_alloc(sizeof(char)* 30);

      if (DvloName!=NULL)
	 {
		printf("\n  DvloName: %s   DemeritScore: %d",DvloName,DemeritScore);fflush(stdout);

		if (DemeritScore<=100)
		{
			dvr=100;
			printf("\n dvr value is 100*:%d",dvr);fflush(stdout);
		}
		else if( (DemeritScore<=130) && (DemeritScore>100))
		{
			dvr=80;
			printf("\n dvr value is 80*:%d",dvr);fflush(stdout);
		}
		else if (DemeritScore>130)
		{
			dvr=50;
			printf("\n dvr value is 50*:%d",dvr);fflush(stdout);
		}
		else
		{
			dvr=0;
			printf("\n dvr value is 0*:%d",dvr);fflush(stdout);
		}

		printf("\n dvr value is----:%d",dvr);fflush(stdout);
		sprintf(ptr,"%d",dvr);
		printf(" after conversion dvr: %s \n",ptr);fflush(stdout);



		return ptr;
	}
	else
	{
		return "0";
	}
}

int getBusinessUnitFunct(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

int getBusinessUnitFunc(tag_t PartTag, char** ProjbussDup,char**ProjdescDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_ProjectDescp=NULL;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);
	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_ProjectDescp);
	printf("project desc -- %s\n",t5_ProjectDescp);fflush(stdout);

	*ProjdescDup = t5_ProjectDescp;

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int GetDVAUseCaseFromLibraryt(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName=NULL;
	char* s=NULL;
	char* moduleAddressS=NULL;
	char* moduleAdd=NULL;
	char* PartNumstyp=NULL;
	char* Designgroupvalue=NULL;
	char* partNumber=NULL;  
	char* DesignGrp13=NULL;
	char* subGroup=NULL;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;
	moduleAddressS = (char *)MEM_alloc(100);


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	ITK_CALL(AOM_ask_value_string(PartTag,"bl_Design Revision_t5_PartType",&PartNumstyp));
	printf("\n DVA Calculation Part Type is  :: %s\n",PartNumstyp);fflush(stdout);


    if(tc_strcmp(PartNumstyp,"M")==0)
	{
      

	  AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ModuleAddress",&moduleAdd);
	  printf("\n DVA Calculation Module Address  :: %s\n",moduleAdd);fflush(stdout);

	  tc_strcpy(moduleAddressS,"");
	  tc_strcat(moduleAddressS,moduleAdd);
	  printf("\n DVA Calculation After cat moduleAddressS %s\n",moduleAddressS);fflush(stdout);


	}

	if(tc_strcmp(PartNumstyp,"T")==0) 
	{ 
	 //Added 12 Digits TPL Logic for Design Group Like 54 
     AOM_ask_value_string(PartTag,"bl_item_item_id",&partNumber);
	 printf("\n DVA Calculation :: Part Number = %s",partNumber);
	 if(tc_strlen(partNumber)==13 && tc_strcmp(PartNumstyp,"M")!=0)  
	 {
	   //If Part of Desgin Group Restructuring like 54
	   AOM_ask_value_string(PartTag,"t5_DesignGrp",&DesignGrp13);
       printf("\n DVA Calculation ::  Design Group = %s ",DesignGrp13);
	   subGroup = subString(partNumber,8,4);
	   tc_strcpy(moduleAddressS,"");  
	   tc_strcat(moduleAddressS,subGroup);
       printf("\n DVA Calculation After cat Design Group %s\n",moduleAddressS);fflush(stdout); 
	   //Code ended here for 54 Design Group Added by Asif
	 } 
      else
	 {
	  ITK_CALL(AOM_ask_value_string(PartTag,"bl_Design Revision_t5_DesignGrp",&Designgroupvalue));
	  printf("\n DVA Calculation Design Group  :: %s\n",Designgroupvalue);fflush(stdout);

	  tc_strcpy(moduleAddressS,"");
	  tc_strcat(moduleAddressS,Designgroupvalue);
	  printf("\n DVA Calculation After cat Design Group %s\n",moduleAddressS);fflush(stdout);
     }
	}

	queryTag = NULLTAG;
	status = QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	else
	{
      printf("Tag found query\n");fflush(stdout);
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	//qry_values1[1] = (char *)MEM_alloc(10);
	//tc_strcpy(qry_values1[1], "DFQ Use Case");

    qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	//qry_entries[1] = (char *)MEM_alloc(10);
	//strcpy(qry_entries[1], "Type");
	//strcpy(qry_entries[1], "object_type");



   printf("Name is  :: %s\n",qry_values1[0]);fflush(stdout);
  // printf("Type is  :: %s\n",qry_values1[1]);fflush(stdout);


	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}


extern int DVAcalculations(void *retValue)
{

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



     tag_t bom_wnd				=NULLTAG;
     tag_t rule					=NULLTAG;
     tag_t top_lne				=NULLTAG;
     tag_t	*ColIndChilds		=NULLTAG;
     tag_t	*dfq_use_case_tags	=NULLTAG;
     tag_t	*DVA_document_tag	=NULLTAG;
     tag_t	*refobjpdfs			=NULLTAG;
     tag_t	*refobjexcels		=NULLTAG;
     //tag_t	*GCIobj				=NULLTAG;
	 tag_t	Childobject			=NULLTAG;
	 tag_t	itemoduleTag		=NULLTAG;
	 tag_t	itemoduleTagLat		=NULLTAG;
	 tag_t	relTypeTags			=NULLTAG;
	 //tag_t	MSexcelDatatyp		=NULLTAG;

     char*VcNumber			=NULL;
     char*DFQdocnosDup		=NULL;
     char*DFQdocnos			=NULL;
     char*DFQUIDsDup		=NULL;
     char*DFQUIDs			=NULL;
     char*DVADescsDup		=NULL;
     char*DVADescs			=NULL;
	 char*VCtypeNam			=NULL;

	 char*PartRelStats		=NULL;
	 char*ProjbussDup		=NULL;
	 char*PartNumsDup		=NULL;
	 char*PartNums			=NULL;
	 char*PartNumstypDup	=NULL;
	 char*PartNumstyp		=NULL;
	 char*Meetexpectation	=NULL;
	 char*MeetexpectationDup=NULL;
	 char* documentName = NULL;

	 int i=0;
	 int count=0;
	 int ichld=0;
	 int resultCount=0;
	 int DVA_result_counts=0;
	 int nFoundpdfs=0;
	 int nFoundexcels=0;
	 //int GCIcount=0;
	 logical DFQApplicablilitycheck1= 0;

	 char	Data[100]= "";
     time_t 	now;
	 struct 	tm when;

	 char *VPrtModNum=NULL;
	 char *VPrtModNumType=NULL;
	 char *CurRe=NULL;
	 char *CurSe=NULL;
	 char *VPrtdesc=NULL;
	 char *prjcode=NULL;
	 char *prjcodeDup=NULL;
	 char *partsts=NULL;
	 char *partstsDup=NULL;
	 char *ProjdescDup = NULL;
	 FILE* file=NULL;
	 char fsuccess_nam[200];
	 char *Owner	= NULL;
	 Owner = (char *)MEM_alloc(50);
	 char *PartRevs=NULL;
	 char *PartRevsDup=NULL;
	 char *CurRevs = NULL;
	 char *CurSeqs = NULL;
	 char *ModuleAddressp=NULL;
	 char *ModuleAddresspDup=NULL;
	 char *partst=NULL;
	 char *partstDup=NULL;
	 char *descp=NULL;
	 char *descpDup=NULL;
	 char *Csvpath=NULL;
	 char *GCIDocPath=NULL;
	 GCIDocPath = (char *)MEM_alloc(200);
	 Csvpath = (char *)MEM_alloc(200);
	 char* Owners	= NULL;
	 Owners = (char *)MEM_alloc(50);

	 int d=0;
	 char* PrerevDRstat	 = NULL;
	 PrerevDRstat	=	(char	*)MEM_alloc(10);
	 ModuleAddresspDup	=	(char	*)MEM_alloc(100);
	 char* DFQComments = NULL;
	 char* DFQCommentsDup	= NULL;
	 char* MeetexpectationDupMM	=NULL;
	 char* Foundpdfs		= NULL;
	 char* Foundexcels	= NULL;
	 char* DFQApplicablilitysDup=NULL;
	 //AE_reference_type_t MSrefType=1;
	 //tag_t file_tag1 = NULLTAG;
	 //IMF_file_t file_descriptor1;
	 //int j=0;
	 PIE_scope_t scope;
	 scope=PIE_TEAMCENTER;
	int rulefound= 0;
	tag_t *closurerule = NULLTAG;
	tag_t *GciObj = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t bom_variant_rule = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
    char* type_name =NULL;
	tag_t e_block		= NULLTAG;
	char **rulename = NULL;
	char **rulevalue = NULL;
	//FILE *file;
	double Designnominal;
	double Definedtarget;
	double Achievednominal;
	double Achievedtarget;
	double CpkDup;
	int GCI=0;
	int Demerit_rating=0;
	int Demerit=0;
	double GCIind;
	int gc=0;

	  double dVA;
	  char*	strDVA		=NULL;
	  char*	foldername	=NULL;
	  char*	objecttype5	=NULL;
	  char*	objecttype4	=NULL;
	  char*	designgroup	=NULL;

	  FL_sort_criteria_t flcriteria;
	  int refcount=0;
	  tag_t *reflist = NULLTAG;
	  tag_t file_tag = NULLTAG;
	  tag_t reflist2 = NULLTAG;
	  tag_t DVAfoldertag = NULLTAG;
	  IMF_file_t file_descriptor;

	  int f =0;
	  int DVAreportflag1 =0;

     int ifail = ITK_ok;

	 //char*VcNumber	 = NULL;
	 //char*VCtypeNam	 = NULL;
	 tag_t DitemTAG = NULLTAG;
	 tag_t DVAfoldertypetag = NULLTAG;
	 tag_t DitemRevTAG = NULLTAG;
	 tag_t homefoldertag = NULLTAG;
	 tag_t object_create_input_tag3 = NULLTAG;
	 tag_t object_create_input_tag4 = NULLTAG;
	 char* username = NULL;
	 tag_t user_tag=NULLTAG;
	 tag_t type_tag3=NULLTAG;
	 tag_t DatasetType=NULLTAG;
	 tag_t dad_tag=NULLTAG;
	 tag_t GCI_relation=NULLTAG;
	 tag_t GCItag=NULLTAG;

	 char *output	 = NULL;

	 char		*Vehicleid 		= NULL;
     USERARG_get_string_argument(&Vehicleid);


			ITEM_find_item(Vehicleid,&DitemTAG);
			ITEM_ask_latest_rev(DitemTAG, &DitemRevTAG);

			time(&now);
			when = *localtime(&now);
			strftime(Data,100,"%Y_%b_%d_%H_%M_%S",&when);


			AOM_ask_value_string(DitemRevTAG,"item_id",&VcNumber);
			printf("Item ID* :: %s\n",VcNumber);fflush(stdout);

			AOM_ask_value_string(DitemRevTAG,"t5_PartType",&VCtypeNam);
			printf("Item ID type* :: %s\n",VCtypeNam);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_id",&VPrtModNum));

			ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_revision_id",&VPrtModNumType));
			printf("\nV number is [%s]\n",VPrtModNum); fflush(stdout);

			CurRe = strtok(VPrtModNumType,";");
			CurSe = strtok(NULL,";");

			ITK_CALL(AOM_ask_value_string(DitemRevTAG,"object_desc",&VPrtdesc));

			ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_ProjectCode",&prjcode));
			tc_strdup(prjcode,&prjcodeDup);

			ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_PartStatus",&partsts));
			tc_strdup(partsts,&partstsDup);

			ITK_CALL(getBusinessUnitFunc(DitemRevTAG, &ProjbussDup,&ProjdescDup));
			//printf("\n t5_BussUnitType :[%s] [%s]\n",ProjbussDup,ProjdescDup);   fflush(stdout);



			ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path",0,&GCIDocPath));
			printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);

			ITK_CALL(POM_get_user(&username,&user_tag));
			printf("\n\n username :%s\n",username);fflush(stdout);

			ITK_CALL(SA_ask_user_home_folder(user_tag,&homefoldertag));

			ITK_CALL(FL_ask_sort_criteria(homefoldertag,&flcriteria));
			documentName = NULL;
			documentName = (char *)MEM_alloc(50);

			//tc_strcpy(documentName, "");
			tc_strcpy(documentName, "DVA_Index_");
			tc_strcat(documentName, VPrtModNum);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, CurRe);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, CurSe);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, Data);

			ITK_CALL(FL_ask_references(homefoldertag,flcriteria,&refcount,&reflist));
			printf("\n the refrence count is*** :[%d]\n",refcount);   fflush(stdout);

		   int DVAreportflag=0;

			for(f=0;f<refcount;f++)
			{
				reflist2=reflist[f];

				ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

				if(tc_strcmp(foldername,"DVA Reports")==0)
				{

					printf("\n\n Folder is already available\n");fflush(stdout);

				   /*ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
				   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
				   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
				   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
				   ITK_CALL(AOM_save_with_extensions(dad_tag));

				   ITK_CALL(AOM_lock(dad_tag));


				   ITK_CALL(FL_insert(reflist2,dad_tag,000));
				   ITK_CALL(AOM_save_with_extensions(reflist2));


				   ITK_CALL(AOM_refresh(dad_tag, TRUE));

				   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

				   ITK_CALL(AE_save_myself(dad_tag));*/

				   DVAreportflag++;


				  //ITK_CALL(FL_insert(reflist2,file_tag,999));

				}
				else
				{
					//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

				}

			}

		
	         //printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);

  
			  if(DVAreportflag==0)
			  {
				  printf("\n\n INside folder creation condition :%s\n");fflush(stdout);

				ITK_CALL(TCTYPE_find_type( "Folder",NULL, &DVAfoldertypetag));
				ITK_CALL(TCTYPE_construct_create_input(DVAfoldertypetag, &object_create_input_tag3));
				ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name","DVA Reports"));

				ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&DVAfoldertag));

				ITK_CALL(AOM_save_with_extensions(DVAfoldertag));

				ITK_CALL(FL_insert(homefoldertag,DVAfoldertag,999));
				ITK_CALL(AOM_save_with_extensions(homefoldertag));

				  //(FL_insert(reflist2,file_tag,999))
			  }


				if(tc_strcmp(VCtypeNam,"V")== 0)
			   {

                tc_strcpy(Csvpath,"");
                tc_strcpy(Csvpath,GCIDocPath);
                sprintf(fsuccess_nam,"DVA_Index_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,Data);
				tc_strcat(Csvpath,fsuccess_nam);
                printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);
				file = fopen(Csvpath,"w");

				if(file!=NULL)
			    {
				printf("\n file is opening\n");   fflush(stdout);
			    }
			    else
			    {
				   printf("\n file is not opening\n");   fflush(stdout);
			    }

				ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

				ITK_CALL(GRM_list_secondary_objects_only(DitemRevTAG,GCI_relation,&GCI,&GciObj));

				if(GCI>0)
				{
						for(gc=0;gc<GCI;gc++)
						{
						printf("\n inside for loop gc count****.\n");fflush(stdout);

						GCItag=GciObj[gc];

						ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
						printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);


						ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
						printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

						ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
						printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
						}
				}

				fprintf(file,",,,,DVA Index Report VC Wise,,date-%s,,,,,,\n",Data);
				fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
				fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
				fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
				fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
				fprintf(file,",,,Last Updated,,,,,,,\n");
				fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
				fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                
				fprintf(file,"\n\n");

				if(Demerit)
				 {
					fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
				 }
				 else{
					 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
				 }
				 if(Demerit_rating)
				{
				  fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
				}
				 else
				{	
				 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
				}
				if(GCIind)
				{
				  fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
				}
				else{

				 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
				}
				 fprintf(file,"\n\n");
				fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");

			   	          if(DitemRevTAG!=NULLTAG)
				          {
						                    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL( BOM_set_window_top_line( bom_wnd, NULLTAG, DitemRevTAG, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
		                                    ITKCALL(CFM_find("ERC Review And Above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);

					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));


					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

											/*ITK_CALL ( BOM_window_ask_variant_rule( bom_wnd, &bom_variant_rule ));
					                        printf( " vc_release BOM_window_ask_variant_rule..\n");fflush(stdout);


											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
					                        ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));*/


											ITK_CALL ( ITEM_ask_rev_variants ( DitemRevTAG, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);

                                      if(top_lne!=NULLTAG)
					                  {

                                        //ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));


									   // ITK_CALL(BOM_window_hide_unconfigured(bom_wnd));
						               // ITK_CALL(BOM_window_show_variants(bom_wnd));

									    printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						               // ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&DitemRevTAG))   ;
						                printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);


                                        //ITK_CALL(BOM_window_hide_variants(bom_wnd));

						                ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));


						               printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);

						    if(count >0)
						    {

						    for (ichld=0;ichld<count ;ichld++ )
						    {

							if(Childobject)Childobject=NULLTAG;
							Childobject=ColIndChilds[ichld];

                            ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
							tc_strdup(PartNums,&PartNumsDup);
							printf("\nPart number is [%s]",PartNumsDup); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
							tc_strdup(PartNumstyp,&PartNumstypDup);
							printf("\nPart number type222 [%s]",PartNumstyp); fflush(stdout);

							 if(tc_strcmp(PartNumstyp,"M")==0)
							 {

								 ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
							     //tc_strdup(ModuleAddressp,&ModuleAddresspDup);
								 printf("\n DVA Calculation Part number revision [%s]",ModuleAddressp); fflush(stdout);

								 tc_strcpy(ModuleAddresspDup,"");
							     tc_strcat(ModuleAddresspDup,ModuleAddressp);

								 printf("\n After Cat DVA Calculation ModuleAddressp[%s]",ModuleAddressp); fflush(stdout);
							 }

							 if(tc_strcmp(PartNumstyp,"T")==0)
							 {
							     

							   ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_DesignGrp",&designgroup));
							    printf("\n DVA Calculation Module DesignGrp [%s]",designgroup); fflush(stdout);
							  
							   tc_strcpy(ModuleAddresspDup,"");
							   tc_strcat(ModuleAddresspDup,designgroup);
							   printf("\n After cat DVA CalculationModule designgroup [%s]",ModuleAddresspDup); fflush(stdout);
							 
							 }

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
							tc_strdup(PartRevs,&PartRevsDup);
							printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

							 CurRevs = strtok(PartRevsDup,";");
							 CurSeqs = strtok(NULL,";");

							

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
							tc_strdup(partst,&partstDup);

							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
							tc_strdup(descp,&descpDup);
							STRNG_replace_str(descpDup,","," ",&descpDup);


							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                            printf("\nPart release is [%s]",PartRelStats); fflush(stdout);


							if(tc_strstr(PartRelStats,"ERC Released")!=NULL)
							{
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							}

								if(tc_strcmp(PartNumstyp,"M")==0 || tc_strcmp(PartNumstyp,"T")==0)
							    {

								printf("\nInside If condition of Part type match"); fflush(stdout);

								 tag_t itemRevTagm1 = NULLTAG;

								ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));            //getting business unit according to project code
								printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

								ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));//check no. of use cases for BUS unit
								printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

								ITEM_find_item(PartNums, &itemoduleTag);
								printf("\n checking : [%s]\n",PartRevs);fflush(stdout);
								//ITEM_find_revision(itemoduleTag,PartRevs,&itemRevTagm1);


								ITEM_ask_latest_rev(itemoduleTag,&itemoduleTagLat);
								GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

								//Get Attached DFQ Documents
								ITK_CALL(GRM_list_secondary_objects_only(itemoduleTagLat, relTypeTags, &DVA_result_counts,&DVA_document_tag));
								printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

								    int trueflagg=0;
									int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"object_type",&objecttype5);
												printf("\n objecttype5.... [%s] ",objecttype5);

												if(tc_strcmp(objecttype5,"T5_DFQ_Document")==0)
												{
													printf("\n Inside objecttype5 condition ");

													AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

													printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

													if(DFQApplicablilitycheck1 == 1)
													{
														trueflagg++;
													}
													else
													{
														falseflagg++;
													}
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);


								if (DVA_result_counts >0)
								{
											for (i=0;i<DVA_result_counts; i++ )
											{
												AOM_ask_value_string(DVA_document_tag[i],"object_type",&objecttype4);
												printf("\n objecttype4..... [%s] ",objecttype4);

												if(tc_strcmp(objecttype4,"T5_DFQ_Document")==0)
												{
													printf("\n Inside objecttype4 condition ");

												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
												tc_strdup(DVADescs,&DVADescsDup);

												STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
												tc_strdup(DFQComments,&DFQCommentsDup);

												STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
												STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);


												if(DFQApplicablilitycheck1 == 1)
												{
													DFQApplCntflag++;
													tc_strdup("Yes",&DFQApplicablilitysDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													falseflagg++;
													tc_strdup("No",&DFQApplicablilitysDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												printf("\n nFoundpdfs [%d] ",nFoundpdfs);fflush(stdout);
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));
												printf("\n nFoundexcels [%d] ",nFoundexcels);fflush(stdout);


												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if(tc_strcmp(MeetexpectationDup,"N")==0)
												{
													   tc_strdup("No",&MeetexpectationDupMM);
												}
												if(tc_strcmp(MeetexpectationDup,"Y")==0)
												{
													   tc_strdup("Yes",&MeetexpectationDupMM);
												}
												if(tc_strcmp(MeetexpectationDup,"NA")==0)
												{
													   tc_strdup("NA",&MeetexpectationDupMM);
												}


												if(DFQApplicablilitycheck1 == 1)
												{
												if(nFoundpdfs >= 1)
												{
													DFQpdfCount++;

												if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
													{
														MeetexpectationCnt++;
													}

												}
												}
												if(nFoundexcels == 1)
												{
													DFQexcelsCount++;
												}

												if (nFoundpdfs == 0)
												{
													tc_strdup("No",&Foundpdfs);
												}else{
													tc_strdup("Yes",&Foundpdfs);
												}

												if (nFoundexcels == 0)
												{
													tc_strdup("No",&Foundexcels);
												}else{
													tc_strdup("Yes",&Foundexcels);
												}

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
												fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMM,DVADescsDup);
												}
											}
								}

								}
								else
								{
									printf("\nInside else condition of Part type not match"); fflush(stdout);


								}

						   }

						 }
					   }
				  }

      }
	   else if(tc_strcmp(VCtypeNam, "CCVC")==0)
	         {

             tag_t	*snapshotObjSet		=NULLTAG;
			 tag_t Snapshot_tag			=NULLTAG;
			 tag_t snapshotObjTypeTag	=NULLTAG;
			 tag_t item_rev_tags		=NULLTAG;
			 tag_t window				=NULLTAG;
			 tag_t top_line				=NULLTAG;
			 tag_t Childobject1			=NULLTAG;
			 tag_t ChildMobject			=NULLTAG;
			 tag_t close_tag			=NULLTAG;
	         tag_t	*closurerule		=NULLTAG;
			 tag_t	*ColIndChilds		=NULLTAG;
			 tag_t	*Modulechilds		=NULLTAG;

			 //char*snapshotObjtype_name	=NULL;
			 //char  snapshotObjtype_name[TCTYPE_name_size_c+1];
			 char*  snapshotObjtype_name= NULL;
             char*ObjName				=NULL;
	         char**rulename				=NULL;
	         char**rulevalue			=NULL;
			 char*PartNums1Dup			=NULL;
			 char*PartNums1				=NULL;
			  
             char*Item_ID_str			=NULL;
             char*objecttype			=NULL;
             char*objecttype1			=NULL;
             char*ModuleNameDup			=NULL;
             char*ModuleName			=NULL;
             char*ModuleNumstyp			=NULL;
			 char*ModuleNumstypDup		=NULL;
			 char*ModulePartRevsDup		=NULL;
			 char*ModulePartRevs		=NULL;
			 char*ModulePartRelStats	=NULL;
			 char*SSTopLineRev			=NULL;

			 double Designnominals;
			 double Definedtargets;
			 double Achievednominals;
			 double Achievedtargets;
			 double CpkDups;

			 PIE_scope_t scope;
			 scope=PIE_TEAMCENTER;

             int count1=0;
             int chld=0;
			 int snapshotCount=0;
			 int Item_ID=0;
			 int rulefound	=	0;
              //printf("inside the CCVC start**\n");fflush(stdout);
			 tc_strcpy(Csvpath,"");
             tc_strcpy(Csvpath,GCIDocPath);
			 sprintf(fsuccess_nam,"DVA_VC_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,Data);
			 tc_strcat(Csvpath,fsuccess_nam);
			 file = fopen(Csvpath,"w");
			 ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

			 ITK_CALL(GRM_list_secondary_objects_only(DitemRevTAG,GCI_relation,&GCI,&GciObj));

			if(GCI>0)
			{
				for(gc=0;gc<GCI;gc++)
						{
							printf("\n inside for loop gc count****.\n");fflush(stdout);

							GCItag=GciObj[gc];

							ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
							printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);
						   
							
							ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
							printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

							ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
							printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
						}
			}
			    
			 fprintf(file,",,,,DVA Index Report VC Wise,,date-%s,,,,,,\n",Data);
			 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
			 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
			 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
			 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
			 fprintf(file,",,,Last Updated,,,,,,,\n");
			 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
			 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
			 fprintf(file,"\n\n");

			  if(Demerit)
				 {
					fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
				 }
				 else{
					 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
				 }
				 if(Demerit_rating)
				{
				  fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
				}
				 else
				{	
				 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
				}
				if(GCIind)
				{
				  fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
				}
				else{

				 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
				}
				 fprintf(file,"\n\n");
			    
			 fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");

             //printf("inside the CCVC**\n");fflush(stdout);
		    ITK_CALL(AOM_ask_value_tags(DitemRevTAG,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
			printf("\n WTRoll::snapshotCount \n::  %d ", snapshotCount);fflush(stdout);

				if(snapshotCount>0)
				   {
					printf("inside the snapshotCount**\n");fflush(stdout);
					 Snapshot_tag = NULLTAG;
					 snapshotObjTypeTag = NULLTAG;
					 Snapshot_tag = snapshotObjSet[0];
                     //printf(" the snapshotCount**\n");fflush(stdout);
					 ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
					 ITK_CALL(TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
					 printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);

					 ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
					 printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);

					 //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			        // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                      //printf(" the snapshotCount topline**\n");fflush(stdout);
					 ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
					 ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                     printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);

                      // printf(" the snapshotCount topline1**\n");fflush(stdout);
                     ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
					 ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_set_window_pack_all (window, FALSE));
                     //printf("after top line**\n");fflush(stdout);
					
					

					ITK_CALL(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
					 printf ("\nrule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
						close_tag = closurerule[0];
						//printf ("closure rule found \n"); fflush(stdout);
					 }
					 ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
					 printf ("closure rule found applied \n"); fflush(stdout);
					// ITKCALL(BOM_set_window_pack_all (window, FALSE));
					 //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

					 //ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
					// ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));
					 //printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
					 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
					 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

					 if (count >0)
					 {

					  for (ichld=0;ichld<count ;ichld++ )
					   {
							if(Childobject1) Childobject1=NULLTAG;
							Childobject1=ColIndChilds[ichld];

							ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
							tc_strdup(PartNums1,&PartNums1Dup);
							printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);


							ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
							printf("\n module line count is***: [%d]", count1);fflush(stdout);

							if (count1 >0)
							{
							 printf("\n module line****************** count is****\n");fflush(stdout);

								for (chld=0;chld<count1 ;chld++ )
								{
									if(ChildMobject) ChildMobject=NULLTAG;
									ChildMobject=Modulechilds[chld];
									int resultCount1=0;

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);


									 if(tc_strcmp(ModuleNumstyp,"M")==0)
									 {

										ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									     //tc_strdup(ModuleAddressp,&ModuleAddresspDup);
										 printf("\n CCVC DVA Calculation Part number revision [%s]",ModuleAddressp); fflush(stdout);

										 tc_strcpy(ModuleAddresspDup,"");
										 tc_strcat(ModuleAddresspDup,ModuleAddressp);

										 printf("\n After Cat CCVC DVA Calculation ModuleAddressp[%s]",ModuleAddressp); fflush(stdout);
									 }

									 if(tc_strcmp(ModuleNumstyp,"T")==0)
									 {
										 

									   ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_DesignGrp",&designgroup));
										printf("\n DVA Calculation Module DesignGrp [%s]",designgroup); fflush(stdout);
									  
									   tc_strcpy(ModuleAddresspDup,"");
									   tc_strcat(ModuleAddresspDup,designgroup);
									   printf("\n After cat CCVC DVA CalculationModule designgroup [%s]",ModuleAddresspDup); fflush(stdout);
									 
									 }

									
									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
									printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									 CurRevs = strtok(ModulePartRevsDup,";");
									 CurSeqs = strtok(NULL,";");

									

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									if(tc_strstr(ModulePartRelStats,"ERC Released")!=NULL)
							        {
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							        }

									if(tc_strcmp(ModuleNumstypDup,"M")==0 || tc_strcmp(ModuleNumstypDup,"T")==0)
									{
										  tag_t itemTagm	= NULLTAG;
										  tag_t itemRevTagm = NULLTAG;

										  ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										  printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);fflush(stdout);
										     
										  ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										  printf("\n No of Use cases Mapped :[%d]\n",resultCount1);fflush(stdout);
										     
										  //Get DFQ Document Relation Class Type
										  
										  ITEM_find_item(ModuleName, &itemTagm);
										  ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										  printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);fflush(stdout);
										  //ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										     
										  GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
										     
										  //Get Attached DFQ Documents
										  ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										  printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflagg=0;
									      int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"object_type",&objecttype);

											   if(tc_strcmp(objecttype,"T5_DFQ_Document")==0)
											   {
													AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

													 printf("\n DVA object type is [%s] ",objecttype);

													printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

													if(DFQApplicablilitycheck1 == 1)
													{
														trueflagg++;
													}
													else
													{
														falseflagg++;
													}

											  }
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount1,falseflagg,trueflagg);


										  if (DVA_result_counts >0)
										  {
											  for (i=0;i<DVA_result_counts; i++ )
											  {
												  AOM_ask_value_string(DVA_document_tag[i],"object_type",&objecttype1);

												  printf("\n DVA object type1 is [%s] ",objecttype1);

											    if(tc_strcmp(objecttype1,"T5_DFQ_Document")==0)
											   {

												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
												tc_strdup(DVADescs,&DVADescsDup);

												STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										        tc_strdup(DFQComments,&DFQCommentsDup);

										        STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										        STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												if(DFQApplicablilitycheck1 == 1)
												{
													DFQApplCntflag++;
													tc_strdup("Yes",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													falseflagg++;
													tc_strdup("No",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);

												}

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												printf("\n nFoundpdfs 1 [%d] ",nFoundpdfs);fflush(stdout);
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));
												printf("\n nFoundexcels 1 [%d] ",nFoundexcels);fflush(stdout);



												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQDesNom",&Designnominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DNDefTarget",&Definedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQAchNom",&Achievednominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_ANDefTarget",&Achievedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQCpkVal",&CpkDups));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										        tc_strdup(Meetexpectation,&MeetexpectationDup);
										        printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);
										        
										        if(tc_strcmp(MeetexpectationDup,"N")==0)
										        {
                                                       tc_strdup("No",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"Y")==0)
										        {
                                                       tc_strdup("Yes",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"NA")==0)
										        {
                                                       tc_strdup("NA",&MeetexpectationDupMM);
										        }

												if(DFQApplicablilitycheck1 == 1)
												{
												if(nFoundpdfs >= 1)
												{
													DFQpdfCount++;

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
												{
													MeetexpectationCnt++;
												}

												}
												}
												if(nFoundexcels == 1)
												{
													DFQexcelsCount++;
												}

												if (nFoundpdfs == 0)
										        {
											     tc_strdup("No",&Foundpdfs);
										        }else{
											       tc_strdup("Yes",&Foundpdfs);
										        }

										       if (nFoundexcels == 0)
										      {
												tc_strdup("No",&Foundexcels);
										      }
											  else
											  {
												tc_strdup("Yes",&Foundexcels);
										      }

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
												fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupMM,DVADescsDup);


											  }
											}
										}

									}
								}


							}

						}

					}

					}

			 }
			else
			{
				printf("\n this is not V/CCVC part \n");fflush(stdout);

			}
			


        
         printf("\n\n DFQApplCntflag1*****: [%d]  DFQpdfCount1*******: [%d]  MeetexpectationCnt1*****: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);

         strDVA=DVACalulate();

		 printf("\n strDVA= [%s] \n", strDVA);fflush(stdout);
		///* file = fopen(Csvpath,"w");
         fprintf(file,"\n\nThe Current DVA Value is,%s\n",strDVA);
		 fclose(file);
		// fclose(file);*/


		 //dVA=strtod(strDVA,NULL);
		 //printf("\n dVA: %lf ",dVA);fflush(stdout);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //tc_strcpy(output,"");
	//IMPLstrcat(output,VCtypeNam);

	

	  *((char **) retValue) = (char *) MEM_alloc( (strlen(strDVA) + 1) * sizeof(char));
      strcpy( *((char **) retValue), strDVA);


 		if(DFQApplCntflag>0)
		{
			DFQApplCntflag=0;
		}

		if(falseflagg>0)
		{
			falseflagg =0;
		}

		if(DFQpdfCount>0)
		{
			DFQpdfCount=0;
		}

		if(DFQexcelsCount>0)
		{
			DFQexcelsCount=0;
		}

		if(MeetexpectationCnt>0)
		{
			MeetexpectationCnt=0;
		}

		for(f=0;f<refcount;f++)
		{
			reflist2=reflist[f];

			ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

			if(tc_strcmp(foldername,"DVA Reports")==0)
			{

				printf("\n\n Folder is already created condition\n");fflush(stdout);

			   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
			   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
			   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
			   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
			   ITK_CALL(AOM_save_with_extensions(dad_tag));

			   //ITK_CALL(AOM_lock(dad_tag));
			   
               printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);
			   ITK_CALL(AOM_refresh(dad_tag, TRUE));

			   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

			   printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);

			   ITK_CALL(AE_save_myself(dad_tag));

			   printf("\n\n inside DVA Reports condition5454545454545488888888 :\n");fflush(stdout);

			   ITK_CALL(FL_insert(reflist2,dad_tag,000));
			   ITK_CALL(AOM_save_with_extensions(reflist2));
			   printf("\n\n inside DVA Reports condition545454545454545566 :\n");fflush(stdout);

			    DVAreportflag1 =1;


			  //ITK_CALL(FL_insert(reflist2,file_tag,999));

			}
			else
			{
				//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

			}

		}

	  if(DVAreportflag1 == 0)
	  {
		   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
		   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
		   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
		   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
		   ITK_CALL(AOM_save_with_extensions(dad_tag));

		   //ITK_CALL(AOM_lock(dad_tag));
		   //ITK_CALL(FL_insert(homefoldertag,dad_tag,000));
		    printf("\n\n inside dataset attach condition 2222222222222:\n");fflush(stdout);



		   ITK_CALL(AOM_refresh(dad_tag, TRUE));

		   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

		  // ITK_CALL(AE_save_myself(dad_tag)); 
		   ITK_CALL(AOM_save_with_extensions(dad_tag)); 

		   printf("\n\n inside dataset attach condition54545454545454 :\n");fflush(stdout);

		   ITK_CALL(FL_insert(DVAfoldertag,dad_tag,000));
		   ITK_CALL(AOM_save_with_extensions(DVAfoldertag));

		   printf("\n\n inside dataset attach condition :\n");fflush(stdout);

		   
       }
		 
           printf("\n\nThe value of DVAreportflag is %d\n",DVAreportflag1);fflush(stdout);
		   printf("\n\n DFQApplCntflag2*****: [%d]  DFQpdfCount2*******: [%d]  MeetexpectationCnt2*****: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);


		  printf("\n\n END of DVA code111111111111111112222224444422222\n");fflush(stdout);



	return ifail;
}


int DVAcalculations1()
{
	/*int ifail = ITK_ok;
    char*Vehicleid =NULL;
    char*VCTname =NULL;

	USERARG_get_string_argument(&Vehicleid);
    DVAcalculations1(Vehicleid,&VCTname);

	printf("VCTname:%s........\n",VCTname);
	*((char **) return_data) = (char *) MEM_alloc( (strlen(VCTname) + 1) * sizeof(char));
    strcpy( *((char **) return_data), VCTname);

	  printf("VCTname* :: %s\n",VCTname);fflush(stdout);

	printf("\n Inside the DVA fun111111111...............");fflush(stdout);
	return ifail;*/




	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS;

	int inputArgTypes[1] = {0};
	int retValueType;
	inputArgTypes[0] = USERARG_STRING_TYPE;
	int nargs = 1;


    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("DVAcalculations",(USER_function_t)DVAcalculations,nargs,inputArgTypes,retValueType);


return ifail;

}

extern int tm_DVAcalculationscalling(int *decision, va_list args)
{
	/*int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	int inputArgTypes[1] = {0};
	int retValueType;
	inputArgTypes[0] = USERARG_STRING_TYPE;
	int nargs = 1;
    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("DVAcalculations",(USER_function_t)DVAcalculations,nargs,inputArgTypes,retValueType);*/

	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	DVAcalculations1();

	return ifail;


}


extern DLLAPI int tm_DVAcalculations_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_DVAcalculations");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_DVAcalculations", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_DVAcalculationscalling);
	printf("\n After registering userservice....tm_DVAcalculations");fflush(stdout);
	return(ITK_ok);
}


