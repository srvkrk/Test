
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}




int MPPStnBOMRptFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;

    char*                  MPPPartNum = NULL;
    char*                  MPPPartRev = NULL;
    char*                  MPPPartSeq = NULL;
    char*                  PlantBOP = NULL;
    char*                  PlantBOPRev = NULL;
    char*                  PlantBOPSeq = NULL;
    char*                  PlantValue = NULL;
    char*                  RevRule = NULL;
    char*                  PlantView = NULL;
    char*                  UsrNmee = NULL;
    
    USERARG_get_string_argument(&MPPPartNum);
    USERARG_get_string_argument(&MPPPartRev);
    USERARG_get_string_argument(&MPPPartSeq);
    USERARG_get_string_argument(&PlantBOP);
    USERARG_get_string_argument(&PlantBOPRev);
    USERARG_get_string_argument(&PlantBOPSeq);
    USERARG_get_string_argument(&PlantValue);
    USERARG_get_string_argument(&PlantView);
    USERARG_get_string_argument(&RevRule);
    USERARG_get_string_argument(&UsrNmee);
    
    printf("\n MPPPartNum :: %s ",MPPPartNum);fflush(stdout);
    printf("\n MPPPartRev :: %s ",MPPPartRev);fflush(stdout);
    printf("\n MPPPartSeq :: %s ",MPPPartSeq);fflush(stdout);
    printf("\n PlantBOP :: %s ",PlantBOP);fflush(stdout);
    printf("\n PlantBOPRev :: %s ",PlantBOPRev);fflush(stdout);
    printf("\n PlantBOPSeq :: %s ",PlantBOPSeq);fflush(stdout);
    printf("\n PlantValue :: %s ",PlantValue);fflush(stdout);
    printf("\n PlantView :: %s ",PlantView);fflush(stdout);
    printf("\n RevRule :: %s ",RevRule);fflush(stdout);
    printf("\n UsrNmee :: %s ",UsrNmee);fflush(stdout);
   
	char*                  LineItem = NULL;
	LineItem	             =(char *) MEM_alloc(1000);
	strcpy(LineItem,"/user/cvprod/shells/STD/MPPStnBOM.sh");
	strcat(LineItem," ");
	strcat(LineItem,MPPPartNum);
	strcat(LineItem," ");
	strcat(LineItem,MPPPartRev);
	strcat(LineItem," ");
	strcat(LineItem,MPPPartSeq);
	strcat(LineItem," ");
	strcat(LineItem,PlantBOP);
	strcat(LineItem," ");
	strcat(LineItem,PlantBOPRev);
	strcat(LineItem," ");
	strcat(LineItem,PlantBOPSeq);
	strcat(LineItem," ");
	strcat(LineItem,PlantValue);
	strcat(LineItem," ");
	strcat(LineItem,PlantView);
	strcat(LineItem," ");
	strcat(LineItem,RevRule);
    strcat(LineItem," ");
	strcat(LineItem,UsrNmee);
	
	printf("\n LineItem = %s",LineItem);fflush(stdout);
	system(LineItem);
	
    return ifail;
}



extern int MPPUserServiceFnMPPStnBomRptFn()
{
    int ifail = ITK_ok;
    int nargs = 10;
    int retValueType;
    int inputArgTypes[10] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; 
    inputArgTypes[1] = USERARG_STRING_TYPE; 
    inputArgTypes[2] = USERARG_STRING_TYPE; 
    inputArgTypes[3] = USERARG_STRING_TYPE; 
    inputArgTypes[4] = USERARG_STRING_TYPE; 
    inputArgTypes[5] = USERARG_STRING_TYPE; 
    inputArgTypes[6] = USERARG_STRING_TYPE; 
    inputArgTypes[7] = USERARG_STRING_TYPE; 
    inputArgTypes[8] = USERARG_STRING_TYPE; 
    inputArgTypes[9] = USERARG_STRING_TYPE; 
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("MPPStnBOMRptFuncsvr",(USER_function_t)MPPStnBOMRptFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceFnMPPStnBOMRptFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(MPPUserServiceFnMPPStnBomRptFn());

    return ifail;
}

extern DLLAPI int tm_MPPStnBOMRpt_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_MPPStnBOMRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnMPPStnBOMRptFn);
    return(ITK_ok);
}

