/*
Code Description :: Reference Items folder will get scanned for SVR and Platform. SVR will be applied on platform to get the unit BOM and BOM completeness check.
If released VC is present as per SVR name then it will get revised.
*/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <unidefs.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tcinit/tcinit.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <property/prop.h>
#include <pie/pie.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <textsrv/textserver.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define PLM_error 919018
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_errStore2 (EMH_USER_error_base + 6)
#define ITK_errErr1 (EMH_USER_error_base + 4)
#define ITK_errErr (EMH_USER_error_base + 99)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

#define VOO_HASH_SIZE 4099
#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer

typedef struct
{
    int size;
    int capacity;
    int increment;
    void **content;
} vector_t;

struct modstruct
 {
	   //part details
		char parent_part[100];
		int child;

 } childstr[10000];

typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];
static vector_t *vector_new( int capacity, int increment );
static vector_t *vector_add( vector_t *v, void *element );
static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
static vector_t *vector_ensure_capacity( vector_t *v, int n );
static vector_t *vector_free( vector_t *v );
static vector_t *vector_insert( vector_t *in, void *element );
static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
static void *vector_get( const vector_t *v, int index );
static int vector_size( const vector_t *v );
static int vector_rem_at( vector_t *in, int n );
static int vector_rem_n_at( vector_t *in, int n, int at );
static int VOO_debug = FALSE;
static char *VOO_prog = (char *)"UnitBOM";

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i=0;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static double token_to_double ( const char *str )
{
    return strtod( str, NULL);
}

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

extern EPM_decision_t DLLAPI ECUCount_Valid16RTPL (EPM_rule_message_t msg)
{
	char *key_lov_name = NULL;
	char *owning_site = NULL;
	int options=0;
	int n_lov_entries=0;
	char **lov_keys;
	char **lov_values;
	logical *deprecated_staus;
	//int options=0;
	int n_shared_sites=0;
	int ic=0;
	char ** shared_sites ;
	char* attributeValue		= NULL;
	char* attributeValue1		= NULL;
	tag_t Design_rev_cls_tag    = NULLTAG;

	EPM_decision_t decision;

	int ifail;
	int status;
	int iStatus	=0;
	int DMLCount=0;
	int tsk_cnt	=0;
	int t		=0;
	int i		=0;
	int p		=0;
	int partcnt =0;
	int ecuRlzStatusCnt =0;
	int level 			       =    0;
	int con				       =    0;
	int containerCount         =    0;
	tag_t	*DMLObj					= NULLTAG;
	tag_t	*Tsk_objects			= NULLTAG;
	tag_t	*PartsTag				= NULLTAG;
	tag_t   *ecu_Rlz_St_list        = NULLTAG;
	char	*DMLprojcode            = NULL;
	char	*Rel_type               = NULL;
	char	*Taskobject_type        = NULL;
	char    *RevIDNo_Org            = NULL;
	char    *VCnumberDup            = NULL;
	char    *VCnumber               = NULL;
	char    *PartNo                 = NULL;
	char    *PartType               = NULL;
	char    *req_item               = NULL;
	char    *t5NoEcuDup             = NULL;
	tag_t	DMLRevTag				= NULLTAG;
	tag_t	DMLToTaskRel		    = NULLTAG;
	tag_t	part_tsk_rel		    = NULLTAG;
	tag_t	ProQryDMLObj			= NULLTAG;
	tag_t	DesignrevTag			= NULLTAG;
	tag_t	LatestVC				= NULLTAG;
	tag_t	CCVCrelation_type		= NULLTAG;
	tag_t	LatestModRevTag			= NULLTAG;
	tag_t	sn_rule					= NULLTAG;
	int		n_Input	       = 2;
	int		t5NoEcuDupint  = 0;
	int		Modcnt	       = 0;
	tag_t	window 	        = NULLTAG;
	tag_t	*Modattachments	= NULLTAG;
	tag_t   Mod_rev_tag     = NULLTAG;
	tag_t   DML_tag			= NULLTAG;
	tag_t	top_line	    = NULLTAG;
	tag_t	DesignMasterTag	= NULLTAG;
	char * username			= NULL;
	char * parent_name		= NULL;
	char * dmlTaskNo		= NULL;
	char * ModulNo			= NULL;
	char * ECUCountErr		= NULL;
	char*   ModulRevid     =NULL;      //3 sept
	int AttachmentCount = 0;
	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t Mod_rev_tag_mstr  = NULLTAG; //3 sept
	decision = EPM_go;// 9 SEPT
	//Added by ajinkya for DVP in VC//
	tag_t CCVCrelation_typeDv	= NULLTAG;
	tag_t *ModattachmentsDv		= NULLTAG;
	tag_t Mod_rev_tag_mstrDv	= NULLTAG;
	tag_t Mod_rev_tagDv			= NULLTAG;
	tag_t class_id				=NULLTAG;
	tag_t *DMLRevision			= NULLTAG;
	tag_t NewDMLRevTag			= NULLTAG;
	tag_t *children				= NULLTAG;
	tag_t bl_Child_dv			= NULLTAG;
	tag_t tsk_dml_rel_type		= NULLTAG;
	char *ModulNoDv = NULL;
	char *ModulRevidDv =NULL;
	char *BusUnitDV = NULL;
	char *DMLDRdvp = NULL;
	char *partNumber = NULL;
	char *ModPartType = NULL;
	char *LatChildName = NULL;
	char *class_name = NULL;
	int ModcntDv = 0;
	int jdv =0;
	int jt =0;
	int n_Cnt =0;
	int jcnt =0;
	logical is_latest;
	char*  type_name= NULL;
	tag_t objTypeTagdv  = NULLTAG;
	tag_t reln_typeDvp  = NULLTAG;
	tag_t SolnItemTag   = NULLTAG;
	tag_t EE_tag		= NULLTAG;
	tag_t EEparent_rev   = NULLTAG;
	tag_t new_Child_tg	= NULLTAG;
	tag_t *childrenee	= NULLTAG;
	tag_t *dvpCtrObj	= NULLTAG;
	tag_t TagWeControl	= NULLTAG;
	int n_attchs_dvp     = 0;
	int  dvp             = 0;
	int  ddi             = 0;
	char *dataset_name1 = NULL;
	char *Item_id_EE = NULL;
	GRM_relation_t *secondary_dvp;
	int	n_entriesWe = 2;
	int n_foundWe = 0;
	int  dvpflag = 0;
	char *qry_entriesWe[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesWe[2] = {"VC", "DVP"};
	//END for DVP//

	ITK_CALL(POM_get_user_id (&username));
	printf("\n ECUCount_Valid16RTPL Session User is : %s\n",username); fflush(stdout);
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	{
		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\n ECUCount_Valid16RTPL Parent Name: %s",parent_name);fflush(stdout);

		ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
		printf("\n ECUCount_Valid16RTPL Target Attachment:%d",AttachmentCount);fflush(stdout);

		if(AttachmentCount > 0)
		{
			DMLTaskTag = attachments[0];

			if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n ECUCount_Valid16RTPL dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);

			// if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			tag_t *tags_found = NULLTAG;
			int n_tags_found= 0;
			int n_rev= 0;

			const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
			const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

			attrs[0] ="item_id";
			values[0] = (char *) dmlTaskNo;

			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
			MEM_free(attrs);
			MEM_free(values);
			CHECK_FAIL;

			if (n_tags_found == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", dmlTaskNo); fflush(stdout);
				exit (0);
			}

			DML_tag = tags_found[0];
			printf("\n after  DML_tag XXXXXXXXXX :\n");fflush(stdout);

			ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));

		//		if (DMLRevTag != NULLTAG)
		//		  {
		//			printf("\n DMLRevTag FOUND XXXXXXXXXXXX:\n");fflush(stdout);
		//			//if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
		//
		//			if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
		//			printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);
		//
		//		   if((tc_strcmp(Rel_type,"Vehicle Release")==0)||(tc_strcmp(Rel_type,"Veh")==0))
		//			{
		//			   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
		//			   ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));
		//
		//			   printf("\n  VC validation Task count is : [%d] \n",tsk_cnt);fflush(stdout);
		//
		//				  if (tsk_cnt>0)
		//					{
		//					  for (t=0;t<tsk_cnt ;t++ )
		//						{
		//						   ITK_CALL(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type)); //3 sept
								ITK_CALL(AOM_ask_value_string(DMLTaskTag,"object_type",&Taskobject_type));//3 sept
								printf("\n  VC validation Taskobject_type is :[%s]\n",Taskobject_type);fflush(stdout);
								if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
								{
								   printf("\n tm_ECURefSnapshot inside T5_ChangeTaskRevision :\n");fflush(stdout);
								   ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));

								   if (part_tsk_rel!=NULLTAG)
									 {
									   //ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[t], part_tsk_rel, &partcnt, &PartsTag));//3 sept
									   ITK_CALL(GRM_list_secondary_objects_only(DMLTaskTag, part_tsk_rel, &partcnt, &PartsTag));//3 sept
									   printf("\n  VC validation partcnt.:%d\n",partcnt);fflush(stdout);

										if (partcnt>0)
										 {
										   for (p=0;p<partcnt;p++)
											 {
												DesignrevTag=PartsTag[p];

												ITEM_ask_item_of_rev(DesignrevTag,&DesignMasterTag); //find master here

												//ITK_CALL(ITEM_ask_latest_rev(DesignrevTag,&LatestVC));
												if( AOM_ask_value_string(DesignrevTag,"item_id",&VCnumber)!=ITK_ok);
												//tc_strcpy(VCnumberDup,VCnumber);
												printf("\n VCnumber is [%s]  \n",VCnumber); fflush(stdout);


												if(AOM_ask_value_string(DesignrevTag,"item_id",&PartNo)==ITK_ok);
												printf("\n  VC validation PartNo is  = [%s]\n", PartNo);fflush(stdout);

												if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo_Org)==ITK_ok);
												printf("\n  VC validation RevIDNo is  = [%s]\n", RevIDNo_Org);fflush(stdout);

												if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok);
												printf("\n  VC validation PartType is  = [%s]\n", PartType);fflush(stdout);

												if((tc_strcmp(PartType,"Configurable VC")==0)||(tc_strcmp(PartType,"CCVC")==0))
												{

													ITK_CALL(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
													printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);

													for(ic=0;ic<n_lov_entries;ic++)
													{
														printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
														(ICS_ask_classification_object(DesignMasterTag,&Design_rev_cls_tag));

														(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));

														printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);

														if(tc_strcmp(attributeValue,lov_keys[ic])==0)
														{
															printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);

															t5NoEcuDup =(char *) MEM_alloc(20);
															tc_strcpy(t5NoEcuDup,lov_values[ic]);

															printf("\n ECU COUNT IS  =%s",t5NoEcuDup); fflush(stdout);//10

															t5NoEcuDupint=atoi(t5NoEcuDup);

															printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10

														}
													}


													ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_type));
													printf("\n   CCVC has ECU module REL FOUND \n");fflush(stdout);

													ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_type,&Modcnt,&Modattachments));
													printf("\n Modcnt ============= [%d]  \n",Modcnt); fflush(stdout);

													if (Modcnt > 0)
													 {
														//Mod_rev_tag = Modattachments[0];
														Mod_rev_tag_mstr = Modattachments[0]; // 3 sept

														ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstr,&Mod_rev_tag));// 3 sept

														if(AOM_ask_value_string(Mod_rev_tag,"item_id",&ModulNo)==ITK_ok);
														printf("\n  VC validation ModulNo is  = [%s]\n", ModulNo);fflush(stdout);

														if(AOM_ask_value_string(Mod_rev_tag,"item_revision_id",&ModulRevid)==ITK_ok); //3 sept
														printf("\n  VC validation ModulRevid is  = [%s]\n", ModulRevid);fflush(stdout);//3 sept

														printf("\n Mod_rev_tagP \n"); fflush(stdout);
														//VC_Multi_Get_Part_BOM_Lvl_Col_1(window,99,level,LatestModRevTag,containerCount);
														VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,Mod_rev_tag,&containerCount);


													}
													printf("\n final count of containers  is [%d] \n",containerCount);fflush(stdout);

													if(containerCount==t5NoEcuDupint)
													  {
														  printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
													  }
													  else
													  {
														printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);

														if (tc_strcmp(ECUCountErr,"NULL") !=0) MEM_free(ECUCountErr);
														ECUCountErr=(char *)MEM_alloc(600);
														tc_strcpy(ECUCountErr,"For ");
														tc_strcat(ECUCountErr,VCnumber);
														tc_strcat(ECUCountErr," the Value of Attribute - number of ECU's -is not matching with the actual number of containers in ECU module ");
														tc_strcat(ECUCountErr,ModulNo);

														printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErr);
														decision = EPM_nogo;
														return decision;
													  }

													containerCount = 0;
													t5NoEcuDupint = 0;
												  }

												  //Code added by ajinkya for DVP Report validation on 10 sep ............ //
												printf("\n  DVP-VC validation for VC started now \n");fflush(stdout);
												if(QRY_find2("ControlObjQry", &TagWeControl));

												if(QRY_execute(TagWeControl, n_entriesWe, qry_entriesWe, qry_valuesWe, &n_foundWe, &dvpCtrObj));
												printf("\n Control Object found for WE parts == %d\n", n_foundWe);fflush(stdout);

												if(n_foundWe==1)
												{
													printf("\n  Control Object found for DVP == %d  \n", n_foundWe);fflush(stdout);
												if (DMLRevTag != NULLTAG)
												{
												  printf("\n As DMLRevTag not null \n");fflush(stdout);

												  ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id));
												  ITK_CALL(POM_name_of_class(class_id,&class_name));
												  printf("\n\n DVP-VC  class_name of Task :%s \n",class_name);fflush(stdout);

												   if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
												   {
														printf("\n\n Task class_name find ---:%s \n",class_name);fflush(stdout);
														ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
														if (tsk_dml_rel_type!=NULLTAG)
														{
															printf("\n\n Relationship tag class_name find  \n");fflush(stdout);
															ITK_CALL(GRM_list_primary_objects_only(DMLRevTag,tsk_dml_rel_type,&jdv,&DMLRevision));
															printf("\n\n\t\t DML Revision from Task : %d \n",jdv);fflush(stdout);

															for (jt=0;jt<jdv ;jt++ )
															{
																printf("\n\n Inside for DML Latest revision  ---:%d \n",jdv);fflush(stdout);
																ITK_CALL(ITEM_rev_sequence_is_latest(DMLRevision[jt],&is_latest));
																printf("\n\n\t\t is_latest : %d \n",is_latest);fflush(stdout);

																if(is_latest != true)
																{
																	printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
																}else
																{
																	printf("\n\n INSIDE DML FIND  code \n");fflush(stdout);
																	NewDMLRevTag = DMLRevision[jt];

																	ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
																	printf("\n IN VC DML business unit for DVP :%s \n",BusUnitDV);fflush(stdout);

																	ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_cDRstatus",&DMLDRdvp));
																	printf("\n IN VC DML DR status  for DVP :%s \n",DMLDRdvp);fflush(stdout);

																}
															}
														}
													}

												printf("\n IN VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);

												if((strcmp(BusUnitDV,"PVBU")==0) && (strcmp(DMLDRdvp,"DR4")==0))
												{
												  printf("\n  DVP-VC validation PartType is  = [%s] \n", PartType);fflush(stdout);
												  if ((tc_strcmp(PartType,"CCVC")==0)||(tc_strcmp(PartType,"V")==0))
												  {
													printf("\n Part TYPE Inside DVP-VC ============= [%s]  \n",PartType); fflush(stdout);
													ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDv));
													printf("\n  DVP-VC CCVC has ECU module REL FOUND \n");fflush(stdout);

													ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_typeDv,&ModcntDv,&ModattachmentsDv));
													printf("\n DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);

													if (ModcntDv > 0)
													 {
														printf("\n Inside DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);
														Mod_rev_tag_mstrDv = ModattachmentsDv[0];

														ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstrDv,&Mod_rev_tagDv));

														if(AOM_ask_value_string(Mod_rev_tagDv,"item_id",&ModulNoDv)==ITK_ok);
														printf("\n  DVP-VC validation ModulNoDv is  = [%s] \n", ModulNoDv);fflush(stdout);

														if(AOM_ask_value_string(Mod_rev_tagDv,"item_revision_id",&ModulRevidDv)==ITK_ok); //3 sept
														printf("\n DVP-VC validation ModulRevidDv is  = [%s] \n", ModulRevidDv);fflush(stdout);//3 sept

														printf("\n Mod_rev_tagP \n"); fflush(stdout);

														//code for Module expand//
														ITK_CALL(BOM_create_window (&window)); //3 sept
														ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept
														ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));
														ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

														ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tagDv,null_tag, &top_line));

														ITK_CALL(BOM_window_show_suppressed (window));

														printf("\n DVP-VC after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

														ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
														printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);

														ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
														printf("\n\n\t\t **** DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);

														if (n_Cnt>0)
														{
															printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);
															for (jcnt=0;jcnt<n_Cnt;jcnt++)
															{
																printf("\n\n\t\t Inside for loop \n");fflush(stdout);

																bl_Child_dv=children[jcnt];

																ITK_CALL(AOM_ask_value_string( bl_Child_dv,"bl_item_item_id",&LatChildName));
																printf("\n DVP-VC LatChildName Parts Id : [%s] \n",LatChildName);

																if( AOM_ask_value_string(bl_Child_dv,"bl_T5_EE_PartRevision_t5_SwPartType",&ModPartType)!=ITK_ok);
																printf("\n DVP-VC t_ChildItemRev tag found ===>%s \n",ModPartType);fflush(stdout);

													   //check for dvp report //
														if(strcmp(ModPartType,"CON")==0)
														{
															printf("\n Inside container part found ===>%s \n",ModPartType);fflush(stdout);
															ITK_CALL(ITEM_find_item(LatChildName,&EE_tag));
															printf("\n Function called FOR EE_tag \n");fflush(stdout);

															if( AOM_ask_value_string(EE_tag,"item_id",&Item_id_EE)!=ITK_ok);

															printf("\n  DVP-VC Item ID is  ---->%s \n",Item_id_EE); fflush(stdout);

															ITK_CALL(ITEM_ask_latest_rev(EE_tag,&EEparent_rev));

															if(TCTYPE_ask_object_type(EEparent_rev,&objTypeTagdv));
															if(TCTYPE_ask_name2(objTypeTagdv,&type_name));
															printf("\n\n\t\t DVP-VC EEparent_rev type_name := %s \n", type_name);fflush(stdout);

															 if(strcmp(type_name,"T5_EE_PartRevision")==0)
															 {
																 printf("\n\n\t\t For DVP-VC part type is  %s \n", type_name);fflush(stdout);

																 ITK_CALL(GRM_find_relation_type("IMAN_specification",&reln_typeDvp));
																 printf("\n\n\t\t DVP for IMAN_specification......... \n");fflush(stdout);

																	   if(reln_typeDvp != NULLTAG)
																	   {
																		 printf("\n\n\t\t DVP-VC relation_type   is not null........ \n");fflush(stdout);

																		  ITK_CALL(GRM_list_secondary_objects(EEparent_rev,reln_typeDvp,&n_attchs_dvp,&secondary_dvp));

																		 printf("\n\n\t\t DVP-VC After GRM_list_secondary_objects count : %d \n",n_attchs_dvp);fflush(stdout);


																		  if(n_attchs_dvp>0)
																		  {
																			for(ddi=0;ddi<n_attchs_dvp;ddi++)
																			{
																				dvpflag=0;
																			 printf("\n\n\t\t DVP-VC Inside data set for DVP-VC found ........ \n");fflush(stdout);

																			   SolnItemTag = secondary_dvp[ddi].secondary;

																			  ITK_CALL(AOM_ask_value_string(SolnItemTag,"object_name",&dataset_name1));
																			  printf("\n\n\t\t DVP-VC Data set name for DVP----%s ........ \n",dataset_name1 );fflush(stdout);

																			   if(strstr(dataset_name1,"DVP") != NULL)
																			  {
																				   printf("\n\n\t\t DVP-VC Inside Flag set as Data set name for DVP----%s ........\n",dataset_name1 );fflush(stdout);

																					dvpflag=1;
																					break;
																			  }
																			}
																			  printf("\n DVP-VC OUTSIDE for loop dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
																			  if (dvpflag==1)
																			  {
																				printf("\n DVP-VC Inside dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
																			  }
																			  else
																			   {
																				printf("\n\n DVP-VC Inside else as DVP report NOT found attached Container as flag value  %d \n" ,dvpflag );fflush(stdout);

																				EMH_clear_errors();
																				EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Please Attach DVP Validation Report to Container Part in Specification \n Give Report Name which Start with DVP Word" );
																				decision = EPM_nogo;
																				return decision;

																			   }

																		  }
																		  else
																		  {
																			   printf("\n\n DVP-VC As no data set found, GIVE THE ERROR Please attach DVP validation report to Container.. (%d) \n",n_attchs_dvp );fflush(stdout);
																			   EMH_clear_errors();
																			   EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "No Dataset Found for Container Part.Please Attach DVP Validation Report to Container in Specification \n Give Report Name which Start with DVP Word" );
																			   decision = EPM_nogo;
																			   return decision;
																		  }

																	   }

																 }
																 else
																{
																		printf("\n\n\t\t DVP-VC Else part type EEparent_rev type_name := %s \n", type_name);fflush(stdout);
																}

															  }
															 else
															{
																 printf("\n DVP-VC Else container part Not found ===>%s \n",ModPartType);fflush(stdout);
															}

														  }
														}

														//end
													 }

												  }
												  else
												  {
													printf("\n Else Part TYPE  DVP-VC  ============= [%s]  \n",PartType); fflush(stdout);
												  }

												 }
												 else
												{
													 printf("\n Else VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);

												}

											   }

											 }
											 else
											 {
												printf("\n Else Control Object Not found for DVP not FOUND == %d  \n", n_foundWe);fflush(stdout);
											 }
											   printf("\n Outside fot DVP report check on VC code \n");fflush(stdout);
												  //end for dvp//
											 }
										  }
									  }
								  }
		//					      }  //3 sept
		//					  }
		//				  }
		//				  else
		//				  {
		//					printf("\n Release type is not Veh release it is [%s]\n",Rel_type);fflush(stdout);
		//				  }
		//	         }
			}
	}

	printf("\n ECUCount_Valid16RTPL---completed function ...\n\n");fflush(stdout);

	return decision;
}
int UpdateAllowForm(tag_t  itemRev,char* Toupd)
{
	tag_t  *attachments = NULLTAG;
	tag_t  relation_type   = NULLTAG;
	tag_t  user_tag = NULLTAG;
	tag_t  dataset = NULLTAG;
	char *ObjectClassType = NULL;
	char *gov_class = NULL;
	char *itemId = NULL;
	int stat = ITK_ok;
	int n_found     = 0;
	tag_t boTag= NULLTAG;
	tag_t creInputTag_r = NULLTAG;
	tag_t boTypeTag = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t Rel_task = NULLTAG;
	int status;
	char *s = NULL;
	int cnt = 0;
	int ij = 0;
	int ifail = 0;

	printf("\nUpdateAllowForm--In function-------------- \n");fflush(stdout);

	TCTYPE_find_type("T5_UpdForm", NULL, &boTypeTag);

	if (AOM_ask_value_string(itemRev,"object_name",&itemId)!=ITK_ok);

	TCTYPE_construct_create_input (boTypeTag, &creInputTag_r);

	if(creInputTag_r != NULLTAG)
		printf("\nUpdateAllowForm--Input Tag Created for item id. \n", n_found);fflush(stdout);

	boTypeTag = NULLTAG;

	if(AOM_set_value_string(creInputTag_r, "object_name", itemId));
	if(AOM_set_value_string(creInputTag_r, "t5_IsUpdAllowed", "N"));

	status = TCTYPE_create_object (creInputTag_r, &boTag) ;
	if(status != ITK_ok)
	{
		EMH_ask_error_text( status, &s);
		printf("\nUpdateAllowForm--*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
		MEM_free(s);
		return status;
	}

	creInputTag_r = NULLTAG;
	if(boTag != NULLTAG) printf("\n UpdateAllowForm--Update form created. \n");fflush(stdout);
	if(AOM_save_without_extensions(boTag));
	if(AOM_unlock(boTag));

	if(GRM_find_relation_type("T5_PartHasUpdForm",&relation_type1));
	if(GRM_find_relation(itemRev,boTag,relation_type1,&tRelationExist));
	if (tRelationExist==NULLTAG)
	{
		   //###  Creating Relation between DML and Task  ###

		   printf("\n UpdateAllowForm--Now Creating Relation Between Design Revision and Update Form \n");fflush(stdout);
		   if(GRM_create_relation(itemRev,boTag,relation_type1,NULLTAG,&Rel_task));
		   if(GRM_save_relation  (Rel_task));
		   printf("\nUpdateAllowForm--Relation Created Successfully\n");fflush(stdout);
	}

	if(GRM_list_secondary_objects_only(itemRev,relation_type,&cnt,&attachments));
	printf("\n UpdateAllowForm--Attached Datasets2: %d\n",cnt);fflush(stdout);
	printf("UpdateAllowForm--Update form value  [%s]\n",Toupd); fflush(stdout);

	for(ij=0;ij<cnt;ij++)
	{
		dataset = attachments[ij];
		if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)
		printf("\n\n UpdateAllowForm--Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

		if (strcmp(ObjectClassType,"T5_UpdForm")==0)
		{
			if( AOM_set_value_string(dataset,"t5_IsUpdAllowed",Toupd));
			if(AOM_save_without_extensions(dataset));
			if(AOM_unlock(dataset));

			if( AOM_ask_value_string(dataset,"t5_IsUpdAllowed",&gov_class));
			printf("\n\n UpdateAllowForm--Update for value updated to:%s\n",gov_class);fflush(stdout);
		}
	}

	printf("\n ECUCount_Valid16RTPL---completed function ...\n\n");fflush(stdout);

	return ITK_ok;
}
int t5removeAllReleaseStatus (tag_t rev)
{
	int			status_count			= 0;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	int			n_values				= 0;
	int			cunt1					= 0;
	int         stat                    = ITK_ok;
	int			ifail					= 0;

	tag_t*		status_list				= NULLTAG;
	tag_t*		relstatus_list			= NULLTAG;
	tag_t*		attr_tags				= NULLTAG;

	tag_t		tReleaseStatusList		= NULLTAG;
	tag_t		class_id				= NULLTAG;

	char		*WSO_Name_RelVal		= NULL ;
	char		*class_name				= NULL;

	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	logical		log1;

	CALLAPI(WSOM_ask_release_status_list(rev,&status_count,&status_list));
	printf("\n t5removeAllReleaseStatus--No of Status == %d\n",status_count);fflush(stdout);

	if(status_count>0)
	{
		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));
		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf("t5removeAllReleaseStatus--Load Success\n" );fflush(stdout);
		}
		else
			printf("t5removeAllReleaseStatus--Load Failure\n");fflush(stdout);

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("t5removeAllReleaseStatus--Status removal started\n");fflush(stdout);
				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				CALLAPI(POM_save_instances(1,&rev,1));
				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));
				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save_without_extensions(rev));
				CALLAPI(AOM_refresh(rev,1));
				printf("t5removeAllReleaseStatus--Status removal completed\n");fflush(stdout);

				CALLAPI(POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
				printf("t5removeAllReleaseStatus--Updated Status Count is :%d\n",n_values);fflush(stdout);
				CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				cunt1=cunt1-1;
			}
			CALLAPI(AOM_unlock(rev));
		}
		printf("t5removeAllReleaseStatus--All Statuses removed\n");;fflush(stdout);
	}
	return ITK_ok;
}
int AssignProject_vc_rel(tag_t  itemRev,char* projectcode)
{
	tag_t  projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char* username=NULL;
	int stat = ITK_ok;
	int ifail = 0;

	//ITK_CALL(AOM_lock(itemRev));
	printf("\n AssignProject_vc_rel--Projectcode [%s]\n",projectcode); fflush(stdout);
	CALLAPI(PROJ_find(projectcode,&projobj));
	printf("\n AssignProject_vc_rel : Assigned to Project\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		printf("\n AssignProject_vc_rel : In not NULL tag\n");fflush(stdout);
		CALLAPI(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n AssignProject_vc_rel--Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n AssignProject_vc_rel--Project not found\n");fflush(stdout);
	}
	//ITK_CALL(AOM_save_without_extensions(itemRev));
	//ITK_CALL(AOM_unlock(itemRev));

	return ITK_ok;
}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );
static int VOO_show_wso
    ( tag_t       wso                         /* <I> */
    );

	static char *VOO_time_stamp
    ();

static int VOO_list_saved_variant_rules
    ( tag_t       itemRev,                    /* <I> */
      int *       nVRules,                    /* <O> */
      tag_t **    vRules                      /* <OF> */
    );
static logical VOO_option_value_hash
    ( int         hash_size,                  /* <I> */
      vector_t *  hash[],                     /* <I> */
      tag_t       option_rev,                 /* <I> */
      int         option_rev_value_index,     /* <I> */
      int         add_if_new                  /* <I> */
    );
static int VOO_variant_expression
    ( tag_t        v1,                        /* <I> */
      int          op,                        /* <I> */
      tag_t        v2,                        /* <I> */
      const char * text,                      /* <I> */
      tag_t      * ve,                        /* <O> */
      logical    * was_new                    /* <O> */
    );
static int VOO_expression_hash
    ( int          hash_size,                 /* <I> */
      vector_t   * hash[],                    /* <I> */
      tag_t        val1,                      /* <I> */
      int          oper,                      /* <I> */
      tag_t        val2,                      /* <I> */
      const char * text,                      /* <I> */
      logical      add_if_new,                /* <I> */
      tag_t      * var_exp,                   /* <O> */
      logical    * was_new                    /* <O> */
    );

int bom_complete( EPM_action_message_t msg )
{
	int ifail			= 0;
	int cnt				= 0;
	int i				= 0;
	int j				= 0;
	int ju				= 0;
	int stat            = ITK_ok;
	int noAttachment	= 0;
	int n_bom_views		= 0;
	int countConfigCtx	= 0;
	int n_entries		= 1;
	int resultCount		= 0;

	char *objecttype	=NULL;
	char *objectname	=NULL;
	char *TempVal		=NULL;

	tag_t DMLTag		= NULLTAG;
	tag_t rev1			= NULLTAG;
	tag_t primary1		= NULLTAG;
	tag_t rootTask		= NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t rev			= NULLTAG;
	tag_t view_type		= NULLTAG;
	tag_t item			= NULLTAG;
	tag_t ConfigCtx		= NULLTAG;
	tag_t ConfigCtxObjTypeTag=NULLTAG;
	tag_t queryTag		= NULLTAG;
	tag_t bom_view		= NULLTAG;
	tag_t Optfmly_tag	= NULLTAG;
	tag_t relation_type1= NULLTAG;
	tag_t relation_dep	= NULLTAG;
	//tag_t rev1		= NULLTAG;

	tag_t *attachments	=NULLTAG;
	tag_t *attachments1 =NULLTAG;
    tag_t *bom_views=NULLTAG;
	tag_t *OptionValue=NULLTAG;
	tag_t *option_revs=NULLTAG;
	tag_t *ConfigCtxSecObject = NULLTAG;

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *SmVCContext = NULL;
	char *SmCrIDContext = NULL;
	char *ContextobjName = NULL;
	char *Varruletxt	= NULL;
	char AllOptions[700];
	char AllOptionValues[700];
	char* relation_name= NULL;
	char* Config_CtxType= NULL;
	char *qry_entries[1] = {"ID"};

	TempVal=(char *) MEM_alloc(1000);


	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n In bom_complete Function............................. \n"); fflush(stdout);

	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf(" bom_complete--Target Attachment:%d\n",noAttachment);fflush(stdout);

	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
	}

	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));

	if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name2( relation_type,&relation_name));
		printf("\n bom_complete--Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
		printf("\n bom_complete--impacted items:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
			printf("\n bom_complete--to find impacted items\n");fflush(stdout);
			rev1 = attachments1[i];
			if(AOM_ask_value_string(rev1,"object_type",&objecttype));
			if(AOM_ask_value_string(rev1,"object_name",&objectname));

			if (strcmp(objecttype,"VariantRule")==0)
			{
				strcpy(TempVal,objectname);
				primary1=rev1;
				if(AOM_ask_value_string(rev1,"cfg0VariantRuleText",&Varruletxt));
				printf("\n bom_complete--Variant rule text is :%s\n",Varruletxt);fflush(stdout);
			}
		}

		for(j=0;j<cnt;j++)
		{
			printf("\n bom_complete--to find impacted items\n");fflush(stdout);
			rev = attachments1[j];
			if(AOM_ask_value_string(rev,"object_type",&objecttype));
			if(AOM_ask_value_string(rev,"object_name",&objectname));

			//if(AOM_ask_value_string(rev,"object_type",&objecttype));

			if (strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				printf( "\n bom_complete--INside platform\n"); fflush(stdout);

				if ( rev !=NULLTAG )
				{
					CALLAPI ( PS_find_view_type( "view", &view_type ));
					printf("\n bom_complete--PS_find_view_type is found......\n" ); fflush(stdout);

					if ( NULLTAG != view_type )
					{
						CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
						CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

						bom_view = bom_views[0];
					}
					else
						printf("\nbom_complete--View not found check.......\n"); fflush(stdout);
				}

				tc_strcpy(AllOptions,"");
				tc_strcpy(AllOptionValues,"");
				CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
				if(relation_dep != NULLTAG)
				{
					printf("\n\t bom_complete--Variant ConfigContext relation found......");	fflush(stdout);
				}

				CALLAPI(GRM_list_secondary_objects_only(item,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
				printf("\n\t bom_complete--Configuration Context count is : %d",countConfigCtx);

				if(countConfigCtx > 0)
				{
					ConfigCtx=ConfigCtxSecObject[0];
					CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
					CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
					printf( "\n\t bom_complete--Config relation Config_CtxType :%s ..",Config_CtxType);

					CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
					printf("\n\t bom_complete--SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

					CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
					printf("\n\t bom_complete--SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

					if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
					printf("\n\t bom_complete--After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
					if (queryTag != NULLTAG)
					{
						printf("\n\tbom_complete--Found Query");fflush(stdout);
					}else
					{
						printf("\n\tbom_complete--Not Found Query");fflush(stdout);
					}

					qry_values[0] = SmCrIDContext;

					if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
					printf("\n\t bom_complete--resultCount : %d\n", resultCount); fflush(stdout);

					for (ju=0;ju<resultCount;ju++ )
					{
						Optfmly_tag = OptionValue[ju];
						CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
						printf("\n\t bom_complete--ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
						tc_strcat(AllOptions,",");
						tc_strcat(AllOptions,ContextobjName);
					}
				}
			}
		}
	}

	char *token = strtok(Varruletxt, "='");

	while (token != NULL)
    {
        printf("bom_complete--%s\n", token); fflush(stdout);

        token = strtok(NULL, "='");
		if(tc_strstr(AllOptions,token)==NULL)
		{
			tc_strcat(AllOptionValues,"\n");
			tc_strcat(AllOptionValues,token);
			printf("bom_complete--option Values are:%s",AllOptionValues); fflush(stdout);
		}
		else
		{

           printf("bom_complete--option found are:"); fflush(stdout);
		}
    }
}
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;
}
//VC/TechSpec availability from SVR
int ChkVCfrmSVR(char *CVObjName)		//VC/TechSpec availability from SVR
{
	int tscount = 0;
	char *VCnm = NULL;
	char *seq = NULL;
	char *VRRev = NULL;
	char *VCname = NULL;
	VCnm =  (char *) MEM_alloc(10 * sizeof(char));
	seq =  (char *) MEM_alloc(10 * sizeof(char));
	VRRev =  (char *) MEM_alloc(10 * sizeof(char));
	char *VCRevG = NULL;
	int Child_Rev_count=0;
	tag_t VCtag = NULLTAG;
	tag_t VCTagLt = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t *Child_rev_list = NULLTAG;
	tag_t *techspec_objects = NULLTAG;

	tc_strtok(CVObjName, "_");
	VRRev = tc_strtok(NULL, "_");
	strncpy(VCnm,CVObjName,8);
	//VRRev=tc_strtok(NULL, ";");
	tc_strcat(VCnm,"R");
	printf( "\n ChkVCfrmSVR:VC Name created from SVR is %s & rev is %s",VCnm,VRRev); fflush(stdout);
	///////
	tag_t rev_tag = NULLTAG;
	tag_t Child_All_Rev = NULLTAG;
	tag_t objTypTag = NULLTAG;
	char*   ObjTyp= NULL;
	if(tc_strcmp(VRRev,"NR")!=0)
	{
		Child_All_Rev= t5GetItemRevison(VCnm);
		if(Child_All_Rev==NULLTAG)
		{
			printf("\n ChkVCfrmSVR:Child_All_Rev is NULL.\n");fflush(stdout);
		}
		else
		{
			if(ITEM_ask_latest_rev(Child_All_Rev, &rev_tag)!=ITK_ok)PrintErrorStack();

			if(TCTYPE_ask_object_type(rev_tag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ChkVCfrmSVR: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			
			if (rev_tag != NULLTAG)
			{
				if(AOM_UIF_ask_value(rev_tag,"item_revision_id",&VCRevG));
				printf( "\n ChkVCfrmSVR: VCRevG [%s]",VCRevG); fflush(stdout);
				seq=tc_strtok(VCRevG, ";");
				printf( "\n ChkVCfrmSVR:VCRevG Found and which is [%s] & seq is[%s]",VCRevG,seq); fflush(stdout);
			}
			else
			{	
				printf( "\n ChkVCfrmSVR:Latest VC Re Tag not found.[%s]",VCnm); fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest VC Revision not found for Creation, Kindly raise ticket in TMS");
				printf("\n Latest VC Revision not found for Creation, Kindly raise ticket in TMS\n");fflush(stdout);
				return PLM_error;
			}
		}
		printf( "\n ChkVCfrmSVR:VC seq is [%s] & VRRev is [%s]",seq,VRRev); fflush(stdout);
		if (tc_strcmp(seq,VRRev)==0)
		{
			printf( "\n ChkVCfrmSVR:VC Revision is already present is system."); fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system. Kindly raise ticket in TMS ");
			printf("\n ChkVCfrmSVR:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
			return PLM_error;
		}
		else
		{
			printf("\n ChkVCfrmSVR: Sequese of [%s] is not found",VRRev);fflush(stdout);
			GRM_find_relation_type("T5_VCSpec", &relation_type_tag);
			GRM_list_secondary_objects_only(rev_tag,relation_type_tag,&tscount,&techspec_objects);
			if (tscount == 0)
			{
				printf( "\n ChkVCfrmSVR:Previous VC Revision is not having Tech Spec attached to it."); fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest Released VC Revision is not having Tech Spec attached to it. Kindly raise ticket in TMS ");
				printf("\n ChkVCfrmSVR::Latest Released VC Revision is not having Tech Spec attached to it.\n");fflush(stdout);
				return PLM_error;
			}
		}
	}
	else
	{
		printf("\n SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
		Child_All_Rev= t5GetItemRevison(VCnm);
		if(Child_All_Rev !=NULLTAG)
		{
			printf("\n ChkVCfrmSVR:Child_All_Rev is Not NULL of NR SVR. VC Revision is already present is system.\n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system. Kindly raise ticket in TMS ");
			printf("\n ChkVCfrmSVR:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
			return PLM_error;
		}
		else
		{
			printf("\nNeed not to check present VC in system, SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
		}
	}
	return 0;
}

int vc_release( EPM_action_message_t msg )
{
	int ifail = 0;
	int stat = ITK_ok;
	int n_bom_views	= 0;
	int j = 0;
	int bom_view_index = 0;
	int noAttachment = 0;
	int n_saved_variant_rules=0;
	int n_options =0;
	int errorflag =0;
	int errorflag4 =0;
	int errorflag1 =0;
	int ernew	   =0;
	int errorflag2 =0;
	int errorflag34	=0;
	int inx=0, jnx=0, knx=0;
	int n_option_data=0, p1=0;
	int n_ves_2_save=0;
	int n_lines2=0;
	int n_lines3=0;
	int n_lines4=0;
	int p2=0;
	int ss=0 , ss2 = 0;
	int p36=0;
	int p4=0;
	int n_lines,n_lines1,Item_ID = 0;
	int option_value_index = -1;
	int cnt = 0;
	int cnt12 = 0;
	int cnt33 = 0;
	int ko = 0;
	int p3 = 0;
	int i = 0;
	int status_count = 0 , NewRevstatus_count = 0;
	int ix=0;
	int imat=0;
	int jmat=0;
	int IntAtr5=0;
	int n_occs=0;
	int iy=0;
	int p34=0;
	int countConfigCtx = 0;
	int n_entries = 1;
	int resultCount=0;
	int opcode=-1;
	int toggle_value_index = -1;
	int int_qunt=0;
	int n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
	int xform_matrix1 = 0;
	int blqu = 0;
	int Childstrcnt= 0;
	int p=0;
	int ju=0;
	int DMLSTVALUT=0;
	int jy=0;
	int v_entr=0;
	int bv_count=0, bvr_count=0;
	int rulefound= 0;
	int structcount=0;
	int n_tags_found = 0;
	int n_tags_found1 = 0;
	int n_tags_found3 = 0;
	int count = 0;
	int PRTSTVALU=0;
	int DRstusFlag=0;
	int add=0;
	int n_instances = 0;
	int n_classes = 0;
	int strcnt2 = 0;
	//int BU_n_entry = 1;
	//int BU_rsltCount = 0;

	int *option1_value_index=NULL;
	int *option2_value_index=NULL;
	int *ind;
	int *ind1;
	int *class_levels;
	int *class_where_found;
	int *instance_where_found;
	int *instance_levels;

	char *v2_text	= NULL;
	char *ItemId	= NULL;
	char *RevId		= NULL;
	char *VCItemId	= NULL;
	char *SVRType	= NULL;
	char *Item_ID_str= NULL;
	char *child_item_id=NULL;
	char *Arch_item_id=NULL;
	char *Arch_item_idStr=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *child_bl_formula=NULL;
	char **child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *platformName=NULL;
	char *objectname=NULL;
	char *objectdesc=NULL;
	char *tempmat=NULL;
	char *option_item_s     =NULL;
	char *option_s          =NULL;
	char *option_eq_s       =NULL;
	char *option_val_s      =NULL;
	char *tempmat1=NULL;
	char *SmVCContext = NULL;
	char *SmCrIDContext = NULL;
	char *itemId12 = NULL;
	char *itemId123 = NULL;
	char *itemId1234 = NULL;
	char *itemId12345 = NULL;
	char *ContextobjName = NULL;
	char *str=NULL;
	char *object_type=NULL;
	char *find_option_name_p=NULL;
	char *find_option_desc_p=NULL;
	char *Context_Str=NULL;
	char *toggle_value=NULL;
	char *qry_entries[1] = {"ID"};
	char *name = NULL;
	char *username =NULL;
	char *TempVal =NULL;
	char *VCPltform1 =NULL;
	char *VehName =NULL;
	char *InpDMLTask =NULL;
	char *DMLNo =NULL;
	char *DMLDRstatus =NULL;
	char *DMLDRstatusStr =NULL;
	char *CurrentRelStatus = NULL;
	char *NewRevRelStatus = NULL;
	char *spcPrefName = NULL;
	char *class_name1 = NULL;
	char *DMLtype = NULL;
	char *DMLDRStrT = NULL;
	char *PRTDRStr = NULL;
	char *PrtDRstus = NULL;
	char *PrtProjj = NULL;
	char *Obj_PrtTyp = NULL;
	char *class_name = NULL;
	char *sModuleAdrr = NULL;
	char *sModuleName = NULL;
	char *sArchModule = NULL;
	char *latest_rev_Rel_Stus = NULL;

	char PartNum[300];
	char ERCRelErrStrng[1500];
	char command[512];

	char **rulename = NULL;
	char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	char **blqu_str = NULL;
	char **xform_matrix_str = NULL;
	char ***ite = NULL;
	char ***opt = NULL;
	char ***descr = NULL;
	char ***value = NULL;

	char* Config_CtxType= NULL;
	char* relation_name= NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char Fresh[1900];
	char NoModule[1900];
	char T3Z01NoModule[2000];
	char NoAlternateModule[2000];
	char RevMisMatch[900];
	char* type_name2= NULL;
	char* type_name= NULL;
	char* type_name1= NULL;

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t *bom_views = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *attachments12 = NULLTAG;
	tag_t *saved_variant_rules=NULLTAG;
	tag_t *options = NULLTAG;
	tag_t *option1_rev = NULLTAG;
	tag_t *option2_rev = NULLTAG;
	tag_t topline = NULLTAG;
	tag_t *ves_2_save = NULLTAG;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	tag_t *opts=NULLTAG;
	tag_t *rootLine=NULLTAG;
	tag_t *bom_variant_config=NULLTAG;
	tag_t *opt_revs=NULLTAG;
	tag_t *secondaries=NULLTAG;
	tag_t *occs = NULLTAG;
	tag_t *occsal = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *secondary_objects1 = NULLTAG;
	tag_t *status_list = NULLTAG;
	tag_t *NewRevstatus_list = NULLTAG;
	tag_t *ConfigCtxSecObject = NULLTAG;
	tag_t *toggle_option_rev=NULLTAG;
	tag_t *ves=NULLTAG;
	tag_t *attachments1 = NULLTAG;
	tag_t *OptionValue=NULLTAG;
	tag_t *option_revs=NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *bvs = NULLTAG, *bvrs = NULLTAG;
	tag_t *tags_found = NULLTAG;
	tag_t *tags_found1 = NULLTAG;
	tag_t *tags_found3 = NULLTAG;
	tag_t *ref_instancesTemp = NULLTAG;
	tag_t *ref_instances = NULLTAG;
	tag_t *ref_classes = NULLTAG;
	tag_t *VCReviseCtrObj = NULLTAG;
	//tag_t *BUntrlObjectTag = NULLTAG;

	tag_t **variant_rule_list= NULLTAG;

	tag_t rev = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t view_type = NULLTAG;
	tag_t item = NULLTAG;
	tag_t bom_view	= NULLTAG;
	tag_t bom_view_type	=NULLTAG;
	tag_t e_block = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t bom_window = NULLTAG;
	tag_t window2 = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t top_line1 = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t Childobject = NULLTAG;
	tag_t Childobject1 = NULLTAG;
	tag_t Childobject3 = NULLTAG;
	tag_t Childobject4 = NULLTAG;
	tag_t Childobject33 = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t *bom_variant_rule = NULLTAG;
	tag_t option1 = NULLTAG;
	tag_t option2 = NULLTAG;
	tag_t toggle_ve = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t v1 = NULLTAG;
	tag_t primary = NULLTAG;
	//const tag_t *primary1 = NULLTAG;
	tag_t primary1 = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t tRelationExist1 = NULLTAG;
	tag_t tRelationExist2 = NULLTAG;
	tag_t tRelationExist3 = NULLTAG;
	tag_t tRelationExist4 = NULLTAG;
	tag_t item1 = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t option = NULLTAG;
	tag_t option_rev = NULLTAG;
	tag_t objTypeTagDi=NULLTAG;
	tag_t objTypeTagDi1=NULLTAG;
	tag_t opt_tag=NULLTAG;
	tag_t master_tag=NULLTAG;
	tag_t Itemmaster_tag=NULLTAG;
	tag_t relation_dep = NULLTAG;
	tag_t ConfigCtx = NULLTAG;
	tag_t ConfigCtxObjTypeTag = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	tag_t v2 = NULLTAG;
	tag_t toggle_option=NULLTAG;
	tag_t owning_item = NULLTAG;
	tag_t VCrev = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t Itemrev = NULLTAG;
	tag_t ItemRev = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t RevNewSeqTag = NULLTAG;
	tag_t parent_master = NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t status2=NULLTAG;
	tag_t status3=NULLTAG;
	tag_t status4=NULLTAG;
	tag_t rev_type_tag = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t DMLRevTag = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t bv = NULLTAG, bvr = NULLTAG, parentBvr = NULLTAG, bv1 = NULLTAG, bvr1 = NULLTAG;
	tag_t Childrev = NULLTAG;
	tag_t user_tag =NULLTAG;
	tag_t cond_ve  = NULLTAG;
	tag_t loadif_ve = NULLTAG;
	tag_t veb = NULLTAG;
	tag_t attr_idDR = NULLTAG;
	tag_t class_id = NULLTAG;
	tag_t class_idr = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t top_bomline = NULLTAG;
	tag_t clause_list = NULLTAG;
	tag_t CtrObjVCReviseQryTag = NULLTAG;
	tag_t ArchTag = NULLTAG;
	tag_t ArchTagRev = NULLTAG;
	//tag_t BUqryTag = NULLTAG;

	logical list_changed=FALSE;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	logical modB=FALSE;

	void **option_data=NULL;

	variant_rule_option_data_t *variant_rule_option_data=NULL;
	variant_rule_option_data_t option_value_dictionary={NULL};

	GRM_relation_t *primary_list_Dep = NULLTAG;

	double mat[4][4];
	double divInt=1000;

	logical retain=false;
	logical is_latest ;
	logical lNull = false, lEmpty = false;
	logical log1 ;
	
	//char *BU_qry_entry[1] = {"SYSCD"};
	//char **BU_qry_values2 =  (char **) MEM_alloc(50 * sizeof(char *));
	//char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	//char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	char *VCReviseinfo1 =NULL;
	int VCReviseQryC=0;

	TempVal=(char *) MEM_alloc(1000);
	VCPltform1=(char *) MEM_alloc(100);
	DMLDRstatusStr=(char *) MEM_alloc(10);
	Arch_item_idStr=(char *) MEM_alloc(10);
//July2023
	int jk = 0;
	int jkk = 0;
	int iArcMdl = 0;
	int iManMOErrFlag = 0;
	int iManSODupFlag = 0;
	int iManSOFlag = 0;
	int MDL_n_entry2 = 2;
	int n_entry2 = 2;
	int iNManSODupFlag = 0;
	int MDL_n_entry3 = 2;
	int MDL_rsltCount2 = 0;
	int MDL_rsltCount3 = 0;
	int BU_n_entry = 1;
	int sManSQErrorFlag = 0;
	int sManSQFlag = 0;
	int sNManSQErrorFlag = 0;
	int sNManSQFlag = 0;
	int sManMQErrorFlag = 0;
	int sManMQFlag = 0;
	int BU_rsltCount = 0;
	int strcnt1=0;
	int strcnt3=0;
	int BOmvarcnt1=0;
	
	char   *DMLBUnit=NULL;
	char   *BUInfo1 = NULL;
	char   *BUInfo2 = NULL;
	char   *BUInfo3 = NULL;
	char   *VCPltform = NULL;
	char   *sMDLinofA1=NULL;
	char   *sMDLinofA2=NULL;
	char   *sMDLinofA3=NULL;
	char   *sMDLinofA4=NULL;
	char   *sMDLinofA5=NULL;
	char   *sMDLinofA6=NULL;
	char   *sMDLinofA7=NULL;
	char   *sMDLinofA8=NULL;
	char   *sMDLinofA9=NULL;
	char   *sMDLinofA10=NULL;
	char **	AStringList =NULL;
	char **	BStringList =NULL;
	char **	CStringList =NULL;
	char **	DStringList =NULL;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    *MDL_qry_entry2[2]  = {"SYSCD","SUBSYSCD"};
	char    *qry_entry2[2]  = {"SYSCD","Information-1"};
	char    *MDL_qry_entry3[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry4[2]  = {"SYSCD","SUBSYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values3     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values4     =  (char **) MEM_alloc(50 * sizeof(char *));
	char *CVObjtyp=NULL;
	char *CVObjDesc=NULL;
	char *CVObjName=NULL;
	char *MDLAddress =NULL;
	tag_t CVrev = NULLTAG;
	tag_t BUqryTag = NULLTAG;
	tag_t CVview_type = NULLTAG;
	tag_t CVitem = NULLTAG;
	tag_t *CVbom_views = NULLTAG;
	tag_t CVbom_view	= NULLTAG;
	tag_t CVbom_window = NULLTAG;
	tag_t CVclose_tag = NULLTAG;
	tag_t CVrule = NULLTAG;
	tag_t *CVclosurerule = NULLTAG;
	tag_t *CVbom_variant_rule = NULLTAG;
	tag_t MdlObj=NULLTAG;
	tag_t CVobjTypeTag=NULLTAG;
	tag_t CVtop_line = NULLTAG;
	tag_t MdlQry_Tag = NULLTAG;
	tag_t MdlQry_Tag3 = NULLTAG;
	tag_t Qry_Tag = NULLTAG;
	tag_t *CVoptions = NULLTAG;
	tag_t *CVoption_revs=NULLTAG;
	tag_t *CVlines = NULLTAG;
	tag_t *MDL_Obj_Tag = NULLTAG;
	tag_t *Obj_Tag = NULLTAG;
	tag_t *MDL_Obj_Tag3 = NULLTAG;
	tag_t *BUntrlObjectTag = NULLTAG;
	int CVn_lines	= 0;
	int n_CVbom_views	= 0;
	int CVn_lines3= 0;
	int	piStringCount	= 0;
	int CVn_lines1= 0;
	int mdlcunt= 0;
	int Cv_entr= 0;
	int SVRFlag= 0;
	int CVrulefound= 0;
	int BOmvarcnt2= 0;
	int rsltCount2= 0;
	char **CVrulename = NULL;
	char **CVrulevalue = NULL;
	char* CVtype_name= NULL;

	char* sManMQMOSet = NULL ;
	char* CVVCPltform = NULL ;
	char* sManSQMOSet = NULL ;
	char* sNManSQMOSet = NULL ;
	char* sNManMQMOSet = NULL ;
	char* sCPModuleAvailErr = NULL ;
	char* OtherZeroQtySet = NULL ;
	char* inValidQtySet = NULL ;
	char* sNManSODupErr = NULL ;
	char* sManSODupErr = NULL ;
	char* sManSOErr = NULL ;
	char* sManMOErr = NULL ;
	char* sFinalErr = NULL ;
	char *BU_qry_entry[1] = {"SYSCD"};
	char **BU_qry_values2 =  (char **) MEM_alloc(50 * sizeof(char *));
	char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
	sManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sCPModuleAvailErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	OtherZeroQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
	inValidQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManMOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sFinalErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	tc_strcpy (sManMOErr,"" );
	tc_strcpy (sManMQMOSet,"" );
	tc_strcpy (sManSQMOSet,"" );
	tc_strcpy (sNManSQMOSet,"" );
	tc_strcpy (sNManMQMOSet,"" );
	//Error list
	tc_strcpy (sCPModuleAvailErr,"" );
	tc_strcpy (OtherZeroQtySet,"" );
	tc_strcpy (inValidQtySet,"" );
	tc_strcpy (sNManSODupErr,"" );
	tc_strcpy (sManSODupErr,"" );
	tc_strcpy (sManSOErr,"" );
	tc_strcpy (sFinalErr,"" );
	//July2023
	tc_strcpy(ERCRelErrStrng,"");
	tc_strcpy(DMLDRstatusStr,"");
	tc_strcpy(Arch_item_idStr,"");

	POM_get_user(&username,&user_tag);
	printf("\n---Starting for vc_release :[%s]------------------------------------\n",username);fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf(" vc_release--Target Attachment:%d\n",noAttachment);fflush(stdout);

	if(noAttachment > 0)
	{
	    DMLTag = attachments[0];

		CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&InpDMLTask));
		printf("\n\t vc_release--InpDMLTask: %s ",InpDMLTask);fflush(stdout);
	}

	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
	CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type1));

	if (tsk_dml_rel_type!=NULLTAG)
	{
		CALLAPI(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&count,&DMLRevision));
		printf("\n\t vc_release--DML Revision from Task for MR : %d",count);fflush(stdout);

		for( jy=0; jy<count; jy++ )
		{
			CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
			printf("\n\t vc_release--is_latest MR is : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\t vc_release--is_latest is not true .....\n");fflush(stdout);
			}
			else
			{
				DMLRevTag = DMLRevision[jy];

				CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
				CALLAPI(POM_name_of_class(class_id1,&class_name1));
				printf("\n\t vc_release--class_name: %s",class_name1);fflush(stdout);

				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
				CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo));
				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&DMLBUnit));
				printf("\t DMLNo------>:%s:DMLDRstatus------>:%s: DMLBUnit------>:%s: ",DMLNo,DMLDRstatus,DMLBUnit);fflush(stdout);

				tc_strcpy(DMLDRstatusStr,",");
				tc_strcat(DMLDRstatusStr,DMLDRstatus);
				tc_strcat(DMLDRstatusStr,",");

				DMLDRStrT=NULL;
				DMLSTVALUT=0;

				DMLDRStrT=subString(DMLDRstatus, 2, 1);
				printf("\n vc_release--DML DR status: DMLDRStrT: %s and ",DMLDRStrT);fflush(stdout);

				DMLSTVALUT=atoi(DMLDRStrT);
				printf(" DMLSTVALUT: %d  DMLDRstatusStr: [%s] \n",DMLSTVALUT,DMLDRstatusStr);fflush(stdout);
			}
		}
	}
	else
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,PLM_error,"DML Task Relation not found. Please raise ticket in TMS.");
		printf("\n vc_release--DML-Task Relation T5_DMLTaskRelation not found in TCUA ?? \n\n");fflush(stdout);
		return PLM_error;
	}

	if(relation_type != NULLTAG)
	{
		//AAA:Control Table
		//AAA: BU compair
		//Find validation which are not applicable to CV.
		if(QRY_find2("ControlObjects", &BUqryTag));
		if (BUqryTag)
		{
			printf("\n A0001:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n A0002:Not Found Query ControlObjects \n");fflush(stdout);
		}

		BU_qry_values2[0] = "VCDmlBU";
		if(QRY_execute(BUqryTag, BU_n_entry, BU_qry_entry, BU_qry_values2, &BU_rsltCount, &BUntrlObjectTag));
		printf(" \nA0003:BU_rsltCount :%d:", BU_rsltCount); fflush(stdout);
		if(BU_rsltCount > 0)
		{
			//ON/OFF
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo1",&BUInfo1)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo2",&BUInfo2)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo3",&BUInfo3)!=ITK_ok)   PrintErrorStack();  // Multi 
			printf("\n A0004:BUInfo1 is  = [%s]; BUInfo2 is  = [%s]",BUInfo1,BUInfo2);fflush(stdout);
		}
		CALLAPI(TCTYPE_ask_name2( relation_type,&relation_name));
		printf("\n vc_release--Relation-TypeName: [%s] ",relation_name);fflush(stdout);

		CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
		printf("\t ChangeReferences-atatched-object-counts: [%d] \n",cnt);fflush(stdout);

		for(i=0;i<cnt;i++)
		{
			printf("\n vc_release--A.i: [%d] to find impacted items ",i);fflush(stdout);

			rev1 = attachments1[i];

			if(AOM_ask_value_string(rev1,"object_type",&objecttype));
			if(AOM_ask_value_string(rev1,"object_name",&platformName));

			printf("\t objecttype: [%s]   platformName: [%s] ",objecttype,platformName);fflush(stdout);

			if (strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				primary1=rev1;
				//if(AOM_ask_value_string(rev1,"object_name",&VCPltform));
				//printf("\t --> Platform Found :VCPltform:%s  DMLBUnit:%s",VCPltform,DMLBUnit);fflush(stdout);
				printf("\t CV:DMLBUnit:%s",DMLBUnit);fflush(stdout);
				if (strcmp(DMLBUnit,"CVBU")==0)
				{
					if(AOM_ask_value_string(rev1,"object_name",&VCPltform));
					printf("\t CV:Platform Found :VCPltform:%s  DMLBUnit:%s",VCPltform,DMLBUnit);fflush(stdout);
					//Quesy control object 

					if(QRY_find2("Control Objects...", &Qry_Tag));
					if (Qry_Tag)
					{
						printf("\n CV_VC:P3:Found Query Qry_Tag \n");fflush(stdout);
					}
					else
					{
						printf("\n CV_VC:P4:Not Found Query Qry_Tag \n");fflush(stdout);
					}


					tc_strcpy (VCPltform1,"");
					tc_strcpy (VCPltform1,"*");
					
					tc_strcat (VCPltform1,VCPltform);
					printf ("\n CV_VC:72:VCPltform1 to check:[%s]. ",VCPltform1);fflush(stdout);

					qry_values2[0] = "PartPlatform";
					qry_values2[1] = VCPltform1;
					//MDL_qry_values2[1] = "MHCV";//hardcoded fro testing
					if(QRY_execute(Qry_Tag, n_entry2, qry_entry2, qry_values2, &rsltCount2, &Obj_Tag));
					printf(" \n CV_VC:P5:rsltCount2 :%d:", rsltCount2); fflush(stdout);
					if(rsltCount2 > 0)
					{
						if (AOM_ask_value_string(Obj_Tag[0],"t5_Userinfo1",&CVVCPltform)!=ITK_ok)   PrintErrorStack();
						printf(" \n CV_VC:P5:CVVCPltform :%d:", CVVCPltform); fflush(stdout);
					}
				}
				else
				{
					if(AOM_ask_value_string(rev1,"object_name",&VCPltform));
					printf("\t PV: Platform Found :VCPltform:%s  DMLBUnit:%s",VCPltform,DMLBUnit);fflush(stdout);
				}
				break;
			}
		}

		if (primary1 == NULLTAG)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Platform is not attached under DML Task Relation. Please raise ticket in TMS for support.");
			printf("\n vc_release--Platform is not attached under DML Task Relation ?? \n\n");fflush(stdout);
			return PLM_error;
		}
		/////////////////////
		//Put Logic here for (platform based modular BOM validation.
		if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
		{
			printf("\n CV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
			if(tc_strstr(BUInfo1,"A008")==NULL)
			{
				printf("\n CV_VC:P2:If moduler BOM then check mandatory module address, Duplication allowed in BOM. \n");fflush(stdout);													
				//Quering control tables for mandatory module address: Duplication allowed in BOM.
				if(QRY_find2("Control Objects...", &MdlQry_Tag));
				if (MdlQry_Tag)
				{
					printf("\n CV_VC:P3:Found Query MdlQry_Tag \n");fflush(stdout);
				}
				else
				{
					printf("\n CV_VC:P4:Not Found Query MdlQry_Tag \n");fflush(stdout);
				}

				MDL_qry_values2[0] = "MANDTE";
				MDL_qry_values2[1] = VCPltform;
				//MDL_qry_values2[1] = "MHCV";//hardcoded fro testing
				if(QRY_execute(MdlQry_Tag, MDL_n_entry2, MDL_qry_entry2, MDL_qry_values2, &MDL_rsltCount2, &MDL_Obj_Tag));
				printf(" \n CV_VC:P5:MDL_rsltCount2 :%d:", MDL_rsltCount2); fflush(stdout);
				if(MDL_rsltCount2 > 0)
				{
					for(jk=0;jk<MDL_rsltCount2;jk++)
					{
						sMDLinofA1=NULL;
						sMDLinofA2=NULL;
						sMDLinofA3=NULL;
						sMDLinofA4=NULL;
						sMDLinofA5=NULL;
						sMDLinofA6=NULL;
						sMDLinofA7=NULL;
						sMDLinofA8=NULL;
						sMDLinofA9=NULL;
						sMDLinofA10=NULL;
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
						printf("\n CV_VC:P7:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
						printf("\n CV_VC:P8:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
						printf("\n CV_VC:P9:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
						printf("\n CV_VC:P10:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
						printf("\n CV_VC:P11:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
						printf("\n CV_VC:P12:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
						printf("\n CV_VC:P13:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
						printf("\n CV_VC:P14:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
						printf("\n CV_VC:P15:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
						printf("\n CV_VC:P16:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
						if(tc_strcmp(sMDLinofA1,"Multi")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA2);
								printf("\n CV_VC:P17:M2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA3);
								printf(" M3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA4);
								printf(" M4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA5);
								printf(" M5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA6);
								printf(" M6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA7);
								printf(" M7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA8);
								printf(" M8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA9);
								printf(" M9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA10);
								printf(" M10.");fflush(stdout);
							}
							printf("\n CV_VC:P18:sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
						}
						else if(tc_strcmp(sMDLinofA1,"Single")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA2);
								printf("\n CV_VC:P19:M2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA3);
								printf(" M3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA4);
								printf(" M4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA5);
								printf(" M5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA6);
								printf(" M6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA7);
								printf(" M7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA8);
								printf(" M8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA9);
								printf(" M9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA10);
								printf(" M10.");fflush(stdout);
							}
							printf("\n CV_VC:P20:sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
						}
						else
						{
							printf("\n CV_VC:P21:Other case....");fflush(stdout);
						}
					}
					printf("\n CV_VC:P22:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
					printf("\n CV_VC:P23:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
				}
				// checking for non mandatory module addresses.
				printf("\n CV_VC:P24:If moduler BOM then check mandatory module address.. \n");fflush(stdout);
				//Quering control tables for mandatory module address: Duplication allowed in BOM.
				if(QRY_find2("Control Objects...", &MdlQry_Tag3));
				if (MdlQry_Tag3)
				{
					printf("\n CV_VC:P25:Found Query MdlQry_Tag3 \n");fflush(stdout);
				}
				else
				{
					printf("\n CV_VC:P26:Not Found Query MdlQry_Tag3 \n");fflush(stdout);
				}

				MDL_qry_values3[0] = "NMANDTE";
				MDL_qry_values3[1] = VCPltform;
				//MDL_qry_values3[1] = "MHCV";//hardcoded for testing
				if(QRY_execute(MdlQry_Tag3, MDL_n_entry3, MDL_qry_entry3, MDL_qry_values3, &MDL_rsltCount3, &MDL_Obj_Tag3));
				printf("\n CV_VC:P27:MDL_rsltCount3 :%d:", MDL_rsltCount3); fflush(stdout);
				if(MDL_rsltCount3 > 0)
				{
					jk=0;
					for(jk=0;jk<MDL_rsltCount3;jk++)
					{
						sMDLinofA1=NULL;
						sMDLinofA2=NULL;
						sMDLinofA3=NULL;
						sMDLinofA4=NULL;
						sMDLinofA5=NULL;
						sMDLinofA6=NULL;
						sMDLinofA7=NULL;
						sMDLinofA8=NULL;
						sMDLinofA9=NULL;
						sMDLinofA10=NULL;
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
						printf("\n CV_VC:P28:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
						printf("\n CV_VC:P29:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
						printf("\n CV_VC:P30:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
						printf("\n CV_VC:P31:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
						printf("\n CV_VC:P32:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
						printf("\n CV_VC:P33:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
						printf("\n CV_VC:P34:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
						printf("\n CV_VC:P35:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
						printf("\n CV_VC:P36:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
						printf("\n CV_VC:P37:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
						if(tc_strcmp(sMDLinofA1,"Multi")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA2);
								printf("\n CV_VC:P38:S2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA3);
								printf(" S3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA4);
								printf(" S4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA5);
								printf(" S5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA6);
								printf(" S6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA7);
								printf(" S7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA8);
								printf(" S8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA9);
								printf(" S9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA10);
								printf(" S10.");fflush(stdout);
							}
							printf("\n CV_VC:P39:sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
						}
						else if(tc_strcmp(sMDLinofA1,"Single")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA2);
								printf("\n CV_VC::S2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA3);
								printf(" S3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA4);
								printf(" S4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA5);
								printf(" S5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA6);
								printf(" S6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA7);
								printf(" S7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA8);
								printf(" S8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA9);
								printf(" S9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA10);
								printf(" S10.");fflush(stdout);
							}
							printf("\n CV_VC:40:sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
						}
						else
						{
							printf("\n CV_VC:41:Other case....");fflush(stdout);
						}
					}
					printf("\n CV_VC:42:Final sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
					printf("\n CV_VC:43:Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
				}
			}
			if(tc_strstr(BUInfo1,"A005")==NULL)
			{
				for(jk=0;jk<cnt;jk++)
				{
					printf("\n CV_VC:44:jk: attachment no:[%d]",jk);fflush(stdout);
					CVrev = attachments1[jk];

					if(AOM_ask_value_string(CVrev,"object_type",&CVObjtyp));
					if(AOM_ask_value_string(CVrev,"object_name",&CVObjName));
					printf("\n CV_VC:46:CVObjtyp: [%s]  CVObjName: [%s] ",CVObjtyp,CVObjName);fflush(stdout);

					if (strcmp(CVObjtyp,"VariantRule")==0)
					{
						
						if(AOM_ask_value_string(CVrev,"object_desc",&CVObjDesc));
						printf( "\n CV_VC:47:CVObjDesc ",CVObjDesc); fflush(stdout);


						if ( primary1 !=NULLTAG )
						{
							CALLAPI ( PS_find_view_type( "view", &CVview_type ));
							if ( CVview_type != NULLTAG )
							{
								CALLAPI ( ITEM_ask_item_of_rev( primary1, &CVitem ));
								CALLAPI ( ITEM_list_bom_views( CVitem, &n_CVbom_views, &CVbom_views ));
								CVbom_view = CVbom_views[0];
							}
							else
							{
								printf("\n CV_VC:48:View not found check.......\n"); fflush(stdout);
							}
						}

						if ( CVbom_view != NULLTAG )
						{
							printf("\n CV_VC:49:before BOM_create_window..\n");	fflush(stdout);

							CALLAPI ( BOM_create_window( &CVbom_window ));
							CALLAPI(CFM_find( "Latest Working", &CVrule ))
							CALLAPI(BOM_set_window_config_rule( CVbom_window, CVrule ));
							CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &CVrulefound, &CVclosurerule ));
							printf ("\n CV_VC:50:CVrule count %d \n",CVrulefound);fflush(stdout);
							if (CVrulefound > 0)
							{
								CVclose_tag = CVclosurerule[0];
								printf ("\n CV_VC:51:.closure CVrule found \n");fflush(stdout);
							}
							CALLAPI(BOM_window_set_closure_rule( CVbom_window,CVclose_tag, 0, CVrulename,CVrulevalue ));
							CALLAPI(BOM_set_window_pack_all(CVbom_window, FALSE));
							CALLAPI(BOM_set_window_top_line( CVbom_window, NULLTAG, primary1, NULLTAG, &CVtop_line ));
							printf("\n CV_VC:52:After BOM_set_window_top_line..\n");fflush(stdout);
							//CALLAPI(BOM_window_ask_variant_rule( CVbom_window, &CVbom_variant_rule ));
							if ( BOM_window_ask_variant_rules( CVbom_window,&BOmvarcnt1,&CVbom_variant_rule ));
							printf("\n CV_VC:53:BOM_window_ask_variant_rule..\n");fflush(stdout);
							if(BOmvarcnt1>0)
                            {
							CALLAPI(TCTYPE_ask_object_type(CVbom_variant_rule[0],&CVobjTypeTag));
							CALLAPI(TCTYPE_ask_name2(CVobjTypeTag,&CVtype_name));
							CALLAPI ( ITEM_ask_rev_variants ( primary1, &e_block ));
							}
							printf("\n CV_VC:54:ITEM_ask_rev_variants..\n");fflush(stdout);

							if(CVtop_line!=NULLTAG)
							{
								if(tc_strstr(BUInfo1,"A006")!=NULL)
								{
									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines, &CVlines));
									printf("\n CV_VC:55.Before setting option CVn_lines: %d and Item_ID_str :%s\n", CVn_lines,Item_ID_str);

									CALLAPI(BOM_window_hide_unconfigured(CVbom_window));
									CALLAPI(BOM_window_show_variants(CVbom_window));
									printf("\n CV_VC:56:After inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_apply_variant_configuration(CVbom_window,1,&CVrev))   ;
									printf("\n CV_VC:57:After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
									//if(BOM_window_apply_overlay_variant_rules(CVbom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									CALLAPI(BOM_window_hide_variants(CVbom_window))   ;
									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines, &CVlines));
									printf("\n CV_VC:58:CVn_lines: [%d]  ",CVn_lines); fflush(stdout);
									//AAA:Need to check need for below loop
									if (CVn_lines >0)
									{
										structcount=0;
										for (jkk=0;jkk<CVn_lines ;jkk++ )
										{
											if(Childobject) Childobject=NULLTAG;

											Childobject=CVlines[jkk];

											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n CV_VC:59:-jkk: [%d]  child_item_id: %s",jkk,child_item_id); fflush(stdout);
											//printf("\n vc_release--jkk: [%d]  ",jkk); fflush(stdout);

											CALLAPI(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
											structcount++;
											tc_strcpy(childstr[jkk].parent_part,child_item_id);
											childstr[jkk].child=n_lines2;
											printf("\n CV_VC:60:Part no IS: %s  n_lines2: %d ",childstr[jkk].parent_part,childstr[jkk].child);fflush(stdout);
										}
									}
								}
							}
							else
							{
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure is not present under Platform. Please check and for any query, please raise ticket in TMS TCUA-DML.");
								printf("\n CV_VC:61:-Structure is not present under Platform in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
								return PLM_error;
							}

							CALLAPI(CFM_find( "ERC release and above", &CVrule ))
							CALLAPI(BOM_set_window_config_rule( CVbom_window, CVrule ));
							memset( &option_value_dictionary, 0, sizeof ( option_value_dictionary ) );

							if(BOmvarcnt1>0)
							{
							CALLAPI ( BOM_variant_rule_ask_options( CVbom_variant_rule[0], &Cv_entr, &CVoptions, &CVoption_revs ) )
							printf("\n CV_VC:62:No of Option values in the CVrule:%d\n",Cv_entr);fflush(stdout);
							}

							if ( CVtop_line!=NULLTAG )
							{
								printf("\n CV_VC:63:inside CVbom_window-----\n"); fflush(stdout);
								if(tc_strstr(BUInfo1,"V001")!=NULL)
								{
									printf("\n CV_VC:63: %s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() ); fflush(stdout);
									//AAA check??
									CALLAPI ( VOO_show_wso( primary1 )) ;
								}

								CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines1, &CVlines));
								printf("\n CV_VC:64:1.LLlast Before setting option CVn_lines1: %d \n", CVn_lines1);

								if(CVbom_window != NULLTAG)
								{
									printf("\n CV_VC:65:before inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_hide_unconfigured(CVbom_window))   ;
									CALLAPI(BOM_window_show_variants(CVbom_window))   ;
									printf("\n CV_VC:66:After inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_apply_variant_configuration(CVbom_window,1,&CVrev))   ;
									printf("\n CV_VC:67:After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

									//if(BOM_window_apply_overlay_variant_rules(CVbom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									CALLAPI(BOM_window_hide_variants(CVbom_window))   ;
									CALLAPI(BOM_window_ask_is_modified(CVbom_window,&modB))   ;
									if(modB)
									{
										printf("\n CV_VC:68:modified bom window\n"); fflush(stdout);
									}
									else
									{
										printf("\n CV_VC:69:not modified bom window\n"); fflush(stdout);
									}

									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines1, &CVlines));

									CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
									if(relation_dep != NULLTAG)
									{
										printf("\n\t CV_VC:70:Variant ConfigContext relation found......");	fflush(stdout);
									}
									//kept off
									if(tc_strstr(BUInfo1,"A007")!=NULL)
									{
										CALLAPI(GRM_list_secondary_objects_only(CVitem,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
										printf("\n\t Configuration Context count is : %d",countConfigCtx);

										if(countConfigCtx>0)
										{
											ConfigCtx=ConfigCtxSecObject[0];

											CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
											CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
											printf( "\n\t vc_release--Config relation Config_CtxType :%s ..",Config_CtxType);

											CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
											printf("\n\t vc_release--SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

											CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
											printf("\n\t vc_release--SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

											if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
											printf("\n\t vc_release--After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);

											if (queryTag != NULLTAG)
											{
												printf("\t vc_release--Found Query");fflush(stdout);
											}else
											{
												printf("\t vc_release--Not Found Query");fflush(stdout);
											}

											qry_values[0] = SmCrIDContext;

											if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
											printf("\n\t vc_release--resultCount : %d\n", resultCount); fflush(stdout);
										}
									}

									printf("\n CV_VC:68:2.LLlast Before setting option CVn_lines1: [%d] \n", CVn_lines1); fflush(stdout);

									EMH_clear_errors();

									if (CVn_lines1 >0)
									{
										if(tc_strstr(BUInfo1,"A009")==NULL)
										{
											//We got Arc module here, get the module address from it. and check in table w.r.t platform.
											//if single mandatory, then count CVn_lines3 should be 1.
											//if Multi mandatory, then count CVn_lines3 should >= 1.
											//if Single not mandatory, then count CVn_lines3 should be 1 or 0.
											//if Multi not mandatory, then count CVn_lines3 should be 1 or 0 or multi...no need check
											/////////////////////////////////////////////////////
											printf("\n CV_VC:P69:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A010")==NULL)
											{
												if((sManMQMOSet==NULL)|| (tc_strcmp(sManMQMOSet,"")==0))
												{
													printf("\n CV_VC:70:sManMQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sManMQMOSet,",",&piStringCount,&AStringList)!=ITK_ok)PrintErrorStack();
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:71:sManMQMOSet Part:%s ",AStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,AStringList[mdlcunt]);
														printf ("\n CV_VC:72:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:73:MDLAddress is NULL.\n");fflush(stdout);
														}
														else
														{
															sManMQFlag=0;
															sManMQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:74:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:75:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:76:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return PLM_error;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sManMQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if(CVn_lines3 >0)
																	{
																		printf("\n CV_VC:78:MDLAddress:[%s] is Multi Mandatory available. \n",MDLAddress);fflush(stdout);
																	}
																	else
																	{
																		sManMQErrorFlag=1;
																		printf("\n CV_VC:79:ERROR:MDLAddress:[%s] is Multi Mandatory not available:[%d] \n",MDLAddress,sManMQErrorFlag);fflush(stdout);																		
																	}
																	break;
																}
															}
															if ((sManMQFlag==0) ||(sManMQErrorFlag==1))
															{
																printf("\n CV_VC:80:sManMQ error.  \n");fflush(stdout);
																if((tc_strcmp(sManMOErr,"")==0) || (tc_strstr(sManMOErr,CVObjName)==NULL))
																{
																	if(tc_strcmp(sManMOErr,"")!=0)
																	{
																		tc_strcat(sManMOErr,"\n");
																	}
																	//tc_strcat(sManMOErr,"\n");
																	tc_strcat(sManMOErr,CVObjName);
																	tc_strcat(sManMOErr,": ");
																}

																if(tc_strstr(sManMOErr,MDLAddress)==NULL)
																{
																	iManMOErrFlag ++;
																	if ((iManMOErrFlag ==20)|| (iManMOErrFlag ==40)||(iManMOErrFlag ==60)||(iManMOErrFlag ==80))
																	{
																		tc_strcat(sManMOErr,"\n");
																	}
																	tc_strcat(sManMOErr,MDLAddress);
																	tc_strcat(sManMOErr,",");
																	printf("\n CV_VC:81:ManMO_module address [%s] added to error set.:[%s]",MDLAddress,sManMOErr);fflush(stdout);
																}
																else
																{
																	printf("\n CV_VC:82::Module address already added... [%s]",MDLAddress);fflush(stdout);
																}
															}
														}
													}
												}
											}
											printf("\n CV_VC:83:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A011")==NULL)
											{
												if((sManSQMOSet==NULL)|| (tc_strcmp(sManSQMOSet,"")==0))
												{
													printf("\n CV_VC:84:sManSQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sManSQMOSet,",",&piStringCount,&BStringList)!=ITK_ok)PrintErrorStack();
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:85:sManSQMOSet Part:[%s]",BStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,BStringList[mdlcunt]);
														printf ("\n CV_VC:86:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:87:MDLAddress is NULL..\n");fflush(stdout);
														}
														else
														{
															sManSQFlag=0;
															sManSQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:88:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:89:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:90:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return PLM_error;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sManSQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if(CVn_lines3 ==1)
																	{
																		printf("\n CV_VC:90:MDLAddress:[%s] is Single Mandatory available. \n",MDLAddress);fflush(stdout);
																	}
																	else if (CVn_lines3 >1)
																	{
																		//sManSQErrorFlag=1;
																		printf("\n CV_VC:91:ERROR:MDLAddress:[%s] is Single Mandatory not available, but Duplicated. \n",MDLAddress);fflush(stdout);
																		if((tc_strcmp(sManSODupErr,"")==0) || (tc_strstr(sManSODupErr,CVObjName)==NULL))
																		{
																			tc_strcat(sManSODupErr,CVObjName);
																			tc_strcat(sManSODupErr,": ");
																		}

																		if(tc_strstr(sManSODupErr,MDLAddress)==NULL)
																		{
																			iManSODupFlag ++;
																			if ((iManSODupFlag ==20)|| (iManSODupFlag ==40)||(iManSODupFlag ==60)||(iManSODupFlag ==80))
																			{
																				tc_strcat(sManSODupErr,"\n");
																			}
																			tc_strcat(sManSODupErr,MDLAddress);
																			tc_strcat(sManSODupErr,",");
																			printf("\n CV_VC:92:Dup ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSODupErr);fflush(stdout);
																		}
																		else
																		{
																			printf("\n CV_VC:93:MOdule address already added..: [%s]",MDLAddress);fflush(stdout);
																		}
																	}
																	else if(CVn_lines3 ==0)
																	{
																		sManSQErrorFlag=1;
																		printf("\n CV_VC:94:ERROR:MDLAddress:[%s] is Single Mandatory not available:[%d] \n",MDLAddress,sManSQErrorFlag);fflush(stdout);
																	}
																	break;
																}
															}
															if ((sManSQFlag==0)||(sManSQErrorFlag ==1))
															{
																printf("\n CV_VC:95:Arc Module address not avaialble..- [%s]",MDLAddress);fflush(stdout);
																//Add to mandatory error set.
																if((tc_strcmp(sManSOErr,"")==0) || (tc_strstr(sManSOErr,CVObjName)==NULL))
																{
																	tc_strcat(sManSOErr,CVObjName);
																	tc_strcat(sManSOErr,": ");
																}

																if(tc_strstr(sManSOErr,MDLAddress)==NULL)
																{
																	iManSOFlag ++;
																	if ((iManSOFlag ==20)|| (iManSOFlag ==40)||(iManSOFlag ==60)||(iManSOFlag ==80))
																	{
																		tc_strcat(sManSOErr,"\n");
																	}
																	tc_strcat(sManSOErr,MDLAddress);
																	tc_strcat(sManSOErr,",");
																	printf("\n CV_VC:96:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSOErr);fflush(stdout);
																}
																else
																{
																	printf("\n CV_VC:97:Module address already added..- [%s]",MDLAddress);fflush(stdout);
																}
															}
														}
													}
												}
											}
											printf("\n CV_VC:98::Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A012")==NULL)
											{
												if((sNManSQMOSet==NULL)|| (tc_strcmp(sNManSQMOSet,"")==0))
												{
													printf("\n CV_VC:99:sNManSQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sNManSQMOSet,",",&piStringCount,&DStringList)!=ITK_ok)PrintErrorStack();
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:A1:sNManSQMOSet Part:[%s]",DStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,DStringList[mdlcunt]);
														printf ("\n CV_VC:A2:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:A3:MDLAddress is NULL..\n");fflush(stdout);
														}
														else
														{
															sNManSQFlag=0;
															sNManSQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:A4:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:A5:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:A6:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return PLM_error;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sNManSQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if((CVn_lines3 ==1)||(CVn_lines3 ==0))
																	{
																		printf("\n CV_VC:A7:MDLAddress:[%s] no need to check non mandatory single. \n",MDLAddress);fflush(stdout);
																	}
																	else
																	{
																		sNManSQErrorFlag=1;
																		printf("\n CV_VC:A8:ERROR:MDLAddress:[%s] non mandatory single only allowed:[%d] \n",MDLAddress,sNManSQErrorFlag);fflush(stdout);
																		if((tc_strcmp(sNManSODupErr,"")==0) || (tc_strstr(sNManSODupErr,CVObjName)==NULL))
																		{
																			//tc_strcat(sNManSODupErr,"\n");
																			tc_strcat(sNManSODupErr,CVObjName);
																			tc_strcat(sNManSODupErr,": ");
																		}
																		if(tc_strstr(sNManSODupErr,MDLAddress)==NULL)
																		{
																			iNManSODupFlag ++;
																			if ((iNManSODupFlag ==20)|| (iNManSODupFlag ==40)||(iNManSODupFlag ==60)||(iNManSODupFlag ==80))
																			{
																				tc_strcat(sNManSODupErr,"\n");
																			}
																			tc_strcat(sNManSODupErr,MDLAddress);
																			tc_strcat(sNManSODupErr,",");
																			printf("\n CV_VC:A10:Non Mandatory single occurance, but duplicated.%s added to error set.:[%s]",MDLAddress,sNManSODupErr);fflush(stdout);
																		}
																	}
																	break;
																}
															}
															if ((sNManSQFlag==0)||(sNManSQErrorFlag==1))
															{
																printf("\n CV_VC:A9:Arc Module address not avaialble..- [%s]",MDLAddress);fflush(stdout);
															}
														}
													}
												}
											}
											printf("\n CV_VC:A11::Final:SKIP sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
										}
									}
								}
								else
								{
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
									printf("\n CV_VC:A12:Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
									return PLM_error;
								}
							}
						}
						if(tc_strstr(BUInfo1,"A019") == NULL)
						{
							printf("\n CV_VC:A13: closing BOM window..\n");fflush(stdout);
							CALLAPI(BOM_save_window(CVbom_window))
							CALLAPI(BOM_close_window(CVbom_window))
						}
					}
				}
				printf("\n CV_VC:A14:Final:sManMOErr:[%s] \n",sManMOErr);fflush(stdout);
				printf("\n CV_VC:A15:Final:sManSOErr:[%s] \n",sManSOErr);fflush(stdout);
				printf("\n CV_VC:A16:Final:sManSODupErr:[%s] \n",sManSODupErr);fflush(stdout);
				printf("\n CV_VC:A17:Final:sNManSODupErr:[%s] \n",sNManSODupErr);fflush(stdout);
				if(tc_strstr(BUInfo1,"A014") == NULL)
				{
					if(tc_strcmp(sManMOErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Below are mandatory module addresses, please check SVR. (ManMQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManMOErr);
					}
				}
				if(tc_strstr(BUInfo1,"A015") == NULL)
				{
					if(tc_strcmp(sManSOErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Below are mandatory module addresses, please check SVR. (ManSQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManSOErr);
					}
				}
				if(tc_strstr(BUInfo1,"A016") == NULL)
				{
					if(tc_strcmp(sManSODupErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Modules are duplicated for below module addresses, please check SVR. (NManSQDup)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManSODupErr);
					}
				}
				if(tc_strstr(BUInfo1,"A017") == NULL)
				{
					if(tc_strcmp(sNManSODupErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Modules for below module addresses are duplicated, please remove duplication. (NManSQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sNManSODupErr);
					}
				}
				if(tc_strstr(BUInfo1,"A018") == NULL)
				{
					if (tc_strlen(sFinalErr) > 0)
					{
						printf("\n CV_VC:A18:Final Error:::[%s] \n",sFinalErr);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,PLM_error,"Please find the below BOM error.\nPlease correct it and process. ",sFinalErr);
						return PLM_error;
					}
					else
					{
						printf("\n CV_VC:A19:Final:NO Error...........\n");fflush(stdout);
					}
				}
			}
		}
		printf("\n CV_VC:A20:GOING TO MAIN CODE NOW...\n");fflush(stdout);
		int vcissue = 0;
		for(j=0;j<cnt;j++)
		{
			printf("\n\n vc_release--B.j: [%d] to find impacted items ",j);fflush(stdout);

			rev = attachments1[j];

			if(AOM_ask_value_string(rev,"object_type",&objecttype));
			if(AOM_ask_value_string(rev,"object_name",&objectname));

			printf("\t objecttype: [%s]  objectname: [%s] ",objecttype,objectname);fflush(stdout);

			if (strcmp(objecttype,"VariantRule")==0)
			{
				SVRFlag=0;
				if(tc_strstr(BUInfo1,"A020")==NULL)
				{
					if(tc_strstr(BUInfo1,"B001")==NULL)
					{
						printf("\n Checking VC availability Starting");fflush(stdout);
						int nTskCnt = 0;
						int tscount = 0;
						char *VCnm = NULL;
						char *seq = NULL;
						char *VRRev = NULL;
						char *VCname = NULL;
						VCnm =  (char *) MEM_alloc(10 * sizeof(char));
						seq =  (char *) MEM_alloc(10 * sizeof(char));
						VRRev =  (char *) MEM_alloc(10 * sizeof(char));
						char *VCRevG = NULL;
						int Child_Rev_count=0;
						tag_t VCtag = NULLTAG;
						tag_t VCTagLt = NULLTAG;
						tag_t part2tsk_rel_typ = NULLTAG;
						tag_t relation_type_tag = NULLTAG;
						tag_t *Child_rev_list = NULLTAG;
						tag_t *techspec_objects = NULLTAG;
						tag_t *VCTask = NULLTAG;

						tc_strtok(objectname, "_");
						VRRev = tc_strtok(NULL, "_");
						strncpy(VCnm,objectname,8);
						//VRRev=tc_strtok(NULL, ";");
						tc_strcat(VCnm,"R");
						printf( "\n ChkVCfrmSVRAvail:VC Name created from SVR is [%s] & rev is [%s] BUInfo1:[%s]",VCnm,VRRev,BUInfo1); fflush(stdout);
						///////
						tag_t rev_tag = NULLTAG;
						tag_t Child_All_Rev = NULLTAG;
						tag_t objTypTag = NULLTAG;
						char*   ObjTyp= NULL;
						if(tc_strcmp(VRRev,"NR")!=0)
						{
							Child_All_Rev= t5GetItemRevison(VCnm);
							if(Child_All_Rev==NULLTAG)
							{
								printf("\n ChkVCfrmSVRAvail:Child_All_Rev is NULL.\n");fflush(stdout);
							}
							else
							{
								if(ITEM_ask_latest_rev(Child_All_Rev, &rev_tag)!=ITK_ok)PrintErrorStack();

								if(TCTYPE_ask_object_type(rev_tag,&objTypTag));
								if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
								printf("\n ChkVCfrmSVRAvail: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
								
								if (rev_tag != NULLTAG)
								{
									if(AOM_UIF_ask_value(rev_tag,"item_revision_id",&VCRevG));
									printf( "\n ChkVCfrmSVRAvail: VCRevG [%s]",VCRevG); fflush(stdout);
									seq=tc_strtok(VCRevG, ";");
									printf( "\n ChkVCfrmSVRAvail:VCRevG Found and which is [%s] & seq is[%s]",VCRevG,seq); fflush(stdout);
									printf( "\n ChkVCfrmSVRAvail:VC seq is [%s] & VRRev is [%s]",seq,VRRev); fflush(stdout);
									if (tc_strcmp(seq,VRRev)==0)
									{
										printf( "\n ChkVCfrmSVRAvail:VC Revision is already present is system."); fflush(stdout);
										//Check VC is attached to task or not. if not give error.
										if(tc_strstr(BUInfo1,"B003")==NULL)
										{
											if(GRM_find_relation_type("CMHasSolutionItem", &part2tsk_rel_typ)!=ITK_ok)PrintErrorStack();
											if (part2tsk_rel_typ!=NULLTAG)
											{
												printf("\n ChkVCfrmSVRAvail--> for part2tsk_rel_typ.");fflush(stdout);
												if(GRM_list_primary_objects_only(rev_tag,part2tsk_rel_typ,&nTskCnt,&VCTask)!=ITK_ok)PrintErrorStack();
												printf("\n ChkVCfrmSVRAvail: for nTskCnt:%d.",nTskCnt);fflush(stdout);
												if (nTskCnt == 0)
												{
													//VC not attached to task
													printf("\n ChkVCfrmSVRAvail-->ERROR: VC not attached to task.");fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
													printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
													return PLM_error;
												}
												else
												{
													SVRFlag=1;
													printf("\n ChkVCfrmSVRAvail-->PASS: VC is attached to task.:SVRFlag:%d",SVRFlag);fflush(stdout);
													//return 1;
												}
											}
										}
										else
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
											printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
											return PLM_error;
										}
									}
									else
									{
										printf("\n ChkVCfrmSVRAvail: Sequese of [%s] is not found",VRRev);fflush(stdout);
										if(tc_strstr(BUInfo1,"B002")==NULL)
										{
											GRM_find_relation_type("T5_VCSpec", &relation_type_tag);
											GRM_list_secondary_objects_only(rev_tag,relation_type_tag,&tscount,&techspec_objects);
											if (tscount == 0)
											{
												printf( "\n ChkVCfrmSVRAvail:Previous VC Revision is not having Tech Spec attached to it."); fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest Released VC Revision is not having Tech Spec attached to it. Kindly raise ticket in TMS ");
												printf("\n ChkVCfrmSVRAvail::Latest Released VC Revision is not having Tech Spec attached to it.\n");fflush(stdout);
												return PLM_error;
											}
										}
									}
								}
								else
								{	
									printf( "\n ChkVCfrmSVRAvail:Latest VC Re Tag not found.[%s]",VCnm); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest VC revision not found created, Kindly raise ticket in TMS");
									printf("\n Latest VC Revision not found for Creation, Kindly raise ticket in TMS\n");fflush(stdout);
									return PLM_error;
								}
							}
						}
						else
						{
							printf("\n SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
							Child_All_Rev= t5GetItemRevison(VCnm);
							if(Child_All_Rev !=NULLTAG)
							{
								printf("\n ChkVCfrmSVRAvail:Child_All_Rev is Not NULL of NR SVR. VC Revision is already present is system.\n");fflush(stdout);
								if(tc_strstr(BUInfo1,"B004")==NULL)
								{
									if(GRM_find_relation_type("CMHasSolutionItem", &part2tsk_rel_typ)!=ITK_ok)PrintErrorStack();
									if (part2tsk_rel_typ!=NULLTAG)
									{
										printf("\n ChkVCfrmSVRAvail--> for part2tsk_rel_typ.");fflush(stdout);
										if(GRM_list_primary_objects_only(Child_All_Rev,part2tsk_rel_typ,&nTskCnt,&VCTask)!=ITK_ok)PrintErrorStack();
										printf("\n ChkVCfrmSVRAvail--> for nTskCnt:%d.",nTskCnt);fflush(stdout);
										if (nTskCnt == 0)
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
											printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
											return PLM_error;	
										}
										else
										{
											SVRFlag =1;
											printf("\n ChkVCfrmSVRAvail: NR VC is attached to task.SVRFlag:%d\n",SVRFlag);fflush(stdout);
											//return 1;
										}
									}
								}
							}
							else
							{
								printf("\nNeed not to check present VC in system, SVR Rev is NR: [%s]",VRRev);fflush(stdout);
							}
						}
						printf("\ncalling ChkVCfrmSVRAvail fun Completed vcissue [%d]",vcissue);fflush(stdout);
					}
					else
					{
						printf("\ncalling ChkVCfrmSVR fun Starting");fflush(stdout);
						vcissue = ChkVCfrmSVR(objectname);
						printf("\ncalling ChkVCfrmSVR fun Completed vcissue [%d]",vcissue);fflush(stdout);
						if (vcissue != 0)
						{
							SVRFlag=1;
							printf("\ncheck vcissue [%d]",vcissue);fflush(stdout);
							return PLM_error;
						}
					}
				}
				printf("\nCheck SVRFlag [%d]",SVRFlag);fflush(stdout);
				if(SVRFlag ==0)
				{
					printf("\nVcpresentcheck Sucessfull...continue to next check");fflush(stdout);
					if(AOM_ask_value_string(rev,"object_desc",&objectdesc));
					strcpy(TempVal,objectname);

					printf( " ----INside platform "); fflush(stdout);

					if ( primary1 !=NULLTAG )
					{
						CALLAPI ( PS_find_view_type( "view", &view_type ));
						//printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
							CALLAPI ( ITEM_ask_item_of_rev( primary1, &item ));
							CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							bom_view = bom_views[0];
						}
						else
							printf("\n vc_release--1.View not found check.......\n"); fflush(stdout);
					}

					if ( bom_view != NULLTAG )
					{
						printf(" vc_release--1.before BOM_create_window..\n");	fflush(stdout);

						CALLAPI ( BOM_create_window( &bom_window ));
						//CALLAPI(CFM_find( "ERC release and above", &rule ))
						CALLAPI(CFM_find( "Latest Working", &rule ))
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
						CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

						printf ("- vc_release--1.rule count %d \n",rulefound);fflush(stdout);

						if (rulefound > 0)
						{
							close_tag = closurerule[0];
							printf (" vc_release--1.closure rule found \n");fflush(stdout);
							// MEM_free(tags_found);
						}

						CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

						CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
						CALLAPI(BOM_set_window_top_line( bom_window, NULLTAG, primary1, NULLTAG, &top_line ));
						printf(" vc_release--1.After BOM_set_window_top_line..\n");fflush(stdout);

						//CALLAPI(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
						if ( BOM_window_ask_variant_rules( bom_window,&BOmvarcnt2,&bom_variant_rule ));
						printf(" vc_release--1.BOM_window_ask_variant_rule..\n");fflush(stdout);

                        if(BOmvarcnt2>0)
						{
						CALLAPI(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
						CALLAPI(TCTYPE_ask_name2(objTypeTag,&type_name));
						}

						CALLAPI ( ITEM_ask_rev_variants ( primary1, &e_block ));
						printf(" vc_release--1.ITEM_ask_rev_variants..\n");fflush(stdout);

						if(top_line!=NULLTAG)
						{
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
							printf("\n vc_release--1.Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);

							CALLAPI(BOM_window_hide_unconfigured(bom_window));
							CALLAPI(BOM_window_show_variants(bom_window));

							//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
							//if(BOM_variant_config_apply (bom_variant_config))   ;

							//if(BOM_variant_rule_apply(primary1))   ;
							printf("\n vc_release--1.After inside bom_window-----\n"); fflush(stdout);
							CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
							printf("\n vc_release--1.After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

							//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
							CALLAPI(BOM_window_hide_variants(bom_window))   ;

							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
							printf("\n vc_release--n_lines: [%d]  ",n_lines); fflush(stdout);

							if (n_lines >0)
							{
								structcount=0;
								for (p1=0;p1<n_lines ;p1++ )
								{
									if(Childobject) Childobject=NULLTAG;

									Childobject=lines[p1];

									CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
									//printf("\n vc_release--p1: [%d]  child_item_id: %s",p1,child_item_id); fflush(stdout);
									printf("\n vc_release--p1: [%d]  ",p1); fflush(stdout);

									CALLAPI(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));

									//printf("\tBOM-n_lines2 : %d",n_lines2);fflush(stdout);

									structcount++;

									tc_strcpy(childstr[p1].parent_part,child_item_id);
									childstr[p1].child=n_lines2;
									printf("\t Part no IS: %s  n_lines2: %d ",childstr[p1].parent_part,childstr[p1].child);fflush(stdout);

									//ITK ( VOO_show_wso( Childobject ));
								}
							}
						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure is not present under Platform. Please raise ticket in TMS TCUA-DML.");
							printf("\n vc_release--Structure is not present under Platform in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
							return PLM_error;
						}

						//start
						CALLAPI(CFM_find( "ERC release and above", &rule ))
						//CALLAPI(CFM_find( "Latest Working", &rule ))
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));

						memset( &option_value_dictionary, 0, sizeof ( option_value_dictionary ) );

						CALLAPI ( BOM_variant_rule_ask_options( bom_variant_rule[0], &v_entr, &options, &option_revs ) )
						printf("\n vc_release--No of Option values in the rule:%d\n",v_entr);fflush(stdout);

						if ( top_line!=NULLTAG )
						{
							printf("\n vc_release--%s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() ); fflush(stdout);

							fprintf( stderr, "\n print rev first .\n");
							CALLAPI ( VOO_show_wso( primary1 )) ;

							// CALLAPI ( ITEM_find_item( ItemId, &master_tag ));
							fprintf(stderr, "\n print Master second .\n");

							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
							printf("\n vc_release--1.LLlast Before setting option n_lines1: %d \n", n_lines1);

							if(bom_window != NULLTAG)
							{
								printf("\n vc_release--before inside bom_window-----\n"); fflush(stdout);
								CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
								CALLAPI(BOM_window_show_variants(bom_window))   ;
								//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
								//if(BOM_variant_config_apply (bom_variant_config))   ;

								//if(BOM_variant_rule_apply(primary1))   ;
								printf("\n vc_release--After inside bom_window-----\n"); fflush(stdout);
								CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
								printf("\n vc_release--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

								//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
								CALLAPI(BOM_window_hide_variants(bom_window))   ;
								CALLAPI(BOM_window_ask_is_modified(bom_window,&modB))   ;
								if(modB)
								{
									fprintf( stderr, "\n vc_release--modified bom window:..\n");fflush(stdout);
								}
								else
								{
									fprintf( stderr, "\n vc_release--not modfiifed ..\n");fflush(stdout);
								}

								CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

								CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
								if(relation_dep != NULLTAG)
								{
									printf("\n\t vc_release--Variant ConfigContext relation found......");	fflush(stdout);
								}

								CALLAPI(GRM_list_secondary_objects_only(item,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
								printf("\n\t vc_release--Configuration Context count is : %d",countConfigCtx);

								if(countConfigCtx>0)
								{
									ConfigCtx=ConfigCtxSecObject[0];

									CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
									CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
									printf( "\n\t vc_release--Config relation Config_CtxType :%s ..",Config_CtxType);

									CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
									printf("\n\t vc_release--SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

									CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
									printf("\n\t vc_release--SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

									if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
									printf("\n\t vc_release--After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);

									if (queryTag != NULLTAG)
									{
										printf("\t vc_release--Found Query");fflush(stdout);
									}else
									{
										printf("\t vc_release--Not Found Query");fflush(stdout);
									}

									qry_values[0] = SmCrIDContext;

									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
									printf("\n\t vc_release--resultCount : %d\n", resultCount); fflush(stdout);
								}

								printf("\n vc_release--2.LLlast Before setting option n_lines1: [%d] mulmodule is start..[%s] \n", n_lines1,MulModule); fflush(stdout);

								EMH_clear_errors();

								tag_t CtrObjArchQryTag = NULLTAG;
								tag_t CtrObjT3Z01Tag = NULLTAG;
								tag_t CtrObjBypassTag = NULLTAG;

								tag_t *ArchNodeCtrObj = NULLTAG;
								tag_t *T3Z01CtrObj = NULLTAG;
								tag_t *BypassCtrObj = NULLTAG;

								char *QryEntry[2] = {"SYSCD","SUBSYSCD"};
								char *QryEntry3[3] = {"SYSCD","SUBSYSCD","Information-1"};

								char **ArchrNodeyEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
								char **BypassEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
								char **T3Z01EntryValue = (char **) MEM_alloc(50 * sizeof(char *));

								char *CtrlInfo11 =NULL;
								char *CtrlInfo22 =NULL;
								char *CtrlInfo33 =NULL;
								char *strinfo1 =NULL;
								char *strinfo2 =NULL;
								char *strinfo3 =NULL;
								char *strinfo4 =NULL;
								char *strinfo6 =NULL;
								char *BypassInfo1 =NULL;
								char *BypassInfo2 =NULL;

								int ArchNodeQryC = 0, BypassCtrlCnt=0, ModuleAvailFlag=0, info7T3Z01Found=0, ReplacemntModT3Z01Cnt=0;
								int CtrlQryCnt=0,  BypassFlag=0;

								CALLAPI(QRY_find2("Control Objects...", &CtrObjArchQryTag));

								if (CtrObjArchQryTag != NULLTAG)
								{
									printf("\n vc_release--CtrObjArchQryTag Found... "); fflush(stdout);

									ArchrNodeyEntryValue[0] = "AltrozArchNode"; //SYSCD
									ArchrNodeyEntryValue[1] = "AltrozArchNode"; //SUBSYSCD
									CALLAPI(QRY_execute(CtrObjArchQryTag, 2, QryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-1... "); fflush(stdout);

									T3Z01EntryValue[0] = "BaseT3Z01Alternate"; //SYSCD
									T3Z01EntryValue[1] = "AlternateModInVeh";  //SUBSYSCD
									CALLAPI(QRY_execute(CtrObjArchQryTag, 2, QryEntry, T3Z01EntryValue, &CtrlQryCnt, &T3Z01CtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-2... "); fflush(stdout);

									BypassEntryValue[0] = "ercbypass";	//SYSCD=ercbypass
									BypassEntryValue[1] = DMLNo;		//SUBSYSCD=dmlno
									BypassEntryValue[2] = objectname;	//Information-1=SVR_number
									CALLAPI(QRY_execute(CtrObjArchQryTag, 3, QryEntry3, BypassEntryValue, &BypassCtrlCnt, &BypassCtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-3... "); fflush(stdout);
								}

								printf("\n vc_release--Control Object CtrlQryCnt:--> [%d] ",CtrlQryCnt); fflush(stdout);

								if(CtrlQryCnt>0)
								{
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo1",&CtrlInfo11));
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo2",&CtrlInfo22));
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo3",&CtrlInfo33));

									printf("\n vc_release--BaseT3Z01Alternate, T3Z01-Info1=> [%s] ",CtrlInfo11); fflush(stdout);
									printf("\n vc_release--BaseT3Z01Alternate, Alternate-Addresses-Info2=> [%s] ",CtrlInfo22); fflush(stdout);
									printf("\n vc_release--BaseT3Z01Alternate, CtrlInfo33=> [%s] ",CtrlInfo33); fflush(stdout);

								}

								printf("\n vc_release--Control Object AltrozArchNode count:--> [%d] ",ArchNodeQryC); fflush(stdout);

								if(ArchNodeQryC>0)
								{
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6));

									printf("\n vc_release--AltrozArchNode, DR-Info6=> [%s] ",strinfo6); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info1=> [%s] ",strinfo1); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info2=> [%s] ",strinfo2); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info3=> [%s] ",strinfo3); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info4=> [%s] ",strinfo4); fflush(stdout);
								}

								printf("\n vc_release--Control Object BypassCtrlCnt:--> [%d] ",BypassCtrlCnt); fflush(stdout);
								if(BypassCtrlCnt>0)
								{
									CALLAPI(AOM_ask_value_string(BypassCtrObj[0],"t5_Userinfo1",&BypassInfo1)); //VC or SVR_no
									CALLAPI(AOM_ask_value_string(BypassCtrObj[0],"t5_Userinfo2",&BypassInfo2)); //Module addresses

									printf("\n vc_release--ercbypass, BypassInfo1=> [%s] ",BypassInfo1); fflush(stdout);
									printf("\n vc_release--ercbypass, BypassInfo2=> [%s] ",BypassInfo2); fflush(stdout);
								}

								if (n_lines1 >0)
								{
									//MulModule = (char *)MEM_alloc (1024 * sizeof(char));
									tc_strcpy(MulModule,"");
									tc_strcpy(NoModule,"");
									tc_strcpy(T3Z01NoModule,"");
									tc_strcpy(NoAlternateModule,"");
									tc_strcpy(RevMisMatch,"");

									info7T3Z01Found=0;
									ReplacemntModT3Z01Cnt=0;

									for (p3=0;p3<n_lines1 ;p3++ )
									{
										if(Childobject1) Childobject1=NULLTAG;

										Childobject1=lines[p3];

										CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
										CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
										//fprintf( stderr, " child_item_id ..:%s\n",child_item_id);

										CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
										if (ArchTag != NULLTAG)
										{
											CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
										}

										CALLAPI(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

										printf("\n\n vc_release--p3: [%d] Arch: [%s]-->ModuleCnt:[%d] ArchName:[%s] ArchModule:[%s]",p3,child_item_id1,n_lines3,sModuleName,sArchModule);fflush(stdout);
										printf(" child_item_no=[%d]\n",n_lines3);fflush(stdout);

										if (n_lines3 >0)
										{
											for (p34=0;p34<n_lines3 ;p34++ )
											{
												if(Childobject33) Childobject33=NULLTAG;

												Childobject33=lines3[p34];

												CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
												//CALLAPI(BOM_line_look_up_attribute ("bl_rev_last_release_status",&IntAtr5));
												//CALLAPI(BOM_line_ask_attribute_string(Childobject33, IntAtr5, &child_bl_formula23));
												
												if( AOM_ask_displayable_values(Childobject33,"bl_rev_last_release_status",&strcnt1,&child_bl_formula23))PrintErrorStack();

												if((tc_strstr(child_bl_formula23[0],"ERC Released")==NULL) || (tc_strstr(child_bl_formula23[0],"T5_LcsErcRlzd")==NULL) )
												{
													fprintf( stderr, "\n 1.Valid release status \n");
													//Function call for platform based moduler BOM validation.
												}
												else
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_error,ITK_errErr1,"These ",child_item_id15," does not have ERC Released status");

													printf("\n  vc_release--These [%s] does not have ERC Released status.... hence skipping..\n",child_item_id15);fflush(stdout);
													printf("\n ---------------------A.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

													return ITK_errErr1;
												}

												if (p34>0)
												{
													if (tc_strcmp(MulChild,child_item_id15)==0)
													{
														tc_strcpy(MulChild,"");
														tc_strcat(MulChild,child_item_id15);
														continue;
													}
													else
													{
														errorflag2=errorflag2+1;
														break;
													}
												}

												tc_strcpy(MulChild,"");
												tc_strcat(MulChild,child_item_id15);

												printf("\n  vc_release--p34: [%d]---inside diff child: [%s] \n",p34,MulChild);fflush(stdout);

												//CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
												//CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

												//Checking DR-validation for Modules:start.
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design_t5_RevPartType", &Obj_PrtTyp));
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_ProjectCode", &PrtProjj));
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_PartStatus", &PrtDRstus));
												printf("\n Part: %s type: %s project: %s PrtDRstus: %s DML DR: %s Relstatus: %s",child_item_id15,Obj_PrtTyp,PrtProjj,PrtDRstus,DMLDRstatus,child_bl_formula23[0]);fflush(stdout);

												PRTDRStr=NULL;
												PRTSTVALU=0;

												PRTDRStr=subString(PrtDRstus, 2, 1);
												printf("\n vc_release--B.Part DR status: PRTDRStr: %s",PRTDRStr);fflush(stdout);

												PRTSTVALU=atoi(PRTDRStr);
												printf(" \t PRTSTVALU: %d ",PRTSTVALU);fflush(stdout);

												if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
												{
													printf("\t vc_release--B.Skipping dummy part: %s ",child_item_id15);fflush(stdout);
												}
												else
												{
													printf("\n In else---vc_release--B.GMD---");fflush(stdout);

													DRstusFlag=0;
													DRstusFlag = ChkFrstLvlModuleDRstus(child_item_id15,DMLSTVALUT);

													printf("\n vc_release--B.GMD::DRstusFlag: %d",DRstusFlag);fflush(stdout);

													if (DRstusFlag >0)
													{
														printf("\n vc_release--B.GMD::Released module part is OKKK.:%s ", child_item_id15);fflush(stdout);
													}
													else
													{
														//ADD PART NUMBER3.
														if ((add==10)||(add==20)||(add==30)||(add==40)||(add==50)||(add==60)||(add==70)||(add==80)||(add==90)||(add==100))
														{
															tc_strcat(ERCRelErrStrng,"\n");
														}
														tc_strcat(ERCRelErrStrng,child_item_id15);
														tc_strcat(ERCRelErrStrng,",");

														add++;

														printf("\n vc_release--B.Rel module part added to ERCRelErrStrng:%d:%s ",add, child_item_id15);fflush(stdout);
													}
												}
												//Checking DR-validation for Modules:start.
											}

											if(tc_strcmp(ERCRelErrStrng,"")!=0)
											{
												printf("\n vc_release--B.DR:ERRORRR.:%s", ERCRelErrStrng);fflush(stdout);
												if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
												{
													printf("\n CVBU_VC:P1:Function call for DR-status validation"); fflush(stdout);
													if(tc_strstr(BUInfo3,"P001")==NULL)
													{
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"CVBU:Below mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision.\n",ERCRelErrStrng);

														printf("\n vc_release--B.Mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision==[%s] \n ",ERCRelErrStrng);fflush(stdout);
														printf("\n ---------------------C.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

														return ITK_err;
													}
												}
												else
												{
													if(tc_strstr(BUInfo3,"P001")==NULL)
													{
														printf("\n PVBU_VC:P2:Function call for DR-status validation."); fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"PVBU:Below mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision.\n",ERCRelErrStrng);

														printf("\n vc_release--B.Mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision==[%s] \n ",ERCRelErrStrng);fflush(stdout);
														printf("\n ---------------------C.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

														return ITK_err;
													}
												}
											}
										}

										//if (n_lines3 > 1)
										if ( (n_lines3>1) &&
											 ((tc_strstr(sModuleName,"TYRE RIM")==NULL) &&(tc_strstr(sArchModule,"TYRE RIM")==NULL))
										   )
										{
											printf("\n vc_release--B.mulmodule is before: %s child_item_id1: %s  ",MulModule,child_item_id1);fflush(stdout);

											tc_strcat(MulModule,"[");
											tc_strcat(MulModule,child_item_id1);
											tc_strcat(MulModule,"]");
											tc_strcat(MulModule,",");
											errorflag=errorflag+1;
											printf("\n vc_release--C......show error for mul....%d   mulmodule: %s  ",n_lines3,MulModule);fflush(stdout);
											//tc_strcpy(Fresh,MulModule);
											//printf("\n.....Fresh is after..%s\n",Fresh);fflush(stdout);
										}

										if((CtrlInfo11!=NULL)&&(sModuleAdrr!=NULL)&&(tc_strstr(CtrlInfo11,sModuleAdrr) != NULL)&&(n_lines3>0))
										{
											info7T3Z01Found=info7T3Z01Found+1;

											printf("\n\n\t sModuleAdrr:[%s]--info7T3Z01 module Found in BOM..[%d]",sModuleAdrr,n_lines3);fflush(stdout);
										}

										if (n_lines3 == 0)
										{
											ModuleAvailFlag=0;

											printf(" DMLDR: [%s] Arch-len: [%d] ",DMLDRstatusStr,tc_strlen(Arch_item_id));fflush(stdout);

											if (Arch_item_id!=NULL)
											{
												Arch_item_idStr=malloc(20);
												tc_strcpy(Arch_item_idStr,subString(Arch_item_id, tc_strlen(Arch_item_id)-6, tc_strlen(Arch_item_id)-1 ) ); //6=length of module address

												printf(" Arch_item_idStr: [%s]  sModuleAdrr:[%s] ",Arch_item_idStr,sModuleAdrr);fflush(stdout);

												///Module not from CtrlInfo11 and available in strinfo1 to strinfo4 only
												if((tc_strstr(CtrlInfo11,Arch_item_idStr) == NULL) && (
												   ((strinfo1 != NULL)&&(tc_strstr(strinfo1,Arch_item_idStr) != NULL)) ||
												   ((strinfo2 != NULL)&&(tc_strstr(strinfo2,Arch_item_idStr) != NULL)) ||
												   ((strinfo3 != NULL)&&(tc_strstr(strinfo3,Arch_item_idStr) != NULL)) ||
												   ((strinfo4 != NULL)&&(tc_strstr(strinfo4,Arch_item_idStr) != NULL))
												  ))
												{
													printf("\t--Found in control-Object ");fflush(stdout);
													ModuleAvailFlag=ModuleAvailFlag+1;
												}

												if ((info7T3Z01Found==0) && (tc_strstr(strinfo6,DMLDRstatusStr)!=NULL))
												{
													if ((CtrlInfo22 != NULL)&&(tc_strstr(CtrlInfo22,Arch_item_idStr) != NULL))
													{
														ReplacemntModT3Z01Cnt=ReplacemntModT3Z01Cnt+1;

														tc_strcat(T3Z01NoModule,Arch_item_idStr);
														tc_strcat(T3Z01NoModule,",");
													}
												}
												else if (info7T3Z01Found>0)
												{
													printf("\n\t vc_release--R......T3Z01 Found Found--- ");fflush(stdout);

													tc_strcpy(T3Z01NoModule,"");
													ReplacemntModT3Z01Cnt=0;
												}
											}

											printf("  ModuleAvailFlag: [%d]  info7T3Z01Found: [%d]  ReplacemntModT3Z01Cnt: [%d] ",ModuleAvailFlag,info7T3Z01Found,ReplacemntModT3Z01Cnt);fflush(stdout);

											if ((tc_strstr(strinfo6,DMLDRstatusStr)!=NULL)&&(ModuleAvailFlag>0)&&(DMLDRstatusStr != NULL)&&(strinfo6 != NULL))
											{
												BypassFlag=0;

												printf("\n vc_release-->1.BypassCtrlCnt: [%d] [%s]=[%s] [%s]==>",BypassCtrlCnt,objectname,BypassInfo1,BypassInfo2); fflush(stdout);

												if( (BypassCtrlCnt>0) &&
													((BypassInfo1 != NULL)&&(tc_strstr(objectname,BypassInfo1) != NULL))&&
													((BypassInfo2 != NULL)&&(tc_strstr(BypassInfo2,Arch_item_idStr) != NULL))
												)
												{
													BypassFlag=BypassFlag+1;
												}

												printf(" BypassFlag: [%d] ",BypassFlag);fflush(stdout);

												if (BypassFlag==0)
												{
													tc_strcat(NoModule,"[");
													tc_strcat(NoModule,Arch_item_id);
													tc_strcat(NoModule,"]");
													tc_strcat(NoModule,",");

													errorflag1=errorflag1+1;
													printf("\nvc_release--D......show error....for no mul....%d",n_lines3);fflush(stdout);
												}
											}
										}
										//ITK ( VOO_show_wso( Childobject ));
									}

									printf("\nvc_release--errorflag1:[%d]  errorflag:[%d]  errorflag2:[%d]  errorflag34:[%d]  info7T3Z01Found: [%d]",errorflag1,errorflag,errorflag2,errorflag34,info7T3Z01Found);fflush(stdout);

									if (errorflag1>0)
									{
										printf("\nvc_release--2.....show error....");fflush(stdout);

										tc_strcat(NoModule,"-->");
										tc_strcat(NoModule,objectname); //objectname=SVRName

										printf("\n vc_release--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModule);fflush(stdout);
										printf("\n ---------------------F.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										if ((CtrlInfo33 != NULL) && (tc_strstr(CtrlInfo33,"ON")!=NULL))
										{
											if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
											{
												printf("\n PV_VC:P2:Function call for platform based moduler BOM validation.."); fflush(stdout);
												if(tc_strstr(BUInfo3,"P002")==NULL)
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_information,ITK_errErr,"CVBU: No module is present under **",NoModule," please verify the SVR.");
													return ITK_Prjerr;
												}
											}
											else
											{
												printf("\n PV_VC:P2:Function call for platform based moduler BOM validation.."); fflush(stdout);
												if(tc_strstr(BUInfo3,"P002")==NULL)
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_information,ITK_errErr,"PVBU: No module is present under **",NoModule," please verify the SVR.");
													return ITK_Prjerr;
												}
											}
										}
										else
										{
											printf("\n vc_release--1.No mandatory module present under ---Skipping valiadtion....???? \n\n");fflush(stdout);
										}
									}
									if ((info7T3Z01Found==0)&&(tc_strstr(strinfo6,DMLDRstatusStr)!=NULL))
									{
										printf("\nvc_release--3--T3Z01.....show error....tc_strlen(T3Z01NoModule): [%d] ReplacemntModT3Z01Cnt: [%d]  T3Z01NoModule: [%s]",tc_strlen(T3Z01NoModule),ReplacemntModT3Z01Cnt,T3Z01NoModule);fflush(stdout);

										if ((tc_strlen(T3Z01NoModule)>0)&&(ReplacemntModT3Z01Cnt>0))
										{
											if (BypassCtrlCnt>0)
											{
												printf("\n vc_release-->2.BypassCtrlCnt: [%d] [%s]=[%s] BypassInfo2:[%s]==>",BypassCtrlCnt,objectname,BypassInfo1,BypassInfo2); fflush(stdout);

												tc_strcpy(NoAlternateModule,"");

												char *tokenStr = strtok(T3Z01NoModule, ",");

												while (tokenStr != NULL)
												{
													BypassFlag=0;

													printf("\n   Tokenized--info8==tokenStr: [%s] ",tokenStr); fflush(stdout);

													if( ((BypassInfo1 != NULL)&&(tc_strstr(objectname,BypassInfo1) != NULL))&&
														((BypassInfo2 != NULL)&&(tc_strstr(BypassInfo2,tokenStr) != NULL))
													  )
													{
														BypassFlag=BypassFlag+1;
													}

													printf(" BypassFlag= [%d] ",BypassFlag);fflush(stdout);

													if (BypassFlag==0)
													{
														//if(tc_strstr(CtrlInfo22,tokenStr)==NULL)
														//{
															tc_strcat(NoAlternateModule,tokenStr);
															tc_strcat(NoAlternateModule,"; ");
														//}
													}

													tokenStr = strtok(NULL, ",");
												}
											}
											else
											{
												tc_strcpy(NoAlternateModule,T3Z01NoModule);
											}

											printf("\n vc_release--R......show error....for [%d] CtrlInfo33: [%s] NoAlternateModule: [%s] ",tc_strlen(NoAlternateModule),CtrlInfo33,NoAlternateModule); fflush(stdout);

											if (tc_strlen(NoAlternateModule)>0)
											{
												tc_strcat(NoAlternateModule,"-->");
												tc_strcat(NoAlternateModule,objectname); //objectname=SVRName

												printf("\n vc_release--1.No Alternate Modules of T3Z01 present under ** [%s], please verify the SVR.\n ",NoAlternateModule);fflush(stdout);
												printf("\n ---------------------R.vc_release function ended with above data error---------------------\n");fflush(stdout);

												if ((CtrlInfo33 != NULL) && (tc_strstr(CtrlInfo33,"ON")!=NULL))
												{
													if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
													{
														printf("\n CV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
														if(tc_strstr(BUInfo3,"P003")==NULL)
														{
															EMH_clear_errors();
															EMH_store_error_s3(EMH_severity_information,ITK_errErr,"CVBU:No Replacevment Modules of T3Z01 is present under **",NoAlternateModule," please verify the SVR.");
															return ITK_Prjerr;
														}
													}
													else
													{
														printf("\n PV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
														if(tc_strstr(BUInfo3,"P003")==NULL)
														{
															EMH_clear_errors();
															EMH_store_error_s3(EMH_severity_information,ITK_errErr,"PVBU: No Replacevment Modules of T3Z01 is present under **",NoAlternateModule," please verify the SVR.");
															return ITK_Prjerr;
														}
													}
												}
												else
												{
													printf("\n vc_release--1.No Replacevment Modules of T3Z01 ---Skipping valiadtion....???? \n\n");fflush(stdout);
												}
											}
										}
									}
									//if ((errorflag>0) && (errorflag1>0) && (errorflag2>0))
									else if ((errorflag>0) && (errorflag2>0))
									{
										printf("\n vc_release--B.....child_item_id1 show error....length :%d and value : %s ",tc_strlen(child_item_id1),child_item_id1);fflush(stdout);
										printf("\n vc_release--B.....show error....length :%d and value : %s ",tc_strlen(MulModule),MulModule);fflush(stdout);
										MulModule[1899] = '\0';
										//printf("\n.....show error....length :%d and value fresh : %s",tc_strlen(Fresh),Fresh);fflush(stdout);
										if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
										{
											printf("\n CV_VC:P4:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P004")==NULL)
											{
												EMH_clear_errors();
												EMH_store_initial_error_s3(EMH_severity_error,ITK_Prjerr,"CVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
										else
										{
											printf("\n PV_VC:P1:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P004")==NULL)
											{
												EMH_clear_errors();
												EMH_store_initial_error_s3(EMH_severity_error,ITK_Prjerr,"PVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
		
									}
									if ((errorflag>0) && (errorflag1==0))
									{
										printf("\nvc_release--1.....show error....");fflush(stdout);
										if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
										{
											printf("\n CV_VC:P5:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P005")==NULL)
											{
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"CVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
										else
										{
											printf("\n PV_VC:P5:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P005")==NULL)
											{
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"PVBU: More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}

										printf("\n vc_release--1.More than One module is present under [%s]  please correct the SVR.\n ",MulModule);fflush(stdout);
										printf("\n ---------------------E.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										//EMH_store_error_s3(EMH_severity_error,ITK_errErr,"No module is present under ",NoModule," please verify the SVR");
										//return ITK_errErr;

									}
									//if ((errorflag==0) && (errorflag1>0))
									//{
									//	printf("\nvc_release--2.....show error....");fflush(stdout);
									//	EMH_clear_errors();
									//	//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
									//	EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No module is present under **",NoModule," please verify the SVR");
									//
									//	printf("\n vc_release--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModule);fflush(stdout);
									//	printf("\n ---------------------F.vc_release function ended with above data error---------------------\n\n");fflush(stdout);
									//	//return ITK_errErr;
									//	//return ITK_Prjerr;
									//}
									if ((errorflag34>0) && ((tc_strcmp(DMLDRstatus,"DR3")==0) || (tc_strcmp(DMLDRstatus,"DR4")==0) || (tc_strcmp(DMLDRstatus,"DR5")==0)))
									{
										printf("\nvc_release--3.....show error....");fflush(stdout);
										EMH_clear_errors();
										//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
										//EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No released module is present under ",RevMisMatch," please verify the SVR");

										printf("\n ---------------------G.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										//return ITK_errErr;
										//return ITK_Prjerr;
									}
								}
							}
							else
							{
								fprintf( stderr, "\n vc_release--B.no bom window found here \n");
								if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
								{
									printf("\n PV_VC:P1:Function call for Structure not found validation.."); fflush(stdout);
									if(tc_strstr(BUInfo3,"P006")==NULL)
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
										printf("\n vc_release--Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
										return PLM_error;
									}
								}
								else
								{
									printf("\n PV_VC:P1:Function call for Structure not found validation.."); fflush(stdout);
									if(tc_strstr(BUInfo3,"P006")==NULL)
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
										printf("\n vc_release--Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
										return PLM_error;
									}
								}
							}

							//break;
						} //end of condn if(top_line!=NULLTAG)
					} //end of condn if ( bom_view != NULLTAG )

					errorflag4=0;

					printf("\n\n vc_release--VCItemId := %s ---------------------------->", TempVal); fflush(stdout);

					VehName=(char *) MEM_alloc(20);

					itemId12 = tc_strtok(TempVal,"_");
					RevId=tc_strtok(NULL,"_");

					itemId123=subString(itemId12,0,8);
					itemId1234=subString(itemId12,0,4);
					itemId12345=subString(itemId12,11,1);

					tc_strcpy(VehName,"");
					tc_strcpy(VehName,itemId123);
					tc_strcat(VehName,itemId12345);

					printf("\n vc_release--itemId12: [%s]  ritemId1234: [%s] ",itemId12,itemId1234); fflush(stdout);
					//printf("\n rev_type_tag Tag Found.");

					const char **attrs = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **values = (const char **) MEM_alloc(2 * sizeof(char *));

					attrs[0] ="item_id";
					attrs[1] ="object_type";

					values[0] = (char *)itemId12;
					values[1] = "Design";

					CALLAPI(ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found));

					MEM_free(attrs);
					MEM_free(values);

					printf( "\n vc_release--VC found count: %d ",n_tags_found); fflush(stdout);

					//CALLAPI(ITEM_find_item(itemId12, &parent_master1))

					if (n_tags_found == 0)
					{
						errorflag4=errorflag4+1;
					}
					printf( "\t errorflag4: %d ",errorflag4); fflush(stdout);

					if (errorflag4>0)
					{
						TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
						if(rev_type_tag!= NULLTAG)
						{
							printf("\n vc_release--1.rev_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
						AOM_set_value_string(rev_create_input_tag, "object_name", itemId12);
						AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234));
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","VC"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VC"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));
						//AAA:t5_PartPlatform onlly for CV
						if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
						{
							printf("\n Setting platform for CVBU VC..."); fflush(stdout);
							if(tc_strstr(BUInfo1,"A001")==NULL)
							{
								//Get Platform... AAA: need to work
								//Set platform

								if (strcmp(DMLBUnit,"CVBU")==0)
								{
									//CVVCPltform
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",CVVCPltform));
									printf("\n Setting platform for CVBU VC... done"); fflush(stdout);
								}
								else
								{
								
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
									printf("\n Setting platform for PVBU VC... done"); fflush(stdout);
								}
							}
						}

						// Construct a CreateInput object for Item
						TCTYPE_find_type("Design", NULL, &item_type_tag);
						if(item_type_tag!= NULLTAG)
						{
							printf("\n vc_release--1.item_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

						AOM_set_value_string(item_create_input_tag, "item_id", itemId12);
						AOM_set_value_string(item_create_input_tag, "object_name", itemId12);
						AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

						//Create Design Object and Design Revision
						TCTYPE_create_object(item_create_input_tag, &parent_master1);
						if(parent_master1 != NULLTAG)
						{
							printf("\n vc_release--1.Design Revision created."); fflush(stdout);

							AOM_save_without_extensions(parent_master1);
						}

						CALLAPI ( ITEM_ask_latest_rev( parent_master1, &ItemRev ));
						CALLAPI(AOM_lock(parent_master1));
						CALLAPI(AOM_lock(ItemRev));

						CALLAPI(AOM_save_without_extensions(ItemRev));
						CALLAPI(AOM_unlock(ItemRev));
						AOM_unlock(parent_master1);

						//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
						//printf("\n release status find.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status2,1,&ItemRev,retain));

						printf("\n vc_release--1.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev,"Y"));

						printf("\n vc_release--1.before project assign.");fflush(stdout);
						CALLAPI(AssignProject_vc_rel(ItemRev,itemId1234));//change Shubham
						printf("\n vc_release--1.after project assign.");fflush(stdout);

						CALLAPI(ITEM_list_bom_views(parent_master1,&bv_count, &bvs))

						CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master1,&bv1 ));
						CALLAPI(AOM_save_without_extensions( bv1 ))
						CALLAPI( AOM_save_without_extensions( parent_master1 ))
						CALLAPI( AOM_unlock( parent_master1 ))
						fprintf( stderr, "\n inside PS_create_bom_view..\n");

						CALLAPI(PS_create_bvr( bv1, "", "", false, ItemRev,&bvr1) )
						if(bvr !=NULLTAG)
						{
							CALLAPI( AOM_save_without_extensions( bvr1) )
							CALLAPI (AOM_save_without_extensions( ItemRev ))
							CALLAPI( AOM_unlock( ItemRev ))
							fprintf( stderr, "\n inside  PS_create_bvr..\n");
						}

						printf("\n\t vc_release--1.VC not found loop..........");fflush(stdout); fflush(stdout);
					}

					const char **attrs1 = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **values1 = (const char **) MEM_alloc(2 * sizeof(char *));

					attrs1[0] ="item_id";
					attrs1[1] ="object_type";

					values1[0] = (char *)VehName;
					values1[1] = "Design";

					CALLAPI(ITEM_find_items_by_key_attributes(2,attrs1, values1, &n_tags_found1, &tags_found1));

					MEM_free(attrs1);
					MEM_free(values1);

					//CALLAPI(ITEM_find_item(VehName, &parent_master))
					printf( "\n vc_release--1.parent_master found..........."); fflush(stdout);
					printf( "\n vc_release--1.parent master count  [%d] \n",n_tags_found1); fflush(stdout);

					//if(parent_master !=NULLTAG)
					if (n_tags_found1 == 1)
					{
						parent_master = tags_found1[0];

						CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))

						printf( "\n vc_release--1.bv_count :%d:.. ",bv_count); fflush(stdout);

						CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
						CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

						if (status_count > 0)  // No Status, so the Item is not yet Released
						{
							for(ss=0; ss<status_count ; ss++)
							{
								CALLAPI(AOM_ask_value_string(status_list[0],"object_name",&CurrentRelStatus));
								printf("\n vc_release--CurrentRelStatus: %s ",CurrentRelStatus);fflush(stdout);

								if((tc_strstr(CurrentRelStatus,"ERC Released")==NULL) || (tc_strstr(CurrentRelStatus,"T5_LcsErcRlzd")==NULL) )
								{
									CALLAPI(QRY_find2("Control Objects...", &CtrObjVCReviseQryTag));

									VCReviseEntryValue[0] = "DmlVCRevise";	//SYSCD
									VCReviseEntryValue[1] = "ON";			//SUBSYSCD

									CALLAPI(QRY_execute(CtrObjVCReviseQryTag, 2, VCReviseQryEntry, VCReviseEntryValue, &VCReviseQryC, &VCReviseCtrObj));
									printf("\n vc_release--Control Object AltrozVCRevise count:--> [%d] ",VCReviseQryC); fflush(stdout);

									if(VCReviseQryC>0)
									{
										CALLAPI(AOM_ask_value_string(VCReviseCtrObj[0],"t5_Userinfo1",&VCReviseinfo1));

										tc_strcpy(command,"");
										tc_strcpy(command,VCReviseinfo1);
										tc_strcat(command," ");
										tc_strcat(command,DMLNo);
										tc_strcat(command," ");
										tc_strcat(command,VehName);

										printf("\n vc_release--:command: %s",command);fflush(stdout);

										TC_write_syslog("vc_release--Command = %s\n",command);
										system(command);

										CALLAPI(ITEM_ask_latest_rev(parent_master, &RevNewSeqTag ));
										if (RevNewSeqTag!=NULLTAG)
										{
											printf("\n vc_release--:RevNewSeqTag Found.. ");fflush(stdout);

											CALLAPI(AOM_UIF_ask_value(RevNewSeqTag, "release_status_list", &latest_rev_Rel_Stus));
											printf("\n vc_release--:latest_rev_Rel_Stus: [%s] ",latest_rev_Rel_Stus);fflush(stdout);

											CALLAPI(WSOM_ask_release_status_list(RevNewSeqTag,&NewRevstatus_count,&NewRevstatus_list));

											printf("\n vc_release--:NewRevstatus_count: [%d] ",NewRevstatus_count);fflush(stdout);
											if (NewRevstatus_count > 0)  // No Status, so the Item is not yet Released
											{
												for(ss2=0; ss2<NewRevstatus_count ; ss2++)
												{
													CALLAPI(AOM_ask_value_string(NewRevstatus_list[ss2],"object_name",&NewRevRelStatus));
													printf("\n vc_release--NewRevRelStatus: %s ",NewRevRelStatus);fflush(stdout);

													if((tc_strstr(NewRevRelStatus,"ERC Released")!=NULL) || (tc_strstr(NewRevRelStatus,"T5_LcsErcRlzd")!=NULL) )
													{
														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,PLM_error,"Unable to Revise Vehicle for SVR attached under DML. Please raise ticket in TMS.");
														printf("\n vc_release--Unable to Revise Vehicle for SVR attached under DML ?? \n\n");fflush(stdout);
														return PLM_error;
													}
												}
											}
										}
									}
									else
									{
										CALLAPI(ITEM_copy_rev(VCrev,NULL,&RevNewSeqTag));
									}
									//t5removeAllReleaseStatus (RevNewSeqTag);

									printf("\n vc_release--2.Before UpdateAllowForm call "); fflush(stdout);
									CALLAPI(UpdateAllowForm(RevNewSeqTag,"Y"));
									CALLAPI(AssignProject_vc_rel(RevNewSeqTag,itemId1234));

									CALLAPI(AOM_lock( RevNewSeqTag ));
									CALLAPI ( AOM_set_value_string(RevNewSeqTag,"t5_PartStatus",DMLDRstatus));
									CALLAPI ( AOM_set_value_string(RevNewSeqTag, "object_desc", objectdesc));
									CALLAPI(AOM_save_without_extensions( RevNewSeqTag) )
									CALLAPI(AOM_refresh(RevNewSeqTag,1));
									CALLAPI(AOM_unlock(RevNewSeqTag));

									//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
									//printf("\n release status find.");fflush(stdout);
									//CALLAPI(RELSTAT_add_release_status(status2,1,&RevNewSeqTag,retain));

									if (bv_count)
									{
										bv = bvs[0];
										MEM_free(bvs);
									}else
									{
										CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
										CALLAPI(AOM_save_without_extensions( bv ))
										CALLAPI( AOM_save_without_extensions( parent_master ))
										CALLAPI( AOM_unlock( parent_master ))
										printf(  "\n vc_release--1.inside PS_create_bom_view..\n"); fflush(stdout);
									}

									fprintf( stderr, "\n ITEM_ask_latest_rev.........\n");

									CALLAPI ( VOO_show_wso( RevNewSeqTag ) )
									CALLAPI(ITEM_rev_list_bom_view_revs(RevNewSeqTag,&bvr_count, &bvrs))
									printf("\n vc_release--1.bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);

									if (bvr_count > 0)
									{
										bvr = bvrs[0];

										CALLAPI(AOM_lock( bvr ));

										CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
										printf("\n vc_release--A.Found....n_occs: [%d] \n",n_occs); fflush(stdout);

										for (iy = 0; iy<n_occs; iy++)
										{
											CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
										}

										/*
										CALLAPI(POM_class_of_instance (bvr,&class_idr));
										CALLAPI(POM_unload_instances (1,&bvr));
										CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
										CALLAPI(POM_is_loaded(bvr,&log1));

										if(log1 == 1)
										{
											printf(" vc_release--A.Load Success \n"); fflush(stdout);
										}
										else
										{
											printf(" vc_release--A.Load Failure \n"); fflush(stdout);
										}

										CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
										printf("\n vc_release--A.Found....n_instances. FOR ITEM REVISION : [%d] \n",n_instances); fflush(stdout);

										for(iy=0;iy<n_instances;iy++)
										{
											CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));
											CALLAPI(POM_name_of_class (class_id,&class_name));

											if(strcmp(class_name,"PSOccurrence")==0 )
											{
												CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
												CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));

												printf("\n vc_release--A.CarViewMask [%s] [%d] \n",spcPrefName,lNull); fflush(stdout);

												if (lNull == 0)
												{
													printf("\n vc_release--A.=> If 1 \n"); fflush(stdout);

													if(strcmp(spcPrefName,"-12")==0 )
													{
														printf("\n vc_release--A.skiping for car mask indexx:: [%s] \n ",spcPrefName); fflush(stdout);
														//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
													}
													else
													{
														//printf("\n vc_release--A.=> Else 1 \n"); fflush(stdout);
														ref_instancesTemp = malloc( sizeof(1) );
														ref_instancesTemp[0]=ref_instances[iy];
														CALLAPI(POM_delete_instances(1,ref_instancesTemp));
														ref_instancesTemp = NULL;
													}
												}
												else
												{
													//printf("\n vc_release--A.=> Else 2 \n"); fflush(stdout);
													ref_instancesTemp = malloc( sizeof(1) );
													ref_instancesTemp[0]=ref_instances[iy];
													CALLAPI(POM_delete_instances(1,ref_instancesTemp));
													ref_instancesTemp = NULL;
												}
											}
										}
										//CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
										//if(bvr !=NULLTAG)
										//{
										//	CALLAPI( AOM_save_without_extensions( bvr) )
										//	CALLAPI (AOM_save_without_extensions( RevNewSeqTag ))
										//	CALLAPI( AOM_unlock( RevNewSeqTag ))
										//	fprintf( stderr, "\n inside  PS_create_bvr..\n");
										//}

										CALLAPI(POM_save_instances(1,&bvr,FALSE));
										*/

										CALLAPI( AOM_save_without_extensions( bvr) )
										CALLAPI(AOM_unlock(bvr));

										MEM_free(bvrs);
									}
									else
									{
										CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
										if(bvr !=NULLTAG)
										{
											CALLAPI(AOM_save_without_extensions( bvr) )
											CALLAPI(AOM_save_without_extensions( RevNewSeqTag ))
											CALLAPI(AOM_unlock( RevNewSeqTag ))
											printf("\n inside  PS_create_bvr.."); fflush(stdout);
										}
									}
									printf( "\n vc_release--1.After PS_create_bvr.."); fflush(stdout);

									break;
								}
								else
								{
									printf("\n CV-PV: Setting error.."); fflush(stdout);
									if(tc_strstr(BUInfo1,"A002")==NULL)
									{
										//AAA: conform error statement
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Found VC revision is not ERC Released. in \n Please raise ticket in TMS." );
										return ITK_Prjerr;
									}
									else
									{
										//Code will be OFFF, we will remove in next deplyment
										printf("\n vc_release--3.In Else Condn "); fflush(stdout);

										CALLAPI(ITEM_rev_list_bom_view_revs(VCrev,&bvr_count, &bvrs))
										//t5removeAllReleaseStatus (VCrev);

										printf("\n vc_release--3.Before UpdateAllowForm call "); fflush(stdout);
										CALLAPI(UpdateAllowForm(VCrev,"Y"));
										CALLAPI(AssignProject_vc_rel(VCrev,itemId1234));

										//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
										//printf("\n release status find.");fflush(stdout);
										//CALLAPI(RELSTAT_add_release_status(status2,1,&VCrev,retain));

										printf( "\n vc_release--3.bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);

										if (bvr_count > 0)
										{
											bvr = bvrs[0];

											CALLAPI(AOM_lock( bvr ));

											CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
											printf("\n vc_release--3.Found....n_occs: [%d] \n",n_occs); fflush(stdout);

											for (iy = 0; iy<n_occs; iy++)
											{
												CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
											}

											/*
											CALLAPI(POM_class_of_instance (bvr,&class_idr));
											CALLAPI(POM_unload_instances (1,&bvr));
											CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
											CALLAPI(POM_is_loaded(bvr,&log1));

											if(log1 == 1)
											{
												printf(" vc_release--B.Load Success \n"); fflush(stdout);
											}
											else
											{
												printf(" vc_release--B.Load Failure \n"); fflush(stdout);
											}

											CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
											printf("\n vc_release--B.Found....n_instances. FOR ITEM REVISION: [%d] \n",n_instances); fflush(stdout);

											for(iy=0;iy<n_instances;iy++)
											{
												CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));
												CALLAPI(POM_name_of_class (class_id,&class_name));

												if(strcmp(class_name,"PSOccurrence")==0 )
												{
													CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
													CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));

													printf("\n vc_release--B.CarViewMask [%s] [%d] \n",spcPrefName,lNull); fflush(stdout);

													if (lNull == 0)
													{
														printf("\n vc_release--B.=> If 1 \n"); fflush(stdout);

														if(strcmp(spcPrefName,"-12")==0 )
														{
															printf("\n vc_release--B.skiping for car mask indexx %s \n ",spcPrefName); fflush(stdout);
															//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
														}
														else
														{
															//printf("\n vc_release--B.=> Else 1 \n"); fflush(stdout);
															ref_instancesTemp = malloc( sizeof(1) );
															ref_instancesTemp[0]=ref_instances[iy];
															CALLAPI(POM_delete_instances(1,ref_instancesTemp));
															ref_instancesTemp = NULL;
														}
													}
													else
													{
														//printf("\n vc_release--B.=> Else 2 \n"); fflush(stdout);
														ref_instancesTemp = malloc( sizeof(1) );
														ref_instancesTemp[0]=ref_instances[iy];
														CALLAPI(POM_delete_instances(1,ref_instancesTemp));
														ref_instancesTemp = NULL;
													}
												}
											}
											*/

											MEM_free(bvrs);

											CALLAPI(POM_save_instances(1,&bvr,FALSE));
											CALLAPI( AOM_save_without_extensions( bvr) )
											CALLAPI(AOM_unlock(bvr));
										}
										else
										{
											CALLAPI(PS_create_bvr( bv, "", "", false, VCrev,&bvr) )
											if(bvr !=NULLTAG)
											{
												CALLAPI( AOM_save_without_extensions( bvr) )
												CALLAPI (AOM_save_without_extensions( VCrev ))
												CALLAPI( AOM_unlock( VCrev ))
												printf(  "\n vc_release--3.inside  PS_create_bvr..\n"); fflush(stdout);
											}
										}

										//printf("\n\t Released VC not found loop..........");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_warning,ITK_errStore1,"Released VC with same name as that of SVR not present in TCUA. please get released VC loaded from TCE");
										//return ITK_errStore1;

										break;
									}
								}
							}
						}
					}
					else
					{
						TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
						if(rev_type_tag!=NULLTAG)
						{
							printf("\n vc_release--2.Else--rev_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
						AOM_set_value_string(rev_create_input_tag, "object_name", VehName);
						AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234));
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","V"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VEHICLE"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));
						//AAA:t5_PartPlatform onlly for CV
						if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
						{
							printf("\n Setting platform for CVBU VC..."); fflush(stdout);
							if(tc_strstr(BUInfo1,"A003")==NULL)
							{
								//Get Platform... AAA: need to work
								//Set platform

								if (strcmp(DMLBUnit,"CVBU")==0)
								{
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",CVVCPltform));
									printf("\n Setting platform for CVBU VC... done"); fflush(stdout);
								}
								else
								{
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
								}
							}
						}

						// Construct a CreateInput object for Item
						TCTYPE_find_type("Design", NULL, &item_type_tag);
						if(item_type_tag!=NULLTAG)
						{
							printf("\n vc_release--2.item_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

						AOM_set_value_string(item_create_input_tag, "item_id", VehName);
						AOM_set_value_string(item_create_input_tag, "object_name", VehName);
						AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

						//Create Design Object and Design Revision
						TCTYPE_create_object(item_create_input_tag, &parent_master);
						if(parent_master!=NULLTAG)
						{
							printf("\n vc_release--2.Design Revision created."); fflush(stdout);

							AOM_save_without_extensions(parent_master);
						}

						CALLAPI ( ITEM_ask_latest_rev( parent_master, &ItemRev1 ));
						CALLAPI(AOM_lock(parent_master));
						CALLAPI(AOM_lock(ItemRev1));

						CALLAPI(AOM_save_without_extensions(ItemRev1));
						CALLAPI(AOM_unlock(ItemRev1));
						AOM_unlock(parent_master);

						//t5removeAllReleaseStatus (ItemRev1);

						printf("\n vc_release--4.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev1,"Y"));
						CALLAPI(AssignProject_vc_rel(ItemRev1,itemId1234));

						//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
						//printf("\n release status find.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status2,1,&ItemRev1,retain));

						CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))

						CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
						CALLAPI(AOM_save_without_extensions( bv ))
						CALLAPI( AOM_save_without_extensions( parent_master ))
						CALLAPI( AOM_unlock( parent_master ))
						printf( "\n vc_release--2.inside PS_create_bom_view..\n");	 fflush(stdout);

						CALLAPI(PS_create_bvr( bv, "", "", false, ItemRev1,&bvr) )
						if(bvr != NULLTAG)
						{
							CALLAPI(AOM_save_without_extensions( bvr) )
							CALLAPI(AOM_save_without_extensions( ItemRev1 ))
							CALLAPI(AOM_unlock( ItemRev1 ))
							printf("\n vc_release--2.inside  PS_create_bvr..\n"); fflush(stdout);
						}
						if (bvr1 != NULLTAG)
						{
							CALLAPI(AOM_lock( bvr1 ));
							CALLAPI(PS_create_occurrences( bvr1, ItemRev1, NULLTAG,1, &occs ))
							//CALLAPI(PS_set_occurrence_qty(bvr1, occs[0], int_qunt));
							CALLAPI(AOM_save_without_extensions( bvr1) )
							CALLAPI(AOM_refresh(bvr1,1));
							CALLAPI(AOM_unlock(bvr1));
						}

						printf("\n\t vc_release--2.VC not found loop..........");fflush(stdout);
						//	 EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"VC with same name as that of SVR not present in TCUA. please get it loaded from TCE or create in TCUA and check-In");
						//		return ITK_errStore1;
					}

					/*
					if(top_line!=NULLTAG)
					{
						// CALLAPI(BOM_line_unpack(top_line));

						CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
						xform_matrix1=0;

						// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
						CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n vc_release--21.LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

						//if(n_lines1 == n_lines)
						//{
						if (n_lines1 >0)
						{
							const char **attrs3 = (const char **) MEM_alloc(2 * sizeof(char *));
							const char **values3 = (const char **) MEM_alloc(2 * sizeof(char *));

							attrs3[0] ="item_id";
							attrs3[1] ="object_type";

							printf("\n vc_release--2.before lock BVR-11  ");fflush(stdout);
							CALLAPI(AOM_lock( bvr ));

							for (p1=0;p1<n_lines1 ;p1++ )
							{
								if(Childobject4) Childobject4=NULLTAG;
								Childobject4=lines[p1];
								//CALLAPI(BOM_line_unpack(Childobject4));

								CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

								if (n_lines4 >0)
								{
									for (p4=0;p4<n_lines4 ;p4++ )
									{
										if(Childobject3) Childobject3=NULLTAG;
										if(child_item_id) child_item_id=NULL;

										Childobject3=lines4[p4];

										CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
										CALLAPI(TCTYPE_ask_name2(objTypeTagDi,&type_name2));

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
										printf("\n\n p4:[%d]  Last child_item_id:: %s and type_name2 :%s \n",p4,child_item_id,type_name2);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
										printf("  revision: %s  ",child_item_revision_id);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
										printf("\n child_bl_formula: %s",child_bl_formula);

										printf("\n ***********xform_matrix1: %d  ",xform_matrix1);
										CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
										printf( "\n child xform matrix 11--> %s",xform_matrix_str);fflush(stdout);

										tempmat1=tc_strtok(xform_matrix_str," ");

										for(imat=0;imat<4;imat++)
										{
											for(jmat=0;jmat<4;jmat++)
											{
												if(imat==0 && jmat==0)
												{
													//printf("\n inside if"); fflush(stdout);
													mat[imat][jmat]=strtod(tempmat1,NULL);
												}
												else
												{
													//printf("\n inside else"); fflush(stdout);
													tempmat=tc_strtok(NULL," ");
													mat[imat][jmat]=strtod(tempmat,NULL);
												}
											}
										}

										CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));

										printf("\n child quantity matrix--> %s  ",blqu_str);

										int_qunt=atoi(blqu_str);

										printf("\n child quantity int--> %d  ",int_qunt);

										if (child_item_id != NULL)
										{
											values3[0] = (char *)child_item_id;
											values3[1] = "Design";

											//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
											CALLAPI(ITEM_find_item_revs_by_key_attributes(2,attrs3, values3,child_item_revision_id, &n_tags_found3, &tags_found3))

											if (n_tags_found3>0)
											{
												Childrev= tags_found3[0];

												//CALLAPI ( ITEM_find_rev( child_item_id, child_item_revision_id, &Childrev ) )
												if(Childrev!=NULLTAG)
												{
													//////CALLAPI ( VOO_show_wso( Childrev ) )

													//CALLAPI(AOM_lock( bvr ));
													CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ))
													CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

													int_qunt = 0;

													//for(imat=0;imat<3;imat++)
													//{
													//	mat[3][imat]=(double)(mat[3][imat]/divInt);
													//}

													for(imat=0;imat<4;imat++)
													{
														for(jmat=0;jmat<4;jmat++)
														{
															printf("%10lf,",mat[imat][jmat]);
														}
														printf("\n");
													}

													CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

													//	CALLAPI(AOM_lock(bvr));

													CALLAPI(AOM_save_without_extensions( bvr) )
													//CALLAPI(AOM_refresh(bvr,1));
													//CALLAPI(AOM_unlock(bvr));
												}
											}
										} //End of if (child_item_id != NULL)
									}
								}
							} //End of for (p1=0;p1<n_lines1 ;p1++ )

							printf("\n vc_release--2.before saving BVR-11  ");fflush(stdout);
							CALLAPI(AOM_save_without_extensions( bvr) )
							CALLAPI(AOM_refresh(bvr,1));
							CALLAPI(AOM_unlock(bvr));

							printf("\n vc_release--2.before memory-Free-1  ");fflush(stdout);
							MEM_free(attrs3);
							MEM_free(values3);
							printf("\n vc_release--2.After memory-Free-1  ");fflush(stdout);

						} //End of if (n_lines1 >0)
						//else
						//{
						//	printf(  " Rules not applied successfully check again:\n"); fflush(stdout);
						//
						//}
					}*/


					if(top_line!=NULLTAG)
					{
						printf("\n vc_release--[--11--]"); fflush(stdout);

						//CALLAPI(AOM_save_without_extensions( bvr));
						//CALLAPI(AOM_refresh(bvr,1));
						//CALLAPI(AOM_lock( bvr ));

						//CALLAPI(BOM_line_unpack(top_line));

						//CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
						xform_matrix1=0;
						// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
						//CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n vc_release--3.LLlast Before setting option n_lines1: %d", n_lines1); fflush(stdout);

						//if(n_lines1 == n_lines)
						//{
						if (n_lines1 >0)
						{
							for (p1=0;p1<n_lines1 ;p1++ )
							{
								if(Childobject4) Childobject4=NULLTAG;
								Childobject4=lines[p1];
								//CALLAPI(BOM_line_unpack(Childobject4));

								CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

								if (n_lines4 >0)
								{
									for (p4=0;p4<n_lines4 ;p4++ )
									{
										if(Childobject3) Childobject3=NULLTAG;

										Childobject3=lines4[p4];

										CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
										CALLAPI(TCTYPE_ask_name2(objTypeTagDi,&type_name2));

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
										fprintf( stderr, " Last child_item_id ..:%s and type_name2 :%s\n",child_item_id,type_name2);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
										fprintf( stderr, " bl_rev_item_revision_id--------------> %s\n",child_item_revision_id);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
										fprintf( stderr, " child_bl_formula 2--------------> %s\n",child_bl_formula);

										//printf("\n***********xform_matrix1:%d\n",xform_matrix1);
										//CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
										
										if( AOM_ask_displayable_values(Childobject3,"bl_plmxml_abs_xform",&strcnt3,&xform_matrix_str))PrintErrorStack();
										printf("\n vc_release--child xform matrix 11-----------> [%s]\n",xform_matrix_str[0]);fflush(stdout);

										tempmat1=tc_strtok(xform_matrix_str[0]," ");

										for(imat=0;imat<4;imat++)
										{
											for(jmat=0;jmat<4;jmat++)
											{
												if(imat==0 && jmat==0)
												{
													//printf("\n inside if"); fflush(stdout);
													mat[imat][jmat]=strtod(tempmat1,NULL);
												}
												else
												{
													//printf("\n inside else"); fflush(stdout);
													tempmat=tc_strtok(NULL," ");
													mat[imat][jmat]=strtod(tempmat,NULL);
												}
											}
										}

										//CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));
										if( AOM_ask_displayable_values(Childobject3,"bl_quantity",&strcnt2,&blqu_str))PrintErrorStack();
										printf("\n vc_release--child quantity matrix--------------> %s\n",blqu_str[0]); fflush(stdout);
										fprintf(stderr,"child quantity matrix--------------> %s\n",blqu_str[0]); fflush(stderr);

										int_qunt=atoi(blqu_str[0]);

										fprintf( stderr, " child quantity int-------------> %d\n",int_qunt);

										const char **attrs3 = (const char **) MEM_alloc(2 * sizeof(char *));
										const char **values3 = (const char **) MEM_alloc(2 * sizeof(char *));

										attrs3[0] ="item_id";
										attrs3[1] ="object_type";

										values3[0] = (char *)child_item_id;
										values3[1] = "Design";

										CALLAPI(ITEM_find_item_revs_by_key_attributes(2,attrs3, values3,child_item_revision_id, &n_tags_found3, &tags_found3))

										MEM_free(attrs3);
										MEM_free(values3);

										if (n_tags_found3>0)
										{
											Childrev= tags_found3[0];

											if(Childrev!=NULLTAG)
											{
												CALLAPI(AOM_lock( bvr ));
												CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ))
												CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

												int_qunt = 0;

												//for(imat=0;imat<3;imat++)
												//{
												//	mat[3][imat]=(double)(mat[3][imat]/divInt);
												//}

												for(imat=0;imat<4;imat++)
												{
													for(jmat=0;jmat<4;jmat++)
													{
														printf("%10lf,",mat[imat][jmat]);
													}
													printf("\n");
												}

												CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

												//	CALLAPI(AOM_lock(bvr));

												printf("\n [--1--]"); fflush(stdout);
												CALLAPI(AOM_save_without_extensions( bvr));
												//printf("\t[--2--]"); fflush(stdout);
												CALLAPI(AOM_refresh(bvr,1));
												//printf("\t[--3--]"); fflush(stdout);
												CALLAPI(AOM_unlock(bvr));
												printf("\t[--4--]"); fflush(stdout);
											}
										}
									}
								}
							}
						}

						//printf("\n [--12--]"); fflush(stdout);
						//CALLAPI(AOM_save_without_extensions( bvr));
						//printf("\t[--2--]"); fflush(stdout);
						//CALLAPI(AOM_refresh(bvr,1));
						//printf("\t[--3--]"); fflush(stdout);
						//CALLAPI(AOM_unlock(bvr));
						//printf("\t[--4--]"); fflush(stdout);
						//else
						//{
						//	printf(  " Rules not applied successfully check again:\n"); fflush(stdout);
						//
						//}
					}

					if (ItemRev1 != NULLTAG)
					{
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
						printf("\n vc_release--2.release status find 1.");fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status3,1,&ItemRev1,retain));
						printf("\n vc_release--5.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev1,"N"));
					}
					if (ItemRev != NULLTAG)
					{
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status4));
						printf("\n release status find 2 .");fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status4,1,&ItemRev,retain));
						printf("\n vc_release--6.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev,"N"));
					}
					if (RevNewSeqTag != NULLTAG)
					{
						ernew=ernew+1;
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
						printf("\n release status find 4.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status3,1,&RevNewSeqTag,retain));
						printf("\n vc_release--7.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(RevNewSeqTag,"N"));
					}
					if (ernew == 0)
					{
						if (VCrev != NULLTAG)
						{
							CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
							printf("\n vc_release--2.release status find 3.");fflush(stdout);
							//CALLAPI(RELSTAT_add_release_status(status3,1,&VCrev,retain));
							printf("\n vc_release--8.Before UpdateAllowForm call "); fflush(stdout);
							CALLAPI(UpdateAllowForm(VCrev,"N"));
						}
					}

					CALLAPI(BOM_save_window(bom_window))
					CALLAPI(BOM_close_window(bom_window))

					if(relation_type1 != NULLTAG)
					{
						CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type1,&cnt12,&attachments12));
						printf("\n vc_release--impacted items:%d\n",cnt12);fflush(stdout);

						if (RevNewSeqTag != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----1 ");fflush(stdout);

							GRM_find_relation(DMLTag,RevNewSeqTag,relation_type1,&tRelationExist);
							if (tRelationExist==NULLTAG)
							{
								//###  Creating Relation between DML and RevNewSeqTag  ###

								printf("\n vc_release--Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,RevNewSeqTag,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--Relation Created Successfully\n");fflush(stdout);
							}
						}
						if (ernew == 0)
						{
							printf("\n vc_release--Relation Creation ----2 ");fflush(stdout);
							if(VCrev != NULLTAG)
							{
								GRM_find_relation(DMLTag,VCrev,relation_type1,&tRelationExist1);
								if (tRelationExist1==NULLTAG)
								{
									//###  Creating Relation between DML and VCrev  ###

									printf("\n vc_release--3.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
									CALLAPI(GRM_create_relation(DMLTag,VCrev,relation_type1,NULLTAG,&Rel_task));
									CALLAPI(GRM_save_relation  (Rel_task));
									printf("\n vc_release--3.Relation Created Successfully\n");fflush(stdout);
								}
							}
						}
						if(ItemRev1 != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----3 ");fflush(stdout);

							GRM_find_relation(DMLTag,ItemRev1,relation_type1,&tRelationExist2);
							if (tRelationExist2==NULLTAG)
							{
								//###  Creating Relation between DML and ItemRev1  ###

								printf("\n vc_release--4.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev1,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--4.Relation Created Successfully\n");fflush(stdout);
							}
						}

						if(ItemRev != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----4 ");fflush(stdout);

							GRM_find_relation(DMLTag,ItemRev,relation_type1,&tRelationExist3);
							if (tRelationExist3==NULLTAG)
							{
								//###  Creating Relation between DML and ItemRev  ###

								printf("\n vc_release--5.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--5.Relation Created Successfully\n");fflush(stdout);
							}
						}

						if (RevNewSeqTag!=NULLTAG)
						{
							logical checkout = 0;

							CALLAPI(RES_is_checked_out(RevNewSeqTag,&checkout));
							printf("\n vc_release--1.checkout:[%d] ",checkout); fflush(stdout);

							if (checkout > 0)
							{
								if(RES_checkin(RevNewSeqTag)!=ITK_ok)
								{
									printf("\n vc_release--1..RES_checkin failed.\n"); fflush(stdout);
								}
								else
								{
									printf("\n vc_release--1..RES_checkin is successful\n"); fflush(stdout);
								}
							}
						}

						//GRM_find_relation(DMLTag,parent_master1,relation_type1,&tRelationExist4);
						//if (tRelationExist4==NULLTAG)
						//{
						//	//###  Creating Relation between DML and Task  ###
						//
						//	printf("\n vc_release--6.Now Creating Relation Between DML Task and VC Object 11\n");fflush(stdout);
						//	CALLAPI(GRM_create_relation(DMLTag,parent_master1,relation_type1,NULLTAG,&Rel_task));
						//	CALLAPI(GRM_save_relation  (Rel_task));
						//	printf("\n vc_release--6.Relation Created Successfully\n");fflush(stdout);
						//}
						//}
						//else
						//{
						//	 EMH_store_error_s1(EMH_severity_error,ITK_errStore2,"Solution Items of DML Task already contains the object. please get it cleared first");
						//	 return ITK_errStore2;
						//}
						// end

					} //End of if(relation_type1 != NULLTAG)
				}
			} //End of condn if (strcmp(objecttype,"VariantRule")==0)
		} //End of for(j=0;j<cnt;j++)
	} //End of if(relation_type != NULLTAG)
	else
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,PLM_error,"DML Task References relation not found. Please raise ticket in TMS.");
		printf("\n vc_release--DML-Task Relation CMReferences not found in TCUA ?? \n\n");fflush(stdout);
		return PLM_error;
	}

	printf("\n End of vc_release ........\n");fflush(stdout);

	return ITK_ok;
}

static void handle_itk_error
    ( int stat,                           /* <I> */
      int source_code_line,               /* <I> */
      const char *source_code_file_name   /* <I> */
    )
{
    if ( VOO_debug )
    {
        int n_ifails=0;
        const int *severities=NULL;
        const int *ifails=NULL;
        const char **texts=NULL;
        char *errstring=NULL;

        fprintf( stderr, "Error detected\n" );
        fflush( stderr);
        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );

		if ( n_ifails && texts != NULL )
        {
            if ( ifails[n_ifails-1] == stat )
            {
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (texts[n_ifails-1]==NULL?"null":texts[n_ifails-1]) );
            }
            else
            {
                EMH_ask_error_text( stat, &errstring );
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
                MEM_free( errstring );
            }
        }
        else
        {
            EMH_ask_error_text( stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
            MEM_free( errstring );
        }

        fprintf( stderr, "%s %s: Error: Line %d in %s\n", VOO_prog, VOO_time_stamp(), source_code_line, source_code_file_name );
    }
}

static int VOO_show_wso ( tag_t wso )
{
    int            stat=ITK_ok;
    tag_t          instance_class=NULLTAG;
    static tag_t   wso_class=NULLTAG;
    static tag_t   ve_class=NULLTAG;
    static int     not_initialized=TRUE;
    logical        is_wso=FALSE;

    // fprintf( stderr, "inside function VOO_show_wso");

	if ( not_initialized ) {
        ITK ( POM_class_id_of_class ( "WorkspaceObject", &wso_class ) );
        ITK ( POM_class_id_of_class ( "VariantExpression", &ve_class ) );
        not_initialized = FALSE;
    }

    if ( NULLTAG == wso ) {
        fprintf( stderr, "VOO_show_wso: Can't show info for a NULLTAG\n" );
        return stat;
    }

    ITK ( POM_class_of_instance ( wso, &instance_class ) );
    ITK ( POM_is_descendant ( wso_class, instance_class, &is_wso ) );

	if ( ! is_wso )
	{
        logical is_ve=FALSE;

        ITK ( POM_is_descendant ( ve_class, instance_class, &is_ve ) );
        if ( is_wso ) {
            char *t=NULL;

            ITK ( BOM_variant_expression_as_text( wso, &t ) );
            fprintf( stderr, "%s %s: VariantExpression: %s: ", VOO_prog, VOO_time_stamp(), (NULL==t?"null":t) );
            MEM_free( t );
        }
        else
        {
            char *class_name=NULL;

            ITK ( POM_name_of_class ( instance_class, &class_name ) );
            fprintf( stderr, "%s", (NULL==class_name?"null":class_name) );
        }
    }
    else
    {
        char *obj_id=NULL;
        WSO_description_t  wso_desc;

        ITK ( WSOM_describe ( wso, &wso_desc ) );
        ITK ( WSOM_ask_object_id_string ( wso, &obj_id ) );
        if ( stat == ITK_ok )
		{
            fprintf( stderr, "obj_id=%s", (NULL==obj_id?"null":obj_id) );
            MEM_free( obj_id );
			//fprintf( stderr, ", name=%s", wso_desc.object_name );
			//fprintf( stderr, ", description=%s", wso_desc.description );
            fprintf( stderr, ", type=%s", wso_desc.object_type );
        }
    }
    fprintf( stderr, "\n" );
    return stat;
}

static char *VOO_time_stamp()
{
    time_t now;
    static char time_stamp[512];

    time( &now );
    sprintf( time_stamp, "%s", ctime( &now ) );
    time_stamp[tc_strlen(time_stamp)-1] = '\0'; /* strip off new line */
    return time_stamp;
}
static int VOO_list_saved_variant_rules
    ( tag_t    itemRev,
      int *    n_variant_rules,
      tag_t ** variant_rules
    )
{
    int         n_secondaries=0;
    tag_t      *secondaries=NULL;
    int         stat=ITK_ok;

    *variant_rules = NULL;
    *n_variant_rules = 0;

	//fprintf( stderr, "inside functionss VOO_list_saved_variant_rules" );

    ITK ( GRM_list_secondary_objects_only( itemRev, NULLTAG, &n_secondaries, &secondaries ) )

	//fprintf( stderr, "n_secondaries :%d" ,n_secondaries	);

    /*  Collect together all the variant_rules */

    if ( n_secondaries )
    {
        *variant_rules = (tag_t *)MEM_alloc( n_secondaries * sizeof ( tag_t ) );
        if ( NULL == variant_rules )
        {
            ITK ( SS_NOMEM )
        }
        else
        {
            int inx;
            tag_t varRuleClass=NULLTAG;

            ITK ( POM_class_id_of_class ( "VariantRule", &varRuleClass ) )
            for ( inx = 0; inx < n_secondaries; inx++ )
            {
                tag_t   classId=NULLTAG;
                logical isVRule=FALSE;

                ITK ( POM_class_of_instance( secondaries[inx], &classId ) )
                ITK ( POM_is_descendant( varRuleClass, classId, &isVRule ) )
                if ( isVRule )
                {
                    (*variant_rules)[(*n_variant_rules)++] = secondaries[inx];
                }
            }
        }
    }
    MEM_free( secondaries );
    return stat;
}
static logical VOO_option_value_hash
    ( int       hash_size,               /* <I> */
      vector_t *hash[],                  /* <I> */
      tag_t     option_rev,              /* <I> */
      int       option_rev_value_index,  /* <I> */
      int       add_if_new               /* <I> */
    )
{
    logical was_new=TRUE;
    int     key;
    int     inx;
    tag_t * hashed_option_rev=NULL;
    int   * hashed_option_rev_value_index=NULL;

    if ( option_rev != NULLTAG )
    {
        key = option_rev % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-2; inx>=0; inx-=2 )
            {
                hashed_option_rev             = (tag_t *)vector_get( hash[key], inx );
                hashed_option_rev_value_index = (int *)  vector_get( hash[key], inx+1 );
                if ( *hashed_option_rev == option_rev && *hashed_option_rev_value_index == option_rev_value_index )
                {
                    was_new = FALSE;
                    break;
                }
            }
        }
        if ( was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 10, 10 );
            if ( (hashed_option_rev = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_option_rev = option_rev;
            if ( (hashed_option_rev_value_index = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_option_rev_value_index = option_rev_value_index;
            hash[key] = vector_add( hash[key], hashed_option_rev );
            hash[key] = vector_add( hash[key], hashed_option_rev_value_index );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    return !was_new;
}
static int VOO_variant_expression
    ( tag_t        v1,               /* <I> */
      int          op,               /* <I> */
      tag_t        v2,               /* <I> */
      const char * text,             /* <I> */
      tag_t      * ve,               /* <O> */
      logical    * was_new           /* <O> */
    )
{
    static variant_rule_option_data_t expression_hash={NULL};

    return VOO_expression_hash( VOO_HASH_SIZE, expression_hash, v1, op, v2, text, TRUE, ve, was_new );
}
static int VOO_expression_hash
    ( int          hash_size,            /* <I> */
      vector_t   * hash[],               /* <I> */
      tag_t        val1,                 /* <I> */
      int          oper,                 /* <I> */
      tag_t        val2,                 /* <I> */
      const char * text,                 /* <I> */
      logical      add_if_new,           /* <I> */
      tag_t      * var_exp,              /* <O> */
      logical    * was_new               /* <O> */
    )
{
    int     stat=ITK_ok;
    int     key;
    int     inx;
    tag_t * hashed_val1=NULL;
    int   * hashed_oper=NULL;
    tag_t * hashed_val2=NULL;
    char  * hashed_text=NULL;
    tag_t * hashed_var_exp=NULL;

    *was_new = TRUE;
    if ( val1 != NULLTAG )
    {
        key = (val1+val2) % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-5; inx>=0; inx-=5 )
            {
                hashed_val1 = (tag_t *)vector_get( hash[key], inx );
                hashed_oper = (int *)  vector_get( hash[key], inx+1 );
                hashed_val2 = (tag_t *)vector_get( hash[key], inx+2 );
                hashed_text = (char *) vector_get( hash[key], inx+3 );
                if ( *hashed_val1 == val1 &&
                     *hashed_oper == oper &&
                     *hashed_val2 == val2 &&
                     0 == tc_strcmp( hashed_text, text ) )
                {
                    hashed_var_exp = (tag_t *)vector_get( hash[key], inx+4 );
                    *was_new = FALSE;
                    break;
                }
            }
        }
        if ( *was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 50, 50 );
            if ( (hashed_val1 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val1 = val1;
            if ( (hashed_oper = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_oper = oper;
            if ( (hashed_val2 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val2 = val2;
            if ( NULL == text )
                hashed_text = NULL;
            else
                hashed_text = MEM_string_copy( text );
            if ( (hashed_var_exp = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                ITK ( BOM_new_variant_expression( val1, oper, val2, text, hashed_var_exp ) )
            hash[key] = vector_add( hash[key], hashed_val1 );
            hash[key] = vector_add( hash[key], hashed_oper );
            hash[key] = vector_add( hash[key], hashed_val2 );
            hash[key] = vector_add( hash[key], hashed_text );
            hash[key] = vector_add( hash[key], hashed_var_exp );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    *var_exp = (hashed_var_exp==NULL?NULLTAG:*hashed_var_exp);
    if ( VOO_debug )
    {
        char *t=NULL;

        ITK ( BOM_variant_expression_as_text( *var_exp, &t ) )
        fprintf( stderr, "%s %s: %s variant expression %s\n", VOO_prog, VOO_time_stamp(), (*was_new?"new":"re-using"), (NULL==t?"null":t) );
        MEM_free( t );
    }
    return stat;
}

/*==================================================================================================
      vector stuff
==================================================================================================*/
/**********************************************************************************
 * Function:          vector_new
 *
 * Purpose:           allocates new vector, inital capacity=`capacity'
 *
 * Description:       returns a pointer to a dynamically allocated vector or
 *                    NULL if no memory can be allocated. On success, the
 *                    vector has a initial capacity of `capacity' and will
 *                    grow in steps of `increment'.
 *
 * Parameters:        int capacity;    initial capacity
 *                    int increment;    incremental growth rate when needed
 *
 * Example:           v = vector_new ( 100, 10 );
 *
 * Return Value:      pointer to a dynamically allocated vector
 *                    NULL if no memory can be allocated
 *
 *********************************************************************************/
static vector_t *vector_new ( int capacity, int increment )
{
    vector_t *vector;

    vector = (vector_t *)MEM_alloc( sizeof ( vector_t ) );
    if ( vector == NULL ) {
        return NULL;
    }
    vector->size = 0;
    vector->capacity = capacity;
    vector->increment = increment;
    vector->content = (void **)MEM_alloc( capacity * sizeof ( void * ) );
    if ( vector->content == NULL ) {
        MEM_free( vector );
        return NULL;
    }
    return vector;
}

/***********************************************************************************
 * Function:          vector_add
 *
 * Purpose:           appaends one pointer at the end of the vector
 *
 * Description:       convenient form of vector_add_n(), calls vector_add_n().
 *
 * Parameters:        vector_t *in;    vector to which the element is added
 *                    void *element;    pointer to the element to be added
 *
 * Example:           v = vector_add ( v, "line 1" );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add ( vector_t *in, void *element )
{
    return vector_add_n ( in, 1, &element );
}

/***********************************************************************************
 * Function:          vector_add_n
 *
 * Purpose:           appaends n pointers at the end of the vector
 *
 * Description:       extend vector `in' if necessary and append n pointers
 *                    to the (possibly reallocated) vector `in'.
 *
 * Parameters:        vector_t *in;        vector to which the element is added
 *                    int n;                number of elements to append
 *                    void *elements[];    array of pointers to elements to add
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add_n ( vector_t *in, int n, void *elements[] )
{
    vector_t *out;

    out = vector_ensure_capacity ( in, n );
    if ( out == NULL ) {
        return NULL;
    }
    memcpy ( &out->content[out->size], elements, n * sizeof ( void * ) );
    out->size += n;
    out->capacity -= n;
    return out;
}

/***********************************************************************************
 * Function:          vector_rem_at
 *
 * Purpose:           removes 1 pointer at position `at'
 *
 * Description:       convenient form of vector_rem_n_at, calls vector_rem_n_at()
 *
 * Parameters:        vector_t *in;        vector of which the element is removed
 *                    int at;                position of the element to be removed
 *
 * Example:           v = vector_add_n ( v, 0 );
 *
 * Return Value:      0     if `at' is within bounds [0,`size')
 *                    2     if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_at ( vector_t *in, int at )
{
    return vector_rem_n_at ( in, 1, at );
}

/***********************************************************************************
 * Function:          vector_rem_n_at
 *
 * Purpose:           removes n pointers from position `at' on
 *
 * Description:       removes `n' pointers beginning at position `at'. Elements
 *                    beyond position `n'+`at' are block moved upward so that
 *                    their sequence is not changed.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_add_n ( v, 1, 0 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_n_at ( vector_t *in, int n, int at )
{
    int ret;

    if ( at + n <= in->size ) {
        int i;

        for ( i=at; i<in->size - n; i++ ) {
            in->content[i] = in->content[i+n];
        }
        in->size -= n;
        in->capacity += n;
        ret = 0;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot remove %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        ret = 2;
    }
    return ret;
}

/***********************************************************************************
 * Function:          vector_insert
 *
 * Purpose:           inserts 1 pointer at position 0
 *
 * Description:       inserts 1 pointer at position 0
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    void *elements;      element to insert
 *
 * Example:           v = vector_insert ( v, (void *)argv[1] );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert ( vector_t *in, void *element )
{
    return vector_insert_n_at ( in, 1, &element, 0 );
}

/***********************************************************************************
 * Function:          vector_insert_n_at
 *
 * Purpose:           inserts `n' pointers at position `at'.
 *
 * Description:       inserts `n' pointers at position `at'.
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    int n;               number of elements to insert
 *                    void *elements[];    elements to insert
 *                    int at;              position of 1st element to insert
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv, 0 );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert_n_at ( vector_t *in, int n, void *elements[], int at )
{
    vector_t *out;

    if ( at <= in->size ) {
        int i;

        out = vector_ensure_capacity ( in, n );
        for ( i=in->size-1; i>=at; i-- ) {
            out->content[i+n] = out->content[i];
        }
        for ( i=0; i<n; i++ ) {
            out->content[i+at] = elements[i];
        }
        out->size += n;
        out->capacity -= n;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot add %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_ensure_capacity
 *
 * Purpose:           ensures capacity for `n' more elements
 *
 * Description:       If the current capacity does not allow for `n' more elements
 *                    the vector is reallocated with the minimum amount of more
 *                    memory to allow for `n' more elements.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_ensure_capacity( v, 5 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static vector_t *vector_ensure_capacity ( vector_t *in, int n )
{
    vector_t *out;

    if ( in->capacity < n ) {
        n = ( n + in->increment - 1 ) / in->increment;
        out = vector_new ( in->size + ( n * in->increment ), in->increment );
        if ( out == NULL ) {
            return NULL;
        }
        out->size = in->size;
        out->capacity = n * in->increment;
        memcpy ( out->content, in->content, in->size * sizeof ( void * ) );
        vector_free ( in );
    }
    else {
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_get
 *
 * Purpose:           returns element at position `index'
 *
 * Description:       returns element at position `index'
 *
 * Parameters:        vector_t *in;        vector of which the elements is returned
 *                    int index;            position of the elements to return
 *
 * Example:           printf ( "Element is: %s\n", (char *)vector_get ( v, 0 ) );
 *
 * Return Value:      pointer to the element at position `index'
 *
 ***********************************************************************************/
static void *vector_get ( const vector_t *in, int index )
{
    return in->content[index];
}

/***********************************************************************************
 * Function:          vector_size
 *
 * Purpose:           returns the current number of stored elements in the vector
 *
 * Description:       returns the current number of stored elements in the vector
 *
 * Parameters:        vector_t *in;        vector of which the size is returned
 *
 * Example:           for ( i=0; i<vector_size ( v ); i++ ) ;
 *
 * Return Value:      current number of stored elements in the vector
 *
 ***********************************************************************************/
static int vector_size ( const vector_t *in )
{
    return in->size;
}

/***********************************************************************************
 * Function:          vector_free
 *
 * Purpose:           frees memory of a vector (does not free the elements!)
 *
 * Description:       frees all dynamically allocated memory in structure
 *                    vector_t for the vector `in'. This does not free the
 *                    memory for the elements for which this vector held
 *                    pointers!
 *
 * Parameters:        vector_t *in;        vector to be freed
 *
 * Example:           v = vector_free ( v );
 *
 * Return Value:      NULL
 *
 ***********************************************************************************/
static vector_t *vector_free ( vector_t *in )
{
    if ( in != NULL )
    {
        MEM_free( in->content );
        MEM_free( in );
    }
    return NULL;
}

int ChkFrstLvlModuleDRstus(char* p_child_item_id, int DMLSTVALUT)
{
	int cr =0;
	int crr =0;
	int DROKFlag =0;
	int n_tags_found2 =0;
	int PRTSTVALU =0;
	int Child_Rev_count =0;
	int Chld_Rel_Stus_Cunt =0;
	tag_t	Child_All_Rev		= NULLTAG;
	tag_t*	Child_rev_list		= NULLTAG;
	tag_t*	Child_status_lst	= NULLTAG;
	tag_t*	tags_found2	= NULLTAG;
	char*	 Chld_Rel_Stus = NULL;
	char*	 Child_Prt_DR = NULL;
	char*	 Child_rev_idd = NULL;
	char*	 PRTDRStr = NULL;

	printf("\n DR:Start of ChkFrstLvlModuleDRstus Function-----------");fflush(stdout);

	const char **attrs2 = (const char **) MEM_alloc(2 * sizeof(char *));
	const char **values2 = (const char **) MEM_alloc(2 * sizeof(char *));

	attrs2[0] ="item_id";
	attrs2[1] ="object_type";

	values2[0] = (char *)p_child_item_id;
	values2[1] = "Design";

	if ( ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();

	printf("\n DR:Total Child rev found: %d, DMLSTVALUT: %d", Child_Rev_count,DMLSTVALUT);fflush(stdout);
	MEM_free(attrs2);
	MEM_free(values2);

	if (n_tags_found2 == 1)
	{
		Child_All_Rev=tags_found2[0];
	}

	if(ITEM_list_all_revs (Child_All_Rev, &Child_Rev_count, &Child_rev_list)!=ITK_ok)PrintErrorStack();
	printf("\n DR:Total Child rev found: %d, DMLSTVALUT: %d", Child_Rev_count,DMLSTVALUT);fflush(stdout);

	if(Child_Rev_count > 0)
	{
		cr			= 0;
		DROKFlag	= 0;

		for(cr=Child_Rev_count-1;cr>=0;cr--)
		{
			Chld_Rel_Stus_Cunt=0;
			DROKFlag=0;
			Child_rev_idd=NULL;

			if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);

			if(WSOM_ask_release_status_list (Child_rev_list[cr], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			printf("\n DR:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);

			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;

				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{
					DROKFlag=0;
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);

					if((tc_strstr(Chld_Rel_Stus,"Released")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Rlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
					{
						DROKFlag=0;
						Child_Prt_DR=NULL;

						if(AOM_ask_value_string(Child_rev_list[cr],"t5_PartStatus",&Child_Prt_DR)!=ITK_ok)PrintErrorStack();
						printf("\n DR:RelStatus:%s  Child_rev_idd:%s DR Status:%s\n", Chld_Rel_Stus, Child_rev_idd,Child_Prt_DR);fflush(stdout);

						PRTDRStr=NULL;
						PRTSTVALU=0;

						PRTDRStr = subString(Child_Prt_DR, 2, 1);
						printf("\n DR:A:PRTDRStr: %s and ",PRTDRStr);fflush(stdout);

						PRTSTVALU = atoi(PRTDRStr);
						printf(":PRTSTVALU: %d",PRTSTVALU);fflush(stdout);

						if (PRTSTVALU >= DMLSTVALUT)
						{
							DROKFlag=1;
							break;
						}
					}
				}
				if (DROKFlag >0)
				{
					break;
				}
			}
		}
		printf("\n DR:DROKFlag: %d",DROKFlag);fflush(stdout);
		if (DROKFlag >0)
		{
			printf("\t DR:Released revison having valid DR-status.: %s ", p_child_item_id);fflush(stdout);
			return 1;
		}
		else
		{
			return 0;
		}
	}

	return 0;
}

extern int tm_vc_release_register_method(int *decision, va_list args)
{
	int ifail=0;
	*decision = ALL_CUSTOMIZATIONS;
	tag_t objTag = va_arg(args, tag_t);

	if( ITK_ok == EPM_register_action_handler("vc_release", "", vc_release))
	{
		printf("\t\n Registered Action Handler tm_vc_release_register_method\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Action Handler tm_vc_release_register_method\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("bom_complete", "", bom_complete))
	{
		printf("\t\n Registered Action Handler bom_complete_register_method\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Action Handler bom_complete_register_method\n");fflush(stdout);
	}

	if( ITK_ok ==  EPM_register_rule_handler ("ECUCount_Valid16RTPL","Compare_ecu_count16RTPL", (EPM_rule_handler_t) ECUCount_Valid16RTPL))
	{
		printf("\t\n Registered rule  Handler ECUCount_Valid16RTPL\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register rule Handler ECUCount_Valid16RTPL\n");fflush(stdout);
	}
	/***************************delete_msg*****************************************/
	/***************************end*****************************************/

	return ITK_ok;
}

extern DLLAPI int tm_vc_release_register_callbacks()
{
	 CUSTOM_register_exit("tm_vc_release", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_vc_release_register_method);

     printf("\n registered function erc_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}
