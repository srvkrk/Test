
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_CKD.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   29-10-2018
* ENVIRONMENT	:   ITK
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 29/10/2018   	 Manoj Kumar			    Base Code
* 01/01/2025   	 Ketan Bhut					Action/Rule Handler
* 01/02/2025   	 Ketan Bhut					CKD DML/Task Creation
* 01/03/2025   	 Ketan Bhut					CKD Reports
* -----------------------------------------------------------------------------
*
*****************************************************************************/
/////////////////////////////////// CKD OLD
//#include <tc/tc.h>
//#include <itk/mem.h>
//#include <base_utils/ResultCheck.hxx>
//#include <base_utils/IFail.hxx>
//#include <base_utils/DateTime.hxx>
//#include <epm/releasestatus.h>

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <pom/pom/pom_errors.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <mld/journal/journal.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>
#include <pie/pie.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)

//////

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPICKD(expr)ITK_CALL_CKD(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL_CKD(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define ITK_err (EMH_USER_error_base+3)
#define	t5CKDSerialNum (EMH_USER_error_base+1000)
#define	t5CKDDummyPart (EMH_USER_error_base+10001)

//using namespace std;
char* subString_CKD (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void  getAllPlantDetailsCKD( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
	 printf("\n Ketan Inside getAllPlantDetailsCKD  \n");fflush(stdout);

     char   *PlantName=NULL;
	 printf("\n RoleName => %s\n", RoleName);
     PlantName=subString_CKD(RoleName,3,4);
     printf("\n PlantName => %s\n", PlantName);

	if((tc_strcmp(PlantName,"APLD")==0)|| (tc_strcmp(PlantName,"STDD")==0))
	  {
		  printf("\n Inside APLD/STDD  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }
	  else if((tc_strcmp(PlantName,"APLP")==0)|| (tc_strcmp(PlantName,"STDP")==0))
	  {
		  printf("\n Inside APLP/STDP  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
	  else if((tc_strcmp(PlantName,"APLC")==0)|| (tc_strcmp(PlantName,"STDC")==0))
	  {
		  printf("\n Inside APLC/STDC  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }
	  else if((tc_strcmp(PlantName,"APLJ")==0)|| (tc_strcmp(PlantName,"STDJ")==0))
	  {
		  printf("\n Inside APLJ/STDJ  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }
	  else if((tc_strcmp(PlantName,"APLL")==0)|| (tc_strcmp(PlantName,"STDL")==0))
	  {
		  printf("\n Inside APLL/STDL  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }
	  else if((tc_strcmp(PlantName,"APLA")==0)|| (tc_strcmp(PlantName,"STDA")==0))
	  {
		  printf("\n Inside APLA/STDA  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }
	  else if((tc_strcmp(PlantName,"APLU")==0)|| (tc_strcmp(PlantName,"STDU")==0))
	  {
		  printf("\n Inside APLU/STDU  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }
	  else if((tc_strcmp(PlantName,"APLS")==0)|| (tc_strcmp(PlantName,"STDS")==0))
	  {
		  printf("\n Inside APLS/STDS  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }
	  else
	 {
		   printf("\n Inside else  \n");fflush(stdout);
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}
	

/* CHARACTER ARRAY */
void setAddStr_CKD(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
		printf("\n setAddStr2");fflush(stdout);
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
		printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
		printf("\n setAddStr4");fflush(stdout);
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
		printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = (char *)malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr_CKD character found===%s",(*strset)[*count-1]);fflush(stdout);
}
	

/* FUNCTION TO GET ITEM REVISION */
int getQueryItemRevision_AllType( const char *val,char *type,tag_t** items,int *n_found)
{
	int ifail = ITK_ok;
	
	printf("\n Inside getQueryItemRevision_AllType......");fflush(stdout);

	printf("\n\n RowsVal object==%s",val);fflush(stdout);
	printf("\n RowsVal type==%s \n",type);fflush(stdout);
	
	tag_t        query           = NULLTAG;
	
	char
	        *qry_entries3[] = {(char *)"Item ID",(char *)"Type"},
	        *qry_values3[]  = {(char *)val,type};
	          
	QRY_find2("Item Revision...", &query);
	QRY_execute(query,2, qry_entries3, qry_values3, n_found, items);

	printf("\n\n getQueryItemRevision_AllType Rows555==%s \n",val);fflush(stdout);

    return ifail;
} 

/* FUNCTION TO GET BARRELS */
int getQueryCKDBARREL( const char *val,char *attr,tag_t** items,int *n_found)
{
	int ifail = ITK_ok;
	
	printf("\n Inside getQueryCKDBARREL......");fflush(stdout);

	printf("\n\n RowsVal object==%s",attr);fflush(stdout);
	printf("\n RowsVal type==%s \n",val);fflush(stdout);
		  
	tag_t        query           = NULLTAG;
          
	char
	        *qry_entries3[] = {(char *)attr},
	        *qry_values3[]  = {(char *)val};

    QRY_find2("CKD BARREL", &query);
    QRY_execute(query,1, qry_entries3, qry_values3, n_found, items);

    printf("\n\n getQueryCKDBARREL final==%s \n",val);fflush(stdout);

	return ifail;
} 

int tm_create_relstate_ckddml_task(char* PlantName, tag_t CKDDmlRev_Tag, tag_t CKDTaskRev_Tag )
{
	int ifail=ITK_ok;	

	char*	CKDDML_no				= NULL;
	char*	CKDTask_no				= NULL;
	char*	PlantLcs				= NULL;
	char*	CKDDmlReleaseStatus		= NULL;
	char*	CKDTaskReleaseStatus	= NULL;
		
	tag_t   CKDDmlstatus			= NULLTAG;
	tag_t   CKDTaskstatus			= NULLTAG;

	logical CKDDml_retain			= false;
	logical CKDTask_retain			= false;
	
	PlantLcs	= (char *)MEM_alloc(100);
		
	tc_strcpy(PlantLcs,"");
	
	printf("\n Ketan Inside tm_create_relstate_ckddml_task......\n");fflush(stdout);

	CALLAPICKD(AOM_ask_value_string(CKDDmlRev_Tag,"current_id", &CKDDML_no));
	CALLAPICKD(AOM_ask_value_string(CKDTaskRev_Tag,"current_id", &CKDTask_no));

	printf("\n CKDDML_no => [%s] || CKDTask_no => [%s] || PlantName => [%s]\n",CKDDML_no,CKDTask_no,PlantName);fflush(stdout);

	if (tc_strcmp(PlantName,"STDJ") == 0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDjWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDL") == 0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDlWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDD") == 0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDdWrkg");
	}
	else if (tc_strcmp(PlantName,"STDP") == 0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
	    tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDU") == 0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDuWrkg");	
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);
		tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}

	printf("\n Final PlantLcs is => [%s] \n", PlantLcs);fflush(stdout);

	CALLAPICKD(RELSTAT_create_release_status(PlantLcs,&CKDDmlstatus));
	CALLAPICKD(AOM_ask_name(CKDDmlstatus, &CKDDmlReleaseStatus));
	printf("\n CKDDmlReleaseStatus => %s\n",CKDDmlReleaseStatus);fflush(stdout);
	CALLAPICKD(RELSTAT_add_release_status(CKDDmlstatus,1,&CKDDmlRev_Tag,CKDDml_retain));

	CALLAPICKD(RELSTAT_create_release_status(PlantLcs,&CKDTaskstatus));
	CALLAPICKD(AOM_ask_name(CKDTaskstatus, &CKDTaskReleaseStatus));
	printf("\n CKDTaskReleaseStatus => %s\n",CKDTaskReleaseStatus);fflush(stdout);
	CALLAPICKD(RELSTAT_add_release_status(CKDTaskstatus,1,&CKDTaskRev_Tag,CKDTask_retain));

	printf("\n Release status created in CKD DML and Task \n");fflush(stdout);

	return 0;
}

int tm_create_ckdTask_From_CKDDML(tag_t new_item )
{
	int ifail=ITK_ok;	

	printf("\n Ketan Inside tm_create_ckdTask_From_CKDDML......\n");fflush(stdout);

	if(new_item != NULLTAG)
	{
		char *item_id 	   = NULL;
		char *DML_no 	   = NULL;
		char **DesignGroupList;
		char **DMLMdAddList;
		char *DMLrlstype   = NULL;
		char *DMLObjName   = NULL;
		char *DMLObjDesc   = NULL;
		char*			CKDNum					=NULL;
		int	 num,mad	   = 0;

		printf("\n Ketan Inside class T5_CKDTaskRevision......\n");fflush(stdout);

		CALLAPICKD(AOM_ask_value_string( new_item, "item_id", &item_id));
		CALLAPICKD(AOM_ask_value_string( new_item, "current_id", &DML_no));
		CALLAPICKD(AOM_ask_value_strings( new_item,"t5_crdesigngroup",&num,&DesignGroupList));
		CALLAPICKD(AOM_ask_value_string( new_item, "t5_rlstype", &DMLrlstype));
		CALLAPICKD(AOM_ask_value_strings(new_item,"t5_MdAddress",&mad,&DMLMdAddList));
		CALLAPICKD(AOM_ask_value_string( new_item, "object_name", &DMLObjName));
		CALLAPICKD(AOM_ask_value_string( new_item, "object_desc", &DMLObjDesc));
	
		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n DMLrlstype : %s\n",DMLrlstype);fflush(stdout);
		printf("\n num is : %d\n",num);fflush(stdout);
		printf("\n ModuleAddress Count : %d\n",mad);fflush(stdout);
		printf("\n DMLObjName :%s\n",DMLObjName);fflush(stdout);
		printf("\n DMLObjDesc : %s\n",DMLObjDesc);fflush(stdout);

		CKDNum = strtok (DML_no,"_");
		printf("\n CKDNum => %s\n",CKDNum);fflush(stdout);

		tag_t  CurrentRoleTag = NULLTAG;
		char*	roleName	= NULL;
		char*	PlantName	= NULL;
		
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n roleName => %s\n",roleName); fflush(stdout);
		PlantName=subString_CKD(roleName,3,4);
		printf("\n PlantName => %s\n", PlantName);

		if(num > 0)
		{
			int number_found;
			int	status;
			tag_t *list_of_WSO_tags=NULLTAG;
			WSO_search_criteria_t  	criteria;
			char *item_id_dup = (char *)MEM_alloc(80 * sizeof(char));
			strcpy(item_id_dup,CKDNum);
			strcat (item_id_dup,"_");
			strcat (item_id_dup,DesignGroupList[0]);
			strcat (item_id_dup,"_");
			strcat (item_id_dup,PlantName);

			printf("\n Ketan Task Final Number => %s\n",item_id_dup);fflush(stdout);
			
			WSOM_clear_search_criteria(&criteria);
			strcpy(criteria.name,item_id_dup);
			//strcpy(criteria.class_name,"T5_ChangeTaskRevision");
			strcpy(criteria.class_name,"T5_CKDTaskRevision");
			status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);			
			
			printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

			if(number_found == 0)
			{
				tag_t item=NULLTAG;
				tag_t rev=NULLTAG;
				tag_t relation_type,relation = NULLTAG;
				printf("\n item_id : %s and DML_no : %s\n ",item_id,DML_no);fflush(stdout);
				
				char**                  stringArrayInput                       =       NULL;
                char**                  stringArrInput                        =       NULL;
                int                     n_strings                              =       1;
                int                     l_strings                              =       300;
				int                     index                                  =       0;
				tag_t                   ObjectTag                              =       NULLTAG;
				tag_t                   ObTag                                  =       NULLTAG;
                tag_t                   ObTagRev                               =       NULLTAG;
				char*                   tempString                             =       NULL;
				tag_t                   createInputTag                         =       NULLTAG;
                tag_t                   createInputTagRev                      =       NULLTAG;
				
				stringArrayInput = (char**)malloc( n_strings * sizeof *stringArrayInput );
                stringArrInput = (char**)malloc( n_strings * sizeof *stringArrInput );
				
				
                for( index=0; index<n_strings; index++ )
                {
                    stringArrayInput[index] = (char*)malloc( l_strings + 1 );
                }
                for( index=0; index<n_strings; index++ )
                {
                    stringArrInput[index] = (char*)malloc( l_strings + 1 );
                }
				
				//ITKCALL(TCTYPE_ask_type("T5_ChangeTask",&ObTag));
				ITKCALL(TCTYPE_ask_type("T5_CKDTask",&ObTag));
                ITKCALL(TCTYPE_construct_create_input(ObTag,&createInputTag));
                //ITKCALL( TCTYPE_find_type("T5_ChangeTaskRevision", NULL, &ObTagRev) );
                ITKCALL( TCTYPE_find_type("T5_CKDTaskRevision", NULL, &ObTagRev) );
                ITKCALL( TCTYPE_construct_create_input(ObTagRev, &createInputTagRev) );
				
				tc_strcpy( stringArrInput[0], item_id_dup);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag, (char*)"item_id", 1, (const char**)stringArrInput));
				
				tc_strcpy( stringArrInput[0], DMLObjName);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag, (char*)"object_name", 1, (const char**)stringArrInput));
				
				tc_strcpy( stringArrInput[0], DMLObjDesc);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag,(char*) "object_desc", 1, (const char**)stringArrInput));
				
				ITKCALL( AOM_tag_to_string(createInputTagRev, &tempString) );
                tc_strcpy( stringArrInput[0], tempString);
                ITKCALL( TCTYPE_set_create_display_value( createInputTag,(char*) "revision", 1,(const char**)stringArrInput) );
				
				//tc_strcpy( stringArrayInput[0], DesignGroupList[0]);
                //ITKCALL( TCTYPE_set_create_display_value( createInputTagRev, "t5_crdesigngroup", 1, (const char**)stringArrayInput) );
				
				ITKCALL( TCTYPE_create_object(createInputTag, &item) );
                AOM_save_without_extensions(item);  
                if(AOM_refresh(item,TRUE));
				
				ITK_CALL_CKD(ITEM_ask_latest_rev(item,&rev));
				
				//CALLAPICKD(ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",NULL,&item,&rev));
				printf("\n Item created first time only with item_id \n");fflush(stdout);

				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				GRM_create_relation(new_item, rev, relation_type,  NULLTAG, &relation);
				GRM_save_relation(relation);

				if(mad>0)
				 {
					int m=0;
					for(m=0;m<mad;m++)
					{
						printf("\nSetting..DML Module Address : %s\n",DMLMdAddList[m]);
						CALLAPICKD(AOM_set_value_string_at(rev,"t5_ModuleAddress",m,DMLMdAddList[m]));
					}
					CALLAPICKD(AOM_save_without_extensions(rev));
					CALLAPICKD(AOM_refresh(rev,0));
				 }

				 // Adding Release status of CKD DML and Task
				 tm_create_relstate_ckddml_task(PlantName,new_item,rev);

			}
			else 
			{ 
				printf("\n Required item_id already in DB....  \n");fflush(stdout); 
			}
			MEM_free(list_of_WSO_tags);
		}
	}
	return 0;
}

int tm_updateObjMasterFormNameCKD(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;

	printf("\nInside tm_updateMasterFormName");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\ntm_updateObjMasterFormName: Item ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
    ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));


	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			printf("\n Type Name:");fflush(stdout);
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			

	
			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;
			

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
            //if (tc_strcmp(type_name,"T5_MBOMDMLMaster")==0)

			//if (tc_strcmp(type_name,"T5_CkdDmlMaster")==0)
			{
				printf("\n Inside secondary Type Name:%s,%s ..............\n",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
			
		}
	}
	return 0;
}

int tm_updateObjRevMasterFormNameCKD(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nInside tm_updateObjRevMasterFormNameCKD ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);//fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s..............",type_name);//fflush(stdout);
			
			//if (tc_strcmp(type_name,"T5_MBOMDMLRevisionMaster")==0)
			//if(tc_strcmp(type_name,"T5_CkdDmlRevisionMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
				printf("I am In Matched T5_CkdDmlRevisionMaster...................\n");
			}
			// else
			// {
			// 	printf("Not Matched...................\n");
			// }
			

		}
	}
	return 0;
}

/* FUNCTION TO CREATE CKD DML */
int tm_ckddml_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	tag_t new_item				= NULLTAG;
	tag_t item_master_form		= NULLTAG;
	tag_t item_rev_master_form  = NULLTAG;
	int isnew              = 0;		
	
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	printf("\n Ketan Inside CKD DML Creation >> tm_ckddml_set_init_val \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	SmlChckStr1		= NULL;
	char*	BscDmlA			= NULL;
	char*	BscDml			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[100]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s \n",CurrYear);fflush(stdout);
	
	SmlChckStr1 = (char *) MEM_alloc( 5000 * sizeof(char) );
	BscDmlA = (char *) MEM_alloc( 5000 * sizeof(char) );
	BscDml = (char *) MEM_alloc( 5000 * sizeof(char) );
	tc_strcpy(SmlChckStr1,CurrYear);
	//tc_strcat(SmlChckStr1,"SM");
	tc_strcat(SmlChckStr1,"CK");
	tc_strcpy(BscDmlA, SmlChckStr1);	
	tc_strcpy(BscDml, SmlChckStr1);
	tc_strcat(BscDml,"%");	
	
	printf("\n Current DML String >> %s \n",BscDml);fflush(stdout);
	if(new_item != NULLTAG && isnew==1)
	{
		char *value                     = NULL;
		char *DmlName                   = NULL;

		char *newid;
		char *item_idval=NULL;

		newid=(char *) MEM_alloc (20);

		tc_strcpy(newid,"*");

		const char *moduletype={newid};
		const char *attr="item_id";

		POM_enquiry_create("ckd_dml_enq");

		const char *sel_attrs[1] = {"puid"};

		POM_enquiry_add_select_attrs("ckd_dml_enq", "t5_CkdDml", 1, sel_attrs);
		POM_enquiry_set_string_value("ckd_dml_enq", "value", 1, &moduletype,POM_enquiry_bind_value);
		POM_enquiry_set_attr_expr ("ckd_dml_enq", "expression", "t5_CkdDml", attr, POM_enquiry_like, "value");
		POM_enquiry_set_where_expr ( "ckd_dml_enq", "expression" );

		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		POM_enquiry_add_order_attr ( "ckd_dml_enq","t5_CkdDml","item_id",POM_enquiry_desc_order);

		POM_enquiry_execute("ckd_dml_enq", &rows, &columns, &report);

		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			AOM_ask_value_string(objtag,"item_id",&item_idval);
			printf("\n The DmlName is : %s \n",item_idval);fflush(stdout);			
						
			int		runningSrl;
			
			//const char* from = "1000010100";  
			char* from = item_idval;  
			char *CkdRSrlNo = (char*) malloc(10);
			strncpy(CkdRSrlNo, from+4, 10); 


			printf("\n \n Recieved running serial :  %s \n",CkdRSrlNo);fflush(stdout);	
			runningSrl = atoi(CkdRSrlNo);
			runningSrl = runningSrl + 1;
			
			printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
			char runningSrlChar[10];	
			sprintf(runningSrlChar, "%06d", runningSrl);
			char *FinalRSrl = (char*) malloc(10);
			strncpy(FinalRSrl, runningSrlChar+1, 6);
			//	tc_strcat(BscDmlA,FinalRSrl);		
			tc_strcat(BscDmlA,runningSrlChar);		
		}
		else
		{		
			tc_strcat(BscDmlA,"000001");
		}

		printf("\n BscDmlA =>  %s \n",BscDmlA);fflush(stdout);	

		POM_enquiry_delete("ckd_dml_enq");

		tag_t  CurrentRoleTag = NULLTAG;
		char*	roleName	= NULL;
		char*	PlantName	= NULL;
		
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n roleName => %s\n",roleName); fflush(stdout);
		PlantName=subString_CKD(roleName,3,4);
		printf("\n PlantName => %s\n", PlantName);

		//strcat (item_id_dml_Str,DmlLastSerial);
		strcat (BscDmlA,"_");
		strcat (BscDmlA,PlantName);

		printf("\n Ketan New Final Build CKD DML ID will be =>  %s \n",BscDmlA);fflush(stdout);	
		
		if(BscDmlA!= NULL)
		{
			if(new_item != NULLTAG )
			{
				printf("\n Inside 1111 \n");fflush(stdout);

				CALLAPICKD(AOM_lock(new_item));
				CALLAPICKD(AOM_set_value_string(new_item,"item_id", BscDmlA));
				CALLAPICKD(AOM_save_without_extensions(new_item));						
				CALLAPICKD(AOM_unlock(new_item));
				
				tag_t			CKDTagrev		= NULLTAG;
				if(ITEM_ask_latest_rev(new_item,&CKDTagrev));
				
				printf("\n Going to Update Master \n");fflush(stdout);

				CALLAPICKD(tm_updateObjMasterFormNameCKD(new_item, BscDmlA));//Update MASTER
				CALLAPICKD(tm_updateObjRevMasterFormNameCKD(CKDTagrev, BscDmlA));//Update MASTER

				printf("\n Calling tm_create_ckdTask_From_CKDDML \n");fflush(stdout);
				CALLAPICKD(tm_create_ckdTask_From_CKDDML(CKDTagrev));
				printf("\n Task Created Successfully \n");fflush(stdout);

				//CALLAPICKD(AOM_lock(item_master_form));
				//CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", BscDmlA));
				//CALLAPICKD(AOM_save_without_extensions(item_master_form));						
				//CALLAPICKD(AOM_unlock(item_master_form));

				// char *rev_master_form_id=NULL;
				// rev_master_form_id=(char *)MEM_alloc(30);
				// tc_strcpy(rev_master_form_id,BscDmlA); 
				// tc_strcat(rev_master_form_id,"/"); 
				// tc_strcat(rev_master_form_id,rev_id); 
				// 
				// CALLAPICKD(AOM_lock(item_rev_master_form));
				// CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
				// CALLAPICKD(AOM_save_without_extensions(item_rev_master_form));
				// CALLAPICKD(AOM_unlock(item_rev_master_form));
				// 
				// printf("\n DML Item ID Updated With %s",BscDmlA);fflush(stdout);			
				// 
				// MEM_free(rev_master_form_id);
				MEM_free(BscDmlA);

			}
			else
			{
				//	item_id=BscDmlA;	
                printf("\n NULLTAG new_item");fflush(stdout);
			}

		}		
	}	
	return 0;
}


int tm_set_erc_dmlval_ckddml( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	printf("\n DML Revision IMANTYPE_init_intl_props invoked ");fflush(stdout);

	
	return 0;
}


/* FUNCTION TO CREATE ASSIGN BARREL TO COUNTRY CODE */
int CKDBarrelAssignFunc( void *return_data )
{
	int status;
	int				ifail 						= ITK_ok;
	printf("\n I am in CKDBarrelAssignFunc function");fflush(stdout);

	char			*PartNum					= NULL;
	char			*FastIncVal					= NULL;
	char			*RevIncVal					= NULL;
	char			*CountryVal					= NULL;
	char			*BarrelNum					= NULL;
	char			*output						= NULL;
	tag_t  			ObTag                     = NULLTAG;
	tag_t  			createInputTag              = NULLTAG;
	tag_t  			boTag			            = NULLTAG;
	char**                  stringArrInput                        =       NULL;
	int n_strings=5;
	int index = 0;
	USERARG_get_string_argument(&PartNum);
	USERARG_get_string_argument(&FastIncVal);
	USERARG_get_string_argument(&RevIncVal);
	USERARG_get_string_argument(&CountryVal);
	USERARG_get_string_argument(&BarrelNum);
	
	printf("\n Recieved Input argument in ITK CKDBarrelAssignFunc(): %s | %s | %s | %s | %s ",PartNum,FastIncVal,RevIncVal,CountryVal,BarrelNum);fflush(stdout);

	stringArrInput = (char**)malloc( n_strings * sizeof *stringArrInput );        
    for( index=0; index<n_strings; index++ )
    {
        stringArrInput[index] = (char*)malloc( 40 + 1 );
    }

	TCTYPE_ask_type("T5_AltBrl",&ObTag);
	TCTYPE_construct_create_input(ObTag,&createInputTag);
	tc_strcpy( stringArrInput[0], BarrelNum);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_BrlNum",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], PartNum);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_ErcEsNo",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], FastIncVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_FstnrInc",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], CountryVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_PlcCode",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], RevIncVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_RvtInc",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], BarrelNum);
	TCTYPE_set_create_display_value( createInputTag, (char *)"object_name", 1, (const char**)stringArrInput);

	TCTYPE_create_object(createInputTag,&boTag);
	printf("\n Auto Task created successfully \n");fflush(stdout);
	AOM_save_without_extensions(boTag);
	printf("\n Task saved \n");fflush(stdout);
	
	printf("\n End of program.....!!\n\n");fflush(stdout);
	
	output = (char *)"NULL";	
	*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) return_data), output); 
	
	return ifail;
	/* Program Logic End*/
}


/* FUNCTION TO CREATE LOT NUMBER */

int tm_lot_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
		
	tag_t new_item				= NULLTAG;
	int isnew              = 0;

	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	printf("\n Ketan Inside tm_lot_num_gen_val \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	CkdDml			= NULL;
	char	*ESorDS			= NULL;
	char	*VcNo			= NULL;
	char*	TotQty			= NULL;
	char*	unitQty			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[6]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s",CurrYear);fflush(stdout);	
	
	CkdDml =  (char *)MEM_alloc(50);
	VcNo =  (char *)MEM_alloc(50);
	TotQty =  (char *)MEM_alloc(50);
	unitQty = (char *)MEM_alloc(50);
	
	int lotTotQty=0;
	int lotQty=0;
	int ModNumOfLots=0;
	
	printf("\n isnew : %d\n",isnew); fflush(stdout);
	
	tag_t new_rev = NULLTAG;

	//if(*new_item != NULLTAG)
	if(new_item != NULLTAG && isnew==1)
	{
		printf("\n Test 1 \n");fflush(stdout);	
		CALLAPICKD(ITEM_ask_latest_rev(new_item, &new_rev));
		char *value                     = NULL;
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_WbsID",&CkdDml));
		printf("\n The the CKD DMl is :  %s \n",CkdDml);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_PartNumber",&VcNo));
		printf("\n The the CKD DMl VC is :  %s \n",VcNo);fflush(stdout);	

		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_LotTotQty",&TotQty));
		printf("\n The the CKD DMl TotQty is :  %s \n",TotQty);fflush(stdout);
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_LotQty",&unitQty));
		printf("\n The the CKD DMl unitQty is :  %s \n",unitQty);fflush(stdout);
		
		lotTotQty=atoi(TotQty);
		lotQty=atoi(unitQty);
		
		ModNumOfLots = lotTotQty%lotQty;
		printf("\n The the CKD DMl ModNumOfLots is :  %d , Hence both the Quantity are divisible \n",ModNumOfLots);fflush(stdout);
		
		
		char* VcNoDup = VcNo;  
		printf("\n The VcNo:  %s \n",VcNo);fflush(stdout);
		char *CountryCode = (char *)MEM_alloc(10);
		tc_strcpy(CountryCode,"");
		printf("\n The CountryCode:  %s \n",CountryCode);fflush(stdout);
		strncpy(CountryCode, VcNoDup,2); 
		CountryCode[2]='\0';
		printf("\n The first 2 character of  CountryCode:  %s \n",CountryCode);fflush(stdout);
		
		char *Lotnumber = (char*) malloc(10);
		tc_strcpy(Lotnumber,CountryCode);
		tc_strcat(Lotnumber,CurrYear);
		printf("\n The temporary Lotnumber :  %s \n",Lotnumber);fflush(stdout);
				
		char *newid;
		char *item_idval=NULL;

		newid=(char *) MEM_alloc (20);

		tc_strcpy(newid,Lotnumber);
		tc_strcat(newid,"*");
		printf("\n The query value :  %s \n",newid);fflush(stdout);

		const char *new_id_val={newid};
		const char *attr="item_id";

		CALLAPICKD(POM_enquiry_create("ckd_lot_num_enq"));

		const char *sel_attrs[1] = {"puid"};

		CALLAPICKD(POM_enquiry_add_select_attrs("ckd_lot_num_enq", "T5_LotNum", 1, sel_attrs));
		CALLAPICKD(POM_enquiry_set_string_value("ckd_lot_num_enq", "value", 1, &new_id_val,POM_enquiry_bind_value));
		CALLAPICKD(POM_enquiry_set_attr_expr ("ckd_lot_num_enq", "expression", "T5_LotNum", attr, POM_enquiry_like, "value"));
		CALLAPICKD(POM_enquiry_set_where_expr ( "ckd_lot_num_enq", "expression" ));
		CALLAPICKD(POM_enquiry_add_order_attr ( "ckd_lot_num_enq","T5_LotNum","creation_date",POM_enquiry_desc_order));
		
		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		CALLAPICKD(POM_enquiry_execute("ckd_lot_num_enq", &rows, &columns, &report));

		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			CALLAPICKD(AOM_ask_value_string(objtag,"item_id",&item_idval));
			printf("\n The previous Lotnumber is : %s \n",item_idval);fflush(stdout);		

			int		runningSrl;
			
			char* from = item_idval;  
			char *lotSrlNo = (char *)MEM_alloc(4);
			char *appndSrlNo = (char *)MEM_alloc(6);
			strncpy(lotSrlNo, from+4, 4); 
            lotSrlNo[4] ='\0';
			
			printf("\n \n Received running serial :  %s \n",lotSrlNo);fflush(stdout);	
			runningSrl = atoi(lotSrlNo);
			runningSrl = runningSrl + 1;
			
			printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
			
			char* runningSrlChar=(char *)MEM_alloc(4);
			tc_strcpy(newid,runningSrlChar);
			sprintf(runningSrlChar, "%04d", runningSrl);
			
			printf("\n \n runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
		
			tc_strcat(Lotnumber,runningSrlChar);			
		}
		else
		{		
			tc_strcat(Lotnumber,"0001");
		}
		
		POM_enquiry_delete("ckd_lot_num_enq");
		
		printf("\n \n Final Build Lot Number will be :  %s \n",Lotnumber);fflush(stdout);	
		
		if(Lotnumber!= NULL)
		{
			CALLAPICKD(AOM_lock(new_item));
			CALLAPICKD(AOM_set_value_string(new_item,"item_id", Lotnumber));
            printf("\n \n In Item master lot number built %s \n",Lotnumber);fflush(stdout);	
			
			CALLAPICKD(AOM_set_value_string(new_item,"object_name", Lotnumber));
			printf("\n set the object_name_lotnum iin new item created :");fflush(stdout);
      
			CALLAPICKD(AOM_save_without_extensions(new_item));						
			CALLAPICKD(AOM_unlock(new_item));
			
			CALLAPICKD(AOM_lock(new_rev));
			CALLAPICKD(AOM_set_value_string(new_rev,"object_name", Lotnumber));
			printf("\n set the object_name_lotnum iin new item revision created : ");fflush(stdout);
			CALLAPICKD(AOM_save_without_extensions(new_rev));						
			CALLAPICKD(AOM_unlock(new_rev));

			CALLAPICKD(tm_updateObjMasterFormNameCKD(new_item, Lotnumber));//Update MASTER
			CALLAPICKD(tm_updateObjRevMasterFormNameCKD(new_rev, Lotnumber));//Update MASTER
			
			// CALLAPICKD(AOM_lock(item_master_form));
			// CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", Lotnumber));
			// CALLAPICKD(AOM_save_without_extensions(item_master_form));						
			// CALLAPICKD(AOM_unlock(item_master_form));
			// 
			// char *rev_master_form_id=NULL;
			// rev_master_form_id=(char *)MEM_alloc(30);
			// tc_strcpy(rev_master_form_id,Lotnumber); 
			// tc_strcat(rev_master_form_id,"/"); 
			// tc_strcat(rev_master_form_id,rev_id); 
			// 
			// CALLAPICKD(AOM_lock(item_rev_master_form));
			// CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
			// CALLAPICKD(AOM_save_without_extensions(item_rev_master_form));
			// CALLAPICKD(AOM_unlock(item_rev_master_form));

			printf("\n Lotnumber Updated With %s",Lotnumber);fflush(stdout);			

			//MEM_free(rev_master_form_id);
      
		}
		else
		{
			printf("\n NULLTAG new_item");fflush(stdout);
		}

	
	return ifail;
}

}

/* FUNCTION TO CREATE BOX NUMBER */
int tm_Boxqty_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	tag_t new_item				= NULLTAG;
	int isnew              = 0;
	// New
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );
	//
	printf("\n Ketan Inside tm_Boxqty_num_gen_val \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	lotnumber			= NULL;
	char*	casecode			= NULL;
		
	lotnumber =  (char *)MEM_alloc(20);
	casecode =  (char *)MEM_alloc(10);
	
	tag_t new_rev = NULLTAG;
	printf("\n isnew : %d\n",isnew); fflush(stdout);
	
	//if(*new_item != NULLTAG)
	if(new_item != NULLTAG && isnew==1)
	{
		printf("\n Test 1 \n");fflush(stdout);	
		CALLAPICKD(ITEM_ask_latest_rev(new_item, &new_rev));

		char *value                     = NULL;
				
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_Cscd",&casecode));
		printf("\n The casecode is :  %s \n",casecode);fflush(stdout);	
		
		if (casecode!=NULL)
		{
		 
		}
		else
		{
		 tc_strdup("EM",&casecode); 
		}
				
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_LotVal",&lotnumber));
		printf("\n The lotnumber is :  %s \n",lotnumber);fflush(stdout);	

		char *BoxQtyNo = (char *)MEM_alloc(20);
		
		tc_strcpy(BoxQtyNo,"");
		tc_strcat(BoxQtyNo,lotnumber);
		tc_strcat(BoxQtyNo,"_");
		tc_strcat(BoxQtyNo,casecode);
		
		
		printf("\n \n Final Build Lot Number will be :  %s \n",BoxQtyNo);fflush(stdout);	
		
		
		if(BoxQtyNo!= NULL)
		{
			CALLAPICKD(AOM_lock(new_item));
			CALLAPICKD(AOM_set_value_string(new_item,"item_id", BoxQtyNo));
			printf("\n \n In Item master BoxQtyNo built %s \n",BoxQtyNo);fflush(stdout);	
		
					
			CALLAPICKD(AOM_set_value_string(new_item,"object_name", BoxQtyNo));
			printf("\n set the object_name_BoxQtyNo iin new item created : ");fflush(stdout);
			
			CALLAPICKD(AOM_save_without_extensions(new_item));						
			CALLAPICKD(AOM_unlock(new_item));
      
			CALLAPICKD(AOM_lock(new_rev));
			CALLAPICKD(AOM_set_value_string(new_rev,"object_name", BoxQtyNo));
			printf("\n set the object_name_BoxQtyNo iin new item revision created ");fflush(stdout);
			CALLAPICKD(AOM_save_without_extensions(new_rev));						
			CALLAPICKD(AOM_unlock(new_rev));

			CALLAPICKD(tm_updateObjMasterFormNameCKD(new_item, BoxQtyNo));//Update MASTER
			CALLAPICKD(tm_updateObjRevMasterFormNameCKD(new_rev, BoxQtyNo));//Update MASTER
			
			
			// CALLAPICKD(AOM_lock(item_master_form));
			// CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", BoxQtyNo));
			// CALLAPICKD(AOM_save_without_extensions(item_master_form));						
			// CALLAPICKD(AOM_unlock(item_master_form));
			// 
			// char *rev_master_form_id=NULL;
			// rev_master_form_id=(char *)MEM_alloc(30);
			// tc_strcpy(rev_master_form_id,BoxQtyNo); 
			// tc_strcat(rev_master_form_id,"/"); 
			// tc_strcat(rev_master_form_id,rev_id); 
			// 
			// CALLAPICKD(AOM_lock(item_rev_master_form));
			// CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
			// CALLAPICKD(AOM_save_without_extensions(item_rev_master_form));
			// CALLAPICKD(AOM_unlock(item_rev_master_form));

			printf("\n BOX Quantity Updated With %s",BoxQtyNo);fflush(stdout);			

			//MEM_free(rev_master_form_id);
      
		}
		else
		{	
            printf("\n NULLTAG new_item \n");fflush(stdout);
		}
		
	
	return ifail;
}

}

int tm_create_relstate_CKD_Dummy(char* PlantName, tag_t CKDDummyRev_Tag)
{
	int ifail=ITK_ok;	

	char*	CKDDummy_no				= NULL;
	char*	PlantLcs				= NULL;
	char*	CKDDmyReleaseStatus		= NULL;
		
	tag_t   CKDDmystatus			= NULLTAG;
	
	logical CKDDmy_retain			= false;
	
	PlantLcs	= (char *)MEM_alloc(100);
		
	tc_strcpy(PlantLcs,"");
	
	printf("\n Ketan Inside tm_create_relstate_CKD_Dummy......\n");fflush(stdout);

	CALLAPICKD(AOM_ask_value_string(CKDDummyRev_Tag,"current_id", &CKDDummy_no));
	
	printf("\n CKDDummy_no => [%s] || PlantName => [%s]\n",CKDDummy_no,PlantName);fflush(stdout);

	if (tc_strcmp(PlantName,"STDJ") == 0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDjWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDL") == 0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDlWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDD") == 0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDdWrkg");
	}
	else if (tc_strcmp(PlantName,"STDP") == 0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
	    tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDU") == 0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDuWrkg");	
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);
		tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}

	printf("\n Final PlantLcs is => [%s] \n", PlantLcs);fflush(stdout);

	CALLAPICKD(RELSTAT_create_release_status(PlantLcs,&CKDDmystatus));
	CALLAPICKD(AOM_ask_name(CKDDmystatus, &CKDDmyReleaseStatus));
	printf("\n CKDDmyReleaseStatus => %s\n",CKDDmyReleaseStatus);fflush(stdout);
	CALLAPICKD(RELSTAT_add_release_status(CKDDmystatus,1,&CKDDummyRev_Tag,CKDDmy_retain));

	printf("\n Release status created in CKD Dummy \n");fflush(stdout);

	return 0;
}

int tm_create_PlantCS_CKD_Dummy(char* PlantName, tag_t CKDDummyRev_Tag)
{
	int ifail=ITK_ok;	

	char*	CKDDummy_no				= NULL;
	char*	Plantdummycs			= NULL;
		
	Plantdummycs	= (char *)MEM_alloc(100);
		
	tc_strcpy(Plantdummycs,"");
	
	printf("\n Ketan Inside tm_create_PlantCS_CKD_Dummy......\n");fflush(stdout);

	CALLAPICKD(AOM_ask_value_string(CKDDummyRev_Tag,"current_id", &CKDDummy_no));
	
	printf("\n CKDDummy_no => [%s] || PlantName => [%s]\n",CKDDummy_no,PlantName);fflush(stdout);

	if (tc_strcmp(PlantName,"STDJ") == 0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
	    tc_strcpy(Plantdummycs, "t5_JsrMakeBuyIndicator");		
	}
	else if (tc_strcmp(PlantName,"STDL") == 0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
	    tc_strcpy(Plantdummycs, "t5_LkoMakeBuyIndicator");		
	}
	else if (tc_strcmp(PlantName,"STDD") == 0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
	    tc_strcpy(Plantdummycs, "t5_DwdMakeBuyIndicator");
	}
	else if (tc_strcmp(PlantName,"STDP") == 0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
	    tc_strcpy(Plantdummycs,"t5_PunMakeBuyIndicator");		
	}
	else if (tc_strcmp(PlantName,"STDU") == 0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
	    tc_strcpy(Plantdummycs, "t5_PnrMakeBuyIndicator");	
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);
		tc_strcpy(Plantdummycs,"t5_PunMakeBuyIndicator");		
	}

	printf("\n Final Plantdummycs is => [%s] \n", Plantdummycs);fflush(stdout); // 21052025

	CALLAPICKD(AOM_lock(CKDDummyRev_Tag));
	//CALLAPICKD(AOM_set_value_string(CKDDummyRev_Tag,Plantdummycs,"E50")); old
	CALLAPICKD(AOM_set_value_string(CKDDummyRev_Tag,Plantdummycs,"E99"));
	CALLAPICKD(AOM_save_without_extensions(CKDDummyRev_Tag));						
	CALLAPICKD(AOM_unlock(CKDDummyRev_Tag));

	printf("\n Plant CS Updated in CKD Dummy \n");fflush(stdout);

	return 0;
}

/*CKD DUMMY PART NUMBER GENRATION */
int tm_ckdDmyPrt_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;

	tag_t new_item				= NULLTAG;
	int isnew              = 0;
	// New
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );
	//
	
	printf("\n Ketan Inside new Entering tm_ckdDmyPrt_num_gen_val \n");fflush(stdout);

	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	partnumber		= NULL;
	char*	phantom			= NULL;
	char*	LRindi			= NULL;
	char*	ckdDML			= NULL;
	char*	ckdCS			= NULL;
	char*	colourIndi		= NULL;
	char*	item_idval		= NULL;
	char*	item_idseq		= NULL;
	char*	item_projcode	= NULL;
	char*	item_desgnGrp	= NULL;
	char*	partnumberQry	= NULL;
	double objWeight=0.0;
	
	int allowCreate=0;
	
	partnumber 	=  (char *)MEM_alloc(20);
	phantom 	=  (char *)MEM_alloc(20);
	LRindi 		=  (char *)MEM_alloc(20);
	ckdDML	 	=  (char *)MEM_alloc(20);
	ckdCS	 	=  (char *)MEM_alloc(20);
	item_idval 	=  (char *)MEM_alloc(10);
	item_idseq  =  (char *)MEM_alloc(10);
	item_projcode =  (char *)MEM_alloc(10);
	item_desgnGrp =  (char *)MEM_alloc(10);
	partnumberQry =  (char *)MEM_alloc(20);tc_strcpy(partnumberQry,"");
	
	
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char *rolename=NULL;

	char*	PlantName	= NULL;
	
    rolename =  (char *)MEM_alloc(100);
    tag_t  CurrentRoleTag = NULLTAG;
    char*       roleName=NULL;//[SA_name_size_c+1]  ;
    ITK_CALL_CKD(SA_ask_current_role(&CurrentRoleTag));
    ITK_CALL_CKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
    printf("\n roleName : %s\n",roleName); fflush(stdout);

	PlantName=subString_CKD(roleName,3,4);
	printf("\n PlantName => %s\n", PlantName);

	getAllPlantDetailsCKD(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
	
	tag_t new_rev = NULLTAG;
	printf("\n isnew : %d\n",isnew); fflush(stdout);

	//if(new_item != NULLTAG)
	if(new_item != NULLTAG && isnew==1)
	{
		printf("\n Test 1 \n");fflush(stdout);	
		CALLAPICKD(ITEM_ask_latest_rev(new_item, &new_rev));
		char *value                     = NULL;
		
		logical  isNull=0;
		char* itemid;
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_TmpPrt",&partnumber));
		printf("\n The tempory partnumber is :  %s \n",partnumber);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_CkdDmyPH",&phantom));
		printf("\n The phantom is :  %s \n",phantom);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_Pos",&LRindi));
		printf("\n The LRindi is :  %s \n",LRindi);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_WbsID",&ckdDML));
		printf("\n The ckdDML is :  %s \n",ckdDML);fflush(stdout);
		
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_ClCKDVCInd",&colourIndi));
		printf("\n The colourIndi is :  %s \n",colourIndi);fflush(stdout);
		
		if (strcmp(colourIndi,"NO")==0)
		{
			printf("\n Test 2 \n");fflush(stdout);	
			tc_strdup("N",&colourIndi);
		}
		else
		{
			printf("\n Test 3 \n");fflush(stdout);	
			tc_strdup("Y",&colourIndi);
		}
		
		printf("\n Test 4 \n");fflush(stdout);	
		CALLAPICKD(AOM_ask_value_string(new_rev,"t5_CkdDmyCS",&ckdCS));
		printf("\n The ckdCS is :  %s \n",ckdCS);fflush(stdout);
		
		char *dmyInitial = subString_CKD(partnumber,0,2);
		char *dmyInitialDup = (char *)MEM_alloc(2);
		tc_strcpy(dmyInitialDup,"");
		
		printf("\n The first 2 digit of dmyInitial :  %s \n",dmyInitial);fflush(stdout); 
		
		tc_strdup(dmyInitial,&dmyInitialDup);
		
		if (strcmp(dmyInitialDup,"99")==0)
		{
			printf("\n ERROR :::The Part is already a CKD dummy part :  %s \n",partnumber);fflush(stdout); 
			allowCreate=0;
			ifail=t5CKDDummyPart;
			printf("\n  Validation ERROR !! t5CKD.c::t5CKDDummyPart =%d",ifail);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ifail,"You are not allowed to add for Dummy created Part.");

			return ifail;
		}
		else
		{	
			printf("\n starting query the selected part number :::The P :  %s",partnumber);fflush(stdout);
		}
		
		tag_t *part_rev_tag = NULLTAG;
		int partcount=0,i=0;
		ITK_CALL_CKD(getQueryItemRevision_AllType(partnumber,(char *)"Design Revision",&part_rev_tag,&partcount));
		printf("\n number of the Part queried is [%d] \n",partcount);fflush(stdout);
		if(partcount>0 && part_rev_tag!=NULLTAG )
		{
			allowCreate=1;
			for (i=0;i<partcount;i++)
			{					
				tag_t Part_tag =NULLTAG;
				Part_tag = part_rev_tag[i];
						
				 CALLAPICKD(AOM_ask_value_string(Part_tag,"item_id",&item_idval));
				 printf("\n The partnumber is valid: %s \n",item_idval);fflush(stdout);	
				
				 CALLAPICKD(AOM_ask_value_string(Part_tag,"t5_ProjectCode",&item_projcode));
				 printf("\n The partnumber item_projcode: %s \n",item_projcode);fflush(stdout);	
				 
				 CALLAPICKD(AOM_ask_value_string(Part_tag,"t5_DesignGrp",&item_desgnGrp));
				 printf("\n The partnumber item_desgnGrp: %s \n",item_desgnGrp);fflush(stdout);	
			 
			}
			
			// Ketan Commented // Skip for testing... need to re-open for validation...

			// if (strlen(item_projcode)==0)
			// {
			// 	EMH_store_error_s1(EMH_severity_error, ITK_err,"Please Select the Revision which has a Project code.");
			// 	return ITK_err;
			// }
			// else
			// {
			// 	printf("\n The error item_projcode: %s %d \n",item_projcode, strlen(item_projcode));fflush(stdout);	
			// }
			// 
			// if (strlen(item_desgnGrp)==0)
			// {
			// 	EMH_store_error_s1(EMH_severity_error, ITK_err,"Please Select the Revision which has a Design Group.");
			// 	return ITK_err;
			// }
			// else
			// {
			// 	printf("\n The error item_desgnGrp: %s  %d\n",item_desgnGrp , strlen(item_desgnGrp));fflush(stdout);	
			// }
		
		}
		else
		{
			printf("\n NO OBJECT QUERIED\n");fflush(stdout);	
			allowCreate=0;
		}
		
		if (allowCreate==1)
		{
			printf("\n Inside allowCreate \n");fflush(stdout);	
			char *CkdDmyPrtNo = (char *)MEM_alloc(20);
			
			if(((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0) || (strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )) //(strcmp(roleName,"DBA")==0) || 
			{
				tc_strcpy(CkdDmyPrtNo,"");
				tc_strcat(CkdDmyPrtNo,partnumber);
				tc_strcat(CkdDmyPrtNo,phantom);
				if((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0)) //(strcmp(roleName,"DBA")==0) || 
				{
					printf("\n Inside STDJ/APLJ \n");fflush(stdout);	
					tc_strcat(CkdDmyPrtNo,"J");
				}
				if((strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )
				{
					printf("\n Inside STDL/APLL \n");fflush(stdout);	
					tc_strcat(CkdDmyPrtNo,"L");
				}
				
				printf("\n The CkdDmyPrtNo Before: %s \n",CkdDmyPrtNo);fflush(stdout);	
				tc_strcat(partnumberQry,CkdDmyPrtNo);
				tc_strcat(partnumberQry,"*");
				printf("\n The partnumberQry : %s \n",partnumberQry);fflush(stdout);	
				 
				const char *new_id_val1={partnumberQry};
				const char *attr1="item_id";

				CALLAPICKD(POM_enquiry_create("ckd_partnum_enq"));

				const char *sel_attrs1[1] = {"puid"};

				CALLAPICKD(POM_enquiry_add_select_attrs("ckd_partnum_enq", "T5_CkdDmy", 1, sel_attrs1));
				CALLAPICKD(POM_enquiry_set_string_value("ckd_partnum_enq", "value", 1, &new_id_val1,POM_enquiry_bind_value));
				CALLAPICKD(POM_enquiry_set_attr_expr   ("ckd_partnum_enq", "expression", "T5_CkdDmy", attr1, POM_enquiry_like, "value"));
				CALLAPICKD(POM_enquiry_set_where_expr  ( "ckd_partnum_enq", "expression" ));
				//CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","creation_date",POM_enquiry_desc_order));
				CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","item_id",POM_enquiry_desc_order));
			
				tag_t gettag=NULLTAG;
				int row1=0,column1=0;
				void ***report1;
				CALLAPICKD(POM_enquiry_execute("ckd_partnum_enq",&row1,&column1,&report1));
				
				printf("\n Number of rows queried for T5_CkdDmy %d",row1);fflush(stdout); 
							    
				if(row1!=0)
				{
					printf("\n Inside row1 \n");fflush(stdout);	

					gettag=*(tag_t*)(report1[0][0]);
					
					int lenght=0;
					int incValue=0;
					char*   Getnum;
					char*   Getlast= (char *)MEM_alloc(1);
					
					char*	bufLastSerial	= NULL;
					char*	GetDummyNum	= NULL;
					
					
					CALLAPICKD(AOM_ask_value_string(gettag,"item_id",&GetDummyNum));
					printf("\n The GetDummyNumJSR/LKO is valid: %s \n",GetDummyNum);fflush(stdout);	
					
					char* dupvalue = GetDummyNum;  
					lenght=tc_strlen(GetDummyNum)-1;
					tc_strcpy(Getlast,"");
					strncpy(Getlast, dupvalue+lenght,1);
					Getlast[1]='\0';
					printf("\n The first  digit of Getlast :  %s \n",Getlast);fflush(stdout);
										
					incValue=atoi(Getlast);
					printf("\n incValue = %d",incValue);fflush(stdout);
				
					allowCreate=1;
					bufLastSerial = (char *)MEM_alloc(2);
					tc_strcpy(bufLastSerial,"");
			        incValue=incValue+1;
					printf("\n incValue = %d",incValue);fflush(stdout);
			
			        if (incValue>9)
					{
						allowCreate=0;
						ifail=t5CKDSerialNum;
						printf("\n  Validation ERROR !! t5CKD.c::t5CKDSerialNum =%d",ifail);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ifail,"Dummy Part cannot be created.");

						return ifail;
					}
					else
					{
						printf("\n Inside incValue Else \n");fflush(stdout);	
						sprintf(bufLastSerial,"%01d",incValue);
						printf("\n bufLastSerial = %s",bufLastSerial);fflush(stdout);
						tc_strcat(CkdDmyPrtNo,bufLastSerial);
					}
					
				}	
				else
				{
					printf("\n Inside row1 Else \n");fflush(stdout);	
					tc_strcat(CkdDmyPrtNo,"0");
				}
			}
			else
			{
				printf("\n Inside roleName Else \n");fflush(stdout);	
				tc_strcpy(CkdDmyPrtNo,"");
				tc_strcat(CkdDmyPrtNo,"99");
				tc_strcat(CkdDmyPrtNo,item_projcode);
				tc_strcat(CkdDmyPrtNo,item_desgnGrp);
				printf("\n The CkdDmyPrtNo Before: %s \n",CkdDmyPrtNo);fflush(stdout);	
				tc_strcat(partnumberQry,CkdDmyPrtNo);
				tc_strcat(partnumberQry,"*");
				printf("\n The partnumberQry : %s \n",partnumberQry);fflush(stdout);	
				 
				const char *new_id_val1={partnumberQry};
				const char *attr1="item_id";

				CALLAPICKD(POM_enquiry_create("ckd_partnum_enq"));

				const char *sel_attrs1[1] = {"puid"};

				CALLAPICKD(POM_enquiry_add_select_attrs("ckd_partnum_enq", "T5_CkdDmy", 1, sel_attrs1));
				CALLAPICKD(POM_enquiry_set_string_value("ckd_partnum_enq", "value", 1, &new_id_val1,POM_enquiry_bind_value));
				CALLAPICKD(POM_enquiry_set_attr_expr   ("ckd_partnum_enq", "expression", "T5_CkdDmy", attr1, POM_enquiry_like, "value"));
				CALLAPICKD(POM_enquiry_set_where_expr  ( "ckd_partnum_enq", "expression" ));
				//CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","creation_date",POM_enquiry_desc_order));
				CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","item_id",POM_enquiry_desc_order));
				
				tag_t gettag=NULLTAG;
				int row1=0,column1=0;
				void ***report1;
				CALLAPICKD(POM_enquiry_execute("ckd_partnum_enq",&row1,&column1,&report1));
			    
				if(row1!=0)
				{
					gettag=*(tag_t*)(report1[0][0]);
					CALLAPICKD(AOM_ask_value_string(gettag,"item_id",&item_idseq));
					printf("\n The partnumber seq is valid: %s \n",item_idseq);fflush(stdout);	
					 
					char* dmylst = item_idseq;  
					char *dmyLast = (char *)MEM_alloc(4);
					tc_strcpy(dmyLast,"");
					strncpy(dmyLast, dmylst+8,4);
					dmyLast[4]='\0';
					printf("\n The first 2 digit of dmyLast :  %s \n",dmyLast);fflush(stdout); 
					
					int runningSrl =0;
					char runningSrlChar[10];
					
					runningSrl = atoi(dmyLast);
					runningSrl = runningSrl + 1;
					
					printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
					
					if (runningSrl<101)
					{
						tc_strcat(CkdDmyPrtNo,"101");
					}
					else
					{
						sprintf(runningSrlChar, "%02d", runningSrl);
					}
											
					printf("\n \n runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
					tc_strcat(CkdDmyPrtNo,runningSrlChar);
				}
				else
				{
					tc_strcat(CkdDmyPrtNo,"101");
				}
				
				tc_strcat(CkdDmyPrtNo,LRindi);
			}
			
			CALLAPICKD(POM_enquiry_delete("ckd_partnum_enq"));

			printf("\n \n Final Build CKD DUMMY PART Number will be :  %s \n",CkdDmyPrtNo);fflush(stdout);	
			
			
			if(CkdDmyPrtNo!= NULL)
			{
				printf("\n Test 1111 \n",CkdDmyPrtNo);fflush(stdout);
				CALLAPICKD(AOM_lock(new_item));
				//CALLAPICKD(AOM_refresh(new_item,1));
				CALLAPICKD(AOM_set_value_string(new_item,"item_id", CkdDmyPrtNo));
				printf("\n \n In Item master ckdDmyPart built %s \n",CkdDmyPrtNo);fflush(stdout);	
				
						
				CALLAPICKD(AOM_set_value_string(new_item,"object_name", CkdDmyPrtNo));
				CALLAPICKD(AOM_save_without_extensions(new_item));						
				CALLAPICKD(AOM_unlock(new_item));
				//CALLAPICKD(AOM_refresh(new_item,0));
        
				CALLAPICKD(AOM_lock(new_rev));
				//CALLAPICKD(AOM_refresh(new_rev,1));
				CALLAPICKD(AOM_set_value_string(new_rev,"object_name", CkdDmyPrtNo));
				printf("\n set the object_name_ckdDmyPart of new item revision created ");fflush(stdout);
				
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_ColourInd", colourIndi));
				//CALLAPICKD(AOM_set_value_string(new_rev,PlantCS, ckdCS));
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_DrawingInd", "N"));
				CALLAPICKD(AOM_set_value_double(new_rev,"t5_Weight",objWeight));
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_PartType","D"));
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_DenisPart",false));
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_HazardousContents",false)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_Recyclability",false)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_Recoverable",false)); 
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_SpareInd",false)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_ListRecSpares",false)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_Dismantable",false)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_CMVRCertificationReqd",false));  	 
				//CALLAPICKD(AOM_set_value_string(new_rev,"t5_SpareCriteria","NAR")) 			
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_DesignGrp","00")) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_SamplesToAppr",false)) ;
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_HomologationReqd","N")) ;
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_MatlClass","")) ;
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_ProjectCode",item_projcode)) ;
				CALLAPICKD(AOM_set_value_logical(new_rev,"t5_ConvDoc",false)) ;
				CALLAPICKD(AOM_set_value_string(new_rev,"t5_Coated","N")) ;
				CALLAPICKD(AOM_set_value_string(new_rev,"item_revision_id","NR;1")) ;
				
			    printf("\n set the attribute_ckdDmyPart of new item created : ");fflush(stdout);
				CALLAPICKD(AOM_save_without_extensions(new_rev));						
				CALLAPICKD(AOM_unlock(new_rev));
				
				CALLAPICKD(tm_updateObjMasterFormNameCKD(new_item, CkdDmyPrtNo));//Update MASTER
				CALLAPICKD(tm_updateObjRevMasterFormNameCKD(new_rev, CkdDmyPrtNo));//Update MASTER
				
				printf("\n Ckd Dmy Part Updated With %s",CkdDmyPrtNo);fflush(stdout);			
		  
		        char* tasknumber_DML=NULL;
		       /*CREATING RELATION */
		        tag_t *dml_rev_tag = NULLTAG;
		        tag_t *task_obj_tag = NULLTAG;
				
				int dmlcount=0,j=0,n_tasksFnd=0,l=0;
				ITK_CALL_CKD(getQueryItemRevision_AllType(ckdDML,(char *)"Ckd Dml Revision",&dml_rev_tag,&dmlcount));
				printf("\n number of the dml queried is [%d] \n",dmlcount);fflush(stdout);
				if(dml_rev_tag!=NULLTAG && dmlcount>0)
				{
					printf("\n inside dml \n");
					for (j=0;j<dmlcount;j++)
					{
								
						CALLAPICKD(AOM_ask_value_string(dml_rev_tag[j] ,"item_id", &tasknumber_DML));
						printf("\n The DML number is %s",tasknumber_DML);fflush(stdout);
						
						tag_t relatnType_tag = NULLTAG;
						GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag);
						printf("\n number of the T5_DMLTaskRelation");
					 
						if (relatnType_tag!=NULLTAG)
						{
							if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag[j], relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
							{
									return ifail;
							}
							printf("\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);
						
							if (n_tasksFnd>0 && task_obj_tag!=NULLTAG)
							{
								printf("\n Ketan123 New Inside going to create relation between Task and Part \n"); fflush(stdout);

							    tag_t task_rev_tag = NULLTAG;
							    task_rev_tag=task_obj_tag[0];
							
								/* CREATING RELATION BETWEEN CKD DMY PART WITH CKD DML */
								
								tag_t relation_type,relation = NULLTAG;
								GRM_find_relation_type("CMHasSolutionItem",&relation_type);
								//GRM_create_relation(task_rev_tag,new_item, relation_type,  NULLTAG, &relation);
								GRM_create_relation(task_rev_tag,new_rev, relation_type,  NULLTAG, &relation);
								GRM_save_relation(relation);

								// Adding Release status in CKD Dummy
								tm_create_relstate_CKD_Dummy(PlantName,new_rev);

								// Adding Plantwise CS in CKD Dummy
								tm_create_PlantCS_CKD_Dummy(PlantName,new_rev);
							
							}
							
					   }
						
					}
				}
				else
				{
					printf("\n NO dml");
				}
				
				
				//MEM_free(rev_master_form_id);
		  
			}
			else
			{	
				printf("\n NULLTAG new_item");fflush(stdout);
			}
		}
		else
		{
			printf("\n creation not allowed");fflush(stdout); 
		}		
    }
	return ifail;
}


/*LR indicator For CKD Dummy*/
/****************************************************************************
Function:       dynamic_pos_LOV
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_pos_LOV( char*** LR_LovValue  ) 
{

	/* va_list for LOV_ask_values_msg */

 
    char   *user_name_string = NULL;
  
 
    char  ***values = NULL;
  
    int  
        ifail = ITK_ok;
      
      char *rolename=NULL;
      rolename =  (char *)MEM_alloc(100);

 	 tag_t  user = NULLTAG;
 
     int Lov_cnt=0;
  
	   printf("\n dynamic_pos_LOV");fflush(stdout);

	   CALLAPICKD(SA_init_module());
	   printf("\n SA_init_module");fflush(stdout);
	   CALLAPICKD(POM_get_user(&user_name_string, &user));
	   printf("\n POM_get_user");fflush(stdout);
	  
		tag_t  CurrentRoleTag = NULLTAG;
		char*       roleName = NULL ;//[SA_name_size_c+1]  ;
		ITK_CALL_CKD(SA_ask_current_role(&CurrentRoleTag));
		ITK_CALL_CKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		
		if(strcmp(roleName,"DBA")==0)
		{
		printf("\n\n  Inside DBA role : %s\n",roleName); fflush(stdout);
		setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"L");
		
		setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"R");
		
		}
		else if((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0) || (strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )
		{
			printf("\n\n  Inside JSR/LKN role : %s\n",roleName); fflush(stdout);
			setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"R");
			setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"L");
		}
		else
		{
			printf("\n\n  Inside other role : %s\n",roleName); fflush(stdout);
			setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"L");
			setAddStr_CKD(&Lov_cnt,LR_LovValue,(char *)"R");
		}

    return Lov_cnt;
}


/****************************************************************************
Function:       dynamic_pos_LengthsMethod
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_pos_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **LR_LovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n dynamic_pos_LengthsMethod");fflush(stdout);
  
  *length=dynamic_pos_LOV(&LR_LovValue);
  printf("\n dynamic_pos_LengthsMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_pos_ValuesMethod
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_pos_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
	int Lov_cnt=0;
   
  
	 printf("\n dynamic_pos_ValuesMethod");fflush(stdout);
	  
	 *n_values=dynamic_pos_LOV(&LR_LovValue);
	 printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);

	 *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	 memset (*values, 0,  *n_values * sizeof(char*));

	 for (ii = 0; ii < *n_values; ii++)
	{ 
						
		(*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
		tc_strcpy ((*values)[ii], LR_LovValue[ii]);
				   
	  } 
	  
    return ifail; 
}


/*******************************SCHEDULE YEAR FOR LOT NUMBER */
	
/****************************************************************************
Function:       dynamic_SchYear_LOV
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_SchYear_LOV( char*** SchYear_LovValue  ) 
{

	/* va_list for LOV_ask_values_msg */
  
   
    char  ***values = NULL;
  
    int   ifail = ITK_ok;
    
    int SchYear_cnt=0;
  
    printf("\n dynamic_SchYear_LOV");fflush(stdout);
	
	char TodayCurrYear[5] = {'\0'};
	time_t now;
	struct tm* now_tm;
    time(&now);
	now_tm = localtime(&now);

	strftime (TodayCurrYear, 5,"%Y", now_tm);
	printf("\n TodayCurrYear is===>[%s]",TodayCurrYear);fflush(stdout);
	
	setAddStr_CKD(&SchYear_cnt,SchYear_LovValue,TodayCurrYear);
	
	
    return SchYear_cnt;
}


/****************************************************************************
Function:       dynamic_SchYear_LengthsMethod
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_SchYear_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 

  
	
    char  **SchYear_LovValue=NULL;
  
    int  ifail = ITK_ok;
   
  
   printf("\n dynamic_pos_LengthsMethod");fflush(stdout);
  
  *length=dynamic_SchYear_LOV(&SchYear_LovValue);
  printf("\n dynamic_SchYear_LengthsMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_SchYear_ValuesMethod
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_SchYear_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 
 
    
    int    ifail = ITK_ok, ii = 0;
   
    char** SchYear_LovValue;
	int SchYear_cnt=0;
   
  
	  printf("\n dynamic_SchYear_ValuesMethod");fflush(stdout);
	  
	  *n_values=dynamic_SchYear_LOV(&SchYear_LovValue);
	  printf("\n dynamic_SchYear_ValuesMethod==>[%d]",*n_values);fflush(stdout);

	  *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	  memset (*values, 0,  *n_values * sizeof(char*));

		int m =0;
		printf("\n count=%d\n",*n_values);fflush(stdout);
		int array_size = *n_values;
		for(m=0;m<array_size;m++)
		{
			
			printf("\n SchYear_LovValue wt  %s",SchYear_LovValue[m]);fflush(stdout);
			*values[m] = SchYear_LovValue[m];
		   
		}
		
		 for (ii = 0; ii < array_size; ii++)
		{ 
		   printf("\n values attached %s",*values[ii]);fflush(stdout);
		}
  
  
    return ifail; 
}

/*******************************/

extern int CKDinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  ckddml_iman_save;
	METHOD_id_t  ckddml_rev_iman_save;
	METHOD_id_t  ckddml_rev_imantype_init_intl_props;
	METHOD_id_t  lot_number_iman_save;
	METHOD_id_t  BoxQty_number_iman_save;
	METHOD_id_t  ckddmy_partnumber_iman_save;
	METHOD_id_t  AltBrl_iman_save;
	METHOD_id_t methodpos;
	METHOD_id_t methodSchYear;
	
	printf("\n ############ After Rigister CKDinitmodule");fflush(stdout);
	
	//CALLAPICKD(METHOD_find_method("T5_CkdDml", "IMAN_save", &ckddml_iman_save));
	//CALLAPICKD(METHOD_find_method("T5_CkdDml", "ITEM_create", &ckddml_iman_save));
	//CALLAPICKD(METHOD_find_method("T5_CkdDmlRevision", TC_save_msg, &ckddml_iman_save));
	CALLAPICKD(METHOD_find_method("T5_CkdDml",TC_save_msg, &ckddml_iman_save));
	if (ckddml_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_ckddml_set_init_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddml_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_ckddml_set_init_val ,NULL));
		printf("\n IN After Rigister tm_ckddml_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_ckddml_set_init_val  == NULL");fflush(stdout);
	}
	
	// CALLAPICKD(METHOD_find_method("T5_CkdDmlRevision", "IMAN_save", &ckddml_rev_iman_save));		
	// if (ckddml_rev_iman_save.id != NULLTAG)
    // {	
	// 	printf("\n before Rigister tm_create_ckdTask");fflush(stdout);
	// 	CALLAPICKD(METHOD_add_action(ckddml_rev_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_create_ckdTask,NULL));
	// 	printf("\n  After Rigister tm_create_ckdTask");fflush(stdout);
    // }
	// else
	// {
	// 	printf("\n After Rigister tm_create_ckdTask  == NULL");fflush(stdout);
	// }
	
	//CALLAPICKD(METHOD_find_method("T5_LotNum", "ITEM_create", &lot_number_iman_save));
	//CALLAPICKD(METHOD_find_method("T5_LotNumRevision", TC_save_msg, &lot_number_iman_save));
	CALLAPICKD(METHOD_find_method("T5_LotNum", TC_save_msg, &lot_number_iman_save));
	if (lot_number_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_lot_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(lot_number_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_lot_num_gen_val ,NULL));
		printf("\n IN After Rigister tm_lot_num_gen_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_lot_num_gen_val  == NULL");fflush(stdout);
	}
		
	
	//CALLAPICKD(METHOD_find_method("T5_BoxQty", "ITEM_create", &BoxQty_number_iman_save));
	//CALLAPICKD(METHOD_find_method("T5_BoxQtyRevision", TC_save_msg, &BoxQty_number_iman_save));
	CALLAPICKD(METHOD_find_method("T5_BoxQty", TC_save_msg, &BoxQty_number_iman_save));
	if (BoxQty_number_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_Boxqty_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(BoxQty_number_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_Boxqty_num_gen_val ,NULL));
		printf("\n IN After Rigister tm_Boxqty_num_gen_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_Boxqty_num_gen_val  == NULL");fflush(stdout);
	}
		
	//CALLAPICKD(METHOD_find_method("T5_CkdDmy", "ITEM_create", &ckddmy_partnumber_iman_save));
	//CALLAPICKD(METHOD_find_method("T5_CkdDmyRevision", TC_save_msg, &ckddmy_partnumber_iman_save));
	CALLAPICKD(METHOD_find_method("T5_CkdDmy", TC_save_msg, &ckddmy_partnumber_iman_save));
	if (ckddmy_partnumber_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_ckdDmyPrt_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddmy_partnumber_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_ckdDmyPrt_num_gen_val ,NULL));
		printf("\n IN After Rigister tm_ckdDmyPrt_num_gen_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_ckdDmyPrt_num_gen_val  == NULL");fflush(stdout);
	}
		

	CALLAPICKD(METHOD_register_method( "T5_CkdDmyPosLov",LOV_ask_values_msg,&dynamic_pos_ValuesMethod, 0,&methodpos));
    CALLAPICKD(METHOD_register_method( "T5_CkdDmyPosLov",LOV_ask_num_of_values_msg,&dynamic_pos_LengthsMethod,0,&methodpos));
	printf("\n IN ******************************dynamic_pos_Method == REGISTER");fflush(stdout);	
               
    
	CALLAPICKD(METHOD_register_method( "T5_LotNumSchYrLov",LOV_ask_values_msg,&dynamic_SchYear_ValuesMethod, 0,&methodSchYear));
    CALLAPICKD(METHOD_register_method( "T5_LotNumSchYrLov",LOV_ask_num_of_values_msg,&dynamic_SchYear_LengthsMethod,0,&methodSchYear));
	printf("\n IN ******************************dynamic_SchYear_Method == REGISTER");fflush(stdout);	
   
	
	return ifail;
	
}

void CKD_stdstrcat(char **src,char* dest)
{  
    char * desc = dest ? dest : "NA";

    const size_t a = strlen(*src);
    const size_t b = strlen(desc);
    const size_t size_ab = a + b + 2;
 
    *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
    tc_strcat(*src , desc);
}

int tm_CKD_Release_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	tag_t	CKD_DMLTag				= NULLTAG;
	tag_t	objTypeTag				= NULLTAG;
	tag_t   CurrentRoleTag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t*	PartTags				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	
	char*   CKD_DMLNo			= NULL;
	char*   CKDDMLno			= NULL;
	char*	PlantNameP			= NULL;
	char*	type_name			= NULL;
	char*	roleName			= NULL;
	char*	object_type			= NULL;
	char*	TaskName			= NULL;
	char*	Part_no				= NULL;
	char*	lcsToset			= NULL;
	char*	Part_Type			= NULL;
	char*	Part_CS				= NULL;
	
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Ketan Inside tm_CKD_Release_Call .....\n");
	
	USERARG_get_tag_argument(&CKD_DMLTag);				// CKD DML Tag              
	  
	CALLAPICKD(AOM_ask_value_string(CKD_DMLTag,"item_id",&CKD_DMLNo));
	printf("\n CKD_DMLNo => %s\n",CKD_DMLNo);fflush(stdout);

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);	
	
	PlantNameP=subString_CKD(roleName,3,4);
	printf("\n PlantNameP => %s\n", PlantNameP); 

	printf("\n Getting Value from Control Object \n");fflush(stdout);

	char    *qry_entryCntrl_CKD[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
	char    *qry_valuesCntrl_CKD[3] = {"CkdPlantInf",PlantNameP,"0"};
	
	tag_t qryTagCntrl_CKD			= NULLTAG;
	tag_t* list_of_WSO_cntrl_tags_CKD= NULLTAG;

	int control_number_found_CKD = 0;
	int n_entryCntrl_CKD		 = 3;

	char*	closureRuleName = NULL;
	char*	RevisionRule	= NULL;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl_CKD));

	if (qryTagCntrl_CKD)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
	
	    CALLAPICKD(QRY_execute(qryTagCntrl_CKD, n_entryCntrl_CKD, qry_entryCntrl_CKD, qry_valuesCntrl_CKD, &control_number_found_CKD, &list_of_WSO_cntrl_tags_CKD));

		printf("\n control_number_found_CKD is : %d\n",control_number_found_CKD);fflush(stdout);
		
		if(control_number_found_CKD>0)
		{
			printf("\n Inside control object \n");fflush(stdout);		
			
			closureRuleName = NULL;
			AOM_ask_value_string( list_of_WSO_cntrl_tags_CKD[0], "t5_Userinfo1", &closureRuleName);
			printf("\n closureRuleName => [%s]\n",closureRuleName);fflush(stdout);
			
			RevisionRule = NULL;
			AOM_ask_value_string( list_of_WSO_cntrl_tags_CKD[0], "t5_Userinfo2", &RevisionRule);
			printf("\n RevisionRule => [%s] \n",RevisionRule);fflush(stdout);			
		}
	}

	// Validation 1 // for CS

	char    *qry_entryCntrl_CS[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl_CS[3] = {"CKD","CS_Validation","0"};
	
    tag_t qryTagCntrl_CS			= NULLTAG;
	tag_t* list_of_WSO_cntrl_tags_CS= NULLTAG;

    int control_number_found_CS = 0;
   	int n_entryCntrl_CS			= 3;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl_CS));

	if (qryTagCntrl_CS)
	{
	    printf("\n CS_Validation : Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl_CS, n_entryCntrl_CS, qry_entryCntrl_CS, qry_valuesCntrl_CS, &control_number_found_CS, &list_of_WSO_cntrl_tags_CS));

		printf("\n CS_Validation : control_number_found_CS is : %d\n",control_number_found_CS);fflush(stdout);
		
		if(control_number_found_CS>0)
		{
			printf("\n CS_Validation : Live. Inside code for checking CS_Validation \n");fflush(stdout);

			char PlantCS[40];
			char PlantOptCS[40];
			char PlantIA[40];
			char PlantStore[40];
			char UserAgency[40];
			char ClosureRule[40];
			char usrLocation[40];

			getAllPlantDetailsCKD(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
			
			printf("\n PlantCS %s \n",PlantCS);
			printf("\n PlantOptCS %s \n",PlantOptCS);
			printf("\n PlantAgency %s \n",PlantIA);
			printf("\n PlantStore %s \n",PlantStore);
			printf("\n UserAgency %s \n",UserAgency);
			
			if(TCTYPE_ask_object_type(CKD_DMLTag,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n CS_Validation : type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);

			if(strcmp(type_name,"T5_CkdDmlRevision")==0)
			{
				printf("\n CS_Validation : Inside class T5_CkdDmlRevision ......\n");fflush(stdout);
				
				if (CKD_DMLTag != NULLTAG)
				{
					CALLAPICKD(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));

					CALLAPICKD(GRM_list_secondary_objects_only(CKD_DMLTag,relation_type,&count,&TaskRevision));
					printf("\n CS_Validation : CKD DML to Task : %d",count);fflush(stdout);

					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						TaskRevTag = TaskRevision[TaskCnt];

						CALLAPICKD(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
						printf("\n CS_Validation : object_type is :%s",object_type);fflush(stdout);

						CALLAPICKD(AOM_ask_value_string(TaskRevTag,"item_id",&TaskName));
						printf("\n CS_Validation : TaskName is :%s",TaskName);fflush(stdout);//TZ1.43

						if(strcmp(object_type,"T5_CKDTaskRevision")==0)
						{
							PartCnt=0;

							CALLAPICKD(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n CS_Validation : CKD DML Task PartCnt: %d",PartCnt);fflush(stdout);

							if (PartCnt>0)
							{
								CALLAPICKD(GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type));
								for (k=0;k<PartCnt ;k++ )
								{
									printf("\n Part Count k =:%d",k);fflush(stdout);
									AssyTag=PartTags[k];

									CALLAPICKD(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									printf("\n Part_no is :%s",Part_no);fflush(stdout);

									CALLAPICKD(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_Type));
									printf("\n Part_Type is :%s",Part_Type);fflush(stdout);

									CALLAPICKD(AOM_ask_value_string(AssyTag,PlantCS,&Part_CS));
									printf("\n Part_CS :%s \n",Part_CS);fflush(stdout);

									if((tc_strcmp(Part_Type,"CKDVC") ==0) || (tc_strcmp(Part_Type,"SFK") ==0))
									{
										printf("\n CS_Validation : Inside CKDVC Parttype \n");fflush(stdout);
										if((tc_strcmp(PlantCS,"")==0)|| (tc_strcmp(Part_CS,"")==0))
										{
											printf("\n CS_Validation : Inside No CS of CKDVC \n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"CKDVC is not having CS,Please Check..");
											return ITK_errStore1;

										}
									}
								}
							}				
						}
					}	 
				}
			}
		}
	}
	//  Validation 1 Ended // 


	// Validation 2 // for Lot Number
	char    *qry_entryCntrl_LOT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl_LOT[3] = {"CKD","LOT_Validation","0"};
	
    tag_t	qryTagCntrl_LOT				=	NULLTAG;
    tag_t*	list_of_WSO_cntrl_tags_LOT	=	NULLTAG;

	int n_entryCntrl_LOT		= 3;
	int control_number_found_LOT= 0;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl_LOT));

	if (qryTagCntrl_LOT)
	{
	    printf("\n LOT_Validation : Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl_LOT, n_entryCntrl_LOT, qry_entryCntrl_LOT, qry_valuesCntrl_LOT, &control_number_found_LOT, &list_of_WSO_cntrl_tags_LOT));

		printf("\n LOT_Validation : control_number_found_LOT is : %d\n",control_number_found_LOT);fflush(stdout);
		
		if(control_number_found_LOT>0)
		{
			printf("\n LOT_Validation : Live. Inside code for checking LOT_Validation \n");fflush(stdout);
		
			tag_t		qryCKDTag	= NULLTAG;
			tag_t*		LotCkd		= NULLTAG;
			
			int		n_entryCKD			=1;
			int		Number_of_LotNumber = 0;

			char*	ArgCKDNum[1] = {"DML No"};
			char*	ArgCKDVal[1] = {CKD_DMLNo};

			if(QRY_find2("LOTNUMBER", &qryCKDTag));
									
			if (qryCKDTag)
			{
				printf("\n LOT_Validation : Found Query for LOTNUMBER... \n");fflush(stdout);

				if(QRY_execute(qryCKDTag, n_entryCKD, ArgCKDNum, ArgCKDVal, &Number_of_LotNumber, &LotCkd));
			}
			else
			{
				printf("\n LOT_Validation : Not Found Query LOTNUMBER... \n");fflush(stdout);
			}
			
			printf("\n LOT_Validation : Number_of_LotNumber is : %d\n",Number_of_LotNumber);fflush(stdout);

			if(Number_of_LotNumber == 0)
			{
				printf("\n LOT_Validation : Lot Number is not Assigned to CKD DML \n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please assign Lot Number for CKD DML..");
				return ITK_errStore1;
			}
		}
	}
	//  Validation 2 Ended //
	
	// Validation 3 // for Zero QTY

	char    *qry_entryCntrl_QTY[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
	char    *qry_valuesCntrl_QTY[3] = {"CKD","QTY_Validation","0"};
	
	tag_t	qryTagCntrl_QTY				=	NULLTAG;
	tag_t*	list_of_WSO_cntrl_tags_QTY	=	NULLTAG;
	
	int n_entryCntrl_QTY		= 3;
	int control_number_found_QTY= 0;
	
	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl_QTY));
	
	if (qryTagCntrl_QTY)
	{
	    printf("\n QTY_Validation :Control Object Query Found \n");fflush(stdout);
	
	    CALLAPICKD(QRY_execute(qryTagCntrl_QTY, n_entryCntrl_QTY, qry_entryCntrl_QTY, qry_valuesCntrl_QTY, &control_number_found_QTY, &list_of_WSO_cntrl_tags_QTY));
	
		printf("\n QTY_Validation : control_number_found_QTY is : %d\n",control_number_found_QTY);fflush(stdout);
		
		if(control_number_found_QTY>0)
		{
			printf("\n QTY_Validation : Live. Inside code for checking QTY_Validation \n");fflush(stdout);

			char*	type_name1			= NULL;
			char*	object_type1		= NULL;
			char*	DMLName				= NULL;
			char*	TaskName1			= NULL;
			char*	Part_no1				= NULL;
			char*	Part_Type1			= NULL;
			
			tag_t	objType_Tag				= NULLTAG;
			tag_t*	PartTags1				= NULLTAG;	
			tag_t	objTypeTag1				= NULLTAG;
			tag_t	relation_type1			= NULLTAG;
			tag_t*	TaskRevision1			= NULLTAG;
			tag_t	TaskRevTag1				= NULLTAG;
			tag_t	tsk_part_sol_rel_type1	= NULLTAG;
			tag_t	AssyTag1				= NULLTAG;
			
			
			int		count1				= 0;
			int		TaskCnt1			= 0;
			int		PartCnt1			= 0;
			int		k1					= 0;

			if(TCTYPE_ask_object_type(CKD_DMLTag,&objType_Tag));
			if(TCTYPE_ask_name2(objType_Tag,&type_name1));
			printf("\n QTY_Validation : type_name1 %s\n", type_name1);fflush(stdout);
			
			if(strcmp(type_name1,"T5_CkdDmlRevision")==0)
			{
				printf("\n QTY_Validation : Inside class T5_CkdDmlRevision ......\n");fflush(stdout);
			
				if (CKD_DMLTag != NULLTAG)
				{
					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type1);
			
					GRM_list_secondary_objects_only(CKD_DMLTag,relation_type1,&count1,&TaskRevision1);
					printf("\n QTY_Validation : CKD DML to Task : %d\n",count1);fflush(stdout);
			
					for (TaskCnt1=0;TaskCnt1<count1 ;TaskCnt1++ )
					{
						TaskRevTag1 = TaskRevision1[TaskCnt1];
			
						AOM_ask_value_string(TaskRevTag1,"object_type",&object_type1);
						printf("\n QTY_Validation : object_type1 is :%s \n",object_type1);fflush(stdout);
			
						AOM_ask_value_string(TaskRevTag1,"item_id",&TaskName1);
						printf("\n QTY_Validation : TaskName1 is :%s \n",TaskName1);fflush(stdout);
			
						if(strcmp(object_type1,"T5_CKDTaskRevision")==0)
						{
							PartCnt1=0;
			
							AOM_ask_value_tags(TaskRevTag1,"CMHasSolutionItem",&PartCnt1,&PartTags1);
							printf("\n QTY_Validation : CKD DML Task PartCnt1: %d \n",PartCnt1);fflush(stdout);
			
							if (PartCnt1>0)
							{
								GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type1);
								for (k1=0;k1<PartCnt1 ;k1++ )
								{
									AssyTag1=PartTags1[k1];
			
									AOM_ask_value_string(AssyTag1,"item_id",&Part_no1);
									AOM_ask_value_string(AssyTag1,"t5_PartType",&Part_Type1);
									
									printf("\n [%d].Part_no1 is => [%s] Part_Type1 => [%s] \n",k+1,Part_no1,Part_Type1);fflush(stdout);										

									tag_t	window			= NULLTAG;
									tag_t	rule			= NULLTAG;
									tag_t*	closure_tags	= NULLTAG;
									tag_t  	closure_tag		= NULLTAG;
									tag_t	item			= NULLTAG;
									tag_t	top_line		= NULLTAG;
									tag_t*	child			= NULLTAG;

									int n_closure_tags;

									int z,i,j,count,countz;

									printf("\n QTY_Validation : ClosureRule is => [%s] || RevisionRule is => [%s] \n", closureRuleName,RevisionRule);
									
									CALLAPICKD(BOM_create_window(&window));
									CALLAPICKD(CFM_find( RevisionRule, &rule ));
									CALLAPICKD(BOM_set_window_config_rule( window, rule ));
									CALLAPICKD(BOM_set_window_pack_all(window, true));	

									CALLAPICKD(PIE_find_closure_rules2(closureRuleName, PIE_TEAMCENTER, &n_closure_tags, &closure_tags)); 
											
									printf ("\n n_closure_tags => %d \n",n_closure_tags);fflush(stdout);
									if (n_closure_tags > 0)
									{
										closure_tag=closure_tags[0];
										printf ("\n closure rule found \n");fflush(stdout);				
									}
									
									ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
									
									// Find out bom line tag
									CALLAPICKD(BOM_set_window_top_line(window,item,AssyTag1,NULLTAG,&top_line));
									CALLAPICKD(BOM_window_hide_unconfigured( window ));
									CALLAPICKD(BOM_window_hide_suppressed( window ));
									// Find out the all childs
									CALLAPICKD(BOM_line_ask_all_child_lines(top_line,&count,&child));

									printf("\n QTY_Validation : Number Of Child [%d]  in CKD-VC/Dummy => [%s] \n",count,Part_no1);
									
									int num_values = 0;
									char*	rules_configured_by		= NULL;
									char**	rules_configured_by1	= NULL;
									char*	Child_PartNo			= NULL;
									char*	Child_PartType			= NULL;
									char*	Child_PartQty			= NULL;
									char*	Part_numbers_Qty		= NULL;
									char*	Part_numbers_Config		= NULL;

									int Part_flag_Qty			= 0;
									int Part_flag_Config		= 0;

									Part_numbers_Qty = (char *) MEM_alloc(3 * sizeof(char ));
									tc_strcpy(Part_numbers_Qty ,"");

									Part_numbers_Config = (char *) MEM_alloc(3 * sizeof(char ));
									tc_strcpy(Part_numbers_Config ,"");

									if ( count > 0 )
									{
										for(i=0;i<count;i++)
										{
											Child_PartNo = NULL;
											CALLAPICKD(AOM_ask_value_string(child[i], "bl_item_item_id", &Child_PartNo));
											printf("\n [%d] Child_PartNo => %s \n",i+1,Child_PartNo);fflush(stdout);
											
											Child_PartType = NULL;
											CALLAPICKD(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_PartType", &Child_PartType));
											printf("\n Child_PartType => %s \n",Child_PartType);fflush(stdout);

											if((tc_strcmp(Child_PartType,"D") == 0) || (tc_strcmp(Child_PartType,"Dummy") == 0))
											{
												printf("\n Skiiping Dummy Child Part type \n");fflush(stdout);
												continue;
											}

											CALLAPICKD(AOM_ask_displayable_values(child[i], "bl_config_string", &num_values, &rules_configured_by1));
											rules_configured_by = (char *)MEM_alloc(100 * sizeof(char));
											tc_strcpy(rules_configured_by, rules_configured_by1[0]);

											if (tc_strcmp(rules_configured_by, "No configured Revision") == 0)
											{
												printf("\n Adding Child Part [%s] into set as no configured revision: \n",Child_PartNo);fflush(stdout);	
												if(tc_strcmp(Part_numbers_Config,"")!=0)
												{
													CKD_stdstrcat(&Part_numbers_Config,Child_PartNo);
													CKD_stdstrcat(&Part_numbers_Config,",");
												}
												else
												{
													CKD_stdstrcat(&Part_numbers_Config,Child_PartNo);
													CKD_stdstrcat(&Part_numbers_Config,",");												
												}
												Part_flag_Config++;
											}										
											
											CALLAPICKD(AOM_ask_value_string(child[i],"bl_quantity",&Child_PartQty));
											printf("\n Child_PartQty => [%s] \n",Child_PartQty);fflush(stdout);	

											if(tc_strcmp(Child_PartQty, "0") == 0 || tc_strlen(Child_PartQty) == 0)
											{
												printf("\n Adding Child Part [%s[ into set as no 0 Qty \n",Child_PartNo);fflush(stdout);
												if(tc_strcmp(Part_numbers_Qty,"")!=0)
												{
													CKD_stdstrcat(&Part_numbers_Qty,Child_PartNo);
													CKD_stdstrcat(&Part_numbers_Qty,",");
												}
												else
												{
													CKD_stdstrcat(&Part_numbers_Qty,Child_PartNo);
													CKD_stdstrcat(&Part_numbers_Qty,",");												
												}
												Part_flag_Qty++;
											}	
										}
									}

									if(window!=NULLTAG)
											BOM_close_window(window);
									
									if ( Part_flag_Qty > 0 )
									{
										printf("\n Pls Remove Zero Qty Part before signoff. [%s]",Part_numbers_Qty);fflush(stdout);
										
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_errStore1,"\n Please Remove Zero Qty Child Part Before signoff.\n",Part_numbers_Qty);
										MEM_free(Part_numbers_Qty);
										return ITK_errStore1;
									}

									if ( Part_flag_Config > 0 )
									{
										printf("\n No configured Child Parts Found [%s]",Part_numbers_Config);fflush(stdout);
										
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_errStore1,"\n Child Part/Parts not Released from Plant.\n",Part_numbers_Config);
										MEM_free(Part_numbers_Config);
										return ITK_errStore1;
									}									

									
									//
								}
							}
						}
					}
				}
			}

			//////////////////
			
			
			
			

		}
	}
	//  Validation 3 Ended //

	/////////////////////////////////////////////////////========= CKD DML Stamping =========/////////////////////////////////////////////////////////////////

	// Control Object for Calling EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","Release","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPICKD(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			sprintf(cmd,"%s %s %s",t5_Userinfo1,CKD_DMLNo,PlantNameP);
			printf("Excuting Command = %s",cmd);fflush(stdout);
			system(cmd);
			printf("After executing Command");fflush(stdout);
	   }
	}
	//
	
	return ifail;

}

int tm_CKD_CKIMP_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	tag_t	CKD_DMLTag				= NULLTAG;
	tag_t	objTypeTag				= NULLTAG;
	tag_t   CurrentRoleTag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t*	PartTags				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	
	char*   CKD_DMLNo			= NULL;
	char*   CKDDMLno			= NULL;
	char*	PlantNameP			= NULL;
	char*	type_name			= NULL;
	char*	roleName			= NULL;
	char*	object_type			= NULL;
	char*	TaskName			= NULL;
	char*	Part_no				= NULL;
	char*	lcsToset			= NULL;
	char*	Part_Type			= NULL;
	char*	Part_CS				= NULL;	
	char*	DMLName				= NULL;
	char*	loginuser			= NULL;
	
	tag_t	DML_No					= NULLTAG;
	tag_t	DML_RevTag				= NULLTAG;
	
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;

	char *output							= NULL;
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Ketan Inside tm_CKD_CKIMP_Call .....\n");
	
	USERARG_get_tag_argument(&CKD_DMLTag);				// CKD DML Tag              
	  
	CALLAPICKD(AOM_ask_value_string(CKD_DMLTag,"item_id",&CKD_DMLNo));
	printf("\n CKD_DMLNo => %s\n",CKD_DMLNo);fflush(stdout);

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);

	CALLAPICKD(POM_get_user_id(&loginuser));
	printf("\n loginuser => %s\n",loginuser); fflush(stdout);

	// Control Object for Calling EXE // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","CKIMP","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution \n");fflush(stdout);

	    char* t5_Userinfo1 = NULL;
		char cmd[100];

		tag_t CKD_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPICKD(AOM_ask_value_string(CKD_obj,"t5_Userinfo1",&t5_Userinfo1));	
		sprintf(cmd,"%s %s %s",t5_Userinfo1,CKD_DMLNo,loginuser);
		printf("\n Ketan Excuting Command for CKIMP => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\n After executing Command for CKIMP \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for CKIMP \n");fflush(stdout);
	}	
	return ifail;
}

int tm_CKD_Dummy_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	tag_t	CKD_DMLTag				= NULLTAG;
	tag_t	objTypeTag				= NULLTAG;
	tag_t   CurrentRoleTag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t*	PartTags				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	
	char*   CKD_DMLNo			= NULL;
	char*   CKDDMLno			= NULL;
	char*	PlantNameP			= NULL;
	char*	type_name			= NULL;
	char*	roleName			= NULL;
	char*	object_type			= NULL;
	char*	TaskName			= NULL;
	char*	Part_no				= NULL;
	char*	lcsToset			= NULL;
	char*	Part_Type			= NULL;
	char*	Part_CS				= NULL;	
	char*	DMLName				= NULL;
	char*	loginuser			= NULL;
	
	tag_t	DML_No					= NULLTAG;
	tag_t	DML_RevTag				= NULLTAG;
	
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;

	char *output							= NULL;
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Ketan Inside tm_CKD_Dummy_Call .....\n");
	
	USERARG_get_tag_argument(&CKD_DMLTag);				// CKD DML Tag              
	  
	CALLAPICKD(AOM_ask_value_string(CKD_DMLTag,"item_id",&CKD_DMLNo));
	printf("\n CKD_DMLNo => %s\n",CKD_DMLNo);fflush(stdout);

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);

	CALLAPICKD(POM_get_user_id(&loginuser));
	printf("\n loginuser => %s\n",loginuser); fflush(stdout);

	// Control Object for Calling EXE // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","Dummy","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution \n");fflush(stdout);

	    char* t5_Userinfo1 = NULL;
		char cmd[100];

		tag_t CKD_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPICKD(AOM_ask_value_string(CKD_obj,"t5_Userinfo1",&t5_Userinfo1));	
		sprintf(cmd,"%s %s %s",t5_Userinfo1,CKD_DMLNo,loginuser);
		printf("\n Ketan Excuting Command for Dummy Structure Report => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\n After executing Command for Dummy Structure Report \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for Dummy Structure Report \n");fflush(stdout);
	}	
	return ifail;
}

int tm_CKD_VC_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	tag_t	CKD_DMLTag				= NULLTAG;
	tag_t	objTypeTag				= NULLTAG;
	tag_t   CurrentRoleTag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t*	PartTags				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	
	char*   CKD_DMLNo			= NULL;
	char*   CKDDMLno			= NULL;
	char*	PlantNameP			= NULL;
	char*	type_name			= NULL;
	char*	roleName			= NULL;
	char*	object_type			= NULL;
	char*	TaskName			= NULL;
	char*	Part_no				= NULL;
	char*	lcsToset			= NULL;
	char*	Part_Type			= NULL;
	char*	Part_CS				= NULL;	
	char*	DMLName				= NULL;
	char*	loginuser			= NULL;
	
	tag_t	DML_No					= NULLTAG;
	tag_t	DML_RevTag				= NULLTAG;
	
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;

	char *output							= NULL;
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Ketan Inside tm_CKD_VC_Call .....\n");
	
	USERARG_get_tag_argument(&CKD_DMLTag);				// CKD DML Tag              
	  
	CALLAPICKD(AOM_ask_value_string(CKD_DMLTag,"item_id",&CKD_DMLNo));
	printf("\n CKD_DMLNo => %s\n",CKD_DMLNo);fflush(stdout);

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);

	CALLAPICKD(POM_get_user_id(&loginuser));
	printf("\n loginuser => %s\n",loginuser); fflush(stdout);

	// Control Object for Calling EXE // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","VC","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution \n");fflush(stdout);

	    char* t5_Userinfo1 = NULL;
		char cmd[100];

		tag_t CKD_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPICKD(AOM_ask_value_string(CKD_obj,"t5_Userinfo1",&t5_Userinfo1));	
		sprintf(cmd,"%s %s %s",t5_Userinfo1,CKD_DMLNo,loginuser);
		printf("\n Ketan Excuting Command for CKD-DML VC REPORT => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\n After executing Command for CKD-DML VC REPORT \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for CKD-DML VC REPORT \n");fflush(stdout);
	}	
	return ifail;
}

int tm_CKD_BOM_CSV_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	char*   Inputstring         	 = NULL;
	char*   Username         	     = NULL;
	char*   RoleName         	     = NULL;
	char*   loginuser         	     = NULL;

	printf("\n Ketan Inside tm_CKD_BOM_CSV_Call .....\n");

	USERARG_get_string_argument(&Inputstring);
	USERARG_get_string_argument(&Username);
	USERARG_get_string_argument(&RoleName);	
	  
	printf("\n Inputstring => %s\n",Inputstring);fflush(stdout);
	printf("\n Username => %s\n",Username);fflush(stdout);
	printf("\n RoleName => %s\n",RoleName);fflush(stdout);

	CALLAPICKD(POM_get_user_id(&loginuser));
	printf("\n loginuser => %s\n",loginuser); fflush(stdout);

	/******creating the File for writting ********/
	char ReleasedDateTime_str[26] = {'\0'};

	char*	Filename		= NULL;
	char*	FileLoc			= NULL;

	FILE*	DmlRelFile		= NULL;

	time_t now;
	struct tm* now_tm;

	time(&now);
	now_tm = localtime(&now);
	strftime (ReleasedDateTime_str, 26, "%a_%b__%d_%H_%M_%S_%Y", now_tm);
	printf("\n ReleasedDateTime_str is===>[%s]",ReleasedDateTime_str);fflush(stdout);

	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );

	tc_strcpy(Filename,"CKD");
	tc_strcat(Filename,"_BOM_");
	tc_strcat(Filename,ReleasedDateTime_str);
	tc_strcat(Filename,".txt");
	printf("\n Filename: %s \n", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/tmp/");
	tc_strcat(FileLoc,Filename);
	printf("\n FileLoc: %s \n", FileLoc);fflush(stdout);

	DmlRelFile = fopen(FileLoc, "w");
	fprintf(DmlRelFile,"%s",Inputstring);fflush(DmlRelFile);

	fclose(DmlRelFile);

	// Control Object for Calling EXE // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","CC_BOM","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution New1.1 \n");fflush(stdout);

	    char* t5_Userinfo1 = NULL;
		char cmd[1000];

		tag_t CKD_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPICKD(AOM_ask_value_string(CKD_obj,"t5_Userinfo1",&t5_Userinfo1));
		printf("\n t5_Userinfo1 => %s \n",t5_Userinfo1);fflush(stdout);
		printf("\n FileLoc => %s \n",FileLoc);fflush(stdout);
		printf("\n Username => %s \n",Username);fflush(stdout);
		printf("\n RoleName => %s \n",RoleName);fflush(stdout);
		
		sprintf(cmd,"%s %s %s %s",t5_Userinfo1,FileLoc,Username,RoleName);
		printf("\n Ketan Excuting Command for CKD BOM Creation => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\n Ketan After executing Command for CKD BOM Creation \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for CKD BOM Creation \n");fflush(stdout);
	}	
	return ifail;
}

int tm_CKD_ESDS_Release_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	tag_t	ES_RevTag				= NULLTAG;
	
	char*   EsNo			= NULL;
	char*	ReleaseStatus	= NULL;
		
	tag_t   status2			= NULLTAG;

	logical retain=false;
	
	printf("\n Ketan Inside tm_CKD_ESDS_Release_Call .....\n");
	
	USERARG_get_tag_argument(&ES_RevTag);				       
	  
	CALLAPICKD(AOM_ask_value_string(ES_RevTag,"item_id",&EsNo));
	printf("\n EsNo => %s\n",EsNo);fflush(stdout);

	// remove status ///
	tag_t		tReleaseStatusList_checkin=NULLTAG; 
	tag_t		class_id				=     NULLTAG;

	char		*class_name				=    NULL;

	int			n_values_checkin			=0; 
	int			cunt1			=0; 
	int			cunt2			=0; 

	logical		log1;
	tag_t*		attr_tags_checkin		=	NULLTAG; 
	logical		*is_it_null_checkin		=   NULL; 
	logical		*is_it_empty_checkin	=   NULL; 

	int       st_count=0;
	tag_t*    status_list;

	CALLAPICKD(POM_class_of_instance(ES_RevTag,&class_id));
	CALLAPICKD(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPICKD(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	printf("\n after getting rel stat...");fflush(stdout);

	CALLAPICKD(POM_unload_instances (1,&ES_RevTag));
	printf("\n test2 \n");fflush(stdout);
	CALLAPICKD(POM_load_instances(1,&ES_RevTag,class_id,1));
	printf("\n test3 \n");fflush(stdout);
	CALLAPICKD(POM_is_loaded(ES_RevTag,&log1));
	printf("\n test4 \n");fflush(stdout);

	if(log1 == 1)
	{
		 printf("\n Load Success \n" );
	}
	else
	printf("\n Load Failure\n"  );	

	CALLAPICKD( POM_length_of_attr(ES_RevTag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

	if(n_values_checkin>0)
	{
		printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
		CALLAPICKD( POM_ask_attr_tags(ES_RevTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
			CALLAPICKD(POM_remove_from_attr(1,&ES_RevTag,tReleaseStatusList_checkin,cunt1,1));

			printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
			
			CALLAPICKD(POM_save_instances(1,&ES_RevTag,1));
			CALLAPICKD(AOM_lock(ES_RevTag));
			CALLAPICKD(AOM_save_without_extensions(ES_RevTag));
			CALLAPICKD(AOM_refresh(ES_RevTag,1));
			CALLAPICKD(AOM_unlock(ES_RevTag));
		}
	}

	//// End of remove status //////

	CALLAPICKD(RELSTAT_create_release_status("T5_LcsMktRel",&status2));
	CALLAPICKD(AOM_ask_name(status2, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus => %s\n",ReleaseStatus);fflush(stdout);
	CALLAPICKD(RELSTAT_add_release_status(status2,1,&ES_RevTag,retain));

	return ifail;
}

int tm_create_relstate_CKD_VC(char* PlantName, tag_t CKDVCRev_Tag)
{
	int ifail=ITK_ok;	

	char*	CKDVC_no				= NULL;
	char*	PlantLcs				= NULL;
	char*	CKDVCReleaseStatus		= NULL;
		
	tag_t   CKDVCstatus			= NULLTAG;
	
	logical CKDVC_retain			= false;
	
	PlantLcs	= (char *)MEM_alloc(100);
		
	tc_strcpy(PlantLcs,"");
	
	printf("\n Ketan Inside tm_create_relstate_CKD_VC......\n");fflush(stdout);

	CALLAPICKD(AOM_ask_value_string(CKDVCRev_Tag,"current_id", &CKDVC_no));
	
	printf("\n CKDVC_no => [%s] || PlantName => [%s]\n",CKDVC_no,PlantName);fflush(stdout);

	if (tc_strcmp(PlantName,"STDJ") == 0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDjWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDL") == 0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDlWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDD") == 0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDdWrkg");
	}
	else if (tc_strcmp(PlantName,"STDP") == 0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
	    tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}
	else if (tc_strcmp(PlantName,"STDU") == 0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
	    tc_strcpy(PlantLcs, "T5_LcsSTDuWrkg");	
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);
		tc_strcpy(PlantLcs,"T5_LcsSTDpWrkg");		
	}

	printf("\n Final PlantLcs is for CKD-VC => [%s] \n", PlantLcs);fflush(stdout);

	CALLAPICKD(RELSTAT_create_release_status(PlantLcs,&CKDVCstatus));
	CALLAPICKD(AOM_ask_name(CKDVCstatus, &CKDVCReleaseStatus));
	printf("\n CKDVCReleaseStatus => %s\n",CKDVCReleaseStatus);fflush(stdout);
	CALLAPICKD(RELSTAT_add_release_status(CKDVCstatus,1,&CKDVCRev_Tag,CKDVC_retain));

	printf("\n Release status created in CKD-VC \n");fflush(stdout);

	return 0;
}

int tm_CKD_VC_ReleaseStatus_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	char*   CKDVC_No         	 = NULL;
	char*   CKDVC_Num         	 = NULL;
	char*   roleName         	 = NULL;
	char*	PlantName			 = NULL;

	tag_t   CurrentRoleTag		= NULLTAG;
	tag_t	CKDVC_tag			= NULLTAG;
	tag_t	CKDVC_rev_tag		= NULLTAG;
	
	printf("\n Ketan Inside tm_CKD_VC_ReleaseStatus_Call .....\n");

	USERARG_get_string_argument(&CKDVC_No);	
	  
	printf("\n CKDVC_No => %s\n",CKDVC_No);fflush(stdout);	

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);

	PlantName=subString_CKD(roleName,3,4);
	printf("\n PlantName => %s\n", PlantName);

	CALLAPICKD(ITEM_find_item (CKDVC_No, &CKDVC_tag));

	if(CKDVC_tag != NULLTAG )
	{
		CALLAPICKD(ITEM_ask_latest_rev(CKDVC_tag,&CKDVC_rev_tag));
		AOM_ask_value_string( CKDVC_rev_tag, "current_id", &CKDVC_Num);

		// Adding Release status in CKD VC
		tm_create_relstate_CKD_VC(PlantName,CKDVC_rev_tag);
	}	
	
	return ifail;
}

static char* default_empty_to_A_CKD(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

int tm_CKD_VC_Dummy_Revise_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	char*   CKD_VC_Dummy_No			= NULL;
	char*   roleName				= NULL;
	char*	PlantName				= NULL;
	char*	CKD_Dummy_revision_id	= NULL;

	tag_t   CurrentRoleTag		= NULLTAG;
	tag_t	CKD_VC_Dummy_RevTag	= NULLTAG;
	
	printf("\n Ketan Inside tm_CKD_VC_Dummy_Revise_Call .....\n");
	
	USERARG_get_tag_argument(&CKD_VC_Dummy_RevTag);
	//USERARG_get_string_argument(&CKD_DML_No);	

	CALLAPICKD(AOM_ask_value_string(CKD_VC_Dummy_RevTag,"item_id",&CKD_VC_Dummy_No));
	printf("\n CKD_VC_Dummy_No => %s\n",CKD_VC_Dummy_No);fflush(stdout);

	CALLAPICKD(SA_ask_current_role(&CurrentRoleTag));
	CALLAPICKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n roleName => %s\n",roleName); fflush(stdout);

	PlantName=subString_CKD(roleName,3,4);
	printf("\n PlantName => %s\n", PlantName);

	tag_t aplrev=NULLTAG;
	CALLAPICKD(ITEM_copy_rev(CKD_VC_Dummy_RevTag,NULL,&aplrev));
	
	// Adding Release status in Revised Revision
	tm_create_relstate_CKD_VC(PlantName,aplrev);
	
	return ifail;
}

int tm_CKD_VC_Dummy_Delete_bom_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	char*   CKD_VC_Dummy_No			= NULL;
	char*   ClosureRule				= NULL;
	char*	RevisionRule			= NULL;
	char*	CurrentViewMask			= NULL;

	tag_t   CurrentRoleTag		= NULLTAG;
	tag_t	CKD_VC_Dummy_RevTag	= NULLTAG;
	
	printf("\n Ketan Inside tm_CKD_VC_Dummy_Delete_bom_Call .....\n"); // 11022026
	
	USERARG_get_tag_argument(&CKD_VC_Dummy_RevTag);
	USERARG_get_string_argument(&ClosureRule);	
	USERARG_get_string_argument(&RevisionRule);	
	USERARG_get_string_argument(&CurrentViewMask);	

	CALLAPICKD(AOM_ask_value_string(CKD_VC_Dummy_RevTag,"item_id",&CKD_VC_Dummy_No));
	printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : CKD_VC_Dummy_No => %s\n",CKD_VC_Dummy_No);fflush(stdout);

	printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : ClosureRule => [%s] \n",ClosureRule);
	printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : RevisionRule => [%s] \n",RevisionRule);
	printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : CurrentViewMask => [%s] \n",CurrentViewMask);

	tag_t	window			= NULLTAG;
	tag_t	rule			= NULLTAG;
	tag_t*	closure_tags	= NULLTAG;
	tag_t  	closure_tag		= NULLTAG;
	tag_t	item			= NULLTAG;
	tag_t	top_line		= NULLTAG;
	tag_t*	child			= NULLTAG;

	int n_closure_tags;

	int z,i,j,count,countz;

	CALLAPICKD(BOM_create_window(&window));
	CALLAPICKD(CFM_find( RevisionRule, &rule ));
	CALLAPICKD(BOM_set_window_config_rule( window, rule ));
	CALLAPICKD(BOM_set_window_pack_all(window, true));	

	//CALLAPICKD(PIE_find_closure_rules2(ClosureRule, PIE_TEAMCENTER, &n_closure_tags, &closure_tags)); 
	//		
	//printf ("\n n_closure_tags => %d \n",n_closure_tags);fflush(stdout);
	//if (n_closure_tags > 0)
	//{
	//	closure_tag=closure_tags[0];
	//	printf ("\n closure rule found \n");fflush(stdout);				
	//}
	//
	//ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	
	// Find out bom line tag
	CALLAPICKD(BOM_set_window_top_line(window,item,CKD_VC_Dummy_RevTag,NULLTAG,&top_line));
	CALLAPICKD(BOM_window_hide_unconfigured( window ));
	CALLAPICKD(BOM_window_hide_suppressed( window ));
	// Find out the all childs
	CALLAPICKD(BOM_line_ask_all_child_lines(top_line,&count,&child));

	printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : Number Of Child [%d]  in CKD-VC/Dummy => [%s] \n",count,CKD_VC_Dummy_No);fflush(stdout);

	int num_values = 0;
	char*	rules_configured_by		= NULL;
	char**	rules_configured_by1	= NULL;
	char*	Child_PartNo			= NULL;
	char*	Child_PartType			= NULL;
	char*	Child_cvm				= NULL;
	char*	Part_numbers_Qty		= NULL;
	char*	Part_numbers_Config		= NULL;

	int Part_flag_Qty			= 0;
	int Part_flag_Config		= 0;

	if ( count > 0 )
	{
		for(i=0;i<count;i++)
		{
			Child_PartNo = NULL;
			CALLAPICKD(AOM_ask_value_string(child[i], "bl_item_item_id", &Child_PartNo));
			printf("\n [%d] Child_PartNo => %s \n",i+1,Child_PartNo);fflush(stdout);
			
			Child_PartType = NULL;
			CALLAPICKD(AOM_UIF_ask_value(child[i], "bl_Design Revision_t5_PartType", &Child_PartType));
			printf("\n Child_PartType => %s \n",Child_PartType);fflush(stdout);

			if((tc_strcmp(Child_PartType,"D") == 0) || (tc_strcmp(Child_PartType,"Dummy") == 0))
			{
				printf("\n Skiiping Dummy Child Part type \n");fflush(stdout);
				continue;
			}

			CALLAPICKD(AOM_ask_displayable_values(child[i], "bl_config_string", &num_values, &rules_configured_by1));
			rules_configured_by = (char *)MEM_alloc(100 * sizeof(char));
			tc_strcpy(rules_configured_by, rules_configured_by1[0]);

			if (tc_strcmp(rules_configured_by, "No configured Revision") == 0)
			{
				printf("\n Adding Child Part [%s] into set as no configured revision: \n",Child_PartNo);fflush(stdout);	
				continue;
			}										
			
			CALLAPICKD(AOM_ask_value_string(child[i],CurrentViewMask,&Child_cvm));
			printf("\n Child_cvm => [%s] \n",Child_cvm);fflush(stdout);	

			if(tc_strcmp(Child_cvm, "0--") == 0 )
			{
				printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : Child part [%s] will be deleted as [%s] is 0-- \n",Child_PartNo,Child_cvm);fflush(stdout);
				//CALLAPICKD(BOMLine_cut(child[i]));
				CALLAPICKD(BOM_line_cut(child[i]));
				
				CALLAPICKD(BOM_save_window(window) );
				printf("\n tm_CKD_VC_Dummy_Delete_bom_Call : Ketan BOM_save successfully\n");
			}	
		}
	}

	if(window!=NULLTAG)
			BOM_close_window(window);

	return ifail;
}
//

extern int CKDServiceinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	printf("\n ############ After Rigister CKDinitmodule");fflush(stdout);	
	
	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE; 
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....CKDBarrelAssignFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method((char *)"CKDBarrelAssignFunc",(USER_function_t)CKDBarrelAssignFunc,nargs,inputArgTypes,retValueType);	

	// Ketan Added for CKD DML Release

	int nargs1 = 1;
	int retValueType1;
	int inputArgTypes1[1] = {0};
	
	inputArgTypes1[0] = USERARG_TAG_TYPE;
	
	retValueType1 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_Release_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_Release_Call",(USER_function_t)tm_CKD_Release_Call,nargs1,inputArgTypes1,retValueType1);

	// Ended

	// Ketan Added for CKIMP

	int nargs2 = 1;
	int retValueType2;
	int inputArgTypes2[1] = {0};
	
	inputArgTypes2[0] = USERARG_TAG_TYPE;
	
	retValueType2 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_CKIMP_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_CKIMP_Call",(USER_function_t)tm_CKD_CKIMP_Call,nargs2,inputArgTypes2,retValueType2);

	// Ended

	// Ketan Added for Dummy Structure Report

	int nargs3 = 1;
	int retValueType3;
	int inputArgTypes3[1] = {0};
	
	inputArgTypes3[0] = USERARG_TAG_TYPE;
	
	retValueType3 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_Dummy_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_Dummy_Call",(USER_function_t)tm_CKD_Dummy_Call,nargs3,inputArgTypes3,retValueType3);

	// Ended

	// Ketan Added for CKD-DML VC REPORT

	int nargs4 = 1;
	int retValueType4;
	int inputArgTypes4[1] = {0};
	
	inputArgTypes4[0] = USERARG_TAG_TYPE;
	
	retValueType4 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_VC_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_VC_Call",(USER_function_t)tm_CKD_VC_Call,nargs4,inputArgTypes4,retValueType4);

	// Ended

	// Ketan Added for CKD BOM Creation through CSV

	int nargs5 = 3;
	int retValueType5;
	int inputArgTypes5[3] = {0};
	
	inputArgTypes5[0] = USERARG_STRING_TYPE;
	inputArgTypes5[1] = USERARG_STRING_TYPE;
	inputArgTypes5[2] = USERARG_STRING_TYPE;
	
	retValueType5 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_BOM_CSV_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_BOM_CSV_Call",(USER_function_t)tm_CKD_BOM_CSV_Call,nargs5,inputArgTypes5,retValueType5);

	// Ended

	// Ketan Added for ES DS Release Status Creation

	int nargs6 = 1;
	int retValueType6;
	int inputArgTypes6[1] = {0};
	
	inputArgTypes6[0] = USERARG_TAG_TYPE;
		
	retValueType6 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_ESDS_Release_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_ESDS_Release_Call",(USER_function_t)tm_CKD_ESDS_Release_Call,nargs6,inputArgTypes6,retValueType6);

	// Ended

	// Ketan Added for CKDVC Plantwise Release Status Creation

	int nargs7 = 1;
	int retValueType7;
	int inputArgTypes7[1] = {0};
	
	inputArgTypes7[0] = USERARG_STRING_TYPE;
		
	retValueType7 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_VC_ReleaseStatus_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_VC_ReleaseStatus_Call",(USER_function_t)tm_CKD_VC_ReleaseStatus_Call,nargs7,inputArgTypes7,retValueType7);

	// Ended

	// Ketan Added for CKD Dummy Revise

	int nargs8 = 1;
	int retValueType8;
	int inputArgTypes8[1] = {0};
	
	inputArgTypes8[0] = USERARG_TAG_TYPE;
		
	retValueType8 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_VC_Dummy_Revise_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_VC_Dummy_Revise_Call",(USER_function_t)tm_CKD_VC_Dummy_Revise_Call,nargs8,inputArgTypes8,retValueType8);

	// Ketan Added for CKD BOM Delete

	int nargs9 = 4;
	int retValueType9;
	int inputArgTypes9[4] = {0};
	
	inputArgTypes9[0] = USERARG_TAG_TYPE;
	inputArgTypes9[1] = USERARG_STRING_TYPE;
	inputArgTypes9[2] = USERARG_STRING_TYPE;
	inputArgTypes9[3] = USERARG_STRING_TYPE;
		
	retValueType9 = USERARG_STRING_TYPE ; 
	
	printf("\n CKDServiceinitmodule before....tm_CKD_VC_Dummy_Delete_bom_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_CKD_VC_Dummy_Delete_bom_Call",(USER_function_t)tm_CKD_VC_Dummy_Delete_bom_Call,nargs9,inputArgTypes9,retValueType9);


	// Ended

	return ifail;	
}

extern DLLAPI int tm_CKD_register_callbacks()
{	
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_CKD");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_CKD", "USER_init_module", (CUSTOM_EXIT_ftn_t)CKDinitmodule);
	ifail=CUSTOM_register_exit ( "tm_CKD", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)CKDServiceinitmodule);
	printf("\n After registoring userservice....tm_CKD");fflush(stdout);
	return ( ITK_ok );
}