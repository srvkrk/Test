/****************************************************************************************************
*  File            :   t5ListEmptyVisPdfDesRev.c
*  Created By      :   Anu Nair
*  Created On      :   01 Mar 2020
*  Purpose         :   BUG in JT/PDF Translation, Dataset DirectModel and PDF have no named references. CC List the DesignRevision
*
*  Usage		   :./Test4dObj -u=ercpsup -p=XYT1ESA -g="" -formObjName="Test_211021"
*****************************************************************************************************/
//#include <ps/ps.h>
//#include <ps/ps_errors.h>
//#include <ai/sample_err.h>
//#include <ae/dataset_msg.h>
//#include <tc/tc.h>
//#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
//#include <ae/dataset.h>
//#include <ps/ps_errors.h>
//#include <sa/sa.h>
//#include <stdarg.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <sys/dir.h>
//#include <sys/stat.h>
//#include <fclasses/tc_string.h>
//#include <tccore/item.h>
//#include <user_exits/user_exits.h>
//#include <tccore/item_errors.h>
//#include <sa/tcfile.h>
//#include <tcinit/tcinit.h>
//#include <tccore/tctype.h>
//#include <res/reservation.h>
//#include <tccore/aom.h>
//#include <tccore/custom.h>
//#include <tc/emh.h>
//#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <tccore/project.h>
//#include <sa/imanfile.h>
//#include <lov/lov.h>
//#include <lov/lov_msg.h>
//#include <itk/mem.h>
//#include <ss/ss_errors.h>
//#include <tccore/item_msg.h>
//#include <tccore/iman_msg.h>
//#include <sa/user.h>
//#include <pie/pie.h>
//#define CONNECT_FAIL (EMH_USER_error_base + 2)
//#define ITK_err 919002
//#define ITK_errStore (EMH_USER_error_base + 4)
//#define PLM_error6 (EMH_USER_error_base+27)



/*--------------------------------------------------*/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcfile_cache.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <tc/preferences.h>
#include "participant.h"
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <time.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error6 (EMH_USER_error_base+27)
/*--------------------------------------------------*/

#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}


#define WRONG_USAGE 100001
char* subString (char* mainStringf ,int fromCharf,int toCharf);
//
void dousage()
{
   printf("\nUSAGE: t5ListEmptyVisPdfDesRev -fromDate= -toDate= -sType= -outFile= \n");
   printf("\E.g: t5ListEmptyVisPdfDesRev -fromDate=01-May-2018 -toDate=02-May-2018 -sType=CMI2Part -outFile=out.txt \n");
   return;
}

void lower_string(char s[])
{
	int c = 0;

	while (s[c] != '\0')
	{
		if (s[c] >= 'A' && s[c] <= 'Z')
		{
			s[c] = s[c] + 32;
		}
		c++;
	}
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

//create_dataset_excel(itemRevTAG, documentNameS, dfq_use_case_desc, dfq_use_case_uid, destinationExcelPathS);
//							//Construct Class Type
//							ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentNameS));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",dfq_use_case_desc));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQUID",dfq_use_case_uid));

void create_dataset_excel ( tag_t tItemRevTag, char* tct_item_id, char* dfq_use_case_desc,  char* dfq_use_case_uid, char* destinationExcelPathS, char*DVA_project_Code )
{
	tag_t aNewDataset = NULLTAG;
	tag_t object_create_input_tag3 = NULLTAG;
	tag_t datasettype = NULLTAG;
	char *reference_nameDS = NULL;
	char *ExcelFleNameCpy = NULL;
	tag_t file_tag = NULLTAG;
	IMF_file_t file_descriptor;
	AE_reference_type_t tagRefTypeText = 1;
	//tag_t file_tag = NULLTAG;
	tag_t relation = NULLTAG;
	tag_t datasettag = NULLTAG;
	tag_t Relatn_type1;
	char *DsetID = NULL;
	tag_t tool = NULLTAG;
	tag_t dfqtag = NULLTAG;
	int ref_count = 0;
	char **ref_list;

	logical checkout1;
	const char *reason	= "";
	const char *change_id	= "";
	const char *dir_name = "";

	reference_nameDS = (char *) MEM_alloc(10);

	
	ITK_CALL(AE_find_datasettype2("T5_DFQ_Document", &datasettype));      //Code Change

	//AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
	//printf("\nref_list[0]:%s",ref_list[0]);

	tc_strcpy(reference_nameDS,"T5_DFQ_EXCEL");//excel

	//tc_strcpy(reference_nameDS,ref_list[0]);

	DsetID = NULL;
	DsetID=(char *) MEM_alloc(32);
	tc_strcpy(DsetID,tct_item_id);
	//tc_strcat(DsetID,tct_item_id);
	//ExcelFleNameCpy = malloc(1500);
	//tc_strcpy(ExcelFleNameCpy,"D:\\bom_X4.xlsx");

	/*ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"Dataset Creation Tool",DsetID,"",&aNewDataset));
	ITK_CALL(AOM_lock(aNewDataset));
	//ITK_CALL(AOM_set_value_string(aNewDataset,"object_name",documentNameS));
	ITK_CALL(AOM_set_value_string(aNewDataset,"object_desc",dfq_use_case_desc));
	ITK_CALL(AOM_set_value_string(aNewDataset,"t5_DFQUID",dfq_use_case_uid));
	ITK_CALL(AOM_set_value_logical(aNewDataset,"t5_DFQApplicablility",0));
	ITK_CALL(AOM_set_value_string(aNewDataset,"t5_DFQ_Project_Code",DVA_project_Code));
	ITK_CALL(AE_set_dataset_tool( aNewDataset, tool));
	ITK_CALL(AE_set_dataset_format2(aNewDataset, "BINARY_REF"));
	ITK_CALL(AOM_save_with_extensions(aNewDataset));
	//ITK_CALL(AOM_unlock(aNewDataset));
	ITK_CALL(AOM_refresh(aNewDataset,0));*/

	ITK_CALL( TCTYPE_find_type( "T5_DFQ_Document", NULL, &dfqtag) );
	ITK_CALL(TCTYPE_construct_create_input(dfqtag, &object_create_input_tag3));
	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",DsetID));
	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",dfq_use_case_desc));
	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQUID",dfq_use_case_uid));
	ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"t5_DFQApplicablility",0));
	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQ_Project_Code",DVA_project_Code));

	ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&datasettag));
	ITK_CALL(AOM_lock(datasettag));
	ITK_CALL(AE_set_dataset_tool( datasettag, tool));
	ITK_CALL(AE_set_dataset_format2(datasettag, "BINARY_REF"));   //Code Change
	ITK_CALL(AOM_save_with_extensions(datasettag));
	ITK_CALL(AOM_refresh(datasettag,0));


	if(RES_is_checked_out(datasettag,&checkout1) !=ITK_ok);PrintErrorStack();
	if (!checkout1)
	{
		if (RES_checkout2(datasettag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok);PrintErrorStack();
		printf("\n DataSet Checked Out 2222\n");
	}

	ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&Relatn_type1));
	ITK_CALL(GRM_create_relation(tItemRevTag,datasettag,Relatn_type1,NULLTAG,&relation));
	printf("\n\t after creating relation between dataset and alias asm\n"); fflush(stdout);
	ITK_CALL(GRM_save_relation(relation));
	ITK_CALL(AOM_refresh(tItemRevTag,0));

	ITK_CALL(AOM_refresh(datasettag, TRUE));
	ITK_CALL(IMF_import_file(destinationExcelPathS,NULL, SS_BINARY, &file_tag, &file_descriptor));
	ITK_CALL(AOM_save_with_extensions(file_tag));

	ITK_CALL(AE_add_dataset_named_ref2(datasettag,reference_nameDS,tagRefTypeText,file_tag));
	printf("\n\t after named reference ALIAS \n"); fflush(stdout);

	ITK_CALL(AOM_save_with_extensions(datasettag));
	ITK_CALL(AOM_unload(file_tag));
	ITK_CALL(AOM_unload(datasettag));



	/*if(RES_is_checked_out(aNewDataset,&checkout1) !=ITK_ok);PrintErrorStack();
	if (!checkout1)
	{
		if (RES_checkout2(aNewDataset,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok);PrintErrorStack();
		printf("\n DataSet Checked Out \n");
	}

	ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&Relatn_type1));
	ITK_CALL(GRM_create_relation(tItemRevTag,aNewDataset,Relatn_type1,NULLTAG,&relation));
	printf("\n\t after creating relation between dataset and alias asm\n"); fflush(stdout);
	ITK_CALL(GRM_save_relation(relation));
	ITK_CALL(AOM_refresh(tItemRevTag,0));

	ITK_CALL(AOM_refresh(aNewDataset, TRUE));
	ITK_CALL(IMF_import_file(destinationExcelPathS,NULL, SS_BINARY, &file_tag, &file_descriptor));
	ITK_CALL(AOM_save_with_extensions(file_tag));

	ITK_CALL(AE_add_dataset_named_ref2(aNewDataset,reference_nameDS,tagRefTypeText,file_tag));
	printf("\n\t after named reference ALIAS \n"); fflush(stdout);

	ITK_CALL(AOM_save_with_extensions(aNewDataset));
	ITK_CALL(AOM_unload(file_tag));
	ITK_CALL(AOM_unload(aNewDataset));*/

}

char* objectfind(char* newString2, char** newString5,char** Projectreturn)
{

    int flag=0;
    int ItemRevNotfound=0;
	tag_t     itemTAG	    = NULLTAG;
	tag_t     itemRevTagm1	= NULLTAG;
	tag_t     relTypeTag	= NULLTAG;
	tag_t     relTag	= NULLTAG;
     //char*newstring3=(char *) MEM_alloc(sizeof(char)* 500);
	char*PartRevs=(char *) MEM_alloc(sizeof(char)* 500);

	char *newstring=NULL;
	char *newstring3=NULL;

	char*partno=NULL;
	char*revision=NULL;
	char*sequence=NULL;
	char*newString=NULL;
	char*Projectcode=NULL;
	//char*Projectreturn=NULL;
	//char*newString5=NULL;
	//char*newstring3=NULL;
	printf("TMKO part After fun call  %s\n",newString2);fflush(stdout);

	partno  = (char *)MEM_alloc(100);
	revision  = (char *)MEM_alloc(100);
	sequence  = (char *)MEM_alloc(100);
	newstring3  = (char *)MEM_alloc(100);
	newString  = (char *)MEM_alloc(100);
	sequence  = (char *)MEM_alloc(100);
	//Projectreturn  = (char *)MEM_alloc(100);
	//newString5  = (char *)MEM_alloc(100);

     STRNG_replace_str(newString2,"-",",",&newString);    //000080-A;2
	 STRNG_replace_str(newString,";",",",&newstring3);
	 printf("TMKO part newstring3  %s\n",newstring3);fflush(stdout);

	//tc_strcpy(newstring3,newString2);

    //newstring3=newString2;
	//printf("TMKO newstring3  %s\n",newstring3);fflush(stdout);

	partno   = tc_strtok(newstring3,",");      ///544288506309-F;1,54459988000R-NR;1
	revision = tc_strtok(NULL,",");
	sequence = tc_strtok(NULL,",");

	printf("TMKO partno*()  %s\n",partno);fflush(stdout);
	printf("TMKO revision*()  %s\n",revision);fflush(stdout);
	printf("TMKO sequence*()  %s\n",sequence);fflush(stdout);

	tc_strcpy(PartRevs,"");
	tc_strcat(PartRevs,revision);
	tc_strcat(PartRevs,";");
	tc_strcat(PartRevs,sequence);
	printf("TMKO PartRevs  %s\n",PartRevs);fflush(stdout);

	


	ITK_CALL(ITEM_find_item(partno,&itemTAG));
	if(itemTAG != NULLTAG)
	{

      printf("\n Item found \n");fflush(stdout);

	}
	else
	{
		   //return newString2;
		   *newString5=newString2;
	      printf("\n Item not found \n");fflush(stdout);

	}


	ITK_CALL(ITEM_find_revision(itemTAG,PartRevs,&itemRevTagm1));

	if(itemRevTagm1 != NULLTAG)
	{

		
	  ITK_CALL(AOM_ask_value_string(itemRevTagm1,"t5_ProjectCode",&Projectcode));
      printf("\n Item Revision found \n");fflush(stdout);
      printf("\n Design Revision Projectcode %s\n",Projectcode);fflush(stdout);
	  *Projectreturn= Projectcode;



	}
	else
	{

	 ItemRevNotfound=1;

	// tc_strcpy(PartRevs2,"");
	 //tc_strcpy(PartRevs2,"");

	// return 0;
	
	   printf("\n Item Revision not found \n");fflush(stdout);
	   *newString5=newString2;
	
	}

	printf("partno  %s\n",partno);fflush(stdout);
	printf("revision  %s\n",revision);fflush(stdout);
	printf("sequence  %s\n",sequence);fflush(stdout);

	flag++;
	partno=NULL;
	revision=NULL;
	sequence=NULL;
	PartRevs=NULL;
	//newstring3=NULL;
	printf("flag  %d\n",flag);fflush(stdout);
	//newString2=tc_strtok(NULL,",");             //Toking comma in NULL
	
	



}

/*int documentattach(char* newString2, tag_t TMKODocrev)
{

    int flag=0;
    int ItemRevNotfound=0;
	tag_t     itemTAG	    = NULLTAG;
	tag_t     itemRevTagm1	= NULLTAG;
	tag_t     relTypeTag	= NULLTAG;
	tag_t     relTag	= NULLTAG;
     //char*newstring3=(char *) MEM_alloc(sizeof(char)* 500);
	char*PartRevs=(char *) MEM_alloc(sizeof(char)* 500);

	char *newstring=NULL;
	char *newstring3=NULL;

	char*partno=NULL;
	char*revision=NULL;
	char*sequence=NULL;
	char*newString=NULL;
	//char*newstring3=NULL;
	printf("TMKO part After fun call  %s\n",newString2);fflush(stdout);

	partno  = (char *)MEM_alloc(100);
	revision  = (char *)MEM_alloc(100);
	sequence  = (char *)MEM_alloc(100);
	newstring3  = (char *)MEM_alloc(100);
	newString  = (char *)MEM_alloc(100);
	sequence  = (char *)MEM_alloc(100);

     STRNG_replace_str(newString2,"-",",",&newString);
	 STRNG_replace_str(newString,";",",",&newstring3);
	 printf("TMKO part newstring3  %s\n",newstring3);fflush(stdout);

	//tc_strcpy(newstring3,newString2);

    //newstring3=newString2;
	//printf("TMKO newstring3  %s\n",newstring3);fflush(stdout);

	partno   = tc_strtok(newstring3,",");      ///544288506309-F;1,54459988000R-NR;1
	revision = tc_strtok(NULL,",");
	sequence = tc_strtok(NULL,",");

	printf("TMKO partno*()  %s\n",partno);fflush(stdout);
	printf("TMKO revision*()  %s\n",revision);fflush(stdout);
	printf("TMKO sequence*()  %s\n",sequence);fflush(stdout);

	tc_strcpy(PartRevs,"");
	tc_strcat(PartRevs,revision);
	tc_strcat(PartRevs,";");
	tc_strcat(PartRevs,sequence);
	printf("TMKO PartRevs  %s\n",PartRevs);fflush(stdout);

	


	ITK_CALL(ITEM_find_item(partno,&itemTAG));
	if(itemTAG != NULLTAG)
	{

      printf("\n Item found \n");fflush(stdout);

	}
	else
	{
	      printf("\n Item not found \n");fflush(stdout);

	}


	ITK_CALL(ITEM_find_revision(itemTAG,PartRevs,&itemRevTagm1));

	if(itemRevTagm1 != NULLTAG)
	{
      printf("\n Item Revision found \n");fflush(stdout);
	  ITK_CALL(GRM_find_relation_type("IMAN_specification",&relTypeTag));


		if(relTypeTag != NULLTAG)
		{

		  printf("\n Relation found \n");fflush(stdout);

		}
		else
		{
			  printf("\n Relation not found \n");fflush(stdout);

		}


	    ITK_CALL(GRM_create_relation(itemRevTagm1,TMKODocrev,relTypeTag,NULLTAG,&relTag));
	    ITK_CALL(GRM_save_relation(relTag));

        printf("\n After Save Relation\n");fflush(stdout);


	}
	else
	{

	 //ItemRevNotfound=1;

	 //return ItemRevNotfound;
	
	   printf("\n Item not found \n");fflush(stdout);
	
	}

	printf("partno  %s\n",partno);fflush(stdout);
	printf("revision  %s\n",revision);fflush(stdout);
	printf("sequence  %s\n",sequence);fflush(stdout);

	flag++;
	partno=NULL;
	revision=NULL;
	sequence=NULL;
	PartRevs=NULL;
	newstring3=NULL;
	printf("flag  %d\n",flag);fflush(stdout);
	//newString2=tc_strtok(NULL,",");             //Toking comma in NULL
	



}*/

/*int dataextraction(char* Projectcode,int**resultCount2)
{

       int resultCount1=0;
       int n_entries=1;


	   tag_t queryTag = NULLTAG;


	   char*qry_entries2=NULL;
	   char*qry_values3=NULL;
	   char*Projectcodevalue=NULL;
	   Projectcodevalue= (char *)MEM_alloc(100)


	   tc_strcpy(Projectcodevalue,"");
	   tc_strcat(Projectcodevalue,"*");
	   tc_strcat(Projectcodevalue,Projectcode);
	   tc_strcat(Projectcodevalue,"*");



		queryTag = NULLTAG;
		ITK_CALL(QRY_find("TMKO_Document_Properties", &queryTag));
		if(queryTag!=NULLTAG)
	    {
		
		printf("\n Query tag Found Successfully\n")
		
		
		}

		qry_entries2[0] = (char *)MEM_alloc(100);
		strcpy(qry_entries2[0], "Project Code");

		qry_values3[0] = (char *)MEM_alloc(100);
		tc_strcpy(qry_values3[0], Projectcodevalue);

		//QRY_set_name_mode(queryTag,false);
		//Execute Query
		ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags));

		Projectcodevalue=NULL;


		if(resultCount1>0)
	    {
		
		
		*resultCount2=resultCount1;
		
		
		}


}
/*int TMKODocTablesave(tag_t TMKODoctable)
{

   int count=0;
   int i=0;
   char*Projectcode=NULL;
   char*DvloName=NULL;
   int retruncount=0;
   tag_t * TableRowtag = NULLTAG;
   DvloName = (char*)MEM_alloc(500);



    ITK_CALL(AOM_lock(TMKODoctable)) ;
	ITK_CALL(AOM_ask_table_rows(TMKODoctable,"t5_TMKO_Table_Properties",&count,&TableRowtag));
	printf("\n t5_TMKO_Table_Properties Count found is %d\n",count);fflush(stdout);
	//tc_strcpy(DvloName,"");
    //tc_strcat(DvloName,"bachg");
	printf("\n DvloName %s\n",DvloName);fflush(stdout);



	 for (i=0; i<count; i++)
	{
     

     ITK_CALL(AOM_ask_value_string(TableRowtag[i],"t5_Project_code",&Projectcode));

	 for (j=0; j<count ;i++)
	 {

       dataextraction(Projectcode,&retruncount);




	 }



	 ITK_CALL(AOM_lock(TableRowtag[i]));


	 ITK_CALL(AOM_set_value_string(TableRowtag[i],"t5_PL_Deviation",retruncount));

	 ITK_CALL(AOM_set_value_string(TableRowtag[i],"t5_FMQ",DvloName));
	 ITK_CALL(AOM_save(TableRowtag[i]));
	 //ITK_CALL(AOM_unlock(TableRowtag[i]));
	 ITK_CALL ( AOM_refresh ( TableRowtag[i],TRUE ) );
	 printf("\n DvloName 22222225585%s\n",DvloName);fflush(stdout);

	 
	 
	 }
	 ITK_CALL(AOM_save(TMKODoctable) ); 
     //ITK_CALL(AOM_unlock(TMKODoctable)); 
	 ITK_CALL(AOM_refresh(TMKODoctable,TRUE));







}*/

int TMKOrevcreationfun(tag_t TMKODocrev)
{

	char* Partno   = NULL;
	char* partnodup = NULL;
	char Partno2[1000];
	char partnodup2[1000];
	char* sequence = NULL;
	char* Revision = NULL;
	char* PartRevs = NULL;
	char* newString = NULL;
	char* newString2 = NULL;
	//char* toker   = NULL;
	partnodup  = (char *)MEM_alloc(500);

	char*toker=(char *) MEM_alloc(sizeof(char)* 500);
	char *tempValue = (char*)malloc(100 * sizeof(char));
	char *tempValue2 = (char*)malloc(100 * sizeof(char));


	tag_t     itemTAG	    = NULLTAG;
	tag_t     itemRevTagm1	= NULLTAG;
	tag_t     relTypeTag	= NULLTAG;
	tag_t     relTag	    = NULLTAG;
	int i=0;
	int flag=0;
	int itr=0;
	int c=0;
	int j=0;
	int m=0;
	int k=0;
	int Wrongdataflag=0;
	char* returnvalue=NULL;
	char* Projectcodevalue=NULL;

	PartRevs  = (char *)MEM_alloc(100);
	newString  = (char *)MEM_alloc(100);
	newString2  = (char *)MEM_alloc(100);
	returnvalue  = (char *)MEM_alloc(500);
	Projectcodevalue  = (char *)MEM_alloc(500);
	char* documentNameS = NULL;
	char* Projectcode = NULL;
    documentNameS = (char *)MEM_alloc(500);
    Projectcode = (char *)MEM_alloc(500);
    tc_strcpy(documentNameS,"");
    tc_strcpy(Projectcode,"");
    tc_strcpy(Projectcodevalue,"");


	ITK_CALL(AOM_ask_value_string(TMKODocrev,"t5_Part_Number",&Partno));
	printf("TMKO part no %s\n",Partno);fflush(stdout); 

	tc_strdup(Partno,&partnodup);
	printf("TMKO partnodup %s\n",partnodup);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(TMKODocrev,"t5_Sequence",&sequence));
	
	printf("TMKO part no sequence %s\n",sequence);fflush(stdout);

    ITK_CALL(AOM_ask_value_string(TMKODocrev,"t5_Revision",&Revision));
	printf("TMKO part Revision %s\n",Revision);fflush(stdout);

	for(i=0;Partno[i]!='\0';i++)
	{

	
	  Partno2[i] = Partno[i];
	
	
	
	}
	Partno2[i]='\0';
	printf("TMKO part number Partno2  %s\n",Partno2);fflush(stdout);
	printf("TMKO part number Partno  %s\n",Partno);fflush(stdout);
    
	for(itr=0;Partno2[itr]!='\0';itr++)
	{ 
        if(Partno2[itr]==',')
        {
            tempValue[c]='\0';
            printf(" tempValue[c] = %s \n",tempValue);
            c=0;
            
            objectfind(tempValue,&returnvalue,&Projectcode);
			printf("return value from function is1^^^  %s\n",returnvalue);fflush(stdout);

			//tc_strlen(returnvalue);
            //if(returnvalue!=NULL)
			if(tc_strlen(returnvalue)>0)
		    {
				printf("returnvalue Length :: %d\n",tc_strlen(returnvalue));fflush(stdout);

				printf("\n inside return value 1 condtion  \n");fflush(stdout);
             //tc_strcat(documentNameS,",");
			 Wrongdataflag=1;
			 tc_strcat(documentNameS,returnvalue);
			 tc_strcat(documentNameS,",");

			 
			
			}
			if(Projectcode!=NULL)
			{
			
			tc_strcat(Projectcodevalue,Projectcode);
			tc_strcat(Projectcodevalue,",");
			
			
			}
			
            //ItemCheck(newString);
        }
        else if(Partno2[itr+1]=='\0')
        {
            tempValue[c]=Partno2[itr];
			c++;
            tempValue[c]='\0';
            printf(" else tempValue[c] = %s \n",tempValue);
            
			//returnvalue = objectfind(tempValue);
			objectfind(tempValue,&returnvalue,&Projectcode);
			printf("return value from function is2^^^  %s\n",returnvalue);fflush(stdout);
			printf("Projectcode value from function is2^^^  %s\n",Projectcode);fflush(stdout);

			 if(tc_strlen(returnvalue)>0)
		    {
				 printf("returnvalue Length 1 :: %d\n",tc_strlen(returnvalue));fflush(stdout);
				 printf("\n inside return value condtion  \n");fflush(stdout); 


			 Wrongdataflag=1;
			 tc_strcat(documentNameS,returnvalue);
			 tc_strcat(documentNameS,",");
			
			}
			if(Projectcode!=NULL)
			{
			
			 tc_strcat(Projectcodevalue,Projectcode);
			 tc_strcat(Projectcodevalue,",");
			
			
			}

            //ItemCheck(newString);
        }
        else
        {
            tempValue[c]=Partno2[itr];
            c++;
        }
        
	}


	printf("incorrect part no is  %s\n",documentNameS);fflush(stdout);
	
		printf("Flag value Wrongdataflag********* %d\n",Wrongdataflag);fflush(stdout);

     if(Wrongdataflag<=0)
     {


		 
//		if(AOM_lock(TMKODocrev));
//
//		 printf("\n Allow to create Document202020\n");fflush(stdout);
//		 ITK_CALL(AOM_set_value_string(TMKODocrev,"t5_Project_Code",Projectcodevalue));
//	     printf("TMKO Project_Code no %s\n",Projectcodevalue);fflush(stdout);
//
//
//		if(AOM_save(TMKODocrev));
//		if(AOM_unlock(TMKODocrev));
//		if(AOM_refresh(TMKODocrev,1));
		 
		for(j=0;partnodup[j]!='\0';j++)
		{

		  partnodup2[j] = partnodup[j];
		}
		partnodup2[j]='\0';


		printf(" partnodup2 = %s ",partnodup2);
		printf("\n Inside the TMKO Creation code\n");fflush(stdout);

	for(m=0;partnodup2[m]!='\0';m++)
	{ 
        if(partnodup2[m]==',')
        {
            tempValue2[k]='\0';
            printf(" tempValue[k] = %s \n",tempValue2);
            k=0;
            
            //documentattach(tempValue2,TMKODocrev);
			//printf("return value from function is  %d\n",returnvalue);fflush(stdout)		
            //ItemCheck(newString);
        }
        else if(partnodup2[m+1]=='\0')
        {
            tempValue2[k]=partnodup2[m];
			k++;
            tempValue2[k]='\0';
            printf(" else tempValue[k] = %s \n",tempValue2);
            
			//documentattach(tempValue2,TMKODocrev);

            //ItemCheck(newString);
        }
        else
        {
            tempValue2[k]=partnodup2[m];
            k++;
        }
        
	}


	}
	else if(Wrongdataflag>0)
	{
	     printf("\n Item Revision not found \n");fflush(stdout);

	      printf("Part not found ......\n");fflush(stdout);
		  //EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Enter correct Part Number,Revision and Sequence");
		  EMH_store_error_s2(EMH_severity_error,ITK_err," Please Enter correct Part Number,Revision and Sequence",documentNameS);
		  printf("After error.........\n");fflush(stdout);
		  return ITK_err;
	      printf("\n Item not found \n");fflush(stdout);
	
	
	
	}


//
//	for(i=0;Partno[i]!='\0';i++)
//	{
//
//	
//	  Partno2[i] = Partno[i];
//	
//	
//	
//	}
//	Partno2[i]='\0';
//	printf("TMKO part number Partno2  %s\n",Partno2);fflush(stdout);
//	printf("TMKO part number Partno  %s\n",Partno);fflush(stdout);
//
//	toker=tc_strtok(Partno2,",");   //544288506309-F;1,54459988000R-NR;1,
//		 
//
//	printf("TMKO toker Point 1 =  %s\n",toker);fflush(stdout);


//	while(toker!=NULL)
//	{
//	
//	  printf("TMKO part number toker Point****** 2 =  %s\n",toker);fflush(stdout);
//	  STRNG_replace_str(toker,"-",",",&newString);
//	  STRNG_replace_str(newString,";",",",&newString2);
//	  printf("TMKO part newString2  %s\n",newString2);fflush(stdout);
//	
//	  objectfind(newString2);
//	  toker=tc_strtok(NULL,",");
//      printf("TMKO toker Point 3 =  %s\n",toker);fflush(stdout);
//	}
//
//	tc_strcpy(PartRevs,"");
//	tc_strcat(PartRevs,Revision);
//	tc_strcat(PartRevs,";");
//	tc_strcat(PartRevs,sequence);
//	printf("TMKO part Revision and sequence %s\n",PartRevs);fflush(stdout);
//
//
//
//	ITK_CALL(ITEM_find_item(Partno,&itemTAG));
//	if(itemTAG != NULLTAG)
//	{
//
//      printf("\n Item found \n");fflush(stdout);
//
//	}
//	else
//	{
//	      printf("\n Item not found \n");fflush(stdout);
//
//	}
//
//	ITK_CALL(ITEM_find_revision(itemTAG,PartRevs,&itemRevTagm1));
//
//
//	if(itemRevTagm1 != NULLTAG)
//	{
//      printf("\n Item Revision found \n");fflush(stdout);
//	  ITK_CALL(GRM_find_relation_type("IMAN_specification",&relTypeTag));
//
//
//		if(relTypeTag != NULLTAG)
//		{
//
//		  printf("\n Relation found \n");fflush(stdout);
//
//		}
//		else
//		{
//			  printf("\n Relation not found \n");fflush(stdout);
//
//		}
//
//
//	    ITK_CALL(GRM_create_relation(itemRevTagm1,TMKODocrev,relTypeTag,NULLTAG,&relTag));
//	    ITK_CALL(GRM_save_relation(relTag));
//
//        printf("\n After Save Relation\n");fflush(stdout);
//
//
//	}
//	else
//	{
//		  printf("\n Item Revision not found \n");fflush(stdout);
//
//	      printf("Part not found ......\n");fflush(stdout);
//		  EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Enter correct Part Number,Revision and Sequence");
//		  printf("After error.........\n");fflush(stdout);
//		  return ITK_err;
//	
//	}


    printf("flag tgt  %d\n",flag);fflush(stdout);
	printf("\n END of TMKO Creation \n");fflush(stdout);

 return 0;


}




int t5_dfq_document_creation(tag_t dfq_doc_cre_form)
{
	logical t5_dfq_applicability_logical = 0;
	int status = 0;
	int k = 0;
	int j = 0;
	int n_entries = 1;
	int number_of_types1 = 0;
	int sec_result_count = 0;
	int create_document = 0;
	int resultCount1 = 0;
	int resultCount2 = 0;
	int incremental_value = 0;
	int incremental_value_latest = 0;
	tag_t *dfq_use_case_tags = NULLTAG;
	tag_t *dfq_document_dataset_tags = NULLTAG;
	tag_t *available_dfq_document_tags = NULLTAG;
	tag_t *proj_tags = NULLTAG;
	tag_t object_create_input_tag3 = NULLTAG;
	tag_t docTag = NULLTAG;
	tag_t relTypeTag = NULLTAG;
	tag_t relTag = NULLTAG;
	tag_t user_data_tag = NULLTAG;
	tag_t *type_tag3 = NULLTAG;
	char* documentNameS = NULL;
	char* documentName1S = NULL;
	char* partTypeS = NULL;
	char* checkedOutS = NULL;
	char* moduleAddressS = NULL;
	char* DesignGrp = NULL;
	char* subGroup  =NULL;
	char* moduleAddressSvalue = NULL;
	char* dfq_use_case_uid = NULL;
	char* dfq_available_doc_uid = NULL;
	char* dfq_use_case_desc = NULL;
	char* documentName = NULL;
	char* dfq_dataset_incremental_value = NULL;
	
	char* t5_projectc_code_string = NULL;
	char* t5_business_unit_type = NULL;
	char* t5_business_unit_type_mod = NULL;
	char* sItemId = NULL;
	char* destinationExcelPathS = NULL;
	char* command = NULL;
	char* dfq_use_case = NULL;
	char* DVA_project_Code = NULL;
	char *s;
	char * DFQ_Project_Code=NULL;
	char * DFQ_Project_Code2=NULL;
	char * DVA_project_Codedup=NULL;
	

	char searchEntry1 [1][30] = {"Dataset Name"};

	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char ** qry_entries1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	moduleAddressS  = (char *)MEM_alloc(100);

	tag_t itemTAG			= NULLTAG;
	tag_t itemRevTAG		= NULLTAG;
	tag_t queryTag			= NULLTAG;
	tag_t		newFileTag	= NULLTAG;
	int PrtRelStus_cnt		= 0;
	int n					= 0;
	tag_t *PrtRelStusTg     = NULLTAG;
	tag_t queryTag1			= NULLTAG;
	char*	 PrtRelStus		= NULL;
	char*    partNumber     = NULL;
	char*    DesignGrp13    = NULL;

	IMF_file_t   	fileDescriptor	 ;

	AOM_ask_value_string(dfq_doc_cre_form,"t5_ItemID",&sItemId);
	printf("Item ID :: %s\n",sItemId);fflush(stdout); 
	
	AOM_ask_value_string(dfq_doc_cre_form,"t5_DVA_Project_Code",&DVA_project_Code);
	tc_strdup(DVA_project_Code,&DVA_project_Codedup);
	printf("DVA_project_Codedup :: %s\n",DVA_project_Codedup);fflush(stdout);
	printf("DVA project Code :: %s\n",DVA_project_Code);fflush(stdout);
	printf("DVA project Length :: %d\n",tc_strlen(DVA_project_Code));fflush(stdout);

	
    if(tc_strlen(DVA_project_Code)>0)
	{
      printf("DVA project Code found\n");fflush(stdout);
                     
	}
	else
	{
		        printf("before error......\n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Please select the project code from drop down");
				printf("After error.........\n");fflush(stdout);
				return ITK_err;
	}

	ITEM_find_item(sItemId,&itemTAG);

	if(itemTAG != NULLTAG)
	{
		printf("\nItem Tag Found \n");

		ITEM_ask_latest_rev(itemTAG, &itemRevTAG);
		if(itemRevTAG != NULLTAG)
		{
			//AOM_lock(itemRevTAG);
			//AOM_set_value_string(itemRevTAG,"t5_ModuleAddress","MB1C01");
			//AOM_save_with_extensions(itemRevTAG);
			//AOM_refresh(itemRevTAG);

			printf("\n Item Revision Tag Found \n");
			AOM_ask_value_string(itemRevTAG,"t5_PartType",&partTypeS);
			printf("\n partTypeS %s\n",partTypeS);fflush(stdout);

			
			if(tc_strcmp(partTypeS,"M")==0 || tc_strcmp(partTypeS,"T")==0)
			{
				printf("\n Allowed for creation DVA\n");fflush(stdout);
				
			}
			else
			{
			
			   printf("\n*** DFQ Document can be created only for objects having PartType as Module/TPL ***\n");fflush(stdout);
				//return 0; Only Module are allowed for DFQ Document Creation

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "DVA Document can be created only for objects having PartType as Module/TPL");
				return ITK_err;
			
			}

			AOM_ask_value_string(itemRevTAG,"checked_out",&checkedOutS);
			printf("\n checkedOutS %s\n",checkedOutS);fflush(stdout);

			//if(tc_strcmp(checkedOutS,"Y")!=0)
			//{
			//	printf("*** DFQ Document can be created only for Checked-Out Parts. ***\n",sItemId);fflush(stdout);
				//return 0; Only checked out DesRev and be used

			//	EMH_clear_errors();
			//	EMH_store_error_s1(EMH_severity_error,ITK_err, "DFQ Document can be created only for Checked-Out Parts");
			//	return ITK_err;
			//}

			PrtRelStus_cnt=0;
			WSOM_ask_release_status_list (itemRevTAG, &PrtRelStus_cnt, &PrtRelStusTg);
			printf("\n T5PartToTaskDeleteVal:PrtRelStus_cnt is:%d.", PrtRelStus_cnt);fflush(stdout);

			if(PrtRelStus_cnt > 0)
			{
				n=0;
				for(n=0;n<PrtRelStus_cnt;n++)
				{
					AOM_ask_value_string (PrtRelStusTg[n],"object_name", &PrtRelStus);
					printf("\n T5PartToTaskDeleteVal:PrtRelStus is:%s.",PrtRelStus);fflush(stdout);
					if(tc_strstr(PrtRelStus,"T5_LcsErcRlzd")!= NULL)
					{
						printf("*** DFQ Document creation not allow for Released Module ***\n");fflush(stdout);
						//return 0; Only checked OUT OR checked IN DesRev to be used

						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, "DVA Document creation not allow for Released Module/TPL");
						return ITK_err;
					}
				}
			}
			/*--------------------------------------------------------
				Get Business Unit from Project Code"
			---------------------------------------------------------*/
			AOM_ask_value_string(itemRevTAG,"t5_ProjectCode",&t5_projectc_code_string);
			printf("\n t5_projectc_code_string %s\n",t5_projectc_code_string);fflush(stdout);

			queryTag = NULLTAG;
			status = QRY_find2("Project for DSRpt", &queryTag);
			if (status != ITK_ok)
			{
				  EMH_ask_error_text( status, &s);
				  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
				  MEM_free(s);
				  return status;
			}

			qry_entries2[0] = (char *)MEM_alloc(15);
			strcpy(qry_entries2[0], "Project Number");

			qry_values3[0] = (char *)MEM_alloc(10);
			tc_strcpy(qry_values3[0], t5_projectc_code_string);

			QRY_set_name_mode(queryTag,false);
			//Execute Query
			status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

			if(resultCount1 == 0)
			{
				EMH_ask_error_text( status, &s);
				printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
				//MEM_free(s);
				//return status;

				EMH_store_error_s2(EMH_severity_information,ITK_err," No Project Found ", t5_projectc_code_string);
				return ITK_err;
			}

			AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type);
			printf("\nBusiness Unit -- %s\n",t5_business_unit_type);fflush(stdout);

			if(tc_strcmp(t5_business_unit_type,"CVBU") == 0) t5_business_unit_type_mod = "CV";
			else if(tc_strcmp(t5_business_unit_type,"PCBU") == 0) t5_business_unit_type_mod = "PV";
			else if(tc_strcmp(t5_business_unit_type,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
			else
			{
				EMH_ask_error_text( status, &s);
				printf("\n*** No Business Unit found for -- %s -- %s\n", t5_projectc_code_string, t5_business_unit_type);fflush(stdout);
				//MEM_free(s);
				//return status;

				EMH_store_error_s2(EMH_severity_information,ITK_err," No Business Unit found for Project code ", t5_projectc_code_string);
				return ITK_err;
			}

			/*--------------------------------------------------------
				Get Applicable DFQ USE CASE
			---------------------------------------------------------*/
			if(tc_strcmp(partTypeS,"M")==0)
			{

			//AOM_ask_value_string(itemRevTAG,"t5_ModuleAddress",&moduleAddressS);
			AOM_ask_value_string(itemRevTAG,"t5_ModuleAddress",&moduleAddressSvalue);
			printf("\n New moduleAddressSvalue %s\n",moduleAddressSvalue);fflush(stdout);
			tc_strcpy(moduleAddressS,"");
			tc_strcat(moduleAddressS,moduleAddressSvalue);
			printf("\n Tm_DVA_Creation After cat Module Address %s\n",moduleAddressS);fflush(stdout);

			if (strlen(moduleAddressS) == 0)
			{
				printf("\n Module Address should not Blank for Part Typer is Module\n");fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Module Address should not Blank for Part Type is Module");
				return ITK_err;
			}


			}

			if(tc_strcmp(partTypeS,"T")==0)
			{
			//If Part of Desgin Group Restructuring like 54
            AOM_ask_value_string(itemRevTAG,"item_id",&partNumber);
			printf("\n t5_dfq_document_creation :: Part Number = %s",partNumber);
			if(tc_strlen(partNumber)==13 && tc_strcmp(partNumber,"M")!=0)
			{
			  AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&DesignGrp13);
              printf("\n t5_dfq_document_creation ::  Design Group = %s ",DesignGrp13);
			  subGroup = subString(partNumber,8,4);
			  tc_strcpy(moduleAddressS,"");
			  tc_strcat(moduleAddressS,subGroup);
              printf("\n tm_DVA_Creation After cat Design Group %s\n",moduleAddressS);fflush(stdout);
			  if (strlen(DesignGrp13) == 0)
			 {
				printf("\n  Design Group should not Blank for Part Typer is TPL\n");fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, " Design Group should not Blank for Part Type is TPL");
				return ITK_err;
			 } 
			}
            else
			{
			AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&DesignGrp);
			printf("\n Design Group %s\n",DesignGrp);fflush(stdout);

			tc_strcpy(moduleAddressS,"");
			tc_strcat(moduleAddressS,DesignGrp);

			printf("\n tm_DVA_Creation After cat Design Group %s\n",moduleAddressS);fflush(stdout);

			if (strlen(moduleAddressS) == 0)
			{
				printf("\n  Design Group should not Blank for Part Typer is TPL\n");fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, " Design Group should not Blank for Part Type is TPL");
				return ITK_err;
			}
            }

			}
			


	

			queryTag = NULLTAG;
			status = QRY_find2("General...", &queryTag);
			if (status != ITK_ok)
			{
			  EMH_ask_error_text( status, &s);
			  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
			  MEM_free(s);
			  return status;
			}

			//Query DFQ Use Case
			documentName = NULL;
			documentName = (char *)MEM_alloc(50);
			tc_strcpy(documentName, "DVA_");
			tc_strcat(documentName, t5_business_unit_type_mod);
			tc_strcat(documentName, "_");
			//tc_strcat(documentName, "MB1C01_");
			tc_strcat(documentName, moduleAddressS);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, "*"); 

			qry_entries[0] = (char *)MEM_alloc(10);
			strcpy(qry_entries[0], "Name");

			qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
			tc_strcpy(qry_values1[0], documentName);

			printf("Business Unit 22222 -- %s\n",documentName);fflush(stdout);

			status = QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags);
			printf("\nNo. of DFA Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

			if(resultCount1 > 0)
			{
				char* excelPathS;
				ITK_CALL( PREF_ask_char_value("DFQ_EXCEL_SHEET_PATH", 0 , &excelPathS ) );
				printf("\nExcel Full Path  :: %s",excelPathS ) ;fflush(stdout);

				if( excelPathS == NULL )
				{
						printf("\npreference not found hence default value is /tmp");fflush(stdout);
				}

				//Get DFQ Document Class Type
				ITK_CALL(TCTYPE_find_types_for_class("T5_DFQ_Document",&number_of_types1,&type_tag3));
				printf("\n Number of class found are-------->  : %d\n",number_of_types1);fflush(stdout);

				//Get DFQ Document Relation Class Type
				GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

				//Get Attached DFQ Documents
				GRM_list_secondary_objects_only(itemRevTAG, relTypeTag, &sec_result_count,&available_dfq_document_tags);
				printf("\nNo of Attached DFQ Documetns are :: %d\n",sec_result_count);fflush(stdout);

				//Query Existing DFQ Document Dataset Tag
				queryTag1 = NULLTAG;
				status = QRY_find2("General...", &queryTag1);
				if (status != ITK_ok)
				{
				  EMH_ask_error_text( status, &s);
				  printf("\n*** Error with Finding Query -- General... ***\n");fflush(stdout);
				  MEM_free(s);
				  return status;
				}

				/* -----------------------------------------------------------------------------
					Code written to get running serial number
					Query all the DFQ Documents having Modules Address and Item ID as below
				------------------------------------------------------------------------------*/
				//Construct STring for Query

				documentName1S = NULL;
				documentName1S = (char *)MEM_alloc(50);
				tc_strcpy(documentName1S, "DVA");
				tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, DVA_project_Code);
			    tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, sItemId);
				tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, "*"); // to be veriried by Tushar

				printf("\nString to QUery -- |%s|\n", documentName1S);fflush(stdout);

				qry_entries1[0] = (char *)MEM_alloc(20);
				strcpy(qry_entries1[0], "Name");

				qry_values2[0] = (char *)MEM_alloc(51);
				tc_strcpy(qry_values2[0], documentName1S);

				//printf("\nNo. of entries in query are -- %d\n", n_entries);fflush(stdout);
				QRY_set_name_mode(queryTag1,false);
				//Execute Query
				status = QRY_execute(queryTag1, n_entries, qry_entries1, qry_values2, &resultCount2, &dfq_document_dataset_tags);
				printf("\nNo of DFQ Documetns are :: %d\n",resultCount2);fflush(stdout);

				if(resultCount2 == 0)
				{
					incremental_value = 0;
				}
				else
				{
					for (j=0;j<resultCount2 ; j++)
					{
						AOM_ask_value_string(dfq_document_dataset_tags[j],"object_name",&dfq_use_case_uid);
						printf("Datset Name -- %s\n",dfq_use_case_uid);fflush(stdout);

						dfq_dataset_incremental_value = NULL;
						tc_strcpy(dfq_use_case,"");
						tc_strcat(dfq_use_case,dfq_use_case_uid);  //DVA_5442_5442MA543_001
						tc_strtok(dfq_use_case_uid,"_"); 
						tc_strtok(NULL,"_"); 
						tc_strtok(NULL,"_");   
					    dfq_dataset_incremental_value = tc_strtok(NULL,"_");
              
						
                        printf("dfq_dataset_incremental_value Name ------- %s\n",dfq_dataset_incremental_value);fflush(stdout);
   
						incremental_value_latest = atoi(dfq_dataset_incremental_value);

						printf("\nincremental_value_latest :: %d\n",incremental_value_latest) ;
						printf("\nincremental_value :: %d\n",incremental_value) ; fflush(stdout);
						if(incremental_value_latest > incremental_value) incremental_value = incremental_value_latest;
					}
				}

				/*-----------------------------------------------------------------------------
					Code written to get running serial number
					Query all the DFQ Documents having Modules Address and Item ID as below
				------------------------------------------------------------------------------*/

				//Looping through DFQ Use Cases to Create DFQ Document if DFQ_Applicability is True and DFQ Document is not available

				for (j=0;j<resultCount1 ; j++)
				{
					dfq_use_case_uid = NULL;
					AOM_ask_value_logical(dfq_use_case_tags[j],"t5_DfQApplicablility",&t5_dfq_applicability_logical);
					printf("%d\n",t5_dfq_applicability_logical);fflush(stdout);

					AOM_ask_value_string(dfq_use_case_tags[j],"object_name",&dfq_use_case_uid);
					printf("DVA UID :: %s\n",dfq_use_case_uid);fflush(stdout);

					//Verifying DFQ Applicability is TRUE [1]
					if(t5_dfq_applicability_logical == 1)
					{
						create_document = 1;

						//Looping through Available DFQ Documents to ignore creation of available DFQ USE CASE ID.
						for (k=0;k<sec_result_count; k++ )
						{
							AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQUID",&dfq_available_doc_uid);
							printf("\nDFQ Document UID :: %s\n",dfq_available_doc_uid);fflush(stdout);

							AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQ_Project_Code",&DFQ_Project_Code);
							printf("\nDFQ Document UID :: %s\n",DFQ_Project_Code);fflush(stdout);

							AOM_ask_value_string(available_dfq_document_tags[k],"project_ids",&DFQ_Project_Code2);
							printf("\nDFQ Document project_ids :: %s\n",DFQ_Project_Code2);fflush(stdout);


							//AOM_UIF_ask_value(available_dfq_document_tags[k],"project_ids",&DFQ_Project_Code2);
							//printf("\nDFQ Document Project code2 :: %s\n",DFQ_Project_Code2);fflush(stdout);


							printf("\nDFQ_Project_Code2 *****:: %s\n",DFQ_Project_Code2);fflush(stdout);
							printf("\nDVA_project_Code ******:: %s\n",DVA_project_Code);fflush(stdout);

							if(tc_strcmp(DFQ_Project_Code, DVA_project_Code) == 0)
							{
								printf("\n Inside the first project code condition1111101155\n");fflush(stdout);

							    if(tc_strcmp(dfq_available_doc_uid, dfq_use_case_uid) == 0)
							   {
								create_document = 0;
								break;
							   }
							}
							else if(tc_strstr(DFQ_Project_Code2, DVA_project_Codedup)!= NULL)
							{
							  printf("\n Inside the Second project code condition22222222285\n");fflush(stdout);

								if(tc_strcmp(dfq_available_doc_uid, dfq_use_case_uid) == 0)
							   {
								create_document = 0;
								break;
							   }
							
							}
						}

						if(create_document == 1)
						{
							//Query
							incremental_value++;
							documentNameS = NULL;
							documentNameS = (char *)MEM_alloc(50);
							if(incremental_value < 9) sprintf(documentNameS,"DVA_%s_%s_00%d",DVA_project_Code, sItemId, incremental_value);
							else if(incremental_value < 99) sprintf(documentNameS,"DVA_%s_%s_0%d",DVA_project_Code, sItemId, incremental_value);
							else if(incremental_value < 999) sprintf(documentNameS,"DVA_%s_%s_%d",DVA_project_Code, sItemId, incremental_value);
							else sprintf(documentNameS,"DVA_%s_%s_00%d",DVA_project_Code, sItemId, incremental_value+1);
							printf("*******************%s-- %d\n",documentNameS,incremental_value);fflush(stdout);
							//DFQ Use Case object name

							//DFQ Use Case Desc
							AOM_ask_value_string(dfq_use_case_tags[j],"object_desc",&dfq_use_case_desc);
							printf("%s\n",dfq_use_case_desc);fflush(stdout);

							//Create DFQ Document

							destinationExcelPathS = NULL;
							command = NULL;
							command=(char *) MEM_alloc(500);
							destinationExcelPathS=(char *) MEM_alloc(300);
							sprintf(destinationExcelPathS,"/tmp/%s.xlsx",documentNameS);
							printf("destinationExcelPathS path %s\n",destinationExcelPathS);fflush(stdout);



							sprintf(command,"cp \"%s\" \"%s\"",excelPathS,destinationExcelPathS);
							TC_write_syslog("Command = %s\n",command);
							printf("Command********************************************* = %s\n",command);fflush(stdout);
							system(command);

							create_dataset_excel(itemRevTAG, documentNameS, dfq_use_case_desc, dfq_use_case_uid, destinationExcelPathS,DVA_project_Code);

//							//Construct Class Type
//							ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentNameS)); //add the following value on DF_DOcument in function create _dateaset_excel
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",dfq_use_case_desc));/add the following value on DF_DOcument in function create _dateaset_excel
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQUID",dfq_use_case_uid));/add the following value on DF_DOcument in function create _dateaset_excel
//
//							TCTYPE_create_object(object_create_input_tag3, &docTag);
//							if(docTag == NULLTAG)
//							{
//								printf("\n *** DFQ Document Creation Failed ***\n");fflush(stdout);
//
//							}
//							else
//							{
//								printf("\n DFQ Document Created.\n");fflush(stdout);
//								destinationExcelPathS = NULL;
//								command = NULL;
//								command=(char *) MEM_alloc(500);
//								destinationExcelPathS=(char *) MEM_alloc(300);
//								sprintf(destinationExcelPathS,"/tmp/%s.xlsx",documentNameS);
//
//								sprintf(command,"cp \"%s\" \"%s\"",excelPathS,destinationExcelPathS);
//								TC_write_syslog("Command = %s\n",command);
//								printf("Command = %s\n",command);fflush(stdout);
//								system(command);
//
//								ITK_CALL(AOM_lock(docTag));
//								//ITK_CALL(IMF_import_file(destinationExcelPathS, "T5_DFQ_EXCEL", SS_BINARY, &newFileTag, &fileDescriptor));
//								//ITK_CALL(AE_add_dataset_named_ref2(docTag,"T5_DFQ_EXCEL", AE_PART_OF, fileDescriptor));
//								ITK_CALL(AE_import_named_ref(docTag,"T5_DFQ_EXCEL", destinationExcelPathS, NULL, AE_PART_OF));
//								ITK_CALL(AE_save_myself(docTag));
//								ITK_CALL(AOM_refresh(docTag,false));
//
//								if(relTypeTag == NULLTAG) printf("\nRelation Tag is NULLTAG\n");fflush(stdout);
//								if(docTag == NULLTAG) printf("\nDocument Tag is NULLTAG\n");fflush(stdout);
//								if(itemRevTAG == NULLTAG) printf("\nItem REvision Tag is NULLTAG\n");fflush(stdout);
//
//								ITK_CALL(AM_set_mode(AM_MODE_ALL_GROUPS));
//								ITK_CALL(GRM_create_relation(itemRevTAG,docTag,relTypeTag,user_data_tag,&relTag));
//								if(relTag != NULLTAG)
//								{
//									ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//									printf("\n Design Revision and DFQ Document Relation Created\n");fflush(stdout);
//									ITK_CALL(AOM_lock(relTag));
//									ITK_CALL(AOM_save_with_extensions(relTag));
//									ITK_CALL(AOM_refresh(relTag,false));
//
//									ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//								}
//								else
//								{
//									printf("\n *** Design Revision and DFQ Document Relation Creation Failed. 111***\n");fflush(stdout);
//								}
//								ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//							}
						}
						else
						{
							printf("\n *** DFQ Document already available for USE CASE ID, ignoring creation of DFQ Document. ***\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n *** DFQ Applicability is FALSE, ignoring creation of DFQ Document. ***\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n *** No DFQ Document USE CASE Applicable. Ignoring Creation of DFQ Documents***\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n*** Design Revision tag Not Found. ***\n");fflush(stdout);

		}
	}
	else
	{
		printf("\n*** Design tag Not Found. ***\n");fflush(stdout);
	}
	return 0;
}

char* DVACalulate()
{
	char* ptr = NULL;
	float percentage;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);



	printf("\n\n DVACalulate--DFQApplcbltyCnt: [%d]  PDFAttachedCnt: [%d]  DFQMeetExpNoCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);


	if ((DFQApplCntflag != 0)&&(DFQpdfCount != 0))
	{

		percentage = (float)(MeetexpectationCnt) / DFQApplCntflag * 100.0;

		printf("\n  after calculation: Percentage = %.2f%%", percentage); fflush(stdout);
		sprintf(ptr,"%10lf",percentage);
		printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

char* GetDemeritScoreRating(char* DvloName , int DemeritScore)
{
	char* ptr = NULL;
	int dvr=0;


	ptr = (char *) MEM_alloc(sizeof(char)* 30);

      if (DvloName!=NULL)
	 {
		printf("\n  DvloName: %s   DemeritScore: %d",DvloName,DemeritScore);fflush(stdout);

		if (DemeritScore<=100)
		{
			dvr=100;
			printf("\n dvr value is 100*:%d",dvr);fflush(stdout);
		}
		else if( (DemeritScore<=130) && (DemeritScore>100))
		{
			dvr=80;
			printf("\n dvr value is 80*:%d",dvr);fflush(stdout);
		}
		else if (DemeritScore>130)
		{
			dvr=50;
			printf("\n dvr value is 50*:%d",dvr);fflush(stdout);
		}
		else
		{
			dvr=0;
			printf("\n dvr value is 0*:%d",dvr);fflush(stdout);
		}

		printf("\n dvr value is----:%d",dvr);fflush(stdout);
		sprintf(ptr,"%d",dvr);
		printf(" after conversion dvr: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

int getBusinessUnitFun(tag_t PartTag, char** ProjdescDup,char** Projname)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_business_unit_type_mod1;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjdescDup = t5_business_unit_type_mod;

	AOM_ask_value_string(proj_tags[0],"t5_VehicleClass",&t5_business_unit_type_mod1);
	printf("Vechile class -- %s\n",t5_business_unit_type_mod1);fflush(stdout);

	*Projname = t5_business_unit_type_mod1;

	return 0;
}

int getBusinessUnitFunc(tag_t PartTag, char** ProjbussDup,char**ProjdescDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_ProjectDescp=NULL;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);
	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_ProjectDescp);
	printf("project desc -- %s\n",t5_ProjectDescp);fflush(stdout);

	*ProjdescDup = t5_ProjectDescp;

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

int getBusinessUnitFunct(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}
int getBusinessUnitFunct222(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);

	printf("t5_ProjectCode22222%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

int GetDVAUseCaseFromLibraryt(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName=NULL;
	char* PartNumstyp=NULL;
	char* s=NULL;
	char* moduleAddressS=NULL;
	char* moduleAdd=NULL;
	char* Designgroupvalue=NULL;
	char* partNumber=NULL;
	char* DesignGrp13=NULL;
	char* subGroup=NULL;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;
	moduleAddressS = (char *)MEM_alloc(100);


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	ITK_CALL(AOM_ask_value_string(PartTag,"bl_Design Revision_t5_PartType",&PartNumstyp));
	printf("\n GCI Creation Part Type is  :: %s\n",PartNumstyp);fflush(stdout);


	if(tc_strcmp(PartNumstyp,"M")==0)
	{
       

	  AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ModuleAddress",&moduleAdd);
	  printf("\n Module Address  :: %s\n",moduleAdd);fflush(stdout);

	  tc_strcpy(moduleAddressS,"");
	  tc_strcat(moduleAddressS,moduleAdd);
	  printf("\n GCI Create After cat moduleAddressS %s\n",moduleAddressS);fflush(stdout);


	}

	if(tc_strcmp(PartNumstyp,"T")==0)
	{
      
      AOM_ask_value_string(PartTag,"bl_item_item_id",&partNumber);
	  printf("\n GetDVAUseCaseFromLibraryt :: Part Number = %s",partNumber);
	  if(tc_strlen(partNumber)==13 && tc_strcmp(partNumber,"M")!=0)
	  {
		      //If Part of Desgin Group Restructuring like 54
			  AOM_ask_value_string(PartTag,"t5_DesignGrp",&DesignGrp13);
              printf("\n t5_dfq_document_creation ::  Design Group = %s ",DesignGrp13);
			  subGroup = subString(partNumber,8,4);
			  tc_strcpy(moduleAddressS,"");
			  tc_strcat(moduleAddressS,subGroup);
              printf("\n tm_DVA_Creation After cat Design Group %s\n",moduleAddressS);fflush(stdout); 
	  } 
	  else
	 {
	  ITK_CALL(AOM_ask_value_string(PartTag,"bl_Design Revision_t5_DesignGrp",&Designgroupvalue));
	  printf("\n GCI create Design Group  :: %s\n",Designgroupvalue);fflush(stdout);

	  tc_strcpy(moduleAddressS,"");
	  tc_strcat(moduleAddressS,Designgroupvalue);
	  printf("\n GCI Create After cat Design Group %s\n",moduleAddressS);fflush(stdout);
	 }
	}

	queryTag = NULLTAG;
	status = QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	else
	{
      printf("Tag found query\n");fflush(stdout);
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	//qry_values1[1] = (char *)MEM_alloc(10);
	//tc_strcpy(qry_values1[1], "DFQ Use Case");

    qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	//qry_entries[1] = (char *)MEM_alloc(10);
	//strcpy(qry_entries[1], "Type");
	//strcpy(qry_entries[1], "object_type");



   printf("Name is  :: %s\n",qry_values1[0]);fflush(stdout);
  // printf("Type is  :: %s\n",qry_values1[1]);fflush(stdout);


	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}

void SendVCdetailsForDVLO( tag_t DitemRevTAG, tag_t DVLONewDataset,FILE** file,char**Csvpath)
{

     tag_t bom_wnd				=NULLTAG;
     tag_t rule					=NULLTAG;
     tag_t top_lne				=NULLTAG;
     tag_t	*ColIndChilds		=NULLTAG;
     tag_t	*dfq_use_case_tags	=NULLTAG;
     tag_t	*DVA_document_tag	=NULLTAG;
     tag_t	*refobjpdfs			=NULLTAG;
     tag_t	*refobjexcels		=NULLTAG;
     //tag_t	*GCIobj				=NULLTAG;
	 tag_t	Childobject			=NULLTAG;
	 tag_t	itemoduleTag		=NULLTAG;
	 tag_t	itemoduleTagLat		=NULLTAG;
	 tag_t	relTypeTags			=NULLTAG;
	 //tag_t	MSexcelDatatyp		=NULLTAG;

     char*VcNumber			=NULL;
     char*DFQdocnosDup		=NULL;
     char*DFQdocnos			=NULL;
     char*DFQUIDsDup		=NULL;
     char*DFQUIDs			=NULL;
     char*DVADescsDup		=NULL;
     char*DVADescs			=NULL;
	 char*VCtypeNam			=NULL;

	 char*PartRelStats		=NULL;
	 char*ProjbussDup		=NULL;
	 char*PartNumsDup		=NULL;
	 char*PartNums			=NULL;
	 char*PartNumstypDup	=NULL;
	 char*PartNumstyp		=NULL;
	 char*Meetexpectation	=NULL;
	 char*MeetexpectationDup=NULL;

	 int i=0;
	 int count=0;
	 int ichld=0;
	 int resultCount=0;
	 int DVA_result_counts=0;
	 int nFoundpdfs=0;
	 int nFoundexcels=0;
	 //int GCIcount=0;
	 logical DFQApplicablilitycheck1= 0;

	 char	Data[100]= "";
     time_t 	now;
	 struct 	tm when;

	 char *VPrtModNum=NULL;
	 char *VPrtModNumType=NULL;
	 char *CurRe=NULL;
	 char *CurSe=NULL;
	 char *VPrtdesc=NULL;
	 char *prjcode=NULL;
	 char *prjcodeDup=NULL;
	 char *partsts=NULL;
	 char *partstsDup=NULL;
	 char *ProjdescDup = NULL;
	 //FILE* file=NULL;
	 char fsuccess_nam[200];
	 char *Owner	= NULL;
	 Owner = (char *)MEM_alloc(50);
	 char *PartRevs=NULL;
	 char *PartRevsDup=NULL;
	 char *CurRevs = NULL;
	 char *CurSeqs = NULL;
	 char *ModuleAddressp=NULL;
	 char *ModuleAddresspDup=NULL;
	 char *designgroup=NULL;
	 ModuleAddresspDup	=	(char*)MEM_alloc(100);
	 char *partst=NULL;
	 char *partstDup=NULL;
	 char *descp=NULL;
	 char *descpDup=NULL;
	 //char *Csvpath=NULL;
	 char *GCIDocPath=NULL;
	 GCIDocPath = (char *)MEM_alloc(200);
	 //Csvpath = (char *)MEM_alloc(200);
	 char* Owners	= NULL;
	 Owners = (char *)MEM_alloc(50);
	  double Designnominal;
	 double Definedtarget;
	 double Achievednominal;
	 double Achievedtarget;
	 double CpkDup;
	  date_t Lastmoddate;
	 char* LastmoddateDup		= NULL;
	 
	 int d=0;
	 char* PrerevDRstat	 = NULL;
	 PrerevDRstat	=	(char	*)MEM_alloc(10);
	 char* DFQComments = NULL;
	 char* DFQCommentsDup	= NULL;
	 char* MeetexpectationDupMM	=NULL;
	 char* Foundpdfs		= NULL;
	 char* Foundexcels	= NULL;
	 char* DFQApplicablilitysDup=NULL;
	 //AE_reference_type_t MSrefType=1;
	 //tag_t file_tag1 = NULLTAG;
	 //IMF_file_t file_descriptor1;
	 //int j=0;
	 PIE_scope_t scope;
	 scope=PIE_TEAMCENTER;
	int rulefound= 0;
	tag_t *closurerule = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t bom_variant_rule = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char* type_name =NULL;
	tag_t e_block		= NULLTAG;
	char **rulename = NULL;
	char **rulevalue = NULL;

	 time(&now);
	 when = *localtime(&now);
     strftime(Data,100,"%Y_%b_%d_%H_%M_%S",&when);


				AOM_ask_value_string(DitemRevTAG,"item_id",&VcNumber);
				printf("Item ID* :: %s\n",VcNumber);fflush(stdout);

				AOM_ask_value_string(DitemRevTAG,"t5_PartType",&VCtypeNam);
				printf("Item ID type* :: %s\n",VCtypeNam);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_id",&VPrtModNum));

	            ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_revision_id",&VPrtModNumType));
				printf("\nV number is [%s]\n",VPrtModNum); fflush(stdout);

				CurRe = strtok(VPrtModNumType,";");
				CurSe = strtok(NULL,";");

				ITK_CALL(AOM_ask_value_string(DitemRevTAG,"object_desc",&VPrtdesc));

				ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_ProjectCode",&prjcode));
				tc_strdup(prjcode,&prjcodeDup);
				
				ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_PartStatus",&partsts));
				tc_strdup(partsts,&partstsDup);

				ITK_CALL(getBusinessUnitFunc(DitemRevTAG, &ProjbussDup,&ProjdescDup));
				printf("\n t5_BussUnitType :[%s] [%s]\n",ProjbussDup,ProjdescDup);   fflush(stdout);

				ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path",0,&GCIDocPath));
				printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);

			   if(tc_strcmp(VCtypeNam,"V")== 0 || tc_strcmp(VCtypeNam,"VCCR")== 0)  
			   {

               /* tc_strcpy(Csvpath,"");
                tc_strcpy(Csvpath,GCIDocPath);
                sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
				tc_strcat(Csvpath,fsuccess_nam);
                printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);
				file = fopen(Csvpath,"w");*/

				if(*file!=NULL)
			    {
				printf("\n file is opening\n");   fflush(stdout);	
			    }
			    else
			    {
				   printf("\n file is not opening\n");   fflush(stdout);	
			    }

				/*fprintf(file,",,,,DVA MIS Report VC Wise,,date-%s,,,,,,\n",Data);
				fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
				fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
				fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
				fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
				fprintf(file,",,,Last Updated,,,,,,,\n");
				fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
				fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
				fprintf(file,"\n\n");*/

				//fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DVA UID,DVA Use case Description,Applicability,DVA Justification Comment,DVA Documents Number,PDF,Xlsx,DVA Meet the Expectations (Yes/No)\n");
				  fprintf(*file,"Part_Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DVA UID,Last Update,Applicability,DVA Justification Comment,DVA Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");
                
			   	          if(DitemRevTAG!=NULLTAG)
				          {
						                    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL( BOM_set_window_top_line( bom_wnd, NULLTAG, DitemRevTAG, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

											/*ITK_CALL ( BOM_window_ask_variant_rule( bom_wnd, &bom_variant_rule ));     /// API NOT IN USE
					                        printf( " vc_release BOM_window_ask_variant_rule..\n");fflush(stdout);
											

											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
					                        ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));*/
											

											ITK_CALL ( ITEM_ask_rev_variants ( DitemRevTAG, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											
                                      if(top_lne!=NULLTAG)
					                  {

                                        ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
									  

									    ITK_CALL(BOM_window_hide_unconfigured(bom_wnd));
						                ITK_CALL(BOM_window_show_variants(bom_wnd));

									    printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&DitemRevTAG))   ;
						                printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
									   

                                        ITK_CALL(BOM_window_hide_variants(bom_wnd));

						                ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
									  

						               printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);

						    if(count >0)
						    {

						    for (ichld=0;ichld<count ;ichld++ )
						    {

							if(Childobject)Childobject=NULLTAG;
							Childobject=ColIndChilds[ichld];

                            ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
							tc_strdup(PartNums,&PartNumsDup);
							printf("\nPart number is [%s]",PartNumsDup); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
							tc_strdup(PartNumstyp,&PartNumstypDup);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
							tc_strdup(PartRevs,&PartRevsDup);
							printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

							 CurRevs = strtok(PartRevsDup,";");
							 CurSeqs = strtok(NULL,";");
							 if(tc_strcmp(PartNumstyp,"M")==0)
							 {

								 ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
								 printf("\nPart number revision [%s]",ModuleAddressp); fflush(stdout);

							     tc_strcpy(ModuleAddresspDup,"");
							     tc_strcat(ModuleAddresspDup,ModuleAddressp);
								 printf("\n After cat Module adderess [%s]",ModuleAddresspDup); fflush(stdout);

							  
							 
							 }

							 if(tc_strcmp(PartNumstyp,"T")==0)
							 {
							     

							   ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_DesignGrp",&designgroup));
							    printf("\n Before cat Module DesignGrp [%s]",designgroup); fflush(stdout);
							  
							   tc_strcpy(ModuleAddresspDup,"");
							   tc_strcat(ModuleAddresspDup,designgroup);
							   printf("\n After cat Module designgroup [%s]",ModuleAddresspDup); fflush(stdout);
							 
							 }


							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
							tc_strdup(partst,&partstDup);

							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
							tc_strdup(descp,&descpDup);
							STRNG_replace_str(descpDup,","," ",&descpDup);


							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                            printf("\nPart release is [%s]",PartRelStats); fflush(stdout);


							if(tc_strstr(PartRelStats,"ERC Released")!=NULL)
							{
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							}

								if(tc_strcmp(PartNumstyp,"M")==0 || tc_strcmp(PartNumstyp,"T")==0)
							    {

								 tag_t itemRevTagm1 = NULLTAG;

								ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));            //getting business unit according to project code
								printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

								ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));//check no. of use cases for BUS unit
								printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

								ITEM_find_item(PartNums, &itemoduleTag);
								printf("\n checking : [%s]\n",PartRevs);fflush(stdout);
								ITEM_find_revision(itemoduleTag,PartRevs,&itemRevTagm1);


								//ITEM_ask_latest_rev(itemoduleTag,&itemoduleTagLat);
								GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

								//Get Attached DFQ Documents
								ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm1, relTypeTags, &DVA_result_counts,&DVA_document_tag));
								printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

								    int trueflagg=0;
									int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(*file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);


								if (DVA_result_counts >0)
								{
									for (i=0;i<DVA_result_counts; i++ )
									{
										AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

										printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

										AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
										tc_strdup(DFQdocnos,&DFQdocnosDup);

										AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
										tc_strdup(DFQUIDs,&DFQUIDsDup);

										ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
										tc_strdup(DVADescs,&DVADescsDup);

										STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										tc_strdup(DFQComments,&DFQCommentsDup);

										STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);


										if(DFQApplicablilitycheck1 == 1)
										{
											DFQApplCntflag++;
											tc_strdup("Yes",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}
										else
										{
											falseflagg++;
											tc_strdup("No",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}

										ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));          //Code Change
										printf("\n\n The nFoundpdfs222 is :%d\n",nFoundpdfs);fflush(stdout);
										ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));    //Code Change
										printf("\n\n The nFoundexcels2222 is :%d\n",nFoundexcels);fflush(stdout);
										ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQDesNom",&Designnominal));
										ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DNDefTarget",&Definedtarget));
										ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQAchNom",&Achievednominal));
										ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_ANDefTarget",&Achievedtarget));
										ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQCpkVal",&CpkDup));


										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										tc_strdup(Meetexpectation,&MeetexpectationDup);
										printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

										if(tc_strcmp(MeetexpectationDup,"N")==0)
										{
                                               tc_strdup("No",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"Y")==0)
										{
                                               tc_strdup("Yes",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"NA")==0)
										{
                                               tc_strdup("NA",&MeetexpectationDupMM);
										}


                                        if(DFQApplicablilitycheck1 == 1)
										{
										if(nFoundpdfs >= 1)
										{
											DFQpdfCount++;

										if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
											{
                                                MeetexpectationCnt++;
											}

										}
										}
										if(nFoundexcels == 1)
										{
											DFQexcelsCount++;
										}

										if (nFoundpdfs == 0)
										{
											tc_strdup("No",&Foundpdfs);
										}else{
											tc_strdup("Yes",&Foundpdfs);
										}

										if (nFoundexcels == 0)
										{
											tc_strdup("No",&Foundexcels);
										}else{
											tc_strdup("Yes",&Foundexcels);
										}

										ITK_CALL(AOM_ask_value_date(DVA_document_tag[i],"last_mod_date",&Lastmoddate));
										ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

										printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
										//fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);
                                          fprintf(*file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,LastmoddateDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMM,DVADescsDup);

									}
								}

								}

						   }

						 }
					   }
				  }
				 
            }
             else if(tc_strcmp(VCtypeNam, "CCVC")==0)
	        {

             tag_t	*snapshotObjSet		=NULLTAG;
			 tag_t Snapshot_tag			=NULLTAG;
			 tag_t snapshotObjTypeTag	=NULLTAG;
			 tag_t item_rev_tags		=NULLTAG;
			 tag_t window				=NULLTAG;
			 tag_t top_line				=NULLTAG;
			 tag_t Childobject1			=NULLTAG;
			 tag_t ChildMobject			=NULLTAG;
			 tag_t close_tag			=NULLTAG;
	         tag_t	*closurerule		=NULLTAG;
			 tag_t	*ColIndChilds		=NULLTAG;
			 tag_t	*Modulechilds		=NULLTAG;

			 //char*snapshotObjtype_name	=NULL;
			 //char  snapshotObjtype_name[TCTYPE_name_size_c+1];
			 char*  snapshotObjtype_name =NULL;
             char*ObjName				=NULL;
	         char**rulename				=NULL;
	         char**rulevalue			=NULL;
			 char*PartNums1Dup			=NULL;
			 char*PartNums1				=NULL;
			 
			  
             char*Item_ID_str			=NULL;
             char*ModuleNameDup			=NULL;
             char*ModuleName			=NULL;
             char*ModuleNumstyp			=NULL;
			 char*ModuleNumstypDup		=NULL;
			 char*ModulePartRevsDup		=NULL;
			 char*ModulePartRevs		=NULL;
			 char*ModuleAddressp1				=NULL;
			 char*designgroup1		=NULL;
			 char*ModulePartRelStats	=NULL;
			 char*SSTopLineRev			=NULL;
			 date_t Lastmoddate;
	         char* LastmoddateDup		= NULL;
			 double Designnominal;
			 double Definedtarget;
			 double Achievednominal;
			 double Achievedtarget;
			 double CpkDup;

			 PIE_scope_t scope;
			 scope=PIE_TEAMCENTER;

             int count1=0;
             int chld=0;
			 int snapshotCount=0;
			 int Item_ID=0;
			 int rulefound	=	0;
              //printf("inside the CCVC start**\n");fflush(stdout);
			 /*tc_strcpy(Csvpath,"");
             tc_strcpy(Csvpath,GCIDocPath);
			 sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
			 tc_strcat(Csvpath,fsuccess_nam);
			 file = fopen(Csvpath,"w");
			    
			 fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
			 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
			 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
			 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
			 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
			 fprintf(file,",,,Last Updated,,,,,,,\n");
			 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
			 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
			 fprintf(file,"\n\n");*/
			    
			// fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Meet the Expectations (Yes/No)\n");
               fprintf(*file,"Part_Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DVA UID,Last Update,Applicability,DVA Justification Comment,DVA Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");
             //printf("inside the CCVC**\n");fflush(stdout);
		    ITK_CALL(AOM_ask_value_tags(DitemRevTAG,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
			printf("\n WTRoll::snapshotCount \n::  %d ", snapshotCount);fflush(stdout);

				if(snapshotCount>0)
				   {
					printf("inside the snapshotCount**\n");fflush(stdout);
					 Snapshot_tag = NULLTAG;
					 snapshotObjTypeTag = NULLTAG;
					 Snapshot_tag = snapshotObjSet[0];
                     //printf(" the snapshotCount**\n");fflush(stdout);
					 ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
					 ITK_CALL(TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
					 printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);

					 ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
					 printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);

					 //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			        // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                      //printf(" the snapshotCount topline**\n");fflush(stdout);
					 ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
					 ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                     printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);

                      // printf(" the snapshotCount topline1**\n");fflush(stdout);
                     ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
					 ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_set_window_pack_all (window, FALSE));
                     //printf("after top line**\n");fflush(stdout);
					
					

					ITK_CALL(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
					 printf ("\nrule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
						close_tag = closurerule[0];
						//printf ("closure rule found \n"); fflush(stdout);
					 }
					 ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
					 printf ("closure rule found applied \n"); fflush(stdout);
					// ITKCALL(BOM_set_window_pack_all (window, FALSE));
					 //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

					/* ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));              ///API NOT IN USE
					 ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));      //// API NOT IN USE
					 printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);*/
					 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
					 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

					 if (count >0)
					 {
					  for (ichld=0;ichld<count ;ichld++ )
					   {
							if(Childobject1) Childobject1=NULLTAG;
							Childobject1=ColIndChilds[ichld];

							ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
							tc_strdup(PartNums1,&PartNums1Dup);
							printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);


							ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
							printf("\n module line count is***: [%d]", count1);fflush(stdout);

							if (count1 >0)
							{
							 printf("\n module line****************** count is****\n");fflush(stdout);

								for (chld=0;chld<count1 ;chld++ )
								{
									if(ChildMobject) ChildMobject=NULLTAG;
									ChildMobject=Modulechilds[chld];
									int resultCount1=0;

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									
									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
									printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									 CurRevs = strtok(ModulePartRevsDup,";");
									 CurSeqs = strtok(NULL,";");
									  if(tc_strcmp(ModuleNumstyp,"M")==0)
									 {

										 ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp1));
										 printf("\n CCVC Part number revision [%s]",ModuleAddressp1); fflush(stdout);

										 tc_strcpy(ModuleAddresspDup,"");
										 tc_strcat(ModuleAddresspDup,ModuleAddressp1);
										 printf("\n CCVC After cat Module adderess [%s]",ModuleAddresspDup); fflush(stdout);

									  
									 
									 }
									 if(tc_strcmp(ModuleNumstyp,"T")==0)
									 {
										 

									   ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_DesignGrp",&designgroup1));
										printf("\n CCVC Before cat Module DesignGrp [%s]",designgroup1); fflush(stdout);
									  
									   tc_strcpy(ModuleAddresspDup,"");
									   tc_strcat(ModuleAddresspDup,designgroup1);
									   printf("\n CCVC After cat Module designgroup [%s]",ModuleAddresspDup); fflush(stdout);
									 
									 }


									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									if(tc_strstr(ModulePartRelStats,"ERC Released")!=NULL)
							        {
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							        }

									if(tc_strcmp(ModuleNumstypDup,"M")==0 || tc_strcmp(ModuleNumstypDup,"T")==0)
									{
										  tag_t itemTagm	= NULLTAG;
										  tag_t itemRevTagm = NULLTAG;

										  ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										  printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);fflush(stdout);
										     
										  ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										  printf("\n No of Use cases Mapped :[%d]\n",resultCount1);fflush(stdout);
										     
										  //Get DFQ Document Relation Class Type
										  
										  ITEM_find_item(ModuleName, &itemTagm);
										  //ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										  printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);fflush(stdout);
										  ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										     
										  GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
										     
										  //Get Attached DFQ Documents
										  ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										  printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflagg=0;
									      int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(*file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount1,falseflagg,trueflagg);


										  if (DVA_result_counts >0)
										  {
											  for (i=0;i<DVA_result_counts; i++ )
											  {
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
												tc_strdup(DVADescs,&DVADescsDup);

												STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										        tc_strdup(DFQComments,&DFQCommentsDup);

										        STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										        STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												if(DFQApplicablilitycheck1 == 1)
												{
													DFQApplCntflag++;
													tc_strdup("Yes",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													falseflagg++;
													tc_strdup("No",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);

												}

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));       //Code Change
												printf("\n\n The nFoundpdfs is :%d\n",nFoundpdfs);fflush(stdout);
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels)); //Code Change
												printf("\n\n The nFoundexcels is :%d\n",nFoundexcels);fflush(stdout);
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[i],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										        tc_strdup(Meetexpectation,&MeetexpectationDup);
										        printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);
										        
										        if(tc_strcmp(MeetexpectationDup,"N")==0)
										        {
                                                       tc_strdup("No",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"Y")==0)
										        {
                                                       tc_strdup("Yes",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"NA")==0)
										        {
                                                       tc_strdup("NA",&MeetexpectationDupMM);
										        }

												if(DFQApplicablilitycheck1 == 1)
												{
												if(nFoundpdfs >= 1)
												{
													DFQpdfCount++;

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
												{
													MeetexpectationCnt++;
												}

												}
												}
												if(nFoundexcels == 1)
												{
													DFQexcelsCount++;
												}

												if (nFoundpdfs == 0)
										        {
											     tc_strdup("No",&Foundpdfs);
										        }else{
											       tc_strdup("Yes",&Foundpdfs);
										        }

										       if (nFoundexcels == 0)
										      {
												tc_strdup("No",&Foundexcels);
										      }
											  else
											  {
												tc_strdup("Yes",&Foundexcels);
										      }

											  ITK_CALL(AOM_ask_value_date(DVA_document_tag[i],"last_mod_date",&Lastmoddate));
										      ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
												//fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);
                                                fprintf(*file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,LastmoddateDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMM,DVADescsDup);
												}
											}

									}
								}


							}

						}

					}

					}

			 }
			 else
	        {
                printf("\n this is not V/CCVC part \n");fflush(stdout);

	        }
			 fclose(*file);

         /* if(Csvpath)
	      {
           
		   char*reference_nameGCI=NULL;
		   tag_t file_tag = NULLTAG;
	       IMF_file_t file_descriptor;
	       AE_reference_type_t tagRefTypeText = 1;

		     reference_nameGCI = (char *) MEM_alloc(10);

             printf("\n before named reference GCI %s",Csvpath); fflush(stdout);
		     tc_strcpy(reference_nameGCI,"T5_GCIDocRef");
			 printf("\n named reference GCI %s",reference_nameGCI); fflush(stdout);


            ITK_CALL(AOM_refresh(DVLONewDataset,TRUE));

            ITK_CALL(IMF_import_file(Csvpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
			ITK_CALL(AOM_save_with_extensions(file_tag));
			
	        ITK_CALL(AE_add_dataset_named_ref2(DVLONewDataset,reference_nameGCI,tagRefTypeText,file_tag));
	        printf("\n after named reference GCI \n"); fflush(stdout);
			 
            ITK_CALL(AOM_save_with_extensions(DVLONewDataset));
	         //ITK_CALL(AOM_unload(file_tag));
			 ITK_CALL(AOM_refresh(DVLONewDataset,0));

             printf("\n Done named reference GCI \n"); fflush(stdout);
			
		  }*/


}
void create_GCI_document( tag_t DitemRevTAG, char*Pointer_10_Val ,char*Pointer_40_Val,char*Pointer_100_Val,char*Pointer_20_Val,char*Pointer_1_Val ,char* DvloName, char* VCPartRev,  char* VCDML, char* DItemIdLat)
{


	tag_t DVLOdatasettype	=NULLTAG;
	tag_t DVLONewDataset	=NULLTAG;
	tag_t DVLORelatn_type	=NULLTAG;
	tag_t DVLORelation		=NULLTAG;
	tag_t Vechtag		=NULLTAG;

	char*	strDVA		=NULL;
	char*	prjcodeDup		=NULL;
	char*	ProjdescDup		=NULL;
	char*	ProjbussDup		=NULL;
	char*	strDSR		=NULL;
	char*	DVLODsetID	=NULL;
	char*	GCIStr		=NULL;
	char*	Csvpath		=NULL;
	char*	fsuccess_nam		=NULL;
	char*	partstsDup		=NULL;
	char*	partsts		=NULL;
	char*	PartRelStat		=NULL;
	char*	VPrtdesc		=NULL;
	char*	GCIDocPath		=NULL;
	
	date_t Creationdateout;
	char*	Creationdate		=NULL;
	char *VPrtModNum=NULL;
	char *VPrtModNumType=NULL;
	FILE* file=NULL;
	FILE* file1=NULL;
	char *Owner=NULL;
	char*Projname=NULL;
	 char	Data[100]= "";
	
	char *CurRe=NULL;
	 char *CurSe=NULL;
	Csvpath = (char *)MEM_alloc(200);
	fsuccess_nam = (char *)MEM_alloc(200);
	CurRe = (char *)MEM_alloc(100);
	CurSe = (char *)MEM_alloc(100);
	Owner = (char *)MEM_alloc(100);

	int DemeritScore=0;
	int dsr=0;

	double GCI;
	double dVA;
	double dSR;
	double Strdsr;
	struct 	tm when;
	time_t 	now;
	time(&now);
	 when = *localtime(&now);
     strftime(Data,100,"%Y_%b_%d_%H_%M_%S",&when);

	//cal
	//char*DvloName=NULL;
	//char*DScore=NULL;

	GCIStr= (char *) MEM_alloc(sizeof(char)* 10);
	DVLODsetID=(char *)MEM_alloc(sizeof(char)* 100);

	tc_strcpy(DVLODsetID,DvloName);

	ITK_CALL(AE_find_datasettype2("T5_GCI_Document", &DVLOdatasettype));

	printf("\n before creation of DVLO obj \n");fflush(stdout);

	ITK_CALL(AE_create_dataset_with_id(DVLOdatasettype,DVLODsetID,"Dataset Creation Tool",DVLODsetID,"",&DVLONewDataset));

	ITK_CALL(AOM_lock(DVLONewDataset));

	printf("\n after creation of DVLO obj \n");fflush(stdout);

	ITK_CALL(AOM_set_value_string(DVLONewDataset,"object_name",DvloName));
	ITK_CALL(AOM_set_value_string(DVLONewDataset,"t5_DVLO_Name1",DvloName));
	ITK_CALL(AOM_set_value_string(DVLONewDataset,"t5_DVLODmlNo1",VCDML));
	ITK_CALL(AOM_set_value_string(DVLONewDataset,"t5_vehicle1",DItemIdLat));
	ITK_CALL(AOM_set_value_string(DVLONewDataset,"t5_vehicle_revision1",VCPartRev));
	ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_Pointer_10",Pointer_10_Val));
	ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_Pointer_40",Pointer_40_Val));
	ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_Pointer_100",Pointer_100_Val));
	ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_pointer_20",Pointer_20_Val));
	ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_pointer_1",Pointer_1_Val));

	printf("\n setting value on DVLO Done \n");fflush(stdout);

    ITK_CALL(AOM_save_with_extensions(DVLONewDataset));

	ITK_CALL(AOM_refresh(DVLONewDataset,0));

    printf("\n creating relation btwn DVLO and design rev \n"); fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&DVLORelatn_type));
	ITK_CALL(GRM_create_relation(DitemRevTAG,DVLONewDataset,DVLORelatn_type,NULLTAG,&DVLORelation));
	printf("\n after creating relation between DVLO and design rev \n"); fflush(stdout);
	ITK_CALL(GRM_save_relation(DVLORelation));

	ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_id",&VPrtModNum));
	ITK_CALL(AOM_ask_value_string(DitemRevTAG,"item_revision_id",&VPrtModNumType));
	ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_PartStatus",&partsts));
	ITK_CALL(AOM_UIF_ask_value(DitemRevTAG,"release_status_list",&PartRelStat));
	ITK_CALL(AOM_ask_value_string(DitemRevTAG,"object_desc",&VPrtdesc));
	ITK_CALL(AOM_ask_value_string(DitemRevTAG,"t5_ProjectCode",&prjcodeDup));
	   printf("\n Design Revision release status is [%s]\n",PartRelStat);   fflush(stdout);
     printf("\nV number is [%s]\n",VPrtModNum); fflush(stdout);
	 CurRe = strtok(VPrtModNumType,";");
	 CurSe = strtok(NULL,";");
	  ITEM_find_item(VPrtModNum,&Vechtag);
	  if(Vechtag != NULLTAG)
	  {
	  
	   printf("\n Inside item Tag found\n"); fflush(stdout);
	  
	  }
	   ITK_CALL(AOM_ask_value_date(Vechtag,"creation_date",&Creationdateout));
	  ITK_CALL(DATE_date_to_string(Creationdateout,"%d/%m/%Y",&Creationdate));
	   printf("\n Design Revision Creation Date [%s]\n",Creationdate);   fflush(stdout);

	  if(tc_strstr(PartRelStat,"ERC Released")==NULL)
	   {

	   	printf("\n Inside the WIP vault condition\n"); fflush(stdout);
	   	tc_strcpy(Owner,"WIP Vault");

	   }
	   else
	   {

	   	printf("\n Inside the Release vault condition\n"); fflush(stdout);
	   	tc_strcpy(Owner,"Release Vault");

	   }
	 tc_strdup(partsts,&partstsDup);

     //ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path_uaprodtrl",0,&GCIDocPath));
	 //printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);
	 ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path",0,&GCIDocPath));
	 printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);

	 //ITK_CALL(getBusinessUnitFunc(DitemRevTAG, &ProjbussDup));
	 ITK_CALL(getBusinessUnitFunct222(DitemRevTAG, &ProjbussDup));
	 ITK_CALL(getBusinessUnitFun(DitemRevTAG, &ProjdescDup,&Projname));
	  printf("\n t5_BussUnitType :111111[%s]\n",ProjbussDup);   fflush(stdout);

	tc_strcpy(Csvpath,"");
    tc_strcpy(Csvpath,GCIDocPath);
   // sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
	sprintf(fsuccess_nam,"MIS_DVA_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
    tc_strcat(Csvpath,fsuccess_nam);
    printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);


	file = fopen(Csvpath,"w");
	if(file!=NULL)
	{
	printf("\n file is opening\n");   fflush(stdout);	
	}
	else
	{
	   printf("\n file is not opening\n");   fflush(stdout);	
	}
	 //file = NULL;

     //fseek(file, 2, SEEK_SET);

	 fprintf(file,",,,,DVA MIS Report VC Wise,,date-%s,,,,,,\n",Data);
	 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
	 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
	 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
	 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
	 fprintf(file,",,,Last Updated,,,,,,,\n");
	 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
	 // fprintf(file1,",,,Project Description,%s,,,,,,\n",ProjdescDup);
	 fprintf(file,",,,Demerit Score(V),%d,,,,\n",DemeritScore);
	 fprintf(file,",,,Demerit Score Rating(S),%d,,,\n",dsr);
	 fprintf(file,",,,Geometry conformance Index(A),%lf,,\n\n\n",GCI);

	  SendVCdetailsForDVLO(DitemRevTAG,DVLONewDataset,&file,&Csvpath);

	//SendVCdetailsForDVLO(DitemRevTAG,DVLONewDataset);    //calling for VC expand

	printf("\n\n DFQApplCntflag: [%d]  DFQpdfCount: [%d]  MeetexpectationCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);
	//tc_strdup(DVACalulate(),&strDVA);
	strDVA=DVACalulate();
	printf("\n strDVA= [%s] \n", strDVA);fflush(stdout);

	if(DVLONewDataset != NULLTAG)
	{

			DemeritScore=((100*atoi(Pointer_100_Val)) + (40*atoi(Pointer_40_Val)) + (10*atoi(Pointer_10_Val)) + (20*atoi(Pointer_20_Val)) + (1*atoi(Pointer_1_Val)));
			printf("\n Total DemeritScore: %d \n",DemeritScore);fflush(stdout);

		  //tc_strdup(GetDemeritScoreRating(DvloName,DemeritScore),&strDSR);
			printf("calling GetDemeritScoreRating fun");fflush(stdout);
			strDSR=GetDemeritScoreRating(DvloName,DemeritScore);
			printf("  strDSR= [%s] ", strDSR);fflush(stdout);

		    if (strDVA!=NULL && strDSR!=NULL)
		    {

			 dVA=strtod(strDVA,NULL);
			 dSR=strtod(strDSR,NULL);
		    
			 printf("\n dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);

			 GCI=((0.5*dSR) + (0.5*dVA));
		    
			 printf("\n  GCI-after calculation: %lf",GCI);fflush(stdout);
		    
			 sprintf(GCIStr,"%10lf",GCI);
			 printf("\n  after conversion  to GCIStr: %s \n",GCIStr);fflush(stdout);
		    
		    }

			if(DFQApplCntflag!=0)
			{
				dsr=atoi(strDSR);
				//ITK_CALL(AOM_lock(DVLONewDataset));
				ITK_CALL(AOM_refresh(DVLONewDataset,1));
					
				printf("\n before setting value GCI, strDSR, strDVA= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
					
				ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_DVA_value_d1",strDVA));						//double not supported		DVA value(D)
				ITK_CALL(AOM_set_value_int(DVLONewDataset,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
				ITK_CALL(AOM_set_value_double(DVLONewDataset,"t5_geometry_conf_index_a1",GCI));		//double not supported		Geometry conformance Index(A)
				ITK_CALL(AOM_set_value_int(DVLONewDataset,"t5_demerit_score_v1",DemeritScore));			//int						DMU Demerit score(V)
					
				ITK_CALL(AOM_save_with_extensions(DVLONewDataset));
				printf("\n after saving GCI\n");fflush(stdout);
				ITK_CALL(AOM_refresh(DVLONewDataset,0));
			
			}
			else
			{
				dsr=atoi(strDSR);
				//ITK_CALL(AOM_lock(DVLONewDataset));  //check out dataset ---> ITK_CALL(AOM_refresh(DVLONewDataset,1));
				ITK_CALL(AOM_refresh(DVLONewDataset,1));
					
				printf("\n before setting value GCI, strDSR, strDVA1= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
					
				ITK_CALL(AOM_UIF_set_value(DVLONewDataset,"t5_DVA_value_d1",strDVA));					//double not supported		DVA value(D)
				ITK_CALL(AOM_set_value_int(DVLONewDataset,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
					
				Strdsr=(double)dsr;
					
				printf("\n  GCI setting after type cast: %lf",Strdsr);fflush(stdout);
				ITK_CALL(AOM_set_value_double(DVLONewDataset,"t5_geometry_conf_index_a1",Strdsr));	//double not supported		Geometry conformance Index(A)
				ITK_CALL(AOM_set_value_int(DVLONewDataset,"t5_demerit_score_v1",DemeritScore));		//int						DMU Demerit score(V)
					
				ITK_CALL(AOM_save_with_extensions(DVLONewDataset));
				printf("\n after saving GCI*****\n");fflush(stdout);
				ITK_CALL(AOM_refresh(DVLONewDataset,0));												//checkin dataset
			
			}

	}
	file = fopen(Csvpath,"r+");
	 //file = NULL;

     //fseek(file, 2, SEEK_SET);

	 fprintf(file,",,,,DVA MIS Report VC Wise,,date-%s,,,,,,\n",Data);
	 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
	 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
	 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
	 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
	 fprintf(file,",,,Last Updated,,,,,,,\n");
	 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
	// fprintf(file1,",,,Project Description,%s,,,,,,\n",ProjdescDup);
	 fprintf(file,",,,Demerit Score(V),%d,\n",DemeritScore);
	 fprintf(file,",,,Demerit Score Rating(S),%d\n",dsr);
	 fprintf(file,",,,Geometry conformance Index(A),%lf\n",GCI);

	 fclose(file);

	      /*if(Csvpath)
	      {
           
		   char*reference_nameGCI=NULL;
		   tag_t file_tag = NULLTAG;
	       IMF_file_t file_descriptor;
	       AE_reference_type_t tagRefTypeText = 1;

		     reference_nameGCI = (char *) MEM_alloc(10);

             printf("\n before named reference GCI %s",Csvpath); fflush(stdout);
		     tc_strcpy(reference_nameGCI,"T5_GCIDocRef");
			 printf("\n named reference GCI %s",reference_nameGCI); fflush(stdout);


            ITK_CALL(AOM_refresh(DVLONewDataset,TRUE));

            ITK_CALL(IMF_import_file(Csvpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
			ITK_CALL(AOM_save_with_extensions(file_tag));
			
	        ITK_CALL(AE_add_dataset_named_ref2(DVLONewDataset,reference_nameGCI,tagRefTypeText,file_tag));
	        printf("\n after named reference GCI \n"); fflush(stdout);
			 
            ITK_CALL(AOM_save_with_extensions(DVLONewDataset));
			ITK_CALL(AOM_load(DVLONewDataset));	
	         //ITK_CALL(AOM_unload(file_tag));
			 ITK_CALL(AOM_refresh(DVLONewDataset,0));

             printf("\n Done named reference GCI \n"); fflush(stdout);
			
		  }*/
		  
          if(Csvpath)
	      {
           
		   char*reference_nameGCI=NULL;
		   tag_t file_tag = NULLTAG;
	       IMF_file_t file_descriptor;
	       AE_reference_type_t tagRefTypeText = 1;

		     reference_nameGCI = (char *) MEM_alloc(10);

             printf("\n before named reference GCI %s",Csvpath); fflush(stdout);
		     tc_strcpy(reference_nameGCI,"T5_GCIDocRef");
			 printf("\n named reference GCI %s",reference_nameGCI); fflush(stdout);


            ITK_CALL(AOM_refresh(DVLONewDataset,TRUE));

            ITK_CALL(IMF_import_file(Csvpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
			ITK_CALL(AOM_save_with_extensions(file_tag));
			
	        ITK_CALL(AE_add_dataset_named_ref2(DVLONewDataset,reference_nameGCI,tagRefTypeText,file_tag));
	        printf("\n after named reference GCI \n"); fflush(stdout);
			 
            ITK_CALL(AOM_save_with_extensions(DVLONewDataset));
	         //ITK_CALL(AOM_unload(file_tag));
			 ITK_CALL(AOM_refresh(DVLONewDataset,0));

             printf("\n Done named reference GCI \n"); fflush(stdout);
			
		  }

}

int t5_DVLO_document_creation(tag_t Revtag)
{

    tag_t DitemTAG			 = NULLTAG;
	tag_t DitemRevTAG		 = NULLTAG;
	tag_t VCDML_tag			 = NULLTAG;
	tag_t VCDMLRevTag		 = NULLTAG;
	tag_t VCDMLobjTypTag	 = NULLTAG;
	tag_t DVLORel			 = NULLTAG;
	tag_t  cmRefTag			 = NULLTAG;
	tag_t  cmSolTag			 = NULLTAG;
	tag_t  GMXqry_tgdml			 = NULLTAG;

	char*TODRDRStatus		 = NULL;
    char*VCDMLDR			 = NULL;
    char*VCDML				 = NULL;
    char*VCPartRev			 = NULL;
	char*VCPartSeq			 = NULL;
							     
	char*Pointer_10_Val		 = NULL;
	char*Pointer_40_Val		 = NULL;
	char*Pointer_100_Val	 = NULL;
	char*Pointer_1_Val		 = NULL;
	char*Pointer_20_Val		 = NULL;
    char*DItemId			 = NULL;
    char*DItemIdLat			 = NULL;
    char*DItemIdLattype		 = NULL;
    char*DItemIdLatRevSeq	 = NULL;
    char*DItemIdLatPartstatus= NULL;
    char*DItemIdLatColInd	 = NULL;
	char*DItemIdLatrlsState	 = NULL;
	char*VCtaskName			 = NULL;
	char*VCDMLtype			 = NULL;
    char*VCDMLRlstype		 = NULL;
    char*TODRDRStatus1		 = NULL;

	TODRDRStatus1 = (char *) MEM_alloc(sizeof(char)* 200);
 
	char*DvloName	=(char *) MEM_alloc(sizeof(char)* 100);
	char*VCdmlTaskNo=(char *) MEM_alloc(sizeof(char)* 50);
	//char VCDMLobjType[WSO_name_size_c+1];
	 char* VCDMLobjType=NULL;
	//char*VCDMLobjType=NULL;
  
    tag_t* VCtaskObjSO		=NULLTAG;
    tag_t* DVLO_objects		=NULLTAG;
    tag_t* DVA_object1		=NULLTAG;

	int l=0;
	int i=0;
	int VCtaskcnt=0;
	int VCDMLkcnt=0;
	int DVLO_count=0;
	int DVAobj_count1=0;
	double VehGCIint=0;

	AOM_ask_value_string(Revtag,"object_name",&DItemId);
	printf("\nitem id obj name............ :: %s\n",DItemId);fflush(stdout);

	AOM_UIF_ask_value(Revtag,"t5_pointer_10",&Pointer_10_Val);
	printf(" \n Pointer_10_Val is :: %s\n",Pointer_10_Val);fflush(stdout);

    AOM_UIF_ask_value(Revtag,"t5_pointer_40",&Pointer_40_Val);
	printf(" \n Pointer_40_Val is :: %s\n",Pointer_40_Val);fflush(stdout);

    AOM_UIF_ask_value(Revtag,"t5_pointer_100",&Pointer_100_Val);
	printf(" \n Pointer_100_Val is :: %s\n",Pointer_100_Val);fflush(stdout);

    AOM_UIF_ask_value(Revtag,"t5_Pointer_20",&Pointer_20_Val);
	printf(" \n Pointer_20_Val is :: %s\n",Pointer_20_Val);fflush(stdout);

    AOM_UIF_ask_value(Revtag,"t5_Pointer_1",&Pointer_1_Val);
	printf("\n Pointer_1_Val is :: %s\n",Pointer_1_Val);fflush(stdout);

	if(tc_strlen(Pointer_10_Val)==0 || tc_strlen(Pointer_40_Val)==0 || tc_strlen(Pointer_100_Val)==0 || tc_strlen(Pointer_20_Val)==0 || tc_strlen(Pointer_1_Val)==0 )
	{
         
        EMH_store_error_s1(EMH_severity_error,PLM_error6,"Please enter All Pointers values.");
		return PLM_error6;
	}

	if(QRY_find2("Control Objects...", &GMXqry_tgdml));

	char *GMsc_entrydml1[2] = {"SYSCD","SUBSYSCD"};
	char **GMsc_RelValdml1 = (char **) MEM_alloc(50 * sizeof(char *));
	GMsc_RelValdml1[0] = "GCIForm5";
	GMsc_RelValdml1[1] = "ON";

	if(GMXqry_tgdml!=NULLTAG)
	{
		printf("\n Query tag found GCIForm5\n"); fflush(stdout);
	
	
	}
	ITK_CALL(QRY_execute(GMXqry_tgdml, 2, GMsc_entrydml1, GMsc_RelValdml1, &DVAobj_count1, &DVA_object1));
	printf("\n Query  found DVAobj_count1 %d\n",DVAobj_count1); fflush(stdout);


	ITEM_find_item(DItemId,&DitemTAG);

	if(DitemTAG != NULLTAG)
	{
		printf("\nItem Tag Found \n");;fflush(stdout);

		ITEM_ask_latest_rev(DitemTAG, &DitemRevTAG);

		if(DitemRevTAG != NULLTAG)
		{
          AOM_ask_value_string(DitemRevTAG,"item_id",&DItemIdLat);
	      printf("Item ID :: %s\n",DItemIdLat);fflush(stdout);

		  AOM_ask_value_string(DitemRevTAG,"t5_PartType",&DItemIdLattype);
	      printf("Item ID type :: %s\n",DItemIdLattype);fflush(stdout);

		  AOM_ask_value_string(DitemRevTAG,"t5_PartStatus",&DItemIdLatPartstatus);
	      printf("Item ID status :: %s\n",DItemIdLatPartstatus);fflush(stdout);

		  if(AOM_ask_value_string(DitemRevTAG,"item_revision_id",&DItemIdLatRevSeq));
		  printf("MRevisionID is :%s\n",DItemIdLatRevSeq);fflush(stdout);

          if(AOM_ask_value_string(DitemRevTAG,"t5_ColourInd",&DItemIdLatColInd));
		  printf("colour ind is :%s\n",DItemIdLatColInd);fflush(stdout);

		  if(AOM_UIF_ask_value(DitemRevTAG,"release_status_list",&DItemIdLatrlsState));
		  printf("release state is :%s\n",DItemIdLatrlsState);fflush(stdout);

			if(tc_strcmp(DItemIdLattype,"V")== 0 || tc_strcmp(DItemIdLattype,"VCCR")== 0)
            {
             printf("\n inside the part type Vehicle............\n");fflush(stdout);

			}
			else if (tc_strcmp(DItemIdLattype,"CCVC")!=0)
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error6,"Create GCI object is valid for Non-colour Vehicle(V) and Cofiguration vehicle(CCVC) part type only.");
				return PLM_error6;
			}
             printf("\n checking col indicator\n");fflush(stdout);

			if (tc_strcmp(DItemIdLatColInd,"C")!=0)
			{

				char*VCDML=(char *) MEM_alloc(sizeof(char)* 100);

				if((tc_strstr(DItemIdLatrlsState,"T5_LcsErcRlzd")!=NULL) || (tc_strstr(DItemIdLatrlsState,"ERC Released")!=NULL))
				{

					ITK_CALL(GRM_find_relation_type("CMReferences", &cmRefTag));       //change reference relation tag
					if(GRM_list_primary_objects_only(DitemRevTAG,cmRefTag,&VCtaskcnt,&VCtaskObjSO)!=ITK_ok);
					printf("\n reference n_TskCnt is %d.\n",VCtaskcnt); fflush(stdout);

					if(VCtaskcnt>0)
					{
						for(l=0;l<VCtaskcnt;l++)
						{

								 if(AOM_ask_value_string(VCtaskObjSO[l],"item_id",&VCtaskName));
								 printf("\n VC task name : [%s] \n", VCtaskName);fflush(stdout);

								 if(tc_strcmp(VCtaskName,"")!=0)
								 {

								  VCdmlTaskNo = tc_strtok(VCtaskName,"_");
								  printf("\n VC DML name : [%s] \n", VCdmlTaskNo);fflush(stdout);

								 }
								 if(ITEM_find_item(VCdmlTaskNo, &VCDML_tag)!=ITK_ok);

								 if (VCDML_tag != NULLTAG)
								 {
									printf("\n DML No is for vechile : [%s] \n", VCdmlTaskNo);fflush(stdout);

									if(ITEM_ask_latest_rev(VCDML_tag, &VCDMLRevTag)!=ITK_ok);

									
									ITK_CALL(TCTYPE_ask_object_type(VCDMLRevTag,&VCDMLobjTypTag));
									printf("\n  after object taggggggg \n");fflush(stdout);

									ITK_CALL(TCTYPE_ask_name2(VCDMLobjTypTag,&VCDMLobjType));
									printf("\n  object_type is %s\n", VCDMLobjType);fflush(stdout);

									if(tc_strcmp(VCDMLobjType,"ChangeRequestRevision")==0)
									{

										ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_rlstype",&VCDMLtype)); //TODR or Vehicle release
										printf("\n  VC DML type is : [%s]\n", VCDMLtype); fflush(stdout);

										ITK_CALL(AOM_UIF_ask_value(VCDMLRevTag,"release_status_list",&VCDMLRlstype));
										printf("\n  VC DML rls is : [%s]\n", VCDMLRlstype); fflush(stdout);
										TODRDRStatus1=NULL;
										TODRDRStatus=NULL;
										ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_PlntToPlnt",&TODRDRStatus));  // DR2 to DR3
										printf("\n t5_PlntToPlnt DMLTODRDRStatus rls is : [%s]\n", TODRDRStatus); fflush(stdout);
										TODRDRStatus1=tc_strtok(TODRDRStatus," ");
										printf("\n After tok TODRDRStatus1 rls is : [%s]\n", TODRDRStatus1); fflush(stdout);
									    printf("\n After tok t5_PlntToPlnt DMLTODRDRStatus rls is : [%s]\n", TODRDRStatus); fflush(stdout);

                                        if(DVAobj_count1>0)
										{
											printf("\n Inside control object found \n");fflush(stdout);
											if((tc_strcmp(VCDMLtype,"TODR")==0) && (tc_strstr(VCDMLRlstype,"ERC Released")==NULL))
											{

												printf("\n Inside TODR object  \n");fflush(stdout);

												if(tc_strcmp(DItemIdLatPartstatus,TODRDRStatus1)==0)
												{
													ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
													printf("\n  item_id is  *14*** %s\n", VCDML);fflush(stdout);
												
												}
											}
										}
										else
										{
											   printf("\n Inside control object count is Zero\n");fflush(stdout);
										       ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
											   printf("\n else VCDML item_id is %s\n", VCDML);fflush(stdout);
										
										
										
										}
										

									   //if((tc_strcmp(VCDMLtype,"TODR")==0) && (tc_strstr(VCDMLRlstype,"ERC Released")==NULL))
                                        /*if(tc_strstr(VCDMLRlstype,"ERC Released")==NULL)
										{

											ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_PlntToPlnt",&TODRDRStatus));
											printf("\n TODR DR is: [%s]\n", TODRDRStatus); fflush(stdout);
											//break;
										}
										else
										{
											printf("\n inside the else condition after break111111\n"); fflush(stdout);
											tc_strcpy(VCDML,"-");

										}*/

										/*if(tc_strstr(VCDMLRlstype,"ERC Released")==NULL)
										{
											ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
											printf("\n  item_id is22222 %s\n", VCDML);fflush(stdout);
										}
										else
										{
											printf("\n inside the else condition after break222222....\n"); fflush(stdout);
											
										}*/


									}
								 }
								 else
								 {
								    printf("\n DML not found****8 \n");fflush(stdout);
								 }

						}

					}
					else
					{
						printf("\n inside the else condition after break111222\n"); fflush(stdout);
						tc_strcpy(VCDML,"-");
						printf("\n inside the else condition after break111222 %s\n", VCDML);fflush(stdout);

					}
//				   else
//				   {
//						 printf("\n Inside CMreferecne DML check condition 11111111\n"); fflush(stdout);
//
//						 EMH_store_error_s1(EMH_severity_error,PLM_error6,"Kindly attach selected Vehicle or CCVC to DML Task then try to create GCI");
//						 return PLM_error6;
//				   }

	            }
	            else
				{
					 ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &cmSolTag));       //solution relation tag

					 if(GRM_list_primary_objects_only(DitemRevTAG,cmSolTag,&VCtaskcnt,&VCtaskObjSO));
	                 printf("\n solution task count****** is %d.\n",VCtaskcnt); fflush(stdout);

					 if(VCtaskcnt>0)
					 {

						for(i=0;i<VCtaskcnt;i++)
						{

						  if(AOM_ask_value_string(VCtaskObjSO[i],"item_id",&VCtaskName));
						  printf("\n VC task name : [%s] \n", VCtaskName);fflush(stdout);


						  if(tc_strcmp(VCtaskName,"")!=0)
						  {
							  VCdmlTaskNo = tc_strtok(VCtaskName,"_");
							  printf("\n VC DML name : [%s] \n", VCdmlTaskNo);fflush(stdout);
						  }

						  if(ITEM_find_item(VCdmlTaskNo, &VCDML_tag)!=ITK_ok);

						  if (VCDML_tag != NULLTAG)
						  {
								printf("\n DML No is for vechile :2222 [%s] \n", VCdmlTaskNo);fflush(stdout);

								if(ITEM_ask_latest_rev(VCDML_tag, &VCDMLRevTag)!=ITK_ok);

								ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
								printf("\n  item_id is %s\n", VCDML);fflush(stdout);

								ITK_CALL(TCTYPE_ask_object_type(VCDMLRevTag,&VCDMLobjTypTag));
								printf("\n  after object taggggggg2222 \n");fflush(stdout);

								ITK_CALL(TCTYPE_ask_name2(VCDMLobjTypTag,&VCDMLobjType));
								printf("\n  object_type is11 %s\n", VCDMLobjType);fflush(stdout);

								if(tc_strcmp(VCDMLobjType,"ChangeRequestRevision")==0)
								{


								ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_rlstype",&VCDMLtype));
								printf("\n  VC DML type is : [%s]\n", VCDMLtype); fflush(stdout);

								ITK_CALL(AOM_UIF_ask_value(VCDMLRevTag,"release_status_list",&VCDMLRlstype));
								printf("\n  VC DML rls is : [%s]\n", VCDMLRlstype); fflush(stdout);

								ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_cDRstatus",&VCDMLDR));
								printf("\n  DR status : [%s]\n", VCDMLDR); fflush(stdout);


								if((tc_strcmp(VCDMLtype,"Veh")==0) && (tc_strstr(VCDMLRlstype,"ERC Released")==NULL))
								{
									printf("\n inside the if condition before break....\n"); fflush(stdout);
									//break;
								}
								else
								{
									printf("\n inside the else condition after break222222....\n"); fflush(stdout);
									tc_strcpy(VCDML,"-");
									printf("\n inside the else condition after break222222.... %s\n", VCDML);fflush(stdout);
								}

								}
						  }
						  else
						  {
							printf("\n DML not found****8 \n");fflush(stdout);
						  }

						}

					 }
					 else
					 {
						printf("\n inside the else condition after break33333333....\n"); fflush(stdout);
						tc_strcpy(VCDML,"-");
						printf("\n inside the else condition after break33333333.... %s\n", VCDML);fflush(stdout);
					 }
//					 else
//					 {
//						 printf("\n Inside CMSolution DML check condition 11111111\n"); fflush(stdout);
//
//						 EMH_store_error_s1(EMH_severity_error,PLM_error6,"Kindly attach selected Vehicle or CCVC to DML Task then try to create GCI");
//						 return PLM_error6;
//					 }
				}

				VCPartRev = tc_strtok(DItemIdLatRevSeq,";");
				VCPartSeq = tc_strtok(NULL,";");
				printf("\n after strtok : [%s] [%s]\n",VCPartRev ,VCPartSeq); fflush(stdout);

				tc_strcpy(DvloName,"");
				tc_strcpy(DvloName,"GCI_");
				tc_strcat(DvloName,DItemIdLat);
				tc_strcat(DvloName,"_");
				tc_strcat(DvloName,VCPartRev);
				tc_strcat(DvloName,"_");
				tc_strcat(DvloName,VCPartSeq);
				//tc_strcat(DvloName,"_");
				//tc_strcat(DvloName,DItemIdLatPartstatus);
				printf("\n DVLO Name is : [%s]\n",DvloName); fflush(stdout);


				if(QRY_find2("General...", &DVLORel));

				printf("\n Querying the form data......\n"); fflush(stdout);

				char *sc_entry1[2] = {"Name","Type"};
				char **sc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));

				sc_RelVal[0] = DvloName;
				sc_RelVal[1] ="GCI Document";

				ITK_CALL(QRY_execute(DVLORel, 2, sc_entry1, sc_RelVal, &DVLO_count, &DVLO_objects));

				printf("\n Query count for GCI form :[%d]\n",DVLO_count); fflush(stdout);

				if (DVLO_count>0)
				{

						EMH_store_error_s1(EMH_severity_error,PLM_error6,"GCI object is already available in system for selected Vehicle Revision or CCVC..Please Check relation in HAS GCI Vehicle relation");
						return PLM_error6;
				}
				else
				{
					if(tc_strcmp(VCDML,"-")==0)
					{

						 printf("\n Inside VCDML condition 11111111\n"); fflush(stdout);
						 printf("\n Inside VCDML condition 11111111 %s\n", VCDML);fflush(stdout);

						 EMH_store_error_s1(EMH_severity_error,PLM_error6,"Kindly attach selected Vehicle or CCVC to DML Task then try to create GCI");
						 return PLM_error6;

					}
					else
					{
						 printf("\n calling create_GCI_document function11111111\n"); fflush(stdout);

						 create_GCI_document(DitemRevTAG,Pointer_10_Val, Pointer_40_Val, Pointer_100_Val,Pointer_20_Val,Pointer_1_Val,DvloName, VCPartRev, VCDML, DItemIdLat);

						 printf("\n END create_GCI_document function11111111\n"); fflush(stdout);

					}
				}


			}
			else
			{
                EMH_store_error_s1(EMH_severity_error,PLM_error6,"Create GCI object is valid for Non-colour Vehicle and not for Colour Vehicle.");
				return PLM_error6;

			}

		}
		else
		{
			printf("\nItem Tag not Found \n");fflush(stdout);
		}


		}
		else
	    {
              EMH_store_error_s1(EMH_severity_error,PLM_error6,"Please enter correct Vehicle/CCVC Number.");
				return PLM_error6;


	    }



		if(DFQApplCntflag>0)   
		{
			DFQApplCntflag=0; 
		}

		if(falseflagg>0)
		{
			falseflagg =0; 
		}

		if(DFQpdfCount>0)
		{
			DFQpdfCount=0;
		}

		if(DFQexcelsCount>0)
		{
			DFQexcelsCount=0; 
		}

		if(MeetexpectationCnt>0)
		{
			MeetexpectationCnt=0;
		}

 return 0;
 }

extern DLLAPI int t5_dvlo_Creation(METHOD_message_t *m, va_list args)
{

	int Status = ITK_ok;
	int ifail=0;

	tag_t revtag = va_arg(args, tag_t);

	//printf("\n *** DVLO Document creation form Start **** \n");fflush(stdout);

	CALLAPI(t5_DVLO_document_creation(revtag));

	//printf("\n *** DVLO Document creation End *** \n");fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int t5_dfmea_creation(METHOD_message_t *m, va_list args)
{

	int Status = ITK_ok;
	int ifail=0;

	tag_t revtag1 = va_arg(args, tag_t);

	//printf("\n *** DFMEA Document creation form Start **** \n");fflush(stdout);

	CALLAPI(t5_dfmea_document_creation(revtag1));

	//printf("\n *** DFMEA Document creation End *** \n");fflush(stdout);

	return ITK_ok;
}



extern DLLAPI int checkindfq(METHOD_message_t *m, va_list args)
{

	int Status = ITK_ok;
	int ifail=0;

	tag_t object_tag1 = va_arg(args, tag_t);

	//printf("\n *** Inside The checkin funstion2 **** \n");fflush(stdout);

	CALLAPI(checkindfqvalidation(object_tag1));

	//printf("\n *** The checkin funstion2 End *** \n");fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int GCICheckout(METHOD_message_t *m, va_list args)
{

	int Status = ITK_ok;
	int ifail=0;

	tag_t object_tag2 = va_arg(args, tag_t);

	printf("\n *** Inside The GCICheckout funstion2 **** \n");fflush(stdout);

	CALLAPI(GCICheckoutvalidation(object_tag2));

	printf("\n *** The GCICheckout funstion2 End *** \n");fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int FourDCheckout(METHOD_message_t *m, va_list args)
{

	int Status = ITK_ok;
	int ifail=0;

	tag_t object_tag3 = va_arg(args, tag_t);

	printf("\n *** Inside The 4D Documents Check Out **** \n");fflush(stdout);

	CALLAPI(FourDCheckoutvalidation(object_tag3));

	printf("\n *** The 4D Documents Check Out End *** \n");fflush(stdout);

	return ITK_ok;
}


extern DLLAPI int t5_DFQ_create_with_dataset(METHOD_message_t *m, va_list args)
{
	int Status = ITK_ok;
	int ifail=0;

	tag_t rev = va_arg(args, tag_t);

	//printf("\n *** DFQ Document creation form Start **** \n");fflush(stdout);

	CALLAPI(t5_dfq_document_creation(rev));

	//printf("\n *** DFQ Document creation End *** \n");fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int TMKODcoumentCreation(METHOD_message_t *m, va_list args)
{
	int Status = ITK_ok;
	int ifail=0;

	tag_t Tmkorev = va_arg(args, tag_t);

	printf("\n *** TMKO Document creation form Start 122222**** \n");fflush(stdout);

	CALLAPI(TMKOrevcreationfun(Tmkorev));

	printf("\n *** TMKO Document creation End 1222*** \n");fflush(stdout);

	return ITK_ok;
}

/*extern DLLAPI int TMKODocTable(METHOD_message_t *m, va_list args)
{
	int Status = ITK_ok;
	int ifail=0;

	tag_t Tmkorevtable = va_arg(args, tag_t);

	printf("\n *** TMKO Table creation form Start **** \n");fflush(stdout);

	CALLAPI(TMKODocTablesave(Tmkorevtable));

	printf("\n *** TMKO Table creation End *** \n");fflush(stdout);

	return ITK_ok;
}*/

extern DLLAPI int t5_DFQ_Doc_save_dataset(METHOD_message_t *m, va_list args)   
{
	int Status = ITK_ok;
	int ifail=0;

	char* objname = NULL;;
	char* meet_expectations = NULL;;
	double design_nominal;
	double defined_target;
	double achieved_nominal;
	double achieved_target;
	double CpkVal;
	char* username = NULL;
		tag_t user_tag=NULLTAG;

	logical dfq_applicability;

	printf("Start t5_DFQ_Doc_save_dataset Method \n");fflush(stdout);

	CALLAPI(POM_get_user(&username,&user_tag));
		printf("\n\n username :%s\n",username);fflush(stdout);

	tag_t objTag = va_arg(args, tag_t);

	AOM_ask_value_string(objTag,"object_name",&objname);
	printf("t5_DFQ_Doc_save_dataset objname :: %s\n",objname);fflush(stdout);

	AOM_ask_value_logical(objTag,"t5_DFQApplicablility",&dfq_applicability);
	printf("t5_DFQ_Doc_save_dataset dfq_applicability %d\n",dfq_applicability);fflush(stdout);

	AOM_ask_value_double(objTag,"t5_DFQDesNom",&design_nominal);
	printf("t5_DFQ_Doc_save_dataset design_nominal ::%f\n",design_nominal);fflush(stdout);

	AOM_ask_value_double(objTag,"t5_DNDefTarget",&defined_target);
	printf("t5_DFQ_Doc_save_dataset defined_target (+/-)::%f\n",defined_target);fflush(stdout);

	AOM_ask_value_double(objTag,"t5_DFQAchNom",&achieved_nominal);
	printf("t5_DFQ_Doc_save_dataset achieved_nominal ::%f\n",achieved_nominal);fflush(stdout);

	AOM_ask_value_double(objTag,"t5_ANDefTarget",&achieved_target);
	printf("t5_DFQ_Doc_save_dataset achieved_target (+/-) ::%f\n",achieved_target);fflush(stdout);

	AOM_ask_value_double(objTag,"t5_DFQCpkVal",&CpkVal);
	printf("t5_DFQ_Doc_save_dataset CpkVal ::%f\n",CpkVal);fflush(stdout);

	AOM_ask_value_string(objTag,"t5_DFQMeetExp",&meet_expectations);
	printf("t5_DFQ_Doc_save_dataset meet_expectations ::%s\n",meet_expectations);fflush(stdout);

	if(strcmp(username,"Ajay Mali")==0 || strcmp(username,"Mohammad Asif")==0  || strcmp(username,"mam.ttl")==0 || strcmp(username,"mukteshg.ttl")==0 || strcmp(username,"Muktesh Girdhani")==0 || strcmp(username,"prasadb1.ttl")==0 || strcmp(username,"Prasad Bhide")==0 || strcmp(username,"pramodk1.ttl")==0 || strcmp(username,"Pramod Koshti")==0)
	{
		printf("\n\n\t\t bypass for loader & infodba for save as operation of DVA ==> %s\n", username);fflush(stdout);
	} 
	else
	{

	
		if ((design_nominal == 999.9999) || (defined_target == 999.9999) || (achieved_nominal == 999.9999)  || (achieved_target == 999.9999) || (CpkVal == 999.9999) || (dfq_applicability == 0))
		{
			printf("*** t5_DFQ_Doc_save_dataset DFQ Analysis not fill for DFQ Document Name %s *** \n",objname);fflush(stdout);

			if(AOM_lock(objTag));

			printf("\n All 999.9999 t5_DFQ_Doc_save_dataset Before setting Meet Expectations NA = %s\n",meet_expectations);fflush(stdout);

			if( AOM_set_value_string(objTag,"t5_DFQMeetExp","NA"));

			printf("\n All 999.9999 t5_DFQ_Doc_save_dataset After setting Meet Expectations NA\n");fflush(stdout);

			if(AOM_save_with_extensions(objTag));
			if(AOM_unlock(objTag));
			if(AOM_refresh(objTag,1));

		}
		else
		{
			if(achieved_target <= (1.3 * defined_target))
			{
				if(AOM_lock(objTag));

				printf("\n t5_DFQ_Doc_save_dataset Before setting Meet Expectations Yes = %s\n",meet_expectations);fflush(stdout);

				if( AOM_set_value_string(objTag,"t5_DFQMeetExp","Y"));

				printf("\n t5_DFQ_Doc_save_dataset After setting Meet Expectations Yes\n");fflush(stdout);

				if(AOM_save_with_extensions(objTag));
				if(AOM_unlock(objTag));
				if(AOM_refresh(objTag,1));
			}
			else
			{
				if(AOM_lock(objTag));

				printf("\n t5_DFQ_Doc_save_dataset Before setting Meet Expectations No = %s\n",meet_expectations);fflush(stdout);

				if(AOM_set_value_string(objTag,"t5_DFQMeetExp","N"));

				printf("\n t5_DFQ_Doc_save_dataset After setting Meet Expectations No\n");fflush(stdout);

				if(AOM_save_with_extensions(objTag));
				if(AOM_unlock(objTag));
				if(AOM_refresh(objTag,1));
			}
		}
	}


	return ITK_ok;
}
extern EPM_decision_t DLLAPI GCIdoc_Validation (EPM_rule_message_t msg)
{

	//EPM_decision_t decision;
	EPM_decision_t decision = EPM_go;

	char* username			= NULL;
	char* CurrentTask		= NULL;
	char* childParentTask	= NULL;
	char* parent_name		= NULL;
	char* dmlTaskNo			= NULL;
	char* GCIDMLnum			= NULL;
	char* GCIDMLSkip		= NULL;
	char* DMLReltype		= NULL;
	char* Busunit			= NULL;
	char* Userinfo1dup		= NULL;
	char* Userinfo2dup		= NULL;
	char* Userinfo3dup		= NULL;
	char* Userinfo4dup		= NULL;
	char* Userinfo5dup		= NULL;
	char* XPartNum			= NULL;
	char* XPartRev			= NULL;
	char* XParttype			= NULL;
	char* DMLDR1			= NULL;
	char* plntToPlnt		= NULL;
	char* XPartStat			= NULL;
	char* XColInd			= NULL;
	char* XPartSeqId		= NULL;
	char* XpartSeq			= NULL;
	char* XdesRev			= NULL;
	char* DvloGCIDup		= NULL;
	char* GCIdml			= NULL;
	char* DvloNumberStr		= NULL;
	char* GCIName			= NULL;
	char *FromPlnt			= NULL;
	char *FfrmPlnt			= NULL;
	//char  objType[WSO_name_size_c+1];
	char *objType            = NULL;
	char *DMUnotfound		 =NULL;
	char *DMUxsl			 =NULL;
	char *DMUnametype1		= NULL;
	char *objecttype		= NULL;

	tag_t  rootTask			 = NULLTAG;
	tag_t  DMLTaskTag		 = NULLTAG;
	tag_t  DML_tag			 = NULLTAG;
	tag_t  DMLRevTag		 = NULLTAG;
	tag_t  objTypTag		 = NULLTAG;
	tag_t  GMXqry_tg		 = NULLTAG;
	tag_t  GCIrevtag		 = NULLTAG;
	tag_t  XrevTag			 = NULLTAG;
	tag_t  DVLORelatn_type	 = NULLTAG;
	tag_t *GciObjtag		 = NULLTAG;
	tag_t *attachments		 = NULLTAG;
	tag_t *GCI_object		 = NULLTAG;
	tag_t *BreakdowncountTags= NULLTAG;
	tag_t* XPartTags		 = NULLTAG;

	int GCIobj_count	=0;
	int noAttachment	=0;
	int Breakdowncount	=0;
	int GCISKIPflag		=0;
	int PASSFlag		=0;
	int	VehGCIH85GrtCnt	=0;
	int	DvloCreateStFlag=0;
	int	Xpartcount		=0;
	int	gciObjcnt		=0;
	int	DMUnameflag	    =0;
	int r =0;
	int	Xp=0;
	int	gc=0;
	int doccheck=0;
	int GCI85flag=0;
	int SoftGCI85flag=0;
	int GCINameConCnt=0;
	int GCINameCnt=0;
	int DMUnotfoundflag=0;
	double VehGCIint =0;
	double GCIvalue;
	char *DvloVehRevSeq  =(char *) MEM_alloc(sizeof(char)* 200);
	char *DvloGCILessStr = (char *) MEM_alloc(sizeof(char)* 200);
	char *DvloGCILessStr1 = (char *) MEM_alloc(sizeof(char)* 200);
	char *GCINametype = (char *) MEM_alloc(sizeof(char)* 200);
	char *GCINametypeStr = (char *) MEM_alloc(sizeof(char)* 200);
	char *VehicleDRStr = (char *) MEM_alloc(sizeof(char)* 200);
	DMUnotfound = (char *) MEM_alloc(sizeof(char)* 200);
	DMUnametype1 = (char *) MEM_alloc(sizeof(char)* 200);






	ITK_CALL(POM_get_user_id (&username));
    printf("\n Inside the GCIdoc_Validation Session User is : %s \n",username); fflush(stdout);


	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	{
		/*
		Inside the GMSignOffCheck ...

		GMSignOffCheck- CurrentTask: Verify Parts for Gate Maturation

		GMSignOffCheck- parent Name: Change Request Life Cycle

		GMSignOffCheck- Target Attachment:2*/


		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n Inside the GCIdoc_Validation ...\n");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n GCIdoc_Validation- CurrentTask: %s \n",CurrentTask);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&childParentTask));
		printf("\n GCIdoc_Validation- childParentTask: %s \n",childParentTask);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\n GCIdoc_Validation- parent Name: %s \n",parent_name);fflush(stdout);

		ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\n GCIdoc_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);

		if(noAttachment > 0)
		{

			printf("\n Inside for GCIdoc_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);
			DMLTaskTag = attachments[0];

			if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n GCIdoc_Validation- DML No: [%s] \n", dmlTaskNo);fflush(stdout);

			if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{

				printf("\n DML tag is not null for GMSignOffCheck- DML No: [%s] \n", dmlTaskNo);fflush(stdout);

				if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

				ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&GCIDMLnum));
				printf("\n  GCI item_id is %s\n", GCIDMLnum);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDR1));
				printf("\n  GCI DR status : [%s]\n", DMLDR1); fflush(stdout);

				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&plntToPlnt));
				printf("\n GCI DR TODR status : [%s]\n", plntToPlnt); fflush(stdout);

				ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));

				ITK_CALL(TCTYPE_ask_name2(objTypTag,&objType));
				printf("\n  object_type is %s\n", objType);fflush(stdout);


                if (tc_strcmp(objType,"ChangeRequestRevision")==0)
			    {
					if(QRY_find2("Control Objects...", &GMXqry_tg));

				    char *GMsc_entry1[2] = {"SYSCD","SUBSYSCD"};
					char **GMsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
					GMsc_RelVal[0] = "DevGCI";
					GMsc_RelVal[1] = "ON";

					ITK_CALL(QRY_execute(GMXqry_tg, 2, GMsc_entry1, GMsc_RelVal, &GCIobj_count, &GCI_object));

					printf("\n Query count for GCI form :[%d]\n",GCIobj_count); fflush(stdout);

				    if(GCIobj_count >0)
					{

					   ITK_CALL(AOM_ask_value_string(GCI_object[0],"t5_Userinfo1",&Userinfo1dup));  //if score less than 90 then we bypass DML for given DR status.
                       printf("\n userinfo1 DML:[%s]\n",Userinfo1dup); fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(GCI_object[0],"t5_Userinfo2",&Userinfo2dup));  //hard check for GCI object from DR0 and above status.
                       printf("\n userinfo2 DR:[%s]\n",Userinfo2dup); fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(GCI_object[0],"t5_Userinfo3",&Userinfo3dup));	//soft check for score lesss than 90 DR0 to DR2 status.
                       printf("\n userinfo3 DR:[%s]\n",Userinfo3dup); fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(GCI_object[0],"t5_Userinfo4",&Userinfo4dup));	//hard check for score less than 90 from DR3 and above status.
                       printf("\n Userinfo4dup DR:[%s]\n",Userinfo4dup); fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(GCI_object[0],"t5_Userinfo5",&Userinfo5dup));  // if value is ON then validation is ON if value is Null validation is Off
					   printf("\n Userinfo5dup ON/OFF  :[%s]\n",Userinfo5dup); fflush(stdout);




					   GCIDMLSkip=(char *)MEM_alloc(50);
					   tc_strcpy(GCIDMLSkip,"");
					   tc_strcpy(GCIDMLSkip,",");
					   tc_strcat(GCIDMLSkip,GCIDMLnum);
					   tc_strcat(GCIDMLSkip,",");

                       printf("\n GCIDMl skip:[%s]\n",GCIDMLSkip); fflush(stdout);

					   if(tc_strstr(Userinfo1dup,GCIDMLSkip)!=NULL)
					   {
						 GCISKIPflag=1;
					   }

						//}

						if(GCISKIPflag>0)
						{
						printf("\n skipping the GCIDML\n"); fflush(stdout);
						}
						else
						{

						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLReltype));
						printf("\n  t5_rlstype is : [%s]\n", DMLReltype); fflush(stdout);

						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&Busunit));
						printf("\n  Busunit : [%s]\n", Busunit); fflush(stdout);

					   	PASSFlag=0;

						if(((tc_strcmp(Busunit,"CVBU")==0) || (tc_strcmp(Busunit,"PVBU")==0)) && (tc_strcmp(DMLReltype,"TODR")==0) && (tc_strcmp(CurrentTask,"GM DML Review")==0))
                        {
							
                            PASSFlag=1;
							printf("\n Inside GM DML Review condition\n"); fflush(stdout);
							printf("\n  DML No is Inside GM DML Review condition  %s\n", GCIDMLnum);fflush(stdout);


                        }
                        else if(((tc_strcmp(Busunit,"CVBU")==0) || (tc_strcmp(Busunit,"PVBU")==0)) && (tc_strcmp(DMLReltype,"Veh")==0) && (tc_strcmp(CurrentTask,"DMU Review")==0))
                        {

							PASSFlag=1;
							printf("\n Inside DMU Review condition\n"); fflush(stdout);
							printf("\n  DML No is Inside DMU Review condition  %s\n", GCIDMLnum);fflush(stdout);
                        }
						else if((tc_strcmp(Busunit,"CVBU")==0) &&(tc_strcmp(DMLReltype,"TODR")==0)&&(tc_strcmp(CurrentTask,"CE Review")==0))
						{

							PASSFlag=1;
							printf("\n Inside CE Review condition\n"); fflush(stdout);
						}


						printf("\n  PASSFlag value is : [%d]\n", PASSFlag); fflush(stdout);

						if(PASSFlag>0)
						{

							printf("\n Inside PASSFlag........\n"); fflush(stdout);

							ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Breakdowncount,&BreakdowncountTags));

							if (Breakdowncount>0)
							{
								printf("\n Inside Breakdowncount[%d]........\n",Breakdowncount); fflush(stdout);


								for (r=0;r<Breakdowncount;r++)
								{

									if (tc_strcmp(DMLReltype,"TODR")==0)
									{
										printf("\n GCI Inside dmltype TODR\n"); fflush(stdout);

										ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[r],"CMReferences",&Xpartcount,&XPartTags)); //Change References
										printf("\n inside check GMDml Skip for now ---------------> : \n"); fflush(stdout);
										printf("\n No of Parts found1 = %d\n",Xpartcount);fflush(stdout);
									}
									if (tc_strcmp(DMLReltype,"Veh")==0)
									{
										printf("\n Inside dmltype Veh\n"); fflush(stdout);

										ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[r],"CMHasSolutionItem",&Xpartcount,&XPartTags));
										printf("\n inside check MDml Skip for now ---------------> : \n"); fflush(stdout);
										printf("\n No of Parts found2 = %d\n",Xpartcount);fflush(stdout);
									}

									if (Xpartcount > 0)
									{
										printf("\n inside CMReferences or CMHasSolutionItem relation... ");fflush(stdout);
										tc_strcpy(DvloGCILessStr1,"");
										tc_strcpy(GCINametype,"");
										tc_strcpy(DMUnotfound,"");
										

										for(Xp=0;Xp<Xpartcount;Xp++)
										{
											XrevTag = XPartTags[Xp];

											ITK_CALL(AOM_ask_value_string(XrevTag,"item_id",&XPartNum));

											ITK_CALL(AOM_ask_value_string(XrevTag,"item_revision_id",&XPartRev));

											ITK_CALL(AOM_ask_value_string(XrevTag,"t5_PartType",&XParttype));

											ITK_CALL(AOM_ask_value_string(XrevTag,"t5_PartStatus",&XPartStat));

											ITK_CALL(AOM_ask_value_string(XrevTag,"t5_ColourInd",&XColInd));

											ITK_CALL(AOM_UIF_ask_value(XrevTag,"sequence_id",&XPartSeqId));

											printf("\n XPartSeqId is : %s ",XPartSeqId);fflush(stdout);

											printf("\n GCI Part No %s/%s/%s Details : %s, %s,%s.\n",XPartNum,XPartRev,XPartSeqId,XParttype,XPartStat,XColInd);fflush(stdout);

											

											XdesRev = tc_strtok(XPartRev,";");
											XpartSeq = tc_strtok(NULL,";");

											if(((tc_strcmp(XParttype,"V")==0) || (tc_strcmp(XParttype,"VCCR")==0)||(tc_strcmp(XParttype,"CCVC")==0)) && (tc_strcmp(XColInd,"C")!=0))
											{
												

												tc_strcpy(DvloVehRevSeq,"");
												tc_strcpy(DvloVehRevSeq,"Please create GCI Demerit Score for attached vehicle ");
												tc_strcat(DvloVehRevSeq,XPartNum);
												tc_strcat(DvloVehRevSeq,"_");
												tc_strcat(DvloVehRevSeq,XPartRev);
												tc_strcat(DvloVehRevSeq,"_");
												tc_strcat(DvloVehRevSeq,XPartSeqId);
												tc_strcat(DvloVehRevSeq," to DML and enter Demerit Score. Using option:  File->New->others->GCI Form and  Please Check relation:- HAS GCI Vehicle relation ");

												ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&DVLORelatn_type));

												ITK_CALL(GRM_list_secondary_objects_only(XrevTag,DVLORelatn_type,&gciObjcnt,&GciObjtag));

												printf("\n gciObjcnt is ...[%d] \n",gciObjcnt);fflush(stdout);
                                                char *DvloNumberStr =(char *) MEM_alloc(sizeof(char)* 200);
											
												if (gciObjcnt>0)
												{
													doccheck=1;

													tc_strcpy(DvloNumberStr,"");
													tc_strcpy(DvloNumberStr,"GCI_");
													tc_strcat(DvloNumberStr,XPartNum);
													tc_strcat(DvloNumberStr,"_");
													tc_strcat(DvloNumberStr,XdesRev);
													tc_strcat(DvloNumberStr,"_");
													tc_strcat(DvloNumberStr,XpartSeq);
													//tc_strcat(DvloNumberStr,"_");

                                                    if (tc_strcmp(DMLReltype,"TODR")==0)
									                { 
														FromPlnt=tc_strtok(plntToPlnt,"to");
														FfrmPlnt=tc_strtok(FromPlnt," ");

														printf("\n GCI FromPlnt value is ...[%s] \n",FfrmPlnt);fflush(stdout);

														//tc_strcat(DvloNumberStr,FfrmPlnt);
													
														printf("\n DvloNumberStr value is ...[%s] \n",DvloNumberStr);fflush(stdout);
												    }
												    else
												    {
														//tc_strcat(DvloNumberStr,DMLDR1);
												    }

													printf("\n DvloNumberStr name ...[%s] \n",DvloNumberStr);fflush(stdout);

													for(gc=0;gc<gciObjcnt;gc++)
													{


														printf("\n inside for loop gc count.\n");fflush(stdout);

														GCIrevtag=GciObjtag[gc];
														ITK_CALL(AOM_ask_value_string(GCIrevtag,"object_type",&objecttype));
		                                                printf("\n objecttype inside loop GCI Creation form :%s\n",objecttype);fflush(stdout);


														 if(gciObjcnt>=2)
														{
															 printf("\n inside dvlo form condition gciObjcnt is ...[%d] \n",gciObjcnt);fflush(stdout);
														  if(tc_strcmp(objecttype,"T5_dvlo_form")==0)
														  {
															  
															  printf("\n inside dvlo form condition\n");
															  continue;
															 
														  
														  }


														}

														ITK_CALL(AOM_ask_value_string(GCIrevtag,"t5_DVLO_Name1",&GCIName));
														printf("\n GCIName :[%s]\n",GCIName);fflush(stdout);

														ITK_CALL(AOM_ask_value_string(GCIrevtag,"t5_DVLODmlNo1",&GCIdml));
														printf("\n GCIdml :[%s]\n",GCIdml);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIrevtag,"t5_geometry_conf_index_a1",&GCIvalue));
														printf("\n GCIvalue :[%lf]\n",GCIvalue);fflush(stdout);

														ITK_CALL(AOM_UIF_ask_value(GCIrevtag,"ref_list",&DMUxsl));
														printf("\n DMUxsl Name is :[%s]\n",DMUxsl);fflush(stdout);
														
													
														

														 if(tc_strstr(DMUxsl,"DMU")==NULL)
														  {

															    printf(" \n inside the DMU Report check xlsx .... \n");fflush(stdout);
																DMUnameflag=DMUnameflag+1;
																tc_strcat(DMUnotfound,GCIName);
																tc_strcat(DMUnotfound,",");

														  }

                                                       


														//if (((tc_strstr(DvloNumberStr,GCIName)!=NULL) && (tc_strcmp(GCIdml,GCIDMLnum)==0)) || ((tc_strstr(DvloNumberStr,GCIName)!=NULL) && (tc_strcmp(GCIdml,GCIDMLnum)==0) && (tc_strcmp("T5_dvlo_form",objecttype)==0)))
														if((tc_strstr(DvloNumberStr,GCIName)!=NULL) && (tc_strcmp(GCIdml,GCIDMLnum)==0))
														{
															DvloCreateStFlag=1;


                                                            printf("\n inside match found777\n");fflush(stdout);

															
															tc_strcpy(VehicleDRStr,"");
															tc_strcpy(VehicleDRStr,",");
															printf("\n  Before is condition  : [%s]\n", DMLDR1); fflush(stdout);

                                                            if (tc_strcmp(DMLReltype,"TODR")==0)
															{ 

																printf("\n Inside if condition  : [%s]\n", DMLDR1); fflush(stdout);
																tc_strcat(VehicleDRStr,DMLDR1);
															
															}
															else
															{
																printf("\n Inside else condition : [%s]\n", DMLDR1); fflush(stdout);
																tc_strcat(VehicleDRStr,DMLDR1);

															}

															tc_strcat(VehicleDRStr,",");

															printf(" \n Userinfo4dup: [%s]  VehicleDRStr: [%s] GCIvalue: [%lf] \n ",Userinfo4dup,VehicleDRStr,GCIvalue);fflush(stdout);
															printf(" \n Userinfo1dup: [%s] \n",Userinfo1dup);fflush(stdout);

															//Start--Validation for Vehicle DR3=> DR Gate
															if ((tc_strstr(Userinfo4dup,VehicleDRStr)!=NULL) && (GCIvalue<90))
															{
																printf(" \n inside the userinfo vehicle condition for hard check .... \n");fflush(stdout);

																VehGCIH85GrtCnt=VehGCIH85GrtCnt+1;
																tc_strcat(DvloGCILessStr1,DvloNumberStr);
																tc_strcat(DvloGCILessStr1,",");

																printf("\n VehGCIH85GrtCnt value for hard check is: [%d]\n",VehGCIH85GrtCnt);fflush(stdout);

															}
															else if((tc_strstr(Userinfo3dup,VehicleDRStr)!=NULL) && (GCIvalue<90))
															{
																printf(" \n inside the userinfo vehicle condition for soft check .... \n");fflush(stdout);

																VehGCIH85GrtCnt=VehGCIH85GrtCnt+1;
																tc_strcat(DvloGCILessStr1,DvloNumberStr);
																tc_strcat(DvloGCILessStr1,",");

																printf("\n VehGCIH85GrtCnt value for soft check is: [%d]\n",VehGCIH85GrtCnt);fflush(stdout);
															}
															
															printf("\n VehGCIH85GrtCnt value is: [%d]\n",VehGCIH85GrtCnt);fflush(stdout);

															//END--Validation for Vehicle DR3=> DR Gate
														}
														else
														{
                                                              printf(" \n inside the Name checking of GCI.... \n");fflush(stdout);
															  GCINameConCnt=GCINameConCnt+1;
															  tc_strcat(GCINametype,XPartNum);
															  tc_strcat(GCINametype,",");

															  printf("\n GCINameConCnt value is: [%d]\n",GCINameConCnt);fflush(stdout);
															  
													    }

													}

												}
//												else if(tc_strstr(Userinfo3dup,XPartStat)!=NULL)
//												{
//														printf(" \n inside the warning or soft check. \n");fflush(stdout);
//
//														EMH_store_error_s1(EMH_severity_warning,ITK_err,DvloVehRevSeq);
//														decision = EPM_go;
//														return decision;
//												}
												else if (tc_strstr(Userinfo2dup,XPartStat)!=NULL)
												{
													printf(" \n inside the Hard GCI check. \n");fflush(stdout);
													printf("\n  GCI Object hard Check DML no [%s] and VC no[%s]\n",GCIDMLnum,XPartNum);

													EMH_store_error_s1(EMH_severity_error,ITK_err,DvloVehRevSeq);

													decision = EPM_nogo;
													return decision;
												}
												if((VehGCIH85GrtCnt>0) && (tc_strstr(Userinfo3dup,VehicleDRStr)!=NULL))
												{
													printf(" \n inside the GCI SOFT CHECK for Score less than 90. \n");fflush(stdout);

													SoftGCI85flag=1;

												    tc_strcpy(DvloGCILessStr,"");
												    tc_strcpy(DvloGCILessStr,"Geometry conformance Index(GCI) is less than 90% for vehicle GCI : ");
                                                    tc_strcat(DvloGCILessStr,DvloGCILessStr1);
													tc_strcat(DvloGCILessStr," For any related Query contact to ERC QA.");
													printf("\n  GCI Soft Check DML no [%s] and VC no[%s] and DR status [%s]\n",GCIDMLnum,XPartNum,VehicleDRStr);


												
												}

												if((VehGCIH85GrtCnt>0) && (tc_strstr(Userinfo4dup,VehicleDRStr)!=NULL))
												{
													printf(" \n inside the GCI HARD CHECK for Score less than 90. \n");fflush(stdout);
													GCI85flag=1;

												    tc_strcpy(DvloGCILessStr,"");
												    tc_strcpy(DvloGCILessStr,"Geometry conformance Index(GCI) is less than 90% for vehicle GCI : ");
                                                    tc_strcat(DvloGCILessStr,DvloGCILessStr1);
													tc_strcat(DvloGCILessStr," For any related Query contact to ERC QA.");
													printf("\n  GCI hard Check DML no [%s] and VC no[%s] and DR status [%s]\n",GCIDMLnum,XPartNum,VehicleDRStr);

//
//													EMH_store_error_s1(EMH_severity_error,ITK_err,DvloGCILessStr);
//
//													decision = EPM_nogo;
//													return decision;
												}

												if(GCINameConCnt>0)
												{
                                                     GCINameCnt=1;
													 printf(" \n Inside the GCINameConCnt .......... %d \n",GCINameConCnt);fflush(stdout);

												    tc_strcpy(GCINametypeStr,"");
												    tc_strcpy(GCINametypeStr,"Please create the correct GCI for : ");
                                                    tc_strcat(GCINametypeStr,GCINametype);
													tc_strcat(GCINametypeStr," For any related Query contact to ERC QA.");
													
													
                                                               
												}
												printf("\n after gci 90 error:%d\n",GCI85flag);fflush(stdout);

											   if((DMUnameflag>0) && (tc_strcmp(Userinfo5dup,"ON")==0))
											   {
												   printf(" \n Inside the ON Condition .......... \n");fflush(stdout);

													DMUnotfoundflag=1;
													tc_strcpy(DMUnametype1,"");
													tc_strcpy(DMUnametype1,"Please Attach the DMU_report_CSV under GCI object : ");
												    tc_strcat(DMUnametype1,DMUnotfound);
												    tc_strcat(DMUnametype1," For any related Query contact to ERC QA.");

															   
											  } 

											

											}
											

										}
									}

							
								}

								if (SoftGCI85flag==1)
								{

									printf("\n .............SOFT CHECK HAPPY DIWALI....... \n");fflush(stdout);

									EMH_store_error_s1(EMH_severity_warning,ITK_err,DvloGCILessStr);
									decision = EPM_go;
									return decision;
								}
									
								if (GCI85flag==1)
								{

									printf("\n .............HARD CHECK HAPPY DIWALI....... \n");fflush(stdout);

									EMH_store_error_s1(EMH_severity_error,ITK_err,DvloGCILessStr);
									decision = EPM_nogo;
									return decision;
								}
								 if (GCINameCnt==1)
								{

									printf("\n .............GCI Name Hard check....... \n");fflush(stdout);

									EMH_store_error_s1(EMH_severity_error,ITK_err,GCINametypeStr);
									decision = EPM_nogo;
									return decision;
								}
								if (DMUnotfoundflag==1)
								{

									printf("\n .............SOFT CHECK DMU CSV file....... \n");fflush(stdout);

									EMH_store_error_s1(EMH_severity_warning,ITK_err,DMUnametype1);
									decision = EPM_go;
									return decision;
								}
								

							}

						}
						}

					}

			    }

            }
		}

	}
	
return decision;
}

extern EPM_decision_t DLLAPI ProgScale_Validation (EPM_rule_message_t msg)
{

	
	EPM_decision_t decision = EPM_go;

    char* username			= NULL;
	char*CurrentTaskNam     =NULL;
	char*parent_nameprog    =NULL;
	char*childParentTaskNam    =NULL;
	char*dmlTaskNo=NULL;
	char*ProgDML=NULL;
	char*DMLReltypeProg=NULL;
	char*BusunitProg=NULL;
	char*Userinfodup=NULL;
	char*Userinfopdup=NULL;
	char*ProDMLSkip=NULL;
	char*PsPartNum=NULL;
	char*PsPartRev=NULL;
	char*PsParttype=NULL;
	char*PsPartStat=NULL;
	char*PsColInd=NULL;
	char*PsProgScale=NULL;
	int noAttachment=0;
	tag_t*attachments =NULLTAG;
	tag_t*Prog_object =NULLTAG;
	tag_t*BreakdowncountprogTags =NULLTAG;
	tag_t*ProgPartTags =NULLTAG;
	tag_t DMLTag=NULLTAG;
	tag_t DML_tag=NULLTAG;
	tag_t DMLproTag=NULLTAG;
	tag_t Progqry_tg=NULLTAG;
	tag_t PsPartTag=NULLTAG;

	tag_t rootTask =NULLTAG;
	tag_t objTypeTag =NULLTAG;
	//char  objTypeprog[WSO_name_size_c+1];
	char*  objTypeprog = NULL;
	int Progobj_count=0;
	int ProgSKIPflag=0;
	int ProgPASSFlag=0;
	int Breakdowncountprog=0;
	int p=0;
	int progpartcount=0;
	int ProgScaleNULL=0;
	int ProgScaleNOTFive=0;
	int sp=0;
	char*ProgScaleBuff=(char*)MEM_alloc(sizeof(char)*100);
	char*ProgScaleBuffFive=(char*)MEM_alloc(sizeof(char)*100);
	char*ProgramSclNull=(char*)MEM_alloc(sizeof(char)*200);
	char*ProgramSclNotFive=(char*)MEM_alloc(sizeof(char)*200);

    ITK_CALL(POM_get_user_id (&username));
    printf("\n Inside the ProgScale_Validation Session User is : %s \n",username); fflush(stdout);


	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	{

        ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n Inside the ProgScale_Validation ...\n");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTaskNam));
		printf("\n ProgScale_Validation- CurrentTask: %s \n",CurrentTaskNam);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&childParentTaskNam));
		printf("\n ProgScale_Validation- childParentTask: %s \n",childParentTaskNam);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_nameprog));
		printf("\n ProgScale_Validation- parent Name: %s \n",parent_nameprog);fflush(stdout);

		ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\n ProgScale_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);

        char *dmlNo =(char *) MEM_alloc(sizeof(char)* 50);
		if(noAttachment > 0)
		{

            printf("\n Inside for ProgScale_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);
			DMLTag = attachments[0];

			if(AOM_ask_value_string(DMLTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n ProgScale_Validation- DML No: [%s] \n", dmlTaskNo);fflush(stdout);

			if((tc_strcmp(parent_nameprog,"VC Task Release")==0) || (tc_strcmp(parent_nameprog,"CVBU VC Task Release")==0))
			{
                printf("\n vc task release task Name: [%s] \n", dmlNo);fflush(stdout); 

				dmlNo = tc_strtok(dmlTaskNo,"_");	
				printf("\n VC Task  DML No: [%s]\n",dmlNo);fflush(stdout);
			}

			if(ITEM_find_item(dmlNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{
                 printf("\n DML tag is not null for ProgScale_Validation- DML No: [%s] \n", dmlNo);fflush(stdout);

				if(ITEM_ask_latest_rev(DML_tag, &DMLproTag)!=ITK_ok)PrintErrorStack();

				ITK_CALL(AOM_ask_value_string(DMLproTag,"item_id",&ProgDML));
				printf("\n  item_id is %s\n", ProgDML);fflush(stdout);

		        ITK_CALL(TCTYPE_ask_object_type(DMLproTag,&objTypeTag));

				ITK_CALL(TCTYPE_ask_name2(objTypeTag,&objTypeprog));
				printf("\n  object_type is %s\n", objTypeprog);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(DMLproTag,"t5_rlstype",&DMLReltypeProg));
				printf("\n  t5_rlstype prog is : [%s]\n", DMLReltypeProg); fflush(stdout);

				ITK_CALL(AOM_ask_value_string(DMLproTag,"t5_ERCBusiUt",&BusunitProg));
				printf("\n  Busunit prog : [%s]\n", BusunitProg); fflush(stdout);

                if (tc_strcmp(objTypeprog,"ChangeRequestRevision")==0)
			    {
                    if(QRY_find2("Control Objects...", &Progqry_tg));

				    char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
					char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
					Progsc_RelVal[0] = "ProScl";
					Progsc_RelVal[1] = "ON";

					ITK_CALL(QRY_execute(Progqry_tg, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));

					printf("\n Query count for Prog form :[%d]\n",Progobj_count); fflush(stdout);

					if(Progobj_count>0)
					{

					   ITK_CALL(AOM_ask_value_string(Prog_object[0],"t5_Userinfo1",&Userinfodup));  
                       printf("\n userinfo1 prog :[%s]\n",Userinfodup); fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(Prog_object[0],"t5_Userinfo2",&Userinfopdup));  
                       printf("\n userinfo2 prog :[%s]\n",Userinfopdup); fflush(stdout);
					  
					   ProDMLSkip=(char *)MEM_alloc(50);
					   tc_strcpy(ProDMLSkip,"");
					   tc_strcpy(ProDMLSkip,",");
					   tc_strcat(ProDMLSkip,ProgDML);
					   tc_strcat(ProDMLSkip,",");

                       printf("\n ProgDMl skip:[%s]\n",ProDMLSkip); fflush(stdout);

					   if(tc_strstr(Userinfodup,ProDMLSkip)!=NULL)
					   {
						 ProgSKIPflag=1;
					   }
                        
						if(ProgSKIPflag>0)
						{
						  printf("\n skipping the ProgDML\n"); fflush(stdout);
						}
						else
						{

						 ProgPASSFlag=0;

						if(((tc_strcmp(BusunitProg,"CVBU")==0) || (tc_strcmp(BusunitProg,"PVBU")==0)) && (tc_strcmp(DMLReltypeProg,"Veh")==0) && (tc_strcmp(CurrentTaskNam,"Check for VC BOM from solution Items and Attach VOD")==0))
						{
                          
						   ProgPASSFlag=1;
						    
						}

						 printf("\n  ProgPASSFlag value is : [%d]\n", ProgPASSFlag); fflush(stdout);

						if(ProgPASSFlag>0)
						{

							printf("\n Inside PASSFlag........\n"); fflush(stdout);

							ITK_CALL(AOM_ask_value_tags(DMLproTag,"T5_DMLTaskRelation",&Breakdowncountprog,&BreakdowncountprogTags));

							if(Breakdowncountprog>0)
							{
								printf("\n Inside Breakdowncountprog[%d]........\n",Breakdowncountprog); fflush(stdout);

								for(p=0;p<Breakdowncountprog;p++)
								{
									printf("\n Inside Breakdowncountprog loop........\n"); fflush(stdout);

								    if(tc_strcmp(DMLReltypeProg,"Veh")==0)
									{
										printf("\n Inside dmltype Veh prog\n"); fflush(stdout);

										ITK_CALL(AOM_ask_value_tags(BreakdowncountprogTags[p],"CMHasSolutionItem",&progpartcount,&ProgPartTags));
										
										printf("\n No of Parts found for prog = %d\n",progpartcount);fflush(stdout);
									}

									if(progpartcount>0)
									{
                                        printf("\n Inside part count prog\n"); fflush(stdout);
                                        tc_strcpy(ProgScaleBuff,"");
                                        tc_strcpy(ProgScaleBuffFive,"");
										for(sp=0;sp<progpartcount;sp++)
										{
                                            printf("\n Inside part count prog loop\n"); fflush(stdout);

										    PsPartTag=ProgPartTags[sp];

										    ITK_CALL(AOM_ask_value_string(PsPartTag,"item_id",&PsPartNum));

											ITK_CALL(AOM_ask_value_string(PsPartTag,"item_revision_id",&PsPartRev));

											ITK_CALL(AOM_ask_value_string(PsPartTag,"t5_PartType",&PsParttype));

											ITK_CALL(AOM_ask_value_string(PsPartTag,"t5_PartStatus",&PsPartStat));

											ITK_CALL(AOM_ask_value_string(PsPartTag,"t5_ColourInd",&PsColInd));

											ITK_CALL(AOM_UIF_ask_value(PsPartTag,"t5_ProgramScale",&PsProgScale));

                                            printf("\nPart No-> %s, %s, %s, %s, %s, %s.\n",PsPartNum,PsPartRev,PsParttype,PsPartStat,PsColInd,PsProgScale);fflush(stdout);

											if(((tc_strcmp(PsParttype,"V")==0)||(tc_strcmp(PsParttype,"CCVC")==0)) && (tc_strcmp(PsColInd,"C")!=0) && (tc_strstr(Userinfopdup,PsPartStat)!=NULL))
											{
                                                printf("\n Inside the program scale check\n"); fflush(stdout);

												if(tc_strlen(PsProgScale) != 0)
												{
													printf("\n Inside the program scale Not NULL\n"); fflush(stdout);
													if(tc_strlen(PsProgScale)==5) 
													{
														printf("\n Inside the program scale five\n"); fflush(stdout);
                                                        printf("\n Inside the prog scale lenght:[%s]\n",PsProgScale); fflush(stdout); 
													}
													else
												    {
													printf("\n Inside the program scale Not five\n"); fflush(stdout);
													ProgScaleNOTFive=ProgScaleNOTFive+1;
                                                    tc_strcat(ProgScaleBuffFive,PsPartNum);
													tc_strcat(ProgScaleBuffFive,",");
													printf("\n ProgScaleNOTFive count :[%d] \n ",ProgScaleNOTFive);fflush(stdout);
                                                    
													}


												}
												else
												{
													printf("\n Inside the program scale NULL\n"); fflush(stdout);
													ProgScaleNULL=ProgScaleNULL+1;
                                                    tc_strcat(ProgScaleBuff,PsPartNum);
													tc_strcat(ProgScaleBuff,",");
													printf("\n ProgScaleNULL count :[%d] \n ",ProgScaleNULL);fflush(stdout);
                                                }

											
											}

                                    }
									printf("\n ProgScaleNULL total count :[%d] \n ",ProgScaleNULL);fflush(stdout);
									printf("\n ProgScaleNOTFive total count :[%d] \n ",ProgScaleNOTFive);fflush(stdout);


                                   }
                                       
								}
								if(ProgScaleNULL>0)
								{

									printf("\n ...........Program Scale NULL Hard check........... \n");fflush(stdout);
									tc_strcpy(ProgramSclNull,"");
							        tc_strcpy(ProgramSclNull,"Please update program scale for : ");
                                    tc_strcat(ProgramSclNull,ProgScaleBuff);
                                    tc_strcat(ProgramSclNull,", To update program scale, Select Revision, go to Tools-> Product Structure Classes-> Update Program Scale");


									EMH_store_error_s1(EMH_severity_error,ITK_err,ProgramSclNull);
									decision = EPM_nogo;
									return decision;
								}
								if(ProgScaleNOTFive>0)
								{

									printf("\n ...........Program Scale NOT FIVE Hard check........... \n");fflush(stdout);
									tc_strcpy(ProgramSclNotFive,"");
							        tc_strcpy(ProgramSclNotFive,"Please enter only five digit integer value for : ");
                                    tc_strcat(ProgramSclNotFive,ProgScaleBuffFive);
                                    tc_strcat(ProgramSclNotFive,", To update program scale, Select Revision, go to Tools-> Product Structure Classes-> Update Program Scale");


									EMH_store_error_s1(EMH_severity_error,ITK_err,ProgramSclNotFive);
									decision = EPM_nogo;
									return decision;
								}
								 
              }
            }
          }
        }
      }
    }
  }
}

        
return decision;
}

 extern DLLAPI int T5PartToDFQVal(METHOD_message_t *msg, va_list args)
{
int Status = ITK_ok;
int ifail = 0;
int Progobj_count = 0;
int i = 0;
tag_t object = va_arg(args, tag_t);
tag_t objTypedfq=NULLTAG;
tag_t objTypeSelect=NULLTAG;
tag_t secObjSelect=NULLTAG;
tag_t priObjTag=NULLTAG;
tag_t secObjTag=NULLTAG;
tag_t class_id=NULLTAG; 
tag_t* Prog_object=NULLTAG; 
char*class_name=NULL;
char*design_checkout=NULL;
char* username = NULL;
tag_t user_tag=NULLTAG;
tag_t Prog_object1=NULLTAG;
tag_t default_group_tag=NULLTAG;
tag_t Controlbj=NULLTAG;
tag_t role_tag=NULLTAG;
//char typedfq_name[TCTYPE_name_size_c+1];
char* typedfq_name =NULL;
//char type_nameSelect[TCTYPE_name_size_c+1];
char* type_nameSelect =NULL;
//char Secondary_type[TCTYPE_name_size_c+1];
char* Secondary_type =NULL;
char* Userinfodup =NULL;
char* rolename =NULL;


CALLAPI(POM_class_of_instance(object,&class_id));
CALLAPI(POM_name_of_class(class_id,&class_name));

printf("\n\nObject Classname dfq:%s\n",class_name);fflush(stdout);

    CALLAPI(POM_get_user(&username,&user_tag));

  // CALLAPI(SA_find_user2(UserID, &user_tag));
   //CALLAPI(SA_ask_user_login_group(user_tag, &default_group_tag));
   SA_ask_current_role(&role_tag);     
   SA_ask_role_name2(role_tag,&rolename);
    printf("\n Cutting of DVA Role Name is%s\n",rolename);fflush(stdout);
    printf("\n\n username *****:%s\n",username);fflush(stdout);

    if(TCTYPE_ask_object_type(object,&objTypeSelect));
	if(TCTYPE_ask_name2(objTypeSelect,&type_nameSelect));
	printf("\n T5PartToDFQVal--selected Object is :: %s\n", type_nameSelect);fflush(stdout);

	if (GRM_ask_primary(object,&priObjTag)!=ITK_ok);

	if (GRM_ask_secondary(object,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjSelect)!=ITK_ok);
	if (TCTYPE_ask_name2(secObjSelect,&Secondary_type)!=ITK_ok);
	printf("\n T5PartToDFQVal--T5PartToDFQVal::sec_type_name :%s\n", Secondary_type);fflush(stdout);

	if(QRY_find2("Control Objects...", &Controlbj));
	printf("\n Inside T5PartToCutting logic\n");fflush(stdout);

	char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	Progsc_RelVal[0] = "DVA_Check_Cut";
	Progsc_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(Controlbj, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
	printf("\n T5PartToCutting control object count :%d \n",Progobj_count);fflush(stdout);

	if(Progobj_count>0)  
	{

		Prog_object1=Prog_object[i];
		ITK_CALL(AOM_ask_value_string(Prog_object1,"t5_Userinfo1",&Userinfodup));  
        printf("\n userinfo1 DVA_Check_Cut:[%s]\n",Userinfodup); fflush(stdout);


//	if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0 || strcmp(username,"ab923373.ttl")==0 || strcmp(username,"Anvesh Bujule")==0 || strcmp(username,"mukteshg.ttl")==0 || strcmp(username,"Muktesh Girdhani")==0 || strcmp(username,"prasadb1.ttl")==0 || strcmp(username,"Prasad Bhide")==0 || strcmp(username,"gn923253.ttl")==0 || strcmp(username,"Gayathri Namboothiri")==0 )
//	{
//	printf("\n\n\t\t bypass for loader & infodba************** ==> %s\n", username);fflush(stdout);
//	}
     if(tc_strstr(Userinfodup,username)!=NULL || tc_strcmp(rolename,"Support_Role")==0)
	{

	 printf("\n DVA_Check_Cut bypass for loader & infodba %s\n", username);fflush(stdout);

	}
	else
	{
	  if(strcmp(type_nameSelect,"T5_DesignHasDVA")==0)
	  {
		   CALLAPI(TCTYPE_ask_object_type(priObjTag, &objTypedfq));
		   CALLAPI(TCTYPE_ask_name2(objTypedfq,&typedfq_name));

		   printf("\n T5PartToDVAVal--T5PartToDVAVal::primary obj type ==> %s\n", typedfq_name);fflush(stdout);

		  if(tc_strcmp(typedfq_name,"Design Revision")==0)
			{
			   CALLAPI(AOM_ask_value_string(priObjTag,"checked_out",&design_checkout));
						   
				if(tc_strcmp(design_checkout, "Y")!=0)
				 {
					 printf("\n Part is check out ==> %s \n", design_checkout);fflush(stdout);
					 EMH_store_error_s1(EMH_severity_error,ITK_err,"cutting of DVA document is not allowed from the module/TPL.");
					return ITK_err;
				 }
		   }
				   
			   

	 }
   }
	}
return ITK_ok;
}


 extern DLLAPI int T5PartToFourDVal(METHOD_message_t *msg, va_list args)
{
int Status = ITK_ok;
int ifail = 0;
int Progobj_count = 0;
int i = 0;
int n = 0;
int FourDvalidRelStus_cnt = 0;
tag_t object = va_arg(args, tag_t);
tag_t objTypedfq=NULLTAG;
tag_t objTypeSelect=NULLTAG;
tag_t secObjSelect=NULLTAG;
tag_t priObjTag=NULLTAG;
tag_t secObjTag=NULLTAG;
tag_t class_id=NULLTAG; 
tag_t* Prog_object=NULLTAG; 
tag_t* FourDvalidRelStusTg=NULLTAG; 
char*class_name=NULL;
char*design_checkout=NULL;
char* username = NULL;
tag_t user_tag=NULLTAG;
tag_t Prog_object1=NULLTAG;
tag_t default_group_tag=NULLTAG;
tag_t Controlbj=NULLTAG;
tag_t role_tag=NULLTAG;

char* typedfq_name =NULL;
char* FourDvalidPrtRelStus =NULL;

char* type_nameSelect =NULL;

char* Secondary_type =NULL;
char* Userinfodup =NULL;
char* rolename =NULL;


CALLAPI(POM_class_of_instance(object,&class_id));
CALLAPI(POM_name_of_class(class_id,&class_name));

printf("\n\nObject Classname dfq:%s\n",class_name);fflush(stdout);

    CALLAPI(POM_get_user(&username,&user_tag));

  // CALLAPI(SA_find_user2(UserID, &user_tag));
   //CALLAPI(SA_ask_user_login_group(user_tag, &default_group_tag));
   SA_ask_current_role(&role_tag);     
   SA_ask_role_name2(role_tag,&rolename);
    printf("\n Cutting of FourD Role Name is%s\n",rolename);fflush(stdout);
    printf("\n\n FourD username *****:%s\n",username);fflush(stdout);

    if(TCTYPE_ask_object_type(object,&objTypeSelect));
	if(TCTYPE_ask_name2(objTypeSelect,&type_nameSelect));
	printf("\n FourD--selected Object is :: %s\n", type_nameSelect);fflush(stdout);

	if (GRM_ask_primary(object,&priObjTag)!=ITK_ok);
     CALLAPI(TCTYPE_ask_object_type(priObjTag, &objTypedfq));
	if (GRM_ask_secondary(object,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjSelect)!=ITK_ok);
	if (TCTYPE_ask_name2(secObjSelect,&Secondary_type)!=ITK_ok);
	printf("\n FourD::sec_type_name :%s\n", Secondary_type);fflush(stdout);

	if(QRY_find2("Control Objects...", &Controlbj));
	printf("\n Inside FourD logic\n");fflush(stdout);

	char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	Progsc_RelVal[0] = "FourD_Check_Cut";
	Progsc_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(Controlbj, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
	printf("\n FourD control object count :%d \n",Progobj_count);fflush(stdout);

	if(Progobj_count>0)
	{

		Prog_object1=Prog_object[i];
		ITK_CALL(AOM_ask_value_string(Prog_object1,"t5_Userinfo1",&Userinfodup));  
        printf("\n userinfo1 FourD:[%s]\n",Userinfodup); fflush(stdout);

	
					ITK_CALL(AOM_UIF_ask_value(priObjTag,"release_status_list",&FourDvalidPrtRelStus));
					printf("\n Cut T5PartToFourDvalid:PrtRelStus is: %s.",FourDvalidPrtRelStus);fflush(stdout);
					if(tc_strstr(FourDvalidPrtRelStus,"T5_LcsErcRlzd")!= NULL || tc_strstr(FourDvalidPrtRelStus,"ERC Released")!=NULL)
					{

						 if(tc_strstr(Userinfodup,username)!=NULL || tc_strcmp(rolename,"Support_Role")==0)
						{

						 printf("\n FourD_Cut bypass for loader & infodba %s\n", username);fflush(stdout);

						}
						else
						{
								  if(strcmp(type_nameSelect,"T5_PartHas4D")==0 || strcmp(type_nameSelect,"T5_PartHasRef4DDfmea")==0)
								  {
									  
									   CALLAPI(TCTYPE_ask_name2(objTypedfq,&typedfq_name));

									   printf("\n FourD::primary obj type ==> %s\n", typedfq_name);fflush(stdout);

									  if(tc_strcmp(typedfq_name,"Design Revision")==0)
									  {
										   
												 
										 EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released, hence cut action not allowed for 4D documents. If part is applicable for 4D feedback as per 4D document applicability matrix, then kindly raise the 4D feedback request in Gen4D system. For any other query contact to 4D support team.");
										 return ITK_err;
								 
									  }
											   
								 }


						 }
					}
			 



			
	}
return ITK_ok;
}
extern DLLAPI int T5DfqDatesetStop(METHOD_message_t *msg, va_list args)
{     
	va_list largs;
	va_copy( largs, args );
    int Status = ITK_ok;
    int ifail = 0;
    int Progobj_count = 0;
    int i = 0;
    tag_t object = va_arg(args, tag_t);
    tag_t objTypedfq=NULLTAG;
    tag_t objTypeSelect=NULLTAG;
    tag_t secObjSelect=NULLTAG;
    tag_t priObjTag=NULLTAG;
    tag_t secObjTag=NULLTAG;
	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
    tag_t class_id=NULLTAG; 
    tag_t* Prog_object=NULLTAG; 
    char*class_name=NULL;
    char*design_checkout=NULL;
    char* username = NULL;
    tag_t user_tag=NULLTAG;
    tag_t Prog_object1=NULLTAG;
    tag_t default_group_tag=NULLTAG;
    tag_t Controlbj=NULLTAG;
    tag_t role_tag=NULLTAG;
    char* typedfq_name =NULL;
    char* type_nameSelect =NULL;
    char* Secondary_type =NULL;
    char* Userinfodup =NULL;
    char* rolename =NULL;
	tag_t objTypeTag1=NULLTAG;
	char *type_name=NULL;
	tag_t objTypeTag2=NULLTAG;
	char *secndry_obj_type_name=NULL;
	char *relation_name=NULL;
    
    printf("\nDFQ dateset stop::");
    CALLAPI(POM_class_of_instance(object,&class_id));
    CALLAPI(POM_name_of_class(class_id,&class_name));  
    printf("\n\nObject Classname dfq:%s\n",class_name);fflush(stdout);  
    CALLAPI(POM_get_user(&username,&user_tag));
    SA_ask_current_role(&role_tag);     
    SA_ask_role_name2(role_tag,&rolename);
    printf("\nDFQ dateset stop:: is%s\n",rolename);fflush(stdout);
    printf("\n\n username *****:%s\n",username);fflush(stdout);
    ITK_CALL(TCTYPE_ask_object_type ( primary_object, &objTypeTag1 ) ) ;
	ITK_CALL(TCTYPE_ask_name2 ( objTypeTag1, &type_name ) ) ;
	ITK_CALL(TCTYPE_ask_object_type ( secondary_object, &objTypeTag2 ) ) ;
	ITK_CALL(TCTYPE_ask_name2 ( objTypeTag2, &secndry_obj_type_name ) ) ;
	ITK_CALL(TCTYPE_ask_name2 ( relation_type, &relation_name ) ) ;
	printf("DFQ dateset stop::type_name %s\n",type_name);
	printf("DFQ dateset stop::secndry_obj_type_name %s\n",secndry_obj_type_name);
	printf("DFQ dateset stop::relation_name %s\n",relation_name);
	if(QRY_find2("Control Objects...", &Controlbj));
	printf("\n Inside DFQ dateset stop:: logic\n");fflush(stdout);
	char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	Progsc_RelVal[0] = "DFQDataSet_Stop";
	Progsc_RelVal[1] = "ON";  
	ITK_CALL(QRY_execute(Controlbj, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
	printf("\n DFQ dateset stop:: control object count :%d \n",Progobj_count);fflush(stdout);
	if(Progobj_count>0)
	{
		Prog_object1=Prog_object[i];
		ITK_CALL(AOM_ask_value_string(Prog_object1,"t5_Userinfo1",&Userinfodup));  
        printf("\n userinfo1 DFQ dateset stop ::[%s]\n",Userinfodup); fflush(stdout);
     if(tc_strstr(Userinfodup,username)!=NULL || tc_strcmp(rolename,"Support_Role")==0)
	{

	 printf("\n DFQ dateset stop:: bypass for loader & infodba %s\n", username);fflush(stdout);

	}
	else
	{
	  if(strcmp(relation_name,"T5_DesignHasDVA")==0)
	  {
		  

		  printf("\n T5PartToDVAVal--T5PartToDVAVal::primary obj type ==> %s\n", type_name);fflush(stdout);
		  if(tc_strcmp(type_name,"Design Revision")==0 && tc_strcmp(secndry_obj_type_name,"T5_dfqdataset")==0)
			{			   
					 EMH_clear_errors();
					 EMH_store_error_s1(EMH_severity_error,ITK_err,"Not allowed to create the relation with DFQ Dataset.");
					return ITK_err;
		    }
	 }
   }
	}  

	return ITK_ok;
}  


 extern DLLAPI int T5PartToRendering(METHOD_message_t *msg, va_list args)
{
int Status = ITK_ok;
int ifail = 0;
int Progobj_count = 0;
tag_t object = va_arg(args, tag_t);
tag_t objTypedfq=NULLTAG;
tag_t Prog_object1=NULLTAG;
tag_t objTypeSelect=NULLTAG;
tag_t secObjSelect=NULLTAG;
tag_t priObjTag=NULLTAG;
tag_t secObjTag=NULLTAG;
tag_t class_id=NULLTAG; 
tag_t Progqry_tg=NULLTAG; 
tag_t* Prog_object=NULLTAG; 
char*class_name=NULL;
char*design_checkout=NULL;
char* username = NULL;
tag_t user_tag=NULLTAG;
//char typedfq_name[TCTYPE_name_size_c+1];
char* typedfq_name =NULL;
//char type_nameSelect[TCTYPE_name_size_c+1];
char* type_nameSelect =NULL;
//char Secondary_type[TCTYPE_name_size_c+1];
char* Secondary_type =NULL;
char* Userinfodup =NULL;
int i=0;


CALLAPI(POM_class_of_instance(object,&class_id));
CALLAPI(POM_name_of_class(class_id,&class_name));

printf("\n\nObject Classname T5PartToRendering:%s\n",class_name);fflush(stdout);

CALLAPI(POM_get_user(&username,&user_tag));

printf("\n\n username T5PartToRendering***1111111111**:%s\n",username);fflush(stdout);

    if(TCTYPE_ask_object_type(object,&objTypeSelect));
	if(TCTYPE_ask_name2(objTypeSelect,&type_nameSelect));
	printf("\n T5PartToRendering--selected Object is :: %s\n", type_nameSelect);fflush(stdout);

	if (GRM_ask_primary(object,&priObjTag)!=ITK_ok);

	if (GRM_ask_secondary(object,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjSelect)!=ITK_ok);
	if (TCTYPE_ask_name2(secObjSelect,&Secondary_type)!=ITK_ok);
	printf("\n T5PartToRendering--T5PartToRendering::sec_type_name :%s\n", Secondary_type);fflush(stdout);
	if(QRY_find2("Control Objects...", &Progqry_tg));
	printf("\n Inside T5PartToRendering logic\n");fflush(stdout);

	char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	Progsc_RelVal[0] = "Ren_Check";
	Progsc_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(Progqry_tg, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
	printf("\n\n T5PartToRendering control object count1 :%d \n",Progobj_count);fflush(stdout);

 
    if(Progobj_count>0)
	{

		for(i=0; i<Progobj_count; i++)
		{

		  Prog_object1=Prog_object[i];
		  ITK_CALL(AOM_ask_value_string(Prog_object1,"t5_Userinfo1",&Userinfodup));  
          printf("\n userinfo1 T5PartToRendering :[%s]\n",Userinfodup); fflush(stdout);


		
		if(tc_strstr(Userinfodup,username)!=NULL)
		{
		printf("\n Progobj_count bypass for loader & infodba %s\n", username);fflush(stdout);
		}
		else
		{
			  if(strcmp(type_nameSelect,"IMAN_Rendering")==0)
			  {
				   CALLAPI(TCTYPE_ask_object_type(priObjTag, &objTypedfq));
				   CALLAPI(TCTYPE_ask_name2(objTypedfq,&typedfq_name));

				   printf("\n Relation Type name is %s\n", typedfq_name);fflush(stdout);
				   printf("\n Secondary_type name is :%s\n", Secondary_type);fflush(stdout);

					if(tc_strcmp(typedfq_name,"Design Revision")==0)
					{
					   
					   if(tc_strcmp(Secondary_type,"DirectModel")==0)
						{
						  printf("\n Inside cutting of Rendering111111111111\n");fflush(stdout);
						  EMH_store_error_s1(EMH_severity_error,ITK_err,"cutting of Rendering relation is not allowed.");
						  return ITK_err;
						}
						else
						{
							printf("\n Inside other dataset\n");fflush(stdout);
						
						}
						 
				    }
						   
					   

			  }
		}

		}
	}

return ITK_ok;
}

int FourDCheckoutvalidation(tag_t object_tag)
{

        tag_t class_id		=  NULLTAG;
        tag_t role_tag		=  NULLTAG;
	   char*class_name		   = NULL;

	   	char* username = NULL;
		tag_t user_tag=NULLTAG;
		tag_t Prog_object1=NULLTAG;
		tag_t Progqry_tg=NULLTAG;
		tag_t* Prog_object=NULLTAG;
		tag_t	Dfq_relation_type;                           
		int		Dfq_allow_chkout	= 1;
		char *Dfqis_chkout=NULL;
		char * Dfq_ObjectClassType = NULL;
		char * Userinfodup = NULL;
		char* objecttype = NULL;
		char* rolename = NULL;
		//int Status = ITK_ok;
        int ifail = 0;
        int Progobj_count = 0;
		int i=0;


		if(QRY_find2("Control Objects...", &Progqry_tg));
		printf("\n Inside FourD check-out logic\n");fflush(stdout);

		char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		Progsc_RelVal[0] = "FourD_Checkout";
		Progsc_RelVal[1] = "ON";

	   SA_ask_current_role(&role_tag);     
       SA_ask_role_name2(role_tag,&rolename);
       printf("\n Check-Out of FourD Role Name is%s\n",rolename);fflush(stdout);
       printf("\n FourD Check-Out username *****:%s\n",username);fflush(stdout);

		ITK_CALL(QRY_execute(Progqry_tg, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
		printf("\n FourD_Checkout control object count1 :%d \n",Progobj_count);fflush(stdout);

		if(Progobj_count>0)
	    {

			
		Prog_object1=Prog_object[i];
		ITK_CALL(AOM_ask_value_string(Prog_object1,"t5_Userinfo1",&Userinfodup));  
		printf("\n userinfo1 FourD_Checkout:[%s]\n",Userinfodup); fflush(stdout);


		CALLAPI(POM_class_of_instance(object_tag,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		CALLAPI(AOM_ask_value_string(object_tag,"object_type",&objecttype));
		printf("\n FourD file objecttype  :%s\n",objecttype);fflush(stdout);
		



		if(strcmp(objecttype,"T5_DADDocRevision")==0 || strcmp(objecttype,"T5_DADClsRevision")==0)
	    { 


	          CALLAPI(POM_get_user(&username,&user_tag));
		      printf("\n FourD username :%s\n",username);fflush(stdout);
       

				 if(tc_strstr(Userinfodup,username)!=NULL || tc_strcmp(rolename,"Support_Role")==0)
				 {

					 printf("\n FourD Check-out bypass for loader & infodba %s\n", username);fflush(stdout);

				 }
				else
				{

					printf("\n FourD Inside else condition \n");fflush(stdout);
					 
					if( AOM_ask_value_string(object_tag,"checked_out",&Dfqis_chkout)==ITK_ok)
					 {
						if(strcmp(Dfqis_chkout,"Y")!=0)
						{
							Dfq_allow_chkout = 0;
							printf("\n FourD Inside checkout condition \n");fflush(stdout);

						}
					 }
				
				
				}
				printf("\n ForuD_allow_chkout value is \n",Dfq_allow_chkout);fflush(stdout);


				if(Dfq_allow_chkout==0)
				{
						printf("\n Inside FourD checkout condition \n");fflush(stdout);
						if(strcmp(objecttype,"T5_DADDocRevision")==0)
						{
							printf("\n Inside checkout DAD Doc error condition \n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-out action not allowed for 4D documents. For any further query contact to 4D support team.");
							return ITK_err;
						}
						else if(strcmp(objecttype,"T5_DADClsRevision")==0)
						{
								printf("\n Inside checkout 4D Clauses error condition \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-out action not allowed for 4D Clauses documents. For any further query contact to 4D support team.");
								return ITK_err;
						
						}
						
				}
			  


		}
		else
		{
		   printf("\n Inside else  error condition 4D Clauses Rev / DAD Doc Revision  \n");fflush(stdout);
		
		
		}
	}


       return ITK_ok;

}

int GCICheckoutvalidation(tag_t object_tag)
{

       tag_t class_id		=  NULLTAG;
	   char*class_name		   = NULL;

	   	char* username = NULL;
		tag_t user_tag=NULLTAG;
		tag_t Progqry_tg=NULLTAG;
		tag_t* Prog_object=NULLTAG;
		tag_t	Dfq_relation_type;                           
		int		Dfq_allow_chkout	= 1;
		char *Dfqis_chkout=NULL;
		char * Dfq_ObjectClassType = NULL;
		char* objecttype = NULL;
		//int Status = ITK_ok;
        int ifail = 0;
        int Progobj_count = 0;


		if(QRY_find2("Control Objects...", &Progqry_tg));
		printf("\n Inside GCI check-in check-out logic\n");fflush(stdout);

		char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		Progsc_RelVal[0] = "GCI_Check";
		Progsc_RelVal[1] = "ON";

		ITK_CALL(QRY_execute(Progqry_tg, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
		printf("\n\n GCI_Document control object count1 :%d \n",Progobj_count);fflush(stdout);

		if(Progobj_count>0)
	    {



        CALLAPI(POM_class_of_instance(object_tag,&class_id));

        CALLAPI(POM_name_of_class(class_id,&class_name));
		 CALLAPI(AOM_ask_value_string(object_tag,"object_type",&objecttype));
		 printf("\n GCI file objecttype  :%s\n",objecttype);fflush(stdout);
		printf("\n\n username :%s\n",class_name);fflush(stdout);



		if(strcmp(objecttype,"T5_GCI_Document")==0 || strcmp(objecttype,"T5_DFQ_UseCase")==0)
	    { 


	    CALLAPI(POM_get_user(&username,&user_tag));
		printf("\n\n username :%s\n",username);fflush(stdout);

		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0 || strcmp(username,"mam.ttl")==0 ||  strcmp(username,"Mohammad Asif")==0 )
		{
			 printf("\n\n\t\t bypass for loader & infodba ==> %s\n", username);fflush(stdout);
		}
		else
		{

			printf("\n Inside else condition \n");fflush(stdout);


			 
			if( AOM_ask_value_string(object_tag,"checked_out",&Dfqis_chkout)==ITK_ok)
			 {
				if(strcmp(Dfqis_chkout,"Y")!=0)
				{
					Dfq_allow_chkout = 0;
					printf("\n Inside checkout condition \n");fflush(stdout);

				}
			 }
		
		
		
		}
		printf("\n Dfq_allow_chkout value is \n",Dfq_allow_chkout);fflush(stdout);


		if(Dfq_allow_chkout==0)
		{
			    printf("\n Inside checkout error1 condition \n");fflush(stdout);
				if(strcmp(objecttype,"T5_GCI_Document")==0)
				{
					printf("\n Inside checkout T5_GCI_Document error condition \n");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-Out GCI Document is not allowed.");
					return ITK_err;
				}
				else if( strcmp(objecttype,"T5_DFQ_UseCase")==0)
			    {
						printf("\n Inside checkout T5_DFQ_UseCase error condition \n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-Out DVA Use Case is not allowed.");
						return ITK_err;
				
				}
		}


		}
		else
		{
		   printf("\n Inside else  error condition T5_GCI_Document/T5_DFQ_UseCase \n");fflush(stdout);
		
		
		}
	}


       return ITK_ok;
 
}
//Add release status DVA Document in MDM DML Processs
int checkDMLRelzStatus(tag_t DsnRev,int *mdmCount)
{
	tag_t dmltask=NULL;
	int dmltaskcount=0;
	tag_t *dmltaskarray=NULLTAG;
	int l=0;
	tag_t dmltasktag=NULLTAG;
	char *obj_type2=NULL;
	char *DesRevitemId=NULL;
	tag_t dmlrevision=NULLTAG;
	int dmlrevisioncount=0;
	tag_t *dmlrevisionarray=NULLTAG;
	int m=0;
	tag_t dmlrevisionatag=NULLTAG;
	char *obj_type3=NULL;
	char *dmlRevisionid=NULL;
	char *reltype=NULL;
	int mdmCount1=0; 
	
    //Check Design Revision attach with DML type "MDM DML for 4D/DVA Document Attachment"//

      ITK_CALL(GRM_find_relation_type("CMReferences",&dmltask));
      ITK_CALL(GRM_list_primary_objects_only(DsnRev,dmltask,&dmltaskcount,&dmltaskarray));
      if(dmltaskcount>0)
      {
    	  for(l=0;l<dmltaskcount;l++)
    	  {
              dmltasktag=dmltaskarray[l];
    		  if(AOM_UIF_ask_value(dmltasktag,"object_type",&obj_type2));
    		  printf("\n ~DML Task Type~ %s",obj_type2);
    		  if(tc_strcmp(obj_type2,"ERC Task Revision")==0)
    		  {
    		   if(AOM_UIF_ask_value(dmltasktag,"item_id",&DesRevitemId));
               printf("\n~DML Task Revision Name~%s",DesRevitemId);
    		   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&dmlrevision));
    		   ITK_CALL(GRM_list_primary_objects_only(dmltasktag,dmlrevision,&dmlrevisioncount,&dmlrevisionarray));
    		   for(m=0;m<dmlrevisioncount;m++)
    		   {
       	        dmlrevisionatag=dmlrevisionarray[m];
                ITK_CALL(AOM_UIF_ask_value(dmlrevisionatag,"object_type",&obj_type3)); 
    			ITK_CALL(AOM_UIF_ask_value(dmlrevisionatag,"item_id",&dmlRevisionid)); 
       	        if(tc_strcmp(obj_type3,"ERC DML Revision")==0)
       	        {
       		        ITK_CALL(AOM_UIF_ask_value(dmlrevisionatag,"t5_rlstype",&reltype));
       		        printf("\n~ DML Rel type ~ %s ",reltype);
    				if(tc_strcmp(reltype,"MDM DML for 4D/DVA Document Attachment")==0)
				{
					mdmCount1=1;
					*mdmCount=mdmCount1;
					printf("\n~ MDM DML for DVA Document found");
				}
				else
				{
					printf("\n ~ Release type is not 4D/DVA Document Attachment");
				}
       	        }
    		   }
    		  }
    	  }
     }
   return 0;
                     //End the code 17-04-2026
}


int checkindfqvalidation(tag_t object_tag)
{

	//tag_t		   primary_object	= NULLTAG;
	//tag_t	 	   object_tag		= va_arg (args, tag_t);
    int	ifail = 0;
	//int status = 0;
	int nFoundpdf= 0;
	int addflag2 = 0;
	int PdfCnt = 0;
	int Pdvacount = 0;
	int applicabilitydup = 0;
	int i = 0;
	int DRSTATUSFlag = 0;
	int addflag1 = 0;
	int Progobj_count = 0;

	char* dfq_object_name  = NULL;
	char* documentNameS2   = NULL;
	char* documentNameS1   = NULL;
	char* PdfNameS2        = NULL;
	char* username         = NULL;
	char*class_name		   = NULL;
	char*object_name2	   = NULL;
	char*t5_dfq_commentS   = NULL;
	char*DRStatus		   = NULL;
	char*partTypeS		   = NULL;

	tag_t user_tag      =  NULLTAG;
	tag_t class_id		=  NULLTAG;
	tag_t DVARelation		=  NULLTAG;
	tag_t PDVATag		=  NULLTAG;
	tag_t DVAqry_tg		=  NULLTAG;

	tag_t* refobjpdf  = NULLTAG;
	tag_t* PDVATags  = NULLTAG;
	tag_t* Prog_object  = NULLTAG;
	int mdmCount=0;


	documentNameS2=(char*)MEM_alloc(sizeof(char)*200);
	documentNameS1=(char*)MEM_alloc(sizeof(char)*200);
	PdfNameS2=(char*)MEM_alloc(sizeof(char)*200);

	logical t5_dfq_applicability_logical1;
	 //int t5_dfq_applicability_logical1 =0;

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));


	if(strcmp(class_name,"T5_DFQ_Document")==0)
	{



		if(QRY_find2("Control Objects...", &DVAqry_tg));

		char *DVA_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **DVA_Checkin_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		DVA_Checkin_RelVal[0] = "DVA_Checkin";
		DVA_Checkin_RelVal[1] = "ON";

		ITK_CALL(QRY_execute(DVAqry_tg, 2, DVA_entry1, DVA_Checkin_RelVal, &Progobj_count, &Prog_object));
		printf("\n DVA_Checkin_RelVal Query count is :[%d]\n",Progobj_count); fflush(stdout);

		if(Progobj_count>0)
		{

		//printf("\n Query count for Prog form :[%d]\n",Progobj_count); fflush(stdout);

		 printf("\n Inside the function of checking.......\n");fflush(stdout);

        CALLAPI(POM_get_user(&username,&user_tag));
		printf("\n\n username :%s\n",username);fflush(stdout);  

		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0 || strcmp(username,"Ajay Mali")==0 ||  strcmp(username,"amm08983")==0 ||  strcmp(username,"mam.ttl")==0 || strcmp(username,"Mohammad Asif")==0 || strcmp(username,"mukteshg.ttl")==0 || strcmp(username,"Muktesh Girdhani")==0 || strcmp(username,"prasadb1.ttl")==0 || strcmp(username,"Prasad Bhide")==0 || strcmp(username,"pramodk1.ttl")==0 || strcmp(username,"Pramod Koshti")==0)
		{
			 printf("\n\n\t\t bypass for loader & infodba ==> %s\n", username);fflush(stdout);
		}
		else
		{
			printf("\n Inside else condition of checkin.......\n");fflush(stdout);

			AOM_ask_value_logical(object_tag,"t5_DFQApplicablility",&t5_dfq_applicability_logical1);
			applicabilitydup = t5_dfq_applicability_logical1;

			printf("\n\n The value of applicabilitydup is :%d\n",applicabilitydup);fflush(stdout);
			printf("\n\n The value of logical is :%d\n",t5_dfq_applicability_logical1);fflush(stdout);
			//printf("\n\n The value of logical is :%s\n",t5_dfq_applicability_logical1);fflush(stdout);

			//applicabilitydup = t5_dfq_applicability_logical1;
			//printf("\n\n The value of applicabilitydup is :%d\n",applicabilitydup);fflush(stdout);

			if(applicabilitydup != 0)
			{
				AOM_ask_value_string(object_tag,"object_name",&dfq_object_name);
				printf("dfq_object_name 2::%s\n",dfq_object_name);fflush(stdout); 
				printf("\n Applicability true found sucessfully.......\n");fflush(stdout);

				AE_ask_all_dataset_named_refs2(object_tag,"T5_DFQ_PDF",&nFoundpdf,&refobjpdf);    //Code Change

                printf("\n\n The nFoundpdf is :%d\n",nFoundpdf);fflush(stdout);
                ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&DVARelation));

				if(DVARelation!=NULLTAG)
				{

                 if(GRM_list_primary_objects_only(object_tag,DVARelation,&Pdvacount,&PDVATags));

				 if(Pdvacount>0)
				 {
					 for (i=0; i<Pdvacount; i++)
					 {
						 PDVATag = PDVATags[i];

						 AOM_ask_value_string(PDVATag,"t5_PartType",&partTypeS);
	                     printf("\n Part Type is ----> -%s\n",partTypeS);fflush(stdout);

	                     AOM_ask_value_string(PDVATag,"t5_PartStatus",&DRStatus);
	                     printf("\n DR Status is ----> %s\n",DRStatus);fflush(stdout);

						if (tc_strcmp(DRStatus,"DR3") ==0 || tc_strcmp(DRStatus,"AR3")==0) 
						{						
							DRSTATUSFlag =1;
							AOM_ask_value_string(PDVATag,"object_name",&object_name2);
	                        printf("\n Object name of DVA Document ----> -%s\n",object_name2);fflush(stdout);
							printf("\n Inside the DR3 condition individuall check-in \n");fflush(stdout);
						} 
					 }
				 
				 }



				}
				if(DRSTATUSFlag==1)
				{
					tc_strcpy(documentNameS2,"");
				    tc_strcat(documentNameS2,dfq_object_name);
					
				
				}
				//documentNameS2=(char*)MEM_alloc(sizeof(char)*100);
	            				
				if(nFoundpdf >= 2)
				{	
					printf("\n Inside pdf count more than one.......\n");fflush(stdout);
					PdfCnt=1;
					
					if(PdfCnt==1)
					{
						tc_strcpy(PdfNameS2,"");

						tc_strcat(PdfNameS2,dfq_object_name);
						
					}
					printf("*** Only one PDF file should be attached to DFQ Document555555 %s ********** \n",PdfNameS2);fflush(stdout);
			    }
				if(strlen(PdfNameS2) > 0)
				{
					printf("*** Hard check Only one PDF file should be attached to DFQ Document555555 %s *** \n",PdfNameS2);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,ITK_err," Please keep only one pdf in named reference of DVA Document. ", PdfNameS2);
					return ITK_err;
				}

				if(nFoundpdf == 0)
				{
					printf("\n Inside pdf count Zero.......\n");fflush(stdout);

					if(strlen(documentNameS2) > 0)
					{
						printf("*** Upload Sign off DVA report PDF under DFQ Document indivduall check-in 55555555 %s *** \n",documentNameS2);fflush(stdout);

						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Upload Sign off DVA report PDF under DVA Document ", documentNameS2);
						return ITK_err;
					}
				}
		    }
			else
			{
			  printf("\n Inside else condtion of applicability false.......\n");fflush(stdout);

			  AOM_ask_value_string(object_tag,"t5_DFQComment",&t5_dfq_commentS);
			  printf("\n DVA Document Comment :----> %s\n",t5_dfq_commentS);fflush(stdout);

				if(tc_strlen(t5_dfq_commentS) < 15 )
				{
					addflag1++;
					if(addflag1==1)
					{
						tc_strcpy(documentNameS1,"");
						tc_strcat(documentNameS1,dfq_object_name);
						tc_strcat(documentNameS1,",");
					}
					else
					{
						tc_strcat(documentNameS1,dfq_object_name);
						tc_strcat(documentNameS1,",");
					}

					printf("*** Please Fill Comment at least 15 characters against DFQ Document %s having DFQ Applicabiity as FALSE  55555*** \n",documentNameS1);fflush(stdout);
				}

				if(strlen(documentNameS1) > 0)
				{
					printf("*** Provide DVA Justification Comment at least 15 characters against DFQ Document, if DFQ Applicability set to False for while individually checkin555555 %s *** \n",documentNameS1);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,ITK_err,"Provide DVA Justification Comment at least 15 characters against DVA Document, if DVA Applicability set to False for ", documentNameS1);
					return ITK_err;
				}
			
			}

			//MDM DML DVA Document release process
			tag_t DVARelation1=NULLTAG;
			int Pdvacount1=0;
			tag_t *PDVATags1=NULLTAG;
			int m=0;
			tag_t PDVATag1=NULLTAG;
			int mdmCount=0;
			tag_t status_relDVA=NULLTAG;
			char *relstatDVA=NULL;
			logical retain_released_dateDVA = TRUE;
			    ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&DVARelation1));
				if(DVARelation1!=NULLTAG)
				{

                 if(GRM_list_primary_objects_only(object_tag,DVARelation1,&Pdvacount1,&PDVATags1));

				 if(Pdvacount1>0)
				 {
					 for (m=0; m<Pdvacount1; m++)  
					 {
						PDVATag1 = PDVATags1[m];
                        checkDMLRelzStatus(PDVATag1, &mdmCount);
						printf("\n ~ DVA MDM relz status count %d",mdmCount);     
					 }
				 
				 }  
				}

				if(mdmCount==1)
			    {
                CALLAPI ( RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relDVA));
				CALLAPI(AOM_UIF_ask_value(object_tag,"release_status_list",&relstatDVA));
				printf("\n mdmdml dva document released stamped:%s ",relstatDVA);fflush(stdout);				
				if((strstr(relstatDVA,"ERC Released")!=NULL)|| (strstr(relstatDVA,"T5_LcsErcRlzd")!=NULL))
				{
					printf("\n Already found released relstatDVA, so skipped...\n");  fflush(stdout);
				}
				else
				{
					CALLAPI(RELSTAT_add_release_status(status_relDVA,1,&object_tag,retain_released_dateDVA));
				}
			    }

		} 
		

	}


	}
	return 0;

}



dvacreate(char* DVA_project_Code,char* sItemId,char* revid)
{


	logical t5_dfq_applicability_logical = 0;
	int status = 0;
	int k = 0;
	int j = 0;
	int n_entries = 1;
	int number_of_types1 = 0;
	int sec_result_count = 0;
	int create_document = 0;
	int resultCount1 = 0;
	int resultCount2 = 0;
	int incremental_value = 0;
	int incremental_value_latest = 0;
	tag_t *dfq_use_case_tags = NULLTAG;
	tag_t *dfq_document_dataset_tags = NULLTAG;
	tag_t *available_dfq_document_tags = NULLTAG;
	tag_t *proj_tags = NULLTAG;
	tag_t object_create_input_tag3 = NULLTAG;
	tag_t docTag = NULLTAG;
	tag_t relTypeTag = NULLTAG;
	tag_t relTag = NULLTAG;
	tag_t user_data_tag = NULLTAG;
	tag_t *type_tag3 = NULLTAG;
	char* documentNameS = NULL;
	char* documentName1S = NULL;
	char* partTypeS = NULL;
	char* checkedOutS = NULL;
	char* moduleAddressS = NULL;
	char* dfq_use_case_uid = NULL;
	char* dfq_available_doc_uid = NULL;
	char* dfq_use_case_desc = NULL;
	char* documentName = NULL;
	char* dfq_dataset_incremental_value = NULL;
	
	char* t5_projectc_code_string = NULL;
	char* t5_business_unit_type = NULL;
	char* t5_business_unit_type_mod = NULL;
	//char* sItemId = NULL;
	char* destinationExcelPathS = NULL;
	char* command = NULL;
	char* dfq_use_case = NULL;
	//char* DVA_project_Code = NULL;
	char *s=NULL;
	char * DFQ_Project_Code=NULL;
	char * DFQ_Project_Code2=NULL;
	char * DVA_project_Codedup=NULL;
	char * moduleAdd = NULL;
	char * designgrp = NULL;
	char * Parttype  =NULL;
	char *partNumber =NULL;
    char *DesignGrp13=NULL;
    char *subGroup   =NULL;
	

	char searchEntry1 [1][30] = {"Dataset Name"};

	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char ** qry_entries1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));

	moduleAddressS = (char *)MEM_alloc(100);

	tag_t itemTAG			= NULLTAG;
    tag_t itemRevTAG		= NULLTAG;
	tag_t queryTag			= NULLTAG;
	tag_t		newFileTag	= NULLTAG;
	int PrtRelStus_cnt		= 0;
	int n					= 0;
	tag_t *PrtRelStusTg     = NULLTAG;
	tag_t queryTag1			= NULLTAG;
	char*	 PrtRelStus		= NULL;

	IMF_file_t   	fileDescriptor	 ;

	/*AOM_ask_value_string(dfq_doc_cre_form,"t5_ItemID",&sItemId);
	printf("Item ID :: %s\n",sItemId);fflush(stdout); 
	
	AOM_ask_value_string(dfq_doc_cre_form,"t5_DVA_Project_Code",&DVA_project_Code);
	tc_strdup(DVA_project_Code,&DVA_project_Codedup);
	printf("DVA_project_Codedup :: %s\n",DVA_project_Codedup);fflush(stdout);
	printf("DVA project Code :: %s\n",DVA_project_Code);fflush(stdout);
	printf("DVA project Length :: %d\n",tc_strlen(DVA_project_Code));fflush(stdout);*/

	
   /* if(tc_strlen(DVA_project_Code)>0)
	{
      printf("DVA project Code found\n");fflush(stdout);
                     
	}
	else
	{
		        printf("before error......\n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Please select the project code from drop down");
				printf("After error.........\n");fflush(stdout);
				return ITK_err;
	}*/

	ITEM_find_item(sItemId,&itemTAG);

	if(itemTAG != NULLTAG)
	{
		printf("\nItem Tag Found \n");

         ITEM_find_revision(itemTAG,revid,&itemRevTAG);

		//ITEM_ask_latest_rev(itemTAG, &itemRevTAG);
		if(itemRevTAG != NULLTAG)
		{
			//AOM_lock(itemRevTAG);
			//AOM_set_value_string(itemRevTAG,"t5_ModuleAddress","MB1C01");
			//AOM_save_with_extensions(itemRevTAG);
			//AOM_refresh(itemRevTAG);

			printf("\n Item Revision Tag Found \n");
			AOM_ask_value_string(itemRevTAG,"t5_PartType",&partTypeS);
			printf("\n partTypeS %s\n",partTypeS);fflush(stdout);

			/*if(tc_strcmp(partTypeS,"M")!=0)
			{
				printf("*** DFQ Document can be created only for objects having PartType as \"Module%s\" ***\n");fflush(stdout);
				//return 0; Only Module are allowed for DFQ Document Creation

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "DVA Document can be created only for objects having PartType as Module");
				return ITK_err;
			}*/

			//AOM_ask_value_string(itemRevTAG,"checked_out",&checkedOutS);
			//printf("\n checkedOutS %s\n",checkedOutS);fflush(stdout);

			//if(tc_strcmp(checkedOutS,"Y")!=0)
			//{
			//	printf("*** DFQ Document can be created only for Checked-Out Parts. ***\n",sItemId);fflush(stdout);
				//return 0; Only checked out DesRev and be used

			//	EMH_clear_errors();
			//	EMH_store_error_s1(EMH_severity_error,ITK_err, "DFQ Document can be created only for Checked-Out Parts");
			//	return ITK_err;
			//}

			PrtRelStus_cnt=0;
			WSOM_ask_release_status_list (itemRevTAG, &PrtRelStus_cnt, &PrtRelStusTg);
			printf("\n T5PartToTaskDeleteVal:PrtRelStus_cnt is:%d.", PrtRelStus_cnt);fflush(stdout);

			/*if(PrtRelStus_cnt > 0)
			{
				n=0;
				for(n=0;n<PrtRelStus_cnt;n++)
				{
					AOM_ask_value_string (PrtRelStusTg[n],"object_name", &PrtRelStus);
					printf("\n T5PartToTaskDeleteVal:PrtRelStus is:%s.",PrtRelStus);fflush(stdout);
					if(tc_strstr(PrtRelStus,"T5_LcsErcRlzd")!= NULL)
					{
						printf("*** DFQ Document creation not allow for Released Module ***\n");fflush(stdout);
						//return 0; Only checked OUT OR checked IN DesRev to be used

						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, "DVA Document creation not allow for Released Module");
						return ITK_err;
					}
				}
			}*/
			/*--------------------------------------------------------
				Get Business Unit from Project Code"
			---------------------------------------------------------*/
			AOM_ask_value_string(itemRevTAG,"t5_ProjectCode",&t5_projectc_code_string);
			printf("\n t5_projectc_code_string %s\n",t5_projectc_code_string);fflush(stdout);

			queryTag = NULLTAG;
			status = QRY_find2("Project for DSRpt", &queryTag);
			/*if (status != ITK_ok)
			{
				  EMH_ask_error_text( status, &s);
				  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
				  MEM_free(s);
				  return status;
			}*/

			qry_entries2[0] = (char *)MEM_alloc(15);
			strcpy(qry_entries2[0], "Project Number");

			qry_values3[0] = (char *)MEM_alloc(10);
			tc_strcpy(qry_values3[0], t5_projectc_code_string);

			QRY_set_name_mode(queryTag,false);
			//Execute Query
			status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

			/*if(resultCount1 == 0)
			{
				EMH_ask_error_text( status, &s);
				printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
				//MEM_free(s);
				//return status;

				EMH_store_error_s2(EMH_severity_information,ITK_err," No Project Found ", t5_projectc_code_string);
				return ITK_err;
			}*/

			AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type);
			printf("\nBusiness Unit -- %s\n",t5_business_unit_type);fflush(stdout);

			if(tc_strcmp(t5_business_unit_type,"CVBU") == 0) t5_business_unit_type_mod = "CV";
			else if(tc_strcmp(t5_business_unit_type,"PCBU") == 0) t5_business_unit_type_mod = "PV";
			else if(tc_strcmp(t5_business_unit_type,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
			else
			{
				///EMH_ask_error_text( status, &s);
				printf("\n*** No Business Unit found for -- %s -- %s\n", t5_projectc_code_string, t5_business_unit_type);fflush(stdout);
				//MEM_free(s);
				//return status;

				//EMH_store_error_s2(EMH_severity_information,ITK_err," No Business Unit found for Project code ", t5_projectc_code_string);
				//return ITK_err;
			}

			/*--------------------------------------------------------
				Get Applicable DFQ USE CASE
			---------------------------------------------------------*/

			AOM_ask_value_string(itemRevTAG,"t5_PartType",&Parttype);
			printf("\n DVA MDM PartType  %s\n",Parttype);fflush(stdout);

			if(tc_strcmp(Parttype,"M")==0)
			{

			 AOM_ask_value_string(itemRevTAG,"t5_ModuleAddress",&moduleAdd);
			 printf("\n DVA MDM moduleAdd %s\n",moduleAdd);fflush(stdout);

			 tc_strcpy(moduleAddressS,"");
			 tc_strcat(moduleAddressS,moduleAdd);

             printf("\n DVA MDM moduleAddressS After cat %s\n",moduleAddressS);fflush(stdout);


			}
			if(tc_strcmp(Parttype,"T")==0)
			{
            AOM_ask_value_string(itemRevTAG,"item_id",&partNumber);
			printf("\nDVA MDM Design Group  :: Part Number = %s",partNumber);
			if(tc_strlen(partNumber)==13 && tc_strcmp(partNumber,"M")!=0)
			{
			  //If Part of Desgin Group Restructuring like 54
			  AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&DesignGrp13);
              printf("\n DVA MDM Design Group  ::  Design Group = %s ",DesignGrp13);
			  subGroup = subString(partNumber,8,4);
			  tc_strcpy(moduleAddressS,"");
			  tc_strcat(moduleAddressS,subGroup);
              printf("\n DVA MDM Design Group  After cat Design Group %s\n",moduleAddressS);fflush(stdout); 
			}		    
			else
			{
			 AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&designgrp);
			 printf("\n DVA MDM Design Group  %s\n",designgrp);fflush(stdout);
			 tc_strcpy(moduleAddressS,"");
			 tc_strcat(moduleAddressS,designgrp);
			 printf("\n DVA MDM Design Group After Cat  %s\n",moduleAddressS);fflush(stdout);
			}			
			}

			printf("\n DVA MDM Design Group OR Module Address  %s\n",moduleAddressS);fflush(stdout);
			

			/*if (strlen(moduleAddressS) == 0)
			{
				printf("\n Module Address should not Blank for Part Typer is Module\n");fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Module Address should not Blank for Part Type is Module");
				return ITK_err;
			}*/

			queryTag = NULLTAG;
			status = QRY_find2("General...", &queryTag);
			/*if (status != ITK_ok)
			{
			  EMH_ask_error_text( status, &s);
			  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
			  MEM_free(s);
			  return status;
			}*/

			//Query DFQ Use Case
			documentName = NULL;
			documentName = (char *)MEM_alloc(50);
			tc_strcpy(documentName, "DVA_");
			tc_strcat(documentName, t5_business_unit_type_mod);
			tc_strcat(documentName, "_");
			//tc_strcat(documentName, "MB1C01_");
			tc_strcat(documentName, moduleAddressS);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, "*");

			qry_entries[0] = (char *)MEM_alloc(10);
			strcpy(qry_entries[0], "Name");

			qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
			tc_strcpy(qry_values1[0], documentName);

			printf("Business Unit 22222 -- %s\n",documentName);fflush(stdout);

			status = QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags);
			printf("\nNo. of DFA Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

			if(resultCount1 > 0)
			{
				char* excelPathS;
				ITK_CALL( PREF_ask_char_value("DFQ_EXCEL_SHEET_PATH", 0 , &excelPathS ) );
				printf("\nExcel Full Path  :: %s",excelPathS ) ;fflush(stdout);

				if( excelPathS == NULL )
				{
						printf("\npreference not found hence default value is /tmp");fflush(stdout);
				}

				//Get DFQ Document Class Type
				ITK_CALL(TCTYPE_find_types_for_class("T5_DFQ_Document",&number_of_types1,&type_tag3));
				printf("\n Number of class found are-------->  : %d\n",number_of_types1);fflush(stdout);

				//Get DFQ Document Relation Class Type
				GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

				//Get Attached DFQ Documents
				GRM_list_secondary_objects_only(itemRevTAG, relTypeTag, &sec_result_count,&available_dfq_document_tags);
				printf("\nNo of Attached DFQ Documetns are :: %d\n",sec_result_count);fflush(stdout);

				//Query Existing DFQ Document Dataset Tag
				queryTag1 = NULLTAG;
				status = QRY_find2("General...", &queryTag1);
				/*if (status != ITK_ok)
				{
				  EMH_ask_error_text( status, &s);
				  printf("\n*** Error with Finding Query -- General... ***\n");fflush(stdout);
				  MEM_free(s);
				  return status;
				}*/

				/* -----------------------------------------------------------------------------
					Code written to get running serial number
					Query all the DFQ Documents having Modules Address and Item ID as below
				------------------------------------------------------------------------------*/
				//Construct STring for Query

				documentName1S = NULL;
				documentName1S = (char *)MEM_alloc(50);
				tc_strcpy(documentName1S, "DVA");
				tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, DVA_project_Code);
			    tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, sItemId);
				tc_strcat(documentName1S, "_");
				tc_strcat(documentName1S, "*"); // to be veriried by Tushar

				printf("\nString to QUery -- |%s|\n", documentName1S);fflush(stdout);

				qry_entries1[0] = (char *)MEM_alloc(20);
				strcpy(qry_entries1[0], "Name");

				qry_values2[0] = (char *)MEM_alloc(51);
				tc_strcpy(qry_values2[0], documentName1S);

				//printf("\nNo. of entries in query are -- %d\n", n_entries);fflush(stdout);
				QRY_set_name_mode(queryTag1,false);
				//Execute Query
				status = QRY_execute(queryTag1, n_entries, qry_entries1, qry_values2, &resultCount2, &dfq_document_dataset_tags);
				printf("\nNo of DFQ Documetns are :: %d\n",resultCount2);fflush(stdout);

				if(resultCount2 == 0)
				{
					incremental_value = 0;
				}
				else
				{
					for (j=0;j<resultCount2 ; j++)
					{
						AOM_ask_value_string(dfq_document_dataset_tags[j],"object_name",&dfq_use_case_uid);
						printf("Datset Name -- %s\n",dfq_use_case_uid);fflush(stdout);

						dfq_dataset_incremental_value = NULL;
						tc_strcpy(dfq_use_case,"");
						tc_strcat(dfq_use_case,dfq_use_case_uid);  //DVA_5442_5442MA543_001
						tc_strtok(dfq_use_case_uid,"_"); 
						tc_strtok(NULL,"_"); 
						tc_strtok(NULL,"_");   
					    dfq_dataset_incremental_value = tc_strtok(NULL,"_");
              
						
                        printf("dfq_dataset_incremental_value Name ------- %s\n",dfq_dataset_incremental_value);fflush(stdout);
   
						incremental_value_latest = atoi(dfq_dataset_incremental_value);

						printf("\nincremental_value_latest :: %d\n",incremental_value_latest) ;
						printf("\nincremental_value :: %d\n",incremental_value) ; fflush(stdout);
						if(incremental_value_latest > incremental_value) incremental_value = incremental_value_latest;
					}
				}

				/*-----------------------------------------------------------------------------
					Code written to get running serial number
					Query all the DFQ Documents having Modules Address and Item ID as below
				------------------------------------------------------------------------------*/

				//Looping through DFQ Use Cases to Create DFQ Document if DFQ_Applicability is True and DFQ Document is not available

				for (j=0;j<resultCount1 ; j++)
				{
					dfq_use_case_uid = NULL;
					AOM_ask_value_logical(dfq_use_case_tags[j],"t5_DfQApplicablility",&t5_dfq_applicability_logical);
					printf("%d\n",t5_dfq_applicability_logical);fflush(stdout);

					AOM_ask_value_string(dfq_use_case_tags[j],"object_name",&dfq_use_case_uid);
					printf("DVA UID :: %s\n",dfq_use_case_uid);fflush(stdout);

					//Verifying DFQ Applicability is TRUE [1]
					if(t5_dfq_applicability_logical == 1)
					{
						create_document = 1;

						//Looping through Available DFQ Documents to ignore creation of available DFQ USE CASE ID.
						for (k=0;k<sec_result_count; k++ )
						{
							AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQUID",&dfq_available_doc_uid);
							printf("\nDFQ Document UID :: %s\n",dfq_available_doc_uid);fflush(stdout);

							AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQ_Project_Code",&DFQ_Project_Code);
							printf("\nDFQ Document UID :: %s\n",DFQ_Project_Code);fflush(stdout);

							AOM_ask_value_string(available_dfq_document_tags[k],"project_ids",&DFQ_Project_Code2);
							printf("\nDFQ Document project_ids :: %s\n",DFQ_Project_Code2);fflush(stdout);


							//AOM_UIF_ask_value(available_dfq_document_tags[k],"project_ids",&DFQ_Project_Code2);
							//printf("\nDFQ Document Project code2 :: %s\n",DFQ_Project_Code2);fflush(stdout);


							printf("\nDFQ_Project_Code2 *****:: %s\n",DFQ_Project_Code2);fflush(stdout);
							printf("\nDVA_project_Code ******:: %s\n",DVA_project_Code);fflush(stdout);

							//if(tc_strcmp(DFQ_Project_Code, DVA_project_Code) == 0)
							//{
								//printf("\n Inside the first project code condition1111101155\n");fflush(stdout);

							    if(tc_strcmp(dfq_available_doc_uid, dfq_use_case_uid) == 0)
							   {
									printf("\n Inside the Same UID Condition\n");fflush(stdout);

								create_document = 0;
								break;

							   }
							//}
							/*else if(tc_strstr(DFQ_Project_Code2, DVA_project_Codedup)!= NULL)
							{
							  printf("\n Inside the Second project code condition22222222285\n");fflush(stdout);

								if(tc_strcmp(dfq_available_doc_uid, dfq_use_case_uid) == 0)
							   {
								create_document = 0;
								break;
							   }
							
							}*/
						}

						if(create_document == 1)
						{
							//Query
							incremental_value++;
							documentNameS = NULL;  
							documentNameS = (char *)MEM_alloc(50);
							if(incremental_value < 9) sprintf(documentNameS,"DVA_%s_%s_00%d",DVA_project_Code, sItemId, incremental_value);
							else if(incremental_value < 99) sprintf(documentNameS,"DVA_%s_%s_0%d",DVA_project_Code, sItemId, incremental_value);
							else if(incremental_value < 999) sprintf(documentNameS,"DVA_%s_%s_%d",DVA_project_Code, sItemId, incremental_value);
							else sprintf(documentNameS,"DVA_%s_%s_00%d",DVA_project_Code, sItemId, incremental_value+1);
							printf("*******************%s-- %d\n",documentNameS,incremental_value);fflush(stdout);
							//DFQ Use Case object name

							//DFQ Use Case Desc
							AOM_ask_value_string(dfq_use_case_tags[j],"object_desc",&dfq_use_case_desc);
							printf("%s\n",dfq_use_case_desc);fflush(stdout);

							//Create DFQ Document

							destinationExcelPathS = NULL;
							command = NULL;
							command=(char *) MEM_alloc(500);
							destinationExcelPathS=(char *) MEM_alloc(300);
							sprintf(destinationExcelPathS,"/tmp/%s.xlsx",documentNameS);
							printf("destinationExcelPathS path %s\n",destinationExcelPathS);fflush(stdout);



							sprintf(command,"cp \"%s\" \"%s\"",excelPathS,destinationExcelPathS);
							TC_write_syslog("Command = %s\n",command);
							printf("Command********************************************* = %s\n",command);fflush(stdout);
							system(command);

							create_dataset_excel(itemRevTAG, documentNameS, dfq_use_case_desc, dfq_use_case_uid, destinationExcelPathS,DVA_project_Code);

//							//Construct Class Type
//							ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentNameS)); //add the following value on DF_DOcument in function create _dateaset_excel
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",dfq_use_case_desc));/add the following value on DF_DOcument in function create _dateaset_excel
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQUID",dfq_use_case_uid));/add the following value on DF_DOcument in function create _dateaset_excel
//
//							TCTYPE_create_object(object_create_input_tag3, &docTag);
//							if(docTag == NULLTAG)
//							{
//								printf("\n *** DFQ Document Creation Failed ***\n");fflush(stdout);
//
//							}
//							else
//							{
//								printf("\n DFQ Document Created.\n");fflush(stdout);
//								destinationExcelPathS = NULL;
//								command = NULL;
//								command=(char *) MEM_alloc(500);
//								destinationExcelPathS=(char *) MEM_alloc(300);
//								sprintf(destinationExcelPathS,"/tmp/%s.xlsx",documentNameS);
//
//								sprintf(command,"cp \"%s\" \"%s\"",excelPathS,destinationExcelPathS);
//								TC_write_syslog("Command = %s\n",command);
//								printf("Command = %s\n",command);fflush(stdout);
//								system(command);
//
//								ITK_CALL(AOM_lock(docTag));
//								//ITK_CALL(IMF_import_file(destinationExcelPathS, "T5_DFQ_EXCEL", SS_BINARY, &newFileTag, &fileDescriptor));
//								//ITK_CALL(AE_add_dataset_named_ref2(docTag,"T5_DFQ_EXCEL", AE_PART_OF, fileDescriptor));
//								ITK_CALL(AE_import_named_ref(docTag,"T5_DFQ_EXCEL", destinationExcelPathS, NULL, AE_PART_OF));
//								ITK_CALL(AE_save_myself(docTag));
//								ITK_CALL(AOM_refresh(docTag,false));
//
//								if(relTypeTag == NULLTAG) printf("\nRelation Tag is NULLTAG\n");fflush(stdout);
//								if(docTag == NULLTAG) printf("\nDocument Tag is NULLTAG\n");fflush(stdout);
//								if(itemRevTAG == NULLTAG) printf("\nItem REvision Tag is NULLTAG\n");fflush(stdout);
//
//								ITK_CALL(AM_set_mode(AM_MODE_ALL_GROUPS));
//								ITK_CALL(GRM_create_relation(itemRevTAG,docTag,relTypeTag,user_data_tag,&relTag));
//								if(relTag != NULLTAG)
//								{
//									ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//									printf("\n Design Revision and DFQ Document Relation Created\n");fflush(stdout);
//									ITK_CALL(AOM_lock(relTag));
//									ITK_CALL(AOM_save_with_extensions(relTag));
//									ITK_CALL(AOM_refresh(relTag,false));
//
//									ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//								}
//								else
//								{
//									printf("\n *** Design Revision and DFQ Document Relation Creation Failed. 111***\n");fflush(stdout);
//								}
//								ITK_CALL(AM_set_mode(AM_MODE_UNSET));
//							}
						}
						else
						{
							printf("\n *** DFQ Document already available for USE CASE ID, ignoring creation of DFQ Document. ***\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n *** DFQ Applicability is FALSE, ignoring creation of DFQ Document. ***\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n *** No DFQ Document USE CASE Applicable. Ignoring Creation of DFQ Documents***\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n*** Design Revision tag Not Found. ***\n");fflush(stdout);

		}
	}
	else
	{
		printf("\n*** Design tag Not Found. ***\n");fflush(stdout);
	}
	
//return 0;

}
int AssignTMKOParticipant(tag_t DcrTag,char* ProgNm,char* PartiType,char* roleName)
{
	int status = 0;
	int error_code = ITK_ok;
	int No_User = 0 , iii=0;

	tag_t* User_Tags= NULLTAG;
	tag_t groupName_tag= NULLTAG;
	tag_t DCR_Patri_Type= NULLTAG;
	tag_t roleName_tag= NULLTAG;
	tag_t DCR_Party =  NULLTAG;
	logical bypass =true;

	char *groupName = NULL;

	groupName = (char *)MEM_alloc(70);

	printf("\n AssignTMKOParticipant-->PartiType Value == [%s]", PartiType);fflush(stdout);

	ITK_CALL(EPM_get_participanttype (PartiType,&DCR_Patri_Type));

	if (DCR_Patri_Type != NULLTAG)
	{
		printf("\n AssignTMKOParticipant-->ProgNm Value == [%s]", ProgNm);fflush(stdout);

		tc_strcpy(groupName,ProgNm);
		tc_strcat(groupName,".");
		tc_strcat(groupName,"DCR");

		printf("\n AssignTMKOParticipant-->groupName Value == [%s]", groupName);fflush(stdout);

		ITK_CALL(SA_find_group(groupName,&groupName_tag));
		ITK_CALL(SA_find_role2(roleName,&roleName_tag));
		ITK_CALL(SA_find_groupmember_by_role(roleName_tag,groupName_tag,&No_User,&User_Tags));
		printf("\n AssignTMKOParticipant-->DCR No_User :[%d]",No_User);  fflush(stdout);

		if (No_User>0)
		{
			for(iii=0;iii<No_User;iii++)
			{
				ITK_CALL(EPM_create_participant(User_Tags[iii],DCR_Patri_Type,&DCR_Party));
				AOM_lock(DcrTag);
				//ITK_CALL(ITEM_rev_add_participant(DcrTag,DCR_Party));
				//ITK_CALL(ITEM_rev_add_participant(DcrTag,DCR_Party));
                 ITK_CALL(PARTICIPANT_add_participant(DcrTag,bypass,DCR_Party));	
				AOM_save_with_extensions(DcrTag);
				AOM_unlock(DcrTag);
			}
			AOM_refresh ( DcrTag,TRUE);
		}
		//MEM_free(DCR_Patri_Type);
	}

	printf("\n AssignTMKOParticipant-->Function process is completed \n");fflush(stdout);

	return 0;
}

char* getProject(char* ProjCode)
{
	tag_t TagQryContObj = NULLTAG, *cntr_objects = NULLTAG;

	int	n_entries = 1;
	int n_found = 0;

	char* ProgName=NULL;

	char *qry_entries[1] = {"Name"};
	char *qry_values[1] = {ProjCode};

	if(QRY_find2("Prd_Project", &TagQryContObj));

	if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n getProgramProject-->Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

	if(n_found > 0)
	{
		if( AOM_ask_value_string(cntr_objects[0],"t5_Program",&ProgName));
		printf("\n getProgramProject-->ProgName Value == [%s]", ProgName);fflush(stdout);
	}

	return ProgName;
}

int TMKO_Auto_Assign( EPM_action_message_t msg )
{
	tag_t	*attachments		= NULLTAG;
	tag_t	*TMKO_Particpant		= NULLTAG;
	int     count               = 0;
	int     jk                  = 0;
	int     i                   = 0;
	int     PrtCount            = 0;
	tag_t	root_task			= NULLTAG;
	tag_t	ObjTypP			= NULLTAG;
	tag_t	objTag			= NULLTAG;
	tag_t	TMKO_Particpant_rel_type			= NULLTAG;
	char*   partno              = NULL;
	char*   partonodup          = NULL;
	char*   projectcode         = NULL;
	char*   TMKO_Pro            = NULL;
	char*   type_name7            = NULL;
	char*   object_name            = NULL;

    ITK_CALL(EPM_ask_root_task(msg.task,&root_task));
 	
    ITK_CALL(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  TMKO Attachment count is %d",count);
	
	if(count>0)
	{
	   
	  

		for(i=0;i<count;i++)
		{

		   objTag = attachments[i];

		   if(AOM_ask_value_string(objTag,"t5_Part_Number",&partno)!=ITK_ok)PrintErrorStack();
		   if(AOM_ask_value_string(objTag,"object_name",&object_name)!=ITK_ok)PrintErrorStack();
		   printf("\n part number is  [%s] ", partno);fflush(stdout);
		   printf("\n object_name is  [%s] ", object_name);fflush(stdout);

			tc_strdup(partno,&partonodup);

			projectcode=subString(partonodup, 0, 4);
			printf("\n object_projectcode is  [%s] ", projectcode);fflush(stdout);


			TMKO_Pro=getProject(projectcode);

			printf("\n object program name is  [%s] ", TMKO_Pro);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("HasParticipant", &TMKO_Particpant_rel_type));

			if(TMKO_Particpant_rel_type != NULLTAG)
			{

			  printf("\n  HasParticipant relation found sucessfully");
 
			}
			else
			{
			  printf("\n  HasParticipant relation Not found");
			}
			if(GRM_list_secondary_objects_only(objTag,TMKO_Particpant_rel_type,&PrtCount,&TMKO_Particpant)!=ITK_ok)PrintErrorStack();
            printf("\n  TMKO_Particpant Attachment count is %d",PrtCount);

			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_AQ_input_and_sign_of","Functional_Lead_AQ");
			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Cost_manager_input","Functional_Lead_TVM");
			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_FMQ_input_and_Sign_off","Functional_Lead_QA_FMQ");
			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_TS_input_and_sign_off","Functional_Lead_TS");
			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Proceed_Re_raise","VLD_Reviewer");

//			AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Chief_Engineer","EE_COC");
//	        AssignTMKOParticipant(objTag,TMKO_Pro,"T5_AQ_input_and_sign_of","Funcational_Lead_AQ");
//	        //AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Cost_manager_input","");
//	        AssignTMKOParticipant(objTag,TMKO_Pro,"T5_FMQ_input_and_Sign_off","Funcation_Lead_QA_FMQ");
//	        AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Proceed_Re_raise","Funcational_Lead_P&SQ");
//	        //AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Proceed_Rework_by_PL","EE_COC");
//	       //AssignTMKOParticipant(objTag,TMKO_Pro,"T5_Submit_to_PL","EE_COC");
//	       AssignTMKOParticipant(objTag,TMKO_Pro,"T5_TS_input_and_sign_off","Funcational_Lead_TS");
//	       //AssignTMKOParticipant(objTag,TMKO_Pro,"T5_TeamHead","EE_COC");

	       //ITK_CALL(EPM_create_process("TMKO Document Release Process","TMKO Document Release Process",template_tag2,1,&DitemRevTAG,&attachment_types2,&test_job_a2));
		

			/*printf("\n TMKO_Auto_Assign-->PrtCount count: %d",PrtCount);fflush(stdout);
					
			//for (jk=0;jk<PrtCount ;jk++ )
			//{

	         //if (tc_strcmp(type_name7,"T5_DcrCHKLST_REV")==0)
			 //{
				tag_t TMKO_PartTag = TMKO_Particpant[jk];

				if(TCTYPE_ask_object_type(TMKO_PartTag,&ObjTypP));
				if(TCTYPE_ask_name2(ObjTypP,&type_name7));
				printf("\n DCR_Auto_Assign-->DML:2 Participants Name: %s", type_name7);fflush(stdout);

				AOM_lock(objTag);
				ITEM_rev_remove_participant (objTag,TMKO_PartTag);
				AOM_save_with_extensions(objTag);
				AOM_unlock(objTag);
				AOM_refresh (objTag,TRUE);
				AssignTMKOParticipant(objTag,TMKO_Pro,"ProposedResponsibleParty","EE_COC");

			//}



			//}*/
						




		}
	}


  printf("\n END of TMKO Assign  code \n");fflush(stdout);

  return ITK_ok;

}



int DVA_doc_attach( EPM_action_message_t msg )
{
    char *	 username			           = NULL;
    char *	 CurrentTask		           = NULL;
    char *	 DFQ_Project_Code			   = NULL;
    char *	 dfq_available_doc_uid		   = NULL;
    char *	 Desid			               = NULL;
    char *	 parent_name			       = NULL;
    char *	 dmlNo			               = NULL;
    char *	 documentName1S			       = NULL;
    char *	 documentName			       = NULL;
    char *	 moduleAddressS			       = NULL;
    char *	 DesRevid			           = NULL;
    char *	 dmlRevId			           = NULL;
    char *	 dfq_use_case_desc			   = NULL;
   // char *	 object_type			   = NULL;

    char *	 Lsmdate			           = NULL;
    char *	 objType			           = NULL;
    //char *	 DVA_project_Code	       = NULL;
    char *	 Desrlsstatus			       = NULL;
    char *	 Breakdownobj			       = NULL;
    char *	 t5_business_unit_type	       = NULL;
    char *	 t5_business_unit_type_mod     = NULL;
    char *	 t5_projectc_code_string       = NULL;
    char *	 dfq_use_case_uid		       = NULL;
    char *	 dfq_use_case			       = NULL;
    char* dfq_dataset_incremental_value    = NULL;
	char* excelPathS                       = NULL;
	char* documentNameS                    = NULL;
	logical t5_dfq_applicability_logical   = 0;
    tag_t   rootTask			           = NULLTAG;
    tag_t   RefRelation			           = NULLTAG;
	tag_t    queryTag2                     = NULLTAG;
    tag_t   RefcountT			           = NULLTAG;
    tag_t   DMLTag			               = NULLTAG;
    tag_t   DML_tag			               = NULLTAG;
    tag_t   objTypTag			           = NULLTAG;
    tag_t   DMLRevTag			           = NULLTAG;
    tag_t   DesRevtag			           = NULLTAG;
    tag_t   queryTag1			           = NULLTAG;
    tag_t   itemTAG			               = NULLTAG;
    tag_t   relTypeTag			           = NULLTAG;
    tag_t   itemRevTAG			           = NULLTAG;
    tag_t   queryTag			           = NULLTAG;
    tag_t*   attachments			       = NULLTAG;
    tag_t*   BreakdowncountTags			   = NULLTAG;
    tag_t*   DsgrevPartTags			       = NULLTAG;
    tag_t*   RefcountTags			       = NULLTAG;
    tag_t*   proj_tags			           = NULLTAG;
    tag_t*   dfq_document_dataset_tags	   = NULLTAG;
    tag_t*   available_dfq_document_tags   = NULLTAG;
	tag_t *dfq_use_case_tags               = NULLTAG;
	tag_t *type_tag3                       = NULL;
	char* destinationExcelPathS            = NULL;
	char* DMLProjectcode                   = NULL;
	char* command                          = NULL;


    int noAttachment=0;
    int Breakdowncount=0;
    int Dsgnrevcount=0;
    int m=0;
    int s=0;
	int     status;
	int		ifail				    = 0;
	int		Refcount				= 0;
	int		j				        = 0;
	int		k				        = 0;
	int		l				        = 0;
	int		resultCount1			= 0;
	int		n_entries				= 1;
	int		resultCount2		    = 1;
	int   incremental_value_latest  = 0;
	int   number_of_types1          = 0;
	int incremental_value           = 0;
	int sec_result_count            = 0;
	int create_document             = 0;
	//documentName1S = NULL;
	documentName1S         =   (char *)  MEM_alloc(50);
	char **qry_entries1    =   (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_entries2    =   (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values      =   (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1     =   (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values2     =   (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3     =   (char **) MEM_alloc(n_entries * sizeof(char *));
	//char ** qry_entries1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));

	qry_values3[0] = (char *)MEM_alloc(10);
	qry_entries2[0] = (char *)MEM_alloc(15);
	qry_entries1[0] = (char *)MEM_alloc(500);
	qry_values2[0] = (char *)MEM_alloc(500);
	//documentName1S = (char *)MEM_alloc(50);
	documentName = (char *)MEM_alloc(50);
	


	ITK_CALL(POM_get_user_id (&username));
	printf("\n DVA Session User is : %s \n",username); fflush(stdout);


	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	{
	
		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n Inside the DVA_update ...\n");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n DVA_update- CurrentTask: %s \n",CurrentTask);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\n DVA_update- parent Name: %s \n",parent_name);fflush(stdout);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\n DVA_update- Target Attachment:%d \n",noAttachment);fflush(stdout);
	
		if(noAttachment > 0)
		{
		
		
			printf("\n Inside DVA Target Attachment:%d \n",noAttachment);fflush(stdout);
			DMLTag = attachments[0];

			ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&dmlNo));
			printf("\n DVA current- DML No: [%s] \n", dmlNo);fflush(stdout);


			if(ITEM_find_item(dmlNo, &DML_tag)!=ITK_ok)PrintErrorStack();


			if (DML_tag != NULLTAG)
			{
					printf("\n DML tag is not null for DVA_Attach DML No: [%s] \n", dmlNo);fflush(stdout);

					if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

					ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&dmlRevId));
					printf("\n  item_id is %s\n", dmlRevId);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"last_mod_date",&Lsmdate));
					
					printf("\n  Last modified date is*************** %s\n", Lsmdate);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&DMLProjectcode));
					printf("\n  DML Project code for DVA Create %s\n", DMLProjectcode);fflush(stdout);

					ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));

					if(objTypTag!=NULLTAG)
				    {
					
					 printf("\n object type found sucessfully \n");fflush(stdout);



					}

					ITK_CALL(TCTYPE_ask_name2(objTypTag,&objType));
					printf("\n  object_type is %s\n", objType);fflush(stdout);


//					ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
//	                ITK_CALL(TCTYPE_ask_name2(objTypTag, &type_name));


					if(tc_strcmp(objType,"ChangeRequestRevision")==0)   //IMAN_reference
					{

						ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Breakdowncount,&BreakdowncountTags));
						   printf("\n Task count %d \n",Breakdowncount);fflush(stdout);
						   
								if (Breakdowncount>0)
								{
						   
									for (m=0;m<Breakdowncount;m++)
									{
											ITK_CALL(AOM_ask_value_string(BreakdowncountTags[m],"item_id",&Breakdownobj));
											printf("\n for Breakdownobj Parts found = %s \n",Breakdownobj);fflush(stdout);
						   
											ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[m],"CMReferences",&Dsgnrevcount,&DsgrevPartTags)); //In Change References we get Design revision.				
											printf("\n for Design revision Parts found = %d\n",Dsgnrevcount);fflush(stdout);
						   
											if(Dsgnrevcount>0)
											{
												char *	 object_type			= NULL;
												char *	 DVA_project_Code		= NULL;
						   
												for(s=0;s<Dsgnrevcount;s++)
												{

													DesRevtag = DsgrevPartTags[s];

													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_id",&Desid));

													printf("\n item id of Module is %s \n",Desid);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_revision_id",&DesRevid));

													printf("\n part revision and sequence  %s \n",DesRevid);fflush(stdout);

													dvacreate(DMLProjectcode,Desid,DesRevid);

                                                   /* ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&RefRelation));

													if(RefRelation != NULLTAG)
													{ 

													 printf("\n Relation Tag found \n");fflush(stdout);

													
													}
													else
													{
													
													 printf("\n Relation Tag NOT found \n");fflush(stdout);


													}

						                            ITK_CALL(GRM_list_secondary_objects_only(DesRevtag,RefRelation,&Refcount,&RefcountTags));

													printf("\n DVA document count is  %d \n",Refcount);fflush(stdout);

													
													if(Refcount == 0)
													{
                                                        

													   
													
													}
													else
													{
													
													printf("\n DVA documents are already available\n");fflush(stdout);
													
													}*/

														
													
													/*DesRevtag = DsgrevPartTags[s];
						   
													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_id",&Desid));

													printf("\n item id of Module is %s \n",Desid);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_revision_id",&DesRevid));
													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"release_status_list",&Desrlsstatus));

													ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelation));

						                            ITK_CALL(GRM_list_secondary_objects_only(DesRevtag,RefRelation,&Refcount,&RefcountTags));

                                                    printf("\n reference count is %d \n",Refcount);fflush(stdout);*/

													/*if(Refcount>0)
													{
														

														for(j=0; j<Refcount; j++)
														{
                                                            RefcountT=RefcountTags[j];

															printf("\n inside reference \n");fflush(stdout);

                                                            ITK_CALL(AOM_ask_value_string(RefcountT,"object_type",&object_type));

															
                                                                printf("\n Inside Object Type condition PDF \n");fflush(stdout);


																ITK_CALL(AOM_ask_value_string(RefcountT,"object_name",&DVA_project_Code));

																printf("\n Project code is %s \n",DVA_project_Code);fflush(stdout);

																printf("\n item id of Module is %s \n",Desid);fflush(stdout);

																/*ITEM_find_item(Desid,&itemTAG);

																ITEM_ask_latest_rev(itemTAG, &itemRevTAG);*/

																//dvacreate(DMLProjectcode,Desid);
															
														

															

													/*	}
													}
													else
													{
													
													    printf("\n Inside else codition of PDF count Zero of Project code \n");fflush(stdout);
													
													
													}*/

											    }
										   }
									}
								}
						
						
					 }


			}
		
		
		}
	
	
	
	
	
	}

       printf("\n END of DVA MDM code \n");fflush(stdout);

  return ITK_ok;

}


int TMKO_Mail_reject( EPM_action_message_t msg )
{
	char* DocHeader_id									=NULL;
	char* ObjType							=NULL;
	char* CurrentId								=NULL;
	char* LastModUsr						=NULL;
	char* creationdate								=NULL;
	char* subobjtyp                               =NULL;  


	tag_t		DocHeaderTag		= NULLTAG;
	tag_t		LatestDocHeaderRevTag	= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		person_tag			= NULLTAG;
	char*		person_name			= NULL;
	char* objectname								=NULL;


	tag_t job_Tag	= NULLTAG;
	tag_t rootTask	= NULLTAG;
	tag_t* subtask	= NULLTAG;
	tag_t* TMKO_Form_objects	= NULLTAG;
	tag_t* childtask	= NULLTAG;
	//date_t decision_date;
	int tskcount =0;
	int childcount =0;
	//int EPM_signoff_attachment =0;
	int i =0;
	int j =0;
	tag_t jobtype_Tag	= NULLTAG;
	tag_t subtaskt	= NULLTAG;
	tag_t Quser	= NULLTAG;
	EPM_signoff_decision_t 	decision;
	char * 	comments= NULL;
	char * 	chiefengg= NULL;
	char * 	costmanager= NULL;
	char * 	TSInput= NULL;
	char * 	PLCOC= NULL;
	char * 	ERCCOC= NULL;
	char * 	person= NULL;
	char * 	wfEndDate= NULL;
	char * 	AQsign= NULL;
	char * 	FMQ_dateEndDate= NULL;
	char * 	AQEndDate= NULL;
	char * 	PLEndDate= NULL;
	char * 	ChiefEndDate= NULL;
	char * 	CostEndDate= NULL;
	char * 	TSEndDate= NULL;
	char* 	enddateEP= NULL;
	
	char * 	subsubtaskname1PL= NULL;
	char * 	username1= NULL;
	char * 	username2= NULL;
	date_t 	decision_date = NULLDATE;
	date_t 	FMQ_date = NULLDATE;
	date_t 	AQ_date = NULLDATE;
	date_t 	PL_date = NULLDATE;
	date_t 	Chief_date = NULLDATE;
	date_t 	Cost_date = NULLDATE;
	date_t 	TS_date = NULLDATE;
	date_t 	ProceedSignoffDate1 = NULLDATE;

	tag_t QuserChief  = NULLTAG;
	tag_t QuserCost	  = NULLTAG;
	tag_t QuserTS	  = NULLTAG;
	tag_t QuserFMQ	  = NULLTAG;
	tag_t  QuserAQ   = NULLTAG;
	tag_t  QuserPLProc   = NULLTAG;
	tag_t  TMKO_Form_tag   = NULLTAG;
	tag_t  DVLORel   = NULLTAG;
	tag_t  TMKODoc   = NULLTAG;
	
	char *usernameChief          = NULL;
	char *usernameCost			 = NULL;
	char *usernameTS			 = NULL;
	char *usernameFMQ			 = NULL;
	char *usernameAQ			 = NULL;
	char *usernamePLProceed			 = NULL;
	char *usernameCoc			 = NULL;
								 
	char *usernameChief1		 = NULL;
	char *usernameCost1			 = NULL;
	char *usernameTS1			 = NULL;
	char *usernameFMQ1			 = NULL;
	char *usernameAQ1			 = NULL;
	char *usernamePLProceed1			 = NULL;
	char *usernameCoc1			 = NULL;
	//EPM_signoff_decision_t *ProceedStatus			 = NULL;
	char * ProceedStatus			 = NULL;
								
	char *performerChief		 = NULL;
	char *performerTS			 = NULL;
	char *performerCost			 = NULL;
	char *performerFMQ			 = NULL;
	char *performerAQ			 = NULL;
	char *performerPLProceed			 = NULL;
	char *performerCoC			 = NULL;
	char *Proceedreraise			 = NULL;
	char *ProceedSignoffDate			 = NULL;
	
	char * PLCOCDecision    = NULL;
	char * PLCOCDecision2    = NULL;
	char * ChiefDecision	= NULL;
	char * CostDecision		= NULL;
	char * TSDecision		= NULL;
	char * AQDecision		= NULL;
	char * FMQDecision		= NULL;
	char * CoCdecision		= NULL;
	char * CoCdecision1		= NULL;
	char * documentNameS    = NULL;
	char * documentNameS1    = NULL;
	char * Objectname99    = NULL;
	char * ProceedComment    = NULL;
	char* dfq_dataset_incremental_value = NULL;
	documentNameS = (char *)MEM_alloc(50);
	documentNameS1 = (char *)MEM_alloc(50);
	int incremental_value = 0;
	int TMKO__count = 0;
	//int incremental_value = 0;
	int incremental_value_latest = 0;
	int l = 0;
	tag_t	object_Tmko =NULLTAG;
	tag_t	datasettag =NULLTAG;
	
			
	//tag_t rootTask		=  NULLTAG;
	tag_t attachments1		=  NULLTAG;
	tag_t* attachments		=  NULLTAG;
	char* username         = NULL;
	char* CurrentTask         = NULL;
	char* objecttype         = NULL;
	char* parent_name         = NULL;
	char* DocHeaderNo         = NULL;
	char* Proceedreraise1         = NULL;
	char* Decisioncomment         = NULL;
	char* Decisondate         = NULL;
	char* decisionsatus         = NULL;
	char* Decisioncond         = NULL;
	char* usernameDecision         = NULL;
	char* usernameDecision1         = NULL;
	int noAttachment = 0 ;

	     
	 
	      
	     	
		
	      ITK_CALL(POM_get_user_id (&username));
		printf("\n TMKO Session User is : %s \n",username); fflush(stdout);

		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		{

			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n Inside the TMKO Reject\n");fflush(stdout);

			ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			printf("\n TMKO- CurrentTask: %s \n",CurrentTask);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			printf("\n TMKO- parent Name: %s \n",parent_name);fflush(stdout);

			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("\n TMKO- Target Attachment:%d \n",noAttachment);fflush(stdout);

			for(j=0; j<noAttachment;j++)
			{
			
			attachments1=attachments[j];

			ITK_CALL(AOM_ask_value_string(attachments1,"object_type",&objecttype));
			printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);


			if(tc_strcmp(objecttype,"T5_TMKOHeaderRevision")==0)
			{
			ITK_CALL(AOM_ask_value_string(attachments1,"item_id",&DocHeaderNo));
			
			printf("\n Name of TMKO Document %s \n",DocHeaderNo);fflush(stdout);

			
			}
			
			
			
			
			
			}

			ITK_CALL(EPM_ask_sub_tasks(rootTask,&tskcount,&subtask));
	        printf("\n sub task count is %d \n",tskcount);fflush(stdout);

			 for(i=0; i<tskcount;i++)
            {

		//ITK_CALL(EPM_ask_attachments(subtask[i],EPM_signoff_attachment,&count9,&subtasku));
		
	
		ITK_CALL(AOM_ask_value_string(subtask[i],"object_name",&objectname));
	
		printf("\n\n task name is %s\n",objectname);
		if(tc_strcmp(objectname,"ERC COC")==0) 
		{
			printf("\n inside the ERC COC \n");
	
			
				 
			 ITK_CALL(AOM_ask_value_string(subtask[i],"comments",&ERCCOC));

			 printf("comment  ERCCOC of Reviwer : %s\n",ERCCOC);
					 
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0EndDate",&enddateEP)); 
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Status",&CoCdecision));
			 
			if(tc_strcmp(CoCdecision,"Completed")==0)
		   {
		   
		     printf("\n inside the ERC COC Approve decision\n");

		      CoCdecision1="Approved";

		   }
		   else
		   {
			   printf("\n inside the ERC COC Approve decision\n");

				CoCdecision1="Rejected";
		   
		   }

			 printf("ERC COC Task complete date : %s\n",enddateEP);
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerCoC));   ///Govind Betkar (gbb916241)
			
			 printf("\n performerFMQ name is %s \n",performerCoC);fflush(stdout);

			 usernameCoc=tc_strtok(performerCoC,"("); 
			 usernameCoc1=tc_strtok(NULL,")"); 
			 printf("\n performer usernameCoc is1111111 %s \n",usernameCoc);fflush(stdout);
			 printf("\n performer usernameCoc1 is111111111111 %s \n",usernameCoc1);fflush(stdout);
		
			  
		 }

		 if(tc_strcmp(objectname,"New Condition Task 1")==0) 
		{
			printf("\n inside the ERC COC \n");
	
			
				 
			 ITK_CALL(AOM_ask_value_string(subtask[i],"comments",&Decisioncomment));

			 printf("comment  Decisioncomment of Reviwer : %s\n",Decisioncomment);             ///Decisioncomment Decisondate decisionsatus usernameDecision
					 
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0EndDate",&Decisondate)); 
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"task_result",&decisionsatus));
			 
			/*if(tc_strcmp(decisionsatus,"Approved")==0)
		   {
		   
		     printf("\n inside the ERC COC Approve decision\n");

		      CoCdecision1="Approved";

		   }
		   else
		   {
			   printf("\n inside the ERC COC Approve decision\n");

				CoCdecision1="Rejected";
		   
		   }*/

			 printf("ERC COC Task complete date : %s\n",enddateEP);
			 ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&Decisioncond));   ///Govind Betkar (gbb916241)
			
			 printf("\n Decisioncond name is %s \n",Decisioncond);fflush(stdout);

			 usernameDecision=tc_strtok(Decisioncond,"("); 
			 usernameDecision1=tc_strtok(NULL,")"); 
			 printf("\n performer usernameDecision is1111111 %s \n",usernameDecision);fflush(stdout);
			 printf("\n performer usernameCoc1 is111111111111 %s \n",usernameDecision1);fflush(stdout);
			
				
			
			  
		 }
	
	    printf(" tskcount [%d] is %d \n",i,childcount);fflush(stdout);
	
		if(tc_strcmp(objectname,"FMQ input and Sign-off")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		{
			printf("\n FMQ input and Sign-off \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));
			//ITK_CALL(AOM_UIF_ask_value(subtask[i],"awp0Acknowledgers",&subsubtaskname1PL));
			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerFMQ));
		   // printf("\n Reviwer name is %s \n",subsubtaskname1PL);fflush(stdout);
		    printf("\n performerFMQ name is %s \n",performerFMQ);fflush(stdout);

			usernameFMQ=tc_strtok(performerFMQ,"("); 
			usernameFMQ1=tc_strtok(NULL,")"); 
			printf("\n performer name1 is1111111 %s \n",usernameFMQ);fflush(stdout);
		    printf("\n performer usernameFMQ1 is111111111111 %s \n",usernameFMQ1);fflush(stdout);
			
			ITK_CALL(SA_find_user2(usernameFMQ1,&QuserFMQ));

			if(Quser!=NULLTAG)
			{
			
			printf("\n Happy Diwali \n");fflush(stdout);
			
			}

	       // ITK_CALL(SA_ask_user_person_name2(Quser,&person));
	
		   for(j=0;j<childcount;j++)
		   {

      
		
		

		   /* printf("\n inside the user tag \n");
		    tc_strtok(subsubtaskname1PL,"");
		    tc_strtok(subsubtaskname1PL,"/"); 
			tc_strtok(NULL,"/"); 
			usernamePL=tc_strtok(NULL," ");  
			username1PL=tc_strtok(NULL," "); //PLM_Support_Group/Support_Role/Govind Betkar (gbb916241)
			tc_strtok(NULL,"("); 
			UserID=tc_strtok(NULL,")"); 
			ITK_CALL(SA_find_user2(UserID,&Quser));

	        ITK_CALL(SA_ask_user_person_name2(Quser,&person));
			
			
			
			printf("\n mail reciver user name is %s \n",usernamePL);fflush(stdout);
			printf("\n mail reciver  %s \n",username1PL);fflush(stdout);
		    printf("\n mail reciver  %s \n",UserID);fflush(stdout);*/
		  //
		//   ITK_CALL(AOM_ask_value_string(childtask[j],"object_type",&subobjtyp));
		  //
		  // if(tc_strcmp(subobjtyp,"EPMSelectSignoffTask")==0)
		// {
				if(QuserFMQ!=NULLTAG)
				{

					ITK_CALL(AOM_UIF_ask_value(subtask[j],"awp0Acknowledgers",&subsubtaskname1PL));
		          printf("\n Reviwer name 00000000is %s \n",subsubtaskname1PL);fflush(stdout);
			
				   ITK_CALL(EPM_ask_decision(childtask[j],QuserFMQ,&decision,&CurrentId,&FMQ_date));
	
				   printf("comment of FMQ Reviwer : %s \n",CurrentId);
				   if(decision==EPM_approve_decision)
				   {
				   
				   printf("\n inside the FMQ Approve decision\n");

				   FMQDecision="Approved";

				   }
				   else
				   {
					   printf("\n inside the FMQ Approve decision\n");

				       // FMQDecision="Rejected";
				   
				   }
					 
					// printf("Approve Date %d\n",date);
					ITK_CALL(ITK_date_to_string(FMQ_date,&FMQ_dateEndDate));
	
				   printf("date of Reviwer : %s\n",FMQ_dateEndDate);
	
				   //return 0;
				}
		     //}
		   }
		 }
	
		 if(tc_strcmp(objectname,"AQ input and sign-of")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		 {
		    printf("\n inside AQ input and sign-of tag \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));

			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerAQ));
		   
		    printf("\n performerAQ name is %s \n",performerAQ);fflush(stdout);

			usernameAQ=tc_strtok(performerAQ,"("); 
			usernameAQ1=tc_strtok(NULL,")"); 
			printf("\n performer usernameAQ is1111111 %s \n",usernameAQ);fflush(stdout);
		    printf("\n performer usernameAQ1 is111111111111 %s \n",usernameAQ1);fflush(stdout);
			
			ITK_CALL(SA_find_user2(usernameAQ1,&QuserAQ));
			
	
	
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_ask_value_string(childtask[j],"object_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMSelectSignoffTask")==0)
			 {
			
			  if(QuserAQ!=NULLTAG)
			  {
				  
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserAQ,&decision,&AQsign,&AQ_date));
	
			     printf("comment ofcAQsign Reviwer : %s\n",AQsign);
	
				 ITK_CALL(ITK_date_to_string(AQ_date,&AQEndDate));
	
				 printf("date of AQEndDate Reviwer : %s\n",AQEndDate);

				 if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the AQ Approve decision\n");

				   AQDecision="Approved";

				 }
				 else
				 {
					   printf("\n inside the AQ Rejected decision\n");

				        //AQDecision="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		   }
		  }
		  MEM_free(childtask);
		 }
		 if(tc_strcmp(objectname,"TS input and sign-off")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		{
			printf("\n inside TS input and sign-off \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));
			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerTS));
		   
		    printf("\n performerTS name is %s \n",performerTS);fflush(stdout);

			usernameTS=tc_strtok(performerTS,"("); 
			usernameTS1=tc_strtok(NULL,")"); 
			printf("\n performer usernameTS is1111111 %s \n",usernameTS);fflush(stdout);
		    printf("\n performer usernameTS1 is111111111111 %s \n",usernameTS1);fflush(stdout);
	
	        ITK_CALL(SA_find_user2(usernameTS1,&QuserTS));
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_ask_value_string(childtask[j],"object_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMSelectSignoffTask")==0)
			 {
	
			  if(QuserTS!=NULLTAG)
			  {
				   ITK_CALL(AOM_UIF_ask_value(subtask[j],"awp0Reviewers",&subsubtaskname1PL));
		          printf("\n Reviwer name 0000000022222is %s \n",subsubtaskname1PL);fflush(stdout);
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserTS,&decision,&TSInput,&TS_date));
	
			     printf("comment  TSInput of Reviwer : %s\n",TSInput);
	
				 ITK_CALL(ITK_date_to_string(TS_date,&TSEndDate));
	
				 printf("date of TSEndDate Reviwer : %s\n",TSEndDate);

				 if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the TS Approve decision\n");

				   TSDecision="Approved";

				 }
				 else
				 {
					   printf("\n inside the TS Rejected decision\n");

				        //TSDecision="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		     }
		   }
		   MEM_free(childtask);
		 }
		  if(tc_strcmp(objectname,"Cost manager input and sign-off")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		 {
			printf("\n inside Cost manager input and sign-off \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));

			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerCost));
		   
		    printf("\n performerCost name is %s \n",performerCost);fflush(stdout);

			usernameCost=tc_strtok(performerCost,"("); 
			usernameCost1=tc_strtok(NULL,")"); 
			printf("\n performer usernameCost is1111111 %s \n",usernameCost);fflush(stdout);
		    printf("\n performer usernameCost1 is111111111111 %s \n",usernameCost1);fflush(stdout);
	
	        ITK_CALL(SA_find_user2(usernameCost1,&QuserCost));
	
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_ask_value_string(childtask[j],"object_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMSelectSignoffTask")==0)
			 {
	
			  if(QuserCost!=NULLTAG)
			  {
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserCost,&decision,&costmanager,&Cost_date));
	
			     printf("comment  costmanager of Reviwer : %s\n",costmanager);
	
				  ITK_CALL(ITK_date_to_string(Cost_date,&CostEndDate));
	
				 printf("date of CostEndDate Reviwer : %s\n",CostEndDate);

				 if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the Cost Approve decision\n");

				   CostDecision="Approved";

				 }
				 else
				 {
					   printf("\n inside the Cost Rejected decision\n");

				        //CostDecision="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		   }
		  }
		  MEM_free(childtask);
		 }
		  if(tc_strcmp(objectname,"Chief Engineer")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		  {
		    printf("\n inside Chief Engineer \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));
			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerChief));
		   
		    printf("\n performerChief name is %s \n",performerChief);fflush(stdout);

			usernameChief=tc_strtok(performerChief,"("); 
			usernameChief1=tc_strtok(NULL,")"); 
			printf("\n performer usernameChief is1111111 %s \n",usernameChief);fflush(stdout);
		    printf("\n performer usernameChief1 is111111111111 %s \n",usernameChief1);fflush(stdout);
	
	        ITK_CALL(SA_find_user2(usernameChief1,&QuserChief));
	
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_ask_value_string(childtask[j],"object_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMSelectSignoffTask")==0)
			 {
	
			  if(QuserChief!=NULLTAG)
			  {
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserChief,&decision,&chiefengg,&Chief_date));
	
			     printf("comment  chiefengg of Reviwer : %s\n",chiefengg);
	
				 ITK_CALL(ITK_date_to_string(Chief_date,&ChiefEndDate));
	
				 printf("date of ChiefEndDate Reviwer : %s\n",ChiefEndDate);  //	14-Dec-2023 17:34

				  if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the Chief Approve decision\n");

				   ChiefDecision="Approved";

				 }
				 else
				 {
					   printf("\n inside the Chief Rejected decision\n");

				        ChiefDecision="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		     }
		   }
		   MEM_free(childtask);
		 }
		  if(tc_strcmp(objectname,"Proceed /Re-raise with rework/Redirect to PL (By COC)")==0) // || (tc_strcmp(objectname,"TS input and sign-off")==0) || (tc_strcmp(objectname,"Cost manager input and sign-off")==0) ||(tc_strcmp(objectname,"Chief Engineer")==0))
		 {
		    printf("\n inside PLCOC \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));
			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerPLProceed));
		   
		    printf("\n performerPLProceed name is %s \n",performerPLProceed);fflush(stdout);
		    printf("\n performerPLProceed count is %d \n",childcount);fflush(stdout);

			usernamePLProceed=tc_strtok(performerPLProceed,"("); 
			usernamePLProceed1=tc_strtok(NULL,")"); 
			printf("\n performer usernamePLProceed is1111111 %s \n",usernamePLProceed);fflush(stdout);
		    printf("\n performer usernamePLProceed1 is111111111111 %s \n",usernamePLProceed1);fflush(stdout);
	
	        ITK_CALL(SA_find_user2(usernamePLProceed1,&QuserPLProc));
	
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_UIF_ask_value(childtask[j],"task_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMPerformSignoffTask")==0)
			 {
	
			  if(QuserPLProc!=NULLTAG)
			  {
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserPLProc,&decision,&PLCOC,&PL_date));
	
			     printf("comment  PLCOC of Reviwer : %s\n",PLCOC);
	
				  ITK_CALL(ITK_date_to_string(PL_date,&PLEndDate));
	
				 printf("date of PLEndDate Reviwer : %s\n",PLEndDate);


				  if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the PLCOC Approve decision\n");

				   PLCOCDecision="Approved";

				 }
				 else if (decision==EPM_reject_decision)
				
				 {
					   printf("\n inside the PLCOC Rejected decision\n");

				        PLCOCDecision="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		     }
		   }
		   MEM_free(childtask);
		 }

		 if(tc_strcmp(objectname,"Proceed/Rework(by PL)")==0)
		 {
		    printf("\n inside Proceed/Rework(by PL) \n");
			ITK_CALL(EPM_ask_sub_tasks(subtask[i],&childcount,&childtask));
			ITK_CALL(AOM_UIF_ask_value(subtask[i],"fnd0Performer",&performerPLProceed));
		   
		    printf("\n performerPLProceed name is %s \n",performerPLProceed);fflush(stdout);
		    printf("\n performerPLProceed count is %d \n",childcount);fflush(stdout);

			Proceedreraise=tc_strtok(performerPLProceed,"("); 
			Proceedreraise1=tc_strtok(NULL,")"); 
			printf("\n performer Proceedreraise is1111111 %s \n",Proceedreraise);fflush(stdout);
		    printf("\n performer Proceedreraise1 is111111111111 %s \n",Proceedreraise1);fflush(stdout);       ////ProceedComment        
																											    //ProceedSignoffDate
																											    //ProceedStatus          
																											    //Proceedreraise
	
	        ITK_CALL(SA_find_user2(Proceedreraise1,&QuserPLProc));
	
		   for(j=0;j<childcount;j++)
		   {
			 ITK_CALL(AOM_UIF_ask_value(childtask[j],"task_type",&subobjtyp));

		     if(tc_strcmp(subobjtyp,"EPMPerformSignoffTask")==0)
			 {
	
			  if(QuserPLProc!=NULLTAG)
			  {
			
			     ITK_CALL(EPM_ask_decision(childtask[j],QuserPLProc,&decision,&ProceedComment,&ProceedSignoffDate1));
	
			     printf("comment  ProceedComment of Reviwer : %s\n",ProceedComment);
	
				ITK_CALL(ITK_date_to_string(ProceedSignoffDate1,&ProceedSignoffDate));
	
				 printf("date of ProceedSignoffDate Reviwer : %s\n",ProceedSignoffDate);


				  if(decision==EPM_approve_decision)
				 {
				   
				   printf("\n inside the ProceedComment Approve decision\n");

				   ProceedStatus="Approved";

				 }
				 else if (decision==EPM_reject_decision)
				
				 {
					   printf("\n inside the ProceedComment Rejected decision\n");

				        ProceedStatus="Rejected";
				   
				 }
				 
				// printf("Approve Date %d\n",date);
	
			     //printf("date of Reviwer %d\n",decision_date);
	
	             //return 0;
			  }
		     }
		   }
		   MEM_free(childtask);
		 }
		
	
	}
	MEM_free(subtask);

	if((tc_strcmp(PLCOCDecision,"Rejected")==0) || (tc_strcmp(ProceedStatus,"Rejected")==0))
	{
        tc_strcpy(documentNameS1,"");
        tc_strcat(documentNameS1,"TMKO");
        tc_strcat(documentNameS1,"_");
        tc_strcat(documentNameS1,DocHeaderNo);
        tc_strcat(documentNameS1,"_");
        tc_strcat(documentNameS1,"*");

		printf("\n Document name is\n%s",documentNameS1); fflush(stdout);
		if(QRY_find2("General...", &DVLORel));

		printf("\n Querying the form data......\n"); fflush(stdout);

		char *sc_entry1[2] = {"Name","Type"};
		char **sc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));

		sc_RelVal[0] = documentNameS1;
		sc_RelVal[1] = "T5_TMKO_REF_Form";

		ITK_CALL(QRY_execute(DVLORel, 2, sc_entry1, sc_RelVal, &TMKO__count, &TMKO_Form_objects));

		printf("\n Query count is%d\n",TMKO__count); fflush(stdout);
        

		for(l=0; l<TMKO__count; l++)
		{
			TMKO_Form_tag=TMKO_Form_objects[l];
		   ITK_CALL(AOM_UIF_ask_value(TMKO_Form_tag,"object_name",&Objectname99));

		//TMKO_025348_1
		//TMKO_025348_2
		//TMKO_025348_3
		dfq_dataset_incremental_value = NULL;
		
		tc_strtok(Objectname99,"_"); 
		tc_strtok(NULL,"_");
		dfq_dataset_incremental_value = tc_strtok(NULL," ");
              
						
         printf("dfq_dataset_incremental_value Name ------- %s\n",dfq_dataset_incremental_value);fflush(stdout);
		incremental_value_latest = atoi(dfq_dataset_incremental_value);

		printf("\nincremental_value_latest :: %d\n",incremental_value_latest) ;
		printf("\nincremental_value :: %d\n",incremental_value) ; fflush(stdout);
		if(incremental_value_latest > incremental_value) incremental_value = incremental_value_latest;
		
		}

		//if()


        incremental_value++;      ///TMKO_025348_001
	    if(incremental_value < 20)
	   {
			
		sprintf(documentNameS,"TMKO_%s_00%d",DocHeaderNo,incremental_value);
		printf("\nDocument name is sp %s\n",documentNameS) ; fflush(stdout);


		}


			


		ITK_CALL( TCTYPE_find_type( "T5_TMKO_REF_Form", NULL, &TMKODoc));
		ITK_CALL(TCTYPE_construct_create_input(TMKODoc, &object_Tmko));                                
		ITK_CALL(AOM_set_value_string(object_Tmko,"object_name",documentNameS));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ERCCOCComment",ERCCOC));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ERCCOCStatus",CoCdecision1));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ERCCOCOwner",usernameCoc));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ERCCOCSignoffDate",enddateEP));

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_chiefEngineerComment",chiefengg));       
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_chiefEngineersignoff",usernameChief)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_chiefEngineerSignoffDate",ChiefEndDate)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_chiefEngineerStatus",ChiefDecision));

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_AQinputandsignoff",usernameAQ));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_AQinputComment",AQsign));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_AQinputSignoffDate",AQEndDate));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_AQinputStatus",AQDecision));

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_TSinputandsignoff",usernameTS)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_TSinputStatus",TSDecision)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_TSinputComment",TSInput)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_TSinputSignoffDate",TSEndDate));

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_CostmanagerComment",costmanager)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_Costmanagerinput",usernameCost));   //t5_Costmanagerinput 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_CostmanagerSignoffDate",CostEndDate)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_CostmanagerStatus",CostDecision));


		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_FMQinputandsignoff",usernameFMQ)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_FMQinputStatus",FMQDecision)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_FMQinputComment",CurrentId)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_FMQinputSignoffDate",FMQ_dateEndDate)); 

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_PLreworkOwner",usernamePLProceed)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_PLStatus",PLCOCDecision)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_PLComment",PLCOC)); 
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_PLSignoffDate",PLEndDate));


		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ProceedComment",ProceedComment));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ProceedSignoffDate",ProceedSignoffDate));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ProceedStatus",ProceedStatus));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_Proceedreraise",Proceedreraise));

		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ConditionComment",Decisioncomment));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ConditionStatus",decisionsatus));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ConditionreworkOwner",usernameDecision));
		ITK_CALL(AOM_set_value_string(object_Tmko,"t5_ConditionSignoffDate",Decisondate));
		
		
        ITK_CALL(TCTYPE_create_object(object_Tmko,&datasettag));
		ITK_CALL(AOM_save_with_extensions(datasettag));
		ITK_CALL(AOM_refresh(datasettag,0));


	
	
	}



			


		}


	return ITK_ok;

}

//int TmkoPartDetails(char* str,filechar **temp2,char **temp3)
//{
//
//	int itr=0;
//    int itr2=0;
//
//	char *temp=(char*)malloc(sizeof(char)*500);
//    char *temp2=(char*)malloc(sizeof(char)*500);
//	 for(int i=0;str[i]!='\0';i++)
//    {
//
//		 if(str[i]==',')
//        {
//            temp[itr]='\0'; 
//            itr=0;
//            
//            printf(" temp = %s \n",temp);
//            for(int j=0;temp[j]!='\0';j++)
//            {
//                if(temp[j]=='-')
//                {
//                    break;
//                }
//                else
//                {
//                    temp2[itr2]=temp[j]; 
//                    itr2++;
//                }
//            }
//            temp2[itr2]='\0';
//            
//            printf(" temp2 = %s \n",temp2);
//            itr2=0;
//			return temp2;
//            
//        }
//		else if(str[i+1]=='\0')
//        {
//            temp[itr]=str[i];
//            itr++;
//            temp[itr]='\0'; 
//            itr=0;
//            
//              printf(" temp = %s \n",temp);
//             
//             for(int j=0;temp[j]!='\0';j++)
//            {
//                if(temp[j]=='-')
//                {
//                    break;
//                }
//                else
//                {
//                    temp2[itr2]=temp[j]; 
//                    itr2++;
//                }
//            }
//            temp2[itr2]='\0';
//            printf(" temp2 = %s \n",temp2);
//        }
//        else
//        {
//            temp[itr]=str[i];
//            itr++;
//        }
//
//	}
//
//
//
//}

int TMKO_PDF_Generation( EPM_action_message_t msg )
{

	tag_t  rootTask     = NULLTAG;
	tag_t  attachments1     = NULLTAG;
	tag_t* attachments  = NULLTAG;

	int noAttachment = 0;

	char* objecttype    = NULL;
	char* Remark1    = NULL;
	char* Remark2    = NULL;
	char* Remark3    = NULL;
	char* Remark4    = NULL;
	char* Remark5    = NULL;
	char* Remark6    = NULL;
	char* Remark7    = NULL;
	char* Remark8    = NULL;
	char* Remark9    = NULL;
	char* Remark10    = NULL;
	char* DocHeaderNo    = NULL;
	char* fsuccess_nam1    = NULL;
	char* Project_Code    = NULL;
	char* Project_Name    = NULL;
	char* PartNumber    = NULL;
	char* PartLevelTargets    = NULL;
	char* DFMEACompleted    = NULL;
	char* CAEFeedbackIncorporated    = NULL;
	char* Costtargetvconfirmed    = NULL;
	char* CriticalIssue    = NULL;
	char* CTRDVPUpdasapplicable    = NULL;
	char* DigitalPhysical    = NULL;
	char* DigitalPhysicalCrafts    = NULL;
	char* WeightTargetVConfirmed    = NULL;
	char* TestingFeedbIncorporated    = NULL;
	char* fsuccess_nam=NULL;
	char* Csvpath=NULL;
	FILE* file=NULL;
	Csvpath = (char *)MEM_alloc(200);
	fsuccess_nam = (char *)MEM_alloc(200);
	tag_t PartMaster=NULLTAG;
	tag_t PartRevision=NULLTAG;
	char * partname=NULL;
	char * partnamedup=NULL;
	char * partnumber=NULL;
	char * itemrevisionid=NULL;
	char * releasestatus=NULL;
	char *drawingindicator=NULL;
	char *TMKODocPath=NULL;
	char *TMKODocShellPath=NULL;
    char * command    = NULL;
	command = (char *)MEM_alloc(500);
	char *temp=(char*)malloc(sizeof(char)*500);
	char *temp2=(char*)malloc(sizeof(char)*500);


	int j=0;
	int i=0;
	int k=0;
	int itr2=0;
	int itr=0;


	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Inside the TMKO_PDF_Generation Condition ...\n");fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n TMKO_PDF_Generation Target Attachment:%d \n",noAttachment);fflush(stdout);

	if(noAttachment>0)
	{
		attachments1=attachments[j];

		ITK_CALL(AOM_ask_value_string(attachments1,"object_type",&objecttype));
		printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);


		if(tc_strcmp(objecttype,"T5_TMKOHeaderRevision")==0)
		{
		  ITK_CALL(AOM_ask_value_string(attachments1,"item_id",&DocHeaderNo));
		
		   printf("\n Name of TMKO Document %s \n",DocHeaderNo);fflush(stdout);


		   ITK_CALL(AOM_ask_value_string(attachments1,"item_id",&DocHeaderNo));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark1",&Remark1));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark2",&Remark2));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark3",&Remark3));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark4",&Remark4));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark5",&Remark5)); 
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark6",&Remark6));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark7",&Remark7));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark8",&Remark8));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark9",&Remark9));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Remark10",&Remark10));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_Project_Code",&Project_Code)); 
			//ITK_CALL(AOM_UIF_ask_value(attachments1,"t5projectname",&Project_Name)); 
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_CAEFeedbackIncorporated",&CAEFeedbackIncorporated));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_DFMEACompleted",&DFMEACompleted));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Costtargetvconfirmed",&Costtargetvconfirmed));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_CriticalIssue",&CriticalIssue));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_CTRDVPUpdasapplicable",&CTRDVPUpdasapplicable));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_DigitalPhysical",&DigitalPhysical));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_DigitalPhysicalCrafts",&DigitalPhysicalCrafts));
			ITK_CALL(AOM_ask_value_string(attachments1,"t5_Part_Number",&PartNumber));     //141-A;2,255-B;1

			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_PartLevelTargets",&PartLevelTargets));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_WeightTargetVConfirmed",&WeightTargetVConfirmed));
			ITK_CALL(AOM_UIF_ask_value(attachments1,"t5_TestingFeedbIncorporated",&TestingFeedbIncorporated));

			printf("\n Name of TMKO Document %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Part Number %s \n",PartNumber);fflush(stdout);

			
			ITK_CALL(PREF_ask_char_value("T5_TMKOCSV_Destination_path",0,&TMKODocPath));

             /*tc_strcpy(fsuccess_na,"");
             tc_strcpy(fsuccess_na,TMKODocPath);
			 sprintf(fsuccess_na,"TMKO Document 1.csv");*/
	         

			 tc_strcpy(Csvpath,"");
             tc_strcpy(Csvpath,TMKODocPath);
             // sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
	         sprintf(fsuccess_nam,"TMKO_Document_1.csv");
             tc_strcat(Csvpath,fsuccess_nam);
			 //file = fopen(fsuccess_na,"w");
			 file = fopen(Csvpath,"w");
			 if(file==NULL)
			 {

			   printf("Unable to Open File \n");
			   return 1;

			 }
             fprintf(file,",,,ONLINE PRODUCTION TOOLING MACHINING KICK-OFF\n\n");
			 fprintf(file,",,,Program Details\n\n");
			 fprintf(file,"Project Code,%s,,Project Name,%s\n\n",Project_Code,Project_Code);
			 fprintf(file,"Part Details\n");
			 fprintf(file,"Part Number,Part Name,Drawing Number,SOR Category,HML Classification,Mod. Number,Sequence Number,Release Status");
			 fprintf(file,"\n\n"); 
			 //TmkoPartDetails(PartNumber,&partnumber1,&itemrevisionid1);
			  for(i=0;PartNumber[i]!='\0';i++)
              {

				 if(PartNumber[i]==',')
				{
					temp[itr]='\0'; 
					itr=0;
					
					printf(" temp = %s \n",temp);
					for(k=0;temp[k]!='\0';k++)
					{
						printf("\n inside loop first \n");
						if(temp[k]=='-')
						{
							break;
						}
						else
						{
							printf("\n inside loop first else \n");
							temp2[itr2]=temp[k]; 
							itr2++;
						}
					}
					temp2[itr2]='\0';
					printf(" temp2*** = %s \n",temp2);

					ITK_CALL(ITEM_find_item(temp2,&PartMaster));

					ITK_CALL(ITEM_ask_latest_rev(PartMaster,&PartRevision)); 

					ITK_CALL(AOM_ask_value_string(PartRevision,"object_name",&partnumber));
					printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(PartRevision,"object_desc",&partname));
					printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);
					ITK_CALL(STRNG_replace_str(partname,","," ",&partnamedup)); 

					printf("\n Part Object Name  %s \n",partnamedup);fflush(stdout); 

					ITK_CALL(AOM_ask_value_string(PartRevision,"t5_DrawingInd",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"SOR CATEGORY",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"HML CALSSIFICATION",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"MOD ",&drawingindicator));

					ITK_CALL(AOM_ask_value_string(PartRevision,"item_revision_id",&itemrevisionid));
					printf("\n Part Object Name itemrevisionid  %s \n",itemrevisionid);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(PartRevision,"release_status_list",&releasestatus));
					

					printf("\n Part Release status  %s \n",releasestatus);fflush(stdout);
			        fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s\n",temp2,partnamedup,"NA","NA","NA","NA",itemrevisionid,releasestatus);
					
					printf(" temp2 = %s \n",temp2);
					itr2=0;
					
					
				}
				else if(PartNumber[i+1]=='\0')
				{
					temp[itr]=PartNumber[i];
					itr++;
					temp[itr]='\0'; 
					itr=0;
					
					  printf(" temp = %s \n",temp);
					 
					 for(k=0;temp[k]!='\0';k++)
					{
						 printf("\n inside loop second \n");
						if(temp[k]=='-')
						{
							break;
						}
						else
						{
							printf("\n inside loop second else \n");
							temp2[itr2]=temp[k]; 
							itr2++;
						}
					}
					temp2[itr2]='\0';
					printf(" temp2 =*********** %s \n",temp2);

					ITK_CALL(ITEM_find_item(temp2,&PartMaster));

					ITK_CALL(ITEM_ask_latest_rev(PartMaster,&PartRevision)); 

					ITK_CALL(AOM_ask_value_string(PartRevision,"object_name",&partnumber));
					printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(PartRevision,"object_desc",&partname));
					printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);
					ITK_CALL(STRNG_replace_str(partname,","," ",&partnamedup)); 

					printf("\n Part Object Name  %s \n",partnamedup);fflush(stdout); 

					ITK_CALL(AOM_ask_value_string(PartRevision,"t5_DrawingInd",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"SOR CATEGORY",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"HML CALSSIFICATION",&drawingindicator));

					//ITK_CALL(AOM_ask_value_string(PartRevision,"MOD ",&drawingindicator));

					ITK_CALL(AOM_ask_value_string(PartRevision,"item_revision_id",&itemrevisionid));
					printf("\n Part Object Name itemrevisionid %s \n",itemrevisionid);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(PartRevision,"release_status_list",&releasestatus));
					printf("\n Part Object Name releasestatus %s \n",releasestatus);fflush(stdout); 

					printf("\n Part Release status  %s \n",releasestatus);fflush(stdout);
			        fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s\n",temp2,partnamedup,"NA","NA","NA","NA",itemrevisionid,releasestatus);
				}
				else
				{
					temp[itr]=PartNumber[i];
					itr++;
				}

			  }
			 
             
			 fprintf(file,"\n\n"); 
			 fprintf(file,",Part Development Summary");
			 fprintf(file,"\n\n");
			 fprintf(file,"Description,Status,Remarks"); 
			 fprintf(file,"\n");
			 fprintf(file,"DFMEA Completed,%s,%s\n",DFMEACompleted,Remark1);
             fprintf(file,"CAE Feedback Incorporated,%s,%s\n",CAEFeedbackIncorporated,Remark2);
             fprintf(file,"Testing Feedback Incorporated,%s,%s\n",TestingFeedbIncorporated,Remark3);
             fprintf(file,"Weight Target Visibility Confirmed,%s,%s\n",WeightTargetVConfirmed,Remark4);
             fprintf(file,"Cost Target Visibility Confirmed,%s,%s\n",Costtargetvconfirmed,Remark5);
             fprintf(file,"CTR/DVP Updated as applicable,%s,%s\n",CTRDVPUpdasapplicable,Remark6);
             fprintf(file,"Part Level Targets(PQ/CA/PAT/Quality) Confirmed,%s,%s\n",PartLevelTargets,Remark7);
             fprintf(file,"Digital/Physical Craftmanship Audit/Optical Quality Confirmed,%s,%s\n",DigitalPhysicalCrafts,Remark8);
             fprintf(file,"Critical Issue Brochure issues closed,%s,%s\n",CriticalIssue,Remark9);
             fprintf(file,"Digital/Physical build issues incorporated,%s,%s\n",DigitalPhysical,Remark10);


		   }
		   fclose(file);
		   ITK_CALL(PREF_ask_char_value("T5_TMKO_Shell_Destination_path",0,&TMKODocShellPath));
		   printf("\n TMKO Shell Destination path is %s \n",TMKODocShellPath);fflush(stdout);

		   tc_strcpy(command,"");
           //tc_strcat(command,"/user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/");  
           tc_strcat(command,TMKODocShellPath);  
		   tc_strcat(command,"convertcsv_topdf.sh");
	       tc_strcat(command," ");
	       tc_strcat(command,fsuccess_nam);
		   printf("\n Before exicute %s\n",command);
		   system(command);


        printf("\n END of PDF Generation \n");
	   return ITK_ok;
	
	
	
	}
}


int TMKO_Mail_approve( EPM_action_message_t msg )
{
	char* DocHeader_id									=NULL;
	char* ObjType							=NULL;
	char* CurrentId								=NULL;
	char* LastModUsr						=NULL;
	char* creationdate								=NULL;
	char* subobjtyp                               =NULL;  


	tag_t		DocHeaderTag		= NULLTAG;
	tag_t		LatestDocHeaderRevTag	= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		person_tag			= NULLTAG;
	char*		person_name			= NULL;
	char* objectname								=NULL;


	tag_t job_Tag	= NULLTAG;
	tag_t rootTask	= NULLTAG;
	tag_t* subtask	= NULLTAG;
	tag_t* TMKO_Form_objects	= NULLTAG;
	tag_t* childtask	= NULLTAG;
	//date_t decision_date;
	int tskcount =0;
	int childcount =0;
	//int EPM_signoff_attachment =0;
	int i =0;
	int j =0;
	tag_t jobtype_Tag	= NULLTAG;
	tag_t subtaskt	= NULLTAG;
	tag_t Quser	= NULLTAG;
	EPM_signoff_decision_t 	decision;
	char * 	comments= NULL;
	char * 	chiefengg= NULL;
	char * 	costmanager= NULL;
	char * 	TSInput= NULL;
	char * 	PLCOC= NULL;
	char * 	ERCCOC= NULL;
	char * 	person= NULL;
	char * 	wfEndDate= NULL;
	char * 	AQsign= NULL;
	char * 	FMQ_dateEndDate= NULL;
	char * 	AQEndDate= NULL;
	char * 	PLEndDate= NULL;
	char * 	ChiefEndDate= NULL;
	char * 	CostEndDate= NULL;
	char * 	TSEndDate= NULL;
	char* 	enddateEP= NULL;
	
	char * 	subsubtaskname1PL= NULL;
	char * 	username1= NULL;
	char * 	username2= NULL;
	date_t 	decision_date = NULLDATE;
	date_t 	FMQ_date = NULLDATE;
	date_t 	AQ_date = NULLDATE;
	date_t 	PL_date = NULLDATE;
	date_t 	Chief_date = NULLDATE;
	date_t 	Cost_date = NULLDATE;
	date_t 	TS_date = NULLDATE;
	date_t 	ProceedSignoffDate1 = NULLDATE;

	tag_t QuserChief  = NULLTAG;
	tag_t QuserCost	  = NULLTAG;
	tag_t QuserTS	  = NULLTAG;
	tag_t QuserFMQ	  = NULLTAG;
	tag_t  QuserAQ   = NULLTAG;
	tag_t  QuserPLProc   = NULLTAG;
	tag_t  TMKO_Form_tag   = NULLTAG;
	tag_t  DVLORel   = NULLTAG;
	tag_t  TMKODoc   = NULLTAG;
	
	char *usernameChief          = NULL;
	char *usernameCost			 = NULL;
	char *usernameTS			 = NULL;
	char *usernameFMQ			 = NULL;
	char *usernameAQ			 = NULL;
	char *usernamePLProceed			 = NULL;
	char *usernameCoc			 = NULL;
								 
	char *usernameChief1		 = NULL;
	char *usernameCost1			 = NULL;
	char *usernameTS1			 = NULL;
	char *usernameFMQ1			 = NULL;
	char *usernameAQ1			 = NULL;
	char *usernamePLProceed1			 = NULL;
	char *usernameCoc1			 = NULL;
	//EPM_signoff_decision_t *ProceedStatus			 = NULL;
	char * ProceedStatus			 = NULL;
								
	char *performerChief		 = NULL;
	char *performerTS			 = NULL;
	char *performerCost			 = NULL;
	char *performerFMQ			 = NULL;
	char *performerAQ			 = NULL;
	char *performerPLProceed			 = NULL;
	char *performerCoC			 = NULL;
	char *Proceedreraise			 = NULL;
	char *ProceedSignoffDate			 = NULL;
	
	char * PLCOCDecision    = NULL;
	char * PLCOCDecision2    = NULL;
	char * ChiefDecision	= NULL;
	char * CostDecision		= NULL;
	char * TSDecision		= NULL;
	char * AQDecision		= NULL;
	char * FMQDecision		= NULL;
	char * CoCdecision		= NULL;
	char * CoCdecision1		= NULL;
	char * documentNameS    = NULL;
	char * documentNameS1    = NULL;
	char * Objectname99    = NULL;
	char * ProceedComment    = NULL;
	char * command    = NULL;
	char* dfq_dataset_incremental_value = NULL;
	documentNameS = (char *)MEM_alloc(50);
	documentNameS1 = (char *)MEM_alloc(50);
	command = (char *)MEM_alloc(500);
	int incremental_value = 0;
	int TMKO__count = 0;
	//int incremental_value = 0;
	int incremental_value_latest = 0;
	int l = 0;
	tag_t	object_Tmko =NULLTAG;
	tag_t	datasettag =NULLTAG;
	
			
	//tag_t rootTask		=  NULLTAG;
	tag_t attachments1		=  NULLTAG;
	tag_t* attachments		=  NULLTAG;
	char* username         = NULL;
	char* CurrentTask         = NULL;
	char* objecttype         = NULL;
	char* parent_name         = NULL;
	char* DocHeaderNo         = NULL;
	char* Proceedreraise1         = NULL;
	char* Decisioncomment         = NULL;
	char* Decisondate         = NULL;
	char* decisionsatus         = NULL;
	char* Decisioncond         = NULL;
	char* usernameDecision         = NULL;
	char* usernameDecision1         = NULL;
	int noAttachment = 0 ;

	     
	 
	      
	     	
		
	    ITK_CALL(POM_get_user_id (&username));
		printf("\n TMKO Session User is : %s \n",username); fflush(stdout);

		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		{

			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n Inside the TMKO Approved Condition ...\n");fflush(stdout);

			ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			printf("\n TMKO- CurrentTask: %s \n",CurrentTask);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			printf("\n TMKO- parent Name: %s \n",parent_name);fflush(stdout);

			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("\n TMKO- Target Attachment:%d \n",noAttachment);fflush(stdout);

			for(j=0; j<noAttachment;j++)
			{
			
			attachments1=attachments[j];

			ITK_CALL(AOM_ask_value_string(attachments1,"object_type",&objecttype));
			printf("\n  TMKO Document object_type %s \n",objecttype);fflush(stdout);


			if(tc_strcmp(objecttype,"T5_TMKOHeaderRevision")==0)
			{
			ITK_CALL(AOM_ask_value_string(attachments1,"item_id",&DocHeaderNo));
			
			printf("\n Name of TMKO Document %s \n",DocHeaderNo);fflush(stdout);

			
			}
			
			
			
			
			
			}


	    tc_strcpy(documentNameS1,"");
        tc_strcat(documentNameS1,"TMKO");
        tc_strcat(documentNameS1,"_");
        tc_strcat(documentNameS1,DocHeaderNo);
        tc_strcat(documentNameS1,"_");
        tc_strcat(documentNameS1,"*");

		printf("\n Document name is\n%s",documentNameS1); fflush(stdout);
		if(QRY_find2("General...", &DVLORel));

		printf("\n Querying the form data......\n"); fflush(stdout);

		char *sc_entry1[2] = {"Name","Type"};
		char **sc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));

		sc_RelVal[0] = documentNameS1;
		sc_RelVal[1] = "T5_TMKO_REF_Form";

		ITK_CALL(QRY_execute(DVLORel, 2, sc_entry1, sc_RelVal, &TMKO__count, &TMKO_Form_objects));

		printf("\n Query count is\n%d",TMKO__count); fflush(stdout);

		if(TMKO__count==0)
		{
			printf("\n inside the 00 shell condition \n");

		 tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
	     tc_strcat(command,"TMKO_Mail.sh");
	     tc_strcat(command," ");
	     tc_strcat(command,DocHeaderNo);
	 

	     printf("\n\tCommand : %s", command);
	     system(command);

		 printf("\n Shell calling sucessfully 00\n"); fflush(stdout);
		 printf("\n Name of TMKO Document in shell call 00 %s \n",DocHeaderNo);fflush(stdout);
		 printf("\n Shell path %s \n",command);fflush(stdout);
	    
		
		
		}
		else if(TMKO__count==1)
		{

		 printf("\n inside the 01 shell condition \n");
		 tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
	     tc_strcat(command,"TMKO_Mail_1.sh");
	     tc_strcat(command," ");
	     tc_strcat(command,DocHeaderNo);
	
	     printf("\n\tCommand : %s", command);
	     system(command);


		 printf("\n Shell calling sucessfully 001\n"); fflush(stdout);
		 printf("\n Name of TMKO Document in shell call 01 %s \n",DocHeaderNo);fflush(stdout);
		 printf("\n Shell path %s \n",command);fflush(stdout);
	     
		
		}
        else if(TMKO__count==2)
		{

			printf("\n inside the 02 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_2.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);
			printf("\n Shell calling sucessfully 002\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 02 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==3)
		{

			printf("\n inside the 03 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_3.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);
			printf("\n Shell calling sucessfully 003\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 03 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==4)
		{

			printf("\n inside the 04 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_4.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);
			printf("\n Shell calling sucessfully 004\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 04 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==5)
		{

			printf("\n inside the 05 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_5.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);
			printf("\n Shell calling sucessfully 005\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 05 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);



		}
		else if(TMKO__count==6)
		{

			printf("\n inside the 06 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_6.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);
			printf("\n Shell calling sucessfully 006\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 06 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==7)
		{

			printf("\n inside the 07 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_7.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);

			printf("\n Shell calling sucessfully 007\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 07 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==8)
		{

			printf("\n inside the 08 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_8.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);

			printf("\n Shell calling sucessfully 008\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 08 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==9)
		{

			printf("\n inside the 09 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_9.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);

			printf("\n Shell calling sucessfully 009\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 09 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}
		else if(TMKO__count==10)
		{

			printf("\n inside the 10 shell condition \n");
			tc_strcat(command,"/user/uaprod/shells/TMKODoc/");
			tc_strcat(command,"TMKO_Mail_10.sh");
			tc_strcat(command," ");
			tc_strcat(command,DocHeaderNo);

			printf("\n\tCommand : %s", command);
			system(command);

			printf("\n Shell calling sucessfully 0010\n"); fflush(stdout);
			printf("\n Name of TMKO Document in shell call 10 %s \n",DocHeaderNo);fflush(stdout);
			printf("\n Shell path %s \n",command);fflush(stdout);


		}


		}

		
	


	return ITK_ok;

}

int FOURD_Doc_attach( EPM_action_message_t msg )
{

			
		///////////////////////////////////
	char buffer[80];
	char *   dmlno				= NULL;	
	char *	 username			= NULL;
	char *	 CurrentTask		= NULL;
	char *	 parent_name		= NULL;
	char *	 dmlNo				= NULL;
	char *	 dmlRevId			= NULL;
	char *	 refObjId			= NULL;
	char *   Breakdownobj		= NULL;
	char *   Desrlsstatus		= NULL;
	char *   Desid				= NULL;
	char *   DesRevid			= NULL;
	char *   testdmlno			= NULL;
	char *	 PartNumberS		= NULL;
	char *	 PartNumberSxls		= NULL;
	char *	 curentname			= NULL;
	char *	 DADname			= NULL;
	char *	 curentnameid		= NULL;
	char *	 curentnamexls		= NULL;
	char *	 ProjctCdeS			= NULL;
	char *	 curentModuleRelStat= NULL;
	char *	 ProjctCdeSxls		= NULL;
	char *	 tok				= NULL;
	char *	 tokxls				= NULL;
	char *	 Parttok			= NULL;
	char *	 Parttokxls			= NULL;
	char *	 PartRevtok			= NULL;
	char *	 PartRevtokxls		= NULL;
	char *	 PartSeqtok			= NULL;
	char *	 PartSeqtokxls		= NULL;
	char *	 ObjTok				= NULL;
	char *	 ObjTokxls			= NULL;
	char *   inputfile			= NULL;
	char *	 nwRev				= NULL;
	char *	 nwRev1				= NULL;
	char *	 nwRevxls			= NULL;
	char *	 PartTypeS			= NULL;
	char *	 PartTypeSxls		= NULL;
	char *	 DADNumber			= NULL;
	char *	 DOCno				= NULL;
	char *	 ObjTokpdf			= NULL;
	char *	 ReleaseStatus		= NULL;
	char *	 ReleaseStatusxls	= NULL;
	char *	 ReleaseStatuspdf	= NULL;
	char *	 PartRevSeq			= NULL;	
	char *	 pdfpath1			= NULL;
	char *	 xlspath1			= NULL;
	char *	 pdfpath			= NULL;
	char *	 xlspath			= NULL;
	char *	 inputline			= NULL;
	char *	 Lsmdate			= NULL;
	char *	 Filename           = NULL;
	char *	 inputlinenew		= NULL;
	char *	 inputlinenew1		= NULL;
	char *	 TypeNmetok			= NULL;
	char *	 Typetok			= NULL;
	char *	 Typetokxls			= NULL;
	char *	 inputfilenew		= NULL;
	char *	 TypeNmetokxls		= NULL;
	char *	 SerialNumtok		= NULL;
	char *	 SerialNumtokxls	= NULL;
	char *	 latest_rev_Rel_Stus= NULL;
	char *	 latest_rev_Rel_Stusxls= NULL;
	char *	 T5_DAD_Document_item_id= NULL;
	//char*   path	= NULL;		
	char	ObjType[WSO_name_size_c+1];
	//char	objType[WSO_name_size_c+1];
	char*	objType =NULL;
	//char	RefobjType[WSO_name_size_c+1];
	char*	RefobjType = NULL;
	char    orig_nameAttach[IMF_filename_size_c + 1];
	char	refname[AE_reference_size_c + 1];
	tag_t   rootTask			= NULLTAG;
	tag_t   DMLTag				= NULLTAG;
	tag_t   DML_tag				= NULLTAG;
	tag_t	DMLRevTag1			= NULLTAG;
	tag_t   objTypTag			= NULLTAG;
	tag_t   RefobjTypTag		= NULLTAG;
	tag_t   DesRevtag			= NULLTAG;
	tag_t   Rel4D				= NULLTAG;
	tag_t   Refobj				= NULLTAG;
	tag_t	text_file			= NULLTAG;
	tag_t	refobjectAttach		= NULLTAG;
	tag_t	RefRelation			= NULLTAG;
	tag_t	Part_tag			= NULLTAG;
	tag_t	Part_tagxls			= NULLTAG;
	tag_t	latestrev			= NULLTAG;
	tag_t	Latestrev_Tag		= NULLTAG;
	tag_t	latestrevxls		= NULLTAG;
	tag_t	DatasetType			= NULLTAG;
	tag_t	DatasetTypexls		= NULLTAG;
	tag_t	PdfDataset			= NULLTAG;
	tag_t	XlsDataset			= NULLTAG;
	tag_t	specificationRel_t	= NULLTAG;
	tag_t	specificationRel_txls=NULLTAG;
	tag_t	PdfLatestDat_t		= NULLTAG;
	tag_t	relationSpeci_type;
	tag_t	relationSpeci_typexls;
	tag_t	FndSpeciRelation;
	tag_t	FndSpeciRelationxls;
	tag_t	dad_tagxls			= NULLTAG;
	tag_t	DADRel_t			= NULLTAG;
	tag_t	DADRel_txls			= NULLTAG;
	tag_t	tRelationFind		= NULLTAG;
	tag_t	tRelationFindxls	= NULLTAG;
	tag_t	tRelationExistxls	= NULLTAG;
	tag_t	tRelationExist		= NULLTAG;
	tag_t	status_rel			= NULLTAG;
	tag_t	status_relxls		= NULLTAG;
	tag_t	status_relpdf		= NULLTAG;
	tag_t	ReqRev				= NULLTAG;
	tag_t	type_tag3			= NULLTAG;
	tag_t	DADrevTag			= NULLTAG;
	tag_t   dml_tag				= NULLTAG;
	tag_t	dad_tag				= NULLTAG;
	tag_t	dadrev_tag			= NULLTAG;
	tag_t	object_create_input_tag3 =NULLTAG;
	tag_t	object_create_input_tag3xls =NULLTAG ;
	tag_t   *attachments		= NULLTAG;
	tag_t   *tags_found4		= NULLTAG;
	tag_t   *RefcountTags		= NULLTAG;
	tag_t   *BreakdowncountTags = NULLTAG;
	tag_t   *DsgrevPartTags		= NULLTAG;
	tag_t   *has4Dsec_objects	= NULLTAG;
	tag_t   *Nmdref_object		= NULLTAG;
	tag_t   Namereferancetag	= NULLTAG;
	tag_t*	relStatus_list;
	tag_t*	relStatus_listxls;
	tag_t*	type_tag3xls;
	//tag_t	dad_tag1 =NULLTAG;

	logical	checkout			= 0;
	logical	checkoutxls			= 0;
	logical	checkout2			= 0;
	logical	checkout2xls		= 0;	
	logical	retain				= 0;
	logical	retainpdf			= 0;
		
	int     Refcount			= 0;
	int     Dsgnrevcount		= 0;
	int     Parthas4Dcount		= 0;
	int     number_of_types1	= 0;
	int     number_of_types1xls	= 0;
	int		status_count		= 0;
	int		status_countxls		= 0;
	int		ss					= 0;
	int		ss1					= 0;
	int     line_count			= 0;
	int		iStatus				= 0;
	int		Breakdowncount		= 0;
	int		ifail				= 0;
	int		n_tags_found4		= 0;
	int     NmdrefFound			= 0;
	int		i = 0;
	int		v = 0;
	int		m = 0;
	int		s = 0;
	int		r = 0;
	int		x = 0;
	int		N = 0;
	
	FILE	*fptr;
	int     status;

	IMF_file_data_p_t file_data;
	nwRev		=(char *) MEM_alloc(10);
/////////////////////////////////////////////
    Filename = (char *) MEM_alloc(sizeof(char)* 400);

	char *path = (char *) MEM_alloc(sizeof(char)* 100);
	//char*	username		= NULL;
	//char*	CurrentTask		= NULL;
	//char*	parent_name		= NULL;
	//char*	dmlNo			= NULL;
	//char*	dmlRevId		= NULL;
	//char*	refObjId		= NULL;
	//char*   Breakdownobj	= NULL;
	//char*   Desrlsstatus	= NULL;		
	//char	ObjType[WSO_name_size_c+1];
	//char	RefobjType[WSO_name_size_c+1];
	//tag_t   rootTask		= NULLTAG;
	//tag_t   DMLTag			= NULLTAG;
	//tag_t   DML_tag			= NULLTAG;
	tag_t	DMLRevTag		= NULLTAG;
	//tag_t   objTypTag		= NULLTAG;
	//tag_t   RefobjTypTag	= NULLTAG;
	//tag_t   DesRevtag		= NULLTAG;
	//tag_t   Rel4D			= NULLTAG;
	//tag_t   Refobj			= NULLTAG;
	//tag_t *attachments		= NULLTAG;
	//tag_t *RefcountTags		= NULL;
	//tag_t *BreakdowncountTags= NULL;
	//tag_t *DsgrevPartTags= NULL;
	//tag_t *has4Dsec_objects= NULL;

	int   noAttachment      = 0;
	//int   Breakdowncount    = 0;
	//int   Refcount			= 0;
	//int   Dsgnrevcount      = 0;
	//int   Parthas4Dcount    = 0;

		ITK_CALL(POM_get_user_id (&username));
		printf("\n 4D_update Session User is : %s \n",username); fflush(stdout);

		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		{

			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n Inside the 4D_update ...\n");fflush(stdout);

			ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			printf("\n 4D_update- CurrentTask: %s \n",CurrentTask);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			printf("\n 4D_update- parent Name: %s \n",parent_name);fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("\n 4D_update- Target Attachment:%d \n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{

				printf("\n Inside 4D Target Attachment:%d \n",noAttachment);fflush(stdout);
				DMLTag = attachments[0];

				ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&dmlNo));
				printf("\n 4D current- DML No: [%s] \n", dmlNo);fflush(stdout);


				if(ITEM_find_item(dmlNo, &DML_tag)!=ITK_ok)PrintErrorStack();

				if (DML_tag != NULLTAG)
				{
					printf("\n DML tag is not null for 4D_update DML No: [%s] \n", dmlNo);fflush(stdout);

					if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

					ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&dmlRevId));
					printf("\n  item_id is %s\n", dmlRevId);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"last_mod_date",&Lsmdate));
					printf("\n  Last modified date is %s\n", Lsmdate);fflush(stdout);

					ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));

					ITK_CALL(TCTYPE_ask_name2(objTypTag,&objType));
					printf("\n  object_type is %s\n", objType);fflush(stdout);

					if(tc_strcmp(objType,"ChangeRequestRevision")==0)   //IMAN_reference
					{

						ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelation));

						ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,RefRelation,&Refcount,&RefcountTags));
						printf("\n Reference count = %d\n",Refcount);fflush(stdout);
						//////////////////////////////////// PDF logic ///////////////////////////////////

						tc_strcpy(Filename,"/tmp/MDMpdfdata_");
						tc_strcat(Filename,Lsmdate);
						tc_strcat(Filename,".txt");
						printf("\n Filename = %s\n",Filename);fflush(stdout);

						fptr=fopen(Filename,"w");
						
						if(Refcount>0)
						{
						
							for (v=0;v<Refcount;v++)
							{		Refobj=RefcountTags[v];

									ITK_CALL(AOM_ask_value_string(Refobj,"object_name",&refObjId));
									printf("\n Reference Parts found = %s \n",refObjId);fflush(stdout);

									tc_strdup(refObjId,&DOCno);

									ITK_CALL(TCTYPE_ask_object_type(Refobj,&RefobjTypTag));

									ITK_CALL(TCTYPE_ask_name2(RefobjTypTag,&RefobjType));
									printf("\n object_type is %s\n", RefobjType);fflush(stdout);
									
									if(tc_strcmp(RefobjType,"PDF")==0)
									{
										//ITK_CALL(AOM_refresh(Refobj, TRUE));
										printf("\n NMRef found str......");fflush(stdout);
										ITK_CALL(AE_ask_all_dataset_named_refs2(Refobj,"PDF_Reference",&NmdrefFound,&Nmdref_object));  //Code Change
										printf("\n NMRef count = [%d]",NmdrefFound);fflush(stdout);

										pdfpath	=	(char	*)MEM_alloc(500);

										for (r=0;r<NmdrefFound;r++)
										{
												Namereferancetag = Nmdref_object[r];
												tc_strcpy(path,"");
												tc_strcpy(path,"/tmp/");
												//IMF_file_data_p_t file_data;
                                            	ITK_CALL(IMF_get_file_access(Namereferancetag, 0, &file_data));
                                            	ITK_CALL(AOM_refresh(Namereferancetag, TRUE));
                               
												printf("\npath: [%s]",path);
												//char myFname[IMF_filename_size_c+1];
												char* myFname =NULL;
												IMF_ask_original_file_name2(Namereferancetag,&myFname);
											
												tc_strcat(path,myFname);
												printf("\nafter path: [%s]\n",path);
												printf("\nmyFname: [%s]\n",myFname);
												tc_strcpy(pdfpath,"");
												tc_strcpy(pdfpath,myFname);
												printf("\n pdfpath: [%s]\n",pdfpath);

                                            	ITK_CALL(IMF_export_file(Namereferancetag,path));
                                            	ITK_CALL(AOM_unload(Namereferancetag));
											    ITK_CALL (AOM_save_with_extensions(Refobj));
                                                ITK_CALL (AOM_refresh(Refobj,FALSE));
                                            	ITK_CALL(AOM_unload(Refobj));
                                            	ITK_CALL(IMF_release_file_access (&file_data));
										}
									}

									fprintf(fptr,"%s,\n",refObjId);fflush(fptr);					
							}
												

						   if(tc_strstr(path,refObjId)!=NULL)
							{
						   
								ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Breakdowncount,&BreakdowncountTags));
						   
								if (Breakdowncount>0)
								{
						   
									for (m=0;m<Breakdowncount;m++)
									{
											ITK_CALL(AOM_ask_value_string(BreakdowncountTags[m],"item_id",&Breakdownobj));
											printf("\n for Breakdownobj Parts found = %s \n",Breakdownobj);fflush(stdout);
						   
											ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[m],"CMReferences",&Dsgnrevcount,&DsgrevPartTags)); //In Change References we get Design revision.				
											printf("\n for Design revision Parts found = %d\n",Dsgnrevcount);fflush(stdout);
						   
											if(Dsgnrevcount>0)
											{
						   
												for(s=0;s<Dsgnrevcount;s++)
												{
														
													DesRevtag=DsgrevPartTags[s];
						   
													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_id",&Desid));
													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"item_revision_id",&DesRevid));
													ITK_CALL(AOM_UIF_ask_value(DesRevtag,"release_status_list",&Desrlsstatus));

													printf("\n ..............................MODULE id = %s[%s]...............................................\n",Desid,DesRevid);fflush(stdout);
													printf("\n Design revision released status = %s\n",Desrlsstatus);fflush(stdout);
												    printf("\n tc_strstr(Desrlsstatus,Released) value is.... [%s]\n",tc_strstr(Desrlsstatus,"Released"));fflush(stdout);
												
													fptr=fopen(Filename,"r");

													printf("\n File is opened................... \n");fflush(stdout);
													if(tc_strstr(Desrlsstatus,"Released")!=NULL)
													{
													

													if(fptr!=NULL)
													{

													inputline=(char *) MEM_alloc(2000);
													inputlinenew =(char *)MEM_alloc(2000);
//
													while(fgets(inputline,2000,fptr)!=NULL)
													{
														printf("inputline[%03d]: %s", ++line_count, inputline);
														printf("\n inputline -------->  : [%s]\n",inputline);fflush(stdout);

														removeNewLineChar(inputline);
														tc_strcpy(inputlinenew,inputline);
														printf("\n inputlinenew------>  : [%s]\n",inputlinenew);fflush(stdout);
														ObjTok = MEM_alloc(35);
														ObjTok = tc_strtok(inputlinenew, ",");
														printf("\n ObjTok  : [%s]\n",ObjTok);fflush(stdout);
														DADNumber	=	(char	*)MEM_alloc(90);
														tc_strcpy(DADNumber,ObjTok);
														ObjTokpdf	=	(char	*)MEM_alloc(90);
														tc_strcpy(ObjTokpdf,DADNumber);
														tc_strcat(ObjTokpdf,".pdf");
														printf("\n ObjTokpdf------>  : [%s]\n",ObjTokpdf);fflush(stdout);

														ITK_CALL(GRM_find_relation_type("T5_PartHas4D", &Rel4D));                               
														printf("\n relation find T5_PartHas4D-------\n");fflush(stdout);
						   
														if (Rel4D!=NULLTAG)
														{
						   
															ITK_CALL(GRM_list_secondary_objects_only(DesRevtag, Rel4D, &Parthas4Dcount, &has4Dsec_objects));
															printf("\n T5_PartHas4D for 4D Total objects found------[%d]\n", Parthas4Dcount);
						   
//															if(Parthas4Dcount==0)
//															{
																printf("\n 4D object to be created.......\n");fflush(stdout);
						   
																	Typetok =NULL;
																	Parttok =NULL;
																	PartRevtok =NULL;
																	PartSeqtok =NULL;
																	SerialNumtok =NULL;
						   
																	Typetok = MEM_alloc(15);
																	Parttok = MEM_alloc(15);
																	PartRevtok = MEM_alloc(15);
																	PartSeqtok = MEM_alloc(15);
																	SerialNumtok = MEM_alloc(15);
						   
																	Typetok = tc_strtok(inputlinenew, "_");// DFA
																	Parttok = tc_strtok(NULL, "_");		// 1234567
																	PartRevtok = tc_strtok(NULL, "_");	//NR
																	PartSeqtok = tc_strtok(NULL, "_");	//1
																	SerialNumtok = tc_strtok(NULL, "_");//01
						   
																	PartRevSeq = MEM_alloc(5);
																	tc_strcpy(PartRevSeq,PartRevtok);
						   
																	printf("\n Typetok to find----------> = %s\n", Typetok);fflush(stdout);
																	printf("\n Parttok to find----------> = %s\n", Parttok);fflush(stdout);
																	printf("\n PartRevtok to find----------> = %s\n", PartRevtok);fflush(stdout);
																	printf("\n PartSeqtok to find----------> = %s\n", PartSeqtok);fflush(stdout);
																	printf("\n SerialNumtok to find----------> = %s\n", SerialNumtok);fflush(stdout);
																	printf("\n PartRevSeq to find----------> = %s\n", PartRevSeq);fflush(stdout);
																	
																	tc_strcat(PartRevSeq,";");
																	tc_strcat(PartRevSeq,PartSeqtok);
																	printf("\n PartRevSeq to find----------> = %s\n", PartRevSeq);fflush(stdout);
						   
																	PartTypeS = (char	*)MEM_alloc(10);
																	tc_strcpy(PartTypeS,Typetok);
																	printf("\n PartTypeS= [%s]\n",PartTypeS);fflush(stdout);
						   
																	PartNumberS = (char	*)MEM_alloc(50);
																	tc_strcpy(PartNumberS,Parttok);
																	printf("\n Part Number to find = [%s]\n",PartNumberS);fflush(stdout);
						   
																	ITK_CALL(ITEM_find_item (PartNumberS,&Part_tag));
						   
																	const char **attrs3  = ( const char **) MEM_alloc(1 * sizeof(char *));
																	const char **values3 = ( const char **) MEM_alloc(1 * sizeof(char *));
																	attrs3[0]	   ="item_id";
																	values3[0]     = (char *)PartNumberS;
						   
																	ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,attrs3, values3,PartRevSeq, &n_tags_found4, &tags_found4));
																	MEM_free(attrs3);
																	MEM_free(values3);
																	printf("\n revcount......%d\n",n_tags_found4);
						   
																	if (n_tags_found4>0)
																	{
																	   latestrev= tags_found4[0];
						   
																	}
																	else
																	{
																		continue;
																	}
						   
																	ITK_CALL(ITEM_ask_latest_rev(Part_tag,&Latestrev_Tag));	 ///trial Latestrev_Tag in replace of latestrev
						   
																	ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"item_id",&curentname));
																	printf("\ncurentname:%s\n",curentname);
						   
																	ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"item_revision_id",&curentnameid));
																	printf("\n curentnameid:%s \n",curentnameid);
						   
																	ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"t5_ProjectCode",&ProjctCdeS));
																	printf("\n Required revision---------------> [%s]and project code ---------->[%s]\n",curentnameid,ProjctCdeS);fflush(stdout);
						   
																	ITK_CALL(AOM_UIF_ask_value(Latestrev_Tag,"release_status_list",&curentModuleRelStat));
																	printf("\n curentModuleRelStat:%s \n",curentModuleRelStat);
																	//return 0;
//																	if(access(pdfpath,F_OK)!=-1)
//																	{
//																		printf("\n FILE PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");fflush(stdout);
//																	}
//																	else
//																	{
//																		printf("\n FILE NOT PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");fflush(stdout);
//																	}
//																	system("pwd");
						   
																printf("\n tc_strstr(curentModuleRelStat,Released) value is.... [%s]\n",tc_strstr(curentModuleRelStat,"Released"));fflush(stdout);

																if(tc_strstr(curentModuleRelStat,"Released")!=NULL)
																{

//																	if(tc_strcmp(ProjctCdeS,"2999")==0||tc_strcmp(ProjctCdeS,"2724")==0|| tc_strcmp(ProjctCdeS,"2829")==0|| tc_strcmp(ProjctCdeS,"2956")==0|| tc_strcmp(ProjctCdeS,"5483")==0|| tc_strcmp(ProjctCdeS,"5482")==0|| tc_strcmp(ProjctCdeS,"5481")==0|| tc_strcmp(ProjctCdeS,"5480")==0|| tc_strcmp(ProjctCdeS,"5479")==0|| tc_strcmp(ProjctCdeS,"5478")==0|| tc_strcmp(ProjctCdeS,"5477")==0||tc_strcmp(ProjctCdeS,"5458")==0|| tc_strcmp(ProjctCdeS,"5442")==0|| tc_strcmp(ProjctCdeS,"5485")==0 || tc_strcmp(ProjctCdeS,"5445")==0 || tc_strcmp(ProjctCdeS,"5447")==0 || tc_strcmp(ProjctCdeS,"5438")==0 || tc_strcmp(ProjctCdeS,"5457")==0 || tc_strcmp(ProjctCdeS,"5464")==0 || tc_strcmp(ProjctCdeS,"5465")==0 || tc_strcmp(ProjctCdeS,"5466")==0 || tc_strcmp(ProjctCdeS,"5468")==0 || tc_strcmp(ProjctCdeS,"5471")==0 || tc_strcmp(ProjctCdeS,"5472")==0 || tc_strcmp(ProjctCdeS,"5473")==0 || tc_strcmp(ProjctCdeS,"5474")==0|| tc_strcmp(ProjctCdeS,"5476")==0)
//																	{
//																		printf("\n PROJECT CODE FOUND [%s] \n", ProjctCdeS);fflush(stdout);
																		printf("\n ObjTokpdf: [%s]\n",ObjTokpdf);

																		if (tc_strstr(ObjTokpdf,".pdf")!=NULL)
																		{
																			printf("\n PDF FOUND \n");fflush(stdout);
																			ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
						   
																			if((tc_strcmp(PartTypeS,"DFA")==0)||(tc_strcmp(PartTypeS,"DFS")==0)||(tc_strcmp(PartTypeS,"DFM")==0))
																			{
																				printf("\n IN DFA cond Reference Parts found = %s \n",refObjId);fflush(stdout);
																				//printf("\n DOCno = %s \n",DOCno);fflush(stdout);
																				printf("\n DADNumber = %s \n",DADNumber);fflush(stdout);
						   
																				ITK_CALL(ITEM_find_item (DADNumber,&dad_tag));
																				//ITK_CALL(ITEM_find_item (T5_DAD_Document_item_id,&dad_tag));//changed
																				if (dad_tag!=NULLTAG)
																				{
																					printf("\n  T5_DADDoc already exists \n");fflush(stdout);
																				}
																				else
																				{
																					printf("\n  T5_DADDoc does not exist hence creating \n");fflush(stdout);
																					//ITK_CALL(TCTYPE_find_types_for_class("T5_DADDoc",&number_of_types1,&type_tag3));
																					ITK_CALL( TCTYPE_find_type( "T5_DADDoc", NULL, &type_tag3) );
																					//ITK_CALL ( TCTYPE_ask_object_type ( wsobj_tag [ wsobj_index ], &wsob_type ) ) ;
																					printf("\n number_of_types T5_DADDoc-------->  : %d\n",number_of_types1);fflush(stdout);
																					ITK_CALL(TCTYPE_construct_create_input(type_tag3, &object_create_input_tag3));
						   
																					ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",DADNumber));
																					ITK_CALL(AOM_ask_value_string(object_create_input_tag3,"item_id",&DADname));
																					printf("\n DADname:%s",DADname);fflush(stdout);
						   
																					//ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",T5_DAD_Document_item_id));
																					ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc","PFIRST DATA"));
						   
																					printf("\n test 123 \n");fflush(stdout);
																					printf("\nDADNumber:%s\n",DADNumber);fflush(stdout);
																					printf("\n test 123 \n");fflush(stdout);
																					printf("\n curentnameid:%s \n",curentnameid);fflush(stdout);
						   
																					ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));			//DFA Item Master
																					//CALLAPI( TCTYPE_create_object(object_create_input_tag3, &dad_tag) );
																					printf("\n 4d obj dad_tag created......\n");fflush(stdout);
						   
																					if(dad_tag)
																						{
																							ITK_CALL(AOM_save_with_extensions(dad_tag));
																							ITK_CALL(AOM_refresh(dad_tag,0));
																							ITK_CALL(AOM_unlock(dad_tag));
																							printf("\n  object created.\n"); fflush(stdout);
																						}
						   
																					printf("\n afterrrrrrr 4d obj dad_tag created finding revision  now......\n");fflush(stdout);
																				//}
						   
																					//ITK_CALL(ITEM_find_revision(dad_tag,nwRev,&rev));
																					if(ITEM_ask_latest_rev(dad_tag,&DADrevTag));					//DFA Item Revision
						   
																					printf("\n AFTER 4D_REV_TAG\n");fflush(stdout);
																					if(AOM_lock(DADrevTag));
																					ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnNum",DADNumber));
																					ITK_CALL(AOM_set_value_string(DADrevTag,"item_revision_id","A;1"));//NEW CHANGE
																					ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnAnlysisDocType",PartTypeS));//NEW CHANGE
						   
																					if(AOM_save_with_extensions(DADrevTag));
																					if(AOM_unlock(DADrevTag));
																					printf("\n AFTER setting value on dad revision \n");fflush(stdout);
						   
						   
																					printf("\n CREATING RELATION BETWEEN PART AND DAD DOC\n");
						   
																					if(GRM_find_relation_type("T5_PartHas4D",&tRelationFind));
						   
																					if (tRelationFind!=NULLTAG && DADrevTag !=NULLTAG && DADrevTag!=NULLTAG)
																					  {
																						printf("\n TESTING HERE \n");fflush(stdout);
																						ITK_CALL( GRM_find_relation(Latestrev_Tag,DADrevTag,tRelationFind,&tRelationExist));
						   
																						printf("\n AFTER TESTING HERE tRelationExist \n");fflush(stdout);
																						if(tRelationExist)
																						  {
																							 printf("\n tRelationExist tRelationExist tRelationExist \n");fflush(stdout);
																						  }
																						  else
																						  {
																							  printf("\n tRelationExist DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
																							 ITK_CALL(GRM_create_relation(Latestrev_Tag,DADrevTag,tRelationFind,NULLTAG,&DADRel_t));//latest part revision and dad doc revision
																							 //ITK_CALL(GRM_create_relation(Latestrev_Tag,dad_tag,tRelationFind,NULLTAG,&DADRel_t));
																							 ITK_CALL(GRM_save_relation(DADRel_t));
																							 ITK_CALL(AOM_refresh(Latestrev_Tag,0));
																						  }
																					  }
						   
																					ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_type));
																					//ITK_CALL(GRM_find_relation_type("TC_Attaches", &relationSpeci_type));
																					if(relationSpeci_type != NULLTAG)
																					{
																						printf("\n ObjTokpdf  ---------------[%s] \n",ObjTokpdf);fflush(stdout);
																						printf("\n ObjTokpdf  ----------------- [%s] \n",ObjTokpdf);fflush(stdout);
																						//ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
																						ITK_CALL(AE_create_dataset_with_id(DatasetType,ObjTokpdf,"Dataset Creation Tool","","",&PdfDataset));
						   
																						ITK_CALL(AE_save_myself(PdfDataset));
						   
																						printf("\n PDF created \n");fflush(stdout);
						   
																						if(PdfDataset != NULLTAG)
																						{
						   
																							printf("\n PdfDataset tag found as dataset registered \n");fflush(stdout);
																							ITK_CALL(GRM_create_relation(DADrevTag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));//dad doc revision and pdf
																							//ITK_CALL(GRM_create_relation(Latestrev_Tag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
																							ITK_CALL(AOM_load(specificationRel_t));
																							ITK_CALL(GRM_save_relation(specificationRel_t));
																							if(specificationRel_t != NULLTAG)
																							{
																								tag_t PdfLatestDat_t=NULLTAG;
						   
																								printf("\n Spec rel found  \n");fflush(stdout);
						   
																								ITK_CALL(AOM_refresh(PdfDataset,TRUE));
																								printf("\n Spec rel found  222222 [%s]\n",ObjTokpdf );fflush(stdout);
						   
																								ITK_CALL(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
																								ITK_CALL(AOM_refresh(PdfLatestDat_t,TRUE));
						   
																								//ITK_CALL(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference","/tmp/DFM_544249201659_B_3_30.pdf",NULL,SS_BINARY));
																								ITK_CALL(AE_import_named_ref(PdfDataset,"PDF_Reference",path,NULL,SS_BINARY));
						   
						   
																								printf("\n Spec rel found  333333333 \n");fflush(stdout);
																								//CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
																								//ITK_CALL(AE_add_dataset_named_ref(tDataset,list[0],SS_BINARY,imannewFileTag));
						   
																								AOM_save_with_extensions(PdfLatestDat_t);
																								AOM_refresh(PdfLatestDat_t, FALSE);
																								AOM_unload(PdfLatestDat_t);
																								ITK_CALL(AE_save_myself(PdfLatestDat_t));
																								printf("\n AFTER IMPORTING NAMED REFERENCE \n");fflush(stdout);
						   
																								//return 0;
						   
																								printf("\n check in the 4D Doc \n");fflush(stdout);
						   
																								ITK_CALL(RES_is_checked_out(DADrevTag,&checkout));
																								printf("\nValue of checkout Attribute in Checkin DADrevTag : [%d]\n",checkout);fflush(stdout);
																								  if (checkout==1)
																								  {
																										ITK_CALL(RES_checkin(DADrevTag));
																										printf("\n %d DADrevTag Checked In \n");
																								  }
						   
																								ITK_CALL(RES_is_checked_out(PdfDataset,&checkout2));
																								printf("\nValue of checkout Attribute in Checkin PdfDataset : [%d]\n",checkout2);fflush(stdout);
																								  if (checkout2==1)
																								  {
																										ITK_CALL(RES_checkin(PdfDataset));
																										printf("\n %d PdfDataset Checked In \n");
																								  }
						   
						   
																								ITK_CALL(WSOM_ask_release_status_list(Latestrev_Tag, &status_count, &relStatus_list));
																								if(status_count>0)
																								{
																									for(ss=0; ss<status_count ; ss++)
																									{
																										ITK_CALL(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
																										printf("\n latest_rev_Rel_Stus: %s \n",latest_rev_Rel_Stus);fflush(stdout);
						   
																										if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
																										{
																											if (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
																											ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
																											if(RELSTAT_add_release_status(status_rel,1,&DADrevTag,retain));
																											printf("\n after setting review status to the 4D Doc \n");fflush(stdout);
						   
																											//if (RELSTAT_create_release_status("T5_LcsReview",&status_relpdf));
																											//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
																											//if(RELSTAT_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
																											//printf("\n after setting review status to the 4D PDF \n");fflush(stdout);
						   
																										}
						   
																										else if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
																										{
																											if (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel));
																											ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
																											if(RELSTAT_add_release_status(status_rel,1,&DADrevTag,retain));
																											printf("\n after setting release status to the 4D Doc \n");fflush(stdout);
						   
																											//if (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relpdf));
																											//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
																											//if(RELSTAT_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
																											//printf("\n after setting release status to the 4D PDF \n");fflush(stdout);
																										}
																									}
																								}
//						   
//						   
//																								//ITK_CALL(RES_checkin(DADrevTag));
//																								//printf("\n after check in the 4D Doc check in the pdf \n");fflush(stdout);
//																								//ITK_CALL(RES_checkin(PdfDataset));
//																								//printf("\n after pdf check in \n");fflush(stdout);
																							}
																						}
																					}
																				}
																			}
																		}
																	//}
																	if(ObjTokpdf!=NULL)
																	{
																		MEM_free(ObjTokpdf);
																	}

																}
						   
						   
																//////////////attachment code pasted end/////////////////////////
						   
																//} part has 4d condtion ==0
						   
																}
															}//while(fgets(inputline,2000,fptr)!=NULL)
						   
														}//if(fptr!=NULL)
													}

													printf("\n After release status condition %s[%s]... \n",Desid,DesRevid);fflush(stdout);


														//////////////////////////////  4D attachment end ///////////////////////////////
						   
												}
											
											}
						 
						   
									}
								}
						   
						}//pdf path check condition  if(tc_strstr(path,refObjId)!=NULL) comment
											    
										//}  ////above this from path!=null for loop comment named ref for loop for (r=0;r<NmdrefFound;r++).........................
									

									//}//if tc_strcmp(RefobjType,"PDF") comment if(tc_strcmp(RefobjType,"PDF")==0)
							//}//Ref count for loop comment for (v=0;v<Refcount;v++).......................
	
						} //if(Refcount>0)
						/////////////////////////////////// PDF logic end ////////////////////////////////



					}


				}

			}


		}


	return ITK_ok;

}

int fourD_DocValidCheck(METHOD_message_t *msg, va_list args)
{
	printf("\n ***** INSIDE ERC 4D_DocValidCheck_pre_condition ***** \n");fflush(stdout);

	int ifail=0;
	tag_t primary_object= va_arg(args, tag_t);
	tag_t primary_obj_type_tag= NULLTAG;
	tag_t group_tag=NULLTAG;
	tag_t role_tag=NULLTAG;

	//char type_name[WSO_name_size_c+1];
	char* type_name  =NULL;
	//char groupname[WSO_name_size_c+1];
	char* groupname = NULL;
	//char rolename[WSO_name_size_c+1];
	char* rolename = NULL;
	char * group_string=NULL;
	char *value=NULL;
	char *ERCWBS=NULL;
	char*	username		= NULL;

	//ass
	char * user_Name=NULL;
	tag_t user_tag1=NULLTAG;
	char	*info1	= NULL;
	char	*userinfo1	= NULL;
	char *DMLrlstype = NULL;
	char*	 DmlDRStatus = NULL;
	tag_t	qry_t1	= NULLTAG;
	char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_val = (char **) MEM_alloc(10 * sizeof(char *));
	int n_entr1 = 1;
	int n_entr = 1;
	char    *qry_entr1[1]  = {"SYSCD"};
	char    *qry_entr[1]  = {"SYSCD"};
	int rsltCunt1=0;
	int rsltCunt=0;
	tag_t *CntrlObjTag1=NULLTAG;
	tag_t *CntrlObjTag=NULLTAG;

	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name);
	printf("\n 4D_DocValidCheck object type_name is ::  %s --------\n",type_name);fflush(stdout);

	ITK_CALL(POM_get_user_id (&username));
	printf("\n Session User is : %s \n",username); fflush(stdout);


	if(tc_strcmp(type_name,"T5_DADDoc")==0)
	{

		
			printf("\n ***** INSIDE 4DOC_creation***** \n");fflush(stdout);

			ifail=POM_ask_group(&group_string,&group_tag);
			ifail=SA_ask_group_name2(group_tag,&groupname);
			ifail=SA_ask_current_role(&role_tag);
			ifail=SA_ask_role_name2(role_tag,&rolename);

			printf("\n 4Ddoccheck Login user groupname ::  %s\n",groupname);fflush(stdout);
			printf("\n 4Ddoccheck Login user Rolename  ::  %s\n",rolename);fflush(stdout);

			if(tc_strcmp(groupname,"PLM_Support_Group")==0)
			{

				if(tc_strcmp(rolename,"Support_Role")==0)
				{

					printf("\n Allowing support role to create the 4D document.....  \n");fflush(stdout);

				}
				else
				{

					EMH_store_error_s1(EMH_severity_error,ITK_err,"Login user's group and role is wrong");
					printf("\n\n\t 4D document owning role is not matching given criteria *****\n");
					return(ITK_err);

				}
			}
			else
			{
			
				EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create 4D document.");
				printf("\n\n\t 4DCreation precondition end*****\n");
				return(ITK_err);
			}

	}

	return ifail;
}

extern int register_dfq_creation(int *decision, va_list args)
{
	METHOD_id_t  method_DFQDocCreForm;
	METHOD_id_t  method_TMKOForm;
	METHOD_id_t  method_DFQDocSave;
    METHOD_id_t  method_dvloFormAtttributeUpdate;
	METHOD_id_t  methoddfq ;
	METHOD_id_t  methoddfmea ;
	METHOD_id_t  method1;
	METHOD_id_t  method4d;
	METHOD_id_t  method5d;
	METHOD_id_t  method6d;
	METHOD_id_t  methoddfq5;
	METHOD_id_t  methoddfq6;

    *decision = ALL_CUSTOMIZATIONS;
	int	ifail = ITK_ok;

	if ( METHOD_find_method("T5_DFQDocCreForm", TC_save_msg, &method_DFQDocCreForm) !=ITK_ok)PrintErrorStack();

    if (method_DFQDocCreForm.id != NULLTAG)
	{
		CALLAPI(METHOD_add_action(method_DFQDocCreForm,METHOD_post_action_type,(METHOD_function_t)t5_DFQ_create_with_dataset,NULL));
	}

	if ( METHOD_find_method("T5_TMKOHeaderRevision", TC_save_msg, &method_TMKOForm) !=ITK_ok)PrintErrorStack();

    if (method_TMKOForm.id != NULLTAG)
	{
		printf("\n Starting Post Action on TMKO Doc TMKODcoumentCreation\n");

		CALLAPI(METHOD_add_action(method_TMKOForm,METHOD_post_action_type,(METHOD_function_t)TMKODcoumentCreation,NULL));

		printf("\n After Post Action on TMKO Doc TMKODcoumentCreation\n");
	}

	//if ( METHOD_find_method("T5_DFQ_Document", AE_save_dataset_msg, &method_DFQDocSave) !=ITK_ok);
	if ( METHOD_find_method("T5_DFQ_Document", "AE_save_myself_dataset", &method_DFQDocSave) !=ITK_ok)PrintErrorStack();

	//printf("\n Save DFQ Dataset \n");

	if (method_DFQDocSave.id != NULLTAG)
	{
		//printf("\n Starting to Post Action of DFQ Dataset\n");

		if( METHOD_add_action(method_DFQDocSave,METHOD_post_action_type ,(METHOD_function_t)t5_DFQ_Doc_save_dataset,NULL)!=ITK_ok)PrintErrorStack();

		if( ifail != ITK_ok )
		{
			//printf("\n ifail is Not OK \n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!method_DFQDocSave not found!!!!!!!!!!\n");
    }


	//////////////////////////////////////////////////////// SAGAR RAWAT/GOVIND DVLO/GCI form start /////////////////////////////////////////////////////////////////////////////
	if ( METHOD_find_method("T5_dvlo_form", TC_save_msg, &method_dvloFormAtttributeUpdate) !=ITK_ok)PrintErrorStack();

	//printf("\n Save DVLO Dataset \n");

	if (method_dvloFormAtttributeUpdate.id != NULLTAG)
	{
		//printf("\n Starting to Post Action of DVLO\n");

		if( METHOD_add_action(method_dvloFormAtttributeUpdate,METHOD_post_action_type ,(METHOD_function_t)t5_dvlo_Creation,NULL)!=ITK_ok)PrintErrorStack();

		if( ifail != ITK_ok )
		{
			//printf("\n ifail is Not OK \n");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!method_DFQDocSave not found!!!!!!!!!!\n");
    }

	ifail = METHOD_find_method("ImanRelation", TC_delete_msg, &methoddfq);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfq.id != NULLTAG)
	    {
			if( METHOD_add_action(methoddfq, METHOD_pre_action_type, (METHOD_function_t) T5PartToDFQVal, NULL)!=ITK_ok)
			{
			}
			//	printf("Registered as METHOD_pre_action_type for T5PartToDFQVal \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for T5PartToDFQVal TC_delete_msg...\n");fflush(stdout);
	   }
   }

   ifail = METHOD_find_method("ImanRelation", TC_delete_msg, &methoddfq);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfq.id != NULLTAG)
	    {
			if( METHOD_add_action(methoddfq, METHOD_pre_action_type, (METHOD_function_t) T5PartToFourDVal, NULL)!=ITK_ok)
			{
			}
			//	printf("Registered as METHOD_pre_action_type for T5PartToDFQVal \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for T5PartToFourDVal TC_delete_msg...\n");fflush(stdout);
	   }
   }
   ifail = METHOD_find_method("ImanRelation", TC_delete_msg, &methoddfq5);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfq5.id != NULLTAG)
	    {
			if( METHOD_add_action(methoddfq5, METHOD_pre_action_type, (METHOD_function_t) T5PartToRendering, NULL)!=ITK_ok)
			{
			}
			//	printf("Registered as METHOD_pre_action_type for T5PartToDFQVal \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for T5PartToRendering TC_delete_msg...\n");fflush(stdout);
	   }
   }

   /***Asif Mohammad Stop the Paste DFQ Dataset on HAS DVA relation*****/
    ifail = METHOD_find_method("ImanRelation", GRM_create_msg, &methoddfq6);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfq6.id != NULLTAG)
	    {
			if( METHOD_add_action(methoddfq6, METHOD_pre_action_type, (METHOD_function_t) T5DfqDatesetStop, NULL)!=ITK_ok) 
			{
			}
			//	printf("Registered as METHOD_pre_action_type for T5PartToDFQVal \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for T5DfqDatesetStop GRM_create_msg...\n");fflush(stdout);
	   }
   }
  /**** Asif Mohammad Stop the Paste DFQ Dataset on HAS DVA relation******/



     /**** Anvesh Bujule Checkin validation ******/


   ifail = METHOD_find_method(RES_Type, RES_checkin_msg ,&method1);
   if( ifail == ITK_ok )
   {

    if (method1.id != NULLTAG)
	{
		CALLAPI(METHOD_add_pre_condition(method1,(METHOD_function_t)checkindfq,NULL));
		//printf("Registered as METHOD_pre_action_type for checkindfq...\n");fflush(stdout);
	}
	else
	{
			printf("Method not found for checkindfq...\n");fflush(stdout);
	}

   }

   ifail = METHOD_find_method(RES_Type, RES_checkout_msg ,&method5d);
   if(ifail== ITK_ok)
	{

    if (method5d.id != NULLTAG)
	{
		printf("\n Inside GCI checkout register successfully\n");fflush(stdout);
		CALLAPI(METHOD_add_action(method5d, METHOD_pre_action_type,(METHOD_function_t)GCICheckout,NULL));
	}


	}
	ifail = METHOD_find_method(RES_Type, RES_checkout_msg ,&method6d);
    if(ifail== ITK_ok)
	{

		if (method6d.id != NULLTAG)
		{
			printf("\n Inside FourDCheckout register successfully\n");fflush(stdout);
			CALLAPI(METHOD_add_action(method6d, METHOD_pre_action_type,(METHOD_function_t)FourDCheckout,NULL));
		}


	}
	

    //Sagar 4D doc restriction on creation.
      
   ifail = METHOD_find_method("T5_DADDoc", TC_save_msg, &method4d);

   if (method4d.id != NULLTAG)
   {

		CALLAPI(METHOD_add_pre_condition(method4d,(METHOD_function_t)fourD_DocValidCheck,NULL));
		//printf("\n :: method4d registered :: \n"); fflush(stdout);
   }
   else
   {
		printf("\n :: method4d not found :: \n"); fflush(stdout);
   }

	//Sagar 4D doc restriction on creation end.

   ifail = METHOD_find_method("T5_Dfmea", TC_save_msg, &methoddfmea);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfmea.id != NULLTAG)
	    {
			//printf("Registered as METHOD_pre_action_type for t5_dfmea_creation.........111 \n");fflush(stdout);
			if( METHOD_add_action(methoddfmea, METHOD_pre_action_type, (METHOD_function_t) t5_dfmea_creation, NULL)!=ITK_ok)
			{}
			
			//	printf("Registered as METHOD_pre_action_type for t5_dfmea_creation......222 \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for t5_dfmea_creation IMAN_save_msg...\n");fflush(stdout);
	   }
   }



	/**** SAGAR RAWAT GCI HARD CHECK start ******/

   if( ITK_ok ==  EPM_register_rule_handler ("GCIdoc_Validation","GCI validation", (EPM_rule_handler_t) GCIdoc_Validation))
   {
		//printf("\t\n Registered rule  Handler GCIdoc_Validation\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register rule Handler GCIdoc_Validation\n");fflush(stdout);
   }

   /**** SAGAR RAWAT GCI HARD CHECK end ******/

    if(ITK_ok == EPM_register_rule_handler("ProgScale_Validation","ProgmScale validation", (EPM_rule_handler_t) ProgScale_Validation))
	{

       // printf("\t\n Registered rule  Handler ProgScale_Validation\n");fflush(stdout);
	}
	else
	{
        printf("\t FAILED to register rule Handler ProgScale_Validation\n");fflush(stdout);
	}

  

	///////////////////////////////////////////////////////// SAGAR RAWAT/GOVIND DVLO/GCI form end /////////////////////////////////////////////////////////////////////////////


   if( ITK_ok == EPM_register_action_handler("4D_Doc_attach", "attach 4d doc and resp doc", FOURD_Doc_attach))
   {
		//printf("\t\n Registered Action Handler 4D_updation \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler 4D_updation\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("TMKO_Mail_reject", "TMKO Mail reject", TMKO_Mail_reject))
   {
		//printf("\t\n Registered Action Handler TMKO_Mail_reject \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler TMKO_Mail_reject\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("TMKO_Mail_approve", "TMKO Mail approve", TMKO_Mail_approve))
   {
		//printf("\t\n Registered Action Handler TMKO_Mail_approve \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler TMKO_Mail_approve\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("TMKO_PDF_Generation", "TMKO PDF Generation", TMKO_PDF_Generation))
   {
		//printf("\t\n Registered Action Handler TMKO_Mail_approve \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler TMKO PDF Generation\n");fflush(stdout);
   }

   
	 if( ITK_ok == EPM_register_action_handler("DVA_Doc_attach", "DVA doc attach", DVA_doc_attach))
   {
		//printf("\t\n Registered Action Handler DVA_Doc_attach \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler DVA_Doc_attach\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("TMKO_Auto_Assign", "TMKO Auto Assign", TMKO_Auto_Assign))
   {
		//printf("\t\n Registered Action Handler TMKO_Auto_Assign \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler TMKO_Auto_Assign\n");fflush(stdout);
   }

	return ifail;

}

extern DLLAPI int tm_dfq_creation_register_callbacks()
{
     CUSTOM_register_exit("tm_dfq_creation", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_dfq_creation);

    // printf("\n Creation of DFQ Dataset \n");

	 return ( ITK_ok );
}

int t5_dfmea_document_creation(tag_t Revtag)
{
		tag_t DitemTAG			 = NULLTAG; 
		char*DItemIdLat			 = NULL;
		char*DItemdesc			 = NULL;
		
		EPM_decision_t decision = EPM_go;
		
		char*Dfmea1		 = NULL;
		char*module1			 = NULL;
		char*modaddr				 = NULL;
		char*modaddr1	=(char *) MEM_alloc(sizeof(char)* 10);

		char*part_type			 = NULL;
		char*part_typeDup			 = NULL;
		//char*module2		 = NULL;
		char*module2	=(char *) MEM_alloc(sizeof(char)* 20);
		tag_t LatestRev=NULLTAG;
		char *errorstr1 = (char *) MEM_alloc(sizeof(char)* 300);
		int	n_entries = 1;
		int n_found = 0;
		int i =0;
		tag_t   DesRev_tag     = NULLTAG;

		char *DFMEAaddrStr = (char *) MEM_alloc(sizeof(char)* 300);
		
		char    **module_qry_values   =  (char **) MEM_alloc(100 * sizeof(char *));
		int		module_n_entry = 1;
		int     mod_rsltCount =  0;
		
		char    *Dfmeamod_qry_entry[3]  = {"SYSCD","SUBSYSCD","Information-1"};
		#define DFMEA_VAL EMH_USER_error_base+30
		
		tag_t   moduleaddrobj = NULLTAG;
		tag_t   *modadrCntrlObjectTag = NULLTAG;
		tag_t   *tItemobj = NULLTAG, *titemobj_results = NULLTAG;
		int n_itemobj_found=0;


		char *inputline1 = NULL;
		inputline1 =(char *)MEM_alloc(200);
		char *DfmeaaddrpathName		   = NULL;
		char *dfmea1		   = NULL;
		char *dfmeaadr		   = NULL;
		
		char *strtxt1 = NULL;
		strtxt1 =(char *)MEM_alloc(100);
		
		FILE *fptr1;
		
		char *Logfname1 = NULL;
		Logfname1 =(char *)MEM_alloc(100);

		AOM_ask_value_string(Revtag,"object_name",&DItemIdLat);
		printf("Item ID :: %s\n",DItemIdLat);fflush(stdout);
		
		AOM_ask_value_string(Revtag,"object_desc",&DItemdesc);
		printf("description :: %s\n",DItemdesc);fflush(stdout);
		
		
		Dfmea1 = tc_strtok(DItemIdLat,"_");
		module1 = tc_strtok(NULL,"_");
		
		printf("Dfmea1 :: %s\n",Dfmea1);fflush(stdout);
		printf("module1 :: %s\n",module1);fflush(stdout);
		//printf("description :: %s\n",DItemdesc);fflush(stdout);

		tc_strcpy(module2,"");
		tc_strcpy(module2,module1);


	printf("\n Finding Query[Item Revision...]..!!\n");fflush(stdout);
                        ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
                        if(tItemobj != NULLTAG)
                        {
                                printf("\n Query[Item Revision...] Tag Found Successfully..!!\n");fflush(stdout);
                                char *cEntries[2]  = {"Item ID","Type"};
                                char *cValues[2]  = {module2,"Design Revision"};
                                ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
                                printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
                                printf("\n Total Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
                                printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
                                if(n_itemobj_found > 0)
                                {
                                        for(i = 0; i < 1; i++)
                                        {
                                                DesRev_tag = titemobj_results[i];
										}
								}
						}


	//ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));


	ITK_CALL(AOM_ask_value_string(DesRev_tag,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	printf("\n part_typeDupFound Count %d", part_typeDup);fflush(stdout);

	tc_strcpy(errorstr1,"");
			tc_strcpy(errorstr1,". \n DFMEA creation is allowed for part types Module and TPL only");



		if((tc_strcmp(part_typeDup,"M")!=0) && (tc_strcmp(part_typeDup,"T")!=0))
		   {
			
			EMH_store_error_s1(EMH_severity_error,ITK_err,errorstr1);
			return ITK_err;
		   }



		if(tc_strcmp(part_typeDup,"M")==0)
		{
		modaddr=subString(module1, 4, 5);
		printf("modaddr :: %s\n",modaddr);fflush(stdout);
		
		
		tc_strcpy(modaddr1,"");
		tc_strcpy(modaddr1,"M");
		tc_strcat(modaddr1,modaddr);
		printf("\n new module address is : [%s]\n",modaddr1); fflush(stdout);



		ITK_CALL(PREF_ask_char_value("DFMEAADDR", 0 , &DfmeaaddrpathName ));//ALIAS_TEXTPATH -name of preference  psasad = /tmp/
		printf("\n ALIAS_TEXTPATH issss %s\n",DfmeaaddrpathName);fflush(stdout);



		if(!DfmeaaddrpathName)
		{
		//printf("\n\n\t\t .Part is check out ==> %s \n", design_checkout);fflush(stdout);
			     EMH_store_error_s1(EMH_severity_error,ITK_err,"Directory not found. Please check ALIAS_TEXTPATH");
		return ITK_err;
		}

		printf("\n ----------------- DFMEA addr check------------ \n");fflush(stdout);


		//strtxt = malloc(1500);

		printf("\n before shell execute for DFMEA addr ------------ \n");fflush(stdout);

		tc_strcpy(strtxt1,"");
		tc_strcat(strtxt1,DfmeaaddrpathName);
		tc_strcat(strtxt1,"/");
		tc_strcat(strtxt1,"dfmea_appl.sh");
		tc_strcat(strtxt1," ");
		tc_strcat(strtxt1,modaddr1);


		system(strtxt1);

		printf("\n after shell execute for DFMEA addr ------------ \n");fflush(stdout);

		tc_strcpy(Logfname1,"/tmp/dfmeaadr1.txt");
		fptr1 = fopen(Logfname1,"r");
		
		printf("\n file open :  ------------ \n");fflush(stdout);
		
		while(fgets(inputline1,1500,fptr1)!=NULL)
		{
			printf("\n inputline1234 : [%s] ------------ \n",inputline1);fflush(stdout);
			
			dfmea1 = tc_strtok(inputline1, ",");
			dfmeaadr = tc_strtok(NULL, ",");

			printf("\n module address : [%s]\n",dfmea1); fflush(stdout);
			printf("\n applicable DFMEA is : [%s]\n",dfmeaadr); fflush(stdout);

			tc_strcpy(DFMEAaddrStr,"");
			tc_strcpy(DFMEAaddrStr,"For Module address : ");
			tc_strcat(DFMEAaddrStr,dfmea1);
			tc_strcat(DFMEAaddrStr," , applicable system DFMEA name is : ");
			tc_strcat(DFMEAaddrStr,dfmeaadr);
			tc_strcat(DFMEAaddrStr,". \nEntered description is : ");
			tc_strcat(DFMEAaddrStr,DItemdesc);
			tc_strcat(DFMEAaddrStr,". \nPlease fill applicable DFMEA in description and ensure excel file with same system DFMEA is attached.");

							
//			EMH_store_error_s1(EMH_severity_warning,ITK_err,DFMEAaddrStr);
//			//decision = EPM_go;
//			return ITK_err;

			printf("\n applicable DFMEA is : [%s]\n",dfmeaadr); fflush(stdout);
			printf("\n description for DFMEA is : [%s]\n",DItemdesc); fflush(stdout);


			if(tc_strstr(DItemdesc,dfmeaadr)==NULL)
		   {
			
			EMH_store_error_s1(EMH_severity_error,ITK_err,DFMEAaddrStr);
			return ITK_err;
		   }

		}
		}



return 0;
}
