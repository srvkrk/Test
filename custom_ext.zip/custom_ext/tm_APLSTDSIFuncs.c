/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_APLSTDSIFuncs.c
* Created By                   : Anshul Gupta
* Created On                   : 03/05/2019
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
#include "tm_apl_std_common_function.c"	
#define MAX_LINE_LEN 1024
	
		
static void ECHO(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

;
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
//Depricated API BOM_line_ask_attribute_string replaced with  AOM_ask_displayable_values
//Depricated API BOM_line_look_up_attribute replaced with   TCTYPE_ask_property_by_name
//Depricated API BOM_line_set_attribute_string replaced with    AOM_UIF_set_value
//Depricated API BOM_line_ask_attribute_logical replaced with     AOM_ask_value_logical
//Depricated API BOM_line_ask_attribute_tag replaced with     AOM_ask_value_tag
//Depricated API CR_create_release_status2 replaced with     RELSTAT_create_release_status

{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}
/****************************************************************************/
/* Function Name    : FU_dumpItkErrors                                      */
/*                                                                          */
/* Called From      : ITK                                                   */
/*                                                                          */
/* Input Parms      : int stat                                              */
/*                    const char * prog_name                                */
/*                    int line_number                                       */
/*                    const char * file_name                                */
/*                                                                          */
/* Output Parms     : None                                                  */
/*                                                                          */
/* Functions called : None                                                  */
/*                                                                          */
/* File Description : Called by the ITK macro to log errors                 */
/*                                                                          */
/* Return Value     : Void                                                  */

/**********************************************************************/

//EBOM-MBOM Function
int tm_ebom_mbom_rpt(char *pltfrm,char *svr,char *revrule,char *closurerulename,char *eff_date_temp,char ***SetModulePart,int *icount)
{
	int		ifail 				=   ITK_ok;
	char	*tasknumber			=	NULL;
	char	*type_name			=	NULL;
	char	*type_nameP			=	NULL;
	char	*type_name2			=	NULL;
	char	*tsk_object_name	=	NULL;
	char	*ClrSVROnly			=	NULL;
	char	*tmpSVR				=	NULL;
	char	*nonClrSvr			=	NULL;
	char	*clrSlr				=	NULL;
	char	*qry_entries3[1]	= {"Name"};
	char	*qry_entries10[1]	= {"ID"};
	char	*itemid;
	char	*svrName			=	NULL;
	char	*t5_SchmPlant		=	NULL;
	char	*t5_ClSrl			=	NULL;
	char	*arch_item_id		=	NULL;
	char	*Archtype_name		=	NULL;
	char	**rulename			=	NULL;
	char	**rulevalue			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*StagePartNo		=	NULL;
	char	*Stage_item_Rev_Seq	=	NULL;
	char	*StagePartType		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*ModPartType		=	NULL;
	char	*ModPartLine		=	NULL;
	char	*ModItem_Rev		=	NULL;
	char	*ModItem_Seq		=	NULL;
	char	*ChildColInd		=	NULL;
	char	*Item_ID_str		=	NULL;
	char	*ModPartAct			=	NULL;

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	char	**valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));

	date_t  eff_date;

	tag_t	objTypeTag			=	NULLTAG;
	tag_t	ItemTypeTag			=	NULLTAG;
	tag_t	*PartTags			=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	ClrVariqueryTag		=	NULLTAG;
	tag_t	*ColVRule_tags		=	NULLTAG;
	tag_t	*t5_clrscm			=	NULLTAG;
	tag_t	PlatformTag			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	tag_t	item_tag			=	NULLTAG;
	tag_t	PlatformTypeTag		=	NULLTAG;
	tag_t	PlatformRevTag		=	NULLTAG;
	tag_t	PlatformRevTypeTag	=	NULLTAG;
	tag_t   e_block				=	NULLTAG;
	tag_t	*lines2				=	NULLTAG;
	tag_t	*lines3				=	NULLTAG;
	tag_t	PartChildobj		=	NULLTAG;
	tag_t	StageChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;


	int		PartCnt			=	0;
	int		n_entriesV		=	1;
	int		n_entriesP		=	1;
	int		n_tags_found	=	0;
	int		n_count			=	0;
	int		ClrCnt = 0;
	int		iSVR = 0;
	int		count_clrscm	=	0;
	int		rulefound		=	0;
	int		count			=	0;
	int		ichld			=	0;
	int		n_lines2		=	0;
	int		n_lines3		=	0;
	int		iMod			=	0;
	int		iMod1			=	0;
	int		NonClrPartlevel =	0;
	int		iChildItemTag	=   0;
	int		Revformula;
	const char *qry_entries[1];
	const char *qry_values[1];
	struct	BomChldStrut	ChldStrutBdySh[5000];
	
	tag_t	*itemclass			=	NULLTAG;
	tag_t	item				=	NULLTAG;
	tag_t	tsk_HSI_rel_type	=	NULLTAG;
	tag_t	t5_appl_SVR			=	NULLTAG;
	tag_t	item_rev_tag		=	NULLTAG;
	tag_t	bom_wnd				=	NULLTAG;
	tag_t	rule				=	NULLTAG;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	tag_t   bom_variant_rule	=	NULLTAG;
	tag_t  	objTypeTag1			=	NULLTAG;
	tag_t	top_lne				=	NULLTAG;
	tag_t	*ArchNodeLines		=	NULLTAG;
	tag_t	VarientRuletag		=	NULLTAG;
	tag_t	*ColIndChilds		=	NULLTAG;
	tag_t	Childobject			=	NULLTAG;
	char   *taskowning_groupVal =	NULL;
	
	

	printf("\nInSide tm_ebom_mbom_rpt");fflush(stdout);
	
	printf("\npltfrm ...%s\n", pltfrm);fflush(stdout);
	printf("\nsvr ...%s\n", svr);fflush(stdout);
	printf("\nrevrule ...%s\n", revrule);fflush(stdout);
	printf("\nclosurerulename ...%s\n", closurerulename);fflush(stdout);
	printf("\neff_date_temp ...%s\n", eff_date_temp);fflush(stdout);
	
	
	if(QRY_find2("Platform", &PlatformTag));
	if (PlatformTag) 
	{ 
		printf("\nFound Query PlatformTag"); fflush(stdout); 
	}
	else 
	{
		printf("\nNot Found Query PlatformTag"); fflush(stdout);		
		return 0;
	}
	
	valuesPlatfrom[0] = pltfrm;//Platform	
	if(QRY_execute(PlatformTag, n_entriesP, qry_entries10, valuesPlatfrom, &n_tags_found, &tags_found));
	printf("\n\n\n Platform count is-------->  : %d",n_tags_found);fflush(stdout);
	if (n_tags_found > 0)
	{		
		item_tag = tags_found[0];//Platform Tag

		ITKCALL(TCTYPE_ask_object_type(item_tag,&PlatformTypeTag));
		ITKCALL(TCTYPE_ask_name2(PlatformTypeTag,&type_nameP));
		printf("\n Platform name------> %s\n",type_nameP);fflush(stdout);
		
		ITKCALL(ITEM_ask_latest_rev(item_tag , &PlatformRevTag));
		ITKCALL(TCTYPE_ask_object_type(PlatformRevTag,&PlatformRevTypeTag));
		ITKCALL(TCTYPE_ask_name2(PlatformRevTypeTag,&type_name2));
		printf("\n Platform name2------> %s\n",type_name2);fflush(stdout);

		if(tc_strcmp(type_name2,"T5_PlatformRevision")==0)
		{
			nonClrSvr	=	(char	*)MEM_alloc(50);
			tc_strcpy(nonClrSvr,svr);		
			printf("\nnonClrSvr : %s",nonClrSvr);fflush(stdout);

			//Query Variant Rule
			if(QRY_find2("VariantRule", &ClrVariqueryTag));

			if (ClrVariqueryTag)
			{
				printf("\nFound Query VariantRule"); fflush(stdout);
			}else
			{
				printf("\nNot Found Query VariantRule"); fflush(stdout);			
				return 0;
			}

			valuesNonColSvr[0] = nonClrSvr;
			if(QRY_execute(ClrVariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &ClrCnt, &ColVRule_tags));
			printf("\n Colour VariantRule count is-------->  : %d",ClrCnt);fflush(stdout);

			if(ClrCnt)
			{
				VarientRuletag	=	NULLTAG;
				svrName			=	NULL;
				VarientRuletag	=	ColVRule_tags[0];//Variant Rule Tag
				
				ITKCALL(AOM_ask_value_string(VarientRuletag, "object_name",&svrName));
				printf("\n svrName : %s",svrName);fflush(stdout);

				printf("\n eff_date_temp:%s",eff_date_temp);

				CALLAPI(ITK_string_to_date(eff_date_temp, &eff_date ));

				printf("\n eff_date Date Set");fflush(stdout);
				
				ITKCALL(BOM_create_window(&bom_wnd ));
				//ITKCALL(CFM_find("ERC release and above APLC", &rule));
				ITKCALL(CFM_find(revrule, &rule));
				ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));
				ITKCALL(CFM_rule_set_date(rule, eff_date));
				//ITKCALL(PIE_find_closure_rules2("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
				ITKCALL(PIE_find_closure_rules2(closurerulename,PIE_TEAMCENTER, &rulefound, &closurerule ));
				printf ("\nrule count %d \n",rulefound);fflush(stdout);
				if (rulefound > 0)
				{
					close_tag = closurerule[0];
					printf ("closure rule found \n"); fflush(stdout);
				}
				ITKCALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));
		
				ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
				ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PlatformRevTag, NULLTAG, &top_lne ));

				
				//ITKCALL(BOM_window_ask_variant_rule( bom_wnd, &bom_variant_rule ));

				//ITKCALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag1));
				//ITKCALL(TCTYPE_ask_name2(objTypeTag1,&Archtype_name));
				//printf("\n Archtype_name------> %s\n",Archtype_name);fflush(stdout);

				ITKCALL( ITEM_ask_rev_variants ( PlatformRevTag, &e_block ));
				printf(" ITEM_ask_rev_variants..\n");fflush(stdout);

				if(top_lne!=NULLTAG)
				{
					ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
					printf("\n n_count --------> : %d\n", n_count);

					ITKCALL(BOM_window_hide_unconfigured(bom_wnd));
					ITKCALL(BOM_window_show_variants(bom_wnd));
					ITKCALL(BOM_window_apply_variant_configuration(bom_wnd,1,&VarientRuletag));
					ITKCALL(BOM_window_hide_variants(bom_wnd));
					ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
					printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
							
					if (count >0)
					{
						for (ichld=0;ichld<count ;ichld++ )
						{
							if(Childobject) Childobject=NULLTAG;
							Childobject=ColIndChilds[ichld];

							ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
							printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
							
							if(tc_strcmp(closurerulename,"BOMLineskipforunconfiguredAPLC")==0)
							{
								if((tc_strstr(arch_item_id,"MB4Z01")!=NULL) || (tc_strstr(arch_item_id,"MB5Z01")!=NULL))
								{
									//Find the APL modules and explode
									if(lines2) lines2=NULL;

									ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
									printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

									if(n_lines2 > 0)
									{
										for (iMod=0;iMod<n_lines2 ;iMod++ )
										{
											if(PartChildobj) PartChildobj=NULLTAG;
											if(lines3) lines3=NULLTAG;
											n_lines3=0;
											if(ModPartNo) ModPartNo=NULL;
											if(item_Rev_Seq) item_Rev_Seq=NULL;
											if(ModPartType) ModPartType=NULL;
											if(taskowning_groupVal) taskowning_groupVal=NULL;
											
											PartChildobj=lines2[iMod];

											ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
											printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
											
											ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
											printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
											
											ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
											printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
											
											iChildItemTag=0;
											t_ChildItemRev=NULLTAG;
											//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
											//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

											 AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
											
											if(t_ChildItemRev!=NULLTAG)
											{
												printf("\n  BOM_line_ask_attribute_tag depricated API replaced with AOM_ask_value_tag..............");fflush(stdout);
												ITKCALL(AOM_UIF_ask_value(t_ChildItemRev,"owning_group",&taskowning_groupVal));											
												printf("\n  taskowning_groupVal:%s ..............",taskowning_groupVal);fflush(stdout);
												
												n_lines3	= 0;
												if((tc_strstr(taskowning_groupVal,"APLC")!=NULL))
												{
													n_lines3=0;
													ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleAPLC","ERC release and above APLC","APLC View",ChldStrutBdySh,&n_lines3));
													printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
												}
												else if((tc_strstr(taskowning_groupVal,"APLV")!=NULL))
												{
													n_lines3=0;
													ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleAPLV","ERC release and above APLV","APLV View",ChldStrutBdySh,&n_lines3));
													printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
												}
												else
												{
													n_lines3=0;
													ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleERC","ERC release and above APLC","View",ChldStrutBdySh,&n_lines3));
													printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
												}
												
												printf("\n Stage Assembly count n_lines3--> %d\n",n_lines3);fflush(stdout);

												if(n_lines3 > 0)
												{
													for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
													{
														if(StageChildobj) StageChildobj=NULLTAG;	
														if(StagePartNo) StagePartNo=NULL;
														if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
														if(StagePartType) StagePartType=NULL;
														
														StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;
														
														ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
														printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
														printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
														printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);

														if(tc_strcmp(StagePartType,"SA")==0)//To add Stage Assembly 
														{
															//To add in set
															ModPartAct	=	(char	*)MEM_alloc(300);
															tc_strcpy(ModPartAct,StagePartNo);
															tc_strcat(ModPartAct,"/");
															tc_strcat(ModPartAct,Stage_item_Rev_Seq);

															printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
															setAddStrFuction(icount,SetModulePart,ModPartAct);
														}
													}
												}
											}

										}//for loop
									}//if(n_lines2 > 0)
								}
							}
							else if(tc_strcmp(closurerulename,"BOMLineskipforunconfigured")==0)
							{
								//Find the ERC and explode and find PB part.
								if(lines2) lines2=NULL;

								ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
								printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

								if(n_lines2 > 0)
								{
									for (iMod=0;iMod<n_lines2 ;iMod++ )
									{
										if(PartChildobj) PartChildobj=NULLTAG;
										if(ModPartNo) ModPartNo=NULL;
										if(item_Rev_Seq) item_Rev_Seq=NULL;
										if(ModPartType) ModPartType=NULL;
										if(ModPartLine) ModPartLine=NULL;
										if(taskowning_groupVal) taskowning_groupVal=NULL;
										PartChildobj=lines2[iMod];

										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
										printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);

										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_line_name", &ModPartLine ));
										printf("\n ModPartLine --> : %s\n",ModPartLine); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
										printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
										printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);

										if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"T")==0)) //To add Module and CP Modules //TCE-Sunset related chnages
										{
											//To add in set
											ModPartAct	=	(char	*)MEM_alloc(300);
											tc_strcpy(ModPartAct,ModPartNo);
											tc_strcat(ModPartAct,"/");
											tc_strcat(ModPartAct,item_Rev_Seq);
											printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);

											setAddStrFuction(icount,SetModulePart,ModPartAct);

											if((tc_strstr(ModPartLine,"JOINERY")!=NULL) && ((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"T")==0))) //TCE-Sunset related chnages
											{
												iChildItemTag=0;
												t_ChildItemRev=NULLTAG;
												//depricated API replaced
												//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
												//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

												AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
												if(t_ChildItemRev!=NULLTAG)
												{
													printf("\n  BOM_line_ask_attribute_tag depricated API replaced with AOM_ask_value_tag..............");fflush(stdout);
													ITKCALL(AOM_UIF_ask_value(t_ChildItemRev,"owning_group",&taskowning_groupVal));
													printf("\n  taskowning_groupVal:%s ..............",taskowning_groupVal);fflush(stdout);
													
													n_lines3=0;
													if((tc_strstr(taskowning_groupVal,"APLC")!=NULL))
													{
														n_lines3=0;
														ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleAPLC","ERC release and above APLC","APLC View",ChldStrutBdySh,&n_lines3));
														printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
													}
													else if((tc_strstr(taskowning_groupVal,"APLV")!=NULL))
													{
														n_lines3=0;
														ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleAPLV","ERC release and above APLV","APLV View",ChldStrutBdySh,&n_lines3));
														printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
													}
													else
													{
														n_lines3=0;
														ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"BOMViewClosureRuleERC","ERC release and above APLC","View",ChldStrutBdySh,&n_lines3));
														printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
													}
													printf("\n Stage Assembly count--> %d\n",n_lines3);fflush(stdout);

													if(n_lines3 > 0)
													{
														for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
														{
															if(StageChildobj) StageChildobj=NULLTAG;	
															if(StagePartNo) StagePartNo=NULL;
															if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
															if(StagePartType) StagePartType=NULL;
															
															StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;

															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
															printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);
															
															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
															printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);
															
															ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
															printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);

															if(tc_strcmp(StagePartType,"CM")==0)//To add CAD Module
															{
																//To add in set
																ModPartAct	=	(char	*)MEM_alloc(300);
																tc_strcpy(ModPartAct,StagePartNo);
																tc_strcat(ModPartAct,"/");
																tc_strcat(ModPartAct,Stage_item_Rev_Seq);

																printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
																setAddStrFuction(icount,SetModulePart,ModPartAct);
															}
														}
													}
												}
											}
										}

									}//for loop
								}//if(n_lines2 > 0)

							}
						}
					}
				}
			}
			else
			{
				printf("\nSVR Not Query VariantRule"); fflush(stdout);	
			}
		}
	}
	else 
	{
		printf ("\n  Platform not found [%s]\n", t5_SchmPlant); fflush(stdout);	
	}
	
	return ifail;
}

//Start EBOM-MBOM Function for Snapshot
static tag_t ask_item_revision_from_bom_line_SnapShot(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITKCALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITKCALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITKCALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

void GetAllChild_SnapShot(tag_t* top_line,int depth,char ***SetModulePart,int *icount)
{
	int n = 0;
	tag_t* children = NULLTAG;
	int k = 0;
	int Item_ID = 0;
	int Item_RevSeq = 0;
	char *Item_ID_str = NULL;
	char *Item_RevSeq_str = NULL;
	tag_t ChildItemRev = NULLTAG;
	char	*ModPartType=	NULL;
	char	*ModPartAct	=	NULL;

	
	depth++;
	printf("\nInside GetAllChild_SnapShot********");fflush(stdout);
	//ITKCALL( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	//ITKCALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_RevSeq));
	//ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_ID, &Item_ID_str));
	//ITKCALL(BOM_line_ask_attribute_string(*top_line, Item_RevSeq, &Item_RevSeq_str));

	AOM_UIF_ask_value(*top_line, "bl_item_item_id", &Item_ID_str);
	printf("\n Item_ID_str-----------------------------------------------------=%s\n",Item_ID_str);fflush(stdout);
	AOM_UIF_ask_value(*top_line, "bl_rev_item_revision_id", &Item_RevSeq_str);
	printf("\n Item_RevSeq_str-----------------------------------------------------=%s\n",Item_RevSeq_str);fflush(stdout);


	printf("\n%d]Item_ID_str: [%s] [%s]",depth,Item_ID_str,Item_RevSeq_str);fflush(stdout);
	ChildItemRev = ask_item_revision_from_bom_line_SnapShot(*top_line);
	
	if (ChildItemRev==NULLTAG)
	{
		printf("\nNULLTAG FOUND FOR BOM LINE ITEM : %s",Item_ID_str);fflush(stdout);
	}
	else
	{
		if(ModPartType) ModPartType=NULL;

		ITKCALL(AOM_ask_value_string(*top_line, "bl_Design_t5_RevPartType", &ModPartType ));
		printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
	
		if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"T")==0) || (tc_strcmp(ModPartType,"CM")==0)) //TCE-Sunset related chnages
		{
			printf("\nFor Adding Item_ID_str: [%s] [%s]",Item_ID_str,Item_RevSeq_str);fflush(stdout);

			//To add in set
			ModPartAct	=	(char	*)MEM_alloc(300);
			tc_strcpy(ModPartAct,Item_ID_str);
			tc_strcat(ModPartAct,"/");
			tc_strcat(ModPartAct,Item_RevSeq_str);

			printf("\n ModPartAct --> : %s",ModPartAct); fflush(stdout);
			setAddStrFuction(icount,SetModulePart,ModPartAct);
		}
		ITKCALL(BOM_line_ask_child_lines (*top_line, &n, &children));

		printf("\nAssembly:%s no of child found:%d",Item_ID_str,n);fflush(stdout);
		for (k = 0; k < n; k++)
		{
			GetAllChild_SnapShot(&children[k],depth,SetModulePart,icount);
		}
	}
}

int tm_ebom_snapshot(char *snapshot,char ***SetModulePart,int *icount)
{
	int	ifail 	=   ITK_ok;

	WSO_search_criteria_t SSCriteria;

	tag_t* SSobjTag		= NULLTAG;

	int SScount			= 0;
	int Item_ID			= 0;

	tag_t Snapshot_tag	= NULLTAG;
	tag_t window		= NULLTAG;
	tag_t item_rev_tags	= NULLTAG;
	tag_t top_line		= NULLTAG;

	char* SSTopLineRev	= NULL;
	char *Item_ID_str	= NULL;

	

	printf("\nInSide tm_ebom_snapshot functionssssssss");fflush(stdout);
	
	printf("\nsnapshot ...%s\n", snapshot);fflush(stdout);
	
	ITKCALL(WSOM_clear_search_criteria(&SSCriteria));
	tc_strcpy(SSCriteria.class_name,"Snapshot");
	tc_strcpy(SSCriteria.name,snapshot);
	ITKCALL(WSOM_search(SSCriteria,&SScount,&SSobjTag));
	printf("\nSnapShot found :%d",SScount);fflush(stdout);

	if (SScount > 0)
	{		
		Snapshot_tag = SSobjTag[0];

		ITKCALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
		printf("\nSnapshot Top Line : %s",SSTopLineRev);fflush(stdout);

		ITKCALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));

		ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
		ITKCALL(BOM_set_window_pack_all (window, FALSE));
		ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

		//ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
		//ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));


		AOM_UIF_ask_value(top_line, "bl_item_item_id", &Item_ID_str);
		printf("\n \n Item_ID_str-----------------------------------------------------=%s\n",Item_ID_str);fflush(stdout);
		printf("\nItem_ID_str#:%s",Item_ID_str);fflush(stdout);


		GetAllChild_SnapShot(&top_line,2,SetModulePart,icount);

	}
	else 
	{
		printf ("\n  SnapShot not found [%s]\n", snapshot); fflush(stdout);	
	}
	
	
	return ifail;
}
//End EBOM-MBOM Function for Snapshot

extern int EBOMMBOMReportServiceFnc( void *retValue)
{
	int				ifail 	= ITK_ok;
	int n_objects = 0;
    tag_t *objects = NULL;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;	
	char *pltfrm_item= NULL;
	char *svr_item= NULL;
	char *revrule_item= NULL;
	char *closurerule_item= NULL;
	char *effdate_item= NULL;
	char** bufferedXmlStrOut;
	int buff_cnt=0;	
	int m =0;

	USERARG_get_string_argument(&pltfrm_item);
	USERARG_get_string_argument(&svr_item);
	USERARG_get_string_argument(&revrule_item);
	USERARG_get_string_argument(&closurerule_item);
	USERARG_get_string_argument(&effdate_item);
		
		
	printf("\nArgument Received(EBOMMBOMReportServiceFnc) pltfrm_item=%s\n",pltfrm_item);fflush(stdout);	
	printf("Argument Received(EBOMMBOMReportServiceFnc) svr_item=%s\n",svr_item);fflush(stdout);	
	printf("Argument Received(EBOMMBOMReportServiceFnc) revrule_item=%s\n",revrule_item);fflush(stdout);	
	printf("Argument Received(EBOMMBOMReportServiceFnc) closurerule_item=%s\n",closurerule_item);fflush(stdout);	
	printf("Argument Received(EBOMMBOMReportServiceFnc) effdate_item=%s\n",effdate_item);fflush(stdout);	
	
	
	printf("After returning Value\n");fflush(stdout);

	if(tc_strcmp(svr_item,"SnapShot")==0)
	{
		//Calling snapshot functions	
		printf("Calling snapshot functions\n");fflush(stdout);
		tm_ebom_snapshot(pltfrm_item,&bufferedXmlStrOut,&buff_cnt);	
	}
	else
	{	
		tm_ebom_mbom_rpt(pltfrm_item,svr_item,revrule_item,closurerule_item,effdate_item,&bufferedXmlStrOut,&buff_cnt);
	}
	printf("\nbuff_cnt : %d",buff_cnt);fflush(stdout);	
	
	m =0;
	printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	for(m=0;m<buff_cnt;m++)
	{
		printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}	
	printf("\nBefore returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);
	printf("\nAfter returning Value=%d",array_struct.length);fflush(stdout);
	
	if (array_struct.length != 0)
		*((USERSERVICE_array_t*) retValue) = array_struct;	
	 
	printf("\nAfter returning Value*******");fflush(stdout);

	return ifail;
}


extern int EBOMMBOMReportRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 5;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;

	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EBOMMBOMReportServiceFnc before....EBOMMBOMReportServiceCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("EBOMMBOMReportServiceFnc",(USER_function_t)EBOMMBOMReportServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int AllAPLFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	CALLAPI(EBOMMBOMReportRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_APLSTDSIFuncs_register_callbacks ()
{
	int ifail    = ITK_ok;
   
	ifail=CUSTOM_register_exit ( "tm_APLSTDSIFuncs", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllAPLFuncServiceFnc);

	return ( ITK_ok );
}
