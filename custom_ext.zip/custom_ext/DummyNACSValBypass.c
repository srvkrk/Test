#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

extern EPM_decision_t DLLAPI DummyNACSValBypass_Check_Func(EPM_rule_message_t msg)
{

	int status;
	EPM_decision_t decision;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int cnt = 0;
	char*	itemid;
	char*	ChildDml;

	char *  IsPPPPMRlzErr = NULL;
	char *  SetIsPPPPMRlzErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line						= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag						= NULLTAG;
	tag_t	item_rev_tag_p						= NULLTAG;
	tag_t	item_rev_task						= NULLTAG;
	tag_t	reln_type_tag						= NULLTAG;


	tag_t	itemTypeTag_cdss					= NULLTAG;
	tag_t	itemclass							= NULLTAG;
	//tag_t	itemclassp							= NULLTAG;
	tag_t	itemclass_task						= NULLTAG;
	tag_t	itemcldclass						= NULLTAG;
	tag_t	value_child_details					= NULLTAG;
	tag_t	objTypeRefTag						= NULLTAG;

	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			task_obj_tag		= NULLTAG;

	int				PartCnt				= 0;
	int				taskCnt				= 0;
	int             st_count			= 0;
	int				n_refs				= 0;
	WSO_description_t desc;


	int				AttCnt				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			task_Tag			= NULLTAG;
	tag_t			task_rev_tag		= NULLTAG;


	char*			Part_no				= NULL;
	char*			Part_type			= NULL;
	char*			Part_CS				= NULL;
	char*			task_no				= NULL;
	char*			inp_task_no			= NULL;
	char			*inp_Plant			= NULL;
	char			*task_Plant			= NULL;
	char            *desid				= NULL;
	char			*dml_type			= NULL;
	char			type_name_ref[TCTYPE_name_size_c+1];


	int				task_len=0;
	int				inp_len=0;
	int				cntErr=0;

	int				ifail				= ITK_ok;
	int				 *levels			= 0;
	tag_t			*referencers		= NULLTAG;

	char			**relations			= NULL;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;

   	printf("\n Inside DummyNACSValBypass_Check_Func %d.....\n",iNumAttch);
	if (!SetIsPPPPMRlzErr) MEM_free(SetIsPPPPMRlzErr);
	SetIsPPPPMRlzErr=(char *)MEM_alloc(1000);
	tc_strcpy(SetIsPPPPMRlzErr,"");
	cntErr = 0;



	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n DummyNACSValBypass_Check_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );


    if(tc_strcmp(CurrentTask,"Work On DML" )==0)
	{
 		ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
			{
				tag_t objTypeTag = NULLTAG;
				tag_t objChildRevTag = NULLTAG;

				ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
				printf("\n itemid %s.....\n",itemid);

				//ITKCALL(ITEM_find_item(itemid,&itemclass));
				//ITKCALL(ITEM_ask_latest_rev(itemclass,&item_rev_tag));
				//ITKCALL(AOM_ask_value_string(item_rev_tag,"item_id",&inp_task_no));
				printf("\n\n\t\t APL DML Cre:itemid  is :%s",itemid);	fflush(stdout);

				//if(strstr(inp_task_no,"AM"))
				//{
				inp_len=0;
				inp_len=strlen(itemid);
				if(strstr(itemid,"NONERC"))
				{
					inp_Plant=subString(itemid,18,inp_len);
				}
				else
				{
					inp_Plant=subString(itemid,14,inp_len);
				}

				printf("\n itemid %s \n",itemid);
				ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
				ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
				printf("\t  type_name ...%s\n", type_name);
				if( objTypeTag == ItemTypeTag )
					{
						printf("\t \n objTypeTag == ItemTypeTag \n");

						ITKCALL (TCTYPE_ask_object_type(pTagAttch[i],&itemTypeTag_cdss));
						ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

						printf("\t  type_itemRev ...%s\n", type_itemRev);

						if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
						{

    						ITKCALL(AOM_ask_value_tags(pTagAttch[i],"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
							if (PartCnt>0)
							{
								GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
								for (k=0;k<PartCnt ;k++ )
								{
									const char *qry_entries[1];
									const char *qry_values[1];
									int n_tags_found=0;
									tag_t	*itemclassp	= NULLTAG;
									 tag_t item = NULLTAG;
									printf("\n\n\t\t for k =:%d",k);fflush(stdout);
									AssyTag=PartTags[k];

									ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
									 qry_entries[0] ="item_id";
									 qry_values[0] = Part_no;
									ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
									//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
									item = itemclassp[0];
									if(item != NULLTAG )
									ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag_p));

									ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type));
									printf("\n\n\t\t Part_type  is :%s",Part_type);	fflush(stdout);

									ITKCALL(AOM_ask_value_string(AssyTag,"t5_PunMakeBuyIndicator",&Part_CS));
									printf("\n\n\t\t Part_CS  is :%s",Part_CS);	fflush(stdout);

									if( (strstr(Part_CS,"NA")) || (strcmp(Part_type,"D")==0) )
									{
										printf("\n\n\t\t Validation Bypass");	fflush(stdout);
										decision = EPM_go;
										return decision;
									}
									else
									{
										printf("\n\n\t\t Validation Calling");	fflush(stdout);
										decision = EPM_nogo;
										return ITK_err;
									}


								}
							}


						}
					}

			}
	}


//	decision = EPM_go;
//	return decision;
}

extern int DummyNACSValBypass_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;


	if( ITK_ok == EPM_register_rule_handler ("DummyNACSValBypass_Check","This Handler is used to display message",(EPM_rule_handler_t)DummyNACSValBypass_Check_Func))
   {
		printf("\t\n Registered Rule Handler DummyNACSValBypass_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler DummyNACSValBypass_register_method\n");fflush(stdout);
   }

    return ITK_ok;
}

extern DLLAPI int DummyNACSValBypass_register_callbacks()
{
	 CUSTOM_register_exit("DummyNACSValBypass", "USER_init_module", (CUSTOM_EXIT_ftn_t)DummyNACSValBypass_register_method);

     printf("\n registered function DummyNACSValBypass\n");	fflush(stdout);

	 return ( ITK_ok );
}
