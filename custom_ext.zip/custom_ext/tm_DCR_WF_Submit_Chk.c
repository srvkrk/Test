/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Ajinkya Jaybhaye
*  Module               :   Workflow Rule Handler basic PO Check validations.
*  Code                 :   tm_DCR_WF_Submit_Chk.c
*  Created on			:   Dec 2023
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_DCR_WF_Submit_Chk(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char *sDCRCHkinfo1		= NULL;
	char *usernam		= NULL;
	int i =0;
	int Allowfalg =0;
	int no_attach	=  0;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	char *group_name = NULL;
	tag_t group_tag = NULLTAG;
	
	printf("\n tm_DCR_WF_Submit_Chk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DCR_WF_Submit_Chk Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if((tc_strcmp(ObjTyp,"DCR Task Revision")==0) || (tc_strcmp(ObjTyp,"T5_DcrTaskRevision")==0))
			{
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n PO:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n PO:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "DCRWFCHK";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n PO:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//PO bypass
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&sDCRCHkinfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n DCR:sDCRCHkinfo1:%s\n",sDCRCHkinfo1);fflush(stdout);
					if(strstr(sDCRCHkinfo1,"DCR001")==NULL)
					{
						POM_ask_group(&group_name, &group_tag);
						printf ("tm_CheckSignoffRole: CheckRole-->Logged in group:%s\n",group_name);fflush(stdout);
						if (tc_strcmp(group_name,"PLM_Support_Group") == 0)
						{
							Allowfalg=1;
						}
						if(POM_get_user_id (&usernam)!=ITK_ok)PrintErrorStack();
						printf("\n PO:Session login User1 for MR : %s\n",usernam); fflush(stdout);
						if(tc_strcmp(usernam,"infodba") ==0 || tc_strcmp(usernam,"loader") ==0)
						{
							Allowfalg=1;
						}
						printf("\n DCR: Allowfalg : %d\n",Allowfalg); fflush(stdout);
						if (Allowfalg ==0)
						{
							printf("\n DCR:ERROR: DCR task not allowed to .\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: You are not allowed to submit DCR task to this workflow.\n If you want to open/close DCR task, then please raise your query to DML/DCR support team in TMS.\n",usernam);	
							decision = EPM_nogo;
							return decision;
						}
					}
					else
					{
						decision = EPM_go;
						return decision;
					}
				}
			}
		}
	}
	printf("\n tm_DCR_WF_Submit_Chk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_DCR_WF_Submit_Chk Function end...");
	return decision;
}
