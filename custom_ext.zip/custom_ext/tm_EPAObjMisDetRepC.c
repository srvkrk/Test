/******************************************************************************
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
* *------------------------------------------------------------------------------
** Filename		:	EstOperationBCNo.c
*
* Description	: > Estimate sheet Operation BC No report for Plantspecific
*				  
* Module  		        
* Since		    :   28-02-2025
* ENVIRONMENT	:   C, ITK
 
*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 28-02-2025    Akhilesh Mittal			    			Operation BC No report for Plantspecific

* -----------------------------------------------------------------------------
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

char *PlmUserId = NULL;
char *mailIDList = NULL;

signed long daysInSecond(signed int day){
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )    
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y-%H-%M",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int ITK_user_main(int argc,char *argv[])
{
	int iFail     = 0;
	int status     = 0;
	int dmlcounter     = 0;
	char*   From_date = NULL;
	char*   To_date = NULL;
	char 	*iFromdate			=	NULL;
	char 	*iTodate			=	NULL;
	char 	*iPlant			=	NULL;
	char 	*iPlant1			=	NULL;
	
	
	FILE *Report = NULL;
	
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);
	printf("\n Login to DB succesfully\n");
	
	iFromdate = ITK_ask_cli_argument("-f=");
	iTodate = ITK_ask_cli_argument("-t=");
	iPlant1 = ITK_ask_cli_argument("-pt=");
	PlmUserId = ITK_ask_cli_argument("-PlmId=");  
	
	if(strstr(iPlant1,"JSR") != NULL) 
	{
		STRNG_replace_str(iPlant1,"JSR","CVBU JSR",&iPlant);
	}
	else if(strstr(iPlant1,"UTK") != NULL)
	{
		STRNG_replace_str(iPlant1,"UTK","CVBU PNR",&iPlant);
	}
	else if(strstr(iPlant1,"PUNE") != NULL)
	{
		STRNG_replace_str(iPlant1,"PUNE","CVBU PUNE",&iPlant);
	}
	else if(strstr(iPlant1,"DWD") != NULL)
	{
		STRNG_replace_str(iPlant1,"DWD","DHARWAD",&iPlant);
	}
	else if(strstr(iPlant1,"LKO") != NULL)
	{
		STRNG_replace_str(iPlant1,"LKO","CVBU LKO",&iPlant);
	}
	else
	{
		STRNG_replace_str(iPlant1,"AllPlant","*",&iPlant);
	}
	//tc_strcat(iFromdate," 00:00");
	//tc_strcat(iTodate," 23:59");
	
	printf("\n From date is :: %s ",iFromdate);fflush(stdout);
	printf("\n To date is :: %s ",iTodate);fflush(stdout);
	printf("\n Plant :: %s ",iPlant);fflush(stdout);
		
	tag_t*  OperationTag 	= NULLTAG;
	tag_t* EPATags = NULLTAG;
	tag_t* TaskRevision = NULLTAG;
	int EPACnt,k=0;
	char *OprcreatDate  = NULL;
	char *CorrectCre_date = NULL;
	char *EPAnumber=NULL;
	char *EPATask=NULL;
	char *EPATaskDup=NULL;
	char *EPPlant=NULL;
	char *EPADesc=NULL;
	char *EPADesc1=NULL;
	char *EPADesc2=NULL;
	char *EPADescnew  = NULL;
	char *EPACreator=NULL;
	char *EPACreDate=NULL;
	char *EPACreDateNew=NULL;
	char *EPAsampledate=NULL;
	char *EPAsampledateNew=NULL;
	char *EPAbreakptDate=NULL;
	char *EPAbreakptDateNew=NULL;
	char *EPAreleaseDate=NULL;
	char *EPAreleaseDateNew=NULL;
	char *EPAMBPAreleaseDate=NULL;
	char *EPAMBPAreleaseDateNew=NULL;
	char *EPATrialDate=NULL;
	char *EPATrialDateNew=NULL;
	char *AplStatus=NULL;
	char *StdStatus=NULL;

	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);
	printf("\n Login to DB succesfully\n");
	
	char CurrentDate[20]={0};
	getCurrentDateTime(CurrentDate);
	printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
	struct tm *timeinfo;
	time_t t1;
	time_t t3;
	char buffer[256];
	tag_t epa_PartTag = NULLTAG;
	tag_t relation_type_epa=NULLTAG;
	
	t1 = time(NULL);
    t3 = shiftDate(t1,-1);
	timeinfo = localtime(&t3);
	strftime (buffer, 20, "%d-%b-%Y",timeinfo);
	printf("\n Previous Day Date :%s\n",buffer);
	char* Header =NULL;
	Header=(char*) MEM_alloc(100);
	tc_strcpy(Header,"");
	char* filename =NULL;
	
	filename=(char*) MEM_alloc(1000);
	tc_strcpy(filename,"");
	tc_strcat(filename,"EPA_MIS_REPORT_");
	tc_strcat(filename,CurrentDate);
	tc_strcat(filename,".csv");
	printf("\n File Name %s\n",filename);fflush(stdout);
	Report = fopen(filename,"w");

	fprintf(Report, ",MIS Report for EPA Milestone / Date Summary From %s To %s for plant %s\n", iFromdate,iTodate,iPlant);fflush(Report);
	fprintf(Report, "\nPlant,EPA No.,EPA Description,EPA Creator (Owner),DML no,LifeCycle State,EPA Creation Date,Sample Avalability Date(with IR / MR),	OK Trials(1+5),SQ Ramp Up Date,Break Point Declaration Date(SCM Clearance), EPA STDS Release Date,MBPA & EPA finalisation and Closure Date\n\n");fflush(Report);
	
	int 	Obj_Count   = 0;

	tag_t   querytag1	= NULLTAG;
	
	char    	*qryentrs1[]	= {"ID","From_Date","To_Date","Plant"};	
	char		**qryvalue1= (char **) MEM_alloc(900 * sizeof(char *));
		
	ITK_CALL(QRY_find2("EPAMIS_Between_Date1",&querytag1));
		
	printf("\nAkki befor Query Execute OperationBCNo......\n \n ");fflush(stdout);

	printf("\n\n outside querytag Execute ");fflush(stdout);
	printf("\n\n just outside querytag1 Execute ");fflush(stdout);
	if(querytag1 != NULLTAG)
	{
		printf("\n\n Inside querytag1 Execute ");fflush(stdout);
		int i,epatCnt,count =0;
		int j =0;
		int countpdml =0;
		
		char*  operationid =NULL;
		char*  BCNo =NULL;
		char*  CostDriver =NULL;
		char*  EPOCHValue =NULL;
		char*  owner =NULL;
		char*  prtseq =NULL;
		char*			EPASheetobject_type			= NULL;
		qryvalue1[0]="**";
		qryvalue1[1]=iFromdate;
		qryvalue1[2]=iTodate;
		qryvalue1[3]=iPlant;
		
		// qryvalue1[1]="01-Jan-2025 00:00";
		// qryvalue1[2]="05-Mar-2025 00:00";
		
		ITK_CALL(QRY_execute(querytag1,4, qryentrs1, qryvalue1, &EPACnt, &EPATags)); //APL Released DML Revision
		printf("\n\n Number of object Found %d \n\n",EPACnt);fflush(stdout);
		
		
		for(k=0;k<EPACnt;k++)
		{
			char *lifecycle_state=NULL;
			lifecycle_state = (char *) MEM_alloc( 100 * sizeof(char) );  
			
			GRM_find_relation_type("T5_DMLTaskRelation",&relation_type_epa);
			GRM_list_secondary_objects_only(EPATags[k],relation_type_epa,&count,&TaskRevision);
						
			printf("\n\n Fetching Values for EPAnumber\n  ");fflush(stdout);
			
			AOM_ask_value_string(EPATags[k] ,"t5_EpaPlantA",&EPPlant);
			printf("EPPlant  found =%s\n",EPPlant);fflush(stdout);
						
			AOM_ask_value_string(EPATags[k] ,"item_id",&EPAnumber);
			printf("EPAnumber  found =%s\n",EPAnumber);fflush(stdout);
			
			AOM_ask_value_string(EPATags[k] ,"current_desc",&EPADesc);
			STRNG_replace_str(EPADesc,","," ",&EPADesc1);
			STRNG_replace_str(EPADesc1,"\n"," ",&EPADesc2);
			printf("EPADesc2  found =%s\n",EPADesc2);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"owning_user",&EPACreator);
			printf("EPACreator  found =%s\n",EPACreator);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k],"release_status_list",&lifecycle_state);fflush(stdout);
			printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
			
			AOM_UIF_ask_value(EPATags[k] ,"creation_date",&EPACreDate);
			EPACreDateNew=subString(EPACreDate,0,11);
			printf("EPACreDate  found =%s\n",EPACreDateNew);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"t5_LstSmplDate",&EPAsampledate);
			EPAsampledateNew=subString(EPAsampledate,0,11);
			printf("EPAsampledate  found =%s\n",EPAsampledateNew);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"t5_BreakPointDate",&EPAbreakptDate);
			EPAbreakptDateNew=subString(EPAbreakptDate,0,11);
			printf("EPAbreakptDate  found =%s\n",EPAbreakptDateNew);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"t5_AQSt1PrtAvalDateForTrail",&EPATrialDate);
			EPATrialDateNew=subString(EPATrialDate,0,11);
			printf("EPATrialDate  found =%s\n",EPATrialDateNew);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"date_released",&EPAreleaseDate);
			EPAreleaseDateNew=subString(EPAreleaseDate,0,11);
			printf("EPAreleaseDateNew  found =%s\n",EPAreleaseDateNew);fflush(stdout);
			
			AOM_UIF_ask_value(EPATags[k] ,"t5_MEPAQADate",&EPAMBPAreleaseDate);
			EPAMBPAreleaseDateNew=subString(EPAMBPAreleaseDate,0,11);
			printf("EPAMBPAreleaseDateNew  found =%s\n",EPAMBPAreleaseDateNew);fflush(stdout);
			
			if(count >0)
			{							
				for (epatCnt=0;epatCnt<count ;epatCnt++ )
				{
					epa_PartTag=NULLTAG;
					epa_PartTag=TaskRevision[epatCnt];
					
					AOM_ask_value_string(TaskRevision[epatCnt] ,"item_id",&EPATask);
					EPATaskDup = subString(EPATask,11,25);
					printf("EPATaskDup  found =%s\n",EPATaskDup);fflush(stdout);
					
				}
			}
			
						
			//fprintf(Report,"%s,%s,%s,%s,,%s,%s,,,%s,%s,%s\n",EPPlant,EPAnumber,EPADesc,EPACreator,EPACreDateNew,EPAsampledateNew,EPAbreakptDateNew,EPAreleaseDateNew,EPAMBPAreleaseDateNew);fflush(Report);	
			fprintf(Report,"%s,%s,%s,%s,%s,",EPPlant,EPAnumber,EPADesc2,EPACreator,EPATaskDup);fflush(Report);	
			
			
						
			if(tc_strstr(lifecycle_state,"Working")!=NULL && tc_strstr(lifecycle_state,"Released")==NULL)
			{
				fprintf(Report,"STDSI Working,");fflush(Report);	
				
			}
			else if(tc_strstr(lifecycle_state,"Working")!=NULL && tc_strstr(lifecycle_state,"Released")!=NULL)
			{
				fprintf(Report,"STDSI Released,");fflush(Report);	
			}
			else if(tc_strstr(lifecycle_state,"Working")==NULL && tc_strstr(lifecycle_state,"Released")!=NULL)
			{
				fprintf(Report,"STDSI Released,");fflush(Report);	
			}
			else
			{
				fprintf(Report,"NA,");fflush(Report);
			}
			
			fprintf(Report,"%s,%s,%s,,%s,%s,%s\n",EPACreDateNew,EPAsampledateNew,EPATrialDateNew,EPAbreakptDateNew,EPAreleaseDateNew,EPAMBPAreleaseDateNew);fflush(Report);	
			
			
				
		}
		
	}
	if(OperationTag)
		MEM_free(OperationTag);
		 
	
	fclose(Report);
	printf("\n\n outside report querytag Execute ");fflush(stdout);
	printf("\n  Report Generated succesfully ....\n");
	
	void MailReportToUser()
	{
	char* ReportMail = NULL;
    ReportMail = (char *) MEM_alloc(1000);

    char* MailSubject = NULL;
    MailSubject = (char *) MEM_alloc(100);
    tc_strcpy(MailSubject,"EPA Objects MIS REPORT between ");
    tc_strcat(MailSubject,iFromdate);
    tc_strcat(MailSubject," to ");
    tc_strcat(MailSubject,iTodate);
    sprintf(ReportMail,"(cat content )| Mail -s  \"%s\" -a %s -c `cat CC` %s",MailSubject,Report,mailIDList);
    
	printf("\n %s",ReportMail);fflush(stdout);
    int SysReturn = 0;
	printf("\n %s",ReportMail);fflush(stdout);
    SysReturn = system(ReportMail);
	}
	
	
	void GetMailIDList()
	{
	tag_t   UserQryTag       =    NULLTAG;
	if(QRY_find2("UserFind", &UserQryTag));
    if (UserQryTag)
    {
        printf("\n Query UserFind Found \n");fflush(stdout);
    }
    else
    {
        printf("\n Query Tag UserFind Not Found \n");fflush(stdout);
    }
	char    *qry_entryUser[1]            =    {"Id"};
    char    *qry_valuesUser[1]           =    {PlmUserId};
	int CntUser = 0;
	tag_t* UserObjects_Tag;
	tag_t Person_Tag = NULLTAG;
	char* UserEmailIdVal = NULL;
	char* UserEmailIdValDup = NULL;
	UserEmailIdValDup = (char *) MEM_alloc(50);
    if(QRY_execute(UserQryTag, 1, qry_entryUser, qry_valuesUser, &CntUser, &UserObjects_Tag));
    printf("No of User Object Found = %d",CntUser);fflush(stdout);
	
	ITK_CALL(SA_ask_user_person(UserObjects_Tag[0],&Person_Tag));
	ITK_CALL(SA_ask_person_email_address(Person_Tag,&UserEmailIdVal));
	strcpy(UserEmailIdValDup,UserEmailIdVal);
	printf("\n UserEmailIdVal =%s",UserEmailIdVal);fflush(stdout);
	mailIDList = (char *) MEM_alloc(50);
	strcpy(mailIDList,UserEmailIdVal);
	
	printf("\n mailIDList =%s",mailIDList);fflush(stdout);
	}
 		
}
