/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int tm_EBOMMBOM_VCReportServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	char *VCNumber= NULL;
	char *VCRev= NULL;
	char *VCSeq= NULL;
	char *SelClosureEBOM= NULL;
	char *SelClosureMBOM= NULL;
	char *SelRRMBOM= NULL;
	char *SelRREBOM= NULL;
	char *userId= NULL;
	char *ScheckQty_VC= NULL;
	char *ScheckWeld_VC= NULL;
	char *ScheckSealant_VC= NULL;
	char *ScheckStud_VC= NULL;
	char *ScheckArcLen_VC= NULL;
	char *RptLoc= NULL;
	char *TaskNum= NULL;
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;


	//USERARG_get_string_argument(&countValidPart);
	USERARG_get_string_argument(&VCNumber);
	USERARG_get_string_argument(&VCRev);
	USERARG_get_string_argument(&VCSeq);
	USERARG_get_string_argument(&SelClosureEBOM);
	USERARG_get_string_argument(&SelClosureMBOM);
	USERARG_get_string_argument(&SelRREBOM);
	USERARG_get_string_argument(&SelRRMBOM);
	USERARG_get_string_argument(&userId);
	USERARG_get_string_argument(&ScheckQty_VC);
	USERARG_get_string_argument(&ScheckWeld_VC);
	USERARG_get_string_argument(&ScheckSealant_VC);
	USERARG_get_string_argument(&ScheckStud_VC);
	USERARG_get_string_argument(&ScheckArcLen_VC);
	USERARG_get_string_argument(&TaskNum);




	//VCNumber;       
	//VCRev;          
	//VCSeq;          
	//SelClosureEBOM; 
	//SelClosureMBOM  
	//SelRRMBOM       
	//SelRREBOM       
	// userId	
	// ScheckQty_VC      
	// ScheckWeld_VC     
	// ScheckSealant_VC 
	// ScheckStud_VC    
	// ScheckArcLen_VC 
	//TaskNum

	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc VCNumber=%s\n",VCNumber);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc VCRev=%s\n",VCRev);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc VCSeq=%s\n",VCSeq);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc SelClosureEBOM=%s\n",SelClosureEBOM);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc SelClosureMBOM=%s\n",SelClosureMBOM);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc SelRRMBOM=%s\n",SelRRMBOM);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc SelRREBOM=%s\n",SelRREBOM);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc userId=%s:\n",userId);fflush(stdout);	
	//printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc userId=%s: %s: %s: %s: %s\n",ScheckQty_VC,ScheckWeld_VC,ScheckSealant_VC,ScheckStud_VC,ScheckArcLen_VC);fflush(stdout);	
	printf("\nArgument tm_EBOMMBOM_VCReportServiceFnc userId=%s: %s: %s: %s: %s %s \n",ScheckQty_VC,ScheckWeld_VC,ScheckSealant_VC,ScheckStud_VC,ScheckArcLen_VC,TaskNum);fflush(stdout);	
	

	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="EBOMMBOMRepExePath";
		qry_valuesCntrl1[1]="Live";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found .... \n");fflush(stdout);
		
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	
	if(control_number_found1>0)
	{
	
		AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath);
						
		printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
		if(tc_strlen(shellpath)>0)
		{
			printf("\ninside EBOMMBOMRepExePath Execute through client code......\n");fflush(stdout);
			
			
			sysCmnd=(char *) MEM_alloc(400);
			tc_strcpy(sysCmnd,shellpath);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,VCNumber);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,VCRev);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,VCSeq);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,SelClosureEBOM);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,SelClosureMBOM);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,SelRREBOM);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,SelRRMBOM);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,userId);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,ScheckQty_VC);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,ScheckWeld_VC);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,ScheckSealant_VC);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,ScheckStud_VC);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,ScheckArcLen_VC);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,TaskNum);
			printf("\n before-- Calling shell file tm_EBOMMBOMRepVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
			system(sysCmnd);
			
			printf("\n after --- Calling shell file tm_EBOMMBOMRepVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
			
			MEM_free(sysCmnd);
		}
	
	
	}



	return ifail;
}


extern int tm_EBOMMBOM_VCReportRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 14; //13
	int retValueType;
	int validRowCntInt=0;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE; //VCNumber;
	inputArgTypes[1] = USERARG_STRING_TYPE; //VCRev;
	inputArgTypes[2] = USERARG_STRING_TYPE; //VCSeq;
	inputArgTypes[3] = USERARG_STRING_TYPE; //SelClosureEBOM;
	inputArgTypes[4] = USERARG_STRING_TYPE; //SelClosureMBOM
	inputArgTypes[5] = USERARG_STRING_TYPE; //SelRRMBOM
	inputArgTypes[6] = USERARG_STRING_TYPE; //SelRREBOM
	inputArgTypes[7] = USERARG_STRING_TYPE; // userId
	inputArgTypes[8] = USERARG_STRING_TYPE; // ScheckQty_VC
	inputArgTypes[9] = USERARG_STRING_TYPE; // ScheckWeld_VC
	inputArgTypes[10] = USERARG_STRING_TYPE; // ScheckSealant_VC
	inputArgTypes[11] = USERARG_STRING_TYPE; // ScheckStud_VC
	inputArgTypes[12] = USERARG_STRING_TYPE; // ScheckArcLen_VC
	inputArgTypes[13] = USERARG_STRING_TYPE; // TaskNum
	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EPAValidPrtUpdServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_EBOMMBOM_VCReportServiceFnc",(USER_function_t)tm_EBOMMBOM_VCReportServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_EBOMMBOMServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(tm_EBOMMBOM_VCReportRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_EBOMMBOM_VCReport_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_EBOMMBOM_VCReport_register_callbacks...."); 
	printf("\n Before registoring userservice tm_EBOMMBOM_VCReport ...."); 
	ifail=CUSTOM_register_exit ( "tm_EBOMMBOM_VCReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_EBOMMBOMServiceFnc);
	printf("\n After registoring userservice tm_EBOMMBOM_VCReport....");
	return ( ITK_ok );
}

