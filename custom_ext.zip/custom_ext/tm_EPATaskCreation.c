/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       tm_EPATaskCreation.c
*
* Description   : > EPA Task creation
*                                 > This ITK functions are called in Rich Client
* Module
* Since             :   28-11-2022
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 13/01/2025     Sandeep Goyal/Abineswar Bisoi                      Base Code
*
* -----------------------------------------------------------------------------
*
*****************************************************************************/


#include <tccore/aom.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pie/pie.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


char 	               *EPATaskProjectCode	                            =	NULL;
char 	               *EPATaskDesignGrp	                            =	NULL;
char 	               *STDEPATaskNme 	                                =	NULL;
char 	               *STDEPATaskDesc 	                                =	NULL;

void STDSIITKREpaTskCrn()
{
	
	char**                  stringArrayEPATaskInput                         =       NULL;
    char**                  stringArrEpaInput                               =       NULL;
    int                     n_strings                                       =       1;
    int                     l_strings                                       =       300;
    int                     index                                           =       0;
	tag_t                   ObTag                                           =       NULLTAG;
    tag_t                   ObTagRev                                        =       NULLTAG;
    tag_t                   createInputTag                                  =       NULLTAG;
    tag_t                   createInputTagRev                               =       NULLTAG;
    tag_t                   objectTag                                       =       NULLTAG;
	char*                   tempString                                      =       NULL;
	
	printf("\n STDSIITKREpaTskCrn Started");fflush(stdout);
	
	stringArrayEPATaskInput = (char**)malloc( n_strings * sizeof *stringArrayEPATaskInput );
    stringArrEpaInput = (char**)malloc( n_strings * sizeof *stringArrEpaInput );
    for( index=0; index<n_strings; index++ )
    {
        stringArrayEPATaskInput[index] = (char*)malloc( l_strings + 1 );
    }
    for( index=0; index<n_strings; index++ )
    {
        stringArrEpaInput[index] = (char*)malloc( l_strings + 1 );
    }
    printf("\n Step 1 Done ");fflush(stdout);

    ITK_CALL(TCTYPE_ask_type("T5_EPATask",&ObTag));
    ITK_CALL(TCTYPE_construct_create_input(ObTag,&createInputTag));
    ITK_CALL( TCTYPE_find_type("T5_EPATaskRevision", NULL, &ObTagRev) );
    ITK_CALL( TCTYPE_construct_create_input(ObTagRev, &createInputTagRev) );
    printf("\n Step 2 Done ");fflush(stdout);
    
    tc_strcpy( stringArrEpaInput[0], STDEPATaskNme);
    
    ITK_CALL( TCTYPE_set_create_display_value( createInputTag, "object_name", 1, (const char**)stringArrEpaInput) );
    ITK_CALL( TCTYPE_set_create_display_value( createInputTag, "item_id", 1, (const char**)stringArrEpaInput) );
    
    tc_strcpy( stringArrEpaInput[0], STDEPATaskDesc);
    ITK_CALL( TCTYPE_set_create_display_value( createInputTag, "object_desc", 1, (const char**)stringArrEpaInput) );

    ITK_CALL( AOM_tag_to_string(createInputTagRev, &tempString) );
    tc_strcpy( stringArrEpaInput[0], tempString);
    ITK_CALL( TCTYPE_set_create_display_value( createInputTag, "revision", 1,(const char**)stringArrEpaInput) );
    printf("\n Step 3 Done ");fflush(stdout);		

    tc_strcpy( stringArrayEPATaskInput[0], "NR");
    ITK_CALL( TCTYPE_set_create_display_value( createInputTagRev, "item_revision_id", 1, (const char**)stringArrayEPATaskInput) );	
	
    tc_strcpy( stringArrayEPATaskInput[0], EPATaskProjectCode);
    ITK_CALL( TCTYPE_set_create_display_value(createInputTagRev, "t5_cprojectcode", 1, (const char**)stringArrayEPATaskInput) );	
	
	tc_strcpy( stringArrayEPATaskInput[0], EPATaskDesignGrp);
    ITK_CALL( TCTYPE_set_create_display_value(createInputTagRev, "t5_crdesigngroup", 2, (const char**)stringArrayEPATaskInput) );
	
    tc_strcpy( stringArrayEPATaskInput[0], "Veh");
    ITK_CALL( TCTYPE_set_create_display_value(createInputTagRev, "t5_rlstype", 1, (const char**)stringArrayEPATaskInput) );
    
    
	
    printf("\n Step 4 Done ");fflush(stdout);		

    ITK_CALL( TCTYPE_create_object(createInputTag, &objectTag) );
    AOM_save_without_extensions(objectTag);  
    if(AOM_refresh(objectTag,TRUE));
    printf("\n Step 5 Done ");fflush(stdout);
	
	printf("\n STDSIITKREpaTskCrn Ended");fflush(stdout);
	
}

int EPATaskCrnFrSTDSIFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                           =       ITK_ok;
	
	
	
 
    printf("\n EPA Task Creation FOR STDSI ");fflush(stdout);
	

	
    USERARG_get_string_argument(&STDEPATaskNme);
    USERARG_get_string_argument(&EPATaskProjectCode);
    USERARG_get_string_argument(&EPATaskDesignGrp);
    USERARG_get_string_argument(&STDEPATaskDesc);
    
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n STDEPATaskNme :: %s ",STDEPATaskNme);fflush(stdout);
    printf("\n EPATaskProjectCode :: %s ",EPATaskProjectCode);fflush(stdout);
    printf("\n EPATaskDesignGrp :: %s ",EPATaskDesignGrp);fflush(stdout);
    printf("\n STDEPATaskDesc :: %s ",STDEPATaskDesc);fflush(stdout);
	
	STDSIITKREpaTskCrn();
	
    return ifail;
}



extern int EPATaskUserServiceFn()
{
    int ifail = ITK_ok;
    int nargs = 4;
    int retValueType;
    int inputArgTypes[4] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; 
    inputArgTypes[1] = USERARG_STRING_TYPE; 
    inputArgTypes[2] = USERARG_STRING_TYPE; 
    inputArgTypes[3] = USERARG_STRING_TYPE; 
    
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("EPATaskCrnFrSTDSIFuncsvr",(USER_function_t)EPATaskCrnFrSTDSIFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceEPATaskCrnFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(EPATaskUserServiceFn());

    return ifail;
}

extern DLLAPI int tm_EPATaskCreation_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_EPATaskCreation", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceEPATaskCrnFn);
    return(ITK_ok);
}

