
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_CEDCoatedPart.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for CED Part Creation logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 20/05/2022   	Poonam			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>

#define T5_WorkFlowHandlerFDJErr (EMH_USER_error_base + 701)
#define MAX_LINE_LEN 1024


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
// Function to check if a character is printable
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}
char *replaceWord(const char *s, const char *oldW, 
                                 const char *newW) 
{ 
    char *result; 
    int i, cnt = 0; 
    int newWlen = strlen(newW); 
    int oldWlen = strlen(oldW); 
  
    // Counting the number of times old word 
    // occur in the string 
    for (i = 0; s[i] != '\0'; i++) 
    { 
        if (strstr(&s[i], oldW) == &s[i]) 
        { 
            cnt++; 
  
            // Jumping to index after the old word. 
            i += oldWlen - 1; 
        } 
    } 
  
    // Making new string of enough length 
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1); 
  
    i = 0; 
    while (*s) 
    { 
        // compare the substring with the result 
        if (strstr(s, oldW) == s) 
        { 
            strcpy(&result[i], newW); 
            i += newWlen; 
            s += oldWlen; 
        } 
        else
            result[i++] = *s++; 
    } 
  
    result[i] = '\0'; 
    return result; 
}
int executeIndDashBoardReportLogic( char* DatefromStr, char* DatetoStr, char*** bufferedXmlStrOut, int *buff_cnt )
{
	int ifail = ITK_ok;
	
	date_t   dateArray[2];
	date_t dateFrom;
	date_t dateTo;
	
	const char * select_attrs[]={"puid"};
	
	int n_inds = 0;
	int n_cols = 0;
	void ***values = NULL;	
	
	
	printf("\nQuery executing based on - Date Range: %s to %s\n",DatefromStr,DatetoStr);fflush(stdout);
	
	ITK_string_to_date(DatefromStr,&dateFrom);		
	ITK_string_to_date(DatetoStr,&dateTo);
	
	dateArray[0]=dateFrom;
	dateArray[1]=dateTo;
	
		//Step 1-   Creates a new enquiry.
		ifail = POM_enquiry_create ("find_dml_objs" );		
		//Step 2 - add the list to the select clause of the query
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_add_select_attrs ("find_dml_objs","T5_ERCIndRevision",1,select_attrs);
		}
		
		//Step 3a - create a date value object.
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_date_value ("find_dml_objs","expr_dates", 2 ,(const date_t*)dateArray,POM_enquiry_bind_value);
		}		
		//Step 4a - create an expression for pom creation_date = Date using the value "expr_dates" 
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dates_between","T5_ERCIndRevision","creation_date",POM_enquiry_between,"expr_dates");
		}		
		
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_where_expr ("find_dml_objs","expr_dates_between");
		}		
		// Step 7 Order by clause 
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_add_order_attr ("find_dml_objs","T5_ERCIndRevision", "creation_date", POM_enquiry_asc_order);
		}	
		//Step 8 - Executes the query and fetches the data.
		if (ifail == ITK_ok)
        {
            ifail = POM_enquiry_execute("find_dml_objs", &n_inds ,&n_cols, &values );
        }		
		//Step 9 - Delete the query and its sub-queries
        if (ifail == ITK_ok)
        {
            ifail = POM_enquiry_delete("find_dml_objs");
        }
		
		printf("\n No of Indents==>%d\n",n_inds);fflush(stdout);
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndDashBoardReport>");
		
		if(n_inds > 0)
		{
			int k = 0;
			int IndWorkFlowFlag=0;
			for(k=0;k<n_inds;k++)
				{
					tag_t indTagObj = NULLTAG;
					indTagObj  = *(tag_t*)(values[k][0]);
					IndWorkFlowFlag=0;
					
					char * IndRefNo = NULL;
					char * IndcreationDt = NULL;
					char * IndDummyRefNo = NULL;
					char * IndERIndSec = NULL;
					char * Indt5PrjCode = NULL;
					char * Indlast_mod_date = NULL;
					char * Indt5WBS = NULL;
					char * Indt5IndWbsDes = NULL;
					char * Indt5PrtIndCat = NULL;
					char * Indt5IndVehno = NULL;
					char*	IndRelStat		= NULL;
					char*	indDesigner		= NULL;
		
					if(indTagObj!=NULLTAG)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndDetails>");
						
						CALLAPI(AOM_ask_value_string(indTagObj,"t5RefNo",&IndRefNo));
						CALLAPI(AOM_UIF_ask_value(indTagObj,"creation_date",&IndcreationDt));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5DummyRefNo",&IndDummyRefNo));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5ERIndSec",&IndERIndSec));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5PrjCode",&Indt5PrjCode));
						CALLAPI(AOM_UIF_ask_value(indTagObj,"last_mod_date",&Indlast_mod_date));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5WBS",&Indt5WBS));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5IndWbsDes",&Indt5IndWbsDes));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5PrtIndCat",&Indt5PrtIndCat));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5IndVehno",&Indt5IndVehno));
						CALLAPI(AOM_ask_value_string(indTagObj,"t5PrtIndAct",&indDesigner));
						
						char* IndRefNoBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndCreDateBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndDummyRefNoBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndERIndSecBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indt5PrjCodeBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indlast_mod_dateBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indt5WBSBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indt5IndWbsDesBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indt5PrtIndCatBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* Indt5IndVehnoBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* indDesignerBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndSignoffUser1NewBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndSignoffUser2NewBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndAppDateBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndStatusNewBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndStartDateNewBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndAssgNameNewBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndRelStatBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* IndClouserDateBuf = (char *)MEM_alloc(200 * sizeof(char));;
						
						if(IndDummyRefNo != NULL) STRNG_replace_str(IndDummyRefNo,"\\n"," ",&IndDummyRefNo);
						if(IndDummyRefNo != NULL) STRNG_replace_str(IndDummyRefNo,"<","(",&IndDummyRefNo);
						if(IndDummyRefNo != NULL) STRNG_replace_str(IndDummyRefNo,">",")",&IndDummyRefNo);
						removeNonAsciiChars(IndDummyRefNo);
						if(IndDummyRefNo != NULL) STRNG_replace_str(IndDummyRefNo,"&","&amp;",&IndDummyRefNo);
						
						if(Indt5WBS != NULL) STRNG_replace_str(Indt5WBS,"\\n"," ",&Indt5WBS);
						if(Indt5WBS != NULL) STRNG_replace_str(Indt5WBS,"<","(",&Indt5WBS);
						if(Indt5WBS != NULL) STRNG_replace_str(Indt5WBS,">",")",&Indt5WBS);
						removeNonAsciiChars(Indt5WBS);
						if(Indt5WBS != NULL) STRNG_replace_str(Indt5WBS,"&","&amp;",&Indt5WBS);
						
						if(Indt5IndWbsDes != NULL) STRNG_replace_str(Indt5IndWbsDes,"\\n"," ",&Indt5IndWbsDes);
						if(Indt5IndWbsDes != NULL) STRNG_replace_str(Indt5IndWbsDes,"<","(",&Indt5IndWbsDes);
						if(Indt5IndWbsDes != NULL) STRNG_replace_str(Indt5IndWbsDes,">",")",&Indt5IndWbsDes);
						removeNonAsciiChars(Indt5IndWbsDes);
						if(Indt5IndWbsDes != NULL) STRNG_replace_str(Indt5IndWbsDes,"&","&amp;",&Indt5IndWbsDes);
						
						if(Indt5IndVehno != NULL) STRNG_replace_str(Indt5IndVehno,"\\n"," ",&Indt5IndVehno);
						if(Indt5IndVehno != NULL) STRNG_replace_str(Indt5IndVehno,"<","(",&Indt5IndVehno);
						if(Indt5IndVehno != NULL) STRNG_replace_str(Indt5IndVehno,">",")",&Indt5IndVehno);
						removeNonAsciiChars(Indt5IndVehno);
						if(Indt5IndVehno != NULL) STRNG_replace_str(Indt5IndVehno,"&","&amp;",&Indt5IndVehno);
						
						sprintf(IndRefNoBuf,"<IndNo>%s</IndNo>",IndRefNo);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndRefNoBuf);
						
						sprintf(IndCreDateBuf,"<IndCreDate>%s</IndCreDate>",IndcreationDt);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndCreDateBuf);
						
						sprintf(IndDummyRefNoBuf,"<IndUserRefNo>%s</IndUserRefNo>",IndDummyRefNo);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndDummyRefNoBuf);
						
						sprintf(IndERIndSecBuf,"<IndAgency>%s</IndAgency>",IndERIndSec);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndERIndSecBuf);
						
						sprintf(Indt5PrjCodeBuf,"<IndPrjCode>%s</IndPrjCode>",Indt5PrjCode);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indt5PrjCodeBuf);
						
						sprintf(Indlast_mod_dateBuf,"<IndLstModDate>%s</IndLstModDate>",Indlast_mod_date);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indlast_mod_dateBuf);
						
						sprintf(Indt5WBSBuf,"<IndWbs>%s</IndWbs>",Indt5WBS);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indt5WBSBuf);
						
						sprintf(Indt5IndWbsDesBuf,"<IndWbsDes>%s</IndWbsDes>",Indt5IndWbsDes);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indt5IndWbsDesBuf);
						
						sprintf(Indt5PrtIndCatBuf,"<IndPrtCat>%s</IndPrtCat>",Indt5PrtIndCat);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indt5PrtIndCatBuf);
						
						sprintf(indDesignerBuf,"<IndVCNo>%s</IndVCNo>",Indt5IndVehno);
						setAddStr(buff_cnt,bufferedXmlStrOut,indDesignerBuf);
						
						sprintf(Indt5IndVehnoBuf,"<IndHeadPlg>%s</IndHeadPlg>",indDesigner);
						setAddStr(buff_cnt,bufferedXmlStrOut,Indt5IndVehnoBuf);
						
						
						ITKCALL(AOM_UIF_ask_value(indTagObj,"release_status_list",&IndRelStat));
					
						printf("\n IndRelStat  == [%s]", IndRelStat);fflush(stdout);
					char* Indrlzdate	=	NULL;
					if(tc_strstr(IndRelStat,"ERC Released")!=NULL)
					{
						IndWorkFlowFlag=1;
						
						int				stat_count		= 0;
						int				LCStcnt		= 0;
						tag_t*			status_list			=	NULLTAG;
						char*			IndLCState		= NULL;
						
						ITKCALL(WSOM_ask_release_status_list(indTagObj,&stat_count,&status_list));
						{
							if(stat_count > 0)
								{
									for (LCStcnt=0; LCStcnt< stat_count; LCStcnt++)
									{
										char* Ind_Objclass_name	=	NULL;
										char* Ind_ObjType	=	NULL;
										Indrlzdate	=	NULL;
										ITKCALL(AOM_ask_value_string(status_list[LCStcnt],"object_name",&Ind_Objclass_name));
										printf("\n Ind_Objclass_name: %s\n",Ind_Objclass_name);fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(status_list[LCStcnt],"object_type",&Ind_ObjType));
										printf("\n rlz status object_type: %s\n",Ind_ObjType);fflush(stdout);
										
										if(tc_strcmp(Ind_Objclass_name,"T5_LcsErcRlzd")==0)
										{
											printf("\n Revision s is APL released");fflush(stdout);
											CALLAPI(AOM_UIF_ask_value(status_list[LCStcnt],"date_released",&Indrlzdate));
											printf("\n\t itemid--Indrlzdate:: [%s]\n\t",Indrlzdate);;fflush(stdout);
											//fprintf(DmlRelFile,",,Completed,,,%s,",Indrlzdate);fflush(DmlRelFile);
											break;

										}
									}
								}
						}
						
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner1></IndCurrentOwner1>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner2></IndCurrentOwner2>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndAppDat></IndAppDat>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStatus>Completed</IndCurrStatus>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClaimUnDate></IndClaimUnDate>");
						//setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStage></IndCurrStage>");	
						//setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClouserDate></IndClouserDate>");
						sprintf(IndRelStatBuf,"<IndCurrStage>%s</IndCurrStage>",IndRelStat);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndRelStatBuf);
						
						if(Indrlzdate!=NULL)
						{
						sprintf(IndClouserDateBuf,"<IndClouserDate>%s</IndClouserDate>",Indrlzdate);
						setAddStr(buff_cnt,bufferedXmlStrOut,IndClouserDateBuf);
						}
						else
						{
							setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClouserDate></IndClouserDate>");
						}
					}
					else
					{
					tag_t	*tasks=NULL;
					tag_t	*WFcount_tasksObjs=NULL;
					int n_tasks=0;
					int WFcount=0;
					int WFcount_tasks=0;
					
					AOM_ask_value_tags(indTagObj, "fnd0StartedWorkflowTasks", &WFcount_tasks, &WFcount_tasksObjs);
					printf("\n fnd0StartedWorkflowTasks 1 Value == [%d]", WFcount_tasks);fflush(stdout);
					
					if (WFcount_tasks>0)  //fnd0StartedTasks
						{
							//IndWorkFlowFlag=1;
							for (WFcount=0; WFcount< WFcount_tasks; WFcount++)
							{
									tag_t WFcount_tasksObj= NULLTAG;
									char*			TaskName		= NULL;
									WFcount_tasksObj = WFcount_tasksObjs[WFcount];
									if( AOM_ask_value_string(WFcount_tasksObj,"object_name",&TaskName));
									printf("\n TaskName  == [%s]", TaskName);fflush(stdout);
									printf("\n IndRefNo 1 Value == [%s]", IndRefNo);fflush(stdout);
									if(tc_strcmp(TaskName, "ERC Indent Workflow") == 0)
									{
										continue;
										
									}
									else
									{
										IndWorkFlowFlag=1;
										char*			IndSignoffUser		= NULL;
										char*			IndSignoffUser1New		= NULL;
										char*			IndSignoffUser1		= NULL;
										char*			IndAppDate		= NULL;
										char*			IndStatus		= NULL;
										char*			IndStartDate		= NULL;
										char*			IndAssgName		= NULL;
										char*			IndAssgNameNew		= NULL;
										char*			IndPerfermer		= NULL;
										char*			Indtask_type		= NULL;
										
										char* IndFinalSignOffUser = (char *)MEM_alloc(200 * sizeof(char));;
										
										if( AOM_UIF_ask_value(WFcount_tasksObj,"awp0Reviewers",&IndSignoffUser1));
										printf("\n IndSignoffUser1 1 Value == [%s]", IndSignoffUser1);fflush(stdout);
										
										if(IndSignoffUser1 != NULL)IndSignoffUser1New = replaceWord(IndSignoffUser1, ",", " ");
										
										//fnd0Performer
										//task_type
										
										if( AOM_UIF_ask_value(WFcount_tasksObj,"fnd0Performer",&IndPerfermer));
										printf("\n IndPerfermer == [%s]", IndPerfermer);fflush(stdout);
										
										if( AOM_UIF_ask_value(WFcount_tasksObj,"task_type",&Indtask_type));
										printf("\n Indtask_type == [%s]", Indtask_type);fflush(stdout);
										
										
										if( AOM_ask_value_string(WFcount_tasksObj,"valid_signoffs",&IndSignoffUser));
										printf("\n IndSignoffUser 1 Value == [%s]", IndSignoffUser);fflush(stdout);
										
										//if( AOM_UIF_ask_value(WFcount_tasksObj,"fnd0EndDate",&IndAppDate));
										if( AOM_UIF_ask_value(WFcount_tasksObj,"last_mod_date",&IndAppDate));
										printf("\n IndAppDate 1 Value == [%s]", IndAppDate);fflush(stdout);
										
										//if( AOM_ask_value_string(WFcount_tasksObj,"fnd0Status",&IndStatus));
										if( AOM_ask_value_string(WFcount_tasksObj,"task_state",&IndStatus));
										printf("\n IndStatus 1 Value == [%s]", IndStatus);fflush(stdout);
										
										if( AOM_UIF_ask_value(WFcount_tasksObj,"fnd0StartDate",&IndStartDate));
										printf("\n TaskNIndStartDateame 1 Value == [%s]", IndStartDate);fflush(stdout);
										
										if( AOM_ask_value_string(WFcount_tasksObj,"current_name",&IndAssgName));
										printf("\n IndAssgName 1 Value == [%s]", IndAssgName);fflush(stdout);
										
										if(IndAssgName != NULL)IndAssgNameNew = replaceWord(IndAssgName, ",", " ");
									
										//valid_signoffs=Current Owner(Pending with Whom?
										
										//fnd0EndDate=Approval Date-->changed to last_mod_date
										//fnd0Status=Current Status of the Indent-->changed to task_state
										//fnd0StartDate=Claim/Unclaim Date
										//current_name=Current Stage of the Indent
										
										printf("\n TaskName 1 Value == [%s]", TaskName);fflush(stdout);
										//fprintf(DmlRelFile,"Current Owner(Pending with Whom?),Approval Date,Current Status of the Indent,Claim/Unclaim Date,Current Stage of the Indent,Closure Date,");fflush(DmlRelFile);
										//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,",IndSignoffUser1New,IndAppDate,IndStatus,IndStartDate,IndAssgName);fflush(DmlRelFile);
										sprintf(IndSignoffUser1NewBuf,"<IndCurrentOwner1>%s</IndCurrentOwner1>",IndSignoffUser1New);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndSignoffUser1NewBuf);
										
										sprintf(IndSignoffUser2NewBuf,"<IndCurrentOwner2>%s</IndCurrentOwner2>",IndPerfermer);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndSignoffUser2NewBuf);
										
										sprintf(IndAppDateBuf,"<IndAppDat>%s</IndAppDat>",IndAppDate);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndAppDateBuf);
										
										sprintf(IndStatusNewBuf,"<IndCurrStatus>%s</IndCurrStatus>",IndStatus);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndStatusNewBuf);
										
										sprintf(IndStartDateNewBuf,"<IndClaimUnDate>%s</IndClaimUnDate>",IndStartDate);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndStartDateNewBuf);
										
										sprintf(IndAssgNameNewBuf,"<IndCurrStage>%s</IndCurrStage>",IndAssgNameNew);
										setAddStr(buff_cnt,bufferedXmlStrOut,IndAssgNameNewBuf);
										
										//sprintf(IndSignoffUser1NewBuf,"<IndClouserDate>%s</IndClouserDate>",IndSignoffUser1New);
										//setAddStr(buff_cnt,bufferedXmlStrOut,IndSignoffUser1NewBuf);
										
										setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClouserDate></IndClouserDate>");
									}
							}
						}
					
					
					}
					if(IndWorkFlowFlag==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner1></IndCurrentOwner1>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner2></IndCurrentOwner2>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndAppDat></IndAppDat>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStatus></IndCurrStatus>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClaimUnDate></IndClaimUnDate>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStage></IndCurrStage>");	
						setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClouserDate></IndClouserDate>");	
					}
					
					tag_t           relation_type	= NULLTAG;
					int				secObj_count	= 0;
					tag_t           *secondary_list	= NULLTAG;
					tag_t           designObj		= NULLTAG;
					tag_t           relationObj		= NULLTAG;
					int IndPartFlag=0;
					CALLAPI(GRM_find_relation_type("T5ERCDtl", &relation_type));
					if(relation_type != NULLTAG)
						{
							CALLAPI(GRM_list_secondary_objects_only(indTagObj, relation_type, &secObj_count, &secondary_list));
							//fprintf(IndExecutioLog,"Design Revision Count with Indent :: %d\n",secObj_count);  fflush(IndExecutioLog);
							printf("\n No of Parts in indent==>%d\n",secObj_count);fflush(stdout);
							IndPartFlag=1;
							if(secObj_count > 0)
							{
								int j=0;
								
								for(j=0; j<secObj_count; j++)
								{
									IndPartFlag=1;
									designObj = secondary_list[j];
								
									CALLAPI(GRM_find_relation(indTagObj, designObj, relation_type, &relationObj));
									if (relationObj != NULLTAG)
									{
									
									char*			designRevision		= NULL;
									char*			designRevisionID		= NULL;
									char*			designRevisionDesc		= NULL;
									char*			indDesignQtySet		= NULL;
									char*			indDesignReqQtySet		= NULL;
									char*			indPartIndCategory		= NULL;
									char*			indt5ERIndIRAvl		= NULL;
									char*			indTRSOStatus		= NULL;
									char*			indSupplierName		= NULL;
									char*			indTkoStatus		= NULL;
									char*			indPartStatus		= NULL;
									char*			ind_ERCIndRemarkIndente		= NULL;
									char*			ind_ERCIndRemarkIndenteNew		= NULL;
									char*			indERCIndRemark		= NULL;
									char*			indERCIndRemarkNew		= NULL;
									char*			indRemarkForIndenticalPart		= NULL;
									char*			indRemarkForIndenticalPartNew		= NULL;
									char*			designRevisionDescNew		= NULL;
									char*			object_type			= NULL;
									
									CALLAPI(AOM_ask_value_string(designObj,"object_type",&object_type));
									printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
									if (tc_strcmp(object_type,"Design Revision")==0 || tc_strcmp(object_type,"T5_EE_PartRevision")==0 || tc_strcmp(object_type,"T5_ClrPartRevision")==0 )
									{
										
									CALLAPI(AOM_ask_value_string(designObj,"item_id",&designRevision));
									printf("\n Processing Part number ==>[%s]\n",designRevision);fflush(stdout);
									CALLAPI(AOM_ask_value_string(designObj,"current_revision_id",&designRevisionID));
									//CALLAPI(AOM_ask_value_int(designObj,"sequence_id",&designSeq));	
									CALLAPI(AOM_ask_value_string(designObj,"current_desc",&designRevisionDesc));	
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndQtySet",&indDesignQtySet));									
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndReqdSet",&indDesignReqQtySet));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_PartIndCategory",&indPartIndCategory));
									CALLAPI(AOM_ask_value_string(relationObj,"t5ERIndIRAvl",&indt5ERIndIRAvl));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_TRSOStatus",&indTRSOStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_SupplierName",&indSupplierName));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_TkoStatus",&indTkoStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5PartStatus",&indPartStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndRemarkIndentee",&ind_ERCIndRemarkIndente));
									CALLAPI(AOM_ask_value_string(relationObj,"t5ERCIndRemark",&indERCIndRemark));	
									CALLAPI(AOM_ask_value_string(relationObj,"t5_RemarkForIndenticalPart",&indRemarkForIndenticalPart));

									if(designRevisionDesc != NULL)designRevisionDescNew = replaceWord(designRevisionDesc, ",", " ");
									
									int	is = 0;
									while(indDesignQtySet[is]!='\0')
										{
											if(indDesignQtySet[is]==',' || indDesignQtySet[is]=='\n')
											{
												indDesignQtySet[is]=' ';
											}
											is++;
										}
										is = 0;
										while(indDesignReqQtySet[is]!='\0')
										{
											if(indDesignReqQtySet[is]==',' || indDesignReqQtySet[is]=='\n')
											{
												indDesignReqQtySet[is]=' ';
											}
											is++;
										}
										is = 0;
										while(indPartIndCategory[is]!='\0')
										{
											if(indPartIndCategory[is]==',' || indPartIndCategory[is]=='\n')
											{
												indPartIndCategory[is]=' ';
											}
											is++;
										}										
									is = 0;
									while(indt5ERIndIRAvl[is]!='\0')
										{
											if(indt5ERIndIRAvl[is]==',' || indt5ERIndIRAvl[is]=='\n')
											{
												indt5ERIndIRAvl[is]=' ';
											}
											is++;
										}
										is = 0;
									while(indTRSOStatus[is]!='\0')
										{
											if(indTRSOStatus[is]==',' || indTRSOStatus[is]=='\n')
											{
												indTRSOStatus[is]=' ';
											}
											is++;
										}
										is = 0;
									while(indSupplierName[is]!='\0')
										{
											if(indSupplierName[is]==',' || indSupplierName[is]=='\n')
											{
												indSupplierName[is]=' ';
											}
											is++;
										}
										is = 0;
									while(indTkoStatus[is]!='\0')
										{
											if(indTkoStatus[is]==',' || indTkoStatus[is]=='\n')
											{
												indTkoStatus[is]=' ';
											}
											is++;
										}
										is = 0;
									while(indPartStatus[is]!='\0')
										{
											if(indPartStatus[is]==',' || indPartStatus[is]=='\n')
											{
												indPartStatus[is]=' ';
											}
											is++;
										}
										is = 0;
										while(ind_ERCIndRemarkIndente[is]!='\0')
										{
											if(ind_ERCIndRemarkIndente[is]==',' || ind_ERCIndRemarkIndente[is]=='\n')
											{
												ind_ERCIndRemarkIndente[is]=' ';
											}
											is++;
										}
										is = 0;
										while(indERCIndRemark[is]!='\0')
										{
											if(indERCIndRemark[is]==',' || indERCIndRemark[is]=='\n')
											{
												indERCIndRemark[is]=' ';
											}
											is++;
										}
										is = 0;
										while(indRemarkForIndenticalPart[is]!='\0')
										{
											if(indRemarkForIndenticalPart[is]==',' || indRemarkForIndenticalPart[is]=='\n')
											{
												indRemarkForIndenticalPart[is]=' ';
											}
											is++;
										}
										
									if(designRevisionDescNew != NULL) STRNG_replace_str(designRevisionDescNew,"\\n"," ",&designRevisionDescNew);
									if(designRevisionDescNew != NULL) STRNG_replace_str(designRevisionDescNew,"<","(",&designRevisionDescNew);
									if(designRevisionDescNew != NULL) STRNG_replace_str(designRevisionDescNew,">",")",&designRevisionDescNew);
									removeNonAsciiChars(designRevisionDescNew);
									if(designRevisionDescNew != NULL) STRNG_replace_str(designRevisionDescNew,"&","&amp;",&designRevisionDescNew);
									
									if(indDesignQtySet != NULL) STRNG_replace_str(indDesignQtySet,"\\n"," ",&indDesignQtySet);
									if(indDesignQtySet != NULL) STRNG_replace_str(indDesignQtySet,"<","(",&indDesignQtySet);
									if(indDesignQtySet != NULL) STRNG_replace_str(indDesignQtySet,">",")",&indDesignQtySet);
									removeNonAsciiChars(indDesignQtySet);
									if(indDesignQtySet != NULL) STRNG_replace_str(indDesignQtySet,"&","&amp;",&indDesignQtySet);
									
									if(indDesignReqQtySet != NULL) STRNG_replace_str(indDesignReqQtySet,"\\n"," ",&indDesignReqQtySet);
									if(indDesignReqQtySet != NULL) STRNG_replace_str(indDesignReqQtySet,"<","(",&indDesignReqQtySet);
									if(indDesignReqQtySet != NULL) STRNG_replace_str(indDesignReqQtySet,">",")",&indDesignReqQtySet);
									removeNonAsciiChars(indDesignReqQtySet);
									if(indDesignReqQtySet != NULL) STRNG_replace_str(indDesignReqQtySet,"&","&amp;",&indDesignReqQtySet);
									
									if(indPartIndCategory != NULL) STRNG_replace_str(indPartIndCategory,"\\n"," ",&indPartIndCategory);
									if(indPartIndCategory != NULL) STRNG_replace_str(indPartIndCategory,"<","(",&indPartIndCategory);
									if(indPartIndCategory != NULL) STRNG_replace_str(indPartIndCategory,">",")",&indPartIndCategory);
									removeNonAsciiChars(indPartIndCategory);
									if(indPartIndCategory != NULL) STRNG_replace_str(indPartIndCategory,"&","&amp;",&indPartIndCategory);
									
									if(indt5ERIndIRAvl != NULL) STRNG_replace_str(indt5ERIndIRAvl,"\\n"," ",&indt5ERIndIRAvl);
									if(indt5ERIndIRAvl != NULL) STRNG_replace_str(indt5ERIndIRAvl,"<","(",&indt5ERIndIRAvl);
									if(indt5ERIndIRAvl != NULL) STRNG_replace_str(indt5ERIndIRAvl,">",")",&indt5ERIndIRAvl);
									removeNonAsciiChars(indt5ERIndIRAvl);
									if(indt5ERIndIRAvl != NULL) STRNG_replace_str(indt5ERIndIRAvl,"&","&amp;",&indt5ERIndIRAvl);
									
									if(indTRSOStatus != NULL) STRNG_replace_str(indTRSOStatus,"\\n"," ",&indTRSOStatus);
									if(indTRSOStatus != NULL) STRNG_replace_str(indTRSOStatus,"<","(",&indTRSOStatus);
									if(indTRSOStatus != NULL) STRNG_replace_str(indTRSOStatus,">",")",&indTRSOStatus);
									removeNonAsciiChars(indTRSOStatus);
									if(indTRSOStatus != NULL) STRNG_replace_str(indTRSOStatus,"&","&amp;",&indTRSOStatus);
									
									if(indSupplierName != NULL) STRNG_replace_str(indSupplierName,"\\n"," ",&indSupplierName);
									if(indSupplierName != NULL) STRNG_replace_str(indSupplierName,"<","(",&indSupplierName);
									if(indSupplierName != NULL) STRNG_replace_str(indSupplierName,">",")",&indSupplierName);
									removeNonAsciiChars(indSupplierName);
									if(indSupplierName != NULL) STRNG_replace_str(indSupplierName,"&","&amp;",&indSupplierName);
									
									
									if(indTkoStatus != NULL) STRNG_replace_str(indTkoStatus,"\\n"," ",&indTkoStatus);
									if(indTkoStatus != NULL) STRNG_replace_str(indTkoStatus,"<","(",&indTkoStatus);
									if(indTkoStatus != NULL) STRNG_replace_str(indTkoStatus,">",")",&indTkoStatus);
									removeNonAsciiChars(indTkoStatus);
									if(indTkoStatus != NULL) STRNG_replace_str(indTkoStatus,"&","&amp;",&indTkoStatus);
									
									if(indPartStatus != NULL) STRNG_replace_str(indPartStatus,"\\n"," ",&indPartStatus);
									if(indPartStatus != NULL) STRNG_replace_str(indPartStatus,"<","(",&indPartStatus);
									if(indPartStatus != NULL) STRNG_replace_str(indPartStatus,">",")",&indPartStatus);
									removeNonAsciiChars(indPartStatus);
									if(indPartStatus != NULL) STRNG_replace_str(indPartStatus,"&","&amp;",&indPartStatus);
									
									if(ind_ERCIndRemarkIndente != NULL) STRNG_replace_str(ind_ERCIndRemarkIndente,"\\n"," ",&ind_ERCIndRemarkIndente);
									if(ind_ERCIndRemarkIndente != NULL) STRNG_replace_str(ind_ERCIndRemarkIndente,"<","(",&ind_ERCIndRemarkIndente);
									if(ind_ERCIndRemarkIndente != NULL) STRNG_replace_str(ind_ERCIndRemarkIndente,">",")",&ind_ERCIndRemarkIndente);
									removeNonAsciiChars(ind_ERCIndRemarkIndente);
									if(ind_ERCIndRemarkIndente != NULL) STRNG_replace_str(ind_ERCIndRemarkIndente,"&","&amp;",&ind_ERCIndRemarkIndente);
									
									if(indERCIndRemark != NULL) STRNG_replace_str(indERCIndRemark,"\\n"," ",&indERCIndRemark);
									if(indERCIndRemark != NULL) STRNG_replace_str(indERCIndRemark,"<","(",&indERCIndRemark);
									if(indERCIndRemark != NULL) STRNG_replace_str(indERCIndRemark,">",")",&indERCIndRemark);
									removeNonAsciiChars(indERCIndRemark);
									if(indERCIndRemark != NULL) STRNG_replace_str(indERCIndRemark,"&","&amp;",&indERCIndRemark);
									
									if(indRemarkForIndenticalPart != NULL) STRNG_replace_str(indRemarkForIndenticalPart,"\\n"," ",&indRemarkForIndenticalPart);
									if(indRemarkForIndenticalPart != NULL) STRNG_replace_str(indRemarkForIndenticalPart,"<","(",&indRemarkForIndenticalPart);
									if(indRemarkForIndenticalPart != NULL) STRNG_replace_str(indRemarkForIndenticalPart,">",")",&indRemarkForIndenticalPart);
									removeNonAsciiChars(indRemarkForIndenticalPart);
									if(indRemarkForIndenticalPart != NULL) STRNG_replace_str(indRemarkForIndenticalPart,"&","&amp;",&indRemarkForIndenticalPart);
									
									char* designRevisionBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* designRevisionIDBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* designRevisionDescNewBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indDesignQtySetBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indDesignReqQtySetBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indPartIndCategoryBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indt5ERIndIRAvlBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indTRSOStatusBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indSupplierNameBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indTkoStatusBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indPartStatusBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* ind_ERCIndRemarkIndenteBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indERCIndRemarkBuf = (char *)MEM_alloc(200 * sizeof(char));;
									char* indRemarkForIndenticalPartBuf = (char *)MEM_alloc(200 * sizeof(char));;
									
									setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
									
									sprintf(designRevisionBuf,"<PartNo>%s</PartNo>",designRevision);
									setAddStr(buff_cnt,bufferedXmlStrOut,designRevisionBuf);
										
									sprintf(designRevisionIDBuf,"<PartRevSeq>%s</PartRevSeq>",designRevisionID);
									setAddStr(buff_cnt,bufferedXmlStrOut,designRevisionIDBuf);
									
									sprintf(designRevisionDescNewBuf,"<PartDesc>%s</PartDesc>",designRevisionDescNew);
									setAddStr(buff_cnt,bufferedXmlStrOut,designRevisionDescNewBuf);
									
									sprintf(indDesignQtySetBuf,"<PartQty>%s</PartQty>",indDesignQtySet);
									setAddStr(buff_cnt,bufferedXmlStrOut,indDesignQtySetBuf);
									
									sprintf(indDesignReqQtySetBuf,"<PartSet>%s</PartSet>",indDesignReqQtySet);
									setAddStr(buff_cnt,bufferedXmlStrOut,indDesignReqQtySetBuf);
									
									sprintf(indPartIndCategoryBuf,"<PartCat>%s</PartCat>",indPartIndCategory);
									setAddStr(buff_cnt,bufferedXmlStrOut,indPartIndCategoryBuf);
									
									sprintf(indt5ERIndIRAvlBuf,"<PartIRReq>%s</PartIRReq>",indt5ERIndIRAvl);
									setAddStr(buff_cnt,bufferedXmlStrOut,indt5ERIndIRAvlBuf);
									
									sprintf(indTRSOStatusBuf,"<PartTRSO>%s</PartTRSO>",indTRSOStatus);
									setAddStr(buff_cnt,bufferedXmlStrOut,indTRSOStatusBuf);
									
									sprintf(indSupplierNameBuf,"<PartSupp>%s</PartSupp>",indSupplierName);
									setAddStr(buff_cnt,bufferedXmlStrOut,indSupplierNameBuf);
									
									sprintf(indTkoStatusBuf,"<PartTKO>%s</PartTKO>",indTkoStatus);
									setAddStr(buff_cnt,bufferedXmlStrOut,indTkoStatusBuf);
									
									sprintf(indPartStatusBuf,"<PartDRStatus>%s</PartDRStatus>",indPartStatus);
									setAddStr(buff_cnt,bufferedXmlStrOut,indPartStatusBuf);
									
									sprintf(ind_ERCIndRemarkIndenteBuf,"<PartRemIndentee>%s</PartRemIndentee>",ind_ERCIndRemarkIndente);
									setAddStr(buff_cnt,bufferedXmlStrOut,ind_ERCIndRemarkIndenteBuf);
									
									sprintf(indERCIndRemarkBuf,"<PartRemIndenter>%s</PartRemIndenter>",indERCIndRemark);
									setAddStr(buff_cnt,bufferedXmlStrOut,indERCIndRemarkBuf);
									
									sprintf(indRemarkForIndenticalPartBuf,"<PartRem>%s</PartRem>",indRemarkForIndenticalPart);
									setAddStr(buff_cnt,bufferedXmlStrOut,indRemarkForIndenticalPartBuf);
									setAddStr(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
									}
								}
								
								}
							}
							else
							{
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartNo></PartNo>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRevSeq></PartRevSeq>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDesc></PartDesc>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartQty></PartQty>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSet></PartSet>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartCat></PartCat>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartIRReq></PartIRReq>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTRSO></PartTRSO>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSupp></PartSupp>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTKO></PartTKO>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDRStatus></PartDRStatus>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndentee></PartRemIndentee>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndenter></PartRemIndenter>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRem></PartRem>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
							}
						}
						if(IndPartFlag==0)
						{
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartNo></PartNo>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRevSeq></PartRevSeq>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDesc></PartDesc>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartQty></PartQty>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSet></PartSet>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartCat></PartCat>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartIRReq></PartIRReq>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTRSO></PartTRSO>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSupp></PartSupp>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTKO></PartTKO>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDRStatus></PartDRStatus>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndentee></PartRemIndentee>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndenter></PartRemIndenter>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRem></PartRem>");
								setAddStr(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
						}
		
					}
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"</IndDetails>");
				
				}
			
		}
		
		//setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
		//setAddStr(buff_cnt,bufferedXmlStrOut,"<IndDashBoardReport>");
		else{
			
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndDetails>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndNo></IndNo>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCreDate></IndCreDate>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndUserRefNo></IndUserRefNo>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndAgency></IndAgency>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndPrjCode></IndPrjCode>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndLstModDate></IndLstModDate>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndWbs></IndWbs>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndWbsDes></IndWbsDes>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndPrtCat></IndPrtCat>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndVCNo></IndVCNo>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndHeadPlg></IndHeadPlg>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner1></IndCurrentOwner1>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrentOwner2></IndCurrentOwner2>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndAppDat></IndAppDat>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStatus></IndCurrStatus>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClaimUnDate></IndClaimUnDate>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndCurrStage></IndCurrStage>");	
		setAddStr(buff_cnt,bufferedXmlStrOut,"<IndClouserDate></IndClouserDate>");				
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartNo></PartNo>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRevSeq></PartRevSeq>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDesc></PartDesc>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartQty></PartQty>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSet></PartSet>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartCat></PartCat>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartIRReq></PartIRReq>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTRSO></PartTRSO>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartSupp></PartSupp>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartTKO></PartTKO>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDRStatus></PartDRStatus>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndentee></PartRemIndentee>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRemIndenter></PartRemIndenter>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRem></PartRem>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"</IndDetails>");	
		}
		
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"</IndDashBoardReport>");

	printf("\n  Report Completed \n");fflush(stdout);
	
	
	return ifail;
}

int tmIndDashBoardReportServ(void *retValue)
{
	const char	*prog_name 	="tmIndDashBoardReportServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\n Start----tmIndDashBoardReportServ....\n");fflush(stdout);
	char* Datefrom = NULL;
	char* Dateto = NULL;
		
	//USERARG_get_string_argument(&releaseStatusStr);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	//print input parameters
	printf("\nDatefrom==>%s\nDateto==>%s\n",Datefrom,Dateto);fflush(stdout);
		
	//end print input parameters
	


	//CALLAPI(dmlReleaseBetweenDates_new(Datefrom,Dateto,releaseStatusStr,PlantDup, projlen, Project_code_ids, colmnLen, additional_attrs, Planner,&bufferedXmlStrOut,&buff_cnt));
	
	CALLAPI(executeIndDashBoardReportLogic( Datefrom, Dateto, &bufferedXmlStrOut, &buff_cnt ));
	
	
	int m =0;
	printf("\n FDJ Report Buff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	printf("\n Before returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

		printf(" After returning Value\n");fflush(stdout);	
		printf("\n End----tmIndDashBoardReportServ....\n");fflush(stdout);
	return ifail;
}

/*End -FDJ - CR-FY22-0049*/
extern int ERCIndentFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	

	
	//Start - FDJ Status Report Service
	
	int n_args2 = 2;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args2 * sizeof(int));
	
	input_arg_type2[0]=USERARG_STRING_TYPE;//From Date
	input_arg_type2[1]=USERARG_STRING_TYPE;//To Date 
	ret_value_type2 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	//printf("\n FDJ: Status creation services start: Before registering tmIndDashBoardReportServ userservice...");  
	ifail=USERSERVICE_register_method("tmIndDashBoardReportServ",(USER_function_t)tmIndDashBoardReportServ,n_args2,input_arg_type2,ret_value_type2);
		
	//End FDJ Status Report Service
	
	
	return ifail;
}

extern int tm_ERCIndent_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
   //Define Rule/Action handler here

	
    return ifail;
}



extern DLLAPI int tm_ERCIndent_register_callbacks ()
{	
    int ifail    = ITK_ok;
	//printf("\ntm_ERCIndent_register_callbacks:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_ERCIndent", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_ERCIndent_register_method);
	//printf("\ntm_ERCIndent_register_callbacks: After registoring....");
	
	//printf("\n Started- Registering user service function ERCIndentFn...");
	ifail=CUSTOM_register_exit ( "tm_ERCIndent", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)ERCIndentFn);//user service not use
	//printf("\n Completed- Registering user service function ERCIndentFn...");
	
  return ( ITK_ok );
}

