/*******************
*  File            :   tm_StdSgnofExcpRpt.c
*  Created By      :   Vijay Khandare
*  Created On      :   11-09-2024
*  Purpose         :   STDSI Exception report....
*  TZ			   :   
*******************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdbool.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define MAX_SIZE 10000
#define STRING_LENGTH 50

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;
int         TotalbomCnt        = 0;

void setofTagList(int *count,tag_t **objlist,tag_t obj )
{
	char* childItemName =NULL;
	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	//printf("\n Number Count : [%d]",*count);fflush(stdout);
	(*objlist)[*count-1] = obj; 
	ITKCALL(AOM_ask_value_string((*objlist)[*count-1],"bl_item_item_id",&childItemName));
}
char     CommonPrtUnq[MAX_SIZE][STRING_LENGTH];
bool isStringAlreadyCpyUnqPrt(char targetStrings[][STRING_LENGTH], int targetCount, char *str)
{
        int  i = 0;
    for(i = 0; i < targetCount; i++)
    {
        if(strcmp(targetStrings[i], str) == 0)
        {
            return true;
        }
    }
    return false;
}

void ExcpStrCat(char **src,char* dest)
{
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

int tmGetChild(tag_t ChildTag,char *RevisionRule,char *ClosureRule,int MaxLevel,tag_t** SetofChildobj,int* CIndex)
{

	int 	counter 		= 0;
	int 	subcounter 		= 0;
	char* 	blLevel			= 0;
	int 	Curlevel		= 0;
	int 	FinLevel		= MaxLevel;// level of expansion
	tag_t*  subChild		=NULLTAG;
	ITKCALL(AOM_UIF_ask_value(ChildTag,"bl_level_starting_0",&blLevel));//
	Curlevel = atoi(blLevel);
    //printf("\n blLevel of Expension  = %d\n",Curlevel);
	setofTagList(CIndex,&*SetofChildobj,ChildTag);
	
	if(Curlevel < FinLevel)
	{  
	    tag_t      NewWindow             = NULLTAG;
	    tag_t      RevRuleTag            = NULLTAG;
	    tag_t*     ClosureRulSet         = NULLTAG;
	    tag_t      ClosureRulObj         = NULLTAG;
	    tag_t      ParentBOMLine         = NULLTAG;
	    tag_t*      SetChildParts        = NULLTAG;
	    int        NoOfClsureRuls        = 0;
	    int        NoOfChilds            = 0;
		
        ITK_CALL(BOM_create_window(&NewWindow));
	    ITK_CALL(CFM_find(RevisionRule,&RevRuleTag));
	    ITK_CALL(BOM_set_window_config_rule(NewWindow,RevRuleTag));
	    //ITK_CALL(PIE_find_closure_rules(ClosureRule,PIE_TEAMCENTER,&NoOfClsureRuls,&ClosureRulSet));
		//Deprecated api changed.......
		ITK_CALL(PIE_find_closure_rules2(ClosureRule,PIE_TEAMCENTER,&NoOfClsureRuls,&ClosureRulSet));
		//.............................
		
		if(NoOfClsureRuls > 0)
        {
            ClosureRulObj = ClosureRulSet[0];
		    ITKCALL(BOM_line_ask_all_child_lines(ChildTag,&counter,&subChild));
		    if(counter > 0)
		    {
		    	for(subcounter=0;subcounter<counter;subcounter++)
		    	{
					tag_t       subChildTag		 = NULLTAG;
					char        *RulCnfigBy      = NULL;
					char        *BmLineQty       = NULL;
					
		    		TotalbomCnt++;
					
		    		subChildTag = subChild[subcounter];
					ITK_CALL(AOM_UIF_ask_value(subChildTag,"bl_config_string",&RulCnfigBy));
					
	                //printf("\n RulCnfigBy status is.... = %s\n",RulCnfigBy);
				    ITK_CALL(AOM_ask_value_string(subChildTag,"bl_quantity",&BmLineQty));
				    printf("BmLineQty is... = %s\n",BmLineQty);fflush(stdout);
					
					if(tc_strcmp(RulCnfigBy,"No configured Revision") == 0 && tc_strcmp(BmLineQty,"0") != 0)
					{
						
		    		    tmGetChild(subChildTag,RevisionRule,ClosureRule,MaxLevel,SetofChildobj,CIndex);
					}
		    	}
		    }
	    }
	}
	
}

int tm_BomExpandS(tag_t ParentPart,char *RevisionRule,char *ClosureRule,int MaxLevel,tag_t **ChildPrtSet,int *ChildPrtIdx)
{
	printf ("Inside tm_BomExpand function... \n");fflush(stdout);
	
	int level2 = 99;

	tag_t      NewWindow             = NULLTAG;
	tag_t      RevRuleTag            = NULLTAG;
	tag_t*     ClosureRulSet         = NULLTAG;
	tag_t      ClosureRulObj         = NULLTAG;
	tag_t      ParentBOMLine         = NULLTAG;
	tag_t*      SetChildParts        = NULLTAG;
	int        NoOfClsureRuls        = 0;
	int        NoOfChilds            = 0;
	
    ITK_CALL(BOM_create_window(&NewWindow));
	
	ITK_CALL(CFM_find(RevisionRule,&RevRuleTag));
	ITK_CALL(BOM_set_window_config_rule(NewWindow,RevRuleTag));
	//ITK_CALL(PIE_find_closure_rules(ClosureRule,PIE_TEAMCENTER,&NoOfClsureRuls,&ClosureRulSet));
	
    //Deprecated api changed.......
    ITK_CALL(PIE_find_closure_rules2(ClosureRule,PIE_TEAMCENTER,&NoOfClsureRuls,&ClosureRulSet));
    //.............................
	
	if(NoOfClsureRuls > 0)
    {
        ClosureRulObj = ClosureRulSet[0];
		
        printf("closure rule found \n");fflush(stdout);
		
		ITK_CALL(BOM_window_set_closure_rule(NewWindow,ClosureRulObj,0,NULL,NULL));
		ITK_CALL(BOM_set_window_top_line(NewWindow,NULLTAG,ParentPart,NULLTAG,&ParentBOMLine));
		ITK_CALL(BOM_line_ask_all_child_lines(ParentBOMLine,&NoOfChilds,&SetChildParts));
		
		printf ("Number of child found is ...... = %d\n",NoOfChilds);fflush(stdout);
		
		if(NoOfChilds > 0)
        {
			int         ChildPrtItr       = 0;
			tag_t       ChildPartObj      = NULLTAG;
			for(ChildPrtItr = 0; ChildPrtItr < NoOfChilds; ChildPrtItr++)
			{
				char*        RuleConfigBy      = NULL;
				char*        BomLineName       = NULL;
				char*        BomLineQty        = NULL;
				tag_t        *PartRevSet       = NULLTAG;
				
				int          NoofRevs          = 0;
				
				ChildPartObj = SetChildParts[ChildPrtItr];
				
				ITK_CALL(AOM_UIF_ask_value(ChildPartObj,"bl_config_string",&RuleConfigBy));
	            //printf("\n RuleConfigBy status is.... = %s\n",RuleConfigBy);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(ChildPartObj,"bl_quantity",&BomLineQty));
				//printf("BomLineQty is... = %s\n",BomLineQty);fflush(stdout);
				
				ITK_CALL(AOM_UIF_ask_value(ChildPartObj,"bl_line_name",&BomLineName));
	            //printf("\n BomLineName status is.... = %s\n",BomLineName);fflush(stdout);
				
				if(tc_strcmp(RuleConfigBy,"No configured Revision") == 0 && tc_strcmp(BomLineQty,"0") != 0)
				{
					//printf("BomLineName is.... = %s\n",BomLineName);fflush(stdout);
					
					setofTagList(ChildPrtIdx,&*ChildPrtSet,ChildPartObj);
					
					TotalbomCnt++;

					tmGetChild(ChildPartObj,RevisionRule,ClosureRule,MaxLevel,ChildPrtSet,ChildPrtIdx);
				}
			}
			
		}
    }
	else
    {
        printf ("closure rule not found \n");fflush(stdout);
    }

	return ITK_ok;
}

int tm_StdSgnofExcpRptFun(char *TaskNum,char **OuptString)
{
	printf("Inside the function tm_StdSgnofExcpRptFun......\n");fflush(stdout);
	printf("Input Task number is.... = %s \n",TaskNum);fflush(stdout);
	
	tag_t       TskQryTag          = NULLTAG;
	tag_t       *ChildPrtSet       = NULLTAG;
	int         ChildPrtIdx        = 0;
	char        *PlantRlzSt        = NULL;
	char        *BlPlantRlzSt      = NULL;
	char        *BlSTDRlz          = NULL;
	char        *APLRlzSt          = NULL;
	char        *RevisionRule      = NULL;
	char        *ClosureRule       = NULL;
	char        *TskAPLPlnt        = NULL;
	char        *TskSTDPlnt        = NULL;
	char        *LevelIn           = NULL;
	
    int          UnqPart           = 0;
	
	
	PlantRlzSt=(char *) MEM_alloc(30 * sizeof(char*));
	BlPlantRlzSt=(char *) MEM_alloc(30 * sizeof(char*));
	BlSTDRlz=(char *) MEM_alloc(30 * sizeof(char*));
	APLRlzSt=(char *) MEM_alloc(30 * sizeof(char*));

	RevisionRule = (char*) MEM_alloc(30 * sizeof(char *));
	ClosureRule = (char*) MEM_alloc(30 * sizeof(char *));
	TskAPLPlnt = (char*) MEM_alloc(30 * sizeof(char *));
	TskSTDPlnt = (char*) MEM_alloc(30 * sizeof(char *));
	LevelIn = (char*) MEM_alloc(10 * sizeof(char *));
	
	tc_strcpy(LevelIn,"99");

	int MaxLevel = atoi(LevelIn);
	
	if(tc_strstr(TaskNum,"STDJ") || tc_strstr(TaskNum,"APLJ"))
	{
		tc_strcpy(PlantRlzSt,"STDSIJ Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDjWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdjRlzd");
		tc_strcpy(APLRlzSt,"APLJ Released");
		tc_strcpy(RevisionRule,"STDJ Released and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDJ");
        tc_strcpy(TskAPLPlnt,"APLJ");
        tc_strcpy(TskSTDPlnt,"STDJ");
	}
	else if(tc_strstr(TaskNum,"STDP") || tc_strstr(TaskNum,"APLP"))
	{
		tc_strcpy(PlantRlzSt,"STDSIP Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDpWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdpRlzd");
		tc_strcpy(APLRlzSt,"APLP Released");
		tc_strcpy(RevisionRule,"STDP Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDP");
		tc_strcpy(TskAPLPlnt,"APLP");
        tc_strcpy(TskSTDPlnt,"STDP");
	}
	else if(tc_strstr(TaskNum,"STDU") || tc_strstr(TaskNum,"APLU"))
	{
		tc_strcpy(PlantRlzSt,"STDSIU Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDuWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStduRlzd");
		tc_strcpy(APLRlzSt,"APLU Released");
		tc_strcpy(RevisionRule,"STDU Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDU");
		tc_strcpy(TskAPLPlnt,"APLU");
        tc_strcpy(TskSTDPlnt,"STDU");
	}
	else if(tc_strstr(TaskNum,"STDL") || tc_strstr(TaskNum,"APLL"))
	{
		tc_strcpy(PlantRlzSt,"STDSIL Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDlWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdlRlzd");
		tc_strcpy(APLRlzSt,"APLL Released");
		tc_strcpy(RevisionRule,"STDL Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDL");
		tc_strcpy(TskAPLPlnt,"APLL");
        tc_strcpy(TskSTDPlnt,"STDL");
	}
	else if(tc_strstr(TaskNum,"STDD") || tc_strstr(TaskNum,"APLD"))
	{
		tc_strcpy(PlantRlzSt,"STDSID Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDdWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStddRlzd");
		tc_strcpy(APLRlzSt,"APLD Released");
		tc_strcpy(RevisionRule,"STDD Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDD");
		tc_strcpy(TskAPLPlnt,"APLD");
        tc_strcpy(TskSTDPlnt,"STDD");
	}
	else if(tc_strstr(TaskNum,"STDS") || tc_strstr(TaskNum,"APLS"))
	{
		tc_strcpy(PlantRlzSt,"STDSIS Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDsWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdsRlzd");
		tc_strcpy(APLRlzSt,"APLS Released");
		tc_strcpy(RevisionRule,"STDS Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDS");
		tc_strcpy(TskAPLPlnt,"APLS");
        tc_strcpy(TskSTDPlnt,"STDS");
	}
	else if(tc_strstr(TaskNum,"STDA") || tc_strstr(TaskNum,"APLA"))
	{
		tc_strcpy(PlantRlzSt,"STDSIA Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDaWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdaRlzd");
		tc_strcpy(APLRlzSt,"APLA Released");
		tc_strcpy(RevisionRule,"STDA Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDA");
		tc_strcpy(TskAPLPlnt,"APLA");
        tc_strcpy(TskSTDPlnt,"STDA");
	}
	else if(tc_strstr(TaskNum,"STDC") || tc_strstr(TaskNum,"APLC"))
	{
		tc_strcpy(PlantRlzSt,"STDSIC Working");
		tc_strcpy(BlPlantRlzSt,"T5_LcsSTDcWrkg");
		tc_strcpy(BlSTDRlz,"T5_LcsStdcRlzd");
		tc_strcpy(APLRlzSt,"APLC Released");
		tc_strcpy(RevisionRule,"STDC Working and Above");
        tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDC");
		tc_strcpy(TskAPLPlnt,"APLC");
        tc_strcpy(TskSTDPlnt,"STDC");
	}
	else
	{
		printf("Task number not correct ......\n");fflush(stdout);
	}
	printf("Release status of plant is  = %s\n",PlantRlzSt);fflush(stdout);

	if(QRY_find2("Item Revision...", &TskQryTag));
	if(TskQryTag != NULLTAG)
	{
		printf("query found.... \n");fflush(stdout);
	    int         TskCnt              = 0;
	    tag_t       *TskSet             = NULLTAG;


		char 		*TskEntry[1] 	= 	{"Item ID"};
	    char 		**Tskvalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
	
	    Tskvalues[0]				=	TaskNum;
		
		if(QRY_execute(TskQryTag,1,TskEntry,Tskvalues,&TskCnt,&TskSet));

		if(TskCnt > 0)
	    {
	    	printf("\nTask found ......  :%d\n",TskCnt);fflush(stdout);
			
            tag_t	     TaskObj           = NULLTAG;
            tag_t	     PartRelation      = NULLTAG;
            tag_t	     *PartSet          = NULLTAG;
			char         *TaskName         = NULL;
			char         *TaskRlzst        = NULL;
			int          NoOfParts         = 0;
			int          Serial            = 0;
			char         *StrSrNo          = NULL;
			
			StrSrNo = (char*) MEM_alloc(100 * sizeof(char *));
			
			
			TaskObj = TskSet[0];

			ITK_CALL(AOM_UIF_ask_value(TaskObj,"item_id",&TaskName));
	        printf("Task Name is ..... = %s\n",TaskName);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(TaskObj,"release_status_list",&TaskRlzst));
			printf("Task Release status is ..... = %s\n",TaskRlzst);fflush(stdout);
			
		    ExcpStrCat(OuptString,"\n=============================================================================,=====================\n");
	        ExcpStrCat(OuptString,"List of dependend child parts needs  to be released from STDS to release the task,");
	        ExcpStrCat(OuptString,TaskName);
	        ExcpStrCat(OuptString,"\n===============================================================================,=====================\n");
	        ExcpStrCat(OuptString,"\n==================,=================,======,==============\n");
	        ExcpStrCat(OuptString,"Sr No.,Part No,Rev/Seq,DML\n");
	        ExcpStrCat(OuptString,"==================,=================,======,==============\n");
			
			if(tc_strstr(TaskName,"MBOM"))
			{
				printf("Skiping because task is MBOM \n");fflush(stdout);
			}
			else
			{
				if(tc_strstr(TaskRlzst,PlantRlzSt) != NULL)
			    {
					printf("Inside required task....!\n");fflush(stdout);
					
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&PartRelation));
	    	        ITK_CALL(GRM_list_secondary_objects_only(TaskObj,PartRelation,&NoOfParts,&PartSet));
					
					if(NoOfParts > 0)
	                {
						int PartItr = 0;
	    	    	    for(PartItr = 0; PartItr < NoOfParts;PartItr++)
	    	    	    {
							tag_t       PartObj      = NULLTAG;
							char        *PartNum     = NULL;
							
							PartObj = PartSet[PartItr];
							
							ITK_CALL(AOM_ask_value_string(PartObj,"item_id",&PartNum));
	                        printf("Part number is... = %s\n",PartNum);fflush(stdout);
							tm_BomExpandS(PartObj,RevisionRule,ClosureRule,MaxLevel,&ChildPrtSet,&ChildPrtIdx);
							
							printf ("Total required bom of [%s] is .... = %d\n",PartNum,ChildPrtIdx);fflush(stdout);
							
							printf ("TotalBom is ... %d\n",TotalbomCnt);fflush(stdout);
							
						    int FPrtItr = 0;
	    	    	        for(FPrtItr = 0; FPrtItr < ChildPrtIdx;FPrtItr++)
	    	    	        {
						    	tag_t       FCldBomlnobj      = NULLTAG;
						    	tag_t       FCldPrtObj        = NULLTAG;
						    	char        *FPartNum         = NULL;
						    	char        *FPrtRevseq       = NULL;
						    	char        *FPrtRlzst        = NULL;
								
								FCldBomlnobj = ChildPrtSet[FPrtItr];
						    	ITK_CALL(AOM_ask_value_string(FCldBomlnobj,"bl_line_name",&FPartNum));
						    	ITK_CALL(AOM_ask_value_string(FCldBomlnobj,"item_revision_id",&FPrtRevseq));
						    	ITK_CALL(AOM_ask_value_string(FCldBomlnobj,"bl_rev_release_status_list",&FPrtRlzst));
								
								//printf("Part number is ... [%s  %s  %s]\n",FPartNum,FPrtRevseq,FPrtRlzst);fflush(stdout);

								printf("Part number is ... [%s  %s  %s]\n",FPartNum,FPrtRevseq,FPrtRlzst);fflush(stdout);
								
								char        *UnConfigPrtNO         = NULL;
								tag_t       ExcpPartObj            = NULLTAG;
								tag_t       *ExcpPrtRevSet         = NULLTAG;
								int         AllRevCnt              = 0;
								
								ITK_CALL(AOM_ask_value_string(FCldBomlnobj,"bl_item_item_id",&UnConfigPrtNO));
								//printf("UnConfigPrtNO is... = %s\n",UnConfigPrtNO);fflush(stdout);
								
								printf("UnConfigPrtNO is... = %s\n",UnConfigPrtNO);fflush(stdout);
								ITK_CALL(ITEM_find_item(UnConfigPrtNO,&ExcpPartObj));
								
								if(ExcpPartObj != NULLTAG)
								{

									int         TaskCntFlag         = 0;
									ITK_CALL(ITEM_list_all_revs(ExcpPartObj,&AllRevCnt,&ExcpPrtRevSet));
									if(AllRevCnt > 0)
									{
										int ExpItr = 0;
										for(ExpItr = 0; ExpItr < AllRevCnt;ExpItr++)
										{
											tag_t       ExcpPrtRevObj       = NULLTAG;
											tag_t       relation_type       = NULLTAG;
											tag_t       *ExpPrtTaskSet          = NULLTAG;
											char        *ExpPartNum         = NULL;
						    	            char        *ExpPrtRevseq       = NULL;
						    	            char        *EXpPrtRlzst        = NULL;
											int         TaskCnt             = 0;

											ExcpPrtRevObj = ExcpPrtRevSet[ExpItr];
											
											//ITK_CALL(AOM_ask_value_string(ExcpPrtRevObj,"bl_item_item_id",&UnConfigPrtNO));
								            //printf("UnConfigPrtNO is... = %s\n",UnConfigPrtNO);fflush(stdout);
											
											ITK_CALL(AOM_ask_value_string(ExcpPrtRevObj,"item_id",&ExpPartNum));
								            ITK_CALL(AOM_ask_value_string(ExcpPrtRevObj,"item_revision_id",&ExpPrtRevseq));
								            ITK_CALL(AOM_UIF_ask_value(ExcpPrtRevObj,"release_status_list",&EXpPrtRlzst));
								            
				                            //printf("Exception Part number is ... [%s  %s  %s]\n",ExpPartNum,ExpPrtRevseq,EXpPrtRlzst);fflush(stdout);

											//printf("Exception Part number is ... [%s  %s]\n",ExpPartNum,ExpPrtRevseq);fflush(stdout);
											printf("Exception Part number is ... [%s  %s  %s]\n",ExpPartNum,ExpPrtRevseq,EXpPrtRlzst);fflush(stdout);
											
											ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						                    ITKCALL(GRM_list_primary_objects_only(ExcpPrtRevObj,relation_type,&TaskCnt,&ExpPrtTaskSet));
											
											if(TaskCnt > 0)
											{
												TaskCntFlag++;
											    int ExpTskItr = 0;
										        for(ExpTskItr = 0; ExpTskItr < TaskCnt;ExpTskItr++)
											    {
											    	tag_t       ExpTskObj           = NULLTAG;
											    	char        *ExpTskNo           = NULL;
											    	ExpTskObj = ExpPrtTaskSet[ExpTskItr];
											    	
											    	ITK_CALL(AOM_ask_value_string(ExpTskObj,"item_id",&ExpTskNo));
											    	printf("Exception Task number is ... [%s]\n",ExpTskNo);fflush(stdout);
											    
								                    if((tc_strstr(ExpTskNo,TskAPLPlnt) != NULL) || (tc_strstr(ExpTskNo,TskSTDPlnt) != NULL))
											        {
											    		if(!isStringAlreadyCpyUnqPrt(CommonPrtUnq, UnqPart, ExpPartNum)) 
                                                        {
					                                        strcpy(CommonPrtUnq[UnqPart++],ExpPartNum);
															
															Serial++;
															sprintf(StrSrNo, "%d", Serial);
															
															ExcpStrCat(OuptString,StrSrNo);
											    	        ExcpStrCat(OuptString,",");
                                                            ExcpStrCat(OuptString,ExpPartNum);
								                            ExcpStrCat(OuptString,",");
                                                            ExcpStrCat(OuptString,ExpPrtRevseq);
								                            ExcpStrCat(OuptString,",");
                                                            ExcpStrCat(OuptString,ExpTskNo);
								                            ExcpStrCat(OuptString,"\n");
											    		}
											    	}
											    }
											}
										}
									}
									if(TaskCntFlag == 0)
									{
										tag_t       LtestRevObj        = NULLTAG;
										char        *ExpLPrtNO         = NULL;
										char        *ExpLPrtRevSeq     = NULL;
										ITK_CALL(ITEM_ask_latest_rev(ExcpPartObj,&LtestRevObj));
										
										ITK_CALL(AOM_ask_value_string(LtestRevObj,"item_id",&ExpLPrtNO));
								        ITK_CALL(AOM_ask_value_string(LtestRevObj,"item_revision_id",&ExpLPrtRevSeq));
										
										if(!isStringAlreadyCpyUnqPrt(CommonPrtUnq, UnqPart, ExpLPrtNO)) 
                                        {
					                        strcpy(CommonPrtUnq[UnqPart++],ExpLPrtNO);
											
											Serial++;
											sprintf(StrSrNo, "%d", Serial);
											
											ExcpStrCat(OuptString,StrSrNo);

										    ExcpStrCat(OuptString,",");
                                            ExcpStrCat(OuptString,ExpLPrtNO);
								            ExcpStrCat(OuptString,",");
                                            ExcpStrCat(OuptString,ExpLPrtRevSeq);
								            ExcpStrCat(OuptString,",");
                                            ExcpStrCat(OuptString,"NA");
								            ExcpStrCat(OuptString,"\n");
										}
									}
								}
						    }	
						}
					}
				}
				else
				{
					printf("Task is not STDSI working ....!\n");fflush(stdout);
				}
			}
	    }
		else
		{
			printf("Task not found\n");fflush(stdout);
		}
		ExcpStrCat(OuptString,"\n");
		ExcpStrCat(OuptString,"********,************,END OF THE REPORT");

	}
}

int STDSIExcpReport(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	char     *TaskNumber         = NULL;
	char     *OuptString			 = NULL;
	
	OuptString = (char *) MEM_alloc(100000 * sizeof(char*) );

	printf("\n inside the function STDSIExcpReport .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&TaskNumber);

	printf("Input Task Name is ... = %s\n",TaskNumber);fflush(stdout);

	//..........................................................
	
	tc_strcpy(OuptString,"");

	tm_StdSgnofExcpRptFun(TaskNumber,&OuptString);
	
	printf("\n before return data....!\n");fflush(stdout);

	*((char **) return_data) = (char *) MEM_alloc( (strlen(OuptString) + 1) * sizeof(char));
    strcpy( *((char **) return_data),OuptString);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(OuptString);

	printf("\n After free...!\n");fflush(stdout);
    return ifail;
}

extern int AllUserServiceFnSTDPrtExpFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 1;
    int retValueType;
    int inputArgTypes[1] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //Task Number

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("STDSIExcpReport",(USER_function_t)STDSIExcpReport,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_StdSgnofExcpRpt_register_callbacks ()
{

    int ifail    = ITK_ok;

    ifail = CUSTOM_register_exit("tm_StdSgnofExcpRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnSTDPrtExpFn);
    return ifail;
}