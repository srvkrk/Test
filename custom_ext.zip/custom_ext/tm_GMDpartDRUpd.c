/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler to update latest released revisin of parts attached to GMD.
*  Code                 :   tm_GMDpartDRUpd.c
*  Created on			:   12/04/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		12/04/2019				Mohan Tayade		Workflow Action Handler to update latest released revisin of parts attached to GMD.
*	2.		08/05/2019				Mohan Tayade		Handle DR3P/AR3P.
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_GMDpartDRUpd(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n GMDUPD:tm_GMDpartDRUpd Function started...");fflush(stdout);
	TC_write_syslog("\n tm_GMDpartDRUpd Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n GMDUPD:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n GMDUPD: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n GMDUPD:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n GMDUPD:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "POCHCK";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n GMDUPD:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n GMDUPD:POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
					if(strstr(POinfo3,"GMDUPDVALOFF")==NULL)
					{
						if(strstr(POinfo3,"GMDUPDVALIUAPROD")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n UAPROD:DML no : %s ", DMlid);fflush(stdout);
							//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/prtdrupd.sh %s ",DMlid);
							sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/prtdrupd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"GMDUPDVALICVPROD")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n CVPROD:DML no : %s ", DMlid);fflush(stdout);
							//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/prtdrupd.sh %s ",DMlid);
							sprintf(command,"/user/cvprod/shells/DML_DCR/prtdrupd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"GMDUPDVALICMITEST")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n CMITEST:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/prtdrupd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"GMDUPDVALIUADEV")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n UADEV:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/prtdrupd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else
						{
							printf("\n POCHCK:other client \n");fflush(stdout);
						}
					}
					else
					{
						printf("\n GMDUPD:Inside else for VCMS \n");fflush(stdout);
						if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
						printf("\n UAPROD:DML no : %s ", DMlid);fflush(stdout);
						//control logic:
						char *SystCommand		= NULL;
						char*   DInfo2= NULL;
						char*   DInfo1= NULL;
						tag_t   DqryTag		= NULLTAG;
						int     D_n_entry		= 1;
						int     D_rsltCount	= 0;
						char    *D_qry_entry[1]  = {"SYSCD"};
						tag_t   *DCntrlObjectTag   = NULLTAG;
						char    **D_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
						//Control object logic:
						if(QRY_find2("ControlObjects", &DqryTag));
						if (DqryTag)
						{
							printf("\n GMDUPD:RefDrw:Found Query ControlObjects \n");fflush(stdout);
						}
						else
						{
							printf("\n GMDUPD:RefDrw:Not Found Query ControlObjects \n");fflush(stdout);
						}

						D_qry_values2[0] = "GMDUPD";
						if(QRY_execute(DqryTag, D_n_entry, D_qry_entry, D_qry_values2, &D_rsltCount, &DCntrlObjectTag));
						printf(" \n GMDUPD:RefDrw:D_rsltCount:%d:", D_rsltCount); fflush(stdout);
						if(D_rsltCount > 0)
						{
							//On/OFF
							if (AOM_ask_value_string(DCntrlObjectTag[0],"t5_Userinfo1",&DInfo1)!=ITK_ok)   PrintErrorStack();
							printf("\n GMDUPD:DInfo1 is :[%s]\n", DInfo1);fflush(stdout);
							//Path
							if (AOM_ask_value_string(DCntrlObjectTag[0],"t5_Userinfo2",&DInfo2)!=ITK_ok)   PrintErrorStack();
							printf("\n GMDUPD:DInfo2 is :[%s]\n", DInfo2);fflush(stdout);
							if(strstr(DInfo1,"GMDUPD001")==NULL)
							{
								SystCommand = (char	*)MEM_alloc(1500);
								tc_strcpy(SystCommand,"");
								tc_strcpy(SystCommand,DInfo2);
								tc_strcat(SystCommand," ");
								tc_strcat(SystCommand,DMlid);
								tc_strcat(SystCommand," ");
								//tc_strcat(SystCommand,emailIDstr);
								//tc_strcat(SystCommand," ");
								printf("\n GMDUPD:SystCommand: %s \n",SystCommand);fflush(stdout);
								TC_write_syslog("SystCommand = %s\n",SystCommand);
								system(SystCommand);
								printf("\n GMDUPD:mail command done. \n");fflush(stdout);
							}
						}
					}
				}
			}
		}
	}

	printf("\n tm_GMDpartDRUpd Function end...");fflush(stdout);
	TC_write_syslog("\n tm_GMDpartDRUpd Function end...");
	//return error_code;
	return 0;
}