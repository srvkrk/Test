#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <sa/role.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <tc/tc.h>
#include <sa/sa.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <Fnd0Participant/participant.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <epm/epm_toolkit_tc_utils.h>



//#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(2000);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

int CheckSupportLogin(tag_t SessionUser_tag)
{
	int     ac    = 0;
	int     Accessflag    = 0;
	int     AccessCount    = 0;
	int     Support_rsltCount    = 0;
	int     Support_n_entry    = 1;
	tag_t	*SupportCntrlObjectTag	= NULLTAG;
	tag_t	SupportqryTag		= NULLTAG;
	char    *Support_qry_entry[1]  = {"SYSCD"};
	char    **Support_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*	 Supportinfo1 = NULL;
	char*	 Supportinfo2 = NULL;
	char*	 AccessFound_name = NULL;
	tag_t	AccessFound_tg = NULLTAG;
	tag_t	*AccessFound = NULLTAG;

	printf("\n CheckSupportLogin-->L1: CheckSupportLogin...\n");fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &SupportqryTag));
	if (SupportqryTag)
	{
		printf("\n CheckSupportLogin-->L2:Found Query SupportqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n CheckSupportLogin-->L3:Not Found Query SupportqryTag \n");fflush(stdout);
	}

	Support_qry_values2[0] = "SUPPORT";
	if(QRY_execute(SupportqryTag, Support_n_entry, Support_qry_entry, Support_qry_values2, &Support_rsltCount, &SupportCntrlObjectTag));
	printf(" \n CheckSupportLogin-->L4:DR_rsltCount :%d:", Support_rsltCount); fflush(stdout);
	if(Support_rsltCount > 0)
	{
		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo1",&Supportinfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckSupportLogin-->L5:Supportinfo1 is : [%s]\n", Supportinfo1);fflush(stdout);

		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo2",&Supportinfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckSupportLogin-->L6:Supportinfo2 is : [%s]\n", Supportinfo2);fflush(stdout);
		if(tc_strstr(Supportinfo1,"CHKLOGINOFF")==NULL)
		{
			//if (SA_find_groupmember_by_user(SessionUser_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
			if (SA_find_groupmember_by_user(SessionUser_tag,&AccessCount,&AccessFound)!=ITK_ok)PrintErrorStack();
			printf("\n CheckSupportLogin-->count of AccessCount: [%d]", AccessCount);fflush(stdout);
			for(ac=0;ac<AccessCount;ac++)
			{
				AccessFound_tg = AccessFound[ac];
				if (AOM_ask_value_string(AccessFound_tg,"object_name",&AccessFound_name)!=ITK_ok)   PrintErrorStack();
				//printf("\n CheckSupportLogin-->Actual Group Member AccessFound_name: [%s]", AccessFound_name);fflush(stdout);
				if((tc_strstr(AccessFound_name,Supportinfo1)!=NULL)|| (tc_strstr(AccessFound_name,Supportinfo2)!=NULL))
				{
					Accessflag++;
					printf("\n CheckSupportLogin-->AccessFound_name----: [%s][%d]", AccessFound_name,Accessflag);fflush(stdout);
					break;
				}
			}
			printf("\n CheckSupportLogin-->Accessflag: [%d] ",Accessflag);fflush(stdout);
			if(Accessflag >0)
			{
				printf("\n CheckSupportLogin-->L7: support access found.\n");fflush(stdout);
				return 1;
			}
			else
			{
				printf("\n CheckSupportLogin-->L8:support access not found. \n");fflush(stdout);
				return 0;
			}
		}
	}

	return 0;
}

int CreateDcrTask(tag_t DcrTag,char* Agg)
{
	char* DcrName=NULL;
	char* DcrTaskName=NULL;

	tag_t Dcr_tag_Rev=NULLTAG;
	tag_t Dcr_task_tag=NULLTAG;
	tag_t Dcr_task_tag_Rev=NULLTAG;
	tag_t* tags_found2=NULLTAG;

	int n_tags_found2=0;

	const char *attrs2[2];
	const char *values2[2];

	DcrTaskName = (char	*)MEM_alloc(200);

	if (AOM_ask_value_string(DcrTag,"item_id",&DcrName)!=ITK_ok);PrintErrorStack();
	ITEM_ask_latest_rev(DcrTag,&Dcr_tag_Rev);

	tc_strcpy(DcrTaskName,DcrName);
	tc_strcat(DcrTaskName,"_");
	tc_strcat(DcrTaskName,Agg);

	printf("\n CreateDcrTask-->Function DcrTaskName :%s ", DcrTaskName);fflush(stdout);

	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)DcrTaskName;
	values2[1] = "T5_DcrTask";

	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	printf("\n CreateDcrTask-->count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2==0)
	{
		int status=0;
		int number_of_types1=0;

		tag_t *type_tag3 = NULLTAG;

		tag_t object_create_input_tag3 = NULLTAG;
		tag_t value_tag_Rev = NULLTAG;

		ITK_CALL(TCTYPE_find_types_for_class("T5_DcrTask",&number_of_types1,&type_tag3));
		printf("\n CreateDcrTask-->number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

		ITK_CALL(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",DcrTaskName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",DcrTaskName));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",DcrTaskName));
		ITK_CALL(TCTYPE_create_object(object_create_input_tag3, &Dcr_task_tag));

		if(Dcr_task_tag != NULLTAG)
		{
			ITK_CALL(AOM_save_without_extensions(Dcr_task_tag));
			ITK_CALL(AOM_refresh(Dcr_task_tag,0));
			ITK_CALL(AOM_unlock(Dcr_task_tag));
			printf("\n CreateDcrTask-->1.DCR task is created......\n"); fflush(stdout);
		}

		ITEM_ask_latest_rev(Dcr_task_tag,&Dcr_task_tag_Rev);
		printf("\n CreateDcrTask-->2.DCR Task Revision is queried......\n");fflush(stdout);

		ITK_CALL(AOM_save_without_extensions(Dcr_task_tag_Rev));
		ITK_CALL(AOM_unlock(Dcr_task_tag_Rev));
	}
	else
	{
		printf("\n CreateDcrTask-->3.DCR task is already created found......\n"); fflush(stdout);

		Dcr_task_tag=tags_found2[0];
		ITEM_ask_latest_rev(Dcr_task_tag,&Dcr_task_tag_Rev);
	}

	if(Dcr_task_tag_Rev != NULLTAG)
	{
		tag_t rel_type_1 = NULLTAG;
		tag_t relation = NULLTAG;

		GRM_find_relation_type("T5_DMLTaskRelation",&rel_type_1);
		GRM_create_relation(Dcr_tag_Rev,Dcr_task_tag_Rev,rel_type_1, NULLTAG, &relation);
		printf("\n CreateDcrTask-->GRM_create_relation ");fflush(stdout);
		GRM_save_relation(relation);
		printf("\n CreateDcrTask-->GRM_save_relation --");fflush(stdout);
	}

	printf("\n CreateDcrTask-->Function process is completed");fflush(stdout);

	return 0;
}

char* getProgramProject(char* ProjCode)
{
	tag_t TagQryContObj = NULLTAG, *cntr_objects = NULLTAG;

	int	n_entries = 1;
	int n_found = 0;

	char* ProgName=NULL;

	char *qry_entries[1] = {"Name"};
	char *qry_values[1] = {ProjCode};

	if(QRY_find2("Prd_Project", &TagQryContObj));

	if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n getProgramProject-->Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

	if(n_found > 0)
	{
		if( AOM_ask_value_string(cntr_objects[0],"t5_Program",&ProgName));
		printf("\n getProgramProject-->ProgName Value == [%s]", ProgName);fflush(stdout);
	}

	return ProgName;
}
int AssignDcrParticipant(tag_t DcrTag,char* ProgNm,char* PartiType,char* roleName)
{
	int status = 0;
	int error_code = ITK_ok;
	int No_User = 0 , iii=0;

	tag_t* User_Tags= NULLTAG;
	tag_t groupName_tag= NULLTAG;
	tag_t DCR_Patri_Type= NULLTAG;
	tag_t roleName_tag= NULLTAG;
	tag_t DCR_Party =  NULLTAG;
	logical hasbypass =true;

	char *groupName = NULL;

	groupName = (char *)MEM_alloc(70);

	printf("\n AssignDcrParticipant-->PartiType Value == [%s]", PartiType);fflush(stdout);

	ITK_CALL(EPM_get_participanttype (PartiType,&DCR_Patri_Type));

	if (DCR_Patri_Type != NULLTAG)
	{
		printf("\n AssignDcrParticipant-->ProgNm Value == [%s]", ProgNm);fflush(stdout);

		tc_strcpy(groupName,ProgNm);
		tc_strcat(groupName,".");
		tc_strcat(groupName,"DCR");

		printf("\n AssignDcrParticipant-->groupName Value == [%s]", groupName);fflush(stdout);

		ITK_CALL(SA_find_group(groupName,&groupName_tag));
		ITK_CALL(SA_find_role2(roleName,&roleName_tag));
		ITK_CALL(SA_find_groupmember_by_role(roleName_tag,groupName_tag,&No_User,&User_Tags));
		printf("\n AssignDcrParticipant-->DCR No_User :[%d]",No_User);  fflush(stdout);

		if (No_User>0)
		{
			for(iii=0;iii<No_User;iii++)
			{
				ITK_CALL(EPM_create_participant(User_Tags[iii],DCR_Patri_Type,&DCR_Party));
				AOM_lock(DcrTag);
				ITK_CALL(PARTICIPANT_add_participant(DcrTag,hasbypass,DCR_Party));
				AOM_save_without_extensions(DcrTag);
				AOM_unlock(DcrTag);
			}
			//AOM_refresh ( DcrTag,TRUE);
		}
		//MEM_free(DCR_Patri_Type);
	}

	printf("\n AssignDcrParticipant-->Function process is completed \n");fflush(stdout);

	return 0;
}


int AssignDcrParticipantAQ(tag_t DcrTag,char* ProgNm,char* PartiType,char* roleName)
{
	int status = 0;
	int error_code = ITK_ok;
	int No_User = 0 , iii=0;

	tag_t* User_Tags= NULLTAG;
	tag_t groupName_tag= NULLTAG;
	tag_t DCR_Patri_Type= NULLTAG;
	tag_t roleName_tag= NULLTAG;
	tag_t DCR_Party =  NULLTAG;
	logical hasbypass =true;

	char *groupName = NULL;

	groupName = (char *)MEM_alloc(70);

	printf("\n AssignDcrParticipantAQ-->PartiType Value == [%s]", PartiType);fflush(stdout);

	ITK_CALL(EPM_get_participanttype (PartiType,&DCR_Patri_Type));

	if (DCR_Patri_Type != NULLTAG)
	{
		printf("\n AssignDcrParticipantAQ-->ProgNm Value == [%s]", ProgNm);fflush(stdout);

		tc_strcpy(groupName,ProgNm);
		tc_strcat(groupName,".");
		tc_strcat(groupName,"DCR");

		printf("\n AssignDcrParticipantAQ-->groupName Value == [%s]", groupName);fflush(stdout);

		ITK_CALL(SA_find_group(groupName,&groupName_tag));
		ITK_CALL(SA_find_role2(roleName,&roleName_tag));
		ITK_CALL(SA_find_groupmember_by_role(roleName_tag,groupName_tag,&No_User,&User_Tags));
		printf("\n AssignDcrParticipantAQ-->DCR No_User :[%d]",No_User);  fflush(stdout);

		if (No_User>0)
		{
			for(iii=0;iii<No_User;iii++)
			{
				ITK_CALL(EPM_create_participant(User_Tags[iii],DCR_Patri_Type,&DCR_Party));
				AOM_lock(DcrTag);
				ITK_CALL(PARTICIPANT_add_participant(DcrTag,hasbypass,DCR_Party));
				AOM_save_without_extensions(DcrTag);
				AOM_unlock(DcrTag);
			}
			//AOM_refresh ( DcrTag,TRUE);
		}
	    else 
	    {
			AssignDcrParticipant(DcrTag,ProgNm,"T5_DcrFUN_LEAD_AQ","Functional_Lead_AQ");
	    }

		//MEM_free(DCR_Patri_Type);
	}

	printf("\n AssignDcrParticipantAQ-->Function process is completed \n");fflush(stdout);

	return 0;
}

int GetStringCharacterCount_DCR(char* mainStringf)
{
	int i=0,alphabets=0,digits=0,special=0,space=0;

  	while ( *(mainStringf+i) != '\0')
  	{
  		if( (*(mainStringf+i) >= 'a' && *(mainStringf+i) <= 'z') || (*(mainStringf+i) >= 'A' && *(mainStringf+i) <= 'Z') )
  		{
  			alphabets++;
 		}
  		else if (*(mainStringf+i) >= '0' && *(mainStringf+i) <= '9')
  		{
  			digits++;
  		}
		else if ((*(mainStringf+i)=='`')||(*(mainStringf+i)=='~')||(*(mainStringf+i)=='!')||(*(mainStringf+i)=='@')||(*(mainStringf+i)=='#')||(*(mainStringf+i)=='$')||(*(mainStringf+i)=='%')||(*(mainStringf+i)=='^')||(*(mainStringf+i)=='&')||(*(mainStringf+i)=='*')|| (*(mainStringf+i)=='(')||(*(mainStringf+i)==')')||(*(mainStringf+i)=='=')||(*(mainStringf+i)=='[')||(*(mainStringf+i)==']')||(*(mainStringf+i)=='|'))
		{
			special++;
		}
  		else
		{
			printf("\nGetStringCharacterCount_DCR-->!!!!!!!!!!!!!!!!! GetSpecialCharacter-Count:::::::::NOT special..................\n");fflush(stdout);
		}
    	i++;
	}

	printf("\nGetStringCharacterCount_DCR-->!!!!!!!!!!!!!!!!! GetSpecialCharacter-Count:::::::::special[%d],[%d][%d][%d]\n",special,alphabets,digits,space);fflush(stdout);

	return alphabets+special;
	//return alphabets;
}


extern DLLAPI int methodGen3DcrRev_PreCond(METHOD_message_t *msg, va_list args)
{
	int status = 0;
	int ifail = 0;
	int n_entry = 1;
	int rsltCount = 0;
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	int	isNew = va_arg(args, int);

	char* DCR_reason = NULL;
	char* yrcmp = NULL;
	char* DCRinfo6 = NULL;
	char* DCRinfo7 = NULL;
	char* DCR_no = NULL;
	char* DCRproj = NULL;
	char* DCR_CostImpact = NULL;
	char* DCR_regulation = NULL;
	char *qry_entry[1]  = {"SYSCD"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t CObjTag = NULLTAG;
	tag_t *CtrObjTag = NULLTAG;
	
	if(QRY_find2("Control Objects...", &CObjTag));
	if (CObjTag)
	{
		printf("\n methodGen3DcrRev_PreCond-->L2:Found Query CObjTag \n");fflush(stdout);
	}
	else
	{
		printf("\n methodGen3DcrRev_PreCond-->L3:Not Found Query CObjTag \n");fflush(stdout);
	}
	printf("\n Starting methodGen3DcrRev_PreCond--------");fflush(stdout);
	CALLAPI(AOM_ask_value_string(objTag,"current_id",&DCR_no));
	printf("\n methodGen3DcrRev_PreCond-->DCR generated no: [%s] ",DCR_no);fflush(stdout);

	qry_values[0] = "DCRVali";
	if(QRY_execute(CObjTag, n_entry, qry_entry, qry_values, &rsltCount, &CtrObjTag));
	printf(" \n methodGen3DcrRev_PreCond-->L4:rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		if (AOM_ask_value_string(CtrObjTag[0],"t5_Userinfo6",&DCRinfo6)!=ITK_ok)   PrintErrorStack();
		if (AOM_ask_value_string(CtrObjTag[0],"t5_Userinfo7",&DCRinfo7)!=ITK_ok)   PrintErrorStack();
		printf("\n methodGen3DcrRev_PreCond-->L5:DCRinfo6 is : [%s]\n", DCRinfo6);fflush(stdout);
	}
	if (tc_strstr(DCRinfo6,"ON")==NULL)
	{
		time_t t = time(NULL);
		struct tm *currentTime = localtime(&t);
		char yearString[3];

		strftime(yearString, sizeof(yearString), "%y", currentTime);

		printf("Last two digits of the current year: %s\n", yearString);
		tc_strcpy(yrcmp,"");
		tc_strcat(yrcmp,"-");
		tc_strcat(yrcmp,yearString);
		tc_strcat(yrcmp,"-");
		printf("yrcmp is  [%s] and DCR_no is [%s]\n", yrcmp,DCR_no);

		if(tc_strstr(DCR_no,yrcmp)==NULL)
		{
			printf("ERROR: 9th and 10th Digit of DCR Number should match, Last two digits of current year. Please update DCR ID. %s\n", yearString);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "9th and 10th Digit of DCR Number should match, Last two digits of current year. Please update DCR ID.");
			return ITK_err;
		}	
	}
	else
	{
		printf("\n methodGen3DcrRev_PreCond-->DCR ID should have last 2 digits of current year is trun off %s",DCR_no);fflush(stdout);
	}

	CALLAPI(AOM_ask_value_string(objTag,"t5_DcrCreRC",&DCR_reason));
	printf("\n methodGen3DcrRev_PreCond-->DCR_reason: [%s] ",DCR_reason);fflush(stdout);

	if (tc_strcmp(DCR_reason,"COST REDUCTION")==0)
	{
		CALLAPI(AOM_ask_value_string(objTag,"t5_DcrtoImDMC",&DCR_CostImpact));
		printf("\n methodGen3DcrRev_PreCond-->DCR_CostImpact:%s",DCR_CostImpact);fflush(stdout);
		if (tc_strlen(DCR_CostImpact)==0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Total Impact (DMC) in Rs. field is mandatory when Reason for Change is COST REDUCTION ");
			return ITK_err;
		}
	}
	else if (tc_strcmp(DCR_reason,"REGULATORY REQUIREMENT")==0)
	{
		CALLAPI(AOM_ask_value_string(objTag,"t5_RiskAreas",&DCR_regulation));
		printf("\n methodGen3DcrRev_PreCond-->DCR_regulation: [%s]",DCR_regulation);fflush(stdout);

		if (tc_strlen(DCR_regulation)==0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Regulation Number field is mandatory when Reason for Change is REGULATORY REQUIREMENT ");
			return ITK_err;
		}
	}

	int num_MintList=0;
	int IOpt=0;
	char **MintList;
	ITK_CALL(AOM_ask_value_strings(objTag,"t5_MinrefNo",&num_MintList,&MintList));

	if (num_MintList > 0)
	{
		for (IOpt=0;IOpt<num_MintList;IOpt++ )
		{
			if (tc_strcmp(MintList[IOpt],"NA"))
			{
				int CharNum=0;
				//CharNum=GetSpecialCharacterCount(MintList[IOpt]);
				CharNum=GetStringCharacterCount_DCR(MintList[IOpt]);
				printf("\nmethodGen3DcrRev_PreCond-->save_method_OptValue_Pre:::::::::CharNum [%d]\n",CharNum);fflush(stdout);

				if (CharNum > 0)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, "Mint Reference No. should be numeric or NA");
					return ITK_err;
				}
			}

		}
	}

	//Check DCR project code is live
	CALLAPI(AOM_ask_value_string(objTag,"t5_DcrProCode",&DCRproj));
	printf("\n methodGen3DcrRev_PreCond-->DCR DCRproj no: [%s] ",DCRproj);fflush(stdout);
	if(tc_strstr(DCRinfo7,"liveoff")==NULL)
	{
		printf("methodGen3DcrRev_PreCond: DCR Check Project code live validation on \n");
		if(tc_strstr(DCRinfo7,DCRproj)==NULL)
		{
			printf("ERROR: Given DCR project code is not live %s\n", DCRproj);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Given project code is not live for DCR Creation, kindly contact BOM Process Team.");
			return ITK_err;
		}
	}

	printf("\n Completed METHOD_add_pre_condition  methodGen3DcrRev_PreCond--------\n");fflush(stdout);

	return error_code;
}
extern DLLAPI int Gen3DcrRev_post(METHOD_message_t *msg, va_list args)
{
	int status=0;
	int error_code = ITK_ok;
	
	tag_t objTag = va_arg(args, tag_t);
	int	isNew = va_arg(args, int);

	char* type_name = NULL;
	char* dcr_name = NULL;
	char* DCR_proj = NULL;

	char* sMatthickness = NULL;
	char* sCurrMatthikness = NULL;
	char* sProMatthikness = NULL;

	char* sRawMatQ = NULL;
	char* sCurrRawMatV = NULL;
	char* sProRawMat = NULL;

	char* sWegchange = NULL;
	char* sCurrentwt = NULL;
	char* sProwt = NULL;

	char* sChmfgpro = NULL;
	char* sDeschpro = NULL;

	char* sAsuppchange = NULL;
	char* Certification_Impact = NULL;
	char* sCurrentsupp = NULL;
	char* sPropsupp = NULL;

	//char* dcr_VEM = NULL;
	//char* dcr_VPG = NULL;
	//char* dcr_PPM = NULL;
	//char* dcr_FMQ = NULL;
	//char* dcr_TVM = NULL;
	//char* dcr_TS = NULL;
	//char* dcr_CS = NULL;
	//char* groupName = NULL;
		    
	//char* DCR_prog = NULL;

	//groupName = (char *)MEM_alloc(100);
	//dcr_VEM = (char *)MEM_alloc(100);
	//dcr_VPG = (char *)MEM_alloc(100);
	//dcr_PPM = (char *)MEM_alloc(100);
	//dcr_FMQ = (char *)MEM_alloc(100);
	//dcr_TVM = (char *)MEM_alloc(100);
	//dcr_TS  = (char *)MEM_alloc(100);
	//dcr_CS  = (char *)MEM_alloc(100);


	if (AOM_ask_value_string(objTag,"object_type",&type_name)!=ITK_ok);PrintErrorStack();
	printf("\n Gen3DcrRev_post-->object type is:%s -------> %d \n", type_name,isNew);fflush(stdout);

	if(AOM_ask_value_string(objTag,"t5_DcrProCode",&DCR_proj)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->DCR_proj: [%s]", DCR_proj);fflush(stdout);

	if(AOM_ask_value_string(objTag,"t5_Matthickness",&sMatthickness)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->sMatthickness OBJ ID: [%s].", sMatthickness);fflush(stdout);
	if(strcmp(sMatthickness,"Yes")==0)
	{
		if(AOM_ask_value_string(objTag,"t5_CurrMatthikness",&sCurrMatthikness)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sCurrMatthikness OBJ ID: [%s].", sCurrMatthikness);fflush(stdout);
		if(AOM_ask_value_string(objTag,"t5_ProMatthikness",&sProMatthikness)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sProMatthikness OBJ ID: [%s].", sProMatthikness);fflush(stdout);

		if(strcmp(sCurrMatthikness,"") !=0 && strcmp(sProMatthikness,"") !=0)
		{
			printf("\nGen3DcrRev_post-->P1: values present\n");
		}
		else
		{
			printf("\n Gen3DcrRev_post-->P1:Please fill the value for current and proposed material thickness.");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value for current and proposed material thickness.");
			return ITK_err;
		}
	}

	if(AOM_ask_value_string(objTag,"t5_RawMatQ",&sRawMatQ)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->sRawMatQ OBJ ID: [%s].", sRawMatQ);fflush(stdout);
	if(strcmp(sRawMatQ,"Yes")==0)
	{
		if(AOM_ask_value_string(objTag,"t5_CurrRawMatV",&sCurrRawMatV)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sCurrRawMatV OBJ ID: [%s].", sCurrRawMatV);fflush(stdout);
		if(AOM_ask_value_string(objTag,"t5_ProRawMat",&sProRawMat)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sProRawMat OBJ ID: [%s].", sProRawMat);fflush(stdout);

		if(strcmp(sCurrRawMatV,"") !=0 && strcmp(sProRawMat,"") !=0)
		{
			printf("\nGen3DcrRev_post-->P2: values present\n");
		}
		else
		{
			printf("\n Gen3DcrRev_post-->P2:Please fill the value for current and proposed raw material.");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value for current and proposed raw material.");
			return ITK_err;
		}
	}


	if(AOM_ask_value_string(objTag,"t5_Wegchange",&sWegchange)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->sWegchange OBJ ID: [%s].", sWegchange);fflush(stdout);
	if(strcmp(sWegchange,"Yes")==0)
	{
		if(AOM_ask_value_string(objTag,"t5_Currentwt",&sCurrentwt)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sCurrentwt OBJ ID: [%s].", sCurrentwt);fflush(stdout);
		if(AOM_ask_value_string(objTag,"t5_Prowt",&sProwt)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sProwt OBJ ID: [%s].", sProwt);fflush(stdout);

		if(strcmp(sCurrentwt,"") !=0 && strcmp(sProwt,"") !=0)
		{
			printf("\n Gen3DcrRev_post-->P3: values present\n");
		}
		else
		{
			printf("\n Gen3DcrRev_post-->P3:Please fill the value for current and proposed weight of part.");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value for current and proposed weight of part.");
			return ITK_err;
		}
	}

	if(AOM_ask_value_string(objTag,"t5_Chmfgpro",&sChmfgpro)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->sChmfgpro OBJ ID: [%s].", sChmfgpro);fflush(stdout);
	if(strcmp(sChmfgpro,"Yes")==0)
	{
		if(AOM_ask_value_string(objTag,"t5_Deschpro",&sDeschpro)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sDeschpro OBJ ID: [%s].", sDeschpro);fflush(stdout);

		if(strcmp(sDeschpro,"") !=0 )
		{
			printf("\n Gen3DcrRev_post-->P4: values present\n");
		}
		else
		{
			printf("\n Gen3DcrRev_post-->P4:Please fill the value for description change in process.");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value for description change in process.");
			return ITK_err;
		}
	}

	if(AOM_ask_value_string(objTag,"t5_Asuppchange",&sAsuppchange)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->sAsuppchange: [%s].", sAsuppchange);fflush(stdout);
	if(strcmp(sAsuppchange,"Yes")==0)
	{
		if(AOM_ask_value_string(objTag,"t5_Currentsupp",&sCurrentsupp)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sCurrentsupp: [%s].", sCurrentsupp);fflush(stdout);
		if(AOM_ask_value_string(objTag,"t5_Propsupp",&sPropsupp)!=ITK_ok)PrintErrorStack();
		printf("\n Gen3DcrRev_post-->sPropsupp: [%s].", sPropsupp);fflush(stdout);

		if((strcmp(sCurrentsupp,"") !=0) && (strcmp(sPropsupp,"") !=0))
		{
			printf("\n Gen3DcrRev_post-->P5: values present\n");
		}
		else
		{
			printf("\n Gen3DcrRev_post-->P5:Please fill the value for current and proposed supplier.");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value for current and proposed supplier.");
			return ITK_err;
		}
	}
	if(AOM_ask_value_string(objTag,"t5_Certification_Impact",&Certification_Impact)!=ITK_ok)PrintErrorStack();
	printf("\n Gen3DcrRev_post-->Certification_Impact: [%s].", Certification_Impact);fflush(stdout);
	if((strcmp(Certification_Impact,"YES")==0) || (strcmp(Certification_Impact,"NO")==0))
	{
		printf("\n Gen3DcrRev_post-->P6: Certification_Impact value is present\n");
	}
	else
	{
		printf("\n Gen3DcrRev_post-->P6:Please fill the value of Certification_Impact.");fflush(stdout);
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Please fill the value of Certification_Impact.");
		return ITK_err;
	}

	//DCR_prog=getProgramProject(DCR_proj);

	//tc_strcpy(groupName,DCR_prog);
	//tc_strcat(groupName,".");
	//tc_strcat(groupName,"DCR::");

	//tc_strcpy(dcr_VEM,groupName);
	//tc_strcpy(dcr_VPG,groupName);
	//tc_strcpy(dcr_PPM,groupName);
	//tc_strcpy(dcr_FMQ,groupName);
	//tc_strcpy(dcr_TVM,groupName);
	//tc_strcpy(dcr_TS,groupName);
	//tc_strcpy(dcr_CS,groupName);

	//tc_strcat(dcr_VEM,"PAT_VEM");
	//tc_strcat(dcr_VPG,"PAT_VPG");
	//tc_strcat(dcr_PPM,"Functional_Lead_PPM");
	//tc_strcat(dcr_FMQ,"Functional_Lead_FMQ");
	//tc_strcat(dcr_TVM,"Functional_Lead_ICM");
	//tc_strcat(dcr_TS,"Functional_Lead_TS");
	//tc_strcat(dcr_CS,"Functional_Lead_CS");

	//AOM_lock(objTag);

	//if (AOM_set_value_string(objTag,"t5_DCR_VEM",dcr_VEM)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_VPG",dcr_VPG)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_PPM",dcr_PPM)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_FMQ",dcr_FMQ)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_TVM",dcr_TVM)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_TS",dcr_TS)!=ITK_ok);PrintErrorStack();
	//if (AOM_set_value_string(objTag,"t5_DCR_CS",dcr_CS)!=ITK_ok);PrintErrorStack();

	//AOM_save_without_extensions(objTag);
	//AOM_unlock(objTag);
	//AOM_refresh (objTag,TRUE);

	//char* Ana_BIW =NULL;
	//char* Ana_CHS =NULL;
	//char* Ana_ENG =NULL;
	//char* Ana_EES =NULL;
	//char* Ana_TAS =NULL;
	//char* Ana_TRM =NULL;

	//Ana_BIW = (char	*)MEM_alloc(100);
	//Ana_CHS = (char	*)MEM_alloc(100);
	//Ana_ENG = (char	*)MEM_alloc(100);
	//Ana_EES = (char	*)MEM_alloc(100);
	//Ana_TAS = (char	*)MEM_alloc(100);
	//Ana_TRM = (char	*)MEM_alloc(100);

	//tc_strcpy(Ana_BIW,groupName);
	//tc_strcpy(Ana_CHS,groupName);
	//tc_strcpy(Ana_ENG,groupName);
	//tc_strcpy(Ana_EES,groupName);
	//tc_strcpy(Ana_TAS,groupName);
	//tc_strcpy(Ana_TRM,groupName);

	//tc_strcat(Ana_BIW,"BIW_COC");
	//tc_strcat(Ana_CHS,"Chassis_COC");
	//tc_strcat(Ana_ENG,"Engines_COC");
	//tc_strcat(Ana_EES,"EE_COC");
	//tc_strcat(Ana_TAS,"TA_COC");
	//tc_strcat(Ana_TRM,"Trim_COC");

	//tag_t DCR_TSK_rel_type=NULLTAG;
	//tag_t *DCRTskTag=NULL;
	//int TskCnt=0;

	//if(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_TSK_rel_type)!=ITK_ok)PrintErrorStack();
	//if(GRM_list_secondary_objects_only(objTag,DCR_TSK_rel_type,&TskCnt,&DCRTskTag)!=ITK_ok)PrintErrorStack();

	//int ii=0;
	//for (ii=0;ii<TskCnt;ii++)
	//{
		//char* DCR_Tsk_Nm=NULL;

		//if(AOM_ask_value_string(DCRTskTag[ii],"item_id",&DCR_Tsk_Nm)!=ITK_ok)PrintErrorStack();
		//printf("\n DCR_Tsk_Nm OBJ ID: [%s].", DCR_Tsk_Nm);fflush(stdout);

		//AOM_lock(DCRTskTag[ii]);
		//if (tc_strstr(DCR_Tsk_Nm,"_BIW"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_BIW)!=ITK_ok);PrintErrorStack();
		//}
		//else if (tc_strstr(DCR_Tsk_Nm,"_Chassis"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_CHS)!=ITK_ok);PrintErrorStack();
		//}
		//else if (tc_strstr(DCR_Tsk_Nm,"_Engines"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_ENG)!=ITK_ok);PrintErrorStack();
		//}
		//else if (tc_strstr(DCR_Tsk_Nm,"_EE"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_EES)!=ITK_ok);PrintErrorStack();
		//}
		//else if (tc_strstr(DCR_Tsk_Nm,"_TA"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_TAS)!=ITK_ok);PrintErrorStack();
		//}
		//else if (tc_strstr(DCR_Tsk_Nm,"_Trim"))
		//{
			//if (AOM_set_value_string(DCRTskTag[ii],"t5_DcrAnalyst",Ana_TRM)!=ITK_ok);PrintErrorStack();
		//}
			//AOM_save_without_extensions(DCRTskTag[ii]);
		//AOM_unlock(DCRTskTag[ii]);
		//AOM_refresh (DCRTskTag[ii],TRUE);
	//}

	printf("\n Gen3DcrRev_post-->Completed...\n");

	return error_code;
}
extern DLLAPI int Gen3Dcr_post(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);

	int	isNew = va_arg(args, int);

	int status = 0;
	int error_code = ITK_ok;

	char* type_name = NULL;
	char* dcr_name = NULL;

	tag_t objTypeTag = NULLTAG;
	tag_t DML_tag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t rel_type = NULLTAG;
	tag_t relation = NULLTAG;
	tag_t objTag_Rev = NULLTAG;

	if (AOM_ask_value_string(objTag,"object_type",&type_name)!=ITK_ok);PrintErrorStack();
	printf("\n Gen3Dcr_post-->object type is: [%s]-------> %d \n", type_name,isNew);fflush(stdout);

	if (!isNew)
	{
		printf("\n Gen3Dcr_post--> DCR is going to be updated:::::::::!!!!!!!! \n");fflush(stdout);

		UpdateDcrResourcePool(objTag);
		return error_code;
	}
	if(strcmp(type_name,"T5_GenDcrChngRep")==0)
	{
		ITEM_ask_latest_rev(objTag,&objTag_Rev);

		if (AOM_ask_value_string(objTag,"item_id",&dcr_name)!=ITK_ok);PrintErrorStack();

		printf("\n Gen3Dcr_post-->DCR-ID: %s \n",dcr_name);fflush(stdout);

		CreateDcrTask(objTag,"BIW");
		CreateDcrTask(objTag,"Chassis");
		CreateDcrTask(objTag,"Engines");
		CreateDcrTask(objTag,"EE");
		CreateDcrTask(objTag,"TA");
		CreateDcrTask(objTag,"Trim");
	}

	printf("\n Gen3Dcr_post-->Completed...\n");

	return error_code;
}


//Added by kalpesh for validation DCR.
int DCR_attach_method(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE DCR_attach_method*** \n");fflush(stdout);

	int ifail				= 0;
	int i					= 0;
	int j					= 0;
	int cnt					= 0;
	int CO_count			= 0;
	int count_dmldes		= 0;
	int count_dcrdes		= 0;
	int DCRVali_rsltCount	= 0;
	int DCRvali_n_entry		= 1;
	int DCRRes_n			= 4;
	int DCRRes_Count		= 0;

	tag_t primary_object = va_arg(args, tag_t);
	tag_t secondary_object = va_arg(args, tag_t);
		  
	tag_t primary_obj_type_tag = NULLTAG;
	tag_t secondary_obj_type_tag = NULLTAG;
	tag_t query_tag = NULLTAG;
	tag_t DCRValiTag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t user_tag1 = NULLTAG;
	tag_t login_group = NULLTAG;
	tag_t role_tag = NULLTAG;
	tag_t user = NULLTAG;
	tag_t group = NULLTAG;
	tag_t role = NULLTAG;
	tag_t group_tag = NULLTAG;
		  
	tag_t *DCRValiCntrlObjectTag = NULLTAG;
	tag_t *DMLToGen3DCR_CO_Tag = NULLTAG;
	tag_t *DCRResObjTag = NULLTAG;

	char *value1 = NULL;
	char *group_string = NULL;
	char *user_id = NULL;
	char *role_name = NULL;
	char *rolename = NULL;
	char *group_name = NULL;
	char *value2 = NULL;
	char *value3 = NULL;
	char *value4 = NULL;
	char *DML_BU = NULL;
	char *DCRID = NULL;
	char *type_name1 = NULL;
	char *type_name2 = NULL;
	char *username = NULL;
	char *username1 = NULL;
	char *Dcrnum = NULL;
	char *DcrGearnum = NULL;
	char *user_Name = NULL;
	char *DCR_reason = NULL;
	char *DML_reason = NULL;
	char *DCR_LCState = NULL;
	char **DML_design_grp = NULL;
	char **DCR_design_grp = NULL;
	char *DCRValiinfo2 = NULL;
	char *DCRValiinfo5 = NULL;
	char *DCRValiinfo1 = NULL;
	char *Requestor = NULL;
	char *RequestorStr = NULL;
	char *RequestorStr1 = NULL;
	char *RequestorStr2 = NULL;

	RequestorStr=MEM_alloc(100);
	RequestorStr1=MEM_alloc(100);
	RequestorStr2=MEM_alloc(100);
	char **query_value = (char **) MEM_alloc(10 * sizeof(char *));
	char **DCRRes_qry_values2 = (char **) MEM_alloc(20 * sizeof(char *));
	char **DCRVali_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));

	char *query_entry[1] = {"SYSCD"};
	char *DCRvali_qry_entry[1]  = {"SYSCD"};
	char *DCRRes_qry_entry[4]  = {"SYSCD","SUBSYSCD","Information-1","Information-2"};

	CALLAPI(TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag));
	CALLAPI(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
	printf("\nDCR_attach_method-->Primary_object type_name is:%s",type_name1);fflush(stdout);

	CALLAPI(TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag));
	CALLAPI(TCTYPE_ask_name2(secondary_obj_type_tag, &type_name2));
	printf("\nDCR_attach_method-->secondary_object type_name is:%s",type_name2);fflush(stdout);

	CALLAPI(POM_get_user_id (&user_id));
	CALLAPI(SA_ask_current_role(&role));
	CALLAPI(SA_ask_role_name2(role, &role_name));
	CALLAPI(POM_ask_group(&group_string,&group_tag));
	CALLAPI(SA_ask_group_name2(group_tag,&group_name));
	

	printf("\nDCR_attach_method-->Logged in user:[%s]  Group_name is [%s] RoleName is [%s]\n",user_id,group_name,role_name); fflush(stdout);

	if(tc_strcmp(type_name1,"ChangeRequestRevision") == 0)
	{
		printf("\nDCR_attach_method-->*****INSIDE ChangeRequestRevision*****\n");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(primary_object,"t5_ERCBusiUt",&DML_BU));
		printf("\nDCR_attach_method-->DML Business Unit is %s\n",DML_BU);fflush(stdout);
		
		CALLAPI(AOM_UIF_ask_value(primary_object,"Requestor",&Requestor));
		printf("\nDCR_attach_method-->DML Requestor is %s\n",Requestor);fflush(stdout);

		RequestorStr=strtok(Requestor,"/");
		RequestorStr1=strtok(NULL,"/");
		RequestorStr2=strtok(NULL,"/");
		printf("\nDCR_attach_method-->RequestorStr is [%s] RequestorStr1 is [%s]\n RequestorStr2 is [%s]",RequestorStr,RequestorStr1,RequestorStr2);fflush(stdout);
		if((tc_strcmp(type_name2,"T5_GenDcrChngRep") == 0) || (tc_strcmp(type_name2,"T5_GenDcrChngRepRevision") == 0) || (tc_strcmp(type_name2,"T5_DChangeReportRevision") == 0))
		{
			printf("\nDCR_attach_method-->*****INSIDE T5_GenDcrChngRep*****\n");fflush(stdout);
			printf("\nDCR_attach_method-->As primary object is DML and secondary object is DCR, so relation creation is allowed.\n");

			if(QRY_find2("Control Objects...", &query_tag));
			if (query_tag != NULLTAG)
			{
				printf("\n DCR_attach_method-->Query found query_tag\n");fflush(stdout);
			}
			else
			{
				printf("\n DCR_attach_method-->Query Not Found query_tag\n");fflush(stdout);
			}
			//PSS918119- DCR LC state should be above DCR approved..
			if(QRY_find2("Control Objects...", &DCRValiTag));
			if (DCRValiTag)
			{
				printf("\n DCR_attach_method-->L2:Found Query DCRValiTag \n");fflush(stdout);
			}
			else
			{
				printf("\n DCR_attach_method-->L3:Not Found Query DCRValiTag \n");fflush(stdout);
			}

			DCRVali_qry_values2[0] = "DCRVali";
			if(QRY_execute(DCRValiTag, DCRvali_n_entry, DCRvali_qry_entry, DCRVali_qry_values2, &DCRVali_rsltCount, &DCRValiCntrlObjectTag));
			printf(" \n DCR_attach_method-->L4:DCRVali_rsltCount :%d:", DCRVali_rsltCount); fflush(stdout);
			if(DCRVali_rsltCount > 0)
			{
				if (AOM_ask_value_string(DCRValiCntrlObjectTag[0],"t5_Userinfo1",&DCRValiinfo1)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->L5:DCRValiinfo1 is : [%s]\n", DCRValiinfo1);fflush(stdout);

				if (AOM_ask_value_string(DCRValiCntrlObjectTag[0],"t5_Userinfo2",&DCRValiinfo2)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->L5:DCRValiinfo2 is : [%s]\n", DCRValiinfo2);fflush(stdout);
				//BU for PSE
				if (AOM_ask_value_string(DCRValiCntrlObjectTag[0],"t5_Userinfo5",&DCRValiinfo5)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->L5:DCRValiinfo5 is : [%s]\n", DCRValiinfo5);fflush(stdout);
			}

			query_value[0] = "DMLToGen3DCR_rel";
			if(QRY_execute(query_tag, 1, query_entry, query_value, &CO_count, &DMLToGen3DCR_CO_Tag));
			printf(" \n DCR_attach_method-->DMLToGen3DCR_rel CO_count:%d", CO_count); fflush(stdout);
			if(QRY_execute(query_tag, 1, query_entry, query_value, &CO_count, &DMLToGen3DCR_CO_Tag));
			printf(" \n DCR_attach_method-->DMLToGen3DCR_rel CO_count:%d", CO_count); fflush(stdout);
			if(CO_count > 0)
			{
				if(AOM_ask_value_string(DMLToGen3DCR_CO_Tag[0],"t5_Userinfo1",&value1)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->DMLToGen3DCR_rel(Control object) Info1= [%s]\n", value1);fflush(stdout);
				//ON/OFF,DCRLC
				if(AOM_ask_value_string(DMLToGen3DCR_CO_Tag[0],"t5_Userinfo2",&value2)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->DMLToGen3DCR_rel(Control object) Info2= [%s]\n", value2);fflush(stdout);
				
				if(AOM_ask_value_string(DMLToGen3DCR_CO_Tag[0],"t5_Userinfo3",&value3)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->DMLToGen3DCR_rel(Control object) Info3= [%s]\n", value3);fflush(stdout);
				
				// DML BU for PV
				if(AOM_ask_value_string(DMLToGen3DCR_CO_Tag[0],"t5_Userinfo4",&value4)!=ITK_ok)   PrintErrorStack();
				printf("\n DCR_attach_method-->DMLToGen3DCR_rel(Control object) Info4= [%s]\n", value4);fflush(stdout);

				CALLAPI(AOM_ask_value_strings(primary_object,"t5_crdesigngroup",&count_dmldes, &DML_design_grp));
				CALLAPI(AOM_ask_value_strings(secondary_object,"t5_DcrDesgGrp",&count_dcrdes, &DCR_design_grp));
				printf("\n DCR_attach_method-->DML Design Group COunt [%d], DCR Design Group Count [%d]\n", count_dmldes,count_dcrdes);fflush(stdout);

				if(tc_strstr(value1, "T5_GenDcrChngRep") == NULL)
				{
					//Validation for DML and DCR reason code
					CALLAPI(AOM_ask_value_string(primary_object,"t5_DmlReasonDisplay",&DML_reason));
					printf("\n DCR_attach_method-->Reason code of DML:[%s]\n",DML_reason);fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(secondary_object,"t5_DcrCreRC",&DCR_reason));
					printf("\n DCR_attach_method-->Reason code of DCR:[%s]\n",DCR_reason);fflush(stdout);

					if (tc_strstr(value2,"P001") == NULL)
					{
						DCRRes_qry_values2[0] = "DCRRES";
						DCRRes_qry_values2[1] = DML_BU;
						DCRRes_qry_values2[2] = DML_reason;
						DCRRes_qry_values2[3] = DCR_reason;

						if(QRY_execute(DCRValiTag, DCRRes_n, DCRRes_qry_entry, DCRRes_qry_values2, &DCRRes_Count, &DCRResObjTag));
						printf("\n DCR_attach_method-->DCRRES_reasoncode_rsltCount :%d:", DCRRes_Count); fflush(stdout);
						
						if(tc_strstr(value1,"RoleOFF") == NULL)
						{
							printf("\n DCR_attach_method-->In Session code check Loop.\n");fflush(stdout);
							if((tc_strstr(RequestorStr,group_name) != NULL) && (tc_strstr(RequestorStr1,role_name) != NULL) && (tc_strstr(RequestorStr2,user_id) != NULL))
							{
								printf("\n DCR_attach_method-->DML reqestor is Correct\n");fflush(stdout);
							}
							else
							{
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR012: Please modify user setting on session bar and set user session same as DML requestor group and role.\n you can see DML requestor role in summary page after selecting DML.");
								printf("\nDCR_attach_method-->Please set the session Group and role as DML Requestor with the DML project code and then try to attach DCR to DML .");fflush(stdout);
								return ITK_err;
							}
						}
						if (((tc_strcmp(DML_BU, "CVBU") == 0)||(tc_strcmp(DML_BU, "CV-PSE") == 0) || (tc_strcmp(DML_BU, "PV-PSE") == 0) || (tc_strcmp(DML_BU, "PV-Transmission") == 0) || (tc_strcmp(DML_BU, "CV-Transmission") == 0) || (tc_strcmp(DML_BU, "PV-Advanced Engineering") == 0) || (tc_strcmp(DML_BU, "CV-Advanced Engineering") == 0) || (tc_strcmp(DML_BU, "PV-Advanced Technology") == 0) || (tc_strcmp(DML_BU, "CV-Advanced Technology") == 0))&&(tc_strcmp(type_name2,"T5_DChangeReportRevision") == 0))
						{
							printf("\n DCR_attach_method-->DML DCR attachment Validation on [%s]\n",value2);fflush(stdout);
							CALLAPI(AOM_ask_value_string(secondary_object,"current_id",&DCRID));
							printf("\n DCR_attach_method--> DCR No is:[%s] & DML Business unit [%s] \n",DCRID,DML_BU);fflush(stdout);

							if (tc_strcmp(DML_BU, "CVBU") == 0)  // CVBU DML DCR Reason Code Validation
							{
								if(tc_strstr(value1, "DSG005") == NULL)
								{
									if(tc_strstr(DCRID,"1477-") != NULL)							
									{
										printf("\n DCR_attach_method--> DCR No is:[%s] & is starting with 1477  Allowed to create Relation \n",DCRID);fflush(stdout);
									}
									else
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR004: For CVBU Business Unit DCR name should start with 1477. Please use correct DCR.");
										printf("\nDCR_attach_method-->DCR_attach_method-->For CVBU Business Unit DCR name should start with 1477 or 995\n");fflush(stdout);
										return ITK_err;
									}
								}
								//CHECKING DESIGN GROUP OF DML AND DCR
								if(tc_strstr(value1, "DSG001") == NULL)
								{
									printf("DCR_attach_method--> DCR No is:[%s] & DML reason Code [%s] & DCR Reason Code [%s], allowed to attach \n",DCRID,DML_reason,DCR_reason);fflush(stdout);
									i= 0;
									j=0;
									cnt = 0;
									for(i=0; i<count_dmldes; i++)
									{
										for(j=0; j<count_dcrdes; j++)
										{
											if(tc_strcmp(DML_design_grp[i], DCR_design_grp[j]) == 0)
											{
												printf("\nCVBU: DCR_attach_method-->DML Design_group[%d] found in list of DCR design groups...!!\n", i);fflush(stdout);
												cnt++;
												break;
											}
										}
									}
									printf("\n DCR_attach_method-->DML DCR Design group match count : %d\n",cnt);fflush(stdout);
									if(cnt == 0)
									{
										TC_write_syslog("DCR_attach_method-->DML design group and DCR design group should be same.\n");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR001:DML design group and DCR design group should be same.\nPlease attach correct DCR or get DCR design group confirmed from pfirst.");
										printf("\nDCR_attach_method-->DML design group and DCR design group should be same.\n");fflush(stdout);
										return ITK_err;
									}
								}
								//CHECKING DML-DCR REASON CODES.
								if(tc_strstr(value1, "DSG002") == NULL)
								{
									char *dcr_no		= NULL;
									char *dml_no		= NULL;
									char *reason_code	= NULL;       
									char *ObjClassName	=NULL;
									char *reason		= NULL;
									char *reasonDup		= NULL;
									char*  reasonUpdate	= NULL;
									char  *type_name	= NULL;
									char  *Dml_reasoncode	= NULL;
									char  *Dcr_reasoncode	= NULL;
									char  *userinfo1	= NULL;
									char  *userinfo2	= NULL;
									char  *userinfo3	= NULL;
									char  *userinfo4	= NULL;
									char  *userinfo5	= NULL;
									
									tag_t DCRTag		= NULLTAG;
									tag_t DCRREVTag		= NULLTAG;
									tag_t ERCDMLQry		= NULLTAG;
									tag_t ERCDMLTag		= NULLTAG;
									tag_t TagClassId	= NULLTAG;
									tag_t objTypeTag	= NULLTAG;
									tag_t VCReviseCtrObj1 = NULLTAG;
									tag_t CtrObjVCReviseQryTag = NULLTAG;

									tag_t *VCReviseCtrObj = NULLTAG;
									tag_t *ERCDMLTags	= NULLTAG;

									int one_entry = 1;
									int QryOPCount = 0;
									int n = 0;

									char *qry_entries[1] = {"ID"};
									char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
									char **VCReviseEntryValue = (char **) MEM_alloc(1000 * sizeof(char *));
									char *VCReviseQryEntry[2]  = {"SYSCD" , "SUBSYSCD"};
									
									int status              = ITK_ok;
									if(QRY_find2("Control Objects...", &CtrObjVCReviseQryTag));
									if (CtrObjVCReviseQryTag)
									{
									   printf("\n Found Query \n");fflush(stdout);
									}
									else
									{
									   printf("\n Not Found Query \n");fflush(stdout);
									}
									VCReviseEntryValue[0] = "DCRReasoncode";	//SYSCD
									VCReviseEntryValue[1] = "DCRReasoncode";			//SUBSYSCD

									if(QRY_execute(CtrObjVCReviseQryTag, 2, VCReviseQryEntry, VCReviseEntryValue, &n, &VCReviseCtrObj));
									printf("\n vc_release--Control Object AltrozVCRevise count:--> [%d] ",n); fflush(stdout);
									if(n>0)	
									{
										VCReviseCtrObj1 = VCReviseCtrObj[0];
										if (AOM_ask_value_string(VCReviseCtrObj1,"t5_Userinfo1",&userinfo1)!=ITK_ok) PrintErrorStack();
										printf("\n user info is [%s]\n", userinfo1);fflush(stdout);
										//DML reason code
										if (AOM_ask_value_string(VCReviseCtrObj1,"t5_Userinfo2",&userinfo2)!=ITK_ok) PrintErrorStack();
										printf("\n user userinfo2 is [%s]\n", userinfo2);fflush(stdout);
										//DCR reason code
										if (AOM_ask_value_string(VCReviseCtrObj1,"t5_Userinfo3",&userinfo3)!=ITK_ok) PrintErrorStack();
										printf("\n user userinfo3 is [%s]\n", userinfo3);fflush(stdout);

										if (AOM_ask_value_string(VCReviseCtrObj1,"t5_Userinfo4",&userinfo4)!=ITK_ok) PrintErrorStack();
										printf("\n user userinfo4 is [%s]\n", userinfo4);fflush(stdout);
										//Bypass DML reason code 
										if (AOM_ask_value_string(VCReviseCtrObj1,"t5_Userinfo5",&userinfo5)!=ITK_ok) PrintErrorStack();
										printf("\n user userinfo5 is [%s]\n", userinfo5);fflush(stdout);

										if(tc_strstr(userinfo1,"DCR001")==NULL)
										{
											if(AOM_ask_value_string(primary_object,"t5_DmlReasonDisplay",&Dml_reasoncode)!=ITK_ok);PrintErrorStack();
											printf("\n ERC: Dml_reasoncode:%s", Dml_reasoncode);fflush(stdout);

											if(AOM_ask_value_string(secondary_object,"t5_DcrCreRC",&Dcr_reasoncode)!=ITK_ok);PrintErrorStack();
											printf("\n ERC: Dcr_reasoncode:%s", Dcr_reasoncode);fflush(stdout);
											if(DCRRes_Count > 0)
											{
												printf("\n ERC011: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,userinfo2)== 0) && (tc_strcmp(Dcr_reasoncode,userinfo3)== 0))
											{
												printf("\n ERC00: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if(tc_strcmp(Dml_reasoncode,Dcr_reasoncode)== 0)
											{
												printf("\n ERC000: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if(tc_strstr(userinfo5,Dml_reasoncode)!= NULL)
											{
												printf("\n ERC0000: Dml_reasoncode is bypassed");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"REGULATORY / SAFETY REQUIREMENTS")== 0) && (tc_strcmp(Dcr_reasoncode,"Regulatory_or_safety_requirement")== 0))
											{
												printf("\n ERC1: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"VALIDATION / CAE FEEDBACK")== 0) && (tc_strcmp(Dcr_reasoncode,"Validation_or_CAE_feedbacks")== 0))
											{
												printf("\n ERC2: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT")== 0) && (tc_strcmp(Dcr_reasoncode,"Quality_process_Improvements")== 0))
											{
												printf("\n ERC3: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT")== 0) && (tc_strcmp(Dcr_reasoncode,"Major Build Issues")== 0))
											{
												printf("\n ERC3: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"CHANGE IN FEATURE LIST")== 0) && (tc_strcmp(Dcr_reasoncode,"New_requirement_VC_aggregate")== 0))
											{
												printf("\n ERC4: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"ALTERNATE SOURCE DEVELOPMENT")== 0) && (tc_strcmp(Dcr_reasoncode,"Alternate_Source")== 0))
											{
												printf("\n ERC5: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION")== 0) && (tc_strcmp(Dcr_reasoncode,"Cost_Reduction")== 0))
											{
												printf("\n ERC6: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"COST REDUCTION")== 0) && (tc_strcmp(Dcr_reasoncode,"Cost_Reduction")== 0))
											{
												printf("\n ERC7: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"WARRANTY COST REDUCTION / INTEGRATED COST REDUCTION")== 0) && (tc_strcmp(Dcr_reasoncode,"Cost_Reduction")== 0))
											{
												printf("\n ERC8: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT")== 0) && (tc_strcmp(Dcr_reasoncode,"Customer_Complaint")== 0))
											{
												printf("\n ERC9: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT")== 0) && (tc_strcmp(Dcr_reasoncode,"3D_Data_Release")== 0))
											{
												printf("\n ERC10: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else if((tc_strcmp(Dml_reasoncode,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT")== 0) && (tc_strcmp(Dcr_reasoncode,"Drg_Error_Correction")== 0))
											{
												printf("\n ERC11: Dml_reasoncode & Dcr_reasoncode is match");fflush(stdout);
											}
											else
											{
												printf("\n ERC11: Dml_reasoncode & Dcr_reasoncode is not matach \n Please map the DML reason code as per DCR reason code");fflush(stdout);
												//ERROR
												TC_write_syslog("DCR_attach_method-->DML reason code and DCR reason code should be mapped as per mapping.\n");
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR005:DML reason code and DCR reason code are not as per mapping.\nPlease check below Points for DML-DCR reason code mapping.\n1] Check DML and DCR reason code (select DML/DCR and do View properties).\n2] Please check DCR reason on DCR object, not on DCR PDF. DCR reason code should be as mentioned on DCR PDF.\n3] If DCR reason is blank/NULL, then raise to DCR Support team with correct reason value mentioned on PDF to update.");
												printf("\nDCR_attach_method-->DML reason code and DCR reason code should be mapped as per mapping\n");fflush(stdout);
												return ITK_err;
											}
										}	
									}
								}
							}
							else if(tc_strstr(DCRValiinfo5,DML_BU) != NULL)
							{
								//else if ((tc_strcmp(DML_BU, "CV-PSE") == 0) || (tc_strcmp(DML_BU, "PV-PSE") == 0) || (tc_strcmp(DML_BU, "PV-Transmission") == 0) || (tc_strcmp(DML_BU, "CV-Transmission") == 0) || (tc_strcmp(DML_BU, "PV-Advanced Engineering") == 0) || (tc_strcmp(DML_BU, "CV-Advanced Engineering") == 0) || (tc_strcmp(DML_BU, "PV-Advanced Technology") == 0) || (tc_strcmp(DML_BU, "CV-Advanced Technology") == 0)) // CV-PSE DML DCR Reason Code Validation
								if(tc_strstr(value1, "DSG003") == NULL)
								{
									if(tc_strstr(DCRID,"2026-") != NULL)
									{
										printf("\n DCR_attach_method--> DCR No is:[%s] & is starting with 1477 Allowed to create Relation \n",DCRID);fflush(stdout);
									}
									else
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR006: For CV-PSE Business Unit DCR name should start with 2026.\n Please attach correct DCR.");
										printf("\nDCR_attach_method-->DCR_attach_method-->For CVBU Business Unit DCR name should start with 2026\n");fflush(stdout);
										return ITK_err;
									}
								}
								//CHECKING DESIGN GROUP OF DML AND DCR
								if(tc_strstr(value1, "DSG004") == NULL)
								{
									printf("CV-PSE:DCR_attach_method--> DCR No is:[%s] & DML reason Code %s & DCR Reason Code %s, allowed to attach \n",DCRID,DML_reason,DCR_reason);fflush(stdout);
									i= 0;
									j=0;
									cnt = 0;
									for(i=0; i<count_dmldes; i++)
									{
										for(j=0; j<count_dcrdes; j++)
										{
											if(tc_strcmp(DML_design_grp[i], DCR_design_grp[j]) == 0)
											{
												printf("\nCV-PSE: DCR_attach_method-->DML Design_group[%d] found in list of DCR design groups...!!\n", i);fflush(stdout);
												cnt++;
												break;
											}
										}
									}
									if(cnt == 0)
									{
										TC_write_syslog("DCR_attach_method-->DML design group and DCR design group should be same.\n");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR002:DML design group and DCR design group should be same.\nPlease attach correct DCR or get DCR design group confirmed from pfirst.");
										printf("\nDCR_attach_method-->DML design group and DCR design group should be same.\n");fflush(stdout);
										return ITK_err;
									}
								}
								//CHECKING DML-DCR REASON CODES.
								printf("\n DCR_attach_method-->DML DCR Design group match count : %d\n",cnt);fflush(stdout);
								if(tc_strstr(value1, "DSG006") == NULL)
								{
									if(DCRRes_Count == 0)
									{
										printf("DCR_attach_method-->CV-PSE: DCR No is:[%s] & DML reason Code %s & DCR Reason Code %s, not matching \n",DCRID,DML_reason,DCR_reason);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR003:CV-PSE:DML reason code and DCR reason code are not as per mapping.\nPlease check below Points for DML-DCR reason code mapping.\n1] Check DML and DCR reason code (select DML/DCR and do View properties).\n2] Please check DCR reason on DCR object, not on DCR PDF. DCR reason code should be as mentioned on DCR PDF.\n3] If DCR reason is blank/NULL, then raise to DCR Support team with correct reason value mentioned on PDF to update.");
										printf("\nDCR_attach_method-->CV-PSE: DML reason Code and DCR reason Code should be same.\n");fflush(stdout);
										return ITK_err;
									}
									else
									{
										printf("\nDCR_attach_method-->CV-PSE: DML reason Code and DCR reason Code is same.\n");fflush(stdout);
									}	
								}	
							}
							if(tc_strstr(value1, "DSG008") == NULL)
							{
								if (AOM_ask_value_string(secondary_object,"item_id",&Dcrnum)!=ITK_ok)   PrintErrorStack();
								printf("\n DCR number is: [%s] ", Dcrnum);fflush(stdout);

								if (AOM_ask_value_string(secondary_object,"t5_Gear_No",&DcrGearnum)!=ITK_ok)   PrintErrorStack();
								printf("\n Dcr Gear number is: [%s] ", DcrGearnum);fflush(stdout);

								if (tc_strstr(Dcrnum,"1477-3-")!=NULL)
								{
										printf("\n  Updating the Dcr Gear number on DML.");fflush(stdout);
										if (AOM_lock(primary_object)!=ITK_ok);PrintErrorStack();
										if(AOM_set_value_string(primary_object,"t5_Gear_Number",DcrGearnum)!=ITK_ok);PrintErrorStack();
										if(AOM_save_without_extensions(primary_object)!=ITK_ok);PrintErrorStack();
										if(AOM_unlock(primary_object)!=ITK_ok);PrintErrorStack();
										if(AOM_refresh (primary_object,TRUE)!=ITK_ok);PrintErrorStack();
								}
							}
						}
						else if ((tc_strcmp(DML_BU, "PVBU") == 0) && (tc_strcmp(type_name2,"T5_GenDcrChngRepRevision") == 0))	// PVBU DML DCR Reason Code Validation
						{
							if (tc_strstr(value2,"P003") == NULL)
							{
								if((DCRRes_Count > 0) || tc_strcmp(DML_reason,"ECU CALIBRATION FILE RELEASE") == 0)	
								{
									printf("\n DCR_attach_method-->Relation created between DML and DCR...!!: DCRRes_Count check\n");fflush(stdout);

									//Validation for DML and DCR Design group.
									
									//printf("\nDesign group of DCR:[%s]\n",DCR_design_grp);fflush(stdout);

									for(i=0; i<count_dmldes; i++)
									{
										for(j=0; j<count_dcrdes; j++)
										{
											if(tc_strcmp(DML_design_grp[i], DCR_design_grp[j]) == 0)
											{
												printf("\n DCR_attach_method-->DML Design_group[%d] found in list of DCR design groups...!!\n", i);fflush(stdout);
												cnt++;
												break;
											}
										}
									}
									printf("\n DCR_attach_method-->DML DCR Design group match count : %d\n",cnt);fflush(stdout);
									if(cnt == 0)
									{
										TC_write_syslog("DCR_attach_method-->DML design group and DCR design group should be same.\n");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR007: DCR not allowed to attach as, DML design group and DCR design group should be same.");
										printf("\nDCR_attach_method-->DML design group and DCR design group should be same.\n");fflush(stdout);
										return ITK_err;
									}
								}
								else
								{
									TC_write_syslog("DML reason code and DCR reason code should be same.\n");
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR:DCR008:DCR not allowed to attach as, DML reason code and DCR reason code should be same.");
									printf("\nDCR_attach_method-->DML reason code and DCR reason code should be same.\n");fflush(stdout);
									return ITK_err;
								}
							}
							if (tc_strstr(value2,"P004") == NULL)
							{
								if ((tc_strcmp(DML_reason,DCR_reason)==0)&&(tc_strcmp(type_name2,"T5_GenDcrChngRepRevision") == 0))
								{
									printf("\n DCR_attach_method-->Relation created between DML and DCR...!!tc_strcmp(DML_reason,DCR_reason)\n");fflush(stdout);

									//Validation for DML and DCR Design group.
									
									//printf("\nDesign group of DCR:[%s]\n",DCR_design_grp);fflush(stdout);

									for(i=0; i<count_dmldes; i++)
									{
										for(j=0; j<count_dcrdes; j++)
										{
											if(tc_strcmp(DML_design_grp[i], DCR_design_grp[j]) == 0)
											{
												printf("\n DCR_attach_method-->DML Design_group[%d] found in list of DCR design groups...!!\n", i);fflush(stdout);
												cnt++;
												break;
											}
										}
									}
									printf("\n DCR_attach_method-->DML DCR Design group match count : %d\n",cnt);fflush(stdout);
									if(cnt == 0)
									{
										TC_write_syslog("DCR_attach_method-->DML design group and DCR design group should be same.\n");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR:DCR009:DCR not allowed to attach as, DML design group and DCR design group should be same.");
										printf("\nDCR_attach_method-->DML design group and DCR design group should be same.\n");fflush(stdout);
										return ITK_err;
									}
								}
								else
								{
									TC_write_syslog("DML reason code and DCR reason code should be same.\n");
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR:DCR010:DCR not allowed to attach as, DML reason code and DCR reason code should be same.");
									printf("\nDCR_attach_method-->DML reason code and DCR reason code should be same.\n");fflush(stdout);
									return ITK_err;
								}
							}
						}
						else if ((tc_strstr(value4,DML_BU) != NULL) && ((tc_strcmp(type_name2,"T5_DChangeReportRevision") == 0) || (tc_strcmp(type_name2,"T5_DChangeReport") == 0)))	// PVBU DML DCR Reason Code Validation)
						{
							printf("\nThere is no Validation for Mint DCR.\n");fflush(stdout);
						}
						else
						{
							printf("\n DCR_attach_method-->DML DCR attachment Validation Business Unit and DCR object check)\n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"DML-DCR attachment Validation: DML Business Unit and DCR object are not allowed to attach. Kindly Raise ticket in TMS.");
							return ITK_err;
						}
					}
					else
					{
						printf("\n DCR_attach_method-->DML DCR attachment Validation Off)\n");fflush(stdout);
					}
					printf("\n DCR_attach_method-->DCR & DML Project Code check Validation start DCRValiinfo2: [%s]\n",DCRValiinfo2);fflush(stdout);
					if(tc_strstr(DCRValiinfo2,"ON") != NULL)
					{
						if((tc_strcmp(type_name2,"T5_DChangeReportRevision") == 0)||(tc_strcmp(type_name2,"T5_DChangeReport") == 0))
						{
							printf("\n DCR_attach_method-->DCR LC validation bypassed for CV.)\n");fflush(stdout);
						}
						else
						{
							CALLAPI(AOM_ask_value_string(secondary_object,"t5_DcrLcState",&DCR_LCState));
							printf("\n DCR_attach_method-->DCR LC state of DCR:[%s]\n",DCR_LCState);fflush(stdout);
							//if ((tc_strcmp(DCR_LCState,"DCR Approved") == 0 )||(tc_strcmp(DCR_LCState,"Under DML Release") == 0 )||(tc_strcmp(DCR_LCState,"DCR Closed") == 0 )||(tc_strcmp(DCR_LCState,"AT VLD") == 0 ))
							//if ((tc_strcmp(DCR_LCState,"DCR Approved") == 0 )||(tc_strcmp(DCR_LCState,"Under DML Release") == 0 )||(tc_strcmp(DCR_LCState,"DCR Closed") == 0 ))
							if(tc_strstr(DCRValiinfo2,DCR_LCState) != NULL)
							{
								printf("\n DCR_attach_method-->DCR is Approved or ahead or DCR approved stage. Hence allowing to attach DCR to DML...!!\n");fflush(stdout);
							}
							else
							{
								TC_write_syslog("DCR LC State is not above DCR Approved.\n");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR:DCR011:DCR not allowed to attach as, DCR LC State value should be alteast 'DCR Approved' or 'Under DML Release' to attach with DML");
								printf("\nDCR_attach_method-->DML design group and DCR design group should be same.\n");fflush(stdout);
								return ITK_err;
							}
						}
					}
					else
					{
						printf("\n DCR_attach_method-->DCR & DML Project Code check Validation Off)\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n DCR_attach_method-->Control object Not Found(DMLToGen3DCR_rel)\n");fflush(stdout);
				}
			}
		}
	}

	printf("\n DCR_attach_method-->Completed...\n");fflush(stdout);

	return ifail;
}
//End of DCR_attach validation.

int DCR_Auto_Assign( EPM_action_message_t msg )
{
	int error_code = ITK_ok;
	int ifail = 0;
	int role_nm = 0;
	int count33 = 0;
	
	tag_t root_task = NULLTAG;
	tag_t query = NULLTAG;
	tag_t objTag = NULLTAG;
	tag_t objTypTag = NULLTAG;
	tag_t DCR_Particpant_rel_type = NULLTAG;
	tag_t DCR_rel_type = NULLTAG;
	tag_t ObjTypP = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t DCR_TSK_rel_type=NULLTAG;
	tag_t group_tag = NULLTAG;

	tag_t *attachments = NULLTAG;
	tag_t *DCR_Particpant = NULLTAG;
	tag_t *DCR_Tags = NULLTAG;
	tag_t *DCRTskTag=NULLTAG;
	tag_t *role_tag = NULLTAG;
	tag_t *contrlObjs = NULLTAG;

	int i=0,j=0,count=0,PrtCount=0,n_tags_found=0,dcrCount=0;
	int jk=0 , jk2=0 , jk3=0;
	int TskCnt=0;
	int ii=0;

	char *username = NULL;
	char *user_id = NULL;
	char *Stampinfo1 = NULL;
	char *Stampinfo2 = NULL;
	char *DCR_proj = NULL;
	char *DCR_prog = NULL;
	char *DCR=NULL;
	char* DCR_Tsk_Nm=NULL;
	char* DCR_Agg=NULL;
	char* DCR_Agg_1=NULL;
				
	char personNm[SA_person_name_size_c+1] ;
	char* ObjTyp=NULL;
	char* type_name7=NULL;
	char *ProgName = (char *)MEM_alloc(20);
	char *RolenameAQ = (char *)MEM_alloc(150);

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));


	CALLAPI(EPM_ask_root_task(msg.task,&root_task));

	//POM_get_user(&username,&user_tag);
	POM_get_user_id	(&user_id);
	printf("\n\n  DCR_Auto_Assign-->Starting for USER-ID: %s....",user_id);fflush(stdout);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nDCR_Auto_Assign-->No. of attachments: %d ",count);

	    qry_values[0]  ="DCRReview";
		qry_entries[0] ="SUBSYSCD";

		ifail = QRY_find2("Control Objects...",&query);
		ifail = QRY_execute(query,1,qry_entries,qry_values,&count33,&contrlObjs);
		printf("\n DCR004: Control objects Found : count==>%d \n",count33);fflush(stdout);
		if(count33>0)
	    {
			CALLAPI(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&Stampinfo1));
			printf("\n DCA005: L1:Stampinfo1 is : [%s]\n",Stampinfo1);fflush(stdout);
			CALLAPI(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&Stampinfo2));
			printf("\n DCA005: L1:Stampinfo1 is : [%s]\n",Stampinfo1);fflush(stdout);
		}

	if(count>0)
	{
		CALLAPI(GRM_find_relation_type("HasParticipant", &DCR_Particpant_rel_type));
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_rel_type));

		for(i=0;i<count;i++)
		{
			objTag=attachments[i];

			if(AOM_ask_value_string(objTag,"item_id",&DCR)!=ITK_ok)PrintErrorStack();
			printf("\n DCR_Auto_Assign-->DCR_Number: [%s] ", DCR);fflush(stdout);

			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n DCR_Auto_Assign-->Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if ((tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0))
			{
				if(AOM_ask_value_string(objTag,"t5_DcrProCode",&DCR_proj)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(objTag,"t5_DcrAggregate",&DCR_Agg)!=ITK_ok)PrintErrorStack();
				printf("\n DCR_Auto_Assign-->1.DCR_proj: [%s].", DCR_proj);fflush(stdout);

				DCR_prog=getProgramProject(DCR_proj);
				tc_strcpy(ProgName,DCR_prog);
				tc_strcat(ProgName,".");
				tc_strcat(ProgName,"DCR");
				printf("Found Group Name is [%s]\n",ProgName);fflush(stdout);

				ifail = SA_find_group(ProgName, &group_tag);
				if(group_tag)
				{
					printf("Group Tag Found\n");fflush(stdout);
					SA_ask_roles_from_group(group_tag,&role_nm,&role_tag);

					printf("Group Found is [%d]\n",role_nm);fflush(stdout);

				}
				else
				{
					printf("Group Tag Not Found is for program name [%s]\n",ProgName);fflush(stdout);
				}

				if(role_nm > 0)
				{
					printf("\n DCR_Auto_Assign-->DCR_prog= [%s]\n",DCR_prog);fflush(stdout);

					if(GRM_list_secondary_objects_only(objTag,DCR_Particpant_rel_type,&PrtCount,&DCR_Particpant)!=ITK_ok)PrintErrorStack();
					printf("\n DCR_Auto_Assign-->PrtCount count: %d",PrtCount);fflush(stdout);
					
					for (jk=0;jk<PrtCount ;jk++ )
					{
						tag_t DCR_PartTag = DCR_Particpant[jk];

						if(TCTYPE_ask_object_type(DCR_PartTag,&ObjTypP));
						if(TCTYPE_ask_name2(ObjTypP,&type_name7));
						printf("\n DCR_Auto_Assign-->DML:2 Participants Name: %s", type_name7);fflush(stdout);
                        // New Added by rudresh:  T5_Crash_Reviewer,T5_CAE_Reviewer,T5_IDT_Reviewer,T5_MS_Reviewer,T5_TLC_Reviewer

						if (tc_strcmp(type_name7,"T5_DcrCHKLST_REV")==0  || tc_strcmp(type_name7,"T5_DcrDMU_ASSES")==0  || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_AQ")==0 || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_CS")==0 || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_FMQ")==0 || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_ICM")==0  || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_PPM")==0 || tc_strcmp(type_name7,"T5_DcrFUN_LEAD_TS")==0 || tc_strcmp(type_name7,"T5_DcrPAT_VEM")==0 || tc_strcmp(type_name7,"T5_DcrPAT_VPG")==0 || tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L2")==0 || tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L1")==0 || tc_strcmp(type_name7,"T5_Crash_Reviewer")==0 || tc_strcmp(type_name7,"T5_CAE_Reviewer")==0 || tc_strcmp(type_name7,"T5_IDT_Reviewer")==0 || tc_strcmp(type_name7,"T5_TLC_Reviewer")==0 || tc_strcmp(type_name7,"T5_MS_Reviewer")==0) 
						{
							char* DCR_Reviewr=NULL;
							if(AOM_UIF_ask_value(DCR_PartTag,"fnd0AssigneeUser",&DCR_Reviewr)!=ITK_ok)PrintErrorStack();
							printf("\n DCR_Auto_Assign-->Removing GH or CH Reviewer: [%s] ",DCR_Reviewr);fflush(stdout);
							
							AOM_lock(objTag);
							PARTICIPANT_remove_participant (objTag,DCR_PartTag);
							AOM_save_without_extensions(objTag);
							AOM_unlock(objTag);
							AOM_refresh (objTag,TRUE);
							printf("\n DCR_Auto_Assign-->REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
						}

						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCHKLST_REV","CheckList_Reviewer");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrDMU_ASSES","DMU_Reviewer");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_CS","Functional_Lead_CS");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_FMQ","Functional_Lead_QA_FMQ");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_ICM","Functional_Lead_TVM");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_PPM","Functional_Lead_P&SQ");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_TS","Functional_Lead_TS");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrPAT_VEM","PAT_VEM");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrPAT_VPG","PAT_VPG");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCHNG_AUTH_BRD_L2","Change_Author_Board_L2");
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCHNG_AUTH_BRD_L1","Change_Author_Board_L1");	//CAB-L1 Reviewer.PSS918119
						AssignDcrParticipant(objTag,DCR_prog,"T5_DcrVEH_LINE_DIR","VLD_Reviewer");
						//New added by rudresh
						if (tc_strstr(Stampinfo1,"DCRRev1")==NULL)
						{
						
							if (tc_strstr(Stampinfo2,"DCRRev2")==NULL)
							{
								AssignDcrParticipant(objTag,DCR_prog,"T5_Crash_Reviewer","Crash");
								AssignDcrParticipant(objTag,DCR_prog,"T5_CAE_Reviewer","CAE");
								AssignDcrParticipant(objTag,DCR_prog,"T5_IDT_Reviewer","IDT");
								AssignDcrParticipant(objTag,DCR_prog,"T5_MS_Reviewer","MS");
								AssignDcrParticipant(objTag,DCR_prog,"T5_TLC_Reviewer","TLC");
							}
							else
							{
								AssignDcrParticipant(objTag,DCR_prog,"T5_Crash_Reviewer","Crash Reviwer");
								AssignDcrParticipant(objTag,DCR_prog,"T5_CAE_Reviewer","CAE Reviwer");
								AssignDcrParticipant(objTag,DCR_prog,"T5_IDT_Reviewer","IDT Reviwer");
								AssignDcrParticipant(objTag,DCR_prog,"T5_MS_Reviewer","MS Reviwer");
								AssignDcrParticipant(objTag,DCR_prog,"T5_TLC_Reviewer","TLC Reviwer");						
							}
						}

						STRNG_replace_str(DCR_Agg," ","_",&DCR_Agg_1);
						 printf("DCR_Agg_1 [%s]",DCR_Agg_1);
						 RolenameAQ=tc_strcpy(RolenameAQ,"AQ_");
				         RolenameAQ=tc_strcat(RolenameAQ,DCR_Agg_1);
						 printf("RolenameAQ xxx [%s]",RolenameAQ);
						if(tc_strcmp(DCR_prog,"X4")==0 && tc_strcmp(DCR_Agg,"Others")!=0)
                        {
					
                             if(tc_strcmp(DCR_Agg,"Interior fittings(Cockpit/Console)")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Interior_Fitting");
                             }
                             else if(tc_strcmp(DCR_Agg,"Mascots")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_MASCOT");
                             }
                             else if(tc_strcmp(DCR_Agg,"Seats")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Seat");
                             }
                             else if(tc_strcmp(DCR_Agg,"Infotainment & Conn Car")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Infotainment_Connected_Cars");
                             }
                             else if(tc_strcmp(DCR_Agg,"Body Elex, ADAS & Power Supply")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Body_Elex_ADAS_Power_Supply");
                             }
                             else if(tc_strcmp(DCR_Agg,"Fuel Systems")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Fuel_System");
                             }
                             else if(tc_strcmp(DCR_Agg,"Suspension")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Suspention");
                             }
                             else if(tc_strcmp(DCR_Agg,"Brakes & Controls")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Brakes_Controls");
                             }
                             else if(tc_strcmp(DCR_Agg,"Brakes & Controls")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_Brakes_Controls");
                             }
                             else if(tc_strcmp(DCR_Agg,"EDS(Harness)")==0 )
                             {
                               AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","AQ_EDS");
                             }
                             else
                             {
                              AssignDcrParticipantAQ(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ",RolenameAQ);
                             }
                             						 
                        }
                        else 
                        {
                        AssignDcrParticipant(objTag,DCR_prog,"T5_DcrFUN_LEAD_AQ","Functional_Lead_AQ");
                        }
						
					}

					if(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_TSK_rel_type)!=ITK_ok)PrintErrorStack();
					if(GRM_list_secondary_objects_only(objTag,DCR_TSK_rel_type,&TskCnt,&DCRTskTag)!=ITK_ok)PrintErrorStack();

					for (ii=0;ii<TskCnt;ii++)
					{
						if(AOM_ask_value_string(DCRTskTag[ii],"item_id",&DCR_Tsk_Nm)!=ITK_ok)PrintErrorStack();
						printf("\n DCR_Auto_Assign-->DCR_Tsk_Nm: [%s].", DCR_Tsk_Nm);fflush(stdout);
				
						if(GRM_list_secondary_objects_only(DCRTskTag[ii],DCR_Particpant_rel_type,&PrtCount,&DCR_Particpant)!=ITK_ok)PrintErrorStack();
						printf("\n DCR_Auto_Assign-->PrtCount count: %d",PrtCount);fflush(stdout);

						for (jk2=0;jk2<PrtCount ;jk2++ )
						{
							tag_t DCR_PartTag = DCR_Particpant[jk2];
							
							if(TCTYPE_ask_object_type(DCR_PartTag,&ObjTypP));
							if(TCTYPE_ask_name2(ObjTypP,&type_name7));
							printf("\n DCR_Auto_Assign-->1.Participants Name: %s", type_name7);fflush(stdout);

							if (tc_strcmp(type_name7,"T5_DcrCOC_EE")==0 )
							{
								char* DCR_Reviewr=NULL;
								if(AOM_UIF_ask_value(DCR_PartTag,"fnd0AssigneeUser",&DCR_Reviewr)!=ITK_ok)PrintErrorStack();
								printf("\n DCR_Auto_Assign-->Removing GH or CH Reviewer: [%s] ",DCR_Reviewr);fflush(stdout);
								AOM_lock(DCRTskTag[ii]);
								PARTICIPANT_remove_participant (DCRTskTag[ii],DCR_PartTag);
								AOM_save_without_extensions(DCRTskTag[ii]);
								AOM_unlock(DCRTskTag[ii]);
								AOM_refresh (DCRTskTag[ii],TRUE);
								printf("\n DCR_Auto_Assign-->REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
							}
						}

						if (tc_strstr(DCR_Tsk_Nm,"_BIW"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","BIW_COC");
						}
						else if (tc_strstr(DCR_Tsk_Nm,"_Chassis"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","Chassis_COC");
						}
						else if (tc_strstr(DCR_Tsk_Nm,"_Engines"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","Engines_COC");
						}
						else if (tc_strstr(DCR_Tsk_Nm,"_EE"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","EE_COC");
						}
						else if (tc_strstr(DCR_Tsk_Nm,"_TA"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","TA_COC");
						}
						else if (tc_strstr(DCR_Tsk_Nm,"_Trim"))
						{
							AssignDcrParticipant(DCRTskTag[ii],DCR_prog,"T5_DcrCOC_EE","Trim_COC");
						}
					}
				}
			}
			else if (tc_strcmp(ObjTyp,"T5_DcrTaskRevision")==0)
			{
				if(GRM_list_primary_objects_only(objTag,DCR_rel_type,&dcrCount,&DCR_Tags)!=ITK_ok)PrintErrorStack();
				printf("\n DCR_Auto_Assign-->2.dcrCount==[%d] \n",dcrCount);fflush(stdout);

				if (dcrCount>0)
				{
					if(AOM_ask_value_string(DCR_Tags[0],"t5_DcrProCode",&DCR_proj)!=ITK_ok)PrintErrorStack();
					printf("\n DCR_Auto_Assign-->2.DCR_proj: [%s]", DCR_proj);fflush(stdout);

					DCR_prog=getProgramProject(DCR_proj);
				}

				printf("\n DCR_Auto_Assign-->2.REMOVE PARTICIPALNTS START.. %s \n",DCR_prog);fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,DCR_Particpant_rel_type,&PrtCount,&DCR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n DCR_Auto_Assign-->2.PrtCount count: %d",PrtCount);fflush(stdout);
				
				for (jk3=0;jk3<PrtCount ;jk3++ )
				{
					tag_t DCR_PartTag = DCR_Particpant[jk3];
					if(TCTYPE_ask_object_type(DCR_PartTag,&ObjTypP));
					if(TCTYPE_ask_name2(ObjTypP,&type_name7));
					printf("\n DCR_Auto_Assign-->2.Participants Name: %s", type_name7);fflush(stdout);

					if (tc_strcmp(type_name7,"T5_DcrCOC_EE")==0 )
					{
						char* DCR_Reviewr=NULL;
						if(AOM_UIF_ask_value(DCR_PartTag,"fnd0AssigneeUser",&DCR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n DCR_Auto_Assign-->2.Removing GH or CH Reviewer: [%s] ",DCR_Reviewr);fflush(stdout);
						AOM_lock(objTag);
						PARTICIPANT_remove_participant (objTag,DCR_PartTag);
						AOM_save_without_extensions(objTag);
						AOM_unlock(objTag);
						AOM_refresh (objTag,TRUE);
						printf("\n DCR_Auto_Assign-->2.REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
					}
				}

				if (tc_strstr(DCR,"_BIW"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","BIW_COC");
				}
				else if (tc_strstr(DCR,"_Chassis"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","Chassis_COC");
				}
				else if (tc_strstr(DCR,"_Engines"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","Engines_COC");
				}
				else if (tc_strstr(DCR,"_EE"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","EE_COC");
				}
				else if (tc_strstr(DCR,"_TA"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","TA_COC");
				}
				else if (tc_strstr(DCR,"_Trim"))
				{
					AssignDcrParticipant(objTag,DCR_prog,"T5_DcrCOC_EE","Trim_COC");
				}
			}
		}
	}

	printf("\n DCR_Auto_Assign-->Completed...\n");fflush(stdout);

	 return error_code;
}

//T5_DcrCHKLST_REV		$DCR_CHKLST_REV
//T5_DcrDMU_ASSES			$DMU_Ass
//T5_DcrFUN_LEAD_AQ		$DCR_FUN_LEAD_AQ
//T5_DcrFUN_LEAD_CS		$DCR_FUN_LEAD_CS
//T5_DcrFUN_LEAD_FMQ		$DCR_FUN_LEAD_FMQ
//T5_DcrFUN_LEAD_ICM		$DCR_FUN_LEAD_ICM
//T5_DcrFUN_LEAD_PPM		$DCR_FUN_LEAD_PPM
//T5_DcrFUN_LEAD_TS		$DCR_FUN_LEAD_TS
//T5_DcrPAT_VEM			$DCR_PAT_VEM
//T5_DcrPAT_VPG			$DCR_PAT_VPG
//T5_DcrCHNG_AUTH_BRD_L2	$DCR_CHNG_AUTH_BRD_L2
// DCR Reason check

int CheckDCRReasonCode(char* sDCRReasn)
{
	int DCRReson_rsltCount = 0;
	int DCRReason_n_entry = 1;

	char *DCRReson_qry_entry[1] = {"SYSCD"};
	char **DCRReson_qry_values2 =  (char **) MEM_alloc(10 * sizeof(char *));

	char *DCRResonInfo1 = NULL;
	char *DCRResonInfo2 = NULL;
	char *DCRResonInfo3 = NULL;
	char *DCRResonInfo4 = NULL;
	char *DCRResonInfo5 = NULL;
	char *DCRResonInfo6 = NULL;
	char *DCRResonInfo7 = NULL;
	char *DCRResonInfo8 = NULL;
	char *DCRResonInfo9 = NULL;
	char *DCRResonInfo10 = NULL;
	char *sDCRReason = NULL;

	tag_t *DCRResonCntrlObjectTag = NULLTAG;
	tag_t DCRResonTag = NULLTAG;

	sDCRReason=(char *)MEM_alloc(200);

	printf("\n\n Start of CheckDCRReasonCode-->sDCRReasn: %s ", sDCRReasn);fflush(stdout);
	
	tc_strcpy(sDCRReason,"");
	tc_strcpy(sDCRReason,",");
	tc_strcat(sDCRReason,sDCRReasn);
	tc_strcat(sDCRReason,",");
	printf("\n CheckDCRReasonCode-->sDCRReason: %s",sDCRReason);fflush(stdout);

	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &DCRResonTag));
	if (DCRResonTag)
	{
		printf("\n CheckDCRReasonCode-->P1:Found Query DCRResonTag \n");fflush(stdout);
	}
	else
	{
		printf("\n CheckDCRReasonCode-->P2:Not Found Query DCRResonTag \n");fflush(stdout);
	}

	DCRReson_qry_values2[0] = "DCRReason";
	
	if(QRY_execute(DCRResonTag, DCRReason_n_entry, DCRReson_qry_entry, DCRReson_qry_values2, &DCRReson_rsltCount, &DCRResonCntrlObjectTag));
	printf(" \n CheckDCRReasonCode-->P3:DR_rsltCount :%d:", DCRReson_rsltCount); fflush(stdout);
	
	if(DCRReson_rsltCount > 0)
	{
		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo1",&DCRResonInfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo1 is : [%s]\n", DCRResonInfo1);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo2",&DCRResonInfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo2 is : [%s]\n", DCRResonInfo2);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo3",&DCRResonInfo3)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo3 is : [%s]\n", DCRResonInfo3);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo4",&DCRResonInfo4)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo4 is : [%s]\n", DCRResonInfo4);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo5",&DCRResonInfo5)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo5 is : [%s]\n", DCRResonInfo5);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo6",&DCRResonInfo6)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo6 is : [%s]\n", DCRResonInfo6);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo7",&DCRResonInfo7)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo7 is : [%s]\n", DCRResonInfo7);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo8",&DCRResonInfo8)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo8 is : [%s]\n", DCRResonInfo8);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_Userinfo9",&DCRResonInfo9)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo9 is : [%s]\n", DCRResonInfo9);fflush(stdout);

		if (AOM_ask_value_string(DCRResonCntrlObjectTag[0],"t5_userinfo10",&DCRResonInfo10)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckDCRReasonCode-->P4:DCRResonInfo10 is : [%s]\n", DCRResonInfo10);fflush(stdout);

		if((tc_strstr(DCRResonInfo1,sDCRReason)!=NULL)|| (tc_strstr(DCRResonInfo2,sDCRReason)!=NULL) || (tc_strstr(DCRResonInfo3,sDCRReason)!=NULL) ||
			(tc_strstr(DCRResonInfo4,sDCRReason)!=NULL)|| (tc_strstr(DCRResonInfo5,sDCRReason)!=NULL)|| (tc_strstr(DCRResonInfo6,sDCRReason)!=NULL)||
			(tc_strstr(DCRResonInfo7,sDCRReason)!=NULL)|| (tc_strstr(DCRResonInfo8,sDCRReason)!=NULL)|| (tc_strstr(DCRResonInfo9,sDCRReason)!=NULL)|| 
			(tc_strstr(DCRResonInfo10,sDCRReason)!=NULL))
		{
			printf("\n CheckDCRReasonCode-->It DCR Reason code found...: %s \n", sDCRReason);fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n CheckDCRReasonCode-->It is DCR Reason code not found: %s \n", sDCRReason);fflush(stdout);
			return 0;
		}
	}

	return 0;
}

//Validation for DCR mandatory according to DR status of earlier released revision.(added by kalpesh)
extern EPM_decision_t DLLAPI Check_DCR_required(EPM_rule_message_t msg)
{
	int i							= 0;
	int j							= 0;
	int k							= 0;
	int l							= 0;
	int dc							= 0;
	int ifail						= 0;
	int count						= 0;
	int task_cnt					= 0;
	int dml_cnt						= 0;
	int rev_cnt						= 0;
	int ECUflag						= 0;
	int prt_cnt						= 0;
	int status_cnt					= 0;
	int DCR_cnt						= 0;
	int partRevflag					= 0;
	int DR2Flag						= 0;
	int DR3Flag						= 0;
	int DR4Flag						= 0;
	int DCR_n_entry = 1;
	int DCR_rsltCount =	0;

	logical		is_latest;

	char *dr_status					= NULL;
	char *status_name				= NULL;
	char *CurrentTask				= NULL;
	char *release_type				= NULL;
	char *DMLReason					= NULL;

	tag_t *attachments				= NULL;
	tag_t *task_list				= NULL;
	tag_t *dml_list					= NULL;
	tag_t *part_list				= NULL;
	tag_t *rev_list					= NULL;
	tag_t *status_list				= NULL;
	tag_t *DCR_list					= NULL;
	tag_t *DCRCntrlObjectTag		= NULLTAG;

	tag_t DMLTag					= NULLTAG;
	tag_t part_tag					= NULLTAG;
	tag_t root_task					= NULLTAG;
	tag_t TaskRelType				= NULLTAG;
	tag_t PartRelType				= NULLTAG;
	tag_t DCR_RelType				= NULLTAG;
	tag_t DCRqryTag					= NULLTAG;


	char    *DCR_qry_entry[1]	=	{"SYSCD"};
	char    **DCR_qry_values2   =  (char **) MEM_alloc(100 * sizeof(char *));
	
	char *DCRinfo1 =	NULL;
	char *DCRinfo3 =	NULL;
	char *DCRinfo7 =	NULL;
	char *part_type = NULL;
	char *partRevision = NULL;
	char *partSeq = NULL;
	char *partRevStr = NULL;
	char *StrPartType =	NULL;
	char *StrDmlRlzType =	NULL;
	char *itemIDNm =	NULL;
	char *DMLRlztype = NULL;
	char *DMLPrtCd = NULL;
	char *DMLID = NULL;
	char *DR2Prt = NULL;
	char *DMLBU = NULL;

	StrPartType =(char *)MEM_alloc(10);
	StrDmlRlzType =(char *)MEM_alloc(50);

	EPM_decision_t decision = EPM_go;

	printf("\n inside Check_DCR_required handler...!!\n"); fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	//printf("\ninside Check_DCR_required\n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCheck_DCR_required-->CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\nCheck_DCR_required-->Number of attachments:[%d]\n",count);	fflush(stdout);

	if(count > 0)
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &TaskRelType));
		CALLAPI(GRM_list_primary_objects_only(attachments[i], TaskRelType, &dml_cnt, &dml_list));//Task to DML
		printf("\nCheck_DCR_required-->DML count:[%d]\n", dml_cnt);

		for(dc=0; dc<dml_cnt; dc++)
		{
			ITKCALL(ITEM_rev_sequence_is_latest(dml_list[dc],&is_latest));
			printf("\n\n\t\t Check_DCR_required-->is_latest : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\n Check_DCR_required-->Not latest DML Revision.....\n");fflush(stdout);
			}
			else
			{
				DMLTag = dml_list[dc];//DML Tag
			}
		}

		if (DMLTag != NULLTAG)
		{
			CALLAPI(AOM_UIF_ask_value(DMLTag, "t5_rlstype", &release_type)); 
			CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRlztype));
			CALLAPI(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLPrtCd));
			CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&DMLID));
			CALLAPI(AOM_ask_value_string(DMLTag,"t5_ERCBusiUt",&DMLBU));
			printf("\n Check_DCR_required-->DML_Number==>[%s] DMLRlztype==> [%s] ReleaseType==> [%s] Project Code==> [%s] Business Unit==> [%s]",DMLID,DMLRlztype,release_type,DMLPrtCd,DMLBU);fflush(stdout);
			CALLAPI(AOM_ask_value_string(DMLTag,"t5_DmlReasonDisplay",&DMLReason));
			printf("\n Check_DCR_required-->Reason code of DML:[%s]\n",DMLReason);fflush(stdout);

			tc_strcpy(StrDmlRlzType,"");
			tc_strcpy(StrDmlRlzType,",");
			tc_strcat(StrDmlRlzType,DMLRlztype);
			tc_strcat(StrDmlRlzType,",");

			printf("\n Check_DCR_required-->A.StrDmlRlzType==>[%s] ",StrDmlRlzType);fflush(stdout);

			CALLAPI(GRM_find_relation_type("CMImplements",&DCR_RelType));
			CALLAPI(GRM_list_secondary_objects_only(DMLTag,DCR_RelType,&DCR_cnt,&DCR_list));

			printf("\n Check_DCR_required-->DCR_cnt attached to DML==> [%d] ", DCR_cnt);fflush(stdout);

			if(QRY_find2("ControlObjects", &DCRqryTag));
			if (DCRqryTag != NULLTAG)
			{
				printf("\n Check_DCR_required-->DCRVali:Found Query ControlObjects \n");fflush(stdout);
				
				DCR_qry_values2[0] = "DCRVali";

				if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
			}
			else
			{
				printf("\n Check_DCR_required-->DCRVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			printf(" \n Check_DCR_required-->DCRVali:DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
			if(DCR_rsltCount > 0)
			{
				if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo1",&DCRinfo1)!=ITK_ok)   PrintErrorStack();
				printf("\n Check_DCR_required-->DCRinfo1: %s ", DCRinfo1);fflush(stdout);

				if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo3",&DCRinfo3)!=ITK_ok)   PrintErrorStack();
				printf("\n Check_DCR_required-->DCRinfo3: %s --DML-Release-Types \n", DCRinfo3);fflush(stdout);

				if (tc_strstr(DCRinfo1,DMLID)==NULL)
				{
					ECUflag=0;
					//printf("\n Check_DCR_required-->DCR Project is live. [%d] \n", DMLPrtCd);fflush(stdout);
					if(tc_strstr(DCRinfo3,StrDmlRlzType)!=NULL)
					{
						for(i=0; i<count; i++)
						{
							CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &PartRelType));
							CALLAPI(GRM_list_secondary_objects_only(attachments[i],PartRelType, &prt_cnt, &part_list));
							
							printf("\n Check_DCR_required-->Part Count:[%d] ", prt_cnt); fflush(stdout);

							printf("\n Check_DCR_required-->Inside the PVBU Unit loop",DMLBU); fflush(stdout);
							if(prt_cnt > 0)
							{
								for(j=0; j<prt_cnt; j++)
								{
									partRevflag=0;
									DR2Flag = 0;

									if(part_list[j] == NULLTAG)
									{
										printf("\n Check_DCR_required-->part_tag not found...!! Hence continuing\n");fflush(stdout);
										continue;
									}

									CALLAPI(AOM_ask_value_string(part_list[j],"item_id", &itemIDNm));
									CALLAPI(AOM_ask_value_string(part_list[j],"t5_PartType", &part_type));
									CALLAPI(AOM_ask_value_string(part_list[j],"item_revision_id", &partRevision));
									CALLAPI(AOM_UIF_ask_value(part_list[j],"IMAN_master_form_rev", &partSeq));
									//CALLAPI(AOM_UIF_ask_value(part_list[j],"sequence_id", &partSeq));
									CALLAPI(AOM_ask_value_string(part_list[j],"t5_PartStatus", &DR2Prt));
									printf("\n Check_DCR_required-->DCRVali:part type=[%s] & Item ID=[%s] & Part DR=[%s] ",part_type,itemIDNm,DR2Prt); fflush(stdout);
									if ((tc_strcmp(DR2Prt,"DR2") == 0) ||(tc_strcmp(DR2Prt,"AR2") == 0))
									{
										DR2Flag = 1;
										printf("\n Check_DCR_required-->part_tag DR2 Flag Set\n");fflush(stdout);	
									}

									tc_strcpy(StrPartType,"");
									tc_strcpy(StrPartType,",");
									tc_strcat(StrPartType,part_type);
									tc_strcat(StrPartType,",");

									if (tc_strstr(partRevision,";")!=NULL)
									{
										partRevStr=strtok(partRevision,";");
									}

									printf("\n Check_DCR_required-->itemIDNm: [%s] Part_Rev[%s] part_type: [%s]  StrPartType: [%s]  DCRinfo1: [%s]\n",itemIDNm,partSeq,part_type,StrPartType,DCRinfo1);fflush(stdout);
									printf("\n Check_DCR_required-->itemIDNm: [%s] partRevStr: [%s] \n",itemIDNm,partRevStr);fflush(stdout);

									//if (tc_strstr(DCRinfo1,StrPartType)==NULL)
									if ((DCRinfo1 != NULL)&&(tc_strstr(DCRinfo1,StrPartType)==NULL)&&(tc_strcmp(partRevStr,"NR")!=0))
									{
										printf("\n Check_DCR_required-->DCRVali:part type=[%s] & Item ID=[%s] ",part_type,itemIDNm); fflush(stdout);

										CALLAPI(ITEM_ask_item_of_rev(part_list[j], &part_tag));
										//printf("\nPart revisions count taken:[%d]\n", j); fflush(stdout);
										CALLAPI(ITEM_list_all_revs(part_tag, &rev_cnt, &rev_list));

										printf("\nCheck_DCR_required-->Part has revisions after:[%d]\n", rev_cnt); fflush(stdout);
										//First time DR3 released revision skip,ADD code for this validation. and skip NR revision for DR validation
										for(k=rev_cnt-1; k>=0; k--)
										{
											//printf("\n Check_DCR_required-->count K- taken:[%d]\n", k); fflush(stdout);
											CALLAPI(WSOM_ask_release_status_list (rev_list[k], &status_cnt, &status_list));
											
											printf("\n Check_DCR_required-->status_cnt:[%d] ", status_cnt); fflush(stdout);
											if(status_cnt > 0)
											{
												for(l=0; l<status_cnt; l++)
												{
													CALLAPI(AOM_ask_value_string (status_list[l], "object_name", &status_name));
													printf("\n Check_DCR_required-->Chld_Rel_Stus: [%s]", status_name);fflush(stdout);

													if((tc_strcmp(status_name,"ERC Released") == 0) || (tc_strcmp(status_name,"T5_LcsErcRlzd") == 0))
													{
														CALLAPI(AOM_UIF_ask_value(rev_list[k], "t5_PartStatus", &dr_status));
														printf("\n Check_DCR_required-->AR/DR status:%s", dr_status);fflush(stdout);
														//DMLRlztype: for ECU check only DR4/5 parts revision
														if((tc_strcmp(DMLRlztype, "ECU Parts Release") == 0)||(tc_strcmp(DMLRlztype, "EP") == 0))
														{
															printf("\n Check_DCR_required-->ECU DML.."); fflush(stdout);
															if((tc_strcmp(dr_status, "DR4") == 0) || (tc_strcmp(dr_status, "DR5")  == 0) || (tc_strcmp(dr_status, "AR4") == 0) || (tc_strcmp(dr_status, "AR5")  == 0))
															{
																ECUflag=1;
																printf("\n Check_DCR_required-->ECU DML..DR4 or DR5..:%d",ECUflag); fflush(stdout);
															}
														}
														else if((tc_strcmp(dr_status, "DR3") == 0) || (tc_strcmp(dr_status, "DR3P") == 0) ||
															(tc_strcmp(dr_status, "DR4") == 0) || (tc_strcmp(dr_status, "DR5")  == 0) ||
															(tc_strcmp(dr_status, "AR3") == 0) || (tc_strcmp(dr_status, "AR3P") == 0) ||
															(tc_strcmp(dr_status, "AR4") == 0) || (tc_strcmp(dr_status, "AR5")  == 0)
														  )
														{
															ECUflag=1;
															printf("\n Check_DCR_required-->Other DML..DR3 above..:%d",ECUflag); fflush(stdout);
														}
														if(ECUflag >0)
														{
															printf("\n Check_DCR_required-->In check-- DCR_cnt:[%d] StrDmlRlzType: [%s] DCRinfo3: [%s]",DCR_cnt,StrDmlRlzType,DCRinfo3);fflush(stdout);

															//if(tc_strstr(DCRinfo3,StrDmlRlzType)!=NULL)

															//{
																if(DCR_cnt > 0)
																{
																	printf("\nCheck_DCR_required-->DCR already present under DML");fflush(stdout);
																	decision = EPM_go;
																	partRevflag=1;
																	break;
																}
																else
																{
																	char* DCRAttachError=NULL;
																	DCRAttachError = (char	*)MEM_alloc(600);

																	tc_strcpy(DCRAttachError,"DCR is not attached with DML Revision.Kindly attach Approved DCR with DML Revision in Implements relation \n DCR Required due to Part : ");
																	tc_strcat(DCRAttachError,partSeq);

																	printf("\nCheck_DCR_required-->Else condition of DCR attached");fflush(stdout);
																	printf("\nNo DCR attached to DML, Hence returning EPM_nogo\n %s\n",DCRAttachError);fflush(stdout);
																	//EMH_store_error_s1(EMH_severity_error,ITK_err,"\tDCR is not attached with DML Revision.Kindly attach Approved DCR with DML Revision in Implements relation\t");
																	EMH_store_error_s1(EMH_severity_error,ITK_err,DCRAttachError);
																	return EPM_nogo;
																}
															//}
														}
														//break;
													}
												}

												printf("\n Check_DCR_required-->partRevflag: [%d] \n",partRevflag); fflush(stdout);

												if (partRevflag>0)
												{
													break;
												}
											}
										} //end of for loop==rev_cnt
									}
									else
									{
										printf("\n\t Check_DCR_required-->DCRVali: Skipping DCR check for rev=NR or parttype= %s of Item ID =%s \n",part_type,itemIDNm); fflush(stdout);
									}
								} //end of for loop==prt_cnt
							}
						}
					}
				}
				else
				{
					printf(" \n *************Check_DCR_required-->DCR Check is off ***************"); fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n Check_DCR_required-->DMLTag not found....\n");fflush(stdout);
		}
	}

	printf("\n Check_DCR_required-->Completed \n"); fflush(stdout);

	return decision;
}//End of DCR mandatory validation.

extern EPM_decision_t DLLAPI Chk_DCR_active(EPM_rule_message_t msg)
{
	int TskCnt = 0;
	int DCR_rsltCount = 0;
	int DCR_n_entry = 1;
	int ifail=0,count=0,n_parents=0;
	int status = ITK_ok;

	char* CurrentTask = NULL;
	char* t5current_name = NULL;
	char* procedure_name = NULL;
	char* Tr_Domain_Approved = NULL;
	char* sChingmt = NULL;
	char* TR_Domain = NULL;
	char *DCR_proj = NULL;
	char *DCR_prog = NULL;
	char *DCRinfo1 = NULL;
	char *ProgName = (char *)MEM_alloc(20);
	char* type_name=NULL;
	char *sTanInfo1 = NULL;
	
	int FlagValidation=0;
	int CruuentFlag=0;
	int ProposedFlag=0;
	int FitmentFlag=0;
	int role_nm = 0;

	tag_t group_tag = NULLTAG;
	tag_t *role_tag = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *parents = NULLTAG;

	tag_t root_task = NULLTAG;
	tag_t DcrLcmTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t DCR_TSK_rel_type = NULLTAG;
	tag_t *DCRTskTag = NULLTAG;
	tag_t DCRqryTag = NULLTAG;
	tag_t *DCRCntrlObjectTag = NULLTAG;
	tag_t query = NULLTAG;
	tag_t *contrlObjs = NULL;

	char    *DCR_qry_entry[1]	=	{"SYSCD"};
	char    **DCR_qry_values2   =  (char **) MEM_alloc(100 * sizeof(char *));

	logical t5InProcess;

	EPM_decision_t decision = EPM_go;
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\ninside Chk_DCR_active ------- \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Chk_DCR_active-->CurrentTask: %s ",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  Chk_DCR_active-->no.of attachments: %d ",count);

	
	char **qry_entries = (char **) MEM_alloc(sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(sizeof(char *));


	qry_entries[0] ="SYSCD";
	qry_values[0]  ="DCR_Workflow";

	ITK_CALL(QRY_find2("Control Objects...", &query));
	ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
	printf("\n Control objects : count==>%d \n",count);fflush(stdout);
	if (count>0)
	{
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sTanInfo1));
		//ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sTanInfo2));
		//ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sTanInfo3));
		//ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sTanInfo4));
		printf("\n L1:sTanInfo1 is : [%s] \n",sTanInfo1);fflush(stdout);
		DcrLcmTag = attachments[0];

		if(tc_strstr(sTanInfo1,"OFF") == NULL)
		{
			CALLAPI(AOM_ask_value_string(DcrLcmTag,"item_id",&t5current_name));
			printf("\n Chk_DCR_active-->DCR name:%s",t5current_name);fflush(stdout);

			//CALLAPI(EPM_ask_active_job_for_target(DcrLcmTag,&n_parents,&parents));
			AOM_ask_value_tags(DcrLcmTag,"fnd0AllWorkflows",&n_parents,&parents);
			printf("\n Chk_DCR_active-->parent count: %d ",n_parents); fflush(stdout);

			if (n_parents>1)
			{
				//CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
				//printf("\n Chk_DCR_active-->procedure: %s ",procedure_name); fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "DCR Object is already submitted in Lifecycle, Please abort the DCR and then resubmit into workflow.");
				decision = EPM_nogo;
				
				return decision;
			}
		}
		else
		{
			decision = EPM_go;
		}
	}

		if(QRY_find2("ControlObjects", &DCRqryTag))
		if (DCRqryTag != NULLTAG)
		{
			printf("\n Chk_DCR_active-->-->DCRVali:Found Query ControlObjects \n");fflush(stdout);
			
			DCR_qry_values2[0] = "DCRVali";

			if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
		}
		else
		{
			printf("\n Chk_DCR_active-->-->DCRVali:Not Found Query ControlObjects \n");fflush(stdout);
		}

		printf(" \n Chk_DCR_active-->-->DCRVali:DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
		if(DCR_rsltCount > 0)
		{
			if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo1",&DCRinfo1)!=ITK_ok)   PrintErrorStack();
			printf("\n Chk_DCR_active-->-->DCRinfo1: %s ", DCRinfo1);fflush(stdout);
		}

		//Start -DCR Project code validation
		if(AOM_ask_value_string(DcrLcmTag,"t5_DcrProCode",&DCR_proj)!=ITK_ok)PrintErrorStack();
		printf("\n DCR_Auto_Assign-->1.DCR_proj: [%s].", DCR_proj);fflush(stdout);

		DCR_prog=getProgramProject(DCR_proj);
		if(DCR_prog != NULL)
		{
			tc_strcpy(ProgName,DCR_prog);
			tc_strcat(ProgName,".");
			tc_strcat(ProgName,"DCR");
		}
		printf("Found Group Name is [%s]\n",ProgName);fflush(stdout);

		ifail = SA_find_group(ProgName, &group_tag);
		if(group_tag)
		{
			printf("Group Tag Found\n");fflush(stdout);
			SA_ask_roles_from_group(group_tag,&role_nm,&role_tag);

			printf("Group Found is [%d]\n",role_nm);fflush(stdout);
		}
		else
		{
			printf("Group Tag Not Found is for program name [%s]\n",ProgName);fflush(stdout);
		}
		if(role_nm == 0)			
		{
			EMH_clear_errors();

			TC_write_syslog("DCR_attach_method-->Roles found in Group is not valid\n");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"DCR workflow is not live for selected project code. Kindly contact to chief engineer to make it live in TCUA.");
			printf("\nDCR_attach_method-->Group Tag Not Found is for program name\n");fflush(stdout);

			decision = EPM_nogo;

			return decision;
		}
		else
		{
			decision = EPM_go;
		}

		//End -DCR Project code validation


		CALLAPI(TCTYPE_ask_object_type (DcrLcmTag, &objTypeTag));
		CALLAPI(TCTYPE_ask_name2( objTypeTag,&type_name));
		printf("\n\t Chk_DCR_active-->type_name ==> %s\n", type_name);fflush(stdout);

		if(tc_strcmp(type_name,"T5_GenDcrChngRepRevision")==0)
		{
			char* DCR_reason=NULL;
			CALLAPI(AOM_ask_value_string(DcrLcmTag,"t5_DcrCreRC",&DCR_reason));
			printf("\n Chk_DCR_active-->DCR_reason:%s",DCR_reason);fflush(stdout);

			FlagValidation=0;
			FlagValidation = CheckDCRReasonCode(DCR_reason);
			printf("\n Chk_DCR_active-->P3:FlagValidation: %d",FlagValidation);fflush(stdout);

			if (FlagValidation==1)
			{

				tag_t *secondary_objects=NULL;
				int count=0;
				CALLAPI(AOM_ask_value_tags(DcrLcmTag,"IMAN_reference",&count,&secondary_objects));
				char* E8D_STR=NULL;
				E8D_STR = (char	*)MEM_alloc(600);

				tc_strcpy(E8D_STR,"RCA-8D-");
				tc_strcat(E8D_STR,t5current_name);
				printf("\n\t Chk_DCR_active-->8D_STR ==> %s  count= %d \n", E8D_STR,count);fflush(stdout);

				int prereqdocflag=0,i=0;
				char* DocName = NULL;

				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						printf("\n Chk_DCR_active-->under loop= [%d]",i);fflush(stdout);

						CALLAPI(AOM_ask_value_string(secondary_objects[i],"object_string" , &DocName));
						//CALLAPI(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
						//CALLAPI(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
						//CALLAPI(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
						printf("\n Chk_DCR_active-->Document Name= %s",DocName);fflush(stdout);

						if(tc_strstr(DocName,E8D_STR)!=NULL)
						{
							printf("\n Valid PreReqDoc available> %s",DocName);fflush(stdout);
							prereqdocflag++;
							break;
						}
					}
				}

				printf("\n Chk_DCR_active-->prereqdocflag= %d",prereqdocflag);fflush(stdout);
				if(prereqdocflag>0)
				{
					printf("\n Chk_DCR_active-->EPM_go for Valid PreReqDoc available");fflush(stdout);
					//decision = EPM_go;

					//return decision;
				}
				else
				{
					char* E8D_STR_ERR=NULL;
					E8D_STR_ERR = (char	*)MEM_alloc(600);
					
					tc_strcpy(E8D_STR_ERR,t5current_name);
					tc_strcat(E8D_STR_ERR," must have the following Pre-requisites document in below standard naming format for given reason code,Please attach with Reference Folder");
					tc_strcat(E8D_STR_ERR,"\n");
					tc_strcat(E8D_STR_ERR,E8D_STR);
					printf("\n\n\t\t Chk_DCR_active-->8D_STR_ERR ==> %s\n", E8D_STR_ERR);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, E8D_STR_ERR);
					decision = EPM_nogo;
					return decision;
				}
			}
			//For Geomerty change.
			printf("\n Chk_DCR_active-->For Geomerty change..........");fflush(stdout);
			if(AOM_ask_value_string(DcrLcmTag,"t5_Chingmt",&sChingmt)!=ITK_ok)PrintErrorStack();
			printf("\n Chk_DCR_active-->sChingmt OBJ ID: [%s].", sChingmt);fflush(stdout);
			
			if((strcmp(sChingmt,"No")==0)||(strcmp(sChingmt,"NO")==0))
			{
				printf("\n Chk_DCR_active-->No need to check attachments: [%s].", sChingmt);fflush(stdout);
			}
			else
			{
				printf("\n Chk_DCR_active-->Check for attachments: [%s].", sChingmt);fflush(stdout);
				//to check Current & Proposed geometry view of part, if Yes, then DCR should have attachment.
				// DCR to relation and check attachment.
				tag_t *sec_dcrattaches=NULL;
				int count=0;
				CALLAPI(AOM_ask_value_tags(DcrLcmTag,"T5_CMDCRHasAttaches",&count,&sec_dcrattaches));
				char* cGeometry_STR=NULL;
				cGeometry_STR = (char	*)MEM_alloc(600);
				char* pGeometry_STR=NULL;
				pGeometry_STR = (char	*)MEM_alloc(600);

				tc_strcpy(cGeometry_STR,"Current_Geometry_");
				tc_strcat(cGeometry_STR,t5current_name);
				
				printf("\n\n\t\t Chk_DCR_active-->doc name1 ==> %s\n", cGeometry_STR);fflush(stdout);
				
				tc_strcpy(pGeometry_STR,"Proposed_Geometry_");
				tc_strcat(pGeometry_STR,t5current_name);
				
				printf("\n\n\t\t Chk_DCR_active-->doc name2 ==> %s\n", pGeometry_STR);fflush(stdout);

				printf("\n Chk_DCR_active-->count= %d \n",count);fflush(stdout);
				int i=0;
				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						char* DocName=NULL;
						printf("\n Chk_DCR_active-->under loop> %d",i);fflush(stdout);
						CALLAPI(AOM_ask_value_string(sec_dcrattaches[i],"object_string" , &DocName));
						printf("\n Chk_DCR_active-->Document Name= %s",DocName);fflush(stdout);
						if(tc_strstr(DocName,cGeometry_STR)!=NULL)
						{
							printf("\n Chk_DCR_active-->Valid cGeometry_STR available> %s",DocName);fflush(stdout);
							CruuentFlag++;
						}
						if(tc_strstr(DocName,pGeometry_STR)!=NULL)
						{
							printf("\n Chk_DCR_active-->Valid pGeometry_STR available> %s",DocName);fflush(stdout);
							ProposedFlag++;
						}
					}
				}
				if ((ProposedFlag >0)  && (CruuentFlag >0))
				{
					printf("\n Chk_DCR_active-->Both Valid Geometry docs available.");fflush(stdout);
				}
				else
				{
					char* FGeometry_STR=NULL;
					FGeometry_STR = (char	*)MEM_alloc(600);
					tc_strcpy(FGeometry_STR,t5current_name);
					tc_strcat(FGeometry_STR," must have the following geometry document in below standard naming format,Please attach with 'DCR Has Attachments' Folder");
					tc_strcat(FGeometry_STR,"\n");
					tc_strcat(FGeometry_STR,cGeometry_STR);
					tc_strcat(FGeometry_STR,"\n");
					tc_strcat(FGeometry_STR,pGeometry_STR);
					printf("\n\n\t\t Chk_DCR_active-->geomentry doc ==> %s\n", FGeometry_STR);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, FGeometry_STR);
					decision = EPM_nogo;
					return decision;
				}
			}
			//Fitment View check
			printf("\n Chk_DCR_active-->Check for Fitment View check attachment.");fflush(stdout);
			//to check Current & Proposed geometry view of part, if Yes, then DCR should have attachment.
			// DCR to relation and check attachment.
			tag_t *sec_Fitattaches=NULL;
			int count=0;
			CALLAPI(AOM_ask_value_tags(DcrLcmTag,"T5_CMDCRHasAttaches",&count,&sec_Fitattaches));
			char* Fitment_STR=NULL;
			Fitment_STR = (char	*)MEM_alloc(600);
			//Fitment_View_DCR.....
			tc_strcpy(Fitment_STR,"Fitment_View_");
			tc_strcat(Fitment_STR,t5current_name);
			printf("\n\n\t\t Chk_DCR_active-->doc name1 ==> %s\n", Fitment_STR);fflush(stdout);
			printf("\n Chk_DCR_active-->Fitment count= %d \n",count);fflush(stdout);
			int i=0;
			if(count>0)
			{
				for(i=0;i<count;i++)
				{
					char* DocName=NULL;
					printf("\n Chk_DCR_active-->Fitment under loop> %d",i);fflush(stdout);
					CALLAPI(AOM_ask_value_string(sec_Fitattaches[i],"object_string" , &DocName));
					printf("\n Chk_DCR_active-->Fitment Document Name= %s",DocName);fflush(stdout);
					if(tc_strstr(DocName,Fitment_STR)!=NULL)
					{
						printf("\n Chk_DCR_active-->Valid Fitment_STR available> %s",DocName);fflush(stdout);
						FitmentFlag++;
						break;
					}
				}
			}
			if (FitmentFlag >0)
			{
				printf("\n Chk_DCR_active-->Both Valid Fitment_View_ doc available.");fflush(stdout);
			}
			else
			{
				char* sFitment_STR=NULL;
				sFitment_STR = (char	*)MEM_alloc(600);
				tc_strcpy(sFitment_STR,t5current_name);
				tc_strcat(sFitment_STR," must have the following Fitment view document in below standard naming format,Please attach with 'DCR Has Attachments' Folder");
				tc_strcat(sFitment_STR,"\n");
				tc_strcat(sFitment_STR,Fitment_STR);
				printf("\n\n\t\t Chk_DCR_active-->fitment ==> %s\n", sFitment_STR);fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, sFitment_STR);
				decision = EPM_nogo;
				return decision;
			}
			if (tc_strstr(DCRinfo1,"ChkTsk")==NULL)
			{
				if(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_TSK_rel_type)!=ITK_ok)PrintErrorStack();
				if(GRM_list_secondary_objects_only(DcrLcmTag,DCR_TSK_rel_type,&TskCnt,&DCRTskTag)!=ITK_ok)PrintErrorStack();
				printf("\n Chk_DCR_active-->-->DCR Task found count is:%d",TskCnt);fflush(stdout);

				if (TskCnt != 6)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Select Gen3-DCR Revision Task, Tasks are not created, Please raise ticket to DCR Catagory or Create new DCR.");
					decision = EPM_nogo;
					return decision;
				}
			}

		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Select Gen3-DCR Revision and then submit it");
			decision = EPM_nogo;
			return decision;
		}

	printf("\n\t Chk_DCR_active-->Completed..........\n");fflush(stdout);

	return decision;
}

//Prasad
extern EPM_decision_t tm_Chk_DCRTaskInWf(EPM_rule_message_t msg)
{
	char* CurrentTask = NULL;
	char* t5current_name = NULL;
	char* procedure_name = NULL;
	char* Tr_Domain_Approved = NULL;
	char* sChingmt = NULL;
	char* TR_Domain = NULL;
	char *DCR_proj = NULL;
	char *DCR_prog = NULL;
	char* DCR_Tsk_Nm = NULL;
	char* DCRinfo1 = NULL;
	char* nameofroot = NULL;
	char *ProgName = (char *)MEM_alloc(20);
	char* type_name=NULL;
	
	int FlagValidation=0;
	int CruuentFlag=0;
	int ProposedFlag=0;
	int FitmentFlag=0;
	int role_nm = 0;
	int ii = 0;
	int TskCnt = 0;
	int DCR_n_entry = 1;
	int DCR_rsltCount = 0;
	int ifail=0,count=0,n_parents=0;
	char    *DCR_qry_entry[1]	=	{"SYSCD"};
	char    **DCR_qry_values2   =  (char **) MEM_alloc(100 * sizeof(char *));

	tag_t group_tag = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *role_tag = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t *DCRCntrlObjectTag = NULLTAG;

	tag_t root_task = NULLTAG;
	tag_t DcrLcmTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t DCRqryTag = NULLTAG;
	tag_t job = NULLTAG;
	tag_t job_type = NULLTAG;
	tag_t roottask = NULLTAG;
	
	logical t5InProcess;

	EPM_decision_t decision = EPM_go;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\ninside tm_Chk_DCRTaskInWf ------- \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n tm_Chk_DCRTaskInWf-->CurrentTask: %s ",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  tm_Chk_DCRTaskInWf-->no.of attachments: %d ",count);

	if(QRY_find2("ControlObjects", &DCRqryTag));
	if (DCRqryTag != NULLTAG)
	{
		printf("\n tm_Chk_DCRTaskInWf-->DCRVali:Found Query ControlObjects \n");fflush(stdout);
		
		DCR_qry_values2[0] = "DCRVali";

		if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
	}
	else
	{
		printf("\n tm_Chk_DCRTaskInWf-->DCRVali:Not Found Query ControlObjects \n");fflush(stdout);
	}

	printf(" \n tm_Chk_DCRTaskInWf-->DCRVali:DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
	if(DCR_rsltCount > 0)
	{
		if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo1",&DCRinfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n tm_Chk_DCRTaskInWf-->DCRinfo1: %s ", DCRinfo1);fflush(stdout);

		if (tc_strstr(DCRinfo1,"DCRChkTsk")==NULL)
		{
			printf("\n------- tm_Chk_DCRTaskInWf-->is live------- ");fflush(stdout);
			if(count > 0)
			{
				DcrLcmTag = attachments[0];
				CALLAPI(AOM_ask_value_string(DcrLcmTag,"item_id",&t5current_name));
				printf("\n tm_Chk_DCRTaskInWf-->DCR name:%s",t5current_name);fflush(stdout);

				tag_t DCR_TSK_rel_type=NULLTAG;
				tag_t *DCRTskTag=NULL;
				
				if(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_TSK_rel_type)!=ITK_ok)PrintErrorStack();
				if(GRM_list_secondary_objects_only(DcrLcmTag,DCR_TSK_rel_type,&TskCnt,&DCRTskTag)!=ITK_ok)PrintErrorStack();
				printf("\n tm_Chk_DCRTaskInWf-->DCR Task found count is:%d",TskCnt);fflush(stdout);

				if (TskCnt != 0)
				{
					printf("\n tm_Chk_DCRTaskInWf-->DCR Task count is Valid");fflush(stdout);
					for (ii=0;ii<TskCnt;ii++)
					{
						if(AOM_ask_value_string(DCRTskTag[ii],"item_id",&DCR_Tsk_Nm)!=ITK_ok)PrintErrorStack();
						printf("\n tm_Chk_DCRTaskInWf: DCR_Tsk_Nm OBJ ID: [%s].", DCR_Tsk_Nm);fflush(stdout);

						//CALLAPI(EPM_ask_active_job_for_target(DCRTskTag[ii],&n_parents,&parents));
						if(EPM_get_current_job(DCRTskTag[ii],&job,&job_type));
						printf("\ntm_Chk_DCRTaskInWf:after job\n"); fflush(stdout);							

						if (job != NULLTAG)
						{
							if(EPM_ask_root_task(job,&roottask));
							if(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
							printf("\ntm_Chk_DCRTaskInWf--> inside %s \n",nameofroot);

							if(tc_strcmp(nameofroot,"Breakdown DCR Task Template")!=0)
							{
								printf("\n tm_Chk_DCRTaskInWf-->DCR task missesed the Add affected parts stage"); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_warning,ITK_err, "DCR task missesed the Add affected parts stage, Kindly raise ticket in TMS");
								decision = EPM_nogo;
								return decision;
							}
						}
						else
						{
							printf("\n tm_Chk_DCRTaskInWf-->Job not found on DCR task revision"); fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_warning,ITK_err, "DCR task missesed the Add affected parts stage, Kindly raise ticket in TMS");
							decision = EPM_nogo;
							return decision;
						}
					}
				}
				else
				{
					printf("\n tm_Chk_DCRTaskInWf-->DCR task count is TskCnt zero [%d] ",TskCnt); fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, "DCR tasks are not present under DCR Break Down Into Plant Item relation, Kindly raise ticket in TMS");
					decision = EPM_nogo;
					return decision;
				}
				printf("\n Handler:tm_Chk_DCRTaskInWf--> is completed for : [%s] \n",t5current_name);fflush(stdout);
			}
		}
	}	
	printf("\n Handler:tm_Chk_DCRTaskInWf-----> Skipp \n");fflush(stdout);
	return decision;		
}

int Set_DCR_Severity( EPM_action_message_t msg )
{
	int ifail = 0;
	int count = 0;
	int n_found = 0,i=0;
	int n_entries = 2 , k=0;

	tag_t *attachments = NULLTAG;
	tag_t *TR_Tags = NULLTAG;
	tag_t *cntr_objects = NULLTAG;

	tag_t root_task =NULLTAG;
	tag_t objTag =NULLTAG;
	tag_t objTypTag =NULLTAG;
	tag_t TagQryContObj = NULLTAG;

	char* ObjTyp=NULL;

	char* DCR_Severity_level=NULL;
	char* DCR_Program=NULL;
	char* DCR_NO =NULL;
	char* DCR_reason =NULL;
	char* UserInfo_DCR =NULL;

	DCR_Severity_level=(char *) MEM_alloc(10);
	tc_strcpy(DCR_Severity_level,"");

	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n Set_DCR_Severity-->Handler:DCR_Set_Severity is started----->count: [%d] ",count);fflush(stdout);

	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];

			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));

			printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--Workfow ObjTyp: [%s]\n", ObjTyp);fflush(stdout);

			if (tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(objTag,"item_id",&DCR_NO));
				printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--DCR_ID: %s",DCR_NO);fflush(stdout);

				CALLAPI(AOM_ask_value_string(objTag,"t5_DcrCreRC",&DCR_reason));
				printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--DCR_reason: [%s] ",DCR_reason);fflush(stdout);

				CALLAPI(AOM_ask_value_string(objTag,"t5_DcrCreSP",&DCR_Program));
				printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--DCR_Program: [%s] ",DCR_Program);fflush(stdout);

				if(QRY_find2("ControlObjQry", &TagQryContObj));
				if (TagQryContObj != NULLTAG)
				{
					qry_values[0] = "DCR_CAT_AB";
					qry_values[1] = DCR_Program;

					if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
					printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--ControlObjQry n_found= %d", n_found);fflush(stdout);

					if(n_found>0)
					{
						for (k=0;k < n_found;k++)
						{
							CALLAPI(AOM_ask_value_string(cntr_objects[k],"t5_Userinfo1",&UserInfo_DCR));
							printf("\n DCR Control Object UserInfo1:	%s",UserInfo_DCR);fflush(stdout);

							if (tc_strcmp(UserInfo_DCR,DCR_reason)==0)
							{
								if( AOM_ask_value_string(cntr_objects[k],"t5_Userinfo2",&DCR_Severity_level));
								printf("\n Set_DCR_Severity-->T5_GenDcrChngRepRevision--1 Value= [%s]", DCR_Severity_level);fflush(stdout);

								break;
							}
						}
					}
				}

				break;
			}
		}

		for(i=0;i<count;i++)
		{
			objTag=attachments[i];

			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));

			printf("\n Set_DCR_Severity-->Workfow 2 ObjTyp : [%s] \n", ObjTyp);fflush(stdout);

			if (tc_strcmp(ObjTyp,"T5_DCR_SevLvl")==0)
			{
				printf("\n Set_DCR_Severity-->T5_DCR_SevLvl----IF condition is true: [%s] \n",DCR_NO);fflush(stdout);

				if (AOM_lock(objTag)!=ITK_ok);PrintErrorStack();

				printf("\n Set_DCR_Severity-->T5_DCR_SevLvl----After Locking DCR Obj:: [%s] n_found: [%d] \n",DCR_NO,n_found);fflush(stdout);

				if ((tc_strlen(DCR_Severity_level)>0) && (tc_strstr(DCR_Severity_level,"Level")!=NULL))
				{
					printf("\n Set_DCR_Severity-->if Condn: [%s]\n",DCR_NO);fflush(stdout);
					if (AOM_set_value_string(objTag,"t5_DcrSevLevel",DCR_Severity_level)!=ITK_ok);PrintErrorStack();
				}
				else
				{
					printf("\n Set_DCR_Severity-->else Condn: [%s]\n",DCR_NO);fflush(stdout);
					if (AOM_set_value_string(objTag,"t5_DcrSevLevel","Level 1")!=ITK_ok);PrintErrorStack();
				}

				if(AOM_save_without_extensions(objTag)!=ITK_ok);PrintErrorStack();
				if(AOM_unlock(objTag)!=ITK_ok);PrintErrorStack();
				if(AOM_refresh (objTag,TRUE)!=ITK_ok);PrintErrorStack();

				break;
			}
		}
	}

	printf("\n Handler:Set_DCR_Severity--> is completed for : [%s] \n",DCR_NO);fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int  DCR_TSK_Part_Rel_PreCond(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int ifail = 0;

	tag_t objTypeTag ,item_tag= NULLTAG;
	char* type_name=NULL;

	tag_t RelobjTag = va_arg(args, tag_t);
	int	isNew = va_arg(args, int);

	if (TCTYPE_ask_object_type(RelobjTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! DCR_TSK_Part_Rel_PreCond:::::::::type_name[%s]  [%d] \n",type_name,isNew);fflush(stdout);

	if (isNew)
	{
		printf("\n DCR_TSK_Part_Rel_PreCond-->!!!!!!!!!!!!!!!!! Is New !!!!!!! \n");fflush(stdout);

	}


	int		ii;
	int  	count,count1,n_tasks=0,n_Starttasks=0;
	int  	dcrCount = 0;

	tag_t	primary_object					= NULLTAG;
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= NULLTAG;
	tag_t	secondary_obj_type_tag			= NULLTAG;
	tag_t DCR_rel_type = NULLTAG;
	tag_t TaskAssignee = NULLTAG;
	tag_t DCRobjTypTag = NULLTAG;
	tag_t DCRqryTag = NULLTAG;
	
	tag_t *DCR_Tags = NULLTAG;
	tag_t *tasks = NULLTAG;
	tag_t *Startedtasks = NULLTAG;


	char*	type_name1= NULL;
	char*	type_name2= NULL;
	char*	DCRRPTinfo1= NULL;
	char*	DCRRPTinfo2= NULL;
	char *taskDCR = (char *) MEM_alloc(100 * sizeof(char *));


	char *username = NULL;
	char *TaskName = NULL;
	char *TaskAssigneeStr = NULL;
	char *DCRRevWf = NULL;
	char *DCRTypName = NULL;
	char *taskDCR10 = NULL;
	char *LeadTask = NULL;
	char *Dcrtaskname = NULL;
	char *tskname = NULL;
	
	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int SupportFlag =  0;
	int AttachFlag=0;
	int DCR_n_entry=0;
	int DCR_rsltCount=0;
	logical	check_out = 0;

	tag_t           *DCRCntrlObjectTag      = NULLTAG;
	char            **DCR_qry_values2       =  (char **) MEM_alloc(10 * sizeof(char *));
	char            *DCR_qry_entry[1]       = {"SYSCD"};
	
	ifail=GRM_ask_primary(RelobjTag,&primary_object);
	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name1);
	printf("\n DCR_TSK_Part_Rel_PreCond-->Primary_object type_name: [%s]",type_name1);fflush(stdout);

	ifail=GRM_ask_secondary(RelobjTag,&secondary_object);
	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name2(secondary_obj_type_tag,&type_name2);
	printf("\n DCR_TSK_Part_Rel_PreCond-->secondary_object type_name: [%s]",type_name2);fflush(stdout);
	
	POM_get_user_id (&username);
	printf("\n DCR_TSK_Part_Rel_PreCond-->Logged in user:%s ",username); fflush(stdout);
	
	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin(SessionUser9_tag);
		printf("\n DCR_TSK_Part_Rel_PreCond-->SupportFlag.: %d",SupportFlag);fflush(stdout);
	}
	printf("\n DCR_TSK_Part_Rel_PreCond-->Login check-9 End......:%d\n",SupportFlag);fflush(stdout);
	
	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0) //544216261202  5442165555555/NR;2
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		AOM_ask_value_tags(primary_object, "process_stage_list", &n_tasks, &tasks);
		printf("\n DCR_TSK_Part_Rel_PreCond-->n_tasks 1 Value == [%d]", n_tasks);fflush(stdout);
		if (n_tasks>0)  //fnd0StartedTasks
		{
			AOM_ask_value_tags(tasks[0], "fnd0StartedTasks", &n_Starttasks, &Startedtasks);
			printf("\n DCR_TSK_Part_Rel_PreCond-->n_Starttasks 1 Value == [%d]", n_Starttasks);fflush(stdout);
			 
			if (n_Starttasks>0) //object_name
			{
				if( AOM_ask_value_string(Startedtasks[0],"object_name",&TaskName));
				printf("\n DCR_TSK_Part_Rel_PreCond-->TaskName== [%s]", TaskName);fflush(stdout);

				if (tc_strcmp(TaskName,"Add Affected Parts to DCR Task")==0)
				{
					if( AOM_ask_value_tag(Startedtasks[0],"fnd0Assignee",&TaskAssignee));
					if (TaskAssignee != NULLTAG)
					{//user_id
						if( AOM_ask_value_string(TaskAssignee,"user_id",&TaskAssigneeStr));

						printf("\n DCR_TSK_Part_Rel_PreCond-->TaskAssigneeStr 1 Value == [%s]", TaskAssigneeStr);fflush(stdout);
						if (tc_strstr(TaskAssigneeStr,username))
						{
							AttachFlag=1;
						}
					}
				}
			}
		}
		else
		{
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_rel_type));
			if(GRM_list_primary_objects_only(primary_object,DCR_rel_type,&dcrCount,&DCR_Tags)!=ITK_ok)PrintErrorStack();
			printf("\n T5TaskToPartCreateVal-->From DCR Task to dcrCount==[%d] \n",dcrCount);fflush(stdout);
			if (dcrCount>0)
			{
				printf("\n\t\t Inside DCRRev Found loop....");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(DCR_Tags[0],"fnd0AllWorkflows",&DCRRevWf));
				printf("\n T5TaskToPartCreateVal-->DCR revision workflow : %s \n",DCRRevWf);fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(DCR_Tags[0],"fnd0ActuatedInteractiveTsks",&taskDCR));
				printf("\n T5TaskToPartCreateVal-->DCR revision workflow task is: %s \n",taskDCR);fflush(stdout);
				
				if(tc_strlen(taskDCR) > 0)
				{
					if (tc_strstr(taskDCR,",")!= NULL)
					{
						taskDCR10 = strtok(taskDCR,",");
					}
					
					printf("\n T5TaskToPartCreateVal-->DCR revision current workflow task is: %s \n",taskDCR10);fflush(stdout);

					if((tc_strcmp(taskDCR10,"DCR Creator Review")==0)|| (tc_strcmp(taskDCR10,"DCR CoC HoD Review 1")==0)|| (tc_strcmp(taskDCR10,"DCR Checklist Review Process 1")==0) 
							|| (tc_strcmp(taskDCR10,"DMU assessment for DCR")==0)||(tc_strcmp(taskDCR10,"Add Affected Parts to DCR Task")==0))
					{
						printf("\n T5TaskToPartCreateVal-->DCR Parts allowed to attach \n");fflush(stdout);
						AttachFlag=1;
					}
					else
					{
						printf("\n T5TaskToPartCreateVal-->DCR Part is not allowed to attach, hence skipping ??? \n");fflush(stdout);
					}
				}	
				else
				{
					if(QRY_find2("Control Objects...", &DCRqryTag));
					if (DCRqryTag != NULLTAG)
					{
						printf("\n T5TaskToPartCreateVal Found Query ControlObjects \n");fflush(stdout);
						
						DCR_qry_values2[0] = "DCRLeadTsk";

						if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
					}
					else
					{
						printf("\n T5TaskToPartCreateVal Not Found Query ControlObjects \n");fflush(stdout);
					}

					printf(" \n T5TaskToPartCreateVal DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
					if(DCR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo1",&DCRRPTinfo1)!=ITK_ok)   PrintErrorStack();
						printf("\n T5TaskToPartCreateVal DCRRPTinfo1: %s ", DCRRPTinfo1);fflush(stdout);
						if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo2",&DCRRPTinfo2)!=ITK_ok)   PrintErrorStack();
						printf("\n T5TaskToPartCreateVal DCRRPTinfo2: %s ", DCRRPTinfo2);fflush(stdout);
					}
					if (tc_strstr(DCRRPTinfo1,"LeadTsk001") == NULL)
					{
				
						CALLAPI(AOM_UIF_ask_value(DCR_Tags[0],"t5_DcrLeadCoc",&LeadTask));
						printf("\n T5TaskToPartCreateVal-->DCR Lead task is: %s \n",LeadTask);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(primary_object,"object_name",&Dcrtaskname));
						printf("\n T5TaskToPartCreateVal-->DCR task name : %s \n",Dcrtaskname);fflush(stdout);
						tskname=subString(Dcrtaskname,18,2);
						//Trims: Tr > _Tr
						if(tc_strstr(LeadTask,tskname) != NULL)
						{
							AttachFlag=1;
						}
					}
				}
			}
		}

		 printf("\n DCR_TSK_Part_Rel_PreCond-->AttachFlag: [%d] ",AttachFlag);fflush(stdout);

		if (AttachFlag==0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Current assignment is not for Add Affected Parts to DCR Task OR current user is not Valid user for attaching Part to DCR task");
			return ITK_err;
		}
	}
	printf("\n DCR_TSK_Part_Rel_PreCond-->Completed...\n");fflush(stdout);
	return error_code;
}

extern int DCR_register_method(int *decision, va_list args)
{
	int ifail=0;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t);


   	METHOD_id_t		methodGen3Dcr;
   	METHOD_id_t		methodGen3DcrRev;
   	METHOD_id_t		methodDcrTskPrt;
	METHOD_id_t		method_DCR_attach;

	CALLAPI (METHOD_find_method("T5_GenDcrChngRep", TC_save_msg, &methodGen3Dcr));
	CALLAPI (METHOD_find_method("T5_GenDcrChngRepRevision", TC_save_msg, &methodGen3DcrRev));
	CALLAPI (METHOD_find_method("T5_DcrTskPrt", TC_save_msg, &methodDcrTskPrt));
	CALLAPI (METHOD_find_method("CMImplements", GRM_create_msg, &method_DCR_attach));

	//Validation for attaching DCR to DML...!!(added by kalpesh)
	if (method_DCR_attach.id != NULL)
	{
		printf("\nInside method_DCR_attach...!!\n"); fflush(stdout);
		if( METHOD_add_pre_condition(method_DCR_attach, (METHOD_function_t) DCR_attach_method, NULL)!=ITK_ok)
		if( ifail != ITK_ok )
		{
			printf("\nError method_DCR_attach\n"); fflush(stdout);
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_DCR_attach tag not found...!!*****************\n"); fflush(stdout);
	}

	//Validation for DCR mandatory according to DR status of earlier released revision.(added by kalpesh)
	if(ITK_ok ==  EPM_register_rule_handler ("Check_DCR_required","Check_DCR_required", (EPM_rule_handler_t) Check_DCR_required))
	{
		printf("\t\n Registered Rule Handler Check_DCR_required\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler Check_DCR_required\n");fflush(stdout);
	}

	if (methodGen3Dcr.id != NULL)
	{
		printf("\n*****************Method methodGen3Dcr  found...!!*****************"); fflush(stdout);
		CALLAPI( METHOD_add_action(methodGen3Dcr, METHOD_post_action_type, (METHOD_function_t) Gen3Dcr_post, NULL)!=ITK_ok);

	}
	else
	{
		printf("\n*****************Method methodGen3Dcr not found...!!*****************"); fflush(stdout);
	}

	if (methodDcrTskPrt.id != NULL)
	{
		printf("\n*****************Method methodDcrTskPrt  found...!!*****************"); fflush(stdout);
		if( METHOD_add_pre_condition(methodDcrTskPrt, (METHOD_function_t)DCR_TSK_Part_Rel_PreCond, NULL)!=ITK_ok)
		{
			printf("\n !!!!!!!!!!! DCR_TSK_Part_Rel_PreCond error found!!!!!!!!!!"); fflush(stdout);
		}

	}
	else
	{
		printf("\n*****************Method methodGen3Dcr not found...!!*****************"); fflush(stdout);
	}

	if (methodGen3DcrRev.id != NULL)
	{
		printf("\n*****************Method methodGen3DcrRev  found...!!*****************"); fflush(stdout);
		CALLAPI( METHOD_add_action(methodGen3DcrRev, METHOD_post_action_type, (METHOD_function_t) Gen3DcrRev_post, NULL)!=ITK_ok);

		if( METHOD_add_pre_condition(methodGen3DcrRev, (METHOD_function_t)methodGen3DcrRev_PreCond, NULL)!=ITK_ok)
		{
			printf("\n !!!!!!!!!!! methodGen3DcrRev_PreCond error found!!!!!!!!!!\n"); fflush(stdout);
		}
	}
	else
	{
		printf("\n*****************Method methodGen3DcrRev not found...!!*****************\n"); fflush(stdout);
	}

	if(ITK_ok ==  EPM_register_action_handler ("tm_DCR_Auto_Assign","Auto Assign Participant", (EPM_action_handler_t) DCR_Auto_Assign))
	{
		printf("\t\n Registered action Handler DCR_Auto_Assign\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register action Handler DCR_Auto_Assign\n");fflush(stdout);
	}

	if(ITK_ok ==  EPM_register_rule_handler ("TDM_CHK_DCR_Submit","Validate for DCR Submisson", (EPM_rule_handler_t) Chk_DCR_active))
	{
		printf("\t\n Registered Rule Handler TDM_CHK_DCR_Submit\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Rule Handler TDM_CHK_DCR_Submit\n");fflush(stdout);
	}
	//Prasad
	if(ITK_ok ==  EPM_register_rule_handler ("tm_Chk_DCRTaskInWf","Validate for DCR Task Completion", (EPM_rule_handler_t) tm_Chk_DCRTaskInWf))
	{
		printf("\t\n Registered Rule Handler tm_Chk_DCRTaskInWf\n");fflush(stdout);
	}else
	{
		printf("\t FAILED to register Rule Handler tm_Chk_DCRTaskInWf\n");fflush(stdout);
	}

	if(ITK_ok ==  EPM_register_action_handler ("DCR_Set_Severity","Setting the severity level on FORM", (EPM_action_handler_t) Set_DCR_Severity))
	{
		printf("\t\n Registered action Handler DCR_Set_Severity\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register action Handler DCR_Set_Severity\n");fflush(stdout);
	}

   return ITK_ok;
}

extern DLLAPI int tm_dcr_register_callbacks()
{
	 CUSTOM_register_exit("tm_dcr", "USER_init_module", (CUSTOM_EXIT_ftn_t) DCR_register_method);
     printf("\n registered function tm_dcr \n");	fflush(stdout);

	 return ( ITK_ok );
}