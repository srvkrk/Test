/******************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :  Prasad Sagare
*  Module               :   
*  Code                 :   
*  Created on			:   24-04-2024
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*********************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

#define ECU_err 919002

EPM_decision_t tm_assign_GID_reviwer(EPM_rule_message_t msg)
{
	int count,i = 0;
	int ifail=0;
	int Partyn_entry = 1;
	int  PartyrsltCount =  0;
	EPM_decision_t decision = EPM_go;
	tag_t	root_task	= NULLTAG;
	tag_t	*attachments	= NULLTAG;
	tag_t	objTypeTag	= NULLTAG;
	tag_t	user_tag	= NULLTAG;
	tag_t   PartyqryTag     = NULLTAG;	
	tag_t   *PartyObjTag    = NULLTAG;

	logical is_latest;

	char* username			= NULL;
	char* CurrentTask		= NULL;
	char* parent_name		= NULL;
	char* AnalystName		= NULL;
	char* RequestorName		= NULL;
	char* ChangReviewName		= NULL;
	char* DMLtp			= NULL;
	char *DMLBUnit			= NULL;
	char *sDMLPARTYInfo1		= NULL;
	char *sDMLPARTYInfo2		= NULL;
	char *sDMLPARTYInfo3		= NULL;
	char *sDMLPARTYInfo4		= NULL;
	char* type_name= NULL;
	char *Partyqry_entry[1]  = {"SYSCD"};
	char **Partyqry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n tm_assign_GID_reviwer Function started...");fflush(stdout);
	TC_write_syslog("\n tm_assign_GID_reviwer Function started...");
	POM_get_user(&username,&user_tag);
	printf("\n GID: Starting for username :%s....\n",username);fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n GID:Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n GID:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n GID:Parent Name:%s\n",parent_name);fflush(stdout);

	if(strstr(CurrentTask,"Assign Analyst and Change Review Board(COC)")!=NULL)
	{
		printf("\n GID:DML participant Check...\n"); fflush(stdout);
		if(QRY_find2("ControlObjects", &PartyqryTag));
		if (PartyqryTag)
		{
			printf("\n Group ID Release:DMLPARTY:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n Group ID Release:Not Found Query ControlObjects \n");fflush(stdout);
		}

		Partyqry_values2[0] = "GroupIDDML";
		if(QRY_execute(PartyqryTag, Partyn_entry, Partyqry_entry, Partyqry_values2, &PartyrsltCount, &PartyObjTag));
		printf("\n GID:GroupIDDML:DMLPARTY count :%d:", PartyrsltCount); fflush(stdout);
		if(PartyrsltCount > 0)
		{
			//ON OFF for DML participants.
			if (AOM_ask_value_string(PartyObjTag[0],"t5_Userinfo1",&sDMLPARTYInfo1)!=ITK_ok)   PrintErrorStack();
			//DML BU
			if (AOM_ask_value_string(PartyObjTag[0],"t5_Userinfo2",&sDMLPARTYInfo2)!=ITK_ok)   PrintErrorStack();
			//DML BU
			if (AOM_ask_value_string(PartyObjTag[0],"t5_Userinfo3",&sDMLPARTYInfo3)!=ITK_ok)   PrintErrorStack();
			//DML type
			if (AOM_ask_value_string(PartyObjTag[0],"t5_Userinfo4",&sDMLPARTYInfo4)!=ITK_ok)   PrintErrorStack();
			printf("\n GID:sDMLPARTYInfo1:[%s] sDMLPARTYInfo2:[%s]",sDMLPARTYInfo1,sDMLPARTYInfo2);fflush(stdout);
			printf("\n GID:sDMLPARTYInfo3:[%s] sDMLPARTYInfo4:[%s]",sDMLPARTYInfo3,sDMLPARTYInfo4);fflush(stdout);

		}

		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n GID: EPM_ask_attachments of :: %d\n",count);

		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name2( objTypeTag,&type_name));
				printf("\n GID:type_name ==> %s\n", type_name);fflush(stdout);
				if(tc_strstr(sDMLPARTYInfo1,"A1") == NULL)
				{
					printf("\n GID:Task based HasParticipant check 1..... \n");fflush(stdout);
					if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
					{
						CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));
						printf("\n GID:Analyst Name of task :: %s \n",AnalystName);fflush(stdout);

						CALLAPI(AOM_UIF_ask_value(attachments[i],"Requestor",&RequestorName));
						printf("\n GID:RequestorName Name of task :: %s \n",RequestorName);fflush(stdout);
						//Checking Analyst.
						if (tc_strcmp(AnalystName,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option");
							return ITK_err;
						}
						printf("\n GID:Passed the Analyst check... \n");fflush(stdout);
					}
				}
				if(tc_strstr(sDMLPARTYInfo1,"A2") == NULL)
				{
					printf("\n GIR:Task based HasParticipant check 2..... \n");fflush(stdout);
					if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
					{
						CALLAPI(AOM_ask_value_string(attachments[i],"t5_rlstype",&DMLtp));
						CALLAPI(AOM_ask_value_string(attachments[i],"t5_ERCBusiUt",&DMLBUnit));
						printf("\n GIR:DMLtp:%s  DMLBUnit:%s\n",DMLtp,DMLBUnit);	fflush(stdout);

						CALLAPI(AOM_UIF_ask_value(attachments[i],"ChangeReviewBoard",&ChangReviewName));
						printf("\n\n\t\t ChangeReviewBoard  :: [%s] \n",ChangReviewName);fflush(stdout);

						//CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_BOMAnalyst",&ChangReviewName1));
						//printf("\n\n\t\t T5_BOMAnalyst Name of task :: %s \n",ChangReviewName1);fflush(stdout);
						if (tc_strcmp(DMLtp,"GIR")==0 || tc_strcmp(DMLtp,"IFR")==0)
						{
							if (tc_strcmp(ChangReviewName,"")==0)
							{
								printf("\n GIR:Pls Assign Change Review Board");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign Change Review Board/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->Select Change Review Board");
								return ITK_err;
							}
						}
						printf("\n GID:Passed the COC check... \n");fflush(stdout);
					}
				}
			}
		}
	}
	printf("\n tm_assign_GID_reviwer Function end...");fflush(stdout);
	TC_write_syslog("\n tm_assign_GID_reviwer Function end...");
	
	/*	if(CurrentTask){MEM_free(CurrentTask);}
	if(parent_name){MEM_free(parent_name);}
	if(sDMLPARTYInfo1){MEM_free(sDMLPARTYInfo1);}
	if(sDMLPARTYInfo2){MEM_free(sDMLPARTYInfo2);}
	if(sDMLPARTYInfo3){MEM_free(sDMLPARTYInfo3);}
	if(sDMLPARTYInfo4){MEM_free(sDMLPARTYInfo4);}
	if(AnalystName){MEM_free(AnalystName);}
	if(RequestorName){MEM_free(RequestorName);}
	if(DMLtp){MEM_free(DMLtp);}
	if(DMLBUnit){MEM_free(DMLBUnit);}
	if(ChangReviewName){MEM_free(ChangReviewName);}*/
	return decision;
}