
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_TestAppl.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for Test Applicability logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 10/01/2021   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerESOErr (EMH_USER_error_base + 701)
#define T5_WorkFlowHandlerAnxErr (EMH_USER_error_base + 702)
#define MAX_LINE_LEN 1024


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}





/*....................Functions.............*/


/*Start Test Applicability Module Logic */


//Function start
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}

///CODE START HERE
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		//printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		//printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_createCedCoatedParts: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_createCedCoatedParts: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}

//Solve BOM by applying SVR on Platform and get unit bom
int tm_SolveAndGetUnitBom(tag_t pltFrmTag, tag_t svrTag,int *cnt, tag_t **moduleList)
{
	int ifail = ITK_ok;
	tag_t view_type = NULLTAG;
	tag_t pltFrmItemTag = NULLTAG;
	int n_bom_views = 0;
	tag_t* bom_views = NULLTAG;
	tag_t bom_view = NULLTAG;
	
	tag_t bom_window = NULLTAG;
	tag_t revRule = NULLTAG;
	
	tag_t* closureRules = NULLTAG;
	int ruleFound = 0;
	tag_t closureRuleTag = NULLTAG;
	tag_t top_line = NULLTAG;
	//tag_t bom_variant_rule = NULLTAG;
	//tag_t *bom_variant_rules=NULLTAG;
	//int rule_count = 0;
	//tag_t bomVariantTypeTag = NULLTAG;
	//char bom_var_type_name[TCTYPE_name_size_c+1];
	//tag_t var_exp_block = NULLTAG;
	
	tag_t* lines = NULLTAG;
	int n_lines = 0;
	
	int i=0;
	tag_t childObj = NULLTAG;
	char* child_item_id = NULL;
	
	int n_lines2 = 0;
	tag_t* lines2 = NULLTAG;
	
	int n_optns = 0;
	tag_t* options = NULLTAG;
	tag_t* option_revs = NULLTAG;
	
	int n_lines1 = 0;
	logical is_bom_modified = FALSE;
	
	int j=0;
	int k =0;
	
	tag_t childObj2 = NULLTAG;
	char* child_item_id2 = NULL;
	
	int n_lines3 = 0;
	tag_t* lines3 = NULLTAG;
	
	tag_t childObj3 = NULLTAG;
	char* child_item_id3 = NULL;
	int IntAttr = 0;
	char* module_rel_status = NULL;
	
	
	printf("\n SAN:tm_SolveAndGetUnitBom: Start of funtion tm_SolveAndGetUnitBom\n");fflush(stdout);
	
	if(pltFrmTag != NULLTAG)
	{
		CALLAPI ( PS_find_view_type( "view", &view_type ));
		printf("\n SAN:tm_SolveAndGetUnitBom: PS_find_view_type is found......\n" ); fflush(stdout);

		if ( view_type != NULLTAG )
		{
			CALLAPI ( ITEM_ask_item_of_rev( pltFrmTag, &pltFrmItemTag ));
			CALLAPI ( ITEM_list_bom_views( pltFrmItemTag, &n_bom_views, &bom_views ));

			bom_view = bom_views[0];
		}
		else
			printf("\n SAN:tm_SolveAndGetUnitBom: View not found....\n"); fflush(stdout);		
	}
	
	
	if( bom_view != NULLTAG )
	{
		PIE_scope_t scope;
		CALLAPI(BOM_create_window( &bom_window ));
		//CALLAPI(CFM_find( "ERC release and above", &rule ))
		CALLAPI(CFM_find( "Latest Working", &revRule ))
		CALLAPI(BOM_set_window_config_rule( bom_window, revRule ));				
		CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",scope, &ruleFound, &closureRules ));
		printf ("\n SAN:tm_SolveAndGetUnitBom: Closure Rule count %d \n",ruleFound);fflush(stdout);
		
		if(ruleFound>0)
		{
			closureRuleTag = closureRules[0];
			printf("\n SAN:tm_SolveAndGetUnitBom: Closure Rule found....\n"); fflush(stdout);	
		}

		if(closureRuleTag!=NULLTAG) CALLAPI(BOM_window_set_closure_rule( bom_window,closureRuleTag, 0, NULL,NULL ));
		CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
		CALLAPI(BOM_set_window_top_line( bom_window, NULLTAG, pltFrmTag, NULLTAG, &top_line ));
		//CALLAPI(BOM_window_ask_variant_rule(bom_window, &bom_variant_rule ));
		
		//ifail = BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);
		
		//CALLAPI(TCTYPE_ask_object_type(bom_variant_rule,&bomVariantTypeTag));
		//CALLAPI(TCTYPE_ask_name(bomVariantTypeTag,bom_var_type_name));
		//printf("\n SAN:tm_SolveAndGetUnitBom: bom_var_type_name[%s]\n",bom_var_type_name);fflush(stdout);
		//Get the variant expression block associated with the specified Item Revision.
		//CALLAPI(ITEM_ask_rev_variants(pltFrmTag, &var_exp_block));
		
		if(top_line!=NULLTAG)
		{
			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
			printf("\n SAN:tm_SolveAndGetUnitBom: Before setting option n_lines: %d\n", n_lines);fflush(stdout);
			CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
			CALLAPI(BOM_window_show_variants(bom_window))   ;
						
			CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&svrTag))   ;
			printf("\n SAN:tm_SolveAndGetUnitBom: After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

			CALLAPI(BOM_window_hide_variants(bom_window))   ;

			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
			printf("\n SAN:tm_SolveAndGetUnitBom: After setting option n_lines: %d\n", n_lines);fflush(stdout);
			
			if(n_lines >0)
			{
				for (i=0;i<n_lines ;i++ )
				{
					if(childObj) childObj=NULLTAG;
					childObj=lines[i];
					CALLAPI(AOM_ask_value_string(childObj, "bl_item_item_id", &child_item_id ));

					CALLAPI(BOM_line_ask_child_lines(childObj, &n_lines2, &lines2));
					printf("\n SAN:tm_SolveAndGetUnitBom: [%d] child_item_id[%s] \t count [%d]",i+1,child_item_id,n_lines2);fflush(stdout);

				}				
			}
			
			 
			CALLAPI(CFM_find("ERC release and above", &revRule))
			//CALLAPI(CFM_find( "Latest Working", &rule ))
			
			//Apply Revision rule 
			CALLAPI(BOM_set_window_config_rule( bom_window, revRule));
			
			// get the list of options and their revisions referenced by the given BOM variant rule.
			//CALLAPI (BOM_variant_rule_ask_options( bom_variant_rule, &n_optns, &options, &option_revs ) )
			//printf("\n SAN:tm_SolveAndGetUnitBom: No of Option values in the rule:%d\n",n_optns);fflush(stdout);
			
			
			if(top_line!=NULLTAG )
			{
				
				CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
				printf("\n SAN:tm_SolveAndGetUnitBom: Before setting option n_lines1: %d \n", n_lines1);fflush(stdout);
				
				if(bom_window != NULLTAG)
				{
					CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
					CALLAPI(BOM_window_show_variants(bom_window))   ;
					printf("\n SAN:tm_SolveAndGetUnitBom: After inside bom_window apply variant condition\n"); fflush(stdout);			
					CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&svrTag))   ;
					printf("\n SAN:tm_SolveAndGetUnitBom: After BOM_window_apply_variant_configuration\n"); fflush(stdout);

					CALLAPI(BOM_window_hide_variants(bom_window))   ;
					CALLAPI(BOM_window_ask_is_modified(bom_window,&is_bom_modified));
					
					if(is_bom_modified)
					{
						printf("\n SAN:tm_SolveAndGetUnitBom: Bom is modified....\n");fflush(stdout);
					}
					else
					{
						printf("\n SAN:tm_SolveAndGetUnitBom: Bom is  not modified....\n");fflush(stdout);
					}
					
					CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
					printf("\n SAN:tm_SolveAndGetUnitBom: After setting option n_lines1: %d \n", n_lines1);fflush(stdout);
					
					printf("\n SAN:tm_SolveAndGetUnitBom: Get the unit bom (module) start...\n");fflush(stdout);
					
					if (n_lines1 >0)
					{
						int unitBomCnt=0;
						int strCnt = 0;
						char** strBuff = NULL;
						int foundStr = 0;
						for (j=0;j<n_lines1 ;j++ )
						{
							if(childObj2) childObj2=NULLTAG;
							childObj2=lines[j];
							CALLAPI(AOM_ask_value_string(childObj2, "bl_item_item_id", &child_item_id2));
							CALLAPI(BOM_line_ask_child_lines(childObj2, &n_lines3, &lines3));
							
							if(n_lines3 >0)
							{
								for (k=0;k<n_lines3 ;k++ )
								{
									if(childObj3) childObj3=NULLTAG;
									childObj3=lines3[k];
									CALLAPI(AOM_ask_value_string(childObj3, "bl_item_item_id", &child_item_id3 ));
									//CALLAPI(BOM_line_look_up_attribute ("bl_rev_last_release_status",&IntAttr));
									//CALLAPI(BOM_line_ask_attribute_string(childObj3, IntAttr, &module_rel_status));
									ifail = AOM_ask_value_string(childObj3,"bl_rev_last_release_status",&module_rel_status);
									
									//more than one module
									if(k>0)
									{
										t5FindStrInSet(strBuff,strCnt,child_item_id3,&foundStr);
										
										if(foundStr==1)
										{
											//t5AddStrToSet(&strCnt,&strBuff,child_item_id3);
											printf("\n SAN:tm_SolveAndGetUnitBom: Multi module case [%s]. Skip it\n",child_item_id3);fflush(stdout);
											continue;
											
										}
										else
										{
											printf("\n SAN:tm_SolveAndGetUnitBom: Multi module case [%s]. Check it \n",child_item_id3);fflush(stdout);
											printf("[%d]child_item_id3[%d]==>%s, module_rel_status===>%s\n",j,k,child_item_id3,module_rel_status);fflush(stdout);
											t5AddTagObjToSet(cnt,moduleList,childObj3);
											unitBomCnt++;
											break;											
											
										}

																				
									}
									else
									{
										printf("[%d]child_item_id3[%d]==>%s, module_rel_status===>%s\n",j,k,child_item_id3,module_rel_status);fflush(stdout);
										t5AddTagObjToSet(cnt,moduleList,childObj3);
										unitBomCnt++;
									}

									
									t5AddStrToSet(&strCnt,&strBuff,child_item_id3);

								}
							}
							
						}
						printf("\nTotal no of unit bom===>%d\n",unitBomCnt);fflush(stdout);
					}
					
					
					
				}
				
				
				
			}


			
			
			
		}
		
		
		
		
		
		//CALLAPI(BOM_save_window(bom_window))
		CALLAPI(BOM_close_window(bom_window))
		
	}
	
	
	
	printf("\n SAN:tm_SolveAndGetUnitBom: End of funtion tm_SolveAndGetUnitBom\n");fflush(stdout);
	return ifail;
}




typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}

int getRevisionRuleObject(char *revisionRuleName, tag_t *revisonRuleObj)
{
	int ifail = ITK_ok;
	int flagRevRule =0;
	//get the Revision Rule Object
	

	CALLAPI(CFM_find(revisionRuleName, revisonRuleObj));
	if (revisonRuleObj != NULLTAG)
	{
		//printf("\nFind revRule\n");fflush(stdout);
		flagRevRule = 1;
		
	}
	
	//printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	
	return ifail;
}

int getClosureRuleObject(char* closureRuleName,tag_t *closureRuleObj)
{
	int ifail = ITK_ok;
	PIE_scope_t scope;
	int closureTagCnt = 0;
	tag_t *closureTags = NULLTAG;
	int flagClosureRule = 0;
	//get the Revision Rule Object
	


	scope=PIE_TEAMCENTER;
	CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&closureTagCnt,&closureTags));
	//printf("\n closureTagCnt:%d ..............",closureTagCnt);fflush(stdout);
	if(closureTagCnt==1)
	{
		*closureRuleObj=closureTags[0];
		flagClosureRule=1;
	}
	//printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	
	return ifail;
}

int getBomViewRevObject(tag_t partRevObj,char* bvrName, tag_t* bomViewObj)
{
	int ifail = ITK_ok;
	const char	*prog_name 		="getBomViewRevObject";
	tag_t partMaster 		= NULLTAG;
	int n_bom_views         = 0;
	tag_t *bom_views        = NULL;
	tag_t viewObj 			= NULLTAG;
	tag_t view_type 		= NULLTAG;
	char* view_type_name = NULL;
	char* partNumber = NULL;
	char* partRev = NULL;
	if(partRevObj == NULLTAG)
	{
		//printf("\ngetBomViewRevObject: Part Object is NULLTAG\n");fflush(stdout);
		return ifail;
	}	
	// Get the Item from the revision
	CALLAPI(ITEM_ask_item_of_rev(partRevObj, &partMaster)); 
	
	//Get the tags of all bom views related to the Item.
	CALLAPI(ITEM_list_bom_views(partMaster, &n_bom_views, &bom_views ));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_id",&partNumber));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_revision_id",&partRev));
	//printf("\n Part number===>%s,%s\n",partNumber,partRev);fflush(stdout);	


	if(n_bom_views>0)
	{
		int j = 0;
		//printf("\nSAN: %s.%s having below bom views...\n", partNumber,partRev);fflush(stdout);
		for(j=0;j<n_bom_views;j++)
		{
			//Get the view type of the BOMView
			CALLAPI(PS_ask_bom_view_type(bom_views[j],&view_type))
			
			//Get the name of the view type
			CALLAPI(PS_ask_view_type_name(view_type, &view_type_name));
			//printf("\nView Type===>%s\n", view_type_name);fflush(stdout);
			
			
			if(tc_strcmp(view_type_name, bvrName) == 0 )
			{
				viewObj = bom_views[j];
				break;
			}						
		}
		*bomViewObj = viewObj;
		
	}
	return ifail;
	
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}


typedef struct BomLineVector_
{
 int level;
 int line_count;
 tag_t *bom_lines;
} *BOMLineVector; 

void setAddBomLineVector(int *count,BOMLineVector **objlist,BOMLineVector obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddBomLineVector1");fflush(stdout);
		(*objlist) = (BOMLineVector *)malloc((*count ) * sizeof(BOMLineVector ));
		//printf("\n ***setAddBomLineVector2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddBomLineVector3");fflush(stdout);
		(*objlist) = (BOMLineVector *)realloc((*objlist),(*count) * sizeof(BOMLineVector ));
		//printf("\n ***setAddBomLineVector4");fflush(stdout);
		//printf("\n **setAddBomLineVector5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddBomLineVector6");fflush(stdout);
}






int relatePrimaryWithSecondaryObj(tag_t primaryTag, tag_t secondaryTag, char* relation )
{
	int ifail = ITK_ok;
	tag_t relation_type = NULLTAG;
	tag_t primSecRelation = NULLTAG;
	CALLAPI(GRM_find_relation_type(relation,&relation_type));
	if(relation_type!=NULLTAG)
	{
		CALLAPI(GRM_create_relation(primaryTag, secondaryTag, relation_type,  NULLTAG, &primSecRelation));
		CALLAPI(GRM_save_relation(primSecRelation));
	}
	else
	{
		printf("\nNo relation %s exists...Please check. Very serious error.\n",relation);fflush(stdout);
	}
	 
	return ifail;
}



void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}




typedef struct PartDetail_
{
	char* partNumber;
	char* parRev;
	char* partDesc;
	char* partDRStatus;
	char* partApplicableESO;
	char* partVehClass;
	char* partProjCode;
	char* partProjDesc;
	char* partOwnerDesUnit;
}*PartDetail;


void setAddPartDetail(int *count,PartDetail **objlist,PartDetail obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartDetail *)malloc((*count ) * sizeof(PartDetail ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartDetail *)realloc((*objlist),(*count) * sizeof(PartDetail ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



int tmCreateTaTableRow(char *vehicleNo ,tag_t* newRowTag)
{
	int ifail = ITK_ok;
	
	tag_t rev_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	
	tag_t item_type_tag = NULLTAG;
	printf("\nSAN:tmCreateTaTableRow,, START------------------"); fflush(stdout);
	TCTYPE_find_type("T5_InpTab_PA_TRow", NULL, &rev_type_tag);
	if(rev_type_tag!=NULLTAG)
	{
		printf("\nSAN:tmCreateDesignRevision: rev_type_tag Tag Found."); fflush(stdout);
		TCTYPE_construct_create_input(rev_type_tag, &item_create_input_tag);
		AOM_set_value_string(item_create_input_tag, "t5_TAPart", vehicleNo);
		/* AOM_set_value_string(item_create_input_tag, "item_revision_id", "NR;1"); //itemId12rev
		
		AOM_set_value_string(item_create_input_tag, "object_desc", "Test Vehicle"); //itemId12rev
		AOM_set_value_string(item_create_input_tag, "t5_PartType", "V"); //itemId12rev
		AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", "5099"); //itemId12rev
		AOM_set_value_string(item_create_input_tag, "t5_DesignGrp", "00"); //itemId12rev
 */

		//Create Design Part and its  Revision
		tag_t rowTag = NULLTAG;
		TCTYPE_create_object(item_create_input_tag, &rowTag);
		
		if(rowTag!=NULLTAG)
		{
			printf("\nSAN:creCEDPart: Design Part created."); fflush(stdout);					 
			AOM_save_with_extensions(rowTag);
			*newRowTag = rowTag;			
		}

				
		
	}
	else
	{
		printf("\nSAN:tmCreateDesignRevision: rev_type_tag Tag NOT FOUND."); fflush(stdout);
	}
	
	printf("\nSAN:tmCreateDesignRevision,, END------------------"); fflush(stdout);
	return ifail;
}

/*CR work start */
int tmAddTATableRowData(tag_t taTag)
{
	
	int ifail = ITK_ok;
	
	printf("\nSAN:tmAddTATableRowData,, START------------------"); fflush(stdout);
	
	int num_rows_to_append = 3;
	int row_new_index = 0;
	tag_t* table_rows_tag = NULLTAG;
	int property_index = 0;
	
	CALLAPI(AOM_lock ( taTag ) );
	
	CALLAPI(AOM_append_table_rows(taTag, "t5_InpTab_PA",num_rows_to_append, &row_new_index, &table_rows_tag ));
	
	for ( property_index = 0 ; property_index < num_rows_to_append; property_index++ )
	{


		//set value on table row tag
		CALLAPI(AOM_lock ( table_rows_tag [ property_index ] ) );
		CALLAPI(AOM_set_value_string(table_rows_tag [ property_index ], "t5_TAPart", "54678" ));
		CALLAPI(AOM_set_value_string(table_rows_tag [ property_index ], "t5_PArev","B" ));
		CALLAPI(AOM_set_value_string(table_rows_tag [ property_index ], "t5_PAseq","2" ));
		CALLAPI(AOM_save_with_extensions ( table_rows_tag [ property_index ] ) );
		CALLAPI(AOM_unlock ( table_rows_tag [ property_index ] ) );
		CALLAPI(AOM_refresh ( table_rows_tag [ property_index ],TRUE ) );
	}			
	
	CALLAPI(AOM_save_with_extensions ( taTag ) );
	CALLAPI(AOM_unlock ( taTag ) );
	CALLAPI(AOM_refresh ( taTag,TRUE ) );	
	
	
	
	printf("\nSAN:tmAddTATableRowData,, END------------------"); fflush(stdout);
	return ifail;
	
}





int tm_SolveAndGetUnitBom_New(tag_t bom_window,tag_t pltFrmTag, tag_t svrTag,int *cnt, tag_t **moduleList)
{
	int ifail = ITK_ok;
	tag_t view_type = NULLTAG;
	tag_t pltFrmItemTag = NULLTAG;
	int n_bom_views = 0;
	tag_t* bom_views = NULLTAG;
	tag_t bom_view = NULLTAG;
	
	//tag_t bom_window = NULLTAG;
	tag_t revRule = NULLTAG;
	
	tag_t* closureRules = NULLTAG;
	int ruleFound = 0;
	tag_t closureRuleTag = NULLTAG;
	tag_t top_line = NULLTAG;
	//tag_t bom_variant_rule = NULLTAG;
	//tag_t bomVariantTypeTag = NULLTAG;
	//char bom_var_type_name[TCTYPE_name_size_c+1];
	//tag_t var_exp_block = NULLTAG;
	
	tag_t* lines = NULLTAG;
	int n_lines = 0;
	
	int i=0;
	tag_t childObj = NULLTAG;
	char* child_item_id = NULL;
	
	int n_lines2 = 0;
	tag_t* lines2 = NULLTAG;
	
	//int n_optns = 0;
	//tag_t* options = NULLTAG;
	//tag_t* option_revs = NULLTAG;
	
	int n_lines1 = 0;
	logical is_bom_modified = FALSE;
	
	int j=0;
	int k =0;
	
	tag_t childObj2 = NULLTAG;
	char* child_item_id2 = NULL;
	
	int n_lines3 = 0;
	tag_t* lines3 = NULLTAG;
	
	tag_t childObj3 = NULLTAG;
	char* child_item_id3 = NULL;
	//int IntAttr = 0;
	char* module_rel_status = NULL;
	
	
	printf("\n SAN:tm_SolveAndGetUnitBom: Start of funtion tm_SolveAndGetUnitBom\n");fflush(stdout);
	
	if(pltFrmTag != NULLTAG)
	{
		CALLAPI ( PS_find_view_type( "view", &view_type ));
		printf("\n SAN:tm_SolveAndGetUnitBom: PS_find_view_type is found......\n" ); fflush(stdout);

		if ( view_type != NULLTAG )
		{
			CALLAPI ( ITEM_ask_item_of_rev( pltFrmTag, &pltFrmItemTag ));
			CALLAPI ( ITEM_list_bom_views( pltFrmItemTag, &n_bom_views, &bom_views ));

			bom_view = bom_views[0];
		}
		else
			printf("\n SAN:tm_SolveAndGetUnitBom: View not found....\n"); fflush(stdout);		
	}
	
	
	if( bom_view != NULLTAG )
	{
		PIE_scope_t scope;
		//CALLAPI(BOM_create_window( &bom_window ));
		CALLAPI(CFM_find( "ERC release and above", &revRule ))
		//CALLAPI(CFM_find( "Latest Working", &revRule ))
		CALLAPI(BOM_set_window_config_rule( bom_window, revRule ));				
		CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",scope, &ruleFound, &closureRules ));
		printf ("\n SAN:tm_SolveAndGetUnitBom: Closure Rule count %d \n",ruleFound);fflush(stdout);
		
		if(ruleFound>0)
		{
			closureRuleTag = closureRules[0];
			printf("\n SAN:tm_SolveAndGetUnitBom: Closure Rule found....\n"); fflush(stdout);	
		}

		if(closureRuleTag!=NULLTAG) CALLAPI(BOM_window_set_closure_rule( bom_window,closureRuleTag, 0, NULL,NULL ));
		CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
		CALLAPI(BOM_set_window_top_line( bom_window, NULLTAG, pltFrmTag, NULLTAG, &top_line ));
		//CALLAPI(BOM_window_ask_variant_rule(bom_window, &bom_variant_rule ));
		
		//CALLAPI(TCTYPE_ask_object_type(bom_variant_rule,&bomVariantTypeTag));
		//CALLAPI(TCTYPE_ask_name(bomVariantTypeTag,bom_var_type_name));
		//printf("\n SAN:tm_SolveAndGetUnitBom: bom_var_type_name[%s]\n",bom_var_type_name);fflush(stdout);
		//Get the variant expression block associated with the specified Item Revision.
		//CALLAPI(ITEM_ask_rev_variants(pltFrmTag, &var_exp_block));
		
		if(top_line!=NULLTAG)
		{
			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
			printf("\n SAN:tm_SolveAndGetUnitBom: Before setting option n_lines: %d\n", n_lines);fflush(stdout);
			CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
			CALLAPI(BOM_window_show_variants(bom_window))   ;
						
			CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&svrTag))   ;
			printf("\n SAN:tm_SolveAndGetUnitBom: After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

			CALLAPI(BOM_window_hide_variants(bom_window))   ;

			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
			printf("\n SAN:tm_SolveAndGetUnitBom: After setting option n_lines: %d\n", n_lines);fflush(stdout);
			
			if(n_lines >0)
			{
				for (i=0;i<n_lines ;i++ )
				{
					if(childObj) childObj=NULLTAG;
					childObj=lines[i];
					CALLAPI(AOM_ask_value_string(childObj, "bl_item_item_id", &child_item_id ));

					CALLAPI(BOM_line_ask_child_lines(childObj, &n_lines2, &lines2));
					printf("\n SAN:tm_SolveAndGetUnitBom: [%d] child_item_id[%s] \t count [%d]",i+1,child_item_id,n_lines2);fflush(stdout);

				}				
			}
			
			 
			CALLAPI(CFM_find("ERC release and above", &revRule))
			//CALLAPI(CFM_find( "Latest Working", &rule ))
			
			//Apply Revision rule 
			CALLAPI(BOM_set_window_config_rule( bom_window, revRule));
			
			// get the list of options and their revisions referenced by the given BOM variant rule.
			//CALLAPI (BOM_variant_rule_ask_options( bom_variant_rule, &n_optns, &options, &option_revs ) )
			//printf("\n SAN:tm_SolveAndGetUnitBom: No of Option values in the rule:%d\n",n_optns);fflush(stdout);
			
			
			if(top_line!=NULLTAG )
			{
				
				CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
				printf("\n SAN:tm_SolveAndGetUnitBom: Before setting option n_lines1: %d \n", n_lines1);fflush(stdout);
				
				if(bom_window != NULLTAG)
				{
					CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
					CALLAPI(BOM_window_show_variants(bom_window))   ;
					printf("\n SAN:tm_SolveAndGetUnitBom: After inside bom_window apply variant condition\n"); fflush(stdout);			
					CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&svrTag))   ;
					printf("\n SAN:tm_SolveAndGetUnitBom: After BOM_window_apply_variant_configuration\n"); fflush(stdout);

					CALLAPI(BOM_window_hide_variants(bom_window))   ;
					CALLAPI(BOM_window_ask_is_modified(bom_window,&is_bom_modified));
					
					if(is_bom_modified)
					{
						printf("\n SAN:tm_SolveAndGetUnitBom: Bom is modified....\n");fflush(stdout);
					}
					else
					{
						printf("\n SAN:tm_SolveAndGetUnitBom: Bom is  not modified....\n");fflush(stdout);
					}
					
					CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
					printf("\n SAN:tm_SolveAndGetUnitBom: After setting option n_lines1: %d \n", n_lines1);fflush(stdout);
					
					printf("\n SAN:tm_SolveAndGetUnitBom: Get the unit bom (module) start...\n");fflush(stdout);
					
					if (n_lines1 >0)
					{
						int unitBomCnt=0;
						int strCnt = 0;
						char** strBuff = NULL;
						int foundStr = 0;
						for (j=0;j<n_lines1 ;j++ )
						{
							if(childObj2) childObj2=NULLTAG;
							childObj2=lines[j];
							CALLAPI(AOM_ask_value_string(childObj2, "bl_item_item_id", &child_item_id2));
							CALLAPI(BOM_line_ask_child_lines(childObj2, &n_lines3, &lines3));
							
							if(n_lines3 >0)
							{
								for (k=0;k<n_lines3 ;k++ )
								{
									if(childObj3) childObj3=NULLTAG;
									childObj3=lines3[k];
									CALLAPI(AOM_ask_value_string(childObj3, "bl_item_item_id", &child_item_id3 ));
									//CALLAPI(BOM_line_look_up_attribute ("bl_rev_last_release_status",&IntAttr));
									//CALLAPI(BOM_line_ask_attribute_string(childObj3, IntAttr, &module_rel_status));
									ifail = AOM_ask_value_string(childObj3,"bl_rev_last_release_status",&module_rel_status);
									
									//more than one module
									if(k>0)
									{
										t5FindStrInSet(strBuff,strCnt,child_item_id3,&foundStr);
										
										if(foundStr==1)
										{
											//t5AddStrToSet(&strCnt,&strBuff,child_item_id3);
											printf("\n SAN:tm_SolveAndGetUnitBom: Multi module case [%s]. Skip it\n",child_item_id3);fflush(stdout);
											continue;
											
										}
										else
										{
											printf("\n SAN:tm_SolveAndGetUnitBom: Multi module case [%s]. Check it \n",child_item_id3);fflush(stdout);
											printf("[%d]child_item_id3[%d]==>%s, module_rel_status===>%s\n",j,k,child_item_id3,module_rel_status);fflush(stdout);
											t5AddTagObjToSet(cnt,moduleList,childObj3);
											unitBomCnt++;
											break;											
											
										}

																				
									}
									else
									{
										printf("[%d]child_item_id3[%d]==>%s, module_rel_status===>%s\n",j,k,child_item_id3,module_rel_status);fflush(stdout);
										t5AddTagObjToSet(cnt,moduleList,childObj3);
										unitBomCnt++;
									}

									
									t5AddStrToSet(&strCnt,&strBuff,child_item_id3);

								}
							}
							
						}
						printf("\nTotal no of unit bom===>%d\n",unitBomCnt);fflush(stdout);
					}
					
					
					
				}
				
				
				
			}


			
			
			
		}
		
		
		
		
		
		//CALLAPI(BOM_save_window(bom_window))
		//CALLAPI(BOM_close_window(bom_window))
		
	}
	
	
	
	printf("\n SAN:tm_SolveAndGetUnitBom: End of funtion tm_SolveAndGetUnitBom\n");fflush(stdout);
	return ifail;
}



 int createTestApplicabilityObject(char * testAppNo, char* platformId, char* svrName, char* vehProg, char* projStr, char* plantStr, char* vertical, tag_t* newTAObj)
{
	int ifail = ITK_ok;
	tag_t rev_type_tag = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	char* itemId12 = NULL;
	tag_t item_type_tag = NULLTAG;
	tag_t taObjMaster = NULLTAG;
	char* itemId12rev = NULL;
	char* itemId12desc = NULL;
	char* ceditemId12desc = NULL;
	char* itemId12prtType = NULL;
	char* itemId12prjcode = NULL;
	char* itemId12DsgGrp = NULL;
	
	printf("\nSAN:creTAObj: Inside Test Applicability part creation logic...........\n");fflush(stdout);
	

	

	
	//TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);//T5_SparKitRevision
	
	
	
	TCTYPE_find_type("T5_TsAppRevision", NULL, &rev_type_tag);
	if(rev_type_tag!=NULLTAG)
	{
		
		printf("\nSAN:creTAObj:rev_type_tag Tag Found."); fflush(stdout);
		
		
		
		printf("\nSAN:Test Appl No===>%s\n",testAppNo);fflush(stdout);
		
		

		printf("\nCreating Test Applicability NR revision- first time.....\n");fflush(stdout);
		TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
		AOM_set_value_string(rev_create_input_tag, "object_name", testAppNo);
		AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR"); //itemId12rev
		
		AOM_set_value_string(rev_create_input_tag, "object_desc", testAppNo); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TA_SVR", svrName); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TA_VehPlatform", platformId); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TAProjCode", projStr); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TA_VehProgram", vehProg); //itemId12rev		
		AOM_set_value_string(rev_create_input_tag, "t5_TA_PlantName", plantStr); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TAVerticle", itemId12DsgGrp); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TAPart", vertical); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TARev", ""); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_TASeq", ""); //itemId12rev
		
		TCTYPE_find_type("T5_TsApp", NULL, &item_type_tag);
		if(item_type_tag!=NULLTAG)
		{
				printf("\nSAN:creTAObj: item_type_tag Tag Found."); fflush(stdout);
				
				
		}
		TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

		AOM_set_value_string(item_create_input_tag, "item_id", testAppNo);
		AOM_set_value_string(item_create_input_tag, "object_name", testAppNo);
		AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

		//Create CED Part and its  Revision
		TCTYPE_create_object(item_create_input_tag, &taObjMaster);
		
		if(taObjMaster!=NULLTAG)
		{
			printf("\nSAN:creTAObj: Test Applicability created."); fflush(stdout);					 
			AOM_save_with_extensions(taObjMaster);				
		}
		
		
		//Get Item revision
		tag_t * taObjRevList = NULLTAG;
		int ta_item_count = 0;
		tag_t taObjRev = NULLTAG;
		ITEM_list_all_revs (taObjMaster, &ta_item_count, &taObjRevList);
		
		if(ta_item_count>0)
		{
			taObjRev = taObjRevList[0];
			*newTAObj = taObjRev;
		}
		
		
	}


	return ifail;
}





typedef struct TestAggDetail_
{
	char TaAggNumber[100];
	char TaAggProjCode[10];
	char TaAggDesgGrp[10];
	//char TaAggRevision[10];
}TestAggDetail;

void setAddTestAggDetail(int *count,TestAggDetail **objlist,TestAggDetail obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (TestAggDetail *)malloc((*count ) * sizeof(TestAggDetail ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (TestAggDetail *)realloc((*objlist),(*count) * sizeof(TestAggDetail ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}


int tmCreateTaAggrObject(tag_t taObj, int testAggDetailCnt, TestAggDetail *testAggDetailList)
{
	int ifail = ITK_ok;
	int i=0;
	TestAggDetail testAggDet;
	printf("\nTest Agg creation logic- TODO\n");fflush(stdout);
	
	for(i=0;i<testAggDetailCnt;i++)
	{		
		
		tag_t rev_type_tag = NULLTAG;
		tag_t rev_create_input_tag = NULLTAG;
		tag_t item_create_input_tag = NULLTAG;
		char* itemId12 = NULL;
		tag_t item_type_tag = NULLTAG;
		tag_t taObjMaster = NULLTAG;
		char* itemId12rev = NULL;
		char* itemId12desc = NULL;
		char* ceditemId12desc = NULL;
		char* itemId12prtType = NULL;
		char* itemId12prjcode = NULL;
		char* itemId12DsgGrp = NULL;		

		
		TCTYPE_find_type("T5_TplDsgRevision", NULL, &rev_type_tag);
		
		if(rev_type_tag!=NULLTAG)
		{
			printf("\nSAN:creTAggObj:rev_type_tag Tag Found."); fflush(stdout);
			testAggDet = testAggDetailList[i];
			printf("\n testAggDetailList[%d]:%s",i,testAggDet.TaAggNumber);fflush(stdout);			
			
			
			
			printf("\nSAN:Test Agg  No===>%s\n",testAggDet.TaAggNumber);fflush(stdout);
			
			

			printf("\nCreating Test Aggregate NR revision- first time.....\n");fflush(stdout);
			
			TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
			AOM_set_value_string(rev_create_input_tag, "object_name", testAggDet.TaAggNumber);
			AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR"); //itemId12rev
			
			AOM_set_value_string(rev_create_input_tag, "object_desc", testAggDet.TaAggNumber); //itemId12rev
			AOM_set_value_string(rev_create_input_tag, "t5_TplProjCode", testAggDet.TaAggProjCode); //itemId12rev
			AOM_set_value_string(rev_create_input_tag, "t5_TplDsgGrp", testAggDet.TaAggDesgGrp); //itemId12rev
			
			TCTYPE_find_type("T5_TplDsg", NULL, &item_type_tag);
			if(item_type_tag!=NULLTAG)
			{
					printf("\nSAN:creTAggObj: item_type_tag Tag Found."); fflush(stdout);
					
					
			}
			TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

			AOM_set_value_string(item_create_input_tag, "item_id", testAggDet.TaAggNumber);
			AOM_set_value_string(item_create_input_tag, "object_name", testAggDet.TaAggNumber);
			AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

			//Create CED Part and its  Revision
			TCTYPE_create_object(item_create_input_tag, &taObjMaster);
			
			if(taObjMaster!=NULLTAG)
			{
				printf("\nSAN:creTAObj: Test Aggregate Object created."); fflush(stdout);					 
				AOM_save_with_extensions(taObjMaster);				
			}
			
			
			//Get Item revision
			tag_t * taObjRevList = NULLTAG;
			int ta_item_count = 0;
			tag_t taObjRev = NULLTAG;
			ITEM_list_all_revs (taObjMaster, &ta_item_count, &taObjRevList);
			
			if(ta_item_count>0)
			{
				taObjRev = taObjRevList[0];
				
				if(taObjRev!=NULLTAG)
				{
					
					CALLAPI(relatePrimaryWithSecondaryObj(taObj,taObjRev,"T5_TAHasAgg"));
					CALLAPI(relatePrimaryWithSecondaryObj(taObjRev,taObj,"T5_AggHasTA"));
					
				}				

			}
			
			
		}

			
	}
	
	return ifail;
}




int tmCreateTestAppliGeneric(char * testAppNo, char* platformId, char* svrName, char* vehProg, char* projStr, char* plantStr, char* vertical, char **resultStr)
{
	int ifail = ITK_ok;
	
	printf("\nSAN:tmCreateTestAppliGeneric,, START------------------"); fflush(stdout);
	
	*resultStr ="FALSE";
	

	tag_t	svrTag = NULLTAG;
	tag_t	pltFrmTag	=	NULLTAG;
	tag_t * moduleList = NULLTAG;
	int cnt = 0;
	
	printf("\nInput parameters:\nTest Applicability No: %s\nPlatform: %s\nSVR:%s\nProgram:%s\nProject:%s\nPlant:%s\nVertical:%s\n",testAppNo,platformId,svrName,vehProg,projStr,plantStr,vertical);fflush(stdout);
	
	//Get Platform Revision Tag

	
	CALLAPI(getItemRevObject(platformId,"T5_PlatformRevision",&pltFrmTag));
	if(pltFrmTag==NULLTAG)
	{
		printf("\n SAN:tmCreateTestAppliGeneric: No Platform revision found with name as %s\n",platformId);fflush(stdout);
		*resultStr ="NOPLATFORM";
		return ifail;
	}	
	
	//Get SVR tag
	CALLAPI(getGeneralObject(svrName,"VariantRule",&svrTag));
	if(svrTag==NULLTAG)
	{
		printf("\n SAN:tmCreateTestAppliGeneric: No Variant Rule found with name as %s\n",svrName);fflush(stdout);
		*resultStr ="NOSVR";
		return ifail;
	}
	
	//Create Test Applicability Object
	
	//int createTestApplicabilityObject(char * testAppNo, char* platformId, char* svrName, char* vehProg, char* projStr, char* plantStr, char* vertical, tag_t* newTAObj)
	tag_t newTAObj = NULLTAG;
	CALLAPI(getGeneralObject(testAppNo,"T5_TsAppRevision",&newTAObj));
	if(newTAObj==NULLTAG)
	{
		printf("\nNew TA object going to create\n");fflush(stdout);
		CALLAPI(createTestApplicabilityObject(testAppNo,platformId,svrName,vehProg,projStr,plantStr,vertical, &newTAObj));
	
		if(newTAObj!=NULLTAG)
		{
			printf("\nNew TA object created\n");fflush(stdout);
		}
		else
		{
			printf("\nNew TA object NOT created\n");fflush(stdout);
			*resultStr ="TANOTCREATED";
			return ifail;
		}
		
	}
	else
	{
		printf("\n Test Applicability object %s already exists\n",testAppNo);fflush(stdout);
		
	}
	
	
	tag_t bom_window = NULLTAG;
	CALLAPI(BOM_create_window( &bom_window ));
	
	CALLAPI(tm_SolveAndGetUnitBom_New(bom_window, pltFrmTag,svrTag,&cnt,&moduleList))
	
	printf("\n SAN:tmCreateTestAppliGeneric: No of Modules=====>%d\n",cnt);fflush(stdout);
	
	TestAggDetail * testAggDetailList = NULL;
	int testAggDetailCnt =0;
	
	if(cnt >0)
	{
		int i=0;
		for(i=0;i<cnt;i++)
		{

			tag_t moduleOccTag = NULLTAG;
			char* objTyp = NULL;
			moduleOccTag= moduleList[i];
			if(moduleOccTag!=NULLTAG)
			{
				char* partNum = NULL;
				CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_item_item_id",&partNum));
				CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_item_object_type",&objTyp));

			
				if(tc_strcmp(objTyp,"Design")==0)
				{
					

					char* partType = NULL;

					CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_Design Revision_t5_PartType",&partType));
					
					

					if(tc_strcmp(partType,"M")==0)
					{
						
						char* partRv = NULL;
						char* level = NULL;
						char* moduleAdd = NULL;
						char* desGrp = NULL;
						char* projCodeS = NULL;
						TestAggDetail testAggObj;
						
						CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_rev_item_revision_id",&partRv));
						
						CALLAPI(AOM_UIF_ask_value(moduleOccTag,"bl_level_starting_0",&level));
						
						CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_Design Revision_t5_ModuleAddress",&moduleAdd));
						CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_Design Revision_t5_DesignGrp",&desGrp));
						CALLAPI(AOM_ask_value_string(moduleOccTag,"bl_Design Revision_t5_ProjectCode",&projCodeS));
						printf("\n%s, %s, %s,%s,%s,%s", level,partNum,partRv, partType,moduleAdd,desGrp);fflush(stdout);
						printf("\nTA_%s_%s",svrName,moduleAdd);fflush(stdout);
						


						char* tstAggNo = (char*)MEM_alloc(100*sizeof(char));
						sprintf(tstAggNo,"TA_%s_%s",svrName,moduleAdd);
						tc_strcpy(testAggObj.TaAggNumber,tstAggNo);
						MEM_free(tstAggNo);
						
						tc_strcpy(testAggObj.TaAggProjCode,projCodeS);
						tc_strcpy(testAggObj.TaAggDesgGrp,desGrp);
						//tc_strcpy(testAggObj.TaAggProjCode,partRv);
						
						setAddTestAggDetail(&testAggDetailCnt,&testAggDetailList,testAggObj);
												
						
						
						
						
						

						
					}
					else
					{
						//printf("\nSkip - Part type not Module\n");fflush(stdout);
						printf("\n Skip - Part type not Module- Part Number==> %s , Part Type ==> %s\n",partNum, partType);fflush(stdout);
					}

				}
				else
				{
					printf("\n Skip - Object type not Design- Part Number==> %s , Part Type ==> %s\n",partNum, objTyp);fflush(stdout);
				}
			}

			
			
		}
	}
	
	CALLAPI(BOM_close_window(bom_window))
		
	
	
	printf("\nTest Aggregate Object count===>%d\n",testAggDetailCnt);
	
	if(testAggDetailCnt >0)
	{
		CALLAPI(tmCreateTaAggrObject(newTAObj, testAggDetailCnt,testAggDetailList));
		*resultStr ="TSAGGCREATED";
	}
	else
	{
		printf("\n No test eligible test agg objects to be created\n");fflush(stdout);
		*resultStr ="TSAGGNOTCREATED";
	}
	
	
	printf("\nSAN:tmCreateTestAppliGeneric,, END------------------"); fflush(stdout);
	
	return ifail;
	
}





int tmTestApplCreServGeneric(void *retValue)
{
	printf("\nTA: Service:Start----tmTestApplCreServGeneric....\n");fflush(stdout);
	
	const char	*prog_name 	="tmTestApplCreServGeneric";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	
	char* testAppNo = NULL;
	char* platform = NULL;
	char* svrNo = NULL;
	char* vehProg = NULL;
	char* projectNo = NULL;
	char* plant = NULL;
	char* vertical = NULL;
	char *resultStr = NULL;
	char * resultStr1 = NULL;
;
	USERARG_get_string_argument(&testAppNo);
	USERARG_get_string_argument(&platform);
	USERARG_get_string_argument(&svrNo);
	USERARG_get_string_argument(&vehProg);
	USERARG_get_string_argument(&projectNo);
	USERARG_get_string_argument(&plant);
	USERARG_get_string_argument(&vertical);
	
	printf("\nTest App No:%s\nPlatform:%s\nSVR:%s\nProgram:%s\nProject:%s\nPlant:%s\nVertical:%s\n",testAppNo,platform,svrNo,vehProg,projectNo,plant,vertical);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );


	printf("\nTAPPL: Output result string: %s", resultStr);fflush(stdout);
	
	//int tmCreateTestAppliGeneric(char * testAppNo, char* platformId, char* svrName, char* vehProg, char* projStr, char* plantStr, char* vertical, char* resultStr)
	CALLAPI(tmCreateTestAppliGeneric(testAppNo, platform, svrNo,vehProg, projectNo, plant, vertical, &resultStr));
					

	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("After returning Value\n");fflush(stdout);	
	printf("\nTA :Test Applicability  Service:End----tmTestApplCreServGeneric....\n");fflush(stdout);
	return ifail;	
	
}

extern int tmTestApplCreFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
	int n_args = 7;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_STRING_TYPE;//Test Applicability No
	input_arg_type[1]=USERARG_STRING_TYPE;//Platform  
	input_arg_type[2]=USERARG_STRING_TYPE;//SVR no
	input_arg_type[3]=USERARG_STRING_TYPE;//Veh Prog Str
	input_arg_type[4]=USERARG_STRING_TYPE;//project str
	input_arg_type[5]=USERARG_STRING_TYPE;//plant 
	input_arg_type[6]=USERARG_STRING_TYPE;//vertical str
	ret_value_type = USERARG_STRING_TYPE;
	
	//printf("\n TA: Test Applicability creation services start: Before registering tmTestApplCreServGeneric userservice...");  
	ifail=USERSERVICE_register_method("tmTestApplCreServGeneric",(USER_function_t)tmTestApplCreServGeneric,n_args,input_arg_type,ret_value_type);
	
	//printf("\n TA: Test Applicabilityservices End: After registering tmTestApplCreServGeneric userservice...."); 
	
	
	
	return ifail;
}



extern DLLAPI int tm_TestAppl_register_callbacks ()
{	
    int ifail    = ITK_ok;
	
	//printf("\n Started- Registering user service function tmTestApplCreFn...");
	ifail=CUSTOM_register_exit ( "tm_TestAppl", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tmTestApplCreFn);//user service not use
	//printf("\n Completed- Registering user service function tmTestApplCreFn...");
	
  return ( ITK_ok );
}

