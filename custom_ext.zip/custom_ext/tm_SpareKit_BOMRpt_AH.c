/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   
*  Code                 :   tm_Part_Ref_Drw_AH.c
*  Created on			:   04/01/2024
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_SpareKit_BOMRpt_AH(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *task_id		= NULL;
	char *RefDMLcommand		= NULL;
	char *RefInfo2		= NULL;
	char *RefInfo1		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     RefDR_rsltCount	= 0;
	char    *RefDR_qry_entry[1]  = {"SYSCD"};
	tag_t   *ReDRCntrlObjectTag   = NULLTAG;
	char    **RefDR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n tm_SpareKit_BOMRpt_AH Function started...");fflush(stdout);
	TC_write_syslog("\n tm_SpareKit_BOMRpt_AH Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_SpareKit_BOMRpt_AH::No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n tm_SpareKit_BOMRpt_AH:: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n tm_SpareKit_BOMRpt_AH:RefDrw:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n tm_SpareKit_BOMRpt_AH:RefDrw:Not Found Query ControlObjects \n");fflush(stdout);
				}

				RefDR_qry_values2[0] = "SPBOMRPT";
				if(QRY_execute(DRqryTag, DR_n_entry, RefDR_qry_entry, RefDR_qry_values2, &RefDR_rsltCount, &ReDRCntrlObjectTag));
				printf(" \n tm_SpareKit_BOMRpt_AH:RefDrw:RefDR_rsltCount:%d:", RefDR_rsltCount); fflush(stdout);
				if(RefDR_rsltCount > 0)
				{
					//On/OFF
					if (AOM_ask_value_string(ReDRCntrlObjectTag[0],"t5_Userinfo1",&RefInfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n tm_SpareKit_BOMRpt_AH:RefInfo1 is :[%s]\n", RefInfo1);fflush(stdout);
					//Path
					if (AOM_ask_value_string(ReDRCntrlObjectTag[0],"t5_Userinfo2",&RefInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n tm_SpareKit_BOMRpt_AH:RefInfo2 Path: [%s]\n", RefInfo2);fflush(stdout);
					if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &task_id));
					printf("\n tm_SpareKit_BOMRpt_AH:DML number-: %s ", task_id);fflush(stdout);
					if(strstr(RefInfo1,"SP002")==NULL)
					{
						printf("\n tm_SpareKit_BOMRpt_AH:PATHBase: \n");fflush(stdout);
						RefDMLcommand = (char	*)MEM_alloc(500);
						tc_strcpy(RefDMLcommand,"");
						tc_strcpy(RefDMLcommand,RefInfo2);
						tc_strcat(RefDMLcommand," ");
						tc_strcat(RefDMLcommand,task_id);
						tc_strcat(RefDMLcommand," ");
						printf("\n tm_SpareKit_BOMRpt_AH:RefDMLcommand: %s \n",RefDMLcommand);fflush(stdout);
						TC_write_syslog("tm_SpareKit_BOMRpt_AH RefDMLcommand = %s\n",RefDMLcommand);
						system(RefDMLcommand);
						printf("\n tm_SpareKit_BOMRpt_AH :PATHBase: successfully.. \n");fflush(stdout);
					}
					else
					{
						printf("\n tm_SpareKit_BOMRpt_AH:,,,,,,,,,,.. \n");fflush(stdout);
					}
				}
			}
		}
	}

	printf("\n tm_SpareKit_BOMRpt_AH Function end...");fflush(stdout);
	TC_write_syslog("\n tm_SpareKit_BOMRpt_AH Function end...");

	//return error_code;
	return 0;
}