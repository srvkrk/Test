#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <bom/bom_msg.h>
#include <tccore/grm.h>
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001

//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
int BomLineModuleValidaion(tag_t tag_bomLineParent,tag_t tag_child)
{
	int   Status			 = ITK_ok;
	char *sDesModuleAddress  = NULL;
	char *sArModAddress		 = NULL;
	char *sPartType			 = NULL;
	char *sObjectTypeArch	 = NULL;
	char *sObjectTypeModule	 = NULL;
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(tag_child,&ChildTagLatestRev));
	if((tag_bomLineParent) && (ChildTagLatestRev))
	{
		if(AOM_ask_value_string(tag_bomLineParent,"object_type",&sObjectTypeArch));
		if(AOM_ask_value_string(ChildTagLatestRev,"object_type",&sObjectTypeModule));
		if(AOM_ask_value_string(ChildTagLatestRev,"t5_PartType",&sPartType));
		printf("\n FILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n sObjectTypeArch => %s\n sObjectTypeModule=>%s\n Module t5_PartType=>%s",sObjectTypeArch,sObjectTypeModule,sPartType);fflush(stdout);
		if((tc_strcmp(sObjectTypeArch,"T5_ArchModuleRevision")==0) && (tc_strcmp(sObjectTypeModule,"Design Revision")==0) &&  (tc_strcmp(sPartType,"M")==0))
		{
			if(AOM_ask_value_string(tag_bomLineParent,"t5_ArchModuleAddress",&sArModAddress));
			if(AOM_ask_value_string(ChildTagLatestRev,"t5_ModuleAddress",&sDesModuleAddress));
			printf("\nFILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
			if(tc_strcmp(sArModAddress,sDesModuleAddress)!=0)
			{
				return 1;
			}
		}
	}
	return 0;
}
//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.

extern DLLAPI int  Save_Structure_method_4(METHOD_message_t *msg, va_list args)
{
	int Status = ITK_ok;
	int max_char_size = 80;
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag1=NULLTAG;
	
	int	ifail = 0;
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];

	int k,m,revision_count,result,child_count,i_ChildCount = 0;
	tag_t *bvrs_tag = NULLTAG;
	tag_t *revisions = NULLTAG;
	tag_t item_of_rev = NULLTAG;
	tag_t			*t_PartChildren								= NULLTAG;
	
	char *object_type = NULL;
	char *PartType = NULL;
	char *objectString = NULL;

	char *bl_object_type = NULL;
	char *bl_PartType = NULL;
	char *bl_objectString = NULL;
	char *sUserLogin;
	tag_t	user_tag =NULLTAG;

	tag_t rev=NULLTAG;
	tag_t bl_rev=NULLTAG;
	tag_t rev_Parent=NULLTAG;
	tag_t parent_rev_tag = NULLTAG;
	tag_t  	item = NULLTAG;
	
	va_list largs;
	va_copy(largs, args );

	tag_t  parent_tag	= va_arg(largs, tag_t);
	tag_t  item_tag		= va_arg(largs, tag_t);
	tag_t  itemRev_tag	= va_arg(largs, tag_t);
	tag_t  bv_tag		= va_arg(largs, tag_t);		
	char *occType		= va_arg(largs, char *);	
	tag_t *newBomline_tag = va_arg(largs, tag_t *);
	tag_t gde_tag		= va_arg(largs, tag_t);	

	printf("\n Going inside method Save_Structure_method_4...........\n");
	if(parent_tag)printf("\n found 1\n");fflush(stdout);
	if(item_tag)printf("\n found 2\n");fflush(stdout);
	if(itemRev_tag)printf("\n found 3\n");fflush(stdout);
	if(bv_tag)printf("\n found 4\n");fflush(stdout);	
	if(*occType)printf("\n found 5\n");fflush(stdout);
	if(*newBomline_tag)printf("\n found 6\n");fflush(stdout);
	if(gde_tag)printf("\n found 7\n");fflush(stdout);
	
	if(TCTYPE_ask_object_type(parent_tag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n Save_Structure_method_4 primary_object  type_name :: %s\n", type_name);fflush(stdout);  //BOMLine
	
	//To Drop Object
	if(AOM_ask_value_tag(parent_tag,"bl_revision", &parent_rev_tag));
	if(parent_rev_tag)printf("\n bl_revision found...\n");fflush(stdout);
	
	if(ITEM_ask_item_of_rev(parent_rev_tag,&item));	
	if(item)printf("\n item...\n");fflush(stdout);

	if(ITEM_ask_latest_rev(item,&bl_rev));
	if(bl_rev)printf("\n bl_rev..\n");fflush(stdout);

//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
	POM_get_user(&sUserLogin,&user_tag);
	if((tc_strcmp(sUserLogin,"loader")!=0) && (tc_strcmp(sUserLogin,"infodba")!=0))
	{
		if((bl_rev != NULLTAG) && (BomLineModuleValidaion(bl_rev,item_tag)>0) )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Architecture Module Revision Address and Module Address is not same.");
			return ITK_errStore;	
		}
	}
	else
	{
		printf("\n\t BYPASS:Architecture Module Revision Address and Module Address Validaion for infodba and loader Login\n Cureent Login:%s ",sUserLogin);fflush(stdout);
	}
//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
	if(bl_rev != NULLTAG)
	{
		if(AOM_ask_value_string(bl_rev,"object_type",&bl_object_type));
		printf("\n\t object_type => %s\n",bl_object_type);fflush(stdout);

		if(AOM_ask_value_string(bl_rev,"t5_PartType",&bl_PartType));
		printf("\n\t t5_PartType => %s\n",bl_PartType);fflush(stdout);

		if(AOM_ask_value_string(bl_rev,"object_string",&bl_objectString));
		printf("\n\t object_string => %s\n",bl_objectString);fflush(stdout);
	}

	//Droping Object
	if(TCTYPE_ask_object_type(item_tag,&objTypeTag1));
	if(TCTYPE_ask_name(objTypeTag1,type_name2));
	printf("\n Save_Structure_method_4 primary_object  type_name2 :: %s\n", type_name2);fflush(stdout);
	
	if(ITEM_ask_latest_rev(item_tag,&rev));
	if(rev)printf("\n rev\n");fflush(stdout);

	if(rev != NULLTAG)
	{
		if(AOM_ask_value_string(rev,"object_type",&object_type));
		printf("\n\t object_type => %s\n",object_type);fflush(stdout);

		if(AOM_ask_value_string(rev,"t5_PartType",&PartType));
		printf("\n\t t5_PartType => %s\n",PartType);fflush(stdout);

		if(AOM_ask_value_string(rev,"object_string",&objectString));
		printf("\n\t object_string => %s\n",objectString);fflush(stdout);
	}

	if(ITEM_list_all_revs (item_tag, &revision_count, &revisions));
	printf("\n ITEM_list_all_revs.... %d\n",revision_count);fflush(stdout);
	
	if((tc_strcmp(bl_object_type,"Design Revision")==0) && (tc_strcmp(bl_PartType,"C")==0))
	{
		printf("\n inside Cmponent Part......");fflush(stdout);	

		//EMH_store_error_s2(EMH_severity_error,ITK_err,"Cmponent can't have Structure","please check PartType");
		EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Cmponent can't have Structure","please check PartType of",bl_objectString);
		
		return ITK_errStore;		
	}
	
	return Status;
}

extern int checkValidation_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
    METHOD_id_t  method1 ;
    *decision = ALL_CUSTOMIZATIONS;  

	printf("\n\n checkValidation.c:it, via Custom Exits.\n");fflush(stdout);
    if (METHOD_find_method("BOMLine", BOMLine_add_msg, &method1) !=ITK_ok);
 
    if (method1.id != NULLTAG)
	{
		printf("\n Method is found for BOMLine_add_msg on Design Revision\n");fflush(stdout);
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) Save_Structure_method_4, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	}

    return ifail;
}

extern DLLAPI int checkValidation_register_callbacks()
{
      CUSTOM_register_exit ( "checkValidation", "USER_init_module", (CUSTOM_EXIT_ftn_t) checkValidation_register_method);
	  printf("\n registered function checkValidation_register_method......\n");	fflush(stdout);      
	  return ( ITK_ok );
}
