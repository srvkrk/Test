#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_Veh_Task_Check(EPM_rule_message_t msg)
{
	int	ifail = ITK_ok;
	int	Breakdowncount = ITK_ok;
	int	r,j,countt,no_attach,i;
	int	taskflag;
	char* DML_no=NULL;
	char* objType=NULL;
	char *DMLtype= NULL;
	char *objTypeofDML= NULL;
	char * Breakdownobj= NULL;
	char * sDMLno= NULL;
	char * objTypeofTask= NULL;
	tag_t DMLRevTag  = NULLTAG;
	tag_t  objTypTag = NULLTAG;
	tag_t  DML_tag = NULLTAG;
	tag_t  DMLRevTg = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  *BreakdowncountTags = NULLTAG;
	tag_t  *DMLRevision = NULLTAG;
	tag_t  *taskAttachments = NULLTAG;
	tag_t  roottask = NULLTAG;
	tag_t  DMLTaskTag = NULLTAG;

	logical is_latest;
	EPM_decision_t decision = EPM_nogo;

	printf("\n Start--Inside tm_Veh_Task_Check Rule handler----------------");fflush(stdout);

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_Veh_Task_Check--No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	char *dmlTaskNo =(char *) MEM_alloc(sizeof(char)* 50);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			DMLTaskTag=taskAttachments[i];

			if (DMLTaskTag != NULLTAG)
			{
				if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
				printf("\n tm_Veh_Task_Check--DML Task No: [%s] \n", dmlTaskNo);fflush(stdout);

				if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag)!=ITK_ok)PrintErrorStack();
				printf("\n tm_Veh_Task_Check--objtype found \n");fflush(stdout);

				if(TCTYPE_ask_name2(objTypTag,&objTypeofTask)!=ITK_ok)PrintErrorStack();
				printf("\n tm_Veh_Task_Check--object_type is %s\n", objTypeofTask);fflush(stdout);

				if(tc_strcmp(objTypeofTask,"T5_ChangeTaskRevision")==0)
				{
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					if (tsk_dml_rel_type!=NULLTAG)
					{
						ITK_CALL(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision));
						printf("\n tm_Veh_Task_Check--DML Revision from Task for : %d",countt);fflush(stdout);

						taskflag=0;
						for (j=0;j<countt ;j++ )
						{
							ITK_CALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
							printf("\n tm_Veh_Task_Check--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n tm_Veh_Task_Check--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								DMLRevTg = DMLRevision[j];
								ITK_CALL(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno));

								ITK_CALL(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype));
								printf("\n tm_Veh_Task_Check--t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);
								if ((tc_strcmp(DMLtype,"TODR")==0)||(tc_strcmp(DMLtype,"Veh")==0))	//for Gate Maturation and Vehicle release
								{
									taskflag=0;

									ITK_CALL(AOM_ask_value_string(DMLRevTg,"item_id",&Breakdownobj));
									printf("\n tm_Veh_Task_Check--for Task Obj = %s \n",Breakdownobj);fflush(stdout);

									if (tc_strstr(Breakdownobj,"_00"))
									{
										taskflag=1;
									}
								}

								printf("\n tm_Veh_Task_Check--taskflag= %d ",taskflag);fflush(stdout);

								if (taskflag==1)
								{
									printf("\t tsk found \n"); fflush(stdout);

									decision = EPM_go;
								}
								else
								{
									printf("\n 00_tsk not found \n");fflush(stdout);

									decision = EPM_nogo;
									
								}
							}
						}
					}
				}
			}
			else
			{
				printf("\n tm_Veh_Task_Check--DML Task tag is null found hence skipping...??? \n\n"); fflush(stdout);
			}
		}
	}

	printf("\n tm_Veh_Task_Check--Completed \n\n"); fflush(stdout);

	return decision;
}
