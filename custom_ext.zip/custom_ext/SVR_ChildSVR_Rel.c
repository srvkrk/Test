/********************************************************************************************************
*  File			: SVR_ChildSVR_Rel.c
*  Created By	: Bhaskar Dimble
*  Created On	: 07-Jan-2019
*  Project		: TCUA 	 
*  Purpose		: Custom user exit for - SVR adn Child SVR relation creation
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"

extern DLLAPI int SVR_ChildSVR_Rel(METHOD_message_t *msg, va_list args)
{
  	va_list largs;
	va_copy( largs, args );

	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	tag_t  *new_relation = va_arg(largs, tag_t *);
	char* relation_name=NULL;
	//tag_t		   relation_type	= NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  tsk_dml_rel_type=NULLTAG;
	tag_t  *DMLTask=NULLTAG;
	tag_t  *DMLRevision=NULLTAG;
	
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	logical		   copy_flag		= (logical)   va_arg (args, int);
	int		       ifail=0,cnt=0,i=0,ij=0,count=0,count_asm=0;
	GRM_relation_t *primary_list	= NULLTAG;
	char		   *is_chkout		=NULL;
	char *objname = NULL;
	char *objname1 = NULL;
	char		   *is_chkout1		=NULL;
	char		   *org_rev_id		=NULL;
	char		   *org_item_cat		=NULL;
	char		   *sPartID		=NULL;
	//tag_t		   primary_object	= NULLTAG;
	tag_t		   *tags	= NULLTAG;
	tag_t			objTypeTag									= NULLTAG;
	tag_t			objTypeTag2									= NULLTAG;
	tag_t			objTypeTag1									= NULLTAG;
	char *Svr_Rev	   = NULL;
	char *Svr_Rev1	   = NULL;
	tag_t DMLRevTag = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLtaskRevTag = NULLTAG;
	char* type_name = NULL;
	char* type_name2 = NULL;
	char* type_name1 = NULL;

	printf("\n SVR_ChildSVR_Rel Function started...");fflush(stdout);
	TC_write_syslog("\n SVR_ChildSVR_Rel Function started...");

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	 if( AOM_ask_value_string(primary_object,"object_name",&objname1)!=ITK_ok);
	 if(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	 if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));

	 if(GRM_list_primary_objects_only(primary_object,DcrProblmItemsRelType,&count,&DMLTask));
	 	Svr_Rev1=subString(objname1,4,6);

							
    if(tc_strcmp(type_name,"VariantRule")==0) 
	{
      if(tc_strcmp(Svr_Rev1,"SUPSVR")==0)
		{
		 if(secondary_object!=NULLTAG)
			   {
				   if(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
				   if(TCTYPE_ask_name2(objTypeTag2,&type_name2));
				   if( AOM_ask_value_string(secondary_object,"object_name",&objname)!=ITK_ok);
				   printf("\n T5TaskToPartCreateVal secondary_object  type_name2 :: %s\n", type_name2);fflush(stdout);

				   

					printf("\n Inside SVR to SVR relation \n");fflush(stdout);
					if(relation_type != NULLTAG)
					{
						if(TCTYPE_ask_name2(relation_type,&relation_name));
					}
					printf("\n Neww relation_name  with SVR and Child SVR:%s \n",relation_name);fflush(stdout);

						if(tc_strcmp(relation_name,"T5_HasChildSVR")==0)
							{
							 if(tc_strcmp(type_name2,"VariantRule")!=0)
								{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You Can not attach objects other than SVR to Has Child SVR Relation.");
								return ITK_err;
								}

						 else
						{
							if(tc_strcmp(type_name2,"VariantRule")==0)
								{
									Svr_Rev=subString(objname,4,6);

										if(tc_strcmp(Svr_Rev,"SUPSVR")==0)
										{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Creating relation of Super SVR with Super SVR is not allowed. Kindly copy Child SVR as normal SVR");
											return ITK_err;
										}
										else
											{
													 for (ij=0;ij<count ;ij++ )
														{
																 DMLtaskRevTag = DMLTask[ij];
																 if(TCTYPE_ask_object_type(DMLtaskRevTag,&objTypeTag1));
																 if(TCTYPE_ask_name2(objTypeTag1,&type_name1));
																 printf("\n\n type name11 %s\n ",type_name1);fflush(stdout);
																  if(tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0)
																	{
																	  if(GRM_list_primary_objects_only(DMLtaskRevTag,tsk_dml_rel_type,&cnt,&DMLRevision));
																	  printf("\n\n DML count %d\n ",cnt);fflush(stdout);
																	  if (cnt > 0)
																	  {
																		  DMLRevTag = DMLRevision[0];
																		  if(EPM_ask_active_job_for_target(DMLRevTag,&i,&parents));
																		  printf("\n\n DML active process count %d\n ",i);fflush(stdout);
																		  if (i>0)
																		  {
																			  EMH_store_error_s1(EMH_severity_error,ITK_err,"'Has Child SVR' relation cannot be created when DML is active in workflow");
																			  return ITK_err;
																		  }

																	  }

																	  

																	}
														}
													
											}
						}
						}	
							 }


				}
		}
		else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Parent Should be Super SVR for creation the Has Child SVR Relation");
									return ITK_err;
					}
	}

    //return ifail;
	printf("\n SVR_ChildSVR_Rel Function end...");fflush(stdout);
	TC_write_syslog("\n SVR_ChildSVR_Rel Function end...");
	return 0;
}  