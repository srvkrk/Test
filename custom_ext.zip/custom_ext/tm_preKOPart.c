/****************************************************************************************************
*  File          :tm_preKOpart.c
*  Created By    :ASJ
*  Created On    :16-JUL-2020
*  Purpose       :PreKOParts Creation, Save, Check in, check out, Revise Validations
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes

******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 919006
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 7)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

/************************* Adi ****************/
#define ERROR_CALL(x){               \
						int stat;                     \
						char *err_string = NULL;             \
						if( (stat = (x)) != ITK_ok)   \
						{                             \
						EMH_ask_error_text (stat, &err_string);              \
						if(err_string != NULL) {\
						printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
						printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
						TC_write_syslog("FORM Property Migiration[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
						MEM_free (err_string);\
						err_string=NULL;\
						}\
						return (stat);          \
						}                         \
					}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
char* subString (char* mainStringf, int fromCharf, int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
t5removeAllReleaseStatus (tag_t rev)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	ERROR_CALL (WSOM_ask_release_status_list(rev,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_save_instances(1,&rev,1));

				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));

				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save_without_extensions(rev));
				CALLAPI(AOM_refresh(rev,1));

			}

			 CALLAPI(AOM_unlock(rev));
		}
		printf("\n Status removed");;fflush(stdout);
	}
		/*ERROR_CALL (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
		ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));
		//ERROR_CALL(ITK_set_bypass(TRUE));

		ERROR_CALL(AOM_refresh(rev,1));
		ERROR_CALL(AOM_save_without_extensions(rev));
	*/
		//ERROR_CALL(AOM_unlock(rev));
}
extern DLLAPI int save_method_preKO(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;

	char		*vodNum		= NULL;
	char		*LR_ind		= NULL;
	char		*proj		= NULL;
	char		*Docnamever		= NULL;
	char		*FullVer		= NULL;
	char		*Docnamesrl		= NULL;
	char		*LRVal		= NULL;
	char		*Desc_obj2		= NULL;
	char		*Docnameproj		= NULL;	
	char		*typ_name		= NULL;	
	tag_t prekotag1=NULLTAG;
	tag_t	attr_id ;
	//char   typ_name[TCTYPE_name_size_c+1];
	tag_t prekotag =va_arg(args, tag_t);

	ITK_CALL(TCTYPE_ask_object_type(prekotag,&prekotag1)!= ITK_ok);
	ITK_CALL(TCTYPE_ask_name2(prekotag1,&typ_name)!= ITK_ok);
		printf("\n inside %s",typ_name);fflush(stdout);
	if(tc_strcmp(typ_name,"T5_preKOPartRevision")==0)
	{
		printf("\n inside T5_preKOPartRevision save1");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(prekotag,"item_id",&vodNum)!=ITK_ok);
		printf("\n inside T5_preKOPartRevision save2");fflush(stdout);

		if (AOM_ask_value_string(prekotag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\nDesc_obj1  = [%s]\n", Desc_obj2);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id","T5_VODRevision",&attr_id))	PrintErrorStack();

		if(strcmp(Desc_obj2,"NR")==0 )
		{
			printf("\nInside preko Part NR check...\n");fflush(stdout);
			if(AOM_lock(prekotag))PrintErrorStack();
			if(POM_set_attr_string(1,&prekotag,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save_without_extensions(prekotag))PrintErrorStack();
			if(AOM_unlock(prekotag))PrintErrorStack();
			if(AOM_refresh(prekotag,1))PrintErrorStack();

			printf("\nNR;1 updated\n");fflush(stdout);
			
			//if(RELSTAT_create_release_status("ERC Review",&status_rel))PrintErrorStack();
			//if(RELSTAT_add_release_status(status_rel,1,&prekotag,retain))PrintErrorStack();
		}
	}
}

extern DLLAPI int preKO_Check_out_Post(METHOD_message_t *msg, va_list args)
{
	tag_t			prekotag									=va_arg(args, tag_t);
//	const char		*reason										= va_arg (args, const char*);
//	const char		*change_id									= va_arg (args, const char*);
//	const char		*dir_name									= va_arg (args, const char*);
//	int				reservation_type							= va_arg (args, int);
	
	const char		*reason		= "preKOPart";
	const char		*change_id	= NULL;
	const char		*dir_name	= NULL;

	int			error_code			= ITK_ok;
	tag_t prekotag1=NULLTAG;
	//char   typ_name[TCTYPE_name_size_c+1];	
	char *vodNum		= NULL;
	char *rev		= NULL;
	char *typ_name		= NULL;
	logical retain=false;
	tag_t           status_rel                                  = NULLTAG;
		logical	checkout		= 0;




	ITK_CALL(TCTYPE_ask_object_type(prekotag,&prekotag1)!= ITK_ok);
	ITK_CALL(TCTYPE_ask_name2(prekotag1,&typ_name)!= ITK_ok);
	printf("\n inside %s",typ_name);fflush(stdout);
	if (AOM_ask_value_string(prekotag,"item_revision_id",&rev)!=ITK_ok)   PrintErrorStack();
	printf("\n rev  = [%s]\n", rev);fflush(stdout);
	if(tc_strcmp(typ_name,"T5_preKOPartRevision")==0)
	{
		if(RES_is_checked_out(prekotag,&checkout)) PrintErrorStack();
		if (checkout==0 && tc_strcmp(rev,"NR;1")==0)
		{	
			printf("\n preKO_Check_out_Post check out for NR creation");fflush(stdout);
			ITK_CALL (RELSTAT_create_release_status("T5_LcsWorking",&status_rel));
			printf("\n preKO_Check_out_Post 1");fflush(stdout);
			ITK_CALL(RELSTAT_add_release_status(status_rel,1,&prekotag,retain));
			printf("\n preKO_Check_out_Post 2");fflush(stdout);
			ITK_CALL(RES_checkout2(prekotag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE));
			printf("\n preKO_Check_out_Post 3");fflush(stdout);
			printf("\n VOD Checked NR \n");fflush(stdout);

		}
		else
		{
			printf("\n either part is checked out or revision is not NR");fflush(stdout);
		}
	}
	return error_code;
}
extern DLLAPI int preKORevCheckOutValidation(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);

	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;

	//char	type_name[TCTYPE_name_size_c+1];
	char	*vodPrtNum		= NULL;
	char	*PartRevSeq		= NULL;
	char	*PEDesc			= NULL;
	char	*PEPrtRelStat	= NULL;
		char *vodNum		= NULL;
		char *type_name		= NULL;


	logical retain=false;

	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);
	tag_t           status_rel                                  = NULLTAG;
	logical	checkout		= 0;

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	//POM_get_user(&username,&user_tag);
	
	//printf("\nInside tm_VODRevision : PECheckInValidation Session user %s\n",username);fflush(stdout);
	printf("\ntm_VOD : preKORevCheckOutValidation PreAction objTypeTag [%s]\n",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_preKOPartRevision")==0)
		{
				printf("\n inside preKORevCheckOutValidation");fflush(stdout);
			//ITK_CALL(AOM_ask_value_string(objTypeTag,"item_id",&vodNum)!=ITK_ok);
			//ITK_CALL (RELSTAT_create_release_status("T5_LcsWorking",&status_rel));
			//ITK_CALL(RELSTAT_add_release_status(status_rel,1,&objTypeTag,retain));
			ITK_CALL(RES_checkout2(objTypeTag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE));
			printf("\n preKOPart Checked Out \n");fflush(stdout);
		}
	
		printf("\n\nEND OF FUNCTION  preKORevCheckOutValidation \n\n");

	
	return error_code;
}
extern DLLAPI int preKORevCheckInValidation(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;

	//char	type_name[TCTYPE_name_size_c+1];
	
	char	*PEPrtNum		= NULL;
	char	*PartRevSeq		= NULL;
	char	*PartDrwInd		= NULL;
	char	*type_name		= NULL;
	
	tag_t	status_rel		= NULLTAG;
	tag_t	rev				= NULLTAG;
	
	logical	retain			= 0;
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	//POM_get_user(&username,&user_tag);

	printf("\n T5_preKOPartRevision: preKORevCheckInValidation objTypeTag [%s]\n",type_name); fflush(stdout);

	if(strcmp(type_name,"T5_preKOPartRevision")==0)
	{
		

		printf("\nPartRevSeq : 	Drawing Id :"); fflush(stdout);

		t5removeAllReleaseStatus(objTag);
		if(RELSTAT_create_release_status("T5_LcsReview",&status_rel)) PrintErrorStack();
		if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)) PrintErrorStack();
		if(AOM_refresh(objTag,1));
		if(AOM_save_without_extensions(objTag));
		if(AOM_unlock(objTag));
	}

	return error_code;
}
extern  DLLAPI int preKO_Revise_properties_Pre(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;

	//char		type_name[TCTYPE_name_size_c+1];

	char		*PartRevSeq		= NULL;
	char		*type_name		= NULL;
	
	logical		checkout		= 0;

	printf("\nInside preKO_Revise_properties_Pre Function....\n");fflush(stdout);
	
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	if(AOM_ask_value_string(objTag,"object_string",&PartRevSeq)!=ITK_ok) PrintErrorStack();

	if(RES_is_checked_out(objTag,&checkout)) PrintErrorStack();
	
	if(checkout>=1)
	{
		printf("\nVOD Part %s Already Checked Out..!!!\n",PartRevSeq);fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_err,"PreKO Part Already Checked Out..!!!");
		return ITK_err;
	}

	return error_code;
}
extern  DLLAPI int preKO_Revise_properties_Post(METHOD_message_t *m, va_list args)
{
	char   *ReleaseStatus=NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t  source_rev_Type_Tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	int	   ifail	=0;
	int	   ii=0;
	char   *text	=NULL;
	char   *type_name	=NULL;
	int	   status_count=0;
	char   *Item_string=NULL;
	logical			retain							= 0;
	int status;	
	int Desc_seq=0;
	int Desc_seq9=0;
	int Desc_seq1=0;
	int Desc_seq2=0;
	char			*Desc_obj	= NULL;
	char			*Desc_obj9	= NULL;
	char			*Desc_obj2	= NULL;
	//char			*Desc_seq3	= NULL;
	char   Desc_seq3[10];
	tag_t			objTypeTag									= NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t master=NULLTAG;
	logical      bypass                  = FALSE;
	tag_t	source_rev				 =va_arg (args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	char	*ReplacedRevision=NULL;
	char		   *ObjectClassType		= NULL;
	char		   *ObjectName		= NULL;
	tag_t			dataset										= NULLTAG;
	tag_t			*attachments								= NULLTAG;
	int revlength= 0;
	tag_t *revisions;
	int revision_count=0;
	tag_t attr_id ;
	tag_t form_attr_id ;
	tag_t			relation_type								= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];

	//const char	   reason;
	//const char     change_id;
	//const char     dir_name;
	const char		*reason	= NULL;
	const char		*change_id	= NULL;
	const char		*dir_name	= NULL;
	//const char	   reason1;
	//const char     change_id1;
	//const char     dir_name1;
	const char		*reason1	= NULL;
	const char		*change_id1	= NULL;
	const char		*dir_name1	= NULL;

	char* revi=NULL;
	char* oojname=NULL;
	 char   revi1[20];
	int				cnt=0;
	int				i=0;
	logical			checkout									= 0;

	int			st_relList_count		= 0; 
	int			Rel_cnt					= 0; 
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ; 
	tag_t		tReleaseStatusList		= NULLTAG; 
	int			n_values				= 0; 
	int			cunt1					= 0; 
	tag_t*		attr_tags				= NULLTAG; 
	logical		*is_it_null				= NULL; 
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	printf("\nInside preKO_Revise_properties_Post Function....\n");fflush(stdout);
	
	if (TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	
	if(ITEM_ask_item_of_rev(source_rev,&master) );

	if(ITEM_ask_latest_rev(master,&rev));

	if(ITEM_list_all_revs(master, &revision_count, &revisions));
	//MEM_free (revisions);
	printf("\nNumber of revision : %d\n",revision_count); fflush(stdout);

	if(WSOM_ask_release_status_list(revisions[revision_count-2],&status_count,&status_list)) PrintErrorStack();

	printf("\nNumber of statuses: %d \n",  status_count);fflush(stdout);
	for (ii = 0; ii < status_count; ii++)
	{
		AOM_ask_name(status_list[ii], &ReleaseStatus);
		printf("\nReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
	}

	if (AOM_ask_value_string(revisions[revision_count-2],"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
	printf("\nDesc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
	
	if (AOM_ask_value_int(revisions[revision_count-2],"sequence_id",&Desc_seq2)!=ITK_ok)   PrintErrorStack();
	printf("\nDesc_seq2  = [%d]\n", Desc_seq2);fflush(stdout);

	if((strcmp(ReleaseStatus,"ERC Review")==0)  || (strcmp(ReleaseStatus,"T5_LcsReview")==0))
	{
		if(AOM_ask_value_string(rev,"item_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
		printf("\n type_name = [%s]\n", type_name);fflush(stdout);
		printf("\n revision  = [%s]\n", Desc_obj);fflush(stdout);
		
		if (AOM_ask_value_int(rev,"sequence_id",&Desc_seq)!=ITK_ok)   PrintErrorStack();
		printf("\n sequence  = [%d]\n", Desc_seq);fflush(stdout);

		Desc_seq1 = Desc_seq2 + 1;
		printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

		printf("\nValue of Desc_obj : %s\n",Desc_obj2);fflush(stdout);
		revi=strtok(Desc_obj2,";");
		printf("\nValue of revi : %s\n",revi);fflush(stdout);
		strcat(revi,";");
		printf("\nValue of revi : %s\n",revi);fflush(stdout);

		sprintf(revi1, "%d", Desc_seq1);
		strcat(revi,revi1);
		printf("\nValue of revi : %s\n",revi);fflush(stdout);

		if(POM_set_attr_string(1, &rev, attr_id, revi)) PrintErrorStack();

		printf("\nUpdating start2\n");fflush(stdout);
		if(AOM_lock(rev));
		if(AOM_set_value_int(rev,"sequence_id",Desc_seq1))PrintErrorStack();
		if(AOM_save_without_extensions(rev))PrintErrorStack();
		if(AOM_unlock(rev))PrintErrorStack();
		printf("\nUpdating end2\n");fflush(stdout);

		t5removeAllReleaseStatus(rev);
		if(RELSTAT_create_release_status("T5_LcsWorking",&status_rel)) PrintErrorStack();
		if(RELSTAT_add_release_status(status_rel,1,&rev,retain)) PrintErrorStack();

		if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments))PrintErrorStack();
		printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
			
		if(RES_checkout2(rev,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
			
		for(i=0;i<cnt;i++)
		{
			dataset = attachments[i];
			
			if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

			if (strcmp(ObjectClassType,"T5_preKOPartRevisionMaster")==0)
			{
				if(AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
				oojname=strtok(ObjectName,"/");
				strcat(oojname,"/");
				strcat(oojname,revi);
				printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
				
				if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
				
				if(AOM_lock(dataset));
				if(POM_set_attr_string(1,&dataset,form_attr_id,oojname)) PrintErrorStack();
				if(AOM_save_without_extensions(dataset))PrintErrorStack();
				if(AOM_unlock(dataset))PrintErrorStack();
			}
			
			if (strcmp(ObjectClassType,"T5_preKOPartRevision")!=0)
			{
				if (strcmp(ObjectClassType,"T5_preKOPartRevisionMaster")!=0)
				{
					printf("\n\n Dataset ObjectClassType1 :%s\n",ObjectClassType);fflush(stdout);
					if(RES_is_checked_out(dataset,&checkout))PrintErrorStack();
					printf("\nValue of checkout : %d\n",checkout);fflush(stdout);
		
					if (checkout==0)
					{
						tag_t* relation_list = NULLTAG;
						int relcount = 0;
						tag_t relation_type1 = NULLTAG;
						if(GRM_find_relation_type("IMAN_reference",&relation_type1))PrintErrorStack();
						if(GRM_list_relations(rev,dataset,relation_type1,NULLTAG,&relcount,&relation_list))PrintErrorStack();
						printf("\nIMAN_references count : %d",relcount);
						printf("\n\ngoing to checkout :%s\n",ObjectClassType);fflush(stdout);
						if(relcount <= 0 )
						{
							if(RES_checkout2(dataset,reason1,change_id1,dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
							printf("\n %d DataSet Checked Out \n",dataset);
						}
						else
						{
							printf("\nSkipping IMAN_reference relation checkout");
						}
					}
				}
			}
		}
	}

	//For Revising VOD Part Released Revision.

	if((strcmp(ReleaseStatus,"ERC Released")==0)  || (strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) )
	{
		if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments)) PrintErrorStack();
		printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
			dataset = attachments[i];
			
			if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

			if (strcmp(ObjectClassType,"T5_preKOPartRevisionMaster")==0)
			{
				if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
				oojname=strtok(ObjectName,"/");
				strcat(oojname,"/");
				printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
				break;
			}
		}

		revi=strtok(Desc_obj2,";");
		printf("\nValue of revi in revision : %s\n",revi);fflush(stdout);
		if(POM_attr_id_of_attr("item_revision_id", "T5_preKOPartRevision", &attr_id))PrintErrorStack();
		if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
		
		
		if(AOM_lock(rev));
		
		if (strcmp(revi,"NR")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"A;1")) PrintErrorStack(); 
			strcat(oojname,"A;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"A")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"B;1")) PrintErrorStack(); 
			strcat(oojname,"B;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"B")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"C;1")) PrintErrorStack(); 
			strcat(oojname,"C;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"C")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"D;1")) PrintErrorStack(); 
			strcat(oojname,"D;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"D")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"E;1")) PrintErrorStack(); 
			strcat(oojname,"E;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"E")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"F;1")) PrintErrorStack(); 
			strcat(oojname,"F;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"F")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"G;1")) PrintErrorStack(); 
			strcat(oojname,"G;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"G")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"H;1")) PrintErrorStack(); 
			strcat(oojname,"H;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"H")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"I;1")) PrintErrorStack(); 
			strcat(oojname,"I;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"I")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"J;1")) PrintErrorStack(); 
			strcat(oojname,"J;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"J")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"K;1")) PrintErrorStack(); 
			strcat(oojname,"K;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"K")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"L;1")) PrintErrorStack(); 
			strcat(oojname,"L;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"L")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"M;1")) PrintErrorStack(); 
			strcat(oojname,"M;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"M")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"N;1")) PrintErrorStack(); 
			strcat(oojname,"N;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"N")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"O;1")) PrintErrorStack(); 
			strcat(oojname,"O;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"O")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"P;1")) PrintErrorStack(); 
			strcat(oojname,"P;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"P")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Q;1")) PrintErrorStack(); 
			strcat(oojname,"Q;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Q")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"R;1")) PrintErrorStack(); 
			strcat(oojname,"R;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"R")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"S;1")) PrintErrorStack(); 
			strcat(oojname,"S;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"S")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"T;1")) PrintErrorStack(); 
			strcat(oojname,"T;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"T")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"U;1")) PrintErrorStack(); 
			strcat(oojname,"U;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"U")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"V;1")) PrintErrorStack(); 
			strcat(oojname,"V;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"V")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"W;1")) PrintErrorStack(); 
			strcat(oojname,"W;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"W")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"X;1")) PrintErrorStack(); 
			strcat(oojname,"X;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"X")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Y;1")) PrintErrorStack(); 
			strcat(oojname,"Y;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Y")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Z;1")) PrintErrorStack(); 
			strcat(oojname,"Z;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Z")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack(); 
			strcat(oojname,"AA;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}

		if(AOM_save_without_extensions(dataset))PrintErrorStack();
		if(AOM_unlock(dataset))PrintErrorStack();

		if(AOM_save_without_extensions(rev))PrintErrorStack();
		if(AOM_unlock(rev))PrintErrorStack();
	
		t5removeAllReleaseStatus(rev);
		ERROR_CALL(RELSTAT_create_release_status("T5_LcsReview",&status_rel));      
		ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));   				
		//ERROR_CALL(ITK_set_bypass(TRUE));                                     
																				
		ERROR_CALL(AOM_refresh(rev,1));                                         
		ERROR_CALL(AOM_save_without_extensions(rev));                                              			
		ERROR_CALL(AOM_unlock(rev));    
	}
	return ITK_ok;
}
extern int save_method_preKOPart_custom_exit(int *decision, va_list args)
{
	METHOD_id_t  methodSavePre ;
	METHOD_id_t  preKOCheckOutVal ;
	METHOD_id_t  preKOCheckInVal ;
	METHOD_id_t  preKORevCopyPre ;
	METHOD_id_t  preKORevCopyPost ;
	int ifail = 0;
	
	*decision = ALL_CUSTOMIZATIONS;

	printf("\n\n tm_VOD.c:it, via Custom User Exit.\n");fflush(stdout);
	if(METHOD_find_method("T5_preKOPartRevision",IMAN_save_msg, &methodSavePre) !=ITK_ok);//
	if(METHOD_find_method(RES_Type, RES_checkout_msg,&preKOCheckOutVal) !=ITK_ok)			PrintErrorStack();	//VOD Revision Check-Out
	if(METHOD_find_method(RES_Type, RES_checkin_msg,&preKOCheckInVal) !=ITK_ok)				PrintErrorStack();	//VOD Revision Check-In
	if(METHOD_find_method("T5_preKOPartRevision","ITEM_copy_rev",&preKORevCopyPre)!=ITK_ok)		PrintErrorStack();	//VOD Revision Revise Action
	if(METHOD_find_method("T5_preKOPartRevision","ITEM_copy_rev",&preKORevCopyPost)!=ITK_ok)		PrintErrorStack();	//VOD Revision Revise Action

	if (methodSavePre.id != NULLTAG)
	{
		printf("\n inside preKOPart save00");fflush(stdout);

		if( METHOD_add_action(methodSavePre, METHOD_pre_action_type, (METHOD_function_t) save_method_preKO, NULL)!=ITK_ok);
		if( ifail != ITK_ok )
		{
				printf("\n inside preKOPart save -1");fflush(stdout);

				EMH_store_error( EMH_severity_error, ifail );
		}
		printf("\n inside preKOPart save211");fflush(stdout);

		if( METHOD_add_action(methodSavePre,METHOD_post_action_type,(METHOD_function_t)preKO_Check_out_Post, NULL)!=ITK_ok);
		if( ifail != ITK_ok )
		{
				printf("\n inside preKOPart_Check_out_Post");fflush(stdout);

				EMH_store_error( EMH_severity_error, ifail );
		}		
	}
	if (preKOCheckOutVal.id != NULLTAG)
	{
		printf("\nInside preKOPartCheckOutVal\n");	fflush(stdout);
		if( METHOD_add_action(preKOCheckOutVal, METHOD_post_action_type, (METHOD_function_t) preKORevCheckOutValidation, NULL)!=ITK_ok) PrintErrorStack();
	}
	if (preKOCheckInVal.id != NULLTAG)
	{
		printf("\nInside preKOPartCheckInVal\n");	fflush(stdout);
		if(METHOD_add_pre_condition(preKOCheckInVal,(METHOD_function_t)preKORevCheckInValidation,NULL)!=ITK_ok) PrintErrorStack();
	}

	if (preKORevCopyPre.id != NULLTAG)
    {
        printf("\nInside preKOPartRevCopyPre\n");	fflush(stdout);
		if(METHOD_add_action(preKORevCopyPre,METHOD_pre_action_type,(METHOD_function_t)preKO_Revise_properties_Pre, NULL)!=ITK_ok)	PrintErrorStack();
    }

	if (preKORevCopyPost.id != NULLTAG)
    {
        printf("\nInside preKOPartRevCopyPost\n");	fflush(stdout);
		if(METHOD_add_action(preKORevCopyPost,METHOD_post_action_type,(METHOD_function_t)preKO_Revise_properties_Post, NULL)!=ITK_ok)	PrintErrorStack();
    }

   	
    return ifail;

}

extern DLLAPI int tm_preKOPart_register_callbacks()
{
 printf("\n \n tm_preKOPart.c :::Hello Teamcenter, via Custom User Exit\n");fflush(stdout);

  CUSTOM_register_exit("tm_preKOPart","USER_init_module",(CUSTOM_EXIT_ftn_t)save_method_preKOPart_custom_exit);
  return ITK_ok;
}