 /***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Rule Handler for PO check Manager validations to check NOPO parts avalability..
*  Code                 :   tm_POChkMangVali.c
*  Created on			:   12/04/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	12/04/2019					Mohan Tayade		PO check Manager validations to check NOPO parts avalability.
*	2.	08/05/2019					Mohan Tayade		Handle DR3P/AR3P.
*   3.  19.4.22		-				Prasad				Uploaded Data from Bhaskar Folder to DV
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_POChkMangVali(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int jr      =  0;
	int i      =  0;
	int tsk      =  0;
	int Tskcnt      =  0;
	int NOPOflag      =  0;
	int NewNOPOflag      =  0;
	int ImCOPartFlag      =  0;
	int PSCNOPOflag      =  0;
	int PORevNOPOflag      =  0;
	int UnmatErrorflag      =  0;
	int ImPartFlag      =  0;
	int spPartCnt      =  0;
	int NOPOErrorflag      =  0;
	int Refcount      =  0;
	int ReqFdrSize=0;
	int FldObjCount	=  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *sPOCHKInfo3		= NULL;
	char *TskNm		= NULL;
	char *sNOPOFldr		= NULL;
	char *sDMLno		= NULL;
	char *Tsk_object_type		= NULL;
	char	*sPOERROR	= NULL;
	char	*class_name1	= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t NOPO_dml_Ref_Rel	= NULLTAG;
	tag_t *RefDoc_tag=NULLTAG;
	tag_t RefTypeTag	= NULLTAG;
	tag_t *Dml_tasks=NULLTAG;
	tag_t *FoldObj_tag=NULLTAG;
	char*   Reftype_name= NULL;
	tag_t	spCMRefrel		= NULLTAG;
	tag_t *spPartTags=NULLTAG;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char*	CurrentTask				=NULL;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_POChkMangVali Function started...");fflush(stdout);
	TC_write_syslog("\n tm_POChkMangVali Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n GMD:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n GMD: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
				printf("\n sDMLno:%s.",sDMLno);fflush(stdout);

				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n GMD:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n GMD:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "POCHCK";
				//DR_qry_values2[0] = "CREVali";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n GMD:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//PO bypass
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&sPOCHKInfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n GMD:  sPOCHKInfo3:%s\n",sPOCHKInfo3);fflush(stdout);
					if(strstr(sPOCHKInfo3,"MANPOVALID")==NULL)
					{
						if(GRM_find_relation_type("T5_CmHasNOPoDetails", &NOPO_dml_Ref_Rel)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(taskAttachments[i],NOPO_dml_Ref_Rel,&Refcount,&RefDoc_tag)!=ITK_ok)PrintErrorStack();
						printf("\n P1:Refcount Value :   %d\n",Refcount);fflush(stdout);
						if(Refcount>0)
						{
							NOPOErrorflag=0;
							UnmatErrorflag=0;
							for (jr=0;jr<Refcount;jr++ )
							{
								if(TCTYPE_ask_object_type(RefDoc_tag[jr],&RefTypeTag));
								if(TCTYPE_ask_name2(RefTypeTag,&Reftype_name));
								printf("\n P1:Reftype_name :: %s\n", Reftype_name);fflush(stdout);
								if(AOM_ask_value_string(RefDoc_tag[jr],"object_name",&sNOPOFldr)!=ITK_ok)PrintErrorStack();
								printf("\n P1::folder name :: %s\n", sNOPOFldr);fflush(stdout);
								if((tc_strcmp(Reftype_name,"T5_NOPO_Parts") ==0)|| (tc_strcmp(Reftype_name,"NOPO Parts") ==0))
								{
									if((tc_strcmp(sNOPOFldr,"T5_NOPO_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"NOPO Parts") ==0))
									{
										printf("\n P1: Folder  available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P1:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P1:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											NOPOflag ++;
											printf("\n P1:ERROR: NOPOErrorflag:%d NOPOflag:%d \n",NOPOErrorflag,NOPOflag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having NOPO parts, please get the PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
								}
								if((tc_strcmp(Reftype_name,"T5_PORevMismatch_Parts") ==0)|| (tc_strcmp(Reftype_name,"PO Rev Mismatch Parts") ==0))
								{
									if((tc_strcmp(sNOPOFldr,"T5_PORevMismatch_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"PO Rev Mismatch Parts") ==0))
									{
										printf("\n P2:PORevMismatch_Parts available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P2:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P2:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											PORevNOPOflag ++;
											printf("\n P2:ERROR: NOPOErrorflag:%d PORevNOPOflag:%d \n",NOPOErrorflag,PORevNOPOflag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having NOPO parts, please get the PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
								}
								if((tc_strcmp(Reftype_name,"T5_PSC_PORevMismatch_Parts") ==0)|| (tc_strcmp(Reftype_name,"P&SC PO Rev Mismatch Parts") ==0))
								{
									if((tc_strcmp(sNOPOFldr,"T5_PSC_PORevMismatch_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"P&SC PO Rev Mismatch Parts") ==0))
									{
										printf("\n P2:T5_PSC_PORevMismatch_Parts available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P2:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P2:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											PSCNOPOflag ++;
											printf("\n P2:ERROR: NOPOErrorflag:%d PSCNOPOflag:%d \n",NOPOErrorflag,PSCNOPOflag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having NOPO parts, please get the PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
								}
								if((tc_strcmp(Reftype_name,"T5_New_NOPO_Parts") ==0)|| (tc_strcmp(Reftype_name,"New NOPO Parts") ==0))
								{
									if((tc_strcmp(sNOPOFldr,"T5_New_NOPO_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"New NOPO Parts") ==0))
									{
										printf("\n P2:NwNOPO available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P2:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P2:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											NewNOPOflag ++;
											printf("\n P3:ERROR: NOPOErrorflag:%d NewNOPOflag:%d \n",NOPOErrorflag,NewNOPOflag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having NOPO parts, please get the PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
								}
								if(tc_strcmp(Reftype_name,"Folder") ==0)
								{
									if(tc_strcmp(sNOPOFldr,"UnMaturated DR Status Parts") ==0)
									{
										printf("\n P1:UnMat available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P1:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P1:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											UnmatErrorflag ++;
											ImPartFlag++;
											printf("\n P1:ERROR: NOPOErrorflag:%d UnmatErrorflag:%d ImPartFlag:%d\n",NOPOErrorflag,UnmatErrorflag,ImPartFlag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having unmaturated DR-status parts, please get the DR-status updated to equal and above than DML TOGate DR-status value \n and PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
									if(tc_strcmp(sNOPOFldr,"CarryOver Parts") ==0)
									{
										printf("\n P2:CO available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P2:CO:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P2:CO:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											ImCOPartFlag ++;
											UnmatErrorflag ++;
											printf("\n P2:ERROR: NOPOErrorflag:%d UnmatErrorflag:%d ImCOPartFlag:%d\n",NOPOErrorflag,UnmatErrorflag,ImCOPartFlag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having carryover parts, please get the DR-status updated to equal and above than DML TOGate DR-status value. \n Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
									//PSS918119 MDM Relation check on Signoff.
									if(tc_strcmp(sNOPOFldr,"Immaturated MS Status Parts") ==0)
									{
										printf("\n P6:UnMat MS available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P6:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P6:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											UnmatErrorflag ++;
											ImPartFlag++;
											printf("\n P6:ERROR: NOPOErrorflag:%d UnmatErrorflag:%d ImPartFlag:%d\n",NOPOErrorflag,UnmatErrorflag,ImPartFlag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having unmaturated DR-status parts, please get the DR-status updated to equal and above than DML TOGate DR-status value \n and PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
									if(tc_strcmp(sNOPOFldr,"Immaturated DR Status Parts") ==0)
									{
										printf("\n P6:UnMat DR available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P6:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P6:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											UnmatErrorflag ++;
											ImPartFlag ++;
											printf("\n P6:ERROR: NOPOErrorflag:%d UnmatErrorflag:%d ImPartFlag:%d\n",NOPOErrorflag,UnmatErrorflag,ImPartFlag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having unmaturated DR-status parts, please get the DR-status updated to equal and above than DML TOGate DR-status value \n and PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
									if(tc_strcmp(sNOPOFldr,"Immaturated CarryOver Parts") ==0)
									{
										printf("\n P7:UnMat CarryOver Parts available.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P7:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P7:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if((FldObjCount>0) || (ReqFdrSize >0))
										{
											NOPOErrorflag ++;
											UnmatErrorflag ++;
											ImCOPartFlag++;
											printf("\n P7:ERROR:: NOPOErrorflag:%d UnmatErrorflag:%d ImCOPartFlag::%d\n",NOPOErrorflag,UnmatErrorflag,ImCOPartFlag);fflush(stdout);
											/*EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML having unmaturated DR-status parts, please get the DR-status updated to equal and above than DML TOGate DR-status value \n and PO raised on latest released revision. Please check 'Has NOPO Details' relation and check for other relations under it too.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;*/
										}
									}
								}
							}

							if((tc_strcmp(CurrentTask,"POReview") ==0)||(tc_strcmp(CurrentTask,"BOM Process PO Review") ==0)||(tc_strcmp(CurrentTask,"GM DML Review") ==0))
							{
								if (NOPOErrorflag >0)
								{
									printf("\n PO Check HARD error.:NewNOPOflag:%d UnmatErrorflag:%d PSCNOPOflag:%d PORevNOPOflag:%d NOPOflag:%d \n",NewNOPOflag,UnmatErrorflag,PSCNOPOflag,PORevNOPOflag,NOPOflag);fflush(stdout);
									if(strstr(sPOCHKInfo3,"POER001")==NULL)
									{
										printf("\n Hard check PO Check is clearedd.\n");fflush(stdout);
										sPOERROR =(char *) MEM_alloc(1000 * sizeof(char *));
										tc_strcpy(sPOERROR,"");
										tc_strcpy(sPOERROR,"This is hard check for PO validation. Please check 'Gate Maturation Exceptions' relation with DML and ensure for below errors with given solution.\nIf all error points are cleared and still issue, please raise ticket in TMS with details.");
										if (NOPOflag >0)
										{
											tc_strcat(sPOERROR,"\n-\nIf parts attached in 'NOPO parts' folder, then PO is not available for any released revision.\nPlease get PO available in SAP, \nor if already PO available, then ensure PO is not blocked/expired OR user can apply for VCMS approval.");
										}
										if (NewNOPOflag >0)
										{
											tc_strcat(sPOERROR,"\n-\nIf parts attached in 'New created NOPO parts' folder, then PO is mandatory,\nor if already PO available, then ensure PO is not blocked/expired. no VCMS is allowed.");
										}
										if ((PSCNOPOflag >0)||(PORevNOPOflag >0))
										{
											tc_strcat(sPOERROR,"\n-\nIf parts attached in 'PO revision Mismatch Parts' folder, then PO is mandatory for part revision, which is going to migrate to higher DR-status.\nNo VCMS is allowed.\nIf user want to consider earlier PO available revision for DR-status migrtaion instead latest NOPO revision,\n then please use front end facility: Tools >PO check Menu > Update PSC Revision.");
										}
										if (ImCOPartFlag >0)
										{
											tc_strcat(sPOERROR,"\n-\nIf Parts attached in 'CarryOver parts' folder, then analyst not having access for part project for DR-status migration.\nPlease get the DR-satus updated for at least one released revision from respective aggregate team \nor take access for such projects and reprocess DML to consider such parts for DR-migration.");
										}
										if (ImPartFlag >0)
										{
											tc_strcat(sPOERROR,"\n-\nIf Parts attached in 'Immature DR-status parts' folder, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation.");
										}
										//tc_strcat(sPOERROR,"\n\n");
										tc_strcat(sPOERROR,"\n\nDML number:");
										tc_strcat(sPOERROR,sDMLno);
										printf("\n sPOERROR: %s \n",sPOERROR);fflush(stdout);
										
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:",sPOERROR);
										decision = EPM_nogo;
										return decision;
									}
									else
									{
										printf("\n Hard PO Check is cleared.\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:There are NOPO parts or immature DR-status parts or carryover parts with this DML. \nPlease check 'Gate Maturation Exceptions' relation with DML and confirm for below. \n1] If NOPO parts - please get the PO placed for latest release revision or get the VCMS approval at manager sign off.\n2] If new created NOPO parts, then PO is mandatory, no VCMS is allowed. \n3] If PO revision mismatch parts- please get the PO placed for latest release revision, PO is mandatory, NO VCMS allowed.\n4] If immature DR-status parts, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation. \n5] If carryover parts, then ensure at least one released revision having equal or above TO DR Gate value or please get latest released revision DR-status updated.\n",sDMLno);
										decision = EPM_nogo;
										return decision;
									}
								}
								else
								{
									printf("\n PO Check is cleared.\n");fflush(stdout);
								}
							}
							else if(tc_strcmp(CurrentTask,"Verify Parts for Gate Maturation") ==0)
							{
								if (NOPOErrorflag >0)
								{
									printf("\n PO Check SOFT check UnmatErrorflag.\n");fflush(stdout);
									if(strstr(sPOCHKInfo3,"POER003")==NULL)
									{
										printf("\n PO vali Soft chk...\n");fflush(stdout);
										if(strstr(sPOCHKInfo3,"POER005")==NULL)
										{
											printf("\n chk further.\n");fflush(stdout);
											sPOERROR =(char *) MEM_alloc(1000 * sizeof(char *));
											tc_strcpy(sPOERROR,"");
											tc_strcpy(sPOERROR,"Please check 'Gate Maturation Exceptions' relation with DML and ensure for below errors with given solution.\n If all error points are cleared and still issue, please raise ticket in TMS with details.");
											if (NOPOflag >0)
											{
												tc_strcat(sPOERROR,"\n-\nIf NOPO parts attached in 'NOPO parts' folder, then PO is not available for any released revision.\nPlease get PO available in SAP, or if already PO available, then ensure PO is not blocked/expired OR user can apply for VCMS approval.\n This is soft check and system will not stop sign off, if only lagacy NOPO parts are there.");
											}
											if (NewNOPOflag >0)
											{
												tc_strcat(sPOERROR,"\n\nIf NOPO parts attached in 'New created NOPO parts' folder, then PO is mandatory, no VCMS is allowed.");
											}
											if ((PSCNOPOflag >0)||(PORevNOPOflag >0))
											{
												tc_strcat(sPOERROR,"\n-\nIf parts attached in 'PO revision Mismatch Parts' folder, then PO is mandatory for part revision, which is going to migrate to higher DR-status.\nNo VCMS is allowed.\nIf user want to consider earlier PO available revision for DR-status migrtaion instead latest NOPO revision,\n then please use front end facility: Tools >PO check Menu > Update PSC Revision.");
											}
											if (ImCOPartFlag >0)
											{
												tc_strcat(sPOERROR,"\n-\nIf Parts attached in 'CarryOver parts' folder, then analyst not having access for part project for DR-status migration.\nPlease get the DR-satus updated for at least one released revision from respective aggregate team \nor take access for such projects and reprocess DML to consider such parts for DR-migration.");
											}
											if (ImPartFlag >0)
											{
												tc_strcat(sPOERROR,"\n-\nIf Parts attached in 'Immature DR-status parts' folder, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation.");
											}
											//tc_strcat(sPOERROR,"\n\n");
											tc_strcat(sPOERROR,"\n\nDML number:");
											tc_strcat(sPOERROR,sDMLno);
											printf("\n sPOERROR::: %s \n",sPOERROR);fflush(stdout);
											if ((NewNOPOflag >0) || (PSCNOPOflag >0) ||(PORevNOPOflag >0)||(ImCOPartFlag >0)||(ImPartFlag >0))
											{
												printf("\n Hard check: Verify Parts for Gate Maturation\n");fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:",sPOERROR);
												decision = EPM_nogo;
												return decision;
											}
											else if (NOPOflag >0)
											{
												printf("\n Soft check: Verify Parts for Gate Maturation\n");fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_warning,PO_BASIC_VALI,"Information Message (Soft Check):If NOPO parts attached in 'NOPO parts' folder, then PO is not available for any released revision.\nPlease get PO available in SAP, or if already PO available, then ensure PO is not blocked/expired OR user can apply for VCMS approval, when DMl is with Manage review.\n This is soft check and system will not stop sign off, if only lagacy NOPO parts are there.\n",sDMLno);
												decision = EPM_go;
												return decision;
											}
										}
										else
										{
											printf("\n Info PO Check Soft chk...\n");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_warning,PO_BASIC_VALI,"Information Message (Soft Check):There are NOPO parts or immature DR-status parts or carryover parts with this DML. \nPlease check 'Gate Maturation Exceptions' relation with DML and confirm for below. \n1] If NOPO parts or PO revision mismatch parts- please get the PO placed for latest release revision or get the VCMS approval at manager sign off.\n2] If new created NOPO parts, then PO is mandatory, no VCMS is allowed.\n3] If immature DR-status parts, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation. \n4] If carryover parts, then ensure at least one released revision having equal or above TO DR Gate value. \nNote: All PO related validation are soft checks here but it will be hard check on manager sign off.\n Immature DR-status parts and Carryover parts validation are hard check always.\n",sDMLno);
											decision = EPM_go;
											return decision;
										}
									}
									else
									{
										printf("\n PO Check Soft chk...\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Information Message (Soft Check):There are NOPO parts or immature DR-status parts or carryover parts with this DML. \nPlease check 'Gate Maturation Exceptions' relation with DML and confirm for below. \n1] If NOPO parts or PO revision mismatch parts- please get the PO placed for latest release revision or get the VCMS approval at manager sign off.\n2] If new created NOPO parts, then PO is mandatory, no VCMS is allowed.\n3] If immature DR-status parts, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation. \n4] If carryover parts, then ensure at least one released revision having equal or above TO DR Gate value. \nNote: All PO related validation are soft checks here but it will be hard check on manager sign off.\n Immature DR-status parts and Carryover parts validation are hard check always.\n",sDMLno);
										decision = EPM_go;
										return decision;
									}
								}
								else
								{
									printf("\n PO Check is clearedd.\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Other signoff...\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"There are NOPO parts or immature DR-status parts or carryover parts with this DML. \nPlease check 'Gate Maturation Exceptions' relation with DML and confirm for below. \n1] If NOPO parts or PO revision mismatch parts- please get the PO placed for latest release revision or get the VCMS approval at manager sign off.\n2] If new created NOPO parts, then PO is mandatory, no VCMS is allowed.\n3] If immature DR-status parts, then please get the DR-satus updated for at least one released revision or attach parts to same DML for DR-status updation. \n4] If carryover parts, then ensure at least one released revision having equal or above TO DR Gate value.\n",sDMLno);
								decision = EPM_nogo;
								return decision;
							}
						}
					}
					printf("\n PO:Checking for empty folder \n");fflush(stdout);
					if(strstr(sPOCHKInfo3,"EMT001")==NULL)
					{
						Tskcnt=0;
						if(AOM_ask_value_tags(taskAttachments[i],"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
						printf("\n GMD:-Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
						if (Tskcnt>0)
						{
							for (tsk=0;tsk<Tskcnt ;tsk++ )
							{
								if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
								printf("\n GMD:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

								if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
								{
									if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
									printf("\n GMD: Checking GMD empty Task Name: [%s]  \n",TskNm);fflush(stdout);

									if(GRM_find_relation_type("CMReferences", &spCMRefrel)!=ITK_ok)PrintErrorStack();
									if(GRM_list_secondary_objects_only(Dml_tasks[tsk],spCMRefrel,&spPartCnt,&spPartTags)!=ITK_ok)PrintErrorStack();
									printf("\n GMD-->spPartCnt [%s] [%d].\n",TskNm,spPartCnt); fflush(stdout);
									if((tc_strstr(TskNm,"_SP") != NULL) ||(tc_strstr(TskNm,"_CO") != NULL))
									{
										printf("\n SKIPP:SP/CO task skipped for hanging part validation.");fflush(stdout);
									}
									else
									{
										if (spPartCnt == 0)
										{
											printf("\n GMD::ERROR: GMD having empty task.\n");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: Change reference folder of task is empty.DML sign off is not allowed.\n Please reject DML to analyst to attach parts to change references folder.\n\nIf Part was attached and now it is not available there, it means, \n analyst used PO of earlier released revision and which is already with higher DR status. \n Pease raise ticket in TMS if any query for it.",TskNm);	
											decision = EPM_nogo;
											return decision;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(sDMLno){MEM_free(sDMLno);}
	if(sPOCHKInfo3){MEM_free(sPOCHKInfo3);}
	if(sNOPOFldr){MEM_free(sNOPOFldr);}
	if(Tsk_object_type){MEM_free(Tsk_object_type);}
	if(TskNm){MEM_free(TskNm);}
	if(Dml_tasks){MEM_free(Dml_tasks);}*/
	printf("\n tm_POChkMangVali Function end...");fflush(stdout);
	TC_write_syslog("\n tm_POChkMangVali Function end...");
	return decision;
}
