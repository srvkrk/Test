#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
#define MAX_LINE_LEN 1024
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}
#define ITK_errStore 91900002

  char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );

    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


	void  getPlantWiseRRCC( char * RoleName ,char  getRevisionRule[40],char  getClosureRule[40],char CurrentViewMask[40],char getBVR[40])
	{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);

	   if(tc_strstr(RoleName,"APL")!=NULL)
	  {
		  if(tc_strcmp(RoleName,"APLD")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLD");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLD");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskD");
			tc_strcpy(getBVR,"View");
			
		  }
		  else  if(tc_strcmp(PlantName,"APLP")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLP");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLP");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskP");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLC")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLC");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLC");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskC");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLJ")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLJ");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLJ");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskJ");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLL")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLL");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLL");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskL");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLA")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLA");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLA");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskA");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLU")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLU");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLU");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskU");
			tc_strcpy(getBVR,"View");
		  }
		  else  if(tc_strcmp(PlantName,"APLS")==0)
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLS");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLS");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskS");
			tc_strcpy(getBVR,"View");
		  }
		  else
		  {
			tc_strcpy(getRevisionRule,"ERC release and above APLC");
			tc_strcpy(getClosureRule,"BOMViewClosureRuleAPLC");
			tc_strcpy(CurrentViewMask,"bl_occ_t5_CurrentViewMaskC");
			tc_strcpy(getBVR,"View");
		  }
	  }
}



int t5GetItemRevison(char* InputPart)
{
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;

	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];

	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n Tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n Tag for part no:%s.", InputPart);fflush(stdout);
	}

	return OutPutTag;	
}



/*******************************4.*******************************************/
//extern int CreateVCRstBOMServiceCalling(char  *AplRevw,char *TotalRowSelc,char *itemId,char *Rev,void *retValue)
extern int CreateVCRstBOMServiceCalling(void *retValue)
 {
	 	int				ifail 	= ITK_ok;
	tag_t  CntrlTag		= NULLTAG;
	tag_t  query1 = NULLTAG;
  	tag_t *CntrlObjs	= NULLTAG;
	tag_t	TbNopart_tg	= NULLTAG;
	tag_t	TbNopart_tag	= NULLTAG;
	tag_t  *occs					=	NULLTAG;
	tag_t	*bvrs					=	NULLTAG;
	tag_t	*bvrs1					=	NULLTAG;
	tag_t *occs_clr = NULLTAG;
	tag_t *bvrTag = NULLTAG;
		tag_t			bvr_tag= NULLTAG;

	char	    *AplRevw				=NULL;
	char		*VEHID					= NULL;
	char		*VehRev					= NULL;
	char		*VehItem_Rev		=	NULL;
	char		*VehItem_Seq		=	NULL;
	char		*responseString1	= NULL;
	//char		*sCustomExpression	= NULL;
	char		*item_id 				= NULL;
	char		*item_idTB 				= NULL;
	char		*item_idTaB 				= NULL;
	char		*item_revision_id= NULL;
	char		*object_desc 			= NULL;
	char		*RowCntWindow1 = NULL;
	char		*TotalRowSelc 		= NULL;
	char		*wind2AElements 		= NULL;
	char		*Rolename 		= NULL;
	char **	GStringList =NULL;
	char **	GStringList2 =NULL;
	char *value_flag_colour=NULL;
		char *  item_Mask= NULL;
		char *  partNumber= NULL;
		tag_t 			*tagTopBLchildLine 			= NULLTAG;
		tag_t 			*tagTopBLchildLine2			= NULLTAG;
			tag_t	window 				= NULLTAG;
			tag_t	window2				= NULLTAG;
			tag_t	top_line			= NULLTAG;

	int		cntt							=0;
	int		n_entries1				=2;
	int		ic				=0;
	int		n_found1				=0;
	int		aModCnt					=0;
	int		bvr_count				=	0;
	int		bvr_count1				=	0;
	int		childCountTopBomLine				=	0;
	int		childCountTopBomLine2				=	0;
	int	TbNo=0;
	int StringCount=0;
	int	TbNo1=0;
	int	iCount=0;
	int StringCount1=0;
		int n_occs_clr=0;
	int  sCustomExpression=0;


	char RevisionRule[40];
	char ClosureRule[40];
	char CurrentViewMask[40];
	char ERCClosureRule[40];
	char BVR[40];
	tag_t   ClrPrtrule	=NULLTAG;

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

	int		StructCntPaintProdPlan	= 0;
	struct	BomChldStrut	ChldStrutPart[1000];
	int		childBS			=0;		

	responseString1=(char *)MEM_alloc(200);

	USERARG_get_string_argument(&AplRevw);	
	USERARG_get_string_argument(&VEHID);	
	USERARG_get_string_argument(&VehRev);	
	USERARG_get_string_argument(&RowCntWindow1);
	USERARG_get_string_argument(&TotalRowSelc);
	USERARG_get_string_argument(&wind2AElements);
	USERARG_get_string_argument(&Rolename);


	printf("\n \nCreateVCRstBOMServiceCalling Registration Successful ****"); fflush(stdout);
	printf("\n *Input From RAC Code AplRevw ::%s",AplRevw); fflush(stdout);
	printf("\n *Input From RAC Code VEHID ::%s",VEHID); fflush(stdout);
	printf("\n *Input From RAC Code VehRev::%s",VehRev); fflush(stdout);
	printf("\n* Input From RAC Code WinCnt1::%s",RowCntWindow1); fflush(stdout);
	printf("\n *Input From RAC Code TotalRowSelc2::%s",TotalRowSelc); fflush(stdout);
	printf("\n *Input From RAC Code wind2AElements::%s",wind2AElements); fflush(stdout);
	printf("\n *Input From RAC Code Rolename::%s",Rolename); fflush(stdout);

	VehItem_Rev =  tc_strtok(VehRev,";");
	printf("\n \n Veh Item_Rev --> : %s\n",VehItem_Rev); fflush(stdout);

	VehItem_Seq = tc_strtok(NULL,";");
	printf("Item_Seq ----> : %s\n",VehItem_Seq); fflush(stdout);

	tc_strcpy(responseString1,VehItem_Rev);
	tc_strcat(responseString1,"*");
	tc_strcat(responseString1,VehItem_Seq);
	printf("\nItem_Rev Seq For Query Run****** ----> : %s\n",responseString1); fflush(stdout);

	int RowCntWindow1C =atoi(RowCntWindow1);
	int TotalRowSelcC =atoi(TotalRowSelc);

	printf("\nRowCntWindow1C  :: %d \n TotalRowSelcC ::%d\n",RowCntWindow1C,TotalRowSelcC); fflush(stdout);

				char *qry_entry[2] = {"Item ID", "Revision"},
						 *qry_vall[2] =  {VEHID,responseString1};

				ITKCALL(QRY_find("Item Revision...", &query1));
				ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
				printf("\n n_found1: %d", n_found1);fflush(stdout);

					for (cntt = 0; cntt < n_found1; cntt++)
					{
						CntrlTag=NULLTAG;
						CntrlTag=CntrlObjs[cntt];

						AOM_ask_value_string( CntrlTag, "item_id", &item_id);
						AOM_ask_value_string( CntrlTag, "item_revision_id", &item_revision_id);
						AOM_ask_value_string( CntrlTag, "object_desc", &object_desc);
						printf("\n item_id: %s\n",item_id);fflush(stdout);						
						printf("\n item_revision_id: %s\n",item_revision_id);fflush(stdout);
						printf("\n object_desc: %s\n",object_desc);fflush(stdout);

						getPlantWiseRRCC(Rolename,RevisionRule,ClosureRule,CurrentViewMask,BVR);
						printf("\n RevisionRule: %s\n",RevisionRule);fflush(stdout);
						printf("\n ClosureRule: %s\n",ClosureRule);fflush(stdout);
						printf("\n CurrentViewMask: %s\n\n",CurrentViewMask);fflush(stdout);

						
						ITKCALL(ITEM_rev_list_bom_view_revs(CntrlTag,&bvr_count, &bvrs));
						if (bvr_count>0)	{	printf("\n  ITEM_rev_list_bom_view_revs Found\n");fflush(stdout);	/*bvr = bvrs1[0];		MEM_free(bvrs);	*/}

						if(EPM__parse_string(wind2AElements,"$",&StringCount,&GStringList)!=ITK_ok)PrintErrorStack();
						printf("\n Window 2A StringCount: %d\n",StringCount);fflush(stdout);

						if(EPM__parse_string(AplRevw,"$",&StringCount1,&GStringList2)!=ITK_ok)PrintErrorStack();
						printf("\n Window 2B StringCount1: %d\n",StringCount1);fflush(stdout);
							
							for (TbNo1=0;TbNo1<StringCount1 ;TbNo1++ )
							{
								printf("\n PartsSet 2B:%s",GStringList2[TbNo1]);fflush(stdout);																										
								if(tc_strcmp(GStringList2[TbNo1],"#")==0)
								{
									 printf("\n NO NEED TO CHECK INVALID PART***");fflush(stdout);
								}
								else{
													    printf("\n NEED TO ADD IN BOM***000000000000ssssss00000");fflush(stdout);


								TbNopart_tag= t5GetItemRevison(GStringList2[TbNo1]);
								AOM_ask_value_string( TbNopart_tag, "item_id", &item_idTB);
								printf("\n item_idTaB in Window 2B  [%s]\n\n",item_idTB);fflush(stdout);	

														ITKCALL(AOM_lock(bvrs[0]));
														ITKCALL(PS_create_occurrences(bvrs[0], TbNopart_tag, NULLTAG,1, &occs ));
														printf(" PS_create_occurrences createed successfully  in PSE\n");
														 ITKCALL(AOM_save(bvrs[0]));
														ITKCALL(AOM_unlock(bvrs[0]));
														ITKCALL(AOM_refresh(bvrs[0],0));

													ITKCALL(BOM_create_window (&window));	
													ITKCALL(BOM_set_window_top_line(window, NULLTAG,CntrlTag ,bvr_tag, &top_line));
													ITKCALL(BOM_line_ask_child_lines (top_line, &childCountTopBomLine, &tagTopBLchildLine));
													printf("BOM Window, Parent Part Child Line Count:-%d \n",childCountTopBomLine);fflush(stdout);

												for(iCount =0 ; iCount < childCountTopBomLine; iCount++)
												{
													   	AOM_ask_value_string(tagTopBLchildLine[iCount],"bl_item_item_id",&partNumber);
														printf("Part number===>%s\n",partNumber);fflush(stdout);

														AOM_UIF_ask_value(tagTopBLchildLine[iCount],CurrentViewMask,&item_Mask);
														printf("Part item_Mask number===>%s\n\n",item_Mask);fflush(stdout);

														if(tc_strcmp(partNumber,item_idTB)==0)
														{							
														  BOM_line_look_up_attribute(CurrentViewMask,&sCustomExpression);
														 ITKCALL(BOM_line_set_attribute_string(tagTopBLchildLine[iCount], sCustomExpression,"-12"));
														  printf(" BOM_line_set_attribute_string set  successfully*********\n");

														  ITKCALL(BOM_save_window(window) );
															printf("BOM_save successfully of ------->\n");

														  ITKCALL(BOM_refresh_window(window));
														  printf(" BOM_refresh successfully of ------->\n\n"); 
														  break;
														}
													}
											//			ITKCALL(BOM_close_window(window));
							}
											
													printf("\n ****************************************************************************************************\n");fflush(stdout);
											}


						//explode the bom and find the variant formula
						ITKCALL(Get_Part_BOM_Lvl(CntrlTag,1,ClosureRule,RevisionRule,"View",ChldStrutPart,&StructCntPaintProdPlan));
						printf("\n StructCntPaintProdPlan:%d",StructCntPaintProdPlan);fflush(stdout);
			
								
						if(RowCntWindow1C>0)
						{				
							for (TbNo=0;TbNo<StringCount ;TbNo++ )
							{
								printf("\n PartsSet 2A:%s",GStringList[TbNo]);fflush(stdout);

										
								if(tc_strcmp(GStringList[TbNo],"#")==0)
								{
									 printf("\n NO NEED TO CHECK INVALID PART***");fflush(stdout);
								}
								else				
								{				int  sCustomExpression=0;	
												TbNopart_tg= t5GetItemRevison(GStringList[TbNo]);
												AOM_ask_value_string( TbNopart_tg, "item_id", &item_idTaB);
												printf("\n item_idTaB in Window 2A : %s\n\n",item_idTaB);fflush(stdout);
																	
													ITKCALL(BOM_create_window (&window2));							
													BOM_set_window_top_line(window2, NULLTAG,CntrlTag ,bvr_tag, &top_line);
													ITKCALL(BOM_line_ask_child_lines (top_line, &childCountTopBomLine2, &tagTopBLchildLine2));
													printf("BOM Window, Parent Part Child Line Count:-%d \n",childCountTopBomLine2);fflush(stdout);

											for(childBS=1;childBS<=StructCntPaintProdPlan;childBS++)
											{
													char	*cArchchldPartNo	=	NULL;
													tag_t	objChild_BVR	=	NULLTAG;
													objChild_BVR			=	ChldStrutPart[childBS].child_objs_bvr;

													ITKCALL(AOM_ask_value_string(objChild_BVR, "bl_item_item_id", &cArchchldPartNo ));
													printf("\n No of Modules Under objChild_BVR --> : %s",cArchchldPartNo); fflush(stdout);

												if(tc_strcmp(item_idTaB,cArchchldPartNo)==0)
												{
																printf("\n Compared Succssfully  NEED To DELETED "); fflush(stdout);

												    	  BOM_line_look_up_attribute(CurrentViewMask,&sCustomExpression);
														 ITKCALL(BOM_line_set_attribute_string(objChild_BVR, sCustomExpression,"0--"));
														  printf(" BOM_line_set_attribute_string set  successfully FOR DELETION*********\n");

														  ITKCALL(BOM_save_window(window2) )
															printf("AOM_save successfully of FOR DELETION------->\n");

														  ITKCALL(BOM_refresh_window(window2));
														  printf(" AOM_refresh successfully of -FOR DELETION------>\n\n"); 
														//  break;																											
											}
										}	
										
									//	ITKCALL(BOM_close_window(window2));

							}
								
								}
								printf("\n ####################################################################################\n");fflush(stdout);
						}





				    }
						return ifail;
 }
/*******************************3.*******************************************/
extern int tm_CreateVCRstBOMServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 7;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );

	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] =  USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("CreateVCRstBOMServiceCalling",(USER_function_t)CreateVCRstBOMServiceCalling,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}
/*******************************2.*******************************************/

extern int tm_CreateVCRstBOMService(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	tm_CreateVCRstBOMServiceCalling();
	
	return ifail;
	
}

/*******************************1.*******************************************/
extern DLLAPI int tm_CreateVCRstBOM_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....");   
	ifail=CUSTOM_register_exit ( "tm_CreateVCRstBOM", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_CreateVCRstBOMService);
	return ( ITK_ok );
}