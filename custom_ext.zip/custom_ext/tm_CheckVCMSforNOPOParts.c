/****************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler PO Check and attach NOPO report to DML as xls.
*  Code                 :   tm_CheckVCMSforNOPOParts.c
*  Command				:	tm_CheckVCMSforNOPOParts -u=ercpsup  -pf=XYT1ESA  -g=dba -file=input.txt
*						:	tm_CheckVCMSforNOPOParts -u=ercpsup  -pf=XYT1ESA  -g=dba -taskno=XXX
*  Created on			:   05/09/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		05/09/2019				Mohan Tayade		remove NOPO parts if VCMS approval found.
*****************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <pie/pie.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define ITK_err 919002
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
char* GetNoPOdmltostatus(char *DMLno);
char	*NOPOPartsSet = NULL;
char	*TaskAtchedPartSet = NULL;
char	*UnMatPartSet = NULL;
char	*NwNOPOPartsSet = NULL;
char	*PORevNOPOPartsSet = NULL;
char	*PSCPORevNOPOPartsSet = NULL;
char	*BypassPartSet = NULL;
char	*POAvailPartSet = NULL;
char	*PORevAvailPartSet = NULL;
char	*SkippedPartSet = NULL;
char	*sPOCHKInfo3 = NULL;
char	*RelDRStatus = NULL;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int DML_GenTPL_Report(char*);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"POcheckatERC -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

//int ITK_user_main(int argc, char *argv[])
//{
//	int				ifail 						= ITK_ok;
//	char			* userid 					= NULL;
//	char			* password					= NULL;
//	char			* group						= NULL;
//	char			* dmlno					= NULL;
//	char			* Filename					= NULL;
//	//char			Data[100]					= "";
//	//char			outputFile[200]				= "";
//
//	userid		= ITK_ask_cli_argument("-u=");
//	password 	= ITK_ask_cli_argument("-pf=");
//	group 		= ITK_ask_cli_argument("-g=");
//	dmlno 		= ITK_ask_cli_argument("-dmlno=");
//
//	time_t 	now;
//	struct 	tm when;
//
//	time(&now);
//	when = *localtime(&now);
//
//	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
//	//sprintf(outputFile,"%s_output.txt",Data);
//
//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
//	{
//		print_requirement();
//		return -1;
//	}
//
//	//ifail = ITK_auto_login();
//	ifail = ITK_init_module(userid, password, group);
//	if (ifail != ITK_ok)
//	{
//		printf("Error in Login to Teamcenter\n");
//		return ifail;
//	}
//	else
//		{
//			printf("\nLogin Successfull.....!!\n");
//			printf("\nWelcome to Teamcenter.....!!\n");
//		}
//	ifail = ITK_set_bypass(true);
//    if (ifail != ITK_ok)
//	{
//		printf("\nUser is not Privileged Admin User \n\n");
//		return -1;
//	}
//	//ifail = read_value_from_file(Filename);
//	ifail = tm_ChkVCMSforNOPOFun(dmlno);
//	CHECK_FAIL;
//
//	printf("\n*********************");
//	printf("\nEnd of program.....!!");
//	printf("\n*********************\n");
//	ifail = ITK_exit_module(true);
//
//	return ifail;
//}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	
	 ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	/*output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/

		//ifail = read_value_from_file(Filename);
		//ifail = GateMaturationUpd(dmlnob);
		ifail = tm_ChkVCMSforNOPOFun(dmlnob);
		CHECK_FAIL;

	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*design_group			= NULL;
	char 			*dr_status				= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s",itemid);


		//ifail = tm_DesignRevBOM(itemid,"13PP254028","DR2");
				ifail = tm_ChkVCMSforNOPOFun(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


int tm_ChkVCMSforNOPOFun(char* dmlno)
{
	int		ifail 		= ITK_ok;
	int     DR_n_entry    = 1;
	int     DR_rsltCount      =  0;
	int     jr      =  0;
	int     jrr      =  0;
	int     Refcount      =  0;
	int ReqFdrSize=0;
	int FldObjCount=0;
	char	*VCMSstrng		= NULL;
	char	*sPrtName		= NULL;
	char	*DmlNm		= NULL;
	char	*sPOCHKInfo3		= NULL;
	char	*DMLtype		= NULL;
	char	*PlntToPlnt		= NULL;
	char	*sDml_DR		= NULL;
	char	*sNOPOFldr		= NULL;
	char	*usernam		= NULL;
	char	*Partnumber		= NULL;
	tag_t   *DRCntrlObjectTag	= NULLTAG;
	tag_t *FoldObj_tag=NULLTAG;
	tag_t   DMLTag     = NULLTAG;
	tag_t   item_tag     = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t	RefTypeTag		= NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t NOPO_dml_Ref_Rel	= NULLTAG;
	tag_t *RefDoc_tag=NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char   Reftype_name[TCTYPE_name_size_c+1];
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	VCMSstrng = (char *) MEM_alloc(100 * sizeof(char ));

	Partnumber     =  (char *) MEM_alloc(500 * sizeof(char));

	printf("\nPO:....Inside PO check...\n");fflush(stdout);


	printf("\n PO:PO check started.... \n");fflush(stdout);
	//PO check bypass logic:
	if(QRY_find("ControlObjects", &DRqryTag));
	if (DRqryTag)
	{
		printf("\n PO:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n PO:Not Found Query ControlObjects \n");fflush(stdout);
	}

	DR_qry_values2[0] = "POCHCK";
	if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
	printf(" \n P1:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
	if(DR_rsltCount > 0)
	{
		//PO bypass
		if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&sPOCHKInfo3)!=ITK_ok)   PrintErrorStack();
		printf("\n P2:sPOCHKInfo3:%s\n",sPOCHKInfo3);fflush(stdout);
	
		if(strstr(sPOCHKInfo3,"VCMSSTART")==NULL)
		{
			if(ITEM_find_item (dmlno, &item_tag)!=ITK_ok) PrintErrorStack();
			if(item_tag==NULLTAG)
			{
				printf("\n P3:item_tag is Null...\n");fflush(stdout);
			}
			else
			{
				printf("\n P4:item_tag is found...\n");fflush(stdout);
				if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
				if(DMLTag==NULLTAG)
				{
					printf("\n P5:Object not found in Teamcenter...!!\n");fflush(stdout);
					return 0;
				}
				else
				{
					printf("\n P6:Object Found...!!");fflush(stdout);
					if(TCTYPE_ask_object_type(DMLTag,&objTypTag)!=ITK_ok)PrintErrorStack();
					if(TCTYPE_ask_name(objTypTag,ObjTyp)!=ITK_ok)PrintErrorStack();
					printf("\n P7: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
					if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						if(POM_get_user_id (&usernam)!=ITK_ok)PrintErrorStack();
						printf("\n P8:Session login User1 for MR : %s\n",usernam); fflush(stdout);
						if(AOM_ask_value_string(DMLTag,"item_id",&DmlNm)!=ITK_ok) PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok) PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&sDml_DR)!=ITK_ok)PrintErrorStack();
						printf("\n P9:DmlNm: %s DMLtype:%s PlntToPlnt:%s  sDml_DR:%s \n",DmlNm,DMLtype,PlntToPlnt,sDml_DR); fflush(stdout);
						//CALL WEB SERVICE
						printf("\n  before GetNoPOdmltostatus\n"); fflush(stdout);
						VCMSstrng = GetNoPOdmltostatus(DmlNm);
						printf("\n  after GetNoPOdmltostatus :: %s\n",VCMSstrng); fflush(stdout);

						//output string: VCMSstrng
						//Checking NOPO relations.
						if(GRM_find_relation_type("T5_CmHasNOPoDetails", &NOPO_dml_Ref_Rel)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(DMLTag,NOPO_dml_Ref_Rel,&Refcount,&RefDoc_tag)!=ITK_ok)PrintErrorStack();
						printf("\n P10: Refcount Value :   %d\n",Refcount);fflush(stdout);
						if(Refcount>0)
						{
							for (jr=0;jr<Refcount;jr++ )
							{
								if(TCTYPE_ask_object_type(RefDoc_tag[jr],&RefTypeTag));
								if(TCTYPE_ask_name(RefTypeTag,Reftype_name));
								printf("\n P11:Checking for....... :: %s\n", Reftype_name);fflush(stdout);
								if(AOM_ask_value_string(RefDoc_tag[jr],"object_name",&sNOPOFldr)!=ITK_ok)PrintErrorStack();
								printf("\n P12:folder name :: %s\n", sNOPOFldr);fflush(stdout);
								if((tc_strcmp(Reftype_name,"T5_NOPO_Parts") ==0)|| (tc_strcmp(Reftype_name,"NOPO Parts") ==0)||(tc_strcmp(Reftype_name,"T5_PSC_PORevMismatch_Parts") ==0)|| (tc_strcmp(Reftype_name,"P&SC PO Rev Mismatch Parts") ==0)||(tc_strcmp(Reftype_name,"T5_PORevMismatch_Parts") ==0)|| (tc_strcmp(Reftype_name,"PO Rev Mismatch Parts") ==0)||(tc_strcmp(Reftype_name,"T5_New_NOPO_Parts") ==0)|| (tc_strcmp(Reftype_name,"New NOPO Parts") ==0))
								{
									if((tc_strcmp(sNOPOFldr,"T5_NOPO_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"NOPO Parts") ==0)||(tc_strcmp(sNOPOFldr,"T5_PSC_PORevMismatch_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"P&SC PO Rev Mismatch Parts") ==0)||(tc_strcmp(sNOPOFldr,"T5_PORevMismatch_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"PO Rev Mismatch Parts") ==0)||(tc_strcmp(sNOPOFldr,"T5_New_NOPO_Parts") ==0)|| (tc_strcmp(sNOPOFldr,"New NOPO Parts") ==0))
									{
										printf("\n P13: Checking NOPO.\n");fflush(stdout);
										if(FL_ask_size(RefDoc_tag[jr],&ReqFdrSize));
										printf("\n P14:ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
										if(FL_ask_references(RefDoc_tag[jr],FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
										printf("\n P15:FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
										if(FldObjCount>0)
										{
											jrr=0;
											for (jrr=0;jrr<FldObjCount;jrr++ )
											{
												if(AOM_ask_value_string(FoldObj_tag[jrr],"item_id",&sPrtName)!=ITK_ok)PrintErrorStack();
												printf("\n P16:Checking part: %s.", sPrtName);fflush(stdout);
												tc_strcpy (Partnumber,"" );
												//tc_strcpy (Partnumber,"," ); //Web service need to handle for it.
												tc_strcat(Partnumber,sPrtName);
												tc_strcat(Partnumber,",");
												printf("\n P16:Checking part number: %s", Partnumber);fflush(stdout);

												if(tc_strstr(VCMSstrng,Partnumber)!=NULL)
												{
													if(AOM_lock( RefDoc_tag[jr])!=ITK_ok)PrintErrorStack();
													if(FL_remove(RefDoc_tag[jr],FoldObj_tag[jrr])!=ITK_ok)PrintErrorStack();
													if(AOM_save (RefDoc_tag[jr])!=ITK_ok)PrintErrorStack();
													if(AOM_unlock(RefDoc_tag[jr])!=ITK_ok)PrintErrorStack();
													if(AOM_refresh(RefDoc_tag[jr],TRUE)!=ITK_ok)PrintErrorStack();
													if(AOM_refresh(DMLTag,TRUE)!=ITK_ok)PrintErrorStack();
													printf("\n P17:part number removed: %s", Partnumber);fflush(stdout);
												}
											}											
										}
										else
										{
											printf("\n P17:Folder already NULL.\n");fflush(stdout);
										}
									}
								}
							}
						}

					}
				}
			}
		}
	}

	return 0;
}

