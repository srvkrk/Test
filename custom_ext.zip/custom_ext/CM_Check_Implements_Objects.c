/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Shivkumar Birnale, Dhiraj Agarwal
*  Module               :   Workflow Rule Handler to check if DML implements the appropriate DCR based on Control Objects
*  Code                 :   CM_Check_Implements_Objects.c
*  Created on			:   April 16th, 2018
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		CM_Check_Implements_Objects
	Description			:		This handler checks the DCR implemented by DML
*/



EPM_decision_t CM_Check_Implements_Objects(EPM_rule_message_t msg)
{
	int i=0,j=0,k=0,status=ITK_ok;
	int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *dmlProjID=NULL;
	char *dmlDRStatus=NULL;
	char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;
	tag_t rootTask_t=NULLTAG;
	tag_t ItemObj = NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t ctrlObjQry=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	
	printf("\n CM_Check_Implements_Objects Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Check_Implements_Objects Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasProblemItem",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));

	for(i=0;i<attachmentCount;i++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[i],&obj_type));
		TC_write_syslog("Object Type = %s\n",obj_type);
		if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
		{
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));
			if(ctrlObjQry!=NULLTAG)
			{
				char *qryEntries[]={"SYSCD","SUBSYSCD","Information-1"};
				char *qryValues[]={"ISDCR",dmlProjID,dmlRelType};
				ITK_CALL(QRY_execute(ctrlObjQry,3,qryEntries,qryValues,&qryRetCnt,&qryResults));
			}
			else
			{
				TC_write_syslog("Control Objects... query not found, Please contact TC Admin\n");
			}
			TC_write_syslog("Query objects returned = %d\n",qryRetCnt);
			if(qryRetCnt == 0)
			{
				TC_write_syslog("No Control Objects found\n");
				//EMH_store_error_s1(EMH_severity_error,CONTROL_OBJ_NOT_FOUND,"No Control Objects found for DCR, kindly Contact to TCUA PLM Admin Team.");
				return EPM_go;
			}
			if(qryRetCnt == 1)
			{

				ITK_CALL(AOM_ask_value_string(qryResults[0],"t5_Userinfo2",&usrInfo2));
				
				if(tc_strstr(usrInfo2,dmlDRStatus)!=NULL)
				{
					if(implemRelationType_t != NULLTAG)
					{
						ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[i],implemRelationType_t,&Dcrcnt,&DcrList));
						
						TC_write_syslog("\n DCR count = %d\n",Dcrcnt);
						if(Dcrcnt==0)
						{
							TC_write_syslog("No DCR attached to DML, Hence returning EPM_nogo\n");
							EMH_store_error_s1(EMH_severity_error,EPM_DCR_NOTFOUND,"\tDCR is not attached with DML Revision.Kindly attach Approved DCR with DML Revision in Implements relation\t");
							return EPM_nogo;
						}
						if(Dcrcnt > 0)
						{
							TC_write_syslog("DCR Count attached to DML = %d\n",Dcrcnt);
							return EPM_go;
						}
					}
					else
					{
						TC_write_syslog("CMImplements relation not found, Contact Admin\n");
						return EPM_nogo;
					}
				}
				else
				{
					TC_write_syslog("DR status not found in Control Object's Info2\n");
					//EMH_store_error_s1(EMH_severity_error,DR_NOT_MATCH,"DML DR and Control Obj DR Status are not match, kindly check the DR Status of DML.");
					return EPM_go;
				}
			}
			else
			{
				TC_write_syslog("Multiple Control Objects found. Hence returning EPM_go\n");
				return EPM_go;
			}
		}
		else
		{
			TC_write_syslog("\nObject Type is not ChangeRequestRevision. Hence returning EPM_nogo\n");
			//EMH_store_error_s1(EMH_severity_error,DML_REVISION_NOT_FOUND,"Please Submit DML Revision in Work Flow.");
			return EPM_go;
		}
	}
	TC_write_syslog("No ChangeRequestRevision found in targets\n");
	printf("\n CM_Check_Implements_Objects Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Check_Implements_Objects Function end...");
	return EPM_go;
}