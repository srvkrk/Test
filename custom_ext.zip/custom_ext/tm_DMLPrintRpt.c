/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan/Anant
*  Module               :   Workflow Action Handler to update latest released revisin of parts attached to GMD.
*  Code                 :   tm_DMLPrintRpt.c
*  Created on			:   14/07/2020
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_DMLPrintRpt(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *PrintDMLInfo1		= NULL;
	char *PrintDMLInfo2		= NULL;
	char *command		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	command=(char *)MEM_alloc(600);
	
	printf("\n tm_DMLPrintRpt Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DMLPrintRpt Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_DMLPrintRpt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n tm_DMLPrintRpt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n tm_DMLPrintRpt:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n tm_DMLPrintRpt:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "PRINTDML";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n tm_DMLPrintRpt:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//ON OFF:
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&PrintDMLInfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n tm_DMLPrintRpt:PrintDMLInfo1 is :[%s]\n", PrintDMLInfo1);fflush(stdout);
					//Path:
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&PrintDMLInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n tm_DMLPrintRpt:PrintDMLInfo2 is :[%s]\n", PrintDMLInfo2);fflush(stdout);
					if(strstr(PrintDMLInfo1,"DMLPRINTOFF")==NULL)
					{
						if(strstr(PrintDMLInfo1,"DMLPRINTUAPROD")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n tm_DMLPrintRpt:UAPROD:DML no : %s ", DMlid);fflush(stdout);
							tc_strcpy(command,"");
							tc_strcpy(command,PrintDMLInfo2);
							tc_strcat(command," ");
							tc_strcat(command,DMlid);
							printf("\n tm_DMLPrintRpt::command: %s",command);fflush(stdout);
							//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
							//sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else
						{
							printf("\n DML:other client \n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_DMLPrintRpt Function end...");fflush(stdout);
	TC_write_syslog("\n tm_DMLPrintRpt Function end...");

	//return error_code;
	return 0;
}