/****************************************************************************************************
**	SOURCE FILE NAME	: tm_GateMaturation.c
**	Author				: Mohan/Bhaskar
**
**	Date							Author					Modification
**	06-Feb-2019						Mohan Tayade			Code creation
**
** command to run:
** tm_GateMaturation -u=ercpsup -p=XYT1ESA -g=dba -dmlno=
******************************************************************************************************/
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
//#define BOM_compare_output_report

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int tm_GateMaturation_Func(EPM_action_message_t msg)
{
	int		i		=  0;
	int		crr		=  0;
	int		ii		=  0;
	int		tsk			= 0;
	int		Tskcnt		= 0;
	int		Mstr		= 0;
	int		Item_count	= 0;
	int		CMRefcount	= 0;
	int		rel_status_cunt	= 0;
	int     DR_n_entry		= 1;
	int     PRTSTVAL		= 0;
	int     FrmValueIntg	= 0;
	int     RelRevFlag		= 0;
	int     DR_rsltCount	= 0;
	int     no_attach      = 0;
	int		error_code	= ITK_ok;
	char	*PlntToPlnt		= NULL;
	char	*PartMstr_no	= NULL;
	char	*DMLProj		= NULL;
	char	*TskNm			= NULL;
	char	*FromPlnt		= NULL;
	char	*rev_idd		= NULL;
	char	*DMLtype		= NULL;
	char	*TaskDsgGrp		= NULL;
	char	*Partno			= NULL;
	char	*Toplnt			= NULL;
	char	*PrtDRst		= NULL;
	char	*rel_status		= NULL;
	char	*Tsk_object_type = NULL;
	char	*Prt_object_type = NULL;
	char	*GMinfo5		= NULL;
	char	*ToValue		= NULL;
	char	*FrmValueStr	= NULL;
	char	*DRinfo4		= NULL;
	char	*PRTSubStr		= NULL;
	char	*Chld_Rel_Stus	= NULL;
	char	DRStrng[20];
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char	ObjTyp[TCTYPE_name_size_c+1];
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	tag_t	*TaskCMRef		= NULLTAG;
	tag_t	*rev_list		= NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t*	rel_status_lst	= NULLTAG;
	tag_t	roottask        = NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t	*Dml_tasks		= NULLTAG;
	tag_t   attr_id		= NULLTAG;
	tag_t   objTag		= NULLTAG;
	tag_t   DRqryTag		= NULLTAG;
	tag_t	*taskAttachments	= NULLTAG;
	tag_t   *DRCntrlObjectTag   = NULLTAG;

	printf("\n GM: Gate Maturation DML start.");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n GM:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//DML Details:
				if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
				printf("\n GM: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s]",DMLtype,DMLProj,PlntToPlnt);fflush(stdout);
				if(tc_strcmp(DMLtype,"TODR")==0)
				{
					if(QRY_find("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "CREVali";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n CREVali:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&GMinfo5)!=ITK_ok)   PrintErrorStack();
						printf("\n DRinfo4:%s GMinfo5: %s\n",DRinfo4,GMinfo5);fflush(stdout);
					}

					if(PlntToPlnt!=NULL)
					{
						//AR0 to AR1
						if(tc_strstr(GMinfo5,PlntToPlnt) != NULL)
						{
							FromPlnt=subString(PlntToPlnt, 0, 3);
							Toplnt=subString(PlntToPlnt, 7, 3);
							printf("\n GM: FromPlnt:[%s] FromPlnt:[%s]\n", FromPlnt,Toplnt);fflush(stdout);

							ToValue=NULL;
							ToValue=subString(Toplnt, 2, 1);
							printf("\n GM: ToValue: %s",ToValue);fflush(stdout);
							FrmValueIntg=0;
							FrmValueStr=NULL;
							FrmValueStr=subString(FromPlnt, 2, 1);
							FrmValueIntg=atoi(FrmValueStr);
							printf("\n GM: FrmValueStr: %s, FrmValueIntg: %d",FrmValueStr,FrmValueIntg);fflush(stdout);
							Tskcnt=0;
							if(AOM_ask_value_tags(taskAttachments[i],"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
							printf("\n GM:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
							if (Tskcnt>0)
							{
								for (tsk=0;tsk<Tskcnt ;tsk++ )
								{
									if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
									printf("\n GM:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

									if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
										if(TaskDsgGrp) TaskDsgGrp=NULL;
										if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
										TaskDsgGrp=subString(TskNm,11,2);
										printf("\n GM: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
										if(tc_strstr(TskNm,"CO")==NULL)
										{
											if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
											if (tsk_CMRef_type!=NULLTAG)
											{
												CMRefcount=0;
												if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
												printf("\n GM: Task CMRefcount: %d",CMRefcount);fflush(stdout);
												if(CMRefcount > 0)
												{
													Mstr=0;
													for (Mstr=0;Mstr<CMRefcount ;Mstr++)
													{
														printf("\n GM:Design Mstr:%d",Mstr);fflush(stdout);
														if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
														// put condition for desi rev , to avoid other attachments.
														if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
														printf("\n GM:Part Mstr_no:%s",PartMstr_no);	fflush(stdout);
														Item_count=0;
														if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
														if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
														printf("\n GM:Total rev found: %d.", Item_count);fflush(stdout);
														if(Item_count > 0)
														{
															ii=0;
															for(ii=Item_count-1;ii>=0;ii--)
															{
																rel_status_cunt=0;
																objTag = rev_list[ii];
																if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																printf("\n GM:Part %s rev:%s and Rel Status:%s", Partno,rev_idd,rel_status);fflush(stdout);
																//Release status.
																if(WSOM_ask_release_status_list (rev_list[ii], &rel_status_cunt, &rel_status_lst)!=ITK_ok)PrintErrorStack();
																printf("\n DR:rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);
																if(rel_status_cunt > 0)
																{
																	crr=0;
																	RelRevFlag=0;
																	for(crr=0;crr<rel_status_cunt;crr++)
																	{
																		if(AOM_ask_value_string (rel_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
																		printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
																		if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Rlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Released")!=NULL))
																		{
																			RelRevFlag=1;
																			PrtDRst=NULL;
																			if(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&PrtDRst)!=ITK_ok)PrintErrorStack();
																			printf("\n GM: Partno:%s rev_idd:%s PrtDRst:%s Toplnt:%s", Partno,rev_idd,PrtDRst,Toplnt);fflush(stdout);
																			if((tc_strcmp(PrtDRst,"")==0) || (tc_strcmp(PrtDRst,"NA")==0))
																			{
																				printf("\n GM:A:Part updation...");fflush(stdout);
																				if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																				if(tc_strstr(DRinfo4,"DRPOMUPD") != NULL)
																				{
																					if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																				}
																				else
																				{
																					if(POM_attr_id_of_attr("t5_PartStatus", "ItemRevision", &attr_id))PrintErrorStack();
																					if(POM_set_attr_string(1,&objTag,attr_id,Toplnt)) PrintErrorStack();
																				}
																				if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																				if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																				printf(" done for part:%s\n",Partno);fflush(stdout);
																			}
																			else 
																			{
																				PRTSTVAL=0;
																				PRTSubStr=NULL;
																				PRTSubStr=subString(PrtDRst, 2, 1);
																				PRTSTVAL=atoi(PRTSubStr);
																				printf("\n GM: PRTSubStr: %s, PRTSTVAL: %d FrmValueIntg:%d ToValue:%s",PRTSubStr,PRTSTVAL,FrmValueIntg,ToValue);fflush(stdout);
																				//From plant value == Part current DR-status
																				if (FrmValueIntg == PRTSTVAL)
																				{
																					tc_strcpy(DRStrng,"");
																					if(tc_strstr(PrtDRst,"DR") != NULL)
																					{
																						tc_strcpy(DRStrng,"DR");
																					}
																					else
																					{
																						tc_strcpy(DRStrng,"AR");
																					}
																					tc_strcat(DRStrng,ToValue);
																					printf("\n GM:A:Part updation..with status:%s ",DRStrng);fflush(stdout);
																					if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																					if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																					if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																					printf(" done for part:%s\n",Partno);fflush(stdout);
																				}
																				else
																				{
																					printf("\n Part not allow for updation:%s\n",Partno);fflush(stdout);
																				}
																			}
																			if (RelRevFlag >0)
																			{
																				break;
																			}
																		}
																	}
																	if (RelRevFlag >0)
																	{
																		break;
																	}
																}
															}
														}
													}
												}
											}
										}
										else
										{
											printf("\n GM: No Expanssion for CO task.");fflush(stdout);
										}
									}
								}
							}
						}
					}
					else
					{
						//Blank value
						printf("\n GM: Blank value..");fflush(stdout);
					}
					if(TaskCMRef) MEM_free(TaskCMRef);
					if(rev_list) MEM_free(rev_list);
				}
				printf("\n GM: ......Updation Function end for GM DML.");fflush(stdout);
				break;
			}
		}
	}

	return error_code;
}


int tm_GateMaturation_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{
		retcode = EPM_register_action_handler ("tm_GateMaturation","tm_GateMaturation",(EPM_action_handler_t)tm_GateMaturation_Func);
	}
	return retcode;
}

extern int tm_GateMaturation_action(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	
	status = tm_GateMaturation_register_action_handlers();
	return status;
}

extern DLLAPI int tm_GateMaturation_register_callbacks ()
{
	int ifail    = ITK_ok;
    ifail=CUSTOM_register_exit("tm_GateMaturation","USER_init_module",(CUSTOM_EXIT_ftn_t)tm_GateMaturation_action);	
    return ( ITK_ok );
}
