#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <ctype.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 9)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;


#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;


void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
};
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void setAddStr(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((tc_strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr character found===%s",(*strset)[*count-1]);fflush(stdout);



	}


			
			
			
			

			/*Version LOV for ECU Parameter*/
/****************************************************************************
Function:       dynamic_ecuversion_LOV
Description:    This function used while creating ECU Parameter to populate version LOV
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_ecuversion_LOV( char*** VerLovValue  ) 
{

/* va_list for LOV_ask_values_msg */

 
    char   *user_name_string = NULL;
  int status;
  int j =0;
 tag_t*		list_of_WSO_cntrl_tags=NULLTAG;
    char  ***values = NULL;
	int        control_number_found;
  WSO_search_criteria_t  	criteria_control;
    int  
        ifail = ITK_ok;
      int max_char_size = 50;
      char *rolename=NULL;
	  char *Version=NULL;
	  char *Version1=NULL;
	  char *Version2=NULL;
	  char *Version3=NULL;
	  char *Version4=NULL;
	  char *Version5=NULL;
	  char *Version6=NULL;
	  char *Version7=NULL;
	  char *Version8=NULL;
	  char *Version9=NULL;
	  char *Version10=NULL;
	  char *subSyscd=NULL;
      rolename =  MEM_alloc(100);
	  Version =	  MEM_alloc(50000);
 	 tag_t  user = NULLTAG;
	char *VersionDup = (char *)MEM_alloc(max_char_size * sizeof(Version)+1);
	char *vers = (char *)MEM_alloc(max_char_size * sizeof(Version)+1);
     int Lov_cnt=0;
  
	   printf("\n inside func dynamic_ecuversion_LOV");fflush(stdout);

	   CALLAPI(SA_init_module());
	   printf("\n SA_init_module");fflush(stdout);
	   CALLAPI(POM_get_user(&user_name_string, &user));
	   printf("\n POM_get_user");fflush(stdout);
	  
		tag_t  CurrentRoleTag = NULLTAG;
	//	char       roleName[SA_name_size_c+1]  ;
	char * roleName =NULL;
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	//	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		
		//func start t5GetVersionList by rajesh
			WSOM_clear_search_criteria(&criteria_control);
			strcpy(criteria_control.name,"ECU_VERSION");
			strcpy(criteria_control.class_name,"T5_ControlObject");
			status	= WSOM_search(criteria_control, &control_number_found, &list_of_WSO_cntrl_tags);

			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			for(j=0;j<control_number_found;j++)
			{

				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_SubSyscd", &subSyscd);
	            printf("\n subSyscd: %s\n",subSyscd);fflush(stdout);

				if(strcmp(subSyscd,"Version")==0)
				{
				printf("\n j++++++++++++++++++[%d]\n",j);fflush(stdout);				
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo1", &Version1);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo2", &Version2);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo3", &Version3);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo4", &Version4);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo5", &Version5);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo6", &Version6);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo7", &Version7);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo8", &Version8);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo9", &Version9);
				AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_userinfo10", &Version10);
				printf("\n Version1: %s Version2=%s Version3=%s Version4=%s Version5: %s Version6=%s Version7=%s Version8=%s Version9=%s Version10=%s\n",Version1,Version2,Version3,Version4,Version5,Version6,Version7,Version8,Version9,Version10);fflush(stdout);
		        if(tc_strlen(Version1)>0)
				{
					tc_strcpy(Version,Version1);
				}
				//printf("\n 1111: ");
				if(tc_strlen(Version2)>0)
				{
					tc_strcat(Version,Version2);
				}
				//printf("\n 2222: ");
				if(tc_strlen(Version3)>0)
				{
					tc_strcat(Version,Version3);
				
				}
				//printf("\n 3333: ");
				if(tc_strlen(Version4)>0)
				{
					tc_strcat(Version,Version4);
				
				}
				//printf("\n 4444: ");
				if(tc_strlen(Version5)>0)
				{
					tc_strcat(Version,Version5);
				
				}
				//printf("\n 5555: ");
				if(tc_strlen(Version6)>0)
				{
					tc_strcat(Version,Version6);
				
				}
				//printf("\n 6666: ");
				if(tc_strlen(Version7)>0)
				{
					tc_strcat(Version,Version7);
				
				}
				//printf("\n 7777: ");
				if(tc_strlen(Version8)>0)
				{
					tc_strcat(Version,Version8);
				
				}
				//printf("\n 8888: ");
				if(tc_strlen(Version9)>0)
				{
					tc_strcat(Version,Version9);
				
				}
				//printf("\n 9999: ");
				if(tc_strlen(Version10)>0)
				{
					tc_strcat(Version,Version10);
				
				}
				//printf("\n 1010: ");
				 printf("\n Version: %s ",Version);
				 if(tc_strlen(Version)>0)
				{
				 printf("\n inside LOV Version: %s ",Version);
				 
				   tc_strcpy(VersionDup,Version);
				    printf("\n VersionDup: %s ",VersionDup);
				   
				   //version=nlsStrAlloc(50);
				   vers = tc_strtok(Version,";"); 
				   printf("\n After Tok Version: %s ",Version);
				 while (vers != NULL)				   
				 //  if(tc_strlen(vers)>0)
				   {
				   printf("\n inside SetAddStr vers: %s ",vers);
				   setAddStr(&Lov_cnt,VerLovValue,vers);
				   vers = tc_strtok(NULL, ";");
				   
				   }
				   	
				   /*if(Version)
				   {
					   Version = NULL;
				   }*/
				}
				 
				 }
				 
			}
			
			//end by Rajesh

    return Lov_cnt;
}


/****************************************************************************
Function:       dynamic_ecuLov_LengthsMethod
Description:    This function used while creating ECU Parameter to populate version LOV
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_ecuLov_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, const tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **VerLovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n 	");fflush(stdout);
  
  *length=dynamic_ecuversion_LOV(&VerLovValue);
  printf("\n dynamic_ecuLov_LengthsMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_ecuVerLov_ValuesMethod
Description:    This function used to get ECU Version list based on control object ECU_VERSION
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_ecuVerLov_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

               logical active = TRUE;
               tag_t lov_tag = va_arg (args, const tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
               int Lov_cnt=0;
   
  
                printf("\n inside dynamic_ecuVerLov_ValuesMethod method");fflush(stdout);
                 
                *n_values=dynamic_ecuversion_LOV(&LR_LovValue);
               printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);
				*values = (char **) MEM_alloc (*n_values * sizeof (char*));
				//printf("\n memory allocated for *values" );fflush(stdout);
               memset (*values, 0,  *n_values * sizeof(char*));
			  // printf("\n memset memory allocated for *values with *n_values size[%d]",*n_values );fflush(stdout);
               for (ii = 0; ii < *n_values; ii++)
               { 
                               //printf("\n inside loop to new memory allocated for *values" );fflush(stdout);                                                          
                              (*values)[ii] = (char *) MEM_alloc (tc_strlen(LR_LovValue[ii]) + 1);
							   //printf("\n after new memory allocated for *values" );fflush(stdout);    
                              tc_strcpy ((*values)[ii], LR_LovValue[ii]);
							  //printf("\n after dynamic lov copied to *values" );fflush(stdout);
                                                               
               } 
      printf("\n End of func dynamic_ecuVerLov_ValuesMethod with ifail val[%d]",ifail );fflush(stdout);           
    return ifail; 
}


int ecu_param_create(METHOD_message_t *msg,va_list  args)
{
	EPM_decision_t decision;
 	/***start ITEM_create_msg overridable signature***/
	char* did_val1  = va_arg(args, char*);
    const char* item_name1 = va_arg(args, char*);
    const char* type_name1 = va_arg(args, char*);
    const char* rev_id1 = va_arg(args, char*);
    tag_t*      ecuTag = va_arg(args, tag_t*);
    tag_t*      ecuTagrev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	/***End ITEM_create_msg overridable signature***/
    int		status;
	int	error_code	= ITK_ok,
	i=0;
	char *did_val 	   = NULL;
	char cCurrentAccessDate[20]={0};
	char *Year=NULL;
	int errno =0;
	int t =0;
	int iLen = 0;
	int bIsNumber = 0; //0=TRUE
	int max_char_size = 100;
	char *Ecu_length = NULL;
	char *EcuType = NULL;
	char *e = NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	tag_t  objTypeTag = NULLTAG;
//	char       roleName[SA_name_size_c+1]  ;
	char * roleName =NULL;
    char   *PlantName=NULL;
	char *val = (char *)MEM_alloc(max_char_size * sizeof(char));
	//char   type_name[TCTYPE_name_size_c+1];
	char	*type_name			=	NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
    printf("\n **************inside ecu_param_create***************\n ");fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
	Year=subString(cCurrentAccessDate,9,2);
	printf("\n ecu_param_create Year =  %s \n",Year);				
	if(TCTYPE_ask_object_type(*ecuTag,&objTypeTag));
//	if(TCTYPE_ask_name(objTypeTag,type_name));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n    ecu_param_create type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
    ITKCALL(SA_ask_current_role(&CurrentRoleTag));
//	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
   ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));

	printf("\n\n ecu_param_create roleName : %s \n",roleName); fflush(stdout);
	PlantName=subString(roleName,0,4);
	printf( "PlantName:%s\n", PlantName);
	if(strcmp(PlantName,"")==0)
	{
			printf("\n ecu_param_create Role is not correct  %s \n",PlantName);
			EMH_clear_errors();
			status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Select the Correct Role for ecu_param_create Creation");
			decision = EPM_nogo;
			return ITK_errStore;
	}
		    printf("\n inside class T5_EPara......\n");fflush(stdout);
			AOM_ask_value_string( *ecuTag, "t5_EPDidValue", &did_val);
			AOM_ask_value_string( *ecuTag, "t5_EPLen", &Ecu_length);
			AOM_ask_value_string( *ecuTag,"t5_ECUType",&EcuType);
			printf("\n ecu_param_create did_val : %s\n",did_val);fflush(stdout);
			printf("\n ecu_param_create Ecu_length : %s\n",Ecu_length);fflush(stdout);
			printf("\n ecu_param_create EcuType is : %s\n",EcuType);fflush(stdout);
			
			//logic to check DID value is hex or not
			 if(did_val[tc_strlen(did_val)-1]=='\n' ) did_val[tc_strlen(did_val)-1]=0;
			   errno=0;
			   t = strtoul(did_val,&e,16);
			   printf("\nt:%d errno:%d \n",t,errno);fflush(stdout);
			   if(*e != 0x00)
			   {
				printf("\n Input value for DIDVal is not Hex Format  %s \n",did_val);
				EMH_clear_errors();				
				//status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Enter Valid DIDVal in Hexadecimal Format");
				tc_strcpy(val,"Please Enter Valid DIDValue in Hexadecimal Format:Your Input DIDVal is = ");
				tc_strcat(val,did_val);
				printf("Val=%s",val);
				
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,val);
				decision = EPM_nogo;
				return ITK_errStore;
			   }
			
			//logic to check EElength value is integer 
			if(tc_strlen(Ecu_length)>0)
			{
				//val=NULL;
				iLen = tc_strlen(Ecu_length);
				for(i=0;i<iLen;i++)
				{
					if(Ecu_length[i] > 57 || Ecu_length[i] < 48)
					{
						bIsNumber = 1; //for 0=FALSE
						break;
					}
				}
				printf("\n bIsNumber  %d \n",bIsNumber);
				if(bIsNumber == 1)
				{
				printf("\n Input value for Ecu_length is not integer  %s \n",Ecu_length);
				
				tc_strcpy(val,"Please Enter Valid Integer value for Ecu_length:Your Input Ecu_length is = ");
				tc_strcat(val,Ecu_length);
				printf("Val=%s",val);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,val);
				decision = EPM_nogo;
				return ITK_errStore;
				}
			}


    return error_code;

}

// Func to getting Vehicle from Tech Spec Object 
	extern DLLAPI int getEEPartfrmEcuParam(tag_t EcuParamObj,tag_t* EEPartFrmECUParam)
	{

		 printf("\n Start func getEEPartfrmEcuParam\n");fflush(stdout);
		int ifail = ITK_ok;
		 int		status;
		tag_t relType = NULLTAG;
		tag_t* primary_objects = NULL;
		int count=0;


		ITKCALL(GRM_find_relation_type("T5_EEPrm", &relType));

		printf("\n EcuParamObj=%u relType=%u\n",EcuParamObj,relType);fflush(stdout);
		
		if( relType != NULLTAG )
		{
			ITKCALL(GRM_list_primary_objects_only(EcuParamObj,relType,&count,&primary_objects));
			printf("\n count=%d \n",count);fflush(stdout);
			if(count > 0)
			{

			*EEPartFrmECUParam = primary_objects[0];
			}

		}
		return ifail;	

		printf("\n End func getEEPartfrmEcuParam\n");fflush(stdout);

	}


	extern DLLAPI int getEEPartRelationFrmEcuParam(METHOD_message_t * message, va_list args )
	{

	printf("\n Start func getEEPartRelationFrmEcuParam\n");fflush(stdout);
    int ifail = ITK_ok;
	tag_t *EEPartTag=NULLTAG;
	 int		status;

        tag_t EcuParamTag= message->object_tag;

        va_list largs;

        va_copy( largs, args);
        va_arg( largs, tag_t );
        EEPartTag = va_arg( largs, tag_t*);
        va_end( largs );

		

			printf("\n Calling func getEEPartfrmEcuParam\n");fflush(stdout);
			ITKCALL(getEEPartfrmEcuParam(EcuParamTag,EEPartTag));

			printf("\n After func call getEEPartfrmEcuParam EEPartTag=%u\n",EEPartTag);fflush(stdout);
			
				
			
			return ifail;	

		printf("\n End func getEEPartRelationFrmEcuParam\n");fflush(stdout);
			
	}

extern int tm_ecuparamcre_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
	METHOD_id_t methodpos;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;
   ifail = METHOD_find_method("T5_EPara", ITEM_create_msg, &method1);
	if (method1.id != NULLTAG)
	{
		ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) ecu_param_create, NULL)!=ITK_ok;
		printf("\nrrrrrrrrRegistered for ecu_param_create as METHOD_post_action_type \n");fflush(stdout);
	}
	else
	{
		printf("\nMethod ecu_param_create not found!TC_save_msg\n");fflush(stdout);
	}
	
	printf("\n  b4 METHOD_register_prop_method for getEEPartRelationFrmEcuParam \n");fflush(stdout); 		
	ITKCALL(METHOD_register_prop_method("T5_EParaRevision", "t5_ParamOfEEPrt",  PROP_ask_value_tag_msg, getEEPartRelationFrmEcuParam, 0,  &method2 ));
	printf("\n  After METHOD_register_prop_method for getEEPartRelationFrmEcuParam\n");fflush(stdout); 	
	//printf("\n  b4 METHOD_register_method for dynamic_ecuversion_LOV \n");fflush(stdout); 	
	ITKCALL(METHOD_register_method( "T5_EcuVersionListLov",LOV_ask_values_msg,&dynamic_ecuVerLov_ValuesMethod, 0,&methodpos));
	//printf("\n  After METHOD_register_method for dynamic_ecuversion_LOV \n");fflush(stdout); 	
			printf("\n  b4 METHOD_register_method for dynamic_ecuLov_LengthsMethod \n");fflush(stdout); 		
		ITKCALL(METHOD_register_method( "T5_EcuVersionListLov",LOV_ask_num_of_values_msg,&dynamic_ecuLov_LengthsMethod,0,&methodpos));
		printf("\n  After METHOD_register_method for dynamic_ecuLov_LengthsMethod \n");fflush(stdout); 	
	
    return ITK_ok;
}

extern DLLAPI int tm_ecuparamcre_register_callbacks()
{
	

	 CUSTOM_register_exit("tm_ecuparamcre", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_ecuparamcre_register_method);

     printf("\n registered function tm_ecuparamcre\n");	fflush(stdout);

	 return ( ITK_ok );
}
