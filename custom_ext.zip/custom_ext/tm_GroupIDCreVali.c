/********************************************************************************************************
*  File			: tm_GroupIDCreVali.c
*  Created By	: Prasad Sagare
*  Created On	: 24-Apr-2024
*  Project		: TCUA 	 
*  Purpose		: Custom user exit for - Group ID & DML relation creation
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"

extern DLLAPI int tm_GroupIDCreVali(METHOD_message_t *msg, va_list args)
{
  	va_list largs;
	va_copy( largs, args );

	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	
	int ifail = 0;
	int count = 0;
	int n_entry = 1;
	int rsltCount = 0;
	int taskcount = 0;
	int dChildvALIPass = 0;
	int iChild = 0;
	int s = 0;
	int j = 0;
	int is = 0;
	int qq = 0;
	int groupIDfnd = 0;
	int D_TskCnt = 0;
	int rulefounddd =0;
	int ChildCunt =0;
	int CADdataset =0;
	int GrpChildPass=0;
	int Speccount=0;
	int tsktodmlrelcount = 0;
	char *Part_no = NULL;
	char *part_revid = NULL;
	char *sPart_tpe = NULL;
	char *zTasknum = NULL;
	char *xrel_status = NULL;
	char *xPrtDRst = NULL;
	char *xParentProj = NULL;
	char *sDMLno = NULL;
	char *yDmlDR = NULL;
	char *ysDml_TP = NULL;
	char *yDML_project = NULL;
	char *DMLrlsts = NULL;
	char *RelTypeCat = NULL;
	char *p_child_item_id = NULL;
	char *rel_sstats = NULL;
	char *Obj_PrtTyp = NULL;
	char *rev_iidd = NULL;
	char *PrtDRstus = NULL;
	char *PrtProjj = NULL;
	char *selectedname = NULL;
	char *curentname = NULL;
	tag_t Itemtag = NULLTAG;
	tag_t latestrev = NULLTAG;
	tag_t p_window = NULLTAG;
	tag_t p_rule = NULLTAG;
	tag_t ImanSpec = NULLTAG;
	tag_t POclose_taggg = NULLTAG;
	tag_t p_top_line = NULLTAG;
	tag_t SecObjDSTag = NULLTAG;
	tag_t *Childobject = NULLTAG;
	tag_t *DTskObj = NULLTAG;
	tag_t *POclosureruleee = NULLTAG;

	char **POrulenameXO = NULL;
	char **POrulevalueXO = NULL;

	tag_t objTypeTag = NULLTAG;
	tag_t SpecTypeTag = NULLTAG;
	tag_t DumItmTag = NULLTAG;
	tag_t DumRevtag = NULLTAG;
	tag_t DMYpart_tsk_rel_typ = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t secObjTypeTag = NULLTAG;
	tag_t relObjTypeTag = NULLTAG;
	tag_t taskjob = NULLTAG;
	tag_t task_job_type = NULLTAG;
	tag_t tsktodmlrel = NULLTAG;
	tag_t DMLReviTag = NULLTAG;
	tag_t roottask = NULLTAG;
	tag_t DMLRevclass_id = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *DMLRev = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *CntrlObjectTag = NULLTAG;
	tag_t *SpecDoc_tag = NULLTAG;
	tag_t COqryTag = NULLTAG;
	
	char *Sesusername = NULL;
	char *DRinfo1 = NULL;
	char *DRinfo2 = NULL;
	char *DRinfo3 = NULL;
	char *DRinfo4 = NULL;
	char *DRinfo5 = NULL;
	char *sDMLtyp = NULL;
	char *nameofroot = NULL;
	char *taskTempLT = NULL;
	char *taskstatus = NULL;
	char *DMLClassname = NULL;
	char *SubSubtaskType = NULL;

	char* type_name= NULL;
	char* Spectype_name= NULL;
	char* sec_type_name= NULL;
	char* rel_type_name= NULL;
	char* name_relation= NULL;

	EPM_decision_t	decision	= EPM_go;
	logical islatest ;

	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values =  (char **) MEM_alloc(64 * sizeof(char *));
	printf("\n tm_GroupIDCreVali Function started...");fflush(stdout);
	TC_write_syslog("\n tm_GroupIDCreVali Function started...");

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));

	if(TCTYPE_ask_object_type(secondary_object,&secObjTypeTag));
	if(TCTYPE_ask_name2(secObjTypeTag,&sec_type_name));

	CALLAPI(TCTYPE_ask_name2( relation_type,&name_relation));

	if(TCTYPE_ask_object_type(relation_type,&relObjTypeTag));
	if(TCTYPE_ask_name2(relObjTypeTag,&rel_type_name));

	CALLAPI(POM_get_user_id (&Sesusername));
	printf("\n T5GroupIDCreVali-->Sesusername : %s\n",Sesusername); fflush(stdout);

	printf("\n GID:Primary Object Type: [%s]\n",type_name); fflush(stdout);
	printf("\n GID:Secondary Object Type: [%s]\n",sec_type_name); fflush(stdout);
	printf("\n GID:Session User: [%s]\n",Sesusername); fflush(stdout);

	printf("\n T5GroupIDCreVali:: rel_type_name: [%s] Prim_Obj_type:[%s] sec_type_name:[%s] name_relation:[%s]", rel_type_name , type_name, sec_type_name,name_relation );fflush(stdout);


	if(QRY_find2("ControlObjects", &COqryTag));
	if (COqryTag)
	{
		printf("\n GID:-->GroupIDDML:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n GID:-->GroupIDDML:Not Found Query ControlObjects \n");fflush(stdout);
	}

	qry_values[0] = "GroupIDDML";
	if(QRY_execute(COqryTag, n_entry, qry_entry, qry_values, &rsltCount, &CntrlObjectTag));
	printf(" \n GID:-->GroupIDDML: rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&DRinfo1)!=ITK_ok)   PrintErrorStack();
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&DRinfo2)!=ITK_ok)   PrintErrorStack();
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&DRinfo3)!=ITK_ok)   PrintErrorStack();
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok)   PrintErrorStack();
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo5",&DRinfo5)!=ITK_ok)   PrintErrorStack();

		printf("\n T5GroupIDCreVali-->DRinfo1: %s DRinfo2:%s DRinfo3:%s DRinfo4:%s  DRinfo5:%s\n", DRinfo1,DRinfo2,DRinfo3,DRinfo4,DRinfo5);fflush(stdout);
	}

	if(tc_strstr(DRinfo1,"OffAdd") == NULL)
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsktodmlrel));
		if(tsktodmlrel)
		{
			CALLAPI(GRM_list_primary_objects_only(primary_object,tsktodmlrel,&tsktodmlrelcount,&DMLRev));
			printf("\n\t T5GroupIDCreVali-->DML Revision from Task for MR tsktodmlrelcount : [%d]",tsktodmlrelcount);fflush(stdout);

			for (s=0;s<tsktodmlrelcount ;s++ )
			{
				DMLReviTag = DMLRev[s];
				CALLAPI(POM_class_of_instance(DMLReviTag,&DMLRevclass_id));
				CALLAPI(POM_name_of_class(DMLRevclass_id,&DMLClassname));
				printf("\n\t T5GroupIDCreVali-->DMLClassname :%s",DMLClassname);fflush(stdout);
				if(tc_strcmp(DMLClassname,"ChangeRequestRevision")==0)
				{
					CALLAPI(ITEM_rev_sequence_is_latest(DMLReviTag,&islatest));
					printf("\n\t T5GroupIDCreVali-->islatest= %d ",islatest);fflush(stdout);

					if(islatest != true)
					{
						printf("\n\t T5GroupIDCreVali-->islatest is not true .....");fflush(stdout);
					}
					else
					{
						CALLAPI(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&sDMLtyp));
						CALLAPI(AOM_ask_value_string(DMLReviTag,"item_id",&sDMLno));
						printf("\n\t T5GroupIDCreVali-->DMLtype is %s sDMLno:%s",sDMLtyp,sDMLno);fflush(stdout);
						if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&yDmlDR)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLReviTag,"t5_cprojectcode",&yDML_project)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(DMLReviTag,"t5_TargetPlant",&ysDml_TP)!=ITK_ok)PrintErrorStack();
						CALLAPI(AOM_UIF_ask_value(DMLReviTag,"release_status_list",&DMLrlsts));
						printf("\n\t T5GroupIDCreVali-->sDMLno :[%s], sDMLtyp:[%s],yDmlDR:[%s],yDML_project:[%s],ysDml_TP:[%s],\n DMLrlsts:[%s],",sDMLno,sDMLtyp,yDmlDR,yDML_project,ysDml_TP,DMLrlsts);fflush(stdout);

						if(tc_strcmp(sDMLtyp,"GIR")==0 || tc_strcmp(sDMLtyp,"IFR")==0)
						{
							if ((strcmp(type_name,"T5_ChangeTaskRevision")==0)||(strcmp(type_name,"ChangeRequestRevision")==0))
							{
								if (primary_object)
								{
									printf("\n\t T5GroupIDCreVali..for relation:%s",name_relation);fflush(stdout);
									if(tc_strstr(DRinfo2,"ADDGID") == NULL)
									{
										printf(" checking relation CMHasSolutionItem");fflush(stdout);
										if ((strcmp(name_relation,"CMHasSolutionItem")==0) && (strcmp(type_name,"T5_ChangeTaskRevision")==0))
										{
											printf("\nT5GroupIDCreVali: inside CMHasSolutionItem.");fflush(stdout);
											if(EPM_get_current_job(primary_object,&taskjob,&task_job_type)!=ITK_ok)PrintErrorStack();
											if (taskjob != NULLTAG)
											{
												if(EPM_ask_root_task(taskjob,&roottask)!=ITK_ok)PrintErrorStack();
												if(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks)!=ITK_ok)PrintErrorStack();
												if(AOM_UIF_ask_value(roottask,"object_name",&nameofroot)!=ITK_ok)PrintErrorStack();
												printf("\n\nT5GroupIDCreVali: inside roottask [%s] \n",nameofroot);fflush(stdout);
												
												if (taskcount>0)
												{
													printf("\n T5GroupIDCreVali:taskcount is  [%d]\n",taskcount);fflush(stdout);
													for(j=0;j<taskcount;j++)
													{
														if(AOM_UIF_ask_value(subtasks[j],"task_state",&taskstatus)!=ITK_ok)PrintErrorStack();
														printf("\n T5GroupIDCreVali:taskstatus is  [%s] \n",taskstatus);fflush(stdout);
														if (tc_strstr(taskstatus,"Started")!=NULL)
														{
															if(AOM_ask_value_string (subtasks[j],"task_type",&SubSubtaskType)!=ITK_ok)PrintErrorStack();
															printf("\n T5GroupIDCreVali:Sub-Sub Task Type.:[%s] ",SubSubtaskType);fflush(stdout);

															CALLAPI(AOM_ask_value_string(secondary_object,"item_id",&Part_no));
															CALLAPI(AOM_ask_value_string(secondary_object,"item_revision_id",&part_revid));
															CALLAPI(AOM_ask_value_string(secondary_object,"t5_PartType",&sPart_tpe));
															if(AOM_UIF_ask_value(secondary_object, "release_status_list", &xrel_status)!=ITK_ok)PrintErrorStack();
															if(AOM_ask_value_string(secondary_object,"t5_PartStatus",&xPrtDRst)!=ITK_ok)PrintErrorStack();
															if( AOM_ask_value_string(secondary_object,"t5_ProjectCode",&xParentProj)==ITK_ok)  PrintErrorStack();

															printf("\n\t T5GroupIDCreVali-->Part_no :[%s], part_revid:[%s],sPart_tpe:[%s],xPrtDRst:[%s],xParentProj:[%s],\n xrel_status:[%s],",Part_no,part_revid,sPart_tpe,xPrtDRst,xParentProj,xrel_status);fflush(stdout);
															printf("\n T5GroupIDCreVali-->Part number: %s",Part_no);	fflush(stdout);

															RelTypeCat= MEM_alloc(100);
															tc_strcpy(RelTypeCat,"");
															tc_strcpy(RelTypeCat,",");
															tc_strcat(RelTypeCat,sPart_tpe);
															tc_strcat(RelTypeCat,",");
															printf("\n T5GroupIDCreVali-:RelTypeCat.:%s \n",RelTypeCat);fflush(stdout);
															//
															if(tc_strcmp(sDMLtyp,"GIR")==0)
															{
																if(tc_strstr(DRinfo1,"PS004") == NULL)
																{
																	if (tc_strstr(DMLrlsts,"ERC Released")!=NULL ||tc_strstr(DMLrlsts,"T5_LcsErcRlzd")!=NULL || tc_strstr(xrel_status,"ERC Released")!=NULL || tc_strcmp(xrel_status,"ERC Released")== 0 || tc_strstr(xrel_status,"T5_LcsErcRlzd")!=NULL || tc_strcmp(xrel_status,"T5_LcsErcRlzd")== 0)
																	{
																		printf("\n T5GroupIDCreVali-->Part is not allowed to attach under ERC Released DML ");fflush(stdout);
																		EMH_clear_errors(); 
																		EMH_store_error_s1(EMH_severity_error,ITK_err," DML is ERC Released or Part is ERC Released is not allowed to attach kindly take new DML and Proceed.");
																		return ITK_err;
																	}
																}
																if(tc_strstr(DRinfo1,"PS003") == NULL)
																{
																	CALLAPI(ITEM_ask_item_of_rev(secondary_object, &Itemtag));
																	printf("\n T5GroupIDCreVali--> ITEM_Found......");fflush(stdout);

																	CALLAPI(ITEM_ask_latest_rev(Itemtag,&latestrev));
																	if( AOM_ask_value_string(secondary_object,"object_string",&selectedname)==ITK_ok)
																	printf("\n T5GroupIDCreVali-->selected revision---------------> %s\n",selectedname);fflush(stdout);

																	if (latestrev!=NULLTAG)
																	{
																		if( AOM_ask_value_string(latestrev,"object_string",&curentname)==ITK_ok)
																		printf("\n T5GroupIDCreVali-->latest revision---------------> %s\n",curentname);fflush(stdout);
																	}

																	if(tc_strcmp(curentname,selectedname)!=0)
																	{
																		printf("\n T5GroupIDCreVali-->Latest part is only allowed to release");fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_err,"Latest Part Revision of Group ID and Assembly is allowed to Attach to the Group ID Release DML.");
																		return ITK_err;
																	}
																}
																if(tc_strstr(DRinfo1,"PS002") == NULL)
																{
																	if (tc_strcmp(yDML_project,xParentProj)!=0)
																	{
																		printf("\n T5GroupIDCreVali-->Part and ERC DML Project Code should be same");fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_err,"Part and ERC DML Project Code should be same.");
																		return ITK_err;
																	}
																}
																//CHECK dml TYPE: IF GM DML
																if(tc_strstr(DRinfo1,"PS001") == NULL)
																{
																	if(tc_strcmp(SubSubtaskType,"EPMDoTask")==0)
																	{
																		if(AOM_UIF_ask_value(subtasks[j],"object_name",&taskTempLT)!=ITK_ok)PrintErrorStack();
																		printf("\n Assignment Name is  %s \n",taskTempLT);fflush(stdout);
																		if(tc_strcmp(taskTempLT,"Add Items For Release")==0)
																		{
																			printf("\n Current Assignment Name is  [%s],user allowed to attach the Group ID parts to the DML. \n",taskTempLT);fflush(stdout);

																			if(tc_strcmp(sPart_tpe,"G")==0)
																			{	
																				if(tc_strstr(part_revid,"NR")!= NULL)
																				{
																					printf("\n T5GroupIDCreVali-->NR revision of Part Type Group ID is not allowed to attach Group ID Release DML.");fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,ITK_err,"NR-WIP Group ID is not allowed to attach Group ID Release DML. Kindly release it with Module Release DML");
																					return ITK_err;
																				}
																				else
																				{
																					printf("\n Inside the Group ID non NR non Release loop");
																					
																					if(GRM_find_relation_type("IMAN_specification", &ImanSpec)!=ITK_ok)PrintErrorStack();
																					if (ImanSpec!=NULLTAG)
																					{
																						printf("\n T5GroupIDCreVali:OK for ImanSpec.");fflush(stdout);
																						CADdataset = 0;
																						CALLAPI(GRM_list_secondary_objects_only(secondary_object,ImanSpec,&Speccount,&SpecDoc_tag));
																						printf("\n T5GroupIDCreVali Specification count Value :------->>>>  %d\n",Speccount);fflush(stdout);
																						if(Speccount > 0)
																						for (is=0;is<Speccount;is++ )
																						{
																							SecObjDSTag = SpecDoc_tag[is];

																							if(TCTYPE_ask_object_type(SecObjDSTag,&SpecTypeTag));
																							if(TCTYPE_ask_name2(SpecTypeTag,&Spectype_name));
																							printf("\nT5GroupIDCreVali RefDoc_tag  Spectype_name :: %s\n", Spectype_name);fflush(stdout);

																							if(tc_strstr(DRinfo3,Spectype_name)!= NULL)
																							{
																								CADdataset++;
																							}
																						}
																						printf("\nT5GroupIDCreVali CADdataset count is :: %d\n", CADdataset);fflush(stdout);
																						if(CADdataset == 0 && tc_strstr(DRinfo1,"Dataset") == NULL)
																						{
																							printf("\nT5GroupIDCreVali: CAD dataset is not attached to the Group ID Part");fflush(stdout);
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR: CAD dataset should be attached to the Group ID Part under Specifications Relation");
																							return ITK_err;
																						}
																					}
																				}
																			}											
																			//Assembly part type or Module Attachment Validation
																			//Assembly,Module
																			else if(tc_strstr(DRinfo2,RelTypeCat)!= NULL)
																			{
																				if(tc_strstr(part_revid,"NR")!= NULL)
																				{
																					printf("\n T5GroupIDCreVali-->NR revision of Part  is not allowed to attch Group ID Release DML.");fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,ITK_err,"NR-WIP part is not allowed to attch Group ID Release DML. Kindly release it with Module Release DML");
																					return ITK_err;
																				}
																				printf("\n T5GroupIDCreVali-:%s \n",RelTypeCat);fflush(stdout);
																				if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																				if(CFM_find( "ERC Review And Above", &p_rule )!=ITK_ok)PrintErrorStack();
																				if(BOM_set_window_config_rule( p_window, p_rule )!=ITK_ok)PrintErrorStack();
																				if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																				if(BOM_set_window_top_line (p_window, NULLTAG, secondary_object, NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();

																				if(tc_strstr(DRinfo2,"BEZ")==NULL)
																				{
																					printf ("\nT5GroupIDCreVali: TMLBOMExpandByQty apply.. \n");fflush(stdout);
																					if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefounddd, &POclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																				else
																				{
																					printf ("\nT5GroupIDCreVali: BOMLineSkipZeroQtyMaskUnconfig apply.. \n");fflush(stdout);
																					if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefounddd, &POclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																				printf ("\nT5GroupIDCreVali:rulefounddd count %d \n",rulefounddd);fflush(stdout);
																				if (rulefounddd > 0)
																				{
																					POclose_taggg = POclosureruleee[0];
																					printf ("\nT5GroupIDCreVali: closure rule found \n");fflush(stdout);
																				}
																				if(BOM_window_set_closure_rule( p_window,POclose_taggg, 0, POrulenameXO,POrulevalueXO )!=ITK_ok)   PrintErrorStack();
																				//0qty

																				if(BOM_line_ask_child_lines (p_top_line, &ChildCunt, &Childobject));
																				printf("\n T5GroupIDCreVali:No of child objects are ChildCunt : %d\n",ChildCunt);fflush(stdout);
																				iChild=0;
																				if (ChildCunt == 0)
																				{
																					if(tc_strstr(DRinfo1,"PS007") == NULL)
																					{
																						printf("\n T5GroupIDCreVali-->Part has no structure, It is not allowed to attach");fflush(stdout);
																						EMH_clear_errors();
																						EMH_store_error_s1(EMH_severity_error,ITK_err,"NR-WIP part is not allowed to attch Group ID Release DML. Kindly release it with Module Release DML");
																						return ITK_err;
																					}
																				}
																				else
																				{
																					for(iChild =0 ; iChild < ChildCunt; iChild++)
																					{
																						GrpChildPass=0;
																						p_child_item_id=NULL;
																						rel_sstats=NULL;
																						Obj_PrtTyp=NULL;
																						rev_iidd=NULL;
																						PrtDRstus=NULL;
																						PrtProjj=NULL;

																						if(AOM_ask_value_string(Childobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(Childobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																						printf("\nT5GroupIDCreVali: p_child_item_id:[%s] Rel Status:[%s]", p_child_item_id,rel_sstats);fflush(stdout);
																						//If child is NR WIP, it should be in same DML.
																						if((tc_strstr(rel_sstats,"Released")==NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")==NULL)||(tc_strstr(rel_sstats,"APL")==NULL)||(tc_strstr(rel_sstats,"STDSI")==NULL))
																						{
																							if(AOM_ask_value_string(Childobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(Childobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(Childobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																							if(AOM_ask_value_string(Childobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																							printf("\n T5GroupIDCreVali: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);
																							if(tc_strcmp(Obj_PrtTyp,"G")==0)
																							{
																								groupIDfnd = 1;
																								dChildvALIPass = 0;
																								DumItmTag= t5GetItemRevison(p_child_item_id);
																								if(DumItmTag==NULLTAG)
																								{
																									printf("\n T5GroupIDCreVali:DumItmTag is NULL.\n");fflush(stdout);
																								}
																								if(GRM_find_relation_type("CMHasSolutionItem", &DMYpart_tsk_rel_typ)!=ITK_ok)PrintErrorStack();
																								if (DMYpart_tsk_rel_typ!=NULLTAG)
																								{
																									printf("\n DMY::OK for DMYpart_tsk_rel_typ.");fflush(stdout);
																								}
																								if(ITEM_ask_latest_rev(DumItmTag, &DumRevtag)!=ITK_ok)PrintErrorStack();
																								printf("\n T5GroupIDCreVali:Part type is dummy and rev is NR");fflush(stdout);
																								if(GRM_list_primary_objects_only(DumRevtag,DMYpart_tsk_rel_typ,&D_TskCnt,&DTskObj)!=ITK_ok)PrintErrorStack();
																								printf("\n T5GroupIDCreVali::Task Count :-------------------->>>>  %d\n",D_TskCnt);fflush(stdout);

																								if (D_TskCnt > 0)
																								{
																									for (qq =0 ; qq < D_TskCnt; qq++ )
																									{
																										if( AOM_ask_value_string(DTskObj[qq],"item_id",&zTasknum)==ITK_ok)
																										printf("\n T5GroupIDCreVali: sDMLno [%s] and Task name zTasknum[ %s].\n",sDMLno,zTasknum); fflush(stdout);
																										if(tc_strstr(zTasknum,sDMLno)!=NULL)
																										{
																											printf("\n T5GroupIDCreVali:attached in same DML OKKK..");fflush(stdout);
																											dChildvALIPass=1;
																											//Group id having one child part clear.
																											break;
																										}
																									}
																								}
																								if(dChildvALIPass == 0)
																								{
																									printf("\n DMY::ERRORRRR.ERC Review Group ID :[%s] should be attached to same DML for release", p_child_item_id);fflush(stdout);
																									EMH_clear_errors();
																									EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR: Bellow ERC Review Group ID part Should be attached to the same DML- ",p_child_item_id);
																									return ITK_err;
																								}
																							}
																						}
																					}
																					if (groupIDfnd == 0)
																					{
																						if(tc_strstr(DRinfo1,"PS006") == NULL)
																						{
																							printf("\n T5GroupIDCreVali:No Group ID [non Released] part found under Assembly/Module %d\n",Part_no);fflush(stdout);
																							EMH_clear_errors();
																							EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR01:Assembly/Module has no Group ID present in its structre, So Release part with Module Release DML:",Part_no);
																							decision = EPM_nogo;
																							return decision;
																						}
																					}
																				}
																			}
																			else
																			{
																				if(tc_strstr(DRinfo1,"PS005") == NULL)
																				{
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR01:For Group ID Release DML, bellow part type is not allowed to attach:",sPart_tpe);
																					decision = EPM_nogo;
																					return decision;
																				}
																			}
																		}
																		else
																		{
																			printf("\n:Error: Part of type [%s] is not allowed to attach th the Group ID Release DML.",sPart_tpe);fflush(stdout);
																			if(tc_strcmp(Sesusername,"infodba") !=0 && tc_strcmp(Sesusername,"loader") !=0)
																			{
																				EMH_clear_errors();
																				EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR01:Part can be attach to Solutions relation at 'Add Items For Release' assignment of Task for Group ID Release DML:",sPart_tpe);
																				decision = EPM_nogo;
																				return decision;
																			}
																		}
																	}
																}
															}
															//
															if(tc_strcmp(sDMLtyp,"IFR")==0)
															{
																if(tc_strstr(DRinfo4,"PS001") == NULL)
																{
																	if (tc_strstr(DMLrlsts,"ERC Released")!=NULL ||tc_strstr(DMLrlsts,"T5_LcsErcRlzd")!=NULL || tc_strstr(xrel_status,"ERC Released")!=NULL || tc_strcmp(xrel_status,"ERC Released")== 0 || tc_strstr(xrel_status,"T5_LcsErcRlzd")!=NULL || tc_strcmp(xrel_status,"T5_LcsErcRlzd")== 0)
																	{
																		printf("\n IFD Release-->Part is not allowed to attach under ERC Released DML ");fflush(stdout);
																		EMH_clear_errors(); 
																		EMH_store_error_s1(EMH_severity_error,ITK_err,"IFD: DML is ERC Released or Part is ERC Released is not allowed to attach kindly take new DML and Proceed.");
																		return ITK_err;
																	}
																}
																if(tc_strstr(DRinfo4,"PS002") == NULL)
																{
																	CALLAPI(ITEM_ask_item_of_rev(secondary_object, &Itemtag));
																	printf("\n IFD Release--> ITEM_Found......");fflush(stdout);

																	CALLAPI(ITEM_ask_latest_rev(Itemtag,&latestrev));
																	if( AOM_ask_value_string(secondary_object,"object_string",&selectedname)==ITK_ok)
																	printf("\n IFD Release-->selected revision---------------> %s\n",selectedname);fflush(stdout);

																	if (latestrev!=NULLTAG)
																	{
																		if( AOM_ask_value_string(latestrev,"object_string",&curentname)==ITK_ok)
																		printf("\n IFD Release-->latest revision---------------> %s\n",curentname);fflush(stdout);
																	}

																	if(tc_strcmp(curentname,selectedname)!=0)
																	{
																		printf("\n IFD Release-->Latest part is only allowed to release");fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_err,"Latest Part Revision of IFD Part and Dummy Part is allowed to Attach to the IFD Release DML.");
																		return ITK_err;
																	}
																}
																if(tc_strstr(DRinfo4,"PS003") == NULL)
																{
																	if(tc_strcmp(SubSubtaskType,"EPMDoTask")==0)
																	{
																		if(AOM_UIF_ask_value(subtasks[j],"object_name",&taskTempLT)!=ITK_ok)PrintErrorStack();
																		printf("\n IFD Release-->Assignment Name is  [%s] \n",taskTempLT);fflush(stdout);
																		if(tc_strcmp(taskTempLT,"Add IFD For Release")==0)
																		{
																			printf("\n IFD Release-->Current Assignment Name is [%s], user allowed to attach the IFD parts to the DML. \n",taskTempLT);fflush(stdout);

																			if(tc_strstr(DRinfo5,sPart_tpe) != NULL)
																			{	
																				printf("\n IFD Release-->sPart_tpe [%s] & part_revid [%s]\n",sPart_tpe,part_revid);fflush(stdout);

																				if(tc_strstr(part_revid,"NR")!= NULL)
																				{
																					printf("\n IFD Release-->NR revision of Part Type IFD is not allowed to attach IFD Release DML.");fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,ITK_err,"NR-WIP IFD Part is not allowed to attach IFD Release DML. Kindly release it with Module Release DML");
																					return ITK_err;
																				}
																				else
																				{
																					printf("\n Inside the IFD non NR non Release loop");
																					
																					if(GRM_find_relation_type("IMAN_specification", &ImanSpec)!=ITK_ok)PrintErrorStack();
																					if (ImanSpec!=NULLTAG)
																					{
																						printf("\n IFD Release-->OK for ImanSpec.");fflush(stdout);
																						CADdataset = 0;
																						CALLAPI(GRM_list_secondary_objects_only(secondary_object,ImanSpec,&Speccount,&SpecDoc_tag));
																						printf("\n IFD Release--> Specification count Value :------->>>>  %d\n",Speccount);fflush(stdout);
																						if(Speccount > 0)
																						for (is=0;is<Speccount;is++ )
																						{
																							SecObjDSTag = SpecDoc_tag[is];

																							if(TCTYPE_ask_object_type(SecObjDSTag,&SpecTypeTag));
																							if(TCTYPE_ask_name2(SpecTypeTag,&Spectype_name));
																							printf("\nIFD Release--> RefDoc_tag  Spectype_name :: %s\n", Spectype_name);fflush(stdout);

																							if(tc_strstr(DRinfo4,Spectype_name)!= NULL)
																							{
																								CADdataset++;
																							}
																						}
																						printf("\nIFD Release--> CADdataset count is :: %d\n", CADdataset);fflush(stdout);
																						if(CADdataset == 0 && tc_strstr(DRinfo4,"Dataset") == NULL)
																						{
																							printf("\nIFD Release-->: CAD dataset is not attached to the Group ID Part");fflush(stdout);
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR: CAD dataset should be attached to the IFD Part under Specifications Relation");
																							return ITK_err;
																						}
																					}
																				}
																			}											
																			else
																			{
																				printf("\n IFD Release-->Inside Else loop of Part type check. \n");fflush(stdout);
																				if(tc_strstr(DRinfo4,"PS004") == NULL)
																				{
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR01:For IFD Release DML, bellow part type is not allowed to attach:",sPart_tpe);
																					decision = EPM_nogo;
																					return decision;
																				}
																			}
																		}
																		else
																		{
																			printf("\n:Error: Part can be attach to Solutions relation at 'Add IFD For Release' assignment of Task for IFD Release DML:[%s]",taskTempLT);fflush(stdout);
																			if(tc_strcmp(Sesusername,"infodba") !=0 && tc_strcmp(Sesusername,"loader") !=0)
																			{
																				EMH_clear_errors();
																				EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR01:Part can be attach to Solutions relation at 'Add IFD For Release' assignment of Task for IFD Release DML:",sPart_tpe);
																				decision = EPM_nogo;
																				return decision;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										else
										{
											printf("\n: Error1: Part cannot be attach to other than Solutions relation for Group ID Release DML.");fflush(stdout);
											if(tc_strcmp(Sesusername,"infodba") !=0 && tc_strcmp(Sesusername,"loader") !=0)
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR01:Part can not be attach to any other relation other than Solutions relation of DML Task for Group ID Release DML.");
												decision = EPM_nogo;
												return decision;
											}
										}
									}
								}
								else
								{
									printf("\n T5GroupIDCreVali: primary_object tag not found.\n");fflush(stdout);
								}	
							}
						}
						else
						{
							printf("\n Current DML is not of type Group ID Release. Skipping....\n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_GroupIDCreVali Function end...");fflush(stdout);
	TC_write_syslog("\n tm_GroupIDCreVali Function end...");
    //return ifail;
	return 0;
}