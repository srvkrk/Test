/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   tm_CTED_Submit_On_Create.c
*  Author		 :   Sagar Baviskar
*  Module		 :   ITK Post Action code to submit CTED Tool intimation Revision in Workflow immediately after creation.
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes

***************************************************************************/

 #include <stdio.h>
 #include <tc/tc.h>
 #include <tccore/custom.h>
 #include <ae/dataset.h>
 #include <epm/epm.h>
 #include <epm/epm_task_template_itk.h>
 #include <epm/releasestatus.h>
 #include <ict/ict_userservice.h>
 //#include <method.h>
 #include <property/prop.h>
 #include <property/prop_errors.h>
 #include <property/prop_msg.h>
 #include <res/reservation.h>
 #include <stdarg.h>
 #include <string.h>
 #include <tc/emh_const.h>
 #include <tc/envelope.h>
 #include <tc/emh.h>
 #include <tccore/aom.h>
 #include <tccore/aom_prop.h>
 #include <tccore/custom.h>
 #include <tccore/item.h>
 #include <tccore/item_errors.h>
 #include <tccore/item_msg.h>
 #include <tccore/method.h>
 #include <tccore/tctype.h>
 #include <tccore/workspaceobject.h>
 #include <sa/tcfile.h>
 //#include <tctype.h>
 //#include <item_errors.h>
 #include <user_exits/user_exits.h>
 //#include <workspaceobject.h>
 //#include <project.h>
 
static int PrintErrorStack( void )
{

 int iNumErrs = 0;
 const int *pSevLst = NULL;
 const int *pErrCdeLst = NULL;
 const char **pMsgLst = NULL;
 register int i = 0;
 
 EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
 fprintf( stderr, "Error(s): \n");
 for ( i = 0; i < iNumErrs; i++ )
 {
 fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
 }
 return ITK_ok;
}

 extern int DLLAPI tm_CTED_Submit_On_Create(METHOD_message_t *m, va_list args)
	{
		const char* item_id;
		const char* item_name;
		const char* type_name;
		const char* rev_id;
		tag_t* new_item_tag;
		tag_t* new_rev_tag;
		tag_t item_master_form_tag;
		tag_t item_rev_master_form_tag;
		tag_t tagItem=NULLTAG;
		tag_t tagItemRev=NULLTAG;
		tag_t objTypeTag;
		tag_t projobj;
		char *ObjProject = NULL;
		char* itemTagString=NULL;
		char* itemRevTagString=NULL;
		char type_name1[TCTYPE_name_size_c+1];
		
		
		item_id = va_arg(args, const char*);
		item_name = va_arg(args, const char*);
		type_name = va_arg(args, const char*);
		rev_id = va_arg(args, const char*);
		new_item_tag = va_arg(args, tag_t *);
		new_rev_tag = va_arg(args, tag_t *);
		item_master_form_tag = va_arg(args, tag_t);
		item_rev_master_form_tag= va_arg(args, tag_t);
		tagItem=*new_item_tag;
		tagItemRev=*new_rev_tag; 
		
        tag_t WF_template_tag = NULLTAG;
		tag_t new_process = NULLTAG;
		int attachment_types = 1;

		printf("\n In tm_CTED_Submit_On_Create... \n");fflush(stdout);
		//Find the object type tag for input tagItemRev
		if(TCTYPE_ask_object_type(tagItemRev,&objTypeTag)!=ITK_ok)PrintErrorStack(); 
		if(TCTYPE_ask_name(objTypeTag,type_name1)!=ITK_ok)PrintErrorStack();
		printf("\n Object Type(type_name1) = %s\n", type_name1);fflush(stdout);
		
		if(tc_strcmp(type_name1,"T5_CTEDRevision")==0)
		{
			if(EPM_find_template2("T5_CTED_Workflow",0,&WF_template_tag)!=ITK_ok)PrintErrorStack();
			if (WF_template_tag!=NULLTAG)
			{
				printf("\n Workflow Template Found\n");fflush(stdout);
				printf("\n Submitting CTED Tool Intimation Revision to workflow...\n");fflush(stdout);
				if(EPM_create_process("CTED Workflow Process","",WF_template_tag,1, &tagItemRev,&attachment_types,&new_process))PrintErrorStack();
				printf("\n Submitted CTED Tool Intimation Revision to workflow \n");fflush(stdout);
			}
			else
			{
				printf("\n Workflow Template Not Found\n");fflush(stdout);
			}
			
		}
		else
		{
			printf("\n Object Type match not found \n");fflush(stdout);
		}
		
		return ITK_ok;
	}

extern int tm_CTED_Submit_On_Create_register_method(int *decision, va_list args)
	{
		METHOD_id_t method;
		*decision = ALL_CUSTOMIZATIONS;
		printf("\n In tm_CTED_Submit_On_Create_register_method... \n");fflush(stdout);
		//Find the method to which we extend to add post action
		if ( METHOD_find_method("T5_CTED", ITEM_create_msg, &method) !=ITK_ok)PrintErrorStack();
		
		if (method.id != NULLTAG)
		{
			//Register the method to be called on post action of ITEM_create_msg
			if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) tm_CTED_Submit_On_Create, NULL)!=ITK_ok)
			PrintErrorStack();
			printf("Registered as Post-Action on Creation of CTED Item\n");fflush(stdout);
		}
		else
		{
			printf("Method not found!\n");fflush(stdout);
		}
		
		return ITK_ok;
	} 
		
		//Function get loaded when TC_Customization_Libraries preference are loaded by teamcenter
		//This library must be added in TC_Customization_Libraries preference as tm_CTED_Submit_On_Create
extern DLLAPI int tm_CTED_Submit_On_Create_register_callbacks()
	{
		printf("\n In tm_CTED_Submit_On_Create_register_callbacks... \n");fflush(stdout);
		//Once this function get loaded Submit_to_workflow_register_method will be called
		if(CUSTOM_register_exit ( "tm_CTED_Submit_On_Create", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_CTED_Submit_On_Create_register_method) !=ITK_ok)PrintErrorStack();
		
		return ( ITK_ok );
    }

// compile tm_CTED_Submit_On_Create.c
// link_custom_exits tm_CTED_Submit_On_Create
// cp /user/tcuaadev/devgroups/sagar/CTED_PostAction/tm_CTED_Submit_On_Create.so /user/tcuaadev/TC_ROOT/lib