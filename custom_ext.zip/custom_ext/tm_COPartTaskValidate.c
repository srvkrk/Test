#include "TMLLibrary_server_exits.h"

int tm_COPartTaskValidate(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int p					= 0;
	int k					= 0;
	int fld					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int	taskflag            = 0;
	int	count               = 0;
	int	prtcnt              = 0;
	int	Tskcount            = 0;
	int	FlderSize           = 0;
	int	FlderObjCount       = 0;
	int partFlag			= 0;
	int FolderFlag			= 0;
	int error_code			= ITK_ok;
	tag_t  roottask			= NULLTAG;
	tag_t  objTypTag        = NULLTAG;
	tag_t  DMLRevTg         = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLRevTag        = NULLTAG;
	tag_t  DMLTaskTag       = NULLTAG;
	tag_t  query            = NULLTAG;
	tag_t  TskTags1         = NULLTAG;
	char *dmlTaskNo         = NULL;
	char *DMLtype           = NULL;
	char *sDMLno            = NULL;
	char *DMLprirty         = NULL;
	char *sCOInfo1          = NULL;
	char *sCOInfo2          = NULL;
	char *sCOInfo3          = NULL;
	char *sCOInfo4          = NULL;
	char *item_id           = NULL;
	char *Prt_object_type   = NULL;
	char * PartMstr_no	    = NULL;
	char * Prtrev_idd	    = NULL;
	char * Prtrel_status    = NULL;
	char * des_group	    = NULL;
	char * FldrName	        = NULL;
	char * objTypeofTask	        = NULL;
	char * Tsk_object_type	        = NULL;
	tag_t  *DMLRevision     = NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  *TskTags	        = NULLTAG;
	tag_t  *PrtsTag	        = NULLTAG;
	tag_t  *FolderObj_tag	        = NULLTAG;
	tag_t  *contrlObjs	        = NULLTAG;

	char	ObjTyp[TCTYPE_name_size_c+1];

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));

	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	logical is_latest;

	//EPM_decision_t decision = EPM_go;
    printf("\n tm_COPartTaskValidate Function started...");fflush(stdout);
	TC_write_syslog("\n tm_COPartTaskValidate Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_COPartTaskValidate:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_COPartTaskValidate:INSIDE Attachments.");fflush(stdout);
			//DMLtsk_tag=taskAttachments[i];

			DMLRevTag=taskAttachments[i];

			printf("\n tm_COPartTaskValidate:INSIDE not null tag.");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="COTASKVAli";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_COPartTaskValidate Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sCOInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sCOInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sCOInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sCOInfo4));
					printf("\n L1:sCOInfo1 is : [%s]  L2:sCOInfo2 is : [%s]  L3:sCOInfo3 is : [%s] L4:sCOInfo4 is : [%s]\n",sCOInfo1,sCOInfo2,sCOInfo3,sCOInfo4);fflush(stdout);

					if(tc_strstr(sCOInfo1,"CO1") != NULL)
					{
					  return 1;
					}
					if(tc_strstr(sCOInfo1,"CO3") != NULL)
					{
					  return 0;
					}
					if(tc_strstr(sCOInfo1,"CO2") == NULL)
					{
						//ITK_CALL(ITEM_ask_latest_rev(DMLtsk_tag,&DMLtaskRevTag));
						//printf("\n DML task tag is not null ");

						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_COPartTaskValidate objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n tm_COPartTaskValidate object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&item_id));
						    printf("\n tm_COPartTaskValidate item_id is %s\n", item_id);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_COPartTaskValidate--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n tm_COPartTaskValidate--is_latest is not true .....\n");fflush(stdout);
							}
							else
				            {
								ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
								printf("\n tm_COPartTaskValidate 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

								for(p=0;p<Tskcount;p++)
								{
									TskTags1=TskTags[p];
									if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
									printf("\n tm_COPartTaskValidate :Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

									if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
										ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
										printf("\n tm_COPartTaskValidate item_id is = %s \n",item_id);fflush(stdout);

										if (tc_strstr(item_id,"_CO")!=NULL)
										{
											if(AOM_ask_value_tags(TskTags1,"CMReferences",&prtcnt,&PrtsTag));
										    printf("\n tm_COPartTaskValidate:Now prtcnt:%d.",prtcnt);fflush(stdout);

											if (prtcnt>0)
											{
												for (k=0; k<prtcnt; k++)
												{
													
													printf("\n tm_COPartTaskValidate :Design k:%d",k);fflush(stdout);
													if(AOM_UIF_ask_value(PrtsTag[k],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
													printf("\n tm_COPartTaskValidate :Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
													/*if(strcmp(Prt_object_type,"Folder")!=0)
													{


														// put condition for design rev, to avoid other attachments.
														if(AOM_ask_value_string(PrtsTag[k],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(PrtsTag[k], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(PrtsTag[k], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(PrtsTag[k], "t5_DesignGrp", &des_group)!=ITK_ok)PrintErrorStack();
														printf("\n tm_COPartTaskValidate:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s des_group:%s", PartMstr_no,Prtrev_idd,Prtrel_status,des_group);fflush(stdout);

														partFlag=1;
														printf("\n tm_COPartTaskValidate :partFlag :%d\n",partFlag);fflush(stdout);

														break;

													}*/
													//else
													//{

														printf("\n tm_COPartTaskValidate: Expanssion for Folder.");fflush(stdout);
														if(AOM_ask_value_string(PrtsTag[k],"object_name",&FldrName)!=ITK_ok)PrintErrorStack();
														printf("\n tm_COPartTaskValidate:FldrName:: %s\n", FldrName);fflush(stdout);
														
														printf("\n tm_COPartTaskValidate: getting parts.\n");fflush(stdout);
														if(FL_ask_size(PrtsTag[k],&FlderSize));
														printf("\n tm_COPartTaskValidate:FlderSize is:   %d\n",FlderSize);fflush(stdout);
														if(FL_ask_references(PrtsTag[k],FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag));
														printf("\n tm_COPartTaskValidate:FlderObjCount is..:   %d\n",FlderObjCount);fflush(stdout);
														if(FlderObjCount>0)
														{
															fld=0;
															for (fld=0;fld<FlderObjCount;fld++)
															{
																FolderFlag=1;
																printf("\n tm_COPartTaskValidate :FolderFlag :%d\n",FolderFlag);fflush(stdout);



																if(AOM_ask_value_string(FolderObj_tag[fld],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "t5_DesignGrp", &des_group)!=ITK_ok)PrintErrorStack();
																printf("\n tm_COPartTaskValidate:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s des_group:%s", PartMstr_no,Prtrev_idd,Prtrel_status,des_group);fflush(stdout);

																break;


															}
														}
														
													//}
												}
												if ((partFlag>0)||(FolderFlag>0))
												{
													return 0;
												}
												else
												{
													return 1;
												}
											}
										}
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_COPartTaskValidate Control objects :Off");fflush(stdout);
						return 1;
					}
				}
			}
		}
	}
	printf("\n tm_COPartTaskValidate Function end...");fflush(stdout);
	TC_write_syslog("\n tm_COPartTaskValidate Function end...");

	return 1;
}

