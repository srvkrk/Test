/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int EPATrnfValInvalPrtUpdServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	
	char		*newEPANo= NULL;
	char		*oldEPANo= NULL;
	char		*epaValidPartList= NULL;
	char		*epaValidPartListforRmv= NULL;
	char		*epavalidPrtSize= NULL;
	char		*epaInValidPartList= NULL;
	char		*epaInValidPartListforRmv= NULL;
	char		*epaInvalidPrtSize= NULL;
	char		*validRowData= NULL;
	char		*validRowDataRm= NULL;
	char		*invalidRowDataRm= NULL;
	char		*fectinValidRowData_prtRemv= NULL;
	char		*invalidRowData= NULL;
	char		*srno_ValPrt= NULL;
	char		*PrtType_ValPrt= NULL;
	char		*PrtNo_ValPrt= NULL;
	char		*PrtDesc_ValPrt= NULL;
	char		*PrtRevSeq_ValPrt= NULL;
	char		*PrtCS_ValPrt= NULL;
	char		*PrtChgeType_ValPrt= NULL;
	char		*PrtOldQty_ValPrt= NULL;
	char		*PrtRev= NULL;
	char		*PrtSeq= NULL;
	char		*srno_InValPrt= NULL;
	char		*PrtType_InValPrt= NULL;
	char		*PrtNo_InValPrt= NULL;
	char		*PrtDesc_InValPrt= NULL;
	char		*PrtRevSeq_InValPrt= NULL;
	char		*PrtCS_InValPrt= NULL;
	char		*PrtChgeType_InValPrt= NULL;
	char		*PrtOldQty_InValPrt= NULL;
	char		*PrtRev1= NULL;
	char		*PrtSeq1= NULL;
	char		*fectinvalidRowData= NULL;
	char		*fectValidRowData= NULL;
	char		*fectValidRowData_prtRemv= NULL;
	char		*srno_ValPrt_prtRemv= NULL;
	char		*PrtType_ValPrt_prtRemv= NULL;
	char		*PrtNo_ValPrt_prtRemv= NULL;
	char		*PrtDesc_ValPrt_prtRemv= NULL;
	char		*PrtRevSeq_ValPrt_prtRemv= NULL;
	char		*PrtCS_ValPrt_prtRemv= NULL;
	char		*PrtChgeType_ValPrt_prtRemv= NULL;
	char		*PrtOldQty_ValPrt_prtRemv= NULL;
	char		*PrtRev_prtRemv= NULL;
	char		*PrtSeq_prtRemv= NULL;
	char		*partTypVal= NULL;
	char		*partNoVal= NULL;
	char		*RevVal= NULL;
	char		*SeqVal= NULL;
	char		*srno_InValPrt_prtRemv= NULL;
	char		*PrtType_InValPrt_prtRemv= NULL;
	char		*PrtNo_InValPrt_prtRemv= NULL;
	char		*PrtDesc_InValPrt_prtRemv= NULL;
	char		*PrtRevSeq_InValPrt_prtRemv= NULL;
	char		*PrtCS_InValPrt_prtRemv= NULL;
	char		*PrtChgeType_InValPrt_prtRemv= NULL;
	char		*PrtOldQty_InValPrt_prtRemv= NULL;
	char		*PrtRev_InprtRemv= NULL;
	char		*PrtSeq_InprtRemv= NULL;
	char		*partTypInVal= NULL;
	char		*partNoInVal= NULL;
	char		*RevInVal= NULL;
	char		*SeqInVal= NULL;
	char		*srNoValid_srNoUpd= NULL;
	char		*srNoinValid_srNoUpd= NULL;
	char		*partTypeValid_srNoUpd= NULL;
	char		*partTypeinValid_srNoUpd= NULL;
	char		*new_srno_ValPrtSt= NULL;
	char		*new_srno_inValPrtSt= NULL;
	char		*srNoValid_srNoUpd1= NULL;
	char		*partTypeValid_srNoUpd1= NULL;
	char		*new_srno_ValPrtSt1= NULL;
	char		*srNoinValid_srNoUpd1= NULL;
	char		*partTypeinValid_srNoUpd1= NULL;
	char		*new_srno_inValPrtSt1= NULL;

	const char *qry_entries[1];
	const char *qry_values[1];

	const char *qry_entries_prtRemvEpa[1];
	const char *qry_values_prtRemvEpa[1];

	int n_tags_found=0;
	int n_tags_found_prtRemvEpa=0;
	int new_srno_ValPrtInt=0;
	int new_srno_inValPrtInt=0;
	int iValCnt_srNoUpd=0;
	int iinValCnt_srNoUpd=0;
	int new_srno_ValPrtInt1=0;
	int iinValCnt_srNoUpd1=0;
	int new_srno_inValPrtInt1=0;

	tag_t	*itemclass							= NULLTAG;
	tag_t	*itemclass_prtRemvEpa				= NULLTAG;
	tag_t	new_epa_rev_tag						= NULLTAG;
	tag_t	epa_rev_tag_prtRemvEpa				= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	item_prtRemvEpa						= NULLTAG;
	tag_t* valid_Table_rows						= NULLTAG;
	tag_t* invalid_Table_rows					= NULLTAG;
	tag_t* invalid_rowsTag					= NULLTAG;
	tag_t* valid_rowsTag = NULLTAG;
	tag_t* valid_rowsTag_srNoUpd = NULLTAG;
	tag_t* invalid_rowsTag_srNoUpd = NULLTAG;
	tag_t* valid_rowsTag_srNoUpd1 = NULLTAG;
	tag_t* invalid_rowsTag_srNoUpd1 = NULLTAG;

	int rcntVal=0;
	int rcnt1=0;
	int rcnt2=0;
	int intvalidRowCnt=0;
	int intInvalidRowCnt=0;
	int rcnt=0;
	int n_valid_rows=0;
	int n_valid_rows_srNoUpd=0;
	int n_invalid_rows_srNoUpd=0;
	int n_valid_rows_srNoUpd1=0;
	int n_invalid_rows_srNoUpd1=0;
	int n_invalid_rows=0;
	int iValCnt=0;
	int iValCnt_srNoUpd1=0;

	USERARG_get_string_argument(&oldEPANo);
	USERARG_get_string_argument(&epaValidPartList);
	USERARG_get_string_argument(&epavalidPrtSize);
	USERARG_get_string_argument(&epaInValidPartList);
	USERARG_get_string_argument(&epaInvalidPrtSize);
	USERARG_get_string_argument(&newEPANo);
	USERARG_get_string_argument(&epaValidPartListforRmv);
	USERARG_get_string_argument(&epaInValidPartListforRmv);

	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) oldEPANo=%s\n",oldEPANo);fflush(stdout);
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epaValidPartList=%s\n",epaValidPartList);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epavalidPrtSize=%s\n",epavalidPrtSize);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epaInValidPartList=%s\n",epaInValidPartList);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epaInvalidPrtSize=%s\n",epaInvalidPrtSize);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) newEPANo=%s\n",newEPANo);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epaValidPartListforRmv=%s\n",epaValidPartListforRmv);fflush(stdout);	
	printf("\nArgument Received(EPATrnfValInvalPrtUpdServiceFnc) epaInValidPartListforRmv=%s\n",epaInValidPartListforRmv);fflush(stdout);	
	
	if(tc_strcmp(oldEPANo,"")!=0)
	{
			
		qry_entries[0] ="item_id";
		qry_values[0] = oldEPANo;

		printf("\n Qurying the NEW EPA where part need to be transferred %s:",oldEPANo);fflush(stdout);

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		if(n_tags_found>0 )
		{
			item = itemclass[0];
			
			ITKCALL(ITEM_ask_latest_rev(item,&new_epa_rev_tag));
		}
	}
	
	intvalidRowCnt = atoi(epavalidPrtSize); // Using atoi()
	printf("\nThe value of intvalidRowCnt : %d", intvalidRowCnt);fflush(stdout);

	intInvalidRowCnt = atoi(epaInvalidPrtSize); // Using atoi()
	printf("\nThe value of intInvalidRowCnt : %d", intInvalidRowCnt);fflush(stdout);

	char *arrayVadDt[intvalidRowCnt];
	char *arrayVadDtRmv[intvalidRowCnt];
	char *arrayinVadDtRmv[intInvalidRowCnt];

	if(intvalidRowCnt>0)
	{
	
		
		for(rcntVal=0;rcntVal<intvalidRowCnt;rcntVal++)
		{
			if(tc_strcmp(epaValidPartList,"")!=0)
			{
				
				if(rcntVal==0)
				{
					validRowData=tc_strtok(epaValidPartList,"~");
				}
				else
				{
					validRowData=tc_strtok(NULL,"~");
				}

				printf("\n validRowData :[%s] \n",validRowData);fflush(stdout);

				if(tc_strcmp(validRowData,"")!=0)
				{
					arrayVadDt[rcntVal]=validRowData;
					
				}
				printf("\n arrayVadDt[rcntVal] :[%s] \n",arrayVadDt[rcntVal]);fflush(stdout);	

			}					

		}
	
		
		if(new_epa_rev_tag!=NULLTAG)
		{
			
			//INSERTING  VALID PARTS IN NEW EPA START

			ITKCALL(AOM_lock(new_epa_rev_tag));
			
			ITKCALL(AOM_insert_table_rows(new_epa_rev_tag, "t5_EpaCmTabValid", 0,intvalidRowCnt, &valid_Table_rows));
			printf("\n\n Inside else of Table Rows Inserted Success\n");fflush(stdout);

			rcnt=0;
			for(rcnt=0;rcnt<intvalidRowCnt;rcnt++)
			{
					
				fectValidRowData=arrayVadDt[rcnt];
				printf("\n fectValidRowData :[%s] \n",fectValidRowData);fflush(stdout);			
				

				srno_ValPrt=tc_strtok(fectValidRowData,"-");
				PrtType_ValPrt = tc_strtok(NULL,"-");
				PrtNo_ValPrt = tc_strtok(NULL,"-");
				PrtDesc_ValPrt = tc_strtok(NULL,"-");
				PrtRevSeq_ValPrt = tc_strtok(NULL,"-");
				PrtCS_ValPrt = tc_strtok(NULL,"-");
				PrtChgeType_ValPrt = tc_strtok(NULL,"-");
				PrtOldQty_ValPrt = tc_strtok(NULL,"-");

				printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_ValPrt,PrtType_ValPrt,PrtNo_ValPrt,PrtDesc_ValPrt,PrtRevSeq_ValPrt,PrtCS_ValPrt
						,PrtChgeType_ValPrt,PrtOldQty_ValPrt);fflush(stdout);
				
				if(tc_strcmp(PrtRevSeq_ValPrt,"")!=0) 
				{
					PrtRev=tc_strtok(PrtRevSeq_ValPrt,";");
					PrtSeq=tc_strtok(NULL,";");
				}

				printf("\n PrtRev [%s] PrtSeq [%s]..",PrtRev,PrtSeq);fflush(stdout);

				if((tc_strcmp(srno_ValPrt,"")!=0) && (tc_strcmp(srno_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_ESrNoValid", srno_ValPrt));
				if((tc_strcmp(PrtType_ValPrt,"")!=0) && (tc_strcmp(PrtType_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PartTypeValid", PrtType_ValPrt));
				if((tc_strcmp(PrtNo_ValPrt,"")!=0) && (tc_strcmp(PrtNo_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PartNumberValid", PrtNo_ValPrt));
				if((tc_strcmp(PrtDesc_ValPrt,"")!=0) && (tc_strcmp(PrtDesc_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_NomenclatureValid", PrtDesc_ValPrt));
				if((tc_strcmp(PrtRev,"")!=0) && (tc_strcmp(PrtRev,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_RevisionValid", PrtRev));
				if((tc_strcmp(PrtSeq,"")!=0) && (tc_strcmp(PrtSeq,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_SequenceValid", PrtSeq));				
				if((tc_strcmp(PrtCS_ValPrt,"")!=0) && (tc_strcmp(PrtCS_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PunMakeBuyIndicatorValid", PrtCS_ValPrt));
				if((tc_strcmp(PrtChgeType_ValPrt,"")!=0) && (tc_strcmp(PrtChgeType_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_changeTypeValid", PrtChgeType_ValPrt));
				if((tc_strcmp(PrtOldQty_ValPrt,"")!=0) && (tc_strcmp(PrtOldQty_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_NewQtyLValid", PrtOldQty_ValPrt));
				
				ITKCALL(AOM_save_with_extensions(valid_Table_rows[rcnt]));
				printf("\n\n Save Success");fflush(stdout);

			}
			ITKCALL(AOM_unlock(new_epa_rev_tag));

			ITKCALL(AOM_refresh(new_epa_rev_tag, FALSE));
			printf("\n\n Refresh the EPA Object");fflush(stdout);

			//INSERTING  VALID PARTS IN NEW EPA END

		}

		//UPDATING the SRNO FOR VALID PARTS of NEW EPA

		if(new_epa_rev_tag!=NULLTAG)
		{
		
			ITKCALL(AOM_ask_table_rows(new_epa_rev_tag,"t5_EpaCmTabValid", &n_valid_rows_srNoUpd,&valid_rowsTag_srNoUpd));
			printf("\n no of table rows fron Valid Parts for Srno Upd are %d \n", n_valid_rows_srNoUpd);fflush(stdout);
			if(n_valid_rows_srNoUpd>0)
			{
				for(iValCnt_srNoUpd=0;iValCnt_srNoUpd<n_valid_rows_srNoUpd;iValCnt_srNoUpd++)
				{
					ITKCALL(AOM_ask_value_string(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], "t5_ESrNoValid", &srNoValid_srNoUpd));
					printf("\n srNoValid_srNoUpd [%s]..",srNoValid_srNoUpd);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], "t5_PartTypeValid", &partTypeValid_srNoUpd));
					printf("\n partTypeValid_srNoUpd [%s]..",partTypeValid_srNoUpd);fflush(stdout);	

					if((tc_strcmp(srNoValid_srNoUpd,"")!=0)  && (tc_strcmp(partTypeValid_srNoUpd,"Parent")==0) )
					{
						
						new_srno_ValPrtInt=new_srno_ValPrtInt+1;
						printf("\n\n new_srno_ValPrtInt %d",new_srno_ValPrtInt);fflush(stdout);

						new_srno_ValPrtSt=(char *) MEM_alloc(50);

						sprintf(new_srno_ValPrtSt, "%d", new_srno_ValPrtInt);
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], TRUE));

						ITKCALL(AOM_set_value_string(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], "t5_ESrNoValid", new_srno_ValPrtSt));
						ITKCALL(AOM_save_with_extensions(valid_rowsTag_srNoUpd[iValCnt_srNoUpd]));
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA");fflush(stdout);
					}
					else if((tc_strcmp(srNoValid_srNoUpd,"")!=0) && (tc_strcmp(partTypeValid_srNoUpd,"Child")==0) )
					{
						new_srno_ValPrtSt=(char *) MEM_alloc(50);

						printf("\n\n inside else new_srno_ValPrtInt for child %d",new_srno_ValPrtInt);fflush(stdout);
						sprintf(new_srno_ValPrtSt, "%d", new_srno_ValPrtInt);

						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], TRUE));

						ITKCALL(AOM_set_value_string(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], "t5_ESrNoValid", new_srno_ValPrtSt));
						ITKCALL(AOM_save_with_extensions(valid_rowsTag_srNoUpd[iValCnt_srNoUpd]));
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd[iValCnt_srNoUpd], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA Part Details Child..");fflush(stdout);
					
					}
					
				}
			}
		
		}


	}

	if(intInvalidRowCnt>0)
	{
		
		char *arrayInvadDt[intInvalidRowCnt];
		
		for(rcnt1=0;rcnt1<intInvalidRowCnt;rcnt1++)
		{
			if(tc_strcmp(epaInValidPartList,"")!=0)
			{
				
				if(rcnt1==0)
				{
					invalidRowData=tc_strtok(epaInValidPartList,"~");
				}
				else
				{
					invalidRowData=tc_strtok(NULL,"~");
				}

				printf("\n invalidRowData :[%s] \n",invalidRowData);fflush(stdout);

				if(tc_strcmp(invalidRowData,"")!=0)
				{
					arrayInvadDt[rcnt1]=invalidRowData;
				}
				printf("\n arrayInvadDt[rcnt1] :[%s] \n",arrayInvadDt[rcnt1]);fflush(stdout);

			}					

		}

		if(new_epa_rev_tag!=NULLTAG)
		{

			//INSERTING  INVALID PARTS IN NEW EPA START

			ITKCALL(AOM_lock(new_epa_rev_tag));

			ITKCALL(AOM_insert_table_rows(new_epa_rev_tag, "t5_EpaCrTabInValid", 0,intInvalidRowCnt, &invalid_Table_rows));
			printf("\n\n Inside else of Table Rows Inserted Success for n_invalid_rows..\n");fflush(stdout);
		
			for(rcnt2=0;rcnt2<intInvalidRowCnt;rcnt2++)
			{
				fectinvalidRowData=arrayInvadDt[rcnt2];
				printf("\n fectinvalidRowData :[%s] \n",fectinvalidRowData);fflush(stdout);

				srno_InValPrt=tc_strtok(fectinvalidRowData,"-");
				PrtType_InValPrt = tc_strtok(NULL,"-");
				PrtNo_InValPrt = tc_strtok(NULL,"-");
				PrtDesc_InValPrt = tc_strtok(NULL,"-");
				PrtRevSeq_InValPrt = tc_strtok(NULL,"-");
				PrtCS_InValPrt = tc_strtok(NULL,"-");
				PrtChgeType_InValPrt = tc_strtok(NULL,"-");
				PrtOldQty_InValPrt = tc_strtok(NULL,"-");

				printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_InValPrt,PrtType_InValPrt,PrtNo_InValPrt,PrtDesc_InValPrt,PrtRevSeq_InValPrt,PrtCS_InValPrt
					,PrtChgeType_InValPrt,PrtOldQty_InValPrt);fflush(stdout);
				
				
				if(tc_strcmp(PrtRevSeq_InValPrt,"")!=0) 
				{
					PrtRev1=tc_strtok(PrtRevSeq_InValPrt,";");
					PrtSeq1=tc_strtok(NULL,";");
				}

				printf("\n PrtRev1 [%s] PrtSeq1 [%s]..",PrtRev1,PrtSeq1);fflush(stdout);

				if((tc_strcmp(srno_InValPrt,"")!=0) && (tc_strcmp(srno_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_ESrNoInValid", srno_InValPrt));
				if((tc_strcmp(PrtType_InValPrt,"")!=0) && (tc_strcmp(PrtType_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PartTypeInValid", PrtType_InValPrt));
				if((tc_strcmp(PrtNo_InValPrt,"")!=0) && (tc_strcmp(PrtNo_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PartNumberInValid", PrtNo_InValPrt));
				if((tc_strcmp(PrtDesc_InValPrt,"")!=0) && (tc_strcmp(PrtDesc_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_NomenclatureInValid", PrtDesc_InValPrt));
				if((tc_strcmp(PrtRev1,"")!=0) && (tc_strcmp(PrtRev1,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_RevisionInValid", PrtRev1));
				if((tc_strcmp(PrtSeq1,"")!=0) && (tc_strcmp(PrtSeq1,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_SequenceInValid", PrtSeq1));				
				if((tc_strcmp(PrtCS_InValPrt,"")!=0) && (tc_strcmp(PrtCS_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PunMakeBuyIndicatorInVal", PrtCS_InValPrt));
				if((tc_strcmp(PrtChgeType_InValPrt,"")!=0) && (tc_strcmp(PrtChgeType_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_changeTypeInValid", PrtChgeType_InValPrt));
				if((tc_strcmp(PrtOldQty_InValPrt,"")!=0) && (tc_strcmp(PrtOldQty_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_OldQtyLInValid", PrtOldQty_InValPrt));
				
				ITKCALL(AOM_save_with_extensions(invalid_Table_rows[rcnt2]));
				printf("\n\n Save Success");fflush(stdout);
			
			}

			ITKCALL(AOM_unlock(new_epa_rev_tag));

			ITKCALL(AOM_refresh(new_epa_rev_tag, FALSE));
			printf("\n\n Refresh the EPA Object 11");fflush(stdout);

			//INSERTING  INVALID PARTS IN NEW EPA END

		
		}

		//UPDATING the SRNO FOR INVALID PARTS of NEW EPA START

		if(new_epa_rev_tag!=NULLTAG)
		{
		
			ITKCALL(AOM_ask_table_rows(new_epa_rev_tag,"t5_EpaCrTabInValid", &n_invalid_rows_srNoUpd,&invalid_rowsTag_srNoUpd));
			printf("\n no of table rows fron inValid Parts for Srno Upd are %d \n", n_invalid_rows_srNoUpd);fflush(stdout);
			if(n_invalid_rows_srNoUpd>0)
			{
				for(iinValCnt_srNoUpd=0;iinValCnt_srNoUpd<n_invalid_rows_srNoUpd;iinValCnt_srNoUpd++)
				{
					ITKCALL(AOM_ask_value_string(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], "t5_ESrNoInValid", &srNoinValid_srNoUpd));
					printf("\n srNoinValid_srNoUpd [%s]..",srNoinValid_srNoUpd);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], "t5_PartTypeInValid", &partTypeinValid_srNoUpd));
					printf("\n partTypeinValid_srNoUpd [%s]..",partTypeinValid_srNoUpd);fflush(stdout);	

					if((tc_strcmp(srNoinValid_srNoUpd,"")!=0)  && (tc_strcmp(partTypeinValid_srNoUpd,"Parent")==0) )
					{
						
						new_srno_inValPrtInt=new_srno_inValPrtInt+1;
						printf("\n\n new_srno_inValPrtInt %d",new_srno_inValPrtInt);fflush(stdout);

						new_srno_inValPrtSt=(char *) MEM_alloc(50);

						sprintf(new_srno_inValPrtSt, "%d", new_srno_inValPrtInt);
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], TRUE));

						ITKCALL(AOM_set_value_string(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], "t5_ESrNoInValid", new_srno_inValPrtSt));
						ITKCALL(AOM_save_with_extensions(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd]));
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA");fflush(stdout);
					}
					else if((tc_strcmp(srNoinValid_srNoUpd,"")!=0) && (tc_strcmp(partTypeinValid_srNoUpd,"Child")==0) )
					{
						new_srno_inValPrtSt=(char *) MEM_alloc(50);

						printf("\n\n inside else new_srno_ValPrtInt for child %d",new_srno_inValPrtInt);fflush(stdout);
						sprintf(new_srno_inValPrtSt, "%d", new_srno_inValPrtInt);

						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], TRUE));

						ITKCALL(AOM_set_value_string(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], "t5_ESrNoInValid", new_srno_inValPrtSt));
						ITKCALL(AOM_save_with_extensions(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd]));
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd[iinValCnt_srNoUpd], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA Part Details Child..");fflush(stdout);
					
					}
					
				}
			}
		
		}
		//UPDATING the SRNO FOR INVALID PARTS of NEW EPA END

	}

	
	
	//Code for Removing the Valid and Invalid Part details from existing EPA
	
	if(tc_strcmp(newEPANo,"")!=0)
	{
		qry_entries_prtRemvEpa[0] ="item_id";
		qry_values_prtRemvEpa[0] = newEPANo;

		printf("\n Qurying the NEW EPA where part need to be removed %s:",newEPANo);fflush(stdout);

		ITEM_find_items_by_key_attributes(1, qry_entries_prtRemvEpa, qry_values_prtRemvEpa,&n_tags_found_prtRemvEpa, &itemclass_prtRemvEpa);
		if(n_tags_found_prtRemvEpa>0)
		{
			item_prtRemvEpa = itemclass_prtRemvEpa[0];
			
			ITKCALL(ITEM_ask_latest_rev(item_prtRemvEpa,&epa_rev_tag_prtRemvEpa));
		}

		
		//Valid Part Detials
		if(intvalidRowCnt>0)
		{
			
			rcntVal=0;
			for(rcntVal=0;rcntVal<intvalidRowCnt;rcntVal++)
			{
				if(tc_strcmp(epaValidPartListforRmv,"")!=0)
				{
					
					if(rcntVal==0)
					{
						validRowDataRm=tc_strtok(epaValidPartListforRmv,"~");
					}
					else
					{
						validRowDataRm=tc_strtok(NULL,"~");
					}

					printf("\n validRowDataRm :[%s] \n",validRowDataRm);fflush(stdout);

					if(tc_strcmp(validRowDataRm,"")!=0)
					{
						arrayVadDtRmv[rcntVal]=validRowDataRm;
						
					}
					printf("\n arrayVadDtRmv[rcntVal] :[%s] \n",arrayVadDtRmv[rcntVal]);fflush(stdout);	

				}					

			}
			
			rcnt=0;
			for(rcnt=0;rcnt<intvalidRowCnt;rcnt++)
			{
						
				fectValidRowData_prtRemv=arrayVadDtRmv[rcnt];
				printf("\n fectValidRowData_prtRemv :[%s] \n",fectValidRowData_prtRemv);fflush(stdout);
				
				srno_ValPrt_prtRemv=tc_strtok(fectValidRowData_prtRemv,"-");
				PrtType_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtNo_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtDesc_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtRevSeq_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtCS_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtChgeType_ValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtOldQty_ValPrt_prtRemv = tc_strtok(NULL,"-");

				printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_ValPrt_prtRemv,PrtType_ValPrt_prtRemv,PrtNo_ValPrt_prtRemv,PrtDesc_ValPrt_prtRemv,PrtRevSeq_ValPrt_prtRemv,PrtCS_ValPrt_prtRemv
						,PrtChgeType_ValPrt_prtRemv,PrtOldQty_ValPrt_prtRemv);fflush(stdout);
				
				if(tc_strcmp(PrtRevSeq_ValPrt_prtRemv,"")!=0) 
				{
					PrtRev_prtRemv=tc_strtok(PrtRevSeq_ValPrt_prtRemv,";");
					PrtSeq_prtRemv=tc_strtok(NULL,";");
				}

				printf("\n PrtRev_prtRemv [%s] PrtSeq_prtRemv [%s]..",PrtRev_prtRemv,PrtSeq_prtRemv);fflush(stdout);
		
		
				ITKCALL(AOM_ask_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCmTabValid", &n_valid_rows,&valid_rowsTag));
				printf("\n no of table rows fron Valid Parts to be removed are %d \n", n_valid_rows);fflush(stdout);
				if(n_valid_rows>0)
				{
					iValCnt=0;
					for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
					{
						
						ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_PartTypeValid", &partTypVal));
						printf("\n 11 partTypVal [%s]..",partTypVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_PartNumberValid", &partNoVal));
						printf("\n 11 partNoVal [%s]..",partNoVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_RevisionValid", &RevVal));
						printf("\n 11 RevVal [%s]..",RevVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_SequenceValid", &SeqVal));
						printf("\n SeqVal [%s]..",SeqVal);fflush(stdout);	

						if( (tc_strcmp(partTypVal,PrtType_ValPrt_prtRemv)==0) && (tc_strcmp(partNoVal,PrtNo_ValPrt_prtRemv)==0) && (tc_strcmp(RevVal,PrtRev_prtRemv)==0) && (tc_strcmp(SeqVal,PrtSeq_prtRemv)==0))
						{
							printf("\n 11 All required values matching in valid part..hence going for delete rows....");fflush(stdout);
							
							int delete_from_row_index = iValCnt;
							int num_rows_to_delete  = 1;

							ITKCALL(AOM_lock(epa_rev_tag_prtRemvEpa));
							ITKCALL(AOM_delete_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCmTabValid", delete_from_row_index,num_rows_to_delete));
							ITKCALL(AOM_unlock(epa_rev_tag_prtRemvEpa));
							ITKCALL(AOM_refresh(epa_rev_tag_prtRemvEpa, FALSE));
							printf("\n\n Refresh the EPA Object after deleting rows from Valid Table Properties...");fflush(stdout);
						}
					}
				}
			}

			// UPDATING THE SRNO AFTER DELETE ROWS IN VALID PARTS START


			ITKCALL(AOM_ask_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCmTabValid", &n_valid_rows_srNoUpd1,&valid_rowsTag_srNoUpd1));
			printf("\n no of table rows fron Valid Parts for Srno Upd1 are %d \n", n_valid_rows_srNoUpd1);fflush(stdout);
			if(n_valid_rows_srNoUpd1>0)
			{
				for(iValCnt_srNoUpd1=0;iValCnt_srNoUpd1<n_valid_rows_srNoUpd1;iValCnt_srNoUpd1++)
				{
					ITKCALL(AOM_ask_value_string(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], "t5_ESrNoValid", &srNoValid_srNoUpd1));
					printf("\n srNoValid_srNoUpd1 [%s]..",srNoValid_srNoUpd1);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], "t5_PartTypeValid", &partTypeValid_srNoUpd1));
					printf("\n partTypeValid_srNoUpd1 [%s]..",partTypeValid_srNoUpd1);fflush(stdout);	

					if((tc_strcmp(srNoValid_srNoUpd1,"")!=0)  && (tc_strcmp(partTypeValid_srNoUpd1,"Parent")==0) )
					{
						
						new_srno_ValPrtInt1=new_srno_ValPrtInt1+1;
						printf("\n\n new_srno_ValPrtInt1 %d",new_srno_ValPrtInt1);fflush(stdout);

						new_srno_ValPrtSt1=(char *) MEM_alloc(50);

						sprintf(new_srno_ValPrtSt1, "%d", new_srno_ValPrtInt1);
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], TRUE));

						ITKCALL(AOM_set_value_string(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], "t5_ESrNoValid", new_srno_ValPrtSt1));
						ITKCALL(AOM_save_with_extensions(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1]));
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA");fflush(stdout);
					}
					else if((tc_strcmp(srNoValid_srNoUpd1,"")!=0) && (tc_strcmp(partTypeValid_srNoUpd1,"Child")==0) )
					{
						new_srno_ValPrtSt1=(char *) MEM_alloc(50);

						printf("\n\n inside else new_srno_ValPrtInt1 for child %d",new_srno_ValPrtInt1);fflush(stdout);
						sprintf(new_srno_ValPrtSt1, "%d", new_srno_ValPrtInt1);

						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], TRUE));

						ITKCALL(AOM_set_value_string(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], "t5_ESrNoValid", new_srno_ValPrtSt1));
						ITKCALL(AOM_save_with_extensions(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1]));
						ITKCALL(AOM_refresh(valid_rowsTag_srNoUpd1[iValCnt_srNoUpd1], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA Part Details Child..");fflush(stdout);
					
					}
					
				}
			}

			// UPDATING THE SRNO AFTER DELETE ROWS IN VALID PARTS END

		}

		//InValid Part Detials

		if(intInvalidRowCnt>0)
		{
			
			rcntVal=0;
			for(rcntVal=0;rcntVal<intInvalidRowCnt;rcntVal++)
			{
				if(tc_strcmp(epaInValidPartListforRmv,"")!=0)
				{
					
					if(rcntVal==0)
					{
						invalidRowDataRm=tc_strtok(epaInValidPartListforRmv,"~");
					}
					else
					{
						invalidRowDataRm=tc_strtok(NULL,"~");
					}

					printf("\n invalidRowDataRm :[%s] \n",invalidRowDataRm);fflush(stdout);

					if(tc_strcmp(invalidRowDataRm,"")!=0)
					{
						arrayinVadDtRmv[rcntVal]=invalidRowDataRm;
						
					}
					printf("\n arrayinVadDtRmv[rcntVal] :[%s] \n",arrayinVadDtRmv[rcntVal]);fflush(stdout);	

				}					

			}
			
			rcnt=0;
			for(rcnt=0;rcnt<intInvalidRowCnt;rcnt++)
			{
						
				fectinValidRowData_prtRemv=arrayinVadDtRmv[rcnt];
				printf("\n fectinValidRowData_prtRemv :[%s] \n",fectinValidRowData_prtRemv);fflush(stdout);
				
				srno_InValPrt_prtRemv=tc_strtok(fectinValidRowData_prtRemv,"-");
				PrtType_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtNo_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtDesc_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtRevSeq_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtCS_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtChgeType_InValPrt_prtRemv = tc_strtok(NULL,"-");
				PrtOldQty_InValPrt_prtRemv = tc_strtok(NULL,"-");

				printf("\n Printing the first value of Invalid:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_InValPrt_prtRemv,PrtType_InValPrt_prtRemv,PrtNo_InValPrt_prtRemv,PrtDesc_InValPrt_prtRemv,PrtRevSeq_InValPrt_prtRemv,PrtCS_InValPrt_prtRemv
						,PrtChgeType_InValPrt_prtRemv,PrtOldQty_InValPrt_prtRemv);fflush(stdout);
				
				if(tc_strcmp(PrtRevSeq_InValPrt_prtRemv,"")!=0) 
				{
					PrtRev_InprtRemv=tc_strtok(PrtRevSeq_InValPrt_prtRemv,";");
					PrtSeq_InprtRemv=tc_strtok(NULL,";");
				}

				printf("\n PrtRev_InprtRemv [%s] PrtSeq_InprtRemv [%s]..",PrtRev_InprtRemv,PrtSeq_InprtRemv);fflush(stdout);
		
		
				ITKCALL(AOM_ask_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCrTabInValid", &n_invalid_rows,&invalid_rowsTag));
				printf("\n no of table rows fron Valid Parts to be removed are %d \n", n_invalid_rows);fflush(stdout);
				if(n_invalid_rows>0)
				{
					iValCnt=0;
					for(iValCnt=0;iValCnt<n_invalid_rows;iValCnt++)
					{
						
						ITKCALL(AOM_ask_value_string(invalid_rowsTag[iValCnt], "t5_PartTypeInValid", &partTypInVal));
						printf("\n 11 partTypInVal [%s]..",partTypInVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(invalid_rowsTag[iValCnt], "t5_PartNumberInValid", &partNoInVal));
						printf("\n 11 partNoInVal [%s]..",partNoInVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(invalid_rowsTag[iValCnt], "t5_RevisionInValid", &RevInVal));
						printf("\n 11 RevInVal [%s]..",RevInVal);fflush(stdout);	

						ITKCALL(AOM_ask_value_string(invalid_rowsTag[iValCnt], "t5_SequenceInValid", &SeqInVal));
						printf("\n SeqInVal [%s]..",SeqInVal);fflush(stdout);	

						if( (tc_strcmp(partTypInVal,PrtType_InValPrt_prtRemv)==0) && (tc_strcmp(partNoInVal,PrtNo_InValPrt_prtRemv)==0) && (tc_strcmp(RevInVal,PrtRev_InprtRemv)==0) && (tc_strcmp(SeqInVal,PrtSeq_InprtRemv)==0))
						{
							printf("\n 11 All required values matching in Invalid part..hence going for delete rows....");fflush(stdout);
							
							int delete_from_row_index = iValCnt;
							int num_rows_to_delete  = 1;

							ITKCALL(AOM_lock(epa_rev_tag_prtRemvEpa));
							ITKCALL(AOM_delete_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCrTabInValid", delete_from_row_index,num_rows_to_delete));
							ITKCALL(AOM_unlock(epa_rev_tag_prtRemvEpa));
							ITKCALL(AOM_refresh(epa_rev_tag_prtRemvEpa, FALSE));
							printf("\n\n Refresh the EPA Object after deleting rows from InValid Table Properties...");fflush(stdout);
						}
					}
				}
			}


			// UPDATING THE SRNO AFTER DELETE ROWS IN INVALID PARTS START

			ITKCALL(AOM_ask_table_rows(epa_rev_tag_prtRemvEpa,"t5_EpaCrTabInValid", &n_invalid_rows_srNoUpd1,&invalid_rowsTag_srNoUpd1));
			printf("\n no of table rows fron inValid Parts for Srno Upd1 are %d \n", n_invalid_rows_srNoUpd1);fflush(stdout);
			if(n_invalid_rows_srNoUpd1>0)
			{
				for(iinValCnt_srNoUpd1=0;iinValCnt_srNoUpd1<n_invalid_rows_srNoUpd1;iinValCnt_srNoUpd1++)
				{
					ITKCALL(AOM_ask_value_string(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], "t5_ESrNoInValid", &srNoinValid_srNoUpd1));
					printf("\n srNoinValid_srNoUpd1 [%s]..",srNoinValid_srNoUpd1);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], "t5_PartTypeInValid", &partTypeinValid_srNoUpd1));
					printf("\n partTypeinValid_srNoUpd1 [%s]..",partTypeinValid_srNoUpd1);fflush(stdout);	

					if((tc_strcmp(srNoinValid_srNoUpd1,"")!=0)  && (tc_strcmp(partTypeinValid_srNoUpd1,"Parent")==0) )
					{
						
						new_srno_inValPrtInt1=new_srno_inValPrtInt1+1;
						printf("\n\n new_srno_inValPrtInt1 %d",new_srno_inValPrtInt1);fflush(stdout);

						new_srno_inValPrtSt1=(char *) MEM_alloc(50);

						sprintf(new_srno_inValPrtSt1, "%d", new_srno_inValPrtInt1);
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], TRUE));

						ITKCALL(AOM_set_value_string(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], "t5_ESrNoInValid", new_srno_inValPrtSt1));
						ITKCALL(AOM_save_with_extensions(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1]));
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA11");fflush(stdout);
					}
					else if((tc_strcmp(srNoinValid_srNoUpd1,"")!=0) && (tc_strcmp(partTypeinValid_srNoUpd1,"Child")==0) )
					{
						new_srno_inValPrtSt1=(char *) MEM_alloc(50);

						printf("\n\n inside else new_srno_ValPrtInt1 for child %d",new_srno_inValPrtInt1);fflush(stdout);
						sprintf(new_srno_inValPrtSt1, "%d", new_srno_inValPrtInt1);

						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], TRUE));

						ITKCALL(AOM_set_value_string(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], "t5_ESrNoInValid", new_srno_inValPrtSt1));
						ITKCALL(AOM_save_with_extensions(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1]));
						ITKCALL(AOM_refresh(invalid_rowsTag_srNoUpd1[iinValCnt_srNoUpd1], FALSE));
						printf("\n\n Update of SRNo and Save Success for Valid New EPA Part Details Child1111..");fflush(stdout);
					
					}
					
				}
			}
			// UPDATING THE SRNO AFTER DELETE ROWS IN INVALID PARTS END


		}
	
	
	}

	return ifail;
}


extern int EPATrnfValInvalPrtUpdRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 8;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	inputArgTypes[7] = USERARG_STRING_TYPE;

	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EPATrnfValInvalPrtUpdServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("EPATrnfValInvalPrtUpdServiceFnc",(USER_function_t)EPATrnfValInvalPrtUpdServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_EPAPrtTrnsFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(EPATrnfValInvalPrtUpdRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_EPATrnfValInvalPrtUpdServiceFnc_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_EPATrnfValInvalPrtUpdServiceFnc_register_callbacks...."); 
	printf("\n Before registoring userservice tm_EPATrnfValInvalPrtUpd ...."); 
	ifail=CUSTOM_register_exit ( "tm_EPATrnfValInvalPrtUpdServiceFnc", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_EPAPrtTrnsFuncServiceFnc);
	printf("\n After registoring userservice tm_EPATrnfValInvalPrtUpd....");
	return ( ITK_ok );
}

