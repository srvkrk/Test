/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Rule Handler for PO check Manager validations to check NOPO parts avalability..
*  Code                 :   tm_BOMcompleteness.c
*  Created on			:   12/04/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	12/05/2021					Mohan Tayade		BOM completeness validation.
*	2.	13/01/2022					Mohan Tayade		BOM completeness validation for DR4 DMLs.
*********************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_BOMcompleteness(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *sDMLno		= NULL;
	tag_t *taskAttachments=NULLTAG;
	char	*PlntToPlnt		=  NULL;
	char	*TskNm			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*Partno		=  NULL;
	char	*Toplnt		=  NULL;
	char	*BomComInfo3		=  NULL;
	char	*BomComInfo4		=  NULL;
	char	*BomComInfo5		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLDR		=  NULL;
	char	*PartMstr_no		=  NULL;
	char	*rel_status		=  NULL;
	char	*doctype		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	int	rel_status_cunt	=  0;
	int	ii	=  0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	CMRefcount	= 0;
	int	Tskcnt	= 0;
	int	r	= 0;

	tag_t	*secobjects = NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *BomComInfo1 =NULL;
	char   *Prtrel_status =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;

	char   *sDMLtaskno =NULL;
	char   *PartTyp =NULL;
	char   *BomComInfo6 =NULL;
	char   *BomComInfo2 =NULL;
	char   *BOMComp =NULL;
	char   *sPrtColInd =NULL;
	char   *DMLProj =NULL;
	char   *vehrev =NULL;
	char   *REP1 =NULL;
	char   *REP2 =NULL;
	char   *REP3 =NULL;
	char   *docname =NULL;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	
	char*   sPartObjyp=NULL;
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	int     BOMCompFlag      =  0;
	int     chkBOMComFlag      =  0;
	int     iBOMComp      =  0;
	int     iBomComInfo2      =  0;
	int     RelRevFlag      =  0;
	int     seccount      =  0;
	int     REP1Flag      =  0;
	int     REP2Flag      =  0;
	int     REP3Flag      =  0;
	double     dbl_BOMComp      =  0;
	double     dbl_iBomComInfo2      =  0;
	char DRStrng[20];
	//new attri
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t rel_type =NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	int j =0;
	int countt =0;
	logical is_latest;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char*	CurrentTask				=NULL;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLDR =(char *) MEM_alloc(20 * sizeof(char *));
	
	printf("\n tm_BOMcompleteness Function started...");fflush(stdout);
	TC_write_syslog("\n tm_BOMcompleteness Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n BOM:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n BOM:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n BOM:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n BOM: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n BOM:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n BOM:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "BomCom";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n BOM:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&BomComInfo1)!=ITK_ok)   PrintErrorStack();
				//percentage
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&BomComInfo2)!=ITK_ok)   PrintErrorStack();
				//FROM TO values for GMD
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&BomComInfo3)!=ITK_ok)   PrintErrorStack();
				//DML DR-status and DML types.:,Veh,TODR,DR3,AR3,DR3P,DR4,AR3P,AR4,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&BomComInfo4)!=ITK_ok)   PrintErrorStack();
				//Part Type
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&BomComInfo5)!=ITK_ok)   PrintErrorStack();
				//,Veh,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&BomComInfo6)!=ITK_ok)   PrintErrorStack();
				printf("\n BOM:BomComInfo1 is  = [%s] BomComInfo2:%s\n BomComInfo3:[%s] BomComInfo4:[%s] \n BomComInfo5:[%s] \n BomComInfo6:[%s]\n", BomComInfo1,BomComInfo2,BomComInfo3,BomComInfo4,BomComInfo5,BomComInfo6);fflush(stdout);
			}
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
				printf("\n Wt:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
					printf("\n Wt:DML Revision from Task for MR : %d",countt);fflush(stdout);
					for (j=0;j<countt ;j++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
						printf("\n Wt: is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n Wt:is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTg = DMLRevision[j];
							if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
							printf("\n Wt:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);
							if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
							if(item_tag==NULLTAG)
							{
								printf("\n X1:item_tag is NULL.\n");fflush(stdout);
								return decision;
							}
							else
							{
								printf("\n X2:item_tag found.\n");fflush(stdout);
								if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
								if(DMLTag==NULLTAG)
								{
									printf("\n X3:Object not found in Teamcenter...!!\n");fflush(stdout);
									return decision;
								}
								else
								{
									//DML Details:
									if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
									printf("\n X5: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
									tc_strcpy(sDMLrlstype,"");
									tc_strcpy(sDMLrlstype,",");
									tc_strcat(sDMLrlstype,DMLtype);
									tc_strcat(sDMLrlstype,",");
									printf("\n sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
									tc_strcpy(sDMLDR,"");
									tc_strcpy(sDMLDR,",");
									tc_strcat(sDMLDR,DMLDR);
									tc_strcat(sDMLDR,",");
									printf("\n sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
									//,Veh,
									if(tc_strstr(BomComInfo6,sDMLrlstype) != NULL)
									{
										if(tc_strstr(BomComInfo1,sDMLno) != NULL)
										{
											printf("\n DML has been bypassed \n");fflush(stdout);
										}
										else
										{
											if(tc_strstr(BomComInfo1,"TaskBomComp") == NULL)
											{
												if(tc_strstr(BomComInfo4,sDMLrlstype) != NULL)
												{
													if(tc_strcmp(DMLtype,"TODR")==0)
													{
														//if ((tc_strcmp(PlntToPlnt,"UPV2 to UPV3")==0) || (tc_strcmp(PlntToPlnt,"UNV3 to DR3")==0)|| (tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
														if(PlntToPlnt != NULL)
														{
															if(tc_strstr(BomComInfo3,PlntToPlnt) != NULL)
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n X22:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	BOMCompFlag=0;
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n X23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n X24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

																			if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																			if (tsk_CMRef_type!=NULLTAG)
																			{
																				CMRefcount=0;
																				if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																				printf("\n X25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																				if(CMRefcount > 0)
																				{
																					Mstr=0;
																					BOMCompFlag=0;
																					for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																					{
																						printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
																						if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																						printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																						if(strcmp(Prt_object_type,"Folder")!=0)
																						{
																							// put condition for desi rev , to avoid other attachments.
																							if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																							printf("\n X28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																							

																							Item_count=0;
																							//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																							All_item_tag= t5GetItemRevison(PartMstr_no);
																							if(All_item_tag==NULLTAG)
																							{
																								printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																								//return 0;
																							}
																							else
																							{
																								if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																								printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																								if(Item_count > 0)
																								{
																									ii=0;
																									BOMCompFlag=0;
																									for(ii=Item_count-1;ii>=0;ii--)
																									{
																										rel_status_cunt=0;
																										if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																										printf("\n X31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																										//check revison
																										chkBOMComFlag=0;
																										printf("\n sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																										if((tc_strcmp(sPrtColInd,"N")==0)||(tc_strcmp(sPrtColInd,"Y")==0))
																										{
																											if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																											{
																												chkBOMComFlag=1;
																											}
																											else if(tc_strstr(BomComInfo1,"BomCompVali2") != NULL)
																											{
																												chkBOMComFlag=1;
																											}
																											printf("\n chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																											if(chkBOMComFlag >0)
																											{
																												tc_strcpy(sPartTyp,"");
																												tc_strcpy(sPartTyp,",");
																												tc_strcat(sPartTyp,PartTyp);
																												tc_strcat(sPartTyp,",");
																												printf("\n sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																												if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																												{
																													if(tc_strstr(BomComInfo1,"REP1") == NULL)
																													{
																														vehrev=tc_strtok(Prtrev_idd,";");
																														printf(  "\n\t Design Revision vehrev = %s  \n",vehrev); fflush(stdout);


																														REP1 = MEM_alloc(50);
																														REP2 = MEM_alloc(50);
																														REP3 = MEM_alloc(50);

																														tc_strcat(REP1,PartMstr_no);
																														tc_strcat(REP1,"_");
																														tc_strcat(REP1,vehrev);
																														tc_strcat(REP1,"_BOM_CORRECTNESS_Mod_REPORT");
																														printf("\n REP1 is: %s \n",REP1);fflush(stdout);

																														tc_strcat(REP2,PartMstr_no);
																														tc_strcat(REP2,"_");
																														tc_strcat(REP2,vehrev);
																														tc_strcat(REP2,"_Data_Dump_Mod");
																														printf("\n REP2 is: %s \n",REP2);fflush(stdout);

																														tc_strcat(REP3,PartMstr_no);
																														tc_strcat(REP3,"_");
																														tc_strcat(REP3,vehrev);
																														tc_strcat(REP3,"_BOM_COMPLETENESS_Mod_REPORT");
																														printf("\n REP3 is: %s \n",REP3);fflush(stdout);

																														ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
								  
																														ITK_CALL(GRM_list_secondary_objects_only(DMLTag,rel_type,&seccount,&secobjects));

																														if (seccount>0)
																														{
																															  REP1Flag  = 0;
																															  REP2Flag  = 0;
																															  REP3Flag  = 0;
																															  for(r=0;r<seccount;r++)
																															  {
																																	ITK_CALL(AOM_UIF_ask_value(secobjects[r],"object_type",&doctype));
																																	printf("\n doctype is: %s \n",doctype);fflush(stdout);
																																  
																																	ITK_CALL(AOM_UIF_ask_value(secobjects[r],"current_name",&docname));
																																	printf("\n docname is: %s \n",docname);fflush(stdout);

																																	if(tc_strstr(BomComInfo1,"BomPertge01") == NULL)
																																	{
																																		if(tc_strstr(docname,REP1)!=NULL)
																																		{
																																		  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP1Flag = 1;
																																		  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if(tc_strstr(docname,REP2)!=NULL)
																																		{
																																		  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																																		  REP2Flag = 1;
																																		  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if(tc_strstr(docname,REP3)!=NULL)
																																		{
																																		  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP3Flag = 1;
																																		  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																																		  //break;
																																		}
																																	}
																																	else
																																	{
																																		printf("\ncheck both \n"); fflush(stdout);
																																		if((tc_strstr(docname,REP1)!=NULL) ||(tc_strstr(docname,"CORRECTNESS_Mod")!=NULL))
																																		{
																																		  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP1Flag = 1;
																																		  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if((tc_strstr(docname,REP2)!=NULL) ||(tc_strstr(docname,"Dump_Mod")!=NULL))
																																		{
																																		  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																																		  REP2Flag = 1;
																																		  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if((tc_strstr(docname,REP3)!=NULL)||(tc_strstr(docname,"COMPLETENESS_Mod")!=NULL))
																																		{
																																		  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP3Flag = 1;
																																		  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																																		  //break;
																																		}
																																	}

																															  }
																														}
																														if ((REP1Flag>0)&& (REP2Flag>0)&& (REP3Flag>0))
																														{
																															  printf("\n************************ EPM_GO***************************** \n"); fflush(stdout);
																															  
																														}
																														else
																														{
																															  printf("\n Condition found"); fflush(stdout);
																															  printf("\n************************ REPFlag is not present***************************** \n"); fflush(stdout);
																															  printf("\n************************ EPM_NOGO***************************** \n"); fflush(stdout);
																															  EMH_clear_errors();
																															  EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"Please ensure to attach BOM_CORRECTNESS_Mod_REPORT, Data_Dump_Mod and BOM_COMPLETENESS_Mod_REPORT in 'References' relation to DML and then refresh worklist and signoff.");
																															  decision = EPM_nogo;
																															  return decision;	  
																														}
																													}
																													if(tc_strstr(BomComInfo1,"BOMComFlag") == NULL)
																													{
																														BOMCompFlag=1;
																													}
																													if(AOM_UIF_ask_value(rev_list[ii], "t5_BOMCmpl", &BOMComp)!=ITK_ok)PrintErrorStack();
																													printf("\n X30:BOMComp found: %s.", BOMComp);fflush(stdout);
																													if((BOMComp==NULL) ||(tc_strcmp(BOMComp,"")==0))
																													{
																														//NULL case
																														printf("\n BOMComp is NULL, FAILED for GM DML.");fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should not be NULL. \nPlease get the BOM completeness report generated for attached vehicle/part. \nOption- Tools - Reports- BOM completeness and correctness report. \nIf the BOM accuracy value percentage is equal or above than below given percentage, then you can sign off this DML. \nBOM COmpleteness Percentage: ",BomComInfo2);	
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														if(tc_strstr(BomComInfo1,"BomCompVali3") == NULL)
																														{
																															STRNG_is_double(BOMComp,&dbl_BOMComp);
																															//dbl_BOMComp=atof(BOMComp);
																															printf(" dbl_BOMComp:: [%f]", dbl_BOMComp);fflush(stdout);

																															STRNG_is_double(BomComInfo2,&dbl_iBomComInfo2);
																															//dbl_iBomComInfo2=atof(BomComInfo2);
																															printf(" dbl_BOMComp:: [%f]", dbl_iBomComInfo2);fflush(stdout);
																															if (tc_strcmp(BOMComp,"100")==0)
																															{
																																BOMCompFlag=0;
																																//break;
																																printf("\n P11:BOMComp is 100 percentage: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																															else if((dbl_BOMComp >dbl_iBomComInfo2 )||(dbl_iBomComInfo2 ==dbl_BOMComp))
																															{
																																BOMCompFlag=0;
																																//break;
																																printf("\n P31::BOMComp is match percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																															else
																															{
																																BOMCompFlag=1;
																																printf("\n P41:BOMComp is not 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																														}
																														else
																														{
																															printf("\n TASK BOM COM OFF...");fflush(stdout);
																														}
																													}
																													break;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																						if (BOMCompFlag >0)
																						{
																							printf("\n P:BOMComp :%d",BOMCompFlag);fflush(stdout);
																							break;
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n Q:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														else
														{
															printf("\n FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);	
															decision = EPM_nogo;
															return decision;
														}

														//if(TaskCMRef) MEM_free(TaskCMRef);
														//if(rev_list) MEM_free(rev_list);
													}
													else
													{
														if(DMLDR != NULL)
														{
															//if ((tc_strcmp(DML_Milestone,"UPV3")==0) || (tc_strcmp(DMLDR,"AR3")==0)|| (tc_strcmp(DMLDR,"DR3")==0))
															if(tc_strstr(BomComInfo4,sDMLDR) != NULL)
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n X22:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	BOMCompFlag=0;
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n X23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n X24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

																			if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																			if (tsk_CMRef_type!=NULLTAG)
																			{
																				CMRefcount=0;
																				if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																				printf("\n X25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																				if(CMRefcount > 0)
																				{
																					Mstr=0;
																					BOMCompFlag=0;
																					for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																					{
																						printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
																						if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																						printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																						if(strcmp(Prt_object_type,"Folder")!=0)
																						{
																							// put condition for desi rev , to avoid other attachments.
																							if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																							printf("\n X28:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																							

																							Item_count=0;
																							//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																							All_item_tag= t5GetItemRevison(PartMstr_no);
																							if(All_item_tag==NULLTAG)
																							{
																								printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																								//return 0;
																							}
																							else
																							{
																								if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																								printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																								if(Item_count > 0)
																								{
																									ii=0;
																									BOMCompFlag=0;
																									for(ii=Item_count-1;ii>=0;ii--)
																									{
																										chkBOMComFlag=0;
																										rel_status_cunt=0;
																										if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																										printf("\n X31:Part %s rev:%s PartTyp:%s  Rel Status:%s sPartObjyp:%s sPrtColInd:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,sPrtColInd);fflush(stdout);
																										if((tc_strcmp(sPrtColInd,"N")==0)||(tc_strcmp(sPrtColInd,"Y")==0))
																										{
																											if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																											{
																												chkBOMComFlag=1;
																											}
																											else if(tc_strstr(BomComInfo1,"BomCompVali2") != NULL)
																											{
																												chkBOMComFlag=1;
																											}
																											if(chkBOMComFlag >0)
																											{
																												tc_strcpy(sPartTyp,"");
																												tc_strcpy(sPartTyp,",");
																												tc_strcat(sPartTyp,PartTyp);
																												tc_strcat(sPartTyp,",");
																												printf("\n sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																												if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																												{
																													if(tc_strstr(BomComInfo1,"REP2") == NULL)
																													{
																														vehrev=tc_strtok(Prtrev_idd,";");
																														printf(  "\n\t Design Revision vehrev = %s  \n",vehrev); fflush(stdout);


																														REP1 = MEM_alloc(50);
																														REP2 = MEM_alloc(50);
																														REP3 = MEM_alloc(50);

																														tc_strcat(REP1,PartMstr_no);
																														tc_strcat(REP1,"_");
																														tc_strcat(REP1,vehrev);
																														tc_strcat(REP1,"_BOM_CORRECTNESS_Mod_REPORT");
																														printf("\n REP1 is: %s \n",REP1);fflush(stdout);

																														tc_strcat(REP2,PartMstr_no);
																														tc_strcat(REP2,"_");
																														tc_strcat(REP2,vehrev);
																														tc_strcat(REP2,"_Data_Dump_Mod");
																														printf("\n REP2 is: %s \n",REP2);fflush(stdout);

																														tc_strcat(REP3,PartMstr_no);
																														tc_strcat(REP3,"_");
																														tc_strcat(REP3,vehrev);
																														tc_strcat(REP3,"_BOM_COMPLETENESS_Mod_REPORT");
																														printf("\n REP3 is: %s \n",REP3);fflush(stdout);

																														ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
								  
																														ITK_CALL(GRM_list_secondary_objects_only(DMLTag,rel_type,&seccount,&secobjects));

																														if (seccount>0)
																														{
																															  REP1Flag  = 0;
																															  REP2Flag  = 0;
																															  REP3Flag  = 0;
																															  for(r=0;r<seccount;r++)
																															  {
																																	ITK_CALL(AOM_UIF_ask_value(secobjects[r],"object_type",&doctype));
																																	printf("\n doctype is: %s \n",doctype);fflush(stdout);
																																  
																																	ITK_CALL(AOM_UIF_ask_value(secobjects[r],"current_name",&docname));
																																	printf("\n docname is: %s \n",docname);fflush(stdout);
																																	if(tc_strstr(BomComInfo1,"BomPertge01") == NULL)
																																	{
																																		if(tc_strstr(docname,REP1)!=NULL)
																																		{
																																		  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP1Flag = 1;
																																		  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if(tc_strstr(docname,REP2)!=NULL) 
																																		{
																																		  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																																		  REP2Flag = 1;
																																		  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if(tc_strstr(docname,REP3)!=NULL)
																																		{
																																		  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP3Flag = 1;
																																		  printf("\n REP3Flag found :%d",REP3Flag); fflush(stdout);
																																		  //break;
																																		}
																																	}
																																	else
																																	{
																																		 printf("\nCheck both.. \n");fflush(stdout);
																																		if((tc_strstr(docname,REP1)!=NULL) || (tc_strstr(docname,"CORRECTNESS_Mod")!=NULL))
																																		{
																																		  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP1Flag = 1;
																																		  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if((tc_strstr(docname,REP2)!=NULL) || (tc_strstr(docname,"Dump_Mod")!=NULL))
																																		{
																																		  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																																		  REP2Flag = 1;
																																		  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																																		 // break;
																																		}
																																		if((tc_strstr(docname,REP3)!=NULL)||(tc_strstr(docname,"COMPLETENESS_Mod")!=NULL))
																																		{
																																		  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																																		  REP3Flag = 1;
																																		  printf("\n REP3Flag found :%d",REP3Flag); fflush(stdout);
																																		  //break;
																																		}
																																	}
																																  
																															  }
																														}
																														if ((REP1Flag>0)&& (REP2Flag>0)&& (REP3Flag>0))
																														{
																															  printf("\n************************ EPM_GO***************************** \n"); fflush(stdout);
																															  
																														}
																														else
																														{
																															  printf("\n Condition found"); fflush(stdout);
																															  printf("\n************************ REPFlag is not present***************************** \n"); fflush(stdout);
																															  printf("\n************************ EPM_NOGO***************************** \n"); fflush(stdout);
																															  EMH_clear_errors();
																															  EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"Please ensure to attach BOM_CORRECTNESS_Mod_REPORT, Data_Dump_Mod and BOM_COMPLETENESS_Mod_REPORT in 'References' relation to DML and then refresh worklist and signoff.");
																															  decision = EPM_nogo;
																															  return decision;	  
																														}
																													}
																													if(tc_strstr(BomComInfo1,"BOMComFlag") == NULL)
																													{
																														BOMCompFlag=1;
																													}
																													if(AOM_UIF_ask_value(rev_list[ii], "t5_BOMCmpl", &BOMComp)!=ITK_ok)PrintErrorStack();
																													printf("\n X30:BOMComp found: %s.", BOMComp);fflush(stdout);
																													printf("\n Prtrev_idd: %s rev_idd:%s",Prtrev_idd,rev_idd);fflush(stdout);

																													if((BOMComp==NULL) ||(tc_strcmp(BOMComp,"")==0))
																													{
																														//NULL case
																														printf("\n BOMCompis NULL, FAILED for veh DML.");fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should not be NULL. \nPlease get the BOM completeness report generated for attached vehicle/part. \nOption- Tools - Reports- BOM completeness and correctness report. \nIf the BOM accuracy value percentage is equal or above than below given percentage, then you can sign off this DML. \nBOM Completeness Percentage: ",BomComInfo2);	
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														if(tc_strstr(BomComInfo1,"BomCompVali3") == NULL)
																														{
																															STRNG_is_double(BOMComp,&dbl_BOMComp);
																															//dbl_BOMComp=atof(BOMComp);
																															printf(" X1:dbl_BOMComp: [%f]", dbl_BOMComp);fflush(stdout);
																															STRNG_is_double(BomComInfo2,&dbl_iBomComInfo2);
																															//dbl_iBomComInfo2=atof(BomComInfo2);
																															printf(" X2:dbl_iBomComInfo2: [%f]", dbl_iBomComInfo2);fflush(stdout);
																															if (tc_strcmp(BOMComp,"100")==0)
																															{
																																BOMCompFlag=0;
																																//break;
																																printf("\n P42:BOMComp is 100 percentage: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																															else if((dbl_BOMComp >dbl_iBomComInfo2 )||(dbl_iBomComInfo2 ==dbl_BOMComp))
																															{
																																BOMCompFlag=0;
																																//break;
																																printf("\n P62:BOMComp is 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																															else
																															{
																																BOMCompFlag=1;
																																printf("\n P72:BOMComp is not 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																															}
																														}
																														else
																														{
																															printf("\n BOM COM OFFF.");fflush(stdout);
																														}
																													}
																													break;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																						if (BOMCompFlag >0)
																						{
																							printf("\n A:BOMComp :%d",BOMCompFlag);fflush(stdout);
																							break;
																						}
																						//break for 0th object
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n B:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														else
														{
															//Blank value
															printf("\n FAILED for DML DR-ststus is NULL.");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML DR-status is NULL. \nPlease update valid AR/DR-status to DML: ",sDMLno);	
															decision = EPM_nogo;
															return decision;
														}
														//if(TaskCMRef) MEM_free(TaskCMRef);
														//if(rev_list) MEM_free(rev_list);
													}
												}
												//break;
											}
										}
									}
								}
							}
							if (BOMCompFlag >0)
							{
								printf("\n FAILED for GM DML.");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should be available on part and BOM completeness percantage should be equal or above than below given percentage.\nPlease get the BOM completeness report generated for attached VC. \nOption- Tools - Reports- BOM completeness and correctness report. \nBOM COmpleteness Percentage: ",BomComInfo2);	
								decision = EPM_nogo;
								return decision;
							}
							else
							{
								printf("\n PASSSS for GM DML.");fflush(stdout);
							}
						}
					}
				}
			}
			else if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
				printf("\n BOM:sDMLno:%s.",sDMLno);fflush(stdout);
				if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
				if(item_tag==NULLTAG)
				{
					printf("\n BOM:item_tag is NULL.\n");fflush(stdout);
					return decision;
				}
				else
				{
					printf("\n BOM:item_tag found.\n");fflush(stdout);
					if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
					if(DMLTag==NULLTAG)
					{
						printf("\n X3:Object not found in Teamcenter...!!\n");fflush(stdout);
						return decision;
					}
					else
					{
						//DML Details:
						if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
						printf("\n BOM: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
						tc_strcpy(sDMLrlstype,"");
						tc_strcpy(sDMLrlstype,",");
						tc_strcat(sDMLrlstype,DMLtype);
						tc_strcat(sDMLrlstype,",");
						printf("\n BOM:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
						tc_strcpy(sDMLDR,"");
						tc_strcpy(sDMLDR,",");
						tc_strcat(sDMLDR,DMLDR);
						tc_strcat(sDMLDR,",");
						printf("\n BOM:sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
						
						if(tc_strstr(BomComInfo1,sDMLno) != NULL)
						{
							printf("\nBOM:DML has been bypassed. \n");fflush(stdout);
						}
						else
						{
							if(tc_strstr(BomComInfo1,"DMLBomComp") == NULL)
							{
								if(tc_strstr(BomComInfo4,sDMLrlstype) != NULL)
								{
									if(tc_strcmp(DMLtype,"TODR")==0)
									{
										//if ((tc_strcmp(PlntToPlnt,"UPV2 to UPV3")==0) || (tc_strcmp(PlntToPlnt,"UNV3 to DR3")==0)|| (tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
										if(PlntToPlnt != NULL)
										{
											if(tc_strstr(BomComInfo3,PlntToPlnt) != NULL)
											{
												Tskcnt=0;
												if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
												printf("\n X22:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
												if (Tskcnt>0)
												{
													BOMCompFlag=0;
													for (tsk=0;tsk<Tskcnt ;tsk++ )
													{
														if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n X23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

														if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
														{
															if(TaskDsgGrp) TaskDsgGrp=NULL;
															if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
															TaskDsgGrp=subString(TskNm,11,2);
															printf("\n X24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

															if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
															if (tsk_CMRef_type!=NULLTAG)
															{
																CMRefcount=0;
																if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																printf("\n X25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																if(CMRefcount > 0)
																{
																	Mstr=0;
																	BOMCompFlag=0;
																	for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																	{
																		printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
																		if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																		if(strcmp(Prt_object_type,"Folder")!=0)
																		{
																			// put condition for desi rev , to avoid other attachments.
																			if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																			printf("\n X28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																			Item_count=0;
																			//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																			All_item_tag= t5GetItemRevison(PartMstr_no);
																			if(All_item_tag==NULLTAG)
																			{
																				printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																				//return 0;
																			}
																			else
																			{
																				if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																				printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																				if(Item_count > 0)
																				{
																					ii=0;
																					BOMCompFlag=0;
																					for(ii=Item_count-1;ii>=0;ii--)
																					{
																						rel_status_cunt=0;
																						if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																						if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																						if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																						printf("\n X31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																						//check revison
																						chkBOMComFlag=0;
																						printf("\n sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																						if((tc_strcmp(sPrtColInd,"N")==0)||(tc_strcmp(sPrtColInd,"Y")==0))
																						{
																							if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																							{
																								chkBOMComFlag=1;
																							}
																							else if(tc_strstr(BomComInfo1,"BomCompVali2") != NULL)
																							{
																								chkBOMComFlag=1;
																							}
																							printf("\n chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																							if(chkBOMComFlag >0)
																							{
																								tc_strcpy(sPartTyp,"");
																								tc_strcpy(sPartTyp,",");
																								tc_strcat(sPartTyp,PartTyp);
																								tc_strcat(sPartTyp,",");
																								printf("\n sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																								if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																								{
																									if(tc_strstr(BomComInfo1,"REP3") == NULL)
																									{
																										vehrev=tc_strtok(Prtrev_idd,";");
																									    printf(  "\n\t Design Revision vehrev = %s  \n",vehrev); fflush(stdout);


																										REP1 = MEM_alloc(50);
																										REP2 = MEM_alloc(50);
																										REP3 = MEM_alloc(50);

																										tc_strcat(REP1,PartMstr_no);
																										tc_strcat(REP1,"_");
																										tc_strcat(REP1,vehrev);
																										tc_strcat(REP1,"_BOM_CORRECTNESS_Mod_REPORT");
																										printf("\n REP1 is: %s \n",REP1);fflush(stdout);

																										tc_strcat(REP2,PartMstr_no);
																										tc_strcat(REP2,"_");
																										tc_strcat(REP2,vehrev);
																										tc_strcat(REP2,"_Data_Dump_Mod");
																										printf("\n REP2 is: %s \n",REP2);fflush(stdout);

																										tc_strcat(REP3,PartMstr_no);
																										tc_strcat(REP3,"_");
																										tc_strcat(REP3,vehrev);
																										tc_strcat(REP3,"_BOM_COMPLETENESS_Mod_REPORT");
																										printf("\n REP3 is: %s \n",REP3);fflush(stdout);

																										ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));

																										ITK_CALL(GRM_list_secondary_objects_only(DMLTag,rel_type,&seccount,&secobjects));

																										if (seccount>0)
																										{
																											  REP1Flag  = 0;
																											  REP2Flag  = 0;
																											  REP3Flag  = 0;
																											  for(r=0;r<seccount;r++)
																											  {
																													ITK_CALL(AOM_UIF_ask_value(secobjects[r],"object_type",&doctype));
																													printf("\n doctype is: %s \n",doctype);fflush(stdout);
																												  
																													ITK_CALL(AOM_UIF_ask_value(secobjects[r],"current_name",&docname));
																													printf("\n docname is: %s \n",docname);fflush(stdout);
																													if(tc_strstr(BomComInfo1,"BomPertge01") == NULL)
																													{
																														if(tc_strstr(docname,REP1)!=NULL) 
																														{
																														  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																														  REP1Flag = 1;
																														  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																														 // break;
																														}
																														if(tc_strstr(docname,REP2)!=NULL) 
																														{
																														  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																														  REP2Flag = 1;
																														  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																														 // break;
																														}
																														if(tc_strstr(docname,REP3)!=NULL)
																														{
																														  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																														  REP3Flag = 1;
																														  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																														  //break;
																														}
																												  }
																												  else
																												  {
																														if((tc_strstr(docname,REP1)!=NULL) || (tc_strstr(docname,"CORRECTNESS_Mod")!=NULL))
																														{
																														  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																														  REP1Flag = 1;
																														  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																														 // break;
																														}
																														if((tc_strstr(docname,REP2)!=NULL) || (tc_strstr(docname,"Dump_Mod")!=NULL))
																														{
																														  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																														  REP2Flag = 1;
																														  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																														 // break;
																														}
																														if((tc_strstr(docname,REP3)!=NULL) || (tc_strstr(docname,"COMPLETENESS_Mod")!=NULL))
																														{
																														  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																														  REP3Flag = 1;
																														  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																														  //break;
																														}
																												  }
																												  
																											  }
																										}
																										if ((REP1Flag>0)&& (REP2Flag>0)&& (REP3Flag>0))
																										{
																											  printf("\n************************ EPM_GO***************************** \n"); fflush(stdout);
																											  
																										}
																										else
																										{
																											  printf("\n Condition found"); fflush(stdout);
																											  printf("\n************************ REPFlag is not present***************************** \n"); fflush(stdout);
																											  printf("\n************************ EPM_NOGO***************************** \n"); fflush(stdout);
																											  EMH_clear_errors();
																											  EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"Please ensure to attach BOM_CORRECTNESS_Mod_REPORT, Data_Dump_Mod and BOM_COMPLETENESS_Mod_REPORT in 'References' relation to DML and then refresh worklist and signoff.");
																											  decision = EPM_nogo;
																											  return decision;	  
																										}
																									}
																									if(tc_strstr(BomComInfo1,"BOMComFlag") == NULL)
																									{
																										BOMCompFlag=1;
																									}
																									if(AOM_UIF_ask_value(rev_list[ii], "t5_BOMCmpl", &BOMComp)!=ITK_ok)PrintErrorStack();
																									printf("\n X30:BOMComp found: %s.", BOMComp);fflush(stdout);
																									if((BOMComp==NULL) ||(tc_strcmp(BOMComp,"")==0))
																									{
																										//NULL case
																										printf("\n BOMComp is NULL, FAILED for GM DML.");fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should not be NULL. \nPlease get the BOM completeness report generated for attached vehicle/part. \nOption- Tools - Reports- BOM completeness and correctness report. \nIf the BOM accuracy value percentage is equal or above than below given percentage, then you can sign off this DML. \nBOM COmpleteness Percentage: ",BomComInfo2);	
																										decision = EPM_nogo;
																										return decision;
																									}
																									else
																									{
																										if(tc_strstr(BomComInfo1,"BomCompVali3") == NULL)
																										{
																											STRNG_is_double(BOMComp,&dbl_BOMComp);
																											//dbl_BOMComp=atof(BOMComp);
																											printf(" X3:dbl_BOMComp: [%f]", dbl_BOMComp);fflush(stdout);

																											STRNG_is_double(BomComInfo2,&dbl_iBomComInfo2);
																											//dbl_iBomComInfo2=atof(BomComInfo2);
																											printf(" X4:dbl_BOMComp: [%f]", dbl_iBomComInfo2);fflush(stdout);
																											if (tc_strcmp(BOMComp,"100")==0)
																											{
																												BOMCompFlag=0;
																												//break;
																												printf("\n P14:BOMComp is 100 percentage: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																											else if((dbl_BOMComp >dbl_iBomComInfo2 )||(dbl_iBomComInfo2 ==dbl_BOMComp))
																											{
																												BOMCompFlag=0;
																												//break;
																												printf("\n P34::BOMComp is 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																											else
																											{
																												BOMCompFlag=1;
																												printf("\n P44:BOMComp is not 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																										}
																										else
																										{
																											printf("\n BOM COM Vali OFFFF.");fflush(stdout);
																										}
																									}
																									break;
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n P:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														if (BOMCompFlag >0)
														{
															printf("\n Q:BOMComp :%d",BOMCompFlag);fflush(stdout);
															break;
														}
													}
												}
											}
										}
										else
										{
											printf("\n FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);	
											decision = EPM_nogo;
											return decision;
										}

										//if(TaskCMRef) MEM_free(TaskCMRef);
										//if(rev_list) MEM_free(rev_list);
									}
									else
									{
										if(DMLDR != NULL)
										{
											//if ((tc_strcmp(DML_Milestone,"UPV3")==0) || (tc_strcmp(DMLDR,"AR3")==0)|| (tc_strcmp(DMLDR,"DR3")==0))
											if(tc_strstr(BomComInfo4,sDMLDR) != NULL)
											{
												Tskcnt=0;
												if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
												printf("\n X22:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
												if (Tskcnt>0)
												{
													BOMCompFlag=0;
													for (tsk=0;tsk<Tskcnt ;tsk++ )
													{
														if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n X23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

														if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
														{
															if(TaskDsgGrp) TaskDsgGrp=NULL;
															if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
															TaskDsgGrp=subString(TskNm,11,2);
															printf("\n X24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

															if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
															if (tsk_CMRef_type!=NULLTAG)
															{
																CMRefcount=0;
																if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																printf("\n X25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																if(CMRefcount > 0)
																{
																	Mstr=0;
																	BOMCompFlag=0;
																	for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																	{
																		printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
																		if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																		if(strcmp(Prt_object_type,"Folder")!=0)
																		{
																			// put condition for desi rev , to avoid other attachments.
																			if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																			if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																			printf("\n X28:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																			

																			Item_count=0;
																			//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																			All_item_tag= t5GetItemRevison(PartMstr_no);
																			if(All_item_tag==NULLTAG)
																			{
																				printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																				//return 0;
																			}
																			else
																			{
																				if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																				printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																				if(Item_count > 0)
																				{
																					ii=0;
																					BOMCompFlag=0;
																					for(ii=Item_count-1;ii>=0;ii--)
																					{
																						chkBOMComFlag=0;
																						rel_status_cunt=0;
																						if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																						if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																						if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																						printf("\n X31:Part %s rev:%s PartTyp:%s  Rel Status:%s sPartObjyp:%s sPrtColInd:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,sPrtColInd);fflush(stdout);
																						if((tc_strcmp(sPrtColInd,"N")==0)||(tc_strcmp(sPrtColInd,"Y")==0))
																						{
																							if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																							{
																								chkBOMComFlag=1;
																							}
																							else if(tc_strstr(BomComInfo1,"BomCompVali2") != NULL)
																							{
																								chkBOMComFlag=1;
																							}
																							printf("\n chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																							if(chkBOMComFlag >0)
																							{
																								tc_strcpy(sPartTyp,"");
																								tc_strcpy(sPartTyp,",");
																								tc_strcat(sPartTyp,PartTyp);
																								tc_strcat(sPartTyp,",");
																								printf("\n sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																								if(tc_strstr(BomComInfo5,sPartTyp) != NULL)
																								{

																									if(tc_strstr(BomComInfo1,"REP4") == NULL)
																									{
																										vehrev=tc_strtok(Prtrev_idd,";");
																										printf(  "\n\t Design Revision vehrev = %s  \n",vehrev); fflush(stdout);


																										REP1 = MEM_alloc(50);
																										REP2 = MEM_alloc(50);
																										REP3 = MEM_alloc(50);

																										tc_strcat(REP1,PartMstr_no);
																										tc_strcat(REP1,"_");
																										tc_strcat(REP1,vehrev);
																										tc_strcat(REP1,"_BOM_CORRECTNESS_Mod_REPORT");
																										printf("\n REP1 is: %s \n",REP1);fflush(stdout);

																										tc_strcat(REP2,PartMstr_no);
																										tc_strcat(REP2,"_");
																										tc_strcat(REP2,vehrev);
																										tc_strcat(REP2,"_Data_Dump_Mod");
																										printf("\n REP2 is: %s \n",REP2);fflush(stdout);

																										tc_strcat(REP3,PartMstr_no);
																										tc_strcat(REP3,"_");
																										tc_strcat(REP3,vehrev);
																										tc_strcat(REP3,"_BOM_COMPLETENESS_Mod_REPORT");
																										printf("\n REP3 is: %s \n",REP3);fflush(stdout);

																										ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));

																										ITK_CALL(GRM_list_secondary_objects_only(DMLTag,rel_type,&seccount,&secobjects));

																										if (seccount>0)
																										{
																											  REP1Flag  = 0;
																											  REP2Flag  = 0;
																											  REP3Flag  = 0;
																											  for(r=0;r<seccount;r++)
																											  {
																													ITK_CALL(AOM_UIF_ask_value(secobjects[r],"object_type",&doctype));
																													printf("\n doctype is: %s \n",doctype);fflush(stdout);
																												  
																													ITK_CALL(AOM_UIF_ask_value(secobjects[r],"current_name",&docname));
																													printf("\n docname is: %s \n",docname);fflush(stdout);
																													if(tc_strstr(BomComInfo1,"BomPertge01") == NULL)
																												  {
																													if(tc_strstr(docname,REP1)!=NULL) 
																													{
																													  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																													  REP1Flag = 1;
																													  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																													 // break;
																													}
																													if(tc_strstr(docname,REP2)!=NULL) 
																													{
																													  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																													  REP2Flag = 1;
																													  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																													 // break;
																													}
																													if(tc_strstr(docname,REP3)!=NULL)
																													{
																													  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																													  REP3Flag = 1;
																													  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																													  //break;
																													}
																												  }
																												  else
																												  {
																													  if((tc_strstr(docname,REP1)!=NULL) ||(tc_strstr(docname,"CORRECTNESS_Mod")!=NULL))
																													{
																													  printf("\n BOM_CORRECTNESS_Mod_REPORT attached found \n");fflush(stdout);
																													  REP1Flag = 1;
																													  printf("\n REP1Flag found:%d",REP1Flag); fflush(stdout);
																													 // break;
																													}
																													if((tc_strstr(docname,REP2)!=NULL) ||(tc_strstr(docname,"Dump_Mod")!=NULL))
																													{
																													  printf("\n Data_Dump_Mod attached found \n");fflush(stdout);
																													  REP2Flag = 1;
																													  printf("\n REP2Flag found:%d",REP2Flag); fflush(stdout);
																													 // break;
																													}
																													if((tc_strstr(docname,REP3)!=NULL)||(tc_strstr(docname,"COMPLETENESS_Mod")!=NULL))
																													{
																													  printf("\n BOM_COMPLETENESS_Mod_REPORT attached found \n");fflush(stdout);
																													  REP3Flag = 1;
																													  printf("\n REP3Flag found:%d",REP3Flag); fflush(stdout);
																													  //break;
																													}
																												  }
																												  
																											  }
																										}
																										if ((REP1Flag>0)&& (REP2Flag>0)&& (REP3Flag>0))
																										{
																											  printf("\n************************ EPM_GO***************************** \n"); fflush(stdout);
																											  
																										}
																										else
																										{
																											  printf("\n Condition found"); fflush(stdout);
																											  printf("\n************************ REPFlag is not present***************************** \n"); fflush(stdout);
																											  printf("\n************************ EPM_NOGO***************************** \n"); fflush(stdout);
																											  EMH_clear_errors();
																											  EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"Please ensure to attach BOM_CORRECTNESS_Mod_REPORT, Data_Dump_Mod and BOM_COMPLETENESS_Mod_REPORT in 'References' relation to DML and then refresh worklist and signoff.");
																											  decision = EPM_nogo;
																											  return decision;	  
																										}
																									}
																									if(tc_strstr(BomComInfo1,"BOMComFlag") == NULL)
																									{
																										BOMCompFlag=1;
																									}
																									if(AOM_UIF_ask_value(rev_list[ii], "t5_BOMCmpl", &BOMComp)!=ITK_ok)PrintErrorStack();
																									printf("\n X30:BOMComp found: %s.", BOMComp);fflush(stdout);
																									printf("\n Prtrev_idd: %s rev_idd:%s",Prtrev_idd,rev_idd);fflush(stdout);

																									if((BOMComp==NULL) ||(tc_strcmp(BOMComp,"")==0))
																									{
																										//NULL case
																										printf("\n BOMCompis NULL, FAILED for veh DML.");fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should not be NULL. \nPlease get the BOM completeness report generated for attached vehicle/part. \nOption- Tools - Reports- BOM completeness and correctness report. \nIf the BOM accuracy value percentage is equal or above than below given percentage, then you can sign off this DML. \nBOM Completeness Percentage: ",BomComInfo2);	
																										decision = EPM_nogo;
																										return decision;
																									}
																									else
																									{
																										if(tc_strstr(BomComInfo1,"BomCompVali3") == NULL)
																										{
																											STRNG_is_double(BOMComp,&dbl_BOMComp);

																											//dbl_BOMComp=atof(BOMComp);
																											printf(" X5:dbl_BOMComp: [%f]", dbl_BOMComp);fflush(stdout);

																											STRNG_is_double(BomComInfo2,&dbl_iBomComInfo2);
																											//dbl_iBomComInfo2=atof(BomComInfo2);
																											printf(" X6:dbl_BOMComp: [%f]", dbl_iBomComInfo2);fflush(stdout);
																											if (tc_strcmp(BOMComp,"100")==0)
																											{
																												BOMCompFlag=0;
																												//break;
																												printf("\n P45:BOMComp is 100 percentage: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																											else if((dbl_BOMComp >dbl_iBomComInfo2 )||(dbl_iBomComInfo2 ==dbl_BOMComp))
																											{
																												BOMCompFlag=0;
																												//break;
																												printf("\n P65:BOMComp is 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																											else
																											{
																												BOMCompFlag=1;
																												printf("\n P75:BOMComp is not 100 percentage:: %s:%d", BOMComp,BOMCompFlag);fflush(stdout);
																											}
																										}
																										else
																										{
																											printf("\n BOM COM Validation off.");fflush(stdout);
																										}
																									}
																									break;
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																		if (BOMCompFlag >0)
																		{
																			printf("\n A:BOMComp :%d",BOMCompFlag);fflush(stdout);
																			break;
																		}
																		//break for 0th object
																	}
																}
															}
														}
														if (BOMCompFlag >0)
														{
															printf("\n B:BOMComp :%d",BOMCompFlag);fflush(stdout);
															break;
														}
													}
												}
											}
										}
										else
										{
											//Blank value
											printf("\n FAILED for DML DR-ststus is NULL.");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML DR-status is NULL. \nPlease update valid AR/DR-status to DML: ",sDMLno);	
											decision = EPM_nogo;
											return decision;
										}
										//if(TaskCMRef) MEM_free(TaskCMRef);
										//if(rev_list) MEM_free(rev_list);
									}
								}
								//break;
							}
						}
					}
				}
				if (BOMCompFlag >0)
				{
					printf("\n FAILED for GM DML.");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"BOM completeness value should be available on part and BOM completeness percantage should be equal or above than below given percentage.\nPlease get the BOM completeness report generated for attached VC. \nOption- Tools - Reports- BOM completeness and correctness report. \nBOM COmpleteness Percentage: ",BomComInfo2);	
					decision = EPM_nogo;
					return decision;
				}
				else
				{
					printf("\n PASSSS for GM DML.");fflush(stdout);
				}
			}
		}
	}
	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(BomComInfo1){MEM_free(BomComInfo1);}
	if(BomComInfo2){MEM_free(BomComInfo2);}
	if(BomComInfo3){MEM_free(BomComInfo3);}
	if(BomComInfo4){MEM_free(BomComInfo4);}
	if(BomComInfo5){MEM_free(BomComInfo5);}
	if(sDMLtaskno){MEM_free(sDMLtaskno);}
	if(sDMLno){MEM_free(sDMLno);}
	if(DMLtype){MEM_free(DMLtype);}
	if(DMLProj){MEM_free(DMLProj);}
	if(PlntToPlnt){MEM_free(PlntToPlnt);}
	if(DMLDR){MEM_free(DMLDR);}
	if(Tsk_object_type){MEM_free(Tsk_object_type);}
	if(Prt_object_type){MEM_free(Prt_object_type);}
	if(PartMstr_no){MEM_free(PartMstr_no);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(Prtrel_status){MEM_free(Prtrel_status);}
	if(Partno){MEM_free(Partno);}
	if(PartTyp){MEM_free(PartTyp);}
	if(sPrtColInd){MEM_free(sPrtColInd);}
	if(rev_idd){MEM_free(rev_idd);}
	if(rel_status){MEM_free(rel_status);}
	if(BOMComp){MEM_free(BOMComp);}
	if(Dml_tasks){MEM_free(Dml_tasks);}
	if(Tsk_object_type){MEM_free(Tsk_object_type);}
	if(TskNm){MEM_free(TskNm);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(Prtrel_status){MEM_free(Prtrel_status);}*/
	printf("\n tm_BOMcompleteness Function end...");fflush(stdout);
	TC_write_syslog("\n tm_BOMcompleteness Function end...");
	return decision;
}
