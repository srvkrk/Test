/****************************************************************************************************
*  File            :   TML_CAE_Model.c
*  Created By      :   Vitthal Sangale
*  Created On      :   02/16/2018
*  Purpose         :   TML CAE Model
******************************************************************************************************/
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <user_exits/user_exits.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <tccore/item_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/aom_prop.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <tccore/workspaceobject.h>
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 4)

#define PLM_error (EMH_USER_error_base+25)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

extern DLLAPI int P_Name_Dynamic_lov_pre_action(METHOD_message_t *msg, va_list args);
extern DLLAPI int P_Name_Dynamic_lov_pre_condition(METHOD_message_t *msg, va_list args);
char* P_Name_prop_ask_function(char *input);

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		for( index=0; index<n_ifails; index++)
		{
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;   
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL; 
	                             
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

//Vitthal START:CAE MODEL
int Transfer_CAE_Object_Into_FL(tag_t tag_Item,char *sProjectName,char *sReqDomain,char *sDRGate)
{
	int   Status			 = ITK_ok;
	WSO_search_criteria_t criteria;
	tag_t *tag_Folder = NULLTAG;
	tag_t secObjLhTypeTag = NULLTAG;
	int n_items_f,iFolderCount;
	int iPostobeInsert=999;
	tag_t tagItem = NULLTAG;
	tag_t *tagItemTemp = NULLTAG;
	int *levels; 
	int n_referencers,n_refs=0,cnt=0;
	tag_t *referencers;
	WSO_description_t desc;
	char **relations=NULL;
	tag_t objTypeRefTag=NULLTAG;
	char type_name_ref[TCTYPE_name_size_c+1];
	int iFlag = 0;
	printf("CAE FOLDER STRUCTURE NOT FOUND ");fflush(stdout);

	WSOM_clear_search_criteria(&criteria);
	strcpy(criteria.name,sDRGate);
	strcpy(criteria.class_name,"Folder");
	WSOM_search(criteria,&n_items_f,&tag_Folder);
	for(iFolderCount=0;iFolderCount<n_items_f;iFolderCount++)
	{
			iFlag=0;
			tagItem=tag_Folder[iFolderCount];
			if(WSOM_where_referenced(tagItem, WSO_where_ref_any_depth,&n_refs,&levels,&referencers,&relations)!=ITK_ok)PrintErrorStack();
			printf("\n\t WSOM_where_referenced levels:%d n_refs: %d ",levels,n_refs); fflush(stdout);
			if (n_refs==4)
			{
				for (cnt=0;cnt<n_refs ;cnt++ )
				{
					
					 if(TCTYPE_ask_object_type(referencers[cnt],&objTypeRefTag))PrintErrorStack();
					if(TCTYPE_ask_name(objTypeRefTag,type_name_ref))PrintErrorStack();
					if (strcmp(type_name_ref,"Folder")==0)
					{
						 if (WSOM_describe(referencers[cnt], &desc) !=ITK_ok)   PrintErrorStack();
						  if(cnt==0 && (strcmp(desc.object_name,sReqDomain)==0))
							  iFlag++;
						  if(cnt==1 && (strcmp(desc.object_name,"CAE")==0))
						      iFlag++;
						  if(cnt==2 && (strcmp(desc.object_name,sProjectName)==0))
							  iFlag++;
			 
					}
				}
				printf("\n\t Request Domain:%s \n iFlag:%d",sReqDomain,iFlag); fflush(stdout);
				if(iFlag==3)
				{
					if(AOM_lock(tagItem))PrintErrorStack();
					FL_insert(tagItem,tag_Item,iPostobeInsert);
					if(AOM_save(tagItem))PrintErrorStack();
					if(AOM_unlock(tagItem));PrintErrorStack();
					if(AOM_refresh(tagItem,1))PrintErrorStack();
				}
			}
			else
			{ 
				printf("CAE FOLDER STRUCTURE NOT FOUND ");fflush(stdout);

			}
	}
	return 0;
}
char *Find_CAE_Model_Name(tag_t tag_ItemRev)
{
	int   Status			 = ITK_ok;
	int	  iArrSize=0,iAggr=0,iArrAttr=0;
	char* sItemId;
	char *sIteration;
	char *sDrGate;
	char *sProjectName;
	char *sReqDomain;
	char *sInterCAE;
	char *sProjectStage;
	char **sAgrValue;
	int max_char_size = 128;
	int count = 0;

	tag_t tsk_dml_rel_type;
	
	char *CAEItemID = NULL;
	CAEItemID=(char *) MEM_alloc(180);
	printf("Find_CAE_Model_Name(tag_t tag_ItemRev)  CAE ITEM NUMBER IS :");fflush(stdout);
	if( AOM_ask_value_string(tag_ItemRev,"item_id",&sItemId)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sIteration",&sIteration)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sIteration",&sIteration)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sProjectName",&sProjectName)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sReqDomain",&sReqDomain)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sDRGate",&sDrGate)!=ITK_ok);PrintErrorStack();
	
	strcpy(CAEItemID,"");
	strcat(CAEItemID,sProjectName);
	strcat(CAEItemID,"_");
	strcat(CAEItemID,sReqDomain);
	strcat(CAEItemID,"_");
	strcat(CAEItemID,sDrGate);
	strcat(CAEItemID,"_");
	strcat(CAEItemID,sIteration);
	printf("-------------->CAE ITEM NUMBER IS :%s",CAEItemID);fflush(stdout);
	
	for(iArrAttr=0 ; iArrAttr<3; iArrAttr++)
	{
		iAggr=0;
		iArrSize=0;
		strcat(CAEItemID,"_");
		if(iArrAttr==0)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_Aggregate",&iArrSize,&sAgrValue)!=ITK_ok);PrintErrorStack();
		if(iArrAttr==1)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_AnalysisType",&iArrSize,&sAgrValue)!=ITK_ok);PrintErrorStack();
		if(iArrAttr==2)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_LoadCase",&iArrSize,&sAgrValue)!=ITK_ok);PrintErrorStack();
		
		for(iAggr=0;iAggr<iArrSize;iAggr++)
		{
			strcat(CAEItemID,sAgrValue[iAggr]);
		}

	}
	printf("CAE ITEM NUMBER IS :%s",CAEItemID);fflush(stdout);
	return CAEItemID;
}
int UpdatePost_CAEModel_Name(tag_t tag_Item,tag_t tag_ItemRev)
{
	int   Status			 = ITK_ok;
	char *sCAEName			 = NULL;
	char *sProjectName;
	char *sReqDomain;
	char *sDRGate;
	tag_t status_rel		 = NULLTAG;
	logical	retain 			 = 0;

	sCAEName=Find_CAE_Model_Name(tag_ItemRev);
    	
	if(AOM_lock(tag_Item))PrintErrorStack();
	if(AOM_set_value_string(tag_Item,"item_id",sCAEName))PrintErrorStack();
//	if(CR_create_release_status("T5_LCS_CAEReview",&status_rel))PrintErrorStack();     
//	if(EPM_add_release_status(status_rel,1,&tag_ItemRev,retain))PrintErrorStack();  
	
	if(AOM_save(tag_Item))PrintErrorStack();
	if(AOM_unlock(tag_Item));PrintErrorStack();
	if(AOM_refresh(tag_Item,1))PrintErrorStack();
	if(AOM_refresh(tag_ItemRev,1))PrintErrorStack();

	if( AOM_ask_value_string(tag_ItemRev,"t5_sProjectName",&sProjectName)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sReqDomain",&sReqDomain)!=ITK_ok);PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sDRGate",&sDRGate)!=ITK_ok);PrintErrorStack();

	Transfer_CAE_Object_Into_FL(tag_Item,sProjectName,sReqDomain,sDRGate);
	return 0;
}
extern DLLAPI int Create_Post_Method_CAEModel(METHOD_message_t *m, va_list args)
{
	int   Status			 = ITK_ok;
	tag_t objTag;
	tag_t objTypeTag;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t objTagMaster = va_arg(args, tag_t);
	printf("Create_Post_Method_CAEModel(METHOD_message_t *m, va_list args)  CAE ITEM NUMBER IS");fflush(stdout);
	ITEM_ask_latest_rev  (objTagMaster, &objTag)  ;
	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok)PrintErrorStack();
    TC_write_syslog("In Create_Post_Method_CAEModel -----------> %s\n",type_name);

	if(strcmp(type_name,"T5_TMCAEModelRevision")==0)
	{
		UpdatePost_CAEModel_Name(objTagMaster,objTag);
	}
	return ITK_ok;
}
//int ValidateCAEObjectCreationAccess(tag_t tag_Item,tag_t tag_ItemRev)
//{
//	int   Status			 = ITK_ok;
//	tag_t user_tag			 = NULLTAG;
//	char *sUserName			 = NULL ;
//
//	POM_get_user(&sUserName,&user_tag);
//	printf("User Name is :%s",sUserName);fflush(stdout);
//
//
//
//	
//	return 0;
//}
extern DLLAPI int Create_Pre_Method_CAEModel(METHOD_message_t *m, va_list args)
{
	int   Status			 = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
 	const char *sCAEName			 = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	const char* item_id;
	const char* item_name;
	
	const char* rev_id ;
    tag_t*      new_item_tag=NULLTAG;
    tag_t*      new_rev_tag=NULLTAG;
	tag_t    tagItem=NULLTAG;
	tag_t    tagItemRev=NULLTAG;
	tag_t  	 itemCAE= NULLTAG ;
	tag_t	 objTypeTag;

	tagItem=new_item_tag[0];
	tagItemRev=new_rev_tag[0];
	printf("Create_Pre_Method_CAEModel CAE ITEM NUMBER IS ");fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
    if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
    if(strcmp(type_name,"T5_TMCAEModelRevision")==0)
	{
		// ValidateCAEObjectCreationAccess();
		 sCAEName=Find_CAE_Model_Name(objTag);
		 TC_write_syslog("ITEM NAME = %s\n",sCAEName);
		 ITEM_find_item(sCAEName,&itemCAE);
		 if(itemCAE==NULLTAG)
		 {
			 TC_write_syslog("ITEM NOT FOUND= %s\n",sCAEName);
		 }
		 else
		 {
			 printf("\n ITEM FOUND :%s\n ",sCAEName);fflush(stdout);
			 EMH_store_error_s2(EMH_severity_error,ITK_err,"\n CAE Item with same nomenclature is Already Present in DB \n",sCAEName);
			 return ITK_errStore;	
		 }
	}
	return ITK_ok;
}

int funPtr_EPM_action_handler_t(EPM_action_message_t msg)
{
	int				Status					= ITK_ok;
	tag_t			tag_rootTask			=NULLTAG;
	tag_t			*tag_Attachement		=NULLTAG;
	tag_t			tag_Temp_Attch		    = NULLTAG;
	char			*sObjectTaskName;
	char			*sCurrentName;
	char			*sObjectType,*sItemId,*sItr;
	char			*sObjectRootTaskName;
	int				iCountAttch = 0,i=0;

	printf("\n INSIDE THE funPtr_EPM_action_handler_t() ");fflush(stdout);
	//CALLAPI(EPM_ask_root_task(msg.task,&tag_rootTask));
	if(EPM_ask_root_task(msg.task,&tag_rootTask)!=ITK_ok);PrintErrorStack();
	if(AOM_ask_value_string(msg.task,"object_name",&sObjectTaskName)!=ITK_ok);PrintErrorStack();
	if(AOM_ask_value_string(tag_rootTask,"object_name",&sObjectRootTaskName)!=ITK_ok);PrintErrorStack();
	printf("\n ROOT TASK NAME IS  :%s\n TASK NAME IS: %s",sObjectRootTaskName,sObjectTaskName);fflush(stdout);

	if(EPM_ask_attachments(tag_rootTask,EPM_target_attachment,&iCountAttch,&tag_Attachement)!=ITK_ok);PrintErrorStack();
	printf("No of Attachemnt is:%d",iCountAttch);fflush(stdout);
	if(iCountAttch>0)
	{
		for(i=0;i<iCountAttch;i++)
		{
			tag_Temp_Attch= tag_Attachement[i];
			if(AOM_ask_value_string(tag_Temp_Attch,"object_name",&sCurrentName)!=ITK_ok);PrintErrorStack();
			if(AOM_ask_value_string(tag_Temp_Attch,"item_id",&sItemId)!=ITK_ok);PrintErrorStack();
			if(AOM_ask_value_string(tag_Temp_Attch,"object_type",&sObjectType)!=ITK_ok);PrintErrorStack();
			if (strcmp(sObjectType,"T5_TMCAEModelRevision")==0)
			{
				if(AOM_ask_value_string(tag_Temp_Attch,"t5_sIteration",&sItr)!=ITK_ok);PrintErrorStack();
				printf("t5_sIteration is:%s",sItr);fflush(stdout);
			}
		    printf("\nCurrent Name : %s \n Item IdL:%s \n Object Type:%s",sCurrentName,sItemId,sObjectType);fflush(stdout);
				
		}
	}

	return ITK_ok;

}
EPM_decision_t EPM_check_responsible_party(EPM_rule_message_t msg)
{
	int s;
	EPM_decision_t decision = EPM_nogo;
	char* userName;
	tag_t aUserTag, responsibleParty;

	s = EPM_ask_responsible_party(msg.task, &responsibleParty);
	if (responsibleParty, NULLTAG)
	{
		decision = EPM_go;
	}

	if(s == ITK_ok && decision == EPM_nogo)
	{
		s = POM_get_user (&userName, &aUserTag);
		MEM_free (userName);

		if (s == ITK_ok)
		{
			if (aUserTag, responsibleParty)
			decision = EPM_go;
		}
	}
	return decision;
}
//Vitthal:END:CAE MODEL 
extern int createpost_register_method_CAE(int *decision, va_list args)
{
    METHOD_id_t  method_TMCAEModelRev;
    METHOD_id_t  method_TMCAEModel;
	METHOD_id_t  method_id_CV,method_id_PV,method_id_PT;
	METHOD_id_t method_id_cond;
    *decision = ALL_CUSTOMIZATIONS;

    if ( METHOD_find_method("T5_TMCAEModel", TC_save_msg, &method_TMCAEModel) !=ITK_ok)   PrintErrorStack();
    if ( METHOD_find_method("T5_TMCAEModelRevision", IMAN_save_msg, &method_TMCAEModelRev) !=ITK_ok)   PrintErrorStack();
	// MADHUSUDAN : CAE_MODEL_LOV
	if ( METHOD_register_method("T5_CAEModelLovTypeCV",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_CV) !=ITK_ok)   PrintErrorStack();
	if ( METHOD_register_method("T5_CAEModelLovTypePV",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_PV) !=ITK_ok)   PrintErrorStack();
	if ( METHOD_register_method("T5_CAEModelLovTypePT",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_PT) !=ITK_ok)   PrintErrorStack();
	if ( METHOD_find_method("T5_TMCAEModelRevision","IMAN_save",&method_id_cond) !=ITK_ok)  PrintErrorStack();


	if (method_TMCAEModel.id != NULLTAG)
    {
        if( METHOD_add_action(method_TMCAEModel, METHOD_post_action_type, (METHOD_function_t) Create_Post_Method_CAEModel, NULL)!=ITK_ok)
        PrintErrorStack();
		printf("inside 'TML_CAE_Model' file , Registered as Create_Post_Method_CAEModel for Creation\n");fflush(stdout);
    }
    else
	{
		printf("method_TMCAEModel not found!\n");fflush(stdout);
	}

	if (method_TMCAEModelRev.id != NULLTAG)
    {
        if( METHOD_add_action(method_TMCAEModelRev, METHOD_pre_action_type, (METHOD_function_t) Create_Pre_Method_CAEModel, NULL)!=ITK_ok)
        PrintErrorStack();
		printf("inside 'TML_CAE_Model' file ,Registered as pre-Action for Creation method_TMCAEModelRev \n");fflush(stdout);
    }
    else
	{
        printf("method_TMCAEModelRev not found!\n");fflush(stdout);
	}

	if (method_id_cond.id != NULLTAG)
    {
        if( METHOD_add_pre_condition(method_id_cond,(METHOD_function_t)P_Name_Dynamic_lov_pre_condition,NULL)!=ITK_ok)
        PrintErrorStack();
		printf("inside 'TML_CAE_Model' file ,Registered as pre-condition for Creation method_id_cond \n");fflush(stdout);
    }
    else
	{
        printf("method_id_cond not found!\n");fflush(stdout);
	}

	// Action Handler Passing Param: Action Handler Name, Description,Function Ptr
	if(ITK_ok ==EPM_register_action_handler("caemanagerappr","CAEModel_Manager_Approval_Testing",funPtr_EPM_action_handler_t))
	{
		printf("inside 'TML_CAE_Model' file ,Registered as EPM_register_action_handler for caemanagerappr\n");fflush(stdout);
	}
	else
	{
		printf(" Fail to Register as EPM_register_action_handler for caemanagerappr\n");fflush(stdout);
	}
	//Rule Handler Passing Param:Handler Name , Desc , Function ptr
	if(ITK_ok==EPM_register_rule_handler("check_responsible_party","Success when logged in user is the responsible party for this task",EPM_check_responsible_party))
	{
		printf("inside 'TML_CAE_Model' file ,Registered as EPM_register_rule_handler for caemanagerappr\n");fflush(stdout);
	}
	else
	{
		printf(" inside 'TML_CAE_Model' file ,Fail to Register as EPM_register_rule_handler for caemanagerappr\n");fflush(stdout);
	}

    return ITK_ok;
}

extern DLLAPI int tm_caemodel_register_callbacks ()
{
	printf("\n\n createpost_register_callbacks ------------ \n\n");fflush(stdout);
    if(CUSTOM_register_exit ( "tm_caemodel", "USER_init_module", (CUSTOM_EXIT_ftn_t)  createpost_register_method_CAE) !=ITK_ok)
		PrintErrorStack();
  return ( ITK_ok );
}




// MADHUSUDAN CAE MODEL LOV CODE ***************

extern DLLAPI int P_Name_Dynamic_lov_pre_action(METHOD_message_t *msg, va_list args)
{
	tag_t lov_tag = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *info1_value,*subSyscdt_value,*Syscd_value,*token,*item_sequence_id,*Converter,*ValesforLov[10],*Input_Prop;
	int status;

    int ifail= ITK_ok,error_code = ITK_ok, n_entries = 2, c_count=0, n_found, ii, i,k;
	char *lov_name;
	

    tag_t query = NULLTAG, *cntr_objects = NULL;
 
      
	k=0;

	
	
	LOV_ask_name2(lov_tag,&lov_name);
	Input_Prop = P_Name_prop_ask_function(lov_name);
	printf("\n ******* Input Property is %s\n", Input_Prop);

	char *qry_entries[2] = {"SUBSYSCD","SYSCD"};
    char *qry_values[2]  =  {"CAE",Input_Prop};

	(QRY_find("KeyWordQry", &query));
	(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n Control objects Found qty: %d", n_found);fflush(stdout);

   for(i=0;i<n_found;i++)
   {
		( AOM_ask_value_string(cntr_objects[i],"t5_Userinfo1",&info1_value));

		token= tc_strtok(info1_value,";");
		
		while (token != NULL) 
		{ 
//			printf("\n ******* LOV_Value's are %s\n", token);
			ValesforLov[k]= token;
			token = tc_strtok(NULL,";");
			k++;
		}

		
		*n_values = k;
	//	 printf("\n n_values is: == %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < k ; ii++)
		{
			(*values)[ii] = (char *) MEM_alloc (strlen(ValesforLov[ii]) + 1);
			tc_strcpy((*values)[ii], ValesforLov[ii]);
		//	printf("\n LOV value is: %s",**values);fflush(stdout);

		}
		
		printf("\n Out of for loop LOV value is: %s",**values);fflush(stdout);
   }

return error_code;
}

extern DLLAPI int P_Name_Dynamic_lov_pre_condition(METHOD_message_t *msg, va_list args)
{
	tag_t object=va_arg(args, tag_t);

	int ifail;
	char *value;

	ifail=AOM_UIF_ask_value(object,"t5_sBusiness_Unit",&value);

	if(tc_strcmp(value,"Select BU")==0)
	{
		EMH_store_error_s2(EMH_severity_error,PLM_error,"Selected Business Unit is wrong","Please Select Proper Business Unit");
		printf("\n\n\t ******* Selected Business Unit is wrong *****\n");
		return(PLM_error);
	}
	else
	{
		printf("\n\n\t ******* Selected Business Unit is ok *****\n");
	}

	return 0;
}

char* P_Name_prop_ask_function(char* input)
{
	char *prop_value;
	if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNameCV")==0)
	{
		prop_value="CV";
		return prop_value;
	}
	else if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNamePV")==0)
	{
		prop_value="PV";
		return prop_value;
	}
	else if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNamePT")==0)
	{
		prop_value="PT";
		return prop_value;
	}
	
}