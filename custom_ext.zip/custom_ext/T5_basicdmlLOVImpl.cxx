//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_basicdmlLOVImpl

#include <T5_basicdml/T5_basicdmlLOV.hxx>
#include <T5_basicdml/T5_basicdmlLOVImpl.hxx>

#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <iostream.h>

#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_basicdmlLOVImpl::T5_basicdmlLOVImpl(T5_basicdmlLOV& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_basicdmlLOVImpl::T5_basicdmlLOVImpl( T5_basicdmlLOV& busObj )
   : T5_basicdmlLOVGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_basicdmlLOVImpl::~T5_basicdmlLOVImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_basicdmlLOVImpl::~T5_basicdmlLOVImpl()
{
}

//----------------------------------------------------------------------------------
// T5_basicdmlLOVImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_basicdmlLOVImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_basicdmlLOVGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int Get_Item_id_Addenda(const char *Project_code, const char *Design_group,int* count, tag_t** items)
{
        int ifail = ITK_ok;
        tag_t DML_addenda=NULLTAG;
	tag_t   Currproj        = NULLTAG;

		int nTwo = 2;
		int modCount = 0;
          char * curr_proj_name =NULL;
		char	*two_attr[] = {(char *)"Project Code",(char *)"Design Group"};

        char	*two_values[] = {(char *)Project_code,(char *)Design_group};
        //char * ErrorMessage1 = NULL;
		tag_t *moduleTags = NULLTAG;

		*count = 0;
		int i=0;


        printf("\n\n Get_Item_id_Addenda::Project_code==%s \n",Project_code);fflush(stdout);
        printf("\n\n Get_Item_id_Addenda::Design_group==%s \n",Design_group);fflush(stdout);


	//ErrorMessage1 = (char *)MEM_alloc(300);

       // tc_strcpy(ErrorMessage1,"DML Project is not \n as per Session Project Code.");

	/*SA_ask_current_project ( &Currproj );
	if ( Currproj != NULLTAG )
	{
	   	AOM_ask_value_string(Currproj,"object_name",&curr_proj_name);
	}
	printf ("\nSESSIONPRJ:curr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;
	TC_write_syslog ("\nSESSIONPRJ:curr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout );
        if(tc_strcmp(curr_proj_name,Project_code) == 0)
	{
		printf("\n:SESSIONPRJ:curr_proj_name and DML_Project_Code are same..................");fflush(stdout);
	}
	else
	{
		printf("\n ERROR-DML not found in Teamcenter.\n");fflush(stdout);
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,PLM_error1,ErrorMessage1);
		return(PLM_error1);
	}*/




		QRY_find2("DML_Addenda", &DML_addenda);


		if (DML_addenda)
		{


				//two_values[0] = (char*)MEM_alloc(tc_strlen(Project_code) + 1);
				//tc_strcpy(two_values[0], Project_code);

				//two_values[1] = (char*)MEM_alloc(tc_strlen(Design_group) + 1);
				//tc_strcpy(two_values[1], Design_group);


				QRY_execute(DML_addenda, nTwo, two_attr, two_values, &modCount, &moduleTags);

				printf("\n\n Get_Item_id_Addenda::modCount==%d \n",modCount);fflush(stdout);

				printf("\n\n Get_Item_id_Addenda::Rows555==%s %d\n",Project_code,modCount);fflush(stdout);
				*count = modCount;


				printf("\n\n Get_Item_id_Addenda::Rows1000 VAL= %d\n",*count);fflush(stdout);
				(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));

				for(i=0;i<*count;i++)
					{
							(*items)[i] = moduleTags[i];
					}


		}



                return ifail;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_basicdmlLOVImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;


        bool isNull1=false;
	tag_t Currproj = NULLTAG;
        //bool isNull2=false;

        char *ErrorMessage = NULL;
       char * ErrorMessage1 = NULL;
       char * curr_proj_name = NULL;
        	std::string obj_val1;
        	std::vector<std::string> obj_val2;
			std::vector<int> lovnullist;

        	//sortOrder=0;
        	int error_flag = 0;
        	*nResults=0;
        	(*results)=NULLTAG;
        	//(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
        	printf("\n--->>>>> T5_basicdmlLOVImpl::In NOT NULL 11111111");fflush(stdout);

        	ErrorMessage = (char *)MEM_alloc(300);
		ErrorMessage1 = (char *)MEM_alloc(300);

        	if( JOURNAL_is_journaling() )
        		        {
        		            //JOURNAL_routine_start( "T5_DMLReasonCodeLOVImpl::fnd0askLOVValuesBase" );
        		            JOURNAL_routine_start( "T5_basicdmlLOVImpl::fnd0askLOVValuesBase" );
        		           // JOURNAL_address_in( impl );
        		            JOURNAL_routine_call();
        		        }

    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation

    printf("\n  T5_basicdmlLOV Starting Testing !!!>>\n");fflush(stdout);
        						try
            	                {
            	            //  list_displayable_properties_with_value(operationInputTag);
            	                        Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
            	                        (Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
            	                        if( refOprtnInput!=NULL )
            	                        {

            	                                refOprtnInput->getString("t5_cprojectcode", obj_val1, isNull1 ); ///get properties from the object
            	                                refOprtnInput->getStringArray("t5_crdesigngroup", obj_val2, lovnullist ); ///get properties from the object

												printf("\n**********************");fflush(stdout);

												//printf("\nobj_val2[0] : [%s]",obj_val2[0].c_str());fflush(stdout);
												//printf("\nobj_val2 : [%zd]",lovnullist.size());fflush(stdout);

            	                                //cout << "Values are: ";
            	                               // cout << obj_val2.size() << " ";

            	                               // cout << "0 th Values is: ";
            	                               // cout << obj_val2[0] << " ";


            	                                tc_strcpy(ErrorMessage,"Please select Below Required Fields\n");	///ashwani
						
						tc_strcpy(ErrorMessage1,"Please select correct session project code\n");




						SA_ask_current_project ( &Currproj );
					        if ( Currproj != NULLTAG )
       						 {
      						          AOM_ask_value_string(Currproj,"object_name",&curr_proj_name);
       						 }
       						 printf ("\nSESSIONPRJ:curr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;

					        TC_write_syslog ("\nSESSIONPRJ:curr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout );

						if(tc_strcmp(curr_proj_name,obj_val1.c_str()) == 0)
       						 {
               						 printf("\n:curr_proj_name and DML_Project_Code are same..................");fflush(stdout);
        					}
					        else
       						 {
							 EMH_clear_errors();
                                                        EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage1);
                                                        (*results)=NULLTAG;
                                                        *nResults=0;
                                                        return(PLM_error1);
							 
						}
	
            	                                if(isNull1==true)
            	                                {
            	                                	error_flag++;
            	                                	tc_strcat(ErrorMessage,",Project Code");
            	                                	//EMH_clear_errors();
    												//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Project Code First.!!");
    												//(*results)=NULLTAG;
    												//*nResults=0;
    												//return ITK_err;
            	                                }

            	                                if(lovnullist.size()==0)
            	                                {
            	                                	error_flag++;
            	                                	tc_strcat(ErrorMessage,",Design Group");
            	                                	//EMH_clear_errors();
    												//EMH_store_error_s1(EMH_severity_error,ITK_err, "Design Group");
    												//(*results)=NULLTAG;
    												//*nResults=0;
    												//return ITK_err;
            	                                }


            	                                printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
            	                                if(error_flag>0)
            	                                {
            	                                	//tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Reason!\n");
            	                                	//tc_strcat(ErrorMessage,"Project Code,Release Type,Business Unit,Vehicle Classification,DR Status,Part Status/Site change [From-To]");
            	                                	EMH_clear_errors();
            	                                	EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);
            	                                	(*results)=NULLTAG;
            	                                	*nResults=0;
            	                                	return(PLM_error1);
            	                                }
            	                                if(error_flag==0)
            	                                {
            	                                	printf("\n Before Call T5_basicdmlLOV::Get_Item_id_Addenda");fflush(stdout);

													printf("\nGiven project Code  -->[%s] >>\n",obj_val1.c_str());fflush(stdout);
													printf("\nGiven Design Group  -->[%s] >>\n",obj_val2[0].c_str());fflush(stdout);

													(*results)=NULLTAG;
													*nResults=0;
													(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
													Get_Item_id_Addenda(obj_val1.c_str(),obj_val2[0].c_str(),nResults, results);

            	                                }
            	                        }
            	                        else
    									{
            	                        	printf("\n--->>>>> T5_basicdmlLOV::In  NULL refinputtag");fflush(stdout);
    									}

            	                   }
    								catch( const IFail& ex )
    								{
    								   ifail = ex.ifail();
    								}

    return ifail;
}
