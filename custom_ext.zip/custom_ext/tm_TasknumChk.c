#include "TMLLibrary_server_exits.h"


extern EPM_decision_t DLLAPI tm_TasknumChk(EPM_rule_message_t msg)
{
    int   no_attach = 0;
    int   i         = 0;
    int   j         = 0;
    int   count     = 0;
    int   countt     = 0;

	char* sTSKInfo1 = NULL;
	char* sTSKInfo2 = NULL;
	char* sTSKInfo3 = NULL;
	char* sTSKInfo4 = NULL;
	char* DMLid     = NULL;
	char* DMLtype     = NULL;
	char* sDMLDR     = NULL;
	char* sErcDmlBU     = NULL;
	char* objTypeofDML     = NULL;
	char* taskid     = NULL;
	char* DMLNo     = NULL;

	tag_t roottask			 = NULLTAG;
	tag_t DMLRevTag			 = NULLTAG;
	tag_t query			     = NULLTAG;
	tag_t objTypTag			     = NULLTAG;
	tag_t tsk_dml_rel_type			     = NULLTAG;
	tag_t DMLtsk_tag			     = NULLTAG;

	tag_t *Attachments	     = NULLTAG;
	tag_t *contrlObjs	     = NULLTAG;
	tag_t *DMLTsk	     = NULLTAG;

	logical is_latest;

	EPM_decision_t decision = EPM_go;


	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_TasknumChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_TasknumChk Function started...");

	if(EPM_ask_root_task(msg.task,&roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach,&Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_TasknumChk No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_TasknumChk:INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="TSKCHK";

				ITK_CALL(QRY_find2("Control Objects...",&query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_TasknumChk Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sTSKInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sTSKInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sTSKInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sTSKInfo4));
					printf("\n tm_TasknumChk L1:sTSKInfo1 is : [%s]  L2:sTSKInfo2 is : [%s]  L3:sTSKInfo3 is : [%s] L4:sTSKInfo4 is : [%s]\n",sTSKInfo1,sTSKInfo2,sTSKInfo3,sTSKInfo4);fflush(stdout);

					if(tc_strstr(sTSKInfo1,"TANOFF1") == NULL)
					{
						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_TasknumChk objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofDML));
						printf("\n tm_TasknumChk objTypeofDML is %s\n", objTypeofDML);fflush(stdout);

						if(tc_strcmp(objTypeofDML,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLid));
							printf("\n  tm_TasknumChk DMLid is %s\n", DMLid);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
							printf("\n  tm_TasknumChk t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
							printf("\n  tm_TasknumChk sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&sErcDmlBU));
							printf("\n  tm_TasknumChk sErcDmlBU is %s\n", sErcDmlBU);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_TasknumChk--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
							   printf("\n tm_TasknumChk--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tsk_dml_rel_type));
								if (tsk_dml_rel_type!=NULLTAG)
								{
									//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
									ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,tsk_dml_rel_type,&countt,&DMLTsk));
									printf("\n tm_TasknumChk:DML Revision from Task for : %d",countt);fflush(stdout);

									for (j=0;j<countt ;j++)
									{
										DMLtsk_tag=DMLTsk[j];

										ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid));
										printf("\n tm_TasknumChk taskid = %s \n",taskid);fflush(stdout);

										DMLNo=subString(taskid,0,10);
										printf("\n tm_TasknumChk DMLNo = %s \n",DMLNo);fflush(stdout);

										if(tc_strcmp(DMLid,DMLNo)!=0)
										{
											printf("\n tm_TasknumChk DMLid and DMLNo --are not same \n"); fflush(stdout);

											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,"\n DML and Task number should be same. Please ABORT DML, remove wrong task and then resubmit DML.");
											decision = EPM_nogo;
											return decision;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_TasknumChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_TasknumChk Function end...");
	return decision;
}