//@<COPYRIGHT>@
//==================================================
//Copyright $2024.

//Siemens Product Lifecycle Management Software Inc.

//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_AutoPPPMPrjCodeLovBOImpl
//

#include <T5_RFISORCODEFL/T5_AutoPPPMPrjCodeLovBOImpl.hxx>

#include <fclasses/tc_string.h>
//#include <tc/tc.h>


#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
//#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;


//----------------------------------------------------------------------------------
// T5_AutoPPPMPrjCodeLovBOImpl::T5_AutoPPPMPrjCodeLovBOImpl(T5_AutoPPPMPrjCodeLovBO& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_AutoPPPMPrjCodeLovBOImpl::T5_AutoPPPMPrjCodeLovBOImpl( T5_AutoPPPMPrjCodeLovBO& busObj )
   : T5_AutoPPPMPrjCodeLovBOGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_AutoPPPMPrjCodeLovBOImpl::~T5_AutoPPPMPrjCodeLovBOImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_AutoPPPMPrjCodeLovBOImpl::~T5_AutoPPPMPrjCodeLovBOImpl()
{
}

//----------------------------------------------------------------------------------
// T5_AutoPPPMPrjCodeLovBOImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_AutoPPPMPrjCodeLovBOImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_AutoPPPMPrjCodeLovBOGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///

int Get_autosor_PPPM_prjCode(const char *Project_code,int* count, tag_t** items)
{
        int ifail = ITK_ok;
        tag_t Query=NULLTAG;

		int nOne = 1;
		int nCount = 0;
		char* one_attr[1] = {(char *)"Barrel Code"};


		char *one_values[] = {(char *)Project_code};

		tag_t *nTags = NULLTAG;

		*count = 0;
		int i=0;


		TC_write_syslog("\nGet_autosor_PPPM_prjCode::Project_code : [%s]\n",Project_code);fflush(stdout);


		QRY_find2("SOR_Barrel", &Query);


		if (Query)
		{


				QRY_execute(Query, nOne, one_attr, one_values, &nCount, &nTags);

				TC_write_syslog("\nGet_autosor_PPPM_prjCode::nCount : [%d] \n",nCount);fflush(stdout);

				TC_write_syslog("\nGet_autosor_PPPM_prjCode::Rows : [%s] [%d]\n",Project_code,nCount);fflush(stdout);
				*count = nCount;


				TC_write_syslog("\n\nGet_autosor_PPPM_prjCode::Rows1000 VAL : [%d]\n",*count);fflush(stdout);
				(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));

				for(i=0;i<*count;i++)
					{
							(*items)[i] = nTags[i];
					}


		}


                return ifail;
}

int  T5_AutoPPPMPrjCodeLovBOImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;
    bool isNull1=false;
    char *ErrorMessage = NULL;

	std::string obj_val1;

	int error_flag = 0;
	*nResults=0;
	(*results)=NULLTAG;

	TC_write_syslog("\nT5_AutoPPPMPrjCodeLovBOImpl::In NOT NULL");fflush(stdout);

	ErrorMessage = (char *)MEM_alloc(300);

	if( JOURNAL_is_journaling() )
	{
		JOURNAL_routine_start( "T5_AutoPPPMPrjCodeLovBOImpl::fnd0askLOVValuesBase" );

		JOURNAL_routine_call();
	}

    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation
    TC_write_syslog("\nT5_AutoPPPMPrjCodeLovBOImpl Starting Testing\n");fflush(stdout);
	try
	{
		//  list_displayable_properties_with_value(operationInputTag);
		Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
		(Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
		if( refOprtnInput!=NULL )
		{

				refOprtnInput->getString("t5_BarrelCode", obj_val1, isNull1 ); ///get properties from the object

				tc_strcpy(ErrorMessage,"Please select Below Required Fields\n");

				if(isNull1==true)
				{
					error_flag++;
					tc_strcat(ErrorMessage,"Project Code");

				}

				TC_write_syslog("\nerror_flag : [%d]\n",error_flag);fflush(stdout);
				if(error_flag>0)
				{
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message : ",ErrorMessage);
					(*results)=NULLTAG;
					*nResults=0;
					return(PLM_error1);
				}
				if(error_flag==0)
				{
					TC_write_syslog("\nBefore Call T5_AutoPPPMPrjCodeLovBOImpl::Get_PPPM_prjCode");fflush(stdout);

					TC_write_syslog("\nProject Code : [%s]\n",obj_val1.c_str());fflush(stdout);

					(*results)=NULLTAG;
					*nResults=0;
					(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
					Get_autosor_PPPM_prjCode(obj_val1.c_str(),nResults, results);

				}
		}
		else
		{
			TC_write_syslog("\nT5_AutoPPPMPrjCodeLovBOImpl::In  NULL");fflush(stdout);
		}

	}

	catch( const IFail& ex )
	{
	   ifail = ex.ifail();
	}


    return ifail;
}
