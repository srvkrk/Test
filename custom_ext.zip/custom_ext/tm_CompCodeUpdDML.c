/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_CcompCodeUpdDML.c
*
* Description		: > This is related to Col Indicator /Comp Code update process in TCUA .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 21/04/2025   	Sanjoy Mondal			    change as per Teamcenter 14.3
* 

* -----------------------------------------------------------------------------
*
*****************************************************************************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <property/idgeneration.h>
#include <Fnd0Participant/participant.h>
#include <tccore/item_msg.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 401)
#define MAX_LINE_LEN 1024

#define ITK_err 919002
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}




		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

int getPartMstrObj(char *partNumber, char *object_type, tag_t *partMaster)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n getPartMstrObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*partMaster = itemObj[count-1];
	}
	
	return ifail;
}

int t5IsUpdateCompCodeClientCodeLogic(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "UpdCompCodeClient";
	qry_values[1] = "UpdCompCodeClient";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nCompCode:Control objects UpdCompCodeClient: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{					
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}
//Get latest parts WIP(if any) and latest Released
int getLatestReleasedAndWIPPart(tag_t partMaster,int *cnt, tag_t **partlist)
{
	int ifail = ITK_ok;
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULL;
	tag_t partRevTag = NULLTAG;
	printf("\nStart of function ==> getLatestPartNew");fflush(stdout);
	if(partMaster == NULLTAG)
	{
		printf("\nDesign Master===> NULLTAG.Exit--> please check with admin");fflush(stdout);
		return ifail;
	}
	
	CALLAPI(ITEM_list_all_revs (partMaster, &partRevCnt, &partRevTagObjs));
	printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
	
	if(partRevCnt>0)
	{
		int i=0;

		for(i=partRevCnt-1;i>=0;i--)
		{
			partRevTag = partRevTagObjs[i];
			char* itemId = NULL;
			char* partRev = NULL;
			char* checkedOut = NULL;
			char* rel_status = NULL;
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))
			
			//checked_out
			CALLAPI(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
			printf("\ngetLatestPartNew - Part object[%d]==>  %s,%s. Checkedout==>%s, Release status==>%s\n",i,itemId,partRev,checkedOut,rel_status);fflush(stdout);
			
			//Skip the checked out part
			if(tc_strcmp(checkedOut, "Y") == 0 )
			{
				continue;
			}
			setAddTagObj(cnt,partlist,partRevTag);
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				break;
			}
			
					
		}

	}
	 
	
	return ifail;
}

int tmCompCodeRelatePrimaryWithSecondaryObj(tag_t primaryTag, tag_t secondaryTag, char* relation )
{
	int ifail = ITK_ok;
	tag_t relation_type = NULLTAG;
	tag_t primSecRelation = NULLTAG;
	CALLAPI(GRM_find_relation_type(relation,&relation_type));
	if(relation_type!=NULLTAG)
	{
		CALLAPI(GRM_create_relation(primaryTag, secondaryTag, relation_type,  NULLTAG, &primSecRelation));
		CALLAPI(GRM_save_relation(primSecRelation));
	}
	else
	{
		printf("\nCompCode:No relation %s exists...Please check. Very serious error.\n",relation);fflush(stdout);
	}
	 
	return ifail;
}



EPM_decision_t tm_CompCodeUpdLCSignOffVald( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_nogo;
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;	
	
	int targetobjects_count = 0;
	
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);	
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))	
	if(targetobjects_count>0)
	{
		int i =0;
		tag_t objectTypeTag = NULLTAG;
		char  	*type_name = NULL;
		tag_t taskObj = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			taskObj = targetobjects[i];
			CALLAPI(TCTYPE_ask_object_type (taskObj, &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
			{
				int partCnt = 0;
				int j = 0;
				tag_t* partTagObjects = NULL;
				char* dmlTaskName = NULL;
				tag_t cntrlObj = NULLTAG;
				
				CALLAPI(AOM_ask_value_string(taskObj,"item_id",&dmlTaskName));
				printf("\nDML Task Name:%s\n",dmlTaskName);fflush(stdout);
				
				ifail = t5IsUpdateCompCodeClientCodeLogic(&cntrlObj);
				
				if(cntrlObj!=NULLTAG)
				{
					
					char* userInfo1	=	NULL;
					char* userInfo2	= 	NULL;
					char* userInfo3	=	NULL;
					char* userInfo4	=	NULL;
					char* userInfo5	=	NULL;
					char* userInfo6	=	NULL;
					char* userInfo7	=	NULL;
					char* userInfo8	=	NULL;
					char* userInfo9	=	NULL;
					
					
					
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//client logic
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path of client code
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//Relation of DML Task
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
					
					
					
					printf("\nCompCode UpdCompCodeClient-UpdCompCodeClient Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
					
					
					
					if(tc_strstr(userInfo3,",References,")!= NULL)
					{
						//ifail = t5UpdateCompCodeForPartsFn(dmlTag,"IMAN_reference");
						CALLAPI(AOM_ask_value_tags(taskObj,"IMAN_reference",&partCnt,&partTagObjects));
					}
					else if(tc_strstr(userInfo3,",Change References,")!= NULL)
					{
						
						CALLAPI(AOM_ask_value_tags(taskObj,"CMReferences",&partCnt,&partTagObjects));
					}
					else
					{
						CALLAPI(AOM_ask_value_tags(taskObj,"IMAN_reference",&partCnt,&partTagObjects));
					}					
					
				}
				else
				{
					CALLAPI(AOM_ask_value_tags(taskObj,"IMAN_reference",&partCnt,&partTagObjects));
				}
				
				
				printf("\nPart Count:%d\n",partCnt);fflush(stdout);
				
				if(partCnt<=0)
				{
					printf("\n No Part attached to task %s",dmlTaskName);fflush(stdout);
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerErr1;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "No Part is attached to the DML Task %s. Please attach the Part in References folder then sign off.", dmlTaskName);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;
				}
				else
				{
					
					decision = EPM_go;
				}
				
				
				
			}
		}
	}
	
	return decision;
}

EPM_decision_t tm_CheckDMLRelzTypeFunc( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_nogo;
	int ifail = ITK_ok;
	int arg_cnt = 0;
	int indx = 0;
	char *value = NULL;
	char *flag  = NULL;
	char *release_type = NULL;
	char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_CheckDMLRelzTypeFunc";
	if(ifail == ITK_ok)
	{
		arg_cnt = TC_number_of_arguments(msg.arguments);
	}
	if((arg_cnt > 1) && (ifail == ITK_ok) )
    {
        //ifail = EPM_wrong_number_of_arguments;
        //EMH_store_error( EMH_severity_error, ifail );
		printf("\n Wrong number of arguments..");fflush(stdout);
		//char* buff = NULL;
		ifail=T5_WorkFlowHandlerErr;
		//buff = (char*)MEM_alloc(200*sizeof(char));
		//sprintf(buff, "Wrong number of arguments");
		EMH_store_error_s1(EMH_severity_error,ifail,"Wrong number of arguments");
		decision = EPM_nogo;
		//if(buff)MEM_free(buff);
		return decision;
    }
	for(indx = 0; indx < arg_cnt && ifail == ITK_ok; indx++ )
    {
		ifail = ITK_ask_argument_named_value( TC_next_argument(msg.arguments), &flag, &value );
		if(ifail == ITK_ok)
		{
			if(tc_strcasecmp(flag, "release_type") == 0)
			{
				if( value != NULL )
                {
                    release_type = (char*) MEM_alloc(( strlen(value) + 1) * sizeof(char));
                    tc_strcpy(release_type,value);
                }
			}
			else
			{
				printf("\n Invalid argument..");fflush(stdout);
				ifail=T5_WorkFlowHandlerErr;
				EMH_store_error_s1(EMH_severity_error,ifail,"Invalid argument..");
				decision = EPM_nogo;
				return decision;
			}
			if( value != NULL )
            {
                MEM_free(value);
            }
            
            if( flag != NULL )
            {
                MEM_free(flag);
            }
		}
	}	
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	if(targetobjects_count > 0)
	{
		int i =0;
		tag_t objectTypeTag = NULLTAG;
		char  	*type_name = NULL;
		char* dmlReleaseType = NULL;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nDML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				

			
			
				//COL - Comp Code and Colour Indicator update
				if((tc_strcmp(dmlReleaseType,release_type)!=0))
				{
					printf("\n DML with release type release_type can only proceed", release_type);fflush(stdout);
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "DML having release type as %s is not allowed.\n Only DML with release type %s is allowed", dmlRelTypeDisplayStr, release_type);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;
				}
				else
				{
					
					decision = EPM_go;
				}
				
				
					
			}
		}
	}
	
	
	return decision;
	
}

int getControlObjForDynamicParticipant(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  getControlObjForDynamicParticipant...\nCheck for control object CedPrtCre-CedPrtCre....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CedPrtCre";
	qry_values[1] = "CedPrtCre";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CedPrtCre-CedPrtCre: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&name));
			CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			printf("\nName:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s\n",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			
			
			*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}

int removeEntryOfControlObjCompCode(char* dmlNo, char* partNo)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n DML No ===> [%s]\n",dmlNo);fflush(stdout);
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "CmpCdUpd";
	qry_values[1] = "dml";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects: count==>%d", count);fflush(stdout);	
	//T5_ControlObject
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\n Control object ===>%s", cntrlStr);
		}
		
	}
	
	
	return ifail;
}




int t5UpdateCompCodeForPartsFn(tag_t dmlTag, char* relationShipStr)
{
	
	int ifail = ITK_ok;
	char* dmlNo = NULL;
	
	CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
	printf("\nTarget Object is ERC DML Revision==>%s, relationship:[%s] ",dmlNo,relationShipStr);fflush(stdout);
	
	int dsCnt=0;
	tag_t* dataSetTagObjects = NULL;
	int n =0;
	char* ds_object_type = NULL;
	int flag = 0;
	CALLAPI(AOM_ask_value_tags(dmlTag,"CMReferences",&dsCnt,&dataSetTagObjects));
	if(dsCnt<=0)
	{
		printf("\nNo DataSet attached to the dml. ");fflush(stdout);
		return ITK_ok;
	}
	char  *refname = NULL;
	AE_reference_type_t     reftype;
	tag_t                   refobject;
	char* orig_name = NULL;
	char *fileLoc = NULL;
	//int f=0;
	for(n=0;n<dsCnt;n++)
	{
		CALLAPI(AOM_ask_value_string(dataSetTagObjects[n],"object_type",&ds_object_type));
		printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
		if(tc_strcmp(ds_object_type,"Text")==0)
		{

			 CALLAPI(AE_find_dataset_named_ref2(dataSetTagObjects[n],0,&refname, &reftype,&refobject));
			 if(refobject==NULLTAG) continue;			 
			 flag++;
		}
	}

	if(flag==0)
	{
		printf("\n No text file attached to the dml. ");fflush(stdout);
		return ITK_ok;
	}
	
	tag_t *dmlTaskTagObjects = NULL;
	tag_t dmlTaskTag = NULLTAG;
	int taskCnt = 0;
	CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
	printf("\nERC Task Count:%d\n",taskCnt);fflush(stdout);
	if(taskCnt>0)
	{
		int i=0;
		char* object_type = NULL;
		for(i=0;i<taskCnt;i++)
		{
			 CALLAPI(AOM_ask_value_string(dmlTaskTagObjects[i],"object_type",&object_type));
			 printf("\n object_type is :%s\n",object_type);fflush(stdout);
			 if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
			 {
				 int partCnt=0;
				 tag_t *partTagObjects = NULL;
				 tag_t partTag = NULLTAG;
				 char* dmlAnalystName = NULL;
				 CALLAPI(AOM_UIF_ask_value(dmlTaskTagObjects[i],"Analyst",&dmlAnalystName));
				 printf("\nDml Task Analyst_name:%s\n",dmlAnalystName);fflush(stdout);

				 CALLAPI(AOM_ask_value_tags(dmlTaskTagObjects[i],relationShipStr,&partCnt,&partTagObjects));
				 printf("\nPart Count:%d\n",partCnt);fflush(stdout);
				 if(partCnt>0)
				 {
					 int j=0;
					 char* part_object_type = NULL;
					 for(j=0;j<partCnt;j++)
					 {
						 partTag = partTagObjects[j];
						 CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
						 printf("\nobject_type of part is :%s\n",part_object_type);fflush(stdout);
						 if(tc_strcmp(part_object_type,"Design")==0)
						 {
							 int partRevCnt=0;
							 char* partNumber = NULL;
							 tag_t* partRevTagObjs = NULL;
							 tag_t partRevTag = NULLTAG;
							 char* fileName = NULL;
							 char *partNoFile = NULL;
							 char* newCompCode = NULL;
							 char* newColInd = NULL;	
							 printf("\n Part type is Design");fflush(stdout); 							
							 CALLAPI(ITEM_list_all_revs (partTag, &partRevCnt, &partRevTagObjs));
							 printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
							  
							 //Sanjoy 2nd compile
							
							 CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNumber));
							 printf("\nPart Master Part No====>%s\n",partNumber);fflush(stdout);
							 fileName = (char *) MEM_alloc( 100 * sizeof(char) );
							 tc_strcpy(fileName,dmlNo);
							 tc_strcat(fileName,"_");
							 tc_strcat(fileName,partNumber);
							 tc_strcat(fileName,".txt");
							 printf("\nFile Name should be: %s\n",fileName);fflush(stdout);
							 
							 if(flag>0)
							 {
								for(n=0;n<dsCnt;n++)
								{
									CALLAPI(AOM_ask_value_string(dataSetTagObjects[n],"object_type",&ds_object_type));
									printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
									if(tc_strcmp(ds_object_type,"Text")==0)
									{
							
										 CALLAPI(AE_find_dataset_named_ref2(dataSetTagObjects[n],0,&refname, &reftype,&refobject));
										 if(refobject==NULLTAG) continue;			 
										 CALLAPI(IMF_ask_original_file_name2(refobject , &orig_name));
										 printf("\n 111111original file name is :%s\n",orig_name);fflush(stdout);
										 if(tc_strcmp(orig_name,fileName)!=0) continue;
										 fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
										 tc_strcpy(fileLoc,"/tmp/");
										 tc_strcat(fileLoc,orig_name);
										 printf("\n FileLoc: %s", fileLoc);fflush(stdout);
										 remove( fileLoc );
										 CALLAPI(IMF_export_file( refobject , fileLoc ) );
										 
										 FILE * fp=NULL;
										 
										 fp = fopen(fileLoc, "r");
										 if(fp==NULL)
										 {
											 printf("\nCould not open the file %s. Kindly check.",fileLoc);fflush(stdout);
											 continue;
										 }
										 else
										 {
											 char buffer[MAX_LINE_LEN] ="";

											 while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
											 {
												 printf("\nbuffer.........>%s",buffer);fflush(stdout); 
												 partNoFile = tc_strtok(buffer,",");
												 newCompCode = tc_strtok(NULL,",");
												 newColInd = tc_strtok(NULL,",");
												 if(tc_strcmp(partNoFile,partNumber)==0)
												 {
													 printf("\nEQUAL");fflush(stdout);
													 break;
												 }
											 }
										 
											 printf("\npartNoFile==>%s",partNoFile);fflush(stdout);
											 printf("\nnewCompCode==>%s",newCompCode);fflush(stdout);
											 printf("\nnewColInd==>%s",newColInd);fflush(stdout);

										 }
										 if(fp!=NULL)
										 {
											 fclose(fp); 
										 }
										 if(fileLoc!=NULL)
										 {
											 printf("\nFreeing fileLoc\n");fflush(stdout);
											 MEM_free(fileLoc);
										 }

									}
								}
								
								//Get the eligible part revs that needed to be updated.
								int cnt =0;
								tag_t* partListTag = NULL;
								CALLAPI(getLatestReleasedAndWIPPart(partTag,&cnt, &partListTag))
								if(cnt>0)
								{
									 int m =0;
									for(m=0;m<cnt;m++)
									{
										char* partNo = NULL;
										char* partCompCode = NULL;
										char* partCI = NULL;
										partRevTag = partListTag[m];
										
										CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&partNo));
										CALLAPI(AOM_ask_value_string(partRevTag,"t5_PrtCatCode",&partCompCode));
										CALLAPI(AOM_ask_value_string(partRevTag,"t5_ColourInd",&partCI));
										printf("\nPart Rev Part No:%s\n",partNo);fflush(stdout);
										printf("\nOld Part Comp Code:%s\n",partCompCode);fflush(stdout);
										printf("\nOld Part Color Indicator:%s\n",partCI);fflush(stdout);
										
										/*logical havingWriteAccess = false;
										CALLAPI(AM_check_users_privilege(user_tag,partRevTag,"WRITE",&havingWriteAccess));
										if(havingWriteAccess==true)
										{
											printf("\nHave write access:\n");fflush(stdout);
										}
										else
										{
											printf("\nHave NO write access:\n");fflush(stdout);
										}*/
										//Update attributes
										
										CALLAPI(AOM_lock(partRevTag));
										CALLAPI(AOM_set_value_string(partRevTag,"t5_PrtCatCode",newCompCode));
										CALLAPI(AOM_set_value_string(partRevTag,"t5_ColourInd",newColInd));
										CALLAPI(AOM_save_without_extensions(partRevTag));
										CALLAPI(AOM_refresh(partRevTag,0));
										CALLAPI(AOM_unlock(partRevTag));
										
										
										CALLAPI(AOM_ask_value_string(partRevTag,"t5_PrtCatCode",&partCompCode));
										CALLAPI(AOM_ask_value_string(partRevTag,"t5_ColourInd",&partCI));
										printf("\nPart No:%s\n",partNo);fflush(stdout);
										printf("\nNew Part Comp Code:%s\n",partCompCode);fflush(stdout);
										printf("\nNew Part Color Indicator:%s\n",partCI);fflush(stdout);
										
									}
								}
								
							 }

							 if(fileName!=NULL)
							 {
								 printf("\nFreeing fileName\n");fflush(stdout);
								 MEM_free(fileName);
							 }
							
						 }
						  
					 }
				 }
				 
				 
				 
			 }
			 
		}
		
	}
	

	return ITK_ok;
}


int  tm_UpdateCompCode_func(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	
	
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);
	
	if(tc_strcmp(currentTaskName, "Update_Color_CompCode") != 0 )
	{
		printf("\nThe Current Task is not Update_Color_CompCode ");fflush(stdout);
		//return ifail;
	}

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	if(tc_strcmp(parentTaskName, "Color Parts Update LC") != 0 )
	{
		printf("\nThe Life cycle is not Color Parts Update LC ");fflush(stdout);
		//return ifail;
	}
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  *type_name = NULL;//[TCTYPE_name_size_c+1];
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nDML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				if(tc_strcmp(dmlReleaseType,"COL")==0)
				{
					dmlTag=targetobjects[i];
					break;
				}
				
				
			}
		}
		if(dmlTag==NULLTAG)
		{
			printf("\nTarget Object is not ERC DML Revision ");fflush(stdout);
			return ifail;
		}
		else
		{
			tag_t cntrlObj = NULLTAG;
			char* dmlNo = NULL;
	
			CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
			printf("\nCompCode: Target Object is ERC DML Revision==>%s ",dmlNo);fflush(stdout);
			ifail = t5IsUpdateCompCodeClientCodeLogic(&cntrlObj);
			//ifail = t5UpdateCompCodeForPartsInChangeReferenceFn(dmlTag);
			if(cntrlObj!=NULLTAG)
			{
				char* userInfo1	=	NULL;
				char* userInfo2	= 	NULL;
				char* userInfo3	=	NULL;
				char* userInfo4	=	NULL;
				char* userInfo5	=	NULL;
				char* userInfo6	=	NULL;
				char* userInfo7	=	NULL;
				char* userInfo8	=	NULL;
				char* userInfo9	=	NULL;
				
				
				
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//client logic
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path of client code
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//Relation of DML Task
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
				if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
				
				
				
				printf("\nCompCode UpdCompCodeClient-UpdCompCodeClient Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
				
				
				if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
				{
					char* sysCmnd = NULL;
					//execute client logic.
					sysCmnd=(char *) MEM_alloc(400);
					tc_strcpy(sysCmnd,userInfo2);
					tc_strcat(sysCmnd," ");
					tc_strcat(sysCmnd,dmlNo);				
					printf("\n Start-- Calling shell file tm_UpdateCompCodeOfColDml.sh using client system command: %s\n",sysCmnd);fflush(stdout);
					system(sysCmnd);

					printf("\n End --- Calling shell file tm_UpdateCompCodeOfColDml.sh using client system command: %s\n",sysCmnd);fflush(stdout);

					MEM_free(sysCmnd);
				}
				else if(tc_strstr(userInfo3,",References,")!= NULL)
				{
					ifail = t5UpdateCompCodeForPartsFn(dmlTag,"IMAN_reference");
				}
				else if(tc_strstr(userInfo3,",Change References,")!= NULL)
				{
					ifail = t5UpdateCompCodeForPartsFn(dmlTag,"CMReferences");
				}
				else
				{
					ifail = t5UpdateCompCodeForPartsFn(dmlTag,"IMAN_reference");
				}
				
				
			}
			else
			{
				//Default logic for Regerences folder of DML task
				ifail = t5UpdateCompCodeForPartsFn(dmlTag,"IMAN_reference");
			}
		}
		
	}
	
	return ifail;
}


int tm_Assign_Participant_COL_type_dmlFunc(EPM_action_message_t msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	char* dmlNo = NULL;	
	
	POM_get_user(&username,&user_tag);
	printf("\nSAN:Starting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSAN:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	if(tc_strcmp(currentTaskName, "Update_Color_CompCode") != 0 )
	{
		printf("\nSAN:The Current Task is not Update_Color_CompCode ");fflush(stdout);
		//return ifail;
	}

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSAN:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	
	if(tc_strcmp(parentTaskName, "Color Parts Update LC") != 0 )
	{
		printf("\nSAN:The Life cycle is not Color Parts Update LC ");fflush(stdout);
		//return ifail;
	}

	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  *type_name = NULL;
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\nSAN:type_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nSAN:DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				if(tc_strcmp(dmlReleaseType,"COL")==0)
				{
					dmlTag=targetobjects[i];
					break;
				}
				
				
			}
		}
		
		if(dmlTag==NULLTAG)
		{
			printf("\nSAN:Target Object is not ERC DML Revision ");fflush(stdout);
			return ifail;
		}
		CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
		printf("\nSAN:Target Object is ERC DML Revision==>%s ",dmlNo);fflush(stdout);
		
		
		
		char* projectId = NULL;

		CALLAPI(AOM_ask_value_string(dmlTag,"t5_cprojectcode",&projectId));
		printf("\n SAN: projectId : %s",projectId); fflush(stdout);
		
		if(projectId!=NULL)
		{
			tag_t queryTag = NULLTAG;
			char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
			char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
			tag_t* projectTags = NULL;
			tag_t projectTag = NULLTAG;
			int projCnt = 0;
			
			CALLAPI(QRY_find2("Qury_Project", &queryTag));
			printf("\n SAN:After Prd_Project: QRY_find2");fflush(stdout);
			if(queryTag)
			{
				printf("\n SAN:Found Query- Qury_Project");fflush(stdout);
			}
			else
			{
				printf("\n SAN:Not Found Query - Qury_Project");fflush(stdout);
			}

			qry_entries[0] = "Name";
			qry_values[0] = projectId;

			if(QRY_execute(queryTag, 1, qry_entries, qry_values, &projCnt, &projectTags));
			printf("\nSAN: Project Count : %d\n", projCnt); fflush(stdout);
			
			if(projCnt>0)
			{
				printf("\nSAN:projectTags = [%s] found in DB\n",projectId);fflush(stdout);
				projectTag = projectTags[0];
				
				if(projectTag!=NULLTAG)
				{
					char* projClass = NULL;
					char* projDesc = NULL;
					char* projPlatForm = NULL;
					char* projBU = NULL;
					
					CALLAPI(AOM_ask_value_string(projectTag,"t5_VehicleClass",&projClass));
					CALLAPI(AOM_ask_value_string(projectTag,"object_desc",&projDesc));
					CALLAPI(AOM_ask_value_string(projectTag,"t5_Program",&projPlatForm));
					CALLAPI(AOM_ask_value_string(projectTag,"t5_BussUnitType",&projBU));
					printf("\nSAN: projClass:[%s] projDesc : %s projPlatForm :[%s] projBU:[%s]\n",projClass,projDesc,projPlatForm,projBU);fflush(stdout);
					
					//SAN: projClass:[HCV] projDesc : 5442 projPlatForm :[X4] projBU:[CVBU]
					
					
					//Query PRD Projects
					tag_t qryTag = NULLTAG;
					char **qry_entry = (char **) MEM_alloc(10 * sizeof(char *));
					char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
					int rsltCount = 0;
					tag_t* CntrlObjectTag = NULL;
					char* info1 = NULL;
					char* info2 = NULL;
					char* info3 = NULL;
					int prdFlag = 0;
					
					printf("\n SAN:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
					if(QRY_find2("Control Objects...", &qryTag));
					if (qryTag)
					{
						printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
					}
					qry_entry[0]="SYSCD";
					qry_values2[0] = "PRDCVBU";
					if(QRY_execute(qryTag, 1, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
					printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
						printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
						printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
						
						
					}
					if(tc_strcmp(projClass,"PRD")==0)
					{
						if((tc_strstr(info1,projectId)!=NULL) || (tc_strstr(info2,projectId)!=NULL))
						{
							prdFlag=1;
							printf("\n SAN:.PRD project of CVBU found: %d",prdFlag); fflush(stdout);
						}
						else
						{
							prdFlag=0;
							printf("\n SAN:.No project CVBU found: %d",prdFlag); fflush(stdout);
						}
					}
					else
					{
						prdFlag=1;
						printf("\n SAN:.No PRD project: %d",prdFlag); fflush(stdout);
					}
					
					if(prdFlag>0)
					{
						//Remove the existing participants (BomAnalyst and CE Reviewer if any) - //T5_CEReviewer, T5_BOMAnalyst
						tag_t dml_part_rel_type = NULLTAG;
						int partyCnt = 0;
						int k=0;
						tag_t* partyObjs = NULL;
						tag_t partyObj = NULLTAG;
						tag_t partyObjType = NULLTAG;
						char   *type_name_partyObj = NULL;//[TCTYPE_name_size_c+1];
						char* dmlReviewer = NULL;
						CALLAPI(GRM_find_relation_type("HasParticipant", &dml_part_rel_type));
						if(dml_part_rel_type!=NULLTAG)
						{
							CALLAPI(GRM_list_secondary_objects_only(dmlTag,dml_part_rel_type,&partyCnt,&partyObjs));
							printf("\nSAN: participant object count: %d",partyCnt);fflush(stdout);	
							for(k=0;k<partyCnt;k++)
							{
								partyObj = partyObjs[k];
								CALLAPI(TCTYPE_ask_object_type(partyObj,&partyObjType));
								CALLAPI(TCTYPE_ask_name2(partyObjType,&type_name_partyObj));
								printf("\n SAN:DML: Participants Name: %s", type_name_partyObj);fflush(stdout);
								
								if(tc_strcmp(dmlReleaseType,"COL")==0)
								{
									if ((tc_strcmp(type_name_partyObj,"T5_BOMAnalyst")==0)||(tc_strcmp(type_name_partyObj,"T5_CEReviewer")==0))
									{
										CALLAPI(AOM_UIF_ask_value(partyObj,"fnd0AssigneeUser",&dmlReviewer));
										printf("\n SAN: Removing BOM Analyst and CE Reviewer: [%s] ",dmlReviewer);fflush(stdout);
										AOM_lock(dmlTag);
										if(PARTICIPANT_remove_participant(dmlTag,partyObj)!=ITK_ok)PrintErrorStack();
										AOM_save_without_extensions(dmlTag) ;
										AOM_unlock(dmlTag);
										
									}
								}		
									
							}	
							//Set CE Reviewer and BOM Analyst for the dmlTag							
							int     ik = 0;
							int     No_CEAna = 0;
							tag_t   CEAna_Rev			= NULLTAG;
							tag_t   CEGrp_tag			= NULLTAG;
							tag_t   CEAnalyst_tag		= NULLTAG;
							tag_t	CEAna_Patri_Type	= NULLTAG;
							tag_t*  CEAna				= NULL;
							tag_t	CEAna_Party		= NULLTAG;
							char*   CEAnalyst_role = NULL;//"CE_Reviewer";
							
							
							//Bom analyst
						
							int     ib = 0;
							int     No_BomAna = 0;
							tag_t   BomAna_Rev			= NULLTAG;
							tag_t   BAGrp_tag			= NULLTAG;
							tag_t   BomAnalyst_tag		= NULLTAG;
							tag_t	BomAna_Patri_Type	= NULLTAG;
							tag_t*  BomAna				= NULL;
							tag_t	BomAna_Party		= NULLTAG;
							char*   BomAnalyst_role = NULL;//"BomAnalyst";
							
							
							
							char	*groupName		= NULL;
							groupName = (char	*)MEM_alloc(100);
							tc_strcpy(groupName,"DML_Participants_Group");
							printf("\n SAN: groupName  --> %s\n",groupName);   fflush(stdout);
							
							//Setting BOM Analyst
							tag_t CntrlTag=NULLTAG;
							logical res = FALSE;
							logical delInd = FALSE;
							CALLAPI(getControlObjForDynamicParticipant(&CntrlTag,&res));	
							if(res && CntrlTag!=NULLTAG)
							{
								char* liveForDyamic = NULL;
								printf("\nValid control object FOUND CedPrtCre-CedPrtCre. Ready to GO!!!!! \n");fflush(stdout);
					
								CALLAPI(AOM_ask_value_logical(CntrlTag,"t5_DelInd",&delInd));
								printf("\nDelete Indicator==>%d\n",delInd);fflush(stdout);
								CALLAPI(AOM_ask_value_string(CntrlTag,"t5_Userinfo8",&liveForDyamic));
								printf("\nliveForDyamic==>%s\n",liveForDyamic);fflush(stdout);
								if(tc_strcmp(liveForDyamic,"YES")==0)
								{
									CALLAPI(AOM_ask_value_string(CntrlTag,"t5_Userinfo9",&BomAnalyst_role));
									printf("\nBomAnalyst_role==>%s\n",BomAnalyst_role);fflush(stdout);
									
									CALLAPI(AOM_ask_value_string(CntrlTag,"t5_userinfo10",&CEAnalyst_role));
									printf("\nCEAnalyst_role=>%s\n",CEAnalyst_role);fflush(stdout);
									
								}
								else
								{
									BomAnalyst_role="BomAnalyst";
									printf("\nBomAnalyst_role==>%s\n",BomAnalyst_role);fflush(stdout);
									CEAnalyst_role="CE_Reviewer";
									printf("\nCEAnalyst_role==>%s\n",CEAnalyst_role);fflush(stdout);
								}
								
							}
							else
							{
								BomAnalyst_role="BomAnalyst";
								CEAnalyst_role="CE_Reviewer";
							}

							printf("\nBomAnalyst_role==>%s\n",BomAnalyst_role);fflush(stdout);
							printf("\nCEAnalyst_role==>%s\n",CEAnalyst_role);fflush(stdout);
							//Setting BOM Analyst
							printf("\n SAN: Setting BOM Analyst...");fflush(stdout);
							if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(BomAnalyst_role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
							if(BomAnalyst_tag!=NULLTAG && BAGrp_tag!=NULLTAG)
							{
								if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
							}
							
							printf("\n SAN:No_BomAna  ---> [%d]",No_BomAna);  fflush(stdout);
							if(No_BomAna>0)
							{
								for(ib=0;ib<No_BomAna;ib++)
								{	
									printf("\n SAN:BOM Analyst no: [%d]",i);fflush(stdout);
									if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(BomAna[ib],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(dmlTag);			
									if(PARTICIPANT_add_participant(dmlTag,TRUE,BomAna_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save_without_extensions(dmlTag);
									AOM_unlock(dmlTag);
								}
							}
							AOM_refresh (dmlTag,TRUE);
							if(BomAna!=NULL)MEM_free(BomAna);
							
							
							//Setting CE Reviewer
							printf("\nCompCode: Setting CE Reviewer...");fflush(stdout);
							if(SA_find_group(groupName, &CEGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(CEAnalyst_role,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
							if(CEAnalyst_tag!=NULLTAG && CEGrp_tag!=NULLTAG)
							{
								if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
							}
							
							printf("\n SAN:No_CEAna  :[%d]",No_CEAna);  fflush(stdout);

							if(No_CEAna>0)
							{
								for(ik=0;ik<No_CEAna;ik++)
								{	
									printf("\n SAN:CE Reviewer no: %d",ik);fflush(stdout);
									if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(dmlTag);			
									if(PARTICIPANT_add_participant(dmlTag,TRUE,CEAna_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save_without_extensions(dmlTag);
									AOM_unlock(dmlTag);
								}
								AOM_refresh (dmlTag,TRUE);
								if(CEAna!=NULL)MEM_free(CEAna);
							}
							
							
							
							
								
								
							
							
							
						}
					}
				

				}
				else
				{
					printf("\n NO PROJECT AVAILABLE..\n");fflush(stdout);
				}
			}
			else
			{
				printf("\nSAN: NO PROJECT AVAILABLE..\n");fflush(stdout);
			}
			
		}
		else
		{
			printf("\nSAN: project id for the dml is null\n");fflush(stdout);
		}
		
		
		

		
	}
	printf("\nEnd CE Review participant assignment step");fflush(stdout);
	return ifail;
}
int CompCodeDelExistingDSServ(void *retValue)
{
	printf("\n Start----CompCodeDelExistingDSServ....\n");fflush(stdout);
	
	const char	*prog_name 	="CompCodeDelExistingDSServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t dmlTag = NULLTAG;
	USERARG_get_tag_argument(&dmlTag);
	
	logical  result = false;
	if(dmlTag !=NULLTAG)
	{
		char* dmlNo = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_string",&dmlNo))
		printf("\nDML Number=====>%s\n",dmlNo);
		
		tag_t dataSetTag = NULLTAG;
		USERARG_get_tag_argument(&dataSetTag);
		if(dataSetTag!=NULLTAG)
		{
			char* datasetnameStr = NULL;
			CALLAPI(AOM_ask_value_string(dataSetTag,"object_string",&datasetnameStr));
			printf("\n deleting dataset %s ........................\n",datasetnameStr);fflush(stdout);
			CALLAPI(AOM_delete_from_parent(dataSetTag,dmlTag))
			printf("\n deleting dataset %s is COMPLETED........................\n",datasetnameStr);fflush(stdout);
		}
		
					
	}
	

	printf("After returning Value\n");fflush(stdout);	
	printf("\n End----CompCodeDelExistingDSServ....\n");fflush(stdout);
	return ifail;	
	
}


/* Function to add string into a set of string */
void t5CompCode_SetAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\nSTN: setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\nSTN: setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5CompCode_FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}


int getUniqueCompCodeList(char* newCompCode, char*** CompCodeList, int *CompCodeList_Cnt )
{
	int ifail = ITK_ok;
	
	printf("\nCompCode:Getting Unique Comp code List.....\n");fflush(stdout);
	
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\nCompCode: newCompCode ===> [%s]\n",newCompCode);fflush(stdout);
	
	qry_entries[0] = "Comp Code";
	
	qry_values[0] = newCompCode;
		
	CALLAPI(QRY_find2("tm_GetCompCode", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObj));
	printf("\nCompCode: getUniqueCompCodeList: count==>%d", count);fflush(stdout);
	
	int i = 0;
	int compListCnt = 0;
	char** compList = NULL;
	
	for(i=0;i<count;i++)
	{
		tag_t compMstrTag = itemObj[i];
		char* compCodeName = NULL;
		int found = 0;
		
		ifail = AOM_ask_value_string(compMstrTag,"object_name",&compCodeName);
		
		t5CompCode_FindStrInSet(compList,compListCnt,compCodeName,&found);
		
		if(found == 0)
		{
			t5CompCode_SetAddStr(&compListCnt,&compList,compCodeName);
		}
		
		
		
	}
	
	*CompCodeList = compList;
	*CompCodeList_Cnt = compListCnt;
	
	return ifail;
	
	
	printf("\nCompCode:End of getUniqueCompCodeList function.....\n");fflush(stdout);
	return ITK_ok;
	
}



int tmGetCompCodeListServ(void *retValue)
{
	const char	*prog_name 	="tmGetCompCodeListServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int CompCodeList_Cnt=0;
	char** CompCodeList = NULL;;	
	printf("\nCompCode: Start----tmGetCompCodeListServ....\n");fflush(stdout);
	char* newCompCode = NULL;
		
	//USERARG_get_string_argument(&releaseStatusStr);
	USERARG_get_string_argument(&newCompCode);

	//print input parameters
	printf("\nCompCode: newCompCode==>%s\n",newCompCode);fflush(stdout);
		

	
	CALLAPI(getUniqueCompCodeList(newCompCode, &CompCodeList, &CompCodeList_Cnt ));
	
	int m =0;
	printf("\nCompCode: List Cnt=%d\n",CompCodeList_Cnt);fflush(stdout);
	array_size = CompCodeList_Cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<CompCodeList_Cnt;m++)
	{
		//printf("\n%s",CompCodeList[m]);fflush(stdout);
		string_array[m] = CompCodeList[m];
	}

	//printf("\nBefore returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nCompCode: End----tmGetCompCodeListServ....\n");fflush(stdout);
	return ifail;
}


int tmCompCodeRelatePartToDMLTask(void *retValue)
{
	printf("\nCompCode:Start----tmCompCodeRelatePartToDMLTask....\n");fflush(stdout);
	const char	*prog_name 	="tmCompCodeRelatePartToDMLTask";	
	int ifail = ITK_ok;
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	tag_t DMLTaskTag = NULLTAG;
	tag_t PartRevTag = NULLTAG;
	char* relationShipStr = NULL;

	USERARG_get_tag_argument(&DMLTaskTag);
	USERARG_get_tag_argument(&PartRevTag);
	USERARG_get_string_argument(&relationShipStr);
	
	//To related part to Task
	printf("\nCompCode: relationShipStr:[%s]\n",relationShipStr);fflush(stdout);
	tc_strcpy(resultStr,"");
	if(relationShipStr == NULL)
	{
		relationShipStr = "IMAN_reference";
	}
	
	
	if(DMLTaskTag!= NULLTAG && PartRevTag != NULLTAG && relationShipStr!=NULL)
	{
		ifail = tmCompCodeRelatePrimaryWithSecondaryObj(DMLTaskTag,PartRevTag,relationShipStr);
		
		if(ifail == ITK_ok)
		{
			tc_strcpy(resultStr,"PASS");
		}
		else
		{
			tc_strcpy(resultStr,"FAIL");
		}
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	

	
	
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nCompCode: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	//printf("Copy Dept Doc - After returning Value\n");fflush(stdout);	

	printf("\nCompCode: END----tmCompCodeRelatePartToDMLTask....\n");fflush(stdout);
	return ifail;	
	
}

/**************PQ Rep Doc *****************/

int t5CompCodeUpd_AddERCReleasedStatusToMyTag(tag_t myTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	ifail = RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status);
	ifail =  AOM_ask_name(release_status, &ReleaseStatus);

	if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		ifail = RELSTAT_add_release_status(release_status,1,&myTag,retain_released_date); 
	}	
	
	return ifail;
}


int t5CompCodeUpd_AddERCReviewStatusToMyTag(tag_t myTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	ifail = RELSTAT_create_release_status("T5_LcsReview",&release_status);
	ifail =  AOM_ask_name(release_status, &ReleaseStatus);

	if((strcmp(ReleaseStatus,"ERC Review")==0)||strcmp(ReleaseStatus,"T5_LcsReview")==0 )
	{
		ifail = RELSTAT_add_release_status(release_status,1,&myTag,retain_released_date); 
	}	
	
	return ifail;
}
int isEligibleToCreUpdPQRepDoc(logical *result)
{
	int ifail = ITK_ok;
	printf("\nPQ:Check for PQ Rep Doc updation access\n");fflush(stdout);
	
	*result = TRUE;
	//To be impletemented
		
	
	return ifail;
	
}
//Pre action of ITEM_create_msg of T5_STNHeader - check if allowed to create - 1-cre
extern DLLAPI int  PQRepDoc_PreValidationCreation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	
	printf("\nPQ: **** Inside the PQRepDoc_PreValidationCreation  - pre creation**** \n");fflush(stdout);
	
	logical isAllowed = FALSE;
	
	ifail = isEligibleToCreUpdPQRepDoc(&isAllowed);
	
	printf("\nPQ: Is Allowed for creation of PQ Rep Doc: [%d]\n", isAllowed);fflush(stdout);
	
	if(!isAllowed)
	{
		EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create PQ Rep Doc. Kindly contact PLM Admin.");
		printf("\nPQ: PQRepDoc_PreValidationCreation 111*********************You Don't Have access to create PQ Rep Doc *********************\n");fflush(stdout);
		return ITK_err;
	}
	else
	{
		printf("\nPQ: Allowed for creation of STN Header\n");fflush(stdout);
		
		

		
	}

	
	printf("\nPQ: **** Exit PQRepDoc_PreValidationCreation **** \n");fflush(stdout);
	return ifail;
	
}

extern DLLAPI int PQRepDoc_PostSaveVald(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	int isnew              = 0;
	tag_t objTag = va_arg(args, tag_t);
	isnew   = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	char* type_name = NULL;
	
	printf("\nPQ: **** Inside the PQ Rep Doc Creation Post**** \n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\nPQ: Inside the PQ Rep function check Object type :%s \n", type_name);fflush(stdout);
	printf("\nPQ:isNew===> [%d]\n",isnew);fflush(stdout);
	
	
	printf("\nPQ: **** Exit PQRepDoc_PostSaveVald function Creation Post **** \n");fflush(stdout);
	return ITK_ok;
	
}

extern DLLAPI int PQRepDocRev_PostSaveVald(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	int isnew              = 0;
	tag_t objTag = va_arg(args, tag_t);
	isnew   = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	char* type_name = NULL;
	
	printf("\nPQ: **** Inside the PQ Rep Doc Rev Creation Post**** \n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\nPQ: Inside the PQ Rep function check Object type :%s \n", type_name);fflush(stdout);
	printf("\nPQ:isNew===> [%d]\n",isnew);fflush(stdout);
	
	char* relStatus = NULL;
	char* repName = NULL;
	
	ifail = AOM_UIF_ask_value(objTag,"release_status_list", &relStatus);
	printf("\nPQ:Release Status of STN: [%s]",relStatus);fflush(stdout);
	
	if(isnew == 1)
	{
		ifail = t5CompCodeUpd_AddERCReviewStatusToMyTag(objTag);
	}
	else
	{
		if(relStatus==NULL)
		{
			ifail = t5CompCodeUpd_AddERCReviewStatusToMyTag(objTag);
			
		}
		else
		{
			if(tc_strcmp(relStatus,"")== 0)
			{
				ifail = t5CompCodeUpd_AddERCReviewStatusToMyTag(objTag);
			}
		}
	}
	
	
	
	
	//t5_pqrepname
	ifail = AOM_ask_value_string(objTag,"object_name",&repName);
	
	printf("\nPQ:Report Name [%s]",repName);fflush(stdout);
	ifail = AOM_set_value_string(objTag, "t5_pqrepname", repName);
	
	
	printf("\nPQ: **** Exit PQRepDocRev_PostSaveVald function Creation Post **** \n");fflush(stdout);
	return ITK_ok;
	
}
/***********End PQ Rep Doc ***********************/


extern int CompCodeUserServiceFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 2;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//Dml object
	input_arg_type[1]=USERARG_TAG_TYPE;//Dataset object
	ret_value_type = USERARG_VOID_TYPE;
 	
	
	printf("\nBefore registering CompCodeUserServiceFn userservice...");  
	ifail=USERSERVICE_register_method("CompCodeDelExistingDSServ",(USER_function_t)CompCodeDelExistingDSServ,n_args,input_arg_type,ret_value_type);
	


	int n_args1 = 1;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args1 * sizeof(int));
	
	input_arg_type1[0]=USERARG_STRING_TYPE;//new comp code
	ret_value_type1 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
 	
	
	printf("\nBefore registering tmGetCompCodeListServ userservice...");  
	ifail=USERSERVICE_register_method("tmGetCompCodeListServ",(USER_function_t)tmGetCompCodeListServ,n_args1,input_arg_type1,ret_value_type1);
	printf("\nAfter registering tmGetCompCodeListServ userservice...."); 



	int n_args2 = 3;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args2 * sizeof(int));
	
	input_arg_type2[0]=USERARG_TAG_TYPE;//DML Task
	input_arg_type2[1]=USERARG_TAG_TYPE;//Child part
	input_arg_type2[2]=USERARG_STRING_TYPE;//Relationship
	ret_value_type2 = USERARG_STRING_TYPE;
 	
	
	printf("\nBefore registering tmCompCodeRelatePartToDMLTask userservice...");  
	ifail=USERSERVICE_register_method("tmCompCodeRelatePartToDMLTask",(USER_function_t)tmCompCodeRelatePartToDMLTask,n_args2,input_arg_type2,ret_value_type2);
	printf("\nAfter registering tmCompCodeRelatePartToDMLTask userservice....");  
	
		
	
	printf("\n After registering CompCodeUserServiceFn userservice...."); 
	
	return ifail;
}

extern int tm_CompCodeUpdDML_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    printf("\ntm_CompCodeUpdDML_register_method: Before registering action handlers....");            
	ifail = EPM_register_action_handler("tm_UpdateCompCode", "tm_UpdateCompCode",tm_UpdateCompCode_func);	
	
	
	ifail = EPM_register_action_handler (
								"tm_ColCFTreview",
								"tm_ColCFTreview",
								(EPM_action_handler_t)tm_Assign_Participant_COL_type_dmlFunc
								);
	printf("\ntm_CompCodeUpdDML_register_method: After registering action handlers...."); 
	
	printf("\ntm_CompCodeUpdDML_register_method: Before registering rule handlers...."); 

	ifail = EPM_register_rule_handler (
							"tm_CheckDMLRelzTypeFunc",
							"tm_CheckDMLRelzTypeFunc",
							(EPM_rule_handler_t)tm_CheckDMLRelzTypeFunc
							);	
							
	ifail = EPM_register_rule_handler (
							"tm_CompCodeUpdLCSignOffVald",
							"tm_CompCodeUpdLCSignOffVald",
							(EPM_rule_handler_t)tm_CompCodeUpdLCSignOffVald
							);								
    printf("\ntm_CompCodeUpdDML_register_method: After registering rule handlers...."); 

/* PQ Reportr Doc **/

	METHOD_id_t  method ;
	METHOD_id_t pqrepDocSaveMethod ;
	if ( METHOD_find_method("T5_PQRepDoc", ITEM_create_msg, &method) !=ITK_ok);
	
	if ( METHOD_find_method("T5_PQRepDocRevision", "IMAN_save", &pqrepDocSaveMethod) !=ITK_ok);//TC_save_msg
	if (method.id != NULL)
	{
		
		
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) PQRepDoc_PreValidationCreation, NULL)!=ITK_ok);

		if( ifail != ITK_ok )
		{

			EMH_store_error( EMH_severity_error, ifail );

		}

	}
	
	if (pqrepDocSaveMethod.id != NULL)
	{
		if( METHOD_add_action(pqrepDocSaveMethod, METHOD_post_action_type, (METHOD_function_t) PQRepDocRev_PostSaveVald, NULL)!=ITK_ok);
	}

	
    return ifail;
}






extern DLLAPI int tm_CompCodeUpdDML_register_callbacks ()
{	
    int ifail    = ITK_ok;
	printf("\ntm_CompCodeUpdDML_register_callbacks:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_CompCodeUpdDML", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_CompCodeUpdDML_register_method);
	printf("\ntm_CompCodeUpdDML_register_callbacks: After registoring....");
	
	printf("\n Started- Registering user service function CompCodeUserServiceFn...");
	ifail=CUSTOM_register_exit ( "tm_CompCodeUpdDML", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)CompCodeUserServiceFn);
	printf("\n Completed- Registering user service function CompCodeUserServiceFn...");
	
  return ( ITK_ok );
}

