/****************************************************************************************************
*  File           :		tm_nonerc_restrict_propupdate.c
*  Created By     :		Amar Kate
*  Created On     :		24-June-2024
*  Purpose        :		Restrict user to update property of other Departments.
*						This is called at pre action of save.
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes
*
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/preferences.h> 

#define MAX_TOKENS 10 // Maximum number of tokens expected

#define ITK_err 919006

/************************* Amar Kate ****************/

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text(stat, &err_string);                 \
        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


extern DLLAPI int  RestrictionsOnUpdatingProperties(METHOD_message_t *msg, va_list args)
{
	
	/** va_list for PROP_set_value_string_msg **/

	printf("\n Amar Inside RestrictionsOnUpdatingProperties.... \n") ;fflush(stdout);
	
	int error_code = ITK_ok;

	char*   OldValue= NULL;

	va_list  largs;
    va_copy(largs, args);
    //va_arg(largs, tag_t);
    tag_t prop_tag      = va_arg( largs, tag_t );
	char *value =  va_arg( largs, char*); 
    logical is_null = va_arg(largs, int) != 0;
    va_end( largs );

    const char *prop_name = NULL;
    METHOD_PROP_MESSAGE_PROP_NAME(msg, prop_name);

	printf("\n Amar Selected prop_name is = [%s] \n",prop_name) ;fflush(stdout);
    
    tag_t  object_tag = NULLTAG;
    METHOD_PROP_MESSAGE_OBJECT(msg, object_tag);

    tag_t type_tag = NULLTAG;
    ITK_CALL(TCTYPE_ask_object_type(object_tag, &type_tag));

	char*   type_name= NULL;
	TCTYPE_ask_name2(type_tag,&type_name);

	printf("\n Amar type_name of Selected part is = [%s] \n",type_name) ;fflush(stdout);

	printf("\n Amar Prop New value is = [%s] \n",value) ;fflush(stdout);
		
	// Control Object
	
	char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 3;

	char*	username	= NULL;
	char*	group_name1	= NULL;
	char*	group_name	= NULL;

	tag_t user_tag				= NULLTAG;
	tag_t GroupMem				= NULLTAG;
	tag_t   qryTagCntrlobj		= NULLTAG;

	tag_t*	list_of_cntrl_tags	= NULLTAG;

	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrlformat[0]="Iman_Save";
		qry_valuesCntrlformat[1]="AllPropBypass";
		qry_valuesCntrlformat[2]="0";
		//qry_valuesCntrlformat[3]="Live";
		
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found for Iman_Save \n");fflush(stdout);
	}

	printf("\n controlObjfound for Iman_Save is ==> %d\n",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
		POM_get_user(&username,&user_tag);

		SA_ask_current_groupmember(&GroupMem);

		if(GroupMem !=NULLTAG)
		{
			ITK_CALL(AOM_ask_value_string(GroupMem,"object_name",&group_name1));
			printf("\n session group_name is  : %s\n",group_name1);fflush(stdout);

			group_name=strtok(group_name1,"/");
			printf("\n session only Group name is  : %s\n",group_name);fflush(stdout);
		}

		char *SupportUsername9 = NULL;
		tag_t SessionUser9_tag=NULLTAG;
		int     SupportFlag      =  0;

		SupportFlag=0;
		POM_get_user(&SupportUsername9,&SessionUser9_tag);
		if(SessionUser9_tag!=NULLTAG)
		{
			SupportFlag=0;
			SupportFlag = CheckSupportLogin(SessionUser9_tag);
			printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
		}
		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "PLM_Support_Group") != 0))
		{
			if ((tc_strstr(group_name, "MBOM") != NULL) || (tc_strstr(group_name, "APL") != NULL) || (tc_strstr(group_name, "STD") != NULL))
			{
				printf("\n Amar Inside group_name is [%s] part of [MBOM/APL/STD], hence you are not authorized to update this prop.  \n",group_name);
				if(strcmp(type_name,"Design Revision")==0) 
				{
					ITK_CALL(AOM_ask_value_string(object_tag,prop_name,&OldValue));	
					printf("\n Amar prop_name =[%s] OldValue is = [%s] newvalue= [%s],is_null =[%d] \n",prop_name,OldValue,value,is_null);fflush(stdout); 

					if (is_null==0)
					{
						if(strcmp(value,OldValue)==0)
						{
							printf("\n Amar Allowed to modified.. \n");fflush(stdout); 
						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Updation of Property is not Allowed..");
							return 1;
						}
					}
				}
			}
			else
			{
				printf("\n group_name %s is not MBOM/APL/STD  \n",group_name);
			}
		}
	}
	

	return error_code;
}

// Function to add a string to the list and increase the count
void setAddStrImansave(int *count, char ***strset, const char *str) {
    *count = *count + 1;
    // Reallocate memory for the new list of strings
    *strset = (char **)realloc(*strset, (*count) * sizeof(char *));
    if (!(*strset)) {
        perror("Failed to allocate memory");
        exit(EXIT_FAILURE);
    }
    (*strset)[*count - 1] = malloc(strlen(str) + 1);
    if (!(*strset)[*count - 1]) {
        perror("Failed to allocate memory");
        exit(EXIT_FAILURE);
    }
    strcpy((*strset)[*count - 1], str);
}

extern int tmsave_design_custom_exit(int *decision, va_list args)
{
	int ifail = ITK_ok;
	METHOD_id_t  method ;
	METHOD_id_t  method1 ;

	*decision = ALL_CUSTOMIZATIONS;

	int i=0;
	int ii=0;

	printf("\n\n Inside tmsave_design_custom_exit Func.. \n");fflush(stdout);

	// Control Object
	char    *qry_entryCntrlSaveProp[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrlSaveProp= (char **) MEM_alloc(5 * sizeof(char *));
	
	tag_t   qryTagCntrlSaveProp     = NULLTAG;
	
	int     n_entryCntrlSaveProp    = 3;
	int  control_number_foundSaveProp=0;
	
	tag_t *list_of_WSO_cntrl_tagsSaveProp=NULLTAG;
	
	char *PropLists = (char *) MEM_alloc(500 * sizeof(char)) ;
	//char*	PropLists		=	NULL;
	char*	PropLists1		=	NULL;
	char*	PropLists2		=	NULL;
	char*	PropupdtName	=	NULL;



	int count = 0;
    char **Propsetlist=NULL;
				
	if(QRY_find2("Control Objects...", &qryTagCntrlSaveProp));
	if (qryTagCntrlSaveProp)
	{
		//printf("\n Control Object Query Found \n");fflush(stdout);
	
		qry_valuesCntrlSaveProp[0]="SaveProp";
		qry_valuesCntrlSaveProp[1]="IMAN_save";
		qry_valuesCntrlSaveProp[2]="0";
		
		if(QRY_execute(qryTagCntrlSaveProp, n_entryCntrlSaveProp, qry_entryCntrlSaveProp, qry_valuesCntrlSaveProp, &control_number_foundSaveProp, &list_of_WSO_cntrl_tagsSaveProp));
	}
	
	printf("\n add_method : control_number_foundSaveProp is => %d\n",control_number_foundSaveProp);fflush(stdout);
	
	if(control_number_foundSaveProp>0)
	{
		//printf("\n Amar Inside control_number_foundSaveProp \n");fflush(stdout);
	
		ITK_CALL (AOM_ask_value_string(list_of_WSO_cntrl_tagsSaveProp[0],"t5_Userinfo1",&PropLists1));
		//printf("\n PropLists1 => %s \n",PropLists1);fflush(stdout);

		ITK_CALL (AOM_ask_value_string(list_of_WSO_cntrl_tagsSaveProp[0],"t5_Userinfo2",&PropLists2));
		//printf("\n PropLists2 => %s \n",PropLists2);fflush(stdout);

        // Properly concatenate strings
        tc_strcpy(PropLists, "");
        if (PropLists1) {
            tc_strcat(PropLists, PropLists1);
        }
        if (PropLists2) {
            //tc_strcat(PropLists, ","); // Add a comma separator
            tc_strcat(PropLists, PropLists2);
        }

        printf("\n After concatenate PropLists is = %s \n", PropLists); fflush(stdout);

		//const char *PropLists = "t5_PartStatus,t5_Coated,t5_ColourID,t5_AppCode";
		char *PropListsCopy = malloc(strlen(PropLists) + 1);
		if (!PropListsCopy) {
			perror("Failed to allocate memory");
			return EXIT_FAILURE;
		}
		strcpy(PropListsCopy, PropLists);

		char *PropupdtName = strtok(PropListsCopy, ",");

		printf("\n PropupdtName = %s \n", PropupdtName);

		while (PropupdtName != NULL) {
			setAddStrImansave(&count, &Propsetlist, PropupdtName);
			PropupdtName = strtok(NULL, ",");
			//printf("\n Inside PropupdtName loop = %s \n", PropupdtName);
		}

		//printf("\n Number of tokens = %d \n", count);

		// Print each string in Propsetlist
		printf("\n Contents of Propsetlist:\n");
		for ( i = 0; i < count; i++) {
			//printf("Propsetlist[%d] = %s\n", i, Propsetlist[i]);
		}
    }

	printf("\n Number of tokens = %d \n", count);
	
    for(ii = 0; ii <count; ii++)
    {
		ITK_CALL(METHOD_find_prop_method("Design Revision", Propsetlist[ii],PROP_set_value_string_msg/*PROP_UIF_set_value_msg*/, &method));

		printf(" Inside Propsetlist[%d] = %s\n", ii, Propsetlist[ii]);

        if (method.id != NULLTAG)
        {
			ITK_CALL( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) RestrictionsOnUpdatingProperties, NULL));
			 //ECHO("\t Amar Registered %s - %s custom method\n", type_name[ii], message[ii]);
			if( ifail != ITK_ok )
			{
					EMH_store_error( EMH_severity_error, ifail ); 
			}
        }
    }

	   printf("\n\n Amar, tmsave_design_custom_exit end .\n");fflush(stdout);

    return ifail;
}


extern DLLAPI int tm_nonerc_restrict_propupdate_register_callbacks ()
{
	  printf("\n\n Amar, tm_nonerc_restrict_propupdate end .\n");fflush(stdout);

      CUSTOM_register_exit ( "tm_nonerc_restrict_propupdate", "USER_init_module", (CUSTOM_EXIT_ftn_t) tmsave_design_custom_exit);

      return ( ITK_ok );
}
