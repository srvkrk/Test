/***************************************************************************
*  File				:   AddULM.c
*  Created By		: 	Sai D. Raypalwar.
*  Created On		:   30-Jun-2023
*  Project			:   TML
*  Purpose			:  
*  
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov_msg.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <tie/tie_errors.h>
#include <tccore/grmtype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tc/wsouif_errors.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <epm/cr.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
int *decision =0;
char*   output      =       NULL;

void Qury_partnumber(tag_t *parttag,char* qry_values[])
{
	tag_t 			 Qryfnd 			 = NULLTAG;
	tag_t           childrev1            = NULLTAG;
	
	ITK_CALL(QRY_find2("Item Revision...", &Qryfnd));
	if(Qryfnd != NULLTAG)
	{
		printf("\nFound Query Item Revision \n"); fflush(stdout);
		int 		n_entries			= 3;		
		char 		*qry_entries[3] 	= {"Item ID","Revision","Type"};
		
		int 		No_Qry_Found 		= 0;
		tag_t 		*partrevision 		= NULLTAG;
		tag_t 		part 				= NULLTAG;
		int 		P 					= 0;
		ITK_CALL(QRY_execute(Qryfnd,n_entries,qry_entries,qry_values,&No_Qry_Found,&partrevision));
		printf("\n Total part found : %d",No_Qry_Found);fflush(stdout);
		if(No_Qry_Found > 0)
		{
			char	*PartitmID					= NULL;
			*parttag=partrevision[P];
			ITK_CALL(AOM_ask_value_string(*parttag,"item_id",&PartitmID));
			printf("\n\n Paste Part item id : %s",PartitmID);fflush(stdout);
		}
		
	}
}

int AddULMPEpart(char *selectedTask,int n_tags_found ,tag_t* tags_found,void *return_data)
{
	int 	iFail     		= ITK_ok ;
	
	int 	part_count		= 0;
	double	consumableQtyD	;			
	tag_t   partM            = NULLTAG;
	tag_t   partrevisionM    = NULLTAG;
	tag_t   *Task             = NULLTAG;
	tag_t   latesttaskrev     = NULLTAG;
	tag_t	*Release_status   = NULLTAG;
	tag_t*	occurrences		= NULLTAG;
	tag_t*	occurrences1		= NULLTAG;
	char *	child_item_Qty	= NULL;
	
	char* task_ID = ITK_ask_cli_argument("-T=");
	tag_t 	 		 parttag			 	= NULLTAG;
	tag_t 	 		 parttag1			 	= NULLTAG;
	char 			 *qry_values[]			= {"55341000024","NR","Design Revision"};
	char 			 *qry_values1[]			= {"55341000016","NR","Design Revision"};
	tag_t       mbomviewtag			= NULLTAG;
	char        *psmbomview			= NULL;
	char        *view				= NULL;
	char        *view1				= NULL;
	int         viewcount			= 0; 
	int			count				= 0;
	int			PartCnt				= 0;
	int			RawCnt				= 0;
	int			k					= 0;
	tag_t       *viewtag    		= NULLTAG;
	tag_t		viewtag1			= NULLTAG;	
	tag_t       MBV         		= NULLTAG;
	tag_t       top_bom_line    	= NULLTAG;
	tag_t       top_bom_line1    	= NULLTAG;
	tag_t       *Partchildttag				= NULLTAG;
	int         Partchildcount       		= 0;
	tag_t       new_bl          	= NULLTAG;
	tag_t       MBVR            	= NULLTAG;
	tag_t       window         		= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t		solrelation_type	= NULLTAG;
	tag_t		RAWrelation			= NULLTAG;
	tag_t*		DMLRevision			= NULLTAG;
	tag_t		Dml					= NULLTAG;
	tag_t		*PartTags			= NULLTAG;
	tag_t		*RawTags			= NULLTAG;
	tag_t		PNTag				= NULLTAG;
	tag_t     occurrencetag				= NULLTAG;
	tag_t       MBOM_RevRule		= NULLTAG;
	tag_t       *MBOM_Closure_Tag			= NULLTAG;
	tag_t       mbomClosure_Rule			= NULLTAG;
	int         CRule_found       			= 0;
	int 		P 					= 0;
	char*		Part_CS				= NULL;
	char*		Part_Dec			= NULL;
	char*		Part_no				= NULL;
	char*		Part_Paste			= NULL;
	char*		Part_Emulsion		= NULL;
	char		*Ecntype			= NULL;
	char	    *childPartitmID				= NULL;	
	output	=(char *) MEM_alloc(10);
	printf("\n inside DB\n");
	printf("\n n_tags_found: %d \n",n_tags_found);fflush(stdout);
	if(n_tags_found>0)
	{
		
		ITK_CALL(ITEM_ask_latest_rev(tags_found[0],&latesttaskrev));
	}
	printf("\n before objecttype ");fflush(stdout);
	int RelCount = 0;
	char			*Temp				= NULL;
	char			*LifeCycle				= NULL;
	AOM_ask_value_string(tags_found[0],"object_type",&Temp);
	printf("\n Object Type is : %s",Temp);fflush(stdout);
	AOM_ask_value_string(latesttaskrev,"object_type",&Temp);
	printf("\n Object Type is : %s",Temp);fflush(stdout);
	printf("\n Release Count: %d \n",RelCount);fflush(stdout);
		
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&solrelation_type));
	ITK_CALL(GRM_list_secondary_objects_only(latesttaskrev,solrelation_type,&PartCnt,&PartTags));
	if (PartCnt>0)
	{
		for (k=0;k<PartCnt ;k++ )
		{
			PNTag=PartTags[k];
			ITK_CALL(AOM_ask_value_string(PNTag,"t5_JsrMakeBuyIndicator",&Part_CS));
			printf("\n t5_JsrMakeBuyIndicator : %s \n",Part_CS);
			
			ITK_CALL(AOM_ask_value_string(PNTag,"object_desc",&Part_Dec));
			printf("\n Part Dec  : %s \n",Part_Dec);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(PNTag,"item_id",&Part_no));
			printf("\n Part_no  : %s \n",Part_no);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(Part_no,&partM));//                            cmitest 544281120101
			ITK_CALL(ITEM_ask_latest_rev(partM,&partrevisionM));
			
			Qury_partnumber(&parttag,qry_values);
			Qury_partnumber(&parttag1,qry_values1);
			
			ITK_CALL(AOM_ask_value_string(parttag,"item_id",&Part_Paste));
			printf("\n Part_Paste  : %s \n",Part_Paste);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(parttag1,"item_id",&Part_Emulsion));
			printf("\n Part_Emulsion  : %s \n",Part_Emulsion);fflush(stdout);
			
			if(tc_strstr(Part_CS,"E99") && tc_strstr(Part_Dec,"LONG MEMBER"))
			{
				ITKCALL(GRM_find_relation_type("T5_RPtRel", &RAWrelation));
				ITK_CALL(GRM_list_secondary_objects_only(partrevisionM,RAWrelation,&RawCnt,&RawTags));
				if(RawCnt>0)
				{
					ITK_CALL(PS_find_view_type("T5_APLJView",&mbomviewtag))//get view tag
					
					ITK_CALL(PS_ask_view_type_name(mbomviewtag,&psmbomview));
					printf("\n Ps_view_type_name %s \n",psmbomview);fflush(stdout);
					
					ITK_CALL(ITEM_list_bom_views(partM,&viewcount, &viewtag));//partM is part number 
					printf("\n Number of bom view [%d] \n",viewcount);fflush(stdout);
					int i=0;
					if(viewcount>0)
					{
						for(i=0;i<viewcount;i++)
						{
							tag_t viewtype =NULLTAG;
							viewtag1=viewtag[i];
							ITK_CALL(PS_ask_bom_view_type(viewtag1,&viewtype));
							ITK_CALL(PS_ask_view_type_name(viewtype,&view));
							printf("\n  view [%s] \n",view);fflush(stdout);
							
						}
					}
					if(viewtag == NULLTAG )
					{
						ITK_CALL(AOM_lock(partM));
						ITK_CALL(PS_create_bom_view(mbomviewtag,"","",partM,&MBV));
						ITK_CALL(AOM_save_with_extensions(MBV));
						ITK_CALL(AOM_save_with_extensions(partM));
						ITK_CALL(AOM_unlock(partM));
						if(MBV!=NULLTAG)
						{
							printf("\n Inside BVR Creation \n");fflush(stdout);
							ITK_CALL(AOM_lock(partrevisionM));//partrevisionM -is part Revision
							ITK_CALL(PS_create_bvr(MBV,"","",false,partrevisionM,&MBVR));
							ITK_CALL(AOM_save_with_extensions(MBVR));
							ITK_CALL(AOM_save_with_extensions(partrevisionM));
						}
						ITKCALL(PS_create_occurrences(MBVR,parttag,NULLTAG,1,&occurrences));
						ITKCALL(PS_create_occurrences(MBVR,parttag1,NULLTAG,1,&occurrences1)); 
						
						ITKCALL(PS_set_occurrence_qty(MBVR, occurrences[0],0.25));
						ITKCALL(PS_set_occurrence_qty(MBVR, occurrences1[0],1.35));
						ITKCALL(AOM_save_with_extensions(MBVR)); 
						ITKCALL(AOM_save_with_extensions(partrevisionM));
						
						if(occurrences) 
							MEM_free(occurrences); 
						else if(occurrences1)
							MEM_free(occurrences1); 						
					}
					else
					{
						int flag =0;
						printf("\n \n BOM View Expansion ........ \n");fflush(stdout);
						ITK_CALL(BOM_create_window(&window));
						ITK_CALL(CFM_find("ERC release and above (Modified)", &MBOM_RevRule));
						//ITK_CALL(CFM_find("Any Status; Working", &MBOM_RevRule));
						ITK_CALL(PIE_find_closure_rules2( "BOMViewClosureRuleAPLJ",PIE_TEAMCENTER, &CRule_found, &MBOM_Closure_Tag ));
						//ITK_CALL(PIE_find_closure_rules("GenTPLBOMViewClosureRuleAPLC",PIE_TEAMCENTER, &CRule_found, &MBOM_Closure_Tag ));
						printf ("MBOM closure rule count %d \n",CRule_found);fflush(stdout);
						if (CRule_found > 0)
						{
							mbomClosure_Rule = MBOM_Closure_Tag[0];
							printf ("closure rule found \n");fflush(stdout);
							
							ITK_CALL(BOM_window_set_closure_rule(window,mbomClosure_Rule,0,NULL,NULL));
							ITK_CALL(BOM_set_window_config_rule( window, MBOM_RevRule ));
							ITK_CALL(BOM_set_window_top_line(window, partM, partrevisionM, viewtag[0], &top_bom_line1));
							ITK_CALL(BOM_line_ask_all_child_lines(top_bom_line1, &Partchildcount, &Partchildttag));
							printf("\n\n Number of child  Part found in MBOM  : %d\n",Partchildcount);fflush(stdout);
							if (Partchildcount >0)
							{
								
								for(P = 0; P < Partchildcount; P++)
								{
									ITK_CALL(AOM_ask_value_string(Partchildttag[P],"bl_item_item_id",&childPartitmID));
									printf("\n\n Child Part item id : %s",childPartitmID);fflush(stdout);
									if(tc_strcmp(childPartitmID,Part_Paste) && tc_strcmp(childPartitmID,Part_Emulsion) ==0)
									{
										//strcpy(output,"Both");
										flag=0;
										printf("\n both have already present \n");fflush(stdout);
									}
									else if(tc_strcmp(childPartitmID,Part_Paste)==0)
									{
										//strcpy(output,"Past");
										flag=0;
										printf("\n only paste Part present \n");fflush(stdout);
									}
									else if(tc_strcmp(childPartitmID,Part_Emulsion)==0)
									{
										//strcpy(output,"Emulsion");
										flag=0;
										printf("\n only Emulsion Part present \n");fflush(stdout);
									}
									else 
									{
										flag=1;
										printf("\n not have paste or Emulsion Part present \n");fflush(stdout);
									}
								}
							}
							if (flag==1)
							{
								printf("\n Flag set \n");fflush(stdout);
								int countlb =0;
								tag_t* bvrlb =NULLTAG;
								ITK_CALL(ITEM_rev_list_bom_view_revs(partrevisionM,&countlb,&bvrlb));
								printf("\n Number of bom view (countlb) [%d] \n",countlb);fflush(stdout);
								
								ITKCALL(PS_create_occurrences(bvrlb[0],parttag,NULLTAG,1,&occurrences));
								printf("\n create_occurrences1 \n");fflush(stdout);
								ITKCALL(PS_create_occurrences(bvrlb[0],parttag1,NULLTAG,1,&occurrences1)); 
								printf("\n create_occurrences2 \n");fflush(stdout);
						
								ITKCALL(PS_set_occurrence_qty(bvrlb[0], occurrences[0],0.25));
								printf("\n set_occurrence_qty1 \n");fflush(stdout);
								ITKCALL(PS_set_occurrence_qty(bvrlb[0], occurrences1[0],1.35));
								printf("\n set_occurrence_qty2 \n");fflush(stdout);
								ITKCALL(AOM_save_with_extensions(bvrlb[0])); 
								ITKCALL(AOM_save_with_extensions(partrevisionM));
						
								if(occurrences) 
									MEM_free(occurrences);
								else if(occurrences1)
									MEM_free(occurrences1); 								
							}
							
						}
						
					}
				}
				else
				{
					strcpy(output,"RawCnt");
					printf("\n Not have any Raw part \n");fflush(stdout);
				}
			}
			 else
			{
				continue;
			} 
		}
	}
	else
	{
		strcpy(output,"TNHP");
		printf("\n Selected Task Not having any Part. \n");
	}
	*((char **) return_data) = 
			   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output);	
	MEM_free(output);			
	return ITK_ok;
}

int AddULMEChk(void *return_data)
{
	char 			*selectedTask		= 	NULL;
	int n_tags_found					=0;
    tag_t* tags_found 					= NULL;
	const char *attrs[1];
    const char *values[1];
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	attrs[0] ="item_id";
	values[0] = (char *)selectedTask;
	ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);
	AddULMPEpart(selectedTask,n_tags_found ,tags_found,return_data);
	
	
}

extern int tm_AddULMPEChkcalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 1;
	int retValueType;
	int inputArgTypes[1] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //Selected Task

		
	retValueType = USERARG_STRING_TYPE ; 
	//printf("\n tm_AddULMPEChkcalling before....AddULMEChk");fflush(stdout);  
	ifail=USERSERVICE_register_method("AddULMEChk",(USER_function_t)AddULMEChk,nargs,inputArgTypes,retValueType);
	//printf("\n tm_AddULMPEChkcalling After....>>>>>>>>>>>>>>>>>>>>>>>>>AddULMEChk>>>>>>>>>>>>>>>>>>>>>>>\n\n\n");fflush(stdout);  
	
	return ifail;
}

extern DLLAPI int tm_addULM_register_callbacks ()
{	
	int ifail    = ITK_ok;
	//printf("\n Before registering userservice....tm_addULM");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_addULM", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_AddULMPEChkcalling);
	//printf("\n After registering userservice....tm_addULM");fflush(stdout);
	return(ITK_ok);
}