

	#include <stdlib.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	#include <tc/iman.h>
	#include <tccore/imantype.h>
	#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <tccore/aom_prop.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>
	#include <pie/pie.h>
	#include <cfm/cfm.h>
	#include <bom/bom.h>
	//#include "collection.h"
	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text ( stat, &err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}


void setAddTagP(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}

void setAddStrP(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n VVVVVVVVVVVVVV1===%s",(*strset)[*count-1]);fflush(stdout);


	}


//Start for expandPlatform_ModuleFunc User service

int expandPlatform_ModuleFunc(void *retValue)
{
	const char				*prog_name 		="expandPlatform_ModuleFunc";
	int ifail = ITK_ok;
	USERSERVICE_array_t 	array_structure;
	char 					**string_array 	= NULL;	
	tag_t platformRevTag = NULLTAG;
	
	char 			*platform_id				= NULL;
	char 			*var_name				= NULL;
	char 			*var_type				= NULL;
	char 			*platform_type				= NULL;
	int n_tags_found;
	tag_t *tags_found=NULLTAG;
	int n_vtags_found;
	tag_t *vtags_found=NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	tag_t   *bom_variant_rules=NULLTAG;
	//tag_t variantRuleTag=NULLTAG;
	tag_t platform_rev=NULLTAG;
	int rulefound;
	tag_t *closurerule=NULLTAG;
	tag_t *retModules=NULLTAG;
	tag_t close_tag;
	char **rulename;
	char **rulevalue;
	tag_t rev;
	int k;
	int moduleTagList_cnt=0;
	int rule_count;	
 char *iscolor;
 char *objtype;
	USERSERVICE_array_t* arrayStruct;
	USERARG_get_tag_argument(&platformRevTag); 
 USERARG_get_string_argument(&iscolor); 
	
	//USERARG_get_tag_array_argument(&array_size,&retModules);
 printf("\n Inside the Function expandPlatform_ModuleFunc \n");fflush(stdout);
	printf("\n Inside the Function expandPlatform_ModuleFunc ==%s \n",iscolor);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"item_id",&platform_id));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"object_type",&platform_type));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	
	//retModules = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	//object_type object_name

	if(platformRevTag)
	{

		printf("\n inside the variant rule condition");fflush(stdout);

		if(CFM_find( "Latest Working", &rule ));


		printf("\n after revisionRule find=[%u] ",rule);fflush(stdout);

		
		ITK_CALL(BOM_create_window (&bom_window)); 
		ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
   
   
   	printf("\n ADDING BOMWINDOW");fflush(stdout);
     setAddTagP(&moduleTagList_cnt,&retModules,top_line);
		
		printf("\n After inside bom_window-----\n"); fflush(stdout);			
		int n_lines1;
		tag_t *lines;
		int x;

		if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
		printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
		for(x=0;x<n_lines1;x++)
		{

			tag_t childline=lines[x];
			
				tag_t bl_item_rev=NULLTAG;
				//ITK_CALL(AOM_ask_value_tag(childline, "mfg0realRevision", &bl_item_rev ));
				ITK_CALL(AOM_ask_value_tag(childline, "bl_revision", &bl_item_rev ));
			//setAddTagP(&moduleTagList_cnt,&retModules,lines[x]);
			setAddTagP(&moduleTagList_cnt,&retModules,childline);
	//		setAddTagP(&moduleTagList_cnt,&retModules,bl_item_rev);
			
			//retModules=lines;               //Returning the modules of CCV
			tag_t child_item;
			char *bl_item_id;
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
			printf("\n [%d] bl_item_id1=%s",x,bl_item_id);fflush(stdout);
			tag_t bom_window1;
			tag_t top_line1;
			int n_lines2;
			tag_t *lines2;
			if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
			printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
			int y;
			for(y=0;y<   n_lines2;y++)
			{

				tag_t childline2=lines2[y];
				tag_t bl_item_rev2=NULLTAG;
				tag_t item=NULLTAG;
				char *bl_item_id2;
				//ITK_CALL(AOM_ask_value_tag(childline2, "mfg0realRevision", &bl_item_rev2 ));
				ITK_CALL(AOM_ask_value_tag(childline2, "bl_revision", &bl_item_rev2 ));
				ITK_CALL(ITEM_ask_item_of_rev(bl_item_rev2,&item));
				ITK_CALL(AOM_ask_value_string(item, "object_type",&objtype));
				
				printf("\n objtype=%s",objtype);fflush(stdout);
				
				if(tc_strcmp(objtype,"T5_ClrPart")==0)
				{
					
					if(tc_strcmp(iscolor,"0")==0)
					{
						
						printf("\n Skipping as flag=%s",iscolor);fflush(stdout);
					}
				
				}
				
			setAddTagP(&moduleTagList_cnt,&retModules,childline2);
		//	setAddTagP(&moduleTagList_cnt,&retModules,bl_item_rev2);
				ITK_CALL(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
				printf("\n[%d] bl_item_id2=%s",y,bl_item_id2);fflush(stdout);
			}

		}                                                                                                      
		
	
		
		printf("\n before USERSERVICE_return_tag_array call with values moduleTagList_cnt[%d]",moduleTagList_cnt);fflush(stdout);
		ITK_CALL(USERSERVICE_return_tag_array(retModules,moduleTagList_cnt,(USERSERVICE_array_t*)retValue));
		printf("\n after USERSERVICE_return_tag_array call");fflush(stdout);

	//ITK_CALL(BOM_close_window (bom_window)); 
	}
	printf("\n End calling func expandPlatform_ModuleFunc");fflush(stdout);
	return 	ifail;

}	



//Start for BOMVAriant apply User service

int ApplyBOMVariantRuleFunc(void *retValue)
{
	const char				*prog_name 		="ApplyBOMVariantRuleFunc";
	int ifail = ITK_ok;
	USERSERVICE_array_t 	array_structure;
	char 					**string_array 	= NULL;	
	tag_t platformRevTag = NULLTAG;
	tag_t variantRuleTag = NULLTAG;
	char 			*platform_id				= NULL;
	char 			*var_name				= NULL;
	char 			*var_type				= NULL;
	char 			*platform_type				= NULL;
	int n_tags_found;
	tag_t *tags_found=NULLTAG;
	int n_vtags_found;
	tag_t *vtags_found=NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	tag_t   *bom_variant_rules=NULLTAG;
	//tag_t variantRuleTag=NULLTAG;
	tag_t platform_rev=NULLTAG;
	int rulefound;
	tag_t *closurerule=NULLTAG;
	tag_t *retModules=NULLTAG;
	tag_t close_tag;
	char **rulename;
	char **rulevalue;
	tag_t rev;
	int k;
	int moduleTagList_cnt=0;
	int rule_count;	

	int variant_count;
	tag_t   *bom_variant_rule1=NULLTAG;

	USERSERVICE_array_t* arrayStruct;
	USERARG_get_tag_argument(&platformRevTag); 
	USERARG_get_tag_argument(&variantRuleTag);
	//USERARG_get_tag_array_argument(&array_size,&retModules);
	printf("\n Inside the Function BomVarApplyFunc \n");fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"item_id",&platform_id));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"object_type",&platform_type));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_name",&var_name));
	printf("\n var_name : %s",var_name);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_type",&var_type));
	printf("\n var_type : %s",var_type);   fflush(stdout);

	//retModules = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	//object_type object_name

	if(variantRuleTag)
	{

		printf("\n inside the variant rule condition");fflush(stdout);

		if(CFM_find( "Latest Working", &rule ));


		printf("\n after revisionRule find=[%u] ",rule);fflush(stdout);

		//if(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

		if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));		//Deprecated API Modification by Amar

		printf ("rule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("closure rule found \n");fflush(stdout);
			// MEM_free(tags_found);
		}
		ITK_CALL(BOM_create_window (&bom_window)); 
		ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
		ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
		ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
		//if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
		if ( BOM_window_ask_variant_rules( bom_window, &variant_count,&bom_variant_rule1 ));	//Deprecated API Modification by Amar
		tag_t bom_variant_rule = bom_variant_rule1[0];
		char *vname;
		if(bom_variant_rule==NULLTAG)
		{
			printf("\n  bom_variant_rule==NULLTAG");fflush(stdout);

		} 
		else 
		{
			printf("\n  bom_variant_rule NOT NULLTAG");fflush(stdout);
		}
		printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);
		tag_t varrule_tags[]={variantRuleTag};
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));
		ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));

		int var_list_count;
		tag_t *variant_rule_list=NULLTAG;
		BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);

		printf("\n RULE COUNT===%d", rule_count); fflush(stdout);

		for(k=0;k<rule_count;k++)
		{
			variantRuleTag=bom_variant_rules[k];
			ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_string", &vname));
			printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
		}
		printf("\n After inside bom_window-----\n"); fflush(stdout);			
		int n_lines1;
		tag_t *lines;
		int x;

		if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
		printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
		for(x=0;x<n_lines1;x++)
		{

			tag_t childline=lines[x];
			
			setAddTagP(&moduleTagList_cnt,&retModules,lines[x]);
			
			//retModules=lines;               //Returning the modules of CCV
			tag_t child_item;
			char *bl_item_id;
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
			printf("\n [%d] bl_item_id1=%s",x,bl_item_id);fflush(stdout);
			tag_t bom_window1;
			tag_t top_line1;
			int n_lines2;
			tag_t *lines2;
			if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
			printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
			int y;
			for(y=0;y<   n_lines2;y++)
			{

				tag_t childline2=lines2[y];
				char *bl_item_id2;
				ITK_CALL(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
				printf("\n[%d] bl_item_id2=%s",y,bl_item_id2);fflush(stdout);
			}

		}                                                                                                      
		//ITK_CALL(get_bom_window_legacy_variant_option(bom_window));
		printf("\n before USERSERVICE_return_tag_array call with values moduleTagList_cnt[%d]",moduleTagList_cnt);fflush(stdout);
		ITK_CALL(USERSERVICE_return_tag_array(retModules,moduleTagList_cnt,(USERSERVICE_array_t*)retValue));
		printf("\n after USERSERVICE_return_tag_array call");fflush(stdout);

	}
	printf("\n End calling func BomVarApplyFunc");fflush(stdout);
	return 	ifail;

}

//Start for BOMVAriant apply User service

int ApplyBOMVariantRuleFunc1(void *retValue)
{
	const char				*prog_name 		="ApplyBOMVariantRuleFunc1";
	int ifail = ITK_ok;
	USERSERVICE_array_t 	array_structure;
	char 					**string_array 	= NULL;	
	tag_t platformRevTag = NULLTAG;
	tag_t variantRuleTag = NULLTAG;
	char 			*platform_id				= NULL;
	char 			*var_name				= NULL;
	char 			*var_type				= NULL;
	char 			*platform_type				= NULL;
	int n_tags_found;
	tag_t *tags_found=NULLTAG;
	int n_vtags_found;
	tag_t *vtags_found=NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	tag_t   *bom_variant_rules=NULLTAG;
	//tag_t variantRuleTag=NULLTAG;
	tag_t platform_rev=NULLTAG;
	int rulefound;
	tag_t *closurerule=NULLTAG;
	tag_t *retModules=NULLTAG;
	tag_t close_tag;
	char **rulename;
	char **rulevalue;
	tag_t rev;
	int k;
	int moduleTagList_cnt=0;
	int rule_count;	
	char *parent_child=NULL;
	int str_count=0;
	char **bom_list=NULL;
	char *rev_rule_name=NULL;
	char *closure_rule_name=NULL;
	char *bl_item_name=NULL;

	int variant_count;
	tag_t   *bom_variant_rule1=NULLTAG;
	
	//collection v;
	USERSERVICE_array_t* arrayStruct;
	USERARG_get_tag_argument(&platformRevTag); 
	USERARG_get_tag_argument(&variantRuleTag);
	USERARG_get_string_argument(&rev_rule_name);
	USERARG_get_string_argument(&closure_rule_name);
	//USERARG_get_tag_array_argument(&array_size,&retModules);
	printf("\n Inside the Function BomVarApplyFunc \n");fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"item_id",&platform_id));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(platformRevTag,"object_type",&platform_type));
	printf("\n platform_id : %s",platform_id);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_name",&var_name));
	printf("\n var_name : %s",var_name);   fflush(stdout);
	ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_type",&var_type));
	printf("\n var_type : %s",var_type);   fflush(stdout);

	//retModules = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	//object_type object_name
	
	parent_child=(char *)MEM_alloc( 200 );
	//collection_init(&v);

	if(variantRuleTag)
	{

		printf("\n inside the variant rule condition");fflush(stdout);

		if(rev_rule_name==NULL)
		{
		if(CFM_find( "Latest Working", &rule ));
		}
	else{
		
		if(CFM_find( rev_rule_name, &rule ));
	}


		printf("\n after revisionRule find=[%u] ",rule);fflush(stdout);
		
		if(closure_rule_name==NULL)
		{

		//if(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
		if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));		//Deprecated API Modification by Amar
		}
		else{
			
			//if(PIE_find_closure_rules( closure_rule_name,PIE_TEAMCENTER, &rulefound, &closurerule ));
			if(PIE_find_closure_rules2( closure_rule_name,PIE_TEAMCENTER, &rulefound, &closurerule ));		//Deprecated API Modification by Amar

		}		printf ("rule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("closure rule found \n");fflush(stdout);
			// MEM_free(tags_found);
		}
		ITK_CALL(BOM_create_window (&bom_window)); 
		ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
		ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
		ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
		//if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
		if ( BOM_window_ask_variant_rules( bom_window, &variant_count,&bom_variant_rule1 ));	//Deprecated API Modification by Amar
		tag_t bom_variant_rule = bom_variant_rule1[0];
		char *vname;
		if(bom_variant_rule==NULLTAG)
		{
			printf("\n  bom_variant_rule==NULLTAG");fflush(stdout);

		} 
		else 
		{
			printf("\n  bom_variant_rule NOT NULLTAG");fflush(stdout);
		}
		printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);
		tag_t varrule_tags[]={variantRuleTag};
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));
		ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));

		int var_list_count;
		tag_t *variant_rule_list=NULLTAG;
		BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);

		printf("\n RULE COUNT===%d", rule_count); fflush(stdout);

		for(k=0;k<rule_count;k++)
		{
			variantRuleTag=bom_variant_rules[k];
			ITK_CALL(AOM_ask_value_string(variantRuleTag,"object_string", &vname));
			printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
		}
		printf("\n After inside bom_window-----\n"); fflush(stdout);			
		int n_lines1;
		tag_t *lines;
		int x;

		if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
		printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
		for(x=0;x<n_lines1;x++)
		{

			tag_t childline=lines[x];
			
		//	setAddTagP(&moduleTagList_cnt,&retModules,lines[x]);
			
			//retModules=lines;               //Returning the modules of CCV
			tag_t child_item;
			char *bl_item_id;
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_object_name", &bl_item_name ));
			printf("\n [%d] bl_item_id1=%s bl_item_name==%s",x,bl_item_id,bl_item_name);fflush(stdout);
			tag_t bom_window1;
			tag_t top_line1;
			int n_lines2;
			tag_t *lines2;
			if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
			printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
			int y;
			for(y=0;y<   n_lines2;y++)
			{

				tag_t childline2=lines2[y];
				char *bl_item_id2;
				ITK_CALL(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
				
				tc_strcpy(parent_child,"");
				tc_strcat(parent_child,bl_item_id);
				tc_strcat(parent_child,"-");
				tc_strcat(parent_child,bl_item_name);
				tc_strcat(parent_child,"#");
				tc_strcat(parent_child,bl_item_id2);
				
				//collection_add(&v, parent_child);
				
				setAddStrP(&str_count,&bom_list,parent_child);
				
				printf("\n[%d] bl_item_id2=%s %s",y,bl_item_id2, parent_child);fflush(stdout);
			}

		}                                                                                                      
		//ITK_CALL(get_bom_window_legacy_variant_option(bom_window));
		printf("\n before USERSERVICE_return_tag_array call with values moduleTagList_cnt[%d]",moduleTagList_cnt);fflush(stdout);
		ITK_CALL(USERSERVICE_return_string_array((const char**)bom_list,str_count,(USERSERVICE_array_t*)retValue));
		
		 
		printf("\n after USERSERVICE_return_string_array call");fflush(stdout);

	}
	printf("\n End calling func BomVarApplyFunc1");fflush(stdout);
	return 	ifail;

}
extern int ApplyBOMVariantRuleServCall()
{

  int ifail = ITK_ok;
	int nargs = 2;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE; // Platform Revision Tag
	inputArgTypes[1] = USERARG_TAG_TYPE; // Variant Rule Tag
	retValueType = USERARG_TAG_TYPE+USERARG_ARRAY_TYPE; // this will be output for modules 
	printf("\n ApplyBOMVariantRuleServCall before USERSERVICE_register_method");fflush(stdout);  
	ifail=USERSERVICE_register_method("ApplyBOMVariantRuleFunc",(USER_function_t)ApplyBOMVariantRuleFunc,nargs,inputArgTypes,retValueType);
	printf("\n ApplyBOMVariantRuleServCall AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

extern int ApplyBOMVariantRuleServCall1()
{

  int ifail = ITK_ok;
	int nargs = 4;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE; // Platform Revision Tag
	inputArgTypes[1] = USERARG_TAG_TYPE; // Variant Rule Tag
	inputArgTypes[2] = USERARG_STRING_TYPE;//Rev Rule
	inputArgTypes[3] = USERARG_STRING_TYPE;//Closure Rule
	retValueType = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // this will be output for modules 
	printf("\n ApplyBOMVariantRuleServCall before USERSERVICE_register_method");fflush(stdout);  
	ifail=USERSERVICE_register_method("ApplyBOMVariantRuleFunc1",(USER_function_t)ApplyBOMVariantRuleFunc1,nargs,inputArgTypes,retValueType);
	printf("\n ApplyBOMVariantRuleServCall11 AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

extern int expandPlatform_Module()
{

  int ifail = ITK_ok;
	int nargs = 2;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE; // Platform Revision Tag
	inputArgTypes[1] = USERARG_STRING_TYPE; // Variant Rule Tag
	retValueType = USERARG_TAG_TYPE+USERARG_ARRAY_TYPE; // this will be output for modules 
	printf("\n expandPlatform_Module before USERSERVICE_register_method");fflush(stdout);  
	ifail=USERSERVICE_register_method("expandPlatform_ModuleFunc",(USER_function_t)expandPlatform_ModuleFunc,nargs,inputArgTypes,retValueType);
	printf("\n expandPlatform_Module AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for BOMVAriant apply User service

extern int bomvarRuleFunc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
 ITK_CALL(expandPlatform_Module());
 ITK_CALL(ApplyBOMVariantRuleServCall());
 ITK_CALL(ApplyBOMVariantRuleServCall1());
 
 }



extern DLLAPI int tm_bomvarrule_register_callbacks ()
{
    //printf("tm_bomvarrule_register_callbacks\n");
	//printf("\ninside tm_bomvarrule_register_callbacks");fflush(stdout);
	ITK_CALL(CUSTOM_register_exit ( "tm_bomvarrule", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  bomvarRuleFunc));
/*	ITK_CALL(CUSTOM_register_exit ( "tm_bomvarrule", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  expandPlatform_Module));
	ITK_CALL(CUSTOM_register_exit ( "tm_bomvarrule", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  ApplyBOMVariantRuleServCall));
	ITK_CALL(CUSTOM_register_exit ( "tm_bomvarrule", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  ApplyBOMVariantRuleServCall1));*/

    return ITK_ok;
}
