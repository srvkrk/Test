/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_PartObsolescenceRequest.c
* Created By                   : Poonam
* Created On                   : 05-April-2025
* Project                      : TML/PartObsolescenceRequest
* Methods Defined              : CUSTOM_EXIT
* Description                  : On TML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
//#define _CRT_SECURE_NO_DEPRECATE					
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64 
#define PROJ_name_size_c   32 
#define	t9PrtObsReqCre_Val001 (EMH_USER_error_base+31)
#define	t9PrtObsReqCre_Val002 (EMH_USER_error_base+31)
#define	t9PrtObsReqCre_Val003 (EMH_USER_error_base+31)


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

#define ECHO(X) printf X; TC_write_syslog X


int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int t5CheckInPartLeadger(char *thisPartNumber);
int t5CreatePart(tag_t NewPartReqObj, char *vstr);
int AssignProject(tag_t  itemRev,char* projectcode);
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return pErrCdeLst[i];//ITK_ok;
}


static int t5CatiaNumbering(tag_t rev,char *thisPartNumber,logical updatable , int incrementval);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );
void setAddStr(int *count,char ***strset,char* str);

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

char *newval = (char*) malloc(12);

strncpy(newval, val,11);
printf("\n newval=%s",newval);fflush(stdout);

return newval;

}
char* prtObsReqsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(30);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}
int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	QRY_find2("Item Revision...", &query);
	QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj);
	printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}
int getTCObjectCount(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	QRY_find2("Item Revision...", &query);
	QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj);
	printf("\n getLatestPart: count==>%d", count);fflush(stdout);
	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return count;
}

extern EPM_decision_t DLLAPI Chk_ObsReqPResPrtyAssignLC(EPM_rule_message_t msg)
				{
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
					char*			t5current_name				=NULL;
					char*			procedure_name				=NULL;
					tag_t Ind_PT_rel_type	= NULLTAG;

					tag_t *taskAttachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndLcmTag = NULLTAG;
					tag_t objTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int ifail=0,count=0,n_parents=0;
					int attachmentCount=0;
					int RSPcount=0;
					tag_t *IndRspy = NULLTAG;
					tag_t IndRspyTag = NULLTAG;
					char*			obj_type					= NULL;
					char *type_name7 = NULL;
					tag_t* signOffTags = NULLTAG;
					int cnt=0;
					int IndResPartyFlag=0;

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for Chk_ObsReqPResPrtyAssignLC"); fflush(stdout);
					
					if(EPM_ask_attachments(msg.task, EPM_signoff_attachment,&cnt, &signOffTags)!=ITK_ok)PrintErrorStack();
					printf("\n No of Sign off Tags ===> %d\n",cnt);fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);
					int h=0;
					if(cnt>0)
					{
					for(h=0 ; h<cnt; h++)
					{
					
					tag_t signOffTag = NULLTAG;
					EPM_signoff_decision_t decsn = EPM_no_decision;
					char* comments = NULL;
					date_t decision_date = NULLDATE;
					signOffTag = signOffTags[h];
					if(EPM_ask_signoff_decision(signOffTag, &decsn, &comments, &decision_date)!=ITK_ok)PrintErrorStack();
					printf("\n comments ==> %s\n",comments);fflush(stdout);
					if (decsn==EPM_approve_decision)
					{
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\nattachmentCount:[%d]",attachmentCount);
					if(attachmentCount > 0)
					{
						objTag = taskAttachments[0];
						
						WSOM_ask_object_type2(objTag,&obj_type);
						printf("\n PartObs type in Assign parti----->[%s]",obj_type); fflush(stdout);
					}
					
					if(GRM_find_relation_type("HasParticipant", &Ind_PT_rel_type)!=ITK_ok)PrintErrorStack();
					if (Ind_PT_rel_type!=NULLTAG)
					{
						printf("\nPartObs type Has participant. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(objTag,Ind_PT_rel_type,&RSPcount,&IndRspy)!=ITK_ok)PrintErrorStack();
						printf("\n PartObsReq Reponsible Party count: %d",RSPcount);fflush(stdout);	
					}
					
					if (RSPcount >0)
					{
						int jk=0;
					
						for (jk=0;jk<RSPcount ;jk++ )
						{	
							tag_t ObjTypIndRspy = NULLTAG;
							IndRspyTag = IndRspy[jk];
							if(TCTYPE_ask_object_type(IndRspyTag,&ObjTypIndRspy));
							if(TCTYPE_ask_name2(ObjTypIndRspy,&type_name7));
							printf("\n Part Obs Req: Participants Name: %s", type_name7);fflush(stdout);
							//VI Reviewer will be work as Certification reviewer
							if (tc_strcmp(type_name7,"ProposedResponsibleParty")==0)
							{
								IndResPartyFlag=1;
								break;
							}
						}
					}
			

					 if (IndResPartyFlag==0)
					 {
						 EMH_clear_errors();
						 EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Assign Responsible Party.");
						 decision = EPM_nogo;
					 }else
					 {
						 decision = EPM_go;
					 }
					}
					}
				}

					return decision;
				}
extern EPM_decision_t DLLAPI Chk_ObsReqDMLRel_LC(EPM_rule_message_t msg)
	{

					
					EPM_decision_t decision = EPM_go;
					int ifail=0;
					tag_t	rootTask = NULLTAG;
					char* currentTaskName = NULL;
					char* parentTaskName = NULL;
					tag_t *targetobjects = NULLTAG;
					int targetobjects_count = 0;
					
					tag_t           *ObsDMLObjlist	= NULLTAG;
					CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
					printf("\nRoot task found");fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
					printf("\n Current Task:[%s]",currentTaskName);fflush(stdout);

					CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
					printf("\n Parent Name:[%s]",parentTaskName);fflush(stdout);	
					
					CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
					printf("\n targetobjects_count:[%d]",targetobjects_count);fflush(stdout);	
					tag_t ObsReqObjTag = NULLTAG;
					if(targetobjects_count > 0)
					{
						
						int i =0;
						tag_t objectTypeTag = NULLTAG;
						char *type_name = NULL;
						ObsReqObjTag = NULLTAG;
						int DmlCnt = 0;
						tag_t *DmlCntObjects = NULLTAG;
				
						for(i=0;i<targetobjects_count;i++)
						{
							CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
							CALLAPI(TCTYPE_ask_name2(objectTypeTag,&type_name));
							printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
							if (tc_strcmp(type_name,"T5_PrtObsReqRevision")==0)
							{
								ObsReqObjTag = targetobjects[i];
								break;										
									
							}
						}
						if(ObsReqObjTag !=NULLTAG)
						{
							CALLAPI(AOM_ask_value_tags(ObsReqObjTag,"T5_ObsReqHasDML",&DmlCnt,&DmlCntObjects));
							printf("\n ObsReqObj DML Count:[%d]",DmlCnt);fflush(stdout);
							int j=0;
							int ObsReqDMLAttched=0;
							char* object_type	=	NULL;
							char* DmlNum	=	NULL;
							if(DmlCnt>0)
							{
								for(j=0;j<DmlCnt;j++)
								{
									tag_t dmlTag = NULLTAG;
									dmlTag = DmlCntObjects[j];
									CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&object_type));
									printf("\n DML object_type is :[%s]",object_type);fflush(stdout);
									if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
									{
										CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&DmlNum));
										printf("\n DmlNum is :[%s]",DmlNum);fflush(stdout);
										ObsReqDMLAttched=1;
										break;
									}
								}
							}
							if(ObsReqDMLAttched>0)
							{
								
								decision = EPM_go;
							}
							else
							{
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Attched the DML in Obsolete Request has DML relation  before signOff.");
								decision = EPM_nogo;
							}
					
						}
					}
					
					return decision;
	
	}

					
int PartObsRequest_Reviewer_AssignFuction(EPM_action_message_t msg )
	{
		int error_code = ITK_ok;
		
		int			att_count= 0;
		int			count= 0;
		tag_t		rootTask_t			= NULLTAG;
		char*		obj_type			= NULL;
		char*		PrtObsReqNo		= NULL;
		char*		PrtObsReqChfEng		= NULL;
		char*		PrtObsReqCocRev		= NULL;
		char*		PrtObsDgnGrp		= NULL;
		tag_t*		attachments			= NULLTAG;
		tag_t		objTag				=  NULLTAG;
		
		
		EPM_ask_root_task(msg.task,&rootTask_t);
		EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments);
		
		if(count > 0)
		{
			for(att_count=0; att_count<count; att_count++)
			{
				objTag = attachments[0];
				WSOM_ask_object_type2(objTag, &obj_type);
				printf("\n PrtObsReqNo obj_type == [%s]\n", obj_type);fflush(stdout);

				if(tc_strcmp(obj_type,"T5_PrtObsReqRevision") == 0)
				{
					AOM_UIF_ask_value(objTag, "item_id", &PrtObsReqNo);
					printf("\n PrtObsReqNo item_id == [%s]\n", PrtObsReqNo);fflush(stdout);
					
					AOM_ask_value_string(objTag,"t5_DesignGroup",&PrtObsDgnGrp);
					printf("PrtObsDgnGrp ::  [%s]", PrtObsDgnGrp);fflush(stdout);

					AOM_ask_value_string(objTag,"t5_WTChfEng",&PrtObsReqChfEng);
					printf("PrtObsReqChfEng ::  %s\n", PrtObsReqChfEng);fflush(stdout);

					AOM_ask_value_string(objTag,"t5_CocReviewer",&PrtObsReqCocRev);
					printf("PrtObsReqCocRev ::  %s\n", PrtObsReqCocRev);fflush(stdout);
					
					char		*RoleName			= NULL;
					tag_t		role_tag		    = NULLTAG;
					tag_t		Grp_tag				= NULLTAG;
					tag_t*		ChfEng_Members	    = NULLTAG;
					tag_t		Chf_user_tag	    = NULLTAG;
					char		*user_id			= NULL;
					tag_t		ChfEng_participant  = NULLTAG;
					tag_t		ChfEng_Type_tag	    = NULLTAG;
					tag_t   ChfEng_head		= NULLTAG;
					
					char		*groupName			= NULL;
					
					RoleName = (char *) MEM_alloc( 100 * sizeof(char) );

					tc_strcpy(RoleName,"Chf_Eng_Role");
					printf("\n MT: RoleName  --> %s\n",RoleName);   fflush(stdout);
				
					groupName = (char *) MEM_alloc( 100 * sizeof(char) );
					tc_strcpy(groupName,"");
					tc_strcpy(groupName,"ERC_Designers_Group");
					printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);
					
					if(SA_find_group(groupName, &Grp_tag)!=ITK_ok);
					
					
					int			member_count		= 0;
					int			mem_count		= 0;
					if(SA_find_role2(RoleName,&role_tag)!=ITK_ok);
					if(SA_find_groupmember_by_role(role_tag,Grp_tag,&member_count,&ChfEng_Members)!=ITK_ok);
					printf("\n ChfEng_Members member_count :: [%d]", member_count);fflush(stdout);

					if(member_count > 0)
					{
						for(mem_count=0; mem_count<member_count; mem_count++)
						{
							
							ChfEng_head=ChfEng_Members[mem_count];
							
							if(SA_ask_groupmember_user(ChfEng_head, &Chf_user_tag)!=ITK_ok);							
							
							if((POM_ask_user_id(Chf_user_tag, &user_id))!=ITK_ok);
							printf("\n user_id  ::  [%s]", user_id);fflush(stdout);
							printf("\n PrtObsReqChfEng  ::  [%s]", PrtObsReqChfEng);fflush(stdout);
							if(tc_strstr(PrtObsReqChfEng, user_id) != NULL)
							{
								printf(" Assigning PrtObsReqChfEng ............. \n");fflush(stdout);
								printf("Chf user_id  ::  [%s]", user_id);fflush(stdout);
								if(EPM_get_participanttype ("T5_PrtObsReqChfEng",&ChfEng_Type_tag)!=ITK_ok);
								if(EPM_create_participant(ChfEng_head,ChfEng_Type_tag,&ChfEng_participant)!=ITK_ok)
								AOM_refresh( objTag, TRUE);
								PARTICIPANT_add_participant(objTag,TRUE,ChfEng_participant);
								AOM_save_without_extensions(objTag);
								AOM_refresh(objTag,FALSE);
								break;
							}							
						}

						MEM_free(user_id);	
						MEM_free(ChfEng_Members);
					}
					
					//Assign t5_CocReviewer
					char		*CocRoleName			= NULL;
					tag_t		Cocrole_tag		    = NULLTAG;
					tag_t		cocGrp_tag				= NULLTAG;
					tag_t*		CocEng_Members	    = NULLTAG;
					tag_t		Coc_user_tag	    = NULLTAG;
					char		*Cocuser_id			= NULL;
					tag_t		CocEng_participant  = NULLTAG;
					tag_t		CocEng_Type_tag	    = NULLTAG;
					
					char		*cocgroupName			= NULL;
					tag_t   CoC_head		= NULLTAG;
					
					CocRoleName = (char *) MEM_alloc( 100 * sizeof(char) );
					
					tc_strcpy(CocRoleName,PrtObsDgnGrp);
					tc_strcat(CocRoleName,"_Managers");
					printf("\n MT: CocRoleName  --> %s\n",CocRoleName);   fflush(stdout);
				
					cocgroupName = (char *) MEM_alloc( 100 * sizeof(char) );
					tc_strcpy(cocgroupName,"");
					tc_strcpy(cocgroupName,"ERC_Designers_Group");
					printf("\n MT: cocgroupName  --> %s\n",cocgroupName);   fflush(stdout);
					
					if(SA_find_group(cocgroupName, &cocGrp_tag)!=ITK_ok);
					
					
					int			Cocmember_count		= 0;
					int			CoCmem_count		= 0;
					if(SA_find_role2(CocRoleName,&Cocrole_tag)!=ITK_ok);
					if(SA_find_groupmember_by_role(Cocrole_tag,cocGrp_tag,&Cocmember_count,&CocEng_Members)!=ITK_ok);
					TC_write_syslog("CocEng_Members Cocmember_count ::  %d\n", Cocmember_count);
					printf("CocEng_Members Cocmember_count ::  %d\n", Cocmember_count);fflush(stdout);
					int PrtObsCOCFound=0;
					if(Cocmember_count > 0)
					{
						for(CoCmem_count=0; CoCmem_count<Cocmember_count; CoCmem_count++)
						{
							
							CoC_head=CocEng_Members[CoCmem_count];
							if(SA_ask_groupmember_user(CoC_head, &Coc_user_tag)!=ITK_ok);							
							
							if((POM_ask_user_id(Coc_user_tag, &Cocuser_id))!=ITK_ok);
							printf("\n Cocuser_id  ::  [%s]", Cocuser_id);fflush(stdout);
							printf("\n PrtObsReqCocRev  ::  [%s]", PrtObsReqCocRev);fflush(stdout);
							if(tc_strstr(PrtObsReqCocRev, Cocuser_id) != NULL)
							{
								printf("Assigning PrtObsReqCocRev ............. \n");fflush(stdout);
								printf(" Cocuser_id  ::  [%s]", Cocuser_id);fflush(stdout);
								if(EPM_get_participanttype ("T5_PrtObsReq_CocRev",&CocEng_Type_tag)!=ITK_ok);
								if(EPM_create_participant(CoC_head,CocEng_Type_tag,&CocEng_participant)!=ITK_ok)
								AOM_refresh( objTag, TRUE);
								PARTICIPANT_add_participant(objTag,TRUE,CocEng_participant);
								AOM_save_without_extensions(objTag);
								AOM_refresh(objTag,FALSE);
								PrtObsCOCFound = 1;
								break;
							}							
						}

						MEM_free(Cocuser_id);	
						MEM_free(CocEng_Members);
					}
				}
			}
		}
		printf("\n Exit PartObsRequest_Reviewer_AssignFuction\n");fflush(stdout);
		return error_code;
	}
/****************************************************************************
Function:       NewPartReqItem_create_pre_condition
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int PrtObsReqItem_create_pre_condition(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
	
	printf("\n PrtObsReqItem_create_pre_condition\n");fflush(stdout);
	
	char *item_type=NULL;
	
	AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **PrtObsReqItem_create_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	printf("\n **PrtObsReqItem_create_pre_condition::isNew = [%d]\n", isNew);fflush(stdout);
	
	char *verticalName=NULL;
	char *verticalNameDup=NULL;
	char *WTChfEngName=NULL;
	char *WTChfEngNameDup=NULL;
	char *CocReviewerName=NULL;
	char *CocReviewerNameDup=NULL;
	char *DesGroupDup=NULL;
	char *DesGroup=NULL;
	char *grpName=NULL;
	char *projectName=NULL;
	char *roleName=NULL;
	
	tag_t userSession=NULLTAG;
	tag_t	latestitemrev=NULLTAG;
	

		if(tc_strcmp(item_type,"T5_PrtObsReqRevision")==0)
		{
			//if(ITEM_ask_latest_rev(item,&latestitemrev));
			//if(latestitemrev!=NULLTAG)
			//{
			CE_current_user_session_tag(&userSession);
			AOM_ask_value_string(userSession,"group_name",&grpName);
			printf("\n PrtObsReqItem_create_pre_condition::grpName====>[%s]", grpName);fflush(stdout);

			AOM_ask_value_string(userSession,"project_name",&projectName);
			printf("\n PrtObsReqItem_create_pre_condition::projectName====>[%s]", projectName);fflush(stdout);

			AOM_ask_value_string(userSession,"role_name",&roleName);
			printf("\n PrtObsReqItem_create_pre_condition::roleName====>[%s]", roleName);fflush(stdout);
			
			AOM_ask_value_string(item,"t5_Vertivcal",&verticalName);
			verticalNameDup = strdup(verticalName);
			printf("\n PrtObsReqItem_create_pre_condition:: verticalNameDup====>[%s]", verticalName);fflush(stdout);
			
			AOM_ask_value_string(item,"t5_WTChfEng",&WTChfEngName);
			WTChfEngNameDup = strdup(WTChfEngName);
			printf("\n PrtObsReqItem_create_pre_condition:: WTChfEngNameDup====>[%s]", WTChfEngNameDup);fflush(stdout);
			
			AOM_ask_value_string(item,"t5_CocReviewer",&CocReviewerName);
			CocReviewerNameDup = strdup(CocReviewerName);
			printf("\n PrtObsReqItem_create_pre_condition:: CocReviewerName====>[%s]", CocReviewerName);fflush(stdout);
			
			AOM_ask_value_string(item,"t5_DesignGroup",&DesGroup);
			DesGroupDup = strdup(DesGroup);
			printf("\n PrtObsReqItem_create_pre_condition:: DesGroupDup====>[%s]", DesGroupDup);fflush(stdout);
			
			if(tc_strlen(verticalNameDup)==0)
			{
				ifail=t9PrtObsReqCre_Val001;
				EMH_store_error_s1(EMH_severity_error,ifail,"Vertical Selection is Required");
				return ifail;
			}
			
			if(tc_strlen(WTChfEngNameDup)==0)
			{
				ifail=t9PrtObsReqCre_Val002;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Cheif Engineer !!");
				return ifail;
			}
			
			if(tc_strlen(CocReviewerNameDup)==0)
			{
				ifail=t9PrtObsReqCre_Val003;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select the CoC Reviewer !!");
				return ifail;
			}
			if(tc_strlen(DesGroupDup)==0)
			{
				ifail=t9PrtObsReqCre_Val003;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Design Group !!");
				return ifail;
			}
			
			// AOM_ask_value_string(latestitemrev,"t5_BusinessUnit",&BusUnitName);
			// BusUnitNameDup = strdup(BusUnitName);
			// printf("\n PrtObsReqItem_create_pre_condition:: BusUnitName====>[%s]", BusUnitName);fflush(stdout);
			
			// AOM_ask_value_string(latestitemrev,"t5_Reason",&ReasonName);
			// ReasonNameDup = strdup(ReasonName);
			// printf("\n PrtObsReqItem_create_pre_condition:: ReasonNameDup====>[%s]", ReasonNameDup);fflush(stdout);
			
			// AOM_ask_value_string(latestitemrev,"t5_Remark",&RemarkName);
			// RemarkNameDup = strdup(RemarkName);
			// printf("\n PrtObsReqItem_create_pre_condition:: RemarkName====>[%s]", RemarkNameDup);fflush(stdout);
			
			// AOM_ask_value_string(latestitemrev,"t5_ProjectCode",&ProjectCode);
			// ProjectCodeDup = strdup(ProjectCode);
			// printf("\n PrtObsReqItem_create_pre_condition:: ProjectCodeDup====>[%s]", ProjectCodeDup);fflush(stdout);
			
			// AOM_ask_value_string(latestitemrev,"t5_DesignGroup",&DesGroup);
			// DesGroupDup = strdup(DesGroup);
			// printf("\n PrtObsReqItem_create_pre_condition:: DesGroupDup====>[%s]", DesGroupDup);fflush(stdout);
				
			// now = time(0);
			// if ((tm = localtime (&now)) == NULL) {printf ("Error extracting time \n");fflush(stdout);}
			// year = (char *) MEM_alloc( 10 * sizeof(char) );
			
			// sprintf(year,"%d",tm->tm_year+1900-2000);
			// printf("\n year->%s",year);fflush(stdout);
			
			// PrtObsReqItemIdSearch = (char *) MEM_alloc( 100 * sizeof(char) );
			// PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
			
			// PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
			// PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
			
			// strcpy(PrtObsReqItemIdSearch,"");
			// strcpy(PrtObsReqItemIdSearch,"ObsModule_");
			// strcat(PrtObsReqItemIdSearch,"*");
			// strcat(PrtObsReqItemIdSearch,"_");
			// strcat(PrtObsReqItemIdSearch,year);
			// strcat(PrtObsReqItemIdSearch,"_");
			// strcat(PrtObsReqItemIdSearch,"*");
			
			// strcpy(PrtObsReqItemId,"");
			// strcpy(PrtObsReqItemId,"ObsModule_");
			// strcat(PrtObsReqItemId,verticalNameDup);
			// strcat(PrtObsReqItemId,"_");
			// strcat(PrtObsReqItemId,year);
			// strcat(PrtObsReqItemId,"_");
			// strcat(PrtObsReqItemId,"00001");
			
			// tag_t PrtObsReqTag = NULLTAG;
			// int ObsReqIdCount=0;
			
			// getTCObject(PrtObsReqItemIdSearch,"T5_PrtObsReqRevision",&PrtObsReqTag,ObsReqIdCount);fflush(stdout);
			// printf("\nNumber of object already created  [%d]",ObsReqIdCount);fflush(stdout);
			
		
		//}
		}
	
 return ifail;
}

/****************************************************************************
Function:       PrtObsReqItem_create_post_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int PrtObsReqItem_create_post_action(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
	tag_t userSession=NULLTAG;
	logical hasBypass=false;
	char   *user_id=NULL;
	
	tag_t	user_tag=NULLTAG;
	tag_t	latestitemrev=NULLTAG;
	
	char *item_type=NULL;
    char *itemId=NULL;
    char *verticalName=NULL;
    char *verticalNameDup=NULL;
    char *PrtObsReqItemIdSearch=NULL;
    char *PrtObsReqItemId=NULL;
    char *BusUnitNameDup=NULL;
    char *BusUnitName=NULL;
    char *ReasonNameDup=NULL;
    char *ReasonName=NULL;
    char *RemarkNameDup=NULL;
    char *RemarkName=NULL;
    char *ProjectCodeDup=NULL;
    char *ProjectCode=NULL;
    char *DesGroupDup=NULL;
    char *DesGroup=NULL;
    char *WTChfEngNameDup=NULL;
    char *WTChfEngName=NULL;
    char *CocReviewerNameDup=NULL;
    char *CocReviewerName=NULL;
	char *newPrtObsReqItemId=NULL;
	char *NewitemId=NULL;
	
	time_t now;
	struct tm *tm;
	char *year=NULL;
	
	printf("\n PrtObsReqItem_create_post_action\n");fflush(stdout);
	
	AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **PrtObsReqItem_create_post_action::type_name = [%s]\n", item_type);fflush(stdout);
	
	POM_get_user_id(&user_id);
	SA_find_user2(user_id, &user_tag);
	
    if(tc_strcmp(item_type,"T5_PrtObsReq")==0)
	{
		if(ITEM_ask_latest_rev(item,&latestitemrev));
		if(latestitemrev!=NULLTAG)
		{
		
		CALLAPI(CE_current_user_session_tag(&userSession));
		CALLAPI(AOM_ask_value_logical(userSession,"fnd0bypassflag",&hasBypass));
		
			printf("\nHAS By pass Flag is FALSE") ;fflush(stdout);
			
			if(isNew==true)
			{
				/*All Custom Validation Called Here !!!!!*/
				AOM_ask_value_string(latestitemrev,"item_id",&itemId);
				printf("\n In PrtObsReqItem_create_post_action In Message Code ::PrtObReq Item ID %s\n",itemId);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_BusinessUnit",&BusUnitName);
				BusUnitNameDup = strdup(BusUnitName);
				printf("\n PrtObsReqItem_create_pre_condition:: BusUnitName====>[%s]", BusUnitName);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_Reason",&ReasonName);
				ReasonNameDup = strdup(ReasonName);
				printf("\n PrtObsReqItem_create_pre_condition:: ReasonNameDup====>[%s]", ReasonNameDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_Remark",&RemarkName);
				RemarkNameDup = strdup(RemarkName);
				printf("\n PrtObsReqItem_create_pre_condition:: RemarkName====>[%s]", RemarkNameDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_ProjectCode",&ProjectCode);
				ProjectCodeDup = strdup(ProjectCode);
				printf("\n PrtObsReqItem_create_pre_condition:: ProjectCodeDup====>[%s]", ProjectCodeDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_DesignGroup",&DesGroup);
				DesGroupDup = strdup(DesGroup);
				printf("\n PrtObsReqItem_create_pre_condition:: DesGroupDup====>[%s]", DesGroupDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_WTChfEng",&WTChfEngName);
				WTChfEngNameDup = strdup(WTChfEngName);
				printf("\n PrtObsReqItem_create_pre_condition:: WTChfEngNameDup====>[%s]", WTChfEngNameDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_CocReviewer",&CocReviewerName);
				CocReviewerNameDup = strdup(CocReviewerName);
				printf("\n PrtObsReqItem_create_pre_condition:: CocReviewerNameDup====>[%s]", CocReviewerNameDup);fflush(stdout);
				
				AOM_ask_value_string(latestitemrev,"t5_Vertivcal",&verticalName);
				verticalNameDup = strdup(verticalName);
				printf("\n PrtObsReqItem_create_pre_condition:: verticalNameDup====>[%s]", verticalName);fflush(stdout);
				
				now = time(0);
				if ((tm = localtime (&now)) == NULL) {printf ("Error extracting time \n");fflush(stdout);}
				year = (char *) MEM_alloc( 10 * sizeof(char) );
				
				sprintf(year,"%d",tm->tm_year+1900-2000);
				printf("\n year->%s",year);fflush(stdout);
				
				PrtObsReqItemIdSearch = (char *) MEM_alloc( 100 * sizeof(char) );
				PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
				
				PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
				PrtObsReqItemId = (char *) MEM_alloc( 100 * sizeof(char) );
				
				strcpy(PrtObsReqItemIdSearch,"");
				strcpy(PrtObsReqItemIdSearch,"ObsModule_");
				strcat(PrtObsReqItemIdSearch,"*");
				strcat(PrtObsReqItemIdSearch,"_");
				strcat(PrtObsReqItemIdSearch,year);
				strcat(PrtObsReqItemIdSearch,"_");
				strcat(PrtObsReqItemIdSearch,"*");
				
				strcpy(PrtObsReqItemId,"");
				strcpy(PrtObsReqItemId,"ObsModule_");
				strcat(PrtObsReqItemId,verticalNameDup);
				strcat(PrtObsReqItemId,"_");
				strcat(PrtObsReqItemId,year);
				strcat(PrtObsReqItemId,"_");
				strcat(PrtObsReqItemId,"00001");
				
				tag_t PrtObsReqTag = NULLTAG;
				int ObsReqIdCount=0;
				
				ObsReqIdCount=getTCObjectCount(PrtObsReqItemIdSearch,"T5_PrtObsReqRevision",&PrtObsReqTag);fflush(stdout);
				printf("\nNumber of object already created  [%d]",ObsReqIdCount);fflush(stdout);
				char *ObsReqIdCountStr=NULL;
				ObsReqIdCountStr = (char *) MEM_alloc( 1000 * sizeof(char) );
				strcpy(ObsReqIdCountStr,"");
				sprintf(ObsReqIdCountStr,"%d",ObsReqIdCount);
				printf("\nNumber of object already created  [%d]",ObsReqIdCount);fflush(stdout);
				
				if(ObsReqIdCount==0)
				{
					printf("\nIndent is already created [%d]",ObsReqIdCount);fflush(stdout);
					strcpy(PrtObsReqItemId,"");
					strcpy(PrtObsReqItemId,"ObsModule_");
					strcat(PrtObsReqItemId,verticalNameDup);
					strcat(PrtObsReqItemId,"_");
					strcat(PrtObsReqItemId,year);
					strcat(PrtObsReqItemId,"_00");
				}
				else
				{
					printf("\nNumber of object [%d]",ObsReqIdCount);fflush(stdout);
					
					strcpy(PrtObsReqItemId,"");
					strcpy(PrtObsReqItemId,"ObsModule_");
					strcat(PrtObsReqItemId,verticalNameDup);
					strcat(PrtObsReqItemId,"_");
					strcat(PrtObsReqItemId,year);
					strcat(PrtObsReqItemId,"_0");
					strcat(PrtObsReqItemId,ObsReqIdCountStr);
				}
				
				PrtObsReqTag = NULLTAG;
				getTCObject(PrtObsReqItemId,"T5_PrtObsReqRevision",&PrtObsReqTag);fflush(stdout);
				
				if(PrtObsReqTag != NULLTAG)
				{
					printf("\n PartObsReq is already created [%s]",PrtObsReqItemId);fflush(stdout);
				}
				else
				{
				AOM_refresh( item, TRUE);
				AOM_set_value_string(item, "object_name", PrtObsReqItemId);
				AOM_set_value_string(item,"item_id",PrtObsReqItemId);
				AOM_set_value_string(item,"object_desc",PrtObsReqItemId);
				
				AOM_save_without_extensions(item);
				printf("\n PrtObsReqItem_create_post_action::After AOM_save_without_extensions\n");fflush(stdout);
				printf("\n PrtObsReqItem_create_post_action::Before AOM_refresh\n");fflush(stdout);
				AOM_refresh(item,FALSE);
				printf("\n PrtObsReqItem_create_post_action::After AOM_refresh\n");fflush(stdout);
				
				AOM_ask_value_string(item,"object_name",&newPrtObsReqItemId);
				printf(" ####### PrtObsReqItem_create_post_action::newPrtObsReqItemId No created with name--->[%s]\n",newPrtObsReqItemId);fflush(stdout);
				AOM_ask_value_string(item,"item_id",&NewitemId);
				printf(" ####### PrtObsReqItem_create_post_action::NewitemId No created with name--->[%s]\n",NewitemId);fflush(stdout);
				
				AOM_refresh( latestitemrev, TRUE);
				AOM_set_value_string(latestitemrev,"item_id",PrtObsReqItemId);
				AOM_set_value_string(latestitemrev,"object_desc",PrtObsReqItemId);
				AOM_save_without_extensions(latestitemrev);
				AOM_refresh(latestitemrev,FALSE);
							
				}
				tag_t relation_type_form = NULLTAG;
				int masterFormcount =0;
				int revmasterFormcount =0;
				
				tag_t *masterForm = NULLTAG;
				tag_t *revmasterForm = NULLTAG;
				
				GRM_find_relation_type("IMAN_master_form", &relation_type_form);
				if(relation_type_form!=NULLTAG)
				{
					GRM_list_secondary_objects_only(item,relation_type_form,&masterFormcount,&masterForm);
					GRM_list_secondary_objects_only(latestitemrev,relation_type_form,&revmasterFormcount,&revmasterForm);
					if(masterFormcount>0)
					{
						AOM_refresh( masterForm[0], TRUE);
						AOM_set_value_string(masterForm[0],"object_name",PrtObsReqItemId);
						AOM_save_without_extensions(masterForm[0]);
						AOM_refresh(masterForm[0],FALSE);					
					}
					if(revmasterFormcount>0)
					{
						AOM_refresh( revmasterForm[0], TRUE);
						AOM_set_value_string(revmasterForm[0],"object_name",PrtObsReqItemId);
						AOM_save_without_extensions(revmasterForm[0]);
						AOM_refresh(revmasterForm[0],FALSE);
					}
				}
				
			
			}
			
	}
	}
	
   return ifail;
}

/****************************************************************************
    Function:       tm_PartObsolescenceRequest_register_action_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_PartObsolescenceRequest_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						

		printf("\n tm_PartObsolescenceRequest_register_action_handlers\n");fflush(stdout);
		
		retcode = EPM_register_action_handler (
								"PartObsRequest_Reviewer",
								"PartObsRequest_Reviewer",
								(EPM_action_handler_t)PartObsRequest_Reviewer_AssignFuction
								);
								
	}
	return retcode;
}

/****************************************************************************
    Function:       tm_PartObsolescenceRequest_register_rule_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_PartObsolescenceRequest_register_rule_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						
		printf("\n tm_PartObsolescenceRequest_register_rule_handlers\n");fflush(stdout);
		
		retcode = EPM_register_rule_handler (
								"ObsReqProposedResParty_Check",
								"ObsReqProposedResParty_Check",
								(EPM_rule_handler_t)Chk_ObsReqPResPrtyAssignLC
								);
								
		printf("\n 11tm_PartObsolescenceRequest_register_rule_handlers\n");fflush(stdout);
		
		printf("\n tm_PartObsolescenceRequest_register_rule_handlers\n");fflush(stdout);
		
		retcode = EPM_register_rule_handler (
								"ObsReqDMLRel_Check",
								"ObsReqDMLRel_Check",
								(EPM_rule_handler_t)Chk_ObsReqDMLRel_LC
								);
								
		printf("\n 11tm_PartObsolescenceRequest_register_rule_handlers\n");fflush(stdout);
								
	}
	return retcode;
}


/****************************************************************************
Function:       Func_PartObsolescenceRequest
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

extern int Func_PartObsolescenceRequest(int *decision, va_list args)
{
    int          ifail = ITK_ok;
   	METHOD_id_t  method1;
   	METHOD_id_t  method2;
  
	int i=0;
    *decision = ALL_CUSTOMIZATIONS;


	ifail = (METHOD_find_method("T5_PrtObsReqRevision", "IMAN_save", &method1));
	ifail = (METHOD_find_method("T5_PrtObsReq", "IMAN_save", &method2));
	if (method2.id != 0)
	{
		printf("\nbefore Method is added now::PrtObsReqItem_create_post_action");fflush(stdout);
		ifail = ( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) PrtObsReqItem_create_post_action, NULL));
		printf("\nafter Method is added now::PrtObsReqItem_create_post_action");fflush(stdout);
		
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	
	if (method1.id != 0)
	{
		//printf("\nbefore Method is added now::PrtObsReqItem_create_post_action");fflush(stdout);
		//ifail = ( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) PrtObsReqItem_create_post_action, NULL));
		//printf("\nafter Method is added now::PrtObsReqItem_create_post_action");fflush(stdout);
		
		printf("\nbefore Method is added now::PrtObsReqItem_create_pre_condition");fflush(stdout);
		ifail = ( METHOD_add_pre_condition(method1, (METHOD_function_t) PrtObsReqItem_create_pre_condition, NULL));
		printf("\nafter Method is added now::PrtObsReqItem_create_pre_condition");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}


	printf("\n before tm_PartObsolescenceReques_register_action_handlers is added now");fflush(stdout);
	ifail = tm_PartObsolescenceRequest_register_action_handlers();
	printf("\n after tm_PartObsolescenceReques_register_action_handlers is added now");fflush(stdout);
	
	printf("\n before tm_PartObsolescenceReques_register_action_handlers is added now");fflush(stdout);
	ifail = tm_PartObsolescenceRequest_register_rule_handlers();
	printf("\n after tm_PartObsolescenceReques_register_rule_handlers is added now");fflush(stdout);

	
    return ifail;
}

/****************************************************************************
    Function:       tm_PartObsolescenceRequest_register_custom_handlers
    Description:    Registering custom entry point

    Input:          int *decision
					va_list args

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure 
****************************************************************************/
extern DLLAPI int tm_PartObsolescenceRequest_register_custom_handlers( int *decision , va_list args)
{
	int ifail = ITK_ok;
	ifail = tm_PartObsolescenceRequest_register_action_handlers();
	*decision  = ALL_CUSTOMIZATIONS;
	args = NULL;
	printf("\n tm_PartObsolescenceRequest_register_custom_handlers\n");fflush(stdout);
	return ifail;
}

extern DLLAPI int tm_PartObsolescenceRequest_register_callbacks ()
{
    int ifail    = ITK_ok;
    //printf("\n before Revise_register_callbacks tm_PartObsolescenceRequest");fflush(stdout);
    
    ifail=CUSTOM_register_exit ( "tm_PartObsolescenceRequest", "USER_init_module", (CUSTOM_EXIT_ftn_t)  Func_PartObsolescenceRequest);
   // printf("\n after calling tm_PartObsolescenceRequest \n");fflush(stdout);

  return ( ITK_ok );
}