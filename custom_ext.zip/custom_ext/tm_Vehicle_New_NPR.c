/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_Vehicle_New_NPR.c
* Created By                   : Sudhir
* Created On                   : 16-Sept-2024
* Project                      : TML/New Part Request
* Methods Defined              : CUSTOM_EXIT
* Description                  : On TML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
//#define _CRT_SECURE_NO_DEPRECATE					
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64 
#define PROJ_name_size_c   32 
#define	t9NewPartReqCre_Val001 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val002 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val003 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val004 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val005 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val006 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val007 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val008 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val009 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val010 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val011 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val012 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val013 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val014 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val015 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val016 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val017 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val018 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val019 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val020 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val021 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val022 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val023 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val024 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val025 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val026 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val027 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val028 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val029 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val030 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val031 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val032 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val033 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val034 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val035 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val036 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val037 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val038 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val039 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val040 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val041 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val042 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val043 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val044 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val045 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0046 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0047 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0048 (EMH_USER_error_base+21)


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

#define ECHO(X) printf X; TC_write_syslog X


int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int t5CheckInPartLeadger(char *thisPartNumber);
int t5CreatePart(tag_t NewPartReqObj, char *vstr);
int AssignProject(tag_t  itemRev,char* projectcode);
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return pErrCdeLst[i];//ITK_ok;
}


static int t5CatiaNumbering(tag_t rev,char *thisPartNumber,logical updatable , int incrementval);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );
void setAddStr(int *count,char ***strset,char* str);

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

char *newval = (char*) malloc(12);

strncpy(newval, val,11);
printf("\n newval=%s",newval);fflush(stdout);

return newval;

}
char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(30);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}

int AssignProject(tag_t  itemRev,char* projectcode)
{

	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

	// ITK_CALL(AOM_lock(itemRev));
	printf("\n\t projectcode [%s]\n",projectcode);fflush(stdout);
	ITK_CALL (PROJ_find(projectcode,&projobj));
	//printf("\n\t Assigned to Project \n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	//   ITK_CALL(AOM_save(itemRev));
	//  ITK_CALL(AOM_unlock(itemRev));

	return status;
}

static int FunToQueryIFDModuleAddress(char *ModuleAddress)
{

	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	int IFDMDADD_FOUND = 0;
	int n_found = 0;

	tag_t	query		= NULLTAG;
	tag_t	*q_item		= NULLTAG;

	char *modinfo01Str	= NULL;
	char *modinfo02Str	= NULL;
	char *modinfo03Str	= NULL;

	int retcode = ITK_ok;


	printf("\n ModuleAddress===%s",ModuleAddress);fflush(stdout);
	ctrl_qry_values[0]	= "ModAddForIM";
	ctrl_qry_values[1]	= "ModAddForIM";
	QRY_find2("Control Objects...", &query);
	if(query!=NULLTAG)
	{
		QRY_execute(query, 2, ctrl_qry_entries, ctrl_qry_values, &n_found, &q_item);
		printf("\n n_found===%d",n_found);fflush(stdout);
		if(n_found>0)
		{
			AOM_ask_value_string(q_item[0],"t5_Userinfo1",&modinfo01Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo2",&modinfo02Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo3",&modinfo03Str);
			if(tc_strstr(modinfo01Str,ModuleAddress)!=NULL 
				|| tc_strstr(modinfo02Str,ModuleAddress)!=NULL 
				|| tc_strstr(modinfo03Str,ModuleAddress)!=NULL)
			{
				IFDMDADD_FOUND = 1;
			}
		}
	}
	printf("\n IFDMDADD_FOUND===%d",IFDMDADD_FOUND);fflush(stdout);

	return IFDMDADD_FOUND;
}

static int FunToQueryModuleAddress(char *ModuleAddress)
{

	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	int ISMODULE_FOUND = 0;
	int n_found = 0;

	tag_t	query		= NULLTAG;
	tag_t	*q_item		= NULLTAG;

	char *modinfo04Str	= NULL;
	char *modinfo05Str	= NULL;
	char *modinfo06Str	= NULL;
	char *modinfo07Str	= NULL;
	char *modinfo08Str	= NULL;
	char *modinfo09Str	= NULL;
	char *modinfo010Str	= NULL;

	int retcode = ITK_ok;


	printf("\n ModuleAddress===%s",ModuleAddress);fflush(stdout);
	ctrl_qry_values[0]	= "ModAddForIM";
	ctrl_qry_values[1]	= "ModAddForIM";
	QRY_find2("Control Objects...", &query);
	if(query!=NULLTAG)
	{
		QRY_execute(query, 2, ctrl_qry_entries, ctrl_qry_values, &n_found, &q_item);
		printf("\n n_found===%d",n_found);fflush(stdout);
		if(n_found>0)
		{
			AOM_ask_value_string(q_item[0],"t5_Userinfo4",&modinfo04Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo5",&modinfo05Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo6",&modinfo06Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo7",&modinfo07Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo8",&modinfo08Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo9",&modinfo09Str);
			AOM_ask_value_string(q_item[0],"t5_userinfo10",&modinfo010Str);

			if(tc_strstr(ModuleAddress,modinfo04Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo05Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo06Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo07Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo08Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo09Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo010Str)!=NULL)
			{
				ISMODULE_FOUND = 1;
			}
		}
	}
	printf("\n ISMODULE_FOUND===%d",ISMODULE_FOUND);fflush(stdout);

	return ISMODULE_FOUND;
}

int IsDesignRevisionAvail(char* InputPart)
{
	int		IsAvailInUA		=	0;
	tag_t   OutPutTag		=	NULLTAG;
	tag_t   query		=	NULLTAG;
	int		n_tags_found2	=	0;
	tag_t	*tags_found2	=	NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int		n_tags_foundd2	=	0;
	tag_t	*tags_foundd2	=	NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};
	//MT end
	printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	//attrs2[0] ="item_id";
	//attrs2[1] ="object_type";
	//values2[0] = (char *)InputPart;
	//values2[1] = "Design";
	//if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();

	qry_values[0]	= InputPart;
	qry_values[1]	= "Design";
	QRY_find2("Item...", &query);
	QRY_execute(query, 2, qry_entries, qry_values, &n_tags_found2, &tags_found2);
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
		IsAvailInUA = 1;
		printf("\n Part found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	else
	{
		IsAvailInUA = 0;
		printf("\n Part not found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	return IsAvailInUA;
}


/*************************************************************************
To fetch Keyword Description from classification in LOV
*************************************************************************
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *Classi_class;
	char *DesignGrp;	
	int error_code = ITK_ok;
	int n_entries = 2;
	int n_found = 0;
	int ii = 0;
	int i;
	tag_t query = NULLTAG, *cntr_objects = NULL;
	
	int TotalLovCount = 0;
	int iMyLovCounter = 0;
	char *qry_entries[2] = {"Name","ext_1"};
	char * user_name_string;
	char *lov_name=NULL;
	char *prop_value=NULL;
	char *lov_type=NULL;
	char *DGrp=NULL;
	char *DGrp1=NULL;
	
	lov_type=(char *) MEM_alloc(100);
	DGrp=(char *) MEM_alloc(10);
	DGrp1=(char *) MEM_alloc(10);
	prop_value=(char *) MEM_alloc(10);


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	printf("\n Inside t5_LOVKeyWordDescValuesMethod\n");fflush(stdout);
	LOV_ask_name2(lov_tag,&lov_name);
	printf("\n Lov_Name_Is %s\n",lov_name);fflush(stdout);
	
	for (i=0;i<100;i++)
		{
			strcpy(DGrp,"");
			sprintf(DGrp,"%d", i);
			
			strcpy(lov_type,"");
			strcpy(lov_type,"T5_KeyWord_D_Grp_");		
			strcat(lov_type,DGrp);
			if(tc_strcmp(lov_name,lov_type)==0)
			{
				if (i<10)
				{
					strcpy(DGrp1,"0");
					strcat(DGrp1,DGrp);
					strcpy(prop_value,DGrp1);
					printf("\n prop_value (DGrp1) is: %s\n",prop_value);fflush(stdout);
				}
				else
				{
					strcpy(prop_value,DGrp);
					printf("\n prop_value (DGrp) is: %s\n",prop_value);fflush(stdout);
				}
				
			}
			
		}

	qry_values[0] = "*" ;
	qry_values[1] = prop_value;

	IFERR_REPORT(QRY_find2("QryKyWrd_iDsgGrp_oClsfObj", &query));
	IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\nKeyword n_found:%d", n_found);fflush(stdout);

	*n_values=n_found;
	if(n_values>0)
	{
		printf("\nKeyword *n_values: %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*)); 

		for (ii = 0; ii < n_found; ii++)
		{
			AOM_ask_value_string(cntr_objects[ii],"name",&Classi_class);

			(*values)[ii] = (char *) MEM_alloc (strlen(Classi_class) + 1);
			strcpy((*values)[ii], Classi_class);

			printf("\n Keyword :%s",(*values)[ii]);
					
		}
		TAG_free(cntr_objects); 
	}
			
    return error_code;
}
*/

/****************************************************************************
Function:       VehNewPartReqItem_create_pre_condition
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int VehNewPartReqItem_create_pre_condition(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
    /***********************************/


    char *item_type=NULL;
    char *grpName=NULL;
    char *projectName=NULL;
    char *roleName=NULL;
    char *InputVCNumDup=NULL;
    char *InputVCNum=NULL;
    char *VCDesriptionDup=NULL;
    char *VCDesription=NULL;
    char *BusinessUnitDup=NULL;
    char *BusinessUnit=NULL;
    char *isCRVCDup=NULL;
    char *isCRVC=NULL;
    char *BaseVCNumberDup=NULL;
    char *BaseVCNumber=NULL;
    char *ProductLineDup=NULL;
    char *ProductLine=NULL;
    char *ProjectCodeDup=NULL;
    char *ProjectCode=NULL;
    char *WhelBaseDup=NULL;
    char *WhelBase=NULL;
    char *PPPMPrjCodeDup=NULL;
    char *PPPMPrjCode=NULL;
    char *VehNwReasonDup=NULL;
    char *VehNwReason=NULL;
    char *ChangematRptDup=NULL;
    char *ChangematRpt=NULL;
    char *PlateformDup=NULL;
    char *Plateform=NULL;
    char *DriveDup=NULL;
    char *Drive=NULL;
    char *InputCRVCNumDup=NULL;
    char *InputCRVCNum=NULL;
    char *anyfileret=NULL;

	const char ch = '.';

	time_t now;
	struct tm *tm;

	int n_tags_found= 0;
	int error= 0;
	
	tag_t *t_item1=NULLTAG;
	tag_t DesignPartTag=NULLTAG;
	
	tag_t userSession=NULLTAG;

	
	logical hasBypass=false;

	


    AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **VehNewPartReqItem_create_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	printf("\n **VehNewPartReqItem_create_pre_condition::isNew = [%d]\n", isNew);fflush(stdout);
	if(isNew==true)
	{
		if(tc_strcmp(item_type,"T5_VehNPR")==0)
		{

			CE_current_user_session_tag(&userSession);
			AOM_ask_value_string(userSession,"group_name",&grpName);
			printf("\n VehNewPartReqItem_create_pre_condition::grpName====>[%s]", grpName);fflush(stdout);

			AOM_ask_value_string(userSession,"project_name",&projectName);
			printf("\n VehNewPartReqItem_create_pre_condition::projectName====>[%s]", projectName);fflush(stdout);

			AOM_ask_value_string(userSession,"role_name",&roleName);
			printf("\n VehNewPartReqItem_create_pre_condition::roleName====>[%s]", roleName);fflush(stdout);

			AOM_ask_value_string(item,"t5_InputVCNum",&InputVCNum);
			InputVCNumDup = strdup(InputVCNum);
			printf("\n VehNewPartReqItem_create_pre_condition:: InputVCNumDup====>[%s]", InputVCNumDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_VCDesription",&VCDesription);
			VCDesriptionDup = strdup(VCDesription);
			printf("\n VehNewPartReqItem_create_pre_condition:: VCDesriptionDup====>[%s]", VCDesriptionDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_BusinessUnit",&BusinessUnit);
			BusinessUnitDup = strdup(BusinessUnit);
			printf("\n VehNewPartReqItem_create_pre_condition:: BusinessUnitDup====>[%s]", BusinessUnitDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_isCRVC",&isCRVC);
			isCRVCDup = strdup(isCRVC);
			printf("\n VehNewPartReqItem_create_pre_condition:: isCRVCDup====>[%s]", isCRVCDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_BaseVCNumber",&BaseVCNumber);
			BaseVCNumberDup = strdup(BaseVCNumber);
			printf("\n VehNewPartReqItem_create_pre_condition:: BaseVCNumberDup====>[%s]", BaseVCNumberDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_ProductLine",&ProductLine);
			ProductLineDup = strdup(ProductLine);
			printf("\n VehNewPartReqItem_create_pre_condition:: ProductLineDup====>[%s]", ProductLineDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_ProjectCode",&ProjectCode);
			ProjectCodeDup = strdup(ProjectCode);
			printf("\n VehNewPartReqItem_create_pre_condition:: ProjectCodeDup====>[%s]", ProjectCodeDup);fflush(stdout);
			
			AOM_ask_value_string(item,"t5_WhelBase",&WhelBase);
			WhelBaseDup = strdup(WhelBase);
			printf("\n VehNewPartReqItem_create_pre_condition:: WhelBaseDup====>[%s]", WhelBaseDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_PPPMPrjCode",&PPPMPrjCode);
			PPPMPrjCodeDup = strdup(PPPMPrjCode);
			printf("\n VehNewPartReqItem_create_pre_condition:: PPPMPrjCodeDup====>[%s]", PPPMPrjCodeDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_VehNwReason",&VehNwReason);
			VehNwReasonDup = strdup(VehNwReason);
			printf("\n VehNewPartReqItem_create_pre_condition:: VehNwReasonDup====>[%s]", VehNwReasonDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_ChangematRpt",&ChangematRpt);
			ChangematRptDup = strdup(ChangematRpt);
			printf("\n VehNewPartReqItem_create_pre_condition:: ChangematRptDup====>[%s]", ChangematRptDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_Plateform",&Plateform);
			PlateformDup = strdup(Plateform);
			printf("\n VehNewPartReqItem_create_pre_condition:: PlateformDup====>[%s]", PlateformDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_Drive",&Drive);
			DriveDup = strdup(Drive);
			printf("\n VehNewPartReqItem_create_pre_condition:: DriveDup====>[%s]", DriveDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_InputCRVCNum",&InputCRVCNum);
			InputCRVCNumDup = strdup(InputCRVCNum);
			printf("\n VehNewPartReqItem_create_pre_condition:: InputCRVCNumDup====>[%s]", InputCRVCNumDup);fflush(stdout);

			if(tc_strlen(VCDesriptionDup)==0)
			{
				ifail=t9NewPartReqCre_Val001;
				EMH_store_error_s1(EMH_severity_error,ifail,"VC Description is Required!!");
				return ifail;
			}
			if(tc_strlen(BusinessUnitDup)==0)
			{
				ifail=t9NewPartReqCre_Val002;
				EMH_store_error_s1(EMH_severity_error,ifail,"Business Unit is Required!!");
				return ifail;
			}

			if(tc_strlen(isCRVCDup)==0)
			{
				ifail=t9NewPartReqCre_Val003;
				EMH_store_error_s1(EMH_severity_error,ifail,"Is it Vehicle combination CR is Required either Yes or No!!");
				return ifail;
			}
			if(tc_strlen(isCRVCDup)>0 && (tc_strcmp(isCRVCDup,"Y")==0 || tc_strcmp(isCRVCDup,"Yes")==0))
			{
				if(tc_strlen(InputVCNumDup)>0)
				{
					ifail=t9NewPartReqCre_Val004;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Is it Vehicle combination CR is Yes then not Required to Give Input VC Number to Be Create!!");
					return ifail;
				}
				if(tc_strlen(InputCRVCNumDup)==0)
				{
					ifail=t9NewPartReqCre_Val005;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Is it Vehicle combination CR is Yes then Required to Give Input CR VC Number to be Create!!");
					return ifail;
				}
			}
			if(tc_strlen(isCRVCDup)>0 && (tc_strcmp(isCRVCDup,"N")==0 || tc_strcmp(isCRVCDup,"NO")==0))
			{
				if(tc_strlen(InputCRVCNumDup)>0)
				{
					ifail=t9NewPartReqCre_Val006;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Is it Vehicle combination CR is Yes then not Required to Give Input CR VC Number to be Create!!");
					return ifail;
				}
				if(tc_strlen(InputVCNumDup)==0)
				{
					ifail=t9NewPartReqCre_Val007;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Is it Vehicle combination CR is Yes then Required to Give Input VC Number to Be Create!!");
					return ifail;
				}
			}
			if(tc_strlen(InputCRVCNumDup)>0)
			{
				if(tc_strlen(BaseVCNumberDup)==0)
				{
					ifail=t9NewPartReqCre_Val008;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Give Input CR VC Number then Base VC Number Requires!!");
					return ifail;
				}
				/*
				if(tc_strlen(WhelBaseDup)>0)
				{
					ifail=t9NewPartReqCre_Val009;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Give Input CR VC Number then Wheel Base is not Requires!!");
					return ifail;
				}
				*/
			}

			if(tc_strlen(InputVCNumDup)>0)
			{
				if(tc_strlen(BaseVCNumberDup)>0)
				{
					ifail=t9NewPartReqCre_Val010;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Give Input VC Number then Base VC Number Not Requires!!");
					return ifail;
				}
				/*
				if(tc_strlen(WhelBaseDup)==0)
				{
					ifail=t9NewPartReqCre_Val011;
					EMH_store_error_s1(EMH_severity_error,ifail,"If Give Input VC Number then Wheel Base is Requires!!");
					return ifail;
				}
				*/
			}
			/*
			if(tc_strlen(WhelBaseDup)>2)
			{
				ifail=t9NewPartReqCre_Val019;
				EMH_store_error_s1(EMH_severity_error,ifail,"Wheel Base is not More than 2 Digit!!");
				return ifail;
			}
			*/
			if(tc_strlen(ProductLineDup)==0)
			{
				ifail=t9NewPartReqCre_Val012;
				EMH_store_error_s1(EMH_severity_error,ifail,"Product Line is Required!!");
				return ifail;
			}
			if(tc_strlen(ProjectCodeDup)==0)
			{
				ifail=t9NewPartReqCre_Val013;
				EMH_store_error_s1(EMH_severity_error,ifail,"Project Code is Required!!");
				return ifail;
			}
			/*
			if(tc_strlen(PPPMPrjCodeDup)==0)
			{
				ifail=t9NewPartReqCre_Val014;
				EMH_store_error_s1(EMH_severity_error,ifail,"PPPM is Required!!");
				return ifail;
			}
			*/

			if(tc_strlen(VehNwReasonDup)==0)
			{
				ifail=t9NewPartReqCre_Val015;
				EMH_store_error_s1(EMH_severity_error,ifail,"Veh New Reason is Required!!");
				return ifail;
			}

			if(tc_strlen(ChangematRptDup)==0)
			{
				ifail=t9NewPartReqCre_Val016;
				EMH_store_error_s1(EMH_severity_error,ifail,"Change Matrix attachment wrt Base VC is Required!!");
				return ifail;
			}

			if(tc_strlen(PlateformDup)==0)
			{
				ifail=t9NewPartReqCre_Val017;
				EMH_store_error_s1(EMH_severity_error,ifail,"Platform is Required!!");
				return ifail;
			}

			if(tc_strlen(DriveDup)==0)
			{
				ifail=t9NewPartReqCre_Val018;
				EMH_store_error_s1(EMH_severity_error,ifail,"Drive Hand is Required!!");
				return ifail;
			}
			
			if(tc_strcmp(ChangematRptDup,"NA")!= 0 && ChangematRptDup!=NULL && tc_strlen(ChangematRptDup)>0)
			{
				anyfileret = strrchr(ChangematRptDup, ch);
				printf("\nextension is==========>%s\n", anyfileret);fflush(stdout);
				if(anyfileret== NULL)
				{
					error++;
				}
			}
			printf("\n VehNewPartReqItem_create_pre_condition:: error====>[%d]", error);fflush(stdout);
			if(error>0)
			{
				ifail=t9NewPartReqCre_Val020;
				EMH_store_error_s1(EMH_severity_error,ifail,"Pls give valid File Name with valid file extension(txt/doc/pdf/xls/ppt/jpeg) !!");
				return ifail;
			}
			
			if(tc_strlen(VCDesriptionDup)>40)
			{
				ifail=t9NewPartReqCre_Val001;
				EMH_store_error_s1(EMH_severity_error,ifail,"VC Description Length is allowed only upto 40!!");
				return ifail;
			}
		}	
	}
    return ifail;
}

/****************************************************************************
Function:       VehNewPartReqItem_create_post_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int VehNewPartReqItem_create_post_action(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
    /***********************************/


    char *item_type=NULL;
    char *user_id=NULL;
    char *itemId=NULL;
    char *InputVCNum=NULL;
    char *VCDesription=NULL;
    char *BusinessUnit=NULL;
    char *isCRVC=NULL;
    char *InputCRVCNum=NULL;
    char *BaseVCNumber=NULL;
    char *ProductLine=NULL;
    char *ProjectCode=NULL;
    char *Drive=NULL;
    char *WhelBase=NULL;
    char *PPPMPrjCode=NULL;
    char *VehNwReason=NULL;
    char *anyfileS=NULL;
    char *Plateform=NULL;
    
	char *Requestno=NULL;
    char *date=NULL;
    char *year=NULL;
    char *month=NULL;
    char *hour=NULL;
    char *min=NULL;
    char *sec=NULL;
    char *newpartreqnumber=NULL;
    char *ootbitemId=NULL;
    
	char *suf1=NULL;
	char *tok=NULL;
	char *ExtFirFile=NULL;
	char *any=NULL;
	char *any_type=NULL;
	char *NewFileNameS_any=NULL;


	tag_t	NewPrtReqTypeTag=NULLTAG;
	tag_t	userSession=NULLTAG;
	tag_t	user_tag=NULLTAG;
	tag_t	*t_item1=NULLTAG;
	tag_t	VehNPRItem_Tag=NULLTAG;
	tag_t	latestitemrev=NULLTAG;
	tag_t	datasettype_any=NULLTAG;
	tag_t	Newdataset_any=NULLTAG;
	tag_t	tool_any=NULLTAG;
	tag_t	relation_type_any=NULLTAG;
	tag_t	relation_any=NULLTAG;

	const char		*reason_any	= "";
	const char		*change_id_any	= "";
	const char		*dir_name_any = "";
	int				reservation_type_any = 2;

	logical			checkout_any = 0;
	
	time_t now;
	struct tm *tm;

	int n_tags_found= 0;
	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};
    
	
	logical hasBypass=false;
	
	

    AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **VehNewPartReqItem_create_post_action::type_name = [%s]\n", item_type);fflush(stdout);
	POM_get_user_id(&user_id);
	SA_find_user2(user_id, &user_tag);
    if(tc_strcmp(item_type,"T5_VehNPR")==0)
	{
		CALLAPI(CE_current_user_session_tag(&userSession));
		CALLAPI(AOM_ask_value_logical(userSession,"fnd0bypassflag",&hasBypass));
		if(hasBypass==false)
		{
			printf("\nHAS By pass Flag is FALSE") ;fflush(stdout);
			if(isNew==true)
			{
				/*All Custom Validation Called Here !!!!!*/
				AOM_ask_value_string(item,"item_id",&itemId);
				printf("\n In VehNewPartReqItem_create_post_action In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);

				AOM_ask_value_string(item,"t5_InputVCNum",&InputVCNum);
				printf("\n VehNewPartReqItem_create_post_action:: InputVCNum====>[%s]", InputVCNum);fflush(stdout);

				AOM_ask_value_string(item,"t5_VCDesription",&VCDesription);
				printf("\n VehNewPartReqItem_create_post_action:: VCDesription====>[%s]", VCDesription);fflush(stdout);

				AOM_ask_value_string(item,"t5_BusinessUnit",&BusinessUnit);
				printf("\n VehNewPartReqItem_create_post_action:: BusinessUnit====>[%s]", BusinessUnit);fflush(stdout);

				AOM_ask_value_string(item,"t5_isCRVC",&isCRVC);
				printf("\n VehNewPartReqItem_create_post_action::isCRVC====>[%s]", isCRVC);fflush(stdout);

				AOM_ask_value_string(item,"t5_InputCRVCNum",&InputCRVCNum);
				printf("\n VehNewPartReqItem_create_post_action::InputCRVCNum====>[%s]", InputCRVCNum);fflush(stdout);

				AOM_ask_value_string(item,"t5_BaseVCNumber",&BaseVCNumber);
				printf("\n VehNewPartReqItem_create_post_action::BaseVCNumber====>[%s]", BaseVCNumber);fflush(stdout);

				AOM_ask_value_logical(item,"t5_ProductLine",&ProductLine);
				printf("\n VehNewPartReqItem_create_post_action::ProductLine====>[%s]", ProductLine);fflush(stdout);

				AOM_ask_value_string(item,"t5_ProjectCode",&ProjectCode);
				printf("\n VehNewPartReqItem_create_post_action::ProjectCode====>[%s]", ProjectCode);fflush(stdout);

				AOM_ask_value_string(item,"t5_Drive",&Drive);
				printf("\n VehNewPartReqItem_create_post_action::Drive====>[%s]", Drive);fflush(stdout);

				AOM_ask_value_logical(item,"t5_WhelBase",&WhelBase);
				printf("\n VehNewPartReqItem_create_post_action::WhelBase====>[%d]", WhelBase);fflush(stdout);

				AOM_ask_value_string(item,"t5_PPPMPrjCode",&PPPMPrjCode);
				printf("\n VehNewPartReqItem_create_post_action::PPPMPrjCode====>[%s]", PPPMPrjCode);fflush(stdout);

				AOM_ask_value_string(item,"t5_VehNwReason",&VehNwReason);
				printf("\n VehNewPartReqItem_create_post_action::VehNwReason====>[%s]", VehNwReason);fflush(stdout);

				AOM_ask_value_string(item,"t5_ChangematRpt",&anyfileS);
				printf("\n VehNewPartReqItem_create_post_action::anyfileS====>[%s]", anyfileS);fflush(stdout);
				
				AOM_ask_value_string(item,"t5_Plateform",&Plateform);
				printf("\n VehNewPartReqItem_create_post_action::Plateform====>[%s]", Plateform);fflush(stdout);

				values[0] = itemId;
				values[1] = "T5_VehNPR";
				ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &t_item1);
				printf("\n VehNewPartReqItem_create_post_action:: n_tags_found==>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0 || n_tags_found==0)
				{
					now = time(0);
					printf("\n VehNewPartReqItem_create_post_action::11111111");fflush(stdout);
					if ((tm = localtime (&now)) == NULL) {printf ("Error extracting time \n");fflush(stdout);}
					Requestno = (char *) MEM_alloc( 100 * sizeof(char) );
					year = (char *) MEM_alloc( 10 * sizeof(char) );
					month = (char *) MEM_alloc( 10 * sizeof(char) );
					date = (char *) MEM_alloc( 10 * sizeof(char) );
					hour = (char *) MEM_alloc( 10 * sizeof(char) );
					min = (char *) MEM_alloc( 10 * sizeof(char) );
					sec = (char *) MEM_alloc( 10 * sizeof(char) );
	
					   
					sprintf(year,"%d",tm->tm_year+1900-2000);
					sprintf(month,"%d",tm->tm_mon+1);
					sprintf(date,"%d",tm->tm_mday);
					sprintf(hour,"%d",tm->tm_hour);
					sprintf(min,"%d",tm->tm_min);
					sprintf(sec,"%d",tm->tm_sec);

					printf("\n year->%s",year);fflush(stdout);
					printf("\n month->%s",month);fflush(stdout);
					printf("\n date->%s",date);fflush(stdout);
					printf("\n hour->%s",hour);fflush(stdout);
					printf("\n min->%s",min);fflush(stdout);
					printf("\n sec->%s",sec);fflush(stdout);

					if(tc_strlen(InputVCNum)>0)
					{
						tc_strcpy(Requestno,InputVCNum);
					}
					if(tc_strlen(InputCRVCNum)>0)
					{
						tc_strcpy(Requestno,InputCRVCNum);
					}
					tc_strcat(Requestno,"_");
					if(tc_strlen(date) < 2) tc_strcat(Requestno,"0");
					tc_strcat(Requestno,date);
					if(strlen(month) < 2) tc_strcat(Requestno,"0");
					tc_strcat(Requestno,month);
					tc_strcat(Requestno,year);
					tc_strcat(Requestno,"_");
					if(strlen(hour) < 2) tc_strcat(Requestno,"0");	
					tc_strcat(Requestno,hour);
					if(strlen(min) < 2) tc_strcat(Requestno,"0");
					tc_strcat(Requestno,min);
					if(strlen(sec) < 2) tc_strcat(Requestno,"0");
					tc_strcat(Requestno,sec);
					
					printf("\n VehNewPartReqItem_create_post_action-->[%s]",Requestno);fflush(stdout);
					

					if(strlen(Requestno)>0)
					{
						VehNPRItem_Tag	= t_item1[0];
						AOM_refresh( item, TRUE);
						AOM_set_value_string(item, "object_name", Requestno);
						AOM_set_value_string(item,"item_id",Requestno);
						AOM_set_value_string(item,"object_desc",Requestno);

						AOM_set_value_string(item,"t5_ProjectCode",ProjectCode);
						AOM_set_value_string(item,"t5_DesignGroup","00");
						AOM_set_value_string(item,"t5_InputVCNum",InputVCNum);
						AOM_set_value_string(item,"t5_VCDesription",VCDesription);
						AOM_set_value_string(item,"t5_BusinessUnit",BusinessUnit);
						AOM_set_value_string(item,"t5_isCRVC",isCRVC);
						AOM_set_value_string(item,"t5_InputCRVCNum",InputCRVCNum);
						AOM_set_value_string(item,"t5_BaseVCNumber",BaseVCNumber);
						AOM_set_value_string(item,"t5_ProductLine",ProductLine);
						AOM_set_value_string(item,"t5_Drive",Drive);
						AOM_set_value_string(item,"t5_WhelBase",WhelBase);
						AOM_set_value_string(item,"t5_PPPMPrjCode",PPPMPrjCode);
						AOM_set_value_string(item,"t5_VehNwReason",VehNwReason);
						AOM_set_value_string(item,"t5_ChangematRpt",anyfileS);
						AOM_set_value_string(item,"t5_Plateform",Plateform);
						AOM_set_value_string(item,"t5_PartType","V");
						AOM_set_value_string(item,"t5_VehNwRaisedBy",user_id);
						AOM_save_without_extensions(item);
						printf("\n VehNewPartReqItem_create_post_action::After AOM_save_without_extensions\n");fflush(stdout);
						printf("\n VehNewPartReqItem_create_post_action::Before AOM_refresh\n");fflush(stdout);
						AOM_refresh(item,FALSE);
						printf("\n VehNewPartReqItem_create_post_action::After AOM_refresh\n");fflush(stdout);

						AOM_ask_value_string(item,"object_name",&newpartreqnumber);
						printf("\nVehNewPartReqItem_create_post_action::newpartreqnumber--->[%s]\n",newpartreqnumber);fflush(stdout);
						AOM_ask_value_string(item,"item_id",&ootbitemId);
						printf(" ####### NewPartReqItem_create_post_action::ootbitemId No created with name--->[%s]\n",ootbitemId);fflush(stdout);
						/*Start Revison Item ID and File Creation...*/
						if(ITEM_ask_latest_rev(item,&latestitemrev));
						if(latestitemrev!=NULLTAG)
						{
							//AOM_refresh( latestitemrev, TRUE);
							AOM_set_value_string(latestitemrev,"item_id",Requestno);
							AOM_set_value_string(latestitemrev,"object_desc",Requestno);
							//AOM_save(latestitemrev);
							//AOM_save_without_extensions(latestitemrev);
							//AOM_refresh(latestitemrev,FALSE);

							if(anyfileS!=NULL && strlen(anyfileS)>0)
							{
								suf1 = strdup(anyfileS);
								printf("\n Value of suf1    ------->[%s]\n ",suf1);fflush(stdout);
								if(strcmp(suf1,"NA")!= 0)
								{	
									tok = strtok(suf1, ".");
									printf("\n After tok suf1 value  ------->[%s]\n ",tok);fflush(stdout);
									tok = strtok(NULL, ".");
									ExtFirFile= tok; 
									
								}
								if(strcasecmp(ExtFirFile,"txt") == 0)
								{
									any="Text";
									any_type = "Text";
								}

								
								if(strcasecmp(ExtFirFile,"jpg") == 0)
								{
									any="JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"png") == 0)
								{
									any="JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"xls") == 0)
								{
									any = "excel";
									any_type = "MSExcel";
								}

								if(strcasecmp(ExtFirFile,"doc") == 0)
								{
									any = "word";
									any_type = "MSWord";
								}

								if(strcasecmp(ExtFirFile,"pdf") == 0)
								{
									any = "PDF_Reference";
									any_type = "PDF";
								}

								if(strcasecmp(ExtFirFile,"ppt") == 0)
								{
									any = "powerpoint";
									any_type = "MSPowePoint";
								}

								if(strcasecmp(ExtFirFile,"pptx") == 0)
								{
									any = "powerpoint";
									any_type = "MSPowePointX";
								}

								if(strcasecmp(ExtFirFile,"docx") == 0)
								{
									any = "word";
									any_type = "MSWordX";
								}

								if(strcasecmp(ExtFirFile,"xlsx") == 0)
								{
									any = "excel";
									any_type = "MSExcelX";
								}

								if(strcasecmp(ExtFirFile,"jpeg") == 0)
								{
									any = "JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"bmp") == 0)
								{
									any = "JPEG_Reference";
									any_type = "JPEG";
								}
								
								if(strcasecmp(ExtFirFile,"msg") == 0)
								{
									any = "Outlook-Msg";
									any_type = "Outlook";
								}


								printf("\n Extension of First File is  ------->[%s]\n ",ExtFirFile);fflush(stdout);
								NewFileNameS_any = (char *) MEM_alloc( 100 * sizeof(char) );
								tc_strcpy(NewFileNameS_any,Requestno);
								//strcat(NewFileNameS_any,"_1.");
								tc_strcat(NewFileNameS_any,"_");
								printf("\n anyfileS    ------->[%s]\n ",anyfileS);fflush(stdout);
								tc_strcat(NewFileNameS_any,anyfileS);
								//strcat(NewFileNameS_any,ExtFirFile);
								printf(" #######Attachment 1  (%s)########\n",NewFileNameS_any);fflush(stdout);
								//AE_find_datasettype(any_type, &datasettype_any);
								AE_find_datasettype2(any_type, &datasettype_any);
								AE_create_dataset_with_id(datasettype_any,NewFileNameS_any,NewFileNameS_any, NULL, NULL, &Newdataset_any);
								//AE_set_dataset_format(Newdataset_any, "BINARY_REF");
								AE_set_dataset_format2(Newdataset_any, "BINARY_REF");
								AE_ask_datasettype_def_tool(datasettype_any, &tool_any);
								AE_set_dataset_tool(Newdataset_any,tool_any);
								//AOM_save(Newdataset_any);
								AOM_refresh( Newdataset_any, TRUE);
								AOM_save_without_extensions(Newdataset_any);
								AOM_refresh(Newdataset_any,FALSE);
								
								if(latestitemrev!=NULLTAG && Newdataset_any!=NULLTAG)
								{
									RES_is_checked_out(Newdataset_any,&checkout_any);
									if (checkout_any==0)
									{
										RES_checkout2(Newdataset_any,reason_any,change_id_any,dir_name_any,reservation_type_any);
										printf("\n DataSet Checked Out \n");fflush(stdout);
									}
									GRM_find_relation_type("IMAN_specification", &relation_type_any);
									GRM_create_relation(latestitemrev, Newdataset_any, relation_type_any, NULLTAG, &relation_any);
									GRM_save_relation(relation_any);
								}
								
							}
						}
						/*End Revison Item ID and File Creation...*/

						/*START FOR Auto Assign Reviewers NPR*/
						if(latestitemrev!=NULLTAG)
						{

							char
								*qry_entries3[2] = {"Name","Type"},
								*qry_values3[2]	= {"*","*"};

							tag_t	query			= NULLTAG;
							tag_t	*q_item1		= NULLTAG;
							tag_t	group_tag		= NULLTAG;
							tag_t	role_tag		= NULLTAG;
							tag_t	VIGrole_tag		= NULLTAG;
							tag_t	*members		= NULLTAG;
							tag_t   coc_id			= NULLTAG;
							tag_t   coc_principle	= NULLTAG;
							tag_t   coc_head		= NULLTAG;
							tag_t   head_engg		= NULLTAG;
							tag_t   pvbu_coc_id		= NULLTAG;
							tag_t   user_tag		= NULLTAG;

							tag_t		Module_Patricipant_Type			= NULLTAG;
							tag_t		module_participant				= NULLTAG;
							tag_t		COCPrinciple_Patricipant_Type	= NULLTAG;
							tag_t		cocprinciple_participant		= NULLTAG;
							tag_t		COCHead_Patricipant_Type		= NULLTAG;
							tag_t		cochead_participant				= NULLTAG;
							tag_t		HeadEngg_Patricipant_Type		= NULLTAG;
							tag_t		headengg_participant			= NULLTAG;
							tag_t		PVBU_Patricipant_Type			= NULLTAG;
							tag_t		pvbu_participant				= NULLTAG;
							tag_t		RaisedBy						= NULLTAG;
							tag_t		RaisedBy_Patricipant_Type		= NULLTAG;
							tag_t		raisedby_participant			= NULLTAG;
							tag_t		*AcknowledgeUser				= NULLTAG;
							tag_t		*Acknowledge_User				= NULLTAG;
							tag_t		ModRevrole_tag					= NULLTAG;
							tag_t		*ModRevmembers					= NULLTAG;
							tag_t		ModReviwer_id					= NULLTAG;
							tag_t		Module_Proposed_Type			= NULLTAG;
							tag_t		modulerev_participant			= NULLTAG;
							tag_t		Roletag							= NULLTAG;
							tag_t		grouptag						= NULLTAG;
							tag_t		current_groupmember_tag			= NULLTAG;

							char   *NprRevitemId=NULL;
							char   *BussiNameS=NULL;
							char   *Proj_typ=NULL;
							char   *ErcGroupName=NULL;
							char   *GroupNameS=NULL;
							char   *GroupNameDup=NULL;
							char   *GroupNameS1=NULL;
							char   *GroupName1Dup=NULL;
							char   *Role_Name=NULL;
							char   *roleName=NULL;
							char   *grpName=NULL;

							int n_found = 0;
							int CheckApplicable = 0;
							int member_found = 0;
							int ModRevmember_found = 0;
							int r,w =0;
							int g =0;
							int h =0;
							int p =0;
							int e =0;
							int userfind =0;
							int ackmemberfound =0;
							int memberfound =0;

							AOM_ask_value_string(latestitemrev,"item_id",&NprRevitemId);
							printf("\n AAAAA NprRevitemId====>[%s]", NprRevitemId);fflush(stdout);

							qry_values3[0]	= ProjectCode;
							qry_values3[1]	= "Project";
							QRY_find2("General...", &query);
							QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &q_item1);
							printf("\n n_found =[%d]",n_found);fflush(stdout);
							if(n_found>0)
							{
								AOM_ask_value_string(q_item1[0],"t5_BussUnitType",&BussiNameS);
								printf("\n AAAAA BussiNameS====>[%s]", BussiNameS);fflush(stdout);
								AOM_ask_value_string(q_item1[0],"t5_ProjectType",&Proj_typ);
								printf("\n AAAAA Proj_typ====>[%s]", Proj_typ);fflush(stdout);

								printf("\n Value of Bussiness Unit (%s) \n",BussiNameS);fflush(stdout);
								if(strcmp(BussiNameS,"CVBU")==0 || tc_strstr(BussiNameS,"CVBU")!=NULL)
								{
									ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
									GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
									GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );
									tc_strcpy(GroupNameS,"Veh");
									tc_strcat(GroupNameS,"_");
									tc_strcat(GroupNameS,"HeadCost");
									tc_strcat(GroupNameS,"_");
									tc_strcat(GroupNameS,"Eng");

									tc_strcpy(GroupNameDup,"Veh");
									tc_strcat(GroupNameDup,"_");
									tc_strcat(GroupNameDup,"VIG");
									tc_strcat(GroupNameDup,"_");
									tc_strcat(GroupNameDup,"Head");

									tc_strcpy(ErcGroupName,"ERC_Designers_Group");
									SA_find_group(ErcGroupName, &group_tag);
									SA_find_role2(GroupNameS,&role_tag);
									SA_find_role2(GroupNameDup,&VIGrole_tag);
									if(group_tag!=NULLTAG)
									{
										if(role_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n member_found==>[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NPRReviewer",GroupNameS);
												//AOM_save(item);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												r=0;
												for(r=0 ; r<member_found; r++)
												{	
													printf("\n Modeule_Reviewer: %d",r+1);fflush(stdout);
													coc_id = members[r];
													if(EPM_get_participanttype ("T5_HadCostEng",&Module_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_id,Module_Patricipant_Type,&module_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,module_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,module_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										
										if(VIGrole_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(VIGrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
											if(ModRevmember_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NPRVIGReviewer",GroupNameDup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												w=0;
												for(w=0 ; w<ModRevmember_found; w++)
												{	
													printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
													ModReviwer_id = ModRevmembers[w];
													if(EPM_get_participanttype ("T5_VIGHdReview",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										
									}
										MEM_free(members);
										MEM_free(ModRevmembers);
								}
								printf("\n Reviewer set before obejct creation @@ \n");fflush(stdout);
							}
							else
							{
								ifail=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,ifail,"Project Details Not Found,Please contact to PLM Team!!");
								return ifail;
							}

							//CE_current_user_session_tag(&userSession);
							

							AOM_ask_value_string(userSession,"role_name",&roleName);
							printf("\n NewPartReqItem_create_pre_condition::roleName====>[%s]", roleName);fflush(stdout);
							AOM_ask_value_string(userSession,"group_name",&grpName);
							printf("\n NewPartReqItem_create_pre_condition::grpName====>[%s]", grpName);fflush(stdout);
							
							Role_Name = (char *) MEM_alloc( 100 * sizeof(char));
							if(tc_strstr(roleName,"CAB")!=NULL)
							{
								tc_strcpy(Role_Name,"00");
								tc_strcat(Role_Name,"_");
								tc_strcat(Role_Name,"Designers");
							}
							else
							{
								tc_strcpy(Role_Name,"00");
								tc_strcat(Role_Name,"_");
								tc_strcat(Role_Name,"Designers");
							}
							
							
							SA_find_role2(Role_Name,&Roletag);
							if(Roletag!=NULLTAG)
							{
								SA_ask_current_groupmember(&current_groupmember_tag );
								SA_ask_groupmember_group (current_groupmember_tag,&grouptag) ;
								SA_find_groupmember_by_role(Roletag,grouptag,&memberfound,&Acknowledge_User);
							}
							SA_find_groupmember_by_rolename(Role_Name, grpName, user_id, &ackmemberfound, &AcknowledgeUser);
							//SA_find_user2(user_id,&RaisedBy);
							//SA_find_groupmember_by_user(user_tag,&userfind,&AcknowledgeUser);
							printf("\n Acknowledge Assignee-->[%d]\n",ackmemberfound);fflush(stdout);
							if(ackmemberfound>0)
							{
								
								EPM_get_participanttype ("T5_NwRaisedBy",&RaisedBy_Patricipant_Type);
								EPM_create_participant(AcknowledgeUser[0],RaisedBy_Patricipant_Type,&raisedby_participant);
								AOM_refresh(latestitemrev, TRUE);
								//ITEM_rev_add_participant(latestitemrev,raisedby_participant);
								PARTICIPANT_add_participant(latestitemrev,TRUE,raisedby_participant);
								AOM_save_without_extensions(latestitemrev);
								AOM_refresh(latestitemrev,FALSE);
							}
						}
						/*END FOR Auto Assign Reviewers NPR*/
					
					}
				}
			}
		}

	}
    return ifail;
}

/****************************************************************************
Function:       TML_Veh_New_Part_Request_Ledger_function
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_Veh_New_Part_Request_Ledger_function(EPM_action_message_t msg)
{
	tag_t        tzroottask					=  NULLTAG;
	tag_t		 session					=  NULLTAG;
	tag_t		 *tzattachment				=  NULLTAG;
	tag_t		 master						=  NULLTAG;
	tag_t		 query1						=  NULLTAG;
	tag_t		 *q_item1					=  NULLTAG;
	tag_t		 *q_item2					=  NULLTAG;
	tag_t		 query2						=  NULLTAG;
	tag_t		 prt_tag					=  NULLTAG;
	tag_t		 PrtLedgerTypeTag			=  NULLTAG;
	tag_t		 PrtLedgerCreInTag			=  NULLTAG;
	tag_t		 PartLedgerTag				=  NULLTAG;
	tag_t		 creltypetag				=  NULLTAG;
	tag_t		 latestitemrev				=  NULLTAG;
	tag_t		 rel_tag					=  NULLTAG;
	tag_t		 updatetag					=  NULLTAG;
	tag_t		 updatetagprt				=  NULLTAG;

	char		*UserId					=  NULL;
	char		*new_type				=  NULL;
	char		*newpartreq				=  NULL;
	char		*reqid					=  NULL;
	char		*ProjectNameDupS		=  NULL;
	char		*ProjectNameS			=  NULL;
	char		*t5DesignGroupDupS		=  NULL;
	char		*t5DesignGroupS			=  NULL;
	char		*PartType				=  NULL;
	char		*PartNumberS			=  NULL;

	char		*InputVCNum				=  NULL;
    char		*VCDesription			=  NULL;
    char		*BusinessUnit			=  NULL;
    char		*isCRVC					=  NULL;
    char		*InputCRVCNum			=  NULL;
    char		*BaseVCNumber			=  NULL;
    char		*ProductLine			=  NULL;
    char		*ProjectCode			=  NULL;
    char		*Drive					=  NULL;
    char		*WhelBase				=  NULL;
    char		*PPPMPrjCode			=  NULL;
    char		*VehNwReason			=  NULL;
    char		*anyfileS				=  NULL;
    char		*Plateform				=  NULL;

    char		*thisPartNumber			=  NULL;
    char		*TEMPrevid				=  NULL;
    char		*revPrtType				=  NULL;
    char		*revid					=  NULL;
    char		*tempId					=  NULL;
    char		*vstr					=  NULL;
    char		*Partstr				=  NULL;
    char		*dgidstr				=  NULL;
    char		*DesigIdstr				=  NULL;
    char		*part_ledger_type		=  NULL;
    char		*ledgerdocnumber		=  NULL;
    char		*ledgerdoc				=  NULL;

	int  inumarg = 0;
	int  izntaskattachment = 0;
	int  n_found1 = 0;
	int  n_found2 = 0;
	int  dsgcnt = 0;
	int  IncrementPartNumber = 0;
	int  IncrementDgId = 0;
	int  IncrementPartNumber_design = 0;
	int  IncrementDgId_1 = 0;

	char *partledgerkeys[1] = {"object_name"};
    int  partledgerorders[1]  ={2};
	int  partledgernum_to_sort = 1;

	char *designkeys[1] = {"item_id"};
    int  designorders[1]  ={2};
	int  designnum_to_sort = 1;

	 const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries1[2] = {"Name","Type"},
        *qry_values1[2]	= {"*","*"};

	char
        *qry_entries2[2] = {"Item ID","Type"},
        *qry_values2[2]	= {"*","*"};


	int error_code	= ITK_ok;


	 EPM_decision_t   decision = EPM_go;


	//ITK_set_bypass(true);
	inumarg = TC_number_of_arguments(msg.arguments);
	printf("\n TML_Veh_New_Part_Request_Ledger_function::No of Argument====>[%d]", inumarg);fflush(stdout);

	POM_ask_session(&session);
	POM_get_user_id(&UserId);
	printf("\n TML_Veh_New_Part_Request_Ledger_function::UserId====>[%s]", UserId);fflush(stdout);
	//MEM_free(UserId);

	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);

	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"object_type",&new_type);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::new_type====>[%s]", new_type);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::newpartreq====>[%s]", newpartreq);fflush(stdout);

	// to Item from revision
	ITEM_ask_item_of_rev(tzattachment[0],&master);
	

	AOM_ask_value_string(master,"t5_VehNPRNumber",&reqid);
	printf("\n reqid====>[%s]", reqid);fflush(stdout);

	AOM_ask_value_string(master,"t5_ProjectCode",&ProjectNameDupS);
	ProjectNameS = strdup(ProjectNameDupS);
	printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

	AOM_ask_value_string(master,"t5_DesignGroup",&t5DesignGroupDupS);
	t5DesignGroupS = strdup(t5DesignGroupDupS);
	printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

	AOM_ask_value_string(master,"t5_PartType",&PartType);
	printf("\n PartType====>[%s]", PartType);fflush(stdout);

	AOM_ask_value_string(master,"t5_InputVCNum",&InputVCNum);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo:: InputVCNum====>[%s]", InputVCNum);fflush(stdout);

	AOM_ask_value_string(master,"t5_VCDesription",&VCDesription);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo:: VCDesription====>[%s]", VCDesription);fflush(stdout);

	AOM_ask_value_string(master,"t5_BusinessUnit",&BusinessUnit);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo:: BusinessUnit====>[%s]", BusinessUnit);fflush(stdout);

	AOM_ask_value_string(master,"t5_isCRVC",&isCRVC);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::isCRVC====>[%s]", isCRVC);fflush(stdout);

	AOM_ask_value_string(master,"t5_InputCRVCNum",&InputCRVCNum);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::InputCRVCNum====>[%s]", InputCRVCNum);fflush(stdout);

	AOM_ask_value_string(master,"t5_BaseVCNumber",&BaseVCNumber);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::BaseVCNumber====>[%s]", BaseVCNumber);fflush(stdout);

	AOM_ask_value_logical(master,"t5_ProductLine",&ProductLine);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::ProductLine====>[%s]", ProductLine);fflush(stdout);

	AOM_ask_value_string(master,"t5_ProjectCode",&ProjectCode);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::ProjectCode====>[%s]", ProjectCode);fflush(stdout);

	AOM_ask_value_string(master,"t5_Drive",&Drive);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::Drive====>[%s]", Drive);fflush(stdout);

	AOM_ask_value_logical(master,"t5_WhelBase",&WhelBase);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::WhelBase====>[%d]", WhelBase);fflush(stdout);

	AOM_ask_value_string(master,"t5_PPPMPrjCode",&PPPMPrjCode);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::PPPMPrjCode====>[%s]", PPPMPrjCode);fflush(stdout);

	AOM_ask_value_string(master,"t5_VehNwReason",&VehNwReason);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::VehNwReason====>[%s]", VehNwReason);fflush(stdout);

	AOM_ask_value_string(master,"t5_ChangematRpt",&anyfileS);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::anyfileS====>[%s]", anyfileS);fflush(stdout);
	
	AOM_ask_value_string(master,"t5_Plateform",&Plateform);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::Plateform====>[%s]", Plateform);fflush(stdout);


	PartNumberS = (char *) MEM_alloc( 20 * sizeof(char) );

	//if(isFor12Digit==true && isFor14Digit==false)
	if(tc_strcmp(PartType,"Vehicle")==0 || tc_strcmp(PartType,"V")==0)
	{
		if(tc_strcmp(isCRVC,"NO")==0 || tc_strcmp(isCRVC,"N")==0)
		{
			tc_strcpy(PartNumberS,InputVCNum);
		}
		if(tc_strcmp(isCRVC,"Yes")==0 || tc_strcmp(isCRVC,"Y")==0)
		{
			tc_strcpy(PartNumberS,InputCRVCNum);
		}
		printf("\n The 9 digit PartNumber is %s\n",PartNumberS);fflush(stdout);
	}
	// QUERY IN PART LEDGER ....

	
	qry_values1[0]	= PartNumberS;
	qry_values1[1]	= "Part Ledger";
	QRY_find2("General...", &query1);
	QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, partledgernum_to_sort, partledgerkeys, partledgerorders, &n_found1, &q_item1);
	printf("\n n_found1 =[%d]",n_found1);fflush(stdout);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::Number of Ledger Object Found are %d\n",n_found1);fflush(stdout);

	// QUERY IN DESIGN CLASS ....

	qry_values2[0]	= PartNumberS;
	qry_values2[1]	= "Design";
	QRY_find2("Item - simple", &query2);
	QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, designnum_to_sort, designkeys, designorders, &n_found2, &q_item2);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::n_found2 =[%d]",n_found2);fflush(stdout);

	// n_found2 ----> Design Object Found.
	// n_found1 ----> Part Ledger Object Found.

	

	thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
	tc_strcpy(thisPartNumber, PartNumberS);
	printf("\n TML_Veh_New_Part_Request_Ledger_functionNo::1 Going to  Create Part Ledger -->%s",thisPartNumber);fflush(stdout);

	printf("\n\n Finally Going To Create Part Ledger -->[%s]\n\n",thisPartNumber);fflush(stdout);

	int		IsAvailInUA			=	0;
	int		ValCntT				=	0;
	tag_t*	ValCntrlObjectTagT	=	NULLTAG;
	tag_t	qryTagT				=	NULLTAG;
	char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
	int		n_entryT			=	1;
	char    *qry_entryT[1]		=	{"SYSCD"};
	char *New_TML_Part_Number_NPR	= NULL;
	char *partDuplicateCheckStr	= NULL;
	char *partDuplicateCheckLocStr	= NULL;
	char *partDuplicateCheckShellStr	= NULL;
	char *itemId	= NULL;


	if(QRY_find2("ControlObjects", &qryTagT));
	if (qryTagT)
	{
		printf("\n Found Query ControlObjects  ");fflush(stdout);
	}
	else
	{
		printf("\n Not Found Query ControlObjects  ");fflush(stdout);
	}

	New_TML_Part_Number_NPR = (char *) MEM_alloc( 20 * sizeof(char) );

	qry_valuesT[0] = "PartDuplicateCheck" ;
	if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT));
	printf(" \n PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);
	if(ValCntT>0)
	{
		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo8",&partDuplicateCheckStr);
		printf("\n partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_userinfo10",&partDuplicateCheckLocStr);
		printf("\n partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);

		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo9",&partDuplicateCheckShellStr);
		printf("\n partDuplicateCheckShellStr===>[%s]",partDuplicateCheckShellStr);fflush(stdout);

		IsAvailInUA = IsDesignRevisionAvail(thisPartNumber);

		if(IsAvailInUA == 0 && tc_strstr(partDuplicateCheckStr,"VEHNPRPARTDUPLICATECHECK")!=NULL)
		{
			char *username=NULL;
			tag_t user_tag=NULLTAG;
			char*	sysCmnd	=	NULL;
			char *homeSite = NULL;
			char* PNoStr = NULL;
			char* FNameStr = NULL;
			sysCmnd=(char *) MEM_alloc(400);
			PNoStr=(char *) MEM_alloc(400);
			FNameStr=(char *) MEM_alloc(400);
			tc_strcpy(PNoStr,thisPartNumber);
			tc_strcpy(FNameStr,thisPartNumber);
			tc_strcat(FNameStr,".txt");
			printf("\n PNoStr: [%s]\n",PNoStr);fflush(stdout);
			printf("\n FNameStr: [%s]\n",FNameStr);fflush(stdout);
			POM_get_user(&username,&user_tag);
			AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
			printf("\n homeSite===>[%s]",homeSite);fflush(stdout);
			if(tc_strcmp(homeSite,"CV_Production")==0)
			{
				tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/VehNPR/PartCallingNPRCVShell.sh ");
			}
			else if(tc_strcmp(homeSite,"Production-Pune")==0)
			{
				tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/VehNPR/PartCallingNPRPVShell.sh ");
			}
			else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
			{
				tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/PartCallingNPRCMITESTShell.sh ");
			}
			else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
			{
				tc_strcpy(sysCmnd,"/user/infodba03/sudhir/NPRCheck/PartCallingNPRDEVShell.sh ");
			}
			else
			{
				//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
				tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
				tc_strcat(sysCmnd,partDuplicateCheckShellStr);
				tc_strcat(sysCmnd," ");
			}
			//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
			tc_strcat(sysCmnd,PNoStr);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,FNameStr);
			printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
			system(sysCmnd);
			MEM_free(sysCmnd);

			// File Open...

			FILE* fptr = NULL;
			char *File_Name = NULL;
			char *File_LOC = NULL;
			char *inputline = NULL;
			char	*f	=NULL;
			char	result1 [ 100000 ] ;
			char	result2 [ 100000 ] ;

			int i = 0;

			File_Name=(char *) MEM_alloc(20);
			File_LOC=(char *) MEM_alloc(400);
			tc_strcpy(File_Name,thisPartNumber);
			tc_strcat(File_Name,".txt");
			if(tc_strcmp(homeSite,"CV_Production")==0)
			{
				tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/VehNPR/");
			}
			else if(tc_strcmp(homeSite,"Production-Pune")==0)
			{
				tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/VehNPR/");
			}
			else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
			{
				tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/");
			}
			else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
			{
				tc_strcpy(File_LOC,"/user/infodba03/sudhir/NPRCheck/");
			}
			else
			{
				///tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
				tc_strcpy(File_LOC,partDuplicateCheckLocStr);
			}
			//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
			tc_strcat(File_LOC,File_Name);
			printf("\n File_Name: [%s]\n",File_Name);fflush(stdout);
			printf("\n File_LOC: [%s]\n",File_LOC);fflush(stdout);
			fptr=fopen(File_LOC,"r");
			if(fptr!=NULL)
			{
				inputline=(char *) MEM_alloc(50000);
				while(fgets(inputline,50000,fptr)!=NULL)
				{
					for (i = 0; i < strlen(inputline); i++)
					{
						if ( inputline[i] == '\n' || inputline[i] == '\r' )
							inputline[i] = '\0';
					}
					while(1)
					{
						f = strstr(inputline,",,");
						if(f==NULL)
						{
							break;
						}

						strcpy(result2,f+1);					
						*(f+1)=' ';
						*(f+2)='\0';
						strcat(f,result2);
					}
					strcpy(result1,inputline);
					printf("\n inputline .......%s\n",result1);fflush(stdout);
					itemId=tc_strtok(result1,"^");
					printf("\n itemId .......[%s]\n",itemId);fflush(stdout);
					if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
					{
						tc_strcpy(New_TML_Part_Number_NPR, itemId);
					}
					else
					{
						printf(" \n PART NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
						tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
					}
				}
			}
			else
			{
				printf(" \n FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
				tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
			}
		}
		else
		{
			printf("\n error message here !!!Part present in TCUA, so skip to check in TCE");fflush(stdout);
			tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
		}
	}
	else
	{
		tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
	}

	printf("\n\n Finally Going To Create Part Ledger After Check IN TCE -->[%s]\n\n",New_TML_Part_Number_NPR);fflush(stdout);
	char* temp_Id1 = NULL;
	char* temp_Id2 = NULL;
	char* FINAL_ASSIGN_PART_NUMBER = NULL;
	temp_Id1=(char *) MEM_alloc(5);
	temp_Id2=(char *) MEM_alloc(5);
	FINAL_ASSIGN_PART_NUMBER=(char *) MEM_alloc(20);
	int Increment_PartNumber_1 = 0;
	int Increment_PartNumber_2 = 0;
	if(tc_strlen(New_TML_Part_Number_NPR)==9 && tc_strlen(thisPartNumber)==9)
	{
		tc_strcpy(FINAL_ASSIGN_PART_NUMBER,thisPartNumber);
	}
	else
	{
		tc_strcpy(FINAL_ASSIGN_PART_NUMBER,thisPartNumber);
	}
	printf("\n FINAL_ASSIGN_PART_NUMBER [%s]*******",FINAL_ASSIGN_PART_NUMBER);fflush(stdout);

	//if(tc_strlen(thisPartNumber)>0)
	if(tc_strlen(FINAL_ASSIGN_PART_NUMBER)>0)
	{
		TCTYPE_find_type ("T5_PrtMtr", "T5_PrtMtr", &PrtLedgerTypeTag);
		TCTYPE_ask_name2(PrtLedgerTypeTag,&part_ledger_type);
		
		printf("\n part_ledger_type [%s]*******",part_ledger_type);fflush(stdout);
		TCTYPE_construct_create_input(PrtLedgerTypeTag,&PrtLedgerCreInTag);
		AOM_set_value_string(PrtLedgerCreInTag, "object_name", FINAL_ASSIGN_PART_NUMBER);
		AOM_set_value_string(PrtLedgerCreInTag, "object_desc", FINAL_ASSIGN_PART_NUMBER);
		TCTYPE_create_object(PrtLedgerCreInTag, &PartLedgerTag);
		
		
		if(PartLedgerTag!=NULLTAG)
		{
			AOM_refresh( PartLedgerTag, TRUE);
			AOM_set_value_string(PartLedgerTag, "object_name", FINAL_ASSIGN_PART_NUMBER);
			AOM_set_value_string(PartLedgerTag, "t5_PrtProjCode", ProjectNameS);			
			AOM_set_value_string(PartLedgerTag, "t5_PrtDesignGrp", t5DesignGroupS);
			AOM_set_value_string(PartLedgerTag, "t5_PrtNmbrDesc", FINAL_ASSIGN_PART_NUMBER);
			AOM_save_without_extensions(PartLedgerTag);
			
			AOM_refresh(PartLedgerTag,FALSE);
			AOM_ask_value_string(PartLedgerTag,"object_name",&ledgerdocnumber);
			printf("\n Part Ledger [%s] Created Successfully*******",ledgerdocnumber);fflush(stdout);
			AOM_ask_value_string(PartLedgerTag,"t5_PrtNmbrDesc",&ledgerdoc);
			printf("\n Part Ledger [%s] Created Successfully*******",ledgerdoc);fflush(stdout);
		}
		GRM_find_relation_type("T5_NwLHP",&creltypetag);
		if(master!=NULLTAG && PartLedgerTag!=NULLTAG)
		{
			printf("\n Part Ledger [%s] *******",ledgerdoc);fflush(stdout);
			printf("\n New Part Request [%s] *******",newpartreq);fflush(stdout);
			ITEM_ask_latest_rev(master,&latestitemrev);
			//if(ITEM_ask_latest_rev(tzattachment[0],&latestitemrev)!=ITK_ok) PrintErrorStack();
			if(PartLedgerTag!=NULLTAG)
			{
				GRM_create_relation(tzattachment[0],PartLedgerTag,creltypetag,NULLTAG,&rel_tag);
				printf("\n After GRM_create_relation *******");fflush(stdout);
				//if(AOM_save_without_extensions(rel_tag)!=ITK_ok) PrintErrorStack();
				GRM_save_relation(rel_tag);
				printf("\n After rel_tag *******");fflush(stdout);
			}
			AOM_refresh(master, TRUE);
			POM_attr_id_of_attr("t5_NwLCState", "T5_VehNPR", &updatetag);
			POM_set_attr_string(1, &master, updatetag, "LcsNwAppr");
			POM_attr_id_of_attr("t5_VehNwTmlPtNo", "T5_VehNPR", &updatetagprt);
			POM_set_attr_string(1, &master, updatetagprt, FINAL_ASSIGN_PART_NUMBER);
			POM_save_instances(1, &master, false);
			printf("\n Completed::POM_save_instances");fflush(stdout);
			AOM_refresh(master, FALSE);
		}
	}
	return error_code;
}


/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		//(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_alloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		//(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		//(*strset) = (char **)malloc((*count ) * sizeof(char *));
		(*strset) = (char **)MEM_alloc((*count ) * sizeof(char *));
	}
	else
	{
		//(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
		(*strset) = (char **)MEM_realloc((*strset),(*count ) * sizeof(char *));
	}
	//(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	(*strset)[*count-1] = MEM_alloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

/****************************************************************************
    Function:       tm_Veh_New_Part_Reqest_register_action_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_Veh_New_Part_Reqest_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						
		
		retcode = EPM_register_action_handler (
								"TML_Veh_New_Part_Request_Ledger",
								"TML_Veh_New_Part_Request_Ledger",
								(EPM_action_handler_t)TML_Veh_New_Part_Request_Ledger_function
								);
		

		printf("\n tm_Veh_New_Part_Reqest_register_action_handlers\n");fflush(stdout);
	}
	return retcode;
}


/****************************************************************************
Function:       TML_Veh_New_Part_Reqest_Check_TargetFunction
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

EPM_decision_t TML_Veh_New_Part_Reqest_Check_TargetFunction( EPM_rule_message_t msg)
{
	
	int			izntaskattachment	= 0;

	tag_t		tzroottask			= NULLTAG;
	tag_t		partrevtag			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t  		*ReqPartList 		= NULLTAG;
	tag_t  		*attachments 		= NULLTAG;
	tag_t		relation_type 		= NULLTAG;
	tag_t		datasetTypeTag 		= NULLTAG;
	tag_t		refrelation_type	= NULLTAG;
	tag_t		nprmaster			= NULLTAG;
	tag_t		*refnprchklist		= NULLTAG;
	int          ifail              = ITK_ok;
	
	int req_tags_found=0;
	int			i			= 0;
	int			cnt			= 0;
	int			k			= 0;
	int			refcnt		= 0;
	int			error		= 0;
	int			chklisterror= 0;
	logical ischkout = 0;
	logical	checkout_checklist = 0;
	
	char		*objType			=  NULL;
	char    *reqnumber = NULL;
	char    *dataset_type_name = NULL;
	int datasetNamedRefCount = 0;
	tag_t *datasetRefObjectTag = NULLTAG;
	//char  dataset_type_name[TCTYPE_name_size_c+1];

	const char
        *attrs1[1] = {"item_id"},
        *values1[1]	= {"*"};

	EPM_decision_t   decision = EPM_go;

	//ITK_set_bypass(true);
	
	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment, &izntaskattachment, &tzattachment );
	for(i=0; i<izntaskattachment;i++)
	{
		tag_t partrevtag = tzattachment[i];
		AOM_ask_value_string(partrevtag,"object_type",&objType);
		printf("\n In TML_Veh_New_Part_Reqest_Check_TargetFunction : object_type : %s \n",objType);fflush(stdout);
		AOM_ask_value_string(partrevtag,"item_id",&reqnumber);
		printf("\n In TML_Veh_New_Part_Reqest_Check_TargetFunction : reqnumber : %s\n",reqnumber);fflush(stdout);
		values1[0] = reqnumber;
		ifail = ITEM_find_item_revs_by_key_attributes(1,attrs1, values1,"NR",&req_tags_found, &ReqPartList);
		printf("\n In TML_Veh_New_Part_Reqest_Check_TargetFunction : req_tags_found : %d\n",req_tags_found);fflush(stdout);
		if(req_tags_found>0)
		{
			GRM_find_relation_type("IMAN_specification",&relation_type);
			GRM_list_secondary_objects_only(ReqPartList[0],relation_type,&cnt,&attachments);
			ITEM_ask_item_of_rev(ReqPartList[0],&nprmaster);
			
			printf("\n In TML_Veh_New_Part_Reqest_Check_TargetFunction : attachment cnt : %d\n",cnt);fflush(stdout);
			if(cnt>0)
			{
				for(k=0;k<cnt;k++)
				{
					tag_t  filetag = attachments[k];
					RES_is_checked_out(filetag,&ischkout);
					AE_ask_dataset_named_refs(filetag,&datasetNamedRefCount,&datasetRefObjectTag);
					if(TCTYPE_ask_object_type(filetag,&datasetTypeTag)!=ITK_ok) PrintErrorStack();
					if(TCTYPE_ask_name2(datasetTypeTag,&dataset_type_name)!=ITK_ok) PrintErrorStack();
					printf("\n dataset_type_name is ====>[%s]", dataset_type_name);fflush(stdout);
					printf("\n datasetNamedRefCount is ====>[%d]", datasetNamedRefCount);fflush(stdout);
					if(ischkout==1 || datasetNamedRefCount==0)
					{
						error++;
					}
					if(datasetNamedRefCount>0)
					{
						tag_t file_name_tag		= NULLTAG;
						tag_t objTypeTag		= NULLTAG;
						char  *fileextension	= NULL;
						char  *filename			= NULL;
						char  *token			= NULL;
						char  *type_name			= NULL;
						//char  type_name[TCTYPE_name_size_c+1];
						int		f				= 0;
						for(f=0;f<datasetNamedRefCount;f++)
						{
							file_name_tag = datasetRefObjectTag[f];
							if(TCTYPE_ask_object_type(file_name_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
							if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
							printf("\n File type_name is ====>[%s]", type_name);fflush(stdout);
							AOM_ask_value_string(file_name_tag,"file_ext",&fileextension);
							printf("\n file extension is ====>[%s]", fileextension);fflush(stdout);
							AOM_ask_value_string(file_name_tag,"object_string",&filename);
							printf("\n filename is ====>[%s]", filename);fflush(stdout);
							token = strtok(filename, ".");
							token = strtok(NULL, ".");
							printf("\n token is ====>[%s]", token);fflush(stdout);
							if(strcasecmp(fileextension,token) == 0)
							{
								printf("\n File extension matched %s", token);fflush(stdout);
							}
							else
							{
								printf("\n File extension not matched %s", token);fflush(stdout);
								error++;
							}
							
						}
					}
				}
			}
			MEM_free(datasetRefObjectTag);
		}
		
	}
	printf("\n In TML_Veh_New_Part_Reqest_Check_TargetFunction : attachment error : %d\n",error);fflush(stdout);
	if(error>0)
	{
		ifail=t9NewPartReqCre_Val030;
		EMH_store_error_s1(EMH_severity_error,ifail,"Attaching Files Should have Physical File,Please add files and check In to dataset!!...");
		decision = EPM_nogo;
	}
	
	MEM_free(tzattachment);
	MEM_free(ReqPartList);
	MEM_free(attachments);
	
	return decision;


}


/****************************************************************************
Function:       VehReviewer_SignOffCheckFunction
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern EPM_decision_t DLLAPI VehReviewer_SignOffCheckFunction(EPM_rule_message_t msg)
{
	tag_t root_task=NULLTAG;
	EPM_decision_t decision = EPM_go;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t *TaskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;
	tag_t master = NULLTAG;
	tag_t  currGrpMember = NULLTAG;
	tag_t  query = NULLTAG;
	tag_t  *q_CtrlSet = NULLTAG;

	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*	NewPrtreqDesignGrp		=NULL;
	char*	NewPrtreqPrtType		=NULL;
	char*	DocNum					=NULL;
	char*	type_name				=NULL;
	char*	Tsk_Prty_typ			=NULL;
	char*	group_AssGroup_Role		=NULL;
	char*	group_AssGroup_RoleDup	=NULL;
	char*	RequiredRolName			=NULL;
	char *Session_group = NULL;
	char *Session_Role = NULL;
	char *Session_User = NULL;
	char *ERROR_MESSAGE = NULL;
	char *GROUP_DETAIS_USER = NULL;
	char *info01 = NULL;
	char *info03 = NULL;
	char *info04 = NULL;
	char *info05 = NULL;

	char *ModuleRvrGroup_Role = NULL;
	char *ModuleRvrGroup_User = NULL;
	

	char *COCPGroup_Role = NULL;
	char *COCPGroup_User = NULL;

	char *COCHGroup_Role = NULL;
	char *COCHGroup_User = NULL;

	char *HeadEngGroup_Role = NULL;
	char *HeadEngGroup_User = NULL;

	char *MCCGroup_Role = NULL;
	char *MCCGroup_User = NULL;

	char *AckGroup_Role = NULL;
	char *AckGroup_User = NULL;



	//char  	type_name[TCTYPE_name_size_c+1];
	//char  	Tsk_Prty_typ[TCTYPE_name_size_c+1];

	int	count,i	=	0;
	int	TskPrtycount,jkk	=	0;
	
	int	ModuleReviewerflag	=	0;
	int	CoCPrincipleReviewerflag	=	0;
	int	CoCHeadReviewerflag	=	0;
	int	HeadOfEngReviewerflag	=	0;
	int ProposedReviewerflag	=	0;
	int	NwRaisedByflag	=	0;
	int	n_Ctrlfound	=	0;

	char
					*qry_entries_ctrl[1] = {"SYSCD"},
					*qry_values_ctrl[1]	= {"*"};

	int ifail= ITK_ok;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n VehReviewer_SignOffCheckFunction:Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n VehReviewer_SignOffCheckFunction:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n VehReviewer_SignOffCheckFunction:Parent Name:%s\n",parent_name);fflush(stdout);
	
	//RequiredRolName = (char *)MEM_alloc(250);
	Session_group = (char *)MEM_alloc(250);
	Session_Role = (char *)MEM_alloc(250);
	Session_User = (char *)MEM_alloc(250);
	ERROR_MESSAGE = (char *)MEM_alloc(500);
	//ERROR_MESSAGE_USR = (char *)MEM_alloc(100);
	
	SA_ask_current_groupmember(&currGrpMember);
	CALLAPI(AOM_ask_value_string(currGrpMember,"object_name",&group_AssGroup_Role));
	printf("\n VehReviewer_SignOffCheckFunction ::group_AssGroup_Role====>[%s]", group_AssGroup_Role);fflush(stdout);
	group_AssGroup_RoleDup = strdup(group_AssGroup_Role);
	tc_strcpy(Session_group, "");
	tc_strcpy(Session_Role, "");
	Session_group = strtok(group_AssGroup_Role,"/");
	Session_Role = strtok(NULL,"/");
	Session_User = strtok(NULL,"/");

	tc_strcpy(ERROR_MESSAGE,"Your Login Id session[");
	tc_strcat(ERROR_MESSAGE,group_AssGroup_RoleDup);
	tc_strcat(ERROR_MESSAGE,"] is not matched with Assign Reviewer[");
	
	printf("\n VehReviewer_SignOffCheckFunction::Session_group is  ::Session_group====>[%s]", Session_group);fflush(stdout);
	printf("\n VehReviewer_SignOffCheckFunction::Session_Role is  ::Session_Role====>[%s]", Session_Role);fflush(stdout);
	printf("\n VehReviewer_SignOffCheckFunction::Session_User is  ::Session_User====>[%s]", Session_User);fflush(stdout);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n VehReviewer_SignOffCheckFunction: EPM_ask_attachments of :: %d\n",count);fflush(stdout);
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n VehReviewer_SignOffCheckFunction::type_name ==> %s\n", type_name);fflush(stdout);			
			if(tc_strcmp(type_name,"T5_VehNPRRevision")==0 || tc_strcmp(type_name,"Veh NPR Revision")==0)
			{
				AOM_ask_value_string(attachments[i],"item_id",&DocNum);
				printf("\n VehReviewer_SignOffCheckFunction::DocNum ==> %s\n", DocNum);fflush(stdout);
				ITEM_ask_item_of_rev(attachments[i],&master);
				CALLAPI(GRM_find_relation_type("HasParticipant", &task_Prty_rel_type));				
				if (task_Prty_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB));
					printf("\n VehReviewer_SignOffCheckFunction: TaskCRB count: %d",TskPrtycount);fflush(stdout);
					if(TskPrtycount>0)
					{
						ModuleReviewerflag=0;
						CoCPrincipleReviewerflag=0;
						NwRaisedByflag=0;
						for(jkk=0;jkk<TskPrtycount;jkk++)
						{
							TskCRBTag = TaskCRB[jkk];
							if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
							if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
							
							printf("\n VehReviewer_SignOffCheckFunction::Tsk_Prty_typ: %s",Tsk_Prty_typ);fflush(stdout);
														
							if (tc_strcmp(Tsk_Prty_typ,"T5_HadCostEng")==0 && tc_strstr(CurrentTask,"Head Cost Eng Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&ModuleRvrGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&ModuleRvrGroup_User));
								printf("\n VehReviewer_SignOffCheckFunction::ModuleRvrGroup_Role: %s",ModuleRvrGroup_Role);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::ModuleRvrGroup_User: %s",ModuleRvrGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,ModuleRvrGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,ModuleRvrGroup_User);
								printf("\n VehReviewer_SignOffCheckFunction::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,"Veh_HeadCost_Eng");
								printf("\n VehReviewer_SignOffCheckFunction::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,ModuleRvrGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,ModuleRvrGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										ModuleReviewerflag=1;
										break;
									}
									else
									{
										ModuleReviewerflag=0;
									}
								}
								else
								{
									ModuleReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"T5_VIGHdReview")==0 && tc_strstr(CurrentTask,"VIG Head Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&COCPGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&COCPGroup_User));
								printf("\n VehReviewer_SignOffCheckFunction::COCPGroup_Role: %s",COCPGroup_Role);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::COCPGroup_User: %s",COCPGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,COCPGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,COCPGroup_User);
								printf("\n VehReviewer_SignOffCheckFunction::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);								
								tc_strcpy(RequiredRolName,"Veh_VIG_Head");
								printf("\n VehReviewer_SignOffCheckFunction::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,COCPGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,COCPGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										CoCPrincipleReviewerflag=1;
										break;
									}
									else
									{
										CoCPrincipleReviewerflag=0;
									}
								}
								else
								{
									CoCPrincipleReviewerflag=0;
								}
							}

							if (tc_strcmp(Tsk_Prty_typ,"T5_NwRaisedBy")==0 && tc_strstr(CurrentTask,"Acknowledge Assignment")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&AckGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&AckGroup_User));
								printf("\n VehReviewer_SignOffCheckFunction::AckGroup_Role: %s",AckGroup_Role);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::AckGroup_User: %s",AckGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,MCCGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,AckGroup_User);
								printf("\n VehReviewer_SignOffCheckFunction::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n VehReviewer_SignOffCheckFunction::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								if(tc_strstr(Session_User,AckGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,AckGroup_Role)!=NULL)
									{
										NwRaisedByflag=1;
										break;
									}
									else
									{
										NwRaisedByflag=0;
									}
								}
								else
								{
									NwRaisedByflag=0;
								}
								
							}
						}
					}
				}
				printf("\n VehReviewer_SignOffCheckFunction: ModuleReviewerflag of :: %d\n",ModuleReviewerflag);fflush(stdout);
				printf("\n VehReviewer_SignOffCheckFunction: CoCPrincipleReviewerflag of :: %d\n",CoCPrincipleReviewerflag);fflush(stdout);
				printf("\n VehReviewer_SignOffCheckFunction: NwRaisedByflag of :: %d\n",NwRaisedByflag);fflush(stdout);
				printf("\n VehReviewer_SignOffCheckFunction: GROUP_DETAIS_USER of :: %s\n",GROUP_DETAIS_USER);fflush(stdout);
				
				if(GROUP_DETAIS_USER!=NULL && tc_strlen(GROUP_DETAIS_USER)>0)tc_strcat(ERROR_MESSAGE,GROUP_DETAIS_USER);
				tc_strcat(ERROR_MESSAGE,"].\nPlease login with assigned person and sigoff approve.");
				printf("\n VehReviewer_SignOffCheckFunction: ERROR_MESSAGE of :: %s\n",ERROR_MESSAGE);fflush(stdout);
				
				QRY_find2("Control Objects...", &query);
				if(query!=NULLTAG)
				{
					qry_values_ctrl[0] = "VehNPRSignOffCheck";
					QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
					printf("\n VehReviewer_SignOffCheckFunction: n_Ctrlfound of :: %d\n",n_Ctrlfound);fflush(stdout);
					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo1",&info01);
					printf("\n VehReviewer_SignOffCheckFunction: info01 of :: %s\n",info01);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo3",&info03);
					printf("\n VehReviewer_SignOffCheckFunction: info03 of :: %s\n",info03);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo4",&info04);
					printf("\n VehReviewer_SignOffCheckFunction: info04 of :: %s\n",info04);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo5",&info05);
					printf("\n VehReviewer_SignOffCheckFunction: info05 of :: %s\n",info05);fflush(stdout);

				}

				if(tc_strstr(info01,"VehNPRSignOffCheck")!=NULL && n_Ctrlfound>0)
				{
					if(ModuleReviewerflag==0 && tc_strstr(CurrentTask,"Head Cost Eng Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0 && tc_strstr(info03,"HeadCostEngReview")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(CoCPrincipleReviewerflag==0 && tc_strstr(CurrentTask,"VIG Head Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0 && tc_strstr(info04,"VIGHeadReview")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(NwRaisedByflag==0 && tc_strstr(CurrentTask,"Acknowledge Assignment")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0 && tc_strstr(info05,"Acknowledge")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
				}
				else
				{
					decision = EPM_go;
				}
			}
		}
	}
	

	//decision = EPM_go;
	return decision;
}

/****************************************************************************
Function:       Veh_New_PartReq_assign_manager_teamreviewer
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern EPM_decision_t DLLAPI Veh_New_PartReq_assign_manager_teamreviewer(EPM_rule_message_t msg)
{
	tag_t root_task=NULLTAG;
	EPM_decision_t decision = EPM_go;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t *TaskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;
	tag_t master = NULLTAG;

	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*	NewPrtreqDesignGrp				=NULL;
	char*	NewPrtreqPrtType				=NULL;
	char*	DocNum				=NULL;
	char*	type_name				=NULL;
	char*	Tsk_Prty_typ				=NULL;

	//char  	type_name[TCTYPE_name_size_c+1];
	//char  	Tsk_Prty_typ[TCTYPE_name_size_c+1];

	int	count,i	=	0;
	int	TskPrtycount,jkk	=	0;
	
	int	ModuleReviewerflag	=	0;
	int	CoCPrincipleReviewerflag	=	0;
	int	CoCHeadReviewerflag	=	0;
	int	HeadOfEngReviewerflag	=	0;
	int ProposedReviewerflag	=	0;
	int	NwRaisedByflag	=	0;

	int ifail=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n Veh_New_PartReq_assign_manager_teamreviewer:Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Veh_New_PartReq_assign_manager_teamreviewer:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n Veh_New_PartReq_assign_manager_teamreviewer:Parent Name:%s\n",parent_name);fflush(stdout);
	if(strstr(CurrentTask,"Assign Reviewers and Review NPR")!=NULL)
	{
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n Veh_New_PartReq_assign_manager_teamreviewer: EPM_ask_attachments of :: %d\n",count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
				printf("\n type_name ==> %s\n", type_name);fflush(stdout);			
				if(tc_strcmp(type_name,"T5_VehNPRRevision")==0 || tc_strcmp(type_name,"Veh NPR Revision")==0)
				{
					AOM_ask_value_string(attachments[i],"item_id",&DocNum);
					printf("\n DocNum ==> %s\n", DocNum);fflush(stdout);
					ITEM_ask_item_of_rev(attachments[i],&master);
					CALLAPI(GRM_find_relation_type("HasParticipant", &task_Prty_rel_type));
					if (task_Prty_rel_type!=NULLTAG)
					{
						CALLAPI(GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB));
						printf("\n MT: TaskCRB count: %d",TskPrtycount);fflush(stdout);
						if(TskPrtycount>0)
						{
							ModuleReviewerflag=0;
							CoCPrincipleReviewerflag=0;
							NwRaisedByflag=0;
							for(jkk=0;jkk<TskPrtycount;jkk++)
							{
								TskCRBTag = TaskCRB[jkk];
								if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
								if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
								if (tc_strcmp(Tsk_Prty_typ,"T5_HadCostEng")==0)
								{
									ModuleReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_VIGHdReview")==0)
								{
									CoCPrincipleReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_NwRaisedBy")==0)
								{
									NwRaisedByflag=1;
								}
							}
						}
					}///
					printf("\n Veh_New_PartReq_assign_manager_teamreviewer: ModuleReviewerflag of :: %d\n",ModuleReviewerflag);fflush(stdout);
					printf("\n Veh_New_PartReq_assign_manager_teamreviewer: CoCPrincipleReviewerflag of :: %d\n",CoCPrincipleReviewerflag);fflush(stdout);
					printf("\n Veh_New_PartReq_assign_manager_teamreviewer: NwRaisedByflag of :: %d\n",NwRaisedByflag);fflush(stdout);

					if(ModuleReviewerflag==0)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Module Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(CoCPrincipleReviewerflag==0)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign COC Principle Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(NwRaisedByflag==0)
					{
						if(tc_strcmp(type_name,"T5_VehNPRRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign New Part Request Raised By, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}
					break;
				}
			}
		}
	}

	//decision = EPM_go;
	return decision;
}

/****************************************************************************
Function:       Veh_New_PartReq_ChkdmlActiveinLC
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern EPM_decision_t DLLAPI Veh_New_PartReq_ChkdmlActiveinLC(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	char*			procedure_name				= NULL;

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t *parents = NULLTAG;



	EPM_decision_t decision = EPM_go;
	int ifail=0,count,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::Root task found for New_PartReq_ChkdmlActiveinLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::EPM_ask_attachments of :: %d",count);fflush(stdout);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
	}

	CALLAPI(TCTYPE_ask_object_type(DMLLcmTag,&primary_obj_type_tag));
	CALLAPI(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::Primary_object type_name is:%s",type_name1);fflush(stdout);

	if(tc_strcmp(type_name1,"T5_VehNPR")==0 || tc_strcmp(type_name1,"Vehicle NPR")==0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "Vehicle New Part Request Master cannot submit in Lifecycle. Kindly Submit Vehicle New Part Request Revision in workflow.");
		decision = EPM_nogo;
		return decision;
	}

	EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents);
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);
	EPM_ask_procedure_name2(parents[0],&procedure_name);
	printf("\n Veh_New_PartReq_ChkdmlActiveinLC::procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
	if(tc_strcmp(procedure_name,"Vehicle New Part Request LifeCycle")!=0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "Vehicle New Part Request Revision can be submit in Lifecycle Vehicle New Part Request Lifecycle.\n You can not submit it other workflow.");
		decision = EPM_nogo;
		return decision;
	}
	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "Vehicle New Part Request already submitted in Lifecycle ... You can not submit it again.");
		decision = EPM_nogo;
		return decision;
	}
	else
	{
		decision = EPM_go;
	}

	return decision;
}

/****************************************************************************
Function:       Veh_New_PartReq_CheckSignOffCommentFn
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
EPM_decision_t Veh_New_PartReq_CheckSignOffCommentFn( EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int ifail = ITK_ok;
	//implement your logic
	tag_t user_tag = NULLTAG;
	char* username = NULL;
	EPM_signoff_decision_t desc = EPM_no_decision;
	char* comments = NULL;
	char* new_type = NULL;
	char* newpartreq = NULL;
	char* Userinfo1 = NULL;
	char* Userinfo2 = NULL;
	char* Userinfo3 = NULL;
	char* Userinfo4 = NULL;
	char* Userinfo5 = NULL;
	char* Userinfo6 = NULL;
	char* Userinfo7 = NULL;
	char* Userinfo8 = NULL;
	char* Userinfo9 = NULL;
	char* ERROR_MSG = NULL;
	char* DECISION = NULL;
	char* MCCFinalComment = NULL;
	char* ObsoluteNumber = NULL;
	char* TargetDate = NULL;
	char* MCCReasonApproveReject = NULL;
	char* decisiondate = NULL;
	char* CurrentTask = NULL;
	date_t decision_date = NULLDATE;
	tag_t tzroottask=NULLTAG;
	tag_t *tzattachment = NULLTAG;
	tag_t master = NULLTAG;
	tag_t query_ctrl = NULLTAG;
	tag_t *q_item_ctrl = NULLTAG;
	tag_t item_ctrl = NULLTAG;
	tag_t MCCApproveReject = NULLTAG;
	tag_t updateMCCRejectBy = NULLTAG;
	tag_t updateMCCApproveBy = NULLTAG;
	tag_t MCCapproveRejectComment = NULLTAG;
	tag_t updateMCCRejectDate = NULLTAG;
	tag_t updateMCCApproveDate = NULLTAG;
	tag_t updateApproveMCCStatus = NULLTAG;
	tag_t updateRejectMCCStatus = NULLTAG;
	tag_t updateMCCCompleteDate = NULLTAG;
	tag_t updateMCCRejectCount = NULLTAG;
	int izntaskattachment = 0;
	int n_found_ctrl = 0;
	int count = 0;
	int commentfound = 0;

	char
        *qry_entries_ctrl[1] = {"SYSCD"},
        *qry_values_ctrl[1]	= {"*"};
	
	POM_get_user(&username,&user_tag);
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::Starting for username :%s....\n",username);fflush(stdout);	

	EPM_ask_decision(msg.task,user_tag,&desc,&comments,&decision_date);
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::comments ==> %s\n",comments);fflush(stdout);

	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"object_type",&new_type);
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::new_type====>[%s]", new_type);fflush(stdout);
	
	AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq);
	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::newpartreq====>[%s]", newpartreq);fflush(stdout);

	ITK_date_to_string(decision_date,&decisiondate);
	if(desc==EPM_approve_decision)
	{
		DECISION = (char*)MEM_alloc(20*sizeof(char));
		tc_strcpy(DECISION,"Approved");
	}
	if(desc==EPM_reject_decision)
	{
		DECISION = (char*)MEM_alloc(20*sizeof(char));
		tc_strcpy(DECISION,"Reject");
	}

	printf("\n Veh_New_PartReq_CheckSignOffCommentFn::DECISION====>[%s]", DECISION);fflush(stdout);

	ITEM_ask_item_of_rev(tzattachment[0],&master);
	if(comments == NULL)
	{
		
		char* buff = NULL;
		
		buff = (char*)MEM_alloc(200*sizeof(char));
		sprintf(buff, "Sign off Comment is mandatory. Kindly enter comments before sign off");
		EMH_clear_errors();
		ifail=t9NewPartReqCre_Val016;
		EMH_store_error_s1(EMH_severity_error,ifail,buff);
		decision = EPM_nogo;
		if(buff)MEM_free(buff);
		return decision; 						
	}
	else
	{
		if(tc_strcmp(comments,"")==0)
		{
			char* buff = NULL;
			
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Sign off Comment is blank. Kindly enter comments before sign off");
			EMH_clear_errors();
			ifail=t9NewPartReqCre_Val016;
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision; 						
		}
		if(tc_strlen(comments)>0 && tc_strcmp(comments,"")!=0)
		{	
			if(master!=NULLTAG)
			{
				AOM_refresh(master, TRUE);

				if(desc==EPM_approve_decision || tc_strcmp(DECISION,"Approved")==0)
				{
					if(tc_strstr(CurrentTask,"Head Cost Eng Review")!=NULL)
					{
						POM_attr_id_of_attr("t5_ApprovedBy", "T5_VehNPR", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, username);

						POM_attr_id_of_attr("t5_RejectBy", "T5_VehNPR", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, "NA");

						POM_attr_id_of_attr("t5_ApproveDate", "T5_VehNPR", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, decisiondate);

						POM_attr_id_of_attr("t5_RejectDate", "T5_VehNPR", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, "NA");

						POM_attr_id_of_attr("t5_CompleteDate", "T5_VehNPR", &updateMCCCompleteDate);
						POM_set_attr_string(1, &master, updateMCCCompleteDate, decisiondate);

						POM_attr_id_of_attr("t5_ApproveReject", "T5_VehNPR", &MCCApproveReject);
						POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

						POM_attr_id_of_attr("t5_ApproveRejectComment", "T5_VehNPR", &MCCapproveRejectComment);
						POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);
					}
					if(tc_strstr(CurrentTask,"VIG Head Review")!=NULL)
					{
						POM_attr_id_of_attr("t5_VIGApprovedBy", "T5_VehNPR", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, username);

						POM_attr_id_of_attr("t5_VIGRejectBy", "T5_VehNPR", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, "NA");

						POM_attr_id_of_attr("t5_VIGApproveDate", "T5_VehNPR", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, decisiondate);

						POM_attr_id_of_attr("t5_VIGRejectDate", "T5_VehNPR", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, "NA");

						POM_attr_id_of_attr("t5_VIGCompleteDate", "T5_VehNPR", &updateMCCCompleteDate);
						POM_set_attr_string(1, &master, updateMCCCompleteDate, decisiondate);

						POM_attr_id_of_attr("t5_VIGApproveReject", "T5_VehNPR", &MCCApproveReject);
						POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

						POM_attr_id_of_attr("t5_VIGApproveComment", "T5_VehNPR", &MCCapproveRejectComment);
						POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);
					}
					
				}
				if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
				{
					if(tc_strstr(CurrentTask,"Head Cost Eng Review")!=NULL)
					{
						POM_attr_id_of_attr("t5_RejectBy", "T5_VehNPR", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, username);

						POM_attr_id_of_attr("t5_ApprovedBy", "T5_VehNPR", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

						POM_attr_id_of_attr("t5_RejectDate", "T5_VehNPR", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

						POM_attr_id_of_attr("t5_ApproveDate", "T5_VehNPR", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

						POM_attr_id_of_attr("t5_ApproveReject", "T5_VehNPR", &MCCApproveReject);
						POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

						POM_attr_id_of_attr("t5_ApproveRejectComment", "T5_VehNPR", &MCCapproveRejectComment);
						POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);
					}
					if(tc_strstr(CurrentTask,"VIG Head Review")!=NULL)
					{
						POM_attr_id_of_attr("t5_VIGRejectBy", "T5_VehNPR", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, username);

						POM_attr_id_of_attr("t5_VIGApprovedBy", "T5_VehNPR", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

						POM_attr_id_of_attr("t5_VIGRejectDate", "T5_VehNPR", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

						POM_attr_id_of_attr("t5_VIGApproveDate", "T5_VehNPR", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

						POM_attr_id_of_attr("t5_VIGApproveReject", "T5_VehNPR", &MCCApproveReject);
						POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

						POM_attr_id_of_attr("t5_VIGRejectComment", "T5_VehNPR", &MCCapproveRejectComment);
						POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);
					}
					
				}

				POM_save_instances(1, &master, false);
				printf("\n Veh_New_PartReq_CheckSignOffCommentFn::Completed::POM_save_instances");fflush(stdout);
				AOM_refresh(master, FALSE);
			}
			decision = EPM_go;
		}
	}	
	
	return decision;
}




/****************************************************************************
    Function:       tm_Veh_New_Part_Reqest_register_rule_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_Veh_New_Part_Reqest_register_rule_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						
		retcode = EPM_register_rule_handler (
								"TML_Veh_Check_Target",
								"TML_Veh_Check_Target",
								(EPM_rule_handler_t)TML_Veh_New_Part_Reqest_Check_TargetFunction
								);

		retcode = EPM_register_rule_handler (
								"TML_Veh_Check_Reviewers",
								"TML_Veh_Check_Reviewers",
								(EPM_rule_handler_t)Veh_New_PartReq_assign_manager_teamreviewer
								);

		retcode = EPM_register_rule_handler (
								"TML_Veh_Check_Target_LC",
								"TML_Veh_Check_Target_LC",
								(EPM_rule_handler_t)Veh_New_PartReq_ChkdmlActiveinLC
								);

		retcode = EPM_register_rule_handler (
								"VehReviewer_SignOffCheck",
								"VehReviewer_SignOffCheck",
								(EPM_rule_handler_t)VehReviewer_SignOffCheckFunction
								);

		retcode = EPM_register_rule_handler (
								"TML_Veh_SignOff_Comment",
								"TML_Veh_SignOff_Comment",
								(EPM_rule_handler_t)Veh_New_PartReq_CheckSignOffCommentFn
								);


		printf("\n tm_Veh_New_Part_Reqest_register_rule_handlers\n");fflush(stdout);
	}
	return retcode;
}


/****************************************************************************
Function:       MYTPE_Veh_New_Part_Reqest
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

extern int MYTPE_Veh_New_Part_Reqest(int *decision, va_list args)
{
    int          ifail = ITK_ok;
   	METHOD_id_t  method1;
   	METHOD_id_t  method2;
   	METHOD_id_t  method3;
   	METHOD_id_t  method4;
   	METHOD_id_t  method5;
   

	TC_argument_list_t
        *myArgs;
	//METHOD_function_t ;
	char *lov_type=NULL;
	char *DGrp=NULL;
	int i=0;
    *decision = ALL_CUSTOMIZATIONS;

    /* Create the method by registering the base action.
    */
	printf("\n MYTPE_Veh_New_Part_Reqest - ");fflush(stdout);
	ifail = (METHOD_find_method("T5_VehNPR", "IMAN_save", &method4));
    if( ifail != ITK_ok )
	{
		EMH_store_error( EMH_severity_error, ifail );
	}
	
	
	if (method4.id != NULLTAG)
	{
		printf("\n before Method is added now::VehNewPartReqItem_create_post_action");fflush(stdout);
		ifail = ( METHOD_add_action(method4, METHOD_post_action_type, (METHOD_function_t) VehNewPartReqItem_create_post_action, NULL));
		printf("\n after Method is added now::VehNewPartReqItem_create_post_action");fflush(stdout);
		ifail = ( METHOD_add_pre_condition(method4, (METHOD_function_t) VehNewPartReqItem_create_pre_condition, NULL));
		printf("\n after Method is added now::VehNewPartReqItem_create_pre_condition");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}

	printf("\n before tm_Veh_New_Part_Reqest_register_action_handlers is added now");fflush(stdout);
	ifail = tm_Veh_New_Part_Reqest_register_action_handlers();
	printf("\n after tm_Veh_New_Part_Reqest_register_action_handlers is added now");fflush(stdout);

	ifail = tm_Veh_New_Part_Reqest_register_rule_handlers();
	printf("\n after tm_Veh_New_Part_Reqest_register_rule_handlers is added now");fflush(stdout);

	
    return ifail;
}

/****************************************************************************
    Function:       tm_Vehicle_New_NPR_register_custom_handlers
    Description:    Registering custom entry point

    Input:          int *decision
					va_list args

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/
extern DLLAPI int tm_Vehicle_New_NPR_register_custom_handlers( int *decision , va_list args)
{
	int ifail = ITK_ok;
	ifail = tm_Veh_New_Part_Reqest_register_action_handlers();
	*decision  = ALL_CUSTOMIZATIONS;
	args = NULL;
	printf("\n tm_Vehicle_New_NPR_register_custom_handlers\n");fflush(stdout);
	return ifail;
}

extern DLLAPI int tm_Vehicle_New_NPR_register_callbacks ()
{
    int ifail    = ITK_ok;
    printf("\n tm_Vehicle_New_NPR.c:before Revise_register_callbacks");fflush(stdout);
    
    ifail=CUSTOM_register_exit ( "tm_Vehicle_New_NPR", "USER_init_module", (CUSTOM_EXIT_ftn_t)  MYTPE_Veh_New_Part_Reqest);
    printf("\n after calling TML_register_callbacks\n");fflush(stdout);

  return ( ITK_ok );
}