/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_Update_Variant_Formula.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t CM_Update_Variant_Formula(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int l					= 0;
	int	n					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVC				= 0;
	int n_parents			= 0;
	int *levels				= 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t   DMLObject		= NULLTAG;
	tag_t	objTypeTag		= NULLTAG;
	tag_t	AssyTag			= NULLTAG;
	tag_t	ArchAssyTag		= NULLTAG;
	tag_t  *parents			= NULL;
	tag_t  ArchobjTypeTag	= NULLTAG;
	tag_t  *children1		= NULLTAG;
	tag_t  Childobject		= NULLTAG;
	tag_t   window,rule,item_tag = null_tag,top_line;
	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *Part_type	=NULL;
	char   *DMLDRstauts		=NULL;
	char   *value			=NULL;
	char   *Arch_obj		=NULL;
	char   *child_bl_formula=NULL;
	char*   ObjTyp=NULL;
	char*   type_name=NULL;
	char*   Archtype_name=NULL;
	char* child_bl_formula_cmp = NULL;

	//BOM_LINE
	char **child_rev_id = NULL;
 	char **child_rev_seq = NULL;
	char **child_rev_stat = NULL;
	char **child_objType = NULL;
	char **mod_addr = NULL;
 	int			revid			= 0;
 	int			revseq			= 0;
 	int			revstat			= 0;
 	int			blobjType		= 0;
 	int			modadd			= 0;
 	int			Variantflag		= 0;
 	int			Variantflag1		= 0;
	int	ifail = 0;
	int	strcnt1 = 0;
	int	strcnt2 = 0;
	int	strcnt3 = 0;
	int	strcnt4 = 0;
	int	strcnt5 = 0;
	int	strcnt6 = 0;
	
	char *username;
	char *userid;
	tag_t user_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;
	int designer_found=0,manager_found=0;
	tag_t * 	list;
	tag_t top_bom_line=NULLTAG;

	EPM_decision_t decision = EPM_go;
	
	printf("\n CM_Update_Variant_Formula Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Update_Variant_Formula Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
					if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
					printf("\n\t count is : %d",count);
					
					if(count >0)
					{
						flagVC=0;
						for(j=0;j<count;j++)
						{
						  if(AOM_ask_value_string(SecObject[j],"object_type",&objecttype));
						  if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
						  if(AOM_ask_value_string(SecObject[j],"object_desc",&objectdesc));
						  if(AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus));
						  if(AOM_ask_value_string(SecObject[j],"t5_PartStatus",&objectDRstatus));
						  if(AOM_ask_value_string(SecObject[j],"t5_PartType",&Part_type));

						  printf("\n\n\t CP Part_no  is :%s",Part_type);	fflush(stdout);
						  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
						  printf("SecObject objectdesc = [%s]\n",objectdesc);fflush(stdout);
						  printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  printf("SecObject objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
						  if(strcmp(Part_type,"M")==0)
							{
							  AssyTag=SecObject[j];
							  if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							  if(TCTYPE_ask_name2(objTypeTag,&type_name));
							  printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

							  if(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
							  printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
								
								/////////Module Variant Formula  Validation////////
								int parent_item_seq=0;
								tag_t itemrev =NULLTAG;
								char* Trgt_bl_formula=NULL;
								char*  Part_no =NULL;
								//int n_parents=0;
								//int *levels = 0;
								//tag_t *parents = NULL;
								int jd=0;
//								tag_t ArchAssyTag =NULLTAG;
//								char* Arch_obj= NULL;
//								tag_t ArchobjTypeTag=NULLTAG;
//								char   Archtype_name	= NULL;
//								tag_t window=NULLTAG;
//								tag_t  rule=NULLTAG;
//								tag_t top_line =NULLTAG;
								int n_BL=0;
								int p1=0;
//								tag_t *children1= NULL;
//								tag_t Childobject=NULLTAG;
								char* child_item_id = NULL;
								//char* child_bl_formula_cmp = NULL;
								char* child_bl_formula = NULL;
								tag_t  	master =	NULLTAG;
								char*  Arch_obj_str = NULL;
								tag_t relation_dep=	NULLTAG;
								int countConfigCtx = 0;
								tag_t  *ConfigCtxSecObject	= NULLTAG;
								tag_t ConfigCtx = NULLTAG;
								tag_t  ConfigCtxObjTypeTag=NULLTAG;
								char*   Config_CtxType	= NULL;
								char*	 SmVCContext			= NULL;
								char*	 SmCrIDContext			= NULL;
								char*	 ContextobjName			= NULL;

								tag_t	qry_t1	= NULLTAG;
								char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entr1 = 1;
								char    *qry_entr1[1]  = {"SYSCD"};
								int rsltCunt1=0;
								tag_t *CntrlObjTag1=NULLTAG;

								tag_t	queryTag	= NULLTAG;
								char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entries = 1;
								int resultCount=0;
								char *qry_entries[1] = {"ID"};

								tag_t *ConId  = NULL;
								int j=0;
								tag_t Optfmly_tag = NULLTAG;

								int dmlIncnt =0;
								int CmpleteVrf=0;
								char *username1;
								tag_t user_tag1=NULLTAG;
								char *userid1;
								


								if(n_parents>0)
								{
								  for (jd=0;jd<n_parents;jd++ )
								  {
									ArchAssyTag=parents[jd];
									if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
									printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
									if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name))PrintErrorStack();
									printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);

										  if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
										 if(AOM_ask_value_string(master,"item_id",&Arch_obj_str))PrintErrorStack();
										 printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

										 if(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep))PrintErrorStack();
										 if(relation_dep != NULLTAG)
										 {
											printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
										 }

										 if(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject))PrintErrorStack();
										 printf("\n\t Configuration Context count is : %d",countConfigCtx);


										if(countConfigCtx>0)
										{
											ConfigCtx=ConfigCtxSecObject[0];
											if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
											if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
											if(top_line!=NULLTAG)
											{
												if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
												printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
												if (n_BL >0)
												{
													
													for (p1=0;p1<n_BL ;p1++ )
													{
														int Result=1;
														if(Childobject) Childobject=NULLTAG;
														Childobject=children1[p1];
														if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
														printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

														if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula_cmp ))PrintErrorStack();
															printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula_cmp); fflush(stdout);
														

														if(tc_strcmp(objectId,child_item_id)==0)
														{

															

															 if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula));
														printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

													if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag))PrintErrorStack();
													if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType))PrintErrorStack();
													printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

													if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext))PrintErrorStack();
													printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

													if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext))PrintErrorStack();
													printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

													if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag))PrintErrorStack();
													printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
													if (queryTag)
													{
														printf("\n\tFound Query");fflush(stdout);
													}else
													{
														printf("\n\tNot Found Query");fflush(stdout);
													}

													qry_values[0] = SmCrIDContext;

													if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ConId))PrintErrorStack();
													printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

													if(POM_get_user(&username1,&user_tag1));
													SA_ask_user_identifier2	(user_tag1,&userid)	;
													printf ("Logged in userid1:::::%s %s\n",userid1,username1);fflush(stdout);
													if(tc_strcmp(userid1,"ercpsup")!=0 && tc_strcmp(userid1,"loader")!=0 && tc_strcmp(userid1,"su_mdm")!=0 && tc_strcmp(userid1,"infodba")!=0)
															{
																if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
																{
																	printf("\n CC available Variant formula not available \n"); fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",objectId);
																	decision = EPM_nogo;
																	return decision;
																	//return ITK_errStore;
																}
															}
//													else
//													{
//													  for (j=0;j<resultCount;j++ )
//													  {
//														 Optfmly_tag = ConId[j];
//														 if(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName))PrintErrorStack();
//														 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family
//
//														 if(ContextobjName)
//														 {
//															printf("\n\t child_bl_formula value:%s",child_bl_formula);
//															printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);
//
//															if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
//															{
//																printf("\n inside iff \n"); fflush(stdout);
//																dmlIncnt++;
//															}
//															else
//															 {
//																printf("\n inside else \n"); fflush(stdout);
//																CmpleteVrf++;
//															 }
//														 }
//													  }
//
//													  printf("\n dmlIncnt value is at end for loop :%d\n",dmlIncnt); fflush(stdout);
//													  if (dmlIncnt>0)
//													  {
//														  printf("\n dmlIncnt greator than 1 :%d\n",dmlIncnt); fflush(stdout);
//														  EMH_clear_errors();
//														  EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",objectId);
//														  return ITK_errStore;
//													  }
//
//													}
//
//													
//
//
//														
//
//															if (tc_strcmp(child_bl_formula_cmp,child_bl_formula)==0)
//															{
//																printf("\nDuplicate Variant Formula found,change is not allowed:%s %s\n",objectId,child_item_id);fflush(stdout);
//																EMH_clear_errors();
//																EMH_store_error_s4(EMH_severity_error,ITK_err,"\nDuplicate Variant formula  found for ",objectId,"  and ",child_item_id);
//																return ITK_errStore;
//															}
//
//															/// checkin for OR condition
//
//															if(QRY_find("ControlObjects", &qry_t1));
//															if (qry_t1)
//															{
//																printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
//															}
//															else
//															{
//																printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
//															}
//
//															qry_val3[0] = "Modulewith_OR1";
//															if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
//															printf(" \n ModulewithOR:rsltCunt1::::>>> :%d:", rsltCunt1); fflush(stdout);
//															if(rsltCunt1>0)
//															{
//																Result=BLFormula_Validate(ConfigCtx,child_bl_formula,child_bl_formula_cmp);
//																printf(" \n ModulewithOR:Result::::>>> :%d:", Result); fflush(stdout);
//																if (Result==0)
//																{
//																	EMH_store_error_s4(EMH_severity_error,ITK_err,"\nDuplicate Variant formula  found for ",objectId,"  and ",child_item_id);
//																	return ITK_errStore;
//																}
//															}
														}
													}
												}//
											}
										}
									}
								  }
								}
								else
								{
									printf("\n Module not attached to any architecture node. \n"); fflush(stdout);

								}
								


								tag_t ArchAssyTag =NULLTAG;
								char* Arch_obj= NULL;
								tag_t ArchobjTypeTag=NULLTAG;
								char*   Archtype_name	= NULL;
								tag_t window=NULLTAG;
								tag_t  rule=NULLTAG;
								tag_t top_line =NULLTAG;
								tag_t *children1= NULL;
								tag_t Childobject=NULLTAG;



							  if(n_parents>0)
								{
								  for (k=0;k<n_parents;k++ )
								  {
									ArchAssyTag=parents[k];
									if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));
									printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
									printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
									  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
									  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
									  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
									  if(top_line!=NULLTAG)
									  {
										  if(BOM_line_ask_child_lines (top_line, &n, &children1));
										  printf("\n\t No of child objects are n : %d",n);fflush(stdout);
										  if (n >0)
										  {
											  for (l=0;l<n ;l++ )
											  {
											     if(Childobject) Childobject=NULLTAG;
											     Childobject=children1[l];
											     if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula));
											     printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);
											     if(Childobject != NULLTAG)
												{
													printf("\n Validate VF handler called \n");fflush(stdout);
													
													
													if( AOM_ask_displayable_values(Childobject,"bl_item_item_id",&strcnt1,&child_rev_id))PrintErrorStack();
                                                    if( AOM_ask_displayable_values(Childobject,"bl_rev_item_revision_id",&strcnt2,&child_rev_seq))PrintErrorStack();
                                                    if( AOM_ask_displayable_values(Childobject,"bl_rev_release_status_list",&strcnt3,&child_rev_stat))PrintErrorStack();
                                                    if( AOM_ask_displayable_values(Childobject,"bl_item_object_type",&strcnt4,&child_objType))PrintErrorStack();
													
													
													printf("\n Part:%s %s Status:%s  child_objType <%s> \n",child_rev_id[0],child_rev_seq[0],child_rev_stat[0],child_objType[0]);fflush(stdout);
                                               if(strcnt4>0)
											   {
													if (tc_strcmp(child_objType[0],"Colour Part")==0)
													{
														return ITK_ok;
													}
											   }

													if(BOM_line_ask_window(Childobject,&window))PrintErrorStack();
													if(window != NULLTAG)
													{
														  if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
														  if(top_bom_line != NULLTAG)
														  {
															 
															 
															  if( AOM_ask_displayable_values(top_bom_line,"fnd0bl_line_object_type",&strcnt5,&child_objType))PrintErrorStack();
															if(strcnt5>0)
															{
															  if (tc_strcmp(child_objType[0],"T5_PlatformRevision")==0)
															  {
																POM_get_user(&username,&user_tag);
																SA_ask_user_identifier2	(user_tag,&userid)	;
																printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
																if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0)
																{
																	printf("\n Variant formula with X4 Context Not Allowed \n");fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated at platform level","Send architecture node separately to Structure Manager to edit variant formula of the module");
																	decision = EPM_nogo;
																	return decision;
																	//return ITK_errStore;
																}
															  }
															}
														  }
													}
													
												if(strcnt2>0 && strcnt3>0)
												{
													if((tc_strstr(child_rev_stat[0],"Release") != NULL) && (tc_strstr(child_rev_seq[0],"NR") != NULL))
													{
														printf ("\n NOT Allowed to updte Variant Formula as child_rev_stat[0]:- ERC Release & child_rev_seq[0]:- is NR \n");fflush(stdout);
														Variantflag++;
													}

													else if((tc_strcmp(child_rev_stat[0],"ERC Review") == 0) && (tc_strstr(child_rev_seq[0],"NR") == NULL))
													{
														printf ("\n NOT Allowed to updte Variant Formula as child_rev_stat[0]:- ERC Release & child_rev_seq[0]:- is not NR \n");fflush(stdout);
														Variantflag1++;
													}

													else if((tc_strstr(child_rev_stat[0],"Release") != NULL) && (tc_strstr(child_rev_seq[0],"NR") == NULL))
													{
														printf ("\n Allowed to updte Variant Formula as child_rev_stat[0]:- ERC Release & child_rev_seq[0]:- not NR \n");fflush(stdout);
														Variantflag++;
													}
													//else if((tc_strstr(child_rev_stat[0],"Review") != NULL) && (tc_strstr(child_rev_seq[0],"NR") != NULL))
													else if((tc_strcmp(child_rev_stat[0],"ERC Review") == 0) && (tc_strstr(child_rev_seq[0],"NR") != NULL))

													{
														printf ("\n Allowed to updte Variant Formula child_rev_stat[0]:- ERC Reviev & child_rev_seq[0]:- NR \n");fflush(stdout);
														Variantflag1++;
													}
												}
//													else
//													{
//														Variantflag1++;
//														
//													}
													
													if (Variantflag1>0)
													{
														POM_get_user(&username,&user_tag);
														SA_ask_user_identifier2	(user_tag,&userid)	;
														printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
														if((tc_strcmp(userid,"su_mdm")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
														{
													
													if(strcnt1>0)
													{
															printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id[0],child_rev_seq[0][0]);fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula updation is allowed if Module Revision =NR and Release Status =ERC Review","For Revision other than NR kindly take Update variant formula type DML",child_rev_id[0]);
															decision = EPM_nogo;
															return decision;
													}
															//return ITK_errStore;
														}
													}
													if (Variantflag>0)
													{
														POM_get_user(&username,&user_tag);
														SA_ask_user_identifier2	(user_tag,&userid)	;
														printf ("Logged in user:%s\n",userid);fflush(stdout);
														if((tc_strcmp(userid,"su_mdm")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
														{
																
																	//if(BOM_line_ask_attribute_string(Childobject, modadd, &mod_addr))PrintErrorStack();
																	 if( AOM_ask_displayable_values(Childobject,"bl_Design Revision_t5_ModuleAddress",&strcnt6,&mod_addr))PrintErrorStack();
																	printf("\n mod_addr:%s\n",mod_addr[0]);fflush(stdout);
																	if(strcnt6>0)
																	{
																	if(mod_addr[0] != NULL && strlen(mod_addr[0]) > 0)
																	{

																		designer_role = (char *)MEM_alloc ((strlen(mod_addr[0]) + strlen("_Designers")) * sizeof(char));
																		strcpy(designer_role,mod_addr[0]);
																		strcat(designer_role,"_Designers");
																		manager_role  = (char *)MEM_alloc ((strlen(mod_addr[0]) + strlen("_Managers")) * sizeof(char));
																		strcpy(manager_role,mod_addr[0]);
																		strcat(manager_role,"_Managers");
																		printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

																		if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list))PrintErrorStack();
																		if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list))PrintErrorStack();
																		printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
																		if(designer_found == 0 && manager_found == 0)
																		{
																			EMH_clear_errors();
																			EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
																			decision = EPM_nogo;
																			return decision;
																			//return ITK_errStore;
																		}

																	}
																	else
																	{
																			EMH_clear_errors();
																			EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address is blank for this module","Contact PLM Team to update Module Address",userid);
																			decision = EPM_nogo;
																			return decision;
																			//return ITK_errStore;
																	}
																	}
																
																else
																{
																			EMH_clear_errors();
																			EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address not found for this module","Contact PLM Team to update Module Address",userid);
																			decision = EPM_nogo;
																			return decision;
																			//return ITK_errStore;
																}
														}	
													}
												}
											  }
										  }
									  }
									}
								  }
								}
							}
						}
					}	
				}
			}
		}
	}
	printf("\n CM_Update_Variant_Formula Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Update_Variant_Formula Function end...");
	return decision;
}

