/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : EPADetailReport.c
* Created By                   : Sneha Modak
* Created On                   : 10/10/2018
* Project                      : TML
* Description                  : On TMML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/

	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	#include <tc/iman.h>
	#include <tccore/imantype.h>
	#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>
	#include <unistd.h>
	
#define ITK_err 919002
#define MAX_LINE_LEN 1024
#define GRM_create_msg "GRM_create"   1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

		int 			TotalAffectedGrp					= 0;
		int 			TotalResltparts					= 0;
		int 			TotalAddparts					= 0;
		int 			TotalDelparts					= 0;
		int 			TotalQtychngparts				= 0;
		
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}


	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text (stat, &err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
	
		typedef struct delta_bom
	{
		int count;
		char **uidlist;
		int *status;
		
		
	}Delta_Bom;
	
int EPAMBPAExclusiveReport_func(char*,char*,char*,char*,char*,char*,char***,int*);
int EPAMBPAExclusiveReport_func_Signoff(char*,char*,char*,char***,int*);
char* subString_attach (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;


	
	void getIndex(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=-1;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=k;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}

void getStrByIndex(char **view_list,int count,int idx,char **str)
{

		printf("\n **getStrByIndex");fflush(stdout);
		
		*str =view_list[idx];
	 
		


}
	
	void setAddStr(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr character found===%s",(*strset)[*count-1]);fflush(stdout);



	}



	
	
	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
	{

	*count=*count+1;
	if(*count==1)
	{
	printf("\n ****setAddTAG1");fflush(stdout);
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG2");fflush(stdout);
	}
	else
	{
	printf("\n **setAddTAG3");fflush(stdout);
	(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG4");fflush(stdout);
	printf("\n **serTAG6");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




	}
	
void setAddInt(int *count,int **objlist,int obj )
        {

        *count=*count+1;
        if(*count==1)
        {
        printf("\n ****setAddTAG1");fflush(stdout);
        (*objlist) = (int *)malloc((*count ) * sizeof(int ));
        printf("\n ***setAddTAG2");fflush(stdout);
        }
        else
        {
        printf("\n **setAddTAG3");fflush(stdout);
        (*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
        printf("\n ***setAddTAG4");fflush(stdout);
        printf("\n **serTAG6");fflush(stdout);
        }

        (*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




        }

void setFindStr(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=0;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=1;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}



static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}
/****************************************************************************/
/* Function Name    : FU_dumpItkErrors                                      */
/*                                                                          */
/* Called From      : ITK                                                   */
/*                                                                          */
/* Input Parms      : int stat                                              */
/*                    const char * prog_name                                */
/*                    int line_number                                       */
/*                    const char * file_name                                */
/*                                                                          */
/* Output Parms     : None                                                  */
/*                                                                          */
/* Functions called : None                                                  */
/*                                                                          */
/* File Description : Called by the ITK macro to log errors                 */
/*                                                                          */
/* Return Value     : Void                                                  */

/**********************************************************************/

 void autoresizestrAdd_SVRAttach(char **src,char* dest)
{	
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";	
	//printf("\n autoresizestrAdd_SVRAttach src len==%d",strlen(*src));
	//printf("\n autoresizestrAdd_SVRAttach desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
   // src = MEM_realloc(src, size_ab);
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
}
/*This will attach/replace the report to the reference items*/
int FindOrCreateDatasetAndAttachInWF(tag_t ERCDmlName,char *datasetName, char *datasetLocation)
{
	int	status	=	ITK_ok;
	int ifail=0;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t dml_Ref_Rel       = NULLTAG;
	tag_t dml_Ref_Rel_t     = NULLTAG;
	printf("\n\n\n Inside FindOrCreateDatasetAndAttachInWF  got datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);
	
   if(access(datasetLocation,F_OK)!=-1)
	{
		printf("\n [%s] access ok\n",datasetLocation);fflush(stdout);
		ITK_CALL(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		printf("\n IMAN_reference found\n");fflush(stdout);
		TC_write_syslog("datasetfile accessed\n");
		ITK_CALL(AE_find_datasettype2("MSExcelX",&msWordType));//MSExcelx
		printf("\n datasetType Fetched\n");fflush(stdout);
		if(msWordType == NULLTAG)
		{
				printf("\n datasetType refrences not found\n");fflush(stdout);
				TC_write_syslog("Could not find Dataset Type Text. Please check data model\n");
				//continue;
		}
		else
		{
			printf("\n datasetType refrences found\n");fflush(stdout);
			int datasetExistsFlag = 0;
			tag_t * DatasetObj = NULL;
			int datasetCount = 0;
			char *ERCDmlDatasetName = NULL;
			//Expand the task to check if dataset is already present
			ITK_CALL(GRM_list_secondary_objects_only(ERCDmlName,dml_Ref_Rel,&datasetCount,&DatasetObj));
			if(datasetCount>0)
			{
				int k = 0;
				for(k=0;k<datasetCount;k++)
				{
					/*Check if Dataset already present or not*/
					ITK_CALL(AOM_ask_value_string(DatasetObj[k],"object_name",&ERCDmlDatasetName));
					printf("\n ERCDmlDatasetName[%s] \n",ERCDmlDatasetName);fflush(stdout);
					if(strcmp(ERCDmlDatasetName,datasetName)==0)
					{
						datasetExistsFlag=1;
						wordDataset = DatasetObj[k];
						printf("\n ERCDmlDatasetName[%s] already exists\n",ERCDmlDatasetName);fflush(stdout);
						break;
					}
				}
				
			}
			//End Expand the task to check if dataset is already present
			if(wordDataset==NULLTAG)
			{
				ITK_CALL(AE_create_dataset_with_id(msWordType,datasetName,"","","",&wordDataset));
				printf("\n Dataset[%s] Created\n",datasetName);fflush(stdout);
				ITK_CALL(AE_save_myself(wordDataset));
				printf("\n DataSet Saved\n");fflush(stdout);
				ITK_CALL(GRM_create_relation(ERCDmlName,wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
				printf("\n Relation Between DML and dataset created\n");fflush(stdout);
				ITK_CALL(AOM_load(dml_Ref_Rel_t));
				printf("\n Relation loaded\n");fflush(stdout);
				ITK_CALL(GRM_save_relation(dml_Ref_Rel_t));
				printf("\n Relation of DML and dataset saved\n");fflush(stdout);
				
			}
			//	ITK_CALL(AE_find_dataset2(datasetName,&wordLatestDat_t));
			ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
			printf("\n Fetched already existing dataset\n");fflush(stdout);
			ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
			printf("\n Refreshing Dataset\n");fflush(stdout);
			ITK_CALL(AOM_lock(wordDataset));
			if(datasetExistsFlag==1)
			{
				ITK_CALL(AE_remove_dataset_named_ref2(wordLatestDat_t,"excel"));
				printf("\n Refrence Removed\n");fflush(stdout);
			}

			/*
			//only refreshing of the object
			ITK_CALL(AE_import_named_ref(wordLatestDat_t,"excel",datasetLocation,NULL,SS_BINARY));
			//if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok);
			printf("\n File Updated\n");fflush(stdout);
			ITK_CALL(AE_save_myself(wordLatestDat_t));
			printf("\n Saved all things\n");fflush(stdout);
			ITK_CALL(AOM_unlock(wordDataset));
			remove(datasetLocation);
			printf("\n File removed\n");fflush(stdout);*/
			//Modification for TC12 Upgradation
			int ref_count;
                char **ref_list;
                tag_t filetag   = NULL;
                IMF_file_t fileDescriptor;

                ITK_CALL(AE_ask_datasettype_refs(msWordType, &ref_count, &ref_list));
                                                                

                ITK_CALL(IMF_import_file(datasetLocation,NULL, SS_BINARY, &filetag, &fileDescriptor));
                printf("\nFile Imported--->");fflush(stdout);
                ITK_CALL(AOM_save_without_extensions(filetag));
                printf("\nFile saved--->");fflush(stdout);

                ITK_CALL(AE_add_dataset_named_ref2(wordLatestDat_t,ref_list[0],AE_PART_OF ,filetag));
                printf("\n DatesetName44\n");fflush(stdout);
                ITK_CALL(AOM_save_without_extensions(wordLatestDat_t));
                printf("\n DatesetName55 \n");fflush(stdout);			
		//END Modification for TC12 Upgradation
		   // if(docFile) MEM_free(docFile);

		}
	}
	else
	{
		printf("\n Dataset location not presewnt[%s]" , datasetLocation);fflush(stdout);
	}
	return ITK_ok;
}
/*This method will fetch all details like SVC, Variant, Task etc, Create necessarry input files, and make system call to the shell scripe and on completion will call another method to attach the report*/
int AttachSVRCompReportInWF(tag_t *ErcObj)
{
	char *DMLID = NULL;
	char *DMLRelType = NULL;
	char *DMLTaskID = NULL;
	char *object_type = NULL;
	tag_t relation_type = NULLTAG;
	tag_t Reference_relation_type = NULLTAG;
	tag_t * 	brkDwnObj = NULL;
	tag_t * 	ReferenceObj = NULL;
	char * partNumber = NULL;
	char * partType = NULL;
	int relCount= 0;
	int relCountRef= 0;
	char *inputForReport = NULL;
	int i=0;

	
	inputForReport = (char *) MEM_alloc( 1000 * sizeof(char) );
    tc_strcpy(inputForReport,"");
	printf("\n\n\n Inside AttachSVRCompReportInWF \n");fflush(stdout);
	ITK_CALL(AOM_ask_value_string(ErcObj[0],"item_id",&DMLID));
	printf("\n\nDML Number found [%s] \n",DMLID);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(ErcObj[0],"t5_rlstype",&DMLRelType));
	printf("\n DML Release type[%s] \n",DMLRelType);fflush(stdout);
	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
	ITK_CALL(GRM_list_secondary_objects_only(ErcObj[0],relation_type,&relCount,&brkDwnObj));
	printf("\n\n Total Number Of ERC TASKS Found ==[%d] \n",relCount);fflush(stdout);
	
	for(i=0;i<relCount;i++)
	{
		ITK_CALL(AOM_ask_value_string(brkDwnObj[i],"item_id",&DMLTaskID));
		printf("\n\n DML Task found [%s] \n",DMLTaskID);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(brkDwnObj[i],"object_type",&object_type));
		printf("\n\n object_type found [%s] \n",object_type);fflush(stdout);
		if(tc_strcmp(object_type,"T5_ChangeTaskRevision") == 0)
		{
			ITK_CALL(GRM_find_relation_type("CMReferences",&Reference_relation_type));
			ITK_CALL(GRM_list_secondary_objects_only(brkDwnObj[i],Reference_relation_type,&relCountRef,&ReferenceObj));
			printf("\n\n Total Number Of References Found ==[%d] \n",relCountRef);fflush(stdout);
			if(relCountRef>0)
			{
				int j=0;
				tag_t query = NULLTAG;
				int noOfCoObjects = 0;
				tag_t *Coobjects = NULL;
				char *information1=NULL;
				char *tempbom = NULL;
				char *tempSVR = NULL;
				char temp[500] ;
				char *fileName = NULL;
				tempSVR = (char *) MEM_alloc( 1 * sizeof(char) );
				fileName = (char *) MEM_alloc( 1 * sizeof(char) ); 
				tempbom = (char *) MEM_alloc( 1 * sizeof(char) );
				tc_strcpy(tempSVR,"");
				tc_strcpy(fileName,"");
				tc_strcpy(tempbom,"");
				FILE* dmlFile =NULL;
				logical deleteIndicator = true;
				printf("\n\n\n Inside relCountRef>0 \n");fflush(stdout);
				char *qry_entries[]	 = { "SYSCD","SUBSYSCD"},*qry_values[]  = {"WFSVR","SVR-SVRCOMPARE"};

				ITK_CALL(QRY_find2("Control Objects...", &query));
				printf("\n query found");fflush(stdout);
				ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, &noOfCoObjects, &Coobjects));
				printf("\n query executed");fflush(stdout);
				printf("\n\n Total Number Of Coobjects Found ==[%d] \n",noOfCoObjects);fflush(stdout);
				
				if(noOfCoObjects>0)
				{
					ITK_CALL(AOM_ask_value_logical(Coobjects[0],"t5_DelInd",&deleteIndicator));
					printf("\n deleteIndicator :[%d]\n",deleteIndicator);fflush(stdout);
				}
				
				if(deleteIndicator==false) // change this - Palash
				{
					char OneRowData[500];
					ITK_CALL(AOM_ask_value_string(Coobjects[0],"t5_Userinfo1",&information1));
					printf("\n\n information1 : [%s] \n",information1);fflush(stdout);
					 tc_strcat(inputForReport,information1);
					 tc_strcat(inputForReport," ");
					 int isFirst=0;
					 for(j=0;j<relCountRef;j++)
					{
						ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"object_type",&partType));
						if(strcmp(partType,"T5_PlatformRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"item_id",&partNumber));
							autoresizestrAdd_SVRAttach(&tempbom,partNumber);
							autoresizestrAdd_SVRAttach(&tempbom," ");
						}
						if(strcmp(partType,"VariantRule")==0)
						{
							/*if(isFirst==0)
								isFirst=1;
							else
							autoresizestrAdd_SVRAttach(&tempSVR,","); */
						
							ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"object_name",&partNumber));
							autoresizestrAdd_SVRAttach(&tempSVR,partNumber);
                            autoresizestrAdd_SVRAttach(&tempSVR,",");
							
						}
						printf("\n\n Part Number :[%s], Part Type :[%s] \n",partNumber,partType);fflush(stdout);
					}
					
					
					tc_strcat(inputForReport,tempbom);
					//strncpy(temp,tempSVR,strlen(tempSVR)-1);
					//temp[strlen(tempSVR)]='\0';
					//printf("\n temp = [%s]",temp);fflush(stdout);
					tc_strcat(inputForReport,tempSVR);
					tc_strcat(inputForReport," ");
					autoresizestrAdd_SVRAttach(&fileName,"/tmp/");
					autoresizestrAdd_SVRAttach(&fileName,DMLTaskID);
					autoresizestrAdd_SVRAttach(&fileName,".txt");
					tc_strcat(inputForReport,fileName);
					printf("\n inputForReport=[%s]\n",inputForReport);fflush(stdout);
					//Place a system call
					system(inputForReport);
					
					//after system call is completed
					//Attach Report TO task
					//open dml.txt file from tmp folder
					dmlFile=fopen(fileName,"r");
					printf("\n fileName=[%s] opened\n",fileName);fflush(stdout);
					if(dmlFile == NULL) 
						{
							printf("\n Error opening file");fflush(stdout);

							printf("\nSVRReport: SVR Report is not Generated for : %s \n",DMLTaskID);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR-SVRReport: SVR Report is not Generated, Kindly Raise Ticket in DML Support Catagory.");
							return ITK_err;
						  //return(-1);
						}
					while(fgets(OneRowData,500,dmlFile)!=NULL)
					{
						printf("\n OneRowData:[%s]",OneRowData);fflush(stdout);
						char * datasetName = NULL;
						char * datasetLocation = NULL;
						datasetName = strtok(OneRowData,":");
						datasetLocation = strtok(NULL,":");
						trimTrailing(datasetLocation);
						trimTrailing(datasetName);
						
						printf("\n datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);
						//ITK_CALL(FindOrCreateDatasetAndAttachInWF(ErcObj[0],datasetName,datasetLocation));
						printf("\n FindOrCreateDatasetAndAttachInWF called successfully \n");fflush(stdout);
					}
				} 
				else
				{
					printf("\n control object is not live \n");fflush(stdout);
				}
			}
			else
			{
				printf("\n\n No Reference Object Found \n");fflush(stdout);
			}
		}
		else
		{
			printf("\n\n not ERC TASK REVISION \n");fflush(stdout);
		}
	}
	return 0;
}

/* int generateAndAttachReport()
{
	tag_t query = NULLTAG;
	int noOfObjects = 0;
	tag_t *objects = NULL;
	
	
	printf("\n\n\n Inside called function \n");fflush(stdout);
	char *qry_entries[]	 = { "ID"},*qry_values[]  = {"16PP251665"};
	
	ITK_CALL(QRY_find2("ERC DML Revision", &query));
	printf("\n query found");fflush(stdout);
	ITK_CALL(QRY_execute(query,1, qry_entries, qry_values, &noOfObjects, &objects));
	printf("\n query executed");fflush(stdout);
	printf("\n\n Total Number Of Objects Found ==[%d] \n",noOfObjects);fflush(stdout);
	
	ITK_CALL(AttachSVRCompReportInWF(objects));

	
	return 0;
} */


/*  int ITK_user_main( int argc , char* argv[] )
{            
   ITK_set_journalling (TRUE);
   
   //char* property[10];
   
   //ITK_CALL(ITK_init_module("infodba","infodba","dba"));              
   //error(z,"login success\n");
   
   ITK_CALL(ITK_auto_login());
   printf("\n\n\nlogin Successfull \n");fflush(stdout);
   
   //ITK_CALL(generateAndAttachReport());
   tag_t query = NULLTAG;
	int noOfObjects = 0;
	tag_t *objects = NULL;
	
	
	printf("\n\n\n Inside called function \n");fflush(stdout);
	char *qry_entries[]	 = { "ID"},*qry_values[]  = {"22PU157310"};
	
	ITK_CALL(QRY_find2("ERC DML Revision", &query));
	printf("\n query found");fflush(stdout);
	ITK_CALL(QRY_execute(query,1, qry_entries, qry_values, &noOfObjects, &objects));
	printf("\n query executed");fflush(stdout);
	printf("\n\n Total Number Of Objects Found ==[%d] \n",noOfObjects);fflush(stdout);
	
	ITK_CALL(AttachSVRCompReportInWF(objects));
               
   //ITK_CALL(POM_logout(false))   ;
   return 0;
}*/   

/*Implementing Handler*/
int SVRComp_RptAttach( EPM_action_message_t msg )
{
	int ifail = 0;
	tag_t root_task		= NULLTAG;
	tag_t DMLRevTag		= NULLTAG;
	tag_t DMLLcmTag		= NULLTAG;
	tag_t objTypTag		= NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t *breakdowntask = NULLTAG;
	tag_t *VecVODObJ	= NULLTAG;
	tag_t *attachments	= NULLTAG;
	tag_t *DMLRevision	= NULLTAG;
	char *part_type		= NULLTAG;
	tag_t *obj_type		= NULLTAG;
	tag_t objTypeTag	= NULLTAG;
	int i=0,j=0,count=0,count_rev=0,countall=0,ir=0,countVOD=0,it=0,VODAttachedFound=0;
	logical is_latest;
	char *dmlNumber			=NULL;
	char *type_name			=NULL;
	char *dmlrelease_type	=NULL;
	char *Objtype_name		=NULL;
	//char ObjTyp[TCTYPE_name_size_c+1];
	
	char *ObjTyp            =NULL;
	
	tag_t tsk_dml_rel_type = NULLTAG;
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));

	printf("\n Start of SVRComp_RptAttach::SVR Release No of attachments: %d -------",count); fflush(stdout);

	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			DMLLcmTag=attachments[i];

			if(TCTYPE_ask_object_type(DMLLcmTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));

			printf("\n SVRComp_RptAttach--Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));

				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_rev,&DMLRevision));
					printf("\n SVRComp_RptAttach--number of ERC DML : %d",count);fflush(stdout);

					for (j=0;j<count_rev ;j++ )
					{
						CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
						printf("\n SVRComp_RptAttach--SVR Release is_latest : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
								printf("\n SVRComp_RptAttach--ERC DML - Not latest \n");fflush(stdout);
						}
						else
						{
							DMLRevTag = DMLRevision[j];

							CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber));
							CALLAPI( AOM_ask_value_string(DMLRevTag,"t5_rlstype",&dmlrelease_type));

							printf("\n SVRComp_RptAttach--DML Number: [%s] \t Release Type: [%s] \n",dmlNumber,dmlrelease_type);fflush(stdout);

							/*Only to be called it the ERC release type is vehicle*/
							VODAttachedFound=0;
							if(strcmp(dmlrelease_type,"Veh")==0)
							{
								printf("\n SVRComp_RptAttach--Calling AttachSVRCompReportInWF...\n");fflush(stdout);

								tag_t dmlObjs[] = {DMLRevTag};
								ITK_CALL(AttachSVRCompReportInWF(dmlObjs));

								printf("\n SVRComp_RptAttach--AttachSVRCompReportInWF Completed..\n");fflush(stdout);
							}
							else
							{
								printf("\n SVRComp_RptAttach--Release Type is not Vehicle...\n");fflush(stdout);
							}
						}
					}
				} //End of if (tsk_dml_rel_type!=NULLTAG)
			} //End of if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
		}
	} //End of if(count>0)
	
	printf("\n End of SVRComp_RptAttach ........\n");fflush(stdout);

	return ITK_ok;
}

extern int SVRComp_RptAttach_register_method(int *decision, va_list args)
{
	int ifail=0;
	*decision = ALL_CUSTOMIZATIONS;
	tag_t objTag = va_arg(args, tag_t);
	//registering action handler SVRComp_RptAttach
	ITK_CALL(EPM_register_action_handler("SVRComp_RptAttach", "SVRComp_RptAttach", SVRComp_RptAttach));
	return ITK_ok;
}

extern DLLAPI int tm_SVRComp_RptAttach_register_callbacks()
{
	//Registering handler
	CUSTOM_register_exit("tm_SVRComp_RptAttach", "USER_init_module", (CUSTOM_EXIT_ftn_t) SVRComp_RptAttach_register_method);
	//printf("\n registered function svr_release_dml111\n");     fflush(stdout);
	return ( ITK_ok );
}
