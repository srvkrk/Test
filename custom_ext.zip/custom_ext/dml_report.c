#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <unidefs.h>
#include <tccore/libtccore_exports.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)));

int DML_input(char *dmlNoS);
int	ifail = ITK_ok;

FILE *fpDml = NULL;

static int report_error(char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

static int PrintErrorStack( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	
	for ( i = 0; i < iNumErrs; i++ )
	{
		
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}

//********************************************************************

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;

	char *dmlNoStr = NULL;
	
	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);
	

	dmlNoStr = ITK_ask_cli_argument("-dmlno=");
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
	{
			printf("\nLogin Successfull.....!!\n");fflush(stdout);
			printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	printf("\nBefore Function starts........1 \n\n");fflush(stdout);
	
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}


	printf("\nBefore Function starts \n\n");fflush(stdout);
	
	ifail = DML_input(dmlNoStr);
	
	CHECK_FAIL;

	printf("\n*********************");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);


	printf("/nCode Run /n");fflush(stdout);

	return ifail;
}


int DML_input(char *dmlNoS)
{
	tag_t item =NULLTAG;
	tag_t CMReferencesTag=NULLTAG;
	tag_t *DMLBreak = NULLTAG;
	tag_t *DMLChangeReferences=NULLTAG;
	tag_t *attachments=NULLTAG;
    tag_t rev=NULLTAG;
	tag_t TaskDMLRelTag=NULLTAG;
	tag_t Jtrel=NULLTAG;
	tag_t window=NULLTAG;
	tag_t *JT=NULLTAG;
    tag_t JT1=NULLTAG;
	tag_t object_type_t=NULLTAG;
	tag_t *DMLChangeReferences_Attchments=NULLTAG;
	tag_t top_bom_line=NULLTAG;
	tag_t *childern=NULLTAG;
	tag_t *rel_statTags=NULLTAG;
	tag_t  rule = NULLTAG;
	tag_t  tsk_HSI_rel_type = NULLTAG;
	tag_t PartRevTag=NULLTAG;
	tag_t PartsForGMFlTag=NULLTAG;
	tag_t PartRevTag1=NULLTAG;
	tag_t dataset=NULLTAG;
	tag_t CMSolutions=NULLTAG;
	tag_t *task_Rel=NULLTAG;
	tag_t *task=NULLTAG;
	tag_t *task1=NULLTAG;
	tag_t task12=NULLTAG;
	tag_t CMReferencesTag1=NULLTAG;
	char* value=NULL;
	char*value_Structure=NULL;
	char*object_rev_id=NULL;
    char*AggregateGroup_Found=NULL;
	char*Item_ID=NULL;
	char*object_type=NULLTAG;
	char*t5_ProjectCode=NULLTAG;
	char*anlyst=NULLTAG;
	char*rel_stat=NULL;
	char*rel_stat_type=NULL;
	char*ID=NULL;
	int stCnt=0;
	char buffer[80];
	char *Jt_user=NULL;
	char *PartNm=NULL;
	char *Mature_PartNm1=NULL;
	char *item_revision_id=NULL;
	char *Revision_sequence=NULL;
	char *Mature_Revision_sequence1=NULL;
	char *ObjectClassType=NULL;
	char *ObjectClassType1=NULL;
	char *current_id=NULL;
	int Jt_count =0;
	char *TaskName=NULL;
	char *analyst=NULL;
	char *objtypetask=NULL;
	char *Design_object=NULL;
	char *FldrName=NULL;
	char *TaskRev=NULL;
	char *Creation_Date=NULL;
	char *Mature_Creation_Date1=NULL;
	char *Released_Date=NULL;
	char *t5_BOMCmpl=NULL;
	char *t5_RolledupWt=NULL;
	char *t5_TargetWt=NULL;
	char *weight=NULL;
	char *targetweight=NULL;
	char *partdrstatus=NULL;
	char *designgrp=NULL;
	char *drstatus=NULL;
	char *managerapproval=NULL;
	char *Mature_Released_Date1=NULL;
	char *CADCretnDt=NULL;
	char *JTCretnDt=NULL;
	char *id=NULL;
	char *rev_id=NULL;
	char *creation_dte=NULL;
	char *business_unit=NULL;
	char *reason=NULL;
	char *Reason=NULL;
	char *wbs=NULL;
	char *prjcode=NULL;
	char *rls_type=NULL;	
	char *dataSetName 		= NULL;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	IMF_file_t	fileDescriptor;
	tag_t  	relation_type = NULLTAG;
	tag_t  	relation    = NULLTAG;
	dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	int DML_count=0;
	int DML_References_count=0;
	int DML_References_Attchment_count=0;
	int x=0;
	int z=0;
	int z1=0;
	int y=0;
	int s=0;
	int j=0;
	int cnt=0;
	int count_tags=0;
	int count_tags1=0;
	int count_tags2=0;
	int Change_reference_count=0;
	time_t t = time(NULL);
	tag_t msExcelType=NULLTAG;
	time(&t);
	struct tm* timeinfo;
	timeinfo = localtime(&t);
	struct tm tm = *localtime(&t);
	strftime(buffer,80,"%Y-%m-%d-%H:%M:%S",timeinfo);
	char *RevSeq =NULL;
	char *Mature_RevSeq1 =NULL;
	char *JTCretnDt1=NULL;
	int FlderSize=0;
	int FlderObjCount=0;
	tag_t *FolderObj_tag = NULLTAG;
	tag_t FolderObj_tag1 = NULLTAG;
	tag_t ExcelDataset=NULLTAG;
	time(&t);
	char *Timestamp = NULL;
	Timestamp = (char *) MEM_alloc (sizeof (char) * 128);
	char str1[100];
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	char str6[100];
	sprintf(str1, "%d", tm.tm_mday);
	sprintf(str2, "%d", tm.tm_mon + 1);
	sprintf(str3, "%d", tm.tm_year + 1900);
	sprintf(str4, "%d", tm.tm_hour);
	sprintf(str5, "%d", tm.tm_min);
	sprintf(str6, "%d", tm.tm_sec);

	tc_strcpy(Timestamp, str1);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str2);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str3);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str4);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str5);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str6);

	printf("\n\t Success String Timestamp: [%s] ",Timestamp);fflush(stdout);
	char *VehicleFile = NULL;
	

	VehicleFile = (char *) MEM_alloc (sizeof (char) * 10000);
	
	
	//tc_strcpy(VehicleFile,"/plmpv16/reports/");
	tc_strcpy(VehicleFile,"/tmp/");
	//tc_strcpy(VehicleFile,"/user/cvprod/PO_TCUA/ANUP/EXE/dmlinfo/Excelfile/");
	tc_strcat(VehicleFile,dmlNoS);
	tc_strcat(VehicleFile,"_");
	tc_strcat(VehicleFile,Timestamp);
	tc_strcat(VehicleFile,"_");
	tc_strcat(VehicleFile,"_DMLifo.csv");

	printf("\n VehicleFile: %s\n", VehicleFile);fflush(stdout);

	

	fpDml = fopen(VehicleFile,"w");

	if (fpDml==NULL)
	{
		printf("\n fpDml is not opened hence skipping \n\n"); fflush(stdout);
		return -1;
	}
	else
	{
		printf("\n In DML_input  dmlNoS: %s \n",dmlNoS); fflush(stdout);

		fprintf(fpDml,"DMLNo, Revision ,Creation_Date ,Business Unit ,Dml Reason ,ERC Wbs Des ,Project Code ,Release Type ,DR Status, Change Review Board \n");fflush(fpDml);

		//**********************************Header*********************************************************************

		ITK_CALL(ITEM_find_item(dmlNoS,  &item));
		ITK_CALL(ITEM_ask_latest_rev(item,  &rev));

		ITK_CALL(AOM_ask_value_string(rev,"item_id",&id)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_ask_value_string(rev,"item_revision_id",&rev_id)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_UIF_ask_value(rev,"creation_date",&creation_dte)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_ask_value_string(rev,"t5_ERCBusiUt",&business_unit)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_UIF_ask_value(rev,"t5_reason",&reason)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_ask_value_string(rev,"t5_ERCWBS",&wbs)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_ask_value_string(rev,"t5_cprojectcode",&prjcode)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_UIF_ask_value(rev,"t5_rlstype",&rls_type)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_ask_value_string(rev,"t5_cDRstatus",&drstatus)!=ITK_ok)PrintErrorStack();
		ITK_CALL(AOM_UIF_ask_value(rev,"ChangeReviewBoard",&managerapproval)!=ITK_ok)PrintErrorStack();

		ITK_CALL(STRNG_replace_str(reason,","," ",&Reason));
		printf(" Reason=%s ", Reason);fflush(stdout);
		
		printf ("item_id: %s\n item_revision_id: %s\n creation_date: %s\n Business Unit: %s\n Reason: %s\n WBS: %s\n Project Code: %s\n Release Type %s\n DR Status : %s\n Change Review Board : %s\n \n", id, rev_id, creation_dte, business_unit, reason, wbs, prjcode, rls_type, drstatus, managerapproval);
		
		fprintf(fpDml,"`%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n\n\n",id,rev_id,creation_dte,business_unit,Reason,wbs,prjcode,rls_type,drstatus,managerapproval); fflush(fpDml);//9
		
		fprintf(fpDml,"PartNo,Revision,BOM Completeness,Rolled up weight,Target Weight, DR status, Design Group, Project Code, object_type,Analyst \n");fflush(fpDml);
		
		ITK_CALL(AOM_ask_value_tags(rev,"T5_DMLTaskRelation", &count_tags, &task)); //got task
		
		ITK_CALL(AOM_UIF_ask_value(rev, "object_type",&objtypetask)!=ITK_ok)PrintErrorStack();

		printf("\n\t GetTaskFromDML count_tags : %d ",count_tags);

		for (x = 0;x< count_tags ;x++ )
		{
			PartRevTag1=task[x];

			ITK_CALL(AOM_ask_value_string(PartRevTag1, "item_id",&TaskName)!=ITK_ok)PrintErrorStack();
			ITK_CALL(AOM_ask_value_string(PartRevTag1, "item_revision_id",&TaskRev)!=ITK_ok)PrintErrorStack();
			printf("\n\t task: [%s] [%s] ",TaskName,TaskRev); fflush(stdout);
			if((tc_strcmp(rls_type,"Vehicle Release")==0) && (tc_strstr(TaskName,"_00")==NULL))
			{
				printf("\t  --Skipping for veh DML...TaskName:%s.",TaskName); fflush(stdout);
				continue;
			}
			else if ((tc_strstr(TaskName,"_CL")!=NULL) || (tc_strstr(TaskName,"_APL")!=NULL) || (tc_strstr(TaskName,"_0E")!=NULL) || (tc_strstr(TaskName,"_MBOM")!=NULL))
			{
				printf("\t  --Skipping...."); fflush(stdout);
				continue;
			}

			ITK_CALL(AOM_UIF_ask_value(PartRevTag1, "Analyst",&analyst)!=ITK_ok)PrintErrorStack();



			ITK_CALL(AOM_ask_value_tags(task[x],"CMReferences", &count_tags1, &task_Rel)); 
			if(count_tags1 == 0)
			{
		
				if(GRM_find_relation_type("CMHasSolutionItem" , &CMSolutions )!=ITK_ok)PrintErrorStack();   // change ref TODR
				if(GRM_list_secondary_objects_only(task[x], CMSolutions, &count_tags1, &task_Rel)!=ITK_ok)PrintErrorStack();

			}

			printf("\n\t GetTaskFromDML count_tags1 : %d ",count_tags1);


			if (count_tags1>0)
			{
				if(task_Rel != NULL)
				{
					PartsForGMFlTag=NULLTAG;

					for (j = 0;j < count_tags1 ;j++ )
					{
						PartRevTag=task_Rel[j];
						
						ITK_CALL(AOM_ask_value_string(PartRevTag,"object_type",&Design_object));  // part/module info
						printf("\n --1-t5_object_type : [%s] ",Design_object);fflush(stdout);

						if(AOM_ask_value_string(PartRevTag,"object_name",&FldrName)!=ITK_ok)PrintErrorStack();

						printf("\n FldrName:: %s\n", FldrName);fflush(stdout);
						
						if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
						{
							PartsForGMFlTag=task_Rel[j];

							continue;
						}
						else
						{
							printf("\n Folder is not found DML is Module release::\n");fflush(stdout);

						}

						if(AOM_ask_value_string(PartRevTag,"item_id",&PartNm)!=ITK_ok)PrintErrorStack();

						printf("\n PartNm=%s ", PartNm);fflush(stdout);

						if(AOM_ask_value_string(PartRevTag,"item_revision_id",&RevSeq)!=ITK_ok)PrintErrorStack(); // semicolon replaced to comma
						printf(" RevSeq=%s ", RevSeq);fflush(stdout);
						

						if(AOM_UIF_ask_value(PartRevTag,"t5_BOMCmpl",&t5_BOMCmpl)!=ITK_ok)PrintErrorStack();  // pART   NOT required   
						printf(" t5_BOMCmpl=%s ", t5_BOMCmpl);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"t5_RolledupWt",&weight)!=ITK_ok)PrintErrorStack();
						printf("\n t5_RolledupWt=%s\t", weight);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"t5_TargetWt",&targetweight)!=ITK_ok)PrintErrorStack();
						printf("\n targetweight=%s\t", targetweight);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"t5_PartStatus",&partdrstatus)!=ITK_ok)PrintErrorStack();
						printf("\n t5_PartDRStatus=%s\t", partdrstatus);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"t5_DesignGrp",&designgrp)!=ITK_ok)PrintErrorStack();
						printf("\n designgrp=%s\t", designgrp);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"object_type",&object_type)!=ITK_ok)PrintErrorStack();
						printf("\n object_type=%s\t", object_type);fflush(stdout);

						if(AOM_UIF_ask_value(PartRevTag,"t5_ProjectCode",&t5_ProjectCode)!=ITK_ok)PrintErrorStack();
						printf("\n Project Code=%s\t", t5_ProjectCode);fflush(stdout);
						printf("\n 11");fflush(stdout);
					
						if (PartNm!=NULL)
						{
							

							fprintf(fpDml,"`%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",PartNm,RevSeq,t5_BOMCmpl,weight,targetweight,partdrstatus,designgrp,t5_ProjectCode,object_type,analyst); fflush(fpDml);
							
						}
					}

					if (PartsForGMFlTag != NULLTAG)
					{
						printf("\n Parts For Gate Maturation folder got \n" );fflush(stdout);
						if(FL_ask_size(PartsForGMFlTag,&FlderSize)!=ITK_ok)PrintErrorStack();
						printf("\n FlderSize is:   %d \n",FlderSize);fflush(stdout);
						if(FL_ask_references(PartsForGMFlTag,FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag)!=ITK_ok)PrintErrorStack();
						printf("\n for FlderObjCount is..:   %d \n",FlderObjCount);fflush(stdout);

						
						if(FlderObjCount>0)
						{
							
							for (y = 0;y< FlderObjCount ;y++ )
							{
								
								task12 = FolderObj_tag[y];

								if(AOM_ask_value_string(task12,"item_id",&PartNm)!=ITK_ok)PrintErrorStack();
								printf("\n B.PartNm=%s ", PartNm);fflush(stdout);

								if(AOM_ask_value_string(task12,"item_revision_id",&RevSeq)!=ITK_ok)PrintErrorStack(); // semicolon replaced to comma
								printf(" RevSeq=%s ",RevSeq );fflush(stdout);
							
								if(AOM_UIF_ask_value(task12,"t5_BOMCmpl",&t5_BOMCmpl)!=ITK_ok)PrintErrorStack();  // pART   NOT required 
								printf(" t5_BOMCmpl=%s ", t5_BOMCmpl);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"t5_RolledupWt",&t5_RolledupWt)!=ITK_ok)PrintErrorStack();
								printf(" Rolled up weight=%s \n", t5_RolledupWt);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"t5_TargetWt",&t5_TargetWt)!=ITK_ok)PrintErrorStack();
								printf(" Target weight=%s \n", t5_TargetWt);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"t5_PartStatus",&partdrstatus)!=ITK_ok)PrintErrorStack();
								printf("\n t5_PartDRStatus=%s\t", partdrstatus);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"t5_DesignGrp",&designgrp)!=ITK_ok)PrintErrorStack();
								printf("\n designgrp=%s\t", designgrp);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"object_type",&object_type)!=ITK_ok)PrintErrorStack();
								printf("\n object_type=%s\t", object_type);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"t5_ProjectCode",&t5_ProjectCode)!=ITK_ok)PrintErrorStack();
								printf("\n Project Code=%s\t", t5_ProjectCode);fflush(stdout);

								if(AOM_UIF_ask_value(task12,"Analyst",&anlyst)!=ITK_ok)PrintErrorStack();
								printf("\n Analyst=%s\t", anlyst);fflush(stdout);

								if (PartNm!=NULL)
								{
									fprintf(fpDml,"`%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",PartNm,RevSeq,t5_BOMCmpl,t5_RolledupWt,t5_TargetWt,partdrstatus,designgrp,t5_ProjectCode,object_type,analyst); fflush(fpDml);
								}
							
							}
						}
						
					}
					else
					{
						printf("\n  Gate maturation folder not found DML is not gate maturation\t");fflush(stdout);
					}


				}
			}
		  
		}
	}
	if (fpDml)
	{
		fclose(fpDml);
	}


				tag_t aNewDataset = NULLTAG;
				tag_t PdfLatestDat_t = NULLTAG;
				char *reference_nameDS = NULL;
				char *ExcelFleNameCpy = NULL;
				tag_t file_tag = NULLTAG;
				IMF_file_t file_descriptor;
				AE_reference_type_t tagRefTypeText = 1;
				tag_t Relatn_type1;
				char *DsetID = NULL;
				int ref_count = 0;
				char **ref_list;

				reference_nameDS = (char *) MEM_alloc(10);

				ITK_CALL(AE_find_datasettype2("MSExcel", &datasettype));
				
				tc_strcpy(reference_nameDS,"MSExcel");//excel

				DsetID = NULL;
				DsetID=(char *) MEM_alloc(100);
				
				//NEW
				tc_strcpy(DsetID,"DMLInfo");
			
				tc_strcat(DsetID,"_");

				tc_strcat(DsetID,Timestamp);
				tc_strcat(DsetID,".csv");

				//NEW

				ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"Dataset Creation Tool",DsetID,"",&aNewDataset));
			    ITK_CALL(AE_save_myself(aNewDataset));

				ITK_CALL(GRM_find_relation_type("IMAN_reference",&Relatn_type1));
				ITK_CALL(GRM_create_relation(rev,aNewDataset,Relatn_type1,NULLTAG,&relation));
				printf("\n\t after creating relation between dataset and Revision \n"); fflush(stdout);
				ITK_CALL(AOM_load(relation));
				ITK_CALL(GRM_save_relation(relation));
				ITK_CALL(AOM_refresh(aNewDataset, TRUE));
				ITK_CALL(AE_ask_dataset_latest_rev(aNewDataset,&PdfLatestDat_t));
				ITK_CALL(AOM_refresh(PdfLatestDat_t,TRUE));
				ITK_CALL(AE_import_named_ref(PdfLatestDat_t,"excel",VehicleFile,NULL,SS_BINARY));
				AOM_save_without_extensions(PdfLatestDat_t);
				AOM_refresh(PdfLatestDat_t, FALSE);
				AOM_unload(PdfLatestDat_t);
				ITK_CALL(AE_save_myself(PdfLatestDat_t));
				printf("\n Completed.... Dataset logic\n");fflush(stdout);

	
	return ifail;
		
}

			

