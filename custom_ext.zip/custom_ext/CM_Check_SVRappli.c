/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Bhaskar Dimble
*  Module               :   Workflow Rule Handler to check if SVR applicability on platform for multiple module and no module BOM solve condition
*  Code                 :   CM_Check_SVRappli.c
*  Created on			:   Jan 8th, 2019
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		CM_Check_SVRappli
	Description			:		This handler checks the SVR applicability on platform for different BOM Solve condition
*/

EPM_decision_t CM_Check_SVRappli(EPM_rule_message_t msg)
{
	int i=0,j=0,k=0,status=ITK_ok;
	int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	int    n_bom_views=0;
	int    bom_view_index=0;
	int    noAttachment=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *dmlProjID=NULL;
	char *DMLDRstatus=NULL;
	char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;

    tag_t  rev=NULLTAG;
    tag_t  rev1=NULLTAG;
	tag_t  view_type= NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ItemObj = NULLTAG;
	tag_t  DcrItemObj=NULLTAG;
	tag_t  ctrlObjQry=NULLTAG;
	tag_t  implemRelationType_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  *qryResults=NULLTAG;
	tag_t  *DcrList=NULLTAG;
	tag_t  *taskList=NULLTAG;
	tag_t  *ItemsList=NULLTAG;
	tag_t  *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	tag_t  item=NULLTAG;
	tag_t  bom_view= NULLTAG;
	char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId                 = NULL;
	char        *SVRType                  = NULL;
	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   Childobject3=NULLTAG;
	tag_t   Childobject4=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	tag_t			dataset									= NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   *bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     errorflag4=0;
	int     errorflag1=0;
	int     errorflag2=0;
	int     errorflag34=0;
	int BOmvarcnt1=0;
	tag_t  *options=NULL;
	char   *v2_text=NULL;
	//tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;

	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	int     n_lines2=0;
	int     n_lines3=0;
	int     n_lines4=0;
	int rulefound= 0;
	int     p2=0;
	int     ss=0;
	int     p36=0;
	char **rulename = NULL;
    char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	 tag_t  *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	int     p4=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	tag_t   *status_list          = NULLTAG;
	tag_t			relation_type							= NULLTAG;
	tag_t			relation_type1							= NULLTAG;
	char*			relation_name=NULL;
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_id156=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *ChildSVRname=NULL;
	tag_t *closurerule = NULL;
	char *child_bl_formula=NULL;
	tag_t  	objTypeTag=NULLTAG;
	char **child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		char   *TempVal			=NULL;
		tag_t close_tag;
	char *objectname=NULL;
	logical modB=FALSE;
	char *rel_status1 = NULL;
	int status_count = 0;
	int structcount=0;
	char*   type_name2=NULL;
	char*   type_name=NULL;
	char*   type_name1=NULL;
	char *tempmat=NULL;
	char MulModule[19000] = { 0 };
	char MulChild[19000] = { 0 };
	char NoSubSet[19000] = { 0 };
	char RevMisMatch[19000] = { 0 };
	int p34=0;
	int p3=0;
	int strcnt1;
	//char *MulModule= NULL;
	char Fresh[19000];
	char NoModule[19000];
	//char RevMisMatch[19000];
    struct modstruct
 {  
	   //part details

		char parent_part[100];
		int child;

 } childstr[10000];

	printf("\n CM_Check_SVRappli Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Check_SVRappli Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));
			
			
					if(DcrProblmItemsRelType != NULLTAG)
					{
						ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));
						
						for(i=0;i<Dcrcnt;i++)
						{
						  printf("\n to find impacted items\n");fflush(stdout);
						  rev1 = DcrList[i]; 
							  if(AOM_ask_value_string(rev1,"object_type",&objecttype));
							  if(AOM_ask_value_string(rev1,"object_name",&objectname));
							  printf("Object Type in loop = %s\n",objecttype);fflush(stdout);
							  if (tc_strcmp(objecttype,"VariantRule")==0)
							{
								  tc_strcpy(TempVal,objectname);
								  primary1=rev1;

							}
						}


						for(j=0;j<Dcrcnt;j++)
							{
							  printf("\n to find impacted items\n");fflush(stdout);
							  rev = DcrList[j]; 
								  if(AOM_ask_value_string(rev,"object_type",&objecttype));
								  if(AOM_ask_value_string(rev,"object_name",&objectname));
			 
	
		  //if(AOM_ask_value_string(rev,"object_type",&objecttype));
		



				if (strcmp(objecttype,"T5_PlatformRevision")==0)
				{
					printf( "\n INside platform\n"); fflush(stdout);

							if ( rev !=NULLTAG )
							{
								if ( PS_find_view_type( "view", &view_type ));
								printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

								if ( view_type != NULLTAG )
								{
									if ( ITEM_ask_item_of_rev( rev, &item ));
									if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

									bom_view = bom_views[0];
								}
								else
								printf("\nView not found check.......\n"); fflush(stdout);
							}

							 if ( bom_view != NULLTAG )
						{
					printf(" before BOM_create_window..\n");	fflush(stdout);	
					if ( BOM_create_window( &bom_window ));
					//if(CFM_find( "ERC release and above", &rule ))
					if(CFM_find( "ERC release and above", &rule ));
					if(BOM_set_window_config_rule( bom_window, rule ));
					
					
					if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
					
					printf ("rule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
									close_tag = closurerule[0];
									printf ("closure rule found \n");fflush(stdout);
								   // MEM_free(tags_found);
					 }
					 if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
					
					if(BOM_set_window_pack_all(bom_window, TRUE));
					if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
					printf( " After BOM_set_window_top_line..\n");fflush(stdout);
					
					//if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
					if ( BOM_window_ask_variant_rules( bom_window,&BOmvarcnt1,&bom_variant_rule ));
					printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);

					//ITK ( ITEM_ask_rev_variants ( rev, &e_block ) )
                    if(BOmvarcnt1>0)
					{
					if(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name));	
					}

                  
			
                    // for super SVR
					
                   if ( top_line!=NULLTAG )
					{
						

						
						 fprintf( stderr, "\n print Master second .\n");
						
									if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
									printf("\n before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
									if(bom_window != NULLTAG)
									{
										printf("\n before inside bom_window-----\n"); fflush(stdout);																	
										if(BOM_window_hide_unconfigured(bom_window))   ;
										if(BOM_window_show_variants(bom_window))   ;


										tc_strcpy(RevMisMatch,"");

													  
												


									
										printf("\n After inside bom_window-----\n"); fflush(stdout);			
										if(BOM_window_apply_variant_configuration(bom_window,1,&primary1))   ;
										printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										if(BOM_window_hide_variants(bom_window))   ;
										if(BOM_window_ask_is_modified(bom_window,&modB))   ;
										if(modB)
										{
											fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
										}
										else
										{
											fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
										}																	

										if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										

										printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

										printf("\n.....mulmodule is start..%s\n",MulModule);fflush(stdout);

										//EMH_clear_errors();

										if (n_lines1 >0)
										{
											//MulModule = (char *)MEM_alloc (1024 * sizeof(char));
											
											for (p3=0;p3<n_lines1 ;p3++ )
											{
												if(Childobject1) Childobject1=NULLTAG;
												Childobject1=lines[p3];
												if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
												//fprintf( stderr, " child_item_id ..:%s\n",child_item_id);

												

												if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

												fprintf( stderr, " child_item_no ..:%d\n",n_lines3);fflush(stdout);
 
                                                  

												  		if (n_lines3 >0)
														{
															for (p34=0;p34<n_lines3 ;p34++ )
															{
															if(Childobject33) Childobject33=NULLTAG;
															Childobject33=lines3[p34];
															if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id156 ));
															//tc_strcat(RevMisMatch,"[");
															tc_strcat(RevMisMatch,child_item_id156);
															//tc_strcat(RevMisMatch,"]");
															tc_strcat(RevMisMatch,",");
															}
														}
											}
										}
												}

												printf("\n.....SuperSVR modules are..%s\n",RevMisMatch);fflush(stdout);
					}


					// for super svr end

                        



				if ( top_line!=NULLTAG )
					{
						

						
						 fprintf( stderr, "\n print Master second .\n");
						
									if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
									printf("\n before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
									if(bom_window != NULLTAG)
									{
										printf("\n before inside bom_window-----\n"); fflush(stdout);																	
										if(BOM_window_hide_unconfigured(bom_window))   ;
										if(BOM_window_show_variants(bom_window))   ;


										if(DmlTaskRelationType_t != NULLTAG)

											ITK_CALL(GRM_list_secondary_objects_only(primary1,DmlTaskRelationType_t,&ItmCnt,&taskList));

											tc_strcpy(MulModule,"");
											tc_strcpy(NoModule,"");
											tc_strcpy(NoSubSet,"");
											tc_strcpy(Fresh,"");
											
						
												for(k=0;k<ItmCnt;k++)
												{
												  printf("\n to find impacted items\n");fflush(stdout);
												  ItemObj = taskList[k]; 

												  tc_strcpy(NoSubSet,"");

												   if(AOM_ask_value_string(ItemObj,"object_name",&ChildSVRname));

												    ITK_CALL(AOM_UIF_ask_value (ItemObj,"release_status_list", &rel_status1));
													 printf("\n release_status_list rel_status11111111 :[%s] \n",rel_status1);   fflush(stdout);
													 if(tc_strcmp(rel_status1,"ERC Released")==0)
													 {
														 printf("\n**************childsvr is released  hence ignoring ******\n");fflush(stdout);
													 }
													 else
													{

												    tc_strcat(MulModule,"SVR Name : ");
													tc_strcat(MulModule,ChildSVRname);
													tc_strcat(MulModule," :: Architecture Node :: ");

													 tc_strcat(NoModule,"SVR Name : ");
													tc_strcat(NoModule,ChildSVRname);
													tc_strcat(NoModule," :: Architecture Node :: ");

											    	//if (WSOM_ask_release_status_list(ItemObj,&status_count,&status_list));

													// if (status_count > 0)  /* No Status, so the Item is not yet Released */
													//	{
														//		for(ss=0; ss<status_count ; ss++)
															//	{
																	//	if(AOM_ask_value_string(status_list[0],"object_name",&CurrentRelStatus));
																	//	printf("\n CurrentRelStatus: %s",CurrentRelStatus);fflush(stdout);
																	//	if(tc_strcmp(CurrentRelStatus,"T5_LcsErcRlzd")==0) 
																	//	{
																	//		printf("\n Skipping for ERC Released----\n"); fflush(stdout);
																	//	}
																	//	else
																//	{

													  
												


									
										printf("\n After inside bom_window-----\n"); fflush(stdout);			
										if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										if(BOM_window_hide_variants(bom_window))   ;
										if(BOM_window_ask_is_modified(bom_window,&modB))   ;
										if(modB)
										{
											fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
										}
										else
										{
											fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
										}																	

										if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										

										printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

										printf("\n.....mulmodule is start..%s\n",MulModule);fflush(stdout);
										

										//EMH_clear_errors();

										if (n_lines1 >0)
										{
											//MulModule = (char *)MEM_alloc (1024 * sizeof(char));
											
											for (p3=0;p3<n_lines1 ;p3++ )
											{
												if(Childobject1) Childobject1=NULLTAG;
												Childobject1=lines[p3];
												if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
												//fprintf( stderr, " child_item_id ..:%s\n",child_item_id);

												

												if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

												fprintf( stderr, " child_item_no ..:%d\n",n_lines3);fflush(stdout);
 
                                                  

												  		if (n_lines3 >0)
														{
															for (p34=0;p34<n_lines3 ;p34++ )
															{
															if(Childobject33) Childobject33=NULLTAG;
															Childobject33=lines3[p34];
															if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
															
															if( AOM_ask_displayable_values(Childobject33,"bl_rev_last_release_status",&strcnt1,&child_bl_formula23))PrintErrorStack();
															
															printf("\n.....Childitem ID is ..%s\n",child_item_id15);fflush(stdout);

															if(tc_strstr(RevMisMatch,child_item_id15) == NULL)

																{
																	tc_strcat(NoSubSet,"[");
																	tc_strcat(NoSubSet,child_item_id15);
																	tc_strcat(NoSubSet,"]");
																	tc_strcat(NoSubSet,",");
																	errorflag34=errorflag34+1;

																	printf("\n.....Error Subset Childitem ID is and childsvr name ..%s %s\n",ChildSVRname,child_item_id15);fflush(stdout);
																}

															if((tc_strstr(child_bl_formula23[0],"ERC Released")==NULL) || (tc_strstr(child_bl_formula23[0],"T5_LcsErcRlzd")==NULL) )
																{
																fprintf( stderr, "\n Valid release status \n");

																}
																else
																{
																//EMH_clear_errors();
																EMH_store_error_s3(EMH_severity_error,ITK_err,"These ",child_item_id15," does not have ERC Released status");
																//return ITK_err;
																return EPM_go;
																}

																if (p34>0)
																{


																 if (tc_strcmp(MulChild,child_item_id15)==0)
																 {
																	tc_strcpy(MulChild,"");
																	tc_strcat(MulChild,child_item_id15);
                                                                  continue;
																 }
																 else
																 {
																	 errorflag2=errorflag2+1;
																	 break;
																 }
																}

															tc_strcpy(MulChild,"");
															tc_strcat(MulChild,child_item_id15);

															printf("\n.....i am inside diff child .%s\n",MulChild);fflush(stdout);
                                                             
															
																
															 


															//if ( ITEM_ask_latest_rev( parent_master, &VCrev ));
															//if (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));
															

															
															}
														}


														if (n_lines3 > 1)
														{
															printf("\n.....mulmodule is before..%s\n",MulModule);fflush(stdout);
															printf("\n.....child_item_id1 is before..%s\n",child_item_id1);fflush(stdout);
															tc_strcat(MulModule,"[");
															tc_strcat(MulModule,child_item_id1);
															tc_strcat(MulModule,"]");
															tc_strcat(MulModule,",");
															errorflag=errorflag+1;
															printf("\n.....show error for mul....%d\n",n_lines3);fflush(stdout);
															printf("\n.....mulmodule is after..%s\n",MulModule);fflush(stdout);
															//tc_strcpy(Fresh,MulModule);
															//printf("\n.....Fresh is after..%s\n",Fresh);fflush(stdout);

															
														}	

													if (n_lines3 == 0)
														{
															
															tc_strcat(NoModule,"[");
															tc_strcat(NoModule,child_item_id1);
															tc_strcat(NoModule,"]");
															tc_strcat(NoModule,",");
															errorflag1=errorflag1+1;
															printf("\n.....show error....");fflush(stdout);
															printf("\n.....show error for no mul....%d\n",n_lines3);fflush(stdout);
															
														}	

											}
										
												
															tc_strcat(Fresh,NoSubSet);	
														}
												}
												}
												
														
														
                                              printf("\n..values of flag errorflag and errorfla1 and errorflag2 errorflag34 %d,%d,%d,%d",errorflag,errorflag1,errorflag2,errorflag34);fflush(stdout);

												//ITK ( VOO_show_wso( Childobject ));

												if (errorflag34>0) 
											{
												printf("\n.....show error....");fflush(stdout);
												//EMH_clear_errors();
												//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
												EMH_store_error_s3(EMH_severity_error,ITK_err,"These modules ",Fresh," are not subset of Super SVR modules");
												//return ITK_err;
												return EPM_nogo;
												//return ITK_Prjerr;
											}
											
											if ((errorflag>0) && (errorflag1>0) )
											{
												printf("\n.....child_item_id1 show error....length :%d and value : %s",tc_strlen(child_item_id1),child_item_id1);fflush(stdout);
												printf("\n.....show error....length :%d and value : %s",tc_strlen(MulModule),MulModule);fflush(stdout);
												MulModule[1899] = '\0';
												//printf("\n.....show error....length :%d and value fresh : %s",tc_strlen(Fresh),Fresh);fflush(stdout);
                                                //EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_err,"More than One module is present under ",MulModule," please correct the SVR");
												EMH_store_error_s3(EMH_severity_error,ITK_err,"No module is present under ",NoModule," please verify the SVR");

												//return ITK_err;
												return EPM_nogo;

												
												
												
												//return ITK_errErr;
											}
											if ((errorflag>0) && (errorflag1==0))
											{
												printf("\n.....show error....");fflush(stdout);
												//EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_err,"More than One module is present under ",MulModule," please correct the SVR");
												//EMH_store_error_s3(EMH_severity_error,ITK_errErr,"No module is present under ",NoModule," please verify the SVR");
												//return ITK_errErr;
												//return ITK_err;
												return EPM_nogo;
											}
											if ((errorflag==0) && (errorflag1>0))
											{
												printf("\n.....show error....");fflush(stdout);
												//EMH_clear_errors();
												//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
												EMH_store_error_s3(EMH_severity_information,ITK_err,"No module is present under **",NoModule," please verify the SVR");
												//return ITK_err;
												return EPM_go;
												//return ITK_Prjerr;
											}
											
											
											
									}
									
									
									else
									{
										fprintf( stderr, "\n no bom window found here \n");
									}

									//break;					
							}
								}
				}
		}
		
					}
		}
	
		  //if(AOM_ask_value_string(rev,"object_type",&objecttype));
		}
	printf("\n CM_Check_SVRappli Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Check_SVRappli Function end...");
	return EPM_go;
}