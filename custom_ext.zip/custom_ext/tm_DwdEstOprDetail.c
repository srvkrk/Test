/*******************
*  File            :   tm_DwdEstOprDetail.c
*  Created By      :   Vijay Khandare
*  Created On      :   15-02-2024
*  Purpose         :   Download Estimate Operations details
*  TZ			   :   
*******************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;			

void EstOprDstrcat(char **src,char* dest)
{
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* replace(char *str, const char *find, const char *replace) 
{
    // Allocate memory for the new string
    char *result;
    int i, count = 0;
    int find_len = strlen(find);
    int replace_len = strlen(replace);

    // Count the number of times the 'find' substring occurs in the original string
    for (i = 0; str[i] != '\0'; i++) 
	{
        if (strstr(&str[i], find) == &str[i])
		{
            count++;
           // Jump index to the next occurrence of the 'find' substring
            i += find_len - 1;
        }
    }
    // Allocate memory for the new string
    result = (char *)MEM_alloc(i + count * (replace_len - find_len) + 1);  
    i = 0;
    while (*str)
	{
        // Compare the substring with the result
        if (strstr(str, find) == str) 
		{
            strcpy(&result[i], replace);
            i += replace_len;
            str += find_len;
        } 
		else 
	    {
            result[i++] = *str++;
        }
    }
    result[i] = '\0';
    //printf("Replaced string: %s\n", result);
    return result;
}
;
int tm_DwdEstOprFn(char *EstimateShNo,char **output)
{
	
    int      noofEst            = 0;
    tag_t   *ESTSheetSet        = NULLTAG;
    tag_t    EstQrtag           = NULLTAG;
    int      SrNo               = 0;

    EstOprDstrcat(output,"======,==============,======================,===========,=================,============,=====,=====,====,========,=========,=========,=========,====,=========,=============,=====,======,==============,=======,=====,========,==============,======,====,=======\n");
    EstOprDstrcat(output," SR NO, Operation No, Operation Description, Work Center, Work Center Desc, Cost Driver, UOM,Value, Qty, APL time, APL gang, PSD time, PSD gang, CPC, Model, Type of process, MMA, T code, APL M/C Desc, Alt Rt, Freq, Lab Time, Process Sheet, PFMEA, CP, BC Num\n");
	EstOprDstrcat(output,"======,==============,======================,===========,=================,============,=====,=====,====,========,=========,=========,=========,====,=========,=============,=====,======,==============,=======,=====,========,==============,======,====,=======\n");

    ITK_CALL(QRY_find2("Item Revision...", &EstQrtag));//API changed for 12.2 to 14.3 upgrade...
	if(EstQrtag != NULLTAG)
	{
		printf("General query found\n");fflush(stdout);
	} 
	else
		printf("General Query not found\n");fflush(stdout);

    char *attribute[2] = {"Item ID","Type"};
    char *values[2]; 
    values[0] = EstimateShNo;
    values[1] = "Estimate Sheet Revision";
    
    //ITK_CALL(ITEM_find_items_by_key_attributes(1,attribute,values,&noofEst,&ESTSheetSet));

    printf("tm_DwdEstOprFn ... Input Estimate sheet number is = %s\n",EstimateShNo);fflush(stdout);

    ITK_CALL(QRY_execute(EstQrtag,2,attribute,values,&noofEst,&ESTSheetSet));

    if(noofEst > 0)
    {
        printf("Estimate sheet found.....\n");fflush(stdout);
        tag_t     EstimateObj    = NULLTAG;
        tag_t     EstOperRel     = NULLTAG;
        int       NoofOper       = 0;
        tag_t     *EstOperSet    = NULLTAG;
        char      *EstObjName    = NULL;
        char       *EstRevId     = NULL;
        char       *EsRlzState   = NULL;
        EstimateObj = ESTSheetSet[0];
        ITK_CALL(AOM_ask_value_string(EstimateObj,"item_id",&EstObjName));
        printf("Estimate sheet Number = %s\n",EstObjName);fflush(stdout);

        ITK_CALL(AOM_ask_value_string(EstimateObj,"item_revision_id",&EstRevId));
        printf("Estimate revision id is = %s\n",EstRevId);fflush(stdout);

        ITK_CALL(AOM_UIF_ask_value(EstimateObj,"release_status_list",&EsRlzState));
        printf("Estimate sheet release state = %s\n",EsRlzState);fflush(stdout);

        ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&EstOperRel));
        ITK_CALL(GRM_list_secondary_objects_only(EstimateObj,EstOperRel,&NoofOper,&EstOperSet));

        if(NoofOper > 0)
        {
            printf("Estimate sheet Operation found.....\n");fflush(stdout);
            int EstOprItr = 0;
	        for(EstOprItr = 0 ; EstOprItr < NoofOper ; EstOprItr++)
	        {
                SrNo++;
                tag_t      EstOperObj          = NULLTAG;
                char       *OprNum            = NULL;
                char       *OprDesc           = NULL;
                char       *BCNum             = NULL;
                char       *WorkCenter        = NULL;
                char       *WorkCntDesc       = NULL;
                char       *CostDriver        = NULL;
                char       *UOM               = NULL;
                char       *Value             = NULL;
                char       *Model             = NULL;
                char       *ProsType          = NULL;
                char       *QTY               = NULL;
                char       *APLTime           = NULL;
                char       *PSDTime           = NULL;
                char       *MMA               = NULL;
                char       *APLGang           = NULL;
                char       *PSDGang           = NULL;
                char       *TCode             = NULL;
                char       *CPC               = NULL;
                char       *APLMCDesc         = NULL;
                char       *ALTRt             = NULL;
                char       *Freq              = NULL;
                char       *LabTime           = NULL;
                char       *ProSheet          = NULL;
                char       *PFMEA             = NULL;
                char       *CPStatus          = NULL;
                char       *OprDescV          = NULL;
                char       *WorkCntDescV      = NULL;
                char       *SerialNo          = (char*) MEM_alloc(50*sizeof(char*));

                tc_strcpy(SerialNo,"");

                sprintf(SerialNo,"%d",SrNo);

                EstOperObj = EstOperSet[EstOprItr];

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEOpnNumber",&OprNum));
                //printf("Estimate sheet Operation Number = %s\n",OprNum);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEOpnDesc",&OprDesc));
                //printf("Estimate sheet Operation Description = %s\n",OprDesc);fflush(stdout);

                OprDescV = replace(OprDesc, ",", " ");

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEBCNo",&BCNum));
                //printf("Estimate sheet Operation BC No = %s\n",BCNum);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHPEBCNo",&WorkCenter));
                //printf("Estimate sheet Operation WorkCenter = %s\n",WorkCenter);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHBCDesc",&WorkCntDesc));
                //printf("Estimate sheet Operation Work Center Desc = %s\n",WorkCntDesc);fflush(stdout);

                WorkCntDescV = replace(WorkCntDesc, ",", " ");

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHCostDriver",&CostDriver));
                //printf("Estimate sheet Operation Cost Driver = %s\n",CostDriver);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHUom",&UOM));
                //printf("Estimate sheet Operation UOM = %s\n",UOM);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHValue",&Value));
                //printf("Estimate sheet Operation Value = %s\n",Value);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_Model",&Model));
                //printf("Estimate sheet Operation Model = %s\n",Model);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_ProcType",&ProsType));
                //printf("Estimate sheet Operation Process Type = %s\n",ProsType);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_EPOCHQty",&QTY));
                //printf("Estimate sheet Operation QTY = %s\n",QTY);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PETimeOpnApl",&APLTime));
                //printf("Estimate sheet Operation APL Time = %s\n",APLTime);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PETimeOpnPsd",&PSDTime));
                //printf("Estimate sheet Operation PSD Time = %s\n",PSDTime);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEMMAInd",&MMA));
                //printf("Estimate sheet Operation MMA = %s\n",MMA);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEAplGangSize",&APLGang));
                //printf("Estimate sheet Operation APL Gang = %s\n",APLGang);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEGangSize",&PSDGang));
                //printf("Estimate sheet Operation PSD Gang = %s\n",PSDGang);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PETradeCode",&TCode));
                //printf("Estimate sheet Operation Trade code = %s\n",TCode);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEPartPerCycle",&CPC));
                //printf("Estimate sheet Operation part per cycle(cpc) = %s\n",CPC);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_APLMCDesc",&APLMCDesc));
                //printf("Estimate sheet Operation APL MC Desc = %s\n",APLMCDesc);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEAltRoute",&ALTRt));
                //printf("Estimate sheet Operation ALT Rt = %s\n",ALTRt);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEFrequency",&Freq));
                //printf("Estimate sheet Operation Freqency = %s\n",Freq);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEInternalLabTime",&LabTime));
                //printf("Estimate sheet Operation Lab Time = %s\n",LabTime);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEProsheet",&ProSheet));
                //printf("Estimate sheet Operation Process Sheet = %s\n",ProSheet);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PfmeaStatus",&PFMEA));
                //printf("Estimate sheet Operation PFMEA = %s\n",PFMEA);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_CpStatus",&CPStatus));
                //printf("Estimate sheet Operation CP Status = %s\n",CPStatus);fflush(stdout);

                EstOprDstrcat(output,SerialNo);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,OprNum);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,OprDescV);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,WorkCenter);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,WorkCntDescV);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,CostDriver);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,UOM);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,Value);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,QTY);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,APLTime);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,APLGang);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,PSDTime);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,PSDGang);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,CPC);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,Model);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,ProsType);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,MMA);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,TCode);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,APLMCDesc);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,ALTRt);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,Freq);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,LabTime);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,ProSheet);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,PFMEA);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,CPStatus);
                EstOprDstrcat(output,",");
                EstOprDstrcat(output,BCNum);
                EstOprDstrcat(output,"\n");                     
            }
        }
    }
    else
    {
        printf("Estimate sheet not found......\n");fflush(stdout);
    }

    EstOprDstrcat(output,"\n");  
    EstOprDstrcat(output,"=======");
    EstOprDstrcat(output,",");   
    EstOprDstrcat(output,"==========="); 
    EstOprDstrcat(output,",");   
    EstOprDstrcat(output,"END OF REPORT.............!");  

    return ITK_ok;
}

int DwdEstOpr(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *InputEstNo         = NULL;
    char     *output			 = NULL;
			
	output = (char *) MEM_alloc( 90000000 * sizeof(char*) );

	printf("\n inside the function DwdEstOpr .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&InputEstNo);

	printf("\n Input Estimate number :: %s ",InputEstNo);fflush(stdout);

	//..........................................................
		
	
	tc_strcpy(output,"");

	tm_DwdEstOprFn(InputEstNo,&output);

	printf("\n before return data....!\n");fflush(stdout);

	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(output);

	printf("\n After free...!\n");fflush(stdout);
    return ifail;
}

extern int AllUserServiceFnDwdEstOprFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 1;
    int retValueType;
    int inputArgTypes[1] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //Estimate sheet Number 
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("DwdEstOpr",(USER_function_t)DwdEstOpr,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_DwdEstOprDetail_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_DwdEstOprDetail", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnDwdEstOprFn);
    return ifail;
}
