/******************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   tm_Rule_Veh_taskSignOffRule: Platform based modular BOM validation for vehicle.
*  Code                 :   tm_Rule_Veh_taskSignOffRule.c
*  Created on			:   10-11-2022
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	10-11-2022					Mohan Tayade		Platform based modular BOM validation for vehicle...
*	2.	09-05-2023					Mohan Tayade		Ensure to signed off other task before 00 task- standalove VC..
*********************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"


int t5GetItemRevisonPSE(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	TC_write_syslog("\n t5GetItemRevison:part1:[%s].", InputPart);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2,&n_tags_found2,&tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2,&n_tags_foundd2,&tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3,&n_tags_foundd3,&tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3,&n_tags_foundd3,&tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
		TC_write_syslog("\n FUN: NULL tag for part no:%s.", InputPart);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
		TC_write_syslog("\n FUN: tag found for part no:%s.", InputPart);
	}
	return OutPutTag;
}

EPM_decision_t tm_Rule_Veh_taskSignOffRule (EPM_rule_message_t msg)
{
	tag_t *Dml_tasksss= NULLTAG;
	tag_t *Dml_taskss= NULLTAG;
	char  *SubSubTaskNm1= NULL;
	char  *SubTaskNm1= NULL;
	char  *PrevECUmoduleNo= NULL;
	int no_attach	=  0;
	int AddSolutionFound	=  0;
	int Tskcntt	=  0;
	int Tskcnttt	=  0;
	int	kkk	=  0;
	int	kk	=  0;
	int	i	=  0;
	int	cr	=  0;
	int	s0ETaskAvailFlag	=  0;
	int	s21TaskAvailFlag	=  0;
	int	s50TaskAvailFlag	=  0;
	int	Prev16TaskFlag	=  0;
	int	PrevZeroTaskFlag	=  0;
	int	PrevFiftyFlag	=  0;
	int	PrevTwentyOneFlag	=  0;
	int	PrevTwentySixFlag	=  0;
	int	PrevThirtyNineFlag	=  0;
	int	PrevThirtyFiveFlag	=  0;
	//int	PrevTwentyOneFlag	=  0;
	tag_t	roottask        =  NULLTAG;
	tag_t	PrevECUMdlTag        =  NULLTAG;
	tag_t	PrevECUMdlTagg        =  NULLTAG;
	tag_t	PrevCCVCrel_type        =  NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *PrevECUMdlTags=NULLTAG;
	char	*SubSubtaskType		=  NULL;
	char	*Tsk_object_typec		=  NULL;
	char	*TaskDsgGrpc		=  NULL;
	char	*TskNmc		=  NULL;
	int	ii	=  0;
	int	VCCRAttached	= 0;
	int	VCAttached	= 0;
	int	VehclAttached	= 0;
	int	VCChildCunt	= 0;
	int	tsk	= 0;
	int	CMRefcount	= 0;
	int	EVskippFlag	= 0;
	int	Tskcnt	= 0;
	int MDLrulefound =0;
	int DR_n_entry    = 1;
	int iChild   =  0;
	int DR_rsltCount   =  0;
	int FiftyFlag      =  0;
	int TwentyOneFlag   =  0;
	int TwentySixFlag   =  0;
	int ThirtyFiveFlag   =  0;
	int ZeroTaskFlag    =  0;
	int ECUMdlFlag     =  0;
	int j =0;
	int tskc =0;
	int countt =0;
	int ThirtyNineFlag    = 0;
	int s16TaskAvailFlag=0;
	int s26TaskAvailFlag=0;
	int s35TaskAvailFlag=0;
	int s39TaskAvailFlag=0;
	int Child_Rev_count=0;
	int PrviChild=0;
	int WIPiChild=0;
	char*	CurrentTask		= NULL;
	char*	WIPPrtDegGrp		= NULL;
	char*	WIPrel_sstats		= NULL;
	char*	WIP_child_item_id		= NULL;
	char*	Prevp_child_item_id		= NULL;
	char*	PrevPrtDegGrp		= NULL;
	char*	Prevrel_sstats		= NULL;
	char*	Child_rev_idd		= NULL;
	char*	relstatPSE		= NULL;
	char	*PlntToPlnt		= NULL;
	char	*TskNm			= NULL;
	char	*rev_idd		= NULL;
	char	*DMLtype		= NULL;
	char	*TaskDsgGrp		= NULL;
	char	*Partno		= NULL;
	char	*PartMstr_no		= NULL;
	char*   ObjTyp= NULL;
	char   *InputTaskDsgGrp=NULL;
	char **MDLrulevalueXO = NULL;
	char **MDLrulenameXO = NULL;
	char **PrevMDLrulenameXO = NULL;
	char **PrevMDLrulevalueXO = NULL;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *Prtrev_idd =NULL;
	char   *DMLDR =NULL;
	char   *p_child_item_id=NULL;
	char   *rel_sstats=NULL;
	char   *rev_iidd=NULL;
	char   *PrtDegGrp=NULL;
	char   *PrtProjj=NULL;
	char   *ECUmoduleNo=NULL;
	int	VehAttached=0;
	int	PrevVCChildCunt=0;
	int	Mstr=0;
	int	TskSignoffFlag=0;
	int	ECUMdlcount=0;
	int	PrevMDLrulefound=0;
	char   *DMLProj =NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*TaskPerfInfo2		=  NULL;
	char	*TaskPerfInfo1		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char	*TaskPerfInfo4		=  NULL;
	char	*TaskPerfInfo3		=  NULL;
	char	*DMLBUnit		=  NULL;
	char	*DmlDR		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t ECUMdlTagg = NULLTAG;
	tag_t ECUMdlTag = NULLTAG;
	tag_t PrevMDLClosureTag = NULLTAG;
	tag_t*	ECUMdlTags	= NULLTAG;
	tag_t*	PrevVCChildobject	= NULLTAG;
	tag_t*	Child_rev_list	= NULL;
	tag_t CCVCrel_type = NULLTAG;
	tag_t *MDLclosureruleee = NULLTAG;
	tag_t *PrevMDLclosureruleee = NULLTAG;
	tag_t	p_window 	= NULLTAG;
	tag_t	Prevp_window 	= NULLTAG;
	tag_t	MDLClosureTag 	= NULLTAG;
	tag_t	MDL_rule 	= NULLTAG;
	tag_t	PrevMDL_rule 	= NULLTAG;
	tag_t	p_top_line 	= NULLTAG;
	tag_t	Prevp_top_line 	= NULLTAG;
	tag_t *VCChildobject=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	DMLTagg 		= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t	Child_All_Rev		= NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	char  *tasknameofroot= NULL;
	int drrtaskcount=0;
	tag_t  	taskjob=NULLTAG;
	tag_t  	taskroottask=NULLTAG;
	tag_t  	task_job_type=NULLTAG;
	tag_t   *subtasks=NULLTAG;
	tag_t   *dmltasks=NULLTAG;
	char *roottask_Objtype = NULL;
	char *status_root_task = NULL;
	char *DMLVert = NULL;
	char *sTask_Result = NULL;
	logical is_latest;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	EPM_decision_t decision = EPM_go;

	printf("\n tm_Rule_Veh_taskSignOffRule Function started...");fflush(stdout);
	TC_write_syslog("\n tm_Rule_Veh_taskSignOffRule Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n PO:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n Veh:P6: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
			//////////////Start adding in handler but ensure initial tag//////////
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Veh:P7:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Veh:P8:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "TSKPERFM";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Veh:P9:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF for CV Veh DML
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&TaskPerfInfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo1:[%s]:",TaskPerfInfo1); fflush(stdout);
				//DML project which skipped for validation.
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&TaskPerfInfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo2:[%s]:",TaskPerfInfo2); fflush(stdout);
				//sign off status which need to check fr task sign off status : Completed
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&TaskPerfInfo3)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo3:[%s]:",TaskPerfInfo3); fflush(stdout);
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&TaskPerfInfo4)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo4:[%s]:",TaskPerfInfo4); fflush(stdout);
				if(tc_strstr(TaskPerfInfo1,"T1") == NULL)
				{
					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
					{
						printf("\n Veh:P12:inside T5_ChangeTaskRevision .....\n");fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						if(InputTaskDsgGrp) InputTaskDsgGrp=NULL;
						InputTaskDsgGrp=subString(sDMLtaskno,11,2);
						printf("\n veh:P13:sDMLtaskno:[%s]  InputTaskDsgGrp:[%s].",sDMLtaskno,InputTaskDsgGrp);fflush(stdout);
						if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
						if (tsk_dml_rel_type!=NULLTAG)
						{
							if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							printf("\n Veh:P14:DML Revision from Task for MR : %d",countt);fflush(stdout);
							for (j=0;j<countt ;j++ )
							{
								if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
								printf("\n Veh:P15: is_latest MR is : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n veh:P16:is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									DMLRevTg = DMLRevision[j];
									if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
									printf("\n Veh:P17:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);

									if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
									if(item_tag==NULLTAG)
									{
										printf("\n Veh:P18:item_tag is NULL.\n");fflush(stdout);
										return decision;
									}
									else
									{
										printf("\n Veh:P19:item_tag found.\n");fflush(stdout);
										if(ITEM_ask_latest_rev (item_tag, &DMLTagg)!=ITK_ok)PrintErrorStack();
										if(DMLTagg==NULLTAG)
										{
											printf("\n Veh:P20:Object not found in Teamcenter...!!\n");fflush(stdout);
											return decision;
										}
										else
										{
											DMLBUnit     =  (char *) MEM_alloc(10 * sizeof(char));
											DMLVert     =  (char *) MEM_alloc(10 * sizeof(char));
											//DML Details:
											if(AOM_ask_value_string(DMLTagg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_ProductLine",&DMLVert)!=ITK_ok)PrintErrorStack();
											printf("\n Veh:P21: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s] DMLBUnit:[%s] DMLVert:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR,DMLBUnit,DMLVert);fflush(stdout);
											if(strcmp(DMLtype,"Veh")==0)
											{
												if(strcmp(DMLBUnit,"")==0)
												{
													//DML BU is NULL.
													printf("\n Veh:P20:ERROR:DML BU is NULL:[%s]\n",sDMLno);fflush(stdout);
													if(tc_strstr(TaskPerfInfo1,"T9") == NULL)
													{
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML business unit is null.\nPlease update it and process. ",sDMLno);
														decision = EPM_nogo;
														return decision;
													}
												}
												else
												{
													if(strcmp(DMLBUnit,"CVBU")==0)
													{
														char *errmsg=NULL;
														errmsg = (char *) MEM_alloc(500 * sizeof(char));
														tc_strcpy(errmsg,"");
														Tskcnt=0;
														if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
														printf("\n EV::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
														EVskippFlag=0;
														if(tc_strlen(DMLVert) == 0)
														{
															//DML BU is NULL.
															printf("\n Veh:P20:ERROR:DML vertical is NULL:[%s]\n",sDMLno);fflush(stdout);
															if(tc_strstr(TaskPerfInfo1,"P1") == NULL)
															{
																EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML Vertical is null.\nPlease update it and process. ",sDMLno);
																decision = EPM_nogo;
																return decision;
															}
														}
														else
														{
															if(tc_strstr(TaskPerfInfo1,"P2") == NULL)
															{
																if(tc_strstr(TaskPerfInfo4,DMLVert) != NULL)
																{
																	EVskippFlag=1;
																	printf("\n Veh:P20:EV DML skipped:[%d]\n",EVskippFlag);fflush(stdout);
																}
																else if(tc_strstr(DMLVert,"EV") != NULL)
																{
																	if(tc_strstr(TaskPerfInfo2,DMLProj) == NULL)
																	{
																		printf("\n EV:Checking for DML:[%s]\n",sDMLno);fflush(stdout);
																		// Get 00 task and then vehicle and expand vehicle to BOM.
																		
																		if (Tskcnt>0)
																		{
																			if(tc_strstr(TaskPerfInfo1,"N1") == NULL)
																			{
																				s16TaskAvailFlag=0;
																				s26TaskAvailFlag=0;
																				s35TaskAvailFlag=0;
																				s39TaskAvailFlag=0;
																				for (tskc=0;tskc<Tskcnt ;tskc++ )
																				{
																					if(AOM_ask_value_string(Dml_tasks[tskc],"object_type",&Tsk_object_typec)!=ITK_ok)PrintErrorStack();
																					printf("\n EV::V:P23:Tsk_object_typec is :%s\n",Tsk_object_typec);fflush(stdout);

																					if(strcmp(Tsk_object_typec,"T5_ChangeTaskRevision")==0)
																					{
																						if(TaskDsgGrpc) TaskDsgGrpc=NULL;
																						if(AOM_UIF_ask_value(Dml_tasks[tskc],"item_id",&TskNmc)!=ITK_ok)PrintErrorStack();
																						TaskDsgGrpc=subString(TskNmc,11,2);
																						printf("\n EV::V:P24: Task: [%s] TaskDsgGrpc:[%s] \n",TskNmc,TaskDsgGrpc);fflush(stdout);
																						if(strcmp(TaskDsgGrpc,"16")==0)
																						{
																							s16TaskAvailFlag=1;
																							
																						}
																						else if(strcmp(TaskDsgGrpc,"26")==0)
																						{
																							s26TaskAvailFlag=1;
																							
																						}
																						else if(strcmp(TaskDsgGrpc,"35")==0)
																						{
																							s35TaskAvailFlag=1;
																							
																						}
																						else if(strcmp(TaskDsgGrpc,"39")==0)
																						{
																							s39TaskAvailFlag=1;
																							
																						}
																					}
																				}
																				printf("\n EV::V:P23:s16TaskAvailFlag:%d s26TaskAvailFlag:%d s35TaskAvailFlag:%d s39TaskAvailFlag:%d \n",s16TaskAvailFlag,s26TaskAvailFlag,s35TaskAvailFlag,s39TaskAvailFlag);fflush(stdout);
																				for (tsk=0;tsk<Tskcnt ;tsk++ )
																				{
																					if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																					printf("\n EV::V:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																					if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																					{
																						if(TaskDsgGrp) TaskDsgGrp=NULL;
																						if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																						TaskDsgGrp=subString(TskNm,11,2);
																						printf("\n EV::V:P24: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																						if((strcmp(TaskDsgGrp,"00")==0)&&(strcmp(InputTaskDsgGrp,"00")==0))
																						{
																							printf("\n EV::V:P26:Vehicle 00 tasks:[%s]",TskNm);fflush(stdout);
																							if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																							if (tsk_CMRef_type!=NULLTAG)
																							{
																								//Getting parts from CMHasSolutionItem
																								CMRefcount=0;
																								if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																								printf("\n EV::V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																								if(CMRefcount > 0)
																								{
																									
																									Mstr=0;
																									VCAttached =0;
																									VCCRAttached =0;
																									VehclAttached =0;
																									VehAttached =0;
																									
																									for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																									{
																										printf("\n EV::V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																										if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																										printf("\n EV::V:P27:Prt_object_type is :[%s]\n",Prt_object_type);fflush(stdout);
																										if(strcmp(Prt_object_type,"Design Revision")==0)
																										{
																											// Put condition for desi rev , to avoid other attachments.
																											if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																											if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																											if(AOM_ask_value_string(TaskCMRef[Mstr], "t5_PartType", &sPartTyp)!=ITK_ok)PrintErrorStack();
																											printf("\n EV::V:P28:PartMstr_no:[%s] attach part revision:[%s] and sPartTyp:[%s]", PartMstr_no,Prtrev_idd,sPartTyp);fflush(stdout);
																											//check task design group wise module availability. Vehicle Combination CR
																											if((strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																											{
																												VehAttached =1;
																												VCCRAttached =1;
																												printf("\n EV:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																											}
																											if((strcmp(sPartTyp,"VC")==0)||(strcmp(sPartTyp,"Vehicle Combination")==0))
																											{
																												VCAttached =1;
																												VehAttached =1;
																												printf("\n EV:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																											}
																											else if((strcmp(sPartTyp,"V")==0)||(strcmp(sPartTyp,"Vehicle")==0)||(strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																											{
																												VehclAttached =1;
																												VehAttached =1;
																												printf("\n EV:V:P26:Chcking for part no:[%s]",PartMstr_no);fflush(stdout);
																												//Expand Vehicle to check ECU module
																												ECUMdlFlag =0;
																												if(GRM_find_relation_type("T5_CCVCHasECUModule", &CCVCrel_type)!=ITK_ok)PrintErrorStack();
																												if (CCVCrel_type!=NULLTAG)
																												{
																													printf("\n EV:getting CCVCrel_type.");fflush(stdout);
																													ECUMdlcount=0;
																													if(GRM_list_secondary_objects_only(TaskCMRef[Mstr],CCVCrel_type,&ECUMdlcount,&ECUMdlTags)!=ITK_ok)PrintErrorStack();
																													printf("\n EV:ECUMdlcount: %d",ECUMdlcount);fflush(stdout);
																													if(ECUMdlcount > 0)
																													{
																														ECUMdlFlag=1;
																														ECUMdlTag = ECUMdlTags[0];
																														//check ECU module having at least one released revision to equal or above.
																														if(ITEM_ask_latest_rev(ECUMdlTag, &ECUMdlTagg)!=ITK_ok)PrintErrorStack();
																														printf("\n EV:Checking ECU module DR status.");fflush(stdout);
																														if(AOM_ask_value_string(ECUMdlTagg,"item_id",&ECUmoduleNo)!=ITK_ok)PrintErrorStack();
																														printf("\n EV:Checking ECU module no:%s",ECUmoduleNo);fflush(stdout);
																													}
																												}
																												if(tc_strstr(Prtrev_idd,"NR") != NULL)
																												{
																													printf("\n EV:V:P26:skipped for NR rev part no:[%s]",PartMstr_no);fflush(stdout);
																												}
																												else
																												{

																													Child_All_Rev= t5GetItemRevisonPSE(PartMstr_no);
																													if(Child_All_Rev==NULLTAG)
																													{
																														printf("\n DR:Child_All_Rev is NULL.\n");fflush(stdout);
																													}
																													else
																													{
																														if(ITEM_list_all_revs (Child_All_Rev,&Child_Rev_count,&Child_rev_list)!=ITK_ok)PrintErrorStack();
																														printf("\n DR:: Total Child rev found: %d",Child_Rev_count);fflush(stdout);
																														if(Child_Rev_count > 0)
																														{
																															cr=0;
																															//DROKFlag=0;
																															for(cr=Child_Rev_count-1;cr>=0;cr--)
																															{
																																if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id",&Child_rev_idd)!=ITK_ok)PrintErrorStack();
																																printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);

																																if(AOM_UIF_ask_value (Child_rev_list[cr], "release_status_list",&relstatPSE)!=ITK_ok)PrintErrorStack();
																																printf("\n DR:Latest relstatPSE:%s.", relstatPSE);fflush(stdout);

																																if((tc_strstr(relstatPSE,"ERC Released") != NULL)||(tc_strstr(relstatPSE,"T5_LcsErcRlzd") != NULL))
																																{
																																	//Expanding first level BOM for VC
																																	printf ("\n EV:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																																	if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																																	printf ("A1 ");fflush(stdout);
																																	//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																																	if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																																	printf ("A2 ");fflush(stdout);
																																	if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																																	printf ("A3 ");fflush(stdout);
																																	if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																																	printf ("A4 ");fflush(stdout);
																																	if(BOM_set_window_top_line (p_window, NULLTAG, Child_rev_list[cr], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																																	//0qty
																																	printf ("A5 ");fflush(stdout);
																																	if((tc_strcmp(sPartTyp,"V")==0)||(tc_strcmp(sPartTyp,"Vehicle")==0))
																																	{
																																		printf ("A6 ");fflush(stdout);
																																		if( PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																		//if( PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																	}
																																	else
																																	{
																																		printf ("A7 ");fflush(stdout);
																																		if( PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																	}
																																	printf ("\n EV:V:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																																	if (MDLrulefound > 0)
																																	{
																																		MDLClosureTag = MDLclosureruleee[0];
																																		printf ("\n EV:V:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																																	}
																																	if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																																	//0qty
																																	if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																																	printf("\n EV:V:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);
																																	iChild=0;
																																	ZeroTaskFlag =0;
																																	TwentyOneFlag =0;
																																	FiftyFlag =0;
																																	TwentySixFlag=0;
																																	ThirtyFiveFlag=0;
																																	for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																	{
																																		p_child_item_id=NULL;
																																		PrtDegGrp=NULL;
																																		rel_sstats=NULL;
																																		if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																		if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																		printf("\n EV:GM:P48: p_child_item_id:[%s] Rel Status:[%s]", p_child_item_id,rel_sstats);fflush(stdout);
																																		if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																		{
																																			if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_DesignGrp",&PrtDegGrp)!=ITK_ok)PrintErrorStack();
																																			printf("\n EV:GM:P48: PrtDegGrp:[%s]",PrtDegGrp);fflush(stdout);


																																			if(tc_strcmp(PrtDegGrp,"26")==0)
																																			{
																																				TwentySixFlag =1;
																																				printf(" TwentySixFlag.:[%d]\n",TwentySixFlag);fflush(stdout);
																																			}
																																			if(tc_strstr(TaskPerfInfo4,DMLProj)!=NULL)
																																			{
																																				if(tc_strcmp(PrtDegGrp,"39")==0)
																																				{
																																					ThirtyNineFlag =1;
																																					printf(" ThirtyNineFlag.:[%d]\n",ThirtyNineFlag);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				if(tc_strcmp(PrtDegGrp,"35")==0)
																																				{
																																					ThirtyFiveFlag =1;
																																					printf(" ThirtyFiveFlag.:[%d]\n",ThirtyFiveFlag);fflush(stdout);
																																				}
																																			}

																																		}
																																	}

																																	printf("\n EV:V:P45:InputTaskDsgGrp:[%s] ECUMdlFlag:[%d] TwentySixFlag:[%d] ThirtyFiveFlag:[%d]\n",InputTaskDsgGrp,ECUMdlFlag,TwentySixFlag,ThirtyFiveFlag);fflush(stdout);
																																	if(tc_strcmp(InputTaskDsgGrp,"00")==0)
																																	{
																																		if (((TwentySixFlag >0) && (s26TaskAvailFlag==0))||((ThirtyFiveFlag >0)&& (s35TaskAvailFlag==0))||((ThirtyNineFlag >0)&& (s39TaskAvailFlag==0)))
																																		{
																																			tc_strcat(errmsg,"Previous released revision of Vehicle ");
																																			tc_strcat(errmsg,PartMstr_no);
																																			tc_strcat(errmsg," having module with design group ");
																																		}
																																		if ((TwentySixFlag >0)&& (s26TaskAvailFlag==0))
																																		{
																																			tc_strcat(errmsg,"26,");
																																		}
																																		if ((ThirtyFiveFlag >0)&& (s35TaskAvailFlag==0))
																																		{
																																			tc_strcat(errmsg,"35,");
																																		}
																																		if ((ThirtyNineFlag >0)&& (s39TaskAvailFlag==0))
																																		{
																																			tc_strcat(errmsg,"39,");
																																		}
																																		if((strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																																		{
																																			printf("\n EV:ECU modules check skip for VCCR.:[%s]\n",PartMstr_no);fflush(stdout);
																																		}
																																		else
																																		{
																																			if(s16TaskAvailFlag==0)
																																			{
																																				if(tc_strstr(TaskPerfInfo1,"K1") == NULL)
																																				{
																																					tc_strcat(errmsg,"16,");
																																				}
																																				else if(tc_strstr(TaskPerfInfo1,"K2") == NULL)
																																				{
																																					if (ECUMdlFlag >0)
																																					{
																																						tc_strcat(errmsg,"16,");
																																					}
																																				}
																																			}
																																		}
																																	}
																																	break;
																																}
																															}
																															//break;
																														}
																													}
																												}
																												//
																												if(tc_strstr(TaskPerfInfo1,"B2") == NULL)
																												{
																													if(tc_strlen(errmsg) > 0)
																													{
																														printf("\n EV:No vehicle attached to 00 task.:[%s]\n",PartMstr_no);fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s3(EMH_severity_error,PO_BASIC_VALI,"ERROR:",errmsg,".\nPlease attach same group tak and process. \nIf you want to attach task, Please get DML aborted and attach respective task and resubmit DML.");
																														decision = EPM_nogo;
																														return decision;
																													}
																												}
																											}
																										}
																										if (VehAttached ==0)
																										{
																											if(tc_strstr(TaskPerfInfo1,"K3") == NULL)
																											{
																												printf("\n EV:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																												EMH_clear_errors();
																												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																												decision = EPM_nogo;
																												return decision;
																											}
																										}
																										else
																										{
																											if(tc_strstr(TaskPerfInfo1,"K4") == NULL)
																											{
																												if(tc_strstr(Prtrev_idd,"NR") != NULL)
																												{
																													if (((VCAttached ==0)|| (VehclAttached ==0)) && (VCCRAttached==0))
																													{
																														printf("\n EV:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: Either VC or Vehicle not found attached to 00 task.\nPlease attach it and process or raise to DML support team. ",PartMstr_no);
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														printf("\n EV:vehicle attached to 00_task or VCCR case....:[%s]\n",PartMstr_no);fflush(stdout);
																													}
																												}
																											}
																										}
																									}

																								}
																								else
																								{
																									if(tc_strstr(TaskPerfInfo1,"K5") == NULL)
																									{
																										printf("\n EV:No vehicle attached to 00 task.:[%s]\n",PartMstr_no);fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																										decision = EPM_nogo;
																										return decision;
																									}
																								}
																							}
																						}
																						//Check if same group module is avaiable in WIP revision while respective task sign off.
																						if(TaskDsgGrp) TaskDsgGrp=NULL;
																						if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																						TaskDsgGrp=subString(TskNm,11,2);
																						printf("\n EV1:V:P24: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																						if(strcmp(TaskDsgGrp,"00")==0)
																						{
																							printf("\n MDL:V:P26:Vehicle 00 tasks:[%s]",TskNm);fflush(stdout);
																							if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																							if (tsk_CMRef_type!=NULLTAG)
																							{
																								//Getting parts from CMHasSolutionItem
																								CMRefcount=0;
																								if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																								printf("\n EV1:V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																								if(CMRefcount > 0)
																								{
																									Mstr=0;
																									VCAttached =0;
																									VCCRAttached =0;
																									VehclAttached =0;
																									VehAttached =0;
																									for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																									{
																										printf("\n EV1:V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																										if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																										printf("\n EV1:V:P27:Prt_object_type is :[%s]\n",Prt_object_type);fflush(stdout);
																										if(strcmp(Prt_object_type,"Design Revision")==0)
																										{
																											// Put condition for desi rev , to avoid other attachments.
																											if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																											if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																											if(AOM_ask_value_string(TaskCMRef[Mstr], "t5_PartType", &sPartTyp)!=ITK_ok)PrintErrorStack();
																											printf("\n EV1:V:P28:PartMstr_no:[%s] attach part revision:[%s] and sPartTyp:[%s]", PartMstr_no,Prtrev_idd,sPartTyp);fflush(stdout);
																											//check task design group wise module availability. Vehicle Combination CR
																											if((strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																											{
																												VehAttached =1;
																												VCCRAttached =1;
																												printf("\n EV1:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																											}
																											if((strcmp(sPartTyp,"VC")==0)||(strcmp(sPartTyp,"Vehicle Combination")==0))
																											{
																												VCAttached =1;
																												VehAttached =1;
																												printf("\n EV1:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																											}
																											else if((strcmp(sPartTyp,"V")==0)||(strcmp(sPartTyp,"Vehicle")==0)||(strcmp(sPartTyp,"VC")==0)||(strcmp(sPartTyp,"Vehicle Combination")==0))
																											{
																												VehclAttached =1;
																												VehAttached =1;
																												printf("\n EV1:V:P26:Chcking for part no:[%s]",PartMstr_no);fflush(stdout);
																												//Expand Vehicle to check ECU module
																												ECUMdlFlag =0;
																												if(GRM_find_relation_type("T5_CCVCHasECUModule", &CCVCrel_type)!=ITK_ok)PrintErrorStack();
																												if (CCVCrel_type!=NULLTAG)
																												{
																													printf("\n EV1:getting CCVCrel_type.");fflush(stdout);
																													ECUMdlcount=0;
																													if(GRM_list_secondary_objects_only(TaskCMRef[Mstr],CCVCrel_type,&ECUMdlcount,&ECUMdlTags)!=ITK_ok)PrintErrorStack();
																													printf("\n EV1:ECUMdlcount: %d",ECUMdlcount);fflush(stdout);
																													if(ECUMdlcount > 0)
																													{
																														ECUMdlFlag=1;
																														ECUMdlTag = ECUMdlTags[0];
																														//check ECU module having at least one released revision to equal or above.
																														if(ITEM_ask_latest_rev(ECUMdlTag, &ECUMdlTagg)!=ITK_ok)PrintErrorStack();
																														printf("\n EV1:Checking ECU module DR status.");fflush(stdout);
																														if(AOM_ask_value_string(ECUMdlTagg,"item_id",&ECUmoduleNo)!=ITK_ok)PrintErrorStack();
																														printf("\n EV1:Checking ECU module no:%s",ECUmoduleNo);fflush(stdout);
																													}
																												}
																												//Expanding first level BOM for VC
																												printf ("\n EV1:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																												if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																												printf ("A1 ");fflush(stdout);
																												//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																												if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																												printf ("A2 ");fflush(stdout);
																												if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																												printf ("A3 ");fflush(stdout);
																												if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																												printf ("A4 ");fflush(stdout);
																												if(BOM_set_window_top_line (p_window, NULLTAG, TaskCMRef[Mstr], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																												//0qty
																												printf ("A5 ");fflush(stdout);
																												if((tc_strcmp(sPartTyp,"V")==0)||(tc_strcmp(sPartTyp,"Vehicle")==0))
																												{
																													printf ("A6 ");fflush(stdout);
																													if( PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																													//if( PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																												else
																												{
																													printf ("A7 ");fflush(stdout);
																													if( PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																												printf ("\n EV1:V:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																												if (MDLrulefound > 0)
																												{
																													MDLClosureTag = MDLclosureruleee[0];
																													printf ("\n EV1:V:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																												}
																												if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																												//0qty
																												if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																												printf("\n EV1:V:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);
																												iChild=0;
																												ZeroTaskFlag =0;
																												TwentyOneFlag =0;
																												FiftyFlag =0;
																												TwentySixFlag=0;
																												ThirtyFiveFlag=0;
																												for(iChild =0 ; iChild < VCChildCunt; iChild++)
																												{
																													p_child_item_id=NULL;
																													PrtDegGrp=NULL;
																													rel_sstats=NULL;
																													if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																													if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																													printf("\n EV1:GM:P48: p_child_item_id:[%s] Rel Status:[%s]", p_child_item_id,rel_sstats);fflush(stdout);
																													if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																													{
																														if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_DesignGrp",&PrtDegGrp)!=ITK_ok)PrintErrorStack();
																														printf("\n EV1:GM:P48: PrtDegGrp:[%s]",PrtDegGrp);fflush(stdout);

																														if(tc_strcmp(PrtDegGrp,"26")==0)
																														{
																															TwentySixFlag =1;
																															printf(" TwentySixFlag.:[%d]\n",TwentySixFlag);fflush(stdout);
																														}
																														if(tc_strstr(TaskPerfInfo4,DMLProj)!=NULL)
																														{
																															if(tc_strcmp(PrtDegGrp,"39")==0)
																															{
																																ThirtyNineFlag =1;
																																printf(" ThirtyNineFlag.:[%d]\n",ThirtyNineFlag);fflush(stdout);
																															}
																														}
																														else
																														{
																															if(tc_strcmp(PrtDegGrp,"35")==0)
																															{
																																ThirtyFiveFlag =1;
																																printf(" ThirtyFiveFlag.:[%d]\n",ThirtyFiveFlag);fflush(stdout);
																															}
																														}

																													}
																												}

																												printf("\n EV1:V:P45:InputTaskDsgGrp:[%s] ECUMdlFlag:[%d]  TwentySixFlag:[%d] ThirtyFiveFlag:[%d]\n",InputTaskDsgGrp,ECUMdlFlag,TwentySixFlag,ThirtyFiveFlag);fflush(stdout);
																												if(tc_strcmp(InputTaskDsgGrp,"00")==0)
																												{
																													printf("\n EV1:V:s16TaskAvailFlag:%d s26TaskAvailFlag:%d s35TaskAvailFlag:%d s39TaskAvailFlag:%d \n",s16TaskAvailFlag,s26TaskAvailFlag,s35TaskAvailFlag,s39TaskAvailFlag);fflush(stdout);
																													//All modules should be attached.
																													if((strcmp(sPartTyp,"VC")==0)||(strcmp(sPartTyp,"Vehicle Combination")==0))
																													{
																														if (((s26TaskAvailFlag >0)&&(TwentySixFlag ==0))||(((s35TaskAvailFlag >0)&&(ThirtyFiveFlag ==0))||((s39TaskAvailFlag >0)&&(ThirtyNineFlag ==0))))
																														{
																															if(tc_strstr(TaskPerfInfo1,"K6") == NULL)
																															{
																																if(ThirtyNineFlag>0)
																																{
																																	printf("\n EV1:00/26/39 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: All mandatory design group module like 00,26,39 should be attached under EV vehicle.\n Please attach it and process. ",PartMstr_no);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																																else
																																{
																																	printf("\n EV1:00/16/26/35 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: All mandatory design group module like 00,26,35 should be attached under EV vehicle.\nPlease attach it and process. ",PartMstr_no);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																															}
																														}
																													}
																													else
																													{
																														if (((s26TaskAvailFlag >0)&&(TwentySixFlag ==0))||(((s35TaskAvailFlag >0)&&(ThirtyFiveFlag ==0))||((s39TaskAvailFlag >0)&&(ThirtyNineFlag ==0)))||((s16TaskAvailFlag >0)&&(ECUMdlFlag ==0)))
																														{
																															if(tc_strstr(TaskPerfInfo1,"K7") == NULL)
																															{
																																if(ThirtyNineFlag>0)
																																{
																																	printf("\n EV1:00/16/26/39 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: All mandatory design group module like 00,16,26,39 should be attached under EV vehicle.\n 16R ECU module should be attach to the folder- Has ECU Calibration Module. \nPlease attach it and process. ",PartMstr_no);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																																else
																																{
																																	printf("\n EV1:00/16/26/35 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																																	EMH_clear_errors();
																																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: All mandatory design group module like 00,16,26,35 should be attached under EV vehicle.\n 16R ECU module should be attach to the folder- Has ECU Calibration Module. \nPlease attach it and process. ",PartMstr_no);
																																	decision = EPM_nogo;
																																	return decision;
																																}
																															}
																														}
																													}

																												}
																												else if(tc_strcmp(InputTaskDsgGrp,"16")==0)
																												{
																													//ECU modules should be attached.
																													if (ECUMdlFlag >0)
																													{
																														printf("\n EV1:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													}
																													else
																													{
																														if(tc_strstr(TaskPerfInfo1,"K8") == NULL)
																														{
																															if((strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																															{
																																printf("\n EV1:ECU modules is skipp to VVCR.:[%s]\n",PartMstr_no);fflush(stdout);
																															}
																															else
																															{
																																printf("\n EV1:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																																EMH_clear_errors();
																																EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"16R ECU module is not attached to Has ECU Calibration Module folder to vehicle.\nPlease attach it and process. ",PartMstr_no);
																																decision = EPM_nogo;
																																return decision;
																															}
																														}
																													}
																												}
																												else if(tc_strcmp(InputTaskDsgGrp,"26")==0)
																												{
																													//ECU modules should be attached.
																													if (TwentySixFlag >0)
																													{
																														printf("\n EV1:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													}
																													else
																													{
																														if(tc_strstr(TaskPerfInfo1,"K9") == NULL)
																														{
																															printf("\n EV1:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																															EMH_clear_errors();
																															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"26 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																															decision = EPM_nogo;
																															return decision;
																														}
																													}
																												}
																												else if(tc_strcmp(InputTaskDsgGrp,"35")==0)
																												{
																													//ECU modules should be attached.
																													if (ThirtyFiveFlag >0)
																													{
																														printf("\n EV1:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													}
																													else
																													{
																														if(tc_strstr(TaskPerfInfo1,"L1") == NULL)
																														{
																															printf("\n EV1:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																															EMH_clear_errors();
																															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"35 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																															decision = EPM_nogo;
																															return decision;
																														}
																													}
																												}
																												else if(tc_strcmp(InputTaskDsgGrp,"39")==0)
																												{
																													//ECU modules should be attached.
																													if (ThirtyNineFlag >0)
																													{
																														printf("\n EV1:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													}
																													else
																													{
																														if(tc_strstr(TaskPerfInfo1,"L2") == NULL)
																														{
																															printf("\n EV1:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																															EMH_clear_errors();
																															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"39 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																															decision = EPM_nogo;
																															return decision;
																														}
																													}
																												}
																												else
																												{
																													printf("\n EV1:Other group task bypassed...:[%s]\n",PartMstr_no);fflush(stdout);
																												}
																											}
																										}
																									}
																									if (VehAttached ==0)
																									{
																										if(tc_strstr(TaskPerfInfo1,"L3") == NULL)
																										{
																											printf("\n EV1:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																											EMH_clear_errors();
																											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																											decision = EPM_nogo;
																											return decision;
																										}
																									}
																									else
																									{
																										if(tc_strstr(TaskPerfInfo1,"L4") == NULL)
																										{
																											if(tc_strstr(Prtrev_idd,"NR") != NULL)
																											{
																												if (((VCAttached ==0)|| (VehclAttached ==0)) && (VCCRAttached==0))
																												{
																													printf("\n EV1:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: Either VC or Vehicle not found attached to 00 task.\nPlease attach it and process or raise to DML support team. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																												else
																												{
																													printf("\n EV1:vehicle attached to 00_task or VCCR case....:[%s]\n",PartMstr_no);fflush(stdout);
																												}
																											}
																										}
																									}
																								}
																								else
																								{
																									if(tc_strstr(TaskPerfInfo1,"L5") == NULL)
																									{
																										printf("\n EV1:No vehicle attached to 00 task.:[%s]\n",PartMstr_no);fflush(stdout);
																										EMH_clear_errors();
																										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																										decision = EPM_nogo;
																										return decision;
																									}
																								}
																							}
																						}
																					}
																				}
																				printf("\n EV2:Now checking for 00 Task sign off to ensure all other tasks are signed off.\n");fflush(stdout);
																				if(tc_strstr(TaskPerfInfo1,"L6") == NULL)
																				{
																					if(tc_strcmp(InputTaskDsgGrp,"00")==0)
																					{
																						tsk=0;
																						for (tsk=0;tsk<Tskcnt ;tsk++ )
																						{
																							TskSignoffFlag=0;
																							if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																							printf("\n EV2::Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);
																							if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																							{
																								if(TaskDsgGrp) TaskDsgGrp=NULL;
																								if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																								TaskDsgGrp=subString(TskNm,11,2);
																								printf("\n EV2:: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																								if(strcmp(TaskDsgGrp,"00")!=0)
																								{
																									//Other than 00 task.
																									if(EPM_get_current_job(Dml_tasks[tsk],&taskjob,&task_job_type)!=ITK_ok)PrintErrorStack();
																									if (taskjob != NULLTAG)
																									{
																										if(EPM_ask_root_task(taskjob,&taskroottask)!=ITK_ok)PrintErrorStack();
																										Tskcntt=0;
																										if(AOM_ask_value_tags(taskroottask,"sub_processes",&Tskcntt,&Dml_taskss)!=ITK_ok)PrintErrorStack();
																										printf("\n EV2::sub_processes count:[%d].",Tskcntt);fflush(stdout);
																										if(Tskcntt >0)
																										{
																											for (kkk=0;kkk<Tskcntt;kkk++)
																											{
																												AddSolutionFound=0;
																												if(AOM_ask_value_tags(Dml_taskss[kkk],"all_tasks",&Tskcnttt,&Dml_tasksss)!=ITK_ok)PrintErrorStack();
																												printf("\n EV2::All tasks form sub_processes:[%d].",Tskcnttt);fflush(stdout);
																												if(Tskcnttt >0)
																												{
																													if(tc_strstr(TaskPerfInfo1,"L7") == NULL)
																													{
																														for (kk=0;kk<Tskcnttt;kk++)
																														{
																															TskSignoffFlag=0;
																															printf("\n EV2::Checking for All tasks:kk:[%d].",kk);fflush(stdout);
																															if(AOM_ask_value_string (Dml_tasksss[kk],"task_type",&SubSubtaskType)!=ITK_ok)PrintErrorStack();
																															printf("\n EV2::Sub-Sub Task Type.:%s ",SubSubtaskType);fflush(stdout);
																															if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&SubSubTaskNm1)!=ITK_ok)PrintErrorStack();
																															printf(" and :SubSubTaskNm1: [%s] ",SubSubTaskNm1);
																															if((tc_strcmp(SubSubtaskType,"EPMTask")==0) && (tc_strcmp(SubSubTaskNm1,"CVBU VC Task Release")==0))
																															{
																																AddSolutionFound=1;
																																if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&tasknameofroot)!=ITK_ok)PrintErrorStack();
																																printf("\n EV2::tasknameofroot: [%s] ",tasknameofroot);

																																if(AOM_ask_value_string(Dml_tasksss[kk],"object_type",&roottask_Objtype)!=ITK_ok)PrintErrorStack();
																																printf(" Object_Type: [%s] ",roottask_Objtype);fflush(stdout);

																																if(AOM_ask_value_string(Dml_tasksss[kk],"task_result",&sTask_Result)!=ITK_ok)PrintErrorStack();
																																printf(" Task Result: [%s] ",sTask_Result);fflush(stdout);
																																if(AOM_ask_value_string(Dml_tasksss[kk],"task_state",&status_root_task)!=ITK_ok)PrintErrorStack();
																																printf(" Task Status: [%s] ",status_root_task);fflush(stdout);
																																if(tc_strstr(TaskPerfInfo1,"S3") == NULL)
																																{
																																	if((tc_strcmp(status_root_task,"Completed")==0)||(tc_strcmp(sTask_Result,"Completed")==0))
																																	{
																																		printf("\n V8:CVBU:Task Sign off not completed...:%s",TskNm);fflush(stdout);
																																		TskSignoffFlag=1;
																																	}
																																}
																																else if(tc_strstr(TaskPerfInfo1,"S4") == NULL)
																																{
																																	//Completed
																																	if((tc_strstr(TaskPerfInfo3,status_root_task) != NULL)||(tc_strstr(TaskPerfInfo3,sTask_Result) != NULL))
																																	{
																																		printf("\n EV2::CVBU::Task Sign off completed.:%s",TskNm);fflush(stdout);
																																		TskSignoffFlag=1;
																																	}
																																	else
																																	{
																																		printf("\n EV2::CVBU:ERROR:Task Sign off not completed.:[%s]",TskNm);fflush(stdout);
																																		TskSignoffFlag=0;
																																	}
																																}
																																break;
																															}
																														}
																													}
																													else
																													{
																														//This will be lkept off later opld logic
																														for (kk=0;kk<Tskcnttt;kk++)
																														{
																															TskSignoffFlag=0;
																															printf("\n EV2::Checking for All tasks:kk:[%d].",kk);fflush(stdout);
																															if(AOM_ask_value_string (Dml_tasksss[kk],"task_type",&SubSubtaskType)!=ITK_ok)PrintErrorStack();
																															printf("\n EV2::Sub-Sub Task Type.:%s ",SubSubtaskType);fflush(stdout);
																															if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&SubSubTaskNm1)!=ITK_ok)PrintErrorStack();
																															printf(" and :SubSubTaskNm1: [%s] ",SubSubTaskNm1);
																															//if((tc_strcmp(taskType,"EPMDoTask")==0) && ((tc_strcmp(SubTaskNm1,"CVBU  VC Task workflow")==0)|| (tc_strcmp(SubTaskNm1,"CVBU VC Task workflow")==0)))
																															if((tc_strcmp(SubSubtaskType,"EPMDoTask")==0) && (tc_strcmp(SubSubTaskNm1,"Add solution items")==0))
																															{
																																AddSolutionFound=1;
																																if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&tasknameofroot)!=ITK_ok)PrintErrorStack();
																																printf("\n EV2::tasknameofroot: [%s] ",tasknameofroot);

																																if(AOM_ask_value_string(Dml_tasksss[kk],"object_type",&roottask_Objtype)!=ITK_ok)PrintErrorStack();
																																printf(" Object_Type: [%s] ",roottask_Objtype);fflush(stdout);

																																if(AOM_ask_value_string(Dml_tasksss[kk],"task_state",&status_root_task)!=ITK_ok)PrintErrorStack();
																																printf(" Status: [%s] ",status_root_task);fflush(stdout);
																																if(tc_strstr(TaskPerfInfo1,"S3") == NULL)
																																{
																																	if (tc_strcmp(status_root_task,"Completed")==0)
																																	{
																																		printf("\n EV2::CVBU:Task Sign off not completed.:%s",TskNm);fflush(stdout);
																																		TskSignoffFlag=1;
																																	}
																																}
																																else if(tc_strstr(TaskPerfInfo1,"S4") == NULL)
																																{
																																	//Completed
																																	if(tc_strstr(TaskPerfInfo3,status_root_task) != NULL)
																																	{
																																		printf("\n EV2::CVBU::Task Sign off completed.:%s",TskNm);fflush(stdout);
																																		TskSignoffFlag=1;
																																	}
																																	else
																																	{
																																		printf("\n EV2::CVBU:ERROR:Task Sign off not completed.:[%s]",TskNm);fflush(stdout);
																																		TskSignoffFlag=0;
																																	}
																																}
																																break;
																															}
																														}
																													}
																												}
																												if (AddSolutionFound >0)
																												{
																													if (TskSignoffFlag >0)
																													{
																														printf("\n EV2::AddSolution assignment Found and task is completed:%s \n",TskNm);fflush(stdout);
																													}
																													else
																													{
																														printf("\n V11:AddSolution assignment Found and task is NOT completed.%s \n",TskNm);fflush(stdout);
																													}
																													break;
																												}
																											}
																										}
																										if (TskSignoffFlag ==0)
																										{
																											printf("\n EV2::ERROR:VBU:Task Sign off not completed.....\n");fflush(stdout);
																											EMH_clear_errors();
																											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"All other than 00 task should be signed off first.\nPlease get other tasks signed off. ",TskNm);
																											decision = EPM_nogo;
																											return decision;
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																		else
																		{
																			printf("\n EV2:P20:DML proj bypassed:[%s]\n",DMLProj);fflush(stdout);
																		}
																	}
																}
															}
														}
														if(EVskippFlag ==0)
														{
															if(tc_strstr(TaskPerfInfo2,DMLProj) == NULL)
															{
																printf("\n Veh:P20:Checking for DML:[%s]\n",sDMLno);fflush(stdout);
																//getting task 
																s0ETaskAvailFlag=0;
																s35TaskAvailFlag=0;
																s21TaskAvailFlag=0;
																s50TaskAvailFlag=0;
																s26TaskAvailFlag=0;
																s39TaskAvailFlag=0;
																s16TaskAvailFlag=0;
																for (tskc=0;tskc<Tskcnt ;tskc++ )
																{
																	if(AOM_ask_value_string(Dml_tasks[tskc],"object_type",&Tsk_object_typec)!=ITK_ok)PrintErrorStack();
																	printf("\n EV::V:P23:Tsk_object_typec is :%s\n",Tsk_object_typec);fflush(stdout);

																	if(strcmp(Tsk_object_typec,"T5_ChangeTaskRevision")==0)
																	{
																		if(TaskDsgGrpc) TaskDsgGrpc=NULL;
																		if(AOM_UIF_ask_value(Dml_tasks[tskc],"item_id",&TskNmc)!=ITK_ok)PrintErrorStack();
																		TaskDsgGrpc=subString(TskNmc,11,2);
																		printf("\n EV::V:P24: Task: [%s] TaskDsgGrpc:[%s] \n",TskNmc,TaskDsgGrpc);fflush(stdout);
																		if(strcmp(TaskDsgGrpc,"16")==0)
																		{
																			s16TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"26")==0)
																		{
																			s26TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"35")==0)
																		{
																			s35TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"39")==0)
																		{
																			s39TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"21")==0)
																		{
																			s21TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"50")==0)
																		{
																			s50TaskAvailFlag=1;
																		}
																		else if(strcmp(TaskDsgGrpc,"0E")==0)
																		{
																			s0ETaskAvailFlag=1;
																		}
																	}
																}
																
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n Veh:V:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	if(tc_strstr(TaskPerfInfo1,"S1") == NULL)
																	{
																		for (tsk=0;tsk<Tskcnt ;tsk++ )
																		{
																			if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																			printf("\n Veh:V:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																			if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																			{
																				if(TaskDsgGrp) TaskDsgGrp=NULL;
																				if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																				TaskDsgGrp=subString(TskNm,11,2);
																				printf("\n Veh:V:P24: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																				if(strcmp(TaskDsgGrp,"00")==0)
																				{
																					printf("\n MDL:V:P26:Vehicle 00 tasks:[%s]",TskNm);fflush(stdout);
																					if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																					if (tsk_CMRef_type!=NULLTAG)
																					{
																						//Getting parts from CMHasSolutionItem
																						CMRefcount=0;
																						if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																						printf("\n Veh:V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																						if(CMRefcount > 0)
																						{
																							Mstr=0;
																							VCAttached =0;
																							VCCRAttached =0;
																							VehclAttached =0;
																							VehAttached =0;
																							for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																							{
																								printf("\n Veh:V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																								if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																								printf("\n Veh:V:P27:Prt_object_type is :[%s]\n",Prt_object_type);fflush(stdout);
																								if(strcmp(Prt_object_type,"Design Revision")==0)
																								{
																									// Put condition for desi rev , to avoid other attachments.
																									if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																									if(AOM_ask_value_string(TaskCMRef[Mstr], "t5_PartType", &sPartTyp)!=ITK_ok)PrintErrorStack();
																									printf("\n Veh:V:P28:PartMstr_no:[%s] attach part revision:[%s] and sPartTyp:[%s]", PartMstr_no,Prtrev_idd,sPartTyp);fflush(stdout);
																									//check task design group wise module availability. Vehicle Combination CR
																									if((strcmp(sPartTyp,"VCCR")==0)||(strcmp(sPartTyp,"Vehicle Combination CR")==0))
																									{
																										VehAttached =1;
																										VCCRAttached =1;
																										printf("\n Veh:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																									}
																									else if((strcmp(sPartTyp,"VC")==0)||(strcmp(sPartTyp,"Vehicle Combination")==0))
																									{
																										VCAttached =1;
																										VehAttached =1;
																										printf("\n Veh:V:P26:bypassing for Vehicle Combination CR:[%s]",PartMstr_no);fflush(stdout);
																									}
																									else if(strcmp(sPartTyp,"V")==0)
																									{
																										VehclAttached =1;
																										VehAttached =1;
																										printf("\n Veh:V:P26:Chcking for part no:[%s]",PartMstr_no);fflush(stdout);
																										//Expand Vehicle to check ECU module
																										ECUMdlFlag =0;
																										if(GRM_find_relation_type("T5_CCVCHasECUModule", &CCVCrel_type)!=ITK_ok)PrintErrorStack();
																										if (CCVCrel_type!=NULLTAG)
																										{
																											printf("\n Veh:getting CCVCrel_type.");fflush(stdout);
																											ECUMdlcount=0;
																											if(GRM_list_secondary_objects_only(TaskCMRef[Mstr],CCVCrel_type,&ECUMdlcount,&ECUMdlTags)!=ITK_ok)PrintErrorStack();
																											printf("\n Veh:ECUMdlcount: %d",ECUMdlcount);fflush(stdout);
																											if(ECUMdlcount > 0)
																											{
																												ECUMdlFlag=1;
																												ECUMdlTag = ECUMdlTags[0];
																												//check ECU module having at least one released revision to equal or above.
																												if(ITEM_ask_latest_rev(ECUMdlTag, &ECUMdlTagg)!=ITK_ok)PrintErrorStack();
																												printf("\n Veh:Checking ECU module DR status.");fflush(stdout);
																												if(AOM_ask_value_string(ECUMdlTagg,"item_id",&ECUmoduleNo)!=ITK_ok)PrintErrorStack();
																												printf("\n Veh:Checking ECU module no:%s",ECUmoduleNo);fflush(stdout);
																											}
																										}
																										//Expanding first level BOM for VC
																										printf ("\n Veh:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																										if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																										printf ("A1 ");fflush(stdout);
																										//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																										if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																										printf ("A2 ");fflush(stdout);
																										if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																										printf ("A3 ");fflush(stdout);
																										if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																										printf ("A4 ");fflush(stdout);
																										if(BOM_set_window_top_line (p_window, NULLTAG, TaskCMRef[Mstr], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																										//0qty
																										printf ("A5 ");fflush(stdout);
																										if((tc_strcmp(sPartTyp,"V")==0)||(tc_strcmp(sPartTyp,"Vehicle")==0))
																										{
																											printf ("A6 ");fflush(stdout);
																											if( PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																											//if( PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																										}
																										else
																										{
																											printf ("A7 ");fflush(stdout);
																											if( PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																										}
																										printf ("\n Veh:V:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																										if (MDLrulefound > 0)
																										{
																											MDLClosureTag = MDLclosureruleee[0];
																											printf ("\n Veh:V:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																										}
																										if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																										//0qty
																										if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																										printf("\n Veh:V:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);
																										iChild=0;
																										ZeroTaskFlag =0;
																										TwentyOneFlag =0;
																										FiftyFlag =0;
																										TwentySixFlag=0;
																										ThirtyFiveFlag=0;
																										if(tc_strstr(TaskPerfInfo1,"B1") == NULL)
																										{
																											//get prev rel rev of VEH AND GET bom and compare 5 deg grp module.
																											// if any diff found then that group task is mandatory to attach.
																											// Get 00 task and then vehicle and expand vehicle to BOM.
																											
																											if(strcmp(sPartTyp,"V")==0)
																											{
																												Child_All_Rev= t5GetItemRevisonPSE(PartMstr_no);
																												if(Child_All_Rev==NULLTAG)
																												{
																													printf("\n DR:Child_All_Rev is NULL.\n");fflush(stdout);
																												}
																												else
																												{
																													if(ITEM_list_all_revs (Child_All_Rev,&Child_Rev_count,&Child_rev_list)!=ITK_ok)PrintErrorStack();
																													printf("\n DR:: Total Child rev found: %d",Child_Rev_count);fflush(stdout);
																													if(Child_Rev_count > 0)
																													{
																														int PrevECUMdlFlag=0;
																														cr=0;
																														//DROKFlag=0;
																														Prev16TaskFlag =0;
																														PrevZeroTaskFlag =0;
																														PrevFiftyFlag =0;
																														PrevTwentyOneFlag =0;
																														PrevTwentySixFlag =0;
																														PrevThirtyNineFlag =0;
																														PrevThirtyFiveFlag =0;
																														for(cr=Child_Rev_count-1;cr>=0;cr--)
																														{
																															if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id",&Child_rev_idd)!=ITK_ok)PrintErrorStack();
																															printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);

																															if(AOM_UIF_ask_value (Child_rev_list[cr], "release_status_list",&relstatPSE)!=ITK_ok)PrintErrorStack();
																															printf("\n DR:Latest relstatPSE:%s.", relstatPSE);fflush(stdout);

																															if((tc_strstr(relstatPSE,"ERC Released") != NULL)||(tc_strstr(relstatPSE,"T5_LcsErcRlzd") != NULL))
																															{
																																//GET ECU module for prev
																																
																																if(s16TaskAvailFlag ==0)
																																{
																																	//PrevECUMdlFlag =0;
																																	if(GRM_find_relation_type("T5_CCVCHasECUModule", &PrevCCVCrel_type)!=ITK_ok)PrintErrorStack();
																																	if (PrevCCVCrel_type!=NULLTAG)
																																	{
																																		printf("\n Veh:getting PrevCCVCrel_type.");fflush(stdout);
																																		ECUMdlcount=0;
																																		if(GRM_list_secondary_objects_only(Child_rev_list[cr],PrevCCVCrel_type,&ECUMdlcount,&PrevECUMdlTags)!=ITK_ok)PrintErrorStack();
																																		printf("\n Veh:ECUMdlcount: %d",ECUMdlcount);fflush(stdout);
																																		if(ECUMdlcount > 0)
																																		{
																																			//PrevECUMdlFlag=1;
																																			PrevECUMdlTag = PrevECUMdlTags[0];
																																			//check ECU module having at least one released revision to equal or above.
																																			if(ITEM_ask_latest_rev(PrevECUMdlTag, &PrevECUMdlTagg)!=ITK_ok)PrintErrorStack();
																																			printf("\n Veh::Checking ECU module DR status.");fflush(stdout);
																																			if(AOM_ask_value_string(PrevECUMdlTagg,"item_id",&PrevECUmoduleNo)!=ITK_ok)PrintErrorStack();
																																			printf("\n Veh:WIP ECUmoduleNo:%s :PrevECUmoduleNo:%s",ECUmoduleNo,PrevECUmoduleNo);fflush(stdout);
																																			if(tc_strcmp(ECUmoduleNo,PrevECUmoduleNo)==0)
																																			{
																																				Prev16TaskFlag=1;
																																			}
																																		}
																																	}
																																}
																																else
																																{
																																	Prev16TaskFlag =1;
																																	printf("\n Task already available: Prev16TaskFlag.:[%d]\n",Prev16TaskFlag);fflush(stdout);
																																}
																																printf ("\n Veh:V:Prev16TaskFlag:%d\n",Prev16TaskFlag);fflush(stdout);
																																//Expanding first level BOM for VC
																																printf ("\n Veh:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																																if(BOM_create_window (&Prevp_window)!=ITK_ok)PrintErrorStack();
																																printf ("A1 ");fflush(stdout);
																																//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																																if(CFM_find( "ERC release and above", &PrevMDL_rule )!=ITK_ok)PrintErrorStack();
																																printf ("A2 ");fflush(stdout);
																																if(BOM_set_window_config_rule( Prevp_window, PrevMDL_rule )!=ITK_ok)PrintErrorStack();
																																printf ("A3 ");fflush(stdout);
																																if(BOM_set_window_pack_all (Prevp_window, true)!=ITK_ok)PrintErrorStack();
																																printf ("A4 ");fflush(stdout);
																																if(BOM_set_window_top_line (Prevp_window, NULLTAG, Child_rev_list[cr], NULLTAG, &Prevp_top_line)!=ITK_ok)PrintErrorStack();
																																//0qty
																																printf ("A5 ");fflush(stdout);
																																if((tc_strcmp(sPartTyp,"V")==0)||(tc_strcmp(sPartTyp,"Vehicle")==0))
																																{
																																	printf ("A6 ");fflush(stdout);
																																	if( PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &PrevMDLrulefound, &PrevMDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																	//if( PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																else
																																{
																																	printf ("A7 ");fflush(stdout);
																																	if( PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &PrevMDLrulefound, &PrevMDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																printf ("\n Veh:V:P44:PrevMDLrulefound count %d \n",PrevMDLrulefound);fflush(stdout);
																																if (PrevMDLrulefound > 0)
																																{
																																	PrevMDLClosureTag = PrevMDLclosureruleee[0];
																																	printf ("\n Veh:V:P44: PrevMDLClosureTag closure rule found \n");fflush(stdout);
																																}
																																if(BOM_window_set_closure_rule( Prevp_window,PrevMDLClosureTag, 0, PrevMDLrulenameXO,PrevMDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																																//0qty
																																if(BOM_line_ask_child_lines (Prevp_top_line, &PrevVCChildCunt, &PrevVCChildobject));
																																printf("\n Veh:V:P45:No of child objects are PrevVCChildCunt : [%d]\n",PrevVCChildCunt);fflush(stdout);
																																PrviChild=0;
																																
																																for(PrviChild =0 ; PrviChild < PrevVCChildCunt; PrviChild++)
																																{
																																	Prevp_child_item_id=NULL;
																																	PrevPrtDegGrp=NULL;
																																	Prevrel_sstats=NULL;
																																	if(AOM_ask_value_string(PrevVCChildobject[PrviChild], "bl_item_item_id", &Prevp_child_item_id )!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(PrevVCChildobject[PrviChild], "bl_rev_release_status_list", &Prevrel_sstats)!=ITK_ok)PrintErrorStack();
																																	printf("\n Veh:GM:P48: Prevp_child_item_id:[%s] Prevrel_sstats:[%s]", Prevp_child_item_id,Prevrel_sstats);fflush(stdout);
																																	if((tc_strstr(Prevrel_sstats,"Released")!=NULL)||(tc_strstr(Prevrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(Prevrel_sstats,"APL")!=NULL)||(tc_strstr(Prevrel_sstats,"STDSI")!=NULL))
																																	{
																																		if(AOM_ask_value_string(PrevVCChildobject[PrviChild],"bl_Design Revision_t5_DesignGrp",&PrevPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																		printf("\n Veh:GM:P48: PrevPrtDegGrp:[%s]",PrevPrtDegGrp);fflush(stdout);
																																		/*s0ETaskAvailFlag=0;
																																		s35TaskAvailFlag=0;
																																		s21TaskAvailFlag=0;
																																		s50TaskAvailFlag=0;
																																		s26TaskAvailFlag=0;
																																		s39TaskAvailFlag=0;
																																		s16TaskAvailFlag=0;*/
																																		printf("\n Veh:GM:P48: s0ETaskAvailFlag:[%d] s21TaskAvailFlag:[%d] s50TaskAvailFlag:[%d] s26TaskAvailFlag:[%d] s39TaskAvailFlag:[%d] s35TaskAvailFlag:[%d] ",s0ETaskAvailFlag,s21TaskAvailFlag,s50TaskAvailFlag,s26TaskAvailFlag,s39TaskAvailFlag,s35TaskAvailFlag);fflush(stdout);
																																		if(s0ETaskAvailFlag ==0)
																																		{
																																			if(tc_strcmp(PrevPrtDegGrp,"00")==0)
																																			{
																																				//WIP for loop...to compare oo modlue
																																				for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																				{
																																					WIP_child_item_id=NULL;
																																					WIPPrtDegGrp=NULL;
																																					WIPrel_sstats=NULL;
																																					if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																					printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																					if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																					{
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																						if(tc_strcmp(WIPPrtDegGrp,"00")==0)
																																						{
																																							if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																							{
																																								PrevZeroTaskFlag =1;
																																								break;
																																							}
																																						}
																																					}
																																				}
																																				
																																				printf(" PrevZeroTaskFlag.:[%d]\n",PrevZeroTaskFlag);fflush(stdout);
																																			}
																																		}
																																		else
																																		{
																																			PrevZeroTaskFlag =1;
																																			printf("\n Task already available: PrevZeroTaskFlag.:[%d]\n",PrevZeroTaskFlag);fflush(stdout);
																																		}
																																		if(s21TaskAvailFlag ==0)
																																		{
																																			if(tc_strcmp(PrevPrtDegGrp,"21")==0)
																																			{
																																				//WIP for loop...to compare oo modlue
																																				for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																				{
																																					WIP_child_item_id=NULL;
																																					WIPPrtDegGrp=NULL;
																																					WIPrel_sstats=NULL;
																																					if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																					printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																					if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																					{
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																						if(tc_strcmp(WIPPrtDegGrp,"21")==0)
																																						{
																																							if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																							{
																																								PrevTwentyOneFlag =1;
																																								break;
																																							}
																																						}
																																					}
																																				}
																																				
																																				//printf(" PrevZeroTaskFlag.:[%d]\n",PrevZeroTaskFlag);fflush(stdout);
																																				printf(" PrevTwentyOneFlag.:[%d]\n",PrevTwentyOneFlag);fflush(stdout);
																																			}
																																		}
																																		else
																																		{
																																			PrevTwentyOneFlag =1;
																																			printf("\n Task already available: PrevTwentyOneFlag.:[%d]\n",PrevTwentyOneFlag);fflush(stdout);
																																		}
																																		if(s50TaskAvailFlag ==0)
																																		{
																																			if(tc_strcmp(PrevPrtDegGrp,"50")==0)
																																			{
																																				//WIP for loop...to compare oo modlue
																																				for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																				{
																																					WIP_child_item_id=NULL;
																																					WIPPrtDegGrp=NULL;
																																					WIPrel_sstats=NULL;
																																					if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																					printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																					if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																					{
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																						if(tc_strcmp(WIPPrtDegGrp,"50")==0)
																																						{
																																							if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																							{
																																								PrevFiftyFlag =1;
																																								break;
																																							}
																																						}
																																					}
																																				}
																																				
																																				printf(" PrevFiftyFlag.:[%d]\n",PrevFiftyFlag);fflush(stdout);
																																			}
																																		}
																																		else
																																		{
																																			PrevFiftyFlag =1;
																																			printf("\n Task already available: PrevFiftyFlag.:[%d]\n",PrevFiftyFlag);fflush(stdout);
																																		}
																																		if(s26TaskAvailFlag ==0)
																																		{
																																			if(tc_strcmp(PrevPrtDegGrp,"26")==0)
																																			{
																																				for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																				{
																																					WIP_child_item_id=NULL;
																																					WIPPrtDegGrp=NULL;
																																					WIPrel_sstats=NULL;
																																					if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																					printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																					if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																					{
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																						if(tc_strcmp(WIPPrtDegGrp,"26")==0)
																																						{
																																							if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																							{
																																								PrevTwentySixFlag =1;
																																								break;
																																							}
																																						}
																																					}
																																				}
																																				
																																				printf(" PrevTwentySixFlag.:[%d]\n",PrevTwentySixFlag);fflush(stdout);
																																			}
																																		}
																																		else
																																		{
																																			PrevTwentySixFlag =1;
																																			printf("\n Task already available: PrevTwentySixFlag.:[%d]\n",PrevTwentySixFlag);fflush(stdout);
																																		}
																																		if(tc_strstr(TaskPerfInfo4,DMLProj)!=NULL)
																																		{
																																			if(s39TaskAvailFlag ==0)
																																			{
																																				if(tc_strcmp(PrevPrtDegGrp,"39")==0)
																																				{
																																					for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																					{
																																						WIP_child_item_id=NULL;
																																						WIPPrtDegGrp=NULL;
																																						WIPrel_sstats=NULL;
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																						if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																						if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																						{
																																							if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																							printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																							if(tc_strcmp(WIPPrtDegGrp,"39")==0)
																																							{
																																								if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																								{
																																									PrevThirtyNineFlag =1;
																																									break;
																																								}
																																							}
																																						}
																																					}
																																					
																																					printf(" PrevThirtyNineFlag.:[%d]\n",PrevThirtyNineFlag);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				PrevThirtyNineFlag =1;
																																				printf("\n Task already available: PrevThirtyNineFlag.:[%d]\n",PrevThirtyNineFlag);fflush(stdout);
																																			}
																																		}
																																		else
																																		{
																																			if(s35TaskAvailFlag ==0)
																																			{
																																				if(tc_strcmp(PrevPrtDegGrp,"35")==0)
																																				{
																																					for(WIPiChild =0 ; WIPiChild < VCChildCunt; WIPiChild++)
																																					{
																																						WIP_child_item_id=NULL;
																																						WIPPrtDegGrp=NULL;
																																						WIPrel_sstats=NULL;
																																						if(AOM_ask_value_string(VCChildobject[WIPiChild], "bl_item_item_id", &WIP_child_item_id )!=ITK_ok)PrintErrorStack();
																																						if(AOM_UIF_ask_value(VCChildobject[WIPiChild], "bl_rev_release_status_list", &WIPrel_sstats)!=ITK_ok)PrintErrorStack();
																																						printf("\n Veh:GM:P48: WIP_child_item_id:[%s] WIPrel_sstats:[%s]", WIP_child_item_id,WIPrel_sstats);fflush(stdout);
																																						if((tc_strstr(WIPrel_sstats,"Released")!=NULL)||(tc_strstr(WIPrel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(WIPrel_sstats,"APL")!=NULL)||(tc_strstr(WIPrel_sstats,"STDSI")!=NULL))
																																						{
																																							if(AOM_ask_value_string(VCChildobject[WIPiChild],"bl_Design Revision_t5_DesignGrp",&WIPPrtDegGrp)!=ITK_ok)PrintErrorStack();
																																							printf("\n Veh:GM:P48: WIPPrtDegGrp:[%s]",WIPPrtDegGrp);fflush(stdout);
																																							if(tc_strcmp(WIPPrtDegGrp,"35")==0)
																																							{
																																								if(tc_strcmp(Prevp_child_item_id,WIP_child_item_id)==0)
																																								{
																																									PrevThirtyFiveFlag =1;
																																									break;
																																								}
																																							}
																																						}
																																					}
																																					printf(" PrevThirtyFiveFlag .:[%d]\n",PrevThirtyFiveFlag);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				PrevThirtyFiveFlag =1;
																																				printf("\n Task already available: PrevThirtyFiveFlag.:[%d]\n",PrevThirtyFiveFlag);fflush(stdout);
																																			}
																																		}
																																	}
																																}
																																printf("\n V: PrevZeroTaskFlag: %d",PrevZeroTaskFlag);fflush(stdout);
																																printf("\n V: Prev16TaskFlag: %d",Prev16TaskFlag);fflush(stdout);
																																printf("\n V: PrevFiftyFlag: %d",PrevFiftyFlag);fflush(stdout);
																																printf("\n V: PrevTwentyOneFlag: %d",PrevTwentyOneFlag);fflush(stdout);
																																printf("\n V: PrevTwentySixFlag: %d",PrevTwentySixFlag);fflush(stdout);
																																printf("\n V: PrevThirtyNineFlag: %d",PrevThirtyNineFlag);fflush(stdout);
																																printf("\n V: PrevThirtyFiveFlag: %d",PrevThirtyFiveFlag);fflush(stdout);
																																if((PrevZeroTaskFlag==0)||(Prev16TaskFlag==0)||(PrevFiftyFlag==0)||(PrevTwentyOneFlag==0)||(PrevTwentySixFlag==0)||((PrevThirtyNineFlag==0)&&(PrevThirtyFiveFlag==0)))
																																{
																																	tc_strcat(errmsg,"Difference found for mentioned design group modules in Previous released and latest WIP revisions of Vehicle ");
																																	tc_strcat(errmsg,PartMstr_no);
																																	tc_strcat(errmsg," with design group ");
																																}
																																if(PrevZeroTaskFlag==0)
																																{
																																	tc_strcat(errmsg,"00,");
																																}
																																if(Prev16TaskFlag==0)
																																{
																																	tc_strcat(errmsg,"16,");
																																}
																																if(PrevFiftyFlag==0)
																																{
																																	tc_strcat(errmsg,"50,");
																																}
																																if(PrevTwentyOneFlag==0)
																																{
																																	tc_strcat(errmsg,"21,");
																																}
																																if(PrevTwentySixFlag==0)
																																{
																																	tc_strcat(errmsg,"26,");
																																}
																																if(tc_strstr(TaskPerfInfo4,DMLProj)!=NULL)
																																{
																																	if(PrevThirtyNineFlag==0)
																																	{
																																		tc_strcat(errmsg," 39,");
																																	}
																																}
																																else
																																{
																																	if(PrevThirtyFiveFlag==0)
																																	{
																																		tc_strcat(errmsg," 35,");
																																	}
																																}
																																if(tc_strstr(TaskPerfInfo1,"B3") == NULL)
																																{
																																	if(tc_strlen(errmsg) > 0)
																																	{
																																		printf("\n VC:No vehicle attached to 00 task.:[%s] errmsg %s\n",PartMstr_no,errmsg);fflush(stdout);
																																		EMH_clear_errors();
																																		EMH_store_error_s3(EMH_severity_error,PO_BASIC_VALI,"ERROR:",errmsg,".\nPlease attach same group tak and process. \nIf you want to attach task, Please get DML aborted and attach respective task and resubmit DML.");
																																		decision = EPM_nogo;
																																		return decision;
																																	}
																																}
																																break;
																															}
																														}
																														
																													}
																												}
																											}
																										}
																										for(iChild =0 ; iChild < VCChildCunt; iChild++)
																										{
																											p_child_item_id=NULL;
																											PrtDegGrp=NULL;
																											rel_sstats=NULL;
																											if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																											if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																											printf("\n Veh:GM:P48: p_child_item_id:[%s] Rel Status:[%s]", p_child_item_id,rel_sstats);fflush(stdout);
																											if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																											{
																												if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_DesignGrp",&PrtDegGrp)!=ITK_ok)PrintErrorStack();
																												printf("\n Veh:GM:P48: PrtDegGrp:[%s]",PrtDegGrp);fflush(stdout);
																												if(tc_strcmp(PrtDegGrp,"00")==0)
																												{
																													ZeroTaskFlag =1;
																													printf(" ZeroTaskFlag.:[%d]\n",ZeroTaskFlag);fflush(stdout);
																												}
																												if(tc_strcmp(PrtDegGrp,"21")==0)
																												{
																													TwentyOneFlag =1;
																													printf(" TwentyOneFlag.:[%d]\n",TwentyOneFlag);fflush(stdout);
																												}
																												if(tc_strcmp(PrtDegGrp,"50")==0)
																												{
																													FiftyFlag =1;
																													printf(" FiftyFlag.:[%d]\n",FiftyFlag);fflush(stdout);
																												}

																												if(tc_strcmp(PrtDegGrp,"26")==0)
																												{
																													TwentySixFlag =1;
																													printf(" TwentySixFlag.:[%d]\n",TwentySixFlag);fflush(stdout);
																												}
																												if(tc_strstr(TaskPerfInfo4,DMLProj)!=NULL)
																												{
																													if(tc_strcmp(PrtDegGrp,"39")==0)
																													{
																														ThirtyNineFlag =1;
																														printf(" ThirtyNineFlag.:[%d]\n",ThirtyNineFlag);fflush(stdout);
																													}
																												}
																												else
																												{
																													if(tc_strcmp(PrtDegGrp,"35")==0)
																													{
																														ThirtyFiveFlag =1;
																														printf(" ThirtyFiveFlag.:[%d]\n",ThirtyFiveFlag);fflush(stdout);
																													}
																												}

																											}
																										}

																										printf("\n Veh:V:P45:InputTaskDsgGrp:[%s] ECUMdlFlag:[%d]  ZeroTaskFlag:[%d] TwentyOneFlag:[%d] FiftyFlag:[%d] TwentySixFlag:[%d] ThirtyFiveFlag:[%d]\n",InputTaskDsgGrp,ECUMdlFlag,ZeroTaskFlag,TwentyOneFlag,FiftyFlag,TwentySixFlag,ThirtyFiveFlag);fflush(stdout);
																										if(tc_strcmp(InputTaskDsgGrp,"00")==0)
																										{
																											//All modules should be attached.
																											if ((ECUMdlFlag >0)&& (ZeroTaskFlag >0)&& (TwentyOneFlag >0)&& (FiftyFlag >0)&& (TwentySixFlag >0)&& ((ThirtyFiveFlag >0) || (ThirtyNineFlag>0)))
																											{
																												printf("\n Veh:All modules are attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																												//Now check all tasks are signed off or not.............................
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T8") == NULL)
																												{
																													if(ThirtyNineFlag>0)
																													{
																														printf("\n Veh:00/21/50/16/26/39 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"All mandatory design group module like 00,21,50,26,39 should be attached under vehicle.\n 16R ECU module should be attach to the folder- Has ECU Calibration Module. \nPlease attach it and process. ",PartMstr_no);
																														decision = EPM_nogo;
																														return decision;
																													}
																													else
																													{
																														printf("\n Veh:00/21/50/16/26/35 Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																														EMH_clear_errors();
																														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"All mandatory design group module like 00,21,50,26,35 should be attached under vehicle.\n 16R ECU module should be attach to the folder- Has ECU Calibration Module. \nPlease attach it and process. ",PartMstr_no);
																														decision = EPM_nogo;
																														return decision;
																													}
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"0E")==0)
																										{
																											//00Grp modules should be attached.
																											if (ZeroTaskFlag >0)
																											{
																												printf("\n Veh:00Grp modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T7") == NULL)
																												{
																													printf("\n Veh:00Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"00 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"21")==0)
																										{
																											//21Grp modules should be attached.
																											if (TwentyOneFlag >0)
																											{
																												printf("\n Veh:21Grp modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T6") == NULL)
																												{
																													printf("\n 21Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"21 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"50")==0)
																										{
																											//50Grp modules should be attached.
																											if (FiftyFlag >0)
																											{
																												printf("\n Veh:50Grp modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T8") == NULL)
																												{
																													printf("\n Veh:50Grp modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"50 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"16")==0)
																										{
																											//ECU modules should be attached.
																											if (ECUMdlFlag >0)
																											{
																												printf("\n Veh:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T9") == NULL)
																												{
																													printf("\n Veh:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"16R ECU module is not attached to Has ECU Calibration Module folder to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"26")==0)
																										{
																											//ECU modules should be attached.
																											if (TwentySixFlag >0)
																											{
																												printf("\n Veh:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"A1") == NULL)
																												{
																													printf("\n Veh:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"26 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"35")==0)
																										{
																											//ECU modules should be attached.
																											if (ThirtyFiveFlag >0)
																											{
																												printf("\n Veh:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"A2") == NULL)
																												{
																													printf("\n Veh:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"35 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else if(tc_strcmp(InputTaskDsgGrp,"39")==0)
																										{
																											//ECU modules should be attached.
																											if (ThirtyNineFlag >0)
																											{
																												printf("\n Veh:ECU modules is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																											}
																											else
																											{
																												if(tc_strstr(TaskPerfInfo1,"T11") == NULL)
																												{
																													printf("\n Veh:ECU modules not is attached to Vehicle.:[%s]\n",PartMstr_no);fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"39 group module is not attached to vehicle.\nPlease attach it and process. ",PartMstr_no);
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																										else
																										{
																											printf("\n Veh:Other group task bypassed...:[%s]\n",PartMstr_no);fflush(stdout);
																										}
																									}
																								}
																							}
																							if (VehAttached ==0)
																							{
																								if(tc_strstr(TaskPerfInfo1,"T3") == NULL)
																								{
																									printf("\n Veh:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																									EMH_clear_errors();
																									EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																									decision = EPM_nogo;
																									return decision;
																								}
																							}
																							else
																							{
																								if(tc_strstr(TaskPerfInfo1,"V1") == NULL)
																								{
																									if(tc_strstr(Prtrev_idd,"NR") != NULL)
																									{
																										if (((VCAttached ==0)|| (VehclAttached ==0)) && (VCCRAttached==0))
																										{
																											printf("\n Veh:No vehicle attached to 00_task...:[%s]\n",PartMstr_no);fflush(stdout);
																											EMH_clear_errors();
																											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: Either VC or Vehicle not found attached to 00 task.\nPlease attach it and process or raise to DML support team. ",PartMstr_no);
																											decision = EPM_nogo;
																											return decision;
																										}
																										else
																										{
																											printf("\n Veh:vehicle attached to 00_task or VCCR case....:[%s]\n",PartMstr_no);fflush(stdout);
																										}
																									}
																								}
																							}
																						}
																						else
																						{
																							if(tc_strstr(TaskPerfInfo1,"T2") == NULL)
																							{
																								printf("\n Veh:No vehicle attached to 00 task.:[%s]\n",PartMstr_no);fflush(stdout);
																								EMH_clear_errors();
																								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Vehicle not found attached to 00 task.\nPlease attach it and process. ",PartMstr_no);
																								decision = EPM_nogo;
																								return decision;
																							}
																						}
																					}
																				}
																			}
																		}
																	}

																	printf("\n Veh:Now checking for 00 Task sign off to ensure all other tasks are signed off.\n");fflush(stdout);
																	if(tc_strstr(TaskPerfInfo1,"S2") == NULL)
																	{
																		if(tc_strcmp(InputTaskDsgGrp,"00")==0)
																		{
																			tsk=0;
																			for (tsk=0;tsk<Tskcnt ;tsk++ )
																			{
																				TskSignoffFlag=0;
																				if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																				printf("\n V1:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);
																				if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																				{
																					if(TaskDsgGrp) TaskDsgGrp=NULL;
																					if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																					TaskDsgGrp=subString(TskNm,11,2);
																					printf("\n V2: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																					if(strcmp(TaskDsgGrp,"00")!=0)
																					{
																						//Other than 00 task.
																						if(EPM_get_current_job(Dml_tasks[tsk],&taskjob,&task_job_type)!=ITK_ok)PrintErrorStack();
																						if (taskjob != NULLTAG)
																						{
																							if(EPM_ask_root_task(taskjob,&taskroottask)!=ITK_ok)PrintErrorStack();
																							Tskcntt=0;
																							if(AOM_ask_value_tags(taskroottask,"sub_processes",&Tskcntt,&Dml_taskss)!=ITK_ok)PrintErrorStack();
																							printf("\n V3:sub_processes count:[%d].",Tskcntt);fflush(stdout);
																							if(Tskcntt >0)
																							{
																								for (kkk=0;kkk<Tskcntt;kkk++)
																								{
																									AddSolutionFound=0;
																									if(AOM_ask_value_tags(Dml_taskss[kkk],"all_tasks",&Tskcnttt,&Dml_tasksss)!=ITK_ok)PrintErrorStack();
																									printf("\n V4:All tasks form sub_processes:[%d].",Tskcnttt);fflush(stdout);
																									if(Tskcnttt >0)
																									{
																										if(tc_strstr(TaskPerfInfo1,"U1") == NULL)
																										{
																											for (kk=0;kk<Tskcnttt;kk++)
																											{
																												TskSignoffFlag=0;
																												printf("\n V5:Checking for All tasks:kk:[%d].",kk);fflush(stdout);
																												if(AOM_ask_value_string (Dml_tasksss[kk],"task_type",&SubSubtaskType)!=ITK_ok)PrintErrorStack();
																												printf("\n V6:Sub-Sub Task Type.:%s ",SubSubtaskType);fflush(stdout);
																												if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&SubSubTaskNm1)!=ITK_ok)PrintErrorStack();
																												printf(" and :SubSubTaskNm1: [%s] ",SubSubTaskNm1);
																												if((tc_strcmp(SubSubtaskType,"EPMTask")==0) && (tc_strcmp(SubSubTaskNm1,"CVBU VC Task Release")==0))
																												{
																													AddSolutionFound=1;
																													if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&tasknameofroot)!=ITK_ok)PrintErrorStack();
																													printf("\n V7:tasknameofroot: [%s] ",tasknameofroot);

																													if(AOM_ask_value_string(Dml_tasksss[kk],"object_type",&roottask_Objtype)!=ITK_ok)PrintErrorStack();
																													printf(" Object_Type: [%s] ",roottask_Objtype);fflush(stdout);

																													if(AOM_ask_value_string(Dml_tasksss[kk],"task_result",&sTask_Result)!=ITK_ok)PrintErrorStack();
																													printf(" Task Result: [%s] ",sTask_Result);fflush(stdout);
																													if(AOM_ask_value_string(Dml_tasksss[kk],"task_state",&status_root_task)!=ITK_ok)PrintErrorStack();
																													printf(" Task Status: [%s] ",status_root_task);fflush(stdout);
																													if(tc_strstr(TaskPerfInfo1,"S3") == NULL)
																													{
																														if((tc_strcmp(status_root_task,"Completed")==0)||(tc_strcmp(sTask_Result,"Completed")==0))
																														{
																															printf("\n V8:CVBU:Task Sign off not completed...:%s",TskNm);fflush(stdout);
																															TskSignoffFlag=1;
																														}
																													}
																													else if(tc_strstr(TaskPerfInfo1,"S4") == NULL)
																													{
																														//Completed
																														if((tc_strstr(TaskPerfInfo3,status_root_task) != NULL)||(tc_strstr(TaskPerfInfo3,sTask_Result) != NULL))
																														{
																															printf("\n V9:CVBU::Task Sign off completed.:%s",TskNm);fflush(stdout);
																															TskSignoffFlag=1;
																														}
																														else
																														{
																															printf("\n V10:CVBU:ERROR:Task Sign off not completed.:[%s]",TskNm);fflush(stdout);
																															TskSignoffFlag=0;
																														}
																													}
																													break;
																												}
																											}
																										}
																										else
																										{
																											//This will be lkept off later opld logic
																											for (kk=0;kk<Tskcnttt;kk++)
																											{
																												TskSignoffFlag=0;
																												printf("\n V5:Checking for All tasks:kk:[%d].",kk);fflush(stdout);
																												if(AOM_ask_value_string (Dml_tasksss[kk],"task_type",&SubSubtaskType)!=ITK_ok)PrintErrorStack();
																												printf("\n V6:Sub-Sub Task Type.:%s ",SubSubtaskType);fflush(stdout);
																												if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&SubSubTaskNm1)!=ITK_ok)PrintErrorStack();
																												printf(" and :SubSubTaskNm1: [%s] ",SubSubTaskNm1);
																												//if((tc_strcmp(taskType,"EPMDoTask")==0) && ((tc_strcmp(SubTaskNm1,"CVBU  VC Task workflow")==0)|| (tc_strcmp(SubTaskNm1,"CVBU VC Task workflow")==0)))
																												if((tc_strcmp(SubSubtaskType,"EPMDoTask")==0) && (tc_strcmp(SubSubTaskNm1,"Add solution items")==0))
																												{
																													AddSolutionFound=1;
																													if(AOM_UIF_ask_value(Dml_tasksss[kk],"object_name",&tasknameofroot)!=ITK_ok)PrintErrorStack();
																													printf("\n V7:tasknameofroot: [%s] ",tasknameofroot);

																													if(AOM_ask_value_string(Dml_tasksss[kk],"object_type",&roottask_Objtype)!=ITK_ok)PrintErrorStack();
																													printf(" Object_Type: [%s] ",roottask_Objtype);fflush(stdout);

																													if(AOM_ask_value_string(Dml_tasksss[kk],"task_state",&status_root_task)!=ITK_ok)PrintErrorStack();
																													printf(" Status: [%s] ",status_root_task);fflush(stdout);
																													if(tc_strstr(TaskPerfInfo1,"S3") == NULL)
																													{
																														if (tc_strcmp(status_root_task,"Completed")==0)
																														{
																															printf("\n V8:CVBU:Task Sign off not completed.:%s",TskNm);fflush(stdout);
																															TskSignoffFlag=1;
																														}
																													}
																													else if(tc_strstr(TaskPerfInfo1,"S4") == NULL)
																													{
																														//Completed
																														if(tc_strstr(TaskPerfInfo3,status_root_task) != NULL)
																														{
																															printf("\n V9:CVBU::Task Sign off completed.:%s",TskNm);fflush(stdout);
																															TskSignoffFlag=1;
																														}
																														else
																														{
																															printf("\n V10:CVBU:ERROR:Task Sign off not completed.:[%s]",TskNm);fflush(stdout);
																															TskSignoffFlag=0;
																														}
																													}
																													break;
																												}
																											}
																										}
																									}
																									if (AddSolutionFound >0)
																									{
																										if (TskSignoffFlag >0)
																										{
																											printf("\n V11:AddSolution assignment Found and task is completed:%s \n",TskNm);fflush(stdout);
																										}
																										else
																										{
																											printf("\n V11:AddSolution assignment Found and task is NOT completed.%s \n",TskNm);fflush(stdout);
																										}
																										break;
																									}
																								}
																							}
																							if (TskSignoffFlag ==0)
																							{
																								printf("\n V12:ERROR:VBU:Task Sign off not completed.....\n");fflush(stdout);
																								EMH_clear_errors();
																								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"All other than 00 task should be signed off first.\nPlease get other tasks signed off. ",TskNm);
																								decision = EPM_nogo;
																								return decision;
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
															else
															{
																printf("\n Veh:P20:DML proj bypassed:[%s]\n",DMLProj);fflush(stdout);
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(TaskPerfInfo1){MEM_free(TaskPerfInfo1);}
	if(TaskPerfInfo2){MEM_free(TaskPerfInfo2);}
	if(TaskPerfInfo3){MEM_free(TaskPerfInfo3);}
	if(TaskPerfInfo4){MEM_free(TaskPerfInfo4);}
	if(sDMLtaskno){MEM_free(sDMLtaskno);}
	if(sDMLno){MEM_free(sDMLno);}
	if(DMLtype){MEM_free(DMLtype);}
	if(DMLProj){MEM_free(DMLProj);}
	if(PlntToPlnt){MEM_free(PlntToPlnt);}
	if(DMLDR){MEM_free(DMLDR);}
	if(DMLBUnit){MEM_free(DMLBUnit);}
	if(DMLVert){MEM_free(DMLVert);}
	if(Tsk_object_type){MEM_free(Tsk_object_type);}
	if(Prt_object_type){MEM_free(Prt_object_type);}
	if(PartMstr_no){MEM_free(PartMstr_no);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(sPartTyp){MEM_free(sPartTyp);}
	if(p_child_item_id){MEM_free(p_child_item_id);}
	if(rel_sstats){MEM_free(rel_sstats);}
	if(TskNm){MEM_free(TskNm);}
	if(Dml_taskss){MEM_free(Dml_taskss);}
	if(SubSubtaskType){MEM_free(SubSubtaskType);}
	if(SubSubTaskNm1){MEM_free(SubSubTaskNm1);}
	if(tasknameofroot){MEM_free(tasknameofroot);}
	if(roottask_Objtype){MEM_free(roottask_Objtype);}
	if(sTask_Result){MEM_free(sTask_Result);}
	if(status_root_task){MEM_free(status_root_task);}*/
	printf("\n tm_Rule_Veh_taskSignOffRule Function end...");fflush(stdout);
	TC_write_syslog("\n tm_Rule_Veh_taskSignOffRule Function end...");
	return decision;
}