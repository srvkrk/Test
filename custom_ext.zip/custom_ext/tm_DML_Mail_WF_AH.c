/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_DML_Mail_WF_AH.c
**
**
**	Date				Author			Modification
**	01-01-2018			Mohan Tayade	Code creation
* 
* SrNo		Modified By		Date			Modification
*	1		Mohan Tayade	16 Aug 2022		Path for CV to call function for Assign dynamic participant.
***********************************************************************************************************************************************************/

#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#define PS_where_used_all_levels   -1 

static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/****************************************************************************
*   Function name			: Assign_Dynamic_party_Func
*   Description				: To set dynamic participant for dml and task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Mohan Tayade	1.30: Set dynamic participants for dml and task
*
****************************************************************************/
int tm_DML_Mail_WF_AH_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLNo			=  NULL;
	tag_t	user		= NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	int error_code = ITK_ok;
	char*	DMLReason		= NULL;
	char*	DML_BU			= NULL;
	char*	DMLType			= NULL;
	char*	ProjectID		= NULL;
	char*	sDMLrlstype		= NULL;
	char*	DMLcommand		= NULL;
	char *person_namee			= NULL;
	char*	DMLprintInfo7		= NULL;
	char*	DMLprintInfo6		= NULL;
	char*	DMLprintInfo5		= NULL;
	char*	DMLprintInfo4		= NULL;
	char*	DMLprintInfo3		= NULL;
	char*	DMLprintInfo2		= NULL;
	char*	DMLprintInfo1		= NULL;
	char*	ReqUserId		= NULL;
	tag_t	person_tagg			= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		person_tag			= NULLTAG;
	char*		person_name			= NULL;
	char*		sCCmails			= NULL;
	char*		sTOmails			= NULL;
	char		*emailID					=NULL;
	int     DR_n_entry    = 1;
	int     n_entry    = 1;
	int     DR_rsltCount      =  0;
	int     rsltCount      =  0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(100 * sizeof(char *));
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;

	printf("\n MT: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML/Task Number: [%s].", DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name(objTypTag,ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		//Control object logic:
		if(QRY_find("ControlObjects", &DRqryTag));
		if (DRqryTag)
		{
			printf("\n POCHCK:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n POCHCK:Not Found Query ControlObjects \n");fflush(stdout);
		}

		DR_qry_values2[0] = "DMLMAILD";
		if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
		printf(" \n POCHCK:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
		if(DR_rsltCount > 0)
		{
			//ONOFF
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&DMLprintInfo1)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo1 is :[%s]\n", DMLprintInfo1);fflush(stdout);
			//DML Types considered
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&DMLprintInfo2)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo2 is :[%s]\n", DMLprintInfo2);fflush(stdout);
			//Path to call shells tm_DML_Mail.sh
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&DMLprintInfo3)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo3 is :[%s]\n", DMLprintInfo3);fflush(stdout);
			//TO mail id
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&DMLprintInfo4)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo4 is :[%s]\n", DMLprintInfo4);fflush(stdout);
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&DMLprintInfo5)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo5 is :[%s]\n", DMLprintInfo5);fflush(stdout);
			sTOmails=(char *)MEM_alloc(500);
			tc_strcpy(sTOmails,"");
			if(DMLprintInfo4 !=NULL)
			{
				tc_strcpy(sTOmails,DMLprintInfo4);
			}
			if(DMLprintInfo5 !=NULL)
			{
				tc_strcat(sTOmails,DMLprintInfo5);
			}
			printf("\n CV:17:sTOmails: [%s]",sTOmails);fflush(stdout);

			//CC mail id
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&DMLprintInfo6)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo6 is :[%s]\n", DMLprintInfo6);fflush(stdout);
			if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&DMLprintInfo7)!=ITK_ok)   PrintErrorStack();
			printf("\n DMLprintInfo7 is :[%s]\n", DMLprintInfo7);fflush(stdout);
			sCCmails=(char *)MEM_alloc(500);
			tc_strcpy(sCCmails,"");
			if(DMLprintInfo6 !=NULL)
			{
				tc_strcpy(sCCmails,DMLprintInfo6);
			}
			if(DMLprintInfo7 !=NULL)
			{
				tc_strcat(sCCmails,DMLprintInfo7);
			}
			printf("\n CV:17:sCCmails: [%s]",sCCmails);fflush(stdout);

			if(strstr(DMLprintInfo1,"PRNT001")==NULL)
			{
				sDMLrlstype=(char *)MEM_alloc(20);
				DMLType=(char *)MEM_alloc(20);
				DML_BU=(char *)MEM_alloc(30);
				ProjectID=(char *)MEM_alloc(20);
				if(AOM_ask_value_string(objTag,"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(objTag,"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(objTag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(objTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(objTag,"requestor_user_id",&ReqUserId)!=ITK_ok)PrintErrorStack();
				printf("\n CV:15:DML Number: [%s] DMLType: [%s] DML_BU:[%s] ProjectID :[%s]",DMLNo,DMLType,DML_BU,ProjectID);fflush(stdout);
				printf("\n requestor_user_id Name %s",ReqUserId);fflush(stdout);
				if(strstr(DMLprintInfo1,"PRNT006")==NULL)
				{
					//if(SA_find_user2("nkp06368", &user)!=ITK_ok)PrintErrorStack();
					printf("\n quering req id...\n");fflush(stdout);
					if(SA_find_user2(ReqUserId, &user)!=ITK_ok)PrintErrorStack();
					if(AOM_load(user)!=ITK_ok)PrintErrorStack();
					if(SA_ask_user_person_name2(user, &person_namee)!=ITK_ok)PrintErrorStack();
					if(SA_find_person2 ( person_namee, &person_tagg)!=ITK_ok)PrintErrorStack();
					if(SA_ask_person_email_address ( person_tagg, &emailID )!=ITK_ok)PrintErrorStack(); 
				}
				else
				{
					if(AOM_ask_owner(objTag,&object_owner)!=ITK_ok)PrintErrorStack();
					if(SA_ask_user_person(object_owner,&person_tag)!=ITK_ok)PrintErrorStack();
					if(SA_ask_person_name2(person_tag,&person_name)!=ITK_ok)PrintErrorStack();
					printf("\nCreator Name %s",person_name);fflush(stdout);
					if(SA_find_user2(person_name, &user)!=ITK_ok)PrintErrorStack();
					//if(AOM_load(user)!=ITK_ok)PrintErrorStack();
					if(SA_ask_user_person_name2(user, &person_namee)!=ITK_ok)PrintErrorStack();
					if(SA_find_person2 ( person_namee, &person_tagg)!=ITK_ok)PrintErrorStack();
					if(SA_ask_person_email_address ( person_tagg, &emailID )!=ITK_ok)PrintErrorStack(); 
					//if(AOM_ask_value_string(person_tag,"fnd0AssigneeEmail",&emailID)!=ITK_ok)PrintErrorStack();
				}
				printf("\nMail ID of Manager:::: %s\n",emailID);fflush(stdout);
				tc_strcpy(sDMLrlstype,"");
				tc_strcpy(sDMLrlstype,",");
				tc_strcat(sDMLrlstype,DMLType);
				tc_strcat(sDMLrlstype,",");
				printf("\n CV:17:sDMLrlstype: [%s]",sDMLrlstype);fflush(stdout);
				if(tc_strstr(DMLprintInfo2,sDMLrlstype) != NULL)
				{
					DMLcommand = (char	*)MEM_alloc(500);
					if(strstr(DMLprintInfo1,"PRNT005")==NULL)
					{
						///user/uaprod/TC_ROOT12/bin/tml_tools/tm_DML_Mail.sh
						//1: DMLno 2:Creator 3: TOmailIds 4:subject 5: CCmail
						tc_strcpy(DMLcommand,"");
						tc_strcpy(DMLcommand,DMLprintInfo3);
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,DMLNo);
						tc_strcat(DMLcommand," ");
						if(emailID !=NULL)
						{
							tc_strcat(DMLcommand,emailID);
							printf("\n  User mail updated.\n");fflush(stdout);
						}
						else
						{
							tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
							printf("\n NO User mail updated.\n");fflush(stdout);
						}
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,sTOmails);
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,DMLNo);
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,sCCmails);
						printf("\n ASSIGN::DMLcommand: %s",DMLcommand);fflush(stdout);
						/*tc_strcpy(DMLcommand,"");
						tc_strcpy(DMLcommand,"/user/testcmi/Dev/devgroups/mohan/Report/tm_DML_MailD/tm_DML_MailSH.sh");
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,DMLNo);
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,DMLNo);
						tc_strcat(DMLcommand," ");
						tc_strcat(DMLcommand,"as925914.ttl@tatamotors.com");
						printf("\n ASSIGN::DMLcommand: %s",DMLcommand);fflush(stdout);*/
						//sprintf(DMLcommand,"/user/uaprod/shells/DMLWF/tm_DML_Mail.sh %s ",DMLNo);
						TC_write_syslog("DMLcommand = %s\n",DMLcommand);
						system(DMLcommand);
						printf("\n ASSIGN:A:Reviewers set successfully.. \n");fflush(stdout);
					}
					else if(strstr(DMLprintInfo1,"PRNT002")==NULL)
					{
						sprintf(DMLcommand,"/user/uaprod/TC_ROOT12/bin/tml_tools/tm_DML_Mail.sh %s ",DMLNo);
						TC_write_syslog("Command = %s\n",DMLcommand);
						system(DMLcommand);

					}
					else if(strstr(DMLprintInfo1,"PRNT003")==NULL)
					{
						sprintf(DMLcommand,"/user/testcmi/Dev/devgroups/mohan/Report/tm_DML_Mail_AH/tm_DML_Mail.sh %s ",DMLNo);
						TC_write_syslog("Command = %s\n",DMLcommand);
						system(DMLcommand);
					}
					else if(strstr(DMLprintInfo1,"PRNT004")==NULL)
					{
						sprintf(DMLcommand,"/home/uadev/devgroups/mohan/test/tm_DML_Mail.sh %s ",DMLNo);
						TC_write_syslog("Command = %s\n",DMLcommand);
						system(DMLcommand);
					}
					else
					{
						printf("\n POCHCK:Other client.. \n");fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}

int tm_DML_Mail_WF_AH_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{
		//Assign BOM/CE/Peer/DMU reviewer
		retcode = EPM_register_action_handler (
								"tm_DML_Mail_WF_AH",
								"tm_DML_Mail_WF_AH",
								(EPM_action_handler_t)tm_DML_Mail_WF_AH_Func
								);
		printf("\n at the end.....\n");fflush(stdout);
	}
	return retcode;
}

extern int tm_DML_Mail_WF_AH_action(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	

	printf("\n before .... ");fflush(stdout);
	status = tm_DML_Mail_WF_AH_register_action_handlers();
	printf("\n after ..... ");fflush(stdout);
	return status;
}

extern DLLAPI int tm_DML_Mail_WF_AH_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n\n before calling ..\n");
    ifail=CUSTOM_register_exit("tm_DML_Mail_WF_AH","USER_init_module",(CUSTOM_EXIT_ftn_t)tm_DML_Mail_WF_AH_action);
	printf("\n\n after calling ...\n");
	
    return ( ITK_ok );
}
