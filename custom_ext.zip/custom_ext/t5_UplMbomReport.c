/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       t5_UplMbom.c
*
* Description   : > This register custom user service. Implemented Custom ITK functions for generating UPLMBOM Object and Reports.
*                                 > This ITK functions are called in Rich Client
* Module
* Since             :   28-11-2022
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 22/11/2022     Sandeep Goyal/Abineswar Bisoi                      Base Code
* 25/12/2023     Abineshwar Bisoi 

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

/* Global Declaration of Attribute required for UPL Report Generation*/
char*       objName            = NULL;
char*       objDesc            = NULL;
char*       objRev             = NULL;
char*       objItemRev         = NULL;
char*       objPrtNumber       = NULL;
char*       objPrtRev          = NULL;
char*       objPrtSeq          = NULL;
char*       objUplPlant        = NULL;
char*       objUplAgency       = NULL;
char*       objUplUser         = NULL;
logical     objIsMassopReq     = false;
logical     objIsEPAReq        = false;
logical     objIsSORReq        = false;
logical     objIsERCRlzReq     = false;
logical     objIsVCCmprReq     = false;
char*       objFirstBaseVC     = NULL;
char*       objSecondBaseVC    = NULL;
char*       objThirdBaseVC     = NULL;
FILE*       fpLogFile          = NULL;
char*       timestamp          = NULL;
tag_t       SetOfParts[10000];
int         PartIndex          =   0;
char*       BomGenMakeBuyInd   =   NULL;
char*       GenMakeBuyInd      =   NULL;
char*       GenPlantLCState    =   NULL;
char*       GenPlantLCStateStd =   NULL;
char*       getPlantStore      =   NULL;
char*       ClosureRule        =   NULL;
char*       ClosureRev         =   NULL;
int         GrpPartFlag        =   0;
int         GrpPartLevel       =   0;
char*       SetOfBaseVC1       =   NULL;
char*       SetOfBaseVC2       =   NULL;
char*       SetOfBaseVC3       =   NULL;
char*       BaseVC1            =   NULL;
char*       BaseVC2            =   NULL;
char*       BaseVC3            =   NULL;
/*Declaration Completed for UPL/MBOM Object*/

const char *attrs[1];
const char *values[1];


int UplMbomReportFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;

    char                    *UplPartNumber                          =       NULL;
    char                    *UplPartRev                             =       NULL;
    char                    *UplPartSeq                             =       NULL;
    char                    *UplPlantName                           =       NULL;
    char                    *UplBomView                             =       NULL;
    char                    *UplCreator                             =       NULL;
    char                    *UplCreationDate                        =       NULL;
    char                    *UplIsMaspReq                           =       NULL;
    char                    *UplIsEpaReq                            =       NULL;
    char                    *UplIsSorReq                            =       NULL;
    char                    *UplIsErcRlzDtReq                       =       NULL;
    char                    *UplIsVcCompReq                         =       NULL;
    char                    *UplBaseVc1                             =       NULL;
    char                    *UplBaseVc2                             =       NULL;
    char                    *UplBaseVc3                             =       NULL;
    char                    *UserRequestId                          =       NULL;
    char                    *ItemRev                                =       NULL;
    tag_t                   ObTag                                   =       NULLTAG;
    tag_t                   ObTagRev                                =       NULLTAG;
    tag_t                   createInputTag                          =       NULLTAG;
    tag_t                   createInputTagRev                       =       NULLTAG;
    tag_t                   objectTag                               =       NULLTAG;
    char**                  stringArrayUplInput                     =       NULL;
    char**                  stringArrUplInput                       =       NULL;
    int                     n_strings                               =       1;
    int                     l_strings                               =       300;
    int                     index                                   =       0;
    char*                   tempString                              =       NULL;
	char*                   LineItem                                =       NULL;
	int                     SysReturn                               =       0;
	
 
    printf("\n I am in main program");fflush(stdout);


    USERARG_get_string_argument(&UplPartNumber);
    printf("\n I am in main program");fflush(stdout);
    USERARG_get_string_argument(&UplPartRev);
    USERARG_get_string_argument(&UplPartSeq);
    USERARG_get_string_argument(&UplPlantName);
    USERARG_get_string_argument(&UplBomView);
    USERARG_get_string_argument(&UplCreator);
    USERARG_get_string_argument(&UplCreationDate);
    USERARG_get_string_argument(&UplIsMaspReq);
    USERARG_get_string_argument(&UplIsEpaReq);
    USERARG_get_string_argument(&UplIsSorReq);
    USERARG_get_string_argument(&UplIsErcRlzDtReq);
    USERARG_get_string_argument(&UplIsVcCompReq);
    printf("\n I am in main program");fflush(stdout);
    USERARG_get_string_argument(&UplBaseVc1);
    USERARG_get_string_argument(&UplBaseVc2);
    USERARG_get_string_argument(&UplBaseVc3);
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n InputUplPartNumber :: %s ",UplPartNumber);fflush(stdout);
    printf("\n InputUplPartRev :: %s ",UplPartRev);fflush(stdout);
    printf("\n InputUplPartSeq :: %s ",UplPartSeq);fflush(stdout);
    printf("\n InputUplPlantName :: %s ",UplPlantName);fflush(stdout);
    printf("\n InputUplBomView :: %s ",UplBomView);fflush(stdout);
    printf("\n InputUplCreator :: %s ",UplCreator);fflush(stdout);
    printf("\n InputUplIsMaspReq :: %s ",UplIsMaspReq);fflush(stdout);
    printf("\n InputUplCreationDate :: %s ",UplCreationDate);fflush(stdout);
    printf("\n InputUplIsMaspReq :: %s ",UplIsMaspReq);fflush(stdout);
    printf("\n InputUplIsEpaReq :: %s ",UplIsEpaReq);fflush(stdout);
    printf("\n InputUplIsSorReq :: %s ",UplIsSorReq);fflush(stdout);
    printf("\n InputUplIsErcRlzDtReq :: %s ",UplIsErcRlzDtReq);fflush(stdout);
    printf("\n InputUplIsVcCompReq :: %s ",UplIsVcCompReq);fflush(stdout);
    printf("\n InputUplBaseVc1 :: %s ",UplBaseVc1);fflush(stdout);
    printf("\n InputUplBaseVc2 :: %s ",UplBaseVc2);fflush(stdout);
    printf("\n InputUplBaseVc3 :: %s ",UplBaseVc3);fflush(stdout);
	
	LineItem	             =(char *) MEM_alloc(1000);
	strcpy(LineItem,"/user/cvprod/shells/STD/UPLCCDyPath.sh");
	strcat(LineItem," ");
	strcat(LineItem,UplPartNumber);
	strcat(LineItem," ");
	strcat(LineItem,UplPartRev);
	strcat(LineItem," ");
	strcat(LineItem,UplPartSeq);
	strcat(LineItem," ");
	strcat(LineItem,UplPlantName);
	strcat(LineItem," ");
	strcat(LineItem,UplBomView);
	strcat(LineItem," ");
	strcat(LineItem,UplCreator);
	strcat(LineItem," ");
	strcat(LineItem,UplCreationDate);
	strcat(LineItem," ");
	strcat(LineItem,UplIsMaspReq);
	strcat(LineItem," ");
	strcat(LineItem,UplIsEpaReq);
	strcat(LineItem," ");
	strcat(LineItem,UplIsSorReq);
	strcat(LineItem," ");
	strcat(LineItem,UplIsErcRlzDtReq);
	strcat(LineItem," ");
	strcat(LineItem,UplIsVcCompReq);
	strcat(LineItem," ");
	strcat(LineItem,UplBaseVc1);
	strcat(LineItem," ");
	strcat(LineItem,UplBaseVc2);
	strcat(LineItem," ");
	strcat(LineItem,UplBaseVc3);
	SysReturn = system(LineItem);
	
    return ifail;
}



extern int UPLMbomUserServiceFnUplMbomReportFn()
{
    int ifail = ITK_ok;
    int nargs = 15;
    int retValueType;
    int inputArgTypes[15] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //PartNumber
    inputArgTypes[1] = USERARG_STRING_TYPE; //PartRev
    inputArgTypes[2] = USERARG_STRING_TYPE; //PartSeq
    inputArgTypes[3] = USERARG_STRING_TYPE; //PlantName
    inputArgTypes[4] = USERARG_STRING_TYPE; //View
    inputArgTypes[5] = USERARG_STRING_TYPE; //CreationUser
    inputArgTypes[6] = USERARG_STRING_TYPE; //CreationDate
    inputArgTypes[7] = USERARG_STRING_TYPE; //IsMassopRequired
    inputArgTypes[8] = USERARG_STRING_TYPE; //IsEPAInfoRequired
    inputArgTypes[9] = USERARG_STRING_TYPE; //IsSORInfoRequired
    inputArgTypes[10] = USERARG_STRING_TYPE; //IsERCReleaseDateRequired
    inputArgTypes[11] = USERARG_STRING_TYPE; //IsVCComparisionRequired
    inputArgTypes[12] = USERARG_STRING_TYPE; //BaseVC1
    inputArgTypes[13] = USERARG_STRING_TYPE; //BaseVC2
    inputArgTypes[14] = USERARG_STRING_TYPE; //BaseVC3
    //inputArgTypes[15] = USERARG_STRING_TYPE; //User Request ID

    retValueType = USERARG_STRING_TYPE ;
    printf("\n UPLMbomUserServiceFnUplMbomReportFn before....UplMbomReportFuncsvr");fflush(stdout);
    ifail=USERSERVICE_register_method("UplMbomReportFuncsvr",(USER_function_t)UplMbomReportFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceFnUplMbomRptFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(UPLMbomUserServiceFnUplMbomReportFn());

    return ifail;
}

extern DLLAPI int t5_UplMbomReport_register_callbacks ()
{

    int ifail    = ITK_ok;
    printf("\n Before registering userservice....tm_UplMbomReport");fflush(stdout);
    ifail = CUSTOM_register_exit("t5_UplMbomReport", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnUplMbomRptFn);
    printf("\n After registering userservice....tm_UplMbomReport");fflush(stdout);
    return(ITK_ok);
}

