#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include "tm_apl_std_common_function.c"

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;


//#define ITK_CALL 	 \
//status=X; 	 \
//if (status != ITK_ok)  	 \
//{	 \
//int	 index = 0;	 \
//int	 n_ifails = 0;	 \
//const int*	 severities = 0;	 \
//const int*	 ifails = 0;	 \
//const char**	texts = NULL;	 \
//\
//EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
//printf("%3d error with #X\n", n_ifails);	 \
//for( index=0; index<n_ifails; index++)	 \
//{	 \
//printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//}	 \
//return status;	 \
//}	 \
//;

/*
deprecated api changes 14.3 (sachin)
CR_create_release_status2-->RELSTAT_create_release_status
BOM_line_ask_attribute_string--> AOM_UIF_ask_value
BOM_line_ask_attribute_tag --> AOM_ask_value_tag
BOM_line_look_up_attribute --> AOM_UIF_ask_value
BOM_line_set_attribute_string --> AOM_UIF_set_value

*/

void setAddStrSTDSI(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int AssignSTDGrpHeadReviewer(tag_t APLTaskRevT,char* Proj_Code)
{
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			rolename = NULL;
	char*			userid = NULL;
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;


	printf("\n Inside AssignSTDGrpHeadReviewer  \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	printf("\n\n\t\t SMDML DML Cre:AssignSTDGrpHeadReviewer:Task_no  is :%s",Task_no);	fflush(stdout);
	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	//****************************TZ1.46****************************************//

			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="SMStateInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
					{
						CALLAPI(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo4", &PltCodeFrmCntrl));
						printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
						tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
					}
			}
			else
			{
				tc_strcpy(PLT_CodeS,"PUNE");
			}
			printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				 printf("\n Dsgn_No [%s]\n",Dsgn_No);
				//if(strstr(rolename,"STD") && strstr(rolename,"HEAD") && strstr(rolename,"SM"))
					
				 printf("\n Before going to STDC reviewer as per role base \n ",rolename); //Added by Anita
				if(strstr(rolename,"STD") && strstr(rolename,"HEAD") && strstr(rolename,"SM") ||(strstr(rolename, "STDC") && strstr(rolename, "_Reviewer"))|| (strstr(rolename, "STDA") && strstr(rolename, "_Reviewer"))) //Added by Anita
				{
					
					printf("\n After going STDC reviewer as per role base \n ",rolename);  //Added by Anita
					 
					printf("\nMatch Found\n");
					flgRoleFnd=true;
					if (flgRoleFnd==true)
					{
						role_tag = role_tags[i];
						CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);
						if(num_of_members>0)
						{
							for (j=0;j<num_of_members ;j++  )
							{
								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);
								TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
								GRM_find_relation_type("HasParticipant", &relation_type);
								GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
								GRM_save_relation(relation);
								printf("\n TestParticipent Assigned..DoneXXXX\n");
							}
						}
					}
					break;
				}  // Roll matches
		}

	}
	return ITK_ok;

}



static int t5UpdateLifecycleStateSTDDML(tag_t object_tag, char* lifecycleStateName)
{

	
	tag_t		class_id				=     NULLTAG;
	char *class_name = NULL;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	int              st_count1 = 0;
	tag_t*    status_list1=NULLTAG;
	logical		log1;
	int n_values_checkin = 0;
	int cunt1 = 0;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	char *Release_Status = NULL;
	int				ifail=0;
    int flag = 0;
	
	
	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);


	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
			printf("\n  Release_Status changes done: for workspaceobject     %s,lifecycleStateName : %s\n", Release_Status,lifecycleStateName);fflush(stdout);

			if(tc_strcmp(lifecycleStateName,Release_Status)==0)
            {
				CALLAPI(POM_unload_instances (1,&object_tag));
				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
				CALLAPI(POM_is_loaded(object_tag,&log1));

				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				if(tc_strcmp(class_name,"T5_SMDMLRevision")!=0)
				{
				
					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save_without_extensions(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));
					CALLAPI(AOM_unlock(object_tag));
				}


			
			}
		}
	}
return 0;

}


int sm_dml_claim( EPM_action_message_t msg )
{
	
	int		status;
	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int	  noAttachment	= 0;
   	tag_t DMLTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char*   type_name = NULL;
	char*			item_id			= NULL;
	char*			DML_no			= NULL;
	char*			DML_Num			= NULL;
	char*			PLT_Code			= NULL;
	char*			lcsToset			= NULL;
	char*			lcsTosetR			= NULL;
	char*			lcsTosetRel			= NULL;
	char*			TASK_Code			= NULL;
	char*			object_type			= NULL;
	char*			task_item_id		= NULL;
	char*			task_no				= NULL;
	int              st_count1 = 0;
	tag_t   status2=NULLTAG;
	tag_t   taskstatus2=NULLTAG;
	char   *ReleaseStatus=NULL;
	char   *taskReleaseStatus=NULL;
	logical retain=false;
	logical taskretain=false;
	int				index				= 0;
	int				count				= 0;
	int				l_strings			= 80;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	int   TaskCnt				= 0;
	int   task_st_count1				= 0;
	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	tag_t*    status_list1=NULLTAG;
	tag_t*    task_status_list1=NULLTAG;
	int	error_code	= ITK_ok;
	tag_t	relation_type= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetRel =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n **************inside sm_dml_claim***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n sm_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask in SMDML flow :%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name in SMDML flow  :%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment in SMDML flow  :%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		printf("111DMLTag");fflush(stdout);
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
		printf("22DMLTag");fflush(stdout);
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n    in SMDML flow  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_SMDMLRevision")==0)
	{
		    printf("\n inside class T5_SMDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);

			DML_Num=tc_strtok(DML_no,"_");
			printf("\n SMDML..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

			
			get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);

			strcpy(lcsToset,StdWrkngLC);
			strcpy(lcsTosetR,StdResLC);
			strcpy(lcsTosetRel,StdRelLC);

			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
			if(st_count1==0)
			{
				CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			
			}

			if (DMLTag != NULLTAG)
			{
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
				
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					TaskRevTag = TaskRevision[TaskCnt];
					
					CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
					printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
					
					if(strcmp(object_type,"T5_SMDMLTaskRevision")==0)
					{
						printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
						AOM_ask_value_string( TaskRevTag, "item_id", &task_item_id);
						AOM_ask_value_string( TaskRevTag, "current_id", &task_no);
						printf("\n\n\t\t task_item_id is :%s",task_item_id);fflush(stdout);
						
						ITKCALL(WSOM_ask_release_status_list(TaskRevTag,&task_st_count1,&task_status_list1));
						printf("\n task_st_count1 :%d is\n",task_st_count1);fflush(stdout);
						if(task_st_count1==0)
						{
							CALLAPI(RELSTAT_create_release_status(lcsToset,&taskstatus2));
							CALLAPI(AOM_ask_name(taskstatus2, &taskReleaseStatus));
							printf("\n *******************task ReleaseStatus: %s\n",taskReleaseStatus);fflush(stdout);
							CALLAPI(RELSTAT_add_release_status(taskstatus2,1,&TaskRevTag,taskretain));						
						}
					}
				}

		}
	}
	
	return error_code;
}

int sm_dml_restructred( EPM_action_message_t msg )
{
	
	int		status;
	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int	  noAttachment	= 0;
   	tag_t DMLTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char*   type_name = NULL;
	char*			item_id			= NULL;
	char*			DML_no			= NULL;
	char*			DML_Num			= NULL;
	char*			PLT_Code			= NULL;
	char*			lcsToset			= NULL;
	char*			lcsTosetR			= NULL;
	char*			lcsTosetRel			= NULL;
	char*			lcsTosetResRel			= NULL;
	char*			TASK_Code			= NULL;
	char*			task_item_id			= NULL;
	char*			task_no			= NULL;
	int              st_count1 = 0;
	tag_t   status2=NULLTAG;
	char   *ReleaseStatus=NULL;
	char   *object_type=NULL;
	logical retain=false;
	int				index				= 0;
	int				l_strings			= 80;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	int   cnt				= 0;
	int   count				= 0;
	int   TaskCnt				= 0;
	int   DMLFlag				= 0;
	int   RestDMLFlag				= 0;
	int   ReRestDMLFlag				= 0;
	int   DMLFlag1				= 0;
	int   RestDMLFlag1				= 0;
	int   ReRestDMLFlag1				= 0;
	int   task_st_count1				= 0;
	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	tag_t*    status_list1=NULLTAG;
	int	error_code	= ITK_ok;
	char *WSO_Name = NULL;

	tag_t*    task_status_list1=NULLTAG;
	tag_t	relation_type= NULLTAG;
	tag_t*			DMLRevision		= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	char cCurrentAccessDate[20]={0};
	date_t Release_date;

	printf("\n **************inside sm_dml_restructred***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetRel =(char *) MEM_alloc(20 * sizeof(char *));//Hemal
	lcsTosetResRel =(char *) MEM_alloc(20 * sizeof(char *));//Hemal



	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n sm_dml_restructred \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask in SMDML flow :%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name in SMDML flow  :%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment in SMDML flow  :%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n    in SMDML flow  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_SMDMLTaskRevision")==0)
	{
		    printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);

			DML_Num=tc_strtok(DML_no,"_");
			printf("\n SMDML..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			TASK_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",PLT_Code,DML_no);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

			
			get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);

			strcpy(lcsToset,StdWrkngLC);
			strcpy(lcsTosetR,StdResLC);
			strcpy(lcsTosetRel,StdRelLC);
			strcpy(lcsTosetResRel,stdReRestLcsR);

			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,lcsToset)==0)
							{
								DMLFlag = 1;
								
							}

							if (tc_strcmp(WSO_Name,lcsTosetR)==0)
							{
								RestDMLFlag = 1;
								
							}

							if (tc_strcmp(WSO_Name,lcsTosetResRel)==0)
							{
								ReRestDMLFlag = 1;
								
							}
						}
				}
			}

			printf("\n RestDMLFlag is :%d ,DMLFlag %d \n",RestDMLFlag,DMLFlag);fflush(stdout);

			if(DMLFlag==1)
			{
				t5UpdateLifecycleStateSTDDML(DMLTag,lcsToset);
			}
			if(RestDMLFlag==1 && 0 == DMLFlag);
			{
				t5UpdateLifecycleStateSTDDML(DMLTag,lcsTosetR);
			}
			if(ReRestDMLFlag==1 && 0 == DMLFlag);
			{
				t5UpdateLifecycleStateSTDDML(DMLTag,lcsTosetResRel);
			}
				
			if((RestDMLFlag==0) && (ReRestDMLFlag==0))
			{
				CALLAPI(RELSTAT_create_release_status(lcsTosetR,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}
			if(RestDMLFlag==1||ReRestDMLFlag ==1)
			{
				CALLAPI(RELSTAT_create_release_status(lcsTosetResRel,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}

			if (DMLTag != NULLTAG)
			{
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				CALLAPI(GRM_list_primary_objects_only(DMLTag,relation_type,&count,&DMLRevision));
				
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					DMLRevTag = DMLRevision[TaskCnt];
					
					CALLAPI(AOM_ask_value_string(DMLRevTag,"object_type",&object_type));
					printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
					
					if(strcmp(object_type,"T5_SMDMLRevision")==0)
					{
						printf("\n inside class T5_SMDMLRevision......\n");fflush(stdout);
						AOM_ask_value_string( DMLRevTag, "item_id", &task_item_id);
						AOM_ask_value_string( DMLRevTag, "current_id", &task_no);
						printf("\n\n\t\t task_item_id is :%s",task_item_id);fflush(stdout);
						
						ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&task_st_count1,&task_status_list1));
						printf("\n task_st_count1 :%d is\n",task_st_count1);fflush(stdout);
						if(task_st_count1>0)
						{
							for (cnt=0;cnt< task_st_count1;cnt++ )
							{
								WSO_Name=NULL;
								ITKCALL(AOM_ask_name(task_status_list1[cnt],&WSO_Name));
								printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
								if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,lcsToset)==0)
									{
										DMLFlag1 = 1;
										
									}

									if (tc_strcmp(WSO_Name,lcsTosetR)==0)
									{
										RestDMLFlag1 = 1;
										
									}

									if (tc_strcmp(WSO_Name,lcsTosetResRel)==0)
									{
										ReRestDMLFlag1 = 1;
										
									}
								}
							}						
						}

						printf("\n RestDMLFlag1 is :%d ,DMLFlag1 %d ,ReRestDMLFlag1 %d\n",RestDMLFlag1,DMLFlag1,ReRestDMLFlag1);fflush(stdout);
						
						if(DMLFlag1==1)
						{
							t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsToset);
						}
						
						if(RestDMLFlag1==1)
						{
							t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsTosetR);
						}
						
						if(ReRestDMLFlag1==1)
						{
							t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsTosetResRel);
						}
							
						if((RestDMLFlag1==0) && (ReRestDMLFlag1==0) )
						{

							
							CALLAPI(RELSTAT_create_release_status(lcsTosetR,&status2));
							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
							printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
							CALLAPI(RELSTAT_add_release_status(status2,1,&DMLRevTag,retain));

							
							
						}
						
						if((RestDMLFlag1==1) || ReRestDMLFlag1==1)
						{
							CALLAPI(RELSTAT_create_release_status(lcsTosetResRel,&status2));
							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
							printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
							CALLAPI(RELSTAT_add_release_status(status2,1,&DMLRevTag,retain));
						}

						
						
						getCurrentDateTime(cCurrentAccessDate);
						printf("\n 111 cCurrentAccessDate:%s",cCurrentAccessDate);
						CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
						CALLAPI(AOM_lock(DMLRevTag));
						CALLAPI(AOM_set_value_date(DMLRevTag,"t5_RescTimeStamp",Release_date));
						CALLAPI(AOM_save_without_extensions(DMLRevTag));
						CALLAPI(AOM_unlock(DMLRevTag));
						
						

					}
				}

		}
		

	}

	return error_code;
}

int sm_dml_re_restructred( EPM_action_message_t msg )
{
	
	int		status;
	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int	  noAttachment	= 0;
   	tag_t DMLTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char*   type_name = NULL;
	char*			item_id			= NULL;
	char*			DML_no			= NULL;
	char*			DML_Num			= NULL;
	char*			PLT_Code			= NULL;
	char*			lcsToset			= NULL;
	char*			lcsTosetR			= NULL;
	char*			lcsTosetRel			= NULL;
	char*			TASK_Code			= NULL;
	char*			task_item_id			= NULL;
	char*			task_no			= NULL;
	int              st_count1 = 0;
	tag_t   status2=NULLTAG;
	char   *ReleaseStatus=NULL;
	char   *object_type=NULL;
	logical retain=false;
	int				index				= 0;
	int				l_strings			= 80;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	int   cnt				= 0;
	int   count				= 0;
	int   TaskCnt				= 0;
	int   DMLFlag				= 0;
	int   RestDMLFlag				= 0;
	int   DMLFlag1				= 0;
	int   RestDMLFlag1				= 0;
	int   task_st_count1				= 0;
	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	tag_t*    status_list1=NULLTAG;
	int	error_code	= ITK_ok;
	char *WSO_Name = NULL;

	tag_t*    task_status_list1=NULLTAG;
	tag_t	relation_type= NULLTAG;
	tag_t*			DMLRevision		= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	char cCurrentAccessDate[20]={0};
	date_t Release_date;

	printf("\n **************inside sm_dml_re_restructred***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetRel =(char *) MEM_alloc(20 * sizeof(char *));//Hemal



	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n sm_dml_re_restructred \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask in SMDML flow :%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name in SMDML flow  :%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment in SMDML flow  :%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n    in SMDML flow  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_SMDMLTaskRevision")==0)
	{
		    printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);

			DML_Num=tc_strtok(DML_no,"_");
			printf("\n SMDML..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			TASK_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",PLT_Code,DML_no);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

			
			get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);

			strcpy(lcsToset,StdResLC);
			strcpy(lcsTosetR,stdReRestLcsR);

			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,lcsToset)==0)
							{
								DMLFlag = 1;
								
							}

							if (tc_strcmp(WSO_Name,lcsTosetR)==0)
							{
								RestDMLFlag = 1;
								
							}
						}
				}
			}

			printf("\n RestDMLFlag is :%d ,DMLFlag %d \n",RestDMLFlag,DMLFlag);fflush(stdout);

			if(DMLFlag==1)
			{
				//t5UpdateLifecycleStateSTDDML(DMLTag,lcsToset);
			}
				
			//if(RestDMLFlag==0)
			//{
			//	CALLAPI(RELSTAT_create_release_status(lcsTosetR,&status2));
			//	CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
			//	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
			//	CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			//
			//}
			CALLAPI(AOM_lock(DMLTag));
			CALLAPI(AOM_set_value_string(DMLTag, "t5_POCheckStatus", ""));
			CALLAPI(AOM_save_without_extensions(DMLTag));
			CALLAPI(AOM_unlock(DMLTag));

			if (DMLTag != NULLTAG)
			{
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				CALLAPI(GRM_list_primary_objects_only(DMLTag,relation_type,&count,&DMLRevision));
				
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					DMLRevTag = DMLRevision[TaskCnt];
					
					CALLAPI(AOM_ask_value_string(DMLRevTag,"object_type",&object_type));
					printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
					
					if(strcmp(object_type,"T5_SMDMLRevision")==0)
					{
						printf("\n inside class T5_SMDMLRevision......\n");fflush(stdout);
						AOM_ask_value_string( DMLRevTag, "item_id", &task_item_id);
						AOM_ask_value_string( DMLRevTag, "current_id", &task_no);
						printf("\n\n\t\t task_item_id is :%s",task_item_id);fflush(stdout);
						
						ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&task_st_count1,&task_status_list1));
						printf("\n task_st_count1 :%d is\n",task_st_count1);fflush(stdout);
						if(task_st_count1>0)
						{
							for (cnt=0;cnt< task_st_count1;cnt++ )
							{
								WSO_Name=NULL;
								ITKCALL(AOM_ask_name(task_status_list1[cnt],&WSO_Name));
								printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
								if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,lcsToset)==0)
									{
										DMLFlag1 = 1;
										
									}

									if (tc_strcmp(WSO_Name,lcsTosetR)==0)
									{
										RestDMLFlag1 = 1;
										
									}
								}
							}						
						}

						printf("\n RestDMLFlag is :%d ,DMLFlag %d \n",RestDMLFlag,DMLFlag);fflush(stdout);


						//if(DMLFlag1==1)
						//{
						//	t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsToset);
						//}

						//if(RestDMLFlag1==0)
						//{
						//	CALLAPI(RELSTAT_create_release_status(lcsTosetR,&status2));
						//	CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						//	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
						//	CALLAPI(RELSTAT_add_release_status(status2,1,&DMLRevTag,retain));
						//}

					}
				}

		}
		

	}

	return error_code;
}

int sm_dml_released( EPM_action_message_t msg )
{
	
	int		status;
	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	int	  noAttachment	= 0;
   	tag_t DMLTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char*   type_name = NULL;
	char*			item_id			= NULL;
	char*			DML_no			= NULL;
	char*			DML_Num			= NULL;
	char*			PLT_Code			= NULL;
	char*			lcsToset			= NULL;
	char*			lcsTosetR			= NULL;
	char*			lcsTosetRel			= NULL;
	char*			lcsTosetReRel			= NULL;
	char*			TASK_Code			= NULL;
	char*			task_item_id			= NULL;
	char*			task_no			= NULL;
	int              st_count1 = 0;
	tag_t   status2=NULLTAG;
	char   *ReleaseStatus=NULL;
	char   *object_type=NULL;
	logical retain=false;
	int				index				= 0;
	int				l_strings			= 80;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	int   cnt				= 0;
	int   count				= 0;
	int   TaskCnt				= 0;
	int   DMLFlag				= 0;
	int   RestDMLFlag				= 0;
	int   RestReDMLFlag				= 0;
	int   RestReDMLFlag1				= 0;
	int   DMLFlag1				= 0;
	int   RestDMLFlag1				= 0;
	int   task_st_count1				= 0;
	int   smPrtCnt				= 0;
	int   SMPartCnt				= 0;
	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	tag_t*    status_list1=NULLTAG;
	int	error_code	= ITK_ok;
	char *WSO_Name = NULL;
	int 	n_values_bvr=0;
	int 	attribute_itemid=0;

	tag_t*    task_status_list1=NULLTAG;
	tag_t	relation_type= NULLTAG;
	tag_t*			DMLRevision		= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t*			SMPartTags			= NULLTAG;
	tag_t			SMAssyTag				= NULLTAG;
	tag_t			*bvr_assy_part= NULLTAG;
    int flagBVR=0;
    int assbvr=0;
    int nClhd=0;
	char *view_name=NULL;
	//char *ViewBVR=NULL;
	char *value_invalRel=NULL;
	char *value_valRel=NULL;
	char *value_flag=NULL;
	char *value_itemid=NULL;
	tag_t			bvrchild						= NULLTAG;

	tag_t DMLRevTag = NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t *occsal;

	char cCurrentAccessDate[20]={0};
	char*			viewTok					=NULL;
	char*			partTok					=NULL;
	char*			value_itemRevID					=NULL;
	int			attribute_invalRel					=0;
	int			attribute_vlaRel					=0;
	int			attribute_flag					=0;
	int n_occs=0,ck=0,iy=0;
	tag_t	window 				= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t  *children;
	tag_t Bomline_tag = NULLTAG;
	tag_t			ChildItem						= NULLTAG;
	char			*dataset_name1				= NULL;
	char			*dataset_invalidRel				= NULL;
	char			*dataset_flag				= NULL;
	char			*ParentItemName				= NULL;
	char			*ParentItemRevID				= NULL;
	int iChildItemTag=0;
	tag_t   t_ChildItemRev;

	date_t Release_date;
	tag_t  DMLClosureDtAttrId = NULLTAG;
	char *SmDmlTyp =NULL; //sanket
	
	printf("\n **************inside sm_dml_released***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetRel =(char *) MEM_alloc(20 * sizeof(char *));//Hemal
	lcsTosetReRel =(char *) MEM_alloc(20 * sizeof(char *));//Hemal



	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n sm_dml_released \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask in SMDML flow :%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name in SMDML flow  :%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment in SMDML flow  :%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n    in SMDML flow  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_SMDMLTaskRevision")==0)
	{
		    printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);

			DML_Num=tc_strtok(DML_no,"_");
			printf("\n SMDML..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			TASK_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",DML_Num,TASK_Code);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n SMDMLPLT_Code:[%s],[%s]\n",TASK_Code,PLT_Code);

			
			get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);//TZ1.46//Priti

			strcpy(lcsToset,StdWrkngLC);
			strcpy(lcsTosetR,StdResLC);
			strcpy(lcsTosetRel,StdRelLC);
			strcpy(lcsTosetReRel,stdReRestLcsR);

			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,lcsTosetR)==0)
							{
								DMLFlag = 1;
								
							}

							if (tc_strcmp(WSO_Name,lcsTosetRel)==0)
							{
								RestDMLFlag = 1;
								
							}
							if (tc_strcmp(WSO_Name,lcsTosetReRel)==0)
							{
								RestReDMLFlag = 1;
								
							}

							
						}
				}
			}

			printf("\n RestDMLFlag is :%d ,DMLFlag %d \n",RestDMLFlag,DMLFlag);fflush(stdout);

			if(DMLFlag==1)
			{
				t5UpdateLifecycleStateSTDDML(DMLTag,lcsTosetR);
			}

			if(RestReDMLFlag==1)
			{
				t5UpdateLifecycleStateSTDDML(DMLTag,lcsTosetReRel);
			}
				
			if(RestDMLFlag==0)
			{
				CALLAPI(RELSTAT_create_release_status(lcsTosetRel,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}

			if (DMLTag != NULLTAG)
			{
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				CALLAPI(GRM_list_primary_objects_only(DMLTag,relation_type,&count,&DMLRevision));
				
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					DMLRevTag = DMLRevision[TaskCnt];
					
					CALLAPI(AOM_ask_value_string(DMLRevTag,"object_type",&object_type));
					printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
					
					if(strcmp(object_type,"T5_SMDMLRevision")==0)
					{
						printf("\n inside class T5_SMDMLRevision......\n");fflush(stdout);
						AOM_ask_value_string( DMLRevTag, "item_id", &task_item_id);
						AOM_ask_value_string( DMLRevTag, "current_id", &task_no);
						AOM_ask_value_string( DMLRevTag, "t5_SMDMLType", &SmDmlTyp); //sanket
			            printf("\n SmDmlTyp:%s",SmDmlTyp);
						printf("\n\n\t\t task_item_id is :%s",task_item_id);fflush(stdout);
						
						ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&task_st_count1,&task_status_list1));
						printf("\n task_st_count1 :%d is\n",task_st_count1);fflush(stdout);
						if(task_st_count1>0)
						{
							for (cnt=0;cnt< task_st_count1;cnt++ )
							{
								WSO_Name=NULL;
								ITKCALL(AOM_ask_name(task_status_list1[cnt],&WSO_Name));
								printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
								if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,lcsTosetR)==0)
									{
										DMLFlag1 = 1;
										
									}

									if (tc_strcmp(WSO_Name,lcsTosetRel)==0)
									{
										RestDMLFlag1 = 1;
										
									}

									if (tc_strcmp(WSO_Name,lcsTosetReRel)==0)
									{
										RestReDMLFlag1 = 1;
										
									}

								}
							}						
						}

						printf("\n RestDMLFlag1 is :%d ,DMLFlag1 %d \n",RestDMLFlag1,DMLFlag1);fflush(stdout);

						
						if(RestDMLFlag1==0)
						{
							
							getCurrentDateTime(cCurrentAccessDate);
							printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
							CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
							CALLAPI(AOM_lock(DMLRevTag));
							CALLAPI(POM_attr_id_of_attr("date_released","T5_SMDMLRevision",&DMLClosureDtAttrId));
							CALLAPI(AOM_refresh(DMLRevTag,TRUE));
							CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							CALLAPI(POM_set_attr_date(1,&DMLRevTag,DMLClosureDtAttrId,Release_date));
							CALLAPI(AOM_save_without_extensions(DMLRevTag));
							CALLAPI(AOM_unlock(DMLRevTag));

							CALLAPI(RELSTAT_create_release_status(lcsTosetRel,&status2));
							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
							printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
							CALLAPI(RELSTAT_add_release_status(status2,1,&DMLRevTag,retain));


						}

						if(DMLFlag1==1)
						{
							t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsTosetR);
						}
						if(RestReDMLFlag1==1)
						{
							t5UpdateLifecycleStateSTDDML(DMLRevTag,lcsTosetReRel);
						}
						
						

					}
				}

				if (strcmp(SmDmlTyp,"IBVCRES")!=0)//sanket
				{
				
				ITKCALL(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&SMPartCnt,&SMPartTags));  //Task attached parts
				printf("\n\n\t\t Released SM DML Cre:Now SMPartCnt:%d",SMPartCnt);fflush(stdout);
				if (SMPartCnt>0)
				{
					for (smPrtCnt=0;smPrtCnt<SMPartCnt ;smPrtCnt++ )
					{
					
						SMAssyTag=SMPartTags[smPrtCnt];

						ITKCALL(AOM_ask_value_string(SMAssyTag,"item_id",&ParentItemName))
						printf("\n Arc Node child ParentItemName:%s ..............",ParentItemName);fflush(stdout);

						ITKCALL(AOM_ask_value_string(SMAssyTag,"item_revision_id",&ParentItemRevID))
						printf("\n D.child ParentItemRevID:%s ..............",ParentItemRevID);fflush(stdout);

						ITKCALL(ITEM_rev_list_bom_view_revs(SMAssyTag, &n_values_bvr, &bvr_assy_part));
						printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

						if(n_values_bvr==0)
						{
							flagBVR=0;
						}
						else if(n_values_bvr>0)
						{
							printf("\n BVR found");fflush(stdout);
							for(assbvr=0;assbvr<n_values_bvr;assbvr++)
							{
								ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
								printf("\n view_name %s",view_name);fflush(stdout);
								partTok = strtok (view_name,"-");
								viewTok = strtok (NULL,"-");
								printf("\n viewTok %s:%s",viewTok,APLViewBVR);fflush(stdout);
								if(strlen(viewTok)>0)
								{
									if(tc_strcmp(viewTok,APLViewBVR)==0)
									{
										flagBVR=1;
										bvr_tag=bvr_assy_part[assbvr];
										break;
									}
								}
							}
							printf("\n BVR found");fflush(stdout);

							if(flagBVR!=1)
							{
								int assbvr=0;
								for(assbvr=0;assbvr<n_values_bvr;assbvr++)
								{
									ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
									printf("\n 11 view_name %s",view_name);fflush(stdout);
									partTok = strtok (view_name,"-");
									viewTok = strtok (NULL,"-");
									printf("\n 11 viewTok %s",viewTok);fflush(stdout);
									if(strlen(viewTok)>0)
									{
										if(tc_strcmp(viewTok,"View")==0)
										{
											flagBVR=1;
											bvr_tag=bvr_assy_part[assbvr];
											break;
										}
									}
								}
							}

						}
					
						printf("\n find occurence..");fflush(stdout);
						ITKCALL(PS_list_occurrences_of_bvr(bvr_tag,&n_occs, &occsal ));
						printf("\n find occurence..window... %d",n_occs);fflush(stdout);
						ITKCALL(BOM_create_window (&window));
						printf("\n find occurence..window");fflush(stdout);
						ITKCALL(CFM_find( "Latest Working", &rule));
						printf("\n find occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_config_rule( window, rule ));
						printf("\n configure occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_top_line(window, null_tag,SMAssyTag , bvr_tag, &top_line));
						ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
						printf("\n nClhd %d,",nClhd);fflush(stdout);
						for (ck = 0; ck < nClhd; ck++)
						{
							//get the revision from bomline
							ITKCALL(BOM_line_unpack (children[ck]));

							//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
							//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
							AOM_ask_value_tag (children[ck],bomAttr_lineItemRevTag, &t_ChildItemRev);
							if(t_ChildItemRev!=NULLTAG)
							{

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
								printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
								printf("\n D.child value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);
								
								Bomline_tag = children[ck];

								//BOM_line_look_up_attribute("bl_occ_t5_InValidRelEPANo", &attribute_invalRel);
								//BOM_line_ask_attribute_string(Bomline_tag, attribute_invalRel, &value_invalRel);
								AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_InValidRelEPANo", &value_invalRel);

								printf("\n D.child value_invalRel:%s ..............",value_invalRel);fflush(stdout);

								//BOM_line_look_up_attribute("bl_occ_t5_RelEPANo", &attribute_vlaRel);
								//BOM_line_ask_attribute_string(Bomline_tag, attribute_vlaRel, &value_valRel);
								AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_RelEPANo", &value_valRel);

								printf("\n D.child value_valRel:%s ..............",value_valRel);fflush(stdout);

								//BOM_line_look_up_attribute(flag, &attribute_flag);
								//BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag);
								AOM_UIF_ask_value(Bomline_tag, flag, &value_flag);
								
								printf("\n D.child value_flag:%s ..............%s",value_flag,task_item_id);fflush(stdout);

								
								if(tc_strcmp(value_invalRel,"")!=0)
								{
									if(tc_strcmp(value_invalRel,task_item_id)==0)
									{
										if(tc_strcmp(value_flag,"--2")==0)
										{
											
											printf("\n Calling BOM_Line_Cut...");fflush(stdout);

											//ITKCALL(BOM_line_cut(Bomline_tag));	
											ITKCALL(AOM_UIF_set_value(Bomline_tag,flag,"---"));											
												
										
										}
									
									}
								
								}
								if(tc_strcmp(value_valRel,"")!=0)
								{
									if(tc_strcmp(value_valRel,task_item_id)==0)
									{
										if(tc_strcmp(value_flag,"01-")==0)
										{
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_flag,""));
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_vlaRel,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag,flag,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_RelEPANo",""));
										
										}
										else if (tc_strcmp(value_flag,"-1-")==0)
										{
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag, attribute_flag, "-12"));
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_vlaRel,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag, flag, "-12"));
											ITKCALL(AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_RelEPANo",""));
										}
									
									}
								
								}
							}


						}
						ITKCALL(BOM_save_window(window));
						//ITKCALL(BOM_refresh_window(window));
						ITKCALL(BOM_close_window(window));
				}


			}

			SMPartCnt=0;
			n_values_bvr=0;
			flagBVR=0;
			assbvr=0;
			ck=0;
			ITKCALL(AOM_ask_value_tags(DMLTag,"CMReferences",&SMPartCnt,&SMPartTags));  //Colour Part Check
			printf("\n\n\t\t Released SM DML Cre:Now SMPartCnt:%d",SMPartCnt);fflush(stdout);
			if (SMPartCnt>0)
			{
				smPrtCnt=0;
				for (smPrtCnt=0;smPrtCnt<SMPartCnt ;smPrtCnt++ )
				{
					flagBVR=0;
					n_values_bvr=0;
					assbvr=0;
					ck=0;

					SMAssyTag=NULLTAG;
					SMAssyTag=SMPartTags[smPrtCnt];

					ITKCALL(AOM_ask_value_string(SMAssyTag,"item_id",&ParentItemName))
					printf("\n 111 Arc Node child ParentItemName:%s ..............",ParentItemName);fflush(stdout);

					ITKCALL(AOM_ask_value_string(SMAssyTag,"item_revision_id",&ParentItemRevID))
					printf("\n D.child ParentItemRevID:%s ..............",ParentItemRevID);fflush(stdout);

					ITKCALL(ITEM_rev_list_bom_view_revs(SMAssyTag, &n_values_bvr, &bvr_assy_part));
					printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

					if(n_values_bvr==0)
					{
						flagBVR=0;
					}
					else if(n_values_bvr>0)
					{
						printf("\n BVR found");fflush(stdout);
						for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						{
							ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							printf("\n view_name %s",view_name);fflush(stdout);
							partTok = strtok (view_name,"-");
							viewTok = strtok (NULL,"-");
							printf("\n viewTok %s:%s",viewTok,APLViewBVR);fflush(stdout);
							if(strlen(viewTok)>0)
							{
								if(tc_strcmp(viewTok,APLViewBVR)==0)
								{
									flagBVR=1;
									bvr_tag=bvr_assy_part[assbvr];
									break;
								}
							}
						}
						printf("\n qqq BVR found %d",flagBVR);fflush(stdout);

						if(flagBVR!=1)
						{
							assbvr=0;
							for(assbvr=0;assbvr<n_values_bvr;assbvr++)
							{
								ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
								printf("\n 11 view_name %s",view_name);fflush(stdout);
								partTok = strtok (view_name,"-");
								viewTok = strtok (NULL,"-");
								printf("\n 11 viewTok %s",viewTok);fflush(stdout);
								if(strlen(viewTok)>0)
								{
									if(tc_strcmp(viewTok,"View")==0)
									{
										flagBVR=1;
										bvr_tag=bvr_assy_part[assbvr];
										break;
									}
								}
							}
						}

					}
				
					printf("\n find occurence..");fflush(stdout);
					ITKCALL(PS_list_occurrences_of_bvr(bvr_tag,&n_occs, &occsal ));
					printf("\n find occurence..window... %d",n_occs);fflush(stdout);
					ITKCALL(BOM_create_window (&window));
					printf("\n find occurence..window");fflush(stdout);
					ITKCALL(CFM_find( "Latest Working", &rule));
					printf("\n find occurence..rule");fflush(stdout);
					ITKCALL(BOM_set_window_config_rule( window, rule ));
					printf("\n configure occurence..rule");fflush(stdout);
					ITKCALL(BOM_set_window_top_line(window, null_tag,SMAssyTag , bvr_tag, &top_line));
					ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
					printf("\n nClhd %d,",nClhd);fflush(stdout);
					for (ck = 0; ck < nClhd; ck++)
					{
						//get the revision from bomline
						ITKCALL(BOM_line_unpack (children[ck]));

						//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
						//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
						AOM_ask_value_tag (children[ck],bomAttr_lineItemRevTag, &t_ChildItemRev);
						
						if(t_ChildItemRev!=NULLTAG)
						{

							ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
							printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

							ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
							printf("\n D.child value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);
							
							Bomline_tag = children[ck];

							//BOM_line_look_up_attribute("bl_occ_t5_InValidRelEPANo", &attribute_invalRel);
							//BOM_line_ask_attribute_string(Bomline_tag, attribute_invalRel, &value_invalRel);
							AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_InValidRelEPANo", &value_invalRel);

							printf("\n D.child value_invalRel:%s ..............",value_invalRel);fflush(stdout);

							//BOM_line_look_up_attribute("bl_occ_t5_RelEPANo", &attribute_vlaRel);
							//BOM_line_ask_attribute_string(Bomline_tag, attribute_vlaRel, &value_valRel);
							AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_RelEPANo", &value_valRel);

							printf("\n D.child value_valRel:%s ..............",value_valRel);fflush(stdout);

							//BOM_line_look_up_attribute(flag, &attribute_flag);
							//BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag);
							AOM_UIF_ask_value(Bomline_tag, flag, &value_flag);
							
							printf("\n D.child value_flag:%s ..............%s",value_flag,task_item_id);fflush(stdout);

							
							if(tc_strcmp(value_invalRel,"")!=0)
							{
								if(tc_strcmp(value_invalRel,task_item_id)==0)
								{
									if(tc_strcmp(value_flag,"--2")==0)
									{
										
										printf("\n Calling BOM_Line_Cut...");fflush(stdout);

										//ITKCALL(BOM_line_cut(Bomline_tag));																
										ITKCALL(AOM_UIF_set_value(Bomline_tag,flag,"---"));	
									
									}
								
								}
							
							}
							if(tc_strcmp(value_valRel,"")!=0)
							{
								if(tc_strcmp(value_valRel,task_item_id)==0)
								{
									if(tc_strcmp(value_flag,"01-")==0)
									{
										//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_flag,""));
										//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_vlaRel,""));
										ITKCALL(AOM_UIF_set_value(Bomline_tag,flag,""));
										ITKCALL(AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_RelEPANo",""));
									
									}
									else if (tc_strcmp(value_flag,"-1-")==0)
									{
										//ITKCALL(BOM_line_set_attribute_string(Bomline_tag, attribute_flag, "-12"));
										//ITKCALL(BOM_line_set_attribute_string(Bomline_tag,attribute_vlaRel,""));
										ITKCALL(AOM_UIF_set_value(Bomline_tag, flag, "-12"));
										ITKCALL(AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_RelEPANo",""));
									}
								
								}
							
							}
						}


					}
					ITKCALL(BOM_save_window(window));
					//ITKCALL(BOM_refresh_window(window));
					ITKCALL(BOM_close_window(window));
			}


		}
		}//sanket
		

		}
	}

	return error_code;
}

int createSMDML_Task( METHOD_message_t *msg, va_list  args )
{
	EPM_decision_t decision;
    tag_t	TaskTag		= va_arg(args, const tag_t);
    tag_t	TaskTagNew		= NULLTAG;
    tag_t			TaskTagrev		= NULLTAG;
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 100;
	char*			DMLAPL					=NULL;
	char*			Suffix					=NULL;
	tag_t *DmlRev=NULLTAG;

	int n_tags_found = 0;


	int
	error_code	= ITK_ok,
	n_entries	= 1,
	n_found		= 0,
	num=0,
	i=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *Dml_Name 	   = NULL;
	char *Proj_ID 	   = NULL;
	tag_t *tags_found = NULL;
	char cCurrentAccessDate[20]={0};
	char *Year=NULL;
	char *DMLSerial=NULL;
	tag_t	queryTag	= NULLTAG;
	tag_t	Dml_tag	= NULLTAG;
	int resultCount=0;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries[1] = {"ID"};
	//char *keys[1] = {"Date Created"};
	char *keys[1] = {"creation_date"};
     int  	 orders[1]  ={1};
	 int  num_to_sort = 1;
	//char *item_id_dup 	   = NULL;
	int  number_found;
	int  DMLFlag=0;
	int  DMLSerialInt;
	int  apl_number_found;
	tag_t *list_of_WSO_tags=NULLTAG;
    tag_t  NewTaskAttrId = NULLTAG;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char	DmlLastSerial[20];
	char **DesignGroupList;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
    char   *PlantName=NULL;
	char *EcnType=NULL;
	char*   type_name = NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	WSO_search_criteria_t  	APLTaskCriteria;
    WSO_search_criteria_t  	APLDMLCriteria;

	tag_t template_tag = NULLTAG;
	tag_t test_job_a = NULLTAG;
	int attachment_types = 1;


	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml_Str = (char *)MEM_alloc(max_char_size * sizeof(char));
    char *dml_type = (char *)MEM_alloc(max_char_size * sizeof(char));
	printf("\n **************inside createSMDML_Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n in SM DML type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	
	/*if(tc_strstr(type_name,"T5_SMDML")!=NULL)
	{
		printf("\n inside T5_SMDMLRevision cond"); fflush(stdout);
		AOM_ask_value_string( TaskTag,"t5_EcnType",&EcnType);
		//dml_type="STDRES";
		strcpy(dml_type,"STDRES");
	
		printf("\n rrbEcnType=%s",dml_type);
		if(TaskTag!=NULLTAG)
		{
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
			PlantName=subString(roleName,3,4);
			printf( "PlantName:%s\n", PlantName);
			if(strcmp(PlantName,"")==0)
			{
				printf("\n Role is not correct  %s \n",PlantName);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Select the Correct Role for SM DML Creation");
				decision = EPM_nogo;
				return ITK_errStore;
			}

			if(QRY_find("SMDMLQuery", &queryTag));
			printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
			if (queryTag)
			{
					   printf("2.Found Query \n");fflush(stdout);
					   getCurrentDateTime(cCurrentAccessDate);
						printf("\n cCurrentAccessDate:%s rrbEcnType:%s",cCurrentAccessDate,dml_type);fflush(stdout);
						Year=subString(cCurrentAccessDate,9,2);
						if(tc_strstr(dml_type,"STDRES")!=NULL)
						{					
							if(strcmp(PlantName,"STDJ")==0)
							{
								strcpy(item_id_dml,Year);
								strcat (item_id_dml,"SM80");
								strcat (item_id_dml,"*");
								printf("\n item_id_dml:%s",item_id_dml);fflush(stdout);
								strcpy(item_id_dml_Str,Year);
								strcat (item_id_dml_Str,"SM80");
							}
							else if(strcmp(PlantName,"STDL")==0)
							{
								strcpy(item_id_dml,Year);
								strcat (item_id_dml,"SM70");
								strcat (item_id_dml,"*");
								printf("\n item_id_dml:%s",item_id_dml);fflush(stdout);
								strcpy(item_id_dml_Str,Year);
								strcat (item_id_dml_Str,"SM70");
							}
							else
							{
								strcpy(item_id_dml,Year);
								strcat (item_id_dml,"SM90");
								strcat (item_id_dml,"*");
								printf("\n item_id_dml:%s",item_id_dml);fflush(stdout);
								strcpy(item_id_dml_Str,Year);
								strcat (item_id_dml_Str,"SM90");
							}
						}
						


						qry_values[0]=item_id_dml ;
						//qry_values[0]="19SM90*" ;
						if(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &resultCount, &DmlRev));
						printf(" \n After resultCount :%d:", resultCount); fflush(stdout);
						
						if (resultCount>0)
						{
							Dml_tag = DmlRev[resultCount-1];
							AOM_ask_value_string( Dml_tag, "item_id", &Dml_Name);
							printf("\n Dml_Name : %s\n",Dml_Name);fflush(stdout);
							DMLSerial=subString(Dml_Name,6,4);
							printf("\n DMLSerial : %s\n",DMLSerial);fflush(stdout);
							DMLSerialInt =atoi(DMLSerial);
							DMLSerialInt = DMLSerialInt + 1 ;
							printf("\n DMLSerialInt :%d\n",DMLSerialInt);fflush(stdout);
							sprintf(DmlLastSerial,"%d",DMLSerialInt);
							printf("\n DmlLastSerial : %s\n",DmlLastSerial);fflush(stdout);
							strcat (item_id_dml_Str,DmlLastSerial);
							strcat (item_id_dml_Str,"_");
							strcat (item_id_dml_Str,PlantName);
							printf("\n item_id_dml_Str:%s",item_id_dml_Str);
						}
						else
						{
							strcat (item_id_dml_Str,"1001");
							strcat (item_id_dml_Str,"_");
							strcat (item_id_dml_Str,PlantName);
						}

						WSOM_clear_search_criteria(&APLDMLCriteria);
						strcpy(APLDMLCriteria.name,item_id_dml_Str);
						strcpy(APLDMLCriteria.class_name,"T5_SMDMLRevision");
						status	= WSOM_search(APLDMLCriteria, &apl_number_found, &list_of_WSO_tags);
						printf("\n apl_number_found:%d",apl_number_found);
					   if(apl_number_found == 0 )
						{
						   printf("\n Item ID changed --> item_id_dml_Str:%s",item_id_dml_Str);
						   if(POM_attr_id_of_attr("item_id","T5_SMDML",&NewTaskAttrId));
						   if(AOM_refresh(TaskTag,TRUE));
						   if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						   if(POM_set_attr_string(1,&TaskTag,NewTaskAttrId,item_id_dml_Str));
						  // if(AOM_set_value_string(TaskTag,"t5_SMDMLType","STDRES"));
						   if(AOM_save_without_extensions(TaskTag));
						   if(AOM_refresh(TaskTag,TRUE));
						   TaskTagNew = TaskTag;
						   DMLFlag =1;
						}
			}
			else
			{
				printf("Not Found Query");fflush(stdout);
			}
		}
	}*/
     printf("\n DMLFlag [%d]",DMLFlag);fflush(stdout);
	if(strcmp(type_name,"T5_SMDML")==0)
	{
        	
			
			if(ITEM_ask_latest_rev(TaskTag,&TaskTagrev));
		    printf("\n inside class T5_SMDML......\n");fflush(stdout);
			ITKCALL(AOM_ask_value_string( TaskTagrev, "item_id", &item_id));
			ITKCALL(AOM_ask_value_string( TaskTagrev, "current_id", &DML_no));
			ITKCALL(AOM_ask_value_strings(TaskTagrev,"t5_crdesigngroup",&num,&DesignGroupList));
            ITKCALL(AOM_ask_value_string( TaskTagrev, "t5_cprojectcode", &Proj_ID));

			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Proj_ID is : %s\n",Proj_ID);fflush(stdout);

			DMLAPL = strtok (DML_no,"_");
			Suffix = strtok (NULL,"_");
			printf("\n DMLAPL is : %s\n",DMLAPL);fflush(stdout);
			printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

			for(i=0;i<num;i++)
			{
				
				strcpy(item_id_dup,DMLAPL);
				strcat (item_id_dup,"_");
				strcat (item_id_dup,DesignGroupList[i]);
				strcat (item_id_dup,"_");
				strcat(item_id_dup,Suffix);

    			printf("\n item_id_dup AFTER CAT is by hanuman :%s\n",item_id_dup);fflush(stdout);

				WSOM_clear_search_criteria(&APLTaskCriteria);
				strcpy(APLTaskCriteria.name,item_id_dup);
				strcpy(APLTaskCriteria.class_name,"T5_SMDMLTaskRevision");
				status	= WSOM_search(APLTaskCriteria, &number_found, &list_of_WSO_tags);

				printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

				if(number_found == 0)
				{
					printf("\n item_id :%s and DML_no :%s\n ",item_id,DML_no);fflush(stdout);
					//TC12 changes start
					//ITEM_create_item(item_id_dup,item_id_dup,"T5_SMDMLTask","A",&item,&rev);
					//printf("\n Item created first time only with item_id \n");fflush(stdout);


					int				n_strings			=	1;
					int				l_strings			=	500;
					int				index				=	0;
					char**			stringArraySMT		=	NULL;
					char*			tempStringt			= NULL;

					tag_t			SMTTypeTag			= NULLTAG;
					tag_t			SMTCreInTag		= NULLTAG;
					tag_t			SMTRevTypeTag		= NULLTAG;
					tag_t			SMTRevCreInTag		= NULLTAG;
					tag_t			SMTaskTag			= NULLTAG;
					tag_t 			SMTaskRevTag	    = NULLTAG;
					
					stringArraySMT = (char**)malloc( n_strings * sizeof *stringArraySMT );
					for( index=0; index<n_strings; index++ )
					{
						stringArraySMT[index] = (char*)malloc( l_strings + 1 );
					}
					
					ITKCALL( TCTYPE_find_type( "T5_SMDMLTask", NULL, &SMTTypeTag) );
					ITKCALL( TCTYPE_construct_create_input( SMTTypeTag, &SMTCreInTag) );

					ITKCALL( TCTYPE_find_type( "T5_SMDMLTaskRevision", NULL, &SMTRevTypeTag) );
					ITKCALL( TCTYPE_construct_create_input( SMTRevTypeTag, &SMTRevCreInTag) );

					tc_strcpy( stringArraySMT[0], item_id_dup);
					ITKCALL( TCTYPE_set_create_display_value( SMTCreInTag, "item_id", 1,(const char**)stringArraySMT) );

					tc_strcpy( stringArraySMT[0], item_id_dup);

					ITKCALL( TCTYPE_set_create_display_value( SMTCreInTag, "object_name", 1,(const char**)stringArraySMT) );

					tc_strcpy( stringArraySMT[0], item_id_dup);
					ITKCALL( TCTYPE_set_create_display_value( SMTCreInTag, "object_desc", 1,(const char**)stringArraySMT) );

					ITKCALL( AOM_tag_to_string(SMTRevCreInTag, &tempStringt) );
					tc_strcpy( stringArraySMT[0], tempStringt);
					printf("\nTest0.4..[%s]\n",stringArraySMT[0]);fflush(stdout);
					ITKCALL( TCTYPE_set_create_display_value( SMTCreInTag, "revision", 1,(const char**) stringArraySMT) );
					tc_strcpy( stringArraySMT[0], "A");
					ITKCALL( TCTYPE_set_create_display_value( SMTRevCreInTag, "item_revision_id", 1,(const char**)stringArraySMT) );
					tc_strcpy( stringArraySMT[0], DesignGroupList[i]);
					ITKCALL( TCTYPE_set_create_display_value( SMTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArraySMT) );
					tc_strcpy( stringArraySMT[0], Proj_ID);
					ITKCALL( TCTYPE_set_create_display_value( SMTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArraySMT) );

					printf("\n Value to set in apl_task_number %s:%s:%s:%s:%s:\n",item_id_dup,item_id,tempStringt,DesignGroupList[i],Proj_ID);fflush(stdout);

					ITKCALL( TCTYPE_create_object( SMTCreInTag, &SMTaskTag) );
					ITKCALL( AOM_save_without_extensions(SMTaskTag) );

					ITKCALL(ITEM_ask_latest_rev(SMTaskTag,&SMTaskRevTag));
					//
					printf("\nSave APL TASK ITEM AND REV\n");fflush(stdout);
					if (SMTaskTag!=NULLTAG)
					{
						printf("\nTASK ITEM IS CREATED\n");fflush(stdout);
					}
					else
					{
						printf("\nTASK ITEM IS NOT CREATED\n");fflush(stdout);
					}
					if (SMTaskRevTag!=NULLTAG)
					{
						printf("\nTASK ITEM REV IS CREATED\n");fflush(stdout);
					}
					else
					{
						printf("\nTASK ITEM REV IS NOT CREATED\n");fflush(stdout);
					}
					AOM_save_without_extensions(SMTaskTag);
					AOM_save_without_extensions(SMTaskRevTag);



					AOM_save_without_extensions(item);
					AOM_save_without_extensions(rev);
					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
					GRM_create_relation(TaskTagrev, SMTaskRevTag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					if(AssignSTDGrpHeadReviewer(SMTaskRevTag,Proj_ID));
					
		
				}
				else
				{
					printf("\n item_id created twice......  \n");fflush(stdout);
				}

				 MEM_free(list_of_WSO_tags);
			 }

			 //Submit SMDML into Workflow
			
			printf("\n Finding CM Release Process Template\n");fflush(stdout);

			ITKCALL(EPM_find_template2("STDSI Restructuring LC",0,&template_tag));
			if (template_tag!=NULLTAG)
			{
				printf("\n Submit APL DML in to workflow\n");fflush(stdout);
				//ITKCALL(EPM_create_process("SM DML Process","",template_tag,1, &TaskTagrev,&attachment_types,&test_job_a));
				printf("\n Submit APL DML in to workflow process complete\n");fflush(stdout);
			}
	}

    return error_code;

}




extern int DLLAPI smdml_validate_dialog( METHOD_message_t *msg, va_list  args )
{
    tag_t	TaskTag		= va_arg(args, const tag_t);
	tag_t objTypeTag=NULLTAG;
	char*   type_name = NULL;
	char *smdmlType = NULL;
	char *dmlprojCode = NULL;
	char *errorMsg = NULL;
	char *DriverVCVal = NULL;
	char *driveVC_ID = NULL;
	
	char *part_type = NULL;
	char *smdmlFactCode = NULL;
	char *sm_Qty = NULL;
	char *sm_valid_date = NULL;

	int     n_entryCntrl    = 4;
	char **ExcomMembList    = NULL;
	char    *qry_entryCntrl[4]  = {"Name","SUBSYSCD","Delete Indicator","Information-2"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
	int control_number_found=0;

	int		n_entryCntrl_DVC= 5;
	char    *qry_entryCntrl_DVC[5]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1","Information-2"};	 	 
	char	**qry_valuesCntrl_DVC= (char **) MEM_alloc(5 * sizeof(char *));

	int		n_entryCntrl_Excom=3;
	int		control_number_found_Excom=0;
	int		num_excomm=0;
	char    *qry_entryCntrl_Excom[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	 	 
	char	**qry_valuesCntrl_Excom= (char **) MEM_alloc(5 * sizeof(char *));

	int control_number_found_DVC=0;
	
	tag_t	*list_of_WSO_cntrl_tags_DVC	=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags_Excom	=	NULLTAG;

	int	n_entries	= 1;
	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	
	
	char *qry_entries_DVC[3] = {"ID","Release Status","Type"};

	int num_to_sort_DVC=1;
	int n_entries_DVC=3;
	char *keys_DVC[1] = {"creation_date"};
	int  	 orders_DVC[1]  ={1};
	int resultCount_DVC=0;
	tag_t *Rev_DVC=NULLTAG;

	tag_t  CurrentRoleTag = NULLTAG;
	char*       roleName = NULL;
    char   *PlantName=NULL;
	tag_t   qryTagCntrl     = NULLTAG;
	tag_t   queryTag_DVC     = NULLTAG;
	char **qry_values_DVC = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t	VCRev_tag	= NULLTAG;
	EPM_decision_t decision;
     tag_t user_tag=NULLTAG;
    char* username;


	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name for apl dml object %s\n", type_name);fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	PlantName=subString(roleName,3,4);
	printf( "PlantName:%s\n", PlantName);fflush(stdout);

	get_CtrlVal_SMDMLStateInf(PlantName,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);
	printf( "1111 PlantName:%s\n", StdWrkngLC,StdResLC,StdRelLC);fflush(stdout);
	
	ITKCALL(POM_get_user(&username,&user_tag));
	printf("\n username %s.\n",username);fflush(stdout);
	
	if(strcmp(type_name,"T5_SMDMLRevision")==0)
	{
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			ITKCALL(AOM_ask_value_string(TaskTag,"t5_SMDMLType",&smdmlType));
			
			if(tc_strcmp(smdmlType,"DENSTDRES")==0)
			{
				printf("\n smdmlType is DENSTDRES..\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"You are not authorized to create SM-EPA or Denis STDS Re-Structuring DML.");
				decision = EPM_nogo;
				return ITK_errStore1;

			}

			ITKCALL(AOM_ask_value_string(TaskTag, "t5_cprojectcode", &dmlprojCode));
			printf("\n dmlprojCode %s\n",dmlprojCode);fflush(stdout);

			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				
				qry_valuesCntrl[0]="PlantDML";
				qry_valuesCntrl[1]=dmlprojCode;
				qry_valuesCntrl[2]="0";
				qry_valuesCntrl[3]=PlantName;
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
				printf("\n control_number_found..%d\n",control_number_found);fflush(stdout);
				if (control_number_found == 0)
				{
					printf("\n smdmlType is other than ..DENSTDRES..\n");fflush(stdout);

					if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
					errorMsg=(char *)MEM_alloc(1000);
					
					tc_strcpy(errorMsg,"Selected project ");
					tc_strcat(errorMsg,dmlprojCode);
					tc_strcat(errorMsg,"  is not live for your Plant ");
					tc_strcat(errorMsg,PlantName);
					tc_strcat(errorMsg,".\nPlease select valid project name as per your plant.");
					
					printf("\n errorMsg :::::::::::::%s\n",errorMsg);fflush(stdout);
					
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
					decision = EPM_nogo;
					return ITK_errStore1;
				
				}
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}

			if((tc_strcmp(smdmlType,"STDRES")==0) || (tc_strcmp(smdmlType,"STDFIALRES")==0) || (tc_strcmp(smdmlType,"SML")==0) || (tc_strcmp(smdmlType,"SMEPA")==0) )
			{
				if (qryTagCntrl)
				{		
					printf("\n Control Object Query Found so finding for Driver VC Control Object \n");fflush(stdout);
					
					qry_valuesCntrl_DVC[0]="STDVErr";
					qry_valuesCntrl_DVC[1]="SignOffErr";
					qry_valuesCntrl_DVC[2]="0";
					qry_valuesCntrl_DVC[3]="DriverVC";
					qry_valuesCntrl_DVC[4]=PlantName;

					if(QRY_execute(qryTagCntrl, n_entryCntrl_DVC, qry_entryCntrl_DVC, qry_valuesCntrl_DVC, &control_number_found_DVC, &list_of_WSO_cntrl_tags_DVC));
					printf("\n control_number_found_DVC %d\n",control_number_found_DVC);fflush(stdout);
					if(control_number_found_DVC>0)
					{
							ITKCALL(AOM_ask_value_string(TaskTag,"t5_DriverVC",&DriverVCVal));
							printf("\n DriverVCVal %s\n",DriverVCVal);fflush(stdout);
							
							if(tc_strcmp(DriverVCVal,"")==0)
							{
										
									if (qryTagCntrl)
									{
										ITKCALL(AOM_ask_value_string(TaskTag, "t5_SMQtyy", &sm_Qty));
										printf("\n sm_Qty %s\n",sm_Qty);fflush(stdout);

										ITKCALL(AOM_UIF_ask_value(TaskTag,"t5_SMValidTill",&sm_valid_date));
										printf("\n sm_valid_date %s\n",sm_valid_date);fflush(stdout);

										ITKCALL(AOM_ask_value_strings(TaskTag,"t5_EXCOMMembr",&num_excomm,&ExcomMembList));
										printf("\n num_excomm %d\n",num_excomm);fflush(stdout);
										
										qry_valuesCntrl_Excom[0]="EXCOM";
										qry_valuesCntrl_Excom[1]="SMQty";
										qry_valuesCntrl_Excom[2]="0";
										
										if(QRY_execute(qryTagCntrl, n_entryCntrl_Excom, qry_entryCntrl_Excom, qry_valuesCntrl_Excom, &control_number_found_Excom, &list_of_WSO_cntrl_tags_Excom));
										printf("\n control_number_found_Excom %d\n",control_number_found_Excom);fflush(stdout);
										if(control_number_found_Excom>0)
										{

											//if((tc_strcmp(sm_Qty,"")==0) || (tc_strcmp(sm_valid_date,"")==0) || (num_excomm==0))
											if((tc_strcmp(sm_Qty,"")==0) || (num_excomm==0))
											{
												
												if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
												errorMsg=(char *)MEM_alloc(1000);
												
												tc_strcpy(errorMsg,"Please Ensure the Complete Information Against below Mentioned Fields since you have not enter Driver VC.\n");
												tc_strcat(errorMsg,"1. Exception Approval By EXCOM Member.\n");
												tc_strcat(errorMsg,"2. Validity Till.\n");
												tc_strcat(errorMsg,"3. Quantity.\n");
												tc_strcat(errorMsg,"4. Select Approval Mail of EXCOM Member.(Select Browse and Then Upload the required Approval Mail)");

												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
												decision = EPM_nogo;
												return ITK_errStore1;									
											
											}
										}
										else
										{
											//if((tc_strcmp(sm_valid_date,"")==0) || (num_excomm==0))
											if((num_excomm==0))
											{
												
												if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
												errorMsg=(char *)MEM_alloc(1000);
												
												tc_strcpy(errorMsg,"Please Ensure the Complete Information Against below Mentioned Fields since you have not enter Driver VC.\n");
												tc_strcat(errorMsg,"1. Exception Approval By EXCOM Member.\n");
												tc_strcat(errorMsg,"2. Validity Till.\n");
												tc_strcat(errorMsg,"3. Select Approval Mail of EXCOM Member.(Select Browse and Then Upload the required Approval Mail)");

												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
												decision = EPM_nogo;
												return ITK_errStore1;									
											
											}							
										
										
										}
									}

							
							}
							else
							{
							
								if(QRY_find2("DriverVCQuerySM", &queryTag_DVC));
								printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);

								qry_values_DVC[0] = DriverVCVal ;
								qry_values_DVC[1] = StdRelLC ;
								qry_values_DVC[2] = "Design Revision" ;

								if(QRY_execute_with_sort(queryTag_DVC, n_entries_DVC, qry_entries_DVC, qry_values_DVC, num_to_sort_DVC, keys_DVC, orders_DVC, &resultCount_DVC, &Rev_DVC));
								if (resultCount_DVC>0)
								{
									VCRev_tag = Rev_DVC[resultCount_DVC-1];

									ITKCALL(AOM_ask_value_string(VCRev_tag, "item_id", &driveVC_ID));
									printf("\n driveVC_ID : %s\n",driveVC_ID);fflush(stdout);

									ITKCALL(AOM_ask_value_string(VCRev_tag,"t5_PartType", &part_type));
									printf("\n part_type : %s\n",part_type);fflush(stdout);
									
									if ((tc_strcmp(part_type,"V")==0) ||(tc_strcmp(part_type,"VC")==0)||(tc_strcmp(part_type,"VCCR")==0))
									{
										printf("\n Driver VC Part Type:%s \n", part_type);fflush(stdout);								
									}
									else
									{
										printf("\n Driver VC Part Type is V/VC/VCCR..\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Driver VC Type is not VC/Vehicle/Vehicle Combination CR..");
										decision = EPM_nogo;
										return ITK_errStore1;
									}


								}
								else
								{
									printf("\n Driver VC Part Type is not found !!!\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please enter valid Driver VC Number having Release Status as STDSI Released as per plant.");
									decision = EPM_nogo;
									return ITK_errStore1;
									
								}
							
							
							}
					
					}


				}
			
			}

			ITKCALL(AOM_ask_value_string(TaskTag,"t5_Category_code4",&smdmlFactCode));
			
			if((tc_strcmp(PlantName,"")!=0) && (tc_strcmp(PlantName,"STDP")==0))
			{
				printf("\n Inside factoryCodeValDup validation..!!!\n");fflush(stdout);
				
				if((tc_strcmp(smdmlType,"STDRES")==0) && (tc_strcmp(smdmlFactCode,"")==0))
				{
					printf("\n factoryCodeValDup is mandatory for Pune/STD User !!!\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Factory Code 1 Value is Blank.Please enter value in Factory Code 1 field while creating SM DML.");
					decision = EPM_nogo;
					return ITK_errStore1;			
				
				}
			}
		}
	}

	return ITK_ok;


}

extern int DLLAPI sm_dml_part_attach( METHOD_message_t *msg, va_list  args )
{
	
	
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	tag_t tsk_dml_rel_type=NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t relation_type_epaTask=NULLTAG;
	tag_t relation_type_epa=NULLTAG;
	tag_t	relation_type_task = NULLTAG;
	tag_t	relation_type_amdml = NULLTAG;
	tag_t	relation_type_smTask = NULLTAG; //TZ 1.50


	char*   type_name = NULL;
	char*   type_name2 = NULL;
	char*   relation_name = NULL;
	char*   epa_task_type_class = NULL;
	char*   epa_type_class = NULL;
	char*   amdml_type_class = NULL;

	tag_t  CurrentRoleTag = NULLTAG;
	tag_t CurrentGroupTag = NULLTAG;
    char *groupName = NULL;
    int isSupportUser = 0;
	char		   *PlantName =NULL;
	char		   *part_name =NULL;
	char		   *part_no =NULL;
	char		   *part_no_revision =NULL;
	char		   *CpyRefDescValue =NULL; // Akhilesh Add
	char		   *epa_Number =NULL;
	char		   *epa_Plant =NULL;
	char		   *epa_TaskId =NULL;
	//char		   *inp_Plant =NULL;
	char		   *relase_Status_DesignRev =NULL;
	//char		   *epa_type_class =NULL;
	char		   *epa_Id =NULL;
	char		   *epa_plant =NULL;
	char		   *epa_WSO_Name =NULL;
	char*   dml_task_type_class = NULL;

	char		   *dml_TaskId =NULL;
	char		   *ClosureDate_task =NULL;
	char		   *sm_task_type_class =NULL;
	char		   *am_Taskecntype =NULL;
	char		   *am_TaskId =NULL;
	char		   *ClosureDateDup		= NULL;
	char		   *ClosureDate_epa		= NULL;
	char		   *smdml_WSO_Name		= NULL;

	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char inp_Plant[40];
	char flag[40];
	char APLViewBVR[40];
	char occFlag[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	
	int count=0;
	int epa_count_task=0;
	int epa_count=0;
	int j=0;
	int PlantPrtStatusRlzd=0;
	int epaScnt=0;
	int rlzdEPAFnd=0,samePlntEPAFnd=0,Precnt1=0,rleasematPlntDMLFnd=0,amCnt=0;


	char*		roleName = NULL;
	char *class_name1= NULL;
	char *DMLtype= NULL;
	char *DMLNumber= NULL;
	char *taskTempLT = NULL;
	char *taskTempLTPrcoseeStage = NULL;
	char *errorMsg = NULL;
	char *sm_dml_TaskId = NULL;
	char *serhPart_ID = NULL;
	char *serhPart_RevID = NULL;
	char *smdml_droppartNo = NULL;
	int st_count1 = 0;
	int cnt_next = 0;
	int Precnt = 0;
	int epaFound = 0;
	int epaCnt = 0;
	int epa_st_count1 = 0;
	int amdml_count = 0,amdmlFnd=0,sm_st_count1=0,smScnt=0,dCnt=0,validamdmlFnd=0,task_count=0,SMtskcnt=0;//1.50

	char cCurrentAccessDate[20]={0};
    char* pAccessDateDup 	= NULL;


	tag_t *DMLRevision = NULLTAG;
	tag_t class_id1=NULLTAG;

	tag_t*    status_list1=NULLTAG;
	tag_t*    epa_status_list1=NULLTAG;
	tag_t*    sm_status_list1=NULLTAG;
	tag_t *epa_PartTskTags = NULLTAG;
	tag_t *epa_PartEpa = NULLTAG;
	tag_t *amdml_Part_task = NULLTAG;
	tag_t *task_countTags = NULLTAG; //1.50
	tag_t epa_ParttskTag = NULLTAG;
	tag_t epa_itemTypeTag_class = NULLTAG;
	tag_t epa_PartTag = NULLTAG;
	tag_t epa_Tag_class = NULLTAG;
	tag_t dml_itemTypeTag_class = NULLTAG;
	tag_t amdml_Tag_class = NULLTAG;
	tag_t sm_itemTypeTag_class = NULLTAG; //1.50
	tag_t dml_ParttskTag = NULLTAG;
	tag_t amdml_PartTag = NULLTAG;
	tag_t sm_ParttskTag = NULLTAG; //1.50
	tag_t PartRev_tag = NULLTAG;
	char *qry_entries_nextRevision[2] = {"ID","Release Status"};

	int num_to_sort_nextRevision=1;
	int n_entries_nextRevision=2;
	char *keys_nextRevision[1] = {"creation_date"};
	int  	 orders_nextRevision[1]  ={1};
	int resultCount_nextRevision=0;
	int ppdmlFnd=0;
	tag_t *Rev_nextRevision=NULLTAG;

	tag_t   queryTag_nextRevision     = NULLTAG;
	char **qry_values_nextRevision = (char **) MEM_alloc(10 * sizeof(char *));
	

	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);
	EPM_decision_t decision;
	


	
	ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     SMDML primary_object  type_name :: %s\n", type_name); fflush(stdout);

    ITKCALL(SA_ask_current_role(&CurrentRoleTag));
    ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
    printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

    // ITKCALL(SA_ask_current_group(&CurrentGroupTag));
    // ITKCALL(SA_ask_group_name2(CurrentGroupTag,&groupName));
    // printf("\n\n  groupName : %s\n",groupName); fflush(stdout);

    if((tc_strcmp(roleName, "Support_Role") == 0) || (tc_strcmp(roleName, "DBA") == 0) )/// dba
    {
    isSupportUser = 1;
    printf("\n Support user found. Role:%s\n", roleName); fflush(stdout);
    }

    PlantName=subString(roleName,3,4);
    printf( "PlantName:%s\n", PlantName);
	get_CtrlVal_SMDMLStateInf(PlantName,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);

	if(tc_strcmp(type_name,"T5_SMDMLTaskRevision")==0)
	{
	
		ITKCALL(AOM_ask_value_string(primary_object, "item_id",&smdml_droppartNo));
		printf("\n smdml_droppartNo:%s\n",smdml_droppartNo);fflush(stdout);
		
		if(relation_type != NULLTAG)
		{
			ITKCALL(TCTYPE_ask_name2( relation_type,&relation_name));

			ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
			ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
			
			if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
			{
				printf("\n     Inside attaching part to SM DML task \n"); fflush(stdout);
				if((tc_strcmp(type_name2,"Design Revision")==0) || (tc_strcmp(type_name2,"EE Part Revision")==0))
				{
					
						if( AOM_ask_value_string(secondary_object,"current_id",&part_name)==ITK_ok)
						printf("\n part_name Value :--------------------   %s\n",part_name); fflush(stdout);

						ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
						ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
						printf("\n     A9_ValidationAtAMDML secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);

						ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
						if (tsk_dml_rel_type!=NULLTAG)
						{
							ITKCALL(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
							printf("\n\t\t APL DML Revision from Task : %d",count); fflush(stdout);
						}


						for (j=0;j<count;j++ )
						{
							DMLRevTag = DMLRevision[j];

							ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
							ITKCALL(POM_name_of_class(class_id1,&class_name1));
							printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

							if(tc_strcmp(class_name1,"T5_SMDMLRevision")==0)
							{
								ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_SMDMLType",&DMLtype));
								printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);	
								
								ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNumber));
								printf("\n\t DMLNumber is :%s",DMLNumber); fflush(stdout);
								break;
							}

						}

						if(tc_strcmp(DMLtype,"")!=0)
						{
							printf("\n DMLtype is not null...\n"); fflush(stdout);
							if(tc_strstr(PlantName,"STD")!=NULL || (isSupportUser == 1))
							{
								if(tc_strstr(DMLNumber,"SM")!=NULL)
								{
									printf("\n DMLNumber is SM...\n");fflush(stdout);
									
										printf("\n Enter Akhilesh\n");fflush(stdout);
									/*********** Akki code to check for part stamp attribute for TZ UA1.73 SCO 9643********/
									char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};	
									char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

									int cntrlcnt=0;
									int  control_number_found1=0;

									tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

									tag_t   qryTagCntrl1     = NULLTAG;
									int     n_entryCntrl1    = 2;
									 
									if(QRY_find2("Control Objects...", &qryTagCntrl1));
									if (qryTagCntrl1 !=NULLTAG)
									{
										printf("\n Control Object Query Found \n");fflush(stdout);
										qry_valuesCntrl1[0]="SMEPAStampCntObj";
										
										qry_valuesCntrl1[1]="0";
										
									if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
									}
									else
									{
										printf("\n Control Object Query not Found \n");fflush(stdout);
									}	
									
									printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

									if(control_number_found1>0)
									{
				
										if((tc_strstr(PlantName,"STDC")!=NULL) || (tc_strstr(PlantName,"STDD")!=NULL) || (tc_strstr(PlantName,"STDJ")!=NULL) || (tc_strstr(PlantName,"STDL")!=NULL) || (tc_strstr(PlantName,"STDU")!=NULL) || (tc_strstr(PlantName,"STDP")!=NULL))
										{
											ITKCALL(AOM_ask_value_string(secondary_object, "t5_JdlStoreLocation",&CpyRefDescValue));
											printf("\n CpyRefDescValue:%s\n",CpyRefDescValue);fflush(stdout);
										
											//if(tc_strcmp(CpyRefDescValue,"")!=0)
											if((CpyRefDescValue!=NULL)&&(tc_strcmp(CpyRefDescValue,"")!=0))
											{
													
												 if(tc_strstr(PlantName,"STDJ")!=NULL)
												 {
													if(tc_strstr(CpyRefDescValue,"SMJ")!=NULL)
													{
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												 }
												 else if(tc_strstr(PlantName,"STDP")!=NULL)
												 {
													 if(tc_strstr(CpyRefDescValue,"SMP")!=NULL)
													 {
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												 }
												 else if(tc_strstr(PlantName,"STDL")!=NULL)
												 {
													 if(tc_strstr(CpyRefDescValue,"SML")!=NULL)
													 {
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part previous rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												 }
												 else if(tc_strstr(PlantName,"STDU")!=NULL)
												 {
													 if(tc_strstr(CpyRefDescValue,"SMU")!=NULL)
													 {
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												 }
												 else if(tc_strstr(PlantName,"STDD")!=NULL)
												 {
													 if(tc_strstr(CpyRefDescValue,"SMD")!=NULL)
													 {
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												 }
												 else if(tc_strstr(PlantName,"STDC")!=NULL)
												{
													 if(tc_strstr(CpyRefDescValue,"SMC")!=NULL)
													 {
														printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"This Part rev is attached with SM in TCE, first release it.");
														return ITK_errStore1;

													}
												}	
													printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
													printf("\n Akhileshfinal\n");fflush(stdout);
											}
										}
									}
									/*********** End of Akhilesh code to check for part stamp attribute for TZ UA1.73 SCO 9643********/
									
									//if( AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&taskTempLT)==ITK_ok); 
									//if( AOM_UIF_ask_value(primary_object,"fnd0MyWorkflowTasks",&taskTempLT)==ITK_ok); //Commented by Deepti for TZ1.88
									if( AOM_UIF_ask_value(primary_object,"fnd0MyWorkflowTasks",&taskTempLT)==ITK_ok); //Added by Deepti for TZ1.88
									printf("\n primary taskTempLT is .. Add Part: %s\n",taskTempLT);fflush(stdout);

									if( AOM_UIF_ask_value(primary_object,"process_stage",&taskTempLTPrcoseeStage)==ITK_ok); 
									printf("\n primary taskTempLT is .. Add Part taskTempLTPrcoseeStage: %s\n",taskTempLTPrcoseeStage);fflush(stdout);
									
									if( (tc_strcmp(taskTempLT,"")==0)) 
									{
										if(( tc_strstr(taskTempLTPrcoseeStage,"SMDML Task Break Down For Part Transfer")!=NULL) || (tc_strstr(taskTempLTPrcoseeStage,"SMDML Task Break Down for Loaded")!=NULL))
										{
											printf("\n bypass for part transfer case..time being,,");fflush(stdout);	
										}
										else
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"SM DML Task Assignment should be Perform Restructuring.\n You are allowed to add Part under SM DML only when Assignment is Perform Restructuring.");
											decision = EPM_nogo;
											return ITK_errStore1;
										}
									}
									else if( tc_strstr(taskTempLT,"Perform Restructuring")==NULL)
									{
										
										if(( tc_strstr(taskTempLTPrcoseeStage,"SMDML Task Break Down For Part Transfer")!=NULL) || (tc_strstr(taskTempLTPrcoseeStage,"SMDML Task Break Down for Loaded")!=NULL))
										{
											printf("\n bypass for part transfer case..time being,,");fflush(stdout);	
										}
										else
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"SM DML Task Assignment should be Perform Restructuring.\n You are allowed to add Part under SM DML only when Assignment is Perform Restructuring.");
											decision = EPM_nogo;
											return ITK_errStore1;
										}
									
									}
									else
									{
										
											ITKCALL(AOM_ask_value_string(secondary_object, "item_id",&part_no));
											printf("\n part_no:%s\n",part_no);fflush(stdout);

											ITKCALL(AOM_ask_value_string(secondary_object, "item_revision_id",&part_no_revision));
											printf("\n part_no_revision:%s\n",part_no_revision);fflush(stdout);
											
											ITKCALL(WSOM_ask_release_status_list(secondary_object,&st_count1,&status_list1));
											printf("\n 111..st_count1 :%d is\n",st_count1);fflush(stdout);											

											if(st_count1>0)
											{
												for (cnt_next=0;cnt_next< st_count1;cnt_next++ )
												{
													ITKCALL(AOM_ask_name(status_list1[cnt_next],&relase_Status_DesignRev));
													printf("\n 111..relase_Status_DesignRev is :%s\n",relase_Status_DesignRev);fflush(stdout);

													if(tc_strcmp(relase_Status_DesignRev,"")!=0)
													{
														printf("\n 111..StdRelLC is :%s\n",StdRelLC);fflush(stdout);
														if (tc_strcmp(relase_Status_DesignRev,StdRelLC)==0)
														{
															
															PlantPrtStatusRlzd++;
															break;
														}
													}
												}
															
												if(QRY_find2("DriverVCQuerySM", &queryTag_nextRevision));
												printf("\n Next offical revision finding... %s:%s\n",stdRlzdLcsR,StdRelLC);fflush(stdout);

												qry_values_nextRevision[0] = part_no ;
												qry_values_nextRevision[1] = StdRelLC ;

												if(QRY_execute_with_sort(queryTag_nextRevision, n_entries_nextRevision, qry_entries_nextRevision, qry_values_nextRevision, num_to_sort_nextRevision, keys_nextRevision, orders_nextRevision, &resultCount_nextRevision, &Rev_nextRevision));
												printf("\n resultCount_nextRevision %d \n",resultCount_nextRevision);fflush(stdout);
												if (resultCount_nextRevision>0)
												{
													
													//for(dCnt=0;dCnt<resultCount_nextRevision;dCnt++)
													for(dCnt=resultCount_nextRevision-1;dCnt>=0;dCnt--)
													{
													
														PartRev_tag = Rev_nextRevision[dCnt];

														ITKCALL(AOM_ask_value_string( PartRev_tag, "item_id", &serhPart_ID));
														printf("\n serhPart_ID : %s\n",serhPart_ID);fflush(stdout);

														ITKCALL(AOM_ask_value_string( PartRev_tag, "item_revision_id", &serhPart_RevID));
														printf("\n serhPart_RevID : %s\n",serhPart_RevID);fflush(stdout);

														if (tc_strcmp(serhPart_RevID,part_no_revision)==0)
														{
															
															printf("\n Matched revision found");fflush(stdout);
															break;
														}
														else
														{
																																	
															if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
															errorMsg=(char *)MEM_alloc(1000);
															
															tc_strcpy(errorMsg,"Revision ");
															tc_strcat(errorMsg,serhPart_ID);
															tc_strcat(errorMsg,":");
															tc_strcat(errorMsg,serhPart_RevID);
															tc_strcat(errorMsg," is STDSI Released");
															tc_strcat(errorMsg,".Only latest STDSI released part should be restructured.");																				
																																			
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
															decision = EPM_nogo;
															return ITK_errStore1;
															break;
														
														}
													
													
													}
												
												
												}
														
														
											}			//no change
											else
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please check for Design Revision Release status.No Release Status found.Please contact PLM support group.");
												decision = EPM_nogo;
												return ITK_errStore1;	
											
											}
											
											printf("\n 111..PlantPrtStatusRlzd is :%d\n",PlantPrtStatusRlzd);fflush(stdout);
											//if(PlantPrtStatusRlzd==0)
											//{
												relation_type_epaTask=NULLTAG;		

												GRM_find_relation_type("CMHasSolutionItem",&relation_type_epaTask);
												GRM_list_primary_objects_only(secondary_object,relation_type_epaTask,&epa_count_task,&epa_PartTskTags);
												printf("\n 111..epa_count_task is :%d\n",epa_count_task);fflush(stdout);
												if(epa_count_task >0)
												{							
													for (Precnt=0;Precnt<epa_count_task ;Precnt++ )
													{
														epa_ParttskTag=NULLTAG;
														epa_itemTypeTag_class=NULLTAG;
														epa_ParttskTag=epa_PartTskTags[Precnt];
														ITKCALL (TCTYPE_ask_object_type(epa_ParttskTag,&epa_itemTypeTag_class));
														ITKCALL (TCTYPE_ask_name2(epa_itemTypeTag_class,&epa_task_type_class));

														printf("\n  epa_task_type_class ...%s\n", epa_task_type_class);fflush(stdout);

														if(tc_strcmp(epa_task_type_class,"T5_EPATaskRevision")==0)
														{
															
															ITKCALL(AOM_ask_value_string(epa_ParttskTag, "item_id",&epa_TaskId));
															printf("\n epa_TaskId %s.....\n",epa_TaskId);fflush(stdout);

															GRM_find_relation_type("T5_DMLTaskRelation",&relation_type_epa);
															GRM_list_primary_objects_only(epa_ParttskTag,relation_type_epa,&epa_count,&epa_PartEpa);
															printf("\n 111..epa_count is :%d\n",epa_count);fflush(stdout);

															if(epa_count >0)
															{							
																for (epaCnt=0;epaCnt<epa_count ;epaCnt++ )
																{
																	epa_PartTag=NULLTAG;
																	epa_Tag_class=NULLTAG;
																	epa_PartTag=epa_PartEpa[epaCnt];
																	ITKCALL (TCTYPE_ask_object_type(epa_PartTag,&epa_Tag_class));
																	ITKCALL (TCTYPE_ask_name2(epa_Tag_class,&epa_type_class));

																	printf("\n  epa_type_class ...%s\n", epa_type_class);fflush(stdout);
																	
																	if(tc_strcmp(epa_type_class,"T5_EPARevision")==0)
																	{
																																				
																		ITKCALL(AOM_ask_value_string(epa_PartTag, "item_id",&epa_Id));
																		printf("\n epa_Id %s.....\n",epa_Id);fflush(stdout);

																		ITKCALL(AOM_ask_value_string(epa_PartTag, "t5_EpaPlantA",&epa_plant));
																		printf("\n epa_plant %s.....\n",epa_plant);fflush(stdout);

																		ITKCALL(AOM_UIF_ask_value(epa_PartTag, "date_released",&ClosureDate_epa));
																		printf("\n ClosureDate_epa %s.....\n",ClosureDate_epa);fflush(stdout);

																		if(tc_strcmp(EpaPlnt,epa_plant)==0)
																		{
																			ITKCALL(WSOM_ask_release_status_list(epa_PartTag,&epa_st_count1,&epa_status_list1));
																			printf("\n epa_st_count1 :%d is\n",epa_st_count1);fflush(stdout);
																			if(epa_st_count1>0)
																			{
																				for (epaScnt=0;epaScnt< epa_st_count1;epaScnt++ )
																				{
																					epa_WSO_Name=NULL;
																					ITKCALL(AOM_ask_name(epa_status_list1[epaScnt],&epa_WSO_Name));
																					printf("\n epa_WSO_Name is :%s\n",epa_WSO_Name);fflush(stdout);
																					if(tc_strcmp(epa_WSO_Name,"")!=0)
																					{
																						if ((tc_strcmp(epa_WSO_Name,StdRelLC)==0) && (tc_strcmp(ClosureDate_epa,"")!=0))
																						{
																							rlzdEPAFnd++;

																							ClosureDateDup = subString(ClosureDate_epa,0,11);
																							printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
																							
																							getCurrentDateTime(cCurrentAccessDate);
																							printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
																							pAccessDateDup = subString(cCurrentAccessDate,0,11);
																							printf("\n  todays date is: %s\n",pAccessDateDup);

																							if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
																							{
																							
																								if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																								errorMsg=(char *)MEM_alloc(1000);
																								
																								tc_strcpy(errorMsg,"Part ");
																								tc_strcat(errorMsg,part_no);
																								tc_strcat(errorMsg,":");
																								tc_strcat(errorMsg,part_no_revision);
																								tc_strcat(errorMsg," being added to SMDML is released today");
																								tc_strcat(errorMsg,".Same Revision Part released today by EPA ");
																								tc_strcat(errorMsg,epa_Id);																								
																								tc_strcat(errorMsg,"should not be added to SMDML on same day.");																				
																																												
																								EMH_clear_errors();
																								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																								decision = EPM_nogo;
																								return ITK_errStore1;
																							}


																							break;
																						}
																					}
																				}
																			}

																			samePlntEPAFnd++;
																			break;
	
																		}																		
																	
																	}
																}
															}
															
															
														}

														if(samePlntEPAFnd>0)
														{
															break;
														}													
															
													}
													if((samePlntEPAFnd>0) && (rlzdEPAFnd==0))
													{
														
															if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
															errorMsg=(char *)MEM_alloc(1000);
															
															tc_strcpy(errorMsg,"Selected part's ");
															tc_strcat(errorMsg,part_no);
															tc_strcat(errorMsg,":");
															tc_strcat(errorMsg,part_no_revision);
															tc_strcat(errorMsg," is under working EPA ");
															tc_strcat(errorMsg,epa_Id );
															tc_strcat(errorMsg,".Hence not allowed to attach the Part in SM-DML.\nPlease check LifeCycle state of selected part's EPA.");
															
															epaFound++;
															
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
															decision = EPM_nogo;
															return ITK_errStore1;															
														
													}
													else if(samePlntEPAFnd==0)
													{
														printf("\n samePlntEPAFnd %d.....%d\n",samePlntEPAFnd,epa_count_task);fflush(stdout);

														for (Precnt1=0;Precnt1<epa_count_task;Precnt1++)
														{
															dml_ParttskTag=NULLTAG;
															dml_itemTypeTag_class=NULLTAG;

															printf("\n Precnt1 %d.....\n",Precnt1);fflush(stdout);

															if(epa_count_task>0)
															{
																printf("\n epa_PartTskTags is null");fflush(stdout);
															}
															else
															{
																printf("\n epa_PartTskTags is not null ");fflush(stdout);
															}
															
															dml_ParttskTag=epa_PartTskTags[Precnt1];
															
															ITKCALL(TCTYPE_ask_object_type(dml_ParttskTag,&dml_itemTypeTag_class));
															if(dml_itemTypeTag_class==NULLTAG)
															{
																printf("\n dml_itemTypeTag_class is null");fflush(stdout);
															}
															else
															{
																printf("\n dml_itemTypeTag_class is not null ");fflush(stdout);
															}
															ITKCALL(TCTYPE_ask_name2(dml_itemTypeTag_class,&dml_task_type_class));

															printf("\n  dml_task_type_class ...%s\n",dml_task_type_class);fflush(stdout);

															if(tc_strcmp(dml_task_type_class,"T5_APLTaskRevision")==0)
															{
																
																ITKCALL(AOM_ask_value_string(dml_ParttskTag, "item_id",&dml_TaskId));
																printf("\n dml_TaskId %s.....\n",dml_TaskId);fflush(stdout);

																GetPlantForDMLORTask(dml_TaskId,inp_Plant);	
																printf("\t  inp_Plant after  ...%s\n", inp_Plant);fflush(stdout);

																if((tc_strcmp(inp_Plant,plantDML)==0))
																{
																	ITKCALL(AOM_UIF_ask_value(dml_ParttskTag,"date_released",&ClosureDate_task));
																	printf("\n ClosureDate_task : %s\n",ClosureDate_task);fflush(stdout);
																	
																	if(  (tc_strstr(dml_TaskId,"PP")!=NULL)  || (tc_strstr(dml_TaskId,"PM")!=NULL) || (tc_strstr(dml_TaskId,"JP")!=NULL) || (tc_strstr(dml_TaskId,"JM")!=NULL) || (tc_strstr(dml_TaskId,"LP")!=NULL) || (tc_strstr(dml_TaskId,"LM")!=NULL) ||(tc_strstr(dml_TaskId,"PR")!=NULL) )
																	{
																		ppdmlFnd++;
																		if(tc_strcmp(ClosureDate_task,"")!=0) 
																		{
																			rleasematPlntDMLFnd++;
																			
																			ClosureDateDup = subString(ClosureDate_task,0,11);
																			printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
																			
																			getCurrentDateTime(cCurrentAccessDate);
																			printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
																			pAccessDateDup = subString(cCurrentAccessDate,0,11);
																			printf("\n  todays date is: %s\n",pAccessDateDup);

																			if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
																			{
																			
																				if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																				errorMsg=(char *)MEM_alloc(1000);
																				
																				tc_strcpy(errorMsg,"Part ");
																				tc_strcat(errorMsg,part_no);
																				tc_strcat(errorMsg,":");
																				tc_strcat(errorMsg,part_no_revision);
																				tc_strcat(errorMsg," being added to SMDML is released today");
																				tc_strcat(errorMsg,".Same Revision Part released today by DML should not be added to SMDML on same day.");																				
																																								
																				EMH_clear_errors();
																				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																				decision = EPM_nogo;
																				return ITK_errStore1;
																			
																			}



																			break;
																																				
																		}														

																	}
																	else if(tc_strstr(dml_TaskId,"AM")!=NULL)
																	{
																		GRM_find_relation_type("T5_DMLTaskRelation",&relation_type_amdml);
																		GRM_list_primary_objects_only(dml_ParttskTag,relation_type_amdml,&amdml_count,&amdml_Part_task);
																		printf("\n 111..amdml_count is :%d\n",amdml_count);fflush(stdout);

																		if(amdml_count >0)
																		{							
																			for (amCnt=0;amCnt<amdml_count ;amCnt++ )
																			{
																				amdml_PartTag=NULLTAG;
																				amdml_Tag_class=NULLTAG;
																				amdml_PartTag=amdml_Part_task[amCnt];
																				ITKCALL (TCTYPE_ask_object_type(amdml_PartTag,&amdml_Tag_class));
																				ITKCALL (TCTYPE_ask_name2(amdml_Tag_class,&amdml_type_class));

																				printf("\n  amdml_type_class ...%s\n", amdml_type_class);fflush(stdout);

																				if(tc_strcmp(amdml_type_class,"T5_APLDMLRevision")==0)
																				{
																					
																					ITKCALL(AOM_ask_value_string(amdml_PartTag, "t5_EcnType",&am_Taskecntype));
																					printf("\n am_Taskecntype %s.....\n",am_Taskecntype);fflush(stdout);

																					ITKCALL(AOM_ask_value_string(amdml_PartTag, "item_id",&am_TaskId));
																					printf("\n am_TaskId %s.....\n",am_TaskId);fflush(stdout);																		
																					
																					if((tc_strcmp(am_Taskecntype,"APLSTR") == 0) || (tc_strcmp(am_Taskecntype,"APLMBOMRES") == 0) || (tc_strcmp(am_Taskecntype,"CARRYOVER") == 0) || (tc_strcmp(am_Taskecntype,"AMBSTR") == 0)|| (tc_strcmp(am_Taskecntype,"TOODMLR") == 0) || (tc_strcmp(am_Taskecntype,"IPBT") == 0) || (tc_strcmp(am_Taskecntype,"FrameGrp") == 0) || (tc_strcmp(am_Taskecntype,"APLRESPREL") == 0))
																					{
																						
																						validamdmlFnd++;
																						if(tc_strcmp(ClosureDate_task,"")!=0) 
																						{
																							rleasematPlntDMLFnd++;

																							ClosureDateDup = subString(ClosureDate_task,0,11);
																							printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
																							
																							getCurrentDateTime(cCurrentAccessDate);
																							printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
																							pAccessDateDup = subString(cCurrentAccessDate,0,11);
																							printf("\n  todays date is: %s\n",pAccessDateDup);

																							if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
																							{
																							
																								if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																								errorMsg=(char *)MEM_alloc(1000);
																								
																								tc_strcpy(errorMsg,"Part ");
																								tc_strcat(errorMsg,part_no);
																								tc_strcat(errorMsg,":");
																								tc_strcat(errorMsg,part_no_revision);
																								tc_strcat(errorMsg," being added to SMDML is released today");
																								tc_strcat(errorMsg,".Same Revision Part released today by DML should not be added to SMDML on same day.");																				
																																												
																								EMH_clear_errors();
																								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																								decision = EPM_nogo;
																								return ITK_errStore1;
																							
																							}

																							break;																						
																						
																						}		
																					
																					}
																					else
																					{
																						printf("\n  DML other than APL-REST ...");
																						amdmlFnd++;
																					}

																				
																				}
																			}
																		}
																	
																	}

																}
															}
															
															}
														
														if((validamdmlFnd>0) && (rleasematPlntDMLFnd==0))
														{
															if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
															errorMsg=(char *)MEM_alloc(1000);

															tc_strcpy(errorMsg,"Current revision ");
															tc_strcat(errorMsg,part_no_revision );
															tc_strcat(errorMsg,"of Part's ");
															tc_strcat(errorMsg,part_no);
															tc_strcat(errorMsg," DML ");
															tc_strcat(errorMsg,am_TaskId);
															tc_strcat(errorMsg," is not STDSI Released yet.Dml of current revision should get released first prior to restructuring.");

															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
															decision = EPM_nogo;
															return ITK_errStore1;				
														
														}
														else if( (ppdmlFnd>0) && (rleasematPlntDMLFnd==0))
														{
														
															if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
															errorMsg=(char *)MEM_alloc(1000);
															
															tc_strcpy(errorMsg,"Current revision ");
															tc_strcat(errorMsg,part_no_revision );
															tc_strcat(errorMsg,"of Part's ");
															tc_strcat(errorMsg,part_no);
															tc_strcat(errorMsg," DML ");
															tc_strcat(errorMsg,dml_TaskId);
															tc_strcat(errorMsg," is not STDSI Released yet.Dml of current revision should get released first prior to restructuring.");
															
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
															decision = EPM_nogo;
															return ITK_errStore1;	
															
														
														}
														else if(amdmlFnd>0)
														{
															if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
															errorMsg=(char *)MEM_alloc(1000);
															
															tc_strcpy(errorMsg,"Not Allowed to Drop Part ");
															tc_strcat(errorMsg,part_no);
															tc_strcat(errorMsg,":");
															tc_strcat(errorMsg,part_no_revision);
															tc_strcat(errorMsg,".Please Check ECN Type of DML ");
															tc_strcat(errorMsg,am_TaskId );
															tc_strcat(errorMsg,".Dml of current revision should get released with ECN type: APLSTR/APLMBOMRES/CARRYOVER/AMBSTR/TOODMLR/IPBT/FrameGrp/APLRESPREL.");
															
															
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
															decision = EPM_nogo;
															return ITK_errStore1;	
														
														
														}
														else
														{
															if(PlantPrtStatusRlzd==0)
															{
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Part being added to SM-DML is not STDSI Released.\n Only STDSI released part from plant should be restructured.");
																decision = EPM_nogo;
																return ITK_errStore1;
															}
														}
													
													}


												}
												else
												{
													if(PlantPrtStatusRlzd==0)
													{
														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Part being added to SM-DML is not STDSI Released and not attached to any task.\n Only STDSI released part from plant should be restructured.");
														decision = EPM_nogo;
														return ITK_errStore1;		
													}
												
												}

											
											//}
											//else	//Deepti TZ1.50
											//{
												relation_type_smTask=NULLTAG;		

												GRM_find_relation_type("CMHasSolutionItem",&relation_type_smTask);
												GRM_list_primary_objects_only(secondary_object,relation_type_smTask,&task_count,&task_countTags);
												printf("\n 111..task_count is :%d\n",task_count);fflush(stdout);
												if(task_count >0)
												{							
													for (SMtskcnt=0;SMtskcnt<task_count ;SMtskcnt++ )
													{
													
														sm_ParttskTag=NULLTAG;
														sm_itemTypeTag_class=NULLTAG;
														
														sm_ParttskTag=task_countTags[SMtskcnt];
														
														ITKCALL (TCTYPE_ask_object_type(sm_ParttskTag,&sm_itemTypeTag_class));
														ITKCALL (TCTYPE_ask_name2(sm_itemTypeTag_class,&sm_task_type_class)); //Deepti TZ1.53

														printf("\n  sm_task_type_class ...%s\n", sm_task_type_class);fflush(stdout);
														
														if(tc_strcmp(sm_task_type_class,"T5_SMDMLTaskRevision")==0)
														{
															ITKCALL(AOM_ask_value_string(sm_ParttskTag, "item_id",&sm_dml_TaskId));
															printf("\n sm_dml_TaskId %s.....%s\n",sm_dml_TaskId,smdml_droppartNo);fflush(stdout);

															if(tc_strcmp(smdml_droppartNo,sm_dml_TaskId)!=0)
															{
																GetPlantForDMLORTask(sm_dml_TaskId,inp_Plant);	
																printf("\t  inp_Plant after  ...%s\n", inp_Plant);fflush(stdout);
																
																if(tc_strstr(sm_dml_TaskId,"SM")!=NULL) 
																{
																	if(tc_strstr(sm_dml_TaskId,inp_Plant)!=NULL) 
																	{
																		
																		ITKCALL(WSOM_ask_release_status_list(sm_ParttskTag,&sm_st_count1,&sm_status_list1));
																		printf("\n sm_st_count1 :%d is\n",sm_st_count1);fflush(stdout);
																		
																		if(sm_st_count1>0)
																		{
																				for (smScnt=0;smScnt< sm_st_count1;smScnt++ )
																				{
																					smdml_WSO_Name=NULL;
																					
																					ITKCALL(AOM_ask_name(sm_status_list1[smScnt],&smdml_WSO_Name));
																					printf("\n smdml_WSO_Name is :%s\n",smdml_WSO_Name);fflush(stdout);
																					if(tc_strcmp(smdml_WSO_Name,"")!=0)
																					{
																						if ((tc_strcmp(smdml_WSO_Name,StdWrkngLC)==0) || (tc_strcmp(smdml_WSO_Name,StdResLC)==0))
																						{
																								
																							if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																							errorMsg=(char *)MEM_alloc(1000);
																							
																							tc_strcpy(errorMsg,"Part ");
																							tc_strcat(errorMsg,part_no);
																							tc_strcat(errorMsg,":");
																							tc_strcat(errorMsg,part_no_revision);
																							tc_strcat(errorMsg," is already under restructuring DML");
																							tc_strcat(errorMsg,sm_dml_TaskId);
																							tc_strcat(errorMsg,".It is expected not to restructure an assembly twice.");																				
																							
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																							decision = EPM_nogo;
																							return ITK_errStore1;
																							break;

																						}
																					}
																				}
																			}
																		}																
																	}
																}													
														}
													}
												}
											
											//}
										
									
									}

								}
							}
							else
							{
							
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Only STDSI user, Support_ROLE, Loader are allowed to attach the Part in SM-DML.");
								decision = EPM_nogo;
								return ITK_errStore1;	
							
							}
						}				
				
				}			
			
			
			}
		}	
	
	
	}
	return ITK_ok;


}

int revert_changes(int PartCnt, tag_t* PartTags, char *RevisionRule,char *flagView,char	*smDMLNo, int FlagSMSTR)
{
	char	rev_id1[ITEM_id_size_c+1];
	char*	cur_rev						= NULL;
	char*	part_item_id				= NULL;
	tag_t	DesignTag					= NULLTAG;
	int k=0;
	tag_t			AssyTag				= NULLTAG;

	printf("\n\n\t\t Revert changes function called....................");fflush(stdout);

	printf("\n\n\t\tPart count:- %d",PartCnt);fflush(stdout);

	if (PartCnt>0)
	{
		for (k=0;k<PartCnt ;k++ )
		{
			printf("\n\n\t\t hi all APL DML Cre:for k =:%d",k);fflush(stdout);

			AssyTag=NULLTAG;
			AssyTag=PartTags[k];

			cur_rev				= NULL;
			part_item_id				= NULL;

			ITKCALL(AOM_ask_value_string(AssyTag, "item_id", &part_item_id));

			ITKCALL(AOM_UIF_ask_value(AssyTag,"item_revision_id",&cur_rev));
			printf("\n\n\t  Part String is cur_rev--->%s",cur_rev);fflush(stdout);

			int		LPCpart1 = 0;
			tag_t	window1				=	NULLTAG;
			tag_t	rule1				=	NULLTAG;
			tag_t	PartRevTag			=	NULLTAG;
			tag_t  *LatestPchildPart1	=	NULLTAG;
			tag_t	top_line1			=	NULLTAG;
									

			ITKCALL(ITEM_ask_item_of_rev(AssyTag, &PartRevTag));

			int			count1						=	0;
			char*  		rev_id1= NULL;
			tag_t *		rev_list					= NULLTAG;
			
			ITKCALL(ITEM_list_all_revs(PartRevTag, &count1,&rev_list));
			printf("\n\n\t\t WSOM count1:- %d\n\n",count1);fflush(stdout);
			//int Flag = 0;
			int ii	 = 0;

			//Flag = 0;
			for (ii = 0; ii < count1; ii++)
			{
				ITKCALL(ITEM_ask_rev_id2( rev_list[ii],&rev_id1));
				printf("\n\n\t  Part String is rev_id1--->%s",rev_id1);fflush(stdout);
				printf("\n\n\t  Part String is rev_id1--->%d",FlagSMSTR);fflush(stdout);
				if(FlagSMSTR ==1)
				{
					
					DesignTag   =    NULLTAG; //successor itemrev tag
					DesignTag	=	 rev_list[ii];

					int zz=0; 

					if(BOM_create_window (&window1)!=ITK_ok);//PrintErrorStack();
					if(CFM_find(RevisionRule, &rule1 )!=ITK_ok);//PrintErrorStack();
					if(BOM_set_window_config_rule( window1, rule1 )!=ITK_ok);//PrintErrorStack();
					 //if(BOM_set_window_pack_all (window1, false)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_top_line (window1, NULLTAG, DesignTag, NULLTAG, &top_line1)!=ITK_ok);//PrintErrorStack();
					printf("\n inside bom_window-----555\n"); fflush(stdout);
					if(BOM_line_ask_child_lines (top_line1, &LPCpart1, &LatestPchildPart1));
					printf("\n\n\t\t No of child objects are n LPCpart1 : %d\n",LPCpart1);fflush(stdout);

					int yy=0;
					int FlagGotPart=0;
					for(yy=0;yy<LPCpart1;yy++)
					{
						int iChildItemTag1=0;
						tag_t   t_ChildItemRev1=NULLTAG;

						ITKCALL(BOM_line_unpack (LatestPchildPart1[yy]));
						//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag1));
						//ITKCALL(BOM_line_ask_attribute_tag(LatestPchildPart1[yy], iChildItemTag1, &t_ChildItemRev1));
						AOM_ask_value_tag (LatestPchildPart1[yy],bomAttr_lineItemRevTag, &t_ChildItemRev1);
				
						if(t_ChildItemRev1!=NULLTAG)
						{
							tag_t Bomline_tag1 = NULLTAG;

							Bomline_tag1=NULLTAG;
							Bomline_tag1 = LatestPchildPart1[yy];

							if(Bomline_tag1!=NULLTAG)
							{
								char*		value_flag1			=	NULL;
								char*		value_itemid1		=	NULL;
								char*		value_itemRevID1	=	NULL;
								char*		value_invalRel	=	NULL;
								char*		value_valRel	=	NULL;
								int attribute_flag1=0;
								int attribute_vlaRel=0;
								int attribute_invalRel=0;

								ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_id",&value_itemid1));
								printf("\n Arc Node child value_itemid1:%s ..............",value_itemid1);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_revision_id",&value_itemRevID1));
								printf("\n value_itemRevID1:%s ..............",value_itemRevID1);fflush(stdout);

								//ITKCALL(BOM_line_look_up_attribute(flagView, &attribute_flag1));					
								//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag1, attribute_flag1, &value_flag1));
								AOM_UIF_ask_value(Bomline_tag1, flagView, &value_flag1);
								printf("\n  value_flag1:%s ..............",value_flag1);fflush(stdout);

								//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_InValidRelEPANo", &attribute_invalRel));
								//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag1, attribute_invalRel, &value_invalRel));
								 AOM_UIF_ask_value(Bomline_tag1, "bl_occ_t5_InValidRelEPANo", &value_invalRel); 
								printf("\n D.child value_invalRel:%s ::%s..............",value_invalRel,smDMLNo);fflush(stdout);

								//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_RelEPANo", &attribute_vlaRel));
								//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag1, attribute_vlaRel, &value_valRel));
								 AOM_UIF_ask_value(Bomline_tag1, "bl_occ_t5_RelEPANo", &value_valRel);
								printf("\n D.child value_valRel:%s ::%s..............",value_valRel,smDMLNo);fflush(stdout);

								if(tc_strcmp(value_invalRel,"")!=0)
								{
									if(tc_strcmp(value_invalRel,smDMLNo)==0)
									{
										if(tc_strcmp(value_flag1,"--2")==0)
										{
											
											printf("\n Calling BOM_Line_Cut...");fflush(stdout);

											//ITKCALL(BOM_line_cut(Bomline_tag1));																
											ITKCALL(AOM_UIF_set_value(Bomline_tag1,flagView,"---"));	
										
										}
									
									}
								
								}
								if(tc_strcmp(value_valRel,"")!=0)
								{
									if(tc_strcmp(value_valRel,smDMLNo)==0)
									{
										if(tc_strcmp(value_flag1,"01-")==0)
										{
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1,attribute_flag1,""));
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1,attribute_vlaRel,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag1,flagView,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag1,"bl_occ_t5_RelEPANo",""));
										
										}
										else if (tc_strcmp(value_flag1,"-1-")==0)
										{
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1, attribute_flag1, "-12"));
											//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1,attribute_vlaRel,""));
											ITKCALL(AOM_UIF_set_value(Bomline_tag1, flagView, "-12"));
											ITKCALL(AOM_UIF_set_value(Bomline_tag1,"bl_occ_t5_RelEPANo",""));
										}
									
									}
								
								}


							}
						}
					}
					ITKCALL(BOM_save_window(window1));
					ITKCALL(BOM_close_window(window1));

				
				}
				if (strcmp(rev_id1,cur_rev)==0)
				{
					printf("\n \t  Both revisions match");
					FlagSMSTR = 1;
				}
			}


		}
	}


}

int sm_carryFrwrd_revert_changes( EPM_action_message_t msg )
{

	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objErcTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLtaskTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			ERCDMLRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartTags123			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			ERCDMLTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t Release_date;


	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				count_erc			= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int 			PartCnt123 			=0;
	int				AttCnt				= 0;
	int				k					= 0;
    int 	n_instances =1;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
     tag_t 	  *ReleaseDateTgs = NULLTAG;
     tag_t 	  ReleaseDateTg = NULLTAG;
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
     logical * 	date_is_valid  = false;
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char*   type_name = NULL;
	char   type_name_erc[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	char AplRlzdLc[40] ;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];	
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char	*parttype=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));


    tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	int cntrlcnt=0;
	int  control_number_found1=0;
	int  FlagGotFrmToplt=0;

    char *FrmPltToPlt 	   = NULL;
	char	*smDMLType				=	NULL;
	char	*smDMLNo				=	NULL;

	printf("\n **************inside sm_carryFrwrd_revert_changes***************\n ");fflush(stdout);

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="SM_CarryForwrd_Revert_Changes";
		qry_valuesCntrl1[1]="Live";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found .... \n");fflush(stdout);
	}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		
		if(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n sm_carryFrwrd_rstrctr_changes \n"); fflush(stdout);

		if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
		if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);
		if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
		if(noAttachment > 0)
		{
			DMLtaskTag = attachments[0];
			if(TCTYPE_ask_object_type(DMLtaskTag,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
		}

		if(strcmp(type_name,"T5_SMDMLTaskRevision")==0)
		{
			tag_t	DMLRevTag				=	NULLTAG;
			int		FlagSMSTR				=	0;
			
			tm_GetSMDMLFromTask(DMLtaskTag, &DMLRevTag);
			if(DMLRevTag)
			{
				
				ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_SMDMLType",&smDMLType));
				printf("\n smDMLType : %s",smDMLType);fflush(stdout);

				ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&smDMLNo));
				printf("\n smDMLNo : %s",smDMLNo);fflush(stdout);

				if(tc_strcmp(smDMLType,"STDRES")==0)
				{
					FlagSMSTR=1;
				}

			}
			FlagSMSTR=1;
			
			if(FlagSMSTR==1)
			{
			
				char *item_id 	   = NULL;
				char *DML_no = NULL;
				char **DesignGroupList;
				int num=0;
				char*			DML_Num				= NULL;
				char*			Dsgn_No				= NULL;
				char*			PLT_Code			= NULL;

				char RevisionRule[40];
				char ERCClosureRule[40];
				char STDClosureRule[40];
				char BVR[40];

				char StdWrkngLC[40];
				char StdResLC[40];
				char StdRelLC[40];
				char EpaPlnt[40];
				char plantDML[40];
				char flagView[40];
				char APLViewBVR[40];
				char occFlag[40];
				char stdRlzdLcsR[40];
				char stdReRestLcsR[40];

				printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
				ITKCALL(AOM_ask_value_string( DMLtaskTag, "item_id", &item_id));
				ITKCALL(AOM_ask_value_string( DMLtaskTag, "current_id", &DML_no));
				ITKCALL(AOM_ask_value_strings(DMLtaskTag,"t5_crdesigngroup",&num,&DesignGroupList));
				
				DML_Num=tc_strtok(DML_no,"_");
				printf("\n SMDML_Num:[%s],[%s]\n",DML_Num,DML_no);fflush(stdout);
				Dsgn_No = tc_strtok(NULL,"_");
				printf("\n SMDML Dsgn_No:[%s],[%s]\n",Dsgn_No,DML_no);fflush(stdout);
				PLT_Code = tc_strtok(NULL,"_");
				printf("\n SMDML Plant[%s],[%s]\n",PLT_Code,DML_no);fflush(stdout);

				
				get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flagView,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);
				printf( " Data from SMDMLStateInf %s:%s:%s:%s:%s:%s:%s:%s:%s\n", StdWrkngLC,StdResLC,StdRelLC,plantDML,flagView,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);fflush(stdout);

				getPlantWiseRRCCDriverVC(PLT_Code,RevisionRule,STDClosureRule,ERCClosureRule,BVR);
				printf("\n  getPlantWiseRRCCDriverVC detaisl:%s:%s,%s ..............",STDClosureRule,ERCClosureRule,BVR);fflush(stdout);

				ITKCALL(AOM_ask_value_tags(DMLtaskTag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				if(PartCnt>0)
				{
					revert_changes(PartCnt,PartTags,RevisionRule,flagView,smDMLNo,FlagSMSTR);
				}

				ITKCALL(AOM_ask_value_tags(DMLtaskTag,"CMReferences",&PartCnt123,&PartTags123));
				printf("\n\n\t\t APL DML Cre:Now ParPartCnt123tCnt:%d",PartCnt123);fflush(stdout);

				
				if(PartCnt123>0)
				{
					revert_changes(PartCnt123,PartTags123,RevisionRule,flagView,smDMLNo,FlagSMSTR);
				}
			
			}
		}
	}


		return error_code;


}

int sm_carryFrwrd_rstrctr_changes( EPM_action_message_t msg )
{
	
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objErcTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLtaskTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			ERCDMLRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			ERCDMLTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t Release_date;


	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				count_erc			= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
    int 	n_instances =1;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
     tag_t 	  *ReleaseDateTgs = NULLTAG;
     tag_t 	  ReleaseDateTg = NULLTAG;
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
     logical * 	date_is_valid  = false;
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char*   type_name = NULL;
	char   type_name_erc[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	char AplRlzdLc[40] ;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];	
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char	*parttype=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside sm_carryFrwrd_rstrctr_changes***************\n ");fflush(stdout);


    tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	int cntrlcnt=0;
	int  control_number_found1=0;
	int  FlagGotFrmToplt=0;

    char *FrmPltToPlt 	   = NULL;

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="SM_CarryForwrd_ReStr_Changes";
		qry_valuesCntrl1[1]="Live";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found .... \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{

			
		if(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n sm_carryFrwrd_rstrctr_changes \n"); fflush(stdout);

		if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
		if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);
		if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
		if(noAttachment > 0)
		{
			DMLtaskTag = attachments[0];
			if(TCTYPE_ask_object_type(DMLtaskTag,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
		}

		if(strcmp(type_name,"T5_SMDMLTaskRevision")==0)
		{
			tag_t	DMLRevTag				=	NULLTAG;
			int FlagSMSTR=0;
			tm_GetSMDMLFromTask(DMLtaskTag, &DMLRevTag);
			if(DMLRevTag)
			{
				char	*smDMLType				=	NULL;
				ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_SMDMLType",&smDMLType));
				printf("\n smDMLType : %s",smDMLType);fflush(stdout);

				if((tc_strcmp(smDMLType,"STDRES")==0) || (tc_strcmp(smDMLType,"IBVCRES")==0)) //sanket
				{
					FlagSMSTR=1;
				}

			}
			FlagSMSTR=1;
			
			if(FlagSMSTR==1)
			{
				char *item_id 	   = NULL;
				char *DML_no = NULL;
				char **DesignGroupList;
				int num=0;
				char*			DML_Num				= NULL;
				char*			Dsgn_No				= NULL;
				char*			PLT_Code			= NULL;

				char RevisionRule[40];
				char ERCClosureRule[40];
				char STDClosureRule[40];
				char BVR[40];

				char StdWrkngLC[40];
				char StdResLC[40];
				char StdRelLC[40];
				char EpaPlnt[40];
				char plantDML[40];
				char flagView[40];
				char APLViewBVR[40];
				char occFlag[40];
				char stdRlzdLcsR[40];
				char stdReRestLcsR[40];

				printf("\n inside class T5_SMDMLTaskRevision......\n");fflush(stdout);
				ITKCALL(AOM_ask_value_string( DMLtaskTag, "item_id", &item_id));
				ITKCALL(AOM_ask_value_string( DMLtaskTag, "current_id", &DML_no));
				ITKCALL(AOM_ask_value_strings(DMLtaskTag,"t5_crdesigngroup",&num,&DesignGroupList));
				
				DML_Num=tc_strtok(DML_no,"_");
				printf("\n SMDML_Num:[%s],[%s]\n",DML_Num,DML_no);fflush(stdout);
				Dsgn_No = tc_strtok(NULL,"_");
				printf("\n SMDML Dsgn_No:[%s],[%s]\n",Dsgn_No,DML_no);fflush(stdout);
				PLT_Code = tc_strtok(NULL,"_");
				printf("\n SMDML Plant[%s],[%s]\n",PLT_Code,DML_no);fflush(stdout);

				
				get_CtrlVal_SMDMLStateInf(PLT_Code,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flagView,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);
				printf( " Data from SMDMLStateInf %s:%s:%s:%s:%s:%s:%s:%s:%s\n", StdWrkngLC,StdResLC,StdRelLC,plantDML,flagView,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);fflush(stdout);

				getPlantWiseRRCCDriverVC(PLT_Code,RevisionRule,STDClosureRule,ERCClosureRule,BVR);
				printf("\n  getPlantWiseRRCCDriverVC detaisl:%s:%s,%s ..............",STDClosureRule,ERCClosureRule,BVR);fflush(stdout);

				ITKCALL(AOM_ask_value_tags(DMLtaskTag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);

				char	rev_id1[ITEM_id_size_c+1];
				char*	cur_rev						= NULL;
				char*	part_item_id				= NULL;
				tag_t	DesignTag					= NULLTAG;

				if (PartCnt>0)
				{
					for (k=0;k<PartCnt ;k++ )
					{
						printf("\n\n\t\t hi all APL DML Cre:for k =:%d",k);fflush(stdout);

						AssyTag=NULLTAG;
						AssyTag=PartTags[k];

						cur_rev				= NULL;
						part_item_id				= NULL;

						ITKCALL(AOM_ask_value_string(AssyTag, "item_id", &part_item_id));

						ITKCALL(AOM_UIF_ask_value(AssyTag,"item_revision_id",&cur_rev));
						printf("\n\n\t  Part String is cur_rev--->%s",cur_rev);fflush(stdout);					

						int		LPCpart = 0;
						tag_t  *LatestPchildPart	=	NULLTAG;
						tag_t	window				=	NULLTAG;
						tag_t	rule				=	NULLTAG;
						tag_t	PartRevTag			=	NULLTAG;
						tag_t	top_line			=	NULLTAG;

						if(BOM_create_window (&window)!=ITK_ok);//PrintErrorStack();
						if(CFM_find(RevisionRule, &rule )!=ITK_ok);//PrintErrorStack();
						if(BOM_set_window_config_rule( window, rule )!=ITK_ok);//PrintErrorStack();
						if(BOM_set_window_top_line (window, NULLTAG, AssyTag, NULLTAG, &top_line)!=ITK_ok);//PrintErrorStack();
						printf("\n inside bom_window-----555\n"); fflush(stdout);
						if(BOM_line_ask_child_lines (top_line, &LPCpart, &LatestPchildPart));
						printf("\n\n\t\t No of child objects are n 555 : %d\n",LPCpart);fflush(stdout);

						if(LPCpart>0)
						{
							//finding successors revisions
							ITKCALL(ITEM_ask_item_of_rev(AssyTag, &PartRevTag));

							int			count1						=	0;
							char*  		rev_id1= NULL;
							tag_t *		rev_list					= NULLTAG;
							
							ITKCALL(ITEM_list_all_revs(PartRevTag, &count1,&rev_list));
							printf("\n\n\t\t WSOM count1:- %d\n\n",count1);fflush(stdout);
							int Flag = 0;
							int ii	 = 0;

							Flag = 0;
							for (ii = 0; ii < count1; ii++)
							{
								ITKCALL(ITEM_ask_rev_id2( rev_list[ii],&rev_id1));
								printf("\n\n\t  Part String is rev_id1--->%s",rev_id1);fflush(stdout);
								if(Flag ==1)
								{
									//successor revisions//
									//explode successor revisions and check for view mask.
									DesignTag   =    NULLTAG; //successor itemrev tag
									DesignTag	=	 rev_list[ii];

									int zz=0;
									
									for(zz=0;zz<LPCpart;zz++)
									{
										int iChildItemTag=0;
										tag_t   t_ChildItemRev;

										ITKCALL(BOM_line_unpack (LatestPchildPart[zz]));
										//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
										//ITKCALL(BOM_line_ask_attribute_tag(LatestPchildPart[zz], iChildItemTag, &t_ChildItemRev));
										AOM_ask_value_tag (LatestPchildPart[zz],bomAttr_lineItemRevTag, &t_ChildItemRev);
									
										if(t_ChildItemRev!=NULLTAG)
										{
											tag_t Bomline_tag = NULLTAG;

											Bomline_tag=NULLTAG;
											
											Bomline_tag = LatestPchildPart[zz];

											if(Bomline_tag!=NULLTAG)
											{
												int			attribute_flag			=	0;
												int			attribute_invalRel		=	0;
												int			attribute_vlaRel		=	0;
												char*		value_flag			=	NULL;
												char*		value_itemid		=	NULL;
												char*		value_itemRevID		=	NULL;
												char*		value_invalRel		=	NULL;
												char*		value_valRel		=	NULL;
												int			flagLoop			=	0;

												ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
												printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

												ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
												printf("\n value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);
												
												//ITKCALL(BOM_line_look_up_attribute(flagView, &attribute_flag));										
												//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
												AOM_UIF_ask_value(Bomline_tag, flagView, &value_flag);
												printf("\n  value_flag:%s ..............",value_flag);fflush(stdout);

												//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_InValidRelEPANo", &attribute_invalRel));
												//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_invalRel, &value_invalRel));
												AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_InValidRelEPANo", &value_invalRel);

												printf("\n child value_invalRel:%s ..............",value_invalRel);fflush(stdout);

												//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_RelEPANo", &attribute_vlaRel));
												//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_vlaRel, &value_valRel));
												AOM_UIF_ask_value(Bomline_tag, "bl_occ_t5_RelEPANo", &value_valRel);

												printf("\n D.child value_valRel:%s ..............",value_valRel);fflush(stdout);

												if(((tc_strstr(value_flag,"01-")!=NULL) || (tc_strstr(value_flag,"-1-")!=NULL) || (tc_strstr(value_flag,"--2")!=NULL)) && ((tc_strcmp(value_invalRel,"")!=0) || (tc_strcmp(value_valRel,"")!=0)))
												{
												
													UPDATEVIEWMASK:
													
													printf("\n hi label start \n"); fflush(stdout);		
													int		LPCpart1			=	0;
													tag_t  *LatestPchildPart1	=	NULLTAG;
													tag_t	window1				=	NULLTAG;
													tag_t	rule1				=	NULLTAG;
													tag_t	top_line1			=	NULLTAG;
													

																							

										
													if(BOM_create_window (&window1)!=ITK_ok);//PrintErrorStack();
													if(CFM_find(RevisionRule, &rule1 )!=ITK_ok);//PrintErrorStack();
													if(BOM_set_window_config_rule( window1, rule1 )!=ITK_ok);//PrintErrorStack();
													 //if(BOM_set_window_pack_all (window1, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window1, NULLTAG, DesignTag, NULLTAG, &top_line1)!=ITK_ok);//PrintErrorStack();
													printf("\n inside bom_window-----555\n"); fflush(stdout);
													if(BOM_line_ask_child_lines (top_line1, &LPCpart1, &LatestPchildPart1));
													printf("\n\n\t\t No of child objects are n LPCpart1 : %d\n",LPCpart1);fflush(stdout);

													int yy=0;
													int FlagGotPart=0;
													for(yy=0;yy<LPCpart1;yy++)
													{
														int iChildItemTag1=0;
														tag_t   t_ChildItemRev1;

														ITKCALL(BOM_line_unpack (LatestPchildPart1[yy]));
														//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag1));
														//ITKCALL(BOM_line_ask_attribute_tag(LatestPchildPart1[yy], iChildItemTag1, &t_ChildItemRev1));
														AOM_ask_value_tag (LatestPchildPart1[yy],bomAttr_lineItemRevTag, &t_ChildItemRev1);
												
														if(t_ChildItemRev1!=NULLTAG)
														{
															tag_t Bomline_tag1 = NULLTAG;

															Bomline_tag1=NULLTAG;
															Bomline_tag1 = LatestPchildPart1[yy];

															if(Bomline_tag1!=NULLTAG)
															{
																char*		value_flag1			=	NULL;
																char*		value_itemid1		=	NULL;
																char*		value_itemRevID1	=	NULL;
																int attribute_flag1=0;

																ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_id",&value_itemid1));
																printf("\n Arc Node child value_itemid1:%s ..............",value_itemid1);fflush(stdout);

																ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_revision_id",&value_itemRevID1));
																printf("\n value_itemRevID1:%s ..............",value_itemRevID1);fflush(stdout);

																//ITKCALL(BOM_line_look_up_attribute(flagView, &attribute_flag1));					
																//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag1, attribute_flag1, &value_flag1));
																AOM_UIF_ask_value(Bomline_tag1, flagView, &value_flag1);
																printf("\n  value_flag1:%s ..............",value_flag1);fflush(stdout);

																if(strcmp(value_itemid,value_itemid1)==0 )
																{
																	FlagGotPart=1;
																	printf("\n same ID match....%s",value_itemid);fflush(stdout);
																	
																	printf("\n tc_strlen(value_flag1) ....%d",tc_strlen(value_flag1));fflush(stdout);

																	if(tc_strlen(value_flag1)>0)
																	{
																		printf("\n  inside value_flag1:%s ..............",value_flag1);fflush(stdout);
																	}
																	else
																	{
																		printf("\n  View mask updating......");fflush(stdout);
																		//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1, attribute_flag1, value_flag));
																		ITKCALL(AOM_UIF_set_value(Bomline_tag1, flagView, value_flag));
																		if(tc_strcmp(value_invalRel,"")!=0)
																		{
																			//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1, attribute_invalRel, value_invalRel));
																			ITKCALL(AOM_UIF_set_value(Bomline_tag1, "bl_occ_t5_InValidRelEPANo", value_invalRel));
																		}
																		if(tc_strcmp(value_valRel,"")!=0)
																		{
																			//ITKCALL(BOM_line_set_attribute_string(Bomline_tag1, attribute_vlaRel, value_valRel));
																			ITKCALL(AOM_UIF_set_value(Bomline_tag1, "bl_occ_t5_RelEPANo", value_valRel));
																		}
																		printf("\n  View mask updated...");fflush(stdout);

																	}
																}

															}
														}
													} //successor for loop ..
													
											
													//sunny start

													//if(FlagGotPart==0)
													printf("\n  sunny value_flag:%s ..............",value_flag);fflush(stdout);
													printf("\n  sunny FlagGotPart:%d ..............",FlagGotPart);fflush(stdout);
													
													if((FlagGotPart==0) && (tc_strstr(value_flag,"--2")!=NULL)) // Currentview --(--2)

													{
														//to check whether APLC bvr exists or not 15197
														//if not create ps_create_bvr : to create bvr 
														//then add apl part: PS_create_occurrences

														printf("\n  after sign off  FlagGotPart ..............");fflush(stdout);

                                                   //sunny End 
														
														int		aplcViewFound					=	0;
														int     bvr_count_bsRev					=	0;
														tag_t	*bvrs_BSRev						=	NULLTAG;
														tag_t	bvr_BSRev1						=	NULLTAG;


														ITKCALL(ITEM_rev_list_bom_view_revs(DesignTag, &bvr_count_bsRev, &bvrs_BSRev));
														printf("\n bvr_count_bsRev %d ",bvr_count_bsRev);fflush(stdout);
														aplcViewFound=0;
														int assbvr=0;
														for(assbvr=0;assbvr<bvr_count_bsRev;assbvr++)
														{	
															char	*view_name						=	NULL;
															tag_t	itemTypeTag_cdss				=	NULLTAG;
															char	*type_itemRev					=	NULL;
															tag_t	bvr_BSRev1						=	NULLTAG;

															ITKCALL(AOM_ask_value_string(bvrs_BSRev[assbvr],"object_name",&view_name));
															printf("\n view_name %s",view_name);fflush(stdout);
															
															ITKCALL(TCTYPE_ask_object_type(bvrs_BSRev[assbvr],&itemTypeTag_cdss));
															ITKCALL(TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
															printf("\n22222Grp 98 type_itemRev : %s",type_itemRev);fflush(stdout);
															if(tc_strstr(view_name,APLViewBVR)!=NULL)
															{
																printf("\nInside view found");fflush(stdout);
																aplcViewFound++;
																bvr_BSRev1	=	bvrs_BSRev[assbvr];
																break;
															}
														}
														
														if (aplcViewFound==0 && bvr_count_bsRev ==1)
														{
															printf("\nInside view not found");fflush(stdout);
															aplcViewFound++;
															bvr_BSRev1	=	bvrs_BSRev[0];
														}

														if(aplcViewFound==0)
														{
															tag_t	*bvrs_BS						=	NULLTAG;
															int bvr_count_bs=0;
															tag_t	bom_view_bs						=	NULLTAG;
															tag_t	*occurrences				=	NULLTAG;
															tag_t	Item_ds		=	NULLTAG;

															ITKCALL(ITEM_ask_item_of_rev(DesignTag, &Item_ds));

															printf("\naplcViewFound is 0");fflush(stdout);
															ITKCALL(ITEM_list_bom_views( Item_ds, &bvr_count_bs, &bvrs_BS));
															printf("\n bvr_count_bs %d ",bvr_count_bs);fflush(stdout);

															if (bvr_count_bs<=0)
															{
																char	*getPlantViewName				=	NULL;
																tag_t	view_type_tag				=	NULLTAG;


																getPlantViewName=NULL;
																tm_GetViewFromDML(item_id, &getPlantViewName);
																printf("\nGrp98 getPlantViewName : %s",getPlantViewName);fflush(stdout);
																ITKCALL(PS_find_view_type(getPlantViewName,&view_type_tag ));

																ITKCALL(AOM_lock(Item_ds));
																ITKCALL(PS_create_bom_view (view_type_tag,"","",Item_ds,&bom_view_bs));
																ITKCALL(AOM_save_without_extensions(bom_view_bs));
																ITKCALL(AOM_save_without_extensions(Item_ds));
																ITKCALL(AOM_unlock(Item_ds));
															}
															else
															{
																bom_view_bs	=	bvrs_BS[0];
															}
															
															ITKCALL(AOM_lock(DesignTag));
															ITKCALL(PS_create_bvr (bom_view_bs,"","",false,DesignTag,&bvr_BSRev1));
															ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
															ITKCALL(AOM_save_without_extensions(DesignTag));
															ITKCALL(AOM_unlock(DesignTag));

															ITKCALL(PS_create_occurrences(bvr_BSRev1,t_ChildItemRev,NULLTAG,1,&occurrences));
															ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
															

															printf("\n calling UPDATEVIEWMASK label start \n"); fflush(stdout);
															if(flagLoop==0)
															{
																flagLoop=1;
																goto UPDATEVIEWMASK;
															}

														}
														else
														{
															tag_t	*occurrences					=	NULLTAG;
															printf("\n hi value_flag:%s ..............",value_flag);fflush(stdout);
															if (bvr_BSRev1!=NULLTAG)
															{
																ITKCALL(PS_create_occurrences(bvr_BSRev1,t_ChildItemRev,NULLTAG,1,&occurrences));
																ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
																printf("\n calling UPDATEVIEWMASK label start... \n"); fflush(stdout);
																if(flagLoop==0)
																{
																	flagLoop=1;
																	goto UPDATEVIEWMASK;
																}
																
															}
															else
															{
																printf("\n bvr_BSRev1 tag null ..");fflush(stdout);
															}

														}
													}

												}
											}

										}
									  
								   } // child part for loop under product pln
												
							   }

								if (strcmp(rev_id1,cur_rev)==0)
								{
									printf("\n \t  Both revisions match");
									Flag = 1;
								}
							 
						  }

						}
					}
				}

			}
		}
		else
		{
			printf("\n No proper class of T5_APLTaskRevision......\n");fflush(stdout);
		}

	  }
	return error_code;
} 


int ValidateSMRestRptGen(tag_t DMLtaskTag)
{
	tag_t  relation_type = NULLTAG;
	GRM_find_relation_type("IMAN_reference",&relation_type);
	time_t t = time(NULL);
	struct tm *tm_info = localtime(&t);
	char currdate[12];
	strftime(currdate, sizeof(currdate), "%d-%b-%Y", tm_info);
	if(relation_type != NULLTAG)
	{
	    printf("\n Reference Relation Exist");fflush(stdout);
	    char* relation_name;
	    char* DataSetObjectNameStr = NULL;
        tag_t*  attachments = NULLTAG;
        int Tcnt = 0;
        TCTYPE_ask_name2( relation_type, &relation_name);
        GRM_list_secondary_objects_only(DMLtaskTag,relation_type,&Tcnt,&attachments);
        tag_t  RptDataset = NULLTAG;
        tag_t  RptobjTypeTag = NULLTAG;
        char*   ObjectClassType;
        char*   DateSetCreationDate;
	    int NoOfFile = 0;
		int isReportGenrated = 0;
	    if (Tcnt > 0)
		{
			printf("\n Valid DataSet Exist");fflush(stdout);
			int Index = 0;
			for (Index = 0;Index<Tcnt;Index++)
			{
			    RptDataset = attachments[Index];
			    TCTYPE_ask_object_type(RptDataset,&RptobjTypeTag);
			    TCTYPE_ask_name2(RptobjTypeTag,&ObjectClassType);
			    printf("\n ObjectClassType :: %s\n", ObjectClassType);
			    AOM_UIF_ask_value(RptDataset,"creation_date",&DateSetCreationDate);
			    
			    if(tc_strcmp(ObjectClassType,"Text") == 0)
				{
				
				    char   **ref_list = NULL;
                    AOM_ask_displayable_values(RptDataset, "ref_list",&NoOfFile, &ref_list);
                    int FileCnt;
                    for (FileCnt = 0; FileCnt < NoOfFile; FileCnt++)
                    {
                        printf ("\n Named Reference %d is <%s> ", FileCnt + 1, ref_list[FileCnt]);
                    }
					if(tc_strstr(DateSetCreationDate,currdate) != NULL)
					{
						printf("\n Valid Report Exist");fflush(stdout);
						isReportGenrated = 1;
						break;
					}
				}
				
			}
		}
		if(NoOfFile>0)
		{
		 
		    printf ("\n currdate =%s", currdate);fflush(stdout);
		    printf ("\n DateSetCreationDate =%s", DateSetCreationDate);fflush(stdout);
			if(isReportGenrated == 0)
			{
				printf ("\n Please Re-Generate the restructuring Report before signoff the task. \n Select the SM DML and Go to Manufacturing --> Report --> APL Report --> SMDML BOM Restructuring Report option");fflush(stdout);
				char *t5MlStIntialErr=NULL;
				t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
				strcpy(t5MlStIntialErr,"");
				strcpy(t5MlStIntialErr,"Please Re-Generate the restructuring Report before signoff the task. \n Select the SM DML and Go to Manufacturing --> Report --> APL Report --> SMDML BOM Restructuring Report");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
				return 99;
			}
		}
		else
		{
			
			printf ("\n Please Generate the restructuring Report before signoff the task. \n Select the SM DML and Go to Manufacturing --> Report --> APL Report --> SMDML BOM Restructuring Report option");fflush(stdout);
		    char *t5MlStIntialErr=NULL;
		    t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
		    strcpy(t5MlStIntialErr,"");
		    strcpy(t5MlStIntialErr,"Please Generate the restructuring Report before signoff the task. \n Select the SM DML and Go to Manufacturing --> Report --> APL Report --> SMDML BOM Restructuring Report ");
		    EMH_clear_errors();
		    EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
		    return 99;
		}
	}
	return 9;
}



extern EPM_decision_t DLLAPI smdml_signoff_checks_Func(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t		 rootTask			= NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *itemid				=NULL;
	char       *smdmlType				=NULL;
	int							iNumAttch					= 0;
	tag_t * pTagAttch;
	tag_t  CurrentRoleTag = NULLTAG;
	char*       RoleName = NULL;
	char *PlantName=NULL;
	tag_t ItemTypeTag = NULLTAG;
	int i=0;
	int n_tags_found = 0;
	int CountSMDML = 0;
	int CounterSM = 0;

	//char *qry_entries[1] = {"ID"};
	//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	const char *qry_entries[1];//Multiple Item Queried Error
	const char *qry_values[1];//Multiple Item Queried Error
	tag_t	*itemclass							= NULLTAG;
	tag_t item = NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;

	tag_t objTypeTag                 =    NULLTAG;
	char*  type_name = NULL;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	char*  type_itemRev = NULL;
	char*  dmlclass = NULL;
	tag_t			TskToSMDMLRel= NULLTAG;
	tag_t			SMDMLRevTag		= NULLTAG;
	tag_t			SMDMLTypeTag		= NULLTAG;

	tag_t*			SMDMLTag		= NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	char	**qry_valuesCntrl_DVC= (char **) MEM_alloc(5 * sizeof(char *));
	int		n_entryCntrl_DVC= 5;
	char    *qry_entryCntrl_DVC[5]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1","Information-2"};	 	 
	int control_number_found_DVC=0;
	tag_t	*list_of_WSO_cntrl_tags_DVC	=	NULLTAG;
	char *DriverVCVal = NULL;
	char *sm_Qty = NULL;
	char *sm_valid_date = NULL;
	char *task_po_check = NULL;
	int		num_excomm=0;
	char **ExcomMembList    = NULL;
	char	**qry_valuesCntrl_Excom= (char **) MEM_alloc(5 * sizeof(char *));
	char	**qry_valuesCntrl_Qty= (char **) MEM_alloc(5 * sizeof(char *));
	int		n_entryCntrl_Excom=3;
	int		n_entryCntrl_Qty=5;
	int		control_number_found_Excom=0;
	int		control_number_found_Qty=0;
	char    *qry_entryCntrl_Excom[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	 	 
	char    *qry_entryCntrl_Qty[5]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1","Information-2"};	 	 
	tag_t	*list_of_WSO_cntrl_tags_Excom	=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags_Qty	=	NULLTAG;
	char *errorMsg = NULL;
	char *smtaskAttPrtNo = NULL;
	char *smtaskAttPrtNo1 = NULL;
	tag_t   queryTag_DVC     = NULLTAG;
	char **qry_values_DVC = (char **) MEM_alloc(10 * sizeof(char *));

	char StdWrkngLC[40];
	char StdResLC[40];
	char StdRelLC[40];
	char EpaPlnt[40];
	char plantDML[40];
	char flag[40];
	char APLViewBVR[40];
	char RevisionRule[40];
	char ERCClosureRule[40];
	char STDClosureRule[40];
	char occFlag[40];
	char BVR[40];
	char stdRlzdLcsR[40];
	char stdReRestLcsR[40];
	int num_to_sort_DVC=1;
	int n_entries_DVC=3;
	int A_entries_DVC=3;
	int nClhd=1;
	int childDVC=1;
	char *keys_DVC[1] = {"creation_date"};
	int  	 orders_DVC[1]  ={1};
	int resultCount_DVC=0;
	int SMPartCnt=0;
	int smPrtCnt=0,Qtyicount=0;
	int partAtthTaskFnd=0;
	tag_t *Rev_DVC=NULLTAG;
	char *qry_entries_DVC[3] = {"ID","Release Status","Type"};
	char *A_qry_entries_DVC[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	tag_t	VCRev_tag	= NULLTAG;
	char *driveVC_ID = NULL;
	char *taskowning_part = NULL;
	char *part_type = NULL;
	char *DChldName = NULL;
	char *DChldRev = NULL;
	char *smdmlprojCode = NULL;
	char *ppChldName = NULL;
	char *ppChldQty = NULL;
	char *DVChldQty = NULL;
	struct	BomChldStrut	ChldStrutDV[5000];
	char	**SetChildRelErr = NULL;//Make a string array
	tag_t*			SMPartTags			= NULLTAG;
	tag_t			SMAssyTag				= NULLTAG;
	tag_t			SMAssyTagTask				= NULLTAG;
	tag_t objChild   =    NULLTAG;
    tag_t t_DChldItemRev;
	tag_t objPPChild   =    NULLTAG;
	tag_t objDVChild   =    NULLTAG;
	tag_t t_PPChldItemRev;
	int status;

	int		iChildItemTag	=	0,icount=0,smPrtCnt1=0,nPrdPlanClhd=0,childPP=0, iChildItemTagPP	=	0,itemQty=0;
	int childDVC1=0,iChildItemTagDV=0,itemQty1=0,iLength=0,il=0,ii=0;
	struct	BomChldStrut	ChldPrdPlanStrutDV[5000];
	char	*tempErr	=	NULL;
	char	*ChildRelErr	= NULL;

	struct	BomChldStrut	ChldPrdPlanCStrutDV[5000];	//Deepti TZ1.54
	struct	BomChldStrut	ChldColourStrutDV[5000];	//Deepti TZ1.54

	tag_t   GenQryTag     = NULLTAG; //sanket
	int     n_entryCnt    = 2;
	char    *qry_entry[2]  = {"Type","Name"};
	char	**qry_value= (char **) MEM_alloc(5 * sizeof(char *));
	int     AmdenObjects=0;
	tag_t *list_of_tags=NULLTAG;
	int s,ss=0;
	int RowsFound=0;
	tag_t *RowTag=NULL;
	char *DrVCno=NULL;
	int ErrorFlag=0;
	char *driveVC_ID1 =NULL;
	char *driveVC_rev = NULL;


	printf("\n Calling smdml_signoff_checks_Func .....\n");fflush(stdout);
	
	SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n smdml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName));
	printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);

	PlantName=subString(RoleName,3,4);
    printf( "PlantName:%s\n", PlantName);fflush(stdout);
    
	char *AmdenVal=NULL; //sanket
	if (PlantName != NULL)
	{
		if (tc_strcmp(PlantName,"STDP")==0)
		{
			AmdenVal="IBVC_PUNE";

		}
		else if (tc_strcmp(PlantName,"STDD")==0)
		{
			AmdenVal="IBVC_DWD";
		}
		else if (tc_strcmp(PlantName,"STDL")==0)
		{
			AmdenVal="IBVC_LKN";
		}
		else if (tc_strcmp(PlantName,"STDJ")==0)
		{
			AmdenVal="IBVC_JSR";
		}
		else if (tc_strcmp(PlantName,"STDU")==0)
		{
			AmdenVal="IBVC_PNR";
		}
		else
		{
			printf("\n Amden Obj not found."); fflush(stdout);
		}
	}
	printf( "\n Amden Obj:%s", AmdenVal);fflush(stdout);

	get_CtrlVal_SMDMLStateInf(PlantName,StdWrkngLC,StdResLC,StdRelLC,EpaPlnt,plantDML,flag,APLViewBVR,occFlag,stdRlzdLcsR,stdReRestLcsR);

	if(tc_strcmp(CurrentTask,"Perform Restructuring")==0)
	{
		ITKCALL( TCTYPE_find_type("T5_SMDMLTaskRevision", NULL, &ItemTypeTag));
		for (i=0; i < iNumAttch; i++)
		{
			
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);fflush(stdout);
			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITKCALL(ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass));
			if(n_tags_found>0) item = itemclass[0];
			if(item != NULLTAG )ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag,&type_name) );
			printf("\t  type_name ...%s\n", type_name);fflush(stdout);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");fflush(stdout);

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));


				if(tc_strcmp(type_itemRev,"T5_SMDMLTaskRevision" )==0)
				{
						printf("\n\n\t\t Isnide SM DML Revison");fflush(stdout);

						if(tc_strstr(RoleName,"STD")==NULL)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please set the role to STD.Only STD user are able to Signoff the SM-DML.");
							decision = EPM_nogo;
							return ITK_errStore1;	
						
						}

						
						ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToSMDMLRel));
						if (TskToSMDMLRel!=NULLTAG)
						{
							ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToSMDMLRel,&CountSMDML,&SMDMLTag));
							printf("\n\n\t\t dss CountDML : %d",CountSMDML);fflush(stdout);

							for (CounterSM=0;CounterSM<CountSMDML;CounterSM++ )
							{
							
									SMDMLRevTag = SMDMLTag[CounterSM];

									ITKCALL (TCTYPE_ask_object_type(SMDMLRevTag,&SMDMLTypeTag));
									ITKCALL (TCTYPE_ask_name2(SMDMLTypeTag,&dmlclass));
									printf("\n\n\t\t dmlclass %s\n",dmlclass);fflush(stdout);

									if(tc_strcmp(dmlclass,"T5_SMDMLRevision")==0)
									{
										ITKCALL(AOM_ask_value_string(SMDMLRevTag,"t5_SMDMLType",&smdmlType));
										printf("\n smdmlType Signoff %s\n",smdmlType);fflush(stdout);

										ITKCALL(AOM_ask_value_string(SMDMLRevTag,"t5_cprojectcode",&smdmlprojCode));
										printf("\n smdmlType Signoff %s\n",smdmlprojCode);fflush(stdout);

                                        //sanket

										ITKCALL(AOM_ask_value_string(SMDMLRevTag,"t5_DriverVC",&driveVC_ID1));
										printf("\n smdml Driver VC: %s\n",driveVC_ID1);fflush(stdout);

										if(tc_strcmp(smdmlType,"IBVCRES")==0)
										{
											
										  ITKCALL(QRY_find2("General...", &GenQryTag));
			                              if (GenQryTag != NULLTAG)
			                              {
				                            printf("\n General Query Found.");fflush(stdout);
				                            qry_value[0]="Amden Table";
				                            qry_value[1]=AmdenVal;
				
				                            ITKCALL(QRY_execute(GenQryTag, n_entryCnt, qry_entry, qry_value, &AmdenObjects, &list_of_tags));
			                               }
			                               else
			                               {
				                             printf("\n General Query not Found.");fflush(stdout);
			                               }	
			
			                               printf("\n Amden Objects found is : %d",AmdenObjects);fflush(stdout);
										   if (AmdenObjects>0)
									       {
											 tag_t AmdenObjTag =NULLTAG;
											 for (s=0;s<AmdenObjects;s++)
											 {
												AmdenObjTag =list_of_tags[s];
												ITKCALL(AOM_ask_table_rows(AmdenObjTag,"t5_AmdTablerow",&RowsFound,&RowTag));
												printf("\n Number of rows found is : %d",RowsFound);fflush(stdout);
												if (RowsFound>0)
												{
													for (ss=0;ss<RowsFound;ss++)
													{
														ITKCALL(AOM_ask_value_string(RowTag[ss],"t5_AmdPartNumber",&DrVCno));
														printf("\n Driver VC number from Amden Table:%s",DrVCno);fflush(stdout);   
														if (tc_strcmp(driveVC_ID1,DrVCno)==0)
														{
														  ErrorFlag++;
														  printf("\n ErrorFlag:%d",ErrorFlag);fflush(stdout);
														  printf("\n VC found in amden table.");fflush(stdout);
																					
														}

													}
												}
												/*
											    if (ErrorFlag==1)
												{
													EMH_clear_errors();
												    EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Driver VC not found in Amden Table.");
													return ITK_errStore1;

												}
												*/
											}
										}
                                       }
										
										if(QRY_find2("Control Objects...", &qryTagCntrl));
										if (qryTagCntrl)
										{		
											printf("\n Control Object Query Found so finding for Driver VC Control Object smdml Signoff \n");fflush(stdout);
											
											qry_valuesCntrl_DVC[0]="STDVErr";
											qry_valuesCntrl_DVC[1]="SignOffErr";
											qry_valuesCntrl_DVC[2]="0";
											qry_valuesCntrl_DVC[3]="DriverVC";
											qry_valuesCntrl_DVC[4]=PlantName;

											if(QRY_execute(qryTagCntrl, n_entryCntrl_DVC, qry_entryCntrl_DVC, qry_valuesCntrl_DVC, &control_number_found_DVC, &list_of_WSO_cntrl_tags_DVC));
											printf("\n control_number_found_DVC smdml Signoff%d\n",control_number_found_DVC);fflush(stdout);

											if (ErrorFlag==0)
											{
											
											if(control_number_found_DVC>0)
											{
													if((tc_strcmp(smdmlType,"STDRES")==0) || (tc_strcmp(smdmlType,"STDFIALRES")==0) || (tc_strcmp(smdmlType,"SML")==0) || (tc_strcmp(smdmlType,"KA")==0) || (tc_strcmp(smdmlType,"IBVCRES")==0) )
													{
													
														ITKCALL(AOM_ask_value_string(SMDMLRevTag,"t5_DriverVC",&DriverVCVal));
														printf("\n DriverVCVal smdml Signoff %s\n",DriverVCVal);fflush(stdout);
														
														if(tc_strcmp(DriverVCVal,"")==0)
														{
															
															if (qryTagCntrl)
															{
																ITKCALL(AOM_ask_value_string(SMDMLRevTag, "t5_SMQtyy", &sm_Qty));
																printf("\n sm_Qty %s\n",sm_Qty);fflush(stdout);

																ITKCALL(AOM_UIF_ask_value(SMDMLRevTag,"t5_SMValidTill",&sm_valid_date));
																printf("\n sm_valid_date %s\n",sm_valid_date);fflush(stdout);

																ITKCALL(AOM_ask_value_strings(SMDMLRevTag,"t5_EXCOMMembr",&num_excomm,&ExcomMembList));
																printf("\n num_excomm %d\n",num_excomm);fflush(stdout);

																int count_mail=0;
																tag_t dml_rel_type;
																tag_t*			ReferencesTag		= NULLTAG;

																ITKCALL(GRM_find_relation_type("IMAN_reference", &dml_rel_type));

																if (dml_rel_type!=NULLTAG)
																{
																	ITKCALL(GRM_list_secondary_objects_only(SMDMLRevTag,dml_rel_type,&count_mail,&ReferencesTag));
																	printf("\n\t\t References count_mail : %d",count_mail); fflush(stdout);
																}
																
																
																qry_valuesCntrl_Excom[0]="EXCOM";
																qry_valuesCntrl_Excom[1]="SMQty";
																qry_valuesCntrl_Excom[2]="0";
																
																if(QRY_execute(qryTagCntrl, n_entryCntrl_Excom, qry_entryCntrl_Excom, qry_valuesCntrl_Excom, &control_number_found_Excom, &list_of_WSO_cntrl_tags_Excom));
																printf("\n control_number_found_Excom %d\n",control_number_found_Excom);fflush(stdout);
																if(control_number_found_Excom>0)
																{

																	if((tc_strcmp(sm_Qty,"")==0) || (tc_strcmp(sm_valid_date,"")==0) || (num_excomm==0) || (count_mail==0))
																	{
																		
																		if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																		errorMsg=(char *)MEM_alloc(1000);
																		
																		tc_strcpy(errorMsg,"Please Ensure the Complete Information Against below Mentioned Fields since you have not enter Driver VC.\n");
																		tc_strcat(errorMsg,"1. Exception Approval By EXCOM Member.\n");
																		tc_strcat(errorMsg,"2. Validity Till.\n");
																		tc_strcat(errorMsg,"3. Quantity.\n");
																		tc_strcat(errorMsg,"4. Select Approval Mail of EXCOM Member.(Select Browse and Then Upload the required Approval Mail)");

																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																		decision = EPM_nogo;
																		return ITK_errStore1;									
																	
																	}
																}
																else
																{
																	if((tc_strcmp(sm_valid_date,"")==0) || (num_excomm==0)|| (count_mail==0))
																	{
																		
																		if (tc_strcmp(errorMsg,"NULL") !=0) MEM_free(errorMsg);
																		errorMsg=(char *)MEM_alloc(1000);
																		
																		tc_strcpy(errorMsg,"Please Ensure the Complete Information Against below Mentioned Fields since you have not enter Driver VC.\n");
																		tc_strcat(errorMsg,"1. Exception Approval By EXCOM Member.\n");
																		tc_strcat(errorMsg,"2. Validity Till.\n");
																		tc_strcat(errorMsg,"3. Select Approval Mail of EXCOM Member.(Select Browse and Then Upload the required Approval Mail)");

																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
																		decision = EPM_nogo;
																		return ITK_errStore1;									
																	
																	}							
																
																
																}
															}											
																												
														}
														else
														{
															if(QRY_find2("DriverVCQuerySM", &queryTag_DVC));
															printf("\n After IFERR_REPORT : QRY_find smdml signoff\n");fflush(stdout);

															qry_values_DVC[0] = DriverVCVal ;
															qry_values_DVC[1] = StdRelLC ;
															qry_values_DVC[2] = "Design Revision" ;

															if(QRY_execute_with_sort(queryTag_DVC, n_entries_DVC, qry_entries_DVC, qry_values_DVC, num_to_sort_DVC, keys_DVC, orders_DVC, &resultCount_DVC, &Rev_DVC));
															if (resultCount_DVC>0)
															{
																VCRev_tag = Rev_DVC[resultCount_DVC-1];

																ITKCALL(AOM_ask_value_string( VCRev_tag, "item_id", &driveVC_ID));
																ITKCALL(AOM_ask_value_string( VCRev_tag, "item_revision_id", &driveVC_rev));
																printf("\n driveVC_ID  smdml signoff: %s\n",driveVC_ID);fflush(stdout);
																printf("\n driveVC_Revision_ ID  smdml signoff: %s\n",driveVC_rev);fflush(stdout);

																ITKCALL(AOM_ask_value_string(VCRev_tag, "t5_PartType", &part_type));
																
																if ((tc_strcmp(part_type,"V")==0) ||(tc_strcmp(part_type,"VC")==0)||(tc_strcmp(part_type,"VCCR")==0))
																{
																	printf("\n Driver VC Part Type:%s \n", part_type);fflush(stdout);								
																}
																else
																{
																	printf("\n Driver VC Part Type is V/VC/VCCR..\n");fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Driver VC Type is not VC/Vehicle/Vehicle Combination CR..");
																	decision = EPM_nogo;
																	return ITK_errStore1;
																}

																//Aniket
																ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&SMPartCnt,&SMPartTags));  //Task attached parts
																printf("\n\n\t\t SM DML Cre:Now SMPartCnt:%d",SMPartCnt);fflush(stdout);
																getPlantWiseRRCCDriverVC(RoleName,RevisionRule,STDClosureRule,ERCClosureRule,BVR);

																printf("\n  getPlantWiseRRCCDriverVC detaisl:%s:%s,%s ..............",STDClosureRule,ERCClosureRule,BVR);fflush(stdout);

																
																tag_t   A_queryTag_DVC     = NULLTAG;
																char **A_qry_values_DVC = (char **) MEM_alloc(10 * sizeof(char *));
																tag_t	*A_list_of_cntrl_tags_DRVC	=	NULLTAG;
																int ctrcount=0;
																if(QRY_find2("Control Objects...", &A_queryTag_DVC));

																A_qry_values_DVC[0] = "DriverVCVal" ;
																A_qry_values_DVC[1] = "DriverVCVal";
																A_qry_values_DVC[2] = "0";

																if(QRY_execute(A_queryTag_DVC, A_entries_DVC, A_qry_entries_DVC, A_qry_values_DVC, &ctrcount,&A_list_of_cntrl_tags_DRVC));
																if (ctrcount>0)
																{
																	TC_write_syslog("Driver VC Validation Start......\n");

																	char* t5_Userinfo1 = NULL;
																	char* t5_Userinfo2 = NULL;
																	char* t5_Userinfo3 = NULL;
																	char* t5_Userinfo4 = NULL;
																	char* t5_Userinfo5 = NULL;
																	char* solutionfolderparts = NULL;
																	solutionfolderparts= (char *) MEM_alloc( 10 * sizeof(char) );
																	char cmd[200];
																	int aaaa =0;
																	char * matched=NULL;
																	matched= (char *) MEM_alloc( 10 * sizeof(char) );
																	char * Not_matched=NULL;
																	Not_matched= (char *) MEM_alloc( 10 * sizeof(char) );
																	int flagsm =0;
																	printf("\n\n\t\t Driver VC Control Object found.....");fflush(stdout);
																	tag_t object = A_list_of_cntrl_tags_DRVC[0];
																	ITKCALL(AOM_ask_value_string(object,"t5_Userinfo1",&t5_Userinfo1));
																	ITKCALL(AOM_ask_value_string(object,"t5_Userinfo2",&t5_Userinfo2));
																	ITKCALL(AOM_ask_value_string(object,"t5_Userinfo3",&t5_Userinfo3));
																	ITKCALL(AOM_ask_value_string(object,"t5_Userinfo4",&t5_Userinfo4));
																	ITKCALL(AOM_ask_value_string(object,"t5_Userinfo5",&t5_Userinfo5));
																	printf("\n Information 1:-%s\n",t5_Userinfo1);fflush(stdout);
																	printf("\n Information 2:- %s\n",t5_Userinfo2);fflush(stdout);
																	printf("\n Information 3:- %s\n",t5_Userinfo3);fflush(stdout);
																	printf("\n Information 4:- %s\n",t5_Userinfo4);fflush(stdout);
																	printf("\n Information 5:- %s\n",t5_Userinfo5);fflush(stdout);

																	time_t current_time = time(NULL);  
																	struct tm *tm_info = localtime(&current_time);
																	printf("Time befor shell script: %s", asctime(tm_info));

																	char * driveVC_rev_update = (char *) MEM_alloc( 100 * sizeof(char) );
																	tc_strcpy(driveVC_rev_update,"");
																	tc_strcpy(driveVC_rev_update,"\"");
																	tc_strcat(driveVC_rev_update,driveVC_rev);
																	tc_strcat(driveVC_rev_update,"\"");

																	printf("\n Updated Revision ID is:- %s",driveVC_rev_update);

																	sprintf(cmd,"%s  %s %s %s %s %s %s",t5_Userinfo1,t5_Userinfo2,t5_Userinfo3,t5_Userinfo4,t5_Userinfo5,driveVC_ID,driveVC_rev_update);

																	printf("Excuting Command = %s",cmd);fflush(stdout);
																	int status = system(cmd);  // Running OOTB Utility BOM Writer.   4 min 
																	time_t current_time1 = time(NULL);  
																	struct tm *tm_info1 = localtime(&current_time1);
																	printf("Time After shell script: %s", asctime(tm_info1));

																	printf("\n After executing Aniket Command");fflush(stdout);
																	printf("\n Status:- %d",status);fflush(stdout);
																	printf("\n Completed wait....");fflush(stdout);
																	if (status == 0)
																	{
																		if (WIFEXITED(status))
																		{
																			int exit_code = WEXITSTATUS(status);
																			printf("Shell script finished with exit code: %d\n", exit_code);
																			printf("\n Validation Started......");fflush(stdout);
																			FILE *fp;
																			FILE *fp1;
																			char input[200];
																			//char* lok = "/home/apldev/devgroups/Aniket/bomexpension/export/";
																			int aaaa =0;
																			char* location=NULL;
																			location=(char *)MEM_alloc(100);
																			tc_strcpy(location,t5_Userinfo5);
																			tc_strcat(location,driveVC_ID);
																			tc_strcat(location,".psup");
																			char* soln_parts=NULL;

																			printf("\n Location :-  %s",location);
																			
																			char inputline[100];
																			int count=0;
																			//char inputline[MAX_LINE_LENGTH];
																			time_t current_time2 = time(NULL);  
																			struct tm *tm_info2 = localtime(&current_time2);
																			printf("Time befor start validation:- %s", asctime(tm_info2));
																			for(aaaa=0;aaaa<SMPartCnt ;aaaa++)
																			{
																				SMAssyTag=SMPartTags[aaaa];
																				partAtthTaskFnd=0;
																				ITKCALL(AOM_ask_value_string(SMAssyTag,"item_id",&smtaskAttPrtNo1));																	
																				printf("\n smtaskAttPrtNo:%s ..............",smtaskAttPrtNo1);fflush(stdout);
																				TC_write_syslog("smtaskAttPrtNo:%s\n",smtaskAttPrtNo1);
																				fp = fopen(location, "r");
																				if(fp!=NULL)
																				{
																					while(fgets(inputline,sizeof(inputline),fp)!=NULL)
																					{
																						count++;
																						//printf("\n inputline:- %s",inputline);
																						TC_write_syslog("Driver VC Content:-%s\n",inputline);

																						if(tc_strstr(inputline,smtaskAttPrtNo1)!=NULL)
																						{
																							printf("\n Condition Satisfy.. Inside Loop..  ");fflush(stdout);
																							partAtthTaskFnd++;	
																							printf("\n part found partAtthTaskFnd:%d ..............",partAtthTaskFnd);fflush(stdout);
																							break;																		
																						}
																					}	
																					fclose(fp); 
																					printf("\n after while loop cout is:- %d ..............",partAtthTaskFnd);fflush(stdout);	

																					if(partAtthTaskFnd==0)
																					{
																						if (cnt==0)
																						{
																							cnt++;
																							printf("\n before [icount] %d,error part %s ..............",icount,smtaskAttPrtNo1);fflush(stdout);
																							tc_strcpy(ChildRelErr," ");
																							tc_strcat(ChildRelErr,"Below Mentioned Parts attached to task are not found in Driver VC:");
																							tc_strcat(ChildRelErr,smtaskAttPrtNo1);
																							printf("\n Error statement is:- [%s] ..............",ChildRelErr);fflush(stdout);
																						}
																						else
																						{
																							tc_strcat(ChildRelErr,smtaskAttPrtNo1);
																						}
																					}																					
																				}
																				else
																				{
																					printf("\n File Not found......");fflush(stdout);
																					TC_write_syslog("Driver VC File not Available at Mention location...\n");	
																				}																				
																			}																			
																			if(cnt>0)
																			{																					
																				setAddStrFuction(&icount,&SetChildRelErr,ChildRelErr);
																			}
																			
																			time_t current_time3 = time(NULL);  
																			struct tm *tm_info3 = localtime(&current_time3);
																			printf("Time after validation:- %s", asctime(tm_info3));	
																				
																		 
																			if (qryTagCntrl)
																			{		
																				printf("\n Control Object Query Found so checking for QTY Mismatch \n");fflush(stdout);
																				
																				qry_valuesCntrl_Qty[0]="APLMBOM";
																				qry_valuesCntrl_Qty[1]="FailureMode";
																				qry_valuesCntrl_Qty[2]="0";
																				qry_valuesCntrl_Qty[3]="DriverVCQty";
																				qry_valuesCntrl_Qty[4]=smdmlprojCode;

																				if(QRY_execute(qryTagCntrl, n_entryCntrl_Qty, qry_entryCntrl_Qty, qry_valuesCntrl_Qty, &control_number_found_Qty, &list_of_WSO_cntrl_tags_Qty));
																				printf("\n control_number_found_Qty smdml Signoff%d\n",control_number_found_Qty);fflush(stdout);
																				if(control_number_found_Qty>0)
																				{
																					for (smPrtCnt1=0;smPrtCnt1<SMPartCnt ;smPrtCnt1++ )
																					{
																						SMAssyTagTask=SMPartTags[smPrtCnt1];																				

																						ITKCALL(AOM_ask_value_string(SMAssyTagTask,"item_id",&smtaskAttPrtNo));
																						printf("\n  smtaskAttPrtNo:%s ..............",smtaskAttPrtNo);fflush(stdout);

																						nPrdPlanClhd	= 0;
																						// Solution folder part expanded here....   SMAssyTagTask = Solution folder part.
																						ITKCALL(Get_Part_BOM_Lvl(SMAssyTagTask,1,STDClosureRule,RevisionRule,BVR,ChldPrdPlanStrutDV,&nPrdPlanClhd));//child parts of Solution items
																						
																						for (childPP = 1; childPP <= nPrdPlanClhd; childPP++)
																						{
																							
																							objPPChild			  =    NULLTAG;
																							t_PPChldItemRev       =    NULLTAG;
																							ppChldName            =    NULL;																				
																							objPPChild   =     ChldPrdPlanStrutDV[childPP].child_objs;

																							iChildItemTagPP	=	0;																					
																							partAtthTaskFnd	=	0;	
																							AOM_ask_value_tag (objPPChild,bomAttr_lineItemRevTag, &t_PPChldItemRev);

																							ITKCALL(AOM_ask_value_string(objPPChild,"item_id",&ppChldName));
																							printf("\n child ppChldName:%s ..............",ppChldName);fflush(stdout);

																							ITKCALL(AOM_UIF_ask_value(objPPChild,"owning_group",&taskowning_part));
																							printf("\n  taskowning_groupVal:%s ..............",taskowning_part);fflush(stdout);

																							if((tc_strstr(taskowning_part,"APL")!=NULL) || ((tc_strstr(taskowning_part,"STD")!=NULL)))
																							{
																								continue;
																							}
																							fp = fopen(location, "r");
																							if(fp!=NULL)
																							{
																								while(fgets(inputline,sizeof(inputline),fp)!=NULL)
																								{
																									count++;
																									//printf("\n inputline:- %s",inputline);
																								
																									TC_write_syslog("Driver VC Content:-%s\n",inputline);
																									if(tc_strstr(inputline,ppChldName)!=NULL)
																									{
																										printf("\n Condition Satisfy.. Inside Loop..  ");fflush(stdout);
																										partAtthTaskFnd++;	
																										printf("\n part found partAtthTaskFnd:%d ..............",partAtthTaskFnd);fflush(stdout);
																										break;	
																																											
																									}
																								}	
																								fclose(fp); 
																								printf("\n part found partAtthTaskFnd:%d ..............",partAtthTaskFnd);fflush(stdout);
																								if(partAtthTaskFnd==0)
																								{
																									
																									if (Qtyicount==0)
																									{
																										setAddStrFuction(&icount,&SetChildRelErr,"\n below mentioned Child Part are not same in Driver VC");
																										Qtyicount++;
																									}
																									
																									if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
																									ChildRelErr=(char *)MEM_alloc(50);
																									tc_strcpy(ChildRelErr,"\n");
																									tc_strcat(ChildRelErr,"Child");
																									tc_strcat(ChildRelErr,ppChldName);
																									tc_strcat(ChildRelErr,"of Parent");
																									tc_strcat(ChildRelErr,smtaskAttPrtNo);
																						
																									setAddStrFuction(&icount,&SetChildRelErr,ChildRelErr);
																								}
																							}
																							else
																							{
																								printf("\n File Not found......");fflush(stdout);
																								TC_write_syslog("Driver VC File not Available at Mention location...\n");
																							}
																							
																					
																						}
																					
																					}

																				}
																			}
																			
																		} 
																		else
																		{
																			printf("Shell script did not terminate normally\n");
																			TC_write_syslog("Driver VC shell Not wait for the return code\n");
																			return -2;
																		}
																	}
																	else
																	{

																		printf("Failed to call shell\n");
																		tc_strcpy(ChildRelErr," ");
																		tc_strcat(ChildRelErr,"Driver VC Validation not Called .... Kindly Connect with PLM Support Team");
																		setAddStrFuction(&icount,&SetChildRelErr,ChildRelErr);
																		TC_write_syslog("Driver VC Shell execute with error code.....\n");
																	}
																	TC_write_syslog("Driver VC Validation End.........\n");

																	if (tc_strcmp(driveVC_rev_update,"NULL") !=0)
																	{
																		MEM_free(driveVC_rev_update);
																	}
																	
																}
																else
																{
																	printf("\n\n\t\t Control Object Not found.......");fflush(stdout);
																	nClhd	= 0;
																	ITKCALL(Get_Part_BOM_Lvl(VCRev_tag,99,ERCClosureRule,RevisionRule,BVR,ChldStrutDV,&nClhd));//Driver VC child parts
																	if (SMPartCnt>0)
																	{
																		for (smPrtCnt=0;smPrtCnt<SMPartCnt ;smPrtCnt++ )
																		{
																			SMAssyTag=SMPartTags[smPrtCnt];
																			partAtthTaskFnd=0;
	
																			ITKCALL(AOM_ask_value_string(SMAssyTag,"item_id",&smtaskAttPrtNo));
																			printf("\n  smtaskAttPrtNo:%s ..............",smtaskAttPrtNo);fflush(stdout);
	
																			for (childDVC = 1; childDVC <= nClhd; childDVC++)
																			{
																				
																				 objChild			  =    NULLTAG;
																				 t_DChldItemRev       =    NULLTAG;
	
																				 DChldName            =    NULL;
																				 DChldRev             =    NULL;
	
																				 objChild   =     ChldStrutDV[childDVC].child_objs_bvr;
	
																				 iChildItemTag	=	0;
																				 
																				 //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																				 //BOM_line_ask_attribute_tag(objChild,iChildItemTag,&t_DChldItemRev);
																				   AOM_ask_value_tag (objChild,bomAttr_lineItemRevTag, &t_DChldItemRev);
																				   
																				 ITKCALL(AOM_ask_value_string(t_DChldItemRev,"item_id",&DChldName));
																				 printf("\n child DChldName:%s ..............",DChldName);fflush(stdout);
	
																				if(tc_strcmp(smtaskAttPrtNo,DChldName)==0)
																				{
																					partAtthTaskFnd++;
																					break;
																				
																				}
	
																			}
	
																			if(partAtthTaskFnd=0)
																			{
																				printf("\n [icount] %d,",icount);fflush(stdout);
																				if (icount==0)
																				{
																					printf("\n before [icount] %d,error part %s ..............",icount,smtaskAttPrtNo);fflush(stdout);
																					setAddStrFuction(&icount,&SetChildRelErr,"Below Mentioned Parts attached to task are not found in Driver VC:");
																				}																	
																				printf("\n before part copy [icount] %d,error part %s ..............",icount,smtaskAttPrtNo);fflush(stdout);
																				
																				if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
																				ChildRelErr=(char *)MEM_alloc(50);
																				tc_strcpy(ChildRelErr,"\n");
																				tc_strcat(ChildRelErr,smtaskAttPrtNo);
																				
																				setAddStrFuction(&icount,&SetChildRelErr,ChildRelErr);
																																				
																					
																			
																			}
	
																		}
	
																		if (qryTagCntrl)
																		{		
																			printf("\n Control Object Query Found so checking for QTY Mismatch \n");fflush(stdout);
																			
																			qry_valuesCntrl_Qty[0]="APLMBOM";
																			qry_valuesCntrl_Qty[1]="FailureMode";
																			qry_valuesCntrl_Qty[2]="0";
																			qry_valuesCntrl_Qty[3]="DriverVCQty";
																			qry_valuesCntrl_Qty[4]=smdmlprojCode;
	
																			if(QRY_execute(qryTagCntrl, n_entryCntrl_Qty, qry_entryCntrl_Qty, qry_valuesCntrl_Qty, &control_number_found_Qty, &list_of_WSO_cntrl_tags_Qty));
																			printf("\n control_number_found_Qty smdml Signoff%d\n",control_number_found_Qty);fflush(stdout);
																			if(control_number_found_Qty>0)
																			{
																				for (smPrtCnt1=0;smPrtCnt1<SMPartCnt ;smPrtCnt1++ )
																				{
																					SMAssyTagTask=SMPartTags[smPrtCnt1];																				
	
																					ITKCALL(AOM_ask_value_string(SMAssyTagTask,"item_id",&smtaskAttPrtNo));
																					printf("\n  smtaskAttPrtNo:%s ..............",smtaskAttPrtNo);fflush(stdout);
	
																					nPrdPlanClhd	= 0;
																					// Solution folder part expanded here....   SMAssyTagTask = Solution folder part.
																					ITKCALL(Get_Part_BOM_Lvl(SMAssyTagTask,1,STDClosureRule,RevisionRule,BVR,ChldPrdPlanStrutDV,&nPrdPlanClhd));//child parts of Solution items
																					
																					for (childPP = 1; childPP <= nPrdPlanClhd; childPP++)
																					{
																						
																						objPPChild			  =    NULLTAG;
																						t_PPChldItemRev       =    NULLTAG;
	
																						ppChldName            =    NULL;																				
	
																						objPPChild   =     ChldPrdPlanStrutDV[childPP].child_objs_bvr;
	
																						iChildItemTagPP	=	0;																					
																						partAtthTaskFnd	=	0;																					
	
																						//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTagPP);
																						//BOM_line_ask_attribute_tag(objPPChild,iChildItemTagPP,&t_PPChldItemRev);
																						AOM_ask_value_tag (objPPChild,bomAttr_lineItemRevTag, &t_PPChldItemRev);
	
																						ITKCALL(AOM_ask_value_string(t_PPChldItemRev,"item_id",&ppChldName));
																						printf("\n child ppChldName:%s ..............",ppChldName);fflush(stdout);
	
																						ITKCALL(AOM_UIF_ask_value(t_PPChldItemRev,"owning_group",&taskowning_part));
																						printf("\n  taskowning_groupVal:%s ..............",taskowning_part);fflush(stdout);
	
																						if((tc_strstr(taskowning_part,"APL")!=NULL) || ((tc_strstr(taskowning_part,"STD")!=NULL)))
																						{
																							continue;
																						}
																						
																						 //Grp98 Logic need to be included.
																						 //ITKCALL(BOM_line_look_up_attribute ("bl_quantity",&itemQty));
																						 //ITKCALL(BOM_line_ask_attribute_string(objPPChild,itemQty, &ppChldQty));
																						 AOM_UIF_ask_value(objPPChild, "bl_quantity", &ppChldQty);
																						 printf("\n ppChldQty:%s ..............",ppChldQty);fflush(stdout);
	
																						 for (childDVC1 = 1; childDVC1 <= nClhd; childDVC1++)
																						 {
																							
																							 objDVChild			  =    NULLTAG;
																							 t_DChldItemRev       =    NULLTAG;
	
																							 DChldName            =    NULL;
																							 DChldRev             =    NULL;
	
																							 objDVChild   =     ChldStrutDV[childDVC1].child_objs_bvr;
	
																							 iChildItemTagDV	=	0;
																							 
																							 //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTagDV);
																							 //BOM_line_ask_attribute_tag(objDVChild,iChildItemTagDV,&t_DChldItemRev);
																							 AOM_ask_value_tag (objDVChild,bomAttr_lineItemRevTag, &t_DChldItemRev);
	
																							 ITKCALL(AOM_ask_value_string(t_DChldItemRev,"item_id",&DChldName));
																							 printf("\n child DChldName:%s ..............",DChldName);fflush(stdout);
	
																							 //ITKCALL(BOM_line_look_up_attribute ("bl_quantity",&itemQty1));
																							 //ITKCALL(BOM_line_ask_attribute_string(objDVChild, itemQty1, &DVChldQty));
																							 AOM_UIF_ask_value(objDVChild, "bl_quantity", &DVChldQty);
																							 printf("\n DVChldQty:%s ..............",DVChldQty);fflush(stdout);
	
																							if(tc_strcmp(ppChldName,DChldName)==0)
																							{
																								
																								if(tc_strcmp(ppChldQty,DVChldQty)!=0)
																								{
																									partAtthTaskFnd++;
																																																
																								}
																								break;
																							
																							}
	
	
																						}
	
																						if(partAtthTaskFnd>0)
																						{
																							
																							if (Qtyicount==0)
																							{
																								setAddStrFuction(&icount,&SetChildRelErr,"\n Quantity of the below mentioned Part are not same in Driver VC:");
																								Qtyicount++;
																							}
																							
																							if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
																							ChildRelErr=(char *)MEM_alloc(50);
																							tc_strcpy(ChildRelErr,"\n");
																							tc_strcat(ChildRelErr,ppChldName);
																				
																							setAddStrFuction(&icount,&SetChildRelErr,ChildRelErr);
																							
																						
																						}
																					}
																				
																				}

																			}
																		}
	
																	}
																}

																
															}
															else		//Deepti TZ1.50
															{
																printf("\n 11 Driver VC Part Type is not found !!!\n");fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please enter valid Driver VC Number having Release Status as STDSI Released as per plant.");
																decision = EPM_nogo;
																return ITK_errStore1;
															
															}
														}
													
													}
											}
											}//sanket
											
										}								
									
									
									}							
							
							
							}
						}

					printf("\n error printing..icount:%d ..............",icount);fflush(stdout);
					if(icount>0)
					{
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							printf("tempErr : ");fflush(stdout);
							for (il=0; il < icount; il++)
							{
								printf("SetChildRelErr[il]: %s",SetChildRelErr[il]);fflush(stdout);
								iLength	=	iLength	+	tc_strlen(SetChildRelErr[il]);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (ii=0; ii < icount; ii++)
							{
								if(ii==0)
								tc_strcpy(tempErr,SetChildRelErr[ii]);
								else
								tc_strcat(tempErr,SetChildRelErr[ii]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);						
							decision = EPM_nogo;
							return ITK_errStore;				
					
					}
					else
					{
						
						
						char    *qryEntrySMHasRestRpt[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
			            char    *qryValuesSMHasRestRpt[3]= {"STDSI","SMHASRESTRPT","0"};
			            tag_t qryTagSTDSISMHasRestRpt=NULLTAG;
			            int qryCountSMHasRestRpt=0;
			            tag_t* qryResultTaskHasEPA=NULLTAG;
			            ITKCALL(QRY_find2("Control Objects...", &qryTagSTDSISMHasRestRpt));
			            if (qryTagSTDSISMHasRestRpt != NULLTAG)
			            {
                           printf("\n ---Control Object Query Found For SM Has Restructuring report HardCheck--- \n");fflush(stdout);
                           ITKCALL(QRY_execute(qryTagSTDSISMHasRestRpt, 3, qryEntrySMHasRestRpt, qryValuesSMHasRestRpt, &qryCountSMHasRestRpt, &qryResultTaskHasEPA));
                           printf("\n ---Control Object Query Count For SM Has Restructuring report HardCheck =%d",qryCountSMHasRestRpt);fflush(stdout);
			            }
			            if(qryCountSMHasRestRpt>0)
			            {
			            	
							int RptStatus = 0;
			            	RptStatus = ValidateSMRestRptGen(item_rev_tag);
							printf("\n SM RptStatus =%d",RptStatus);
							if(RptStatus == 99)
							{
								
								decision = EPM_nogo;
								return ITK_errStore;
							}
			            }
						

					
						task_po_check=NULL;
						ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_POCheckStatus", &task_po_check));
						printf("\n task_po_check.. %s \n",task_po_check);fflush(stdout);
						if(strcmp(task_po_check,"")==0)
						{
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the PO check before Signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementaion-->PO Checks");
							decision = EPM_nogo;
							return ITK_errStore;				
						}
						else if(strcmp(task_po_check,"POCHKFAIL")==0)
						{
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PO Check fails.Please check the PO Report attached with Task. ");
							decision = EPM_nogo;
							return ITK_errStore;				
						}
						else if(strcmp(task_po_check,"POCHKPASS")==0)
						{
							printf("\n task_po_check POCHKPASS.. %s \n",task_po_check);fflush(stdout);

							
							//Added by DEEPTI for TZ1.54 Backend for Colour Part Restructuring

							tm_amsm_colour_part_restructuring(item_rev_tag);							

							//End by DEEPTI for TZ1.54 Backend for Colour Part Restructuring


						}
						else
						{				
							printf("\n task_po_check.. POCHKPASS");fflush(stdout);	
						}			
					
					
					}
				
				}
			}
		}
	}
	else if(tc_strcmp(CurrentTask,"Revert the Change")==0)
	{
		
		ITKCALL( TCTYPE_find_type("T5_SMDMLTaskRevision", NULL, &ItemTypeTag));
		for (i=0; i < iNumAttch; i++)
		{
			
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);fflush(stdout);
			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			if(n_tags_found>0) item = itemclass[0];
			if(item != NULLTAG )ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag,&type_name) );
			printf("\t  type_name ...%s\n", type_name);fflush(stdout);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");fflush(stdout);

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));


				if(tc_strcmp(type_itemRev,"T5_SMDMLTaskRevision" )==0)
				{
						printf("\n\n\t\t Isnide SM DML Revison");fflush(stdout);

						if(tc_strstr(RoleName,"STD")==NULL)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please set the role to STD.Only STD user are able to Signoff the SM-DML.");
							decision = EPM_nogo;
							return ITK_errStore1;	
						
						}
				}
			}
		}
	
	
	}
  decision = EPM_go;
  return decision;

}

extern int tm_sm_dml_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    METHOD_id_t  method3;
    METHOD_id_t  method4;
    int ifail=0;
	char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("sm_dml_claim", "", sm_dml_claim))
   {
		printf("\t\n Registered Action Handler sm_dml_claim_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler sm_dml_claim_register_method\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("sm_dml_restructred", "", sm_dml_restructred))
   {
		printf("\t\n Registered Action Handler sm_dml_restructred_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler sm_dml_restructred_register_method\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("sm_dml_released", "", sm_dml_released))
   {
		printf("\t\n Registered Action Handler sm_dml_released_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler sm_dml_released_register_method\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("sm_dml_re_restructred", "", sm_dml_re_restructred))
   {
		printf("\t\n Registered Action Handler sm_dml_re_restructred_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler sm_dml_re_restructred_register_method\n");fflush(stdout);
   }


   
	ifail = METHOD_find_method("T5_SMDMLRevision", ITEM_create_msg, &method1);
	if (method1.id != NULL)
	{
		ifail = METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) createSMDML_Task, NULL)!=ITK_ok;
		printf("\n ITEM_create_msg for SMDMLRevision Creation\n");fflush(stdout);
	}else
	{
		printf("\n ITEM_create_msg Method not found!TC_save_msg\n");fflush(stdout);
	}

	/*ifail = METHOD_find_method("T5_SMDMLRevision", IMAN_save_msg, &method4);
	if( ifail == ITK_ok )
	{
		printf("\n IMAN_save_msg Before register method for T5_SMDMLRevision \n");
		if (method4.id != NULL)
		{
			if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) smdml_validate_dialog, NULL)!=ITK_ok)
			printf("\n IMAN_save_msg for T5_SMDMLRevision Creation\n");fflush(stdout);
		}else
		{
			printf("\n Method not found for T5_SMDMLRevision !TC_save_msg\n");
		}
	}*/

	ifail = METHOD_find_method("CMHasSolutionItem", GRM_create_msg, &method2);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for GRM_create_msg in T5_SMDMLRevision\n");
		if (method2.id != NULL)
		{
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) sm_dml_part_attach, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for T5_SMDMLRevision\n");
		}
		else
		printf("Method not found!GRM_create_msg T5_SMDMLRevision\n");
	}

	if( ITK_ok == EPM_register_action_handler("sm_carryFrwrd_rstrctr_changes", "", sm_carryFrwrd_rstrctr_changes))
	{
		printf("\t\n Registered Action Handler sm_carryFrwrd_rstrctr_changes_register_method\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler apl_carryFrwrd_rstrctr_changes_register_method\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("sm_carryFrwrd_revert_changes", "", sm_carryFrwrd_revert_changes))
	{
		printf("\t\n Registered Action Handler sm_carryFrwrd_sm_carryFrwrd_revert_changes_changes_register_method\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler apl_carryFrwrd_rstrctr_changes_register_method\n");fflush(stdout);
	}

   if( ITK_ok == EPM_register_rule_handler("smdml_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)smdml_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler smdml_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler smdml_signoff_checks_Func\n");fflush(stdout);
   }

	

    return ITK_ok;
}

extern DLLAPI int tm_sm_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("tm_sm_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_sm_dml_assign_register_method);

     printf("\n registered function tm_sm_dml_assign\n");	fflush(stdout);



	 return ( ITK_ok );
}

