#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
// #include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
// #include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
// #include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
// #include <tc/iman.h>
// #include <tccore/imantype.h>
// #include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
// #include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
// #include <epm/cr_effectivity.h>
#include <tccore/item_msg.h>
#include <pie/pie.h>

#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define POM_enquiry_desc_order 1
#define POM_enquiry_like 16001

int cnt = 0;
int cntFlag = 0;

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


static int report_error(char *file, int line, char *call, int status, logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        int const    *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
        if (n_errors > 0)
        {
            printf("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            //EMH_get_error_string (NULLTAG, status, &error_message_string);
            EMH_ask_error_text (status, &error_message_string);
            printf("\n%s\n", error_message_string);
        }

        printf("error %d at line %d in %s\n", status, line, file);
        printf("%s\n", call);

        if (exit_on_error)
        {
            printf("\nExiting program!\n");
            exit (status);
        }
    }
    return status;
}

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;

int val(char c)
{
    if (c >= '0' && c <= '9')
        return (int)c - '0';
    else
        return (int)c - 'A' + 10;
}
 
// Function to convert a number from given base 'b'
// to decimal
int toDeci(char *str, int base)
{
    int len = strlen(str);
    int power = 1; // Initialize power of base
    int num = 0;  // Initialize result
    int i;
 
    // Decimal equivalent is str[len-1]*1 +
    // str[len-1]*base + str[len-1]*(base^2) + ...
    for (i = len - 1; i >= 0; i--)
    {
        // A digit in input number must be
        // less than number's base
        if (val(str[i]) >= base)
        {
           printf("Invalid Number");
           return -1;
        }
 
        num += val(str[i]) * power;
        power = power * base;
    }
 
    return num;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


//Start Code to Explode BOM -3
void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	
	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,"View")==0)
				{
					flagBVR=1;	
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					if(tc_strcmp(viewTok,ViewBVR)==0)
					{
						flagBVR=1;	
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 1.42 Backend
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev); 
			AOM_ask_value_tag (children[k],"bl_line_object", &t_ChildItemRev);
			
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);		
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				
				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}
	
	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;
	
	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;	
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);	
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{
			
			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);	
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;
		
		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);
		
	}
	return ifail;
}
//End Code to Explode BOM -3


void  GetPlantDetails1( char * ES_Plnt ,char  getPlantCS[40] ,char  getLCSAPLRlz[40],char  getLCSSTDWrkg[40],char  getLCSSTDRlz[40],char  ContexPlantVal[40], char View[40], char ClsrRule[40], char RevRule[40])
{
      printf( "ES_Plnt:%s\n", ES_Plnt);

	  if(strcmp(ES_Plnt,"DHARWAD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApldRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDdWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStddRlzd");
		tc_strcpy(ContexPlantVal,"DHARWAD");
		tc_strcpy(View,"APLD View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLD");
		//tc_strcpy(RevRule,"APLD Released data only");
		tc_strcpy(RevRule,"APLD Released and Above");

	  }else  if(strcmp(ES_Plnt,"CVBU PUNE")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplpRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdpRlzd");
		tc_strcpy(ContexPlantVal,"CVBU Pune");
		tc_strcpy(View,"APLP View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLP");
		//tc_strcpy(RevRule,"APLP Released data only");
		tc_strcpy(RevRule,"APLP Released and Above");

	  }else  if( strcmp(ES_Plnt,"CAR")==0 || strcmp(ES_Plnt,"PCBU")==0 )
	  {
		printf("\n Inside CAR plnt ....");
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdRlzd");
		tc_strcpy(ContexPlantVal,"CAR");
		tc_strcpy(View,"APLC View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLC");
		//tc_strcpy(RevRule,"APLC Released data only");
		tc_strcpy(RevRule,"APLC Released and Above");

	  }else  if(strcmp(ES_Plnt,"CVBU JSR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApljRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDjWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdjRlzd");
		tc_strcpy(ContexPlantVal,"CVBU JSR");
		tc_strcpy(View,"APLJ View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLJ");
		//tc_strcpy(RevRule,"APLJ Released data only");
		tc_strcpy(RevRule,"APLJ Released and Above");


	  }else  if(strcmp(ES_Plnt,"CVBU LKO")==0 || strcmp(ES_Plnt,"PCBU LKO")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApllRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDlWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdlRlzd");
		tc_strcpy(ContexPlantVal,"CVBU LKO");
		tc_strcpy(View,"APLL View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLL");
		//tc_strcpy(RevRule,"APLL Released data only");
		tc_strcpy(RevRule,"APLL Released and Above");


	  }
	  //else  if(strcmp(ES_Plnt,"SMALLCAR AHD")==0 )
	  else  if(strcmp(ES_Plnt,"AHD")==0 ) // Updated by Ketan
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplaRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDaWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdaRlzd");
		//tc_strcpy(ContexPlantVal,"SMALLCAR AHD");
		tc_strcpy(ContexPlantVal,"AHD"); // Updated by Ketan
		tc_strcpy(View,"APLA View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLA");
		//tc_strcpy(RevRule,"APLA Released data only");
		tc_strcpy(RevRule,"APLA Released and Above");


	  }
	  else  if(strcmp(ES_Plnt,"SANAND")==0 ) // Added by Ketan
	  {
		tc_strcpy(getPlantCS,"t5_SndMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplsRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDsWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdsRlzd");
		tc_strcpy(ContexPlantVal,"SANAND"); 
		tc_strcpy(View,"APLS View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLS");
		//tc_strcpy(RevRule,"APLA Released data only");
		tc_strcpy(RevRule,"APLS Released and Above");


	  }
	  else  if(strcmp(ES_Plnt,"CVBU PNR")==0 || strcmp(ES_Plnt,"SMALLCAR PNR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApluRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDuWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStduRlzd");
		tc_strcpy(ContexPlantVal,"CVBU PNR");
		tc_strcpy(View,"APLU View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLU");
		//tc_strcpy(RevRule,"APLU Released data only");
		tc_strcpy(RevRule,"APLU Released and Above");

	  }else  if(strcmp(ES_Plnt,"TMLDL JSR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplsRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDsWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdsRlzd");
		tc_strcpy(ContexPlantVal,"CVBU JSR");
		tc_strcpy(View,"APLJ View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLJ");
		//tc_strcpy(RevRule,"APLJ Released data only");
		tc_strcpy(RevRule,"APLJ Released and Above");

	  }
	  else  if(strcmp(ES_Plnt,"PUVBU")==0) // to be change first
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplvRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDvWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdvRlzd");

		tc_strcpy(ContexPlantVal,"PUVBU");
		tc_strcpy(View,"APLV View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLV");
		//tc_strcpy(RevRule,"APLV Released data only");
		tc_strcpy(RevRule,"APLV Released and Above");

	  }
	  else
	 {
		printf("\n Inside Else ....");
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcspAplpRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdpRlzd");
		tc_strcpy(ContexPlantVal,"CVBU Pune");
		tc_strcpy(View,"APLP View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLP");
		//tc_strcpy(RevRule,"APLP Released data only");
		tc_strcpy(RevRule,"APLP Released and Above");


	  }
}

// Ketan Added // TZ 1.76
extern EPM_decision_t DLLAPI ES_Role_Validation(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	
	tag_t	rootTask		=	NULLTAG;
	tag_t	item_rev_tag	= NULLTAG;
	tag_t*  pTagAttch;
	tag_t	CurrentRoleTag	= NULLTAG;
	
	
	char*	CurrentTask				= NULL;
	char*	parent_name				= NULL;
	char*	Item_id					= NULL;
	char*	itemid;
	//char    roleName[SA_name_size_c+1];
	char*	roleName					= NULL;

	int iNumAttch	= 0;
	int i			= 0;
	int Item_ID		= 0;
	int	STD_Part_task_checked_out_val_cnt = 0;
	
	printf("\n Ketan Inside ES_Role_Validation .....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask: %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name: %s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 3;
	
	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found for ES_Role \n");fflush(stdout);
		qry_valuesCntrlformat[0]="ES_Role";
		qry_valuesCntrlformat[1]="Validation";
		qry_valuesCntrlformat[2]="0";
							
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found for ES_Role \n");fflush(stdout);
	}

	printf("\n controlObjfound is for ES_Role ==> %d\n",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
		printf("\n Live. Inside ES_Role Validation for PSD Reviewer \n");fflush(stdout);

		if((tc_strstr(CurrentTask,"Review By PSD")!=NULL) && (tc_strstr(roleName,"PSD_Reviewer")== NULL)) // PSD Reviewer Approve
		{
			printf("\n Error : PSD Reviewer Approve \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please Set the Correct Role while Approve Estimate Sheet from PSD Reviewer.");
			
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			printf("\n Role is ok for PSD Reviewer \n");fflush(stdout);
		}
	}

	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI estimate_sheet_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	int status1;
	int status2;
	int status3;
	int status33;
	int status34;
	int status4;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char*	itemiddup;
	char*	ESPlt;
	char*	EsShop;
	char*	ESProcEdn;
	char*	PsdStdTime;
	char*	AplStdTime;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char *type_name=NULL;
	//char  type_name[TCTYPE_name_size_c+1];
	int   ifail				= 0;
	char *type_itemRev=NULL;
	//char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			OprNo				= NULL;
	char*			WcNum				= NULL;
	char*			APLTime				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	char PlantCS[40];
	char LcsAplRlz[40];
	char LcsStdWrkg[40];
	char LcsStdRlz[40];
	char ContxtPlntVal[40];
	char ESView[40];
	char ClosureRule[40];
	char RevsnRule[40];
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char *  roleName = NULL;
    
	cntFlag = 0;
	char *  Errr = NULL;
	char *  APLTimeSet = NULL;
	char *  PrtSet = NULL;

	char *username= NULL;
	char *userid= NULL;

	int cnt = 0;
	int cnt1 = 0;
	int cntFlag = 0;
	tag_t			user_tag				=NULLTAG;
	char* ItemIdNm=NULL;
										

	printf("\n Calling estimate_sheet_signoff_checks_Func %d.....\n",iNumAttch);

	if (tc_strcmp(Errr,"NULL") !=0) MEM_free(Errr);
				Errr=(char *)MEM_alloc(5000);
				tc_strcpy(Errr," ");


if (tc_strcmp(APLTimeSet,"NULL") !=0) MEM_free(APLTimeSet);
				APLTimeSet=(char *)MEM_alloc(5000);
				tc_strcpy(APLTimeSet," ");

if (tc_strcmp(PrtSet,"NULL") !=0) MEM_free(PrtSet);
				PrtSet=(char *)MEM_alloc(5000);
				tc_strcpy(PrtSet," ");


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n new estimate_sheet_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\n CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	// Added By Ketan // 

	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 3;
	
	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found for ES_Role \n");fflush(stdout);
		qry_valuesCntrlformat[0]="ES_Role";
		qry_valuesCntrlformat[1]="Validation";
		qry_valuesCntrlformat[2]="0";
							
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found for ES_Role \n");fflush(stdout);
	}

	printf("\n controlObjfound is for ES_Role ==> %d\n",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
		printf("\n Live. Inside ES_Role Validation \n");fflush(stdout);
		
		if((tc_strcmp(CurrentTask,"Assign Estimate Sheet")==0) && (tc_strstr(roleName,"ES_Planner_")== NULL)) // APL Planner Signoff
		{
			printf("\n Error : APL Planner Signoff \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please Set the Correct Role while Releasing Estimate Sheet from APL Planner.");
			return ITK_errStore1;
		}
		else if((tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(roleName,"PSD_Planner")== NULL)) // PSD Planner Signoff
		{
			printf("\n Error : PSD Planner Signoff \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please Set the Correct Role while Releasing Estimate Sheet from PSD Planner.");
			return ITK_errStore1;
		}

		else if((tc_strstr(CurrentTask,"Reviewer can review Estimate")!=NULL) && (tc_strstr(roleName,"ES_Reviewer_")== NULL)) // APL Reviewer Approve
		{
			printf("\n Error : APL Reviewer Approve \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Please Set the Correct Role while Approve Estimate Sheet from APL Reviewer.");
			
			decision = EPM_nogo;
			return decision;
		}		
	}

	// Ended


 	ITKCALL( TCTYPE_find_type("T5_EstimateSheetRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		//char *qry_entries[1];
		//char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;
		int n_found1=0;
		 tag_t	*itemclass	= NULLTAG;
		 tag_t	*CntrlObjs	= NULLTAG;
		  tag_t item = NULLTAG;
			tag_t query = NULLTAG;
			tag_t query1 = NULLTAG;
			int n_entries=4;
			int n_entries1=3;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemiddup));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PEPlantName",&ESPlt));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_EstShop",&EsShop));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PEProcessEDNNo",&ESProcEdn));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PETimeOpnPsd",&PsdStdTime));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PETimeOpnApl",&AplStdTime));

			printf("\n itemid %s.....\n",itemid);
			printf("\n itemiddup %s.....\n",itemiddup);
			printf("\n ESPlt %s.....\n",ESPlt);
			printf("\n EsShop %s.....\n",EsShop);
			printf("\n ESProcEdn %s.....\n",ESProcEdn);
			printf("\n PsdStdTime %s.....\n",PsdStdTime);
			printf("\n AplStdTime %s.....\n",AplStdTime);
			
	GetPlantDetails1(ESPlt,PlantCS,LcsAplRlz,LcsStdWrkg,LcsStdRlz,ContxtPlntVal,ESView,ClosureRule,RevsnRule);
	printf("\n PlantCS: %s \n",PlantCS);
	printf("\n LcsAplRlz: %s \n",LcsAplRlz);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
	printf("\n LcsStdRlz: %s \n",LcsStdRlz);
	printf("\n ContxtPlntVal: %s \n",ContxtPlntVal);
	printf("\n ESView: %s \n",ESView);
	printf("\n ClosureRule: %s \n",ClosureRule);
	printf("\n RevsnRule: %s \n",RevsnRule);


// added by dss 1.51 ///
tag_t dquery1 = NULLTAG;
int d_entries1=3;
int d_found1=0;
tag_t	*dCntrlObjs	= NULLTAG;

	char
	    *dqry_entry[3] = {"SUBSYSCD", "SYSCD","Delete Indicator"},
	    *dqry_vall[3] =  {"Estimate Sheet", "Check","0"};
	   
	   
	   IFERR_REPORT(QRY_find2("Control Objects...", &dquery1));
	   //IFERR_REPORT(QRY_find2("ControlObjQry", &query1));
	   printf("\n After fins qryyy-- ");fflush(stdout);
	   IFERR_REPORT(QRY_execute(dquery1, d_entries1, dqry_entry, dqry_vall, &d_found1, &dCntrlObjs));
	   printf("\n d_found1: %d", d_found1);fflush(stdout);
// added by dss 1.51 ///

char
         *qry_entries[4] = {"ID","Plant Name","*Shop Name","Process EDN Number"},
         *qry_values[4] =  {itemid,ESPlt,EsShop,ESProcEdn};

	
    IFERR_REPORT(QRY_find2("EstimateRevPlantShopEdnQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_tags_found, &itemclass));
    printf("\n n_tags_found %d", n_tags_found);fflush(stdout);

		item = itemclass[0];

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			if (!SetChildRelErr) MEM_free(SetChildRelErr);
			SetChildRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetChildRelErr,"");

			if(tc_strcmp(type_itemRev,"T5_EstimateSheetRevision" )==0)
			{
					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(item,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);

							AssyTag				= NULLTAG;
							AssyTag=PartTags[k];

							OprNo=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&OprNo));
							printf("\n\n\t\t Operation Number is :%s",OprNo);fflush(stdout);
							
							WcNum=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"t5_EPOCHPEBCNo",&WcNum));
							printf("\n\n\t\t WorkCenter Number is :%s",WcNum);fflush(stdout);
							printf("\n\n\t\t WorkCenter length is :%d",strlen(WcNum));fflush(stdout);

							if(strlen(WcNum)==0)
							{
								if(cnt==0)
								{
										cnt = 1;
										tc_strcat(Errr,"\nWork Centers Not found for below operations of Estimate Sheet");
										tc_strcat(Errr,"\nPlease Ensure Work Centers are present on all operations for Estimate sheet\n");
										tc_strcat(Errr,OprNo);
										tc_strcat(Errr,",");
										

								}else
									{
										 
										tc_strcat(Errr,OprNo);
										tc_strcat(Errr,",");
									   cnt = cnt+1;
								   }
								   
							}


							APLTime=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"t5_PETimeOpnApl",&APLTime));
							printf("\n\n\t\t APLTime  is :%s",APLTime);fflush(stdout);

							if( tc_strcmp(APLTime,"0")!=0 || tc_strcmp(APLTime,"0.0")!=0 || tc_strcmp(APLTime,"0.00")!=0 )
							{
								/*check whether process sheet attached to ES or not.
								if process sheet not attached
								{
									if(cnt1==0)
									{
											cnt1 = 1;
											tc_strcat(APLTimeSet,"\nProcess Sheet attachment to each Operation with non-zero timing is Mandatory");
											tc_strcat(APLTimeSet,"\nSOLUTION: Please make sure process sheet send to PLM from NPP\n");
											tc_strcat(APLTimeSet,OprNo);
											tc_strcat(APLTimeSet,",");

									}
									else
										{
											tc_strcat(APLTimeSet,OprNo);
											tc_strcat(APLTimeSet,",");
										    cnt1 = cnt1+1;
									   }


								}
								*/

							}

						}
					}
					else
					{
							if (PartCnt==0)
							{
								printf("\n Estimate Sheet with zero operations");fflush(stdout);
								EMH_clear_errors();
								status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nOperations are not present for the Estimate Sheet you are releasing\nPlease Ensure You release the Estimate Sheet with operations");
								//status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,"\nOperations are not present for the Estimate Sheet you are releasing\nPlease Ensure You release the Estimate Sheet with operations");
								decision = EPM_nogo;
								return ITK_errStore;
							}
						

					}


					printf("\n Errr: %s\n",Errr);fflush(stdout);
					
				if( tc_strcmp(CurrentTask,"Assign Estimate Sheet" )==0 || ( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) ) )
				{
					if(cnt>0)
					{
						printf("\n Estimate Sheet with blank WC:  %s \n",Errr);fflush(stdout);
						EMH_clear_errors();
						status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
						decision = EPM_nogo;
						return ITK_errStore;
					}

					// Added by dss 1.51

					if(d_found1>0)
					{
						char			*PrtNo		= NULL;
						
						const char *dqry_entries[2];
						const char *dqry_values[2];

						int d_tags_found=0;
						tag_t	*ditemclassp	= NULLTAG;
						tag_t ditem = NULLTAG;
						int Item_count      =  0;
						tag_t	*drev_list				= NULL;

						int dstat_count=0;
						tag_t*	dstat_list;
						int FlagGotLatestAPLRlzRev=0;

						PrtNo=strtok( itemiddup, "-" );
						printf("\n PrtNo: %s.", PrtNo);fflush(stdout);
						
						dqry_entries[0] ="item_id";
						dqry_entries[1] ="object_type";
						tag_t	PartMasterTag	=	NULLTAG;
						ITKCALL(ITEM_find_item( PrtNo, &PartMasterTag ));
						char*	MaterCObjectType = NULL;
						ITKCALL(AOM_ask_value_string(PartMasterTag,"object_type",&MaterCObjectType));
						printf("\n Master Class object type : %s",MaterCObjectType );fflush(stdout);

						dqry_values[0] = PrtNo;
						// dqry_values[1] = "Design";
						dqry_values[1] = MaterCObjectType;
						
						ITEM_find_items_by_key_attributes(2, dqry_entries, dqry_values,&d_tags_found, &ditemclassp);
						
						ditem = ditemclassp[0];

						ITKCALL(ITEM_list_all_revs (ditem, &Item_count, &drev_list));
						printf("\n Total rev found: %d.", Item_count);fflush(stdout);

						if(Item_count > 0)
							{
								int zz=0;
								for(zz=Item_count-1; zz>=0; zz--)
								{
									printf("\n check whether part apl released from plant");fflush(stdout);
									ITKCALL(WSOM_ask_release_status_list(drev_list[zz],&dstat_count,&dstat_list));
									if(dstat_count == 0)
									{
										printf("\n NO LCS Found for part : %d\n",dstat_count);fflush(stdout);
										//break;
									}
									else
									{	
										int LCSi=0;
										for (LCSi=0;LCSi<dstat_count ;LCSi++ )
										{
											char*			class_name=NULL;
											ITKCALL(AOM_ask_value_string(dstat_list[LCSi],"object_name",&class_name));
											printf("\n class_name: %s\n",class_name);fflush(stdout);
											
											if(tc_strcmp(class_name,LcsAplRlz)==0)
											{
												FlagGotLatestAPLRlzRev=1;
												break;
											}
										}
										printf("\n FlagGotLatestAPLRlzRev : %d\n",FlagGotLatestAPLRlzRev);fflush(stdout);
									}
									if(FlagGotLatestAPLRlzRev==1)
									{
									  break;		
									}

								}
						
							} // end of if(Item_count > 0)

							printf("\n FlagGotLatestAPLRlzRev : %d\n",FlagGotLatestAPLRlzRev);fflush(stdout);
						
							if(FlagGotLatestAPLRlzRev==1)
							{
								char			*Part_CS		= NULL;
								ITKCALL(AOM_ask_value_string(drev_list[Item_count-1],PlantCS,&Part_CS));
								printf("\n Part_CS: %s\n",Part_CS);fflush(stdout);

								if(tc_strcmp(Part_CS,"E50")==0 || tc_strcmp(Part_CS,"E98")==0 ||  tc_strcmp(Part_CS,"E99")==0)
								{
									printf("\n Part_CS: %s is ok .. np \n",Part_CS);fflush(stdout);
								}
								else
								{
									printf("\n Part not with CS E50/E99/E98 ");fflush(stdout);
									EMH_clear_errors();
									status34=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\n Latest APL Released Part is not with CS E50/E99/E98, Not Allow to Release Estimate Sheet for part with CS other than E99/E50/E98");
									decision = EPM_nogo;
									return ITK_errStore;	

								}
							}
							else
							{
								printf("\n No APL Released Part Found ");fflush(stdout);
								EMH_clear_errors();
								status34=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\n APL Released Part Not Found for Plant.");
								decision = EPM_nogo;
								return ITK_errStore;	
							}
						
					}

					//end added by dss 1.51
				}


					// Process Sheet ES Checks
					if(POM_get_user_id (&userid)==ITK_ok);
					printf("\n\n  userid : %s\n",userid); fflush(stdout);

					ITKCALL(POM_get_user(&username,&user_tag));
            		printf("\n Starting for username :%s....\n",username);fflush(stdout);

					//if(nlsStrCmp(userid,"pgm02434")==0 && nlsStrCmp(t5PEDNTypeDup,"AW")==0 )
					if( tc_strcmp(userid,"pgm02434")==0 && tc_strcmp(CurrentTask,"Assign Estimate Sheet")==0 )
					{
					  printf("\nSetting attribute");fflush(stdout);

					  ITKCALL(AOM_lock(item));
					 // ITKCALL ( AOM_set_value_string(item,"t5_PfdStatus","True"));
					  ITKCALL ( AOM_set_value_logical(item,"t5_PfdStatus",true));
					  ITKCALL(AOM_save_without_extensions(item));
					  ITKCALL(AOM_unlock(item));
					}


	

 //if(nlsStrCmp(StrUsrNamDup,"pgm02434")==0 && nlsStrCmp(t5PEDNTypeDup,"AR")==0 )
				if( tc_strcmp(userid,"pgm02434")==0 && tc_strcmp(CurrentTask,"Reviewer can review Estimate")==0 )
					{
						printf("\nBypass process sheet check");fflush(stdout);
						goto CLEANUP;
					}

					printf("\n ESPlt %s.....\n",ESPlt);fflush(stdout);

					if( tc_strcmp(ESPlt,"CVBU PUNE")==0 && tc_strcmp(CurrentTask,"Reviewer can review Estimate")==0 )
					{
						if(cnt1>0)
						{
							printf("\n Process Sheet check for non zero APL timing:  %s \n",APLTimeSet);fflush(stdout);

							EMH_clear_errors();
							status2=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,APLTimeSet);
							decision = EPM_nogo;
							return ITK_errStore;
						}


					}

				//Added TZ1.48 by dss
					if( tc_strcmp(CurrentTask,"Assign Estimate Sheet" )==0 )
					{
					  if(strlen(AplStdTime)==0)
						{
								printf("\n Estimate Sheet with no APL timing");fflush(stdout);

								EMH_clear_errors();
								status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease do the following activity before signoff the Estimate Sheet\nSelect Estimate Sheet, Manufacturing --> Planning --> Estimate Sheet --> Update All Estimate Operation(APL View)");
								decision = EPM_nogo;
								return ITK_errStore;
						}
					}

				//Added TZ1.48 by dss


				if( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) )
					{
					  if(strlen(PsdStdTime)==0)
						{
								printf("\n Estimate Sheet with no PSD timing");fflush(stdout);

								EMH_clear_errors();
								status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease do the following activity before signoff the Estimate Sheet\nSelect Estimate Sheet, Manufacturing --> Planning --> Estimate Sheet --> Update All Estimate Operation(PSD View)");
								decision = EPM_nogo;
								return ITK_errStore;
						}

						// added by dss 1.51
						if(d_found1>0)
						{
							tag_t queryfnd = NULLTAG;
							int d_entries = 5;
							int d_tags_found = 0;
							tag_t	*ditemclass	= NULLTAG;

							date_t dcreation_date;
							char* ccreation_date = NULL;

							ccreation_date = malloc(30 * sizeof (char *) );

							ITKCALL(AOM_ask_value_date(pTagAttch[i], "creation_date",&dcreation_date));
							ITK_date_to_string(dcreation_date, &ccreation_date);
								if(tc_strcmp(ccreation_date,"")==0)
								{
									tc_strcpy(ccreation_date,"NULL");
								}
							printf("\n ccreation_date %s", ccreation_date);fflush(stdout);


							char
							 *dqry_entries[5] = {"ID","Plant Name","*Shop Name","Name","Date Created"},
							 *dqry_values[5] =  {itemid,ESPlt,EsShop,"PW",ccreation_date};

							IFERR_REPORT(QRY_find2("tm_EstimateSheetQueryForPSD", &queryfnd));
							
							IFERR_REPORT(QRY_execute(queryfnd, d_entries, dqry_entries, dqry_values, &d_tags_found, &ditemclass));
							printf("\n d_tags_found %d", d_tags_found);fflush(stdout);

							if(d_tags_found>0)
							{	
								printf("\n Multiple PSD Working ES.. ");fflush(stdout);

								EMH_clear_errors();
								status33=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\n Previous Editions of Estimate Sheet is not PSD Final Released, Please Release Previous Editions of Estimate Sheet");
								decision = EPM_nogo;
								return ITK_errStore;
							}
						}
						//end added by dss 1.51
					}

					//Explode latest Released Item Rev upto 99 lvl and check for ES created for inhouse parts, if not give softcheck. //

					char
					 *qry_entry[3] = {"SUBSYSCD", "SYSCD","Delete Indicator"},
					 *qry_vall[3] =  {"MultiLvlExplsn", "Estimate Sheet","0"};


					IFERR_REPORT(QRY_find2("Control Objects...", &query1));
					//IFERR_REPORT(QRY_find2("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					IFERR_REPORT(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						int escnt=0;
						if( tc_strcmp(CurrentTask,"Assign Estimate Sheet" )==0 || ( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) ) )
						{

							tag_t*			EstToMstrRelTags			= NULLTAG;
							tag_t *  rev_list;
							int n_entriesds=1;
							int n_entrieses=2;

							int  EstToMstrRel=0;
							int  dsrev=0;

							EstToMstrRel=0;
							CALLAPI(AOM_ask_value_tags(item,"T5_Estimate_Design_Relation",&EstToMstrRel,&EstToMstrRelTags));
							printf("\n\n\t\t EstToMstrRel Count is :%d",EstToMstrRel);fflush(stdout);

							if(EstToMstrRel>0)
							{
								tag_t			DesgnTag	= NULLTAG;

								tag_t queryds = NULLTAG;
								tag_t queryes = NULLTAG;

								char *DesignId = NULL;
								char *DesignRevId = NULL;
								char *RelStat_Name = NULL;

								char * ItemName ;
								char * PrtType ;
								char * PrtCS ;

								char   *taskowning_groupVal=NULL;

								tag_t	*itemrevdsclass	= NULLTAG;
								tag_t	*esclass	= NULLTAG;
								tag_t	DesignrevTag	= NULLTAG;

								int ds_tags_found=0;
								int es_tags_found=0;
								int stat_count=0;
								tag_t*    stat_list=NULLTAG;

								int FlagGotLatestRev=0;
								int ChldCnt=0;
								int StructChldCnt=0;
								

								int iChildItemTag_DVC	= 0;
								tag_t t_ChildItemRev_DVC	= NULLTAG;

								struct	BomChldStrut	ChldStrutERC[5000];

								tag_t	objChild			= NULLTAG;
								tag_t	objChild_bvr			= NULLTAG;
								int child_lvl=0;
								char	*c_Qty						=	NULL;



								//char *qry_entriesds[1] = {"Item ID"};
								//char **qry_valuesds =	(char **) MEM_alloc(10 * sizeof(char *));

								DesgnTag=EstToMstrRelTags[0];
								ITKCALL(AOM_ask_value_string(DesgnTag,"item_id",&DesignId));
								printf("\n\n\t\t DesignId is :%s",DesignId);fflush(stdout);

								IFERR_REPORT(QRY_find2("GetLatestItemRev", &queryds));
								printf("\n found qryy ");fflush(stdout);
								
								char
								*qry_entriesds[1] = {"ID"},
								*qry_valuesds[1] =  {DesignId};

								//qry_valuesds[0]=DesignId;

								IFERR_REPORT(QRY_execute(queryds, n_entriesds, qry_entriesds, qry_valuesds, &ds_tags_found, &itemrevdsclass));
								printf("\n ds_tags_found %d", ds_tags_found);fflush(stdout);

								FlagGotLatestRev=0;
								for (dsrev = 0; dsrev<ds_tags_found; dsrev++)
								{
									DesignrevTag=NULLTAG;
									DesignrevTag=itemrevdsclass[dsrev];

									DesignRevId=NULL;
									ITKCALL(AOM_ask_value_string(DesignrevTag,"item_revision_id",&DesignRevId));
									printf("\n\n\t\t DesignRevId is :%s",DesignRevId);fflush(stdout);

									stat_list=NULLTAG;
									stat_count=0;
									ITKCALL(WSOM_ask_release_status_list(DesignrevTag,&stat_count,&stat_list));
									printf("\n stat_count :%d is\n",stat_count);fflush(stdout);

									RelStat_Name=NULL;
									ITKCALL(AOM_ask_name(stat_list[stat_count-1],&RelStat_Name));
									printf("\n RelStat_Name is :%s\n",RelStat_Name);fflush(stdout);

									if(tc_strcmp(RelStat_Name,"")!=0)
										{
										printf("\n Test11");fflush(stdout);
											if (tc_strcmp(RelStat_Name,LcsAplRlz)==0 || tc_strcmp(RelStat_Name,LcsStdWrkg)==0 || tc_strcmp(RelStat_Name,LcsStdRlz)==0)
											{
												printf("\n Got Latest Rev : [%s,%s]",DesignId,DesignRevId);fflush(stdout);
												FlagGotLatestRev=1;
												break;
											}
										}
								}

								printf("\n FlagGotLatestRev : [%d]",FlagGotLatestRev);fflush(stdout);

								if(FlagGotLatestRev==1)
								{
									printf("\n Latest Partnumber Rev is : [%s,%s]",DesignId,DesignRevId);fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(DesignrevTag,"owning_group",&taskowning_groupVal));
										printf("\n  taskowning_groupVal:%s ..............",taskowning_groupVal);fflush(stdout);

										//if((tc_strstr(taskowning_groupVal,"APL")!=NULL)|| (tc_strstr(taskowning_groupVal,"STD")!=NULL) )
										if((tc_strstr(taskowning_groupVal,"APL")!=NULL))
										{
											ITKCALL(Get_Part_BOM_Lvl(DesignrevTag,99,ClosureRule,RevsnRule,ESView,ChldStrutERC,&StructChldCnt));

										}
										else
										{
											ITKCALL(Get_Part_BOM_Lvl(DesignrevTag,99,ClosureRule,RevsnRule,"View",ChldStrutERC,&StructChldCnt));
										}


									printf("\n\t\t StructChldCnt:%d",StructChldCnt);fflush(stdout);
									
									ChldCnt=0;
									  for ( ChldCnt = 1; ChldCnt <= StructChldCnt; ChldCnt++)
									  {
										objChild		= NULLTAG;
										objChild_bvr	= NULLTAG;
										c_Qty			= NULL;
										child_lvl       =0;

										printf("\nPrint Item ID==>%d\n",ChldCnt);fflush(stdout);

										objChild=ChldStrutERC[ChldCnt].child_objs;
										objChild_bvr=ChldStrutERC[ChldCnt].child_objs_bvr;
										child_lvl=ChldStrutERC[ChldCnt].child_objs_lvl;
										
										ItemName=NULL;
										AOM_ask_value_string(objChild,"item_id",&ItemName);
										printf("\nItemName==>%s\n",ItemName);fflush(stdout);

										printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);


										AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
										printf("\nQty==>%s\n",c_Qty);fflush(stdout);

										PrtType=NULL;
										ITKCALL(AOM_ask_value_string(objChild,"t5_PartType",&PrtType));
										printf("\n\n\t PrtType-->%s",PrtType);fflush(stdout);

										if( (strcmp(PrtType,"G") != 0) || (strcmp(PrtType,"D")!=0) )
										{
											printf("\n\n\t\t inside Validation");	fflush(stdout);

											PrtCS=NULL;
											ITKCALL(AOM_ask_value_string(objChild,PlantCS,&PrtCS));
											printf("\n\n\t PrtCS-->%s",PrtCS);fflush(stdout);

											if( (strcmp(PrtCS,"E50") == 0) || (strcmp(PrtCS,"E99")==0) )
											{
												ItemIdNm=NULL;
												ItemIdNm =(char *) MEM_alloc(20 * sizeof(char *));
												 strcpy(ItemIdNm,ItemName);
												 strcat(ItemIdNm,"*");
												 printf("\n ItemIdNm: [%s]",ItemIdNm);fflush(stdout);

												IFERR_REPORT(QRY_find2("EstimateRevPlantShopEdnQry", &queryes));
												printf("\n found queryes ");fflush(stdout);
												
												char
												*qry_entrieses[2] = {"ID","Plant Name"},
												*qry_valueses[2] =  {ItemIdNm,ESPlt};

												//qry_valuesds[0]=DesignId;

												es_tags_found=0;
												IFERR_REPORT(QRY_execute(queryes, n_entrieses, qry_entrieses, qry_valueses, &es_tags_found, &esclass));
												printf("\n es_tags_found %d", es_tags_found);fflush(stdout);

												if(es_tags_found>0)
												{
													printf("\n Estimate Available for :[%s]",ItemName);fflush(stdout);
												}
												else
												{
													printf("\n Estimate Not Available for :[%s]",ItemName);fflush(stdout);
													if(escnt==0)
													{
															escnt = 1;
															tc_strcat(PrtSet,"\nEstimate Sheet Not Available for Following Parts");
															tc_strcat(PrtSet,"\nPlease Ensure Estimate Sheet gets available in system for Following Parts\n");
															tc_strcat(PrtSet,ItemName);
															tc_strcat(PrtSet,",");
															

													}
													else
													{	 
														if(tc_strstr(PrtSet,ItemName)==NULL)
														{
															tc_strcat(PrtSet,ItemName);
															tc_strcat(PrtSet,",");
														}
															escnt = escnt+1;
													 }


												}

												
												

											}

											
										} 
										 



									 }
								  }

							}
						} 

						if(escnt>0)
						{
							printf("\n Estimate Sheet 99 lvl explosion... %s \n",PrtSet);
							EMH_clear_errors();
							status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,PrtSet);
							decision = EPM_nogo;
							return ITK_errStore;
						}


					}// if(n_found1>0) end of control object

					//End of Explode latest Released Item Rev upto 99 lvl and check for ES created for inhouse parts, if not give softcheck. //
			 }
		}
  }



CLEANUP:
	decision = EPM_go;
	return decision;
}


int ES_APLPrereleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_APLPrereleased***************\n ");fflush(stdout);


   strcpy(lcsToset,"T5_APLPre-Released");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_APLPrereleased \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}


	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];


									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save_without_extensions(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////



								CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));

							
							
						}
					}

	}

	return error_code;
}


int ES_APLFinalReleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_APLFinalReleased***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_APLFinalReleased");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_APLFinalReleased \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save_without_extensions(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status /////

								CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
							
							
						}
					}

	}

	return error_code;
}


int ES_PSDWorking( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_PSDWorking***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_PSDWorking");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDWorking \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

			CALLAPI(AOM_lock(DMLTag));
           CALLAPI(AOM_set_value_string(DMLTag,"t5_PEAgency","PSD"));
			CALLAPI(AOM_save_without_extensions(DMLTag));
		    CALLAPI(AOM_unlock(DMLTag));

	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{
	    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save_without_extensions(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////

								CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
							
							
						}
					}

			// Added by dss 1.51 //
			tag_t dquery1 = NULLTAG;
			int d_entries1=4;
			int d_found1=0;
			tag_t	*dCntrlObjs	= NULLTAG;

			char
			*dqry_entry[4] = {"SUBSYSCD", "SYSCD","Information-1","Delete Indicator"},
			*dqry_vall[4] =  {"Estimate Sheet", "AutoCreate","Live","0"};
		   
		   IFERR_REPORT(QRY_find2("Control Objects...", &dquery1));
		   //IFERR_REPORT(QRY_find2("ControlObjQry", &query1));
		   printf("\n Ketan After fins qryyy-- \n");fflush(stdout);
		   IFERR_REPORT(QRY_execute(dquery1, d_entries1, dqry_entry, dqry_vall, &d_found1, &dCntrlObjs));
		   printf("\n Ketan d_found1: %d", d_found1);fflush(stdout);
		   
		   if(d_found1>0)
			{
				 printf("\n Going for ES Autocreation....");fflush(stdout);

			}

			// End added by dss 1.51 // 
			

	} // if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )

	return error_code;
}


int ES_PSDFinalReleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	date_t Release_date;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_PSDFinalReleased***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_PSDFinalReleased");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDFinalReleased \n"); fflush(stdout);

	


	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
			printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
		   CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
     	  // CALLAPI(ITK_set_bypass(TRUE));
		   CALLAPI(AOM_lock(DMLTag));
           CALLAPI(AOM_set_value_date(DMLTag,"t5_ActualRelDate",Release_date));
			CALLAPI(AOM_save_without_extensions(DMLTag));
		    CALLAPI(AOM_unlock(DMLTag));
	}

	// Control Object for Calling EXE // Added By Ketan TZ 1.75

	char*	qry_entryCntrl_ES[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char*	qry_valuesCntrl_ES[3]	= {"ES","Stamping","0"};
	
    tag_t	qryTagCntrl_ES				= NULLTAG;
    tag_t*	list_of_WSO_cntrl_tags_ES	= NULLTAG;

	int n_entryCntrl_ES			= 3;
	int control_number_found_ES = 0;;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl_ES));

	if (qryTagCntrl_ES)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl_ES, n_entryCntrl_ES, qry_entryCntrl_ES, qry_valuesCntrl_ES, &control_number_found_ES, &list_of_WSO_cntrl_tags_ES));

		printf("\n control_number_found_ES is : %d\n",control_number_found_ES);fflush(stdout);
	}

	if(control_number_found_ES>0)
	{
		printf("\n Control Object Based Execution for ES Stamping\n");fflush(stdout);

	    char* ES_no = NULL;
		
		AOM_ask_value_string(DMLTag,"item_id",&ES_no);

		printf("\n ES_no => %s \n",ES_no);fflush(stdout);

		char* t5_Userinfo1_ES = NULL;
		char cmd_ES[100];

		tag_t ES_obj = list_of_WSO_cntrl_tags_ES[0];
		CALLAPI(AOM_ask_value_string(ES_obj,"t5_Userinfo1",&t5_Userinfo1_ES));	
		//sprintf(cmd_ES,"%s %s",t5_Userinfo1_ES,ES_no);
		sprintf(cmd_ES,"%s \"%s\"",t5_Userinfo1_ES,ES_no);
		printf("\n Ketan Excuting Command = %s \n",cmd_ES);fflush(stdout);
		system(cmd_ES);
		printf("\n After executing Command \n");fflush(stdout);
	}
	else
	{
		printf("\n Non - Control Object Based Execution for ES Stamping \n");fflush(stdout);

		if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
		{

			    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

						PartCnt=0;
						CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
						printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
						if (PartCnt>0)
						{
							for (k=0;k<PartCnt ;k++ )
							{
								printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
								AssyTag=PartTags[k];

										// remove status ///
												tag_t		tReleaseStatusList_checkin=NULLTAG; 
												tag_t		class_id				=     NULLTAG;

												char		*class_name				=    NULL;

												int			n_values_checkin			=0; 
												int			cunt1			=0; 
												int			cunt2			=0; 

												logical		log1;
												tag_t*		attr_tags_checkin		=	NULLTAG; 
												logical		*is_it_null_checkin		=   NULL; 
												logical		*is_it_empty_checkin	=   NULL; 

											int       st_count=0;
											tag_t*    status_list;


												ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
												ITK_CALL(POM_name_of_class(class_id,&class_name));
												printf("\n class_name is :%s\n",class_name);fflush(stdout);

												ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
												printf("\n after getting rel stat...");fflush(stdout);

										/*
												CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
												printf("\n st_count:[%d]",st_count);fflush(stdout);

												if(st_count>0)
												{
													for (cunt2 =  0; cunt2 < st_count; cunt2++)
													{
														CR_remove_release_status(AssyTag,status_list[cunt2]);	
													}
												}
										*/
												

												//ITK_CALL(POM_unload_instances (1,&AssyTag));
												POM_unload_instances (1,&AssyTag);
												printf("\n test2 \n");fflush(stdout);
												ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
												printf("\n test3 \n");fflush(stdout);
												ITK_CALL(POM_is_loaded(AssyTag,&log1));
												printf("\n test4 \n");fflush(stdout);

												if(log1 == 1)
												{
													 printf(" Load Success\n " );
												}
												else
												printf("Load Failure\n"  );
												

												ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
												printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

												if(n_values_checkin>0)
												{
													printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
													printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


													for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
													{
														printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
														ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

														printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
														
														ITK_CALL(POM_save_instances(1,&AssyTag,1));
														//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
														ITK_CALL(AOM_lock(AssyTag));
														ITK_CALL(AOM_save_without_extensions(AssyTag));
														ITK_CALL(AOM_refresh(AssyTag,1));
														ITK_CALL(AOM_unlock(AssyTag));
													}
												}

										//// End of remove status //////

									CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
									CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
									printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
									CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
								
								
							}
						}
		}
	}

	return error_code;
}

int CreateRelDesigntoESRev(tag_t* rev,char * PrtNm,char * t5PEPlantName,char * t5EstShop,char * t5PEProcessEDNNo)
{
	int status;
	int		ifail	=0;

			tag_t	*designclass	= NULLTAG;

			tag_t queryes = NULLTAG;
			int n_entrieses=2;
			int DesignTags=0;
		
			printf("\n PrtNm: [%s]",PrtNm);fflush(stdout);


			ITK_CALL(QRY_find2("Item...", &queryes));
			printf("\n found queryes ");fflush(stdout);
			
			char
			*qry_entrieses[2] = {"Item ID","Type"},
			*qry_valueses[2] =  {PrtNm,"Design"};
			
			ITK_CALL(QRY_execute(queryes, n_entrieses, qry_entrieses, qry_valueses, &DesignTags, &designclass));
			
			printf("\n DesignTags : %d", DesignTags);fflush(stdout);

			if(DesignTags>0)
			{
				//Create Rel ES to Design //
				/*
				tag_t	relation_type	= NULLTAG;
				tag_t  apltaskrelation = NULLTAG;
				ITK_CALL(GRM_find_relation_type("T5_Estimate_Design_Relation",&relation_type));
				ITK_CALL(GRM_create_relation(*rev, designclass[0], relation_type,  NULLTAG, &apltaskrelation));
				ITK_CALL(GRM_save_relation(apltaskrelation));
				printf("\n ES to Design relation created ...");fflush(stdout);
				*/

				// Create Rel of Design to ES
				tag_t	relation_type1	= NULLTAG;
				tag_t  apltaskrelation1 = NULLTAG;
				ITK_CALL(GRM_find_relation_type("T5_Design_Estimate_Relation",&relation_type1));
				ITK_CALL(GRM_create_relation(designclass[0],*rev, relation_type1,  NULLTAG, &apltaskrelation1));
				ITK_CALL(GRM_save_relation(apltaskrelation1));
				printf("\n Design to ES relation created ...");fflush(stdout);

				ITK_CALL(AOM_refresh(*rev,TRUE));
				ITK_CALL(AOM_refresh(designclass[0],TRUE));
				//ITK_CALL(AOM_refresh(apltaskrelation,TRUE));
				ITK_CALL(AOM_refresh(apltaskrelation1,TRUE));
					
			}
			else
			{
				printf("\n Design [%s] doesn't Exists, So Relation With ES [%s],[%s],[%s],[%s] Is Not Created.\n",PrtNm,PrtNm,t5PEPlantName,t5EstShop,t5PEProcessEDNNo);
			}
}


int setAttributesOnESOPR(tag_t* item,char * EstimateNumberr, char* OprNo)
{
	int status;
	int		ifail	=0;

	ITK_CALL(AOM_lock(*item));


	ITK_CALL ( AOM_set_value_string(*item,"t5_EstimateNumber",EstimateNumberr));
	ITK_CALL ( AOM_set_value_string(*item,"item_id",OprNo));
	ITK_CALL(AOM_save_without_extensions(*item));
	ITK_CALL(AOM_unlock(*item));

}

int setAttributesOnESRev(tag_t* ESRev,char * ProcEdnNo, int Seq)
{
	int status;
	int		ifail	=0;

	ITK_CALL(AOM_lock(*ESRev));

	ITK_CALL ( AOM_set_value_string(*ESRev,"t5_PEProcessEDNNo",ProcEdnNo));
	ITK_CALL ( AOM_set_value_int(*ESRev,"sequence_id",Seq));
	ITK_CALL(AOM_save_without_extensions(*ESRev));
	ITK_CALL(AOM_unlock(*ESRev));

}


int setAttributesOnES(tag_t* item,char * t5PEPlantName,char* t5EstShop,char* t5PEProcessEDNNo,char* t5PEPartDesc)
{
	int status;
	int		ifail	=0;

	ITK_CALL(AOM_lock(*item));

	if(t5PEPlantName!=NULL && strcmp(t5PEPlantName,"")!=0 ) ITK_CALL ( AOM_set_value_string(*item,"t5_ESPlantName",t5PEPlantName));
	if(t5EstShop!=NULL && strcmp(t5EstShop,"")!=0 ) ITK_CALL ( AOM_set_value_string(*item,"t5_ShopName",t5EstShop));
	if(t5PEProcessEDNNo!=NULL && strcmp(t5PEProcessEDNNo,"")!=0 ) ITK_CALL ( AOM_set_value_string(*item,"t5_ProcEdnNumber",t5PEProcessEDNNo));
	if(t5PEPartDesc!=NULL && strcmp(t5PEPartDesc,"")!=0 ) ITK_CALL ( AOM_set_value_string(*item,"object_desc",t5PEPartDesc));
	ITK_CALL(AOM_save_without_extensions(*item));
	ITK_CALL(AOM_refresh(*item,0));
	ITK_CALL(AOM_unlock(*item));

}

int CreateRelESOPRRevtoESRev(tag_t* rev,tag_t esclass,char * PrtNm,char * t5PEPlantName,char * t5EstShop,char * t5PEProcessEDNNo, char* EstimateNo)
{
	int status;
	int		ifail	=0;


			tag_t queryes = NULLTAG;
			int n_entrieses=2;
			int DesignTags=0;

		
			ITK_CALL(AOM_lock(*rev));
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PEPartNumber",EstimateNo));
			//ITK_CALL ( AOM_set_value_string(*item,"item_id",OprNo));
			ITK_CALL(AOM_save_without_extensions(*rev));
			ITK_CALL(AOM_unlock(*rev));

			printf("\n PrtNm: [%s]",PrtNm);fflush(stdout);


				//Create Rel
				tag_t	relation_type	= NULLTAG;
				tag_t  apltaskrelation = NULLTAG;
				ITK_CALL(GRM_find_relation_type("T5_OperationToEstimateRel",&relation_type));
				ITK_CALL(GRM_create_relation(*rev, esclass, relation_type,  NULLTAG, &apltaskrelation));
				ITK_CALL(GRM_save_relation(apltaskrelation));
				printf("\n ES to Design relation created ...");fflush(stdout);

				tag_t	relation_type1	= NULLTAG;
				tag_t  apltaskrelation1 = NULLTAG;
				ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&relation_type1));
				ITK_CALL(GRM_create_relation(esclass,*rev, relation_type1,  NULLTAG, &apltaskrelation1));
				ITK_CALL(GRM_save_relation(apltaskrelation1));
				printf("\n Design to ES relation created ...");fflush(stdout);

				ITK_CALL(AOM_refresh(*rev,TRUE));
				ITK_CALL(AOM_refresh(esclass,TRUE));
				ITK_CALL(AOM_refresh(apltaskrelation,TRUE));
				ITK_CALL(AOM_refresh(apltaskrelation1,TRUE));

			
				//fprintf(fperror,"\n Design [%s] doesn't Exists, So Relation With ES [%s],[%s],[%s],[%s] Is Not Created.\n",PrtNm,PrtNm,t5PEPlantName,t5EstShop,t5PEProcessEDNNo);
			
}

int DeleteRelationOfNewOprtoES(tag_t* rev,tag_t esclass)
{
	int status;
	int		ifail	=0;


			tag_t queryes = NULLTAG;
			int n_entrieses=2;
			int DesignTags=0;
			tag_t	relation_type	= NULLTAG;

		
				// Delete relation
				ITK_CALL(GRM_find_relation_type("T5_OperationToEstimateRel",&relation_type));
				tag_t relation_tag=NULLTAG;
				CALLAPI(GRM_find_relation(*rev, esclass, relation_type, &relation_tag)); //need to check
				if(relation_tag!=NULLTAG)
				{
					printf("\n oprtoES Relation deleted....");fflush(stdout);
					CALLAPI(GRM_delete_relation(relation_tag));
				}			
}



int UpdateMasterFormName(tag_t OprItem,tag_t OprItemRev,char* OprNo)
{
	int status;
	int		ifail	=0;


	printf("\n\n\t\t inside UpdateMasterFormName \n OprNo :%s",OprNo);fflush(stdout);

	int PartCnt1=0;
	tag_t*	PartTags1	= NULLTAG;
	CALLAPI(AOM_ask_value_tags(OprItem,"IMAN_master_form",&PartCnt1,&PartTags1));
	printf("\n\n\t\t IMAN_master_form Count PartCnt1 is :%d",PartCnt1);fflush(stdout);
	
	if(PartCnt1>0)
	{
		ITK_CALL(AOM_lock(OprItem));
		ITK_CALL ( AOM_set_value_string(PartTags1[0],"object_name",OprNo));
		ITK_CALL(AOM_save_without_extensions(OprItem));
		ITK_CALL(AOM_unlock(OprItem));
	}

			
	int PartCnt=0;
	tag_t*	PartTags	= NULLTAG;
	CALLAPI(AOM_ask_value_tags(OprItemRev,"IMAN_master_form_rev",&PartCnt,&PartTags));
	printf("\n\n\t\t IMAN_master_form_rev Count PartCnt is :%d",PartCnt);fflush(stdout);
	
	if(PartCnt>0)
	{
		ITK_CALL(AOM_lock(OprItemRev));
		ITK_CALL ( AOM_set_value_string(PartTags[0],"object_name",OprNo));
		ITK_CALL(AOM_save_without_extensions(OprItemRev));
		ITK_CALL(AOM_unlock(OprItemRev));
	}


}


int DeleteRelationofNewEStoOpr(tag_t* rev,tag_t OprTag)
{
	int status;
	int		ifail	=0;


			tag_t queryes = NULLTAG;
			int n_entrieses=2;
			int DesignTags=0;
			tag_t	relation_type	= NULLTAG;

		
				// Delete relation
				ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&relation_type));
				tag_t relation_tag=NULLTAG;
				CALLAPI(GRM_find_relation(*rev, OprTag, relation_type, &relation_tag)); //need to check
				if(relation_tag!=NULLTAG)
				{
					printf("\n EStoOpr Relation deleted....");fflush(stdout);
					CALLAPI(GRM_delete_relation(relation_tag));
				}			
}

int StampAPLWorkingStatus(tag_t AssyTag)
{

	int status;
	int		ifail	=0;

    char* lcsToset=NULL;
		tag_t   status2=NULLTAG;
	char   *ReleaseStatus=NULL;
	logical retain=false;



									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


	lcsToset =(char *) MEM_alloc(50 * sizeof(char *));

    printf("\n **************inside StampAPLWorkingStatus***************\n ");fflush(stdout);


   strcpy(lcsToset,"T5_ESAPLWorking");

											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save_without_extensions(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////



								CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));


}

/*int ES_PSDclaim_OLD( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	//date_t Release_date;
	printf("\n ************** Inside ES_PSDclaim ***************\n ");fflush(stdout);
   
	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDclaim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
		// CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
     	// CALLAPI(ITK_set_bypass(TRUE));
		// CALLAPI(AOM_lock(DMLTag));
		// CALLAPI(AOM_set_value_date(DMLTag,"t5_ActualRelDate",Release_date));
		// CALLAPI(AOM_save_without_extensions(DMLTag));
		// CALLAPI(AOM_unlock(DMLTag));
	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{
		
		tag_t   qryTagCntrlobj		= NULLTAG;
		tag_t*	list_of_cntrl_tags	= NULLTAG;

		char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
		char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

		int controlObjfound	= 0;
		int	n_entryCntrlobj = 4;

		if(QRY_find2("Control Objects...", &qryTagCntrlobj));

		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrlformat[0]="ES";
			qry_valuesCntrlformat[1]="PSDReject";
			qry_valuesCntrlformat[2]="0";
			qry_valuesCntrlformat[3]="Live";
			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found  \n");fflush(stdout);
		}

		printf("\n controlObjfound is ==> %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0)
		{		
			printf("\n\n Priyanka  Inside code for es rejection \n");fflush(stdout);

			int		extUsrCnt	   = 0; 
			int		oldusrcount	   = 0; 
			
			tag_t*	OldParticipantRel   	= NULLTAG;
			tag_t	OldParticipantRelTag	= NULLTAG;
			tag_t	OldObjTypTask			= NULLTAG;
			tag_t   current_member			= NULLTAG;
			tag_t	new_participant_type	= NULLTAG;
			tag_t	new_participant_tag		= NULLTAG;

			//char	Oldtype_namee_task[TCTYPE_name_size_c+1];
			char*	Oldtype_namee_task	= NULL;
			char*	Proj_Code			= NULL;

			GRM_find_relation_type("HasParticipant", &relation_type);

			CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&oldusrcount,&OldParticipantRel));
			printf("\n oldusrcount to delete  ==> %d \n",oldusrcount);fflush(stdout);

			for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
			{
				OldParticipantRelTag =NULLTAG;
				printf("\n Removing old user :%d \n",extUsrCnt);fflush(stdout);
				OldParticipantRelTag = OldParticipantRel[extUsrCnt];
								
				printf("\n Inside removing the relation...\n");fflush(stdout);

				if(OldParticipantRelTag!=NULLTAG)
				{
				CALLAPI(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
				CALLAPI(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
				printf("\n Task: Participants Name ==> %s \n", Oldtype_namee_task);fflush(stdout);

				if ((tc_strcmp(Oldtype_namee_task,"T5_PSDPlanner")==0))
				{
					printf("\n Removing the user..\n");fflush(stdout);
				
					//CALLAPI(ITEM_rev_remove_participant (DMLTag,OldParticipantRelTag));
					CALLAPI(PARTICIPANT_remove_participant (DMLTag,OldParticipantRelTag));
					break;
				}
				}
				else
				{
					printf("\n OldParticipantRelTag null tag..\n");fflush(stdout);
				}
				
			}
			
			printf("\n Test 1111PP \n");fflush(stdout);
			
			CALLAPI(SA_ask_current_groupmember(&current_member));
			TCTYPE_find_type("T5_PSDPlanner", "T5_PSDPlanner", &new_participant_type);
			if(new_participant_type!=NULLTAG)
			{
				CALLAPI(EPM_create_participant(current_member, new_participant_type, &new_participant_tag));
				printf("\n Test 2222PP \n");fflush(stdout);
				CALLAPI(AOM_lock(DMLTag));
				printf("\n Test 3333PP \n");fflush(stdout);
				int n_participant_types = 1;
				tag_t participant_types[1] = {new_participant_tag};
				printf("\n Test 3333 \n");fflush(stdout);
				//CALLAPI(ITEM_rev_set_participants(DMLTag,n_participant_types,participant_types));
				CALLAPI(PARTICIPANT_set_participants(DMLTag,true,n_participant_types,participant_types));
				printf("\n Test 4444PP \n");fflush(stdout);
				CALLAPI(AOM_save_without_extensions(DMLTag));
				printf("\n Test 5555PP \n");fflush(stdout);
				CALLAPI(AOM_unlock(DMLTag));
				printf("\n Test 6666PP \n");fflush(stdout);
			}
		}
		
	}

	return error_code;
}*/

int ES_PSDclaim( EPM_action_message_t msg )
{
	int		status;
	int		ifail			= 0;
	int		error_code		= ITK_ok;
	int		noAttachment 	= 0;

	char*	CurrentTask		= NULL;
	char*	parent_name		= NULL;
	char*	Proj_Code		= NULL;
	char*	objtype_name	= NULL;
	char*	item_id 		= NULL;
	
	tag_t	rootTask		= NULLTAG;
	tag_t*	attachments		= NULLTAG;
	tag_t	objTypeTag		= NULLTAG;
	tag_t	ES_rev_tag		= NULLTAG;
	
    printf("\n ************** Ketan Inside ES_PSDclaim ***************\n ");fflush(stdout);
   
	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDclaim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		ES_rev_tag = attachments[0];
		if(TCTYPE_ask_object_type(ES_rev_tag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&objtype_name));
	    printf("\n objtype_name changes done: for workspaceobject => %s\n", objtype_name);fflush(stdout);
	}

	if(strcmp(objtype_name,"T5_EstimateSheetRevision")==0 )
	{
		printf("\n Inside class T5_EstimateSheetRevision......\n");fflush(stdout);
		
		tag_t   qryTagCntrlobj		= NULLTAG;
		tag_t*	list_of_cntrl_tags	= NULLTAG;

		char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
		char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

		int controlObjfound	= 0;
		int	n_entryCntrlobj = 4;

		if(QRY_find2("Control Objects...", &qryTagCntrlobj));

		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrlformat[0]="ES";
			qry_valuesCntrlformat[1]="PSDReject";
			qry_valuesCntrlformat[2]="0";
			qry_valuesCntrlformat[3]="Live";
			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found  \n");fflush(stdout);
		}

		printf("\n controlObjfound is ==> %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0) // Added By Ketan
		{	
			printf("\n Ketan Inside code for ES rejection \n");fflush(stdout);

			int		oldusrcount	   = 0; 
			
			tag_t*	OldParticipantRel   	= NULLTAG;
			tag_t   current_member			= NULLTAG;
			tag_t	new_participant_type	= NULLTAG;
			tag_t	new_participant_tag		= NULLTAG;

			char	Oldtype_namee_task[TCTYPE_name_size_c+1];
			
			// Ketan Added 09/01/2024
			tag_t	AnalystTag	= NULLTAG;
			
			char*	type_name;
			
			CALLAPI( TCTYPE_find_type( "T5_PSDPlanner", "T5_PSDPlanner", &AnalystTag));

			if(TCTYPE_ask_name2(AnalystTag,&type_name));

			printf("\n ES : Name is : %s \n", type_name);fflush(stdout);

			CALLAPI(PARTICIPANT_ask_participants(ES_rev_tag,AnalystTag,&oldusrcount,&OldParticipantRel));

			CALLAPI(PARTICIPANT_remove_participants(ES_rev_tag,oldusrcount,OldParticipantRel));

			printf("\n ES : Test 1111 \n");fflush(stdout);
			
			CALLAPI(SA_ask_current_groupmember(&current_member));
			TCTYPE_find_type("T5_PSDPlanner", "T5_PSDPlanner", &new_participant_type);
			CALLAPI(EPM_create_participant(current_member, new_participant_type, &new_participant_tag));
			
			printf("\n ES : Test 2222 \n");fflush(stdout);
			int n_participant_types = 1;
			tag_t participant_types[1] = {new_participant_tag};
			printf("\n ES : Test 3333 \n");fflush(stdout);
			//CALLAPI(ITEM_rev_set_participants(ES_rev_tag,n_participant_types,participant_types));
			CALLAPI(PARTICIPANT_set_participants(ES_rev_tag,true,n_participant_types,participant_types));
			printf("\n ES : Test ended 4444 \n");fflush(stdout);

			printf("\n Assign PSD Reviewer again after claim \n");fflush(stdout);

			char*	groupName 			= NULL;
			char*	item_id				= NULL;
			char*	EstPlntName 		= NULL;
			
			groupName			= (char	*)MEM_alloc(100);

			tc_strcpy(groupName,"EstimateSheet_");
			
			AOM_ask_value_string(ES_rev_tag, "item_id", &item_id);
			AOM_ask_value_string(ES_rev_tag, "t5_PEPlantName", &EstPlntName);

			printf("\n EstPlntName is => %s\n",EstPlntName);fflush(stdout);

			if(strcmp(EstPlntName,"CAR")==0 || strcmp(EstPlntName,"PCBU")==0)
			{
				printf("\n Inside CAR \n");fflush(stdout);
				tc_strcat(groupName,"CAR");
			}
			else if(strcmp(EstPlntName,"CVBU PUNE")==0)
			{
				printf("\n Inside CVBU PUNE \n");fflush(stdout);
				tc_strcat(groupName,"CVPUNE");
			}
			else if(strcmp(EstPlntName,"CVBU JSR")==0)
			{
				printf("\n Inside CVBU JSR \n");fflush(stdout);
				tc_strcat(groupName,"JSR");
			}
			else if(strcmp(EstPlntName,"CVBU LKO")==0)
			{
				printf("\n Inside CVBU LKO \n");fflush(stdout);
				tc_strcat(groupName,"CVLKO");
			}
			else if(strcmp(EstPlntName,"CVBU PNR")==0)
			{
				printf("\n Inside CVBU PNR \n");fflush(stdout);
				tc_strcat(groupName,"CVPNR");
			}
			else if(strcmp(EstPlntName,"DHARWAD")==0)
			{
				printf("\n Inside DHARWAD \n");fflush(stdout);
				tc_strcat(groupName,"DWD");
			}
			else if(strcmp(EstPlntName,"AHD")==0) 
			{
				printf("\n Inside AHD \n");fflush(stdout);
				tc_strcat(groupName,"AHD");
			}
			else if(strcmp(EstPlntName,"SANAND")==0) 
			{
				printf("\n Inside SANAND \n");fflush(stdout);
				tc_strcat(groupName,"SND");
			}
			else if(strcmp(EstPlntName,"SMALLCAR PNR")==0)
			{
				printf("\n Inside SMALLCAR PNR \n");fflush(stdout);
				tc_strcat(groupName,"PVPNR");
			}
			else if(strcmp(EstPlntName,"PCBU LKO")==0)
			{
				printf("\n Inside PCBU LKO \n");fflush(stdout);
				tc_strcat(groupName,"PVLKO");
				
			}
			else if(strcmp(EstPlntName,"TMLDL JSR")==0)
			{
				printf("\n Inside TMLDL JSR \n");fflush(stdout);
				tc_strcat(groupName,"TMLDLJSR");
			}
			else
			{
				printf("\n Invalid PlantName on Estimate sheet......\n");fflush(stdout); 
			}

			printf("\n groupName is => %s\n",groupName);fflush(stdout);

			CALLAPI(AssignPSDReviewer(ES_rev_tag,groupName));

		}
	}

	return error_code;
}


int ES_AutoCreation( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	int n_tags_found1 = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 3,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;
	tag_t*			PartTags1			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			OprTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				PartCnt1				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	tag_t  	CopiedES;
	tag_t  	CopiedESRev;
	tag_t  	CopiedOprRev;
	tag_t  	CopiedOpr;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	char *Revv=NULL;
	int Seqq;
	char *ProcEdnNo=NULL;
	char *RevSeqID=NULL;
	char Sequence[50];

		char *PltNm=NULL;
		char *ShpNm=NULL;
		char *item_id_value=NULL;
		char *ConcatedStr=NULL;
		char *PrtNumEst=NULL;
		char *itemRevSeq=NULL;
		char *EstimateNumberr=NULL;
		char *NewOprNum=NULL;
		char *Desc=NULL;
	tag_t	VCRev_tag	= NULLTAG;
	char *sortedprocednno = NULL;
	char *sortedprocednno1= NULL;

		int jj=0;
	date_t Release_date;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_AutoCreation***************\n ");fflush(stdout);


	char    *qry_entryCntrlformat[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   qryTagCntrlobj     = NULLTAG;
	int     n_entryCntrlobj    = 3;

			int controlObjfound=0;
			tag_t *list_of_cntrl_tags=NULLTAG;

			if(QRY_find2("Control Objects...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="ES_AutoCreation";
				qry_valuesCntrlformat[1]="Live";
				qry_valuesCntrlformat[2]="0";
				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found for ES_AutoCreation... \n");fflush(stdout);
			}	
			
			printf("\n controlObjfound for ES_AutoCreation is : %d\n",controlObjfound);fflush(stdout);

if(controlObjfound>0)
 {	

	if(EPM_ask_root_task(msg.task,&rootTask));

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

			CALLAPI(AOM_ask_value_string(DMLTag, "item_revision_id", &Revv ));
			printf("\n Hi...Revv: %s\n", Revv);fflush(stdout);

			CALLAPI(AOM_ask_value_int(DMLTag, "sequence_id", &Seqq ));
			printf("\n Hi...Seqq: %d\n", Seqq);fflush(stdout);
			sprintf(Sequence,"%d",Seqq);
			printf("\n Hi...Sequence: %s\n", Sequence);fflush(stdout);

	
			RevSeqID = NULL;
			itemRevSeq=(char *) MEM_alloc(32);
			strcpy(itemRevSeq,Revv);
			strcat(itemRevSeq,";");
			strcat(itemRevSeq,Sequence);
			printf("\n Hi...itemRevSeq: %s\n", itemRevSeq);fflush(stdout);

			ITKCALL(AOM_ask_value_string(DMLTag, "item_id", &item_id_value));
			ITKCALL(AOM_ask_value_string(DMLTag, "t5_EstShop", &ShpNm));
			ITKCALL(AOM_ask_value_string(DMLTag, "t5_PEPlantName", &PltNm));
			ITKCALL(AOM_ask_value_string(DMLTag, "t5_PEProcessEDNNo", &ProcEdnNo));
			ITKCALL(AOM_ask_value_string(DMLTag, "object_desc", &Desc));

			printf("\n PltNm: [%s]",PltNm);fflush(stdout);
			printf("\n ShpNm: [%s]",ShpNm);(stdout);
			printf("\n ProcEdnNo: [%s]",ProcEdnNo);fflush(stdout);
			printf("\n Desc: [%s]",Desc);fflush(stdout);
			printf("\n item_id_value: [%s]",item_id_value);fflush(stdout);

			char*			EstPrtNum				= NULL;
			EstPrtNum= strtok( item_id_value, "-" );
			printf("\n EstPrtNum: [%s]",EstPrtNum);fflush(stdout);

			PrtNumEst = NULL;
			PrtNumEst=(char *) MEM_alloc(100);
			strcpy(PrtNumEst,EstPrtNum);
			strcat(PrtNumEst,"*");
			printf("\n PrtNumEst: [%s]",PrtNumEst);fflush(stdout);


	int num_to_sort_DVC=1;
	char *keys_DVC[1] = {"Process EDN Number"};
	int  	 orders_DVC[1]  ={1};
			 tag_t	*itemclass	= NULLTAG;
			 tag_t	*itemclass1	= NULLTAG;

			int jk=0;
char
         *qry_entries[3] = {"ID","Plant Name","*Shop Name"},
         *qry_values[3] =  {PrtNumEst,PltNm,ShpNm};

	
    IFERR_REPORT(QRY_find2("EstimateRevPlantShopEdnQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_tags_found1, &itemclass1));
	if(QRY_execute_with_sort(query, n_entries, qry_entries, qry_values, num_to_sort_DVC, keys_DVC, orders_DVC, &n_tags_found, &itemclass));
    printf("\n n_tags_found1 %d", n_tags_found1);fflush(stdout);
    printf("\n n_tags_found %d", n_tags_found);fflush(stdout);
		
		int num=0;
		  if (n_tags_found1>0)
		  {
			  for( jk=0; jk<n_tags_found1; jk++)
			  {
				VCRev_tag = itemclass1[jk];
				
				ITKCALL(AOM_ask_value_string(VCRev_tag, "t5_PEProcessEDNNo", &sortedprocednno1));
				printf("\n sortedprocednno1 : %s\n",sortedprocednno1);fflush(stdout);
				int intprocno=(atoi(sortedprocednno1));
				printf("\n intprocno : %d\n",intprocno);fflush(stdout);
				
				if(jk==0)
				  {
					num=intprocno;
				  }
  				printf("\n before num : %d\n",num);fflush(stdout);


				if ( intprocno > num)
						 {
							//temp = intprocno;
							//intprocno = num;
							num = intprocno;
							printf("\n num : %d\n",num);fflush(stdout);

						 }
			  }
		  }

		printf("\n Final Largest proc edn num : %d\n",num);fflush(stdout);

	
		  if (n_tags_found>0)
		  {
			VCRev_tag = itemclass[n_tags_found-1];
			
			ITKCALL(AOM_ask_value_string(VCRev_tag, "t5_PEProcessEDNNo", &sortedprocednno));
			printf("\n sortedprocednno : %s\n",sortedprocednno);fflush(stdout);
		  }
	    
			char tmp_str_nxt_srl[20];
			//int tmp_int_nxt_srl=(atoi(ProcEdnNo)+1);
			int tmp_int_nxt_srl=num+1;
			sprintf(tmp_str_nxt_srl,"%d",tmp_int_nxt_srl);	
			printf("\n tmp_str_nxt_srl:%s",tmp_str_nxt_srl);fflush(stdout);



			ConcatedStr = NULL;
			ConcatedStr=(char *) MEM_alloc(100);
			strcpy(ConcatedStr,EstPrtNum);
			strcat(ConcatedStr,"-");
			strcat(ConcatedStr,PltNm);
			strcat(ConcatedStr,"-");
			strcat(ConcatedStr,ShpNm);
			strcat(ConcatedStr,"-");
			strcat(ConcatedStr,tmp_str_nxt_srl);

			printf("\n ConcatedStr: [%s]",ConcatedStr);fflush(stdout);

			EstimateNumberr=NULL;
			EstimateNumberr=(char *) MEM_alloc(100);
			tc_strcpy(EstimateNumberr,EstPrtNum);
			tc_strcat(EstimateNumberr,PltNm);
			tc_strcat(EstimateNumberr,ShpNm);
			tc_strcat(EstimateNumberr,tmp_str_nxt_srl);
			printf("\n EstimateNumberr: %s\n",EstimateNumberr);fflush(stdout);

			        if(AOM_refresh(DMLTag,1));
			       // CALLAPI ( ITEM_copy_item( DMLTag, "","NR;1", &CopiedES, &CopiedESRev ));
			        CALLAPI ( ITEM_copy_item( DMLTag,ConcatedStr,Revv, &CopiedES, &CopiedESRev ));
			        CALLAPI(AOM_save_without_extensions( CopiedES ))
			        CALLAPI( AOM_save_without_extensions( CopiedESRev ))
			        CALLAPI( AOM_unlock( CopiedES ))
			        CALLAPI( AOM_unlock( CopiedESRev ))
				
					printf("\n\n\t\t ES Created successfully ...");fflush(stdout);

					setAttributesOnES(&CopiedES,PltNm,ShpNm,tmp_str_nxt_srl,Desc); 
					printf("\n after setAttributesOnES");fflush(stdout);

					setAttributesOnESRev(&CopiedESRev,tmp_str_nxt_srl,Seqq); 
					printf("\n after setAttributesOnESRev");fflush(stdout);

					StampAPLWorkingStatus(CopiedESRev);
					printf("\n after StampAPLWorkingStatus on ES");fflush(stdout);

					CreateRelDesigntoESRev(&CopiedESRev,EstPrtNum,PltNm,ShpNm,tmp_str_nxt_srl);

					PartCnt1=0;
					CALLAPI(AOM_ask_value_tags(CopiedESRev,"T5_EstimateOprationRelation",&PartCnt1,&PartTags1));
					printf("\n\n\t\t Operations Count PartCnt1 is :%d",PartCnt1);fflush(stdout);

					if (PartCnt1>0)
					{
						for (k=0;k<PartCnt1 ;k++ )
						{
							OprTag=PartTags1[k];

							DeleteRelationofNewEStoOpr(&CopiedESRev,OprTag);
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
						}
					}

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);

					if (PartCnt>0)
					{
						for (jj=0;jj<PartCnt ;jj++ )
						{
							AssyTag=PartTags[jj];

							char *OprNo=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag, "item_id", &OprNo));
							printf("\n\n\t\t OprNo =:%s",OprNo);fflush(stdout);

							char *OprRev=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id", &OprRev));
							printf("\n\n\t\t OprRev =:%s",OprRev);fflush(stdout);


							NewOprNum=NULL;
							NewOprNum=(char *) MEM_alloc(100);
							tc_strcpy(NewOprNum,OprNo);
							tc_strcat(NewOprNum,EstimateNumberr);
							printf("\n NewOprNum: %s\n",NewOprNum);fflush(stdout);

							
							if(AOM_refresh(AssyTag,1));
						   // CALLAPI ( ITEM_copy_item( AssyTag, "","NR;1", &CopiedES, &CopiedESRev ));
							CALLAPI ( ITEM_copy_item( AssyTag,NewOprNum,OprRev, &CopiedOpr, &CopiedOprRev ));
							CALLAPI(AOM_save_without_extensions( CopiedOpr ))
							CALLAPI( AOM_save_without_extensions( CopiedOprRev ))
							CALLAPI( AOM_unlock( CopiedOpr ))
							CALLAPI( AOM_unlock( CopiedOprRev ))
							

							setAttributesOnESOPR(&CopiedOpr,EstimateNumberr,OprNo); 
							printf("\n after setAttributesOnESOPR");fflush(stdout);

							DeleteRelationOfNewOprtoES(&CopiedOprRev,DMLTag);
							printf("\n after DeleteRelationOfNewOprtoES");fflush(stdout);

							CreateRelESOPRRevtoESRev(&CopiedOprRev,CopiedESRev,EstPrtNum,PltNm,ShpNm,tmp_str_nxt_srl,ConcatedStr);
							printf("\n after CreateRelESOPRRevtoESRev");fflush(stdout);

							UpdateMasterFormName(CopiedOpr,CopiedOprRev,OprNo);
							printf("\n after UpdateMasterFormName");fflush(stdout);

							StampAPLWorkingStatus(CopiedOprRev);
							printf("\n after StampAPLWorkingStatus on Opr");fflush(stdout);

						}
					}
	}
 }

	return error_code;
}


int Save_ES_Msg( METHOD_message_t *msg, va_list  args )
{

    tag_t	TaskTag		= va_arg(args, const tag_t);

	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *item_id 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *groupName 	   = NULL;
	char *ES_Planner_role 	   = NULL;
	char *ES_Reviewer_role 	   = NULL;
	char *PSD_Planner_role 	   = NULL; // added by dss 1.54
	char *PSD_Reviewer_role    = NULL; // added by dss 1.54
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;
	char *taskTempLT 	   = NULL;//Priyanka

	//const char*   CR_EM_role = "CR_ERC_EM";
	//const char*   ES_Planner_role = "ES_Planner";
	//const char*   ES_Reviewer_role = "ES_Reviewer";

	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;
	
	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name 	   = NULL;
	char *type_name1 	   = NULL;
	char *type_name2 	   = NULL;
	//char   type_name1[TCTYPE_name_size_c+1];
	//char   type_name2[TCTYPE_name_size_c+1];
	char   userid[SA_user_size_c+1];
	WSO_search_criteria_t  	criteria;

	groupName = (char	*)MEM_alloc(100);
	ES_Planner_role = (char	*)MEM_alloc(100);
	ES_Reviewer_role = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	PSD_Planner_role = (char	*)MEM_alloc(100); // added by dss 1.54
	PSD_Reviewer_role = (char	*)MEM_alloc(100); // added by dss 1.54
	tc_strcpy(groupName,"EstimateSheet_");
	tc_strcpy(ES_Planner_role,"ES_Planner_");
	tc_strcpy(ES_Reviewer_role,"ES_Reviewer_");
	tc_strcpy(PSD_Planner_role,"PSD_Planner"); // added by dss 1.54
	tc_strcpy(PSD_Reviewer_role,"PSD_Reviewer"); // added by dss 1.54
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);
	printf("\n MT: PSD_Planner_role  --> %s\n",PSD_Planner_role);   fflush(stdout); // added by dss 1.54
	printf("\n MT: PSD_Reviewer_role  --> %s\n",PSD_Reviewer_role);   fflush(stdout);// added by dss 1.54

    printf("\n **************inside Save_CR_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0)
	{
		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskTag, "item_id", &item_id);
			AOM_ask_value_string( TaskTag,"t5_PEPlannedBy",&EstPlanner);
            AOM_ask_value_string( TaskTag, "t5_PEProcessApproveBy", &EstReviewer);

			 AOM_ask_value_string( TaskTag, "t5_PEPlantName", &EstPlntName);

	printf("\n EstPlntName is : %s\n",EstPlntName);fflush(stdout);
	
	if(strcmp(EstPlntName,"CAR")==0 || strcmp(EstPlntName,"PCBU")==0)
    {
		tc_strcpy(PsdRoleName,"EstimateCAR AssignReview");
		tc_strcat(groupName,"CAR");
		tc_strcat(ES_Planner_role,"CAR");
		tc_strcat(ES_Reviewer_role,"CAR");
	}
	else if(strcmp(EstPlntName,"CVBU PUNE")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUPUNE AssignReview");
		tc_strcat(groupName,"CVPUNE");
		tc_strcat(ES_Planner_role,"CVPUNE");
		tc_strcat(ES_Reviewer_role,"CVPUNE");

	}
	else if(strcmp(EstPlntName,"CVBU JSR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUJSR AssignReview");
		tc_strcat(groupName,"JSR");
		tc_strcat(ES_Planner_role,"JSR");
		tc_strcat(ES_Reviewer_role,"JSR");

	}
	else if(strcmp(EstPlntName,"CVBU LKO")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBULKO AssignReview");
		tc_strcat(groupName,"CVLKO");
		tc_strcat(ES_Planner_role,"CVLKO");
		tc_strcat(ES_Reviewer_role,"CVLKO");

	}
	else if(strcmp(EstPlntName,"CVBU PNR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUUTK AssignReview");
		tc_strcat(groupName,"CVPNR");
		tc_strcat(ES_Planner_role,"CVPNR");
		tc_strcat(ES_Reviewer_role,"CVPNR");

	}
	else if(strcmp(EstPlntName,"DHARWAD")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateDHARWAD AssignReview");
		tc_strcat(groupName,"DWD");
		tc_strcat(ES_Planner_role,"DWD");
		tc_strcat(ES_Reviewer_role,"DWD");


	}
	//else if(strcmp(EstPlntName,"SMALLCAR AHD")==0)
	else if(strcmp(EstPlntName,"AHD")==0) // Updated By Ketan 
	{
		//tc_strcpy(PsdRoleName,"EstimateSANAND AssignReview");
		tc_strcpy(PsdRoleName,"EstimateAHD AssignReview"); // Updated By Ketan 
		tc_strcat(groupName,"AHD");
		tc_strcat(ES_Planner_role,"AHD");
		tc_strcat(ES_Reviewer_role,"AHD");

	}
	else if(strcmp(EstPlntName,"SANAND")==0) // Added By Ketan 
	{
		tc_strcpy(PsdRoleName,"EstimateSANAND AssignReview");
		tc_strcat(groupName,"SND");
		tc_strcat(ES_Planner_role,"SND");
		tc_strcat(ES_Reviewer_role,"SND");

	}
	else if(strcmp(EstPlntName,"SMALLCAR PNR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateSMALLCARPNR AssignReview");
		tc_strcat(groupName,"PVPNR");
		tc_strcat(ES_Planner_role,"PVPNR");
		tc_strcat(ES_Reviewer_role,"PVPNR");

	}
	else if(strcmp(EstPlntName,"PCBU LKO")==0)
	{
		tc_strcpy(PsdRoleName,"EstimatePCBULKO AssignReview");
		tc_strcat(groupName,"PVLKO");
		tc_strcat(ES_Planner_role,"PVLKO");
		tc_strcat(ES_Reviewer_role,"PVLKO");

	}
	else if(strcmp(EstPlntName,"TMLDL JSR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateTMLDLJSR AssignReview");
		tc_strcat(groupName,"TMLDLJSR");
		tc_strcat(ES_Planner_role,"TMLDLJSR");
		tc_strcat(ES_Reviewer_role,"TMLDLJSR");
	}
	else
	{
		printf("\nInvalid PlantName on Estimate sheet......\n");fflush(stdout); 
	}	


			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n EstPlanner : %s\n",EstPlanner);fflush(stdout);
			printf("\n EstReviewer is : %s\n",EstReviewer);fflush(stdout);
			printf("\n PsdRoleName is : %s\n",PsdRoleName);fflush(stdout);
			printf("\n groupName is : %s\n",groupName);fflush(stdout);

			CALLAPI( AOM_UIF_ask_value(TaskTag,"fnd0StartedWorkflowTasks",&taskTempLT)); //ADDED BY Priyanka
			printf("\n Task assignment  for estimatesheet: %s\n",taskTempLT);fflush(stdout);
			
			if(EstPlanner!=NULL)
			{
				printf("\n EstPlanner ....");fflush(stdout);
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(ES_Planner_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n EstPlanner CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n EstPlanner CR:EM no: [%d]",ii);fflush(stdout);
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						if(TCTYPE_ask_object_type(GHTags[ii],&objTypeTag2));
						if(TCTYPE_ask_name2(objTypeTag2,&type_name1));
						printf("\n   EstPlanner  type_name1 :: %s\n", type_name1);fflush(stdout);

						printf("\n EstPlanner User ID Name :[%s]\n",userid);
						printf("\n EstPlanner member_name :[%s]\n",member_name);
						if(strcmp(member_name,EstPlanner)==0)
						{
							logical bypass_assignable_check =true;

							if(EPM_get_participanttype ("T5_EstimatePlanner",&participant_type2)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							AOM_lock(TaskTag);			
							//if(ITEM_rev_add_participant(TaskTag,participant_tag2)!=ITK_ok)PrintErrorStack();
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							AOM_save_without_extensions(TaskTag);
							AOM_unlock(TaskTag);
							printf("\n EstPlanner Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
				}

			if(EstReviewer!=NULL)
			{
				printf("\n EstReviewer CR:Setting Group_Head...");fflush(stdout);
				if(SA_find_group(groupName, &Grp_tag2)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(ES_Reviewer_role,&CR_GrHd_Tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(CR_GrHd_Tag1,Grp_tag2,&No_GH1,&GHTags1)!=ITK_ok)PrintErrorStack();
				printf("\n EstReviewer CR:No_GH1 :[%d]",No_GH1);  fflush(stdout);
				if(No_GH1>0)
				{
					for(iii=0;iii<No_GH1;iii++)
					{	
						printf("\n EstReviewer CR:EM no: [%d]",iii);fflush(stdout);
						if (AOM_ask_value_string(GHTags1[iii],"user_name",&member_name1)!=ITK_ok)   PrintErrorStack();
						if(TCTYPE_ask_object_type(GHTags1[iii],&objTypeTag4));
						if(TCTYPE_ask_name2(objTypeTag4,&type_name2));
						printf("\n   EstReviewer  type_name2 :: %s\n", type_name2);fflush(stdout);

						printf("\n EstReviewer User ID Name :[%s]\n",userid);
						printf("\n EstReviewer member_name1 :[%s]\n",member_name1);
						if(strcmp(member_name1,EstReviewer)==0)
						{
							logical bypass_assignable_check =true;

							if(EPM_get_participanttype ("T5_EstimateReviewer",&participant_type3)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags1[iii],participant_type3,&participant_tag3)!=ITK_ok)PrintErrorStack();
							AOM_lock(TaskTag);			
							//if(ITEM_rev_add_participant(TaskTag,participant_tag3)!=ITK_ok)PrintErrorStack();
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag3)!=ITK_ok)PrintErrorStack();
							AOM_save_without_extensions(TaskTag);
							AOM_unlock(TaskTag);
							printf("\n EstReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags1);
				}			

			//added by dss 1.54 // assigning PSD_Planner
			tag_t			group_tag			= NULLTAG;
			tag_t*			role_tags			= NULLTAG;
			int				num_of_roles		= 0;


			CALLAPI(SA_find_group(groupName,&group_tag));
			if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

			printf("\nNo of Role found in Group are_psdplanner psd :%d\n",num_of_roles);fflush(stdout);
			if( (tc_strstr(taskTempLT,"APL Review Of Estimate Sheet")!=NULL) || (tc_strstr(taskTempLT,"Assign Estimate Sheet")!=NULL))//ADDED BY Priyanka for Rejection of reviewer
			{
				printf("\nX566XXXXXXXUTKK :%d\n",num_of_roles);fflush(stdout);
				if(num_of_roles>0)
				{
					int				num_of_members		= 0;
					//char			rolename[SA_name_size_c+1];
					char* rolename 	   = NULL;
					char* userid 	   = NULL;
					//char				userid[SA_user_size_c+1];

					tag_t			user_tag			= NULLTAG;
					tag_t			relation			= NULLTAG;
					tag_t			participant_type	= NULLTAG;
					tag_t			participant_tag		= NULLTAG;
					tag_t			relation_type		= NULLTAG;
					tag_t			role_tag		= NULLTAG;
					tag_t*			member_tags			= NULLTAG;
					int jk=0;

				  ij=0;
				  for (ij=0;ij<num_of_roles ;ij++ )
					{
					  
						CALLAPI(SA_ask_role_name2(role_tags[ij],&rolename));
						printf("\nRol Name :[%d][%s]\n",ij,rolename);fflush(stdout);

						if(tc_strcmp(rolename,PSD_Planner_role)==0)
						{
									printf("\n Role Match Found\n");fflush(stdout);
									role_tag = role_tags[ij];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (jk=0;jk<num_of_members ;jk++  )
										{
											CALLAPI(SA_ask_groupmember_user(member_tags[jk],&user_tag));
											CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
											printf("\n User ID Name :[%s]\n",userid);fflush(stdout);
										
											TCTYPE_find_type("T5_PSDPlanner", "T5_PSDPlanner", &participant_type);
											EPM_create_participant(member_tags[jk], participant_type, &participant_tag);
											GRM_find_relation_type("HasParticipant", &relation_type);
											GRM_create_relation(TaskTag, participant_tag, relation_type,  NULLTAG, &relation);
											GRM_save_relation(relation);
											printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
																					
										}
									}

						}

					}
					
				}
			}
			else
		{
			printf("\n not process pppp..to \n");fflush(stdout);
		}	


			//End added by dss 1.54 // assigning PSD_Planner

			//added by dss 1.54 // assigning PSD_Reviewer
			printf("\nNo of Role found in Group are .... :%d\n",num_of_roles);fflush(stdout);
			if(num_of_roles>0)
				{
					int				num_of_members		= 0;
					//char			rolename[SA_name_size_c+1];
					char*			rolename=NULL;
					char*			userid=NULL;
					//char				userid[SA_user_size_c+1];

					tag_t			user_tag			= NULLTAG;
					tag_t			relation			= NULLTAG;
					tag_t			participant_type	= NULLTAG;
					tag_t			participant_tag		= NULLTAG;
					tag_t			relation_type		= NULLTAG;
					tag_t			role_tag		= NULLTAG;
					tag_t*			member_tags			= NULLTAG;
					int jk=0;

				  ij=0;
				  for (ij=0;ij<num_of_roles ;ij++ )
					{
					  
						CALLAPI(SA_ask_role_name2(role_tags[ij],&rolename));
						printf("\n Rol Name :[%d][%s]\n",ij,rolename);fflush(stdout);

						if(tc_strcmp(rolename,PSD_Reviewer_role)==0)
						{
									printf("\n Role Match Found\n");fflush(stdout);
									role_tag = role_tags[ij];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (jk=0;jk<num_of_members ;jk++  )
										{
											CALLAPI(SA_ask_groupmember_user(member_tags[jk],&user_tag));
											CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
										
											TCTYPE_find_type("T5_PSDReviewer", "T5_PSDReviewer", &participant_type);
											EPM_create_participant(member_tags[jk], participant_type, &participant_tag);
											GRM_find_relation_type("HasParticipant", &relation_type);
											GRM_create_relation(TaskTag, participant_tag, relation_type,  NULLTAG, &relation);
											GRM_save_relation(relation);
											printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
																					
										}
									}

						}

					}
					
				}

			//End added by dss 1.54 // assigning PSD_Reviewer


	}

    return error_code;

}

void  GetESPlantFromRole( char  getPlantES[40])
{
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char   *roleName=NULL;
	char   *PlantName=NULL;


	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

      PlantName=subString(roleName,3,4);
      printf( "PlantName:%s\n", PlantName);fflush(stdout);

	  tc_strcpy(getPlantES,PlantName);
	  printf( "getPlantES:%s\n", getPlantES);fflush(stdout);
}


int myESDomainNameLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	//GetESPlantFromRole(PlantES);
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char		*roleName	= NULL;

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	if( tc_strstr(roleName,"CVPUNE")!=NULL || tc_strstr(roleName,"PVPUNE")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"PDMAIN");
			
		}
		else if(tc_strstr(roleName,"DWD")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"DDMAIN");
			
		}	
		else if(tc_strstr(roleName,"CAR")!=NULL)
		{
			printf( "inside car...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PDMAIN");
			
		}	
		else if(tc_strstr(roleName,"JSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JDMAIN");
			
		}	
		else if( tc_strstr(roleName,"CVLKO")!=NULL || tc_strstr(roleName,"PVLKO")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"LDMAIN");
			
		}	
		else if(tc_strstr(roleName,"TMLDLJSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JDMAIN");
			
		}	
		else if(tc_strstr(roleName,"CVPNR")!=NULL || tc_strstr(roleName,"PVPNR")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"UDMAIN");
			
		}	
		else if(tc_strstr(roleName,"AHD")!=NULL) // Added by Ketan
		{
			printf("\n ADMAIN : Inside AHD \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"ADMAIN");
			
		}
		else if(tc_strstr(roleName,"SND")!=NULL) // Added by Ketan
		{
			printf("\n\n SDMAIN : Inside SND \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"SDMAIN");
			
		}
		else if(tc_strstr(roleName,"UVPUNE")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"VDMAIN");
			
		}	
		else
		{
			 printf( "inside else...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PDMAIN");
			
		}	

	//printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
	/*
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DDMAIN");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JDMAIN");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LDMAIN");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"ADMAIN");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"UDMAIN");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SDMAIN");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}
		*/


	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"Delete Indicator", "SYSCD"},
         *qry_values[2] =  {"0", CntrlSysCD};


    IFERR_REPORT(QRY_find2("Control Objects...", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

int myESShopNameLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;


		tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char		*roleName		= NULL;

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	if( tc_strstr(roleName,"CVPUNE")!=NULL || tc_strstr(roleName,"PVPUNE")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"PSHOP");
			
		}
		else if(tc_strstr(roleName,"DWD")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"DSHOP");
			
		}	
		else if(tc_strstr(roleName,"CAR")!=NULL)
		{
			printf( "inside car...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PSHOP");
			
		}	
		else if(tc_strstr(roleName,"JSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JSHOP");
			
		}	
		else if( tc_strstr(roleName,"CVLKO")!=NULL || tc_strstr(roleName,"PVLKO")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"LSHOP");
			
		}	
		else if(tc_strstr(roleName,"TMLDLJSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JSHOP");
			
		}	
		else if(tc_strstr(roleName,"CVPNR")!=NULL || tc_strstr(roleName,"PVPNR")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"USHOP");
			
		}	
		else if(tc_strstr(roleName,"AHD")!=NULL) // Added By Ketan
		{
			printf("\n ASHOP : Inside AHD \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"ASHOP");
			
		}
		else if(tc_strstr(roleName,"SND")!=NULL) // Added By Ketan
		{
			printf("\n SSHOP : Inside SND \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"SSHOP");
			
		}	
		else if(tc_strstr(roleName,"UVPUNE")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"VSHOP");
			
		}	
		else
		{
			 printf( "inside else...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PSHOP");
			
		}	

/*
	GetESPlantFromRole(PlantES);
	printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DSHOP");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JSHOP");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LSHOP");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"ASHOP");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"USHOP");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SSHOP");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

*/
	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"Delete Indicator", "SYSCD"},
         *qry_values[2] =  {"0", CntrlSysCD};


   // IFERR_REPORT(QRY_find2("ControlObjQry", &query));
    IFERR_REPORT(QRY_find2("Control Objects...", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

// Added by Ketan
extern EPM_decision_t DLLAPI Chk_ES_Activein_WF(EPM_rule_message_t msg)
{
	
	char*	CurrentTask				= NULL;
	char*	t5current_name			= NULL;
	char*	procedure_name			= NULL;
	char*	type_name1				= NULL;

	tag_t	root_task				= NULLTAG;
	tag_t	primary_obj_type_tag	= NULLTAG;
	tag_t*	attachments				= NULLTAG;
	tag_t*	DMLRevision				= NULLTAG;
	tag_t*	parents					= NULLTAG;
	tag_t	ES_Tag					= NULLTAG;
	tag_t	DMLRevTag				= NULLTAG;

	logical	t5InProcess;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	printf("\n Ketan Inside Chk_ES_Activein_WF \n");fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n Root task found for Chk_ES_Activein_WF \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask => %s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n EPM_ask_attachments of => %d",count);

	if(count > 0)
	{
		ES_Tag = attachments[0];
	}

	CALLAPI(TCTYPE_ask_object_type(ES_Tag,&primary_obj_type_tag));
	CALLAPI(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
	printf("\n Primary_object type_name is => %s \n",type_name1);fflush(stdout);

	//
	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 3;
	int	cntrlcnt		= 0;
	
	char*	ESDS_Lcs 		= NULL;
	
	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found for ES_WF \n");fflush(stdout);
		qry_valuesCntrlformat[0]="ES_WF";
		qry_valuesCntrlformat[1]="Live";
		qry_valuesCntrlformat[2]="0";
							
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found for ES_WF \n");fflush(stdout);
	}

	printf("\n controlObjfound is for ES Workflow ==> %d\n",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
		printf("\n Live. Inside ES_WF Validation \n");fflush(stdout);

		printf("\n type_name1 => %s \n",type_name1);fflush(stdout);
		
		if((tc_strcmp(type_name1,"T5_EstimateSheet") == 0) || (tc_strcmp(type_name1,"T5_EstimateOprtn") == 0) || (tc_strcmp(type_name1,"T5_EstimateOprtnRevision") == 0))
		{
			printf("\n Inside Error... \n");fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Selected Object cannot submit in Lifecycle. Kindly Submit Estimate Sheet Revision in workflow.");
			decision = EPM_nogo;
			return decision;
		}
		
		CALLAPI(AOM_ask_value_string(ES_Tag,"current_name",&t5current_name));
		printf("\n t5current_name is => %s \n",t5current_name);fflush(stdout);

		CALLAPI(EPM_ask_active_job_for_target(ES_Tag,&n_parents,&parents));
		printf("\n EPM_ask_active_job_for_target  => %d\n",n_parents); fflush(stdout);

		if(n_parents>1 && parents!=NULLTAG)
		{
			printf("\n Inside Error... \n");fflush(stdout);

			//CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
			//printf("\n procedure_nameprocedure_name => %s\n",procedure_name); fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Estimate Sheet already submitted in Workflow.You can not submit it again..");
			decision = EPM_nogo; 
		}
		else
		{
			printf("\n Allowed... \n");fflush(stdout);
			decision = EPM_go;
		}
	}

	return decision;
}
// Ended

int myESTobeApprovedLOVValuesMethodP( METHOD_message_t *msg, va_list  args ) // Changes Done By Ketan
{
	printf("\n Ketan Inside myESTobeApprovedLOVValuesMethodP \n"); fflush(stdout);

    /* va_list for LOV_ask_values_msg */
    tag_t	lov_tag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char***	values		= va_arg(args, char***);
	
	int		error_code		= ITK_ok;
	int		num_of_members	= 0; 
	int		ii				= 0;
       
	tag_t	CurrentRoleTag	= NULLTAG;
	tag_t	Grp_tag			= NULLTAG;
	tag_t	CR_GrHd_Tag		= NULLTAG;
	tag_t*  GHTags			= NULLTAG;
	tag_t	objTypeTag		= NULLTAG;
	
	//char	roleName[SA_name_size_c+1];
	char*	roleName 		= NULL;
	char*	groupName 		= NULL;
	char*	ES_Reviewer_role= NULL;
	char*	member_name 	= NULL;
	char*	type_name 		= NULL;
	//char	type_name[TCTYPE_name_size_c+1];
	
	groupName			= (char	*)MEM_alloc(100);
	ES_Reviewer_role	= (char	*)MEM_alloc(100);
	
	tc_strcpy(groupName,"EstimateSheet_");
	tc_strcpy(ES_Reviewer_role,"ES_Reviewer_");

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n roleName : %s\n",roleName); fflush(stdout);

	if( tc_strstr(roleName,"CVPUNE")!=NULL || tc_strstr(roleName,"PVPUNE")!=NULL )
	{
		printf("\n Inside CVPUNE \n");fflush(stdout);
		tc_strcat(groupName,"CVPUNE");
		tc_strcat(ES_Reviewer_role,"CVPUNE");
	}
	else if(tc_strstr(roleName,"DWD")!=NULL)
	{
		printf("\n Inside DWD \n");fflush(stdout);
		tc_strcat(groupName,"DWD");
		tc_strcat(ES_Reviewer_role,"DWD");
	}	
	else if(tc_strstr(roleName,"CAR")!=NULL)
	{
		printf("\n Inside CAR \n");fflush(stdout);
		tc_strcat(groupName,"CAR");
		tc_strcat(ES_Reviewer_role,"CAR");
	}	
	else if(tc_strstr(roleName,"JSR")!=NULL)
	{
		printf("\n Inside JSR \n");fflush(stdout);
		tc_strcat(groupName,"JSR");
		tc_strcat(ES_Reviewer_role,"JSR");
	}	
	else if( tc_strstr(roleName,"CVLKO")!=NULL || tc_strstr(roleName,"PVLKO")!=NULL )
	{
		printf("\n Inside CVLKO \n");fflush(stdout);
		tc_strcat(groupName,"CVLKO");
		tc_strcat(ES_Reviewer_role,"CVLKO");
	}	
	else if(tc_strstr(roleName,"CVPNR")!=NULL || tc_strstr(roleName,"PVPNR")!=NULL )
	{
		printf("\n Inside CVPNR \n");fflush(stdout);
		tc_strcat(groupName,"CVPNR");
		tc_strcat(ES_Reviewer_role,"CVPNR");
	}	
	else if(tc_strstr(roleName,"AHD")!=NULL) 
	{
		printf("\n Inside AHD \n");fflush(stdout);
		tc_strcat(groupName,"AHD");
		tc_strcat(ES_Reviewer_role,"AHD");
	}
	else if(tc_strstr(roleName,"SND")!=NULL) 
	{
		printf("\n Inside SND \n");fflush(stdout);
		tc_strcat(groupName,"SND");
		tc_strcat(ES_Reviewer_role,"SND");
	}
	else
	{
		printf("\n Inside Else \n");fflush(stdout);
		tc_strcat(groupName,"CVPUNE");
		tc_strcat(ES_Reviewer_role,"CVPUNE");
	}	
	
	printf("\n groupName is : %s\n",groupName);fflush(stdout);
	printf("\n ES_Reviewer_role : %s\n",ES_Reviewer_role);fflush(stdout);
	
	printf("\n Expanding Group and Role \n ");fflush(stdout);
	if(SA_find_group(groupName, &Grp_tag)!=ITK_ok)PrintErrorStack();
	if(SA_find_role2(ES_Reviewer_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
	if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag,&num_of_members,&GHTags)!=ITK_ok)PrintErrorStack();
	
	printf("\n No of Group Members found in Group/Role are => [%d] \n",num_of_members);  fflush(stdout);
	
	*n_values = num_of_members;
	if(num_of_members>0)
	{
		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for(ii=0;ii<num_of_members;ii++)
		{	
			printf("\n EstReviewer CR:EM no: [%d]",ii);fflush(stdout);
			if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
			if(TCTYPE_ask_object_type(GHTags[ii],&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n EstReviewer type_name2 :: %s\n", type_name);fflush(stdout);
			printf("\n EstReviewer member_name :[%s]\n",member_name);

			(*values)[ii] = (char *) MEM_alloc (strlen(member_name) + 1);
			strcpy((*values)[ii], member_name);
		}
	}
	MEM_free(GHTags);

	return error_code;
}

int myESTobeApprovedLOVValuesMethodP1( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char*       roleName=NULL ;

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


		if( tc_strstr(roleName,"CVPUNE")!=NULL || tc_strstr(roleName,"PVPUNE")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"PAPPBY");
			
		}
		else if(tc_strstr(roleName,"DWD")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"DAPPBY");
			
		}	
		else if(tc_strstr(roleName,"CAR")!=NULL)
		{
			printf( "inside car...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PAPPBY");
			
		}	
		else if(tc_strstr(roleName,"JSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JAPPBY");
			
		}	
		else if( tc_strstr(roleName,"CVLKO")!=NULL || tc_strstr(roleName,"PVLKO")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"LAPPBY");
			
		}	
		else if(tc_strstr(roleName,"TMLDLJSR")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"JAPPBY");
			
		}	
		else if(tc_strstr(roleName,"CVPNR")!=NULL || tc_strstr(roleName,"PVPNR")!=NULL )
		{
			tc_strcpy(CntrlSysCD,"UAPPBY");
			
		}	
		else if(tc_strstr(roleName,"AHD")!=NULL) // Added by Ketan
		{
			printf("\n AAPPBY : Inside AHD \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"AAPPBY");
			
		}
		else if(tc_strstr(roleName,"SND")!=NULL) // Added by Ketan
		{
			printf("\n SAPPBY : Inside SND \n"); fflush(stdout);
			tc_strcpy(CntrlSysCD,"SAPPBY");
			
		}
		else if(tc_strstr(roleName,"UVPUNE")!=NULL)
		{
			tc_strcpy(CntrlSysCD,"VAPPBY");
			
		}	
		else
		{
			 printf( "inside else...");fflush(stdout);
			tc_strcpy(CntrlSysCD,"PAPPBY");
			
		}	

/*
	GetESPlantFromRole(PlantES);
	printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DAPPBY");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JAPPBY");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LAPPBY");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"AAPPBY");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"UAPPBY");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SAPPBY");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

*/

	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"Delete Indicator", "SYSCD"},
         *qry_values[2] =  {"0", CntrlSysCD};


    //IFERR_REPORT(QRY_find2("ControlObjQry", &query));
    IFERR_REPORT(QRY_find2("Control Objects...", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

void setAddTAG_ES(int *count,tag_t **objlist,tag_t obj ) 
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

int AssignESPlanner(tag_t ESRevT,char* ES_Planner_role,char* groupName)
{
	
	char*	ES_number			= NULL;
	char*	EstPlanner 			= NULL;
	//char*	ES_Planner_role 	= NULL;
	//char*	EstPlntName 		= NULL;
	char*	member_name 		= NULL;
	char*	type_name 			= NULL;
	//char	type_name[TCTYPE_name_size_c+1];
	char	userid[SA_user_size_c+1];

	tag_t	Grp_tag				= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t*  GHTags				= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;

	int		No_GH		= 0; 
	int		ii			= 0; 
	int		ifail		= 0; 

	//ES_Planner_role = (char	*)MEM_alloc(100);
	//tc_strcpy(ES_Planner_role,"ES_Planner_");
	
	printf("\n Ketan Inside AssignESPlanner \n");fflush(stdout);

	printf("\n groupName is => %s\n",groupName);fflush(stdout);
	printf("\n ES_Planner_role => %s \n",ES_Planner_role);	fflush(stdout);
	
	ITKCALL(AOM_ask_value_string(ESRevT,"item_id",&ES_number));
	AOM_ask_value_string(ESRevT,"t5_PEPlannedBy",&EstPlanner);
	
	printf("\n ES_number: [%s]\n",ES_number);fflush(stdout);
	printf("\n EstPlanner => %s\n",EstPlanner);fflush(stdout);
	
	if(EstPlanner!=NULL)
	{
		printf("\n EstPlanner ....");fflush(stdout);
		if(SA_find_group(groupName, &Grp_tag)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(ES_Planner_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
		printf("\n EstPlanner CR:No_GH :[%d]",No_GH);  fflush(stdout);
		if(No_GH>0)
		{
			for(ii=0;ii<No_GH;ii++)
			{	
				printf("\n EstPlanner CR:EM no: [%d]",ii);fflush(stdout);
				if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
				if(TCTYPE_ask_object_type(GHTags[ii],&objTypeTag));
				if(TCTYPE_ask_name2(objTypeTag,&type_name));
				printf("\n EstPlanner  type_name :: %s\n", type_name);fflush(stdout);

				printf("\n EstPlanner User ID Name :[%s]\n",userid);
				printf("\n EstPlanner member_name :[%s]\n",member_name);
				if(strcmp(member_name,EstPlanner)==0)
				{
					logical bypass_assignable_check =true;

					if(EPM_get_participanttype ("T5_EstimatePlanner",&participant_type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(GHTags[ii],participant_type,&participant_tag)!=ITK_ok)PrintErrorStack();
					AOM_lock(ESRevT);			
					//if(ITEM_rev_add_participant(ESRevT,participant_tag)!=ITK_ok)PrintErrorStack();
					if(PARTICIPANT_add_participant(ESRevT,bypass_assignable_check,participant_tag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(ESRevT);
					AOM_unlock(ESRevT);
					printf("\n ES Planner Assigned to : [%s]\n",userid);fflush(stdout);
				}
			}
		}
	AOM_refresh ( ESRevT,TRUE);
	MEM_free(GHTags);
	}

	return ITK_ok;

}

int AssignESReviewer(tag_t ESRevT,char* ES_Reviewer_role,char* groupName)
{
	
	char*	ES_number			= NULL;
	//char*	EstPlanner 			= NULL;
	//char*	ES_Reviewer_role 	= NULL;
	//char*	EstPlntName 		= NULL;
	char*	EstReviewer 		= NULL;
	char*	member_name 		= NULL;
	char*	type_name 			= NULL;
	//char	type_name[TCTYPE_name_size_c+1];
	char	userid[SA_user_size_c+1];

	tag_t	Grp_tag				= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t*  GHTags				= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;

	int		No_GH		= 0; 
	int		ii			= 0;
	int		ifail		= 0; 

	//ES_Reviewer_role = (char	*)MEM_alloc(100);
	//tc_strcpy(ES_Reviewer_role,"ES_Reviewer_");
	
	printf("\n Ketan Inside AssignESReviewer \n");fflush(stdout);

	printf("\n groupName is => %s\n",groupName);fflush(stdout);
	printf("\n ES_Reviewer_role is => %s\n",ES_Reviewer_role);fflush(stdout);

	ITKCALL(AOM_ask_value_string(ESRevT,"item_id",&ES_number));
	AOM_ask_value_string(ESRevT,"t5_PEProcessApproveBy",&EstReviewer);
	
	printf("\n ES_number: [%s]\n",ES_number);fflush(stdout);
	printf("\n EstReviewer: [%s]\n",EstReviewer);fflush(stdout);

	if(EstReviewer!=NULL)
	{
		printf("\n EstReviewer CR:Setting Group_Head...");fflush(stdout);
		if(SA_find_group(groupName, &Grp_tag)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(ES_Reviewer_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
		printf("\n EstReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
		if(No_GH>0)
		{
			for(ii=0;ii<No_GH;ii++)
			{	
				printf("\n EstReviewer CR:EM no: [%d]",ii);fflush(stdout);
				if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
				if(TCTYPE_ask_object_type(GHTags[ii],&objTypeTag));
				if(TCTYPE_ask_name2(objTypeTag,&type_name));
				printf("\n EstReviewer type_name2 :: %s\n", type_name);fflush(stdout);

				printf("\n EstReviewer User ID Name :[%s]\n",userid);
				printf("\n EstReviewer member_name :[%s]\n",member_name);
				if(strcmp(member_name,EstReviewer)==0)
				{
					logical bypass_assignable_check =true;

					if(EPM_get_participanttype ("T5_EstimateReviewer",&participant_type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(GHTags[ii],participant_type,&participant_tag)!=ITK_ok)PrintErrorStack();
					AOM_lock(ESRevT);			
					//if(ITEM_rev_add_participant(ESRevT,participant_tag)!=ITK_ok)PrintErrorStack();
					if(PARTICIPANT_add_participant(ESRevT,bypass_assignable_check,participant_tag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(ESRevT);
					AOM_unlock(ESRevT);
					printf("\n ES Reviewer Assigned to : [%s]\n",userid);fflush(stdout);

				}
			}
		}
		AOM_refresh ( ESRevT,TRUE);
		MEM_free(GHTags);
	}	
	
	return ITK_ok;

}

int AssignPSDPlanner(tag_t ESRevT,char* groupName)
{
	
	char*	ES_number			= NULL;
	char*	PSD_Planner_role 	= NULL;
	char*	rolename		 	= NULL;
	char*	userid			 	= NULL;
	//char	rolename[SA_name_size_c+1];
	//char	userid[SA_user_size_c+1];
	

	tag_t	group_tag			= NULLTAG;
	tag_t*	role_tags			= NULLTAG;
	tag_t	user_tag			= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	role_tag			= NULLTAG;
	tag_t*	member_tags			= NULLTAG;
	
	int		num_of_members		= 0;
	int		num_of_roles		= 0;
	int		ij			= 0; 
	int		jk			= 0;
	int		ifail		= 0; 

	PSD_Planner_role = (char	*)MEM_alloc(100);
	tc_strcpy(PSD_Planner_role,"PSD_Planner");
	
	printf("\n Ketan Inside AssignPSDPlanner \n");fflush(stdout);

	printf("\n groupName is => %s\n",groupName);fflush(stdout);

	ITKCALL(AOM_ask_value_string(ESRevT,"item_id",&ES_number));
	
	printf("\n ES_number: [%s]\n",ES_number);fflush(stdout);
	printf("\n PSD_Planner_role is => %s\n",PSD_Planner_role);fflush(stdout);

	ITKCALL(SA_find_group(groupName,&group_tag));
	if (group_tag != NULLTAG)
	ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags));

	printf("\n No of Role found in Group[%s] are => %d\n",groupName,num_of_roles);fflush(stdout);
			
	if(num_of_roles>0)
	{
		ij=0;
		for (ij=0;ij<num_of_roles ;ij++ )
		{
			ITKCALL(SA_ask_role_name2(role_tags[ij],&rolename));
			printf("\n Rol Name :[%d][%s]\n",ij,rolename);fflush(stdout);

			if(tc_strcmp(rolename,PSD_Planner_role)==0)
			{
				printf("\n Role Match Found\n");fflush(stdout);
				role_tag = role_tags[ij];
				ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;

					for (jk=0;jk<num_of_members ;jk++  )
					{
						ITKCALL(SA_ask_groupmember_user(member_tags[jk],&user_tag));
						ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n User ID Name :[%s]\n",userid);fflush(stdout);
					
						// TCTYPE_find_type("T5_PSDPlanner", "T5_PSDPlanner", &participant_type);
						// EPM_create_participant(member_tags[jk], participant_type, &participant_tag);
						// GRM_find_relation_type("HasParticipant", &relation_type);
						// GRM_create_relation(ESRevT, participant_tag, relation_type,  NULLTAG, &relation);
						// GRM_save_relation(relation);
						// printf("\n PSD Planner Assigned..to : [%s]\n",userid);fflush(stdout);

						TCTYPE_find_type("T5_PSDPlanner", "T5_PSDPlanner", &participant_type);
						printf("\n PSD Planner : Test 3333 \n");fflush(stdout);
						setAddTAG_ES(&p1,&ptypes,participant_type);
						printf("\n PSD Planner Test 3333.1 \n");fflush(stdout);
						setAddTAG_ES(&p2,&ptypes2,member_tags[jk]);
						printf("\n PSD Planner Test ended 4444 \n");fflush(stdout);
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					CALLAPI(PARTICIPANT_add_participants(ESRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}

			}

		}
					
	}
	else
	{
		printf("\n No Role found Under group => %s \n",groupName);fflush(stdout);
	}	

	return ITK_ok;

}

int AssignPSDReviewer(tag_t ESRevT,char* groupName)
{
	
	char*	ES_number			= NULL;
	char*	PSD_Reviewer_role 	= NULL;
	char*	rolename		 	= NULL;
	char*	userid			 	= NULL;
	//char	rolename[SA_name_size_c+1];
	//char	userid[SA_user_size_c+1];
	

	tag_t	group_tag			= NULLTAG;
	tag_t*	role_tags			= NULLTAG;
	tag_t	user_tag			= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	role_tag			= NULLTAG;
	tag_t*	member_tags			= NULLTAG;
	
	int		num_of_members		= 0;
	int		num_of_roles		= 0;
	int		ij			= 0; 
	int		jk			= 0; 
	int		ifail		= 0; 

	PSD_Reviewer_role = (char	*)MEM_alloc(100);
	tc_strcpy(PSD_Reviewer_role,"PSD_Reviewer");
	
	printf("\n Ketan Inside AssignPSDReviewer \n");fflush(stdout);

	printf("\n groupName is => %s\n",groupName);fflush(stdout);

	ITKCALL(AOM_ask_value_string(ESRevT,"item_id",&ES_number));
	
	printf("\n ES_number: [%s]\n",ES_number);fflush(stdout);
	printf("\n PSD_Reviewer_role is => %s\n",PSD_Reviewer_role);fflush(stdout);

	ITKCALL(SA_find_group(groupName,&group_tag));
	if (group_tag != NULLTAG)
	ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags));

	printf("\n No of Role found in Group[%s] are => %d\n",groupName,num_of_roles);fflush(stdout);
			
	if(num_of_roles>0)
	{
		ij=0;
		for (ij=0;ij<num_of_roles ;ij++ )
		{
			ITKCALL(SA_ask_role_name2(role_tags[ij],&rolename));
			printf("\n Rol Name :[%d][%s]\n",ij,rolename);fflush(stdout);

			if(tc_strcmp(rolename,PSD_Reviewer_role)==0)
			{
				printf("\n Role Match Found\n");fflush(stdout);
				role_tag = role_tags[ij];
				ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;

					for (jk=0;jk<num_of_members ;jk++  )
					{
						ITKCALL(SA_ask_groupmember_user(member_tags[jk],&user_tag));
						ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n User ID Name :[%s]\n",userid);fflush(stdout);
					
						// TCTYPE_find_type("T5_PSDReviewer", "T5_PSDReviewer", &participant_type);
						// EPM_create_participant(member_tags[jk], participant_type, &participant_tag);
						// GRM_find_relation_type("HasParticipant", &relation_type);
						// GRM_create_relation(ESRevT, participant_tag, relation_type,  NULLTAG, &relation);
						// GRM_save_relation(relation);
						// printf("\n PSD Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);

						TCTYPE_find_type("T5_PSDReviewer", "T5_PSDReviewer", &participant_type);
						printf("\n PSD Reviewer : Analyst Test 3333 \n");fflush(stdout);
						setAddTAG_ES(&p1,&ptypes,participant_type);
						printf("\n PSD Reviewer : Test 3333.1 \n");fflush(stdout);
						setAddTAG_ES(&p2,&ptypes2,member_tags[jk]);
						printf("\n PSD Reviewer : Test ended 4444 \n");fflush(stdout);
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					CALLAPI(PARTICIPANT_add_participants(ESRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}

			}

		}
					
	}
	else
	{
		printf("\n No Role found Under group => %s \n",groupName);fflush(stdout);
	}	

	return ITK_ok;

}

int Assign_APL_PSD( EPM_action_message_t msg )
{

	int				error_code	= ITK_ok;
	int             ifail		= 0;		
		
	//char    type_name[TCTYPE_name_size_c+1];
	char*	type_name			= NULL;
	char*	item_id				= NULL;
	char*	ES_no				= NULL;
	char*	CurrentTask			= NULL;
	char*	parent_name			= NULL;
	char*	EstPlntName 		= NULL;
	char*	ES_Planner_role		= NULL;
	char*	ES_Reviewer_role	= NULL;
	char*	PSD_Planner_role	= NULL; 
	char*	PSD_Reviewer_role	= NULL; 
	char*	PsdRoleName 	    = NULL;
	char*	groupName 			= NULL;
	
	int	  noAttachment 	= 0;
		
	tag_t   ES_rev_tag			= NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t	rootTask			= NULLTAG;
	tag_t	*attachments		= NULLTAG;

	groupName			= (char	*)MEM_alloc(100);
	ES_Planner_role		= (char	*)MEM_alloc(100);
	ES_Reviewer_role	= (char	*)MEM_alloc(100);
	PsdRoleName			= (char	*)MEM_alloc(100);
	PSD_Planner_role	= (char	*)MEM_alloc(100); 
	PSD_Reviewer_role	= (char	*)MEM_alloc(100); 

	tc_strcpy(groupName,"EstimateSheet_");
	tc_strcpy(ES_Planner_role,"ES_Planner_");
	tc_strcpy(ES_Reviewer_role,"ES_Reviewer_");
	tc_strcpy(PSD_Planner_role,"PSD_Planner"); 
	tc_strcpy(PSD_Reviewer_role,"PSD_Reviewer"); 
	
	printf("\n ************** Ketan inside Assign_APL_PSD ***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Assign_APL_PSD \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		ES_rev_tag = attachments[0];
		if(TCTYPE_ask_object_type(ES_rev_tag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject => %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0)
	{
		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);
			AOM_ask_value_string( ES_rev_tag, "item_id", &item_id);
			AOM_ask_value_string( ES_rev_tag, "current_id", &ES_no);

			printf("\n ES_no => %s \n",ES_no);fflush(stdout);

			AOM_ask_value_string(ES_rev_tag, "t5_PEPlantName", &EstPlntName);

			if(strcmp(EstPlntName,"CAR")==0 || strcmp(EstPlntName,"PCBU")==0)
			{
				printf("\n Inside CAR \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateCAR AssignReview");
				tc_strcat(groupName,"CAR");
				tc_strcat(ES_Planner_role,"CAR");
				tc_strcat(ES_Reviewer_role,"CAR");
			}
			else if(strcmp(EstPlntName,"CVBU PUNE")==0)
			{
				printf("\n Inside CVBU PUNE \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateCVBUPUNE AssignReview");
				tc_strcat(groupName,"CVPUNE");
				tc_strcat(ES_Planner_role,"CVPUNE");
				tc_strcat(ES_Reviewer_role,"CVPUNE");

			}
			else if(strcmp(EstPlntName,"CVBU JSR")==0)
			{
				printf("\n Inside CVBU JSR \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateCVBUJSR AssignReview");
				tc_strcat(groupName,"JSR");
				tc_strcat(ES_Planner_role,"JSR");
				tc_strcat(ES_Reviewer_role,"JSR");

			}
			else if(strcmp(EstPlntName,"CVBU LKO")==0)
			{
				printf("\n Inside CVBU LKO \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateCVBULKO AssignReview");
				tc_strcat(groupName,"CVLKO");
				tc_strcat(ES_Planner_role,"CVLKO");
				tc_strcat(ES_Reviewer_role,"CVLKO");

			}
			else if(strcmp(EstPlntName,"CVBU PNR")==0)
			{
				printf("\n Inside CVBU PNR \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateCVBUUTK AssignReview");
				tc_strcat(groupName,"CVPNR");
				tc_strcat(ES_Planner_role,"CVPNR");
				tc_strcat(ES_Reviewer_role,"CVPNR");

			}
			else if(strcmp(EstPlntName,"DHARWAD")==0)
			{
				printf("\n Inside DHARWAD \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateDHARWAD AssignReview");
				tc_strcat(groupName,"DWD");
				tc_strcat(ES_Planner_role,"DWD");
				tc_strcat(ES_Reviewer_role,"DWD");


			}
			else if(strcmp(EstPlntName,"AHD")==0) 
			{
				printf("\n Inside AHD \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateAHD AssignReview"); 
				tc_strcat(groupName,"AHD");
				tc_strcat(ES_Planner_role,"AHD");
				tc_strcat(ES_Reviewer_role,"AHD");

			}
			else if(strcmp(EstPlntName,"SANAND")==0) 
			{
				printf("\n Inside SANAND \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateSANAND AssignReview");
				tc_strcat(groupName,"SND");
				tc_strcat(ES_Planner_role,"SND");
				tc_strcat(ES_Reviewer_role,"SND");

			}
			else if(strcmp(EstPlntName,"SMALLCAR PNR")==0)
			{
				printf("\n Inside SMALLCAR PNR \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateSMALLCARPNR AssignReview");
				tc_strcat(groupName,"PVPNR");
				tc_strcat(ES_Planner_role,"PVPNR");
				tc_strcat(ES_Reviewer_role,"PVPNR");

			}
			else if(strcmp(EstPlntName,"PCBU LKO")==0)
			{
				printf("\n Inside PCBU LKO \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimatePCBULKO AssignReview");
				tc_strcat(groupName,"PVLKO");
				tc_strcat(ES_Planner_role,"PVLKO");
				tc_strcat(ES_Reviewer_role,"PVLKO");

			}
			else if(strcmp(EstPlntName,"TMLDL JSR")==0)
			{
				printf("\n Inside TMLDL JSR \n");fflush(stdout);
				tc_strcpy(PsdRoleName,"EstimateTMLDLJSR AssignReview");
				tc_strcat(groupName,"TMLDLJSR");
				tc_strcat(ES_Planner_role,"TMLDLJSR");
				tc_strcat(ES_Reviewer_role,"TMLDLJSR");
			}
			else
			{
				printf("\n Invalid PlantName on Estimate sheet......\n");fflush(stdout); 
			}

			printf("\n ES_Planner_role : %s\n",ES_Planner_role);fflush(stdout);
			printf("\n ES_Reviewer_role : %s\n",ES_Reviewer_role);fflush(stdout);
			printf("\n groupName is : %s\n",groupName);fflush(stdout);

			CALLAPI(AssignESPlanner(ES_rev_tag,ES_Planner_role,groupName));
			CALLAPI(AssignESReviewer(ES_rev_tag,ES_Reviewer_role,groupName));
			CALLAPI(AssignPSDPlanner(ES_rev_tag,groupName));
			CALLAPI(AssignPSDReviewer(ES_rev_tag,groupName));
	}
	else
	{
	  	printf("\n No proper class for T5_EstimateSheetRevision......\n");fflush(stdout);
	}

	return error_code;
}

extern int tm_escreate_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method;
    int ifail=0;  
 
	if( ifail == ITK_ok )
    {
        //printf("\n T5_PEShopNameLOVType Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_PEShopNameLOVType",LOV_ask_values_msg,&myESDomainNameLOVValuesMethodP,0,&method);
		//printf("\n after T5_PEShopNameLOVType Project Codecm \n");fflush(stdout);
	}

	if( ifail == ITK_ok )
    {
        //printf("\n T5_EstShopLOVType Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_EstShopLOVType",LOV_ask_values_msg,&myESShopNameLOVValuesMethodP,0,&method);
		//printf("\n after T5_EstShopLOVType Project Codecm \n");fflush(stdout);
	}


	if( ifail == ITK_ok )
    {
        //printf("\n T5_PEProcessApproveByLOVTyp Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_PEProcessApproveByLOVTyp",LOV_ask_values_msg,&myESTobeApprovedLOVValuesMethodP,0,&method);
		//printf("\n after T5_PEProcessApproveByLOVTyp Project Codecm \n");fflush(stdout);
	}

	// Added By Ketan
	if( ITK_ok == EPM_register_action_handler("Assign_APL_PSD", "", Assign_APL_PSD))
	{
		//printf("\t\n Registered Action Handler Assign_APL_PSD \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler Assign_APL_PSD\n");fflush(stdout);
	}
	//Ended
  
	if( ITK_ok == EPM_register_action_handler("ES_APLPrereleased", "", ES_APLPrereleased))
	{
		//printf("\t\n Registered Action Handler ES_APLPrereleased\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_APLPrereleased\n");fflush(stdout);
	}
	
	if( ITK_ok == EPM_register_action_handler("ES_APLFinalReleased", "", ES_APLFinalReleased))
	{
		//printf("\t\n Registered Action Handler ES_APLFinalReleased\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_APLFinalReleased\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("ES_PSDWorking", "", ES_PSDWorking))
	{
		//printf("\t\n Registered Action Handler ES_PSDWorking\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_PSDWorking\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("ES_PSDFinalReleased", "", ES_PSDFinalReleased))
	{
		//printf("\t\n Registered Action Handler ES_PSDFinalReleased\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_PSDFinalReleased\n");fflush(stdout);
	}

	//added by dss///

	if( ITK_ok == EPM_register_action_handler("ES_AutoCreation", "", ES_AutoCreation))
	{
		//printf("\t\n Registered Action Handler ES_AutoCreation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_AutoCreation\n");fflush(stdout);
	}

	//end of code added by dss ////

	if( ITK_ok == EPM_register_action_handler("ES_PSDclaim", "", ES_PSDclaim))
	{
		//printf("\t\n Registered Action Handler ES_Rejection_psd \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler ES_Rejection_psd \n");fflush(stdout);
	}


	if( ITK_ok == EPM_register_rule_handler ("estimate_sheet_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)estimate_sheet_signoff_checks_Func))
	{
		//printf("\t\n Registered Rule Handler estimate_sheet_signoff_checks_Func\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler estimate_sheet_signoff_checks_Func\n");fflush(stdout);
	}
   
	// Added By Ketan
	if(ITK_ok ==  EPM_register_rule_handler ("ES_activeInWorkflow","Check Validation with ES_activeInWorkflow", (EPM_rule_handler_t) Chk_ES_Activein_WF))
	{
		//printf("\t\n Registered rule  ES_activeInWorkflow.................\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register rule Handler ES_activeInWorkflow\n");fflush(stdout);
	}
	// Endded

	if( ITK_ok == EPM_register_rule_handler ("ES_Role_Validation","This Handler is used to display message",(EPM_rule_handler_t)ES_Role_Validation)) // Added by Ketan TZ 1.76
	{
		//printf("\t\n Registered Rule Handler ES_Role_Validation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler ES_Role_Validation\n");fflush(stdout);
	}

	return ITK_ok;

}

extern DLLAPI int tm_escreate_register_callbacks()
{
	 CUSTOM_register_exit("tm_escreate", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_escreate_register_method);

     printf("\n registered function tm_escreate\n");	fflush(stdout);

	 return ( ITK_ok );
}
