/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler to check VCMS approval for NOPO parts under DML.
*  Code                 :   tm_CheckVCMSforNOPO.c
*  Created on			:   12/04/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		05/09/2019				Mohan Tayade		Workflow Action Handler to check VCMS approval for NOPO parts under DML.
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_CheckVCMSforNOPO(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int FirstCheckOK	=  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *POinfo3		= NULL;
	char *DMLtype		= NULL;
	char *sDml_DR		= NULL;
	char *PlntToPlnt		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n tm_CheckVCMSforNOPO Function started...");fflush(stdout);
	TC_write_syslog("\n tm_CheckVCMSforNOPO Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Checking eligibility
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&DMlid)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLtype)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&sDml_DR)!=ITK_ok)PrintErrorStack();
				printf("\n P9:DMlid: %s DMLtype:%s PlntToPlnt:%s  sDml_DR:%s \n",DMlid,DMLtype,PlntToPlnt,sDml_DR); fflush(stdout);
				FirstCheckOK=0;
				if(((tc_strcmp(DMLtype,"MR")==0)||(tc_strcmp(DMLtype,"DFMR")==0)||(tc_strcmp(DMLtype,"TPL")==0)||(tc_strcmp(DMLtype,"Veh")==0))&& ((tc_strcmp(sDml_DR,"AR3P")==0)||(tc_strcmp(sDml_DR,"DR3P")==0)||(tc_strcmp(sDml_DR,"DR4")==0)|| (tc_strcmp(sDml_DR,"DR5")==0)||(tc_strcmp(sDml_DR,"AR4")==0)|| (tc_strcmp(sDml_DR,"AR5")==0)))
				{
					printf("\n P10:PO FirstCheckOK for DML:%s \n",DMlid);fflush(stdout);
					FirstCheckOK=1;
				}
				else if((tc_strcmp(DMLtype,"TODR")==0) && ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)||(tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)||(tc_strcmp(PlntToPlnt,"DR3 to DR4")==0)||(tc_strcmp(PlntToPlnt,"DR4 to DR5")==0)))
				{
					printf("\n P11: PO FirstCheckOK for DML:%s \n",DMlid);fflush(stdout);
					FirstCheckOK=1;
				}
				else
				{
					printf("\n P12: Not eligible DML:%s \n",DMlid);fflush(stdout);
					FirstCheckOK=0;
				}
				if(FirstCheckOK >0)
				{
					//Control object logic:
					if(QRY_find2("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n P13:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n P14:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "POCHCK";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n P15:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
						printf("\n POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
						if(strstr(POinfo3,"GMDVCMSOFF")==NULL)
						{
							if(strstr(POinfo3,"GMDVCMSUAPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UAPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/vcmsfornopo.sh %s ",DMlid);
								sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/vcmsfornopo.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"GMDVCMSCVPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CVPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/vcmsfornopo.sh %s ",DMlid);
								sprintf(command,"/user/cvprod/shells/DML_DCR/vcmsfornopo.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"GMDVCMSCMITEST")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CMITEST:VCMS:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/vcmsfornopo.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"GMDVCMSUADEV")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UADEV:VCMS:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/vcmsfornopo.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else
							{
								printf("\n POCHCK:other client \n");fflush(stdout);
							}
						}
					}
				}
				else
				{
					printf("\n P121:DML is not applicable for PO check. \n");fflush(stdout);
				}
			}
		}
	}
	printf("\n tm_CheckVCMSforNOPO Function end...");fflush(stdout);
	TC_write_syslog("\n tm_CheckVCMSforNOPO Function end...");
	//return error_code;
	return 0;
}