/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       tm_CommonAddDeleteReport.c
*
* Description   : > This register custom user service. Implemented Custom ITK functions for generating  Report.
*                                 > This ITK functions will calle in Rich Client for generating report.
* Module

* Since             :   12-12-2023
* ENVIRONMENT   :   C,ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 12/12/2023     Vaibhav Bodkhe                                             Base Code
* 10/07/2024     Vaibhav Bodkhe                                             Custom register pritf removed
* 22/11/2025     Vaibhav Bodkhe                                             Custom register pritf removed
*
* -----------------------------------------------------------------------------
*
*****************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL         \
status=X;        \
if (status != ITK_ok)    \
{        \
int      index = 0;      \
int      n_ifails = 0;   \
const int*       severities = 0;         \
const int*       ifails = 0;     \
const char**    texts = NULL;    \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);         \
for( index=0; index<n_ifails; index++)   \
{        \
printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
}        \
return status;   \
}        \
;
int CommonAddDeleteReport(void *return_data)
{
	
	int 				n_tags_found				= 0;
	char 				*BasePart					= NULL;
	char 				*BaseRev					= NULL;
	char 				*BaseSeq					= NULL;
	char 				*BasePlant					= NULL;
	char 				*BaseView					= NULL;
	char 				*PropsedPart				= NULL;
	char 				*ProposedRev				= NULL;
	char 				*ProposedSeq				= NULL;
	char 				*ProposedPlant				= NULL;
	char 				*ProposedView				= NULL;
	char 				*PlantNme					= NULL;
	char 				*MaxLvl						= NULL;
	char 				*View				= NULL;
	char 				*UserName					= NULL;
	char 				*isvclistreq					= NULL;
	char				command[1000];
	
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&BasePart);
	USERARG_get_string_argument(&BaseRev);
	USERARG_get_string_argument(&BaseSeq);
	USERARG_get_string_argument(&BasePlant);
	USERARG_get_string_argument(&BaseView);
	
	USERARG_get_string_argument(&PropsedPart);
	USERARG_get_string_argument(&ProposedRev);
	USERARG_get_string_argument(&ProposedSeq); 
	USERARG_get_string_argument(&ProposedPlant);  
	USERARG_get_string_argument(&ProposedView);
	
	USERARG_get_string_argument(&MaxLvl); 
	USERARG_get_string_argument(&UserName); 
	USERARG_get_string_argument(&isvclistreq); 
	printf("\n BasePart Number :: %s ",BasePart);fflush(stdout);
	printf("\n BaseRev Number :: %s ",BaseRev);fflush(stdout);
	printf("\n BaseSeq Number :: %s ",BaseSeq);fflush(stdout);
	printf("\n BasePlant  :: %s ",BasePlant);fflush(stdout);
	printf("\n BaseView  :: %s ",BaseView);fflush(stdout);
	
	printf("\n PropsedPart Number :: %s ",PropsedPart);fflush(stdout);
	printf("\n ProposedRev Number :: %s ",ProposedRev);fflush(stdout);
	printf("\n ProposedSeq Number :: %s ",ProposedSeq);fflush(stdout);
	printf("\n ProposedPlant  :: %s ",ProposedPlant);fflush(stdout);
	printf("\n ProposedView  :: %s ",ProposedView);fflush(stdout);
	
	printf("\n MaxLvl :: %s ",MaxLvl);fflush(stdout);
	printf("\n UserName :: %s \n\n",UserName);fflush(stdout);
	printf("\n isvclistreq :: %s \n\n",isvclistreq);fflush(stdout);
	printf("\n Going to call CADReport EXE file............\n\n ");fflush(stdout);
	sprintf(command,"/user/cvprod/shells/APL/tm_CommonAddDelReport.sh  %s %s %s %s %s %s %s %s %s %s %s %s %s",BasePart,BaseRev,BaseSeq,BasePlant,BaseView,PropsedPart,ProposedRev,ProposedSeq,ProposedPlant,ProposedView,MaxLvl,UserName,isvclistreq);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	
	
	return ITK_ok;
}
extern int tm_CommonAddDeleteReportfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	int nargs = 13;
	int retValueType;
	int inputArgTypes[13] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //Base Part
	inputArgTypes[1] = USERARG_STRING_TYPE; //BaseRev
	inputArgTypes[2] = USERARG_STRING_TYPE; //BaseSeq
	inputArgTypes[3] = USERARG_STRING_TYPE; //BPlantNme
	inputArgTypes[4] = USERARG_STRING_TYPE; //BaseView
	
	inputArgTypes[5] = USERARG_STRING_TYPE; //Propsed Part
	inputArgTypes[6] = USERARG_STRING_TYPE; //Propsed Rev
	inputArgTypes[7] = USERARG_STRING_TYPE; //Propsed Seqt
	inputArgTypes[8] = USERARG_STRING_TYPE; //PPlantNme
	inputArgTypes[9] = USERARG_STRING_TYPE; //ProposedView
	
	inputArgTypes[10] = USERARG_STRING_TYPE; //MaxLvl
	inputArgTypes[11] = USERARG_STRING_TYPE; //UserName 
	inputArgTypes[12] = USERARG_STRING_TYPE; //isvclistreq
	retValueType = USERARG_STRING_TYPE ; 
	ifail=USERSERVICE_register_method("CommonAddDeleteReport",(USER_function_t)CommonAddDeleteReport,nargs,inputArgTypes,retValueType);
	return ifail;
}
extern DLLAPI int tm_CommonAddDeleteReport_register_callbacks ()
{	
	int ifail    = ITK_ok;
	ifail = CUSTOM_register_exit("tm_CommonAddDeleteReport", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_CommonAddDeleteReportfncalling);
	return(ITK_ok);
}