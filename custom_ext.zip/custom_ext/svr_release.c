#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>


#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

tag_t svr_update_rel_status(tag_t object_tag)
{		
		tag_t		class_id				=     NULLTAG;
		char		*class_name				=    NULL;
		tag_t		tReleaseStatusList_checkin=NULLTAG; 
		logical		log1;
		int			n_values_checkin			=0;
		int			cunt1					=	0; 
		tag_t*		attr_tags_checkin		=	NULLTAG; 
		logical		*is_it_null_checkin		=   NULL; 
		logical		*is_it_empty_checkin	=   NULL;
		
		int status = ITK_ok;
		
		status = POM_class_of_instance(object_tag,&class_id); 

		status = POM_name_of_class(class_id,&class_name); 

		status = POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin);fflush(stdout);
		if(status==ITK_ok)
	    {
			printf("\nSVR:release_status_list found\n");
		}

		status =POM_unload_instances (1,&object_tag);
		status =POM_load_instances(1,&object_tag,class_id,1);
		status =POM_is_loaded(object_tag,&log1);
		if(status==ITK_ok)
	    {
			//printf("\n\nSVR:status Updated......\n");
		}

//		if(log1 == 1)
//		{
//			 printf(" Load Success\n " );
//		}else
//		printf("Load Failure\n"  );

		status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
		if(status==ITK_ok)
	    {
			printf("\nnSVR:No of status:%d\n",n_values_checkin);fflush(stdout);
		}
		
		if(n_values_checkin>0)
		{
			status = POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin);
//			if(status==ITK_ok)
//			{
//				printf("\nSVR:No of status:%d\n",n_values_checkin);fflush(stdout);
//			}

			for (cunt1 =0;cunt1 < n_values_checkin; cunt1++)
			{ 
				char*			WSO_Name					= NULL;
				status = AOM_ask_name(attr_tags_checkin[cunt1],&WSO_Name);
				printf("\nSVR:del existing status:%d\n",cunt1);fflush(stdout);  
				status =POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1);
				//				if(status==ITK_ok)
//				{
//					printf("\nSVR:no of status del:%d\n",cunt1);fflush(stdout);
//				}			
				status =POM_save_instances(1,&object_tag,1);
				status =POM_refresh_instances(1,&object_tag,class_id,2);
				status =AOM_lock(object_tag);
				status =AOM_save(object_tag);
				status =AOM_refresh(object_tag,1);
			}

			status =POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin);
			if(status==ITK_ok)
			{
				printf("\nnSVR: No of status after delete:%d\n",n_values_checkin);fflush(stdout);

			}


			 status =AOM_unlock(object_tag);
			 if(status==ITK_ok)
			 {
				printf("\nSVR return\n");fflush(stdout);
			 }
		  }
	return object_tag;
}
;


extern EPM_decision_t DLLAPI svr_chk_assigned_participants(EPM_rule_message_t msg)
	{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULLTAG;
		tag_t objTypeTag = NULLTAG;
		tag_t    	    propEff_tag				    =NULLTAG;

		char*	username				=NULL;
		tag_t	user_tag				=NULLTAG;
 		char*	CurrentTask				=NULL;	
		char*	parent_name				=NULL; 
		char  	type_name[TCTYPE_name_size_c+1];
 		char*	 AnalystName		= NULL;		 
		char*	 biw_review		= NULL;
		char*	 trim_review		= NULL;
		char*	 chassis_review		= NULL;
		char*	 ee_review			= NULL;
		char*	 pt_review			= NULL;
		char*	 vi_review			= NULL;
		int ifail=0;
		
		POM_get_user(&username,&user_tag);
		printf("\n\t Starting for username :%s....\n",username);fflush(stdout);		

		CALLAPI(EPM_ask_root_task(msg.task,&root_task)); 

		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);	

		CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
		printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

		if(strstr(CurrentTask,"Assign Analyst and VI Reviewer")!=NULL)
		{
			CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
			printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
			if(count>0)
			{
			  for(i=0;i<count;i++)
			  {			
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name( objTypeTag, type_name));
				printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)				//Task - Analyst, COC Review  
				{				
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));		
//					printf("\n\n\t\t Analyst Name of task :: %s \n",AnalystName);fflush(stdout);  
//					if (tc_strcmp(AnalystName,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option"); 	
//						return ITK_err;
//					}


					/*******************/
					tag_t Tsk_CRB_rel_type = NULLTAG;
					tag_t* TskCRB = NULLTAG;
				 
					tag_t	ObjTypTskCRB	= NULLTAG;
					char   type_name8[TCTYPE_name_size_c+1];
					int CRBcunt =0;
					int d=0;
					int anaflag=0;

					if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (Tsk_CRB_rel_type!=NULLTAG)
					{
							//printf("\n SVR:inside DML HasParticipant \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(attachments[i],Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
							printf("\nSVR:Task Participants: %d",CRBcunt);fflush(stdout);	
							for (d=0;d<CRBcunt ;d++ )
							{	
							//	printf("\nSVR:d:%d\n",d);fflush(stdout); 
								if(TCTYPE_ask_object_type(TskCRB[d],&ObjTypTskCRB));
								if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
							//	printf("\n SVR:DML: type_name8 :: %s\n", type_name8);fflush(stdout);
								if (strcmp(type_name8,"Analyst")==0)
								{
									printf("\n SVR - Analyst present \n"); fflush(stdout); 
									anaflag=1;
								}
							}
					}
					if(anaflag!=1)
					{						
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Analyst to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Analyst option"); 	
						return ITK_err;					
					}

					/*******************/

//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_BIWReviewer",&biw_review));	
//					printf("\n\n\t\t biw_review:%s\n",biw_review);fflush(stdout);  
//					if (tc_strcmp(biw_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign BIW Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->BIW_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_TRIMReviewer",&trim_review));	
//					printf("\n\n\t\t trim_review:%s\n",trim_review);fflush(stdout);  
//					if (tc_strcmp(trim_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Trim Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Trim_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_CHReviewer",&chassis_review));	
//					printf("\n\n\t\t chassis_review:%s\n",chassis_review);fflush(stdout);  
//					if (tc_strcmp(chassis_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Chassis Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Chassis_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_EEReviewer",&ee_review));	
//					printf("\n\n\t\t ee_review:%s\n",ee_review);fflush(stdout);  
//					if (tc_strcmp(ee_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign E & E Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->EE_COC_Reviewer option"); 	
//						return ITK_err;
//					}
//
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_PTReviewer",&pt_review));	
//					if (tc_strcmp(ee_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls assign Powertrain Reviewer to the Task, \nHelp: Expand DML till target","\nUse: Select Task : Tools->Assign Participant->Powertrain_COC_Reviewer option"); 	
//						return ITK_err;
//					} 


				}

				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)   //DML - VI Manager Review 
				{					  
//					CALLAPI(AOM_UIF_ask_value(attachments[i],"T5_VIReviewer",&vi_review));    
//					printf("\n\n\t\t VI Reviewer Name of task :: %s \n",vi_review);fflush(stdout);
//
//					if (tc_strcmp(vi_review,"")==0)
//					{
//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign VI Reviewer/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->VI Reviewer"); 	
//						return ITK_err;
//					}

					/**************/
					tag_t dml_CRB_rel_type = NULLTAG;
					tag_t DmlCRBTag = NULLTAG;
					tag_t	ObjTypDmlCRB	= NULLTAG;
					int CRBcount = 0;
					char   type_name7[TCTYPE_name_size_c+1];
					int j = 0;
					int viflag=0;
					tag_t* DmlCRB = NULLTAG;

 					if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
					if (dml_CRB_rel_type!=NULLTAG)
					{
						//printf("\nSVR Inside DML HasParticipant.. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(attachments[i],dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
						printf("\nSVR DML Participant count: %d",CRBcount);fflush(stdout);	
						for (j=0;j<CRBcount ;j++ )
						{	
						 
							DmlCRBTag = DmlCRB[j];
							if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
							if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
							//printf("\n SVR:DML: type_name7 :: %s\n", type_name7);fflush(stdout);
							if (strcmp(type_name7,"T5_VIReviewer")==0)
							{
									printf("\n SVR - VI reviewer present \n"); fflush(stdout); 
									viflag=1;
							}
						}
					}
					if(viflag!=1)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Pls Assign VI Reviewer/Manager to the DML, \nHelp: Go to target","\nUse: Select DML : Tools->Assign Participant->VI Reviewer"); 	
						return ITK_err;
					
					}
							
							 
					/**************/
				}
			  }
			}
		}

		decision = EPM_go;
		return decision;
	}


 
 extern EPM_decision_t DLLAPI svr_chk_signoff(EPM_rule_message_t msg) 
	{
	  int count,j,l;
	  int m = 0;
 	  tag_t *attachments = NULLTAG;
	  tag_t *DMLRevision = NULLTAG;
	  tag_t  *secondary_objects = NULLTAG;
	  char *user_name;
	  char *class_name;
	  char *class_name1;
 	  tag_t relation_type;
	  tag_t tsk_dml_rel_type;
	  int   n_attchs,partcnt = 0;

  	  tag_t class_id=NULLTAG;
	  tag_t class_id1=NULLTAG;
 	  tag_t root_task=NULLTAG;
 	  tag_t *PartsTag=NULLTAG;
 	  int status = ITK_ok;
  
	  char*	 object_type		= NULL;	
 	  
	  char*	 t5current_name		= NULL;	
 	  char*	 DMLtype			= NULL;	
   	  char*	 current_name		= NULL;
	  char*	 projectname		= NULL;
	  char	*s;
   	  logical is_latest;

 		tag_t DMLLcmTag = NULLTAG;
		tag_t DMLRevTag = NULLTAG;
		int   ifail				= 0;

   		char		   *DMLNumber =NULL;
		char		   *taskGrp	  =NULL;
 
		char*	username				=NULL;

 		EPM_decision_t decision = EPM_go;
		char obj_type[WSO_name_size_c+1];

		CALLAPI(POM_get_user_id (&username));
		printf("\n SVR Release session user:%s\n",username); fflush(stdout);

		if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0)
		{
		  CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 		  
		  CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		  printf("\nSVR Release No of attachments:%d",count);	
		  
		  if(count > 0)
		  {
				  DMLLcmTag = attachments[0];
				  status = AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name);
				  printf("\nSVR Release t5current_name:%s",t5current_name);fflush(stdout);

				  if ( status != ITK_ok)
				  {
					 EMH_ask_error_text( status, &s);
					 printf("\nSVR Release Error with AOM_ask_value_string : %s \n",s);
					 MEM_free(s);
					 return status;
				  }
				 
				  CALLAPI(POM_class_of_instance(DMLLcmTag,&class_id));
				  CALLAPI(POM_name_of_class(class_id,&class_name));
				  printf("\nSVR Release class_name of Task :%s",class_name);fflush(stdout); 
				  CALLAPI(AOM_refresh( DMLLcmTag, 0 ));
		  }		  
		  else
		  {
			  EMH_clear_errors();
			  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "SVR DML Not Found");
			  decision = EPM_nogo;
			  return decision;
		  }
		  

		  if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
		  {
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					if (tsk_dml_rel_type!=NULLTAG)
					{
						CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision));
						printf("\nSVR Release DML Revision from Task : %d",count);fflush(stdout);			
							
						for (j=0;j<count ;j++ )
						{	
							CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
							printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\nSVR Release DML - Not latest\n");fflush(stdout);
							}else
							{	
								DMLRevTag = DMLRevision[j];
/*
								CALLAPI(AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname));
								printf("\nSVR Release DML Projectname: %s\n",projectname);fflush(stdout);
								
 								CALLAPI(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
								printf("\nSVR Release DML current_name:%s\n",current_name);fflush(stdout);

								DMLNumber = strtok( current_name, "_" );
								taskGrp	  = strtok ( NULL, "_" );
								printf("\nSVR Release DML taskGrp:%s",taskGrp); fflush(stdout); 
*/
								CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
								CALLAPI(POM_name_of_class(class_id1,&class_name1));
								printf("\nSVR Release DML class_name:%s",class_name1);
								
								CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\nSVR Release DMLtype:%s",DMLtype);fflush(stdout);

								if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
								{
																
									if(strcmp(DMLtype,"SVR")==0)
									{								
										CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &relation_type));
										if (relation_type!=NULLTAG)
										{				
												CALLAPI(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects));
												printf("\nSVR Release DML No of DI : %d",n_attchs);fflush(stdout);
												if(n_attchs>0)
												{
													for (l=0;l<n_attchs ;l++ )
													{										 
														 CALLAPI(AOM_ask_value_string(secondary_objects[l],"object_type",&object_type));
														 printf("\nSVR Release DML object_type:%s",object_type);fflush(stdout);											 
														 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
														 {
																CALLAPI(AOM_ask_value_tags(secondary_objects[l],"CMReferences",&partcnt,&PartsTag));
																printf("\nSVR Release DML svrcnt:%d",partcnt);fflush(stdout); 
																if (partcnt>0)
																{ 
																	int tt= 0;
																	tag_t*    list_status=NULLTAG;
																	

																	for (tt=0;tt<partcnt;tt++ )
																	{
																		CALLAPI(AOM_ask_value_string(PartsTag[tt],"object_type",&object_type));
																		 if(strcmp(object_type,"VariantRule")==0)
																		 {
																			 int scnt =0,pp=0,iswip=0;
																		     printf("\nSVR Release DML Target SVR Found:%d\n",tt);fflush(stdout); 
																			 CALLAPI(WSOM_ask_release_status_list(PartsTag[tt],&scnt,&list_status)); 
																			 if(scnt>0)
																			 {
																					for (pp=0;pp<scnt;pp++ )
																					{
																						char*	  WSO_Name	 = NULL;
																						CALLAPI(AOM_ask_name(list_status[pp],&WSO_Name));
																						printf("\nSVR status check:%s\n",WSO_Name);fflush(stdout);																						
																						if(strcmp(WSO_Name,"ERC Released")==0 || strcmp(WSO_Name,"T5_LcsErcRlzd")==0)
																						{
																							iswip =0;
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "SVR is already released");
																							decision = EPM_nogo;
																							return decision;																					
																						}
																						if(strcmp(WSO_Name,"ERC Review")==0)
																						{
																							iswip =1;																					
																						}

																					}
																			  }
//																			  if(iswip !=1)
//																			  {
//																					EMH_clear_errors();
//																					EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Only WIP SVR can be attached to the Task of SVR Release DML.");
//																					decision = EPM_nogo;
//																					return decision;	
//																			  }



																		 }
																		 else
																		 {
																			EMH_clear_errors();
																			EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Only SVR can be attached to the Task of SVR Release DML . Please remove objects other than SVR.");
																			decision = EPM_nogo;
																			return decision;																 
																		 }

																	}

																}
																else
																{
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "There is no SVR attached to the Task. Please attach SVR to task which you want to release with this dml or remove empty task.");
																	decision = EPM_nogo;
																	return decision;
																}
														 }
														 else
														 {
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Error. Object type other than task is attached to DML.");
																	decision = EPM_nogo;
																	return decision;
														 
														 
														 }
														
													}
												}
										} 
								  }
								  else
								  {
									  EMH_clear_errors();
									  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "ERC-DML should be of type SVR Release");
									  decision = EPM_nogo;
								  }
						  
						//}
							  }else
							  {
								  EMH_clear_errors();
								  EMH_store_error_s1(EMH_severity_error,ITK_SVR_err, "Select valid ERC DML");
								  decision = EPM_nogo;
								  return decision;
							  }
				   }
				}
			}
		}
	}
	  decision = EPM_go;
 
	  if(DMLRevision)
				MEM_free(DMLRevision);		
	  
	  if(attachments)
				MEM_free(attachments);


	  if(secondary_objects)
				MEM_free(secondary_objects);

	  return decision;
	  
}


extern EPM_decision_t DLLAPI svr_chk_dmlactive(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	

	tag_t *attachments = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\ninside svr_chk_dmlactive\n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nSVR DML CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR DML No of attachments:%d",count);	

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
		CALLAPI(AOM_ask_value_string(DMLLcmTag,"current_name",&t5current_name));
		printf("\nSVR DML name:%s",t5current_name);fflush(stdout); 

		CALLAPI(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
		printf("\nSVR DML No of Parents:%d\n",n_parents); fflush(stdout);

		CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
 
	}  
		
	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML already submitted in Lifecycle");
		decision = EPM_nogo;		
	}else
	{
		decision = EPM_go;
	}	
		
	return decision;
}



int svr_stamp_status( EPM_action_message_t msg )
{	
		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l	,cnt	=0;
	
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
		tag_t			*objTypeTagTask			= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
		tag_t DMLTag = NULLTAG;
		tag_t svrTag = NULLTAG;
		tag_t PrtTag = NULLTAG;
		tag_t *Dml_tasks= NULLTAG;
		tag_t *PartsTag= NULLTAG;
		tag_t attach = NULLTAG;
		tag_t   release_status =NULLTAG;  
 		tag_t    	    propEff_tag				    =NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;
		int  attype = 1,partcnt=0,k=0;
		
		char*			parent_name				=NULL; 
		char*			object_type				=NULL;	
		char*			Analyst_name			=NULL;	
		char*			DmlAnalyst_name			=NULL;	
		
		char*			task_no					=NULL;	
		char*			CurrentTask				=NULL;	
		char*			TaskName				=NULL;	
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
		char*			svr_name					=NULL;
		char*			ReleaseStatus					=NULL;
		char*			value					=NULL;
		char			*eff_date         = NULL;
		char *FrmDate;
		char *ItemID;
		char cNextDate[20]={0};
		char cCurrentAccessDate[20]={0};
		date_t test_date_1;
		date_t cCurrent_date_1;
	    date_t DayTommorow ;
	    date_t test_date_2;
	    date_t *start_end_date = NULL;
	    //date_t *CLdate = NULL;
	    tag_t eff_d = NULLTAG;
		logical  retain_released_date =TRUE;
		logical stat  ;

		tag_t UpdateRlease_t1			= NULLTAG;
		tag_t UpdateRlease_t2			= NULLTAG;
		tag_t UpdateRlease_t3			= NULLTAG;

 		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
 
 
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);	 
 		
		if(strcmp(parent_name,"SVR Release Workflow")==0)
		{
  			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0)
			{
			    DMLTag = attachments[0];			    	
			}
			CALLAPI(AOM_lock(DMLTag));
			CALLAPI(AOM_set_value_string(DMLTag,"CMClosure","Closed"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMMaturity","Complete"));
			CALLAPI(AOM_set_value_string(DMLTag,"CMDisposition","Approved"));
			
			if(ITK_ok != (ifail = AOM_save(DMLTag)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

			UpdateRlease_t1 = svr_update_rel_status(DMLTag);
			if (UpdateRlease_t1)
			{
				printf("\n Status Updated NULL on SVR DML Revision Object\n");fflush(stdout);
			}else 
			printf("\n SVR UpdateRlease_t1 not found! ! !");  fflush(stdout);
			
			CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
			CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

			if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
			{
				CALLAPI(EPM_add_release_status(release_status,1,&DMLTag,retain_released_date));
			}
			if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
			{
				return ifail;
			}

		    CALLAPI(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&cnt,&Dml_tasks));
			printf("\n Now cnt:%d\n",cnt);fflush(stdout);

			if (cnt>0)
			{
				for (i=0;i<cnt ;i++ )
				{
					   AOM_ask_value_string(Dml_tasks[i],"object_type",&object_type);
					   printf("\n object_type is :%s\n",object_type);fflush(stdout);

					   if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
					   {
							getCurrentDateTime(cCurrentAccessDate);
							//AOM_set_value_date

							CALLAPI(AOM_lock(Dml_tasks[i]));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosure","Closed"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMMaturity","Complete"));
							CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMDisposition","Approved"));
							//CALLAPI(AOM_set_value_string(Dml_tasks[i],"CMClosureDate",cCurrentAccessDate));
							
							if(ITK_ok != (ifail = AOM_save(Dml_tasks[i])))
							{
								return ifail;
							}

							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							}

							UpdateRlease_t2 = svr_update_rel_status(Dml_tasks[i]);
							if (UpdateRlease_t2)
							{
								printf("\nSVR: Status Updated on DML Task\n");fflush(stdout);
							}else 
							printf("\nSVR: release status not found! ! !");  fflush(stdout);
							
							CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
							CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

							if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
							{
								CALLAPI(EPM_add_release_status(release_status,1,&Dml_tasks[i],retain_released_date));
							}
							if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[i], 0 )))
							{
								return ifail;
							} 
 
						    CALLAPI(AOM_ask_value_tags(Dml_tasks[i],"CMReferences",&partcnt,&PartsTag));
						    printf("\nSVR Cnt:%d\n",partcnt);fflush(stdout);

						   if (partcnt>0)
						   {
							 for (k=0;k<partcnt ;k++ )
							 {							
							 
								svrTag=PartsTag[k];

								CALLAPI(AOM_ask_value_string(svrTag,"object_name",&svr_name));	
								printf("\nSVR Name:%s\n",svr_name);	fflush(stdout);	

								UpdateRlease_t3 = svr_update_rel_status(svrTag);
								if (UpdateRlease_t3)
								{
									printf("\nSVR - Release Status Object returned after svr_update_rel_status\n");fflush(stdout);
								}else 
								printf("\n SVR - Release Status Object Not Found\n");  fflush(stdout);
								
								CALLAPI(CR_create_release_status("T5_LcsErcRlzd",&release_status));
								CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

								if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
								{
									CALLAPI(EPM_add_release_status(release_status,1,&svrTag,retain_released_date));
								}
								
		 						printf("\nSVR Release Status Created: %s\n",ReleaseStatus);fflush(stdout);
								 
								if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
								{
									if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;  
									printf("\n svr stat:%d\n",stat);

									if(stat != true)
									{
										printf("\nSVR  stat is not true .....\n");
									}
									else
									{
										printf("\nSVR  stat is  true .....\n");
									}
									
									getCurrentDateTime(cCurrentAccessDate);
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\nSVR  effectivity_text is value : %s\n",value);
										
									getNextDate(cNextDate);
									printf("\nSVR  cNextDate:%s",cNextDate);
									//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;											
									
									if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))									
									{
										return ifail;
									}
									start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2); 
									start_end_date[0] = test_date_1;
									start_end_date[1] = test_date_2;
									
									if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(eff_d)))
									{
										return ifail;
									}

									if(ITK_ok != (ifail = AOM_save(release_status)))
									{
										return ifail;
									}
									if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
									{
										return ifail;
									}
										
									if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
									if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail; 
									printf("\nSVR  After setting effectivity_text value : %s\n",value);
									if(ITK_ok != (ifail = AOM_refresh( svrTag, 0 )))
									{
										return ifail;
									}
										
								}
								else
								{
									printf("\nSVR  No status and Effectivity stamping\n ");
								}

								 
							  }
								
							}
						
						}
							
					 }

			 }
			   
	  }
	  else
	  {
		printf("\nSVR  inside else loop \n");fflush(stdout);
	  }
	
		return ITK_ok;
}
;


int GenerateRepSvrImpact (tag_t DmlTag )
{
    int     status=0; 
	char *SVR = NULL;
	char *svr_name = NULL;
 	int ifail =0;
	int n_modes=0;
	char **mode_names = NULL;

	
	char*			mod_name_SVR				=NULL;  
	char*			mod_name_VC				=NULL;  
	char*			SVRname				=NULL;  
	char*			FileDown				=NULL;  
	tag_t			bom_window				=NULLTAG;
	tag_t			bom_window_VC				=NULLTAG;
	tag_t			bom_window_SVR				=NULLTAG;
	tag_t			top_line_VC				=NULLTAG; 
	tag_t			top_line_SVR				=NULLTAG; 
	tag_t			rule					=NULLTAG;
	tag_t			PrdConfigTag			=NULLTAG;
	tag_t			objTypeTagDi			=NULLTAG;
	tag_t			primaryTag				=NULLTAG;
	tag_t			PlatformTag				=NULLTAG;
	tag_t			PlatformTagRev				=NULLTAG;
	tag_t			SvrTag				=NULLTAG;
	//tag_t			*SvrTagS			=NULL;

	tag_t           *bom_variant_config=NULL;
	tag_t           *bomvariantlist_SVR=NULL;
	FILE	*fd;
	

	tag_t *Primary_objects1 = NULL;
	tag_t *Primary_objects2 = NULL;
	tag_t *secondary_objects1 = NULL;
	tag_t *lines_VC = NULL;
	tag_t *sub_lines_VC = NULL;
	tag_t *sub_lines_SVR = NULL;

	char   type_name3[TCTYPE_name_size_c+1];

	WSO_search_criteria_t  	criteria;
	int number_found=0,countS=0;
	tag_t *list_of_WSO_tags=NULL;
	int i=0,k=0,n_lines=0,zz=0,n_lines1=0, vcount=0,countDep=0,vcountSVR=0,SvrFolder_Size=0,sub_n_lines_VC=0,sub_n_lines_SVR=0,n_lines_SVR_Cnt=0;
	int sub_n_lines=0,sub_n_lines1=0, zt=0,countDep1=0,n_lines_VC_Cnt=0,zx=0,zy=0,flagMatch=0,K=0;
	logical modB=FALSE;
	logical modB_SVR=FALSE;

	 tag_t 	*bomvariantlist = NULLTAG;
	 tag_t 	*SvrTagS = NULLTAG;
	 tag_t 	*lines_SVR = NULLTAG;
	 tag_t 	FolderTag = NULLTAG;
	 //char* SVR_Name= NULLTAG;
	 //char* SvrName_Dup= (char *) MEM_alloc ( 100);
	 
	char	SVR_Name_Type[WSO_name_size_c+1] ;
	char	SVR_Name[WSO_name_size_c+1] ;
	char	SvrName_Dup[WSO_name_size_c+1] ;
	char*	 VcName			= NULL;
	char*	 dmlNumber			= NULL;
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t *closurerule = NULL;
	int rulefound=0;
	tag_t close_tag=NULLTAG;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char **rulename_SVR = NULL;
	char **rulevalue_SVR = NULL;

	const char *cTemp="item_id";
	const char *item_name = NULL;

	 int ReqCnt=0;
   


  
	 SVR = (char *) MEM_alloc (sizeof (char) * 128);
	 FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	
	WSOM_clear_search_criteria(&criteria);
	strcpy(criteria.name,"X4_SVR_list");
	strcpy(criteria.class_name,"Folder");
	CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
	printf("\n\n\t\t FOLDER found : %d\n",number_found);fflush(stdout);
	FolderTag=list_of_WSO_tags[0];
	//CALLAPI(CFM_find( "Latest Working", &rule));
	CALLAPI(CFM_find("ERC release and above", &rule));

	CALLAPI(PIE_find_closure_rules( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule ));
    printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
	close_tag = closurerule[0];
	printf ("closure rule found \n");fflush(stdout);
	
	}


	CALLAPI(AOM_ask_value_string(DmlTag,"item_id",&dmlNumber));
	tc_strcpy(FileDown,"/tmp/");
	tc_strcat(FileDown,dmlNumber);
	tc_strcat(FileDown,"_BomCompare.csv");


	printf("\n\n\t\t file name : %s\n",FileDown);fflush(stdout);
	//CALLAPI(FL_ask_size(FolderTag,&SvrFolder_Size));
	CALLAPI(FL_ask_references(FolderTag,FL_fsc_by_name,&SvrFolder_Size,&SvrTagS));
	printf("\n\n\t\t folder size : %d\n",SvrFolder_Size);fflush(stdout);
	if (SvrFolder_Size >0)
	{
		fd=fopen(FileDown,"w");
		if(fd==NULL)
		{
			printf("\nError in opening the file \n");fflush(stdout);
			
		}
		
		for (ReqCnt=0;ReqCnt<SvrFolder_Size;ReqCnt++)
		{
			SvrTag=SvrTagS[ReqCnt];
			CALLAPI(WSOM_ask_name(SvrTag,SVR_Name));
			CALLAPI(WSOM_ask_name(SvrTag,SvrName_Dup));
			CALLAPI(WSOM_ask_object_type(SvrTag,SVR_Name_Type));
			printf("\nDvoReqRel_Name [%s] and it Is [%s]\n",SVR_Name,SVR_Name_Type);fflush(stdout);
			if (tc_strcmp(SVR_Name_Type,"VariantRule")==0)
			{
				
				fprintf(fd,",SVR  and VC\n");
				
				VcName = tc_strtok(SVR_Name,"_");
				fprintf(fd,"%d,%s and %s \n",ReqCnt,SVR_Name,VcName);

				printf("\nVC_Name [%s]\n",VcName);fflush(stdout);
				//attrs[0] ="item_id";
				values[0] = (char *)VcName;
				
				ITK_CALL(ITEM_find_items_by_key_attributes(1,&cTemp, values, &n_tags_found, &tags_found));

				if (n_tags_found == 0)
				{
					printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", VcName);fflush(stdout);
				}
				else if (n_tags_found > 1)
				{
					printf ( "More than one items matched with id %s\n", VcName);fflush(stdout);
				}

				if (n_tags_found==1)
				{
					if (bom_window_VC)
					{
						bom_window_VC=NULLTAG;
					}
					if (top_line_VC)
					{
						top_line_VC=NULLTAG;
					}

					CALLAPI(BOM_create_window(&bom_window_VC));
					CALLAPI(BOM_set_window_config_rule( bom_window_VC, rule));	
					CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename,rulevalue ));
					CALLAPI(BOM_set_window_pack_all(bom_window_VC, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_VC, tags_found[0], NULLTAG, NULLTAG, &top_line_VC));
					printf("\n inside bom_window_SVR-----444\n"); fflush(stdout);

					CALLAPI(BOM_line_ask_all_child_lines(top_line_VC, &n_lines_VC_Cnt, &lines_VC));
					printf("\n VC expansion: %d \n", n_lines_VC_Cnt); fflush(stdout);	
					if (n_lines_VC_Cnt >0)
					{
							for (zz=0;zz<n_lines_VC_Cnt ;zz++)
							{
								//CALLAPI(AOM_ask_value_string(lines_VC[zz],"bl_line_name",&mod_name));	
								//printf("\nmod_name:%s\n",mod_name);	fflush(stdout);
								CALLAPI(BOM_line_ask_all_child_lines(lines_VC[zz], &sub_n_lines_VC, &sub_lines_VC));		
							}  
					}

				}

				
				CALLAPI(GRM_list_primary_objects_only(SvrTag,NULLTAG,&countDep,&Primary_objects1));
				printf("count found %d ",countDep);fflush(stdout);
				for (K=0;K < countDep;K++ )
				{
				PrdConfigTag=Primary_objects1[K];							
				CALLAPI(TCTYPE_ask_object_type(PrdConfigTag,&objTypeTagDi));
				CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
				printf( "\n type_name Prd config :%s ..\n",type_name3);
				if (tc_strcmp(type_name3,"Cfg0ProductItem")==0)
				{
					CALLAPI(GRM_list_primary_objects_only(PrdConfigTag,NULLTAG,&countDep1,&Primary_objects2));
					for (i=0;i < countDep1;i++ )
					{
						primaryTag=Primary_objects2[i];
						CALLAPI(TCTYPE_ask_object_type(primaryTag,&objTypeTagDi));
						CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name3));	  
						printf( "\n type_name Platform :%s ..\n",type_name3);
						if (tc_strcmp(type_name3,"T5_Platform")==0)
						{
							//CALLAPI ( ITEM_ask_latest_rev( primaryTag, &PlatformRevTag ));
							PlatformTag=Primary_objects2[i];
							CALLAPI ( ITEM_ask_latest_rev( PlatformTag, &PlatformTagRev ));
							break;
							
						}
					}
					if (PlatformTag)
					{
						break;
					}

				}
				}
				/// SVR and PLatform both found here
				
				if (PlatformTagRev && SvrTag)
				{
					
					
					CALLAPI(BOM_create_window(&bom_window_SVR));
					CALLAPI(BOM_set_window_config_rule( bom_window_SVR, rule));	
					CALLAPI(BOM_window_set_closure_rule( bom_window_VC,close_tag, 0, rulename_SVR,rulevalue_SVR ));
					CALLAPI(BOM_set_window_pack_all(bom_window_SVR, TRUE));  
					CALLAPI(BOM_set_window_top_line( bom_window_SVR, NULLTAG,PlatformTagRev , NULLTAG, &top_line_SVR));
					printf("\n inside bom_window-----444\n"); fflush(stdout);			
					BOM_window_apply_variant_configuration(bom_window_SVR,1,&SvrTag);
					CALLAPI(BOM_window_hide_unconfigured(bom_window_SVR));				
					CALLAPI(BOM_window_hide_variants(bom_window_SVR));  

					printf("\n After BOM_window_apply_variant_configuration-----444\n"); fflush(stdout);  
					BOM_window_ask_variant_rules(bom_window_SVR,&vcount,&bomvariantlist); 
					if(vcount > 0)
					{													
						printf( "\n SVR is applied:..\n");																		 
						printf("\nSVR count:%d\n",vcount);	fflush(stdout);
					}
					else
					{
						printf( "\n NO SVR applied in BOM window ..\n");
					}		
					
					CALLAPI(BOM_window_ask_is_modified(bom_window_SVR,&modB));
					if(modB)
					{
						printf( "\n modified bom window:..\n");
					}
					else
					{
						printf( "\n not modfiifed ..\n");
					}	

					
					CALLAPI(BOM_line_ask_all_child_lines(top_line_SVR, &n_lines_SVR_Cnt, &lines_SVR));
					printf("\n After applying SVR all childlines: %d \n", n_lines_SVR_Cnt); fflush(stdout);	
					if (n_lines_SVR_Cnt >0)
					{
							for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
							{
								//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
								//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
									CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
									for (zy=0;zy<sub_n_lines_SVR ;zy++)
									{
										CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
										flagMatch=0;
										//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	
										for (zt=0;zt<sub_n_lines_VC ;zt++)
										{
											
											CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
											//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
											
											if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
											{
												flagMatch=1;
												break;
											}


										}
										if (flagMatch==0)
										{
											printf("\n\t\t\t difference in BOM for SVR=========================================>>> %s\n",mod_name_SVR);	fflush(stdout);
											fprintf(fd," ,%s, Module from Solved BOM not found under the VC %s BOM \n",mod_name_SVR,VcName);
										}
										
									}  		
							}
							
							///////////// comparing VC
							printf("\n\t\t\tStarting for VC:====================>>>>>>>>>>>>\n");	fflush(stdout);
							for (zt=0;zt<sub_n_lines_VC ;zt++)
							{
											
								CALLAPI(AOM_ask_value_string(sub_lines_VC[zt],"bl_item_item_id",&mod_name_VC));	
								//printf("\n\t\t\tmod_name VC:%s\n",mod_name_VC);	fflush(stdout);
								flagMatch=0;
								for (zx=0;zx<n_lines_SVR_Cnt ;zx++)
								{
										//CALLAPI(AOM_ask_value_string(lines_SVR[zx],"bl_line_name",&mod_name_SVR));	
										//printf("\nmod_name:%s\n",mod_name_SVR);	fflush(stdout);
										CALLAPI(BOM_line_ask_all_child_lines(lines_SVR[zx], &sub_n_lines_SVR, &sub_lines_SVR));
										for (zy=0;zy<sub_n_lines_SVR ;zy++)
										{
											CALLAPI(AOM_ask_value_string(sub_lines_SVR[zy],"bl_item_item_id",&mod_name_SVR));
											
											//printf("\n\t\t\t starting to comparemod_name SVR:%s\n",mod_name_SVR);	fflush(stdout);	

												
												if (tc_strcmp(mod_name_VC,mod_name_SVR)==0)
												{
													flagMatch=1;
													break;
												}
											
										}
										if (flagMatch==1)
										{
											break;
										}
								}
								if (flagMatch==0)
								{
												fprintf(fd,", %s,Module from VC not found under the solved BOM of SVR %s \n",mod_name_VC,SvrName_Dup);
												printf("\n\t\t\t difference in BOM for VC=========================================>>> %s\n",mod_name_VC);	fflush(stdout);
												
								}
							}
					}


				} 


			}


		}
		if (fd)
		{
			fclose(fd);
		}
		tag_t dml_Ref_Rel	= NULLTAG;
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;
		tag_t dml_Ref_Rel_t	= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;

		printf("\n going for dataset\n");fflush(stdout);
		CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		CALLAPI(AE_find_datasettype2("MSExcel",&msExcelType));
		if(msExcelType == NULLTAG)
		{
			printf("\n Could not find Dataset\n");fflush(stdout);
		}
		printf("\n Dataset Creation, ");fflush(stdout);
		CALLAPI(AE_create_dataset_with_id(msExcelType,dmlNumber,"Impact Analysis report for SVR DML","","",&ExcelDataset));
		CALLAPI(AE_save_myself(ExcelDataset));
		printf(" Relation Creation, ");fflush(stdout);
		CALLAPI(GRM_create_relation(DmlTag,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
		printf(" done, ");fflush(stdout);
		CALLAPI(AOM_load(dml_Ref_Rel_t));
		printf(" load, ");fflush(stdout);
		CALLAPI(GRM_save_relation(dml_Ref_Rel_t));
		printf(" save, ");fflush(stdout);
		CALLAPI(AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t));
		printf(" lst rev, ");fflush(stdout);
		CALLAPI(AOM_refresh(ExlLatestDat_t,TRUE));
		CALLAPI(AE_import_named_ref(ExlLatestDat_t,"excel",FileDown,NULL,SS_BINARY));
		printf(" name ref, ");fflush(stdout);
		CALLAPI(AE_save_myself(ExlLatestDat_t));
		CALLAPI(AE_save_myself(ExcelDataset));
		CALLAPI(AOM_refresh (DmlTag, 0));

		remove(FileDown);
	}

	MEM_free(list_of_WSO_tags);
	//BOM_close_window(bom_window_SVR);
	//BOM_close_window(bom_window_VC);
 		 
	return ITK_ok;	
} 

int svr_impact_analysis( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;
	tag_t	DMLRevTag			=NULLTAG;
	tag_t	DMLLcmTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	tag_t	*DMLRevision		=NULL;
	int i=0,j=0,count=0,count_rev=0;
	logical is_latest;
	char *dmlNumber=NULL;
	char *dmlrelease_type=NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t tsk_dml_rel_type;
	

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nSVR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			DMLLcmTag=attachments[i];
			if(TCTYPE_ask_object_type(DMLLcmTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				
				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_rev,&DMLRevision));
					printf("\nSVR Release DML Revision from Task : %d",count);fflush(stdout);			
						
					for (j=0;j<count_rev ;j++ )
					{	
						CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
						printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\nSVR Release DML - Not latest\n");fflush(stdout);
						}else
						{	
							DMLRevTag = DMLRevision[j];

							CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber));
							CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&dmlrelease_type));
							printf("\n DML Nos is %s  release type is %s\n",dmlNumber,dmlrelease_type);fflush(stdout);
							break;
							break;
							// need to write code here
						}
					}
				}
			}
		}

		if (DMLRevTag)
		{
			printf("\n Inside DMLRevTag DML Nos is %s  release type is %s\n",dmlNumber,dmlrelease_type);fflush(stdout);
			GenerateRepSvrImpact (DMLRevTag);
			printf("\n After GenerateRepSvrImpact\n");fflush(stdout);
		}

	}
return ITK_ok;
}
;
 



extern int svr_release_register_method(int *decision, va_list args)
{
   

   int ifail=0;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 

   if( ITK_ok ==  EPM_register_rule_handler ("svr-assign-participants","SVR Release Validate Participants", (EPM_rule_handler_t) svr_chk_assigned_participants))
   {
		printf("\t\n Registered Rule  Handler svr_chk_assigned_participants\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_assigned_participants\n");fflush(stdout);
   }

  
   if( ITK_ok == EPM_register_rule_handler("svr-chk-signoff", "SVR Release Validate Signoff", svr_chk_signoff))
   {
		printf("\t\n Registered Rule Handler svr_chk_signoff\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_signoff\n");fflush(stdout);
   }  

   if(ITK_ok ==  EPM_register_rule_handler ("svr-chkdml-workflow","SVR Release Validate Active DML", (EPM_rule_handler_t) svr_chk_dmlactive))
   {
		printf("\t\n Registered Rule Handler svr_chk_dmlactive\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler svr_chk_dmlactive\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("svr_stamp_status", "", svr_stamp_status))
   {
		printf("\t\n Registered Action Handler svr_stamp_status\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler svr_stamp_status\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("svr_impact_analysis", "", svr_impact_analysis))
   {
		printf("\t\n Registered Action Handler svr_impact_analysis\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler svr_stamp_status\n");fflush(stdout);
   }

   
   return ITK_ok;
}

extern DLLAPI int svr_release_register_callbacks()
{     
	 CUSTOM_register_exit("svr_release", "USER_init_module", (CUSTOM_EXIT_ftn_t) svr_release_register_method);

     printf("\n registered function svr_release_dml\n");	fflush(stdout);

	 return ( ITK_ok );
}

