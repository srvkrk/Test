/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Anant Hingankar
*  Module               :   GM DML.
*  Code                 :   tm_ExpMulLevelForGMD.c
*  Created on			:   16/09/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		16/09/2019				Mohan Tayade		Workflow Action Handler to expand part till N level and attach eligible parts under DML create folder for Carrry over parts.
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_ExpMulLevelForGMD(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int j      =  0;
	int FirstCheckOK	=  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *POinfo3		= NULL;
	char *GMinfo3		= NULL;
	char *DMLtype		= NULL;
	char *PathInfo6		= NULL;
	char *sDml_DR		= NULL;
	char *GMDEXPcommand		= NULL;
	char *PlntToPlnt		= NULL;
	char*   ObjTyp= NULL;
	char*   sDMLtaskno= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *DMLRevision=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	tag_t   tsk_dml_rel_type		= NULLTAG;
	tag_t   DMLRevTg		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	int     countt	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	logical is_latest;
	GMDEXPcommand=(char *)MEM_alloc(600);
	printf("\n tm_ExpMulLevelForGMD Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ExpMulLevelForGMD Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Checking eligibility
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&DMlid)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLtype)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&sDml_DR)!=ITK_ok)PrintErrorStack();
				printf("\n P9:DMlid: %s DMLtype:%s PlntToPlnt:%s  sDml_DR:%s \n",DMlid,DMLtype,PlntToPlnt,sDml_DR); fflush(stdout);
				FirstCheckOK=0;
				if(tc_strcmp(DMLtype,"TODR")==0)
				{
					//Control object logic:
					if(QRY_find2("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n P13:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n P14:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "POCHCK";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n P15:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						//if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&GMinfo3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&PathInfo6)!=ITK_ok)   PrintErrorStack();
						printf("\n GMinfo3 is :[%s] PathInfo6:[%s]\n", GMinfo3,PathInfo6);fflush(stdout);
						if(strstr(GMinfo3,"GMDEXPOFF")==NULL)
						{
							if(strstr(GMinfo3,"GMDEXPUAPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UAPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
								sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/expgmdml.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(GMinfo3,"GMDEXPCVPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CVPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
								sprintf(command,"/user/cvprod/shells/DML_DCR/expgmdml.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(GMinfo3,"GMDEXPCMITEST")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CMITEST:VCMS:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(GMinfo3,"GMDEXPUADEV")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UADEV:VCMS:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/expgmdml.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else
							{
								printf("\n GMDchk:other client \n");fflush(stdout);
							}
						}
						else if(strstr(GMinfo3,"GMDEXPPATH")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n GMD EXP:pathway:DML no : %s ", DMlid);fflush(stdout);
							tc_strcpy(GMDEXPcommand,"");
							tc_strcpy(GMDEXPcommand,PathInfo6);
							tc_strcat(GMDEXPcommand," ");
							tc_strcat(GMDEXPcommand,DMlid);
							printf("\n GMD EXP::GMDEXPcommand: %s",GMDEXPcommand);fflush(stdout);
							TC_write_syslog("GMDEXPcommand = %s\n",GMDEXPcommand);
							system(GMDEXPcommand);
						}
					}
				}	
			}
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
				printf("\n TSK:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
					printf("\n TSK::DML Revision from Task for MR : %d",countt);fflush(stdout);
					for (j=0;j<countt ;j++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
						printf("\n TSK:: is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n TSK::is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTg = DMLRevision[j];
							if(AOM_ask_value_string(DMLRevTg,"item_id",&DMlid)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(DMLRevTg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(DMLRevTg,"t5_cDRstatus",&sDml_DR)!=ITK_ok)PrintErrorStack();
							printf("\n TSK::DMlid: %s DMLtype:%s PlntToPlnt:%s  sDml_DR:%s \n",DMlid,DMLtype,PlntToPlnt,sDml_DR); fflush(stdout);
							FirstCheckOK=0;
							if(tc_strcmp(DMLtype,"TODR")==0)
							{
								//Control object logic:
								if(QRY_find2("ControlObjects", &DRqryTag));
								if (DRqryTag)
								{
									printf("\n TSK::Found Query ControlObjects \n");fflush(stdout);
								}
								else
								{
									printf("\n TSK::Not Found Query ControlObjects \n");fflush(stdout);
								}

								DR_qry_values2[0] = "POCHCK";
								if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
								printf(" \n TSK::DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
								if(DR_rsltCount > 0)
								{
									//if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
									if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&GMinfo3)!=ITK_ok)   PrintErrorStack();
									if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&PathInfo6)!=ITK_ok)   PrintErrorStack();
									printf("\n TSK:GMinfo3::[%s] PathInfo6:[%s]\n", GMinfo3,PathInfo6);fflush(stdout);
									if(strstr(GMinfo3,"GMDEXPOFF")==NULL)
									{
										if(strstr(GMinfo3,"GMDEXPUAPROD")==NULL)
										{
											if(AOM_UIF_ask_value(DMLRevTg, "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
											printf("\n TSK:UAPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
											//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
											sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/expgmdml.sh %s ",DMlid);
											TC_write_syslog("Command = %s\n",command);
											system(command);
										}
										else if(strstr(GMinfo3,"GMDEXPCVPROD")==NULL)
										{
											if(AOM_UIF_ask_value(DMLRevTg, "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
											printf("\n TSK:CVPROD:VCMS:DML no : %s ", DMlid);fflush(stdout);
											//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
											sprintf(command,"/user/cvprod/shells/DML_DCR/expgmdml.sh %s ",DMlid);
											TC_write_syslog("Command = %s\n",command);
											system(command);
										}
										else if(strstr(GMinfo3,"GMDEXPCMITEST")==NULL)
										{
											if(AOM_UIF_ask_value(DMLRevTg, "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
											printf("\n TSK:CMITEST:VCMS:DML no : %s ", DMlid);fflush(stdout);
											sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",DMlid);
											TC_write_syslog("Command = %s\n",command);
											system(command);
										}
										else if(strstr(GMinfo3,"GMDEXPUADEV")==NULL)
										{
											if(AOM_UIF_ask_value(DMLRevTg, "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
											printf("\n TSK:UADEV:VCMS:DML no : %s ", DMlid);fflush(stdout);
											sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/expgmdml.sh %s ",DMlid);
											TC_write_syslog("Command = %s\n",command);
											system(command);
										}
										else
										{
											printf("\n GMDchk:other client \n");fflush(stdout);
										}
									}
									else if(strstr(GMinfo3,"GMDEXPPATH")==NULL)
									{
										if(AOM_UIF_ask_value(DMLRevTg, "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
										printf("\n TSK:UADEV:VCMS:DML no : %s ", DMlid);fflush(stdout);
										tc_strcpy(GMDEXPcommand,"");
										tc_strcpy(GMDEXPcommand,PathInfo6);
										tc_strcat(GMDEXPcommand," ");
										tc_strcat(GMDEXPcommand,DMlid);
										printf("\n GMD EXP::GMDEXPcommand: %s",GMDEXPcommand);fflush(stdout);
										TC_write_syslog("GMDEXPcommand = %s\n",GMDEXPcommand);
										system(GMDEXPcommand);
									}
									else
									{
										printf("\n GMDchk:offfff \n");fflush(stdout);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_ExpMulLevelForGMD Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ExpMulLevelForGMD Function end...");

	//return error_code;
	return 0;
}