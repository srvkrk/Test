/****************************************************************************************************
*  File	           :   std_dml_assign.c ( File name )
*  Project         :   PLM TCUA Project-STDS1.		     
*  Modification History :
*  Date			Modified By			TZ			Modification Notes
*  20/06/18		Priti Pagar			1.35		STDSI Sign off validations-1. Previous revision not released check
																		   2. Child part not released
																		   3. AMDML validations bypass
																		   4. Two revision can not be released on same day
																		   5. Next revision of part exists with DR>DR3
																		   6. PP/PM DML for part released error
*******************************************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void  getPlantDetailsAttr_Std( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if(strcmp(PlantName,"APLJ")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int std_dml_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l;
		int  attype = 1;
		int  count = 1;
		int  TaskCnt = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
	    tag_t DMLTag = NULLTAG;
	    tag_t			APLDMLRevTag		= NULLTAG;
	    tag_t*			TaskRevision		= NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;
	    tag_t	relation_type,relation	,propTag	= NULLTAG;

		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
     	tag_t			TaskRevTag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;


		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Dml_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;



		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n std_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	   printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			 if(noAttachment > 0)
			{
			   for(t=0;t<noAttachment;t++)
			   {
				   DMLTag = attachments[t];
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);
     			  if(strcmp(object_type,"T5_APLDMLRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));
					printf("\n Dml_no is :%s\n",Dml_no);	fflush(stdout);
				   if (DMLTag != NULLTAG)
				    {
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
						   for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
								TaskRevTag = TaskRevision[TaskCnt];
								CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
								printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								if(strcmp(object_type,"T5_APLTaskRevision")==0)
								{
								if(AssignSTDAnalyst(TaskRevTag));
								if(AssignSTDReviewer(TaskRevTag));
								}
							}
			        }
		       }
			 }
			}

		return ITK_ok;
}

int std_dml_claim( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_claim***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_LcsSTDWrkg");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Create EPA")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_crdesigngroup", &Proj_Code);


			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
							{
								DMLFlag = 1;
							}
						}
				}
			}

			if(DMLFlag == 0)
			{
				CALLAPI(CR_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(EPM_add_release_status(status2,1,&DMLTag,retain));
			}

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);
			if (DMLTag != NULLTAG)
			 {
					PartCnt=0;
					getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
					printf("\n PlantCS %s \n",PlantCS);
					printf("\n PlantOptCS %s \n",PlantOptCS);
					printf("\n PlantAgency %s \n",PlantIA);
					printf("\n PlantStore %s \n",PlantStore);
					printf("\n UserAgency %s \n",UserAgency);

					CALLAPI(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							PartFlag = 0;
			            	ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1));
							printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

							if(st_count1>0)
							{
								for (cnt=0;cnt< st_count1;cnt++ )
								{
									WSO_Name=NULL;
									ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
									printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
									if(tc_strcmp(WSO_Name,"")!=0)
										{
											if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
											{
												PartFlag = 1;
											}
										}
								}
							}

							if(PartFlag == 0)
							{
								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
							}
						}
					}
				}

	}if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Review the Changes")==0)
	{
   /********************** Gss 2.49 For Generating 35-36 Parts at reviewer Claim of APL Reviewer *****************/
   /********************** This need to  be implemented if required now it is moved to ERC *****************/
	}
	else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int AssignSTDAnalyst(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	logical			flgRoleFnd			= false;

	printf("\n Inside AssignSTDAnalyst \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	if(tc_strcmp(PLT_Code,"APLP")==0)
    {
	tc_strcpy(PLT_CodeS,"PUNE");
	}else
	if(tc_strcmp(PLT_Code,"APLD")==0)
	{
	tc_strcpy(PLT_CodeS,"DWD");
	}else
	if(tc_strcmp(PLT_Code,"APLC")==0)
	{
	tc_strcpy(PLT_CodeS,"CAR");
	}else
	if(tc_strcmp(PLT_Code,"APLJ")==0)
	{
	tc_strcpy(PLT_CodeS,"JSR");
	}else
	if(tc_strcmp(PLT_Code,"APLL")==0)
	{
	tc_strcpy(PLT_CodeS,"LKO");
	}else
	if(tc_strcmp(PLT_Code,"APLA")==0)
	{
	tc_strcpy(PLT_CodeS,"AHD");
	}else
	if(tc_strcmp(PLT_Code,"APLU")==0)
	{
	tc_strcpy(PLT_CodeS,"UTK");
	}else
	if(tc_strcmp(PLT_Code,"APLS")==0)
	{
	tc_strcpy(PLT_CodeS,"JDL");
	}else
	{
	tc_strcpy(PLT_CodeS,"PUNE");
	}

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,"STD"))
				{
					printf("\nMatch Found\n");
					flgRoleFnd=true;
					break;
				}
		}

		if (flgRoleFnd==true)
		{
			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
			if(num_of_members>0)
			{
				for (j=0;j<num_of_members ;j++  )
				{
					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
					CALLAPI(SA_ask_user_identifier(user_tag,userid));
					printf("\nUser ID Name :[%s]\n",userid);
					TCTYPE_find_type("Analyst", "Analyst", &participant_type);
					EPM_create_participant(member_tags[j], participant_type, &participant_tag);
					GRM_find_relation_type("HasParticipant", &relation_type);
 				    CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
					if(count == 0)
					{
					GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					printf("\n TestParticipent Assigned..DoneXXXX\n");
					}else
					{
					printf("\n Already Assigned..DoneXXXX\n");
					}
				}
			}else  //default group
			{
			APL_Plnr_Grp = NULL;
			group_tag = NULLTAG;
			num_of_roles = 0;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

			CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

			 if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
			printf("\nNo of Role found in Group are :%d\n",num_of_roles);
			flgRoleFnd=false;
			if(num_of_roles>0)
			{
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);
						if(strstr(rolename,"STD"))
						{
							printf("\nMatch Found\n");
							flgRoleFnd=true;
							break;
						}
				}

				if (flgRoleFnd==true)
				{
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							if(count == 0)
							{
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
							}
							else
							{
								printf("\n Already Assigned..DoneXXXX\n");
							}
						}
					}
				}
	        }
		}
		}
	}else //default group
	{
			APL_Plnr_Grp = NULL;
			group_tag = NULLTAG;
			num_of_roles = 0;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

			CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

			 if (group_tag != NULLTAG)
			CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
			printf("\nNo of Role found in Group are :%d\n",num_of_roles);
			flgRoleFnd=false;
			if(num_of_roles>0)
			{
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);
						if(strstr(rolename,"STD"))
						{
							printf("\nMatch Found\n");
							flgRoleFnd=true;
							break;
						}
				}

				if (flgRoleFnd==true)
				{
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							printf("\n count :[%d]\n",count);
							if(count == 0)
							{
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
							}
							else
							{
							printf("\n Already Assigned..DoneXXXX\n");
							}
						}
					}
				}
	        }
	}
	return ITK_ok;
}

int AssignSTDReviewer(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				count		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	logical			flgRoleFnd			= false;

	printf("\n Inside AssignSTDReviewer  \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	if(tc_strcmp(PLT_Code,"APLP")==0)
    {
	tc_strcpy(PLT_CodeS,"PUNE");
	}else
	if(tc_strcmp(PLT_Code,"APLD")==0)
	{
	tc_strcpy(PLT_CodeS,"DWD");
	}else
	if(tc_strcmp(PLT_Code,"APLC")==0)
	{
	tc_strcpy(PLT_CodeS,"CAR");
	}else
	if(tc_strcmp(PLT_Code,"APLJ")==0)
	{
	tc_strcpy(PLT_CodeS,"JSR");
	}else
	if(tc_strcmp(PLT_Code,"APLL")==0)
	{
	tc_strcpy(PLT_CodeS,"LKO");
	}else
	if(tc_strcmp(PLT_Code,"APLA")==0)
	{
	tc_strcpy(PLT_CodeS,"AHD");
	}else
	if(tc_strcmp(PLT_Code,"APLU")==0)
	{
	tc_strcpy(PLT_CodeS,"UTK");
	}else
	if(tc_strcmp(PLT_Code,"APLS")==0)
	{
	tc_strcpy(PLT_CodeS,"JDL");
	}else
	{
	tc_strcpy(PLT_CodeS,"PUNE");
	}

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,"STD"))
				{
					printf("\nMatch Found\n");
					flgRoleFnd=true;
					break;
				}
		}

		if (flgRoleFnd==true)
		{
			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
			if(num_of_members>0)
			{
				for (j=0;j<num_of_members ;j++  )
				{
					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
					CALLAPI(SA_ask_user_identifier(user_tag,userid));
					printf("\nUser ID Name :[%s]\n",userid);
					TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
					EPM_create_participant(member_tags[j], participant_type, &participant_tag);
					GRM_find_relation_type("HasParticipant", &relation_type);
					CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
					printf("\n count :[%d]\n",count);
					if(count == 0)
					{
					GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					printf("\n TestParticipent Assigned..DoneXXXX\n");
					}
					else
					{
					printf("\n Already Assigned..DoneXXXX\n");
					}
				}
			}else
			{
					APL_Plnr_Grp = NULL;
					group_tag = NULLTAG;
					num_of_roles = 0;
					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"STD");
					tc_strcat(APL_Plnr_Grp,"_");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);
					tc_strcat(APL_Plnr_Grp,"_");
					tc_strcat(APL_Plnr_Grp,"Default");
					printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

					CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

					 if (group_tag != NULLTAG)
					CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
					printf("\nNo of Role found in Group are :%d\n",num_of_roles);
					flgRoleFnd=false;
					if(num_of_roles>0)
					{
						for (i=0;i<num_of_roles ;i++ )
						{
								CALLAPI(SA_ask_role_name(role_tags[i],rolename));
								printf("\nRol Name :[%d][%s]\n",i,rolename);
								if(strstr(rolename,"STD"))
								{
									printf("\nMatch Found\n");
									flgRoleFnd=true;
									break;
								}
						}

						if (flgRoleFnd==true)
						{
							CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);
									TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
									GRM_find_relation_type("HasParticipant", &relation_type);
									CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
									printf("\n count :[%d]\n",count);
									if(count == 0)
									{
									GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
									GRM_save_relation(relation);
									printf("\n TestParticipent Assigned..DoneXXXX\n");
									}
									else
									{
									printf("\n Already Assigned..DoneXXXX\n");
									}
								}
							}
					}
			  }
			}
		}
	}else
	{
					APL_Plnr_Grp = NULL;
					group_tag = NULLTAG;
					num_of_roles = 0;
					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"STD");
					tc_strcat(APL_Plnr_Grp,"_");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);
					tc_strcat(APL_Plnr_Grp,"_");
					tc_strcat(APL_Plnr_Grp,"Default");
					printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

					CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

					 if (group_tag != NULLTAG)
					CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
					printf("\nNo of Role found in Group are :%d\n",num_of_roles);
					flgRoleFnd=false;
					if(num_of_roles>0)
					{
						for (i=0;i<num_of_roles ;i++ )
						{
								CALLAPI(SA_ask_role_name(role_tags[i],rolename));
								printf("\nRol Name :[%d][%s]\n",i,rolename);
								if(strstr(rolename,"STD"))
								{
									printf("\nMatch Found\n");
									flgRoleFnd=true;
									break;
								}
						}

						if (flgRoleFnd==true)
						{
							CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);
									TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
									GRM_find_relation_type("HasParticipant", &relation_type);
									CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
									printf("\n count :[%d]\n",count);
									if(count == 0)
									{
									GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
									GRM_save_relation(relation);
									printf("\n TestParticipent Assigned..DoneXXXX\n");
									}
									else
									{
									printf("\n Already Assigned..DoneXXXX\n");
									}
								}
							}
					}
			  }
	}
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer \n");

	///return 0;
}

//#######################################################################################//
//Child part validation-1. CHild part NR of parent is released from same DML or not
//						2. CHild part of parent is present in same plant EPA or not
//#######################################################################################//
int Child_std_validation(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* SetStdRelErr)
{
	int				ifail				=	ITK_ok;
	int				status				=	0;
	char*			Part_no				=	NULL;
	char*			Part_Type			=	NULL;
	char*			CItemName			=	NULL;
	char*			CItemRev			=	NULL;
	char*			CPart_no			=	NULL;
	char*			CPart_Rev			=	NULL;
	char *			ChildRelErr			=	NULL;
	char*			type_name			=	NULL;
	char*			t5CTask_name		=	NULL;
	char*			t5Task_name			=	NULL;
	char*			TaskId				=	NULL;
	char*			tsk_Plant			=	NULL;
	char*			inp_Tsk_no			=	NULL;
	char*			inp_Plant			=	NULL;
	char*			ClosureDatetsk		=	NULL;
	char*			ReleaseStatustsk	=	NULL;
	char*			CPart_IdNR			=	NULL;
	char*			CPart_RevNR			=	NULL;
	char*			NRTaskId			=	NULL;
	char*			epa_Plant			=	NULL;
	char*			ReleaseStatusepa	=	NULL;
	char*			NRRevEPASet			=	NULL;
	char*			NRRevDMLSet			=	NULL;
	char*			NrDmlID				=	NULL;


	tag_t			DesignTag			=	NULLTAG;
	tag_t			ChRDsgnTag			=	NULLTAG;
	tag_t			objTypeTag			=	NULLTAG;
	tag_t			window				=	NULLTAG;
	tag_t			rule				=	NULLTAG;
	tag_t			top_line			=	NULLTAG;
	tag_t	  		relation_type		=	NULLTAG;
	tag_t	  		relation_type_task	=	NULLTAG;
	tag_t	  		t_ChildItemRev		=	NULLTAG;
	tag_t	  		PartTskTag			=	NULLTAG;
	tag_t	  		itemTypeTag_class	=	NULLTAG;
	tag_t	  		NRParttskTag		=	NULLTAG;
	tag_t	  		NRitemTypeTag_class	=	NULLTAG;

	tag_t*			DgnChld				=	NULLTAG;
	tag_t*  		prtTasks			=	NULLTAG;
	tag_t  			prtTask				=	NULLTAG;	
	tag_t*			status_list			=	NULLTAG;
	tag_t*			status_listTask		=	NULLTAG;
	tag_t*			PartTaskTags		=	NULLTAG;
	tag_t*			NRPartTskTags		=	NULLTAG;
	tag_t*			epa_status_list		=	NULLTAG;

	int				iPrt=0,nClhd=0,iChld=0,cntTask=0,iTask=0,iSameTask=0,iChRItem=0;
	int				iChildItemTag=0;
	int st_count			=	0;
	int iStCnt				=	0;
	int chldLcsRlzd			=	0;
	int count_task			=	0;
	int cnt_tk				=	0;
	int st_tskCnt			=	0;
	int stlst				=	0;
	int TaskRlzFlg			=	0;
	int epaRlzFlg			=	0;
	int NRcount_task		=	0;
	int Precnt				=	0;
	int preEpaFlg			=	0;
	int st_epacount			=	0;
	int NRinEPA				=	0;
	int preTaskNrFlg		=	0;
	int chNrRelzFlg			=	0;

	char			type_class[TCTYPE_name_size_c+1];
	char			NRtype_class[TCTYPE_name_size_c+1];

	if (!NRRevEPASet) MEM_free(NRRevEPASet);
	NRRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevEPASet," ");

	if (!NRRevDMLSet) MEM_free(NRRevDMLSet);
	NRRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevDMLSet," ");


	printf("\n###########Inside STDSI Child part checks###################\n");fflush(stdout);

	status = AOM_ask_value_string(sTaskTag,"current_name",&t5Task_name);

	CALLAPI(AOM_ask_value_string(sTaskTag,"item_id",&inp_Tsk_no));
	printf("\n\n\t\t inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	inp_Plant=subString(inp_Tsk_no,14,strlen(inp_Tsk_no));
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);

	if (partCnt>0)
	{
		for (iPrt=0;iPrt<partCnt ;iPrt++ )
		{
			printf("\niPrt : %d",iPrt);fflush(stdout);

			DesignTag	=	partsTags[iPrt];
			//Asks an object for its type. Return tag_t as output
			if(TCTYPE_ask_object_type(DesignTag,&objTypeTag));

			//Asks a type for its name. Return String, which need to free once used.
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

			if (tc_strcmp(type_name,"Design Revision")==0)
			{
				CALLAPI(AOM_ask_value_string(DesignTag,"item_id",&Part_no));
				printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

				CALLAPI(AOM_ask_value_string(DesignTag,"t5_PartType",&Part_Type));
				printf("\n\n\t\t Part_Type  is :%s",Part_Type);	fflush(stdout);

				//Explode the BOM
				nClhd	=	0;
				CALLAPI(BOM_create_window (&window));
				CALLAPI(CFM_find( "Latest Working", &rule));
				CALLAPI(BOM_set_window_config_rule( window, rule ));
				CALLAPI(BOM_set_window_top_line(window, null_tag,DesignTag , null_tag, &top_line));
				CALLAPI(BOM_line_ask_child_lines (top_line, &nClhd, &DgnChld));

				printf("\nNo of Child Found : %d",nClhd);fflush(stdout);


				for (iChld=0;iChld<nClhd ;iChld++ )
				{				

					ITKCALL(BOM_line_unpack (DgnChld[iChld]));
					ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
					ITKCALL(BOM_line_ask_attribute_tag(DgnChld[iChld], iChildItemTag, &t_ChildItemRev));

					ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&CItemName));
					printf("\n child CItemName:%s ..............",CItemName);fflush(stdout);

					ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&CItemRev));
					printf("\n child ItemRev:%s ..............",CItemRev);fflush(stdout);

					CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
					CALLAPI(GRM_list_primary_objects_only(t_ChildItemRev,relation_type,&cntTask,&prtTasks));

					printf("\nNo of Child Task Found : %d",cntTask);fflush(stdout);
					//Check Child is attached with same Task or not.
						if (cntTask>0)
						{
							iSameTask	=	0;
							for (iTask=0;iTask<cntTask;iTask++)
							{
								prtTask	=	NULLTAG;
								prtTask	=	prtTasks[iTask];
								//current_id
								status = AOM_ask_value_string(prtTask,"current_name",&t5CTask_name);
								printf("\nName of Input task: %s",t5Task_name);fflush(stdout);
								printf("\nName of child task: %s",t5CTask_name);fflush(stdout);

								if (tc_strcmp(t5Task_name,t5CTask_name)==0)
								{
									//Parent and child are in same Task.
									iSameTask++;
									printf("\nChild Part %s and Parent Parent Part is in Same Task : %s, count : %d",CItemName,t5CTask_name,iSameTask);fflush(stdout);
									break;
								}
							}
							if (iSameTask>0)
							{
								//If Parent and child are in same task part validation will not be called.
								return ifail;
							}
						}

						if(iSameTask == 0)
						{
							//Query the All revision of the child part
							//check any one revision release from same plant or not.
							//if any revision release from same plant validation will not be call
							//else validation error will be added in string.

							const char *qry_entries[1];
							const char *qry_values[1];
							int			n_tags_found=0;
							tag_t		*itemclass	=	NULLTAG;
							tag_t		item		=	NULLTAG;


							printf("\n Child Part Number %s.....\n",CItemName);
							qry_entries[0] ="item_id";
							qry_values[0] = CItemName;

							//Find Item by its ID.
							ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
							item = itemclass[0];
							if(item != NULLTAG )
							{
								int	nCRItem			=	0;
								int	cntCldTask		=	0;
								int st_count		=	0;

								tag_t*		CRitem_revs_tag		=	NULLTAG;
								tag_t*  	ChRTask				=	NULLTAG;
								//List all item revsion
								ITKCALL(ITEM_list_all_revs(item,&nCRItem,&CRitem_revs_tag));
								printf("\n No of Child Task Found : %d",nCRItem);fflush(stdout);

								chldLcsRlzd=0;
								TaskRlzFlg=0;
								NRinEPA=0;
								for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
								{
									printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
									ChRDsgnTag=NULLTAG;
									ChRDsgnTag	=	CRitem_revs_tag[iChRItem];

									CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_id",&CPart_no));
									printf("\n\n\t\t Child Part_no  is :%s",CPart_no);	fflush(stdout);

									CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
									printf("\n\n\t\t Child Part_no  is :%s",CPart_Rev);	fflush(stdout);


									ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
									printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
									if (st_count>0)
									{
										for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsStdRlzd
										{
											char* c_st_class_name	=	NULL;
											ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
											printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
											if(tc_strcmp(c_st_class_name,"T5_LcsStdRlzd")==0)
											{
												printf("\n Revision %s of child part %s of parent %s is STDSI released",CPart_Rev,CPart_no,Part_no);fflush(stdout);
												chldLcsRlzd=1;
												break;

											}
										}
									}
									else
									{
										printf("\n%s has no status, so part is not released from any agency",CPart_no);fflush(stdout);
									}

									if(chldLcsRlzd==1)
									{
										printf("\n Child LCS is STDSI released, checking whether it is released from same plant DML");fflush(stdout);
										relation_type_task=NULLTAG;
										GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
										GRM_list_primary_objects_only(ChRDsgnTag,relation_type_task,&count_task,&PartTaskTags);
										if(count_task >0)
										{										
											for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
											{
												PartTskTag=PartTaskTags[cnt_tk];
												ITKCALL (TCTYPE_ask_object_type(PartTskTag,&itemTypeTag_class));
												ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

												printf("\t  type_class ...%s\n", type_class);
												if(tc_strcmp(type_class,"T5_APLTaskRevision")==0)
												{
													ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
													printf("\n TaskId %s.....\n",TaskId);

													tsk_Plant=subString(TaskId,14,strlen(TaskId));
													printf("\t  tsk_Plant after  ...%s\n", tsk_Plant);
													
													if(tc_strcmp(inp_Plant,tsk_Plant)==0)
													{
														ClosureDatetsk=NULL;
														ITKCALL(AOM_UIF_ask_value(PartTskTag,"date_released",&ClosureDatetsk));
														printf("\n ClosureDatetsk : %s\n",ClosureDatetsk);fflush(stdout);

														if(strlen(ClosureDatetsk)>5)
														{

															ITKCALL(WSOM_ask_release_status_list(PartTskTag,&st_tskCnt,&status_listTask));
															for (stlst = 0; stlst < st_tskCnt; stlst++)
															{
																AOM_ask_name(status_listTask[stlst], &ReleaseStatustsk);
																printf("\n ReleaseStatustsk %s \n",  ReleaseStatustsk);fflush(stdout);
																if( (tc_strcmp(ReleaseStatustsk,"T5_LcsStdRlzd")==0) )
																{
																	TaskRlzFlg=1;
																	break;
																}
															}
														}

													}
												}
											}
										}
									}
								}

								if( (chldLcsRlzd==0) && (TaskRlzFlg==0) )
								{
									chNrRelzFlg=0;
									tag_t		itemNR		=	NULLTAG;
									printf("\n No revision of child part %s of parent %s seems released from STDSI, checking for NR in EPA and its DML",CItemName,Part_no);fflush(stdout);

									for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
									{
										printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
										ChRDsgnTag=NULLTAG;
										ChRDsgnTag	=	CRitem_revs_tag[iChRItem];								

										CPart_Rev=NULL;
										CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
										printf("\n\n\t\t Child Part Rev  is :%s",CPart_Rev);	fflush(stdout);
										if(tc_strcmp(CPart_Rev,"NR")==0)
										{
											printf("\n Found NR Revision of %s",CItemName);fflush(stdout);
											itemNR=CRitem_revs_tag[iChRItem];
											break;
										}
									}
//									const char *qry_entries1[2];
//									const char *qry_values1[2];
//									int			n_tags_foundNR=0;
//									tag_t		*itemclassNR	=	NULLTAG;
//									tag_t		itemNR		=	NULLTAG;
//
//									printf("\n Child Part Number %s.....\n",CItemName);fflush(stdout);								
//
//									qry_entries1[0] ="item_id";
//									qry_values1[0] = CItemName;
//									qry_entries1[1] ="item_revision_id";
//									//qry_values1[1] = "NR";
//									qry_values1[1] = "A";
//
//									//Find Item by its ID.
//									ITEM_find_items_by_key_attributes(1, qry_entries1, qry_values1,&n_tags_foundNR, &itemclassNR);
//									itemNR = itemclass[0];
									if(itemNR != NULLTAG )
									{
										CALLAPI(AOM_ask_value_string(itemNR,"item_id",&CPart_IdNR));
										printf("\n\n\t\t  CHild Name : CPart_IdNR  is :%s",CPart_IdNR);	fflush(stdout);

										CALLAPI(AOM_ask_value_string(itemNR,"item_revision_id",&CPart_RevNR));
										printf("\n\n\t\t  CHild Rev : CPart_RevNR  is :%s",CPart_RevNR);	fflush(stdout);

										//Checking whether NR is in EPA of same plant or not//

										epaRlzFlg=0;
										relation_type_task=NULLTAG;
										GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
										GRM_list_primary_objects_only(itemNR,relation_type_task,&NRcount_task,&NRPartTskTags);
										if(NRcount_task >0)
										{							
											for (Precnt=0;Precnt<NRcount_task ;Precnt++ )
											{
												NRParttskTag=NULLTAG;
												NRitemTypeTag_class=NULLTAG;
												NRParttskTag=NRPartTskTags[Precnt];
												ITKCALL (TCTYPE_ask_object_type(NRParttskTag,&NRitemTypeTag_class));
												ITKCALL (TCTYPE_ask_name(NRitemTypeTag_class,NRtype_class));

												printf("\n  NRtype_class ...%s\n", NRtype_class);

												NRTaskId=NULL;
												ITKCALL(AOM_ask_value_string(NRParttskTag, "item_id",&NRTaskId));
												printf("\n NRTaskId %s.....\n",NRTaskId);

												if(tc_strcmp(NRtype_class,"T5_EPATaskRevision")==0)
												{
													epa_Plant=NULL;
													epa_Plant=subString(NRTaskId,22,strlen(NRTaskId));
													printf("\t  epa_Plant after  ...%s\n", epa_Plant);

													if(tc_strcmp(inp_Plant,epa_Plant)==0)
													{
														ITKCALL(WSOM_ask_release_status_list(NRParttskTag,&st_epacount,&epa_status_list));
														for (stlst = 0; stlst < st_epacount; stlst++)
														{
															printf("\n stlst:%d",stlst);fflush(stdout);

															ReleaseStatusepa=NULL;
															AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
															printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
															if( (tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")!=0) && (stlst==(st_epacount-1)) )
															{
																NRinEPA=1;
																if(preEpaFlg==0)
																{
																	 tc_strcat(NRRevEPASet,"\n Following child parts are under STDSI working EPA. Please release the child part by finalizing EPA \n");																	 
																	 preEpaFlg=1;
																}
																 tc_strcat(NRRevEPASet,"\n");
																 tc_strcat(NRRevEPASet,"NR Revision of part ");																 
																 tc_strcat(NRRevEPASet,CPart_IdNR);
																 tc_strcat(NRRevEPASet," of parent ");
																 tc_strcat(NRRevEPASet,Part_no);
																 tc_strcat(NRRevEPASet," is contained in EPA Task ");
																 tc_strcat(NRRevEPASet,NRTaskId);																 
																 break;
															}
														}														
														
													}
												}
											}

											if(NRinEPA==0)
											{
												for (Precnt=0;Precnt<NRcount_task ;Precnt++ )
												{
													NRParttskTag=NULLTAG;
													NRitemTypeTag_class=NULLTAG;
													NRParttskTag=NRPartTskTags[Precnt];
													ITKCALL (TCTYPE_ask_object_type(NRParttskTag,&NRitemTypeTag_class));
													ITKCALL (TCTYPE_ask_name(NRitemTypeTag_class,NRtype_class));

													printf("\n  NRtype_class ...%s\n", NRtype_class);

													NRTaskId=NULL;
													ITKCALL(AOM_ask_value_string(NRParttskTag, "item_id",&NRTaskId));
													printf("\n NRTaskId %s.....\n",NRTaskId);

													if(tc_strcmp(NRtype_class,"T5_APLTaskRevision")==0)
													{
														epa_Plant=NULL;
														epa_Plant=subString(NRTaskId,14,strlen(NRTaskId));
														printf("\t  epa_Plant after  ...%s\n", epa_Plant);

														NrDmlID=subString(NRTaskId,0,10);

														if(tc_strcmp(inp_Plant,epa_Plant)==0)
														{
															ClosureDatetsk=NULL;
															ITKCALL(AOM_UIF_ask_value(NRParttskTag,"date_released",&ClosureDatetsk));
															printf("\n ClosureDatetsk : %s\n",ClosureDatetsk);fflush(stdout);

															if(strlen(ClosureDatetsk)>0)
															{
																st_epacount=0;
																epa_status_list=NULLTAG;
																ITKCALL(WSOM_ask_release_status_list(NRParttskTag,&st_epacount,&epa_status_list));
																printf("\n no. of status:%d",st_epacount);fflush(stdout);

																for (stlst = 0; stlst < st_epacount; stlst++)
																{
																	printf("\n stlst:%d",stlst);fflush(stdout);

																	ReleaseStatusepa=NULL;
																	AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
																	printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);

																	if( (tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")==0))
																	{
																		chNrRelzFlg=1;
																	}
//																	if( (tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")!=0) && (stlst==(st_epacount-1)) )
//																	{																		
//																		if(preTaskNrFlg==0)
//																		{
//																			 tc_strcat(NRRevDMLSet,"\n Child Part NR of Parent is not STDSI Released From Plant DML.Please release this DML from STDS1.\n");																	 
//																			 preTaskNrFlg=1;
//																		}
//																		 tc_strcat(NRRevDMLSet,"\n");
//																		 tc_strcat(NRRevDMLSet,"NR Revision of child part ");																 
//																		 tc_strcat(NRRevDMLSet,CPart_IdNR);
//																		 tc_strcat(NRRevDMLSet," of parent ");
//																		 tc_strcat(NRRevDMLSet,Part_no);
//																		 tc_strcat(NRRevDMLSet," is contained in DML ");
//																		 tc_strcat(NRRevDMLSet,NrDmlID);
//																		 tc_strcat(NRRevDMLSet,"_");
//																		 tc_strcat(NRRevDMLSet,epa_Plant);																		 
//																		 break;
//																	}
																}	
															}														
															
														}
													}
												}
												if(chNrRelzFlg==0)
															{
																if(preTaskNrFlg==0)
																		{
																			 tc_strcat(NRRevDMLSet,"\n Child Part NR of Parent is not STDSI Released From Plant DML.Please release the child part from STDS1.\n");																	 
																			 preTaskNrFlg=1;
																		}
																		 tc_strcat(NRRevDMLSet,"\n");
																		 tc_strcat(NRRevDMLSet,"NR Revision of child part ");																 
																		 tc_strcat(NRRevDMLSet,CPart_IdNR);
																		 tc_strcat(NRRevDMLSet," of parent ");
																		 tc_strcat(NRRevDMLSet,Part_no);
																		 tc_strcat(NRRevDMLSet," is not STDSI Released from plant");																 
//																		 
															}
											}

										}


									}



									
								}//chldLcsRlzd=0
							}
						}
					//printf("\n ChildRelEr22r: %s\n",SetStdRelErr);fflush(stdout);
				}
			}
		}

		printf("\n NRRevDMLSet:%s",NRRevDMLSet);fflush(stdout);
		printf("\n NRRevEPASet:%s",NRRevEPASet);fflush(stdout);
		if(strlen(NRRevDMLSet)>10)
						{
							tc_strcat(SetStdRelErr,NRRevDMLSet);	
							cntFlag = 1;
						}
						if(strlen(NRRevEPASet)>10)
						{
							tc_strcat(SetStdRelErr,NRRevEPASet);	
							cntFlag = 1;
						}
	}

	return 0;

}
//#######################################################################################//
//This validation will ensure that the two revision of parts can not be released on same day
//#######################################################################################//
int STD_Two_Rev_Same_Day_Checks_P(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
{
			int				j			=	0;
			int				task_len	=	0;
			int				kTask		=	0;
			int				count		=	0;
			int				Pre_count	=	0;
			int				k			=	0;

			

			char*			Part_no				= NULL;	        
			char			*inp_Plant			= NULL;
			char			*task_Plant			= NULL;
			char*			current_name		= NULL;
			char*			ClosureDate			= NULL;
			char*			ClosureDateDup		= NULL;
			char*			DmlId				= NULL;
			char			pAccessDate[20];
			char			cCurrentAccessDate[20]={0};
       		char *			pAccessDateDup 		= NULL;
			char *			twoRevRlzErr1		= NULL;
			char  			rev_id1[ITEM_id_size_c+1];
			char			type_name_ref[TCTYPE_name_size_c+1];

		    tag_t			*DMLRevision		= NULLTAG;	    
			tag_t			objTypeRefTag		= NULLTAG;			
			tag_t			tsk_dml_rel_type	= NULLTAG;
        	tag_t			relation_type		= NULLTAG;
        	tag_t			relation_type2		= NULLTAG;
        	tag_t			AssyPreTag			= NULLTAG;
			tag_t			DMLRevTag			= NULLTAG;	        
			tag_t*			PartDmlTags			= NULLTAG;
			tag_t*			PartPreTags			= NULLTAG;
			tag_t			PartDmlTag			= NULLTAG;
			tag_t			AssyTag				= NULLTAG;
			logical			is_latest;     
		  
	      

		// Start for two rev. on same day check
		if (tc_strcmp(twoRevRlzErr1,"NULL")==0) MEM_free(twoRevRlzErr1);
		twoRevRlzErr1=(char *)MEM_alloc(100);
		tc_strcpy(twoRevRlzErr1,"");

		printf("\n ##############Inside two revision released on same day check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);//task

				for (k=0;k<PartCnt ;k++ )
				{
					const char *attrs[1];
					const char *values[1];
					int n_tags_found=0;
	                int				count1				= 0;
	                int				BypassNACSFlag				= 0;

					printf("\n\n\t\t for k_same rev =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];
					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					//Logic for getting previous revision//
					GRM_find_relation_type("IMAN_based_on",&relation_type2);
					GRM_list_secondary_objects_only(AssyTag,relation_type2,&Pre_count,&PartPreTags);
					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					if(Pre_count>0)
					{

					AssyPreTag=PartPreTags[0];
					///////////////////////////////////////			
					
						ITEM_ask_rev_id 	( AssyPreTag, rev_id1);

						printf("\n rev_id1 is  ---->%s\n", rev_id1);fflush(stdout);//diplay the previous revision					


						GRM_find_relation_type("CMHasSolutionItem",&relation_type);
						GRM_list_primary_objects_only(AssyPreTag,relation_type,&count,&PartDmlTags);

						printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
						if(count >0)
						{
					   for (kTask=0;kTask<count ;kTask++ )
					   {
						PartDmlTag=PartDmlTags[kTask];//task pointer
						printf("\n\n\t\t INSIDE: ");fflush(stdout);



							ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
							ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
							printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);

							  if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
								{
									ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
									if (tsk_dml_rel_type!=NULLTAG)
									 {

										ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count1,&DMLRevision));
										printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml

										for (j=0;j<count1 ;j++ )
										{
											ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
											printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

											if(is_latest != true)
											{
												printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
											}else
											{
												ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
												printf("\n DmlId %s.....\n",DmlId);//previous revision's task
												DMLRevTag = DMLRevision[j];//DML
												ITKCALL(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
												printf("\n\n\t\t dml is :%s\n",current_name);fflush(stdout);
												task_len=0;
												task_len=strlen(DmlId);
												task_Plant=subString(DmlId,14,task_len);
												printf("\n task_Plant is : %s\n",task_Plant);fflush(stdout);

												if(tc_strcmp(inp_Plant,task_Plant)==0)
												{
													printf("\n inside plant check is :\n");fflush(stdout);

													ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
													printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

													ClosureDateDup = subString(ClosureDate,0,11);
													printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
													getCurrentDateTime(cCurrentAccessDate);
													printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
													pAccessDateDup = subString(cCurrentAccessDate,0,11);
													printf("\n  todays date is: %s\n",pAccessDateDup);
													
													if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
													{
														tc_strcat(twoRevRlzErr1,"\n Two revision of part ");
														tc_strcat(twoRevRlzErr1,Part_no);
														tc_strcat(twoRevRlzErr1," cannot be released on same day.");
														printf("\n IsPPPPMRlzErr: %s\n",twoRevRlzErr1);fflush(stdout);												
													  }
												}

											}

									}
								  }

							  }


				  }
				}
				}
				else
					{
					printf("\n Previous revision does not exist for part %s",Part_no);fflush(stdout);
					}
			
				} 
				if(strlen(twoRevRlzErr1)>10)
				{
					tc_strcat(SetStdRelErr,twoRevRlzErr1);
					cntFlag=1;
				}

	return 0;
}
//###############################################################################################//
//##Check will not allow the Sign-off of a DML if Next Official Revision of  Parts exist with DR Status > DR3 so user has to Release Latest Revision only##//
//###############################################################################################//

int Next_Rev_Gt_DR3_Exists_Check(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				control_number_found= 0;
	int				cntCntrl			= 0;
	int				iCntl				= 0;
	int				status				= 0;

	char			*inp_Plant			= NULL;
	char			*tsk_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*TaskId				= NULL;
	char			*Revision			= NULL;
	char			*Temp				= NULL;
	char			*attchdPart			= NULL;
	char			*SubSyscd			= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartTskTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			itemTypeTag_Dml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartTaskTags		= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags= NULLTAG;

	WSO_search_criteria_t  	criteria_Gcontrol;

	logical			is_latest_dml;

				printf("\n ############Inside Next_Rev_Gt_DR3_Exists_Check : Next revision DML with STDSI Check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				//########Validation made control object based as in TCE#####//
				WSOM_clear_search_criteria(&criteria_Gcontrol);
				strcpy(criteria_Gcontrol.name,"NxtRevDrChk");
				strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
				status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
				printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
				if (control_number_found>0)
				{
					cntCntrl	=	0;
					for (iCntl=0;iCntl<control_number_found;iCntl++ )
					{
						AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
						printf("\n\nSubSyscd : %s",SubSyscd);fflush(stdout);
						if ((tc_strcmp(SubSyscd,"Live")==0))
						{
							cntCntrl++;
							MEM_free(list_of_WSO_cntrl_tags);
							break;
						}
					}
				}

				printf("\n cntCntrl:%d",cntCntrl);fflush(stdout);

				if(cntCntrl>0)
				{
					printf("\n Check to be executed as control object found");fflush(stdout);

				//###########################################################//

				if((tc_strstr(itemid,"PP")!=NULL || tc_strstr(itemid,"PM")!=NULL  || tc_strstr(itemid,"JP")!=NULL  || tc_strstr(itemid,"JM")!=NULL  || tc_strstr(itemid,"LP")!=NULL  || tc_strstr(itemid,"LM")!=NULL))
				{
					for (k=0;k<PartCnt ;k++ )
					{				

						printf("\n\n\t\t for k =:%d",k);fflush(stdout);
						AssyTag=PartTags[k];

						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

						if (AOM_ask_value_string(AssyTag,"current_revision_id",&Desc_obj_Inp_Part)==ITK_ok)
						printf("\n Desc_obj_Inp_Part Value is :  %s\n",Desc_obj_Inp_Part);

						if( AOM_ask_value_string(AssyTag,"t5_PartStatus",&part_DRStatus)==ITK_ok)
						printf("\n part_DRStatus Value :  %s\n",part_DRStatus);

						if((!tc_strcmp(part_DRStatus,"DR0")) || (!tc_strcmp(part_DRStatus,"DR1")) || (!tc_strcmp(part_DRStatus,"DR2")) || (!tc_strcmp(part_DRStatus,"DR3")))
						continue;

						if( (strlen(part_DRStatus)==0) || !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5"))
						{

							if(ITEM_ask_item_of_rev ( AssyTag,&master) );
							if(ITEM_ask_latest_rev(master,&latestrev));

							if(latestrev != NULLTAG)
							{
								if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj_lt_Rev)==ITK_ok)
								printf("\n Desc_obj_lt_Rev Value is : %s\n",Desc_obj_lt_Rev);

								if (AOM_ask_value_string(latestrev,"item_revision_id",&Revision)==ITK_ok)
								printf("\n Revision Value is : %s\n",Revision);

								if(tc_strcmp(Desc_obj_Inp_Part,Desc_obj_lt_Rev)==0)
								{
									printf("Task Part object is latest ..");fflush(stdout);
								}
								else
								{
									printf("Task Part object is not latest ..");fflush(stdout);

									ITKCALL(WSOM_ask_release_status_list(latestrev,&st_count,&status_list));
									printf("\n st_count :%d is\n",st_count);fflush(stdout);

									if(st_count>0)
											{
												st_ok_Flg=0;
												for (cnt_next=0;cnt_next< st_count;cnt_next++ )
												{
													WSO_Name_next_Rev=NULL;
													ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
													printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													if ((tc_strcmp(WSO_Name_next_Rev,"T5_LcsAplRlzd")==0)||(tc_strcmp(WSO_Name_next_Rev,"T5_LcsSTDWrkg")==0) || (tc_strcmp(WSO_Name_next_Rev,"T5_LcsStdRlzd")==0))
													{
														st_ok_Flg=1;
													}

												}
												if(st_ok_Flg==1)
												{
													GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
													GRM_list_primary_objects_only(latestrev,relation_type_task,&count_task,&PartTaskTags);
													if(count_task >0)
													{
														NextRevFlagDml=0;
														for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
														{
															PartTskTag=PartTaskTags[cnt_tk];
															ITKCALL (TCTYPE_ask_object_type(PartTskTag,&itemTypeTag_class));
															ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

															printf("\t  type_class ...%s\n", type_class);
															if(tc_strcmp(type_class,"T5_APLTaskRevision")==0)
															{
																ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
																printf("\n TaskId %s.....\n",TaskId);

																if(tc_strstr(TaskId,"APL")==NULL) continue;
																if(tc_strstr(TaskId,"_PR")!=NULL) continue;

																tsk_Plant=subString(TaskId,14,strlen(TaskId));
																printf("\t  tsk_Plant after  ...%s\n", tsk_Plant);
																
																if(tc_strcmp(inp_Plant,tsk_Plant)==0)
																{
																	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type_1));
																	if (tsk_dml_rel_type_1!=NULLTAG)
																	{
																		ITKCALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type_1,&count_dml_1,&DMLRevision_Prt));
																		printf("\n\n\t\t DML Revision from Task : %d",count_dml_1);fflush(stdout);

																		for (j=0;j<count_dml_1 ;j++ )
																		{
																			ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision_Prt[j],&is_latest_dml));
																			printf("\n\n\t\t is_latest_dml : %d\n",is_latest_dml);fflush(stdout);

																			if(is_latest_dml != true)
																			{
																				printf("\n\n\t\t is_latest_dml is not true .....\n");fflush(stdout);
																			}else
																			{
																				DMLRevTag_Prt = DMLRevision_Prt[j];

																				ITKCALL (TCTYPE_ask_object_type(DMLRevTag_Prt,&itemTypeTag_Dml));
																				ITKCALL (TCTYPE_ask_name(itemTypeTag_Dml,type_dml));

																				if(tc_strcmp(type_dml,"T5_APLDMLRevision")==0)
																				{
																					ITKCALL(WSOM_ask_release_status_list(DMLRevTag_Prt,&st_count_dml,&dml_status_list));
																					for (dmlstlst = 0; dmlstlst < st_count_dml; dmlstlst++)
																					{
																						AOM_ask_name(dml_status_list[dmlstlst], &ReleaseStatusDML);
																						printf("\n ReleaseStatusDML %s \n",  ReleaseStatusDML);fflush(stdout);
																						if(tc_strcmp(ReleaseStatusDML,"T5_LcsStdRlzd")==0)
																						{
																							NextRevFlagDml=1;
																							break;
																						}
																					}																						
																				}
																			}
																		}
																	}
																}
															}
														}
													}

														if(NextRevFlagDml==0)
														{			

															attchdPart=NULL;
															attchdPart=(char *)MEM_alloc(1000);

															Temp=NULL;
															Temp=(char *)MEM_alloc(1000);												
															
															tc_strcpy(Temp,"\nNext Official Revision ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp,",");
															tc_strcat(Temp,Revision);
															tc_strcat(Temp,",DR Status-");
															tc_strcat(Temp,part_DRStatus);
															tc_strcat(Temp," of part ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp," exists with DR status > DR3. So, please release latest revision only.");															
															tc_strcpy(attchdPart,Temp);

															printf("%s",attchdPart); fflush(stdout);

															tc_strcat(SetStdRelErr,attchdPart);	
															cntFlag = 1;

														}

												}//st_ok_flg end
											}
								}
							}
							else
							{
								printf("\n No next revision of part");fflush(stdout);
							}
						}
						else
						{
							printf("\n Part DR status:%s",part_DRStatus);fflush(stdout);
						}
					}
				}
				}
				else
				{
					printf("\n Control object not found for check execution");fflush(stdout);
				}

			

			return 0;

}
//##############################################################################################################################################//
//This validation will ensure the release of previous revisions of part in DML
//1. Previous revision of part is released from same plant DML
//2. Previous revision of part is contained in same plant DML
//3. Previous revision of part is contanied in same plant SMDML-Rework point-Logic to carry forward previous revision changes into current revision
//###############################################################################################################################################//

int Prev_Rev_Checks(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				Pre_count			= 0;
	int				Precnt				= 0;
	int				precount_task		= 0;
	int				preEpaFlg			= 0;
	int				stlst				= 0;
	int				st_epacount			= 0;
	int				epaRlzFlg			= 0;
	int				smRlzFlg			= 0;
	int				prevRevinEPA		= 0;
	int				precount_task1		= 0;
	int				tskRlzFlg			= 0;
	int				st_prt				= 0;
	int				prtRlzFlg			= 0;
	int				count1				= 0;
	int				st_dmlCnt			= 0;
	int				dmlRlzFlg			= 0;
	int				FlagPrevPartRlzd	= 0;

	char			*inp_Plant			= NULL;
	char			*inp_PlntLstLtr		= NULL;
	char			*epa_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*Revision			= NULL;
	char			*pre_revision		= NULL;
	char			*itemidpre			= NULL;
	char			*epaTaskId			= NULL;
	char			*PreTaskId			= NULL;
	char			*PreTaskId1			= NULL;
	char			*Preepa_Plant		= NULL;
	char			*PrevRevEPASet		= NULL;
	char			*ReleaseStatusepa	= NULL;
	char			*Pretask_Plant		= NULL;
	char			*Pretask_Plant1		= NULL;
	char			*dmlId				= NULL;
	char			*ClosureDate		= NULL;
	char			*ReleaseStatuspart	= NULL;
	char			*DmlName			= NULL;
	char			*dml_Plant			= NULL;
	char			*ClosureDateDML		= NULL;
	char			*ReleaseStatusdml	= NULL;
	char			*PrevRevDMLSet		= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];
	char			Pretype_class[TCTYPE_name_size_c+1];
	char			Pretype_class1[TCTYPE_name_size_c+1];
	char			Pretype_class2[TCTYPE_name_size_c+1];

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartepaTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			AssyPreTag			= NULLTAG;
	tag_t			PreParttskTag		= NULLTAG;
	tag_t			PreitemTypeTag_class= NULLTAG;
	tag_t			PreitemTypeTag_class1= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	tag_t			PreParttskTag1		= NULLTAG;
	tag_t			tsk_dml_rel_type	= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t*			status_listDml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartEpaTags			= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			PartPreTags			= NULLTAG;
	tag_t*			PrePartTskTags		= NULLTAG;
	tag_t*			PrePartTskTags1		= NULLTAG;
	tag_t*			epa_status_list		= NULLTAG;
	tag_t*			prt_status_list		= NULLTAG;
	tag_t*			DMLRevision			= NULLTAG;

	logical			CurrentRevInEPA2;
	logical			is_latest;

	if (!PrevRevEPASet) MEM_free(PrevRevEPASet);
	PrevRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevEPASet," ");
	
	if (!PrevRevDMLSet) MEM_free(PrevRevDMLSet);
	PrevRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevDMLSet," ");

	printf("\n\n ##############Inside Previous revision checks##############");fflush(stdout);

				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				inp_PlntLstLtr=subString(itemid,17,task_len);
				printf("\t  inp_PlntLstLtr after  ...%s\n", inp_PlntLstLtr);
				

				for (k=0;k<PartCnt ;k++ )
				{					
					printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					//Finding whether current revision is in EPA or not//
					GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
					GRM_list_primary_objects_only(AssyTag,relation_type_task,&count_task,&PartEpaTags);
					if(count_task >0)
					{						
						for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
						{
							PartepaTag=PartEpaTags[cnt_tk];
							ITKCALL (TCTYPE_ask_object_type(PartepaTag,&itemTypeTag_class));
							ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

							printf("\t  type_class ...%s\n", type_class);
							if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
							{
								ITKCALL(AOM_ask_value_string(PartepaTag, "item_id",&epaTaskId));
								printf("\n epaTaskId %s.....\n",epaTaskId);

								epa_Plant=subString(epaTaskId,22,strlen(epaTaskId));
								printf("\t  epa_Plant after  ...%s\n", epa_Plant);
								
								if(tc_strcmp(inp_Plant,epa_Plant)==0)
								{
									CurrentRevInEPA2=true;
								}
							}
						}
					}
					//#################################################//
					
					GRM_find_relation_type("IMAN_based_on",&relation_type);
					GRM_list_secondary_objects_only(AssyTag,relation_type,&Pre_count,&PartPreTags);
					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					
					if(Pre_count >0)
					{
					prevRevinEPA=0;
					prtRlzFlg=0;
					dmlRlzFlg=0;
					FlagPrevPartRlzd=0;
					AssyPreTag=PartPreTags[0];
					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
					printf("\n itemidpre %s.....\n",itemidpre);

					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&pre_revision));
					printf("\n pre_revision %s.....\n",pre_revision);

					ITKCALL(AOM_ask_value_string(AssyPreTag, "t5_PartStatus",&part_DRStatus));
					printf("\n part_DRStatus %s.....\n",part_DRStatus);

					ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_prt,&prt_status_list));
					for (stlst = 0; stlst < st_prt; stlst++)
					{
						AOM_ask_name(prt_status_list[stlst], &ReleaseStatuspart);
						printf("\n ReleaseStatuspart %s \n",  ReleaseStatuspart);fflush(stdout);
						if(tc_strcmp(ReleaseStatuspart,"T5_LcsStdRlzd")==0)
						{
							prtRlzFlg=1;
						}
					}

					if(strlen(part_DRStatus)>0)
					{
						if( (tc_strcmp(part_DRStatus,"DR0")==0) || (tc_strcmp(part_DRStatus,"DR1")==0) || (tc_strcmp(part_DRStatus,"DR2")==0) || (tc_strcmp(part_DRStatus,"DR3")==0) || (tc_strcmp(part_DRStatus,"AR0")==0) || (tc_strcmp(part_DRStatus,"AR1")==0) || (tc_strcmp(part_DRStatus,"AR2")==0) || (tc_strcmp(part_DRStatus,"AR3")==0) || (tc_strcmp(part_DRStatus,"NA")==0) )
						{
							continue;
						}
					}

					if(CurrentRevInEPA2!=true)
					{
						printf("\n Current revision is not in epa of same plant, checking whether previous revision is in epa of same plant");fflush(stdout);						
						
						epaRlzFlg=0;
						PrePartTskTags=NULLTAG;
						GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
						printf("\n precount_task:%d",precount_task);fflush(stdout);
						if(precount_task >0)
						{							
							for (Precnt=0;Precnt<precount_task ;Precnt++ )
							{
								PreParttskTag=NULLTAG;
								printf("\n For count:%d",Precnt);fflush(stdout);
								PreParttskTag=PrePartTskTags[Precnt];
								PreitemTypeTag_class=NULLTAG;
								ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class));
								ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class,Pretype_class));

								printf("\n Pretype_class ...%s\n", Pretype_class);

								PreTaskId=NULL;
								ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
								printf("\n PreTaskId %s.....\n",PreTaskId);

								if(tc_strcmp(Pretype_class,"T5_EPATaskRevision")==0)
								{								

									Preepa_Plant=subString(PreTaskId,22,strlen(PreTaskId));
									printf("\t  Preepa_Plant after  ...%s\n", Preepa_Plant);

									if(tc_strcmp(inp_Plant,Preepa_Plant)==0)
									{

										ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_epacount,&epa_status_list));
										for (stlst = 0; stlst < st_epacount; stlst++)
										{
											AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
											printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
											if(tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")!=0 && (stlst==st_epacount-1) )
											{												
												prevRevinEPA=1;
												if(preEpaFlg==0)
												{
													 tc_strcat(PrevRevEPASet,"\nPlease release this EPA Task from STDS1.\n");
													 tc_strcat(PrevRevEPASet,"OR\n");
													 tc_strcat(PrevRevEPASet,"Put the current revision of part under same EPA or new EPA.");
													 preEpaFlg=1;
												}
												 tc_strcat(PrevRevEPASet,"\n");
												 tc_strcat(PrevRevEPASet,"Previous Revision (");
												 tc_strcat(PrevRevEPASet,pre_revision);
												 tc_strcat(PrevRevEPASet,") Of Part ");
												 tc_strcat(PrevRevEPASet,Part_no);
												 tc_strcat(PrevRevEPASet," is contained in EPA Task ");
												 tc_strcat(PrevRevEPASet,PreTaskId);
												 tc_strcat(PrevRevEPASet,"\n");	
											}
										}
										break;
									}									
									
								}
							}						

						}
					}

						if(CurrentRevInEPA2!=true)
						{
							printf("\n Current revision is not in epa of same plant, checking whether previous revision is in SMDML of same plant");fflush(stdout);						
							
							epaRlzFlg=0;
							PrePartTskTags=NULLTAG;
							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
							if(precount_task >0)
							{							
								for (Precnt=0;Precnt<precount_task ;Precnt++ )
								{
									PreParttskTag=NULLTAG;
									PreParttskTag=PrePartTskTags[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
									ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class2,Pretype_class2));

									printf("\t  Pretype_class2 ...%s\n", Pretype_class2);

									ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
									printf("\n PreTaskId %s.....\n",PreTaskId);


									if(tc_strcmp(Pretype_class2,"T5_APLTaskRevision")==0)
									{

										Pretask_Plant=subString(PreTaskId,17,strlen(PreTaskId));
										printf("\t  Pretask_Plant after  ...%s\n", Pretask_Plant);
										
										dmlId=subString(PreTaskId,2,2);
										printf("\n dmlId:%s",dmlId);fflush(stdout);

										if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(inp_PlntLstLtr,Pretask_Plant)==0))
										{

											ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_epacount,&epa_status_list));
											for (stlst = 0; stlst < st_epacount; stlst++)
											{
												AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
												if(tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")!=0 && (stlst==st_epacount-1))
												{
													//smRlzFlg=1;
													///break;
													printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
													//#############Logic to carry forward previous revision changes#############//



													//##########################################################################//
												}
											}
										}
									}
								}							
								
							}
						}

						if(prevRevinEPA==0)
						{
							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task1,&PrePartTskTags1);
							tskRlzFlg=0;
							if(precount_task1 >0)
							{							
								for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
								{
									PreParttskTag1=PrePartTskTags1[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
									ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));

									printf("\t  Pretype_class1 ...%s\n", Pretype_class1);

									ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
									printf("\n PreTaskId1 %s.....\n",PreTaskId1);


									if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
									{

										Pretask_Plant1=subString(PreTaskId1,17,strlen(PreTaskId1));
										printf("\t  Pretask_Plant1 after  ...%s\n", Pretask_Plant1);

										ITKCALL(AOM_UIF_ask_value(PreParttskTag1,"date_released",&ClosureDate));
										printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);

										if(tc_strcmp(Pretask_Plant1,inp_Plant)==0)
										{
											ITKCALL(WSOM_ask_release_status_list(PreParttskTag1,&st_count,&status_list));
											for (stlst = 0; stlst < st_count; stlst++)
											{
												AOM_ask_name(status_list[stlst], &ReleaseStatusepa);
												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
												if(tc_strcmp(ReleaseStatusepa,"T5_LcsStdRlzd")==0)
												{
													tskRlzFlg=1;
												}
											}
										}

										if( (tskRlzFlg==1) && (strlen(ClosureDate)>2) && (prtRlzFlg==1))
										{
											FlagPrevPartRlzd=1;
											break;
										}
										
									}
								}
							}

										//#####Check wthether DML is released or not############//
										if(precount_task1 >0)
										{	
											for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
											{
												PreParttskTag1=PrePartTskTags1[Precnt];
												ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
												ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));

												printf("\t  Pretype_class1 ...%s\n", Pretype_class1);

												ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
												printf("\n PreTaskId1 %s.....\n",PreTaskId1);


												if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
												{
													ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
													if (tsk_dml_rel_type!=NULLTAG)
													 {

														ITKCALL(GRM_list_primary_objects_only(PreParttskTag1,tsk_dml_rel_type,&count1,&DMLRevision));
														printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml

														for (j=0;j<count1 ;j++ )
														{
															ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
															printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

															if(is_latest != true)
															{
																printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
															}else
															{
																DMLRevTag = DMLRevision[j];//DML

																ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
																printf("\n DmlName %s.....\n",DmlName);//previous revision's DML																

																dml_Plant=subString(DmlName,11,strlen(DmlName));
																printf("\n dml_Plant is : %s\n",dml_Plant);fflush(stdout);

																if(tc_strcmp(inp_Plant,dml_Plant)==0)
																{
																	printf("\n inside plant check is :\n");fflush(stdout);

																	ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDateDML));
																	printf("\n ClosureDateDML : %s\n",ClosureDateDML);fflush(stdout);
																	if(strlen(ClosureDateDML)>2) 
																	{
																		ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&st_dmlCnt,&status_listDml));
																		for (stlst = 0; stlst < st_dmlCnt; stlst++)
																		{
																			AOM_ask_name(status_listDml[stlst], &ReleaseStatusdml);
																			printf("\n ReleaseStatusdml %s \n",  ReleaseStatusdml);fflush(stdout);
																			if( (tc_strcmp(ReleaseStatusdml,"T5_LcsStdRlzd")==0))
																			{
																				dmlRlzFlg=1;
																				break;
																			}
																		}
																	}
																}
															}
														}
													 }
												}
											}
										}																

										//#######################################################//
										printf("\n dmlRlzFlg:%d \t FlagPrevPartRlzd:%d",dmlRlzFlg,FlagPrevPartRlzd);fflush(stdout);

										if( (dmlRlzFlg==0) && (FlagPrevPartRlzd==0))
										{
											
											 tc_strcat(PrevRevDMLSet,"\nPrevious Revision (");
											 tc_strcat(PrevRevDMLSet,pre_revision);
											 tc_strcat(PrevRevDMLSet,") Of Part ");
											 tc_strcat(PrevRevDMLSet,Part_no);
											 tc_strcat(PrevRevDMLSet," is contained in DML ");
											 tc_strcat(PrevRevDMLSet,DmlName);
											 tc_strcat(PrevRevDMLSet," which is not released from STDSI ");									

										}
						}

						
					}
				}

				printf("\n PrevRevDMLSet:%s",PrevRevDMLSet);fflush(stdout);
				printf("\n PrevRevEPASet:%s",PrevRevEPASet);fflush(stdout);

				if(strlen(PrevRevDMLSet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevDMLSet);	
							cntFlag = 1;
						}
						if(strlen(PrevRevEPASet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevEPASet);	
							cntFlag = 1;
						}
					
					
				

			return 0;

}
//########################################################################################//
//At the time of sign off of APL AMDML, this validation will ensure whether the PP/PM DML
//for part is released or not.
//########################################################################################//

int AMDML_Std_Validation(int PartCnt,tag_t	sTaskTag, tag_t* PartTags,char* SetStdRelErr)
{

			int k = 0;
			int cnt1 = 0;
			int             st_count			= 0;
			int				n_refs				= 0;
			int				task_len			= 0;
			int				inp_len				= 0;
			int				cntErr				= 0;
			int				ifail				= ITK_ok;
			int				 *levels			= 0;
			int				n_tags_found1=0;
			int				cntSt=0;

			char			*Item_id = NULL;
			char*			ChildDml;
			char *  IsPPPPMRlzErr = NULL;
			char *  SetIsPPPPMRlzErr = NULL;
			char*			Part_no				= NULL;
			char*			inp_task_no			= NULL;
			char*			class_name=NULL;
			char			*inp_Plant			= NULL;
			char			*task_Plant			= NULL;
			char            *desid				= NULL;
			char			*dml_type			= NULL;
			char			type_name_ref[TCTYPE_name_size_c+1];
			char			**relations			= NULL;

			tag_t			item_rev_tag_p				= NULLTAG;
			tag_t			objTypeRefTag				= NULLTAG;
			tag_t			AssyTag						= NULLTAG;
			tag_t			*referencers				= NULLTAG;
			tag_t			item1						= NULLTAG;


			tag_t*    status_list;
			 tag_t	*itemclass1							= NULLTAG;

			const char *attrs[1];
		    const char *values[1];


			printf("\n Inside t5StdAMDMLValidation_Check_Func ....\n");
			cntErr = 0;

			ITKCALL(AOM_ask_value_string(sTaskTag,"item_id",&inp_task_no));
			printf("\n\n\t\t t5StdAMDMLValidation_Check_Func :inp_task_no  is :%s",inp_task_no);	fflush(stdout);

			if(strstr(inp_task_no,"AM"))
			{
				inp_len=0;
				inp_len=strlen(inp_task_no);
				if(strstr(inp_task_no,"NONERC"))
				{
					inp_Plant=subString(inp_task_no,18,inp_len);
				}
				else
				{
					inp_Plant=subString(inp_task_no,14,inp_len);
				}

			    printf("\n t5StdAMDMLValidation_Check_Func ..............");fflush(stdout);
				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n\n\t\t STD DML Cre:for k =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t STD DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

					attrs[0] ="item_id";
					values[0] = (char *)Part_no;

					ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found1, &itemclass1);
					 item1 = itemclass1[0];
					if(item1 != NULLTAG )
					ITKCALL(ITEM_ask_latest_rev(item1,&item_rev_tag_p));

					if ( (ifail = WSOM_where_referenced( item_rev_tag_p, WSO_where_ref_any_depth,&n_refs,&levels,&referencers,&relations )) != ITK_ok )
					{
						return ifail;
					}
					printf("\nTCDCn_refs  to item are:%d\n",n_refs);fflush(stdout);

					if (n_refs >0)
					{
						for (cnt1=0;cnt1<n_refs ;cnt1++ )
						{
							ITKCALL(TCTYPE_ask_object_type(referencers[cnt1],&objTypeRefTag));
							ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
							printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
							if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
							{

								if( AOM_ask_value_string(referencers[cnt1],"item_id",&desid)!=ITK_ok);
								printf("\n saveCS_method::Design Revision Item ID %s\n", desid);fflush(stdout);

								dml_type=subString(desid,2,2);
								ChildDml=subString(desid,0,10);
								printf("\ndml_type:%s",dml_type);fflush(stdout);
								printf("\n ChildDml:%s",ChildDml);fflush(stdout);

								task_len=0;
								task_len=strlen(desid);
								if(strstr(desid,"NONERC"))
								{
									task_Plant=subString(desid,18,task_len);
								}
								else
								{
									task_Plant=subString(desid,14,task_len);
								}
								printf("\n task_Plant:%s",task_Plant);fflush(stdout);
								printf("\n inp_Plant:%s",inp_Plant);fflush(stdout);

								ITKCALL(WSOM_ask_release_status_list(referencers[cnt1],&st_count,&status_list));
								printf("\n st_count:%d",st_count);fflush(stdout);

								//if (tc_strcmp(IsPPPPMRlzErr,"NULL")==0) MEM_free(IsPPPPMRlzErr);
								IsPPPPMRlzErr=NULL;
								IsPPPPMRlzErr=(char *)MEM_alloc(1000);
								tc_strcpy(IsPPPPMRlzErr," ");

								if(tc_strcmp(inp_Plant,task_Plant)==0)
											{
												if(tc_strcmp(dml_type,"PP")==0 || tc_strcmp(dml_type,"PM")==0)
												{

													if (st_count == 0)  /* No Status, so the Item is not yet Released */
													{
														printf("\n No Status, so the Item is not yet Released \n");


															tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
															tc_strcat(IsPPPPMRlzErr,ChildDml);
															tc_strcat(IsPPPPMRlzErr,"_");
															tc_strcat(IsPPPPMRlzErr,task_Plant);
															tc_strcat(IsPPPPMRlzErr," for Part ");
															tc_strcat(IsPPPPMRlzErr,Part_no);
															tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
															tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
															cntErr=cntErr+1;
															printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr);fflush(stdout);


													}else
														{

														for(cntSt=0;cntSt<st_count;cntSt++)
															{

																ITKCALL(AOM_ask_value_string(status_list[cntSt],"object_name",&class_name));
																printf("\n class_name: %s\n",class_name);fflush(stdout);


																		if( (tc_strcmp(class_name,"T5_LcsStdRlzd")!=0) && (cntSt==st_count-1) )
																		{
																				tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
																				tc_strcat(IsPPPPMRlzErr,ChildDml);
																				tc_strcat(IsPPPPMRlzErr,"_");
																				tc_strcat(IsPPPPMRlzErr,task_Plant);
																				tc_strcat(IsPPPPMRlzErr," for Part ");
																				tc_strcat(IsPPPPMRlzErr,Part_no);
																				tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
																				tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
																				cntErr=cntErr+1;
																				printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr);fflush(stdout);

																		}



															}

														}
												}
											}
//									if(cntErr==1)
//											{
//												tc_strcpy(SetStdRelErr,IsPPPPMRlzErr);
//												cntFlag = 1;
//											}
//											else
//											{
//												tc_strcat(SetStdRelErr,IsPPPPMRlzErr);
//												cntFlag = 1;
//											}

									printf("\n IsPPPPMRlzErr:%s",IsPPPPMRlzErr);fflush(stdout);
									if(strlen(IsPPPPMRlzErr)>10)
									{
									tc_strcat(SetStdRelErr,IsPPPPMRlzErr);
									cntFlag = 1;
									}

							}
						}
					}


				}
			}

	return 0;

}


int std_dml_release( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_release***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_LcsStdRlzd");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_APLDMLRevision")==0)
	{
		    printf("\n inside class T5_APLDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
        				printf("\n Item created first time only with item_id \n");fflush(stdout);
                        if (DMLTag != NULLTAG)
						 {
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							 /// Solution Item start

							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
							TaskRevTag = TaskRevision[TaskCnt];

							CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
							printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
							if(strcmp(object_type,"T5_APLTaskRevision")==0)
							{
								PartCnt=0;

								CALLAPI(CR_create_release_status(lcsToset,&status2));
      							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&TaskRevTag,retain));


								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
										{
								           CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
											if((strcmp(ReleaseStatus,"T5_LcsStdRlzd")==0) )
											{
												CALLAPI(WSOM_ask_effectivity_mode(&stat));

												getCurrentDateTime(cCurrentAccessDate);
												CALLAPI(PROP_ask_property_by_name(status2,"effectivity_text",&propEff_tag));
												CALLAPI(PROP_ask_value_string(propEff_tag,&value));

												getNextDate(cNextDate);
												printf("\n cNextDate:%s",cNextDate);

												CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
												CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

												start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

												printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

												start_end_date[0] = test_date_1;
												start_end_date[1] = test_date_2;

												CALLAPI(WSOM_status_clear_effectivities (status2));
												CALLAPI(WSOM_effectivity_create_with_dates(status2, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
												CALLAPI(AOM_save(eff_d));
												CALLAPI(AOM_save(status2));
												CALLAPI(AOM_refresh(status2,0));
											}
										}
									}
								}
							}
						  }  /// Solution Item end
					 }

	}else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int AMDML_Bypass_Checks(tag_t Task_Tag)
{
	int			count				= 0;
	int			j					= 0;

	char		*DmlName			= NULL;
	char		*DmlEcn				= NULL;
	char		*TaskName			= NULL;

	tag_t		tsk_dml_rel_type	= NULLTAG;
	tag_t		DMLRevTag			= NULLTAG;

	tag_t*		DMLRevision			= NULLTAG;

	logical		is_latest;	

	printf("\n Inside AMDML_Bypass_Checks");fflush(stdout);

	ITKCALL(AOM_ask_value_string(Task_Tag, "item_id",&TaskName));
	printf("\n TaskName %s.....\n",TaskName);

	if(tc_strstr(TaskName,"AM"))
	{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(Task_Tag,tsk_dml_rel_type,&count,&DMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);		//task to dml

			for (j=0;j<count ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = DMLRevision[j];//DML

					ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
					printf("\n DmlName %s.....\n",DmlName);

					ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_EcnType",&DmlEcn));
					printf("\n DmlEcn %s.....\n",DmlEcn);

					if(tc_strcmp(DmlEcn,"AMDML")==0)
					{
						printf("\n Bypass Validations as AMDML of type AM");fflush(stdout);
						return 1;
					}
					else
					{
						printf("\n Call all Validations as AMDML is not of type AM");fflush(stdout);
						return 0;
					}
				}
			}
		 }
	}
	else
	{
		printf("\n Given task is not of AMDML");fflush(stdout);
		return 0;
	}
        		
	           

	return 0;

}


extern EPM_decision_t DLLAPI std_dml_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];

	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
   cnt = 0;
  cntFlag = 0;


	printf("\n Calling std_dml_signoff_checks_Func %d.....\n",iNumAttch);


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


	getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
	printf("\n PlantCS %s \n",PlantCS);
	printf("\n PlantOptCS %s \n",PlantOptCS);
	printf("\n PlantAgency %s \n",PlantIA);
	printf("\n PlantStore %s \n",PlantStore);
	printf("\n UserAgency %s \n",UserAgency);

     if(tc_strcmp(CurrentTask,"Create EPA" )==0)
	{
 	ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;
		 tag_t	*itemclass							= NULLTAG;
		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			if (!SetStdRelErr) MEM_free(SetStdRelErr);
			SetStdRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetStdRelErr,"");

			if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
			{

    		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);

			//##############Bypass All the validations if AMDML of type AM###############//
			BypassAMDMLFlag = AMDML_Bypass_Checks(item_rev_tag);
			printf("\t  BypassAMDMLFlag ...%d\n", BypassAMDMLFlag);	
			
			if(BypassAMDMLFlag==1)
			{
			printf("\n Bypass all validations as AMDML of type AM");fflush(stdout);
			goto BYPASSVALIDATIONS;
			}
			else
			{
				printf("\n Call all validations as DML is not of type AM");fflush(stdout);
			}
			//############################################################################//

			if (PartCnt>0)
			{

				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				printf("\n\n\t\t for k =:%d",k);fflush(stdout);

				printf("\n cntFlag_1: %d",cntFlag);fflush(stdout);

				AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,SetStdRelErr);
		        printf("\n cntFlag_2: %d",cntFlag);fflush(stdout);

                Child_std_validation(PartCnt,item_rev_tag, PartTags,SetStdRelErr);
		        printf("\n cntFlag_3: %d",cntFlag);fflush(stdout);

				STD_Two_Rev_Same_Day_Checks_P(PartCnt,PartTags,SetStdRelErr,itemid);
                printf("\n cntFlag_4: %d",cntFlag);fflush(stdout);

				Next_Rev_Gt_DR3_Exists_Check(PartCnt,PartTags,SetStdRelErr,itemid);
                printf("\n cntFlag_5: %d",cntFlag);fflush(stdout);

				Prev_Rev_Checks(PartCnt,PartTags,SetStdRelErr,itemid);
                printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

		 } //End for Part

		   printf("\n SetStdRelErr: %s\n",SetStdRelErr);fflush(stdout);
			//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
			if(cntFlag==1)
			{
				printf("\n All Child Part is not Released  Error %s \n",SetStdRelErr);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetStdRelErr);
				//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
				//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
				decision = EPM_nogo;
				return ITK_errStore;
			}

	  }
    }
  }
 }
 BYPASSVALIDATIONS:
	decision = EPM_go;
	return decision;
}


extern int std_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("std_dml_assign", "", std_dml_assign))
   {
		printf("\t\n Registered Action Handler std_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_assign\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_rule_handler ("std_dml_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)std_dml_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }
	if( ITK_ok == EPM_register_action_handler("std_dml_claim", "", std_dml_claim))
   {
		printf("\t\n Registered Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }


   if( ITK_ok == EPM_register_action_handler("std_dml_release", "", std_dml_release))
   {
		printf("\t\n Registered Action Handler std_dml_release_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_release_register_method\n");fflush(stdout);
   }


    return ITK_ok;
}

extern DLLAPI int std_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("std_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)std_user_assign_register_method);

     printf("\n registered function std_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}
