#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h> 
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <cfm/cfm.h>










//#define ITK_CALL(x) {           \
//        int stat;                     \
//        char *err_string;             \
//        if( (stat = (x)) != ITK_ok)   \
//        {                             \
//        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
//        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
//        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
//        if(err_string) MEM_free(err_string);                                \
//        exit (EXIT_FAILURE);                                                   \
//        }                                                                    \
//}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL; 

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}



#define SAFE_TC_FREE(ptr) do { \
            if (ptr) { \
                MEM_free(ptr); \
                (ptr) = NULL; \
            } \
        } while(0)







//Nikhil code starts
static int get_plant_cs(tag_t bom_line, char *plant_filter, char **plant_cs)
{
    int ifail = ITK_ok;
    char *prop_name = NULL;
    
    if(tc_strcmp(plant_filter, "DHARWAD") == 0)
    {
        prop_name = "bl_Design Revision_t5_DwdMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "CVBU Pune") == 0)
    {
        prop_name = "bl_Design Revision_t5_PunMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "PUVBU") == 0)
    {
        prop_name = "bl_Design Revision_t5_PunUVMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "CAR") == 0)
    {
        prop_name = "bl_Design Revision_t5_CarMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "CVBU JSR") == 0)
    {
        prop_name = "bl_Design Revision_t5_JsrMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "CVBU LKO") == 0)
    {
        prop_name = "bl_Design Revision_t5_LkoMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "AHD") == 0)
    {
        prop_name = "bl_Design Revision_t5_AhdMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "CVBU PNR") == 0)
    {
        prop_name = "bl_Design Revision_t5_PnrMakeBuyIndicator";
    }
    else if(tc_strcmp(plant_filter, "TMLDL JSR") == 0)
    {
        prop_name = "bl_Design Revision_t5_JdlMakeBuyIndicator";
    }
    else
    {
        prop_name = "bl_Design Revision_t5_PunMakeBuyIndicator";
    }
    
    ITK_CALL(AOM_ask_value_string(bom_line, prop_name, plant_cs));
    
    return ifail;
}



// Global buffer to collect BOM data
static char bom_data_buffer[100000];
static int bom_data_pos = 0;

//  declaration
void add_bom_line_data(char *level, char *item_id, char *revision, 
                       char *description, char *quantity , char *parttype, char *partcat,char *desgrp, char *drstatus );
// add BOM line data to the global buffer
void add_bom_line_data(char *level, char *item_id, char *revision, 
                       char *description, char *quantity, char *parttype, char *partcat, char *desgrp, char *drstatus )
{
    // Format: Level|ItemID|Revision|Description|Quantity
    int written = snprintf(bom_data_buffer + bom_data_pos, 
                          sizeof(bom_data_buffer) - bom_data_pos,
                          "%s|%s|%s|%s|%s|%s|%s|%s|%s\n",
                          level ? level : "",
                          item_id ? item_id : "",
                          revision ? revision : "",
                          description ? description : "",
                          quantity ? quantity : "",
                          parttype ? parttype : "",
						  partcat ?  partcat : "",
					      desgrp ?   desgrp : "",
						  drstatus ?  drstatus : "");
    
    if (written > 0) {
        bom_data_pos += written;
    }
}



int traverse_bom_hierarchy(int count, tag_t *child_lines, 
                          int max_level, 
                          int skip_underscore_parts, 
                          char *plant_filter,
                          int stop_at_f,
                          int skip_zero_qty)
{
    int ifail = ITK_ok;
    int i, sub_child_count = 0;
    tag_t *sub_child_lines = NULLTAG;
    
    char *level_str = NULL;
    char *item_id = NULL;
    char *revision = NULL;
    char *quantity = NULL;
    char *plant_cs = NULL;
    char *description = NULL;
    int qty_value = 0;
    int current_level = 0;
    int should_expand = 1;
    
    char *InputPartType = NULL;
    char *child_line_Part_Category1 = NULL;
    char *child_line_DesignGrp = NULL;
    char *child_line_PartStatus = NULL;

    printf("\n=== Processing %d children ===\n", count);
    
    for(i = 0; i < count; i++)
    {
        // Reset pointers for each iteration
        sub_child_count = 0;
        sub_child_lines = NULLTAG;
        should_expand = 1;
        
        level_str = NULL;
        item_id = NULL;
        revision = NULL;
        description = NULL;
        quantity = NULL;
        InputPartType = NULL;
        child_line_Part_Category1 = NULL;
        child_line_DesignGrp = NULL;
        child_line_PartStatus = NULL;
        plant_cs = NULL;
        
        // Get BOM line properties
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_level_starting_0", &level_str));
        ITK_CALL(AOM_ask_value_string(child_lines[i], "bl_item_item_id", &item_id));
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_rev_item_revision_id", &revision));
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_rev_object_desc", &description));
        ITK_CALL(AOM_ask_value_string(child_lines[i], "bl_quantity", &quantity));

        ITK_CALL(AOM_ask_value_string(child_lines[i], "bl_Design Revision_t5_PartType", &InputPartType));
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_Design Revision_t5_SpareCriteria", &child_line_Part_Category1));
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_Design Revision_t5_DesignGrp", &child_line_DesignGrp));
        ITK_CALL(AOM_UIF_ask_value(child_lines[i], "bl_Design Revision_t5_PartStatus", &child_line_PartStatus));

        current_level = atoi(level_str);
        qty_value = atoi(quantity);
        
        printf("\nProcessing: %s, Level: %d, Qty: %d", item_id, current_level, qty_value);
        
        //  CHECK FILTERS  
        
        //  Max level check
        if(current_level >= max_level)
        {
            printf("   SKIP: Max level reached\n");
            goto cleanup_continue;
        }
        
        //  Underscore check  MUST BE BEFORE add_bom_line_data
        if(skip_underscore_parts && item_id && tc_strstr(item_id, "_") != NULL)
        {
            printf("   SKIP: Contains underscore\n");
            goto cleanup_continue;
        }
        
        //  Zero quantity check
        if(skip_zero_qty && qty_value == 0)
        {
            printf("   SKIP: Zero quantity\n");
            goto cleanup_continue;
        }
        
        // 
        add_bom_line_data(level_str, item_id, revision, description, quantity, 
                         InputPartType, child_line_Part_Category1, 
                         child_line_DesignGrp, child_line_PartStatus);
        
        printf("  ADDED to buffer\n");
        
        //  Get plant CS (Make/Buy indicator)
        ITK_CALL(get_plant_cs(child_lines[i], plant_filter, &plant_cs));
        printf("  Plant CS: %s\n", plant_cs ? plant_cs : "NULL");
        
        // "Stop at F" check
        if(stop_at_f && plant_cs && tc_strstr(plant_cs, "F") != NULL)
        {
            printf("   STOP at F: %s - no child expansion\n", plant_cs);
            should_expand = 0;
        }
        
        // Get children ONLY if we should expand 
        if(should_expand)
        {
            ITK_CALL(BOM_line_ask_all_child_lines(child_lines[i], &sub_child_count, &sub_child_lines));
            printf("  Found %d children for expansion\n", sub_child_count);
        }
        else
        {
            printf("  NOT getting children (Stop at F enabled)\n");
            sub_child_count = 0;
        }
        
        // Recursive expansion decision 
        if(should_expand && sub_child_count > 0)
        {
            printf("  Expanding %d children to next level...\n", sub_child_count);
            
            // Recursive call for next level
            ifail = traverse_bom_hierarchy(sub_child_count, sub_child_lines,
                                          max_level, skip_underscore_parts,
                                          plant_filter, stop_at_f,
                                          skip_zero_qty);
            
            if(ifail != ITK_ok) 
            {
                // Clean up on error
                goto cleanup_error;
            }
        }
        else if(sub_child_count == 0)
        {
            printf("  Leaf node  no children to expand\n");
        }
        
        
        cleanup_continue:
        SAFE_TC_FREE(level_str);
        SAFE_TC_FREE(item_id);
        SAFE_TC_FREE(revision);
        SAFE_TC_FREE(description);
        SAFE_TC_FREE(quantity);
        SAFE_TC_FREE(InputPartType);
        SAFE_TC_FREE(child_line_Part_Category1);
        SAFE_TC_FREE(child_line_DesignGrp);
        SAFE_TC_FREE(child_line_PartStatus);
        SAFE_TC_FREE(plant_cs);
        
        if(sub_child_lines)
        {
            MEM_free(sub_child_lines);
            sub_child_lines = NULLTAG;
        }
        
        continue;  // Move to next 
        
        //  ERROR CLEANUP 
        cleanup_error:
        SAFE_TC_FREE(level_str);
        SAFE_TC_FREE(item_id);
        SAFE_TC_FREE(revision);
        SAFE_TC_FREE(description);
        SAFE_TC_FREE(quantity);
        SAFE_TC_FREE(InputPartType);
        SAFE_TC_FREE(child_line_Part_Category1);
        SAFE_TC_FREE(child_line_DesignGrp);
        SAFE_TC_FREE(child_line_PartStatus);
        SAFE_TC_FREE(plant_cs);
        if(sub_child_lines) MEM_free(sub_child_lines);
        return ifail;
    }
    
    return ifail;
}



char* expand_bom_multilevel(tag_t item_rev, 
                         char *closure_rule_name,
                         char *revision_rule_name,
                         int max_level,
                         int skip_underscore_parts,
                         char *plant_filter,
                         int stop_at_f,
                         int skip_zero_qty)
{
    int ifail = ITK_ok;
    int count = 0;
    tag_t *child_lines = NULLTAG;
    tag_t window = NULLTAG;
    tag_t top_line = NULLTAG;
    tag_t rule = NULLTAG;
    tag_t *closure_rules = NULLTAG;
    tag_t close_tag = NULLTAG;
    int rule_found = 0;
    
    // Reset global buffer
    bom_data_pos = 0;
    bom_data_buffer[0] = '\0';
    
    printf("\n========== Starting BOM Expansion11111 ==========\n");
    printf("Parameters:\n");
    printf("  Max Level: %d\n", max_level);
    printf("  Skip Underscore Parts: %s\n", skip_underscore_parts ? "YES" : "NO");
    printf("  Plant Filter: %s\n", plant_filter ? plant_filter : "None");
    
    printf("  Stop at F: %s\n", stop_at_f ? "YES" : "NO");
    printf("  Skip Zero Quantity: %s\n", skip_zero_qty ? "YES" : "NO");
    printf("\n");
    // Create BOM window
    ITK_CALL(BOM_create_window(&window));
    ITK_CALL(CFM_find(revision_rule_name, &rule));
    ITK_CALL(BOM_set_window_config_rule(window, rule));
    ITK_CALL(BOM_set_window_pack_all(window, true));
    
    if(closure_rule_name && tc_strlen(closure_rule_name) > 0)
    {
        ITK_CALL(PIE_find_closure_rules2(closure_rule_name, PIE_TEAMCENTER, 
                                       &rule_found, &closure_rules));
        if(rule_found > 0)
        {
            close_tag = closure_rules[0];
            printf("Using closure rule: %s\n", closure_rule_name);
            ITK_CALL(BOM_window_set_closure_rule(window, close_tag, 0, NULL, NULL));
        }
    }
    
    // Set top line
    ITK_CALL(BOM_set_window_top_line(window, NULLTAG, item_rev, NULLTAG, &top_line));
    ITK_CALL(BOM_window_hide_unconfigured(window));
    ITK_CALL(BOM_window_hide_suppressed(window));
    
    // Get top item info
    char *top_item_id = NULL;
    char *top_revision = NULL;
    char *top_description = NULL;
    char *top_quantity = NULL;
    char *top_InputPartType = NULL;
    char *top_line_Part_Category1 = NULL;
    char *top_line_DesignGrp = NULL;
    char *top_line_PartStatus = NULL;
    char *top_level = "0";
    
    ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &top_item_id));
    ITK_CALL(AOM_UIF_ask_value(top_line, "bl_rev_item_revision_id", &top_revision));
    ITK_CALL(AOM_UIF_ask_value(top_line, "bl_rev_object_desc", &top_description));
    ITK_CALL(AOM_ask_value_string(top_line, "bl_quantity", &top_quantity));
    
    // Part Type
    ITK_CALL(AOM_ask_value_string(top_line, "bl_Design Revision_t5_PartType", &top_InputPartType));
    
    // Part Category
    ITK_CALL(AOM_UIF_ask_value(top_line, "bl_Design Revision_t5_SpareCriteria", &top_line_Part_Category1));
    
    // Design Group
    ITK_CALL(AOM_UIF_ask_value(top_line, "bl_Design Revision_t5_DesignGrp", &top_line_DesignGrp));
    
    // DR status
    ITK_CALL(AOM_UIF_ask_value(top_line, "bl_Design Revision_t5_PartStatus", &top_line_PartStatus));
    
    //  FILTER CHECK FOR TOP ITEM 
    // Check if top item should be skipped 
    int should_skip_top = 0;
    
    if(skip_underscore_parts && top_item_id && tc_strstr(top_item_id, "_") != NULL)
    {
        printf(" Top item contains underscore: %s\n", top_item_id);
        should_skip_top = 1;
    }
    
    int top_qty_value = top_quantity ? atoi(top_quantity) : 0;
    if(skip_zero_qty && top_qty_value == 0)
    {
        printf(" Top item has zero quantity\n");
        should_skip_top = 1;
    }
    
    // Add top item to data 
    if(!should_skip_top)
    {
        add_bom_line_data(top_level, top_item_id, top_revision, top_description, 
                         top_quantity, top_InputPartType, top_line_Part_Category1, 
                         top_line_DesignGrp, top_line_PartStatus);
        printf("Top Item: %s, Revision: %s (ADDED)\n", top_item_id, top_revision);
    }
    else
    {
        printf("Top Item: %s, Revision: %s (SKIPPED due to filters)\n", top_item_id, top_revision);
    }
    
    // Get all direct children
    ITK_CALL(BOM_line_ask_all_child_lines(top_line, &count, &child_lines));
    printf("\nFound %d direct children for top item\n", count);
    
    // Start recursive BOM traversal
    if(count > 0)
    {
        printf("\nBeginning recursive BOM traversal...\n");
        ifail = traverse_bom_hierarchy(count, child_lines, max_level, 
                                      skip_underscore_parts, plant_filter,
                                      stop_at_f, skip_zero_qty);
    }
    
    // Clean up
    SAFE_TC_FREE(top_item_id);
    SAFE_TC_FREE(top_revision);
    SAFE_TC_FREE(top_description);
    SAFE_TC_FREE(top_quantity);
    SAFE_TC_FREE(top_InputPartType);
    SAFE_TC_FREE(top_line_Part_Category1);
    SAFE_TC_FREE(top_line_DesignGrp);
    SAFE_TC_FREE(top_line_PartStatus);
    
    if(child_lines) MEM_free(child_lines);
    if(closure_rules) MEM_free(closure_rules);
    if(window != NULLTAG) BOM_close_window(window);
    
    printf("\n========== BOM Expansion Completed ==========\n");
    printf("Total data collected: %d bytes\n", bom_data_pos);
    
    // Return collected data
    char *result = MEM_alloc(bom_data_pos + 1);
    if(result)
    {
        strcpy(result, bom_data_buffer);
    }
    
    return result;
}

int tm_DesignCostDetailsReport_Service(void *return_data)
{
    int ifail = ITK_ok;

    char *item_id = NULL;
    char *Rev_Seq = NULL;
	char *closureRule = NULL;
	char *RevRule = NULL;
	char *plantName = NULL;
    tag_t item = NULLTAG;
    tag_t rev = NULLTAG;

	char *qry_entries[1] = {"Item ID"};
	char ** qry_values = (char ** ) MEM_alloc(10 * sizeof(char * ));
	tag_t queryTag = NULLTAG;
	int n_entries = 1;
	int resultCount = 0;
	int jj=0;
	char *revision= NULL;
	tag_t * ModuleTag = NULLTAG;
	
	char *stopAtFStr = NULL;      
    char *skipZeroQtyStr = NULL; 

    // Read arguments in registration order
    USERARG_get_string_argument(&item_id);
    USERARG_get_string_argument(&Rev_Seq);
    USERARG_get_string_argument(&closureRule);
    USERARG_get_string_argument(&RevRule);
    USERARG_get_string_argument(&plantName);
    USERARG_get_string_argument(&stopAtFStr);      
    USERARG_get_string_argument(&skipZeroQtyStr);


	printf("\n Received parameters:");
    printf("\n Item: %s", item_id);
    printf("\n Revision: %s", Rev_Seq);
    printf("\n Plant: %s", plantName);
    printf("Stop at F (string): %s\n", stopAtFStr);     
    printf("Skip Zero Qty (string): %s\n", skipZeroQtyStr);
    fflush(stdout);

	// Convert string parameters to integers
    int stopAtF = atoi(stopAtFStr);        // Convert "1" or "0" to int
    int skipZeroQty = atoi(skipZeroQtyStr); // Convert "1" or "0" to int
	
	printf("Stop at F (int): %d\n", stopAtF);
    printf("Skip Zero Qty (int): %d\n", skipZeroQty);

    // Find item
    //ifail = ITEM_find_item(item_id, &item);
    //if (ifail != ITK_ok)
    //{
    //    char **ret = (char **)return_data;
    //    *ret = MEM_string_copy("ERROR: Item not found");
    //    return ITK_ok;
    //}
	//
    //// Latest revision
    //ifail = ITEM_ask_latest_rev(item, &rev);
    //if (ifail != ITK_ok)
    //{
    //    char **ret = (char **)return_data;
    //    *ret = MEM_string_copy("ERROR: Cannot get latest revision");
    //    return ITK_ok;
    //}

	qry_values[0] = item_id;


	if (QRY_find2("Item Revision...", & queryTag));

	printf("\n Querying for :%s: \n ", item_id);

	if (QRY_execute(queryTag, n_entries, qry_entries, qry_values, & resultCount, & ModuleTag));
      printf("\n Result count :%d: \n ", resultCount);
      if (resultCount > 0) 
		  {
		for (jj = 0; jj < resultCount; jj++) 
			{
		          ITK_CALL(AOM_ask_value_string(ModuleTag[jj], "item_revision_id", & revision));
		          printf("\n Rev is :%s\n", revision); fflush(stdout);

				 if(tc_strcmp(revision,Rev_Seq)==0)
			{
					
				printf("\n Going to print Rev is :%s\n", revision); fflush(stdout);
				printf("\n Going to print Rev from front-end is :%s\n", Rev_Seq); fflush(stdout);
				 char *result = expand_bom_multilevel(ModuleTag[jj], 
                                 closureRule,  // closure rule
                                 RevRule,  // revision rule
                                 99,                       // max level (99 levels)
                                 1,                        // skip underscore parts (1=yes, 0=no)
                                 plantName,               // plant filter
                                 stopAtF,                        // stop at F (1=yes, 0=no)
                                 skipZeroQty); ;
					//test
					
					printf("expand_bom_multilevel returned: %p\n", result);
					
					if (result == NULL)
					{
					    printf("ERROR: BOM expansion returned NULL\n");
					    char **ret = (char **)return_data;
					    *ret = MEM_string_copy("ERROR: BOM expansion failed - NULL result");
					   // if (item_rev_id) MEM_free(item_rev_id);
					    return ITK_ok;
					}

					// Check if result is valid
					printf("Result length: %lu chars\n", tc_strlen(result));
					printf("First 200 chars of result:\n%.200s\n", result);
					
					// Return success result - IMPORTANT: Use the exact result, don't copy it
					char **ret = (char **)return_data;
					*ret = result;  // Return the actual pointer
					
					printf("Service completed successfully\n");
					printf("Nikhil Service completed successfully\n");
			}
			
			
		}
		}

    

	

    return ITK_ok;
}




extern int AllUserServiceFnDesigncostRptFtn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	
    if (ifail != ITK_ok) return ifail;

    

	int nargs3 = 7;	
	int inputArgTypes3[7] = {0};
   //int inputArgTypes3[1] = { USERARG_STRING_TYPE };
   int retValueType3 = USERARG_STRING_TYPE;

	inputArgTypes3[0] = USERARG_STRING_TYPE; // Item_id
	inputArgTypes3[1] = USERARG_STRING_TYPE; // revision/Sequence
	inputArgTypes3[2] = USERARG_STRING_TYPE; // closure
	inputArgTypes3[3] = USERARG_STRING_TYPE; // rev
	inputArgTypes3[4] = USERARG_STRING_TYPE; // Plant name
	inputArgTypes3[5] = USERARG_STRING_TYPE; // Stop at F
	inputArgTypes3[6] = USERARG_STRING_TYPE; // Skip Zero Qty
	
	printf("\n Registering tm_DesignCostDetailReport service method...");	fflush(stdout);

    ifail = USERSERVICE_register_method("tm_DesignCostDetailsReport_Service", (USER_function_t)tm_DesignCostDetailsReport_Service, nargs3, inputArgTypes3, retValueType3);

	return ifail;
}

extern "C" DLLAPI int tm_DesignCostDetailReport_register_callbacks()
{

	int ifail = ITK_ok;
	printf("\n Before registoring userservice....tm_DesignCostDetailReport");
	fflush(stdout);
	ifail = CUSTOM_register_exit("tm_DesignCostDetailReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnDesigncostRptFtn);
	printf("\n After registoring userservice....tm_DesignCostDetailReport");
	fflush(stdout);
	return (ITK_ok);
}