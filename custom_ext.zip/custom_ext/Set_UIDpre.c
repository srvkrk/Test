/********************************************************************************************************
*  File			: Set_UIDpre.c
*  Created By	: Abhilash
*  Created On	: 08-Jan-2019
*  Project		: TCUA 	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"
extern DLLAPI int Set_UIDpre(METHOD_message_t *msg, va_list args)
{
	int ifail				= ITK_ok;

	tag_t  primary_object			= va_arg(args, tag_t);
	
	tag_t  objTypeTag				= NULLTAG;
	
	char   *OccUIDflag				= NULL;
	char   *ErrorText				= NULL;

	char* type_name= NULL;

	printf("\n Set_UIDpre Function started...");fflush(stdout);
	TC_write_syslog("\n Set_UIDpre Function started...");

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n Set_OccUID type_name -------->  : %s\n", type_name);fflush(stdout);
	if(tc_strcmp(type_name,"T5_ModuleVF_to_Change")==0) 
	{
		ifail = AOM_UIF_ask_value(primary_object,"t5_Occcurance_Flag",&OccUIDflag);
		printf("\n Set_OccUID OccUIDflag--------> :%s\n",OccUIDflag);fflush(stdout);

		if(tc_strcmp(OccUIDflag,"True")==0)
		{
			printf("\n\t OccUIDflag TRUE Changing to False \n"); fflush(stdout);
			ifail = AOM_lock( primary_object );
			ifail = AOM_UIF_set_value(primary_object,"t5_Occcurance_Flag","False");
			
			
			  if(ifail != ITK_ok)
               {
                ITK_CALL(AOM_unlock(primary_object));
               EMH_ask_error_text(ifail,&ErrorText);
               }
               else
               {
               ITK_CALL(AOM_save_without_extensions(primary_object));
               ITK_CALL(AOM_refresh(primary_object,0));
               ITK_CALL(AOM_unlock(primary_object));
               }
			
		}
		else 
		{
			printf("\n\t Bypassssssss in Set_UID_details_Preactions \n"); fflush(stdout);
		}
	}
	printf("\n Set_UIDpre Function end...");fflush(stdout);
	TC_write_syslog("\n Set_UIDpre Function end...");
//return ifail;
return 0;
}
