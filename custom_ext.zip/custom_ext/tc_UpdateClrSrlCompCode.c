/*
./tc_UpdateClrSrlCompCode -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*/

#include <stdio.h>
#include <string.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <cfm/cfm.h>

#define PROP_ask_value_strings_msg   "PROP_ask_value_strings"
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define SAFE_SM_FREE(a) do                          \
{                           \
    if ( (a) != NULL )      \
    {                       \
        MEM_free( (a) );    \
        (a) = NULL;         \
    }                       \
}                           \
while ( 0 )                                                

int		ifail			=   ITK_ok;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

    }
	return return_code;
}


//Driver Code
extern int ITK_user_main (int argc, char ** argv )
{
	

	int     value_entries     =   1;
	int  	n_TskCnt		  =	  0;
	int     i, j, t              =   0;
	int		iCounter;
	int     n_items           =   0;
	int     status            =   0;
	char	*sUserName		  =   NULL;
	char	*sPassword		  =   NULL;
	char	*sgrp		      =   NULL;
	char	*clr_srl		  =   NULL;
	char	**values		  =   NULL;
	char    *entries[1]	      =   {"Color Serial"};
	char	*item_id		  =	  NULL;
	char	*dup_item_id	  =	  NULL;
	char    *sitem_id		  =   NULL;
	char    *sitem_rev_id	  =   NULL;
	char    *citem_id		  =   NULL;
	char    *citem_rev_id	  =   NULL;
	char    *dr_status	      =   NULL;
	char    *child_dr_status  =   NULL;
	char    *release_status   =   NULL;
	char	*p_child_item_id  =   NULL;
	char	*c_owning_user    =   NULL;
	char	*c_project_code   =   NULL;
	char    *release_status_dml   =   NULL;
	char	*Tasknum		  =   NULL;
	
	
	tag_t   LatestRevision;
	tag_t   p_child_item_revision;
	tag_t   *items            =   NULL;
	tag_t   ItemQuery         =   NULLTAG;
	tag_t   tag_item          =   NULLTAG;
	tag_t   item_tag          =   NULLTAG;
	tag_t   p_child_item_tag  =   NULLTAG;
	tag_t   c_owning_user_tag  =   NULLTAG;
	tag_t   relation_Soln     =   NULLTAG;
	tag_t   *TskObjSO		  =   NULLTAG;

	// ITK_auto_login
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	//Take input from user
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	sgrp	  = ITK_ask_cli_argument("-g=");
	status = ITK_CALL(ITK_init_module(sUserName, sPassword, sgrp));


	

	if (status == 0)
	{
		printf("\n Login succesfully \n");
		values = (char **) MEM_alloc(value_entries * sizeof(char *));
		ITK_CALL(QRY_find("ColorSchemeDataRevision", &ItemQuery));
		if (ItemQuery)
		{
			printf("\n Found Query : ColorSchemeDataRevision \n"); fflush(stdout);
			clr_srl = (char *)MEM_alloc(50);
			tc_strcpy(clr_srl, "*O7*GRTBK_ART_LR*");
			values[0] = (char *)MEM_alloc( strlen( clr_srl ) + 1);
			tc_strcpy(values[0], clr_srl );

			ITK_CALL(QRY_execute(ItemQuery, value_entries, entries, values, &n_items, &items));
			printf("\nTotal no. of Parts Found : [%d]\n\n",n_items); fflush(stdout);
			
		}
	}
	else
	{
		printf("\n Unable to Login \n");
	}
	printf("\n\t ***************** End of MAIN FUNCTION ********************* \n");
	return ITK_ok;
}
