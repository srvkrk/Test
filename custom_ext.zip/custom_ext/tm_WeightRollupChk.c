
#include "TMLLibrary_server_exits.h"

#define Rollup_err 919002

EPM_decision_t tm_WeightRollupChk(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	tag_t *taskAttachments=NULLTAG;
	char	*PlntToPlnt		=  NULL;
	char	*TskNm			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*Partno		=  NULL;
	char	*Toplnt		=  NULL;
	char	*sDMLDR		=  NULL;
	char	*PartMstr_no		=  NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=  NULL;
	int	rel_status_cunt	=  0;
	int	ii	=  0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	CMRefcount	= 0;
	int	Tskcnt	= 0;
	int	Xpartcount	= 0;

	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *BomComInfo1 =NULL;
	char   *Prtrel_status =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;

	char   *PartTyp =NULL;
	char   *BomComInfo2 =NULL;
	char   *BOMComp =NULL;
	char   *DMLProj =NULL;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	int     BOMCompFlag      =  0;
	int     iBOMComp      =  0;
	int     iBomComInfo2      =  0;
	int     RelRevFlag      =  0;
	char DRStrng[20];
	int	chkBOMComFlag	= 0;
	tag_t *ClsObjTag= NULLTAG;
	tag_t *XPartTags= NULLTAG;
	tag_t   *ccvMstrTag      = NULLTAG;
	tag_t   part_tsk_rel_typ      = NULLTAG;
	tag_t   master     = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	int     Conut_Mst      =  0;
	int     cnt_ccvcls      =  0;
	int     WeightFlag      =  0;
	int     Xp      =  0;
	int     revcount =  0;
	double     iUnladenWeight      =  0;
	double     iWeightRollup      =  0;
	double     iTrgBOMComp      =  0;
	double     idegreesWt      =  0;
	double     iWtDiff      =  0;
	char	*sUnladenWeightt		=  NULL;
	char	*sdegreesWttDup		=  NULL;
	char	*sdegreesWtt		=  NULL;
	char	*parttype		=  NULL;
	char	*sPrtColInd		=  NULL;
	char	*BomComInfo3		=  NULL;
	char	*BomComInfo4		=  NULL;
	char	*BomComInfo5		=  NULL;
	char	*BomComInfo7		=  NULL;
	char	*BomComInfo6		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char	*sWeightRollup		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*AttrVal		=  NULL;
	char	*partid		    =  NULL;
	char	*ErorStrg		=  NULL;
	char	*sdegreesWttDupp		=  NULL;
	char	*eptr		=  NULL;
	char	*sUnladenWeight		=  NULL;
	char	*taskid		        =  NULL;
	//new attri
	tag_t DMLRevTg         = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t Xpartcount1      = NULLTAG;
	tag_t item             = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	int j =0;
	int countt =0;
	logical is_latest;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	tag_t   DMLtsk_tag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char*	CurrentTask				=NULL;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLDR =(char *) MEM_alloc(20 * sizeof(char *));
	ErorStrg =(char *) MEM_alloc(200 * sizeof(char *));
	sUnladenWeightt =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWttDup =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWtt =(char *) MEM_alloc(200 * sizeof(char *));
	
	printf("\n tm_WeightRollupChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_WeightRollupChk Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n Wt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Wt::Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Wt::Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "ROLLUP";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Wt::DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&BomComInfo1)!=ITK_ok)   PrintErrorStack();
				//percentage
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&BomComInfo2)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt:A:BomComInfo2: %s \n",BomComInfo2);fflush(stdout);
				iTrgBOMComp=atof(BomComInfo2);
				printf("\n Wt::iTrgBOMComp:%f \n",iTrgBOMComp);fflush(stdout);
				//iTrgBOMComp = strtod(BomComInfo2, &eptr);
				//printf("\n Wt::AAAAAAAAAAAAAAAAAA:%lf \n",iTrgBOMComp);fflush(stdout);
				//FROM TO values for GMD
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&BomComInfo3)!=ITK_ok)   PrintErrorStack();
				//DML DR-status and DML types.:,Veh,TODR,DR3,AR3,DR3P,DR4,AR3P,AR4,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&BomComInfo4)!=ITK_ok)   PrintErrorStack();
				//Part Type
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&BomComInfo5)!=ITK_ok)   PrintErrorStack();
				//DR2 weight check:DR-status veh DML and FROMTO DR-status for GMD
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&BomComInfo6)!=ITK_ok)   PrintErrorStack();
				//for veh DML only: ,Veh,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&BomComInfo7)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt::BomComInfo1 is  = [%s] BomComInfo2:%s\n BomComInfo3:[%s] \n BomComInfo4:[%s] \n BomComInfo5:[%s]\n iTrgBOMComp:[%f]", BomComInfo1,BomComInfo2,BomComInfo3,BomComInfo4,BomComInfo5,iTrgBOMComp);fflush(stdout);
				printf("\n Wt:A:BomComInfo6:[%s] BomComInfo7:[%s] \n",BomComInfo6,BomComInfo7);fflush(stdout);
			}
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				printf("\n Wt::This is for veh DML submission.\n");fflush(stdout);
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
				printf("\n Wt:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
					printf("\n Wt:DML Revision from Task for MR : %d",countt);fflush(stdout);
					for (j=0;j<countt ;j++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
						printf("\n Wt: is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n Wt:is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTg = DMLRevision[j];
							if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
							printf("\n Wt:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);
							
							if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
							if(item_tag==NULLTAG)
							{
								printf("\n Wt::item_tag is NULL.\n");fflush(stdout);
								return decision;
							}
							else
							{
								printf("\n Wt::item_tag found.\n");fflush(stdout);
								if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
								if(DMLTag==NULLTAG)
								{
									printf("\n Wt::Object not found in Teamcenter...!!\n");fflush(stdout);
									return decision;
								}
								else
								{
									//DML Details:
									if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
									printf("\n Wt:: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
									tc_strcpy(sDMLrlstype,"");
									tc_strcpy(sDMLrlstype,",");
									tc_strcat(sDMLrlstype,DMLtype);
									tc_strcat(sDMLrlstype,",");
									printf("\n Wt:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
									tc_strcpy(sDMLDR,"");
									tc_strcpy(sDMLDR,",");
									tc_strcat(sDMLDR,DMLDR);
									tc_strcat(sDMLDR,",");
									printf("\n Wt::sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
									//for Veh DML only
									if(tc_strstr(BomComInfo7,sDMLrlstype) != NULL)
									{
										if(tc_strstr(BomComInfo1,sDMLno) != NULL)
										{
											printf("\n Wt:DML has been bypassed. \n");fflush(stdout);
										}
										else
										{
											if(tc_strstr(BomComInfo1,"BOM01") == NULL)
											{
												if(tc_strstr(BomComInfo4,sDMLrlstype) != NULL)
												{
													if(tc_strcmp(DMLtype,"TODR")==0)
													{
														printf("\n Wt:Inside Gate Maturation DML..................");fflush(stdout);
														if(PlntToPlnt != NULL)
														{
															if((tc_strstr(BomComInfo3,PlntToPlnt) != NULL)||(tc_strstr(BomComInfo6,PlntToPlnt) != NULL))
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n Wt::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	for (j=0;j<countt ;j++)
																	{
																		DMLtsk_tag=Dml_tasks[j];

																		ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid));
																		printf("\n taskid = %s \n",taskid);fflush(stdout);


																		ITK_CALL(AOM_ask_value_tags(DMLtsk_tag,"CMReferences",&Xpartcount,&XPartTags)); //Change References
																		printf("\n inside1 ---------------> : \n",DMLtype); fflush(stdout);
																		printf("\n 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);

																		printf("\n inside for loop");fflush(stdout);
																			
																		for(Xp=0;Xp<Xpartcount;Xp++)
																		{
																			Xpartcount1=XPartTags[Xp];

																			ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
																			printf("\n partid = %s \n",partid);fflush(stdout);

																			//ITK_CALL(ITEM_find(Xpartcount1,&revcount,&rev_list));
																			//ITK_CALL(ITEM_find_revisions(Xpartcount1,NULL,&revcount,&rev_list));
																			ITK_CALL(ITEM_ask_item_of_rev(XPartTags[Xp],&item));

																			ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));


																			ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
																			printf("\n partid = %s \n",partid);fflush(stdout);

																			ITK_CALL(AOM_UIF_ask_value(XPartTags[Xp],"t5_PartType",&parttype));
																			printf("\n parttype = %s \n",parttype);fflush(stdout);


																			if((tc_strcmp(parttype,"V") == 0) || (tc_strcmp(parttype,"Vehicle") == 0))
																			{
																				if(AOM_UIF_ask_value(XPartTags[Xp],"t5_RolledupWt",&sWeightRollup));
																				printf("\n Wt:sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																				
																				if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																				{
																					//NULL case
																					printf("\n Wt:sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s1(EMH_severity_error,Rollup_err,"Part not having RolledUp Weight value updated. \nPlease get it updated, then you can sign off this DML.");	
																					decision = EPM_nogo;
																					return decision;
																				}
																				else
																				{
																					printf("\n Wt:sWeightRollup is not NULL");fflush(stdout);
																					//decision = EPM_go;
																					//return decision;
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													else
													{
														printf("\n Wt::Inside vehicle DML..................");fflush(stdout);
														if(DMLDR != NULL)
														{
															if((tc_strstr(BomComInfo4,sDMLDR) != NULL) ||(tc_strstr(BomComInfo6,sDMLDR) != NULL))
															{
																Tskcnt=0;
																if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																printf("\n Wt::no of tasks:%d\n",Tskcnt);fflush(stdout);
																if (Tskcnt>0)
																{
																	
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Wt::Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n Wt:: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

																			if (tc_strcmp(TaskDsgGrp,"00")==0)
																			{
																				ITK_CALL(AOM_ask_value_tags(Dml_tasks[tsk],"CMHasSolutionItem",&Xpartcount,&XPartTags)); //Change References
																				printf("\n inside1 ---------------> : \n",DMLtype); fflush(stdout);
																				printf("\n 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);

																				printf("\n inside for loop");fflush(stdout);
																					
																				for(Xp=0;Xp<Xpartcount;Xp++)
																				{
																					Xpartcount1=XPartTags[Xp];

																					ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
																					printf("\n partid = %s \n",partid);fflush(stdout);

																					//ITK_CALL(ITEM_find(Xpartcount1,&revcount,&rev_list));
																					//ITK_CALL(ITEM_find_revisions(Xpartcount1,NULL,&revcount,&rev_list));
																					ITK_CALL(ITEM_ask_item_of_rev(XPartTags[Xp],&item));

																					ITK_CALL(ITEM_list_all_revs(item,&revcount,&rev_list));


																					ITK_CALL(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid));
																					printf("\n partid = %s \n",partid);fflush(stdout);

																					ITK_CALL(AOM_UIF_ask_value(XPartTags[Xp],"t5_PartType",&parttype));
																					printf("\n parttype = %s \n",parttype);fflush(stdout);

																					
																					if(tc_strstr(BomComInfo5,parttype) != NULL)
																					{
																						if(AOM_UIF_ask_value(XPartTags[Xp], "t5_RolledupWt", &sWeightRollup)!=ITK_ok)PrintErrorStack();
																						printf("\n Wt:sWeightRollup:[%s] and ", sWeightRollup);fflush(stdout);
																						
																						if((sWeightRollup==NULL) ||(tc_strcmp(sWeightRollup,"")==0))
																						{
																							//NULL case
																							printf("\n Wt:sWeightRollup NULL, FAILED for GM DML.");fflush(stdout);
																							EMH_clear_errors();
																							EMH_store_error_s1(EMH_severity_error,Rollup_err,"Part not having RolledUp Weight value updated. \nPlease get it updated, then you can sign off this DML.");	
																							decision = EPM_nogo;
																							return decision;
																						}
																						else
																						{
																							printf("\n Wt:sWeightRollup is not NULL");fflush(stdout);
																							//decision = EPM_go;
																							//return decision;
																						}
																					}
																				}
																				break;
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_WeightRollupChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_WeightRollupChk Function end...");
    return decision;
}

