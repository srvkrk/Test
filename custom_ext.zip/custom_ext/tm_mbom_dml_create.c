/************************************************************************************************************************************************
*  File            		:  tm_mbom_dml_create.c
*  Created By      		:  Nilesh Kumar
*  Created On      		:  01-Apr-2023
*  Project        		:  MBOM DML
*  Purpose         		:  MBOM DML to be created for applicable ERC flown DML via WORKFLOW

*  Naming Convention 	:  nnAAnnnnnn_MBOM

*  Modification History :  1 - Copying of design group from ERC flown DML to MBOM DML				//	Nilesh Kumar
						   2 - Updating MBOM release type based on ERC DML release type				//  Nilesh Kumar
						   3 - MBOM DML description from ERC flown DML - Dynamic					//  Nilesh Kumar
						   4 - t5_rlstype - attribute value copy from ERC DML TO MBOM DML			//  Nilesh Kumar
						   5 - Added Design Group Creation list based on ERC TASK List by strrchr - which gives characters after token character.	20-06-2025		//	Nilesh Kumar
************************************************************************************************************************************************/


// #include <epm/epm.h>
// #include <tccore/aom_prop.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <tccore/custom.h>
// #include <ict/ict_userservice.h>
// #define ITK_errStore1 (EMH_USER_error_base + 5)

#include "tm_apl_std_common_function.c"

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

//sachinD GM auto clearence

void setAddStrFuction11(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStrFuction %d",*count);fflush(stdout);
	printf("\n\n\t\t Updated Function007..*");
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrFuction ErrorString===%s",(*strset)[*count-1]);fflush(stdout);

}


//sachinD GM auto clearence

int GMAutoclearence(EPM_action_message_t msg )
{
	int   			ifail					= 0;
	int	  noAttachment=0,t=0;
	tag_t	relation_type						= NULLTAG;
	int count=0;

	int TaskCnt=0;
	int k=0;
	int c=0;
	char	*partCs								= NULL;
	int		autoclearflag=0;
    int		relztypefnd=0;
	char	*object_type						= NULL;
	char	*obj_type_part						= NULL;
	char*			username				=NULL;
	char*			parent_name				=NULL;
	char*			CurrentTask				=NULL;
	char*			releasetyp				=NULL;
	char*			DRstatus				=NULL;
	int taskcount = 0;
	tag_t *PartTags			= NULLTAG;
	int PartCnt = 0;
	tag_t *DmlTasksTags			= NULLTAG;
	tag_t			PartTag				=NULLTAG;
	char*			PartNum				=NULL;
	char*			Parttyp				=NULL;
	tag_t			*attachments			=NULLTAG;

	tag_t			rootTask				=NULLTAG;
	tag_t ERCDMLTag = NULLTAG;

	printf("\n Inside GMAutoclearence check ...");
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		for(t=0;t<noAttachment;t++)
		{
			ERCDMLTag=NULLTAG;
			ERCDMLTag = attachments[t];
			ITKCALL(AOM_ask_value_string(ERCDMLTag,"object_type",&object_type));
			printf("\n object_type is :%s\n",object_type);fflush(stdout);		
			
			ITKCALL(AOM_ask_value_string(ERCDMLTag,"t5_rlstype",&releasetyp));
			printf("\n releasetyp is :%s\n",releasetyp);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string(ERCDMLTag,"t5_cDRstatus",&DRstatus));
			printf("\n DRstatus is :%s\n",DRstatus);fflush(stdout);			
				
				if (strcmp(object_type, "ChangeRequestRevision") == 0)
				{
					if (strcmp(releasetyp, "TODR") == 0)
					{
						relztypefnd++;
						if (tc_strcmp(DRstatus,"DR3")==0 || tc_strcmp(DRstatus,"DR3P")==0 || tc_strcmp(DRstatus,"DR4")==0 || tc_strcmp(DRstatus,"DR5")==0)
						{	
							CALLAPI(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
							printf("\n DML Task Count : %d\n",taskcount);fflush(stdout);
							if (taskcount>0)
							{
								for ( c=0; c<taskcount ;c++ )
								{	
                                    PartTags= NULLTAG;							
								    CALLAPI(AOM_ask_value_tags(DmlTasksTags[c], "CMReferences", &PartCnt, &PartTags));
								    printf("\n task PartCnt:%d", PartCnt);fflush(stdout);
										
										if (PartCnt > 0)
										{											
											for (k = 0; k < PartCnt; k++)
											{
												PartTag = NULLTAG;
												PartTag = PartTags[k];

												ITKCALL(AOM_ask_value_string(PartTag,"object_type",&obj_type_part));
			                                    printf("\n obj_type_part is :%s\n",obj_type_part);fflush(stdout);

												if(tc_strcmp(obj_type_part, "Design Revision") == 0)
												{

                                                ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
												printf("\n PartNum is :%s\n",PartNum);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(PartTag,"t5_PartType",&Parttyp));
												printf("\n Parttyp is :%s\n",Parttyp);fflush(stdout);
												
												if((tc_strcmp(Parttyp,"V")==0) || (tc_strcmp(Parttyp,"VC")==0) || (tc_strcmp(Parttyp,"VCCR")==0))
												{													
													autoclearflag++;
													break;
												}
											   }
											}
										}
								}
						}	}
					}			
				}

		}
	}
	
    printf("\n autoclearflag:%d", autoclearflag);fflush(stdout);
	
	if(relztypefnd>0)
	{
		if(autoclearflag>0)
		{
			return ITK_ok;

		}
		else
		{
			return ITK_errStore;	
		}
	}
	else
	{
		return ITK_ok;
	}
	

}

//Start code to Logic Creation of MBOM DML creation
int mbom_dml_create( EPM_action_message_t msg )
{
	char			*item_sequence_id;
	char			*DmlAnalyst_name		= NULL;
	char			*DmlChangeSpecialist	= NULL;
	//int				status;
	int 			max_char_size 			= 80;
	char*			DMLAPL					= NULL;
	char*			Suffix					= NULL;
	tag_t			rootTask				= NULLTAG;
	char			*CurrentTask			= NULL;
	char       		*parent_name			= NULL;
	char      		*Proj_Code				= NULL;
	char*			Part_no					= NULL;
	char*			PartTypeStr				= NULL;
	char*			type_name1				= NULL;
	char*			PartTypeAssy			= NULL;
	char*			ercDsgGrp				= NULL;

	int 			n_tags_found 			= 0;
	tag_t			*attachments			= NULLTAG;
	int   			ifail					= 0;
	
	int
					error_code				= ITK_ok,
					n_entries				= 2,
					n_found					= 0,
					num						= 0,
					i						= 0,
					j						= 0,
					ii						= 0,i1=0;
					tag_t			
					query					= NULLTAG,
					objTypeTag				= NULLTAG,
					item					= NULLTAG,
					rev						= NULLTAG,
					user					= NULLTAG;
	char 			*item_id 	  			= NULL;
	char 			*erc_item_id 	   		= NULL;
	char 			*PlantName 	   			= NULL;
	char 			*subSyscd 	   			= NULL;//Start Plant Aggregate
	logical			delInd					= false;//TZ 1.43
	char 			*DesGrpVal 	   			= NULL;//Start Plant Aggregate
	char 			*DesGrpTmp 	   			= NULL;//Start Plant Aggregate
	tag_t 			*tags_found 			= NULL;
	int	  			noAttachment,noTaskAttachment 	= 0;
	int	  			iDes 					= 0;//Start Plant Aggregate
	tag_t 			ERCDMLObjtag 			= NULLTAG;

	tag_t			item_apl				= NULLTAG;
	tag_t			rev_apl					= NULLTAG;
	tag_t			APLDRevTypeTag			= NULLTAG;
	tag_t			APLDRevCreInTag			= NULLTAG;
	tag_t*			TaskRevision			= NULLTAG;
	

	char**			stringArrayAPLD			= NULL;
	char**			stringArrayAPLT			= NULL;
	int			    n_strings				= 1;
	int			    n_strings_dsg			= 99;//Start Plant Aggregate
	int			    cnt						= 0;//Start Plant Aggregate
	int			    cnt1					= 0;//Start Plant Aggregate
	int			    FlagFound				= 0;//Start Plant Aggregate
	int				FlagSnapshot    		= 0;
	char*			object_type				= NULL;
	

	//char *item_id_dup 	   = NULL;
	int   			apl_task_number_found;
	int  			apl_number_found;
	int 			*erc_number_found;
	int  			control_number_found;
	int 			tskcnterc 				= 0;
	tag_t 			*Dml_ercTasks			= NULLTAG;
	tag_t 			tsk_HSI_rel_type 		= NULLTAG;
	char			*tsk_object_name 		= NULL;
	char			*tsk_object_type 		= NULL;
	char   			*DMLNumber 				= NULL;
    char   			*taskGrp	  			= NULL;

	tag_t 			*TskHSItems 			= NULLTAG;
	int 			TskHSIcount 			= 0;
	int 			flagDMLhdr 				= 0;

	tag_t 			*list_of_WSO_tags		= NULLTAG;
	tag_t 			*list_of_WSO_erc_tags	= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags = NULLTAG;
	tag_t			APLDTypeTag				= NULLTAG;
	tag_t			APLDCreInTag			= NULLTAG;
	tag_t			APLDMLTag				= NULLTAG;
	tag_t			PartRevTag				= NULLTAG;
	tag_t			tsk_part_sol_rel_type	= NULLTAG;
	tag_t			tsk_part_CR_rel_type	= NULLTAG;
	tag_t			AssyTag					= NULLTAG;
	tag_t			tsk_part_APL_rel		= NULLTAG;

	//Dhanashri added// UATZ1.45
	
    tag_t 			*list_of_WSO_cntrl_tags1 = NULLTAG;
	
	int  			FlagGotFrmToplt			= 0;

    char 			*FrmPltToPlt 	   		= NULL;

	//End Dhanashri added// UATZ1.45

	//Priti added//
	tag_t			class_id			= NULLTAG;
	char			*class_name			= NULL;

	int				index				= 0;
	int				iDML				= 0;
	int				l_strings			= 500;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int				cntTaskD			= 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         	Fndrelation 		= NULLTAG;
    tag_t  			NewDMLAttrId 		= NULLTAG;
    tag_t  			NewDMLRevAttrId 	= NULLTAG;

	char 			*item_erc_id_dup 	= (char *)MEM_alloc(max_char_size * sizeof(char));
	char 			*item_erc_id_dup1 	= (char *)MEM_alloc(max_char_size * sizeof(char));
	char			*tempString			= NULL;

    char 			*erc_dml_name  		= NULL;
	char 			*erc_dml_desc  		= NULL;
	char 			*erc_rel_type  		= NULL;
	char 			*mbom_rel_type  	= NULL;
	char 			*erc_dr_status  	= NULL;
	char 			*erc_FrmToPlnt  	= NULL;
	char 			*item_name   		= NULL;
	char 			*Design_group 		= NULL;
	char 			*RlsType 			= NULL;
	char 			*DML_no 			= NULL;
	char 			**DesignGroupList	= (char **) MEM_alloc(100 * sizeof(char *));
	char 			**DesignGroupStr	= NULL;// Plant Aggregate
	char 			**DesignGroupStr1	= NULL;// Plant Aggregate
	char 			**TaskDesignGroupStr= NULL;// Plant Aggregate
	char 			*DesGrpFrst			= NULL;// Plant Aggregate
	char 			*DesGrpFrstTmp		= NULL;// Plant Aggregate
	int				DesGrpFrstTmp1;// Plant Aggregate
	char			DesGrpFrstTmp2[20];// Plant Aggregate
	char 			*DesGrpLst			= NULL;// Plant Aggregate
	char   			*type_name;
	tag_t			relation_type,relation	,propTag	= NULLTAG;
	tag_t  			aplrelation 		= NULLTAG;
	tag_t  			apltaskrelation 	= NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	const char		*apl_dml_qry_entries[1];
	const char		*apl_dml_qry_values[1];
	const char		*apl_task_qry_entries[1];
	const char		*apl_task_qry_values[1];
	char			apl_dml_rev_id[TCTYPE_name_size_c+1]="A";
	char			apl_dml_task_rev_id[TCTYPE_name_size_c+1]="A";

	tag_t   		qryTagCntrl     	= NULLTAG;
	int     		n_entryCntrl   		= 3;
	char    		*qry_entryCntrl[3]  = {"Name","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl	= (char **) MEM_alloc(5 * sizeof(char *));

	char    		*qry_entryCntrlPB[4]  = {"Name","SUBSYSCD","Delete Indicator","Information-1"};	
	char			**qry_valuesCntrlPB	  = (char **) MEM_alloc(6 * sizeof(char *));
	int				control_number_foundPrj		=	0;
	int				clrSvrCnt					=	0;
	int				n_entryCntrlPB				=	4;	//Deepti TZ3.52

	tag_t   		qryTagCntrlPB				=	NULLTAG;
	tag_t   		dml_svr_sol_rel_type		=	NULLTAG;
	tag_t   		dml_svr_APL_rel				=	NULLTAG;
	tag_t			*list_of_WSO_cntrlPrj_tags	=	NULLTAG;
	tag_t			*clrSvrTags					=	NULLTAG;

	int				n_entryCntrlUnitBOM			=	4;
	int				control_number_foundUnitBOM	=	0;

	char    		*qry_entryCntrlUnitBOM[4]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	//HEMAL TZ1.52
	char			**qry_valuesCntrlUnitBOM= (char **) MEM_alloc(5 * sizeof(char *));//HEMAL TZ1.52

	tag_t   		qryTagCntrlUnitBom				= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tagsUnitBOM	= NULLTAG;
	tag_t  			reln_type_Reference =NULLTAG;
	char			*APL_DML_no 					= NULL;
                
    				APL_DML_no 						= (char *)MEM_alloc(max_char_size * sizeof(char));

	int				n_attchs_ref					= 0;
	tag_t			*rellist_refs					= NULLTAG;
	int MBOMDMLTaskCount 	=		0;
	tag_t						*MBOMTask_List						= NULLTAG;
	char *object_typedml =NULL;
	char *reltask_id=NULL;



    printf("\n **************tm_mbom_dml_create***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Current Task for MBOM DML creation : %s ",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n mr_dml_create Parent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n mr_dml_create Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		ERCDMLObjtag = attachments[0];
		if(TCTYPE_ask_object_type(ERCDMLObjtag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n mr_dml_create type_name [%s]\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		//Control Object Check for ERC DML Design Group
		char    *qry_entryCntrl1[3]  		= {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1			= (char **) MEM_alloc(5 * sizeof(char *));
		int 	cntrlcnt					= 0;
		int  	control_number_found1		= 0;
		int     n_entryCntrl1    			= 3;
		char 	*ctrlObj_Info1 				= NULL;
		tag_t   qryTagCntrl1     			= NULLTAG;
		tag_t 	*cntr_objects				= NULLTAG;
		char			*eRcbUsuNit			= NULL;
		char			*pRoductlIne 		= NULL;
		char			*Temp				= NULL;
		char			*reasondesc			= NULL;
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="MBOMAplDsgGrp1";
			qry_valuesCntrl1[1]="MBOMAplDsgGrp1";
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &cntr_objects))
			printf("\n MBOMAplDsgGrp1 control object found : %d",control_number_found1);fflush(stdout);
		}
		else
		{
			EMH_clear_errors();
			printf("\n Control Object Query not Found \n");fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Control Object Query not found, please check environment configuration.\n Please raise DPDS TMS !!!");
			return ITK_errStore1;
		}
		
		if(control_number_found1>0)
		{
			int DESIGN_COUNT = 0;
			int dsgChkFlag = 0;
			AOM_ask_value_string( cntr_objects[0], "t5_Userinfo1", &ctrlObj_Info1);
			printf("\n Information 1 : %s",ctrlObj_Info1);fflush(stdout);
			tag_t	ERC_DML_TASK_REL_NAME	=	NULLTAG;
			tag_t	*ERC_TASK_LIST			=	NULLTAG;
			GRM_find_relation_type("T5_DMLTaskRelation",&ERC_DML_TASK_REL_NAME);
			GRM_list_secondary_objects_only(ERCDMLObjtag, ERC_DML_TASK_REL_NAME, &num,&ERC_TASK_LIST);
			// AOM_ask_value_strings(ERCDMLObjtag,"t5_crdesigngroup",&num,&DesignGroupList);
			

			printf("\n Total Task Found : %d",num);fflush(stdout);
			if(num>0)
			{
				int ERC_TASK_DSG_ITR = 0;
				for(ERC_TASK_DSG_ITR = 0 ; ERC_TASK_DSG_ITR < num ; ERC_TASK_DSG_ITR++){
					char*	ERC_TASK_NAME 	= NULL;
					char*	ERC_DEG_LIST	= NULL;
					AOM_ask_value_string(ERC_TASK_LIST[ERC_TASK_DSG_ITR],"item_id",&ERC_TASK_NAME);
					ERC_DEG_LIST = strrchr(ERC_TASK_NAME,'_');
					DesignGroupList[ERC_TASK_DSG_ITR] = (char*) MEM_alloc (tc_strlen(ERC_DEG_LIST) * sizeof(char));
					tc_strcpy(DesignGroupList[ERC_TASK_DSG_ITR],ERC_DEG_LIST+1);
					printf("\n Design Group of %s is %s ",ERC_TASK_NAME,ERC_DEG_LIST + 1);fflush(stdout);
				}
				int k=0;
				for(k=0 ; k<num;k++)
				{
					if (tc_strstr(ctrlObj_Info1,DesignGroupList[k]) != NULL )
					{
						dsgChkFlag = 1;
						break;
					}
				}
			}
			else
			{
				printf("\n ERC DML is not having any designgroup\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"ERC DML is not having any designgroup .\n Please raise DPDS(ERC) for the resolution !!!");
				return ITK_errStore1;
			}
			
			printf("\n dsgChkFlag = :[%d]",dsgChkFlag);fflush(stdout);
			
			if(dsgChkFlag == 1)
			{
				int ErcTaskIterator =0;
				int 			Erctask_count		= 	0;
				int 			ErcTaskFlag			=	0;
				int				n_strings			=	1;
				int				l_strings			=	300;
				int				index			    =	0;
				tag_t			*ErcTask_List		= 	NULLTAG;
				tag_t			ErcTaskTag			= 	NULLTAG;
				tag_t			ErcTaskRel			= 	NULLTAG;
				tag_t			*ErcTask			= 	NULLTAG;
				char			*eRctAsknAme		= 	NULL;
				tag_t			MBOMDML				= 	NULLTAG;
				tag_t			MBOMDMLCre			= 	NULLTAG;
				tag_t			MBOMDMLRevTag		= 	NULLTAG;
				tag_t			MBOMDMLRevTagCre	= 	NULLTAG;
				tag_t			MBOMDMLTag			= 	NULLTAG;
				tag_t			MBOMDMLRevObjTag	= 	NULLTAG;
				char**			stringArrayMBOM		= 	NULL;
				tag_t			taskPartRelName     =	NULLTAG;
				
								mbom_rel_type 		= (char *)MEM_alloc(250);

				stringArrayMBOM = (char**)malloc( n_strings * sizeof *stringArrayMBOM );
				for( index=0; index<n_strings; index++ )
				{
					stringArrayMBOM[index] = (char*)malloc( l_strings + 1 );
				}
				//MR DML Creation Logic
				printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
				AOM_ask_value_string( ERCDMLObjtag, "item_id", &item_id);
				AOM_ask_value_string( ERCDMLObjtag, "current_id", &DML_no);
				AOM_ask_value_string( ERCDMLObjtag, "t5_cprojectcode", &Proj_Code);
				AOM_ask_value_string( ERCDMLObjtag, "object_name", &erc_dml_name);
				AOM_ask_value_string( ERCDMLObjtag, "object_desc", &erc_dml_desc);
				AOM_ask_value_string( ERCDMLObjtag, "t5_rlstype", &erc_rel_type);
				AOM_ask_value_string( ERCDMLObjtag, "t5_cDRstatus", &erc_dr_status);
				AOM_ask_value_string( ERCDMLObjtag, "t5_PlntToPlnt", &erc_FrmToPlnt);
				AOM_ask_value_string( ERCDMLObjtag, "t5_ERCBusiUt", &eRcbUsuNit);
				AOM_ask_value_string( ERCDMLObjtag, "object_type", &Temp);
				AOM_ask_value_string( ERCDMLObjtag, "t5_ProductLine", &pRoductlIne);
				AOM_ask_value_string( ERCDMLObjtag, "t5_reasondesc", &reasondesc);   //cbb


				printf("\n ERC DML Project Code : %s",Proj_Code);fflush(stdout);
				printf("\n item_id : %s",item_id);fflush(stdout);
				printf("\n DML_no : %s",DML_no);fflush(stdout);		
				printf("\n num is : %d",num);fflush(stdout);
				printf("\n erc_dml_name is : %s",erc_dml_name);fflush(stdout);
				printf("\n erc_dml_desc is : %s",erc_dml_desc);fflush(stdout);
				printf("\n erc_rel_type is : %s",erc_rel_type);fflush(stdout);
				printf("\n erc_dr_status is : %s",erc_dr_status);fflush(stdout);
				printf("\n erc_FrmToPlnt is : %s",erc_FrmToPlnt);fflush(stdout);
				printf("\n ERC Business Unit is : %s",eRcbUsuNit);fflush(stdout);
				printf("\n object_type is : %s",Temp);fflush(stdout);
				printf("\n ProductLine is : %s",pRoductlIne);fflush(stdout);  
				printf("\n reasondesc is : %s",reasondesc);fflush(stdout);     //cbb

				if(strcmp(erc_rel_type,"Veh")==0) mbom_rel_type="VCREST";
				else if(strcmp(erc_rel_type,"TPL")==0) mbom_rel_type="MFG_SubMdRlz";
				else if(strcmp(erc_rel_type,"TODR")==0) mbom_rel_type="GM_MMDML";
				else if(strcmp(erc_rel_type,"WO")==0) mbom_rel_type="Wdrw_FrmObs";
				else if(strcmp(erc_rel_type,"WO")==0) mbom_rel_type="Wdrw_FrmObs";
				else {
					tc_strcpy(mbom_rel_type," ");
					tc_strcpy(mbom_rel_type,"MFG_SubMdRlz");
					}

				
				
				GRM_find_relation_type("T5_DMLTaskRelation",&ErcTaskRel);
				GRM_list_secondary_objects_only	(ERCDMLObjtag, ErcTaskRel, &Erctask_count,&ErcTask);
				
				printf("\n Total ERC Task found : %d",Erctask_count);fflush(stdout);
				int				MBOMDMLFlag		=	0;
				int				FoundFlag		=	0;
				
				for(ErcTaskIterator = 0 ; ErcTaskIterator < Erctask_count ; ErcTaskIterator++)
				{
					ErcTaskTag = ErcTask[ErcTaskIterator];
					AOM_ask_value_string(ErcTaskTag,"item_id",&eRctAsknAme);
					printf("\n ERC Task Name 			: %s",eRctAsknAme);fflush(stdout);
					int PartCntInt = 0;
					int changerefcnt = 0 ;
					tag_t*	PartTagsInt = NULLTAG;
					if(!tc_strstr (eRctAsknAme,"MBOM") && !tc_strstr (eRctAsknAme,"APL") && !tc_strstr (eRctAsknAme,"STD"))
					{	
						printf("\n ErcTaskFlag : %d",ErcTaskFlag);fflush(stdout);
						if(ErcTaskFlag == 0 && MBOMDMLFlag == 0)
						{
							 (ErcTask_List) = (tag_t* )malloc((1 ) * sizeof(tag_t ));
						}
						else if(FoundFlag != 0)
						{
							
							(ErcTask_List) = (tag_t* )realloc((ErcTask_List),(ErcTaskFlag + 1 ) * sizeof(tag_t ));
						}


						CALLAPI(AOM_ask_value_tags(ErcTaskTag,"CMHasSolutionItem",&PartCntInt,&PartTagsInt));
						CALLAPI(AOM_ask_value_tags(ErcTaskTag,"CMReferences",&changerefcnt,&PartTagsInt));
						if(PartCntInt == 0 && changerefcnt == 0)
						{	
							MBOMDMLFlag++;
							FoundFlag = 0;
							printf("\n Task has no parts attached in Has solution and change reference");fflush(stdout);
							continue;

						}
						else
						{
							ErcTask_List[ErcTaskFlag] = ErcTaskTag;
							ErcTaskFlag++;
							FoundFlag++;
							printf("\n Adding to  ErcTask_List\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n MBOM DML already present !!! \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"MBOM DML already present !!! .\n Please expand and check - Breaks Down into Plan Items !!!");
						return ITK_errStore1;
					}
				}
				printf("\n No MBOM DML Found, So Going to create MBOM DML Under ERC DML !!! \n ");fflush(stdout);
				if(MBOMDMLFlag != Erctask_count)
				{
					CALLAPI( TCTYPE_find_type( "T5_MBOMDML", NULL, &MBOMDML) );
					CALLAPI( TCTYPE_construct_create_input( MBOMDML, &MBOMDMLCre) );

					CALLAPI( TCTYPE_find_type( "T5_MBOMDMLRevision", NULL, &MBOMDMLRevTag) );
					CALLAPI( TCTYPE_construct_create_input( MBOMDMLRevTag, &MBOMDMLRevTagCre) );
					
					tc_strcpy( stringArrayMBOM[0], DML_no);
					tc_strcat( stringArrayMBOM[0],"_MBOM");
					printf("\n MBOM DML Number : %s",stringArrayMBOM[0]);fflush(stdout);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLCre, "item_id", 1,(const char**)stringArrayMBOM) );

					tc_strcpy( stringArrayMBOM[0], erc_dml_name);
					printf("\n MBOM DML Object Name : %s",stringArrayMBOM[0]);fflush(stdout);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLCre, "object_name", 1, (const char**)stringArrayMBOM));

					tc_strcpy( stringArrayMBOM[0], erc_dml_desc);
					printf("\n MBOM DML Desc : %s",stringArrayMBOM[0]);fflush(stdout);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLCre, "object_desc", 1, (const char**)stringArrayMBOM) );
					
					CALLAPI( AOM_tag_to_string(MBOMDMLRevTagCre, &tempString) );
					tc_strcpy( stringArrayMBOM[0], tempString);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLCre, "revision", 1,(const char**)stringArrayMBOM) );
					printf("\n MBOM DML Revision  : %s",stringArrayMBOM[0]);fflush(stdout);

					tc_strcpy( stringArrayMBOM[0],"NR");
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "item_revision_id", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML Revision Id : %s",stringArrayMBOM[0]);fflush(stdout);

					tc_strcpy( stringArrayMBOM[0],erc_dr_status);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_cDRstatus", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML DR Status : %s",stringArrayMBOM[0]);fflush(stdout);
					tc_strcpy( stringArrayMBOM[0],Proj_Code);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_cprojectcode", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML Project code : %s",stringArrayMBOM[0]);fflush(stdout);
					tc_strcpy( stringArrayMBOM[0],eRcbUsuNit);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_ERCBusiUt", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML Business Unit : %s",stringArrayMBOM[0]);fflush(stdout);
					tc_strcpy( stringArrayMBOM[0],mbom_rel_type);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_MBOMRlzType", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML Release Type : %s",stringArrayMBOM[0]);fflush(stdout);
					tc_strcpy( stringArrayMBOM[0],pRoductlIne);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_ProductLine", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML Product Line : %s",stringArrayMBOM[0]);fflush(stdout);
					tc_strcpy( stringArrayMBOM[0],erc_rel_type);
					CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_rlstype", 1, (const char**)stringArrayMBOM) );
					printf("\n MBOM DML ERC Release Type : %s",stringArrayMBOM[0]);fflush(stdout);

					// char* Reasondes = NULL;					
					// Reasondes = (char *)MEM_alloc(250);

					if(tc_strcmp(reasondesc,"")== 0)    //cbb
					{
						
						// tc_strcpy(Reasondes,"");
						// tc_strcat(Reasondes,"NA");
						//printf("\n Reasondes is  : %s",Reasondes);fflush(stdout);
						tc_strcat(reasondesc,"NA");
						printf("\n Updated reasondesc is : %s",reasondesc);fflush(stdout);

						// tc_strcpy( stringArrayMBOM[0],reasondesc);
						// CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_reasondesc", 1, (const char**)stringArrayMBOM) );
						// printf("\n Updated MBOM DML Reason Desc : %s",stringArrayMBOM[0]);fflush(stdout);

					}
						tc_strcpy( stringArrayMBOM[0],reasondesc);
						CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_reasondesc", 1, (const char**)stringArrayMBOM) );
						printf("\n Updated MBOM DML Reason Desc : %s",stringArrayMBOM[0]);fflush(stdout);
					



					if(tc_strcmp(erc_rel_type,"TODR") == 0)
					{
						tc_strcpy( stringArrayMBOM[0],erc_FrmToPlnt);
						CALLAPI( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "t5_PlntToPlnt", 1, (const char**)stringArrayMBOM) );
						printf("\n MBOM DML  : %s",stringArrayMBOM[0]);fflush(stdout);
					}
					
					CALLAPI(TCTYPE_create_object(MBOMDMLCre,&MBOMDMLTag));
					
					printf("\n MBOM DML Object Created. \n");fflush(stdout);

					CALLAPI(AOM_save_without_extensions(MBOMDMLTag));
					CALLAPI(AOM_refresh(MBOMDMLTag,1));

					CALLAPI(ITEM_ask_latest_rev(MBOMDMLTag,&MBOMDMLRevObjTag));

					if(MBOMDMLTag != NULLTAG && MBOMDMLRevObjTag != NULLTAG)
					{
						printf("\n MBOM DML Object Created and Saved, Getting into Relationship !!!");

						CALLAPI(AOM_save_without_extensions(MBOMDMLRevObjTag));
						CALLAPI(AOM_refresh(MBOMDMLRevObjTag,1));

						CALLAPI(AOM_lock(MBOMDMLRevObjTag));
						int dsgitr ;
						for(dsgitr = 0; dsgitr < num ;dsgitr++)
						{
							printf("\n Inside Design Group list : %s",DesignGroupList[dsgitr]);fflush(stdout);
							CALLAPI(AOM_set_value_string_at(MBOMDMLRevObjTag,"t5_crdesigngroup",dsgitr,DesignGroupList[dsgitr]));
						}
						// CALLAPI(AOM_refresh(MBOMDMLRevObjTag,1));
						CALLAPI(AOM_save_without_extensions(MBOMDMLRevObjTag) );
						CALLAPI(AOM_refresh(MBOMDMLRevObjTag,1));
						CALLAPI(AOM_unlock(MBOMDMLRevObjTag) );

					}
					else
					{
						printf("\n MBOM DML Created, but not saved. Please check !!!");
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"MBOM DML Created, but not saved.\n This can happen due to server issue.\nPlease query and check if task or DML is created or not.\nIf the not created kindly proceed with regenration process !!!.\nIf created, Raise DPDS TMS for the same.");
						return ITK_errStore1;
					}
					
					tag_t  						TasktoDMLrel						= NULLTAG;
					tag_t  						EDMLMDMLRel							= NULLTAG;
					tag_t						MBOMDMLLtRev						= NULLTAG;
					tag_t						ErcDMLLtRev							= NULLTAG;
					tag_t						MBOMDMLType							= NULLTAG;
					tag_t						temdmlrevtype						= NULLTAG;
					char						*temprev							= NULL;
					char						*MBOMDMLTypeName;
					
					int 						DMLTaskIterator						= 0;
					tag_t 						*MBOM_DML_Result 					= NULLTAG;
					int 						MBOMDMLCOUNT 						= 0;
					const char					*Mbom_dml_qry_entries[1];
												Mbom_dml_qry_entries[0] 			="item_id";
					const char					*Mbom_Dml_qry_values[1];
					char 						MbomDmlNo[20];
					
					tc_strcpy(MbomDmlNo,DML_no);
					Mbom_Dml_qry_values[0] 				= tc_strcat(MbomDmlNo,"_MBOM");
					ITKCALL(ITEM_ask_latest_rev(MBOMDMLTag,&temdmlrevtype));
					if(temdmlrevtype != NULLTAG)
					{
						AOM_ask_value_string(temdmlrevtype,"item_revision_id",&temprev);
						printf("\n MBOM DML Revision ID (NR / A) : %s \n",temprev);fflush(stdout);
					}
					
					printf("\n MBOM DML Number : %s",Mbom_Dml_qry_values[0]);
					ITKCALL(ITEM_find_item_revs_by_key_attributes(1,Mbom_dml_qry_entries,Mbom_Dml_qry_values,temprev,&MBOMDMLCOUNT,&MBOM_DML_Result));
					printf("\n Total MBOM DML Revision found %d \n ",MBOMDMLCOUNT);fflush(stdout);
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&TasktoDMLrel));
					if (TasktoDMLrel != NULLTAG)
					{	
						printf("\n DML to Task relation Found \n");fflush(stdout);
						ITKCALL(ITEM_ask_latest_rev(MBOMDMLTag,&MBOMDMLLtRev));
						if(MBOMDMLLtRev == NULLTAG)
						{
							printf("\n No MBOM DML Revision Found !!! Please Check\n ");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"No MBOM DML Revision Found !!! .\n Please expand and check - Breaks Down into Plan Items !!!");
							return ITK_errStore1;
						}
						else	
						{
							
							printf("\n MBOM DML Revision Found .... Going to Create Releationship (ERC DML AND MBOM DML) !!!");fflush(stdout);
							ITKCALL(GRM_create_relation(ERCDMLObjtag,MBOM_DML_Result[0],TasktoDMLrel,NULLTAG,&EDMLMDMLRel));

							if(EDMLMDMLRel == NULLTAG)
							{
								printf("\n Relation between ERC DML and MBOM DML is unsuccessful \n ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Relation between ERC DML and MBOM DML is unsuccessful.\nThis can happen due to server issue.\n");
								return ITK_errStore1;
							}
							else
							{
								ITKCALL(GRM_save_relation(EDMLMDMLRel));
								printf("\n ERC DML to MBOM DML relation created \n");fflush(stdout);

							}

							for(DMLTaskIterator = 0; DMLTaskIterator < ErcTaskFlag ; DMLTaskIterator++)
							{
								printf("\n Total MBOM Task count: %d",ErcTaskFlag);fflush(stdout);
								tag_t	 						ERCTaskRevTag								= NULLTAG;
								tag_t	 						ERCTaskMBOMTag								= NULLTAG;
								tag_t	 						ERCMBOMTaskTag								= NULLTAG;
								tag_t	 						ERCMBOMTaskInpTag							= NULLTAG;
								tag_t	 						ERCMBOMRevTaskTag							= NULLTAG;
								tag_t	 						ERCMBOMTaskRevInpTag						= NULLTAG;
								tag_t	 						ERCMBOMTaskObjTag							= NULLTAG;
								tag_t	 						ERCMBOMTaskRevObjTag						= NULLTAG;
								
								char							*ERCMbomTask								= NULL;
								char							*ERCMbomTaskTemp							= NULL;
								char							*ERCMbomTaskRevTemp							= NULL;
								char							*ERCDesigngrp								= NULL;
								char							*ERCMBOMTagStr								= NULL;

								 const char						*Mbom_Task_qry_values[1];

								int								ERCMbomTaskCount							= 0;

								tag_t 							*MBOM_Task_DML_Result 						= NULLTAG;
								tag_t*							PartTags									= NULLTAG;
								int 							PartCnt										= 0;
								int 							PartCntCR									= 0;

tag_t                                                   task_sol_foldertag                                                  = NULLTAG;
								tag_t                                                   *parttag                                                            = NULLTAG;
								tag_t                                                    folderparts                                                        = NULLTAG;
								tag_t                                                   *FolderObj_tag                                                      = NULLTAG;
								int                                                      count                                                              = 0;
								int                                                      FlderSize                                                          = 0;
								int                                                      FlderObjCount                                                      = 0;
								int                                                      Refflag                                                            = 0;
								int                                                     FLCount                                                             = 0;
								char                                                    *folderprtObjTyp                                                    = NULL;
								char                                                     *object_name                                                       = NULL;
								

								

								char**							ErcMbomTaskAttrInpArray						= NULL;
																ErcMbomTaskAttrInpArray 					= (char**)malloc( n_strings * sizeof(*ErcMbomTaskAttrInpArray));
								for( index=0; index<n_strings; index++ )
								{
									ErcMbomTaskAttrInpArray[index] = (char*)malloc(500);
								}

								ERCTaskMBOMTag = ErcTask_List[DMLTaskIterator];
								AOM_ask_value_string(ERCTaskMBOMTag,"item_id",&ERCMbomTaskTemp);
								AOM_ask_value_string(ERCTaskMBOMTag,"item_revision_id",&ERCMbomTaskRevTemp);

								printf("\n ERCMbomTaskTemp : %s",ERCMbomTaskTemp);fflush(stdout);
								printf("\n ERCMbomTaskRevTemp : %s",ERCMbomTaskRevTemp);fflush(stdout);
								tc_strcpy(ERCMbomTask,"");
								AOM_ask_value_string(ERCTaskMBOMTag,"item_id",&ERCMbomTask);
								printf("\n ERC Mbom Task name is : %s ",ERCMbomTask);fflush(stdout);
								AOM_ask_value_string(ERCTaskMBOMTag,"t5designgroup",&ERCDesigngrp);//added by vaibhav
								printf("\n ERC Mbom Task t5designgroup is : %s ",ERCDesigngrp);fflush(stdout);//added by vaibhav
								if(tc_strcmp(ERCDesigngrp,"")==0)//added by vaibhav
								{
									printf("\n t5designgroup Value not available on ERC task  \n");fflush(stdout);
									ERCDesigngrp=subString(ERCMbomTask,11,13);//added by vaibhav
									printf("\n ERC MBOM Task Design Group is : %s",ERCDesigngrp);fflush(stdout);//added by vaibhav
								}
//////////////////////////////////////////CO_Task_Generation_ERC_MBOM.c///////////////////////////////////////////////////
								if(tc_strstr(ERCMbomTask,"CO")!=NULL)
								{
										ifail = GRM_find_relation_type("CMReferences", &task_sol_foldertag);
										ifail = GRM_list_secondary_objects_only(ERCTaskMBOMTag,task_sol_foldertag, &count, &parttag);
										printf("\n  CMReferences part count is: %d\n",count);fflush(stdout);
										for (j= 0; j < count; j++)
										{
												Refflag++;
												printf("\n  Refflag is: %d\n",Refflag);fflush(stdout);
												folderparts=parttag[j];

												AOM_ask_value_string(folderparts,"object_type",&folderprtObjTyp);
												printf("\n  Part_type is: %s\n",folderprtObjTyp);fflush(stdout);
												AOM_ask_value_string(folderparts,"object_name",&object_name);
												printf("\n  object_name is: %s\n",object_name);fflush(stdout);
												if((tc_strcmp(folderprtObjTyp,"Folder")==0) && (tc_strcmp(object_name,"Parts For Gate Maturation")==0))
												{
														ITKCALL(FL_ask_size(folderparts,&FlderSize));
														printf("\n GMD:FlderSize is:   %d\n",FlderSize);fflush(stdout);
														ITKCALL(FL_ask_references(folderparts,NULLTAG ,&FlderObjCount,&FolderObj_tag));
														if(FlderObjCount>0)
														{
																FLCount++;
																printf("\n GMD:FlderObjCount is..:   %d\n",FlderObjCount);fflush(stdout);
																break;
														}
												}
										}

								}
								printf("\n  Refflag is: %d\n",Refflag);fflush(stdout);
								printf("\n  FLCount is: %d\n",FLCount);fflush(stdout);
								if((FLCount==0) && (tc_strstr(ERCMbomTask,"CO")!=NULL))
								{
										printf("\n No Need to Create CO Task.....   %d\n",FlderObjCount);fflush(stdout);
								}
								else
								{

								//////////////////////////////////////////CO_Task_Generation_ERC_MBOM.c  END ///////////////////////////////////////////////////
								  
								tc_strdup(ERCMbomTask,&ERCMbomTask);
								tc_strcat(ERCMbomTask,"_MBOM");
								printf("\n ERCMbomTask before : %s",ERCMbomTask);fflush(stdout);
								tc_strcpy(ErcMbomTaskAttrInpArray[0],"");
								tc_strcpy(ErcMbomTaskAttrInpArray[0],ERCMbomTask);
								
								Mbom_Task_qry_values[0] = ERCMbomTask;
								printf("\n ERCMbomTask After : %s",ERCMbomTask);fflush(stdout);
								printf("\n Item ID for ERC MBOM Task is 1 : %s",ErcMbomTaskAttrInpArray[0]);fflush(stdout);
								
								CALLAPI( TCTYPE_find_type( "T5_MBOMTASK", NULL, &ERCMBOMTaskTag) );
								CALLAPI( TCTYPE_construct_create_input( ERCMBOMTaskTag, &ERCMBOMTaskInpTag) );

								CALLAPI( TCTYPE_find_type("T5_MBOMTASKRevision", NULL, &ERCMBOMRevTaskTag) );
								CALLAPI( TCTYPE_construct_create_input( ERCMBOMRevTaskTag, &ERCMBOMTaskRevInpTag) );

								CALLAPI( TCTYPE_set_create_display_value( ERCMBOMTaskInpTag, "item_id", 1,(const char**)ErcMbomTaskAttrInpArray));
								printf("\n Item ID for ERC MBOM Task is 4 : %s",ErcMbomTaskAttrInpArray[0]);fflush(stdout);

								tc_strcpy(ErcMbomTaskAttrInpArray[0],erc_dml_desc);
								CALLAPI( TCTYPE_set_create_display_value( ERCMBOMTaskInpTag, "object_desc", 1,(const char**)ErcMbomTaskAttrInpArray) );

								tc_strcpy(ErcMbomTaskAttrInpArray[0],erc_dml_name);
								CALLAPI( TCTYPE_set_create_display_value( ERCMBOMTaskInpTag, "object_name", 1,(const char**)ErcMbomTaskAttrInpArray) );

								// CALLAPI( AOM_tag_to_string(ERCMBOMTaskRevInpTag, &ERCMBOMTagStr) );
								// tc_strcpy( ErcMbomTaskAttrInpArray[0], ERCMBOMTagStr);
								// CALLAPI( TCTYPE_set_create_display_value( ERCMBOMTaskInpTag, "revision", 1,(const char**)ErcMbomTaskAttrInpArray) );
								// printf("\n ERC MBOM TASK Revision Object Value  : %s",ErcMbomTaskAttrInpArray[0]);fflush(stdout);

								// tc_strcpy( ErcMbomTaskAttrInpArray[0],"A");
								CALLAPI( TCTYPE_set_create_display_value( ERCMBOMTaskRevInpTag, "item_revision_id", 1, (const char**)ErcMbomTaskAttrInpArray) );
								printf("\n  ERC MBOM TASK Revision Id : %s \n",ErcMbomTaskAttrInpArray[0]);fflush(stdout);

								CALLAPI(TCTYPE_create_object(ERCMBOMTaskInpTag,&ERCMBOMTaskObjTag));
//******************************************************************* Ketan Added *********************************************************************************// 
								// CALLAPI(AOM_refresh(ERCMBOMTaskObjTag,1));
								CALLAPI( AOM_save_without_extensions(ERCMBOMTaskObjTag) );
								CALLAPI(AOM_refresh(ERCMBOMTaskObjTag,1));

								printf("\n MBOM Task: %s Created from ERC Task \n",ERCMbomTask);fflush(stdout);

								CALLAPI(ITEM_ask_latest_rev(ERCMBOMTaskObjTag,&ERCMBOMTaskRevObjTag));

								if (MBOMDMLRevObjTag != NULLTAG && ERCMBOMTaskRevObjTag != NULLTAG)
								{
									GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
									GRM_create_relation(MBOMDMLRevObjTag, ERCMBOMTaskRevObjTag, relation_type,  NULLTAG, &apltaskrelation);
									GRM_save_relation(apltaskrelation);
									printf("\n Relation Created between MBOM-DML and MBOM-Task: %s \n",ERCMbomTask);fflush(stdout);
								}
								printf("\n ************************ Mbom_Task_qry_values****************** %s",Mbom_Task_qry_values[0]);fflush(stdout);
								ITKCALL(ITEM_find_items_by_key_attributes(1,Mbom_dml_qry_entries,Mbom_Task_qry_values,&ERCMbomTaskCount,&MBOM_Task_DML_Result));
								
								//Added by Vaibhav.... Update Project code and Design Group attributes on MBOM Task Revision...
								//start
								CALLAPI(AOM_lock(ERCMBOMTaskRevObjTag));
									CALLAPI(AOM_set_value_string(ERCMBOMTaskRevObjTag,"t5_cprojectcode",Proj_Code)); //	Project Code
									printf("\n set value for t5_cprojectcode : %s",Proj_Code);fflush(stdout);
									if(tc_strcmp(ERCDesigngrp,"CL") == 0 || tc_strcmp(ERCDesigngrp,"SP") == 0 || tc_strcmp(ERCDesigngrp,"CO") == 0)
									
									{
										CALLAPI(AOM_set_value_string(ERCMBOMTaskRevObjTag,"t5_crdesigngroup",DesignGroupList[0])); // Design group
									}
									else{
									CALLAPI(AOM_set_value_string(ERCMBOMTaskRevObjTag,"t5_crdesigngroup",ERCDesigngrp)); // Design group
									}
									printf("\n set value for CL/SP/CO t5_crdesigngroup : %s",ERCDesigngrp);fflush(stdout);
									// CALLAPI(AOM_refresh(ERCMBOMTaskRevObjTag,1));
									CALLAPI(AOM_save_without_extensions(ERCMBOMTaskRevObjTag) );
									CALLAPI(AOM_refresh(ERCMBOMTaskRevObjTag,1));
								CALLAPI(AOM_unlock(ERCMBOMTaskRevObjTag) );
								//End
//******************************************************************* Ketan added for part addition **********************************************************************//
								
								char* tsk_object_name = NULL ;

								CALLAPI(AOM_ask_value_tags(ERCTaskMBOMTag,"CMHasSolutionItem",&count,&PartTags));
								if(count == 0)
								{
									CALLAPI(AOM_ask_value_tags(ERCTaskMBOMTag,"CMReferences",&count,&PartTags));
									PartCnt	=	1;
								}
								
								printf("\n No of Task in ERC DML : %d\n",count);fflush(stdout);

								if (count>0)
								{
									for (i1=0;i1<count ;i1++ )
									{
										PartRevTag = PartTags[i1];
										CALLAPI(AOM_ask_value_string(PartRevTag,"object_type",&object_type));
										
										printf("\n object_type is :%s",object_type);fflush(stdout);
										printf("\n ERC Task Type   => %s",object_type);fflush(stdout);
									if (PartCnt == 0)
									{
										printf("\n Inside PartCnt\n");fflush(stdout);
										GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									}	
										else
										{
											GRM_find_relation_type("CMReferences",&tsk_part_sol_rel_type);
											printf("\n Part is attached in Change References");fflush(stdout);
										}
										
										/* CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n  ERC Task Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n ERC Task AssyTag type_name1 := %s", type_name1);fflush(stdout);		
										
										CALLAPI(POM_class_of_instance(AssyTag,&class_id));
										CALLAPI(POM_name_of_class(class_id,&class_name));
										printf("\n class_name is :%s\n",class_name);fflush(stdout);
*/
										CALLAPI(AOM_ask_value_string(PartRevTag,"object_type",&PartTypeStr));
										printf("\n ERC Task :AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if ( (PartRevTag != NULLTAG && ERCMBOMTaskRevObjTag != NULLTAG && tsk_part_sol_rel_type != NULLTAG))
										{

											CALLAPI(GRM_find_relation(ERCMBOMTaskRevObjTag, PartRevTag, tsk_part_sol_rel_type ,&Fndrelation));
											if(Fndrelation)
											{
												printf("\n\t Relation Already Exist.\n" );fflush(stdout);
											}
											else
											{
												printf("\n Attaching Part to MBOM task \n");	fflush(stdout);
												GRM_create_relation(ERCMBOMTaskRevObjTag, PartRevTag, tsk_part_sol_rel_type,  NULLTAG, &tsk_part_APL_rel);
												GRM_save_relation(tsk_part_APL_rel);
											}
										}
									}
								}

								// Ended
							}
							}
							GRM_list_secondary_objects_only	(MBOMDMLLtRev, ErcTaskRel, &MBOMDMLTaskCount,&MBOMTask_List);
							printf("\n Total MBOM Task found : %d",MBOMDMLTaskCount);fflush(stdout);
							
						}
					}

					/*
					//color sync code comment and handle in mbomDmlColorSyncWithBase
					int a=0;
					for(a=0;a<MBOMDMLTaskCount;a++)
					{
						ITKCALL(AOM_ask_value_string(MBOMTask_List[a],"object_type",&object_typedml));
						printf("\n\t A Object type of DML:- %s",object_typedml);fflush(stdout);

						if(tc_strcmp(object_typedml,"T5_MBOMTASKRevision")==0 )
						{
							ITKCALL(AOM_ask_value_string(MBOMTask_List[a],"current_id",&reltask_id));
							printf("\n\t A Task ID:-%s",reltask_id);fflush(stdout);	
						}
						//MBOM COLOUR PART GENERATION START TZ1.73

						
						if (ERCDMLObjtag != NULLTAG && MBOMDMLLtRev != NULLTAG)
						{
							printf("\n\t A Task ID:-*******************%s",reltask_id);fflush(stdout);
							printf("\n\t A release typeAfter change-*******************%s" ,erc_rel_type);fflush(stdout);	
							if( (tc_strcmp(erc_rel_type,"CP")==0) || (tc_strcmp(erc_rel_type,"CM")==0) )
							{
								printf("\n CREATE_COLOR_MBOM_APL_PARTS");fflush(stdout);
								CREATE_COLOR_MBOM_APL_PARTS(MBOMDMLLtRev);
								tm_mbom_apl_colour_nonColour_part_synch(MBOMDMLLtRev); //TZ1.76
							}
							else if((tc_strcmp(erc_rel_type,"Veh")==0)&&(tc_strstr(reltask_id,"CL_MBOM")!=NULL))
							{
								printf("\n Condition is ssatisfy for release type ERC Release... Inside condition");
								CREATE_COLOR_MBOM_APL_PARTS(MBOMDMLLtRev);
								tm_mbom_apl_colour_nonColour_part_synch(MBOMDMLLtRev); 
								printf("\n Color Part generation completed for the CL Task");
							}
							else
							{
								printf("\n CL Task Condition is not satisfy.");
							}
						}
						
					}*/

					//MBOM COLOUR PART GENERATION END TZ1.73


					if (ERCDMLObjtag != NULLTAG && MBOMDMLLtRev != NULLTAG)
					{
						
						printf("\n **** Submit MBOM DML into Workflow **** \n");fflush(stdout);
						tag_t template_tag = NULLTAG;
						tag_t test_job_a = NULLTAG;
						int attachment_types[1] = {1};

						char* MbomDMLTagRevName = NULL;
						
						printf("\n Finding Process Template\n");fflush(stdout);
						CALLAPI(EPM_find_template2("MBOM ECN Workflow",0,&template_tag));
						if (template_tag!=NULLTAG)
						{
							tc_strcpy(MbomDMLTagRevName,"");
							printf("\n Submiting MBOM DML in to workflow\n");fflush(stdout);
							CALLAPI(AOM_ask_value_string(MBOMDMLLtRev,"object_string",&MbomDMLTagRevName));
							CALLAPI(EPM_create_process(MbomDMLTagRevName,"",template_tag,1, MBOM_DML_Result,attachment_types,&test_job_a));
							printf("\n Submit MBOM DML in to workflow (MBOM ECN Workflow) process complete\n");fflush(stdout);
						}
					}
					printf("\n END OF CODE !!! Happy Debugging !!!\n ");fflush(stdout);
				}
				else
				{
					printf("\n END OF CODE !!! MBOM DML Creation canceled as no part/parts is attached to ERC Task... !!!\n ");fflush(stdout);
				}
				
			}//end of dsgChkFlag
		}
	}
	else
    {
		EMH_clear_errors();
		printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Invalid Object Type !!!\n Please check for control Object.\n Either no control object is present or Delete Indicator is false.");
		return ITK_errStore1;
    }

	
}

// Action Handler for sync color task with base task for ERC Flown DML at MBOM Level

int mbomDmlColorSyncWithBase( EPM_action_message_t msg )
{
	int status;
	int ifail = ITK_ok;
	tag_t rootTask = NULLTAG;
	tag_t *TargetAttch = NULLTAG;
	char *CurrentTask = NULL;
	char *parent_name = NULL;
	int	iNumAttch =0;
	tag_t taskRevisionTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	char *type_name = NULL;
	char *taskNumber = NULL;
	tag_t relationTag = NULLTAG;
	int count = 0, count1=0, i=0, numOfWFtasks=0,y=0;
	tag_t *DmlRevisionTag = NULLTAG;
	char *releaseType = NULL;
	char *mbomreleaseType =NULL;
	char *dmlNumber = NULL;
	tag_t *allTaskRevisonTags= NULLTAG;
	char *taskNumberfromTag = NULL;
	tag_t *valuesOfWFtasksTag= NULLTAG;
	char *taskName = NULL;
	char *taskResult = NULL;
	char *errorMsg = NULL;
    errorMsg = (char *)MEM_alloc(3000);
	int errorFlag=0;

	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	printf("\nInside mbomDmlColorSyncWithBase");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n mbomDmlColorSyncWithBase\n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout); 

	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch) );
	printf("\nNo of Target Attachements:%d\n",iNumAttch);fflush(stdout);

	if (iNumAttch>0)
	{
		ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
        if (qryTagCntrl1)
    	{
        	printf("\n Control Object Query Found For F9X01CreationHandler\n");fflush(stdout);
			qry_valuesCntrl1[0] = "colorSync";
        	qry_valuesCntrl1[1] = "colorSync";
        	qry_valuesCntrl1[2] = "0";
			ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);
        }
		if(control_number_found1>0)
		{
			taskRevisionTag = TargetAttch[0];
			ITKCALL(TCTYPE_ask_object_type(taskRevisionTag,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n workspaceobject  type_name00000000   %s\n", type_name);fflush(stdout);
			if(tc_strcmp(type_name,"T5_MBOMTASKRevision")==0 || tc_strcmp(type_name,"T5_APLTaskRevision")==0)
			{
				ITKCALL(AOM_ask_value_string( taskRevisionTag, "item_id", &taskNumber));

				//solution item

				char *solFoldPartNumber=NULL;
				char *solFoldPartType=NULL;
				char * releasest_name9 = NULL;
				char * info12 = NULL;
				char * NonclrErr = NULL;
				NonclrErr = (char *)MEM_alloc(2000);
				
				tc_strcpy(NonclrErr, "");



				char **SetOprRelErr = NULL;
				SetOprRelErr = (char **)MEM_alloc(50 * sizeof *SetOprRelErr);
				char *part_clrind=NULL;
				tag_t solFolTag=NULLTAG;
				int partCount=0;
				tag_t *solFoldPartTag=NULLTAG;
				int xx=0;
				tag_t RelationFindt=NULLTAG;
				tag_t *BaseParttag1=NULLTAG;
				int ncountBsPart1=0;
				char *BasePART=NULL;
				int Rlsz_count1=0;
				int iLCS2=0;
				int noncolorcheckFlg=0;
				tag_t * status_listofbase = NULLTAG;


				char AplRvwLC[40]; 
				char AplWrkngLC[40];
				char AplRlzdLc[40];
				char Stdwrknglc[40];
				char Stdrlzdlc[40];
				char PltLcs[40];
				char StdPlant[40];
				char StdRevRule[40];
				char StdCLosRule[40];
				char StdView[40];
				char *PlantName = NULL;
				char *roleName = NULL;
				tag_t CurrentRoleTag = NULLTAG;
				int error_cnt = 0;
				int i_cnt = 0;
				int cntFlag = 0;

				ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &solFolTag));
                ITKCALL(GRM_list_secondary_objects_only(taskRevisionTag,solFolTag,&partCount,&solFoldPartTag));

                printf("\n\n\t\t Number of part under solution folder : %d",partCount);fflush(stdout);

                
				//

				printf("\n  Task Number item_id %s ",taskNumber);fflush(stdout);
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &relationTag));
	
				if (relationTag!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(taskRevisionTag,relationTag,&count,&DmlRevisionTag));
					printf("\n  DML Revision from Task : %d",count); fflush(stdout);
					if(count>0)
					{
						AOM_ask_value_string( DmlRevisionTag[0],"item_id",&dmlNumber);
						printf("\n  DML Number is  %s ",dmlNumber);fflush(stdout);
						AOM_ask_value_string( DmlRevisionTag[0],"t5_rlstype",&releaseType);
						printf("\n Release Type on ERC flown DML  %s ",releaseType);fflush(stdout);

						AOM_ask_value_string( DmlRevisionTag[0],"t5_MBOMRlzType",&mbomreleaseType);
						printf("\n Release Type on ERC flown DML  %s ",mbomreleaseType);fflush(stdout);

						
						if( (tc_strcmp(releaseType,"CP")==0) || (tc_strcmp(releaseType,"CM")==0) ) //25CU900100_00_MBOM
						{

							//non colour parts release need  to be check here

											//noncolorcheckFlg = 0;
								if(partCount>0)
								{
									for(int xx=0;xx<partCount;xx++)
									{
										ITKCALL(AOM_ask_value_string( solFoldPartTag[xx], "item_id", &solFoldPartNumber));
										printf("\n Part Number under solution folder is  %s ",solFoldPartNumber);fflush(stdout);
										ITKCALL(AOM_ask_value_string( solFoldPartTag[xx], "t5_PartType", &solFoldPartType));
										printf("\n Part Type under solution folder is  %s ",solFoldPartType);fflush(stdout);
										ITKCALL(AOM_ask_value_string(solFoldPartTag[xx], "t5_ColourInd", &part_clrind));
										printf("\n part_clrind Value :--------------------   %s\n", part_clrind);
										ITKCALL(SA_ask_current_role(&CurrentRoleTag));
										ITKCALL(SA_ask_role_name2(CurrentRoleTag, &roleName))
										printf("\n\n roleName : %s\n", roleName);
										fflush(stdout);
										PlantName = subString(roleName, 3, 4);
										printf("APL GM DML PlantName:%s\n", PlantName);

										get_CtrlVal_APLStateInf(PlantName, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);
										printf("APL GM DML AplRlzdLc:%s\n", AplRlzdLc);
										printf("APL GM DML AplWrkngLC:%s\n", AplWrkngLC);

										if (tc_strcmp(part_clrind, "C") == 0) 
										{
											ITKCALL(GRM_find_relation_type("TC_Is_Represented_By", & RelationFindt));
											ITKCALL(GRM_list_secondary_objects_only(solFoldPartTag[xx], RelationFindt, & ncountBsPart1, & BaseParttag1)); //Solution Item
											if (ncountBsPart1 == 0) 
											{

											  EMH_clear_errors();
											  EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Non color Part is not present,contact PLM Color Part Team");
											  return ITK_errStore1;
											}

										printf("\t  no. of Base 1 parts for Color parts ...%d\n", ncountBsPart1);
										fflush(stdout);
										ITKCALL(AOM_ask_value_string(BaseParttag1[0], "item_id", & BasePART));
										printf("\t  base part num of color is ...%s\n", BasePART);
										fflush(stdout);
										ITKCALL(WSOM_ask_release_status_list(BaseParttag1[0], & Rlsz_count1, & status_listofbase)); // use if condn rls count greater than zeor 
										printf("\n Rlsz_count1--------->>> :%d is\n", Rlsz_count1);
										fflush(stdout);
										
										for (iLCS2 = 0; iLCS2 < Rlsz_count1; iLCS2++) 
										{
										  noncolorcheckFlg = 0;
										  ITKCALL(AOM_ask_value_string(status_listofbase[iLCS2], "object_name", & releasest_name9));
										  printf("\n Object Release Flag: %s\n", releasest_name9);
										  fflush(stdout);

										 
										
										  if (tc_strcmp(releasest_name9, AplRlzdLc) == 0) //	
										  {
												printf("\n \t Non colour part is alreday AplRlzdLc ");
												
												noncolorcheckFlg++;
												break; 
										  } 
										}
										   
											 if (noncolorcheckFlg <= 0 )
											 {
                      
											  
											  printf("\n \t  non colour part is not APL released ");
											  
											  	if (error_cnt==0) 
												{
													
													error_cnt =1;

													printf("\n\t   Inside Error noncolorcheckFlg : %d\n", noncolorcheckFlg);
													
												

													tc_strcpy(NonclrErr, " ");


													tc_strcat(NonclrErr, " Colour part ");

													tc_strcat(NonclrErr, solFoldPartNumber);

													tc_strcat(NonclrErr, " contains non-colour part ");

													tc_strcat(NonclrErr, BasePART);

													tc_strcat(NonclrErr, " , which is not an APL release. Please release the base part first.");

													tc_strcat(NonclrErr, "\n");
 

													printf("\n\t   Inside Error NonclrErr : %s \n", NonclrErr);

												}
												else
												{
													
													tc_strcat(NonclrErr, " Colour part ");

													tc_strcat(NonclrErr, solFoldPartNumber);

													tc_strcat(NonclrErr, " contains non-colour part ");

													tc_strcat(NonclrErr, BasePART);

													tc_strcat(NonclrErr, " , which is not an APL release. Please release the base part first");

													tc_strcat(NonclrErr, "\n");
													
													printf("\n\t   Inside Error NonclrErr : %s \n", NonclrErr);
													
													error_cnt = error_cnt+1;   
													
												}
											
												if(error_cnt==1)
												{
												
													setAddStrFuction11(&i_cnt,&SetOprRelErr,NonclrErr);
													cntFlag = 1;
													
												}
												else
												{
													
													setAddStrFuction11(&i_cnt,&SetOprRelErr,NonclrErr);
													cntFlag = 1;
													
												}
											 }
											  
											

										}
											//printf("\n\t  noncolorcheckFlg : %d  %s \n", noncolorcheckFlg, solFoldPartNumber );
											//if (noncolorcheckFlg > 0) 
											//{

											//}	
									}
									
								}

								if (cntFlag == 0) 
									{
										printf("\n conditions are ok ");fflush(stdout);
									}
									else
									{
										printf("\n\t   Inside Error NonclrErr : %s \n", NonclrErr);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_errStore1, NonclrErr);
										return ITK_errStore1;
												
									}

								//sign off check


							//
							printf("\n CREATE_COLOR_MBOM_APL_PARTS");fflush(stdout);
							CREATE_COLOR_MBOM_APL_PARTS(DmlRevisionTag[0]);fflush(stdout);
							tm_mbom_apl_colour_nonColour_part_synch(DmlRevisionTag[0]); //TZ1.76
						}
						else if((tc_strcmp(releaseType,"Veh")==0)&&(tc_strstr(taskNumber,"_CL_MBOM")!=NULL||tc_strstr(taskNumber,"_CL_APL")!=NULL||tc_strstr(taskNumber,"_00CL_MBOM")!=NULL))
						{
							ITKCALL(GRM_list_secondary_objects_only(DmlRevisionTag[0],relationTag,&count1,&allTaskRevisonTags));
							for(i=0;i<count1;i++)
							{
								ITKCALL(AOM_ask_value_string( allTaskRevisonTags[i], "item_id", &taskNumberfromTag));
								printf("\n MBOM Task Number taskNumberfromTag %s ",taskNumberfromTag);fflush(stdout);
								if(tc_strstr(taskNumberfromTag,"_00_MBOM")!=NULL || tc_strstr(taskNumberfromTag,"_00_APL")!=NULL )
								{
									ITKCALL(AOM_ask_value_tags(allTaskRevisonTags[i], "fnd0ActuatedInteractiveTsks", &numOfWFtasks, &valuesOfWFtasksTag ));
									printf("\n Total Workflow Tasks  %d ",numOfWFtasks);fflush(stdout);
									for(y=0;y<numOfWFtasks;y++)
									{
										ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[y], "fnd0AliasTaskName", &taskName));
										printf("\n  Task taskName %s ",taskName);fflush(stdout);
										ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[y], "task_result", &taskResult));
										printf("\n  Task taskResult %s ",taskResult);fflush(stdout);
										if(tc_strcmp(taskName,"Manager Review")==0 && tc_strcmp(taskResult,"Approved")==0 && tc_strstr(taskNumberfromTag,"_00_MBOM")!=NULL)
										{
											printf("\n MBOM condition calling");fflush(stdout);
											printf("\n Condition is ssatisfy for release type ERC Release... Inside condition");fflush(stdout);
											CREATE_COLOR_MBOM_APL_PARTS(DmlRevisionTag[0]);
											tm_mbom_apl_colour_nonColour_part_synch(DmlRevisionTag[0]); 
											printf("\n Color Part generation completed for the CL Task");fflush(stdout);
											errorFlag=1;
											break;
										}
										else if(tc_strcmp(taskName,"Review The Changes Done By APL Planner")==0 && tc_strcmp(taskResult,"Approved")==0 && tc_strstr(taskNumberfromTag,"_00_APL")!=NULL)
										{
											printf("\n APL condition calling");fflush(stdout);
											printf("\n Condition is ssatisfy for release type ERC Release... Inside condition");fflush(stdout);
											CREATE_COLOR_MBOM_APL_PARTS(DmlRevisionTag[0]);
											tm_mbom_apl_colour_nonColour_part_synch(DmlRevisionTag[0]); 
											printf("\n Color Part generation completed for the CL Task");fflush(stdout);
											errorFlag=1;
											break;	
										}
										else
										{
											printf("\n condition not valid %s \n",taskNumberfromTag);fflush(stdout);
										}
			
									}
								}
								else
								{
									printf("\n base task is not _00_MBOM and _00_APL task");fflush(stdout);
								}
							}
							if(errorFlag==0)
							{
								EMH_clear_errors();
								printf("\n Base task is not release so sync not work......%s \n",taskNumberfromTag);fflush(stdout);
								printf("\n errorFlag value is ......%d \n",taskNumberfromTag);fflush(stdout);
								tc_strcpy(errorMsg, "Please release  Base Task _00_ of DML - ");
								tc_strcat(errorMsg, dmlNumber);
								tc_strcat(errorMsg, " first then complete color task");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
								return ITK_errStore1;
							}
							else
							{
								printf("\n No error");fflush(stdout);
							}
			
						}
						else if((tc_strcmp(mbomreleaseType,"VCREST")==0)&&(tc_strstr(taskNumber,"_00CL_MBOM")!=NULL))
						{
							ITKCALL(GRM_list_secondary_objects_only(DmlRevisionTag[0],relationTag,&count1,&allTaskRevisonTags));
							for(i=0;i<count1;i++)
							{
								printf("\n Aniket");fflush(stdout);
								ITKCALL(AOM_ask_value_string( allTaskRevisonTags[i], "item_id", &taskNumberfromTag));
								printf("\n MBOM Task Number taskNumberfromTag %s ",taskNumberfromTag);fflush(stdout);
								if(tc_strstr(taskNumberfromTag,"MM_MBOM")!=NULL || tc_strstr(taskNumberfromTag,"_00_APL")!=NULL )
								{
									ITKCALL(AOM_ask_value_tags(allTaskRevisonTags[i], "fnd0ActuatedInteractiveTsks", &numOfWFtasks, &valuesOfWFtasksTag ));
									printf("\n Total Workflow Tasks  %d ",numOfWFtasks);fflush(stdout);
									for(y=0;y<numOfWFtasks;y++)
									{
										ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[y], "fnd0AliasTaskName", &taskName));
										printf("\n  Task taskName %s ",taskName);fflush(stdout);
										ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[y], "task_result", &taskResult));
										printf("\n  Task taskResult %s ",taskResult);fflush(stdout);
										if(tc_strcmp(taskName,"Manager Review")==0 && tc_strcmp(taskResult,"Approved")==0 && (tc_strstr(taskNumberfromTag,"_00_MBOM")!=NULL||tc_strstr(taskNumberfromTag,"MM_MBOM")!=NULL))
										{
											printf("\n MBOM condition calling");fflush(stdout);
											printf("\n Condition is ssatisfy for release type ERC Release... Inside condition");fflush(stdout);
											CREATE_COLOR_MBOM_APL_PARTS(DmlRevisionTag[0]);
											tm_mbom_apl_colour_nonColour_part_synch(DmlRevisionTag[0]); 
											printf("\n Color Part generation completed for the CL Task");fflush(stdout);
											errorFlag=1;
											break;
										}
										else if(tc_strcmp(taskName,"Review The Changes Done By APL Planner")==0 && tc_strcmp(taskResult,"Approved")==0 && tc_strstr(taskNumberfromTag,"_00_APL")!=NULL)
										{
											printf("\n APL condition calling");fflush(stdout);
											printf("\n Condition is ssatisfy for release type ERC Release... Inside condition");fflush(stdout);
											CREATE_COLOR_MBOM_APL_PARTS(DmlRevisionTag[0]);
											tm_mbom_apl_colour_nonColour_part_synch(DmlRevisionTag[0]); 
											printf("\n Color Part generation completed for the CL Task");fflush(stdout);
											errorFlag=1;
											break;	
										}
										else
										{
											printf("\n condition not valid %s \n",taskNumberfromTag);fflush(stdout);
										}
			
									}
								}
								else
								{
									printf("\n base task is not _00_MBOM and _00_APL task");fflush(stdout);
								}
							}
							if(errorFlag==0)
							{
								EMH_clear_errors();
								printf("\n Base task is not release so sync not work......%s \n",taskNumberfromTag);fflush(stdout);
								printf("\n errorFlag value is ......%d \n",taskNumberfromTag);fflush(stdout);
								tc_strcpy(errorMsg, "Please release  Base Task _00_ of DML - ");
								tc_strcat(errorMsg, dmlNumber);
								tc_strcat(errorMsg, " first then complete color task");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorMsg);
								return ITK_errStore1;
							}
							else
							{
								printf("\n No error");fflush(stdout);
							}
			
						}
						else
						{
							printf("\n CL Task Condition is not satisfy.");fflush(stdout);
						}
					}
					else
					{
						printf("\n primary object count found 0");fflush(stdout);
					}
				}
			}
		}
		else
		{
			printf("\n control object not found...colorSync");fflush(stdout);
		}
	}
	return ifail;
}

extern int mbom_dml_create_register_method(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 5;
	int retValueType;
	char* objTag = va_arg(args, char*);
		
	if( ITK_ok == EPM_register_action_handler("mbom_dml_create", "", mbom_dml_create))
	{
		printf("n mbom_dml_create action handler registration SUCCESSFULL");fflush(stdout);
	}
   else
   {
		printf("\n mbom_dml_create action handler registration FAILED");fflush(stdout);
   }
   
    if( ITK_ok == EPM_register_action_handler("GMAutoclearence", "", GMAutoclearence))
	{
		printf("n GMAutoclearence action handler registration SUCCESSFULL");fflush(stdout);
	}
   else
   {
		printf("\n GMAutoclearence action handler registration FAILED");fflush(stdout);
   }

    // color code sync handler

	if( ITK_ok == EPM_register_action_handler("mbomDmlColorSyncWithBase", "", mbomDmlColorSyncWithBase))
	{
		printf("n mbomDmlColorSyncWithBase action handler registration SUCCESSFULL");fflush(stdout);
	}
	else
	{
		printf("\n mbomDmlColorSyncWithBase action handler registration FAILED");fflush(stdout);
	}
   
	return ifail;
	
}

extern DLLAPI int tm_mbom_dml_create_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	ifail = CUSTOM_register_exit("tm_mbom_dml_create", "USER_init_module",(CUSTOM_EXIT_ftn_t)mbom_dml_create_register_method);
	return(ITK_ok);
}
