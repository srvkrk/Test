#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <map>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedPtr.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h> /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h> /* for dataset id and rev */
#include <ae/ae_types.h>  /* for dataset id and rev */
#include <unidefs.h>
#include <tccore/tctype.h>

#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>
#include <tccore/tctype.h>
#include <time.h>
#include <cmath>
#include <bits/stdc++.h>

#include <metaframework/BusinessObjectRef.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <mld/logging/TcMainLogger.hxx>

using namespace std;
using namespace Teamcenter;
using Teamcenter::Main::logger;

#define ITK_CALL(x)                                                                 \
    {                                                                               \
        int stat;                                                                   \
        char *err_string;                                                           \
        if ((stat = (x)) != ITK_ok)                                                 \
        {                                                                           \
            EMH_ask_error_text(stat, &err_string);                                  \
            printf("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
            printf("\n FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
            if (err_string)                                                         \
                MEM_free(err_string);                                               \
            exit(EXIT_FAILURE);                                                     \
        }                                                                           \
    }

typedef struct TaskDet
{
    string taskName_s;
    string description_s;
    string WFStatus_s;
    string stage_s;
    string prjCode_s;
    string dsgGrp_s;
    string taskReleaseStat_s;
    string analyst_s;
    string anaReceivedDate_s;
    string anaEndDate_s;
    int anaAge_s;
    string anaCom_s;
    string reviewer_s;
    string revReceivedDate_s;
    string revEndDate_s;
    int revAge_s;
    string revCom_s;
    string dateReleased_s;
    string dmlName_s;
    string dmlReason_s;
    string drStatus_s;
    string dmlReleaseStat_s;
    string APLReleaseDate_s;
    string ecnRelDate_s;
    string partNum_s;
    string epaNo_s;
    string epaLCS_s;
    string epaCreateDate_s;
    string epaTryOutDate_s;
    string epaReleaseDate_s;
    int epaCreateAge_s;
    int epaTryoutAge_s;
    string ecnType_s;
} TaskDet_t;

char *removeJunk(char *in)
{
    // printf("\n Test Inside Function removeChar \n");fflush(stdout);
    int i, j;
    char *tmp;
    tmp = (char *)malloc(strlen(in) + 2);
    i = 0;
    j = 0;
    while (in[j])
    {
        // if (in[j] != '\x01' && in[j] != '\x02')
        if (in[j] != '\n' && in[j] != '\r' && in[j] != '#' && in[j] != '$' && in[j] != ',')
        {
            tmp[i] = in[j];
            i++;
        }
        j++;
    }
    tmp[i] = '\0';
    return tmp;
}

char *subString_DMLBWDate(char *mainStringf, int fromCharf, int toCharf)
{
    int i;
    char *retStringf;
    retStringf = (char *)malloc(200);
    for (i = 0; i < toCharf; i++)
        *(retStringf + i) = *(mainStringf + i + fromCharf);
    *(retStringf + i) = '\0';
    return retStringf;
}

int dateDiff(char *startDate, char *endDate, char *todayDate)
{
    struct tm date1 = {0};
    struct tm date2 = {0};
    // printf("Current Task - %s\n", task);
    // printf("Start Date: %s End date: %s \n", startDate, endDate);

    strptime(startDate, "%d-%b-%Y %H:%M", &date1);

    if (tc_strcmp(startDate, "") == 0)
        return -1;

    if (tc_strcmp(endDate, "") == 0)
        strptime(todayDate, "%d_%b_%Y_%H_%M_%S", &date2);
    else
        strptime(endDate, "%d-%b-%Y %H:%M", &date2);
    // strptime(endDate,"%d_%b_%Y_%H_%M_%S",&date2);

    time_t time1 = mktime(&date1);
    time_t time2 = mktime(&date2);

    double diff = difftime(time2, time1);

    int diffInDays = diff / (24 * 60 * 60);

    printf("Date Diff - %d\n", diffInDays);

    return diffInDays;
    // return 0;
}

int tm_DMLBWDate_Call();

void getReportDetails(set<tag_t> taskNumbers, char *WFname, char *doTask, char *revTask, char *releaseAttr, char *ackTask, char *todayDate, ofstream &outputFile, char *ambienceUsr)
{

    // tag_t taskTag, taskRev;
    int sNo = 0;
    int cntWF;
    tag_t *WFTag;

    tag_t dml;
    tag_t task;

    char *WFObj;

    char *taskName;
    char *desc, *description;
    char *prjCode;
    char *dsgGrp;
    char *taskRelStat, *taskReleaseStat;
    char *dateReleased;

    char *dmlName;
    char *drStatus;
    char *dmlRelStat;
    char *dmlReleaseStat;
    char *APLReleaseDate;
    char *ecnRelDate;
    char *WFStatus;

    int cntDML;
    tag_t *dmlTag;
    int cntTsk;
    tag_t *tskTag;
    char *tskObj;
    int doTskFlg = 0;
    char *analyst, *reviewer, *analysts;

    tag_t DMLtaskRelTag;
    char *anaCompleteDate;
    char *anaReceivedDate;
    char *anaEndDate;
    char *revReceiveDate;
    char *revEndDate;

    char *taskType;

    int anaAge = 0;
    // string doDuration;
    int revAge = 0;
    int within15 = 0;
    int relIn45Days = 0;
    int relIn4515Days = 0;
    // float anaTime = 0;
    // float revTime = 0;

    char *stage;
    char *anaCom;
    char *revCom;

    char *prtNum;
    char *allPrtNum;

    int cntStg;
    tag_t *stgTag;

    int prtCnt;
    tag_t *prtTag = NULLTAG;

    char *part;
    char *revision;
    char *ecnType;
    char *folderChk;

    tag_t EPASolTag;
    int cntEPATsk;
    tag_t *EPATskTag;

    char *objType;

    int cntDMLEPA;
    tag_t *EPADMLTag;

    char *objEPATsk;

    char *epaNum;
    char *epaRel;
    char *epaRels;
    char *epaCreateDate;
    char *epaTryOutDate;
    char *epaReleaseDate;

    int epaCreateAge = 0;
    int epaTryoutAge = 0;

    int cntaplDMLPriTag;
    tag_t *aplDMLPriTag;

    // char *epaInfo;

    char *reviewAPI;
    char *reviewers;

    char *dmlObjType;
    char *dmlReason;

    GRM_find_relation_type("T5_DMLTaskRelation", &DMLtaskRelTag);
    GRM_find_relation_type("CMHasSolutionItem", &EPASolTag);
    // ackDuration = (char *)MEM_alloc(20 * sizeof(char *));
    // doDuration = (char *)MEM_alloc(20 * sizeof(char *));
    // revDuration = (char *)MEM_alloc(20 * sizeof(char *));

    // tc_strcpy(ackDuration,"");
    // tc_strcpy(doDuration,"");
    // tc_strcpy(revDuration,"");

    taskName = (char *)MEM_alloc(100 * sizeof(char *));
    description = (char *)MEM_alloc(100 * sizeof(char *));
    WFStatus = (char *)MEM_alloc(100 * sizeof(char *));
    prjCode = (char *)MEM_alloc(100 * sizeof(char *));
    dsgGrp = (char *)MEM_alloc(100 * sizeof(char *));
    taskRelStat = (char *)MEM_alloc(100 * sizeof(char *));
    taskReleaseStat = (char *)MEM_alloc(100 * sizeof(char *));
    analyst = (char *)MEM_alloc(100 * sizeof(char *));
    anaReceivedDate = (char *)MEM_alloc(100 * sizeof(char *));
    anaEndDate = (char *)MEM_alloc(100 * sizeof(char *));
    anaCom = (char *)MEM_alloc(100 * sizeof(char *));
    reviewer = (char *)MEM_alloc(100 * sizeof(char *));
    reviewers = (char *)MEM_alloc(100 * sizeof(char *));
    revReceiveDate = (char *)MEM_alloc(100 * sizeof(char *));
    revEndDate = (char *)MEM_alloc(100 * sizeof(char *));
    revCom = (char *)MEM_alloc(100 * sizeof(char *));
    dateReleased = (char *)MEM_alloc(100 * sizeof(char *));
    dmlName = (char *)MEM_alloc(100 * sizeof(char *));
    drStatus = (char *)MEM_alloc(100 * sizeof(char *));
    dmlReleaseStat = (char *)MEM_alloc(100 * sizeof(char *));
    APLReleaseDate = (char *)MEM_alloc(100 * sizeof(char *));
    ecnRelDate = (char *)MEM_alloc(100 * sizeof(char *));
    tskObj = (char *)MEM_alloc(100 * sizeof(char *));
    taskType = (char *)MEM_alloc(100 * sizeof(char *));
    stage = (char *)MEM_alloc(100 * sizeof(char *));
    // anaAge = (char *)MEM_alloc(100 * sizeof(char *));
    // revAge = (char *)MEM_alloc(100 * sizeof(char *));
    prtNum = (char *)MEM_alloc(100 * sizeof(char *));
    allPrtNum = (char *)MEM_alloc(50000 * sizeof(char *));
    part = (char *)MEM_alloc(100 * sizeof(char *));
    revision = (char *)MEM_alloc(100 * sizeof(char *));
    epaNum = (char *)MEM_alloc(100 * sizeof(char *));
    epaRel = (char *)MEM_alloc(50000 * sizeof(char *));
    epaRels = (char *)MEM_alloc(100 * sizeof(char *));
    epaCreateDate = (char *)MEM_alloc(100 * sizeof(char *));
    epaTryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
    epaReleaseDate = (char *)MEM_alloc(100 * sizeof(char *));
    reviewAPI = (char *)MEM_alloc(100 * sizeof(char *));
    dmlReason = (char *)MEM_alloc(100 * sizeof(char *));
    // ecnType = (char *)MEM_alloc(100 * sizeof(char *));

    // tc_strcpy(taskName,"");
    // tc_strcpy(description,"");
    // tc_strcpy(WFStatus,"");
    // tc_strcpy(prjCode,"");
    // tc_strcpy(dsgGrp,"");
    // tc_strcpy(taskReleaseStat,"");
    // tc_strcpy(analyst,"");
    // tc_strcpy(anaReceivedDate, "");
    // tc_strcpy(anaEndDate, "");
    // // tc_strcpy(reviewer,"");
    // tc_strcpy(revReceiveDate, "");
    // tc_strcpy(revEndDate, "");
    // tc_strcpy(tskObj, "");
    // tc_strcpy(dateReleased,"");
    // tc_strcpy(dmlName,"");
    // tc_strcpy(drStatus,"");
    // tc_strcpy(dmlReleaseStat,"");
    // tc_strcpy(APLReleaseDate,"");
    // tc_strcpy(ecnRelDate,"");
    // tc_strcpy(taskType, "");

    int totTsk = 0;
    int totTskRel = 0;
    int totToBeRel = 0;
    int totTskRel15 = 0;
    int totTskEx1545 = 0;
    int totTskEx15 = 0;

    set<tag_t>::iterator itr;
    for (itr = taskNumbers.begin(); itr != taskNumbers.end(); itr++)
    {
        // prtTag = NULLTAG;

        // totTsk++;
        tc_strcpy(anaReceivedDate, "");
        tc_strcpy(anaEndDate, "");
        tc_strcpy(revReceiveDate, "");
        tc_strcpy(revEndDate, "");
        tc_strcpy(anaCom, "");
        tc_strcpy(revCom, "");
        tc_strcpy(prtNum, "");
        tc_strcpy(allPrtNum, "");
        tc_strcpy(epaNum, "");
        tc_strcpy(epaRels, "");
        tc_strcpy(epaRel, "");
        tc_strcpy(epaCreateDate, "");
        tc_strcpy(epaTryOutDate, "");
        tc_strcpy(epaReleaseDate, "");
        tc_strcpy(reviewAPI, "");
        tc_strcpy(dmlReason, "");
        sNo++;
        task = *itr;
        ITK_CALL(AOM_ask_value_string(task, "item_id", &taskName));
        printf("Current Task = %s\n", taskName);

        // if(prtTag != NULLTAG)
        //     MEM_free(prtTag);

        if (tc_strcmp(taskName, "22CUG86110_00_MBOM") == 0)
            continue;

        // if (tc_strcmp(taskName, "23CU520010_25_APLP") != 0)
        //    continue;

        ITK_CALL(AOM_ask_value_string(task, "object_desc", &desc));
        STRNG_replace_str(desc, ",", ";", &description);
        printf("Description = %s\n", description);
        ITK_CALL(AOM_ask_value_string(task, "t5_cprojectcode", &prjCode));
        printf("Project Code = %s\n", prjCode);
        ITK_CALL(AOM_ask_value_string(task, "t5_crdesigngroup", &dsgGrp));
        printf("Design Group = %s\n", dsgGrp);
        ITK_CALL(AOM_UIF_ask_value(task, "release_status_list", &taskRelStat));
        STRNG_replace_str(taskRelStat, ",", ";", &taskReleaseStat);
        printf("Release Status = %s\n", taskReleaseStat);
        ITK_CALL(AOM_UIF_ask_value(task, releaseAttr, &dateReleased));
        printf("Release Date = %s\n", dateReleased);

        // ITK_CALL(AOM_ask_value_tags(taskRev, "fnd0AllWorkflows", &cntWF, &WFTag));

        ITK_CALL(GRM_list_primary_objects_only(task, DMLtaskRelTag, &cntDML, &dmlTag));

        dml = dmlTag[0];
        ITK_CALL(AOM_ask_value_string(dml, "item_id", &dmlName));
        printf("DML Name = %s\n", dmlName);
        ITK_CALL(AOM_UIF_ask_value(dml, "t5_cDRstatus", &drStatus));
        printf("DML DR Status = %s\n", drStatus);
        ITK_CALL(AOM_UIF_ask_value(dml, "release_status_list", &dmlRelStat));
        STRNG_replace_str(dmlRelStat, ",", ";", &dmlReleaseStat);
        printf("DML Release Status = %s\n", dmlReleaseStat);
        // ITK_CALL(AOM_UIF_ask_value(dml,"release_status_list ",&dmlRelStat)); //Change to ERC Release date
        ITK_CALL(AOM_UIF_ask_value(dml, "t5_APLReleaseDate", &APLReleaseDate));
        printf("DML APL Release Date = %s\n", APLReleaseDate);
        ITK_CALL(AOM_UIF_ask_value(dml, releaseAttr, &ecnRelDate));
        printf("DML ECN Release Date = %s\n", ecnRelDate);

        if (tc_strstr(dmlName, "AM") != NULL)
        {
            ITK_CALL(AOM_UIF_ask_value(dml, "t5_DmlReasonDisplay", &dmlReason));
            printf("DML Reason: %s", dmlReason);
        }
        else
        {
            ITK_CALL(GRM_list_primary_objects_only(dml, DMLtaskRelTag, &cntaplDMLPriTag, &aplDMLPriTag)); // For ERC DML
            for (int d = 0; d < cntaplDMLPriTag; d++)
            {
                ITK_CALL(AOM_UIF_ask_value(aplDMLPriTag[d], "object_type", &dmlObjType));

                if (tc_strcmp(dmlObjType, "ERC DML Revision") == 0)
                {
                    ITK_CALL(AOM_UIF_ask_value(aplDMLPriTag[d], "t5_reason", &dmlReason));
                    break;
                }

                if (tc_strcmp(dmlObjType, "MBOMDML Revision") == 0)
                {
                    ITK_CALL(GRM_list_primary_objects_only(aplDMLPriTag[d], DMLtaskRelTag, &cntaplDMLPriTag, &aplDMLPriTag)); // For ERC DML
                    for (int a = 0; a < cntaplDMLPriTag; a++)
                    {
                        ITK_CALL(AOM_UIF_ask_value(aplDMLPriTag[a], "object_type", &dmlObjType));
                        if (tc_strcmp(dmlObjType, "ERC DML Revision") == 0)
                        {
                            ITK_CALL(AOM_UIF_ask_value(aplDMLPriTag[a], "t5_reason", &dmlReason));
                            break;
                        }
                    }
                }
            }
        }

        ITK_CALL(AOM_ask_value_tags(task, "fnd0AllWorkflows", &cntWF, &WFTag));

        for (int i = 0; i < cntWF; i++)
        {
            ITK_CALL(AOM_UIF_ask_value(WFTag[i], "object_name", &WFObj));
            printf("WF Object Name = %s\n", WFObj);
            if (tc_strcmp(WFObj, WFname) == 0)
            {
                ITK_CALL(AOM_UIF_ask_value(WFTag[i], "fnd0Status", &WFStatus));
                printf("WFStatus = %s\n", WFStatus);
                if (tc_strcmp(WFStatus, "Completed") == 0)
                {
                    // totTskRel++;
                    // printf("\ntotTskRel-%d\n",totTskRel);
                    tc_strcpy(reviewAPI, "fnd0Performer");
                }
                else
                    tc_strcpy(reviewAPI, "awp0Reviewers");

                printf("reviewer API - %s", reviewAPI);

                ITK_CALL(AOM_ask_value_tags(WFTag[i], "fnd0ActuatedInteractiveTsks", &cntTsk, &tskTag));
                doTskFlg = 0;
                for (int j = 0; j < cntTsk; j++)
                {
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                    printf("tskObj = %s\n", tskObj);
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_type", &taskType));
                    printf("tskObj = %s\n", taskType);
                    if (tc_strcmp(taskType, "Do Task") == 0 || tc_strcmp(taskType, "Review Task") == 0 || tc_strcmp(taskType, "Acknowledge Task") == 0)
                    {

                        if (tc_strcmp(tskObj, ackTask) == 0)
                        {
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &anaReceivedDate));
                            printf("anaReceivedDate = %s\n", anaReceivedDate);
                            // ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0ActualDuration", &ackDuration));
                        }

                        printf("doTask = %s\n", doTask);

                        if (tc_strcmp(tskObj, doTask) == 0)
                        {
                            printf("Inside do task compare\n");
                            doTskFlg++;
                            // ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &anaReceivedDate));
                            // ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &anaCompleteDate_s));
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0Performer", &analyst));
                            printf("analyst = %s\n", analyst);
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0EndDate", &anaEndDate));
                            printf("anaEndDate = %s\n", anaEndDate);
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "comments", &anaCom));
                            printf("anaCom = %s\n", anaCom);
                            // ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0ActualDuration", &doDuration));
                        }
                    }
                }

                for (int j = 0; j < cntTsk; j++)
                {
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_type", &taskType));

                    if (tc_strcmp(taskType, "Do Task") == 0 || tc_strcmp(taskType, "Review Task") == 0 || tc_strcmp(taskType, "Acknowledge Task") == 0)
                    {
                        if (doTskFlg > 0)
                        {
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                            printf("tskObj = %s\n", tskObj);
                            if (tc_strcmp(tskObj, revTask) == 0)
                            {
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], reviewAPI, &reviewers));
                                STRNG_replace_str(reviewers, ",", ";", &reviewer);
                                printf("reviewer = %s\n", reviewer);

                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &revReceiveDate));
                                printf("revReceiveDate = %s\n", revReceiveDate);
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0EndDate", &revEndDate));
                                printf("revEndDate = %s\n", revEndDate);
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "comments", &revCom));
                                printf("revCom = %s\n", revCom);
                                // ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0ActualDuration", &revDuration));
                            }
                        }
                        else
                        {
                            cout << "Inside analyst check from ack task\n";
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                            if (tc_strcmp(tskObj, ackTask) == 0)
                            {
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "awp0Acknowledgers", &analysts));
                                STRNG_replace_str(analysts, ",", ";", &analyst);
                                printf("analyst = %s\n", analyst);
                            }
                        }
                    }
                }
            }
        }

        if (tc_strstr(dmlName, "AM") != NULL)
        {
            ITK_CALL(AOM_UIF_ask_value(dml, "t5_EcnType", &ecnType));
            printf("in AM ECN Type: %s", ecnType);
        }
        else
        {
            ITK_CALL(AOM_UIF_ask_value(dml, "t5_rlstype", &ecnType));
            printf("not in AM ECN Type: %s", ecnType);
        }

        // char *prtTemp;

        if (tc_strcmp(ecnType, "Gate Maturation") == 0 || tc_strcmp(ecnType, "APL Gate Maturation") == 0)
        {
            ITK_CALL(AOM_ask_value_tags(task, "CMReferences", &prtCnt, &prtTag));
            // ITK_CALL(AOM_UIF_ask_value(task, "CMReferences", &prtTemp));
        }
        else
        {
            ITK_CALL(AOM_ask_value_tags(task, "CMHasSolutionItem", &prtCnt, &prtTag));
            // ITK_CALL(AOM_UIF_ask_value(task, "CMHasSolutionItem", &prtTemp));
        }

        printf("\nprtCnt - %d\n", prtCnt);
        // printf("\npart list - %s\n",prtTemp);
        int epaCHK = 0;

        if (prtCnt > 0)
        {
            for (int k = 0; k < prtCnt; k++)
            {

                ITK_CALL(AOM_UIF_ask_value(prtTag[k], "object_type", &folderChk));
                if (tc_strcmp(folderChk, "Folder") == 0)
                    continue;
                ITK_CALL(AOM_UIF_ask_value(prtTag[k], "item_id", &part));
                ITK_CALL(AOM_UIF_ask_value(prtTag[k], "item_revision_id", &revision));

                tc_strcpy(prtNum, "");
                tc_strcat(prtNum, part);
                tc_strcat(prtNum, "/");
                tc_strcat(prtNum, revision);

                if (k == 0)
                    tc_strcat(allPrtNum, prtNum);
                else
                {
                    tc_strcat(allPrtNum, " # ");
                    tc_strcat(allPrtNum, prtNum);
                }

                if (epaCHK == 0)
                {
                    tc_strcpy(epaNum, "");
                    tc_strcpy(epaRel, "");
                    ITK_CALL(GRM_list_primary_objects_only(prtTag[k], EPASolTag, &cntEPATsk, &EPATskTag));
                    // ITK_CALL(GRM_list_primary_objects_only(prtTag[k], DMLtaskRelTag, &cntEPATsk, &EPATskTag));

                    printf("\n  cntEPATsk - %d \n", cntEPATsk);
                    printf("EPA Check for part number - %s\n", part);

                    if (cntEPATsk > 0)
                    {
                        for (int z = 0; z < cntEPATsk; z++)
                        {
                            tc_strcpy(epaNum, "");
                            tc_strcpy(epaRel, "");

                            ITK_CALL(AOM_UIF_ask_value(EPATskTag[z], "object_type", &objType));

                            if (tc_strcmp(objType, "EPA Task Revision") == 0)
                            {
                                ITK_CALL(GRM_list_primary_objects_only(EPATskTag[z], DMLtaskRelTag, &cntDMLEPA, &EPADMLTag));
                                if (cntDMLEPA > 0)
                                {
                                    for (int x = 0; x < cntDMLEPA; x++)
                                    {
                                        ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "object_type", &objEPATsk));

                                        printf("\ncntEPATsk - %d\n", cntDMLEPA);
                                        printf("\nobjType EPA - %s\n", objEPATsk);

                                        if (tc_strcmp(objEPATsk, "EPA Revision") == 0)
                                        {
                                            ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "item_id", &epaNum));
                                            ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "release_status_list", &epaRels));
                                            STRNG_replace_str(epaRels, ",", ";", &epaRel);
                                            ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "creation_date", &epaCreateDate));
                                            ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "t5_Tryout_Stds_Date", &epaTryOutDate));

                                            ITK_CALL(AOM_UIF_ask_value(EPADMLTag[x], "date_released", &epaReleaseDate));

                                            printf("Current EPA - %s\n", epaNum);

                                            if (tc_strcmp(epaNum, "") != 0)
                                            {
                                                if (tc_strcmp(epaReleaseDate, "") == 0)
                                                {
                                                    epaCreateAge = dateDiff(epaCreateDate, "", todayDate);
                                                }
                                                else
                                                {
                                                    epaCreateAge = dateDiff(epaCreateDate, epaReleaseDate, todayDate);
                                                }

                                                if (tc_strcmp(epaReleaseDate, "") == 0)
                                                {
                                                    epaTryoutAge = dateDiff(epaTryOutDate, "", todayDate);
                                                }
                                                else
                                                {
                                                    epaTryoutAge = dateDiff(epaTryOutDate, epaReleaseDate, todayDate);
                                                }
                                            }
                                            // if(z==0)
                                            // {
                                            //     tc_strcat(epaInfo,epaNum);
                                            //     tc_strcat(epaInfo,"->");
                                            //     tc_strcat(epaInfo,epaRel);
                                            // }
                                            // else{
                                            //     tc_strcat(epaInfo," # ");
                                            //     tc_strcat(epaInfo,epaNum);
                                            //     tc_strcat(epaInfo,"->");
                                            //     tc_strcat(epaInfo,epaRel);
                                            // }
                                        }
                                        epaCHK++;
                                        break;
                                    }
                                }
                            }

                            if (epaCHK > 0)
                                break;
                        }
                    }
                }
            }
        }

        printf("allPrtNum: %s\n", allPrtNum);

        if (tc_strcmp(WFStatus, "Completed") == 0)
        {
            tc_strcpy(stage, "Complete");
        }
        else
        {
            ITK_CALL(AOM_ask_value_tags(task, "fnd0StartedWorkflowTasks", &cntStg, &stgTag));
            if (cntStg > 0)
            {
                ITK_CALL(AOM_UIF_ask_value(stgTag[cntStg - 1], "object_name", &stage));
            }
            else
            {
                tc_strcpy(stage, "Error");
            }
        }

        cout << "Before Date Check\n";
        if (tc_strcmp(anaReceivedDate, "") != 0)
            anaAge = dateDiff(anaReceivedDate, anaEndDate, todayDate);
        if (anaAge == 0)
            anaAge = 1;
        cout << "After Analyst Date Check\n";
        if (tc_strcmp(revReceiveDate, "") != 0)
            revAge = dateDiff(revReceiveDate, revEndDate, todayDate);
        if (revAge == 0)
            revAge = 1;
        cout << "After Reviewer Date Check\n";

        within15 = dateDiff(anaReceivedDate, revEndDate, todayDate);

        // cout << "Total Task Released by ECM," << totTskRel << "\n";
        // cout << "Total Task Received at ECM," << totTsk << "\n";
        // totToBeRel = totTsk - totTskRel;
        // cout << "Total Task to be Released by ECM," << totToBeRel << "\n";

        if (tc_strcmp(ambienceUsr, "") != 0)
        {
            if (tc_strstr(analyst, ambienceUsr) == NULL)
            {
                totTsk++;
                if (within15 <= 15)
                {
                    totTskRel15++;
                    cout << "Task Released within 15 Days," << totTskRel15 << "\n";
                }
                if (within15 > 15)
                {
                    totTskEx15++;
                    cout << "Task Released exceed 15 Days in last 45 Days," << totTskEx15 << "\n";
                }
                if (tc_strcmp(revEndDate, "") != 0)
                    relIn45Days = dateDiff(revEndDate, "", todayDate);

                if (relIn45Days <= 45)
                {
                    cout << "Going to check release condition for 45 days for " << taskName << "\n";
                    relIn4515Days = dateDiff(anaReceivedDate, revEndDate, todayDate);
                    cout << "Checked release condition for 45 days\n";
                }

                // if (relIn4515Days > 15)
                if (within15 > 15 && relIn4515Days <= 45)
                {
                    totTskEx1545++;
                    cout << "Task Pending after 15 days," << totTskEx1545 << "\n";
                }

                if (tc_strcmp(WFStatus, "Completed") == 0)
                {
                    totTskRel++;
                    printf("\ntotTskRel-%d\n", totTskRel);
                }
            }
        }
        else
        {
            totTsk++;
            if (within15 <= 15)
            {
                totTskRel15++;
                cout << "Task Released within 15 Days," << totTskRel15 << "\n";
            }
            if (within15 > 15)
            {
                totTskEx15++;
                cout << "Task Released exceed 15 Days in last 45 Days," << totTskEx15 << "\n";
            }
            if (tc_strcmp(revEndDate, "") != 0)
                relIn45Days = dateDiff(revEndDate, "", todayDate);

            if (relIn45Days <= 45)
            {
                cout << "Going to check release condition for 45 days for " << taskName << "\n";
                relIn4515Days = dateDiff(anaReceivedDate, revEndDate, todayDate);
                cout << "Checked release condition for 45 days\n";
            }

            // if (relIn4515Days > 15)
            if (within15 > 15 && relIn4515Days <= 45)
            {
                totTskEx1545++;
                cout << "Task Pending after 15 days," << totTskEx1545 << "\n";
            }

            if (tc_strcmp(WFStatus, "Completed") == 0)
            {
                totTskRel++;
                printf("\ntotTskRel-%d\n", totTskRel);
            }
        }

        cout << "Palash\n";
        TaskDet taskDet;
        taskDet.taskName_s = std::string(taskName);
        cout << "taskDet.taskName_s" << taskDet.taskName_s << "\n";
        taskDet.description_s = std::string(removeJunk(description));
        cout << "taskDet.description_s" << taskDet.description_s << "\n";
        taskDet.WFStatus_s = std::string(WFStatus);
        cout << "taskDet.WFStatus_s" << taskDet.WFStatus_s << "\n";
        taskDet.stage_s = std::string(stage);
        cout << "taskDet.stage_s" << taskDet.stage_s << "\n";
        taskDet.prjCode_s = std::string(prjCode);
        cout << "taskDet.prjCode_s" << taskDet.prjCode_s << "\n";
        taskDet.dsgGrp_s = std::string(dsgGrp);
        cout << "taskDet.dsgGrp_s" << taskDet.dsgGrp_s << "\n";
        taskDet.taskReleaseStat_s = std::string(taskReleaseStat);
        cout << "taskDet.taskReleaseStat_s" << taskDet.taskReleaseStat_s << "\n";
        taskDet.analyst_s = std::string(removeJunk(analyst));
        cout << "taskDet.analyst_s" << taskDet.analyst_s << "\n";
        taskDet.anaReceivedDate_s = std::string(anaReceivedDate);
        cout << "taskDet.anaReceivedDate_s" << taskDet.anaReceivedDate_s << "\n";
        taskDet.anaEndDate_s = std::string(anaEndDate);
        cout << "taskDet.anaEndDate_s" << taskDet.anaEndDate_s << "\n";
        taskDet.anaAge_s = anaAge;
        cout << "Palash 1\n";
        taskDet.anaCom_s = std::string(removeJunk(anaCom));
        taskDet.reviewer_s = std::string(removeJunk(reviewer));
        cout << "Palash 2\n";
        taskDet.revReceivedDate_s = std::string(revReceiveDate);
        taskDet.revEndDate_s = std::string(revEndDate);
        taskDet.revAge_s = revAge;
        cout << "Palash 3\n";
        taskDet.revCom_s = std::string(removeJunk(revCom));
        cout << "Palash 4\n";
        taskDet.dateReleased_s = std::string(dateReleased);
        taskDet.dmlName_s = std::string(dmlName);
        taskDet.dmlReason_s = std::string(removeJunk(dmlReason));
        taskDet.drStatus_s = std::string(drStatus);
        taskDet.dmlReleaseStat_s = std::string(dmlReleaseStat);
        taskDet.APLReleaseDate_s = std::string(APLReleaseDate);
        taskDet.ecnRelDate_s = std::string(ecnRelDate);
        taskDet.partNum_s = std::string(removeJunk(allPrtNum));
        taskDet.epaNo_s = std::string(epaNum);
        cout << "taskDet.epaNo_s" << taskDet.epaNo_s << "\n";
        taskDet.epaLCS_s = std::string(removeJunk(epaRel));
        taskDet.epaCreateDate_s = std::string(epaCreateDate);
        taskDet.epaReleaseDate_s = std::string(epaReleaseDate);
        taskDet.epaCreateAge_s = epaCreateAge;
        taskDet.epaTryoutAge_s = epaTryoutAge;
        taskDet.ecnType_s = ecnType;

        cout << sNo << "," << taskDet.taskName_s << "," << taskDet.description_s << "," << taskDet.WFStatus_s << "," << taskDet.stage_s << "," << taskDet.prjCode_s << "," << taskDet.dsgGrp_s << "," << taskDet.ecnType_s << "," << taskDet.taskReleaseStat_s << "," << taskDet.analyst_s << "," << taskDet.anaReceivedDate_s << "," << taskDet.anaEndDate_s << "," << taskDet.anaAge_s << "," << taskDet.anaCom_s << "," << taskDet.reviewer_s << "," << taskDet.revReceivedDate_s << "," << taskDet.revEndDate_s << "," << taskDet.revAge_s << "," << taskDet.revCom_s << "," << taskDet.dateReleased_s << "," << taskDet.dmlName_s << "," << taskDet.dmlReason_s << "," << taskDet.drStatus_s << "," << taskDet.dmlReleaseStat_s << "," << taskDet.APLReleaseDate_s << "," << taskDet.ecnRelDate_s << "," << taskDet.partNum_s << "," << taskDet.epaNo_s << "," << taskDet.epaLCS_s << "," << taskDet.epaCreateDate_s << "," << taskDet.epaTryOutDate_s << "," << taskDet.epaReleaseDate_s << "," << taskDet.epaCreateAge_s << "," << taskDet.epaTryoutAge_s << "\n";
        outputFile << sNo << "," << taskDet.taskName_s << "," << taskDet.description_s << "," << taskDet.WFStatus_s << "," << taskDet.stage_s << "," << taskDet.prjCode_s << "," << taskDet.dsgGrp_s << "," << taskDet.ecnType_s << "," << taskDet.taskReleaseStat_s << "," << taskDet.analyst_s << "," << taskDet.anaReceivedDate_s << "," << taskDet.anaEndDate_s << "," << taskDet.anaAge_s << "," << taskDet.anaCom_s << "," << taskDet.reviewer_s << "," << taskDet.revReceivedDate_s << "," << taskDet.revEndDate_s << "," << taskDet.revAge_s << "," << taskDet.revCom_s << "," << taskDet.dateReleased_s << "," << taskDet.dmlName_s << "," << taskDet.dmlReason_s << "," << taskDet.drStatus_s << "," << taskDet.dmlReleaseStat_s << "," << taskDet.APLReleaseDate_s << "," << taskDet.ecnRelDate_s << "," << taskDet.partNum_s << "," << taskDet.epaNo_s << "," << taskDet.epaLCS_s << "," << taskDet.epaCreateDate_s << "," << taskDet.epaTryOutDate_s << "," << taskDet.epaReleaseDate_s << "," << taskDet.epaCreateAge_s << "," << taskDet.epaTryoutAge_s << "\n";
        // outputFile<< "\n";
        //  outputFile << totTsk << "," << taskDet.taskName_s << "," << taskDet.description_s << "," << taskDet.WFStatus_s << "," << taskDet.stage_s << "," << taskDet.prjCode_s << "," << taskDet.dsgGrp_s << "," << taskDet.taskReleaseStat_s << "," << taskDet.analyst_s << "," << taskDet.anaReceivedDate_s << "," << taskDet.anaEndDate_s << "," << taskDet.anaAge_s << "," << taskDet.anaCom_s << "," << taskDet.reviewer_s << "," << taskDet.revReceivedDate_s << "," << taskDet.revEndDate_s << "," << taskDet.revAge_s << "," << taskDet.revCom_s << "," << taskDet.dateReleased_s << "," << taskDet.dmlName_s << "," << taskDet.drStatus_s << "," << taskDet.dmlReleaseStat_s << "," << taskDet.APLReleaseDate_s << "," << taskDet.ecnRelDate_s << "," << taskDet.partNum_s <<  "," << taskDet.epaInfo_s << "\n";
    }

    cout << "\n";
    outputFile << "\n";

    cout << ",,Total Task Received at ECM," << totTsk << "\n";
    outputFile << ",,Total Task Received at ECM," << totTsk << "\n";

    cout << ",,Total Task Released by ECM (A)," << totTskRel << "\n";
    outputFile << ",,Total Task Released by ECM (A)," << totTskRel << "\n";

    totToBeRel = totTsk - totTskRel;
    cout << ",,Total Task to be Released by ECM," << totToBeRel << "\n";
    outputFile << ",,Total Task to be Released by ECM," << totToBeRel << "\n";

    cout << ",,Task Released within 15 Days (B)," << totTskRel15 << "\n";
    outputFile << ",,Task Released within 15 Days (B)," << totTskRel15 << "\n";

    cout << ",,Task Released exceed 15 Days in last 45 Days," << totTskEx1545 << "\n";
    outputFile << ",,Task Released exceed 15 Days in last 45 Days," << totTskEx1545 << "\n";

    cout << ",,Task Pending after 15 days (C)," << totTskEx15 << "\n";
    outputFile << ",,Task Pending after 15 days (C)," << totTskEx15 << "\n";

    cout << ",,Efficiency (B*100/(A-C))," << (totTskRel15 * 100 / (totTskRel - totTskEx15)) << "\n";
    outputFile << ",,Efficiency (B*100/(A-C))," << (totTskRel15 * 100 / (totTskRel - totTskEx15)) << "\n";
}

int ITK_user_main(int argc, char *argv[])
{

    // ./tm_DMLBWDate -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -fd=20-Apr-2024 -td=27-Apr-2024 -agen=STDSI
    printf("*****************Inside main start***********************");
    char *fromDate = ITK_ask_cli_argument("-fd="); // from date
    char *toDate = ITK_ask_cli_argument("-td=");   // to date
    char *agency = ITK_ask_cli_argument("-agen="); // release status
    char *plant = ITK_ask_cli_argument("-plant="); // plant
    char *mail = ITK_ask_cli_argument("-mail=");   // mail
    char *csvName = ITK_ask_cli_argument("-fileName=");
    // char *doTask,*revTask,WFname;
    set<tag_t> taskNumbers;
    char *WFname, *doTask, *revTask, *releaseAttr, *ackTask;
    char *owningGrp = (char *)MEM_alloc(10);
    char *aplTsk = (char *)MEM_alloc(10);
    char *stdTsk = (char *)MEM_alloc(10);
    char *tskName;
    char *analyst;
    char *ambienceUsr;

    tc_strcpy(aplTsk, "APL");
    tc_strcpy(stdTsk, "STD");
    printf("\nAPL Name %s\n", aplTsk);
    tc_strcat(stdTsk, owningGrp);
    printf("\nSTDSI Name %s\n", stdTsk);

    tc_strcpy(owningGrp, subString_DMLBWDate(plant, 0, 1));
    cout << " Inside for1\n";
    tc_strcat(aplTsk, owningGrp);

    char *FileName = (char *)MEM_alloc(100 * sizeof(char *));
    char reportFireDate[100] = "";

    time_t now;
    struct tm when;
    time(&now);
    when = *localtime(&now);
    strftime(reportFireDate, 100, "%d_%b_%Y_%H_%M_%S", &when);
    ofstream outputFile;
    // FILE *outputFile;
    // sprintf(FileName, "DML_Report_%s.csv", reportFireDate);
    tc_strcpy(FileName, csvName);

    printf("From date - %s\n", fromDate);
    fflush(stdout);
    printf("To date - %s\n", toDate);
    fflush(stdout);
    printf("Agency - %s\n", agency);
    fflush(stdout);
    printf("Report Fire Date - %s\n", reportFireDate);
    fflush(stdout);
    printf("File name = %s\n", FileName);

    // exit(0);

    printf("\n*****Before Login******\n");
    ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
    //  ITK_init_module("mhn03162","XYT1ESA" ,"");
    ITK_auto_login();
    ITK_set_bypass(true);
    ITK_set_journalling(TRUE);
    printf("\n*****Login Successful******\n");

    // Control Object for all information wrt Agency
    char *qryAgencyInfo[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qryAgencyValues[3] = {"DMLBWRPT", agency, "0"};

    tag_t qryTagAgency = NULLTAG;
    int qryCountA = 0;
    tag_t *qryResultA = NULLTAG;

    ITKCALL(QRY_find2("Control Objects...", &qryTagAgency));
    if (qryTagAgency)
    {
        printf("\n Control Object Query Found \n ");
        fflush(stdout);
        ITKCALL(QRY_execute(qryTagAgency, 3, qryAgencyInfo, qryAgencyValues, &qryCountA, &qryResultA));

        if (qryCountA > 0)
        {
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo1", &WFname);      // STDSI Task BreakDown
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo2", &doTask);      // Create EPA
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo3", &revTask);     // Review the Changes
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo4", &releaseAttr); // date_released
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo5", &ackTask);     // Acknowledge Task
        }
    }
    // Control Object for all information wrt Agency - Code Ends

    // Control Object for all ambience users
    char *qryAmbienceInfo[4] = {"Name", "SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qryAmbienceValues[4] = {"DMLBWRPT", agency, plant, "0"};

    // tag_t qryTagAmbience = NULLTAG;
    int qryCountAmb = 0;
    tag_t *qryResultAmb = NULLTAG;

    ITKCALL(QRY_find2("Control Objects...", &qryTagAgency));
    if (qryTagAgency)
    {
        printf("\n Control Object Query Found \n ");
        fflush(stdout);
        ITKCALL(QRY_execute(qryTagAgency, 4, qryAmbienceInfo, qryAmbienceValues, &qryCountAmb, &qryResultAmb));

        if (qryCountAmb > 0)
        {
            AOM_ask_value_string(qryResultAmb[0], "t5_Userinfo1", &ambienceUsr); // Ambience User
            printf("\n ambienceUsr - %s\n", ambienceUsr);
        }
    }
    // Control Object for all ambience users

    outputFile.open(FileName);

    cout << "From Date:," << fromDate << "\n";
    cout << "To Date:," << toDate << "\n";
    cout << "Agency:," << agency << "\n";
    cout << "Plant:," << plant << "\n";

    outputFile << "From Date:," << fromDate << "\n";
    outputFile << "To Date:," << toDate << "\n";
    outputFile << "Agency:," << agency << "\n";
    outputFile << "Plant:," << plant << "\n";

    // fprintf(outputFile, "S.No,Task Number,Task Description,Workflow Status,Project Code, Design Group,Task Release Status,Task Received Date,Task Release Date,Analyst,Reviewer,DML Number,DML DR Status,DML Release Status,DML APL Release Date,DML ECM Release Date\n");
    // fflush(outputFile);
    outputFile << "\n";
    outputFile << "S.No,Task Number,Task Description,Workflow Status,Stage,Project Code,Design Group,Release Type,Task Release Status,Analyst,Analyst Received Date,Analyst End Date,Analyst Task Age,Analyst Comments,Reviewer,Reviewer Received Date,Reviewer End Date,Reviewer Task Age,Reviewer Comments,Task Release Date,DML Number,DML Reason,DML DR Status,DML Release Status,DML APL Release Date,DML ECM Release Date,Attached Part(s),EPA Number,EPA Release Status,EPA Creation Date,EPA Tryout Date,EPA Release Date,EPA Age from Creation Date,EPA Age from TryOut Date\n";

    if (qryCountA > 0)
    {
        char **qry_entries = (char **)MEM_alloc(10 * sizeof(char *));
        char **qry_values = (char **)MEM_alloc(10 * sizeof(char *));
        tag_t queryTag = NULLTAG;
        qry_entries[0] = "WF_name";
        qry_entries[1] = "Created After";
        qry_entries[2] = "Created Before";

        qry_values[0] = WFname;
        qry_values[1] = fromDate;
        qry_values[2] = toDate;

        char *keys[1] = {(char *)"fnd0StartDate"};
        int orders[1] = {2};

        int countWF;
        tag_t *resultWF;

        ITK_CALL(QRY_find2("EPMTaskWF", &queryTag));
        ITK_CALL(QRY_execute_with_sort(queryTag, 3, qry_entries, qry_values, 1, keys, orders, &countWF, &resultWF));

        char *TaskObj, *taskType;
        tag_t WFTag;
        int cntTask;
        tag_t *taskTag;

        if (countWF > 0)
        {
            for (int i = 0; i < countWF; i++)
            {

                WFTag = resultWF[i];
                ITK_CALL(AOM_UIF_ask_value(WFTag, "task_type", &taskType));
                if (tc_strcmp(taskType, "EPMDoTask") == 0 || tc_strcmp(taskType, "EPMPerformSignoffTask") == 0 || tc_strcmp(taskType, "EPMAcknowledgeTask") == 0)
                {
                    // cout << " Inside for\n";
                    ITK_CALL(AOM_UIF_ask_value(WFTag, "object_name", &TaskObj));

                    if (tc_strcmp(TaskObj, doTask) == 0 || tc_strcmp(TaskObj, revTask) == 0)
                    {
                        ITK_CALL(AOM_UIF_ask_value(WFTag, "root_target_attachments", &tskName));
                        ITK_CALL(AOM_UIF_ask_value(WFTag, "fnd0Performer", &analyst));
                        printf("analyst = %s\n", analyst);

                        if (tc_strstr(tskName, aplTsk) != NULL)
                        {
                            // if(qryCountAmb > 0)
                            // {
                            // if(tc_strstr(analyst,ambienceUsr) == NULL)
                            // {
                            ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
                            taskNumbers.insert(taskTag[0]);
                            // }
                            // }
                            // else
                            // {
                            //     ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
                            //     taskNumbers.insert(taskTag[0]);
                            // }
                        }

                        if (tc_strcmp(agency, "STDSI") == 0)
                        {

                            if (tc_strstr(tskName, stdTsk) != NULL)
                            {
                                // if(qryCountAmb > 0)
                                // {
                                // if(tc_strstr(analyst,ambienceUsr) == NULL)
                                // {
                                ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
                                taskNumbers.insert(taskTag[0]);
                                // }
                                // }
                                // else
                                // {
                                //     ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
                                //     taskNumbers.insert(taskTag[0]);
                                // }
                            }
                        }
                    }
                }
            }
            getReportDetails(taskNumbers, WFname, doTask, revTask, releaseAttr, ackTask, reportFireDate, outputFile, ambienceUsr);
        }
        else
            printf("No Workflow Available");
    }
    else
        printf("Agency information not available");

    // set<tag_t>::iterator itr;
    // for (itr = taskNumbers.begin(); itr != taskNumbers.end(); itr++)
    // {
    //     tag_t task = *itr;
    //     char *taskName;
    //     AOM_ask_value_string(task,"item_id",&taskName);

    // outputFile << std::string(taskName)<<"\n";
    // }
    fflush(stdout);

    outputFile.close();
    return 0;
}

int tm_DMLBWDate_Call(void *return_data)
{
    // Variable Decleration
    int ifail = ITK_ok;
    // tag_t rev = NULLTAG;
    char *fromDate = NULL;
    char *toDate = NULL;
    char *plant = NULL;
    char *agency = NULL;
    char *mail = NULL;

    // char *inp_RemoveUnderscorePart	= NULL;
    // char *inp_Plant					= NULL;
    // char *inp_StopatF				= NULL;
    // char *inp_SkipZeroQty			= NULL;
    // char *inp_sup			        = NULL;
    // char *mailLOV                   = NULL;
    // char *output					= NULL;

    // output = (char *) MEM_alloc( 1000 * sizeof(char) );

    // USERARG_get_tag_argument(&rev);									// rev
    USERARG_get_string_argument(&fromDate); // fromDate
    USERARG_get_string_argument(&toDate);   // toDate
    USERARG_get_string_argument(&plant);    // plant
    USERARG_get_string_argument(&agency);   // agency
    USERARG_get_string_argument(&mail);     // mail
    // USERARG_get_string_argument(&inp_RemoveUnderscorePart);			// inp_RemoveUnderscorePart
    // USERARG_get_string_argument(&inp_Plant);						// inp_Plant
    // USERARG_get_string_argument(&inp_StopatF);						// inp_StopatF
    // USERARG_get_string_argument(&inp_SkipZeroQty);					// inp_SkipZeroQty
    // USERARG_get_string_argument(&inp_sup);					        // inp_sup
    // USERARG_get_string_argument(&mailLOV);

    // tc_strcpy(output,"");

    // Control Object for EXE
    char *qry_entries[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qry_values[3] = {"DMLBWRPT", "REPORTPATH", "0"};

    tag_t qryTag = NULLTAG;
    int query_count;
    tag_t *query_result = NULLTAG;

    ITK_CALL(QRY_find2("Control Objects...", &qryTag));

    if (qryTag)
    {
        printf("\n Control Object Query Found \n");
        fflush(stdout);

        ITK_CALL(QRY_execute(qryTag, 3, qry_entries, qry_values, &query_count, &query_result));

        printf("\n query_count is : %d\n", query_count);
        fflush(stdout);

        if (query_count > 0)
        {
            char *t5_Userinfo1 = NULL;
            char cmd[500];
            tag_t obj = query_result[0];
            ITK_CALL(AOM_ask_value_string(obj, "t5_Userinfo1", &t5_Userinfo1));
            sprintf(cmd, "%s/DMLBWDateEXE.sh %s %s %s %s %s &", t5_Userinfo1, fromDate, toDate, plant, agency, mail);
            // sprintf(cmd,"%s -if=%s -im=%s &",t5_Userinfo1,VCList,MailList);
            printf("Excuting Command = %s", cmd);
            fflush(stdout);
            system(cmd);
            printf("After executing Command");
            fflush(stdout);
        }
    }

    // printf("output:%s",output);

    // *((char **) return_data) =
    // 		   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

    // 		strcpy( *((char **) return_data), output);

    return ifail;
}
extern int AllUserServiceFnDMLBWDateFtn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    int nargs = 5;
    int retValueType;
    int inputArgTypes[5] = {0};

    // int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
    //  Refer ict_userservice.h for more arg types
    inputArgTypes[0] = USERARG_STRING_TYPE; // From DATE
    inputArgTypes[1] = USERARG_STRING_TYPE; // To Date
    inputArgTypes[2] = USERARG_STRING_TYPE; // plant
    inputArgTypes[3] = USERARG_STRING_TYPE; // Agency
    inputArgTypes[4] = USERARG_STRING_TYPE; // mail

    // inputArgTypes[4] = USERARG_STRING_TYPE;  // RemoveUnderscore
    // inputArgTypes[5] = USERARG_STRING_TYPE;  // inp_Plant
    // inputArgTypes[6] = USERARG_STRING_TYPE;  // inp_StopatF
    // inputArgTypes[7] = USERARG_STRING_TYPE;  // inp_SkipZeroQty
    // inputArgTypes[8] = USERARG_STRING_TYPE;  // inp_supp
    // inputArgTypes[9] = USERARG_STRING_TYPE;  // mailLOV

    retValueType = USERARG_STRING_TYPE;
    printf("\n AllUserServiceFnDMLBWDateFtn before....AllUserServiceFnDMLBWDateFtn");
    fflush(stdout);
    ifail = USERSERVICE_register_method("tm_DMLBWDate_Call", (USER_function_t)tm_DMLBWDate_Call, nargs, inputArgTypes, retValueType);

    return ifail;
}

extern "C" DLLAPI int tm_DMLBWDate_register_callbacks()
{

    int ifail = ITK_ok;
    printf("\n Before registoring userservice....tm_DMLBWDate");
    fflush(stdout);
    ifail = CUSTOM_register_exit("tm_DMLBWDate", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnDMLBWDateFtn);
    printf("\n After registoring userservice....tm_DMLBWDate");
    fflush(stdout);
    return (ITK_ok);
}