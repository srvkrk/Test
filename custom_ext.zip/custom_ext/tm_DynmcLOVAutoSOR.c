//home/uadev/TC_ROOT/pool_manager/confs/Development/ tail -f nohup.out
#include<stdlib.h>
#include<stdarg.h>
#include<tc/tc.h>
#include <tc/emh.h>
#include <tc/iman.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <ict/ict_userservice.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "bapi.h"
#include "sapstr.h"
#include "t.h"
#include "wmhelpe.h"
#include "ppe.h"
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <user_exits/user_exits.h>

RFC_HANDLE BapiLogonPD(void);
RFC_HANDLE BapiLogonPQ(void);
RFC_HANDLE BapiLogon(void);

void  rfc_error(char *operation);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);
char* Ask_lov_type_function(char* input);
extern DLLAPI int autosor_createpost_method_1(METHOD_message_t *m, va_list args);
void trimTrailing(char * str);

RFC_HANDLE BapiLogon(void)
{
	static RFC_OPTIONS RfcOptions;
	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

    RfcOptions.destination ="PP8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="p690";
	RfcConnoptR3only.gateway_host="p690";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;		//Production Server

	printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname); fflush(stdout);
	TC_write_syslog("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname); fflush(stdout);
	hRfc= RfcOpen(&RfcOptions);
	if (hRfc == RFC_HANDLE_NULL)
	{
		printf("\nERROR RECEIVED CPIC-ERROR"); fflush(stdout);
		TC_write_syslog("\nERROR RECEIVED CPIC-ERROR"); fflush(stdout);
		exit(0);
	}
	else
	{
		printf("\nGot the connection!!!"); fflush(stdout);
		TC_write_syslog("\nGot the connection!!!"); fflush(stdout);
		RfcEnvironment(&RfcEnv);
	}

	return hRfc;
}

RFC_RC ZSTAR_PROJECT_DETAIL(RFC_HANDLE hRfc,ZZSRM_PROJECT_CODE *eIV_ZZSRM_PROJECT_CODE,
								ZSRM_PROJECT_PLATFORM *eIV_ZSRM_PROJECT_PLATFORM,
								ZSRM_PROJECT_LINE			*eIV_ZSRM_PROJECT_LINE,
								ZSRM_PROJECT_MANUF_LOC		*eIV_ZSRM_PROJECT_MANUF_LOC,
								ZSRM_BUSINESS_UNIT	        *eIV_ZSRM_BUSINESS_UNIT,
								COMT_CHECKBOX		        *eIV_COMT_CHECKBOX,
								ITAB_H				        thZSRM_PROJECT_DETAIL,
								ITAB_H				        thZSRM_PROJECT_VARIANT,
								char				*xException
							)
{
	RFC_PARAMETER Exporting[6];
	RFC_PARAMETER Importing[1];
	RFC_TABLE Tables[3];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "IV_PROJECT_CODE";
	Exporting[0].nlen = 15;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(ZZSRM_PROJECT_CODE);
	Exporting[0].addr = eIV_ZZSRM_PROJECT_CODE;

	Exporting[1].name = "IV_PLATFORM";
	Exporting[1].nlen = 11;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(ZSRM_PROJECT_PLATFORM);
	Exporting[1].addr = eIV_ZSRM_PROJECT_PLATFORM;

	Exporting[2].name = "IV_LINE";
	Exporting[2].nlen = 7;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(ZSRM_PROJECT_LINE);
	Exporting[2].addr = eIV_ZSRM_PROJECT_LINE;

	Exporting[3].name = "IV_MANUF_LOC";
	Exporting[3].nlen = 12;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(ZSRM_PROJECT_MANUF_LOC);
	Exporting[3].addr = eIV_ZSRM_PROJECT_MANUF_LOC;

	Exporting[4].name = "IV_BUSINESS_UNIT";
	Exporting[4].nlen = 16;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(ZSRM_BUSINESS_UNIT);
	Exporting[4].addr = eIV_ZSRM_BUSINESS_UNIT;

	Exporting[5].name = "IV_DELTA";
	Exporting[5].nlen = 8;
	Exporting[5].type = TYPC;
	Exporting[5].leng = sizeof(COMT_CHECKBOX);
	Exporting[5].addr = eIV_COMT_CHECKBOX;

	Exporting[6].name = NULL;

    Tables[0].name     = "T_PROJECT_HEADER";
    Tables[0].nlen     = 16;
    Tables[0].type     = handleOfZSRM_PROJECT_DETAIL;
    Tables[0].ithandle = thZSRM_PROJECT_DETAIL;

	Tables[1].name     = "T_PROJECT_VARIANT";
    Tables[1].nlen     = 17;
    Tables[1].type     = handleOfZSRM_PROJECT_DETAIL;
    Tables[1].ithandle = thZSRM_PROJECT_VARIANT;

    Tables[2].name = NULL;


	RfcRc = RfcCall(hRfc,"ZSTAR_PROJECT_DETAIL",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			
			Importing[0].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		break;
		default:
			printf("\nNOT RFC OK");
			TC_write_syslog("\nNOT RFC OK");
		break;
	}
	return RfcRc;
}



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
int tm_PPPMPrjLovSorMethod( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag  = va_arg(args, const tag_t);
	int* n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	int error_code = ITK_ok;
	int i = 0;
	int pppmcnt = 0;
	int variantcnt = 0;
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	int crow1=0;
	int crow2=1;
	char xException[256];
	char* prjcode = NULL;
	char desc[50] = { 0 };
	char prodflag[3] = { 0 };
	char pltform[11] = { 0 };
	char busunit[11] = { 0 };
	char prjcode1[25] = { 0 };
	char var[17] = { 0 };
	char varname[21] = { 0 };
	char prodstatus[51] = { 0 };
	char mandt[4] = { 0 };
	char line[10] = { 0 };
	char becnhmark[51] = { 0 };
	char location[51] = { 0 };
	int iProjectCodeCnt = 0;
	int iCnt = 0;
	ZZSRM_PROJECT_CODE			eIV_ZZSRM_PROJECT_CODE;
	ZSRM_PROJECT_PLATFORM	    eIV_ZSRM_PROJECT_PLATFORM;
	ZSRM_PROJECT_LINE			eIV_ZSRM_PROJECT_LINE;
	ZSRM_PROJECT_MANUF_LOC		eIV_ZSRM_PROJECT_MANUF_LOC;
	ZSRM_BUSINESS_UNIT	        eIV_ZSRM_BUSINESS_UNIT;
	COMT_CHECKBOX		        eIV_COMT_CHECKBOX;
	ITAB_H	thZSRM_PROJECT_DETAIL=ITAB_NULL;
	ZSRM_PROJECT_DETAIL *tProjectDetails;
	ITAB_H	thZSRM_PROJECT_VARIANT=ITAB_NULL;
	ZSRM_PROJECT_VARIANT *tVariantDetails;
	*n_values = 1;

	
	hRfc = BapiLogon();

	printf("\nZSTAR_PROJECT_DETAIL function PPP project code details\n"); fflush(stdout); 
	TC_write_syslog("\nZSTAR_PROJECT_DETAIL function PPP project code details\n"); fflush(stdout); 
	
	thZSRM_PROJECT_DETAIL = ITAB_NULL;

	if (thZSRM_PROJECT_DETAIL==ITAB_NULL)
	{
		thZSRM_PROJECT_DETAIL = ItCreate("IT_PROJECT_DETAILS",sizeof(ZSRM_PROJECT_DETAIL),0,0);
		if (thZSRM_PROJECT_DETAIL==ITAB_NULL)
			rfc_error("ItCreateIT_PROJECT_DETAILS");

	}
	else
	{

		if (ItFree(thZSRM_PROJECT_DETAIL) != 0)
			rfc_error("ItFreeIT_PROJECT_DETAILS");
	}

    thZSRM_PROJECT_VARIANT = ITAB_NULL;

	if (thZSRM_PROJECT_VARIANT==ITAB_NULL)
	{
		thZSRM_PROJECT_VARIANT = ItCreate("IT_PROJECT_VARIANT",sizeof(ZSRM_PROJECT_VARIANT),0,0);
		if (thZSRM_PROJECT_VARIANT==ITAB_NULL)
			rfc_error("ItCreateIT_PROJECT_VARIANT");

	}
	else
	{

		if (ItFree(thZSRM_PROJECT_VARIANT) != 0)
			rfc_error("ItFreeIT_PROJECT_VARIANT");
	}

	SETCHAR(eIV_ZZSRM_PROJECT_CODE.ZZSRM_PROJECT_CODE,"");
	SETCHAR(eIV_ZSRM_PROJECT_PLATFORM,"");
	SETCHAR(eIV_ZSRM_PROJECT_LINE,"");
	SETCHAR(eIV_ZSRM_PROJECT_MANUF_LOC,"");
	SETCHAR(eIV_ZSRM_BUSINESS_UNIT,"");
	SETCHAR(eIV_COMT_CHECKBOX,"");

	printf("\ncll_ZSTAR_BARREL_PROJECT_GETDETAIL function111\n"); fflush(stdout);
	TC_write_syslog("\ncll_ZSTAR_BARREL_PROJECT_GETDETAIL function111\n"); fflush(stdout);

	RfcRc = ZSTAR_PROJECT_DETAIL(hRfc,&eIV_ZZSRM_PROJECT_CODE,&eIV_ZSRM_PROJECT_PLATFORM,&eIV_ZSRM_PROJECT_LINE,&eIV_ZSRM_PROJECT_MANUF_LOC,&eIV_ZSRM_BUSINESS_UNIT,&eIV_COMT_CHECKBOX,thZSRM_PROJECT_DETAIL,thZSRM_PROJECT_VARIANT,xException);
		
	printf("\nNo. of records [ %d ] found in BAPI 'thZSRM_PROJECT_DETAIL'\n",ItFill(thZSRM_PROJECT_DETAIL)); fflush(stdout);
	TC_write_syslog("\nNo. of records [ %d ] found in BAPI 'thZSRM_PROJECT_DETAIL'\n",ItFill(thZSRM_PROJECT_DETAIL)); fflush(stdout);

	
	if (ItFill(thZSRM_PROJECT_DETAIL)>0)
	{
		switch (RfcRc)
		{
			case RFC_OK:
				  
				
				iProjectCodeCnt = ItFill(thZSRM_PROJECT_DETAIL);

				printf("\n*********PPPM PROJECT_DETAILS************%d",iProjectCodeCnt);fflush(stdout);
				TC_write_syslog("\n*********PPPM PROJECT_DETAILS************%d",iProjectCodeCnt);fflush(stdout);


				if( iProjectCodeCnt <= 0 )
				{
					printf("\nNo PPPM project found"); fflush(stdout);
					TC_write_syslog("\nNo PPPM project found"); fflush(stdout);
					return iProjectCodeCnt;
				}
				
				*n_values = iProjectCodeCnt;
				*values = (char **)MEM_alloc (*n_values * sizeof(char*));
								
				for (crow1 = 1;crow1 <= ItFill(thZSRM_PROJECT_DETAIL); crow1++)
				{
						tProjectDetails = ItGetLine(thZSRM_PROJECT_DETAIL,crow1);
						if (tProjectDetails == NULL)
						{
							printf("ItCreateIT_PROJECT_HEADER");fflush(stdout);
							TC_write_syslog("ItCreateIT_PROJECT_HEADER");fflush(stdout);
						}

						prjcode = (char*) MEM_alloc(50);

						GETCHAR(tProjectDetails->PROJ_CODE,prjcode);prjcode[strlen(prjcode)] = '\0';
						GETCHAR(tProjectDetails->DISCRIPTION,desc); desc[strlen(desc)] = '\0';
						(*values)[crow1-1] = (char *) MEM_alloc (50);
						tc_strcpy((*values)[crow1-1], prjcode);
				
				}
			break;
			case RFC_EXCEPTION:
				printf("\nRFC EXCEPTION: %s",xException);
			break;
			case RFC_SYS_EXCEPTION:
				printf("\nSystem Exception Raised!!!");
			break;
			case RFC_FAILURE:
				printf("\nFailure!!!");
			break;
			default:
				printf("\nOther Failure!");
			break;
		}
		if (ItDelete(thZSRM_PROJECT_VARIANT) != 0) rfc_error("ItDelete thZSRM_PROJECT_VARIANT");
		if (ItDelete(thZSRM_PROJECT_DETAIL) != 0) rfc_error("ItDelete thZSRM_PROJECT_DETAIL");
	}
	RfcClose(hRfc);
	return error_code;
}

extern int tm_SorLovPopulate_method (int *decision, va_list args)
{
	int	ifail = 0;
	METHOD_id_t  method;

	if( ifail == ITK_ok )
    {
		TC_write_syslog("\nregistering T5_PPPMPrjCodeLOVType");
		printf("\nregistering T5_PPPMPrjCodeLOVType");
        ITK_CALL(METHOD_register_method( "T5_PPPMPrjCodeLOVType",LOV_ask_values_msg, &tm_PPPMPrjLovSorMethod,  0, &method));
    }
	
	ITK_CALL(METHOD_find_method("Item",TC_save_msg,&method));

	printf("\nRegistered autosor");fflush(stdout);
	TC_write_syslog("\nRegistered autosor");fflush(stdout);
    if (method.id != NULLTAG)
    {
        ITK_CALL(METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) autosor_createpost_method_1, NULL) );
		printf("\nRegistered as Post-Action for Creation autosor\n");fflush(stdout);
		TC_write_syslog("\nRegistered as Post-Action for Creation autosor\n");fflush(stdout);
    }
    else
        printf("\nautosor create post Method not found!\n");fflush(stdout);
        TC_write_syslog("\nautosor create post Method not found!\n");fflush(stdout);

	return ifail;
}
extern DLLAPI int autosor_createpost_method_1(METHOD_message_t *m, va_list args)
{
	tag_t objTypeTag;
	tag_t objTag;
	char type_name[TCTYPE_name_size_c+1];
	tag_t objTagMaster = va_arg(args, tag_t);

	ITK_CALL(ITEM_ask_latest_rev(objTagMaster, &objTag));
	ITK_CALL(TCTYPE_ask_object_type(objTag,&objTypeTag));
	ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\ntype_name:%s",type_name);fflush(stdout);
	TC_write_syslog("\ntype_name:%s",type_name);fflush(stdout);
	if(strcmp(type_name,"T5_AutoSorRevision")==0)
	{
		setVariantNameIdValue(&objTag);
	}
	return ITK_ok;
}
int setVariantNameIdValue(tag_t *objTag)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];
	ZZSRM_PROJECT_CODE			eIV_ZZSRM_PROJECT_CODE;
	ZSRM_PROJECT_PLATFORM	    eIV_ZSRM_PROJECT_PLATFORM;
	ZSRM_PROJECT_LINE			eIV_ZSRM_PROJECT_LINE;
	ZSRM_PROJECT_MANUF_LOC		eIV_ZSRM_PROJECT_MANUF_LOC;
	ZSRM_BUSINESS_UNIT	        eIV_ZSRM_BUSINESS_UNIT;
	COMT_CHECKBOX		        eIV_COMT_CHECKBOX;
	ITAB_H	thZSRM_PROJECT_DETAIL=ITAB_NULL;
	ZSRM_PROJECT_DETAIL *tProjectDetails;
	ITAB_H	thZSRM_PROJECT_VARIANT=ITAB_NULL;
	ZSRM_PROJECT_VARIANT *tVariantDetails;
	int iNoOfVarName = 0;
	int iCounter = 0;
	char *varId = NULL;
	char *varName = NULL;
	int crow2= 0 ;
	char* t5_PPPMPrjCode = NULL;

	//varId = (char *) MEM_alloc(17* sizeof(char));
	//varName = (char *) MEM_alloc(21* sizeof(char));

	ITK_CALL(AOM_ask_value_string(*objTag,"t5_PPPMPrjCode",&t5_PPPMPrjCode));
	printf("\nt5_PPPMPrjCode:%s",t5_PPPMPrjCode);
	TC_write_syslog("\nt5_PPPMPrjCode:%s",t5_PPPMPrjCode);

	if ( t5_PPPMPrjCode == NULL )
	{
		printf("\nt5_PPPMPrjCode value is null");
		TC_write_syslog("\nt5_PPPMPrjCode value is null");
	}
	else
	{

		hRfc = BapiLogon();

		printf("\nZSTAR_PROJECT_DETAIL function get variant id and name\n"); fflush(stdout); 
		TC_write_syslog("\nZSTAR_PROJECT_DETAIL function get variant id and name\n"); fflush(stdout); 

		thZSRM_PROJECT_DETAIL = ITAB_NULL;

		if (thZSRM_PROJECT_DETAIL==ITAB_NULL)
		{
			thZSRM_PROJECT_DETAIL = ItCreate("IT_PROJECT_DETAILS",sizeof(ZSRM_PROJECT_DETAIL),0,0);
			if (thZSRM_PROJECT_DETAIL==ITAB_NULL)
				rfc_error("ItCreateIT_PROJECT_DETAILS");

		}
		else
		{

			if (ItFree(thZSRM_PROJECT_DETAIL) != 0)
				rfc_error("ItFreeIT_PROJECT_DETAILS");
		}

		thZSRM_PROJECT_VARIANT = ITAB_NULL;

		if (thZSRM_PROJECT_VARIANT==ITAB_NULL)
		{
			thZSRM_PROJECT_VARIANT = ItCreate("IT_PROJECT_VARIANT",sizeof(ZSRM_PROJECT_VARIANT),0,0);
			if (thZSRM_PROJECT_VARIANT==ITAB_NULL)
				rfc_error("ItCreateIT_PROJECT_VARIANT");

		}
		else
		{

			if (ItFree(thZSRM_PROJECT_VARIANT) != 0)
				rfc_error("ItFreeIT_PROJECT_VARIANT");
		}

		SETCHAR(eIV_ZZSRM_PROJECT_CODE.ZZSRM_PROJECT_CODE,t5_PPPMPrjCode);
		SETCHAR(eIV_ZSRM_PROJECT_PLATFORM,"");
		SETCHAR(eIV_ZSRM_PROJECT_LINE,"");
		SETCHAR(eIV_ZSRM_PROJECT_MANUF_LOC,"");
		SETCHAR(eIV_ZSRM_BUSINESS_UNIT,"");
		SETCHAR(eIV_COMT_CHECKBOX,"");

		printf("\ncll_ZSTAR_BARREL_PROJECT_GETDETAIL function111\n"); fflush(stdout);
		TC_write_syslog("\ncll_ZSTAR_BARREL_PROJECT_GETDETAIL function111\n"); fflush(stdout);

		RfcRc = ZSTAR_PROJECT_DETAIL(hRfc,&eIV_ZZSRM_PROJECT_CODE,&eIV_ZSRM_PROJECT_PLATFORM,&eIV_ZSRM_PROJECT_LINE,&eIV_ZSRM_PROJECT_MANUF_LOC,&eIV_ZSRM_BUSINESS_UNIT,&eIV_COMT_CHECKBOX,thZSRM_PROJECT_DETAIL,thZSRM_PROJECT_VARIANT,xException);
			
		printf("\nNo. of records [ %d ] found in BAPI 'thZSRM_PROJECT_DETAIL'\n",ItFill(thZSRM_PROJECT_DETAIL)); fflush(stdout);
		TC_write_syslog("\nNo. of records [ %d ] found in BAPI 'thZSRM_PROJECT_DETAIL'\n",ItFill(thZSRM_PROJECT_DETAIL)); fflush(stdout);

		
		if (ItFill(thZSRM_PROJECT_DETAIL)>0)
		{
			switch (RfcRc)
			{
				case RFC_OK:

					iNoOfVarName = ItFill(thZSRM_PROJECT_VARIANT);
					printf("\niNoOfVarName:%d",iNoOfVarName);fflush(stdout);
					TC_write_syslog("\niNoOfVarName:%d",iNoOfVarName);fflush(stdout);
					char **VariantName = (char **) MEM_alloc(iNoOfVarName * sizeof(char *));
					char **VariantId = (char **) MEM_alloc(iNoOfVarName * sizeof(char *));
					iCounter = 0;
					
					for (crow2 = 1;crow2 <= ItFill(thZSRM_PROJECT_VARIANT); crow2++)
					{
						tVariantDetails = ItGetLine(thZSRM_PROJECT_VARIANT,crow2);
						if (tVariantDetails == NULL)
							printf("ItCreateIT_PROJECT_VARIANT");fflush(stdout);

						varId = (char *) MEM_alloc(17* sizeof(char));
						varName = (char *) MEM_alloc(21* sizeof(char));

						memset(varId,0,sizeof(varId));
						memset(varName,0,sizeof(varName));


						GETCHAR(tVariantDetails->VARIANT_ID,varId); varId[strlen(varId)] = '\0';
						GETCHAR(tVariantDetails->VARIANT_NAME,varName); varName[strlen(varName)] = '\0';

						TC_write_syslog("\nbefore VariantName[%d]:%s",iCounter,varId);fflush(stdout);
						TC_write_syslog("\nbefore VariantId[%d]:%s",iCounter,varName);fflush(stdout);
						

						trimTrailing(varName);
						trimTrailing(varId);
						
						VariantName[iCounter] =  varName ;
						VariantId[iCounter] = varId ;
						//tc_strcpy(VariantName[iCounter],  varName ) ;
						//tc_strcpy(VariantId[iCounter], varId ) ;
						printf("\nVariantName[%d]:%s",iCounter,VariantName[iCounter]);fflush(stdout);
						printf("\nVariantId[%d]:%s",iCounter,VariantId[iCounter]);fflush(stdout);

						TC_write_syslog("\nVariantName[%d]:%s",iCounter,VariantName[iCounter]);fflush(stdout);
						TC_write_syslog("\nVariantId[%d]:%s",iCounter,VariantId[iCounter]);fflush(stdout);
						iCounter = iCounter + 1;

						
						
					}  
					printf("\niNoOfVarName before update:%d",iNoOfVarName);fflush(stdout);
					TC_write_syslog("\niNoOfVarName before update:%d",iNoOfVarName);fflush(stdout);
					if( iNoOfVarName > 0 )
					{
						printf("\nsetting t5_VariantName and t5_VaraintId values from bapi on post create");
						TC_write_syslog("\nsetting t5_VariantName and t5_VaraintId values from bapi on post create");
						ITK_CALL(AOM_lock(*objTag));
						ITK_CALL(AOM_set_value_strings(*objTag,"t5_VariantName",iNoOfVarName,VariantName));
						ITK_CALL(AOM_set_value_strings(*objTag,"t5_VaraintId",iNoOfVarName,VariantId));
						ITK_CALL(AOM_save(*objTag));
						ITK_CALL(AOM_unlock(*objTag));
						ITK_CALL(AOM_refresh(*objTag,false));  
					}
				break;
				case RFC_EXCEPTION:
					printf("\nRFC EXCEPTION:%s",xException);
					TC_write_syslog("\nRFC EXCEPTION:%s",xException);
				break;
				case RFC_SYS_EXCEPTION:
					printf("\nSystem Exception Raised!!!");
					TC_write_syslog("\nSystem Exception Raised!!!");
				break;
				case RFC_FAILURE:
					printf("\nFailure!!!");
					TC_write_syslog("\nFailure!!!");
				break;
				default:
					printf("\nOther Failure!");
					TC_write_syslog("\nOther Failure!");
				break;
			}
			if (ItDelete(thZSRM_PROJECT_VARIANT) != 0) rfc_error("ItDelete thZSRM_PROJECT_VARIANT");
			if (ItDelete(thZSRM_PROJECT_DETAIL) != 0) rfc_error("ItDelete thZSRM_PROJECT_DETAIL");
		}
		RfcClose(hRfc);
	}
	return ITK_ok;
}
void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
DLLAPI int tm_DynmcLOVAutoSOR_register_callbacks ()
{
	int ifail=0;
	TC_write_syslog("\ntm_DynmcLOVAutoSOR\n\n");fflush(stdout);
	printf("\ntm_DynmcLOVAutoSOR\n\n");fflush(stdout);
	ITK_CALL(CUSTOM_register_exit ( "tm_DynmcLOVAutoSOR", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_SorLovPopulate_method));
	return ( ITK_ok );
}
