
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_UpdateProperty.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   01-12-2023
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 01/12/2023  	 Amar Kate				    Update Property Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/grmtype.h>
#include <epm/releasestatus.h>
#include <tccore/releasestatus.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int tm_UpdateProperty_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	ItemID			=NULL;
	char*	Revision		=NULL;
	char*	type			=NULL;
	char*	Propname		=NULL;
	char*	Propvalue		=NULL;
	char*	Datevalue		= NULL;

	printf("\n Amar Inside tm_UpdateProperty_Release_Call .....\n");
	
	USERARG_get_string_argument(&ItemID);
	USERARG_get_string_argument(&Revision);              
	USERARG_get_string_argument(&type);              
	USERARG_get_string_argument(&Propname);              
	USERARG_get_string_argument(&Propvalue);              
	USERARG_get_string_argument(&Datevalue);              
	 
	printf("\n ItemID => %s\n",ItemID);fflush(stdout);
	printf("\n Revision => %s\n",Revision);fflush(stdout);
	printf("\n type => %s\n",type);fflush(stdout);
	printf("\n Propname => %s\n",Propname);fflush(stdout);
	printf("\n Propvalue => %s\n",Propvalue);fflush(stdout);
	printf("\n Datevalue => %s\n",Datevalue);fflush(stdout);

	
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"UpdateProperty","UpdateProperty","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Inside Control Object Query \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			//sprintf(cmd,"%s -ItemID=%s -Revision=\"%s\" -type=\"%s\" -Propname=%s -Propvalue=\"%s\" -Datevalue=\"%s\" &",t5_Userinfo1,ItemID,Revision,type,Propname,Propvalue,Datevalue);
			sprintf(cmd,"%s/UpdateProperty.sh %s %s %s %s %s %s &",t5_Userinfo1,ItemID,Revision,type,Propname,Propvalue,Datevalue);
			printf("Excuting Command = %s",cmd);fflush(stdout);
			system(cmd);
			printf("\n After executing Command\n");fflush(stdout);
	   }
	}
	return ifail;
}

extern int tm_UpdatePropertyinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for Update Property

	int nargs1 = 6;
	int retValueType1;
	int inputArgTypes1[6] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE; 
	inputArgTypes1[3] = USERARG_STRING_TYPE; 
	inputArgTypes1[4] = USERARG_STRING_TYPE; 
	inputArgTypes1[5] = USERARG_STRING_TYPE; 

	retValueType1 = USERARG_STRING_TYPE ; 
	
	//printf("\n tm_UpdatePropertyinitmodule before....tm_UpdateProperty_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_UpdateProperty_Call",(USER_function_t)tm_UpdateProperty_Call,nargs1,inputArgTypes1,retValueType1);

	return ifail;	
}

extern DLLAPI int tm_UpdateProperty_register_callbacks()
{	
	int ifail    = ITK_ok;
	//printf("\n Amar Before registoring userservice....tm_UpdateProperty");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_UpdateProperty", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_UpdatePropertyinitmodule);
	//printf("\n Amar After registoring userservice....tm_UpdateProperty");fflush(stdout);
	return ( ITK_ok );
}