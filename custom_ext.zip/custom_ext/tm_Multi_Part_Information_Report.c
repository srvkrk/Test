#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
//#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov_msg.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>  
//#include <tccore/tc_errors.h>
#include <errno.h>
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <tie/tie_errors.h>
#include <tccore/grmtype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tc/wsouif_errors.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
//#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <epm/cr.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
extern int MulPartInforeport(void *return_data)
{
	
	int 				n_tags_found				= 0;
    tag_t				*tags_found 				= NULLTAG;
    tag_t				item_id 					= NULLTAG;
	const char 			*attrs[1];
    const char 			*values[1];
	char 				*InputVcs					= NULL;
	char 				*AttributeStringInput					= NULL;
	char 				*OutFile					= NULL;
	FILE				*uservclist					= NULL;
	FILE				*Report						= NULL;
	char*   			itemid	     		     	= NULL;
	char*   			vc_number     		    	= NULL;
	char*   			UserName     		    	= NULL;
	char	command[1000];
	OutFile = (char *) MEM_alloc(100 * sizeof(char *));
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&InputVcs);
    USERARG_get_string_argument(&AttributeStringInput);
    USERARG_get_string_argument(&UserName);
	printf("\n InputVcs Number :: %s ",InputVcs);fflush(stdout);
	printf("\n Input  AttributeStringInput :: %s ",AttributeStringInput);fflush(stdout);
	printf("\n Login user :: %s ",UserName);fflush(stdout);
	printf("\n Going to call Exe");fflush(stdout);
	sprintf(command,"/user/cvprod/shells/APL/Multi_Part_Information_Report.sh  %s %s %s ",InputVcs,AttributeStringInput,UserName);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	return ITK_ok;
}
extern int tm_Multi_Part_Information_Reportfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 3;
	int retValueType;
	int inputArgTypes[3] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //InputVcs
	inputArgTypes[1] = USERARG_STRING_TYPE; //attributeString
	inputArgTypes[2] = USERARG_STRING_TYPE; //UserName
	retValueType = USERARG_STRING_TYPE ;  
	printf("\n Going to call tm_Multi_Part_Information_Reportfncalling");fflush(stdout);
	ifail=USERSERVICE_register_method("MulPartInforeport",(USER_function_t)MulPartInforeport,nargs,inputArgTypes,retValueType);
	
	return ifail;
}
extern DLLAPI int tm_Multi_Part_Information_Report_register_callbacks ()
{	
	int ifail    = ITK_ok;
	ifail = CUSTOM_register_exit("tm_Multi_Part_Information_Report", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_Multi_Part_Information_Reportfncalling);
	printf("\n Going to call tm_Multi_Part_Information_Report_register_callbacks");fflush(stdout);
	return(ITK_ok);
}