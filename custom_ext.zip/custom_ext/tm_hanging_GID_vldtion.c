/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Ritesh
*  Module              :   Workflow Rule Handler to handler ensure group id in hanging part validation
*  Code                  :   tm_hanging_GID_vldtion.c
*  Created on			:   Jul 17th, 2025
*  Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		tm_hanging_GID_vldtion
	Description			:		This handler ensure the group id in hanging part validation
*/

EPM_decision_t tm_hanging_GID_vldtion(EPM_rule_message_t msg)
{
	int   i							= 0;
	int   attachmentCount			= 0;
	char*   obj_type=NULL;
	tag_t rootTask_t				= NULLTAG;
	tag_t *taskAttachments			= NULLTAG;
	tag_t  objTypTag				= NULLTAG;	
	char*	 combo_4		= NULL;
	char*	 combo_7		= NULL;
	char*	 combo_9		= NULL;
	char*	 combo_41		= NULL;
	char*	 combo_10		= NULL;
	char*	 combo_11		= NULL;
	char*	 combo_12		= NULL;
	char*	 combo_22		= NULL;
	char*	 combo_36		= NULL;
	char*	 combo_13		= NULL;
	char*	 combo_23		= NULL;
	char*	 combo_25		= NULL;
	char*	 combo_26		= NULL;
	char*	 combo_27		= NULL;
	char*	 combo_28		= NULL;
	char*	 combo_18		= NULL;
	char*	 combo_33		= NULL;
	char*	 sDMLrlstype		= NULL;
	char*	 DMLno			= NULL;
	char*	 DMLtp			= NULL;
	char*	 CheckListType	= NULL;
	char*	 info1_value	= NULL;
	char*	 info5_value	= NULL;
	char*	 token			= NULL;
	char*	 FldrName			= NULL;
	char*	 sParttype			= NULL;
	int		Chk_count		=0;
	int		ijk				=0;
	int		FOlderflag				=0;
	int		taskcount				=0;
	int		partcount				=0;
	int		sdk				=0;
	int		tt				=0;
	int		t				=0;
	int		kk				=0;
	int		entry_c			=1;
	int		CtrObjQryCount	=0;
	int		rlsTypeFlag 	=0;
	tag_t	DMLRevTag		= NULLTAG;
	tag_t	Mani_Relation	=NULLTAG;
	tag_t	Task_Part	=NULLTAG;
	tag_t	*DmlTasksTags	=NULLTAG;
	tag_t	*PartTags	=NULLTAG;
	tag_t	DMLChkList		=NULLTAG;
	tag_t	CtrObjQry		=NULLTAG;
	tag_t	*CntObj_tag		=NULLTAG;

	char		*Qry_entry[1]	= {"SYSCD"};
	char		**Qry_values    = (char **) MEM_alloc(10 * sizeof(char *));
	sDMLrlstype=(char *)MEM_alloc(20);
	sParttype=(char *)MEM_alloc(30);

	EPM_decision_t decision = EPM_go;
	printf("\n tm_hanging_GID_vldtion Function started...");fflush(stdout);
	TC_write_syslog("\n tm_hanging_GID_vldtion Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	
	if(attachmentCount >0)
	{
		for(i=0;i<attachmentCount;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&obj_type));
			printf("\n ********** tm_hanging_GID_vldtion Workfow obj type: [%s]*************\n", obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
			{
				printf("\n\t DML_Found \n");fflush(stdout);

				DMLRevTag=taskAttachments[i];

				if(QRY_find2("ControlObjects", &CtrObjQry));
				if (CtrObjQry)
				{
					printf("\n\t ControlObjects Query_found \n");fflush(stdout);
				}
				else
				{
					printf("\n\t ControlObjects Query_Not_Found \n");fflush(stdout);
				}

				Qry_values[0] = "HANGPART" ;

				if(QRY_execute(CtrObjQry, entry_c, Qry_entry, Qry_values, &CtrObjQryCount, &CntObj_tag));
				printf("\n\t ControlObjects Count = %d \n",CtrObjQryCount);fflush(stdout);

				if(CtrObjQryCount>0)
				{
					kk=0;
					rlsTypeFlag=0;
					for (sdk=0; sdk < CtrObjQryCount; sdk++)
					{
						ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo1",&info1_value));
						printf("\n ControlObjects Value1 = %s \n",info1_value);fflush(stdout);
						//DML type
						ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo2",&info2_value));
						printf("\n ControlObjects Value2 = %s \n",info2_value);fflush(stdout);

						//Part type
						ITK_CALL(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo3",&info3_value));
						printf("\n ControlObjects info3_value = %s \n",info3_value);fflush(stdout);

						if(tc_strstr(info1_value,"HANG01")==NULL)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLno));
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtp));
							printf("\n\t MT: DMLno:%s ,DMLtype:%s \n",DMLno,DMLtp);fflush(stdout);
							tc_strcpy(sDMLrlstype,"");
							tc_strcpy(sDMLrlstype,",");
							tc_strcat(sDMLrlstype,DMLtp);
							tc_strcat(sDMLrlstype,",");
							printf("\n sDMLrlstype: %s",sDMLrlstype);fflush(stdout);

							if(tc_strstr(info2_value,sDMLrlstype)!=NULL)
							{
								if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
								printf("\nDML Task Count : %d",taskcount);fflush(stdout);
								if (taskcount>0)
								{	
									for(t=0;t<taskcount;t++)
									{		
										if(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags)); //Solutions Items
										printf("1.partcount  is %d\n", partcount);fflush(stdout);

										if(partcount>0)
										{
											for(tt=0;tt<partcount;tt++)
											{
												Task_Part = Task_Parts[PartTags];
												if(AOM_ask_value_string(Task_Part,"item_id",&PartNum));
												printf("\n PartNum :[%s]:", PartNum); fflush(stdout);
												if(AOM_ask_value_string(Task_Part,"t5_PartType",&ItemPType));
												printf("\n ItemPType :[%s]:", ItemPType); fflush(stdout);

												tc_strcpy(sParttype,"");
												tc_strcpy(sParttype,",");
												tc_strcat(sParttype,ItemPType);
												tc_strcat(sParttype,",");
												printf("\n sParttype: %s",sParttype);fflush(stdout);

												//if(tc_strcmp(ItemPType,"V" )==0 || tc_strcmp(ItemPType,"T" )==0 ||  tc_strcmp(ItemPType,"M" )==0 || tc_strcmp(ItemPType,"VC" )==0 || tc_strcmp(ItemPType,"D" )==0 ||
												//tc_strcmp(ItemPType,"DA" )==0 ||tc_strcmp(ItemPType,"DC" )==0 || tc_strcmp(ItemPType,"IFD" )==0|| tc_strcmp(ItemPType,"IM" )==0 ||
												//tc_strcmp(ItemPType,"EM" )==0||tc_strcmp(ItemPType,"TD" )==0||tc_strcmp(ItemPType,"CM" )==0||tc_strcmp(ItemPType,"VCCR" )==0||tc_strcmp(ItemPType,"CCVC" )==0)
												if(tc_strstr(info3_value,sParttype)!=NULL)
												{
														printf("\n Part Type is V/T/M/VC/D/G[%s]--->So continue No hanging part check..............",ItemPType);fflush(stdout);
												}
												else
												{
													printf("\n Part Type is Other than this V/T/M/VC/D/G[%s]--->So continue for hanging part check..............",ItemPType);fflush(stdout);
													printf("\n\t AssyTag exists........\n");fflush(stdout);
													CALLAPI(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
													printf("\n\t where_used count of objects are : %d\n",n_parents); fflush(stdout);

													CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&ItemName1));
													printf("\n child ItemName1:%s ..............",ItemName1);fflush(stdout);

													CALLAPI(AOM_ask_value_string(AssyTag,"item_revision_id",&t5Des_Rev));
													printf("\n\n\t\t t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);

													revisionID = strtok( t5Des_Rev, ";" );
													printf("\n\n\t\t revisionID is :%s",revisionID); fflush(stdout);

													CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&t5rlz_list));
													printf("\n\n\t\t t5rlz_list is :%s",t5rlz_list); fflush(stdout);
													printf("\n\n\t\t DMLtype is :%s",DMLtype); fflush(stdout);

													if (tc_strcmp(HangingPrtErr,"NULL") !=0) MEM_free(HangingPrtErr);
													HangingPrtErr=(char *)MEM_alloc(200);
													tc_strcpy(HangingPrtErr,"");
													tc_strcpy(SetHangingPrtErr,"");

													if((n_parents==0) && (tc_strcmp(revisionID,"NR")==0) && (tc_strstr(t5rlz_list,"Released")==NULL) && (tc_strcmp(DMLtype,"D")!=0))
													{
														printf("\n\n\t\t Inside Where_used count...............\n"); fflush(stdout);
														if((!tc_strcmp(DMLtype,"EP") && !tc_strcmp(taskGrp,"16")) || (tc_strcmp(Object_PartType,"DTPL")==0))
														{
															printf("\n ## Hanging parts validation bypassed for LLP release and task 16 of ECU Parts Release.\n");fflush(stdout);
														}
														else
														{
															printf("\n\n\t\t Inside else loop Where_used.........\n"); fflush(stdout);
															tc_strcat(HangingPrtErr,"PartNumber[");
															tc_strcat(HangingPrtErr,ItemName1);
															tc_strcat(HangingPrtErr,",");
															tc_strcat(HangingPrtErr,t5Des_Rev);
															tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
															printf("\n ChildRelErr10: %s\n",HangingPrtErr);fflush(stdout);
															tc_strcpy(SetHangingPrtErr,HangingPrtErr);

															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,ITK_Prjerr, "ERROR: The Parts attached to task in Solution folder are not attached to any assembly.\nPlease attach to any assembly and ensure to attach same parent part in same DML for NR case.\n(Hanging Parts) : ",SetHangingPrtErr);
															decision = EPM_nogo;
															return decision;
														}
													}	
												}
											}
										}
									}
								}
							}				
						}
					}
				}
			}
		}
		printf("\n tm_hanging_GID_vldtion Function end...");fflush(stdout);
		TC_write_syslog("\n tm_hanging_GID_vldtion Function end...");
		return decision;
	}
}