#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_SpareKit_BOMRpt_RH(EPM_rule_message_t msg)
{
	int seccount      =0;
    int i             =0;
    int DMLSPRPTDoc   =0;
    int Taskcout      =0;
    int partcnt       =0;
    int no_attach     =0;
    int ChkScopeFlag  =0;
    int count  =0;
    int kk  =0;
    int prt  =0;
    int ChkDMLScop  =0;
    int p  =0;
    tag_t DMLTag     = NULLTAG;
    tag_t dmltag     = NULLTAG;
    tag_t DMLRevTag  = NULLTAG;
    tag_t rel_type   = NULLTAG;
    tag_t DmlTsk_tag = NULLTAG;
    tag_t TskTypeTag = NULLTAG;
    tag_t objTypTag = NULLTAG;
    tag_t AssyTag   = NULLTAG;
	tag_t roottask			 = NULLTAG;
	tag_t query			 = NULLTAG;
    tag_t *secobjects  = NULLTAG;
    tag_t *TskRevn_tag = NULLTAG;
    tag_t *PartsTag    = NULLTAG;
	tag_t *contrlObjs  = NULLTAG;
	tag_t * Attachments= NULLTAG;
    char *drstatus   = NULL;
    char *item_id    = NULL;
    char *Chklistvar = NULL;
    char *scopedoc   = NULL;
    char *docname    = NULL;
    char *doctype    = NULL;
	char *DMLNo      = NULL;
	char *Tsk_Typ    = NULL;
	char *Part_no    = NULL;
	char *Part_prj   = NULL;
	char *DesgTyp    = NULL;
	char *sScopeInfo1    = NULL;
	char *sScopeInfo4    = NULL;
	char *sScopeInfo2    = NULL;
	char *sScopeInfo5    = NULL;
	char *sScopeInfo3    = NULL;
	char *objTypeofTask    = NULL;
	char *sDMLUnt    = NULL;
	char *DMLtype    = NULL;
	char *sDMLrlstype    = NULL;
	logical     is_latest;
	logical     is_Tskltst;

	EPM_decision_t decision = EPM_go;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));
	sDMLrlstype=(char *)MEM_alloc(20);

	printf("\n tm_SpareKit_BOMRpt_RH Function started...");fflush(stdout);
	TC_write_syslog("\n tm_SpareKit_BOMRpt_RH Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_SpareKit_BOMRpt_RH No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_SpareKit_BOMRpt_RH :INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SPBOMRPT";
				qry_values[0]  ="SPBOMRPT";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_SpareKit_BOMRpt_RH Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					//ON/OFF
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sScopeInfo1));
					
					printf("\n  tm_SpareKit_BOMRpt_RH L1:sScopeInfo1 is : [%s]  L2:sScopeInfo2 is : [%s]  L3:sScopeInfo3 is : [%s] L4:sScopeInfo4 is : [%s]\n",sScopeInfo1,sScopeInfo2,sScopeInfo3,sScopeInfo4);fflush(stdout);
					
					if(tc_strstr(sScopeInfo1,"SPBOMRPTOFF") == NULL)
					{
						
						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_SpareKit_BOMRpt_RH objtype found \n");fflush(stdout);
					  
						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n tm_SpareKit_BOMRpt_RH object_type is %s\n", objTypeofTask);fflush(stdout);
						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"item_id",&item_id));
							printf("\n tm_SpareKit_BOMRpt_RH item_id is: %s \n",item_id);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
							printf("\n tm_SpareKit_BOMRpt_RH t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

							ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"t5_cDRstatus",&drstatus));
							printf("\n tm_SpareKit_BOMRpt_RH drstatus is: %s \n",drstatus);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&sDMLUnt));
							printf("\n tm_SpareKit_BOMRpt_RH sDMLUnt is: %s \n",sDMLUnt);fflush(stdout);

							/*scopedoc = MEM_alloc(50);
							tc_strcpy(scopedoc,"");
							tc_strcat(scopedoc,item_id);
							printf("\n tm_SpareKit_BOMRpt_RH name is: %s \n",scopedoc);fflush(stdout);*/


							ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
							ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&seccount,&secobjects));
							if (seccount>0)
							{
								for(i=0;i<seccount;i++)
								{
									
									ITK_CALL(AOM_UIF_ask_value(secobjects[i],"current_name",&docname)); 
									//if ((tc_strstr(docname,Chklistvar)!=NULL)) //&& 
									if(tc_strstr(docname,"Spare_kit_report_")!=NULL)
									{
										DMLSPRPTDoc = 1;	
										printf("\n tm_SpareKit_BOMRpt_RH attached found :%d \n",DMLSPRPTDoc);fflush(stdout);				
										break;
									}
									
								}
							}
							if (DMLSPRPTDoc == 1)
							{
								decision = EPM_go;
								printf("\n tm_SpareKit_BOMRpt_RH attached... \n");fflush(stdout);
								return decision;
							}
							else
							{
								printf("\n tm_SpareKit_BOMRpt_RH Condition 3 found"); fflush(stdout);
								if(tc_strstr(sScopeInfo1,"SPOFF2") == NULL)
								{
									printf("\n tm_SpareKit_BOMRpt_RH is NOT attached.  \n"); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\n ERROR: Please ensure to attach Spare Kit Report in 'references' folder of DML.\n Then refresh worklist and sign off assignment.");
									decision = EPM_go;
									return decision;
									//printf("\n tm_SpareKit_BOMRpt_RH is NOT attached.  \n"); fflush(stdout);
								}
							}	
						}
					}
				}
			}
		}
	}
	return decision;
}