//#define _CRT_SECURE_NO_DEPRECATE					
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <tc/folder.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>

#define MAX_LINE_LEN 1024
#define GRM_create_msg "GRM_create"   1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define	t9ScopeDocumentError_001 (EMH_USER_error_base + 40)
#define ITK_CALL(x) {           \
            int stat;                     \
            char *err_string;             \
            if( (stat = (x)) != ITK_ok)   \
            {                             \
            EMH_ask_error_text (stat, &err_string);                 \
            printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
            printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
            if(err_string) MEM_free(err_string);                                \
            exit (EXIT_FAILURE);                                                   \
            }                                                                    \
        }


int DML_Scope_Document(char*,char*,int,char**,void*,char***,int*);

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int line_number,                    /* <I> Line Number in which the error Occurred in the Program */
 const char * file_name              /* <I> Name of the File */
 )
{
  int          n_ifails=0;
  const int   *severities=NULL;
  const int   *ifails=NULL;
  const char **texts=NULL;
  char        *errstring=NULL;
  char *err= NULL;
  err = ( char * ) MEM_alloc ( sizeof ( char ) * MAX_LINE_LEN );

  EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
  if ( n_ifails && texts != NULL )
    {
      if ( ifails[n_ifails-1] == stat )
        {
          sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, texts[n_ifails-1] );
          printf ( "%s ", err );fflush(stdout);
        }
      else
        {
          EMH_ask_error_text (stat, &errstring );
          sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
          printf ( "%s", err );fflush(stdout);
          if ( errstring != NULL )
            MEM_free( errstring );
        }
    }
  else
    {
      EMH_ask_error_text (stat, &errstring );
      sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
      printf ( " %s", err );fflush(stdout);
      if ( errstring != NULL )
        MEM_free( errstring );
    }
  sprintf ( err,"\n\n%s: Error: Line %d in %s\n\n", prog_name, line_number, file_name );
  printf ( "%s ", err);fflush(stdout);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}


void setFindStr(char **view_list,int count,char *str,int *found)
{

	//printf("\n **setFindStr");fflush(stdout);
	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

	//printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{
			*found=1;
			break;

		}

	}
	//printf("\n **setFindStr found= %d",*found);fflush(stdout);


}

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	//printf("\n Added in Set ===%s",(*strset)[*count-1]);fflush(stdout);
}
/****************************************************************************/
/* Function Name    : FU_dumpItkErrors                                      */
/*                                                                          */
/* Called From      : ITK                                                   */
/*                                                                          */
/* Input Parms      : int stat                                              */
/*                    const char * prog_name                                */
/*                    int line_number                                       */
/*                    const char * file_name                                */
/*                                                                          */
/* Output Parms     : None                                                  */
/*                                                                          */
/* Functions called : None                                                  */
/*                                                                          */
/* File Description : Called by the ITK macro to log errors                 */
/*                                                                          */
/* Return Value     : Void                                                  */

/**********************************************************************/



EPM_decision_t DML_Scope_Document_Check( EPM_rule_message_t msg)
{
	EPM_decision_t  decision 						= EPM_go;
	tag_t			tzroottask						= NULLTAG;
	tag_t			*tzattachment					= NULL;
	tag_t 			*taskList						= NULL;
	tag_t  			*PartList						= NULL;
	tag_t	    	master							= NULLTAG;
	tag_t       	*all_rev_list        			= NULL; 
	tag_t       	latestrev 						= NULLTAG;
	tag_t 			*release_status_objects_prev	= NULL;
	tag_t 			*list_of_WSO_cntrl_tags2		= NULL;
	tag_t   		qryTagCntrl1     				= NULLTAG;
	
	char* 			target_object 					= NULL;
	char*       	release_type					= NULL;
	char			*TaskNumber		    			= NULL;
	char        	*PartNumber        				= NULL;
	char        	*revision_id         			= NULL;
	char        	*revision_latest    			= NULL;
	char 			*APLPlantName  					= NULL;
	char 			*UserInfo 						= NULL;
	char 			*business_type 						= NULL;
	char    		*qry_entryCntrl2[1]  			= {"SYSCD"};
	char   			**qry_valuesCntrl2				= (char **) MEM_alloc(5 * sizeof(char *));
	char			**setOfReleaseType;
	char 			*doc_name						= NULL;
	char 			*his_obj						= NULL;
	char  			name[WSO_name_size_c+1]    		= {'\0'};
	char			*released_date					= NULL;
	char        	*errstring1						= NULL;
	char 			ReleasedDate_str[12] 			= {'\0'};
	const char * 	prog_name						= "DML_Scope_Document_Check";
	
	int				izntaskattachment				= 0;
	int				attachcount						= 0;	
	int	 			partcount						= 0;		
	int         	count_all_rev					= 0;
	int        		count_release_prev 				= 0; 
	int 			ifail 							= ITK_ok;
	//int    	 	n_entryCntrl2    				= 3;
	int     		n_entryCntrl2    				= 1;
	int  			control_number_found2			= 0;
	int				setOfStringint = 0;
	int				arg_cnt = 0;
	
	date_t	   		Part_released_date 				= NULLDATE;
	int 			cntrObjCount 					= 0;
	tag_t* 			cntrlObjRlsTyp 					= NULL;
	
	struct tm* 		now_tm;
	
	time_t 			now;
		
	//char    		*qry_entryCntrl2[3]  = {"SYSCD","Information-1","Delete Indicator"};

	doc_name = (char *) MEM_alloc( 100 * sizeof(char) ); 
	his_obj  = (char *) MEM_alloc( 100 * sizeof(char) ); 
	
	
	printf("\n *********************** Inside DML_Scope_Document_Check *****************************");fflush(stdout);
	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
		char    		*entry[2]  			= {"SYSCD","SUBSYSCD"};
		char    		*value[2]  			= {"releaseType","DMLScopeDoc"};
		
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl2[0]="ScopEdoC";
		 
		ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl2, qry_entryCntrl2, qry_valuesCntrl2, &control_number_found2, &list_of_WSO_cntrl_tags2));
		ITK_CALL(QRY_execute(qryTagCntrl1, 2, entry, value, &cntrObjCount, &cntrlObjRlsTyp));
		printf("\n cntrObjCount is : %d\n",cntrObjCount);fflush(stdout);
	}
	else
	{
		printf("\n Control Object Query not Found  \n");fflush(stdout);
	}

	printf("\n control_number_found2 is : %d\n",control_number_found2);fflush(stdout);
	//printf("\n cntrObjCount is : %d\n",cntrObjCount);fflush(stdout);
	
	if(control_number_found2>0)
	{
		

		ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_SubSyscd", &APLPlantName));
		printf("\n APLPlantName: %s\n",APLPlantName);fflush(stdout);
		ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo1", &UserInfo));
		printf("\n User Info1 obtained: %s\n",UserInfo);fflush(stdout);
	}
	
	if(cntrObjCount>0)
	{
		char* userInfo1 = NULL;
		char* releaeType = NULL;
		
		
		
		releaeType = (char *) MEM_alloc( 10 * sizeof(char) ); 
		
		ITK_CALL(AOM_ask_value_string( cntrlObjRlsTyp[0], "t5_Userinfo1", &userInfo1));
		printf("\n userInfo1: %s\n",userInfo1);fflush(stdout);
		
		releaeType = tc_strtok(userInfo1,",");
		
		while (releaeType != NULL) 
		{ 
			printf("\n%s", releaeType); fflush(stdout);
			setAddStr(&setOfStringint,&setOfReleaseType,releaeType);
			releaeType = tc_strtok(NULL, ","); 
		} 
		
	}
	
	printf("\n setOfStringint %d",setOfStringint);fflush(stdout);
	
	
	
	time(&now);
	now_tm = localtime(&now);
	strftime (ReleasedDate_str, 12, "%Y/%m/%d", now_tm);
	printf("\n ReleasedDate_str is===>[%s]\n",ReleasedDate_str);fflush(stdout);
	
	ITK_CALL(ITK_set_bypass(true));
	
	ITK_CALL(EPM_ask_root_task(msg.task, &tzroottask));
	ITK_CALL(EPM_ask_attachments(tzroottask, EPM_target_attachment, &izntaskattachment, &tzattachment ));	
	
	ITK_CALL(AOM_ask_value_string(tzattachment[0],"object_type",&target_object));
	printf("\n Target Class====>[%s]", target_object);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(tzattachment[0],"item_id",&TaskNumber));
	printf("\n TaskName====>[%s]", TaskNumber);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_tags(tzattachment[0],"IMAN_reference",&attachcount,&taskList));//Added by Varun .............
	printf("\nNo of Attachment Found ====>[%d]\n", attachcount);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(tzattachment[0],"t5_rlstype",&release_type));
	printf("\n Release Type Obtained====>[%s]", release_type);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(tzattachment[0],"t5_ERCBusiUt",&business_type));
	printf("\n business_type Obtained====>[%s]", business_type);fflush(stdout);
	
	//To check for the relation attaches ...and look for the presence of the DSAS doc.
	
	//If found raise an EPM_go and if not raise an EPM_nogo signal.
	
	//To check if userinfo1 is in release type (Gate Maturation,TPL with Spare kit Release,BOM Error Cleanup,Production Part Regularization,TPL)
	
	tc_strcpy(doc_name,"");
	tc_strcpy(doc_name,"DSAS_");
	tc_strcat(doc_name,TaskNumber);
	
	tc_strcpy(his_obj,"");
	tc_strcpy(his_obj,TaskNumber);
	tc_strcat(his_obj,"_DML_HISTORY");
	
	printf("\n Doc name should be ======> %s",doc_name);fflush(stdout);
	
	
	if(tc_strstr(UserInfo,"TRUE")!=NULL)
	{	
		printf("\n Target Class====>[%s]", target_object);fflush(stdout);
		if(tc_strstr(target_object,"ChangeRequestRevision") != NULL)
		{
			int count=0;
			//if(attachcount>0)
			//{
				int m,i,j,k;
				int found = 0;
				
				setFindStr(setOfReleaseType,setOfStringint,release_type,&found);

				/*if (
				(tc_strcmp(release_type,"XO") == 0 ) || 
				(tc_strcmp(release_type,"TPL") == 0) || 
				(tc_strcmp(release_type,"TK") == 0) ||
				(tc_strcmp(release_type,"BEC") == 0) ||
				(tc_strcmp(release_type,"PPR") == 0) ||
				(tc_strcmp(release_type,"MR") == 0) )
				{*/
				if(tc_strcmp(business_type,"CVBU")==0)
				{
					if(found>0)
					{
						printf("\n release_type [%s] found in control object",release_type);fflush(stdout);
						for(m=0;m<attachcount;m++)
						{
							printf("\n****************Attachment Found(DML Scope Document)[%d]*****************\n",m);fflush(stdout);
							 tag_t doc=taskList[m];
							 char* attachDocName=NULL;
							 
							 ITK_CALL(AOM_ask_value_string(doc,"current_name", &attachDocName));
							 printf("\n Doc Name found ====>[%s]", attachDocName);fflush(stdout);
							 
							 if(tc_strcmp(attachDocName,doc_name)==0) 
							 {
								tag_t qryTagGen = NULLTAG;
								
								printf("\n Found a DSAS Documnet ====>[%s]", attachDocName);fflush(stdout);
								printf("\n DML History Object Name ======> %s",his_obj);fflush(stdout);

								if(QRY_find2("General...", &qryTagGen));

								if (qryTagGen)
								{
									int hist_obj_count = 0;
									tag_t *hist_objs = NULL;
									
									
									//char *name1[2]={"Type","Name"};
									//char *val1[2]={"Dml His",his_obj};
									char *name1[1]={"Name"};
									char *val1[1]={his_obj};
									
									printf("\n qryTagGen Query Found \n");fflush(stdout);
									
									//ITK_CALL(QRY_execute(qryTagGen, 2, name1, val1, &hist_obj_count, &hist_objs));
									ITK_CALL(QRY_execute(qryTagGen, 1, name1, val1, &hist_obj_count, &hist_objs));
									
									printf("\n hist_obj_count ========> %d", hist_obj_count);fflush(stdout);
									
									if(hist_obj_count == 1)
									{
										
										int folderCount = 0;
										int forFolder = 0;
										int folderCond = 0;
										
										tag_t* folder_contain = NULL;
										
										ITK_CALL(FL_ask_references(hist_objs[0],FL_fsc_by_date_modified ,&folderCount,&folder_contain));
										
										for(forFolder=0;forFolder<folderCount;forFolder++)
										{
											char	*containName = NULL;
											//char	containName[WSO_name_size_c+1];
											
											ITK_CALL(WSOM_ask_name2(folder_contain[forFolder],&containName));
											
											if(tc_strcmp(attachDocName,containName)==0)
											{
												folderCond++;
												break;
											}
											else
											{
												continue;
											}
										}
										
										if(folderCond==0)
										{
											printf("\n before FL_insert");fflush(stdout);
											ITK_CALL(AOM_lock(hist_objs[0] ));
											ITK_CALL(FL_insert(hist_objs[0],doc,999));				
											ITK_CALL(AOM_save_without_extensions(hist_objs[0] ));
											ITK_CALL(AOM_unlock(hist_objs[0]));
											printf("\n After FL_insert");fflush(stdout);
										}
										else
										{
											printf("\n PDF already contained in Hist Obj");fflush(stdout);
										}
										
										
										
										/*tag_t specRelationType_t = NULLTAG;
										
										//	ITK_CALL(GRM_find_relation_type("IMAN_specification",&specRelationType_t));
										//ITK_CALL(GRM_find_relation_type("ImanRelation",&specRelationType_t));                                                                                                       
										ITK_CALL(GRM_find_relation_type("IMAN_reference",&specRelationType_t));                                                                                                       
										
										if(specRelationType_t)
										{
											int obj_count = 0;
											tag_t *objects = NULL;
											
											printf("\n GRM_find_relation_type found");fflush(stdout);
											
											tag_t relation_tag = NULLTAG;
											ITK_CALL(GRM_create_relation(hist_objs[0], doc, specRelationType_t, NULLTAG, &relation_tag));
											
											ITK_CALL(GRM_list_all_related_objects_only(hist_objs[0],&obj_count,&objects));
											
											printf("\n obj_count [%d]",obj_count);fflush(stdout);
											
											if(obj_count==0)
											{
												if(relation_tag)
												{
													ITK_CALL(GRM_save_relation(relation_tag));
													printf("\n relationship created and saved");fflush(stdout);
												}
												else
												{
													printf("\n relationship not created");fflush(stdout);
												}
											}
											
										}
										else
										{
											printf("\n GRM_find_relation_type not found");fflush(stdout);
										}*/
									}
									else
									{
										printf("\n History Object [%s] not found",his_obj);fflush(stdout);
									}
								}
								else
								{
								printf("\n qryTagGen Query not Found  \n");fflush(stdout);
								}

								count++;
								break;
							 }
							 else
							 {
								 
								 continue;
								  
							 }
							//AOM_ask_value_tags(task,"CMHasSolutionItem",&partcount,&PartList);
							//printf("\n No of Parts found in the Task ====>[%d]", partcount);fflush(stdout);
							
						}
						printf("\n count [%d]",count);fflush(stdout);
						if(count==0)
						{
							int i = 0;
							char* error_msg = NULL;
							char *value = NULL;
							char *flag  = NULL;
							char *check = NULL;
							
							error_msg = (char *) MEM_alloc( 100 * sizeof(char) );
							
							arg_cnt = TC_number_of_arguments(msg.arguments);
							printf("\n Number of arguments: [%d]",arg_cnt);fflush(stdout);
		
							for(i=0;i<arg_cnt;i++)
							{
								ifail= ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &flag, &value);
								
								if(ifail == ITK_ok)
								{
									if(tc_strcmp(flag,"check") == 0)
									{
										if( value != NULL )
										{
											check = (char*) MEM_alloc(( strlen(value) + 1) * sizeof(char));
											tc_strcpy(check,value);
											
										}
									}
									else
									{
										printf("\n Invalid argument..");fflush(stdout);
										ifail=t9ScopeDocumentError_001;
										ITK_CALL(EMH_store_error_s1(EMH_severity_error,ifail,"Invalid argument.."));
										decision = EPM_nogo;
										return decision;
									}
								}
							}
							
							printf("\n check ============> %s",check);fflush(stdout);
							
							tc_strcpy(error_msg,"");
							tc_strcpy(error_msg,"\n DML Scope Document not Found.\n DML Document having name ");
							tc_strcat(error_msg,doc_name);
							tc_strcat(error_msg," must be attached.");
							
							printf("\n %s",error_msg);fflush(stdout);
							
							 ifail=t9ScopeDocumentError_001;
							 //EMH_ask_error_text (ifail,&errstring1);
							 
							 if(tc_strcmp(check,"hard")==0)
							 {
								 EMH_clear_errors();
								 printf("\n----------Before Prompting for Error--------------------\n");fflush(stdout);
								 ITK_CALL(EMH_store_error_s1(EMH_severity_error,ifail,error_msg)); 
								 printf("------------After Prompting for Error-------------------\n");fflush(stdout);
								 decision = EPM_nogo;
							 }
							 else
							 {
								char* warning = NULL;
								warning = (char *) MEM_alloc( 1000 * sizeof(char) );
								 
								tc_strcpy(warning,"");
								tc_strcpy(warning,"\nIn the CVBU DML release workflow, before the CE sign-off node, the system will check for the attachment of DML scope document (DSD). If this document is not attached to the DML, the CE approval should not be allowed to happen.");
								tc_strcat(warning,"\nDSD should be mandatory for the following DML Release types:");
								tc_strcat(warning,"\n\t Technical Part List");
								tc_strcat(warning,"\n\t Gate Maturation");
								tc_strcat(warning,"\n\t TPL with Spare Kit Release");
								tc_strcat(warning,"\n\t BOM Error Cleanup");
								tc_strcat(warning,"\n\t Production Part Regularization");
								tc_strcat(warning,"\n\t Module Release");
								
								
								printf("\n warning size ========> %d",strlen(warning));fflush(stdout);
								printf("\n warning ========>\n %s",warning);fflush(stdout);
								EMH_clear_errors();
								
								 printf("\n----------Before Prompting for Error--------------------\n");fflush(stdout);
								 //ITK_CALL(EMH_store_error_s1(EMH_severity_error,ifail,error_msg)); 
								 ITK_CALL(EMH_store_error_s1(EMH_severity_information,t9ScopeDocumentError_001,warning)); 
								 printf("------------After Prompting for Error-------------------\n");fflush(stdout);
								
							 }
							printf("=========================No DS Document Found=======================\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n release type is not as specified.");fflush(stdout);
					}
				}
				else
				{
					printf("\n Busniess type is not CVBU.");fflush(stdout);
				}				
			//}				
		}
	}
	
	return decision;
}


//Added by Varun.....
//Register Rule Handler.........
int DML_Scope_Document_register_rule_handlers()
{
	int ifail = ITK_ok;
	ifail = EPM_register_rule_handler("DML_Scope_Document_Check","DML_Scope_Document_Check",(EPM_rule_handler_t)DML_Scope_Document_Check);					
	return ifail;
}
//All custom handlers
extern int All_custom_func(int *decision, va_list args)
{
    int ifail = ITK_ok;
	
	printf("\n before DML_Scope_Document_register_rule_handlers");fflush(stdout); 
	ifail = DML_Scope_Document_register_rule_handlers();
    printf("\n After DML_Scope_Document_register_rule_handlers"); fflush(stdout);  
    return ifail;
}

//Added by Varun.....

extern DLLAPI int tm_DML_Scope_Document_register_callbacks ()
{
	
    int ifail    = ITK_ok;
	printf("\n Before registoring callbacks(tm_DML_Scope_Document)..............");
    
    ifail=CUSTOM_register_exit ( "tm_DML_Scope_Document", "USER_init_module", (CUSTOM_EXIT_ftn_t)All_custom_func);
	printf("\n After registoring callbacks(tm_DML_Scope_Document)..............");
	
  return ( ITK_ok );
}

