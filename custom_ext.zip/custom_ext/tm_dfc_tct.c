/*
./compile tm_dfc_tct.c
./link_custom_exits tm_dfc_tct
rm -f $TC_ROOT/lib/tm_dfc_tct.so
cp tm_dfc_tct.so $TC_ROOT/lib/.
*/
//#include <ps/ps.h>
//#include <ps/ps_errors.h>
//#include <ai/sample_err.h>
#include <tc/tc.h>
//#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
//#include <bom/bom.h>
//#include <ae/dataset.h>
//#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#define ITK_errStore (EMH_USER_error_base + 3)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error ( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

static void tm_TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

int Assign_TCT_Platform_Review_Func(EPM_action_message_t msg)
{
	//char type_name7[TCTYPE_name_size_c+1];
	char *type_name7 = NULL;
	tag_t PPGrp_tag = NULLTAG; 
	char *groupName = NULL;
	char *s_Platform = NULL;
	char* CurrentTask = NULL;
	char* ObjTyp = NULL;
	char* current_release_level = NULL;
	char* parent_name = NULL;
	char* task_result = NULL;
	char* tct_group_role1 = NULL ;
	char* tct_group_role2 = NULL ;
	char* tct_item_id = NULL;
	char* username = NULL;
	int CRBcount = 0 ;
	int No_PPAna = 0;
	int atch = 0 ;
	int jk = 0;
	int no_attach = 0 ;
	int pp = 0 ;
	logical is_Tskltst;
	tag_t *DmlCRB = NULLTAG ;
	tag_t *attachment = NULLTAG;
	tag_t DmlCRBTag = NULLTAG ;
	tag_t ObjTypDmlCRB = NULLTAG ;
	tag_t PPAna_Party = NULLTAG;
	tag_t PPAna_Patri_Type = NULLTAG;
	tag_t PPAnalyst_tag = NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG ;
	tag_t job = NULLTAG;
	tag_t objTag = NULLTAG;
	tag_t root_task = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t*  PPAna = NULLTAG;
	tag_t objMasterTag = NULLTAG;


	ITK_CALL ( POM_get_user(&username,&user_tag) ) ;
	TC_write_syslog("\nStarting for username:[%s]",username);fflush(stdout);

	ITK_CALL ( EPM_ask_root_task(msg.task,&root_task ) ) ;
	TC_write_syslog("\nRoot task found");fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(msg.task,"object_name",&CurrentTask) ) ;
	TC_write_syslog("\nCurrentTask:%s.",CurrentTask);fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(msg.task,"task_result",&task_result) ) ;
	TC_write_syslog("\ntask_result:%s.",task_result);fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(root_task,"object_name",&parent_name ) ) ;
	TC_write_syslog("\nParent Name:%s.",parent_name);fflush(stdout);
	
	
	ITK_CALL ( EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment) ) ;
	TC_write_syslog("\nNo of Attachements: [%d]", no_attach);fflush(stdout);
	if ( no_attach > 0 )
	{
		for ( atch = 0; atch < no_attach; atch++ )
		{
			objTag = attachment[atch];
			ITK_CALL ( AOM_ask_value_string(objTag,"object_type",&ObjTyp) ) ;
			TC_write_syslog("\nObjTyp is :%s\n",ObjTyp);fflush(stdout);

			ITK_CALL ( AOM_ask_value_string(objTag,"item_id",&tct_item_id) ) ;
			TC_write_syslog("\nTCT item_id :%s\n",tct_item_id);fflush(stdout);

			if( tc_strcmp ( ObjTyp, "T5_DFC_TCTRevision" ) == 0 )
			{
				TC_write_syslog ( "\nMatching condition" );
				groupName = (char	*)MEM_alloc(100);
				tc_strcpy(groupName,"DFC_TCT_Engineer");
				
				ITEM_ask_item_of_rev( objTag,&objMasterTag);

				ITK_CALL ( AOM_ask_value_string ( objMasterTag, "t5_Platform", &s_Platform ) ) ;

				TC_write_syslog("\ngroupName : %s",groupName);   fflush(stdout);
				ITK_CALL(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type));
				if ( dml_CRB_rel_type != NULLTAG )
				{
					TC_write_syslog("\nREMOVE PARTICIPALNTS START......... \n"); fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB));
					TC_write_syslog("\nDmlCRB count: %d",CRBcount);fflush(stdout);	
					for (jk=0;jk<CRBcount ;jk++ )
					{	
						DmlCRBTag = DmlCRB[jk];
						ITK_CALL(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
						//ITK_CALL(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));//deprecated
						ITK_CALL(TCTYPE_ask_name2(ObjTypDmlCRB, &type_name7));
						TC_write_syslog("\ntype_name7 : %s", type_name7);fflush(stdout);
						char *DMLReviewr = NULL ;
						if (tc_strcmp(type_name7,"T5_TCT_CostManager")==0)
						{
							ITK_CALL(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr));
							TC_write_syslog("\nRemoving reviewer: [%s] ",DMLReviewr);fflush(stdout);
							//ITK_CALL ( AOM_lock(objTag) );
							ITK_CALL(AOM_refresh(objTag,TRUE));
							//ITK_CALL(ITEM_rev_remove_participant (objTag,DmlCRBTag));//deprecated
							ITK_CALL(PARTICIPANT_remove_participant (objTag,DmlCRBTag));
							//AOM_save(objTag);//deprecated
							
							ITK_CALL(AOM_save_without_extensions( objTag) );
							ITK_CALL( AOM_unlock(objTag) );
						}
					}
				}
				//---
					//not attached to any participant
					TC_write_syslog("\ncheck Latest revision of part");
					ITK_CALL(ITEM_rev_sequence_is_latest(objTag,&is_Tskltst));
					if ( is_Tskltst != true )
					{
						TC_write_syslog("\nis_Tskltst is not true\n");fflush(stdout);
					}
					else
					{

						ITK_CALL(SA_find_group(groupName, &PPGrp_tag));
						
						tct_group_role1 = MEM_alloc ( 50 ) ;
						tc_strcpy ( tct_group_role1, s_Platform ) ;
						tc_strcat ( tct_group_role1, "_TCT_Cost_Manager" ) ;//uaprod platform name
						TC_write_syslog("\ntct_group_role1 :[%s]",tct_group_role1);  fflush(stdout);

						ITK_CALL ( SA_find_role2(tct_group_role1,&PPAnalyst_tag));
						
						if ( PPAnalyst_tag == NULLTAG )
						{
							tct_group_role2 = MEM_alloc ( 50 ) ;
							tc_strcpy ( tct_group_role2, s_Platform ) ;
							tc_strcat ( tct_group_role2, "_TCT_CM" ) ;//cv prod role name shorten due to platform name
							TC_write_syslog("\n[%s] role not found hence will search [%s] role",tct_group_role1,tct_group_role2);
							

							TC_write_syslog("\ntct_group_role2 :[%s]",tct_group_role2);  fflush(stdout);

							ITK_CALL ( SA_find_role2(tct_group_role2,&PPAnalyst_tag));
						}

						ITK_CALL ( SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna));

						TC_write_syslog("\nNo_PPAna tct_group_role1 :[%d]",No_PPAna);  fflush(stdout);
						if ( No_PPAna > 0 )
						{
							for ( pp = 0; pp < No_PPAna; pp++ )
							{	
								TC_write_syslog("\nAnalyst no: [%d]",pp);fflush(stdout);
								ITK_CALL(EPM_get_participanttype ("T5_TCT_CostManager",&PPAna_Patri_Type));
								ITK_CALL(EPM_create_participant(PPAna[pp],PPAna_Patri_Type,&PPAna_Party));
								//ITK_CALL(AOM_lock(objTag));	
								ITK_CALL(AOM_refresh(objTag,TRUE));
								//ITK_CALL(ITEM_rev_add_participant(objTag,PPAna_Party));//deprecated

								//1 = true	0=FALSE
								ITK_CALL(PARTICIPANT_add_participant(objTag,FALSE,PPAna_Party));

								//AOM_save(objTag);//deprecated
								
								ITK_CALL(AOM_save_without_extensions( objTag ) );
								
								ITK_CALL(AOM_unlock(objTag));
							}
							//ITK_CALL(AOM_refresh ( objTag,TRUE));
							MEM_free(PPAna);
						}
						else
						{
							TC_write_syslog("\nNo Valid participient found");fflush(stdout);
						}
					}
				//---
			}
		}
	}
	return ITK_ok;
}

int Load_tbl_pr_ws_obj_to_TCTRevTble ( tag_t tct_item_tag, char *s_Platform )
{
	tag_t *wsobj_tag = NULLTAG;
	int hits = 0 ;
	int wsobj_index = 0 ;
	tag_t wsob_type = NULLTAG ;
	char *type_name = NULL ;

	const char *table_property_name = "t5_TCT_ctrl_Tbl_pr" ;
	int	n_table_rows = 0 ;
	tag_t *table_rows = NULLTAG ;
	int i_level = 0 ;
	char *s_Module = NULL ;
	char *s_ModuleAddress = NULL ;
	int property_index = 0;

	//---
	//tag_t tct_item_tag = NULLTAG ;
	tag_t latest_tct_item_rev = NULLTAG ;
	char *item_type = NULL;
	char *curentname = NULL;
	//int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	int i = 0 ;

	int prop_index = 0;
	const char *table_property_name_DFC_TCT = "t5_TCT_Table";
	//int num_rows_to_append = 502; //X4 SCV=227
	int num_rows_to_append = 0;
	int row_index = 0;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
		
	//---

	//ITEM_find_item(  tct_item_id, &tct_item_tag );
	ITK_CALL(ITEM_ask_type2 (tct_item_tag, &item_type));
	TC_write_syslog ( "\nitem_type:%s", item_type ) ;
	ITK_CALL(ITEM_ask_latest_rev ( tct_item_tag, &latest_tct_item_rev ));
	if ( latest_tct_item_rev != NULLTAG )
	{

		//lock are append rows to DFC TCT table
			
			

		ITK_CALL ( WSOM_find2 ( s_Platform, &hits , &wsobj_tag ) );
		if ( hits > 0 )
		{
			for ( wsobj_index = 0 ; wsobj_index < hits ; wsobj_index++ )
			{
				ITK_CALL ( TCTYPE_ask_object_type ( wsobj_tag [ wsobj_index ], &wsob_type ) ) ;
				ITK_CALL ( TCTYPE_ask_name2 ( wsob_type, &type_name ) ) ;
				TC_write_syslog ( "\ntype_name:%s",type_name );
				if ( tc_strcmp ( type_name, "T5_TCT_Ctrl_obj" ) == 0 )
				{
					ITK_CALL ( AOM_ask_table_rows ( wsobj_tag [ wsobj_index ], table_property_name, &n_table_rows, &table_rows ) ) ;

					//ITK_CALL(AOM_lock ( latest_tct_item_rev ) );
					ITK_CALL(AOM_refresh(latest_tct_item_rev,TRUE));
					num_rows_to_append = n_table_rows;
					ITK_CALL(AOM_append_table_rows(latest_tct_item_rev, table_property_name_DFC_TCT,num_rows_to_append, &NewLevel, &table_rows1Tag ));
		
					
					for ( property_index = 0 ; property_index < n_table_rows; property_index++ )
					{
						//Get from Control object
						ITK_CALL ( AOM_ask_value_int ( table_rows [ property_index ], "t5_Level_ctrl_obj", &i_level ) ) ;
						ITK_CALL ( AOM_ask_value_string ( table_rows [ property_index ], "t5_Module_ctrl_obj", &s_Module ) ) ;
						ITK_CALL ( AOM_ask_value_string ( table_rows [ property_index ], "t5_ModuleAddress_ctrl_obj", &s_ModuleAddress ) ) ;
						TC_write_syslog ( "\n[%4d] [%s] [%s]", i_level, s_Module, s_ModuleAddress ) ;

						//set value on DFC TCT
						ITK_CALL(AOM_refresh(table_rows1Tag [ property_index ],TRUE));
						
						//ITK_CALL(AOM_lock ( table_rows1Tag [ property_index ] ) );
						ITK_CALL(AOM_set_value_int(table_rows1Tag [ property_index ], "t5_Level", i_level ));
						ITK_CALL(AOM_set_value_string(table_rows1Tag [ property_index ], "t5_Module",s_Module ));
						ITK_CALL(AOM_set_value_string(table_rows1Tag [ property_index ], "t5_ModuleAddress",s_ModuleAddress ));

						//ITK_CALL(AOM_save ( table_rows1Tag [ property_index ] ) );//deprecated
						ITK_CALL(AOM_save_without_extensions( table_rows1Tag [ property_index ]) );
						
						ITK_CALL(AOM_unlock ( table_rows1Tag [ property_index ] ) );
						
					}
				}
			}
		}
		//ITK_CALL(AOM_save ( latest_tct_item_rev ) );

		ITK_CALL(AOM_save_without_extensions( latest_tct_item_rev) );

		ITK_CALL(AOM_unlock ( latest_tct_item_rev ) );

	}

	return 0;
}

extern DLLAPI int DFC_TCT_save_method_post ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL ;
	char myItem_id[20] = { 0 } ;
	char *s_Platform = NULL ;
	//char *myItem_id = NULL ;

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );//deprecated
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	TC_write_syslog ( "\nDFC_TCT_save_method post type_name:%s", type_name ) ;
	if ( tc_strcmp ( type_name, "T5_DFC_TCT" ) == 0 )
	{
		ITK_CALL ( AOM_ask_value_string ( objTag, "item_id", &myItem_id ) ) ;
		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_Platform", &s_Platform ) ) ;
		TC_write_syslog ( "\nitem_id:", myItem_id );
		TC_write_syslog ( "\nplatform:", s_Platform );
		Load_tbl_pr_ws_obj_to_TCTRevTble ( objTag, s_Platform ) ;
	}
	return ITK_ok;
}
extern DLLAPI int DFC_TCT_save_method ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char *s_prj_code = NULL;
	int n_entries = 2 ;
    int n_found = 0 ;
	tag_t query = NULLTAG;
    tag_t *cntr_objects	= NULL;
	char *s_project_desc = NULL;
	char myItem_id[20] = { 0 } ;
	char *s_item_id = NULL ;
	char *s_Platform = NULL ;
	tag_t projobj = NULLTAG ;
		
	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );//deprecated
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );
	TC_write_syslog ( "\nDFC_TCT_save_method type_name:%s", type_name ) ;
	if ( tc_strcmp ( type_name, "T5_DFC_TCT" ) == 0 )
	{

		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_ProjectCode", &s_prj_code ) ) ;
		TC_write_syslog ( "\nDFC_TCT_save_method s_prj_code:%s", s_prj_code ) ;
		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_Platform", &s_Platform ) ) ;
		TC_write_syslog ( "\nDFC_TCT_save_method s_Platform:%s", s_Platform ) ;

		ITK_CALL ( PROJ_find ( s_prj_code,&projobj ) ) ;
		ITK_CALL ( SA_set_current_project(projobj ) ) ;
	
		TC_write_syslog ( "\nDefault Project on DFC object : [%s]", s_prj_code ) ;


		char *qry_entries[2] = { "Project ID", "Active" } ;
		char *qry_values[2]	= { s_prj_code, "Y" } ;

		ITK_CALL ( AOM_ask_value_string ( objTag, "item_id", &s_item_id ) ) ;

		TC_write_syslog ( "\ns_item_id:%s", s_item_id ) ;

		if ( ( s_prj_code == NULL ) || ( s_item_id == NULL ) )
		{
			EMH_clear_errors ( ) ;
			EMH_store_error_s1 ( EMH_severity_error, ITK_errStore, "Project code null or item id null" ) ;
			TC_write_syslog ( "\nProject code null or item id null" ) ;
			return ITK_errStore;
		}
		sprintf ( myItem_id, "TCT-%s-%s", s_prj_code, s_item_id ) ;

		//ITK_CALL ( QRY_find ( "QueryProject", &query ) ) ;//obsoleted
		ITK_CALL ( QRY_find2 ( "QueryProject", &query ) ) ;
		if ( query )
		{
			TC_write_syslog ( "\nDFC Query Found3" ) ; fflush ( stdout ) ;
		}
		else
		{
			TC_write_syslog ( "\nDFC Query Not Found3" ) ; fflush ( stdout ) ;
		}
		ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
		TC_write_syslog ( "\nDFC n_found:%d", n_found ) ; fflush ( stdout ) ;
		if ( n_found > 0 )
		{
			// Get TC_Project property for project description
			ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "project_desc", &s_project_desc ) ) ;

			TC_write_syslog ( "\ns_project_desc:%s", s_project_desc ) ;

			//ITK_CALL ( AOM_lock ( objTag ) ) ;
			ITK_CALL(AOM_refresh(objTag,TRUE));
			ITK_CALL ( AOM_set_value_string ( objTag, "item_id", myItem_id ) ) ;
			ITK_CALL ( AOM_set_value_string ( objTag, "object_name", myItem_id ) ) ;
			ITK_CALL ( AOM_set_value_string ( objTag, "t5_ProjectDescription", s_project_desc ) ) ;
			ITK_CALL ( AOM_set_value_string ( objTag, "object_desc", s_project_desc ) ) ;

			//ITK_CALL ( AOM_save ( objTag ) ) ;//deprecated
			ITK_CALL(AOM_save_without_extensions( objTag) );
			
			ITK_CALL ( AOM_unlock ( objTag ) ) ;

			
		}
		else
		{
			TC_write_syslog ( "\nActive project not found" ) ;
			EMH_clear_errors ( ) ;
			EMH_store_error_s1 ( EMH_severity_error, ITK_errStore, "Active project not found" ) ;
			return ITK_errStore;
		}
	}
	return ITK_ok;

}

int myAskLOVPlatformValuesMethod ( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag = va_arg(args, const tag_t);
    int* n_values = va_arg(args, int*);
    char ***values = va_arg(args, char***);
	int status;
    int error_code = ITK_ok;

	char *entry_fields[1] = {"SYSCD"};
	char *value_fields[1]  = {"ModPlatform"};
	int no_of_entry = 1;
	tag_t PlatformQry = NULLTAG;
	int iCtrl_obj_Count = 0;
	tag_t *tPlatform_ObjTags = NULLTAG;
	char *s_PlatformList = NULL;

	char *v_PlatformList[50];
	int iPlatform_Count = 0;
	char *s_Platform_Tok = NULL;
	int i_index_ctrl_obj = 0;
	int i_platform_index = 0;


	TC_write_syslog("\n************** cmcreate_dynamic_lov.c::myAskLOVPlatformValuesMethodP");fflush(stdout);

	//ITK_CALL(QRY_find("ControlObjects", &PlatformQry));//obsoleted
	ITK_CALL(QRY_find2("ControlObjects", &PlatformQry));
	if (PlatformQry)
	{
		TC_write_syslog("\nPlatformqry Found Query2");fflush(stdout);
	}
	else
	{
		TC_write_syslog("\nPlatformqry - Not Found Query2");fflush(stdout);
	}
	ITK_CALL(QRY_execute(PlatformQry,no_of_entry,entry_fields,value_fields,&iCtrl_obj_Count,&tPlatform_ObjTags));

    TC_write_syslog("\nControl object count:[%d]", iCtrl_obj_Count);fflush(stdout);
	for (i_index_ctrl_obj = 0; i_index_ctrl_obj < iCtrl_obj_Count; i_index_ctrl_obj++)
	{
		ITK_CALL ( AOM_ask_value_string(tPlatform_ObjTags[i_index_ctrl_obj],"t5_Userinfo1",&s_PlatformList));
		TC_write_syslog("\ns_PlatformList:%s",s_PlatformList);
		s_Platform_Tok = tc_strtok ( s_PlatformList, ";" );
		TC_write_syslog("\n1 s_Platform_Tok:%s",s_Platform_Tok);
		if ( ( s_Platform_Tok != NULL ) && ( tc_strcmp ( s_Platform_Tok, "" ) != 0 ) )
		{
			v_PlatformList[iPlatform_Count] = s_Platform_Tok;	//save 1st not null value
			TC_write_syslog("\n1iPlatform_Count:[%d]",iPlatform_Count);
			TC_write_syslog("\n1v_PlatformList[iPlatform_Count]:[%s]",v_PlatformList[iPlatform_Count]);
			TC_write_syslog("\n1s_Platform_Tok:[%s]",s_Platform_Tok);

			iPlatform_Count = iPlatform_Count + 1 ;
			
			while ( ( s_Platform_Tok != NULL ) && ( tc_strcmp ( s_Platform_Tok, "" ) != 0 ) )
			{
				s_Platform_Tok = tc_strtok ( NULL, ";" );
				if ( ( s_Platform_Tok != NULL ) && ( tc_strcmp ( s_Platform_Tok, "" ) != 0 ) )
				{
					v_PlatformList[iPlatform_Count] = s_Platform_Tok;	//save next all values
					TC_write_syslog("\n2iPlatform_Count:[%d]",iPlatform_Count);
					TC_write_syslog("\n2v_PlatformList[iPlatform_Count]:[%s]",v_PlatformList[iPlatform_Count]);
					TC_write_syslog("\n2s_Platform_Tok:[%s]",s_Platform_Tok);
					iPlatform_Count = iPlatform_Count + 1 ;
					
				}
			}
		}
		*n_values = iPlatform_Count;
		TC_write_syslog("\nPlatform count *n_values:[%d]\n", *n_values);fflush(stdout);
		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));
		for (i_platform_index = 0; i_platform_index < *n_values; i_platform_index++)
		{
			(*values)[i_platform_index] = (char *) MEM_alloc (strlen(v_PlatformList[i_platform_index]) + 1);
			strcpy((*values)[i_platform_index], v_PlatformList[i_platform_index]);
			TC_write_syslog("\n(*values)[i_platform_index]:%s",(*values)[i_platform_index]);
		}
		tm_TAG_free(tPlatform_ObjTags);
		tm_TAG_free(*v_PlatformList);
		
	}
return error_code;
}

int myAsk_TCT_Prj_LOVValuesMethod ( METHOD_message_t *msg, va_list  args )
{
    tag_t	lov_tag		= va_arg(args, const tag_t);
    int*	n_values	= va_arg(args, int*);
    char	***values	= va_arg(args, char***);
	char	*dfc_tct_project_code;
	int		status;

	int error_code = ITK_ok ;
	int n_entries = 2 ;
	int n_found = 0 ;
	int ii = 0 ;
    tag_t query = NULLTAG;
    tag_t *cntr_objects	= NULL;
    tag_t user = NULLTAG;
    char *qry_entries[2] = {"Project ID","Active"} ;
    char *qry_values[2]	= {"*","True"} ;

    TC_write_syslog("\n************** TCT PROJ_dynamic_lov.c::myAsk_TCT_Prj_LOVValuesMethod ");fflush(stdout);

    //ITK_CALL(QRY_find("QueryProject", &query));//obsoleted
    ITK_CALL(QRY_find2("QueryProject", &query));
	TC_write_syslog("\nAfter ITK_CALL : QRY_find2 \n");fflush(stdout);
	if (query)
	{
		TC_write_syslog("\nFound Query");fflush(stdout);
	}
	else
	{
		TC_write_syslog("\nNot Found Query");fflush(stdout);
	}

    ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    TC_write_syslog("\nProject Found:%d", n_found);fflush(stdout);

    *n_values = n_found;
    //TC_write_syslog("\n####### = %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"project_id",&dfc_tct_project_code));
		TC_write_syslog("\nProject id:%s",dfc_tct_project_code ) ;

		(*values)[ii] = (char *) MEM_alloc (strlen(dfc_tct_project_code) + 1);
        strcpy((*values)[ii], dfc_tct_project_code);
    }
    tm_TAG_free(cntr_objects);
    tm_TAG_free(dfc_tct_project_code);

    return error_code;
}

extern int tm_dfc_tct_register_method(int *decision, va_list args)
{
	METHOD_id_t  method_save;
	METHOD_id_t  method_save_post_act;
	METHOD_id_t  method;
	METHOD_id_t  methoddum1 ;
	METHOD_id_t  methoddum ;
	int	ifail = 0;

	*decision = ALL_CUSTOMIZATIONS;

	ITK_CALL ( METHOD_find_method ( "T5_DFC_TCT", "IMAN_save", &method_save  ) ) ;
	if ( method_save.id != NULLTAG )
	{
		ITK_CALL ( METHOD_add_action ( method_save, METHOD_pre_action_type, (METHOD_function_t) DFC_TCT_save_method, NULL ) ) ;
	}

	ITK_CALL ( METHOD_find_method ( "T5_DFC_TCT", "IMAN_save", &method_save_post_act  ) );
	if ( method_save_post_act.id != NULLTAG )
	{
		ITK_CALL ( METHOD_add_action ( method_save_post_act, METHOD_post_action_type, (METHOD_function_t) DFC_TCT_save_method_post, NULL ) ) ;
	}
	
	ITK_CALL ( EPM_register_action_handler ( "TCT-action-handler", "Placement: Assign Task Action of select-signoff-team task", (EPM_action_handler_t)Assign_TCT_Platform_Review_Func ) ) ;
	
	ITK_CALL ( METHOD_register_method( "T5_TCT_ProjCodeLOVType", LOV_ask_values_msg, &myAsk_TCT_Prj_LOVValuesMethod, 0, &method ) );

	ITK_CALL ( METHOD_register_method( "T5_TCT_PlatformLovType", LOV_ask_values_msg, &myAskLOVPlatformValuesMethod, 0, &method ) );

}
DLLAPI int tm_dfc_tct_register_callbacks ( )
{
	int ifail = 0 ;
	//printf("\nStarting tm_dfc_tct...");
	TC_write_syslog("\nStarting tm_dfc_tct...");
	if ( CUSTOM_register_exit ( "tm_dfc_tct", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_dfc_tct_register_method) != ITK_ok ) ;
	return ( ITK_ok );
}
