
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_cmvr.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   10-12-2019
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 10-12-2019   	 Rajesh Raman Basak			this is used to generate auto Intent No & CMVR NO during CMVR Type Intent Approval Creation

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <fclasses/tc_time.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <ps/ps_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_basic.h>
#include<ics/ics.h>
#include<ics/ics2.h>
#include<ics/ics_defines.h>
#include<ics/ics_errors.h>
#include <bom/bom_errors.h>
#include <bom/bom_msg.h>
#include <bom/bomlines.h>
#include <common/tc_deprecation_macros.h>
#define ITK_err 910001
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text(stat,&err_string);								\
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int CmvrSaveAsPostBypass();
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr character found===%s",(*strset)[*count-1]);fflush(stdout);



}

int printObject(tag_t objtag)
{

               int                prop_count=0;
               char**             prop_names=NULL;
               int        num_values=0;
               char**     values =NULL;
               tag_t                   class_tag=NULLTAG;
               char                     *class_name=NULL;
               int j=0,k=0;

               logical propConstReqBool=false;

               int ifail=ITK_ok;

               printf("\n printObject()->");fflush(stdout);

     if(objtag==NULLTAG)
     {
                printf("\nNULLTAG");fflush(stdout);
                return ifail;
     }
               /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
               ITK_CALL(POM_name_of_class(class_tag, &class_name) );

*/
     char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

     ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



               ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
               printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
               // printf("\n printObject2 %d",prop_count);fflush(stdout);

               for (k=0;k<prop_count;k++)
               {
               //ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values));
			   ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values));

               tag_t prop_tag = NULLTAG;
               ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
               printf("\n %s:{,[",prop_names[k]);fflush(stdout);

               propConstReqBool=false;
               char *prop_dispay_name=NULL;
               PROP_value_type_t valtype;
               char *valtypeName=NULL;
               ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

                                                                           printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
                                                                           printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
                                                                           printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
                                                                           printf("\n]\n");fflush(stdout);

               for(j=0;j<num_values;j++)
               {
               printf("\n\t%s,",values[j]);fflush(stdout);
               }

               printf("\n },");fflush(stdout);

               }
               printf("\n]");fflush(stdout);
return ifail;
}
int getCmvrAttrObj( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n in getCmvrAttrObj func");fflush(stdout);
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);
	
	printf("\n b4 Qry getCmvrAttrObj");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getCmvrAttrObj");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getCmvrAttrObj control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}
int getCmvrAttrNoWrtTSBU( char *TechSpecBusunit,int   *retcmvrattrno )
{
	int ifail = ITK_ok;
	
	//tag_t        query           = NULLTAG;	
	tag_t    *RetICOCmvrNoContrlObjs=NULLTAG;
	char *CntrlObjName=NULL;
	char *CmvrAttrid=NULL;
	int CmvrAttridInt=0;
	int retCntrlObjcount=0;
	if(TechSpecBusunit)
	{
		
		retCntrlObjcount=0;
		ITKCALL(getCmvrAttrObj(TechSpecBusunit,"ICOCmvrAttrNo",&retCntrlObjcount,&RetICOCmvrNoContrlObjs));
		printf("\n after call getCmvrAttrObjfunc count: %d \n",retCntrlObjcount);fflush(stdout);
		if(retCntrlObjcount>0)
		{
			ITKCALL( AOM_ask_value_string(RetICOCmvrNoContrlObjs[0], "object_name", &CntrlObjName));
			printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
			AOM_ask_value_string( RetICOCmvrNoContrlObjs[0], "t5_Userinfo1", &CmvrAttrid);
			printf("\n after getCmvrAttrObj: info1[CmvrAttrid] =%s\n",CmvrAttrid);fflush(stdout);
		}
	}
	printf("\n 22getCmvrAttrObj: info1[CmvrAttrid] =%s\n",CmvrAttrid);fflush(stdout);
	if(CmvrAttrid!=NULL)
	{
		 CmvrAttridInt=atoi(CmvrAttrid);
	}
	if(CmvrAttridInt>0)
	{
		 *retcmvrattrno =CmvrAttridInt;
	}
	else
	{
		CmvrAttridInt=8171;
		printf("\n CmvrAttridInt=%d\n",CmvrAttridInt);fflush(stdout);
		 *retcmvrattrno =CmvrAttridInt;

	}
	printf("\n\n End Qry for getCmvrAttrNoWrtTSBU control object size ==%d with retcmvrattrno=%d\n",retCntrlObjcount,*retcmvrattrno);fflush(stdout);

	return ifail;
}





extern int DLLAPI CmvrToVcRelPostMsg( METHOD_message_t *msg, va_list  args )
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char   *Ptype_name=NULL;;
	//char   Stype_name[TCTYPE_name_size_c+1];
	char   *Stype_name=NULL;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *relation_name=NULL;
	char   *username  = NULL;
	char   *VCNum  = NULL;
	char 	*VCNumDup =NULL;
	char   *CmvrNo  = NULL;
	char   *CmvrNoDup  = NULL;
	char   *CmvrIntentNo  = NULL;
	char   *CmvrIntentNoDup  = NULL;
	char   *VcPartType  = NULL;
	char   *VcPartTypeDup  = NULL;
	char   *CmvrWFStepName  = NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	char *TaskAnlyst = NULL;
	//char *TaskAnlyst = NULL;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	tag_t	ccvMstrTag = NULLTAG;
	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries1[2]={"role_name1","Name"};
	int n_entries1=2;	
	tag_t user_tag=NULLTAG;
	char * user_name_string;
	//char       cRoleName[SA_name_size_c+1]  ;
	char       *cRoleName=NULL  ;
	char *group_name=NULL;
	char *TechSpecBusunit=NULL;
	char *TechSpecBusunitDup=NULL;
	char *CmvrBusUnit=NULL;
	char *CmvrBusUnitDup=NULL;								
	tag_t grp_tag;
	tag_t query1 = NULLTAG;
	tag_t *cntr_objects1 = NULL;
	tag_t tRole_name =NULLTAG;
	int n_found1=0;
	int j=0;
	int araiaccesflg=0;
	ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	printf("\n     CmvrToVcRelPostMsg primary_object  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	ITK_CALL( POM_get_user(&user_name_string,&user_tag)); 
	printf("\n after POM_get_user:%s\n",user_name_string);fflush(stdout);  
	if(primary_object!=NULLTAG)
	{
		AOM_ask_value_string( primary_object, "t5_CmvrNo", &CmvrNo);
		printf("\n\n\t\t CmvrNo :%s",CmvrNo);	fflush(stdout);
		AOM_ask_value_string( primary_object, "t5_IntentNumber", &CmvrIntentNo);
		printf("\n\n\t\t CmvrIntentNo :%s",CmvrIntentNo);	fflush(stdout);
	}
	if(CmvrNo)
	{
		tc_strdup(CmvrNo,&CmvrNoDup);
	}
	printf("\n\n\t\t CmvrNoDup :%s",CmvrNoDup);	fflush(stdout);
	if(CmvrIntentNo)
	{
		tc_strdup(CmvrIntentNo,&CmvrIntentNoDup);
	}
	printf("\n\n\t\t CmvrIntentNoDup :%s",CmvrIntentNoDup);	fflush(stdout);
	ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
	//ITKCALL(TCTYPE_ask_name(objTypeTag2,Stype_name));
	ITKCALL(TCTYPE_ask_name2(objTypeTag2,&Stype_name));
	printf("\n     CmvrToVcRelPostMsg secondary_object  Stype_name :: %s\n", Stype_name); fflush(stdout);

	ITKCALL(POM_get_user_id (&username));
	printf("\n\n  CmvrToVcRelPostMsg Session login User1 : %s\n",username); fflush(stdout);
	
	
	
	//Start TZ1.65
	
		qry_values1[0]="*";
		qry_values1[1]=user_name_string;
		
		//CALLAPI(QRY_find("QryKyWrd_iUnme_oRole", &query1));
		CALLAPI(QRY_find2("QryKyWrd_iUnme_oRole", &query1));
		printf("\nG[%s]-- ",user_name_string);fflush(stdout);

		CALLAPI(QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		printf("\n no of groups for user[%s]   %d found",user_name_string, n_found1);fflush(stdout);
		//TotalLovCount = 0;                
		if(n_found1>0)
		{
			printf("\nafter for loop n_found:%d",n_found1);
			araiaccesflg=0;
			for (j=0;j<n_found1;j++ )
			{
		//		printf("\n Entered Loop \n");fflush(stdout);
				tRole_name	=	NULLTAG;
				
				// printf("\n Before getting tag \n");fflush(stdout);
				grp_tag = cntr_objects1[j];
				// printf("\n Before call: \n");fflush(stdout);
				ITK_CALL(SA_ask_groupmember_role(grp_tag,&tRole_name));
				//ITK_CALL(SA_ask_role_name(tRole_name,cRoleName));
				ITK_CALL(SA_ask_role_name2(tRole_name,&cRoleName));
				printf("\n cRoleName:%s \n",cRoleName);fflush(stdout);	
			
				ITK_CALL(AOM_ask_value_string(grp_tag,"object_name",&group_name));
				printf("\n group name:%s ..............",group_name);fflush(stdout);
				//if(tc_strcmp(group_name, "dba")==0)
				if(tc_strcmp(cRoleName, "DBA")==0 || tc_strcmp(group_name, "dba")==0)
				{
					printf("\n inside the loop dba group name:%s cRoleName=%s",group_name,cRoleName);fflush(stdout);
					break;
	
				}
				
				if(tc_strstr(cRoleName, "ARAI_Initiator_Role")!=NULL)
				{
					printf("\n inside the ARAI_Initiator_Role group name:%s cRoleName=%s",group_name,cRoleName);fflush(stdout);
					araiaccesflg=1;
					break;
	
				}
			}
		}
	
	//End TZ1.65
	if(tc_strstr(group_name, "dba")==NULL)
	{
					if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"rrb06909") !=0)
					{	
						CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&CmvrWFStepName));
						printf("\n primary CmvrWFStepName is :- %s\n",CmvrWFStepName);fflush(stdout);
						if(CmvrWFStepName == NULL)	
						{
							printf("\n CMVR must be active in CMVR Workflow !!! \n");fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_err,"CMVR must be active in CMVR Workflow !! ");
							//decision = EPM_nogo;
							return ITK_err;
						}
						else if (tc_strstr(CmvrWFStepName,"Create Relation between Intent and Vehicle")!=NULL)
						{
						CALLAPI(POM_get_user_id (&username));
						printf("\n\n  Session login User1 for CMVR : %s\n",username); fflush(stdout);

						
							
								//Check Analyst
								CALLAPI(AOM_UIF_ask_value(primary_object,"t5_InitiatedBy",&TaskAnlyst));
								printf("\n\n  InitiatedBy for CMVR : %s\n",TaskAnlyst); fflush(stdout);
								if(tc_strcmp(TaskAnlyst,"loader")!=0)
								{
									if(tc_strcmp(username,TaskAnlyst) !=0)
									{
										printf("\n Session User is Not CMVR Initor..Only CMVR Initiator can make relation between CMVR & VC:%s",TaskAnlyst); fflush(stdout);
										EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not in CMVR Initor Group ..Only CMVR Initiator can make relation between CMVR & VC:- ",username);
										return ITK_err;
									}
									else
									{
										printf("\n allow to process the CMVR & VC relation coz CMVR active in WF with assignment  %s\n",CmvrWFStepName);fflush(stdout);		
									}
								}
								else
								{
									printf("\n Session User[%s] araiaccesflg[%d]",username,araiaccesflg); fflush(stdout);
									if(tc_strcmp(username,"loader")==0)
									{
										printf("\n allow to process the CMVR & VC relation with loader login  %s\n",username);fflush(stdout);		
									}
									else
									{
										if(araiaccesflg>0)
										{
											printf("\n allow to process the CMVR & VC relation coz CMVR active in WF with assignment [%s]\n",CmvrWFStepName);fflush(stdout);		
										}
										else
										{
											printf("\n Session User is Not CMVR Initor..Only CMVR Initiator can make relation between CMVR & VC:%s",username); fflush(stdout);
											EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not in CMVR Initor Group..Only CMVR Initiator can make relation between CMVR & VC:- ",username);
											return ITK_err;
										}
									}
									
								}
							
								

						}
						else
						{	
							printf("\n CMVR must be active in CMVR Workflow & Assignment must be with <Create Relation between Intent and Vehicle.> !!! \n");fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_err,"CMVR must be active in CMVR Workflow & Assignment must be with <Create Relation between Intent and Vehicle> !!! ");
							//decision = EPM_nogo;
							return ITK_err;
						}
						
					}
					else
					{
						printf("\n session user is loader/infodba,CMVR can get attach with Vehicle !!! \n");fflush(stdout);
					}
	
	}
	//Create Relation between Intent and Vehicle.
	
	
	
	if(tc_strcmp(Ptype_name,"T5_CMVR")==0)
	{
		if(relation_type != NULLTAG)
		{
			//ITKCALL(TCTYPE_ask_name( relation_type, relation_name));
			ITKCALL(TCTYPE_ask_name2( relation_type, &relation_name));
		}

		if(tc_strcmp(relation_name,"T5_CmvrVeh")==0)
		{
			if(tc_strcmp(Stype_name,"Design Revision")==0)
			{
														
				ITKCALL(WSOM_ask_release_status_list(secondary_object,&st_count,&status_list));
				printf("\n\n\t\t inside cmvr to VC relation :Child Status Count  is :%d",st_count);	fflush(stdout);
				
				AOM_ask_value_string( secondary_object, "item_id", &VCNum);
				printf("\n\n\t\t VCNumc :%s",VCNum);	fflush(stdout);
				if(VCNum)
				{
					tc_strdup(VCNum,&VCNumDup);
				}
				printf("\n\n\t\t VCNumDup :%s",VCNumDup);	fflush(stdout);
				AOM_ask_value_string( secondary_object, "t5_PartType", &VcPartType);
				printf("\n\n\t\t VcPartType :%s",VcPartType);	fflush(stdout);
				if (st_count>0)
				{
					lcstatcnt=0;
					//if(tc_strcmp(VcPartType,"V")==0 || tc_strcmp(VcPartType,"VC")==0 || tc_strcmp(VcPartType,"VCCR")==0 || tc_strcmp(VcPartType,"CCVC")==0)
					if(tc_strcmp(VcPartType,"V")==0 || tc_strcmp(VcPartType,"VCCR")==0 || tc_strcmp(VcPartType,"CCVC")==0)
					{
						for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsErcRlzd
						{
							char* c_st_class_name	=	NULL;
							ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
							printf("\n inside cmvr to VC relation :c_st_class_name: %s:\n",c_st_class_name);fflush(stdout);													
							//if(tc_strcmp(c_st_class_name,"T5_LcsErcRlzd")==0 ) 
							if((tc_strcmp(c_st_class_name,"T5_LcsErcRlzd")==0) ||(tc_strcmp(c_st_class_name,"T5_LcsAPLWrkg")==0) ||(tc_strcmp(c_st_class_name,"T5_LcsAplRlzd")==0)||(tc_strcmp(c_st_class_name,"T5_LcsSTDWrkg")==0)||(tc_strcmp(c_st_class_name,"T5_LcsStdRlzd")==0))
							{
								printf("\n inside cmvr to VC relation :satisfy the release status[%s]  ",c_st_class_name);fflush(stdout);								
								lcstatcnt++;
								
								//getting techspec of VC
								tag_t task_relation_type = NULLTAG;
								int TScount=0;
								tag_t *primaryobjs = NULLTAG;
								tag_t TechSpecObjTag = NULLTAG;
								char *TechSpecNum=NULL;
								
								GRM_find_relation_type("T5_VCSpec",&task_relation_type);
								if(task_relation_type != NULLTAG)
								{
									//CALLAPI(TCTYPE_ask_name( task_relation_type, relation_name));
									CALLAPI(GRM_list_secondary_objects_only(secondary_object,task_relation_type,&TScount,&primaryobjs));
									printf("\n TScount: %d\n", TScount);fflush(stdout);
									if(TScount>0)
									{
										TechSpecObjTag=primaryobjs[0];
										AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum);
										printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
										AOM_ask_value_string(TechSpecObjTag,"t5_VCClassName",&TechSpecBusunit);
										printf("\n TechSpecBusunit: %s\n", TechSpecBusunit);fflush(stdout);
										if(TechSpecBusunit)
										{
											tc_strdup(TechSpecBusunit,&TechSpecBusunitDup);
										}
										printf("\n\n\t\t TechSpecBusunitDup :%s",TechSpecBusunitDup);	fflush(stdout);
									}
								}
								
								//End techspec of VC
								
								//find the classified object for above tech Spec
								
								CALLAPI(ITEM_ask_item_of_rev(secondary_object,&ccvMstrTag));
								CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
								printf("\n classified object count[%d] for CCV[%s] !!",cnt,VCNum); fflush(stdout);
								if(cnt>0)
								{
									
										//client code logic need to place here for backend mode
										
										tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
										tag_t   qryTagCntrl1     = NULLTAG;
										int     n_entryCntrl1    = 3;
										char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
										char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
										int cntrlcnt=0;
										int  control_number_found1=0;
										char* shellpath = NULL;
										char* sysCmnd = NULL;
										
										//if(QRY_find("Control Objects...", &qryTagCntrl1));
										if(QRY_find2("Control Objects...", &qryTagCntrl1));
										if (qryTagCntrl1)
										{
											printf("\n Control Object Query Found \n");fflush(stdout);
											qry_valuesCntrl1[0]="CmvrVehRelByCC";
											qry_valuesCntrl1[1]="Live";
											qry_valuesCntrl1[2]="0";
											
											if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
										}
										else
										{
											printf("\n Control Object Query not Found .... \n");fflush(stdout);
											
										}	
										
										printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
										
										if(control_number_found1>0)
										{
													printf("\n Control Object CmvrVehRelByCC Found \n");fflush(stdout);
											
																							
													ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
													
													printf("\n CmvrVehRelByCC shellpath==>%s\n",shellpath);fflush(stdout);
														if(tc_strlen(shellpath)>0)
														{
															printf("\ninside CmvrVehRelByCC Execute through client code......\n");fflush(stdout);
															
															
															sysCmnd=(char *) MEM_alloc(400);
															tc_strcpy(sysCmnd,shellpath);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-cmvr=);
															tc_strcat(sysCmnd,CmvrIntentNoDup);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-veh=);
															tc_strcat(sysCmnd,VCNumDup);
															printf("\n before-- Calling shell file tm_CmvrVehRelByCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															system(sysCmnd);
															
															printf("\n after --- Calling shell file tm_CmvrVehRelByCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															
															MEM_free(sysCmnd);
														}
													
												
											
										}									
										//end new process
									//start old process without client code 
									else
									{
										
										printf("\n inside the else condition of CmvrVehRelByCC Control Object not Found with delInd false\n");fflush(stdout);

										
										
										char * 	theClassId =NULL;
										int  	theAttributeCount;
										int * 	theAttributeIds;
										int * 	theAttributeValCounts;
										char *** 	theAttributeValues;
										tag_t 	theICOTag=NULLTAG;
										printf("\n classifiction obj found for VC[%s] CmvrNoDup[%s]",VCNum,CmvrNoDup); fflush(stdout);
										
										char * 	key_lov_name;
										int  	options;
										int i;
										int keyfound=0;
										int  	n_lov_entries;
										char ** 	lov_keys;
										char ** 	lov_values;
										logical * 	deprecated_staus;
										char * 	owning_site;
										char *keyLovOfCmvrNo=MEM_alloc(100);
										int  	n_shared_sites;
										char ** 	shared_sites ;
										char * 	unctName=NULL;
										char *	shortName=NULL;
										char * 	unctUnit=NULL;
										int  	unctFormat=0;
										int intid2 =0;
										
										int retcount;
										printf("\n TechSpecBusunitDup: %s \n",TechSpecBusunitDup);fflush(stdout);
										CALLAPI(getCmvrAttrNoWrtTSBU(TechSpecBusunitDup,&retcount));
										printf("\n after call getCmvrAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
										intid2=retcount;
										printf("\n  before ICS_describe_unct intid2=%d",intid2); fflush(stdout);
										CALLAPI(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
										printf("\n After ICS_describe_unct ifail[%d]",ifail); fflush(stdout);
										if(ifail != ITK_ok)
										{
										printf("\n  intid2[%d] unctName[%s] shortName[%d] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
										return ifail;	
										}
										printf("\n  2intid2[%d] unctName[%s] shortName[%d] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
										 char theKeyLOVId[10];
										const char * 	key_lov_id;
										if(unctFormat)
										{
														
											sprintf(theKeyLOVId, "%d", unctFormat);
											key_lov_id=theKeyLOVId;	
											printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);	
										//const char * 	key_lov_id="-1104"; //cls attr id for CMVR_TYP_APPRVL_NO
										CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));

										printf("\n n_lov_entries=%d options=%d",n_lov_entries,options); fflush(stdout);
											for(i=0;i<n_lov_entries;i++)								
											{
												printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
												
												//if(tc_strcmp(lov_values[i],"AAMN0001")==0)
												if(tc_strcmp(lov_values[i],CmvrNoDup)==0)
												{
													keyfound++;
													strcpy(keyLovOfCmvrNo, lov_keys[i]);
												}
												
											}
										}
										
										
	//
										printf("\n keyLovofCmvrNo=%s ",keyLovOfCmvrNo); fflush(stdout);
										 int n_attrs = 1;
										 printf("\n 1111 intid2=%d",intid2); fflush(stdout);
										//int att_ids[1] = {8171};
										int att_ids[1] ={0};
										if(intid2>1)
										{
											att_ids[1] = intid2;
										}
										else
										{
											att_ids[1] = 8171;
										}
										 printf("\n 222"); fflush(stdout);
										
										int n_attr_val[1] = {1};
										 printf("\n 333"); fflush(stdout);
										char ***attr_vals;
										attr_vals = malloc(1 * sizeof(char **));
										// attr_vals = (char***) MEM_alloc( n_attrs * sizeof(char**) );

										 printf("\n 444"); fflush(stdout);
										// attr_vals[0] = (char**) MEM_alloc( n_attr_val[0] * sizeof(char*) );
										  printf("\n 555"); fflush(stdout);
										// attr_vals[1] = (char**) MEM_alloc( n_attr_val[1] * sizeof(char*) ); 
										printf("\n 22keyLovofCmvrNo=%s ",keyLovOfCmvrNo); fflush(stdout);
											attr_vals[0] = MEM_alloc(1 * sizeof(char *));
											attr_vals[1] = MEM_alloc(1 * sizeof(char *));
											//attr_vals[1] = MEM_alloc( 100 ); 
											//attr_vals[0][0] = (char *) MEM_alloc(tc_strlen(CmvrNoDup) + 1);

										//if(tc_strlen(keyLovOfCmvrNo)>0)
											printf("\n keyfound=%d ",keyfound); fflush(stdout);
										if(keyfound>0)
										{
											printf("\n inside set key for keyLovofCmvrNo=%s ",keyLovOfCmvrNo); fflush(stdout);
											attr_vals[0][0] = (char *) MEM_alloc(strlen( keyLovOfCmvrNo ) + 1);
											//attr_vals[0][0] = (char *) MEM_alloc( 100 ); 
											//malloc(nCols * sizeof(char *));
											strcpy(attr_vals[0][0], keyLovOfCmvrNo);
										}
										else
										{
										printf("\n Setting <NA> incase of key for keyLovofCmvrNo=%s not available !!",keyLovOfCmvrNo); fflush(stdout);
										attr_vals[0][0] = (char *) MEM_alloc(strlen( CmvrNoDup ) + 1);
										//attr_vals[0][0] = (char *) MEM_alloc( 100 ); 
										strcpy(attr_vals[0][0], CmvrNoDup);
										}
										
										
										
										theICOTag=*ClsObjTag;
										//printObject(theICOTag);	
										CALLAPI(ICS_ico_ask_all_attributes(theICOTag,&theAttributeCount,&theAttributeIds,&theAttributeValCounts,&theAttributeValues));
										printf("\n classifiction obj found for theAttributeCount[%d] theAttributeIds[%d] theAttributeValCounts[%d]",theAttributeCount,*theAttributeIds,*theAttributeValCounts); fflush(stdout);
										CALLAPI(ICS_ico_set_attributes(theICOTag,n_attrs,att_ids,n_attr_val,(const char***) attr_vals));
										 printf("\n after update cmvr no in classifiction obj found for VC[%s] CmvrNoDup[%s]",VCNum,CmvrNoDup); fflush(stdout);
									}
									
								}
								 else
								{
									printf("\n classifiction obj not found for VC [%s] ",VCNum); fflush(stdout);
									printf("\n Tech Spec of VC[%s] must be classified/Released prior to make relation with CMVR \n",VCNum);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec must be classified/Released prior to make make relation with CMVR for VC= ",VCNum);
									//decision = EPM_nogo;
									return ITK_err;
								} 
								 
								
								

							}
							
						}
						//VC Type need to be aadded
						printf("\n 22group_name=%s username=%s",group_name,username); fflush(stdout);
						//if(tc_strstr(group_name, "dba")==NULL)
						if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"rrb06909") !=0)
						{
							if(tc_strstr(cRoleName, "DBA")==NULL)
							{
								if(lcstatcnt>0)
								{
									printf("\n Allow to make relation between CMVR and  VC[%s] ",VCNum); fflush(stdout);
								}
								else
								{
									printf("\n VC must be ERC Released and above,Allow only released VC to make relation with CMVR \n");fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_error,ITK_err,"VC is not released,Allow only released VC to make relation with CMVR ");
									//decision = EPM_nogo;
									return ITK_err;
								}
							}
							else
							{
								printf("\n Allow to make relation between CMVR and  VC[%s] for DBA Role ",VCNum); fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Part Type must be Veh/CCVC/VCCR to make relation with CMVR \n");fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type must be Vehicle or Configurable VC to make relation with CMVR ");
							//decision = EPM_nogo;
							return ITK_err;
					}
				}
				else
				{
					printf("\n inside cmvr to VC relation :has no status, so relation will not get create with group_name=%s",group_name);fflush(stdout);
					if(tc_strstr(group_name, "dba")==NULL)
					{
					EMH_clear_errors();
					status=EMH_store_error_s1(EMH_severity_error,ITK_err,"No ERC Release status found for selected Vehicle/CVVC!!");
					//decision = EPM_nogo;
					return ITK_err;
					}
				}
				
				
			
			}
		
		}
		else
		{
			printf("\n NO CMVR relation class \n");fflush(stdout);
		}

	}

	return ITK_ok;

}


int getQueryAllCmvr( const char *val,int   *n_found ,tag_t    **t_item1)
{
	int ifail = ITK_ok;
	printf("\n in getQueryAllCmvr func");fflush(stdout);
	printf("\n\n Input CmvrIntentNum==%s \n",val);fflush(stdout);
	tag_t        query           = NULLTAG;
	char *cmvrintentdup=NULL;
	 cmvrintentdup = (char *) MEM_alloc( 200 * sizeof(char) );
	 tc_strcpy(cmvrintentdup,val);
	// tc_strcat(TaskID,"*");
	printf("\n\n CMVR IntentNumber would be qry with==%s \n",cmvrintentdup);fflush(stdout);

	char  *qry_entries3[] = {"Request ID/Intent NO"},
	*qry_values3[]       = {cmvrintentdup};

	printf("\n b4 Qry CmvrQry");fflush(stdout);

	//QRY_find("CmvrQry", &query);
	QRY_find2("CmvrQry", &query);
	printf("\n in after qry find CmvrQry");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, t_item1);
	printf("\n\n End Qry getQueryAllTask ==%s \n",cmvrintentdup);fflush(stdout);

	return ifail;
}


int ChkExistingCmvrNoFunc( const char *val,char *IntentbaseSrz,int   *n_found ,tag_t    **t_item1)
{
	int ifail = ITK_ok;
	printf("\n in ChkExistingCmvrNoFunc func");fflush(stdout);
	printf("\n\n Input CmvrIntentNum==%s IntentbaseSrz=%s\n",val,IntentbaseSrz);fflush(stdout);
	tag_t        query           = NULLTAG;
	char *InpCmvrNo=NULL;
	 InpCmvrNo = (char *) MEM_alloc( 200 * sizeof(char) );
	 tc_strcpy(InpCmvrNo,val);
	// tc_strcat(TaskID,"*");
	printf("\n\n input CMVR No==%s \n",InpCmvrNo);fflush(stdout);

	char  *qry_entries3[] = {"CMVR NO","Request ID/Intent NO"},
	*qry_values3[]       = {InpCmvrNo,IntentbaseSrz};

	printf("\n b4 Qry CmvrQry");fflush(stdout);

	//QRY_find("CmvrQry", &query);
	QRY_find2("CmvrObjQryNew", &query);
	printf("\n in after qry find CmvrQry");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, t_item1);
	printf("\n\n End Qry n_found=%d ChkExistingCmvrNoFunc ==%s \n",*n_found,InpCmvrNo);fflush(stdout);

	return ifail;
}

int getDefaultUsr( char *val,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SUBSYSCD"},
	*qry_values3[]       = {val};

	printf("\n in getDefaultUsr func");fflush(stdout);
	printf("\n\n Input SUBSYSCD==%s \n",val);fflush(stdout);
	
	printf("\n b4 Qry getDefaultUsr");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getDefaultUsr");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getDefaultUsr control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}

/*dynamic generation of list of Initiator */
/****************************************************************************
Function:       dynamic_CmvrInitiator_LOV
Description:    This function used dynamic generation of list of Initiator to populate Initiator LOV
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_CmvrInitiator_LOV( char*** CmvrInitiatorLovValue  ) 
{

/* va_list for LOV_ask_values_msg */

 
	char   *user_name_string = NULL;
	int status;
	int j =0;
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;
	char  ***values = NULL;
	int        control_number_found;
	WSO_search_criteria_t  	criteria_control;
	int  ifail = ITK_ok;
	int max_char_size = 50;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	//char				userid[SA_user_size_c+1]; 
	char				*userid=NULL; 
	tag_t			group_tag			= NULLTAG;
	tag_t  user = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	char *CmvrInitiatorUsr = NULL;
	char *DefaultInitiator = NULL;
	tag_t			*RetContrlObjs				=NULLTAG;
	int   n_found=0;
	int Lov_cnt=0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	
	//int				j					= 0;
  
	   printf("\n inside func dynamic_CmvrInitiator_LOV");fflush(stdout);

		CALLAPI(SA_init_module());
		printf("\n SA_init_module");fflush(stdout);
		CALLAPI(POM_get_user(&user_name_string, &user));
		printf("\n POM_get_user");fflush(stdout);

		tag_t  CurrentRoleTag = NULLTAG;
		//char       roleName[SA_name_size_c+1]  ;
		char       *roleName=NULL  ;
		//char       rolename[SA_name_size_c+1]  ;
		char       *rolename=NULL  ;
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		//ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		char *GrpName=(char *) MEM_alloc(100 * sizeof(char *));
		tc_strcpy(GrpName,"ARAI_Initiator_Grp");
		printf("\n ARAI User Group Name:[%s]\n",GrpName);fflush(stdout);
		CALLAPI(SA_find_group(GrpName,&group_tag));
		if (group_tag != NULLTAG)
		CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nARAI No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	//set default value
	
	CALLAPI(getDefaultUsr( "CmvrDefaultUser",&n_found ,&RetContrlObjs));  //SUBSYSCD=CmvrDefaultUser
	printf("\n DefaultInitiator n_found: %d\n",n_found);fflush(stdout);
	if(n_found>0)
	{
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo1", &DefaultInitiator);
		printf("\n DefaultInitiator: %s\n",DefaultInitiator);fflush(stdout);
		if(DefaultInitiator)
		{
		setAddStr(&Lov_cnt,CmvrInitiatorLovValue,DefaultInitiator);
		}
	}
	//End
	if(num_of_roles>0)
	{
		
		for (i=0;i<num_of_roles ;i++ )
		{
				//CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nARAI Rol Name :[%d][%s] tc_strlen(rolename)=%d\n",i,rolename,tc_strlen(rolename));fflush(stdout);
				if (tc_strlen(rolename)>0)
				{
					
					
					CALLAPI(SA_find_groupmember_by_role(role_tags[0],group_tag,&num_of_members,&member_tags));
					printf("\nARAI No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							//CALLAPI(SA_ask_user_identifier(user_tag,userid));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nARAI grp access User ID Name :[%s]\n",userid);fflush(stdout);
							if(userid!=NULL)
							{
								 printf("\n inside SetAddStr CmvrInitiatorUsr: %s ",userid);
								 //CmvrInitiatorUsr = (char *)MEM_alloc(max_char_size * strlen(userid)+1);
								setAddStr(&Lov_cnt,CmvrInitiatorLovValue,userid);
							}
						}
					}
				}
		}

		
	}
	
	printf("\n End func dynamic_CmvrInitiator_LOV !!");fflush(stdout);			
			
//end by Rajesh

    return Lov_cnt;
}



/****************************************************************************
Function:       dynamic_CmvrInitiatorMethod
Description:    This function used to register method for CmvrInitiatorLovValue
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_CmvrInitiatorMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, const tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **CmvrInitiatorLovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n inside dynamic_CmvrInitiatorMethod process	");fflush(stdout);
  
  *length=dynamic_CmvrInitiator_LOV(&CmvrInitiatorLovValue);
  printf("\n dynamic_CmvrInitiatorMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_CmvrInitiator_ValuesMethod
Description:    This function used to get CMVR Initiator Value method
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_CmvrInitiator_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

               logical active = TRUE;
               tag_t lov_tag = va_arg (args, const tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
               int Lov_cnt=0;
   
  
                printf("\n inside dynamic_CmvrInitiator_ValuesMethod method");fflush(stdout);
                 
                *n_values=dynamic_CmvrInitiator_LOV(&LR_LovValue);
               printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);
				*values = (char **) MEM_alloc (*n_values * sizeof (char*));
				//printf("\n memory allocated for *values" );fflush(stdout);
               memset (*values, 0,  *n_values * sizeof(char*));
			  // printf("\n memset memory allocated for *values with *n_values size[%d]",*n_values );fflush(stdout);
               for (ii = 0; ii < *n_values; ii++)
               { 
                               //printf("\n inside loop to new memory allocated for *values" );fflush(stdout);                                                          
                              (*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
							   //printf("\n after new memory allocated for *values" );fflush(stdout);    
                              tc_strcpy ((*values)[ii], LR_LovValue[ii]);
							  //printf("\n after dynamic lov copied to *values" );fflush(stdout);
                                                               
               } 
      printf("\n End of func dynamic_CmvrInitiator_ValuesMethod with ifail val[%d]",ifail );fflush(stdout);           
    return ifail; 
}

/*dynamic generation of list of CMVR Approver */
/****************************************************************************
Function:       dynamic_CmvrApproverLov
Description:    This function used dynamic generation of list of Initiator to populate Initiator LOV
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_CmvrApproverLov( char*** CmvrInitiatorLovValue  ) 
{

/* va_list for LOV_ask_values_msg */

 
	char   *user_name_string = NULL;
	int status;
	int j =0;
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;
	char  ***values = NULL;
	int        control_number_found;
	WSO_search_criteria_t  	criteria_control;
	int  ifail = ITK_ok;
	int max_char_size = 50;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t			group_tag			= NULLTAG;
	char *DefaultApprover = NULL;
	tag_t			*RetContrlObjs				=NULLTAG;
	int   n_found=0;
	//char				userid[SA_user_size_c+1]; 
	char				*userid=NULL; 
	//Version =	  MEM_alloc(50000);
	tag_t  user = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	char *CmvrInitiatorUsr = NULL;
	int Lov_cnt=0;
 
	   printf("\n inside func dynamic_CmvrApproverLov");fflush(stdout);

		CALLAPI(SA_init_module());
		printf("\n SA_init_module");fflush(stdout);
		CALLAPI(POM_get_user(&user_name_string, &user));
		printf("\n POM_get_user");fflush(stdout);

		tag_t  CurrentRoleTag = NULLTAG;
		char       *roleName=NULL  ;
		//char       rolename[SA_name_size_c+1]  ;
		char       *rolename=NULL  ;
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		char *GrpName=(char *) MEM_alloc(100 * sizeof(char *));
		tc_strcpy(GrpName,"ARAI_Approver_Grp");
		printf("\n ARAI User Group Name:[%s]\n",GrpName);fflush(stdout);
		CALLAPI(SA_find_group(GrpName,&group_tag));
		if (group_tag != NULLTAG)
		CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nARAI No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	//set default value
	
	CALLAPI(getDefaultUsr( "CmvrDefaultUser",&n_found ,&RetContrlObjs));  //SUBSYSCD=CmvrDefaultUser
	printf("\n DefaultApprover n_found: %d\n",n_found);fflush(stdout);
	if(n_found>0)
	{
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo2", &DefaultApprover);
		printf("\n DefaultApprover: %s\n",DefaultApprover);fflush(stdout);
		if(DefaultApprover)
		{
		setAddStr(&Lov_cnt,CmvrInitiatorLovValue,DefaultApprover);
		}
	}
	//End
	
	if(num_of_roles>0)
	{
		
		for (i=0;i<num_of_roles ;i++ )
		{
				//CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nARAI Rol Name :[%d][%s] tc_strlen(rolename)=%d\n",i,rolename,tc_strlen(rolename));fflush(stdout);
				if (tc_strlen(rolename)>0)
				{
					
					
					CALLAPI(SA_find_groupmember_by_role(role_tags[0],group_tag,&num_of_members,&member_tags));
					printf("\nARAI No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\ndynamic_CmvrApproverLov access User ID Name :[%s]\n",userid);fflush(stdout);
							if(userid!=NULL)
							{
								 printf("\n inside b4 SetAddStr dynamic_CmvrApproverLovUser: %s ",userid);
								 //CmvrInitiatorUsr = (char *)MEM_alloc(max_char_size * strlen(userid)+1);
								setAddStr(&Lov_cnt,CmvrInitiatorLovValue,userid);
							}
						}
					}
				}
		}

		
	}
	
				
 printf("\n End func dynamic_CmvrApproverLov !!");fflush(stdout);		
//end by Rajesh

    return Lov_cnt;
}



/****************************************************************************
Function:       dynamic_CmvrApproverLovMethod
Description:    This function used to register method for dynamic_CmvrApproverLov
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_CmvrApproverLovMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, const tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **CmvrInitiatorLovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n inside dynamic_CmvrApproverLovMethod process	");fflush(stdout);
  
  *length=dynamic_CmvrApproverLov(&CmvrInitiatorLovValue);
  printf("\n dynamic_CmvrApproverLovMethod with lov length===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_CmvrApprover_ValuesMethod
Description:    This function used to get CMVR Initiator Value method
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_CmvrApprover_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

               logical active = TRUE;
               tag_t lov_tag = va_arg (args, const tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
               int Lov_cnt=0;
   
  
                printf("\n inside dynamic_CmvrApprover_ValuesMethod method");fflush(stdout);
                 
                *n_values=dynamic_CmvrApproverLov(&LR_LovValue);
               printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);
				*values = (char **) MEM_alloc (*n_values * sizeof (char*));
				//printf("\n memory allocated for *values" );fflush(stdout);
               memset (*values, 0,  *n_values * sizeof(char*));
			  // printf("\n memset memory allocated for *values with *n_values size[%d]",*n_values );fflush(stdout);
               for (ii = 0; ii < *n_values; ii++)
               { 
                               //printf("\n inside loop to new memory allocated for *values" );fflush(stdout);                                                          
                              (*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
							   //printf("\n after new memory allocated for *values" );fflush(stdout);    
                              tc_strcpy ((*values)[ii], LR_LovValue[ii]);
							  //printf("\n after dynamic lov copied to *values" );fflush(stdout);
                                                               
               } 
      printf("\n End of func dynamic_CmvrApprover_ValuesMethod with ifail val[%d]",ifail );fflush(stdout);           
    return ifail; 
}


// Func to getting Vehicle from CMVR Object 
extern DLLAPI int getCmvrFrmVeh(tag_t CMVRObj,tag_t* VehFrmTS)
{

	 printf("\n Start func getCmvrFrmVeh\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;


	ITK_CALL(GRM_find_relation_type("T5_CmvrVeh", &relType));

	printf("\n CMVRObj=%u relType=%u\n",CMVRObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(CMVRObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{

		*VehFrmTS = primary_objects[0];
		}

	}
	return ifail;	

	printf("\n End func getCmvrFrmVeh\n");fflush(stdout);

}


	extern DLLAPI int getCmvrRelationFrmVC(METHOD_message_t * message, va_list args )
	{

	printf("\n Start func getCmvrRelationFrmVC\n");fflush(stdout);
    int ifail = ITK_ok;
	tag_t *VehTag=NULLTAG;
	

        tag_t CmvrTag= message->object_tag;

        va_list largs;

        va_copy( largs, args);
        va_arg( largs, tag_t );
        VehTag = va_arg( largs, tag_t*);
        va_end( largs );

		

			printf("\n Calling func getCmvrFrmVeh\n");fflush(stdout);
			ITK_CALL(getCmvrFrmVeh(CmvrTag,VehTag));

			printf("\n After func call getCmvrFrmVeh VehTag=%u\n",VehTag);fflush(stdout);
			
				
			
			return ifail;	

		
			
	}

int tm_CmvrCreFun( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	//tag_t new_item         = NULLTAG;
	tag_t		*cmvr_obj	= NULLTAG;
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	//logical isnew              = 0;
	int CmvrFlag		   = 0;
	tag_t  user = NULLTAG;
	char   *user_name_string = NULL;
	tag_t			*RetContrlObjs				=NULLTAG;
	char *DefaultApprover = NULL;
	//signature for item create
	
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	
	
	//new_item               = va_arg(args, tag_t);
	//isnew                  = va_arg(args, int);
	printf("\n 	 inside tm_CmvrCreFun for post action tm_Cmvr creation !! ");fflush(stdout);
	//printf("\n Is CMVR New %d ",isnew);fflush(stdout);
	time_t 	now;
	struct 	tm	when;
	char 	CurrYear[6]		= "";
	char* from2 = CurrYear;  
	char *YearCode = MEM_alloc(10);
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);	
	strncpy(YearCode, from2+2,2);
	printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
	printf("\n--->>>>> cmvr Current Year >> %s  new_item=%u",CurrYear,new_item);fflush(stdout);
	
	//char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     //ITK_CALL(TCTYPE_ask_object_type(new_item,&type_tag));

     //ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));

	 printf("\n object type_name :  %s \n",type_name);fflush(stdout);	
	
	
	//set default value
	CALLAPI(SA_init_module());
		printf("\n SA_init_module");fflush(stdout);
		CALLAPI(POM_get_user(&user_name_string, &user));
		printf("\n POM_get_user[%s]",user_name_string);fflush(stdout);
		
		if(tc_strcmp(user_name_string,"loader")==0)
		{
		printf("\n Bypass auto creation logic for Loader user: %s\n",DefaultApprover);fflush(stdout);
		return ifail;
		}
		
	/* CALLAPI(getDefaultUsr( "CmvrDefaultUser",&n_found ,&RetContrlObjs));  //SUBSYSCD=CmvrDefaultUser
	printf("\n DefaultApprover n_found: %d\n",n_found);fflush(stdout);
	if(n_found>0)
	{
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo2", &DefaultApprover);
		printf("\n DefaultApprover: %s\n",DefaultApprover);fflush(stdout);
		
	} */
	
	
	
	//if(new_item != NULLTAG && isnew >1)
	//{
		char *loc 	   = NULL;
		char *ProjCode 	   = NULL;
		char **DesignGroupList = NULL;
		char **DMLMdAddList = NULL;
		char *SrlNo   = NULL;
		
		char *locDup 	   = NULL;
		char *ProjCodeDup 	   = NULL;
		//char *YearCode = NULL;
		char *YearCodeDup = NULL;
		char *CarbonMonOx 	   = NULL;
		char *CarbonMonOxDup 	   = NULL;
		char *HydCarb = NULL;
		char *HydCarbDup = NULL;
		
		char *ReactvHydCarb 	   = NULL;
		char *ReactvHydCarbDup 	   = NULL;
		char *HCNox = NULL;
		char *HCNoxDup = NULL;
		char *NonMethHc 	   = NULL;
		char *NonMethHcDup 	   = NULL;
		char *NOxD = NULL;
		char *NOxDup = NULL;
		
		char *PM 	   = NULL;
		char *PMDup 	   = NULL;
		char *HornSoundLvl = NULL;
		char *HornSoundLvlDup = NULL;
		char *NoiseLvl 	   = NULL;
		char *NoiseLvlDup 	   = NULL;
		
		char *letter1 	   = NULL;
		char *letter1Dup 	   = NULL;
		char *letter2 = NULL;
		char *letter2Dup = NULL;
		char *letter3 	   = NULL;
		char *letter3Dup 	   = NULL;
		char *letter4 	   = NULL;
		char *letter4Dup 	   = NULL;
		char *last4 	   = NULL;
		char *last4Dup 	   = NULL;
		int cmvrcnt1=0;
		char *ToBeNewCmvrNo 	   = NULL;
		char *ToBeNewCmvrNoDup 	   = NULL;
		char *NOx 	   = NULL;
		char *SrlNoDup 	   = NULL;
		char *CmvrIntentNum 	   = NULL;
		char *CmvrIntentNumDup 	   = NULL;
		char *ExCmvrNo 	   = NULL;
		char *ExCmvrNoDup 	   = NULL;
		char *IntentNoToBe 	   = NULL;
		char *IntentNoToBeDup 	   = NULL;
		char *CmvrDesc		= NULL;
		char *CmvrDescDup		= NULL;
		char *CmvrBusUnit=NULL;
		char *CmvrBusUnitDup=NULL;	
		char *CertExtnNo=NULL;
		char *CertExtnNoDup=NULL;	
		char *IntentNoToBeSrz = (char *)MEM_alloc(80 * sizeof(char));		
		char *NotifyMsg=NULL;
		
		int	 num,mad	   = 0;
		printf("\n inside class CMVR CRE......\n");fflush(stdout);
		if(*new_item)
		{
		//printObject(*new_item);	
		//}
		
		AOM_ask_value_string( *new_item, "t5_Intent_1", &loc);
		AOM_ask_value_string( *new_item, "t5_CmvrProjCode", &ProjCode);
		//AOM_ask_value_string( *new_item, "object_desc", &CmvrDesc);
		AOM_ask_value_string( *new_item, "object_name", &CmvrDesc);
		//AOM_ask_value_strings( new_item,"t5_Intent_3",&num,&DesignGroupList); //t5_Intent_3=Year will get runtime
		//AOM_ask_value_string( *new_item, "t5_Intent_4", &SrlNo);  //t5_Intent_4=Srl No
		AOM_ask_value_string( *new_item, "t5_last_4", &SrlNo);  //t5_Intent_4=Srl No
		}
	
		printf("\n loc : %s\n",loc);fflush(stdout);
		printf("\n ProjCode : %s\n",ProjCode);fflush(stdout);
		printf("\n SrlNo : %s\n",SrlNo);fflush(stdout);
		printf("\n CmvrDesc : %s\n",CmvrDesc);fflush(stdout);
		if(loc)
		{
			tc_strdup(loc,&locDup);
		}
		if(ProjCode)
		{
			tc_strdup(ProjCode,&ProjCodeDup);
		}
		if(CurrYear)
		{
			tc_strdup(CurrYear,&YearCodeDup);
		}
		
		if(SrlNo)
		{
			tc_strdup(SrlNo,&SrlNoDup);
		}
		if(CmvrDesc)
		{
			tc_strdup(CmvrDesc,&CmvrDescDup);
		}
		printf("\n locDup : %s  ProjCodeDup : %s YearCodeDup : %s  SrlNoDup : %s CmvrDescDup :%s\n",locDup,ProjCodeDup,YearCodeDup,SrlNoDup,CmvrDescDup);fflush(stdout);
		//Attr Values which will decide to create CMVR Intent approval object
		
		AOM_ask_value_string( *new_item, "t5_Pollutant_CM", &CarbonMonOx);
		printf("CarbonMonOx=%s\n",CarbonMonOx);fflush(stdout);
		if(CarbonMonOx)
		{
			tc_strdup(CarbonMonOx,&CarbonMonOxDup);
		}
		
		printf("Copied CarbonMonOxDup=%s\n",CarbonMonOxDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_HC", &HydCarb);
		printf("HydCarb=%s\n",HydCarb);fflush(stdout);
		if(HydCarb)
		{
			tc_strdup(HydCarb,&HydCarbDup);
		}
		
		printf("Copied HydCarbDup=%s\n",HydCarbDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_RHC", &ReactvHydCarb);
		printf("ReactvHydCarb=%s\n",ReactvHydCarb);fflush(stdout);
		if(ReactvHydCarb)
		{
			tc_strdup(ReactvHydCarb,&ReactvHydCarbDup);
		}
		
		printf("Copied ReactvHydCarbDup=%s\n",ReactvHydCarbDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_HCNO", &HCNox);
		printf("HCNox=%s\n",HCNox);fflush(stdout);
		if(HCNox)
		{
			tc_strdup(HCNox,&HCNoxDup);
		}
		
		printf("Copied HCNoxDup=%s\n",HCNoxDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_NH", &NonMethHc);
		printf("NonMethHc=%s\n",NonMethHc);fflush(stdout);
		if(NonMethHc)
		{
			tc_strdup(NonMethHc,&NonMethHcDup);
		}
		
		printf("Copied NonMethHcDup=%s\n",NonMethHcDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_NO", &NOx);
		printf("NOx=%s\n",NOx);fflush(stdout);
		if(NOx)
		{
			tc_strdup(NOx,&NOxDup);
		}
		
		printf("Copied NOxDup=%s\n",NOxDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_PM", &PM);
		printf("PM=%s\n",PM);fflush(stdout);
		if(PM)
		{
			tc_strdup(PM,&PMDup);
		}
		
		printf("Copied PMDup=%s\n",PMDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_Pollutant_HO", &HornSoundLvl);
		printf("HornSoundLvl=%s\n",HornSoundLvl);fflush(stdout);
		if(HornSoundLvl)
		{
			tc_strdup(HornSoundLvl,&HornSoundLvlDup);
		}
		
		printf("Copied HornSoundLvlDup=%s\n",HornSoundLvlDup);fflush(stdout);
		AOM_ask_value_string( *new_item, "t5_BystanderPos", &NoiseLvl);
		printf("NoiseLvl=%s\n",NoiseLvl);fflush(stdout);
		if(NoiseLvl)
		{
			tc_strdup(NoiseLvl,&NoiseLvlDup);
		}
		// CarbonMonOxDup,HydCarbDup,ReactvHydCarbDup,HCNoxDup,NonMethHcDup,NOxDup,PMDup,HornSoundLvlDup,NoiseLvlDup
		printf("Copied NoiseLvlDup=%s\n",NoiseLvlDup);fflush(stdout);
		//Need to use Query Builder to get CMVR Object to decide for new creation.....
		//char *qry_entries3[] = {"Carbon Monoxide","Hydrocarbon, if applicable","Reactive HC, if applicable","HC+NOx, if applicable","Non-Methane HC, if applicable","NOx, if applicable","PM, if applicable","Sound level of horn as installed on the vehicle","Pass-by Noise value"};
		char *qry_entries3[] = {"Carbon Monoxide/Carbon Monoxide (CO)","Hydrocarbon, if applicable/Hydrocarbon, (THC/HC)","Reactive HC, if applicable/THC + Nox","HC+NOx, if applicable/HC + Nox","Non-Methane HC, if applicable/Non-Methane Hydrocarbon (NMHC)","NOx, if applicable/Oxides of Nitrogen (NOx)","PM, if applicable/Mass of Particulate Matter (PM)","Sound level of horn as installed on the vehicle","Pass-by Noise value"};
		char *qry_values3[] = {CarbonMonOxDup,HydCarbDup,ReactvHydCarbDup,HCNoxDup,NonMethHcDup,NOxDup,PMDup,HornSoundLvlDup,NoiseLvlDup};
		//CALLAPI(QRY_find("CmvrObjQry", &query));
		CALLAPI(QRY_find2("CmvrObjQry", &query));
		CALLAPI(QRY_execute(query, 9, qry_entries3, qry_values3, &n_found, &cmvr_obj));
		printf("\n \n number of cmvr objs : %d \n",n_found);fflush(stdout);			
		if (n_found != 0)
		{
			tag_t 		CMVR_tag = 	NULLTAG;
			tag_t *Qrycmvrobjset                        		= NULLTAG;
			char *NewCmvrNo=NULL;
			char *IntNumStr=NULL;
			char *tmpStr= NULL;
			char *FuelType=NULL;
			
			tag_t status_rel		 = NULLTAG;
				logical 	retain;
			int cmvrcnt=0;
			NewCmvrNo = (char *) MEM_alloc( 50 * sizeof(char) );
			IntNumStr = (char *) MEM_alloc( 50 * sizeof(char) );
			
			printf("\n \n inside cond number of cmvr objs : %d \n",n_found);fflush(stdout);
			if(cmvr_obj[0])
			{
				CMVR_tag = cmvr_obj[0];
			}
			
			int number_found;
			int	status;
			tag_t *list_of_WSO_tags=NULLTAG;
			WSO_search_criteria_t  	criteria;
			char *IntentNoToBe = (char *)MEM_alloc(80 * sizeof(char));
			char *BaseIntentNo = (char *)MEM_alloc(80 * sizeof(char));
			tc_strcpy(IntentNoToBe,locDup);
			tc_strcat (IntentNoToBe,ProjCodeDup);
			//tc_strcat (IntentNoToBe,"2025");
			tc_strcat (IntentNoToBe,YearCodeDup);
			tc_strcpy(BaseIntentNo,IntentNoToBe);
			tc_strcat(BaseIntentNo,"*");
			printf("\n \n nBaseIntentNo : %s IntentNoToBe=%s\n",BaseIntentNo,IntentNoToBe);fflush(stdout); fflush(stdout);			
			
				int n_rows;
				int n_cols;
				int row;
				int column;
				void ***report;
				const char *str_list[15]={BaseIntentNo};
				printf("\nstr_list[0]=%s",str_list[0]); fflush(stdout);				
				const char *select_attrs[1] = {"t5_IntentNumber"};
				printf("\n 11\t"); fflush(stdout);
				CALLAPI(POM_enquiry_create ("cmvr_enq"));
				printf("\n 22\t"); fflush(stdout);
				CALLAPI(POM_enquiry_add_select_attrs ("cmvr_enq","t5_CMVR", 1, select_attrs));
				printf("\n 33\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_string_value ("cmvr_enq","attrval",1,str_list,POM_enquiry_bind_value));
				printf("\n 44\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_attr_expr ("cmvr_enq","expr1", "t5_CMVR","t5_IntentNumber",POM_enquiry_like, "attrval"));
				printf("\n 55\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_where_expr ("cmvr_enq","expr1"));
				printf("\n 66\t"); fflush(stdout);
				CALLAPI(POM_enquiry_add_order_attr( "cmvr_enq", "t5_CMVR", "t5_IntentNumber", POM_enquiry_desc_order ));
				printf("\n 77\t"); fflush(stdout);
				CALLAPI(POM_enquiry_execute("cmvr_enq", &n_rows, &n_cols, &report));
				printf("\n 88\t"); fflush(stdout);
				CALLAPI(POM_enquiry_delete("cmvr_enq")); 
				printf("\n \n cmvrcnt : %d \n",n_rows);fflush(stdout); fflush(stdout);
				for (row = 0; row < n_rows; row++)
				{
					
				for (column = 0; column < n_cols; column++)
					
				printf("\n Query return=%s  \t", report[row][column]); fflush(stdout);
			
				}
			//CALLAPI(getQueryAllCmvr(BaseIntentNo,&cmvrcnt,&Qrycmvrobjset)); //Function for Query All cmvr object based on input
			
				tag_t Qrycmvr_tag =NULLTAG;
				//Qrycmvr_tag = Qrycmvrobjset[0];
				char        	*Type           	   = NULL;
				char        	*IntentNum           	   = NULL;
				char        	*PrevSrlNoOfltaest           	   = NULL;
				char        	*PrevSrlNoOfltaestDup           	   = NULL;
				char runningSrlChar[4];	
				int		runningSrl;
				//if (Qrycmvr_tag  != NULLTAG)
				if(n_rows>0)
				{
					
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"object_type",&Type));
					// printf("\n getQueryAllCmvr : cmvr Type : %s \n",Type); fflush(stdout);
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"t5_IntentNumber",&IntentNum));
					// printf("\n getQueryAllCmvr : IntentNum : %s \n",IntentNum); fflush(stdout);
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"t5_Intent_4",&PrevSrlNoOfltaest));
					// printf("\n getQueryAllCmvr : PrevSrlNoOfltaest : %s \n",PrevSrlNoOfltaest); fflush(stdout);
					printf("\nB4 cal BaseIntentNo=%s row=%d col=%d report=%s",BaseIntentNo,n_rows,n_cols,report[0][0]); fflush(stdout);
					tmpStr=report[0][0];
					printf("\n \n tmpStr : %s \n",tmpStr);fflush(stdout); fflush(stdout);

					if(tmpStr)
					{
						 PrevSrlNoOfltaestDup=subString(tmpStr,8,11);
						printf( "PrevSrlNoOfltaestDup:%s\n", PrevSrlNoOfltaestDup); fflush(stdout);
					}
					
					
					
					printf("Copied PrevSrlNoOfltaestDup=%s\n",PrevSrlNoOfltaestDup);fflush(stdout);
					
						
					runningSrl = atoi(PrevSrlNoOfltaestDup);
					runningSrl = runningSrl + 1;
					
					printf("\n \n incremented runningSrl to int:  %d \n",runningSrl);fflush(stdout);	
					
					sprintf(runningSrlChar, "%04d", runningSrl);
					printf("\n \n Final runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
					
					tc_strcat (IntentNoToBe,runningSrlChar);
					
				}
				else
				{
					tc_strcat (IntentNoToBe,"0001");
				}
			
			
			//tc_strcat (IntentNoToBe,SrlNoDup);
			printf("\n IntentNoToBe :: %s\n",IntentNoToBe);fflush(stdout);
			if(IntentNoToBe)
			{
				 tc_strdup(IntentNoToBe,&IntentNoToBeDup);
				printf( "IntentNoToBeDup:%s\n", IntentNoToBeDup);fflush(stdout);
			}
			printf("\n inside class cmvr_item_create......\n");fflush(stdout);
			AOM_ask_value_string( *new_item, "t5_letter_1", &letter1);
			printf( "letter1:%s\n", letter1);fflush(stdout);
			if(letter1)
			{
				 letter1Dup=subString(letter1,0,1);
				printf( "Issuing Agency:%s\n", letter1Dup);fflush(stdout);
			}
			AOM_ask_value_string( *new_item, "t5_letter_2", &letter2);
			printf( "letter2:%s\n", letter2);fflush(stdout);
			if(letter2)
			{
				 letter2Dup=subString(letter2,0,1);
				printf( "Type Of Cert:%s\n", letter2Dup);fflush(stdout);
			}
			AOM_ask_value_string( *new_item, "t5_letter_3", &letter3);
			printf( "letter3:%s\n", letter3);fflush(stdout);
			if(letter3)
			{
				 letter3Dup=subString(letter3,0,1);
				printf( "Issuing Year :%s\n", letter3Dup);fflush(stdout);
			}
			AOM_ask_value_string( *new_item, "t5_letter_4", &letter4);
			printf( "letter4:%s\n", letter4);fflush(stdout);
			if(letter4)
			{
				tc_strdup(letter4,&letter4Dup);
				trimLeading(letter4Dup);
				 FuelType=subString(letter4Dup,0,1);
			}
			printf( "Fuel Type:%s\n", FuelType);fflush(stdout);
			
			
			AOM_ask_value_string( *new_item, "t5_last_4", &last4);
			printf( "last4:%s\n", last4);fflush(stdout);
			if(last4)
			{
				tc_strdup(last4,&last4Dup);				 
				printf( "last4Dup:%s\n", last4Dup);fflush(stdout);
			}


			AOM_ask_value_string( *new_item, "t5_ExtNo", &CertExtnNo);
			printf( "CertExtnNo:%s\n", CertExtnNo);fflush(stdout);
			if(CertExtnNo)
			{
				 tc_strdup(CertExtnNo,&CertExtnNoDup);
				 
				printf( "CertExtnNoDup :%s\n", CertExtnNoDup);fflush(stdout);
			}
			printf("\n\n\t\tletter1Dup : %s letter2Dup : %s letter3Dup : %s  letter4Dup : %s  last4Dup : %s\n",letter1Dup,letter2Dup,letter3Dup,FuelType,last4Dup);fflush(stdout);

			tc_strcpy(NewCmvrNo,letter1Dup);
			tc_strcat(NewCmvrNo,letter2Dup);
			tc_strcat (NewCmvrNo,letter3Dup);
			//tc_strcat (NewCmvrNo,letter4Dup);
			tc_strcat (NewCmvrNo,FuelType);
			tc_strcat (NewCmvrNo,last4Dup);
			if(tc_strlen(CertExtnNoDup)>0)
			{
			tc_strcat (NewCmvrNo,"_");
			tc_strcat (NewCmvrNo,CertExtnNoDup);
			}
			printf( "NewCmvrNo:%s\n", NewCmvrNo);fflush(stdout);
			
			if(NewCmvrNo)
				{
					 tc_strdup(NewCmvrNo,&ToBeNewCmvrNoDup);	
					printf( "ToBeNewCmvrNoDup:%s\n", ToBeNewCmvrNoDup);fflush(stdout);
				}
				
			
			//char *BaseIntentNoSrz = (char *)MEM_alloc(80 * sizeof(char));
			tc_strcpy(IntentNoToBeSrz,locDup);
			tc_strcat (IntentNoToBeSrz,ProjCodeDup);
			tc_strcat (IntentNoToBeSrz,"*");
			printf( "IntentNoToBeSrz:%s\n", IntentNoToBeSrz);fflush(stdout);
			CALLAPI(ChkExistingCmvrNoFunc(ToBeNewCmvrNoDup,IntentNoToBeSrz,&cmvrcnt1,&Qrycmvrobjset)); //Function for Query All cmvr object based on input
			printf( "in item create cmvrcnt1:%d\n", cmvrcnt1);fflush(stdout);
			tc_strcpy(IntNumStr,"");
			tc_strcat(IntNumStr,"Intent NO,CMVR NO :");
			//if(Qrycmvrobjset[0])
			if(cmvrcnt1>0)
			{
				AOM_ask_value_string( Qrycmvrobjset[0], "t5_IntentNumber", &CmvrIntentNum);
				printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
				if(CmvrIntentNum)
				{
					 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
					printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
				}
				
				AOM_ask_value_string( Qrycmvrobjset[0], "t5_CmvrNo", &ExCmvrNo);
				printf( "ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
				if(ExCmvrNo)
				{
					 tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
					printf( "ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
				}
			}
				printf("\nin CMVR create item Existing CmvrNo is : %s \n",ExCmvrNoDup);fflush(stdout);
				
				AOM_ask_value_string( CMVR_tag, "t5_VehType", &CmvrBusUnit);
				printf( "CmvrBusUnit:%s\n", CmvrBusUnit);fflush(stdout);
				if(CmvrBusUnit)
				{
					 tc_strdup(CmvrBusUnit,&CmvrBusUnitDup);	
					printf( "CmvrBusUnitDup:%s\n", CmvrBusUnitDup);fflush(stdout);
				}
				
				printf("\n inside cmvr create CmvrBusUnitDup is : %s cmvrcnt1=%d \n",CmvrBusUnitDup,cmvrcnt1);fflush(stdout);
				
				printf("\n inside cmvr create item condition   :: \n");fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(*new_item,"t5_ExtNo",&CertExtnNo));
					printf( "CertExtnNo:%s\n", CertExtnNo);fflush(stdout);
					if(CertExtnNo)
					{
						 tc_strdup(CertExtnNo,&CertExtnNoDup);
						 
						printf( "CertExtnNoDup :%s\n", CertExtnNoDup);fflush(stdout);
					}
					
					
				if(tc_strlen(ExCmvrNoDup)>0)
				{
					if(tc_strcmp(ExCmvrNoDup,NewCmvrNo)==0)
					{
						CmvrFlag=1;
						tc_strcat(IntNumStr,"\n");
						tc_strcat(IntNumStr,CmvrIntentNumDup);
						tc_strcat(IntNumStr,",");
						tc_strcat(IntNumStr,ExCmvrNoDup);
					}
				}
				printf("\nin CMVR create item IntNumStr :: %s cmvrcnt1=%d\n",IntNumStr,cmvrcnt1);fflush(stdout);
				if(CmvrFlag==1 || cmvrcnt1>0)
				{
					EMH_store_error_s2(EMH_severity_error,ITK_err,"CMVR already available for input value:- \n ",IntNumStr);
					printf("\nInside Err IntNumStr :: %s\n",IntNumStr);fflush(stdout);
					return ITK_err;
					
				}
				else
				{
					//Here need to build the auto Intent Number logic
					printf("\ntc_strlen(IntentNoToBeDup) :: %d\n",tc_strlen(IntentNoToBeDup));fflush(stdout);
					if(tc_strlen(IntentNoToBeDup)<11)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Invalid Length Of Intent Number:-  ",IntentNoToBeDup);
						printf("\nIntentNoToBeDup :: %s\n",IntentNoToBeDup);fflush(stdout);
						return ITK_err;
					}
					else
					{
						printf("\n b4 set IntentNoToBeDup = %s ToBeNewCmvrNoDup = %s runningSrlChar=%s for create CMVR object !!\n",IntentNoToBeDup,ToBeNewCmvrNoDup,runningSrlChar);fflush(stdout);
						CALLAPI(AOM_lock(*new_item));
						AOM_set_value_string(*new_item,"t5_IntentNumber", IntentNoToBeDup);
						AOM_set_value_string(*new_item,"item_id", IntentNoToBeDup);
						AOM_set_value_string(*new_item,"t5_CmvrNo", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"t5_Intent_4", runningSrlChar);
						AOM_set_value_string(*new_item,"object_name", CmvrDescDup);
						//CALLAPI(AOM_save(*new_item));						
						CALLAPI(AOM_save_without_extensions(*new_item));						
						CALLAPI(AOM_unlock(*new_item));
						CALLAPI(AOM_lock(*new_rev));
						AOM_set_value_string(*new_rev,"object_name", CmvrDescDup);
						//CALLAPI(AOM_save(*new_rev));						
						CALLAPI(AOM_save_without_extensions(*new_rev));						
						CALLAPI(AOM_unlock(*new_rev));
						printf("\nB4 Release status T5_LcsReview added to IntentNoToBeDup :: %s\n",IntentNoToBeDup);fflush(stdout);
						//CALLAPI(CR_create_release_status("T5_LcsReview",&status_rel)); //hashed for Teamcenter14 recommendation
						CALLAPI(RELSTAT_create_release_status("T5_LcsReview",&status_rel)); //similar new API for Teamcenter14
						if(status_rel)
						CALLAPI(RELSTAT_add_release_status(status_rel,1,new_item,retain));  
						printf("\nAfter Release status T5_LcsReview added to IntentNoToBeDup :: %s\n",IntentNoToBeDup);fflush(stdout);
						CALLAPI(AOM_lock(item_master_form));
						printf("\nB4 set IntentNoToBeDup :: %s in object_name with val[%s]\n",IntentNoToBeDup,CmvrDescDup);fflush(stdout);
						//printObject(item_master_form);	
						AOM_set_value_string(item_master_form,"object_name", IntentNoToBeDup);
						//CALLAPI(AOM_save(item_master_form));						
						CALLAPI(AOM_save_without_extensions(item_master_form));						
						CALLAPI(AOM_unlock(item_master_form));
						printf("\nAfter set IntentNoToBeDup :: %s in object_name for item_master_form\n",IntentNoToBeDup);fflush(stdout);
						//printObject(item_master_form);
						char *rev_master_form_id=NULL;
						rev_master_form_id=MEM_alloc(30);
                        tc_strcpy(rev_master_form_id,IntentNoToBeDup); 
                        tc_strcat(rev_master_form_id,"/"); 
                        tc_strcat(rev_master_form_id,rev_id); 
						printf("\nB4 set IntentNoToBeDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
						CALLAPI(AOM_lock(item_rev_master_form));
                        CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
                        //CALLAPI(AOM_save_with_extensions(item_rev_master_form));
						//CALLAPI(AOM_save(item_rev_master_form));
						CALLAPI(AOM_save_without_extensions(item_rev_master_form));
                        CALLAPI(AOM_unlock(item_rev_master_form));
						printf("\nAfter set IntentNoToBeDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
					}
					
					
				
					
				}
				
				//adding new cmvrno val to CMVR LOV 
				
				//CmvrIntentNumDup t5_VehType
				
				//client code logic need to place here for backend mode
									
									tag_t *Cntrlobjset=NULLTAG;
									tag_t   qryTagCntrl    = NULLTAG;
									int     n_entryCntrl    = 3;
									char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
									char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
									int cntrlcnt=0;
									int  control_number_found=0;
									char* shellpath = NULL;
									char* sysCmnd = NULL;
									
									//if(QRY_find("Control Objects...", &qryTagCntrl));
									if(QRY_find2("Control Objects...", &qryTagCntrl));
									if (qryTagCntrl)
									{
										printf("\n Control Object Query Found \n");fflush(stdout);
										qry_valuesCntrl[0]="AutoAddCmvrnoToLov";
										qry_valuesCntrl[1]="Live";
										qry_valuesCntrl[2]="0";
										
										if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &Cntrlobjset));
									}
									else
									{
										printf("\n Control Object Query not Found .... \n");fflush(stdout);
										
									}	
									
									printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
									
									if(control_number_found>0)
									{
										printf("\n Control Object AutoAddCmvrnoToLov Found \n");fflush(stdout);
										
										AOM_ask_value_string( CMVR_tag, "t5_IntentNumber", &CmvrIntentNum);
										printf( "22CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
										if(CmvrIntentNum)
										{
											 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
											printf( "22CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
										}
										AOM_ask_value_string( CMVR_tag, "t5_CmvrNo", &ExCmvrNo);
										printf( "22ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
										if(ExCmvrNo)
										{
											 tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
											printf( "22ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
										}
										
										printf("\n22Existing CmvrNo is : %s \n",ExCmvrNoDup);fflush(stdout);	
												
												
												ITK_CALL(AOM_ask_value_string(Cntrlobjset[0],"t5_Userinfo1",&shellpath));
												
												printf("\n AutoAddCmvrnoToLov shellpath==>%s\n",shellpath);fflush(stdout);
													
										
									
				
				
				
													char * 	ClsAttrName=NULL;
													char *	ClsAttrshortName=NULL;
													char * 	ClsAttrUnit=NULL;
													int  	ClsAttrFormat=0;
													int cmvrAttrId =0;
													
													int retcount;
													printf("\n CmvrBusUnitDup: %s \n",CmvrBusUnitDup);fflush(stdout);
													CALLAPI(getCmvrAttrNoWrtTSBU(CmvrBusUnitDup,&retcount));
													printf("\n after call getCmvrAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
													cmvrAttrId=retcount;
													printf("\n  before ICS_describe_unct cmvrAttrId=%d",cmvrAttrId); fflush(stdout);
													CALLAPI(ICS_describe_unct(cmvrAttrId,&ClsAttrName,&ClsAttrshortName,&ClsAttrUnit,&ClsAttrFormat));
													printf("\n After ICS_describe_unct ifail[%d]",ifail); fflush(stdout);
													if(ifail != ITK_ok)
													{
													printf("\n  cmvrAttrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",cmvrAttrId,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);						
													return ifail;	
													}
													printf("\n 2 cmvrAttrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",cmvrAttrId,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);
													 char theKeyLOVId[10];
													const char * 	key_lov_id;
													if(ClsAttrFormat)
													{
																	
														sprintf(theKeyLOVId, "%d", ClsAttrFormat);
														key_lov_id=theKeyLOVId;	
														printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);
													}
													if(key_lov_id)
													{
														if(tc_strlen(shellpath)>0)
														{
															printf("\ninside AutoAddCmvrnoToLov Execute through client code by EXE[%s] key_lov_id[%s] \n",shellpath,key_lov_id);fflush(stdout);
															
															
															sysCmnd=(char *) MEM_alloc(400);
															tc_strcpy(sysCmnd,shellpath);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-cmvr=);
															tc_strcat(sysCmnd,key_lov_id);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-veh=);
															tc_strcat(sysCmnd,ToBeNewCmvrNoDup);
															printf("\n before-- Calling shell file AutoAddCmvrnoToLov.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															system(sysCmnd);
															
															printf("\n after --- Calling shell file AutoAddCmvrnoToLov.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															
															MEM_free(sysCmnd);
														}
													}
									}
									else
									{
										printf("\n  No control obj[AutoAddCmvrnoToLov] found for Auto Cmvrno value update to LOV !! "); fflush(stdout);
									}
				//End adding new cmvrno val to CMVR LOV 
				
				
				printf("\nCMVR object created with IntentNoToBeDup :: %s ToBeNewCmvrNoDup = %s with ifail=%d\n",IntentNoToBeDup,ToBeNewCmvrNoDup,ifail);fflush(stdout);
				
				
			}
			/*else
			{
				printf("\nNo CMVR available in system :: %s\n",ToBeNewCmvrNoDup);fflush(stdout);
				if(tc_strlen(ToBeNewCmvrNoDup)<11)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Invalid Length Of Intent Number:-  ",ToBeNewCmvrNoDup);
						printf("\nToBeNewCmvrNoDup :: %s\n",ToBeNewCmvrNoDup);fflush(stdout);
						return ITK_err;
					}
					else
					{
						printf("\n b4 set ToBeNewCmvrNoDup = %s ToBeNewCmvrNoDup = %s for create CMVR object !!\n",ToBeNewCmvrNoDup,ToBeNewCmvrNoDup);fflush(stdout);
						AOM_set_value_string(*new_item,"t5_IntentNumber", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"item_id", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"t5_CmvrNo", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"t5_Intent_4", last4Dup);
						CALLAPI(AOM_lock(item_master_form));
						printf("\nB4 set ToBeNewCmvrNoDup :: %s in object_name\n",ToBeNewCmvrNoDup);fflush(stdout);
						AOM_set_value_string(item_master_form,"object_name", ToBeNewCmvrNoDup);
						CALLAPI(AOM_save(item_master_form));						
						CALLAPI(AOM_unlock(item_master_form));
						printf("\nAfter set ToBeNewCmvrNoDup :: %s in object_name for item_master_form\n",ToBeNewCmvrNoDup);fflush(stdout);
						char *rev_master_form_id=NULL;
						rev_master_form_id=MEM_alloc(30);
                        tc_strcpy(rev_master_form_id,ToBeNewCmvrNoDup); 
                        tc_strcat(rev_master_form_id,"/"); 
                        tc_strcat(rev_master_form_id,rev_id); 
						printf("\nB4 set ToBeNewCmvrNoDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
						CALLAPI(AOM_lock(item_rev_master_form));
                        CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
                        CALLAPI(AOM_save(item_rev_master_form));
                        CALLAPI(AOM_unlock(item_rev_master_form));
						printf("\nAfter set ToBeNewCmvrNoDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
					}
			}
			*/

			if(ifail == ITK_ok)
				{
					NotifyMsg = (char *) MEM_alloc( 150 * sizeof(char) );
					printf("\n CMVR object created with IntentNoToBeDup :: %s ToBeNewCmvrNoDup = %s",IntentNoToBeDup,ToBeNewCmvrNoDup); fflush(stdout);
					tc_strcpy(NotifyMsg,"Below CMVR created,Pls Check\n");
					tc_strcat(NotifyMsg,"CMVR object created with IntentNoToBeDup");
					tc_strcat (NotifyMsg,"[");
					tc_strcat(NotifyMsg,IntentNoToBeDup);
					tc_strcat (NotifyMsg,"]");
					
					
					printf( "NotifyMsg:%s\n", NotifyMsg);fflush(stdout);
			
					int CmvrSaveAsPostBypassChkFlg=0;
					printf("\n in project assignment in newly CMVR obj b4 call CmvrSaveAsPostBypassChk = %d func for post method tm_CmvrCreSaveFun\n",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
					CmvrSaveAsPostBypassChkFlg=CmvrSaveAsPostBypass();

					printf("\n in project assignment in newly CMVR obj after tm_CmvrCreSaveFun CmvrSaveAsPostBypassChk = %d\n",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
					if(CmvrSaveAsPostBypassChkFlg>0)
					{
						printf("\n in project assignment in newly CMVR obj  post save method  tm_CmvrCreSaveFun bypassed with CmvrSaveAsPostBypassChkFlg=%d ",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
						return ifail;
					}
					tag_t   projobj1=NULLTAG;
					tag_t NewCmvrObj=*new_item;
					if(strcmp(ProjCodeDup,"")==0) //project_list
					{
						printf("\n  CMVR Cre Post Project is  NULL  ");fflush(stdout);
					}
					else
					{
						printf("\n CMVR CRE Post Project from Object in else : %s ",ProjCodeDup);fflush(stdout);

						CALLAPI(PROJ_find(ProjCodeDup,&projobj1));

						if(projobj1)
						{
							printf("\nb4 project asssign CMVR CRE Post");fflush(stdout);
							CALLAPI(PROJ_assign_objects(1 ,&projobj1 ,1 ,&NewCmvrObj ));
							printf("\nafter project asssign CMVR CRE Post");fflush(stdout);
						}
						else
						{
							printf("\n Project not found in project asssign CMVR CRE Post  ");fflush(stdout);
						}
					}
					//EMH_store_error_s2(EMH_severity_information,ITK_err,"Below CMVR created,Pls Check \n",NotifyMsg);
					//EMH_store_error_s1(EMH_severity_information,ITK_err,NotifyMsg);
					//return ITK_err;
				}
			//MEM_free(cmvr_obj);
			//MEM_free(NotifyMsg);
			
		//}
	
	printf("\n 	 End tm_CmvrCreFun for post action tm_Cmvr creation !! ");fflush(stdout);
	//MEM_free(IntNumStr);
	//MEM_free(NewCmvrNo);
	return 0;
	
}

	int CmvrSaveAsPostBypass()
	{


		tag_t *cntrlObjSet=NULLTAG;
		tag_t   qryTagCntrl     = NULLTAG;
		int     n_entryCntrl    = 3;
		int ifail=0;
		char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
		int  control_number_found=0;
		
				printf("\n start func CmvrSaveAsPostBypass Calling qry to decide whether this AH will required or not ....\n");
				//if(QRY_find("Control Objects...", &qryTagCntrl));
				if(QRY_find2("Control Objects...", &qryTagCntrl));
				if (qryTagCntrl)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrl[0]="CmvrSaveAsPostBypass";
					qry_valuesCntrl[1]="Live";
					qry_valuesCntrl[2]="0";
					
					if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
				}
				else
				{
					printf("\n Control Object Query not Found .... \n");fflush(stdout);
					
				}	
				
				printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
				if(control_number_found>0)
				{
				printf("\n CmvrSaveAsPostBypass is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
				ifail= control_number_found;
				 //return ifail;
				}
			
	printf("\n end the function CmvrSaveAsPostBypass with ifail [%d]\n",ifail);fflush(stdout);		
	return ifail;
	}



char * CmvrBypassUsr()
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 2;
	int ifail=0;
	char    *qry_entryCntrl[2]  = {"SYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	char *BypassUsr=NULL;
			printf("\n start func CmvrBypassUsr Calling qry to decide whether this AH will required or not ....\n");
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]="CmvrBypassUsr";
				//qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[1]="0";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
				
			printf("\n CmvrBypassUsr found in server[%d]\n",control_number_found);fflush(stdout);
			ITKCALL(AOM_ask_value_string(cntrlObjSet[0],"t5_SubSyscd", &BypassUsr));
			printf("\n\n\t\t BypassUsr :%s",BypassUsr);	fflush(stdout);
			//ifail= control_number_found;
			 //return ifail;
			}
		
printf("\n end the function CmvrBypassUsr with ifail [%d] and BypassUsr=%s\n",ifail,BypassUsr);fflush(stdout);		
return BypassUsr;
}

int tm_CmvrCreSaveFun(METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	//tag_t new_item         = NULLTAG;
	tag_t		*cmvr_obj	= NULLTAG;
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	//logical isnew              = 0;
	int CmvrFlag		   = 0;
	tag_t  user = NULLTAG;
	char   *user_name_string = NULL;
	tag_t			*RetContrlObjs				=NULLTAG;
	char *DefaultApprover = NULL;
	//signature for item create
	
	// char* item_id  = va_arg(args, char*);
    // const char* item_name = va_arg(args, char*);
    // const char* type_name = va_arg(args, char*);
    // const char* rev_id = va_arg(args, char*);
	
   // tag_t*      new_item = va_arg(args, tag_t*);
   // tag_t*      new_rev = va_arg(args, tag_t*);
    //tag_t       item_master_form = va_arg(args, tag_t);
    //tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	//Start signature for item save
	

va_list largs;
   va_copy( largs, args );               
   tag_t new_item = va_arg(largs, tag_t);
   tag_t new_rev = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	//char *type_name = va_arg(largs, char *);
	va_end( largs );	
	//End signature for item save
	
	
	//new_item               = va_arg(args, tag_t);
	//isnew                  = va_arg(args, int);
	printf("\n 	 inside tm_CmvrCreSaveFun for pre action tm_Cmvr creation with isNew=%d !! ",isNew);fflush(stdout);
	
	int CmvrSaveAsPostBypassChkFlg=0;
printf("\n b4 call CmvrSaveAsPostBypassChk = %d func for post method tm_CmvrCreSaveFun\n",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
CmvrSaveAsPostBypassChkFlg=CmvrSaveAsPostBypass();

printf("\n after tm_CmvrCreSaveFun CmvrSaveAsPostBypassChk = %d\n",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
if(CmvrSaveAsPostBypassChkFlg>0)
{
	printf("\n post save method  tm_CmvrCreSaveFun bypassed with CmvrSaveAsPostBypassChkFlg=%d ",CmvrSaveAsPostBypassChkFlg);fflush(stdout);
	return ifail;
}
	//printf("\n Is CMVR New %d ",isnew);fflush(stdout);
	time_t 	now;
	struct 	tm	when;
	char 	CurrYear[6]		= "";
	char* from2 = CurrYear;  
	char *YearCode = MEM_alloc(10);
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);	
	strncpy(YearCode, from2+2,2);
	printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
	printf("\n--->>>>> cmvr Current Year >> %s  new_item=%u",CurrYear,new_item);fflush(stdout);
	
	//char *type_name=NULL;
    // tag_t type_tag = NULLTAG;
     //ITK_CALL(TCTYPE_ask_object_type(new_item,&type_tag));

     //ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));

	 //printf("\n object type_name :  %s \n",type_name);fflush(stdout);	
	TCTYPE_save_operation_context_t save_context;
        CALLAPI(TCTYPE_ask_save_operation_context(&save_context));
	
	//TCTYPE_save_operation_context_e enum_value = TCTYPE_unknown_operation_context;
// Ask current context of IMAN_save operation
//TCTYPE_ask_save_operation_context(&enum_value);

// print context and check its value against enum list
TC_write_syslog("operation_context save_context: %d", save_context);
	printf("\n operation_context save_context: %d", save_context);fflush(stdout);
	
	
	 if (save_context == TCTYPE_save_on_create)
	 {
		 printf("\n save_context[%d] for new create",save_context);fflush(stdout);
	 }
	 else if(save_context == TCTYPE_save_on_saveas)
	 {
		 printf("\n save_context[%d] for TCTYPE_save_on_saveas",save_context);fflush(stdout);
	 }
	 else if(save_context == TCTYPE_save_on_revise) 
	 {
		 printf("\n save_context[%d] for TCTYPE_save_on_update",save_context);fflush(stdout);
	 }
	 else if(save_context == TCTYPE_save_on_update)
	 {
		 printf("\n save_context[%d] for TCTYPE_save_on_update",save_context);fflush(stdout);
	 }
	 else if(save_context == TCTYPE_save_on_clone)
	 {
		 printf("\n save_context[%d] for TCTYPE_save_on_clone",save_context);fflush(stdout);
	 }
	 else if(save_context == TCTYPE_unknown_operation_context )
	 {
		 printf("\n save_context[%d] for TCTYPE_unknown_operation_context ",save_context);fflush(stdout);
		 //return ifail;
	 }	 
	 else 	 
	 {
		 printf("\n save_context[%d] for other option",save_context);fflush(stdout);
	 }
	//set default value
	CALLAPI(SA_init_module());
		printf("\n SA_init_module");fflush(stdout);
		CALLAPI(POM_get_user(&user_name_string, &user));
		printf("\n POM_get_user[%s]",user_name_string);fflush(stdout);
		
		if(tc_strcmp(user_name_string,"loader")==0)
		{
		printf("\n Bypass auto creation logic for Loader user: %s\n",DefaultApprover);fflush(stdout);
		return ifail;
		}
		
	/* CALLAPI(getDefaultUsr( "CmvrDefaultUser",&n_found ,&RetContrlObjs));  //SUBSYSCD=CmvrDefaultUser
	printf("\n DefaultApprover n_found: %d\n",n_found);fflush(stdout);
	if(n_found>0)
	{
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo2", &DefaultApprover);
		printf("\n DefaultApprover: %s\n",DefaultApprover);fflush(stdout);
		
	} */
	printf("\n isNew[%d]",isNew);fflush(stdout);
	if(isNew==true)
	{
		printf("\n isNew[%d] for new create",isNew);fflush(stdout);
	}
	else
	{
		printf("\n isNew[%d] for not new create",isNew);fflush(stdout);
	}
	if(isNew==0)
	{
		printf("\n CMVR has already created\n");fflush(stdout);
		return ifail;
		
	}
	
	//if(new_item != NULLTAG && isnew >1)
	//{
		char *loc 	   = NULL;
		char *ProjCode 	   = NULL;
		char **DesignGroupList = NULL;
		char **DMLMdAddList = NULL;
		char *SrlNo   = NULL;
		
		char *locDup 	   = NULL;
		char *ProjCodeDup 	   = NULL;
		//char *YearCode = NULL;
		char *YearCodeDup = NULL;
		char *CarbonMonOx 	   = NULL;
		char *CarbonMonOxDup 	   = NULL;
		char *HydCarb = NULL;
		char *HydCarbDup = NULL;
		
		char *ReactvHydCarb 	   = NULL;
		char *ReactvHydCarbDup 	   = NULL;
		char *HCNox = NULL;
		char *HCNoxDup = NULL;
		char *NonMethHc 	   = NULL;
		char *NonMethHcDup 	   = NULL;
		char *NOxD = NULL;
		char *NOxDup = NULL;
		
		char *PM 	   = NULL;
		char *PMDup 	   = NULL;
		char *HornSoundLvl = NULL;
		char *HornSoundLvlDup = NULL;
		char *NoiseLvl 	   = NULL;
		char *NoiseLvlDup 	   = NULL;
		
		char *letter1 	   = NULL;
		char *letter1Dup 	   = NULL;
		char *letter2 = NULL;
		char *letter2Dup = NULL;
		char *letter3 	   = NULL;
		char *letter3Dup 	   = NULL;
		char *letter4 	   = NULL;
		char *letter4Dup 	   = NULL;
		char *last4 	   = NULL;
		char *last4Dup 	   = NULL;
		
		char *ToBeNewCmvrNo 	   = NULL;
		char *ToBeNewCmvrNoDup 	   = NULL;
		char *NOx 	   = NULL;
		char *SrlNoDup 	   = NULL;
		char *CmvrIntentNum 	   = NULL;
		char *CmvrIntentNumDup 	   = NULL;
		char *ExCmvrNo 	   = NULL;
		char *ExCmvrNoDup 	   = NULL;
		char *IntentNoToBe 	   = NULL;
		char *IntentNoToBeDup 	   = NULL;
		char *CmvrDesc		= NULL;
		char *CmvrDescDup		= NULL;
		char *CmvrBusUnit=NULL;
		char *CmvrBusUnitDup=NULL;	
		char *CertExtnNo=NULL;
		char *CertExtnNoDup=NULL;	
		char *NotifyMsg=NULL;
		int	 num,mad	   = 0;
		printf("\n inside class CMVR CRE......\n");fflush(stdout);
		if(new_item)
		{
		//printObject(new_item);	
		//}
		
		AOM_ask_value_string( new_item, "t5_Intent_1", &loc);
		AOM_ask_value_string( new_item, "t5_CmvrProjCode", &ProjCode);
		AOM_ask_value_string( new_item, "object_desc", &CmvrDesc);
		//AOM_ask_value_strings( new_item,"t5_Intent_3",&num,&DesignGroupList); //t5_Intent_3=Year will get runtime
		//AOM_ask_value_string( new_item, "t5_Intent_4", &SrlNo);  //t5_Intent_4=Srl No
		AOM_ask_value_string( new_item, "t5_last_4", &SrlNo);  //t5_Intent_4=Srl No
		}
	
		printf("\n loc : %s\n",loc);fflush(stdout);
		printf("\n ProjCode : %s\n",ProjCode);fflush(stdout);
		printf("\n SrlNo : %s\n",SrlNo);fflush(stdout);
		printf("\n CmvrDesc : %s\n",CmvrDesc);fflush(stdout);
		if(loc)
		{
			tc_strdup(loc,&locDup);
		}
		if(ProjCode)
		{
			tc_strdup(ProjCode,&ProjCodeDup);
		}
		if(CurrYear)
		{
			tc_strdup(CurrYear,&YearCodeDup);
		}
		
		if(SrlNo)
		{
			tc_strdup(SrlNo,&SrlNoDup);
		}
		if(CmvrDesc)
		{
			tc_strdup(CmvrDesc,&CmvrDescDup);
		}
		printf("\n locDup : %s  ProjCodeDup : %s YearCodeDup : %s  SrlNoDup : %s CmvrDescDup :%s\n",locDup,ProjCodeDup,YearCodeDup,SrlNoDup,CmvrDescDup);fflush(stdout);
		//Attr Values which will decide to create CMVR Intent approval object
		
		AOM_ask_value_string( new_item, "t5_Pollutant_CM", &CarbonMonOx);
		printf("CarbonMonOx=%s\n",CarbonMonOx);fflush(stdout);
		if(CarbonMonOx)
		{
			tc_strdup(CarbonMonOx,&CarbonMonOxDup);
		}
		
		printf("Copied CarbonMonOxDup=%s\n",CarbonMonOxDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_HC", &HydCarb);
		printf("HydCarb=%s\n",HydCarb);fflush(stdout);
		if(HydCarb)
		{
			tc_strdup(HydCarb,&HydCarbDup);
		}
		
		printf("Copied HydCarbDup=%s\n",HydCarbDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_RHC", &ReactvHydCarb);
		printf("ReactvHydCarb=%s\n",ReactvHydCarb);fflush(stdout);
		if(ReactvHydCarb)
		{
			tc_strdup(ReactvHydCarb,&ReactvHydCarbDup);
		}
		
		printf("Copied ReactvHydCarbDup=%s\n",ReactvHydCarbDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_HCNO", &HCNox);
		printf("HCNox=%s\n",HCNox);fflush(stdout);
		if(HCNox)
		{
			tc_strdup(HCNox,&HCNoxDup);
		}
		
		printf("Copied HCNoxDup=%s\n",HCNoxDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_NH", &NonMethHc);
		printf("NonMethHc=%s\n",NonMethHc);fflush(stdout);
		if(NonMethHc)
		{
			tc_strdup(NonMethHc,&NonMethHcDup);
		}
		
		printf("Copied NonMethHcDup=%s\n",NonMethHcDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_NO", &NOx);
		printf("NOx=%s\n",NOx);fflush(stdout);
		if(NOx)
		{
			tc_strdup(NOx,&NOxDup);
		}
		
		printf("Copied NOxDup=%s\n",NOxDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_PM", &PM);
		printf("PM=%s\n",PM);fflush(stdout);
		if(PM)
		{
			tc_strdup(PM,&PMDup);
		}
		
		printf("Copied PMDup=%s\n",PMDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_Pollutant_HO", &HornSoundLvl);
		printf("HornSoundLvl=%s\n",HornSoundLvl);fflush(stdout);
		if(HornSoundLvl)
		{
			tc_strdup(HornSoundLvl,&HornSoundLvlDup);
		}
		
		printf("Copied HornSoundLvlDup=%s\n",HornSoundLvlDup);fflush(stdout);
		AOM_ask_value_string( new_item, "t5_BystanderPos", &NoiseLvl);
		printf("NoiseLvl=%s\n",NoiseLvl);fflush(stdout);
		if(NoiseLvl)
		{
			tc_strdup(NoiseLvl,&NoiseLvlDup);
		}
		// CarbonMonOxDup,HydCarbDup,ReactvHydCarbDup,HCNoxDup,NonMethHcDup,NOxDup,PMDup,HornSoundLvlDup,NoiseLvlDup
		printf("Copied NoiseLvlDup=%s\n",NoiseLvlDup);fflush(stdout);
		//Need to use Query Builder to get CMVR Object to decide for new creation.....
		//char *qry_entries3[] = {"Carbon Monoxide","Hydrocarbon, if applicable","Reactive HC, if applicable","HC+NOx, if applicable","Non-Methane HC, if applicable","NOx, if applicable","PM, if applicable","Sound level of horn as installed on the vehicle","Pass-by Noise value"};
		char *qry_entries3[] = {"Carbon Monoxide/Carbon Monoxide (CO)","Hydrocarbon, if applicable/Hydrocarbon, (THC/HC)","Reactive HC, if applicable/THC + Nox","HC+NOx, if applicable/HC + Nox","Non-Methane HC, if applicable/Non-Methane Hydrocarbon (NMHC)","NOx, if applicable/Oxides of Nitrogen (NOx)","PM, if applicable/Mass of Particulate Matter (PM)","Sound level of horn as installed on the vehicle","Pass-by Noise value"};
		char *qry_values3[] = {CarbonMonOxDup,HydCarbDup,ReactvHydCarbDup,HCNoxDup,NonMethHcDup,NOxDup,PMDup,HornSoundLvlDup,NoiseLvlDup};
		//CALLAPI(QRY_find("CmvrObjQry", &query));
		CALLAPI(QRY_find2("CmvrObjQry", &query));
		CALLAPI(QRY_execute(query, 9, qry_entries3, qry_values3, &n_found, &cmvr_obj));
		printf("\n \n number of cmvr objs : %d \n",n_found);fflush(stdout);			
		if (n_found != 0)
		{
			tag_t 		CMVR_tag = 	NULLTAG;
			tag_t *Qrycmvrobjset                        		= NULLTAG;
			char *NewCmvrNo=NULL;
			char *IntNumStr=NULL;
			char *tmpStr= NULL;
			char *FuelType=NULL;
			//char *NotifyMsg=NULL;
			tag_t status_rel		 = NULLTAG;
				logical 	retain;
			int cmvrcnt=0;
			int cmvrcnt1=0;
			NewCmvrNo = (char *) MEM_alloc( 50 * sizeof(char) );
			IntNumStr = (char *) MEM_alloc( 50 * sizeof(char) );
			
			printf("\n \n inside cond number of cmvr objs : %d \n",n_found);fflush(stdout);
			if(cmvr_obj[0])
			{
				CMVR_tag = cmvr_obj[0];
			}
			
			int number_found;
			int	status;
			tag_t *list_of_WSO_tags=NULLTAG;
			WSO_search_criteria_t  	criteria;
			char *IntentNoToBe = (char *)MEM_alloc(80 * sizeof(char));
			char *BaseIntentNo = (char *)MEM_alloc(80 * sizeof(char));
			tc_strcpy(IntentNoToBe,locDup);
			tc_strcat (IntentNoToBe,ProjCodeDup);
			//tc_strcat (IntentNoToBe,"2025");
			tc_strcat (IntentNoToBe,YearCodeDup);
			tc_strcpy(BaseIntentNo,IntentNoToBe);
			tc_strcat(BaseIntentNo,"*");
			printf("\n \n nBaseIntentNo : %s IntentNoToBe=%s\n",BaseIntentNo,IntentNoToBe);fflush(stdout); fflush(stdout);			
			
				int n_rows;
				int n_cols;
				int row;
				int column;
				void ***report;
				const char *str_list[15]={BaseIntentNo};
				printf("\nstr_list[0]=%s",str_list[0]); fflush(stdout);				
				const char *select_attrs[1] = {"t5_IntentNumber"};
				printf("\n 11\t"); fflush(stdout);
				CALLAPI(POM_enquiry_create ("cmvr_enq"));
				printf("\n 22\t"); fflush(stdout);
				CALLAPI(POM_enquiry_add_select_attrs ("cmvr_enq","t5_CMVR", 1, select_attrs));
				printf("\n 33\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_string_value ("cmvr_enq","attrval",1,str_list,POM_enquiry_bind_value));
				printf("\n 44\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_attr_expr ("cmvr_enq","expr1", "t5_CMVR","t5_IntentNumber",POM_enquiry_like, "attrval"));
				printf("\n 55\t"); fflush(stdout);
				CALLAPI(POM_enquiry_set_where_expr ("cmvr_enq","expr1"));
				printf("\n 66\t"); fflush(stdout);
				CALLAPI(POM_enquiry_add_order_attr( "cmvr_enq", "t5_CMVR", "t5_IntentNumber", POM_enquiry_desc_order ));
				printf("\n 77\t"); fflush(stdout);
				CALLAPI(POM_enquiry_execute("cmvr_enq", &n_rows, &n_cols, &report));
				printf("\n 88\t"); fflush(stdout);
				CALLAPI(POM_enquiry_delete("cmvr_enq")); 
				printf("\n \n cmvrcnt : %d \n",n_rows);fflush(stdout); fflush(stdout);
				for (row = 0; row < n_rows; row++)
				{
					
				for (column = 0; column < n_cols; column++)
					
				printf("\n Query return=%s  \t", report[row][column]); fflush(stdout);
			
				}
			//CALLAPI(getQueryAllCmvr(BaseIntentNo,&cmvrcnt,&Qrycmvrobjset)); //Function for Query All cmvr object based on input
			
				tag_t Qrycmvr_tag =NULLTAG;
				//Qrycmvr_tag = Qrycmvrobjset[0];
				char        	*Type           	   = NULL;
				char        	*IntentNum           	   = NULL;
				char        	*PrevSrlNoOfltaest           	   = NULL;
				char        	*PrevSrlNoOfltaestDup           	   = NULL;
				char runningSrlChar[4];	
				int		runningSrl;
				//if (Qrycmvr_tag  != NULLTAG)
				if(n_rows>0)
				{
					
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"object_type",&Type));
					// printf("\n getQueryAllCmvr : cmvr Type : %s \n",Type); fflush(stdout);
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"t5_IntentNumber",&IntentNum));
					// printf("\n getQueryAllCmvr : IntentNum : %s \n",IntentNum); fflush(stdout);
					// CALLAPI (AOM_ask_value_string(Qrycmvr_tag,"t5_Intent_4",&PrevSrlNoOfltaest));
					// printf("\n getQueryAllCmvr : PrevSrlNoOfltaest : %s \n",PrevSrlNoOfltaest); fflush(stdout);
					printf("\nB4 cal BaseIntentNo=%s row=%d col=%d report=%s",BaseIntentNo,n_rows,n_cols,report[0][0]); fflush(stdout);
					tmpStr=report[0][0];
					printf("\n \n tmpStr : %s \n",tmpStr);fflush(stdout); fflush(stdout);

					if(tmpStr)
					{
						 PrevSrlNoOfltaestDup=subString(tmpStr,8,11);
						printf( "PrevSrlNoOfltaestDup:%s\n", PrevSrlNoOfltaestDup); fflush(stdout);
					}
					
					
					
					printf("Copied PrevSrlNoOfltaestDup=%s\n",PrevSrlNoOfltaestDup);fflush(stdout);
					
						
					runningSrl = atoi(PrevSrlNoOfltaestDup);
					runningSrl = runningSrl + 1;
					
					printf("\n \n incremented runningSrl to int:  %d \n",runningSrl);fflush(stdout);	
					
					sprintf(runningSrlChar, "%04d", runningSrl);
					printf("\n \n Final runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
					
					tc_strcat (IntentNoToBe,runningSrlChar);
					
				}
				else
				{
					tc_strcat (IntentNoToBe,"0001");
				}
			
			
			//tc_strcat (IntentNoToBe,SrlNoDup);
			printf("\n IntentNoToBe :: %s\n",IntentNoToBe);fflush(stdout);
			if(IntentNoToBe)
			{
				 tc_strdup(IntentNoToBe,&IntentNoToBeDup);
				printf( "IntentNoToBeDup:%s\n", IntentNoToBeDup);fflush(stdout);
			}
			printf("\n inside class cmvr_item_create......\n");fflush(stdout);
			AOM_ask_value_string( new_item, "t5_letter_1", &letter1);
			printf( "letter1:%s\n", letter1);fflush(stdout);
			if(letter1)
			{
				 letter1Dup=subString(letter1,0,1);
				printf( "Issuing Agency:%s\n", letter1Dup);fflush(stdout);
			}
			AOM_ask_value_string( new_item, "t5_letter_2", &letter2);
			printf( "letter2:%s\n", letter2);fflush(stdout);
			if(letter2)
			{
				 letter2Dup=subString(letter2,0,1);
				printf( "Type Of Cert:%s\n", letter2Dup);fflush(stdout);
			}
			AOM_ask_value_string( new_item, "t5_letter_3", &letter3);
			printf( "letter3:%s\n", letter3);fflush(stdout);
			if(letter3)
			{
				 letter3Dup=subString(letter3,0,1);
				printf( "Issuing Year :%s\n", letter3Dup);fflush(stdout);
			}
			AOM_ask_value_string( new_item, "t5_letter_4", &letter4);
			printf( "letter4:%s\n", letter4);fflush(stdout);
			if(letter4)
			{
				tc_strdup(letter4,&letter4Dup);
				trimLeading(letter4Dup);
				 FuelType=subString(letter4Dup,0,1);
			}
			printf( "Fuel Type:%s\n", FuelType);fflush(stdout);
			
			
			AOM_ask_value_string( new_item, "t5_last_4", &last4);
			printf( "last4:%s\n", last4);fflush(stdout);
			if(last4)
			{
				tc_strdup(last4,&last4Dup);				 
				printf( "last4Dup:%s\n", last4Dup);fflush(stdout);
			}


			AOM_ask_value_string( new_item, "t5_ExtNo", &CertExtnNo);
			printf( "CertExtnNo:%s\n", CertExtnNo);fflush(stdout);
			if(CertExtnNo)
			{
				 tc_strdup(CertExtnNo,&CertExtnNoDup);
				 
				printf( "CertExtnNoDup :%s\n", CertExtnNoDup);fflush(stdout);
			}
			printf("\n\n\t\tletter1Dup : %s letter2Dup : %s letter3Dup : %s  letter4Dup : %s  last4Dup : %s\n",letter1Dup,letter2Dup,letter3Dup,FuelType,last4Dup);fflush(stdout);

			tc_strcpy(NewCmvrNo,letter1Dup);
			tc_strcat(NewCmvrNo,letter2Dup);
			tc_strcat (NewCmvrNo,letter3Dup);
			//tc_strcat (NewCmvrNo,letter4Dup);
			tc_strcat (NewCmvrNo,FuelType);
			tc_strcat (NewCmvrNo,last4Dup);
			if(tc_strlen(CertExtnNoDup)>0)
			{
			tc_strcat (NewCmvrNo,"_");
			tc_strcat (NewCmvrNo,CertExtnNoDup);
			}
			printf( "NewCmvrNo:%s\n", NewCmvrNo);fflush(stdout);
			
			if(NewCmvrNo)
				{
					 tc_strdup(NewCmvrNo,&ToBeNewCmvrNoDup);	
					printf( "ToBeNewCmvrNoDup:%s\n", ToBeNewCmvrNoDup);fflush(stdout);
				}
			
			//ToBeNewCmvrNoDup
			char *IntentNoToBeSrz = (char *)MEM_alloc(80 * sizeof(char));
			//char *BaseIntentNoSrz = (char *)MEM_alloc(80 * sizeof(char));
			tc_strcpy(IntentNoToBeSrz,locDup);
			tc_strcat (IntentNoToBeSrz,ProjCodeDup);
			tc_strcat (IntentNoToBeSrz,"*");
			printf( "IntentNoToBeSrz:%s\n", IntentNoToBeSrz);fflush(stdout);
			CALLAPI(ChkExistingCmvrNoFunc(ToBeNewCmvrNoDup,IntentNoToBeSrz,&cmvrcnt1,&Qrycmvrobjset)); //Function for Query All cmvr object based on input
			printf( "cmvrcnt1:%d\n", cmvrcnt1);fflush(stdout);
			tc_strcpy(IntNumStr,"");
			tc_strcat(IntNumStr,"Intent NO,CMVR NO :");
			
			
			if(cmvrcnt1>0)
			{
				AOM_ask_value_string( Qrycmvrobjset[0], "t5_IntentNumber", &CmvrIntentNum);
				printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
				if(CmvrIntentNum)
				{
					 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
					printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
				}
				
				AOM_ask_value_string( Qrycmvrobjset[0], "t5_CmvrNo", &ExCmvrNo);
				printf( "ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
				if(ExCmvrNo)
				{
					 tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
					printf( "ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
				}
			}
			
			if(CMVR_tag)
			{
				AOM_ask_value_string( CMVR_tag, "t5_IntentNumber", &CmvrIntentNum);
				printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
				if(CmvrIntentNum)
				{
					 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
					printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
				}
				
				// AOM_ask_value_string( CMVR_tag, "t5_CmvrNo", &ExCmvrNo);
				// printf( "ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
				// if(ExCmvrNo)
				// {
					 // tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
					// printf( "ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
				// }
				
				// printf("\nExisting CmvrNo is : %s \n",ExCmvrNoDup);fflush(stdout);
				
				AOM_ask_value_string( CMVR_tag, "t5_VehType", &CmvrBusUnit);
				printf( "CmvrBusUnit:%s\n", CmvrBusUnit);fflush(stdout);
				if(CmvrBusUnit)
				{
					 tc_strdup(CmvrBusUnit,&CmvrBusUnitDup);	
					printf( "CmvrBusUnitDup:%s\n", CmvrBusUnitDup);fflush(stdout);
				}
			}
				printf("\nCmvrBusUnitDup is : %s save_context=%d\n",CmvrBusUnitDup,save_context);fflush(stdout);
				if((save_context==4) || (save_context==3) || (save_context==1)) //save_context ==4 or 1 for save as and save_context==0 for create new item ,Edit/save=3
				//if(save_context>0)
				{
					printf("\n inside save_context condition save  :: %d\n",save_context);fflush(stdout);
					
					AOM_ask_value_string( new_item, "t5_ExtNo", &CertExtnNo);
					printf( "CertExtnNo:%s\n", CertExtnNo);fflush(stdout);
					if(CertExtnNo)
					{
						 tc_strdup(CertExtnNo,&CertExtnNoDup);
						 
						printf( "CertExtnNoDup :%s\n", CertExtnNoDup);fflush(stdout);
					}
					
				//	AOM_ask_value_string( new_item, "t5_CmvrNo", &ExCmvrNo);
				// printf( "2ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
				// if(ExCmvrNo)
				// {
					 // tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
					// printf( "ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
				// }
				
				
				AOM_ask_value_string( new_item, "t5_IntentNumber", &CmvrIntentNum);
				printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
				if(CmvrIntentNum)
				{
					 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
					printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
				}
				printf("\n2Existing CmvrNo is : %s cmvrcnt1=%d\n",ExCmvrNoDup,cmvrcnt1);fflush(stdout);
				if(tc_strlen(ExCmvrNoDup)>0)
				{
					if((tc_strcmp(ExCmvrNoDup,NewCmvrNo)==0) || (cmvrcnt1>0))
					{
						CmvrFlag=1;
						tc_strcat(IntNumStr,"\n");
						tc_strcat(IntNumStr,CmvrIntentNumDup);
						tc_strcat(IntNumStr,",");
						tc_strcat(IntNumStr,ExCmvrNoDup);
					}
				}
					printf("\nIntNumStr :: %s CmvrFlag=%d\n",IntNumStr,CmvrFlag);fflush(stdout);
					if(CmvrFlag==1)
					{
						//EMH_store_error_s2(EMH_severity_error,ITK_err,"CMVR already available for input value:- \n ",IntNumStr);
						//printf("\nInside Err IntNumStr :: %s\n",IntNumStr);fflush(stdout);
						//return ITK_err;
						printf("\nInside same CMVR No IntNumStr :: %s, going to skip saveAsPost for CMVR as no new CMVR will be create by Save As option\n",IntNumStr);fflush(stdout);
						return ifail;
						
					}
					printf("\nInside CertExtnNoDup: %s\n",CertExtnNoDup);fflush(stdout);
					if(save_context==TCTYPE_save_on_update || save_context== TCTYPE_unknown_operation_context)
					{ 
						char *username;
						CALLAPI(POM_get_user_id (&username));
						printf("\n\n  Session login user [%s] for CMVR Eidt .\n",username); fflush(stdout);
						
						char * CmvrBypassUsrName=NULL;
						printf("\n b4 call CmvrBypassUsrName = %s func for post method tm_CmvrCreSaveFun\n",CmvrBypassUsrName);fflush(stdout);
						CmvrBypassUsrName=CmvrBypassUsr();

						printf("\n after tm_CmvrCreSaveFun CmvrBypassUsrName = %s\n",CmvrBypassUsrName);fflush(stdout);
						if(tc_strstr(CmvrBypassUsrName,username)!=NULL)
						//if(tc_strstr(username,"rrb06909")!=NULL)
						{
							printf("\nCert Extn No ,CMVR No to be update by Edit option if user is %s. \n",username);fflush(stdout);	
							CALLAPI(AOM_lock(new_item));
							//AOM_set_value_string(new_item,"t5_IntentNumber", IntentNoToBeDup);
							//AOM_set_value_string(new_item,"item_id", IntentNoToBeDup);
							CALLAPI(AOM_set_value_string(new_item,"t5_CmvrNo", ToBeNewCmvrNoDup));
							CALLAPI(AOM_set_value_string(new_item,"t5_ExtNo", CertExtnNoDup));
							//AOM_set_value_string(new_item,"t5_Intent_4", runningSrlChar);
							//AOM_set_value_string(new_item,"object_name", CmvrDescDup);
							//CALLAPI(AOM_save(*new_item));						
							CALLAPI(AOM_save_without_extensions(new_item));						
							CALLAPI(AOM_unlock(new_item));
							//return ifail;
						}
						else
						{
						printf("\nCert Extn No ,CMVR No cant be update by Edit option , going to skip saveAsPost for CMVR as no new CMVR will be create by Edit option\n",IntNumStr);fflush(stdout);	
						return ifail;
						}
						
						//return ifail;
					}
					else
					{
							CALLAPI(AOM_lock(new_item));
							AOM_set_value_string(new_item,"t5_IntentNumber", IntentNoToBeDup);
							AOM_set_value_string(new_item,"item_id", IntentNoToBeDup);
							CALLAPI(AOM_set_value_string(new_item,"t5_CmvrNo", ToBeNewCmvrNoDup));
							CALLAPI(AOM_set_value_string(new_item,"t5_ExtNo", CertExtnNoDup));
							//AOM_set_value_string(new_item,"t5_Intent_4", runningSrlChar);
							//AOM_set_value_string(new_item,"object_name", CmvrDescDup);
							//CALLAPI(AOM_save(*new_item));						
							CALLAPI(AOM_save_without_extensions(new_item));						
							CALLAPI(AOM_unlock(new_item));
					}		
							printf("\nB4 Release status T5_LcsReview added to IntentNoToBeDup :: %s\n",IntentNoToBeDup);fflush(stdout);
						////CALLAPI(CR_create_release_status("T5_LcsReview",&status_rel)); //hashed for Teamcenter14 recommendation
						//CALLAPI(RELSTAT_create_release_status("T5_LcsReview",&status_rel)); //similar new API for Teamcenter14
						//if(status_rel)
						//CALLAPI(RELSTAT_add_release_status(status_rel,1,new_item,retain));  
						printf("\nAfter Release status T5_LcsReview added to IntentNoToBeDup :: %s\n",IntentNoToBeDup);fflush(stdout);

				}
				//adding new cmvrno val to CMVR LOV 
				
				//CmvrIntentNumDup t5_VehType
				
				//client code logic need to place here for backend mode
									
									tag_t *Cntrlobjset=NULLTAG;
									tag_t   qryTagCntrl    = NULLTAG;
									int     n_entryCntrl    = 3;
									char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
									char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
									int cntrlcnt=0;
									int  control_number_found=0;
									char* shellpath = NULL;
									char* sysCmnd = NULL;
									
									//if(QRY_find("Control Objects...", &qryTagCntrl));
									if(QRY_find2("Control Objects...", &qryTagCntrl));
									if (qryTagCntrl)
									{
										printf("\n Control Object Query Found \n");fflush(stdout);
										qry_valuesCntrl[0]="AutoAddCmvrnoToLov";
										qry_valuesCntrl[1]="Live";
										qry_valuesCntrl[2]="0";
										
										if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &Cntrlobjset));
									}
									else
									{
										printf("\n Control Object Query not Found .... \n");fflush(stdout);
										
									}	
									
									printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
									
									if(control_number_found>0)
									{
										printf("\n Control Object AutoAddCmvrnoToLov Found \n");fflush(stdout);
										
										AOM_ask_value_string( CMVR_tag, "t5_IntentNumber", &CmvrIntentNum);
										printf( "22CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
										if(CmvrIntentNum)
										{
											 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);	
											printf( "22CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
										}
										AOM_ask_value_string( CMVR_tag, "t5_CmvrNo", &ExCmvrNo);
										printf( "22ExCmvrNo:%s\n", ExCmvrNo);fflush(stdout);
										if(ExCmvrNo)
										{
											 tc_strdup(ExCmvrNo,&ExCmvrNoDup);	
											printf( "22ExCmvrNoDup:%s\n", ExCmvrNoDup);fflush(stdout);
										}
										
										printf("\n22Existing CmvrNo is : %s \n",ExCmvrNoDup);fflush(stdout);	
												
												
												ITK_CALL(AOM_ask_value_string(Cntrlobjset[0],"t5_Userinfo1",&shellpath));
												
												printf("\n AutoAddCmvrnoToLov shellpath==>%s\n",shellpath);fflush(stdout);
													
										
									
				
				
				
													char * 	ClsAttrName=NULL;
													char *	ClsAttrshortName=NULL;
													char * 	ClsAttrUnit=NULL;
													int  	ClsAttrFormat=0;
													int cmvrAttrId =0;
													
													int retcount;
													printf("\n CmvrBusUnitDup: %s \n",CmvrBusUnitDup);fflush(stdout);
													CALLAPI(getCmvrAttrNoWrtTSBU(CmvrBusUnitDup,&retcount));
													printf("\n after call getCmvrAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
													cmvrAttrId=retcount;
													printf("\n  before ICS_describe_unct cmvrAttrId=%d",cmvrAttrId); fflush(stdout);
													CALLAPI(ICS_describe_unct(cmvrAttrId,&ClsAttrName,&ClsAttrshortName,&ClsAttrUnit,&ClsAttrFormat));
													printf("\n After ICS_describe_unct ifail[%d]",ifail); fflush(stdout);
													if(ifail != ITK_ok)
													{
													printf("\n  cmvrAttrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",cmvrAttrId,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);						
													return ifail;	
													}
													printf("\n 2 cmvrAttrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",cmvrAttrId,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);
													 char theKeyLOVId[10];
													const char * 	key_lov_id;
													if(ClsAttrFormat)
													{
																	
														sprintf(theKeyLOVId, "%d", ClsAttrFormat);
														key_lov_id=theKeyLOVId;	
														printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);
													}
													if(key_lov_id)
													{
														if(tc_strlen(shellpath)>0)
														{
															printf("\ninside AutoAddCmvrnoToLov Execute through client code by EXE[%s] key_lov_id[%s] \n",shellpath,key_lov_id);fflush(stdout);
															
															
															sysCmnd=(char *) MEM_alloc(400);
															tc_strcpy(sysCmnd,shellpath);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-cmvr=);
															tc_strcat(sysCmnd,key_lov_id);
															tc_strcat(sysCmnd," ");
															//tc_strcat(sysCmnd,-veh=);
															tc_strcat(sysCmnd,ToBeNewCmvrNoDup);
															printf("\n before-- Calling shell file AutoAddCmvrnoToLov.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															system(sysCmnd);
															
															printf("\n after --- Calling shell file AutoAddCmvrnoToLov.sh using client system command: %s\n",sysCmnd);fflush(stdout);
															
															MEM_free(sysCmnd);
														}
													}
									}
									else
									{
										printf("\n  No control obj[AutoAddCmvrnoToLov] found for Auto Cmvrno value update to LOV !! "); fflush(stdout);
									}
				//End adding new cmvrno val to CMVR LOV 
				
				
				printf("\nCMVR object created with IntentNoToBeDup :: %s ToBeNewCmvrNoDup = %s with ifail=%d\n",IntentNoToBeDup,ToBeNewCmvrNoDup,ifail);fflush(stdout);
				
				
			}
			/*else
			{
				printf("\nNo CMVR available in system :: %s\n",ToBeNewCmvrNoDup);fflush(stdout);
				if(tc_strlen(ToBeNewCmvrNoDup)<11)
					{
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Invalid Length Of Intent Number:-  ",ToBeNewCmvrNoDup);
						printf("\nToBeNewCmvrNoDup :: %s\n",ToBeNewCmvrNoDup);fflush(stdout);
						return ITK_err;
					}
					else
					{
						printf("\n b4 set ToBeNewCmvrNoDup = %s ToBeNewCmvrNoDup = %s for create CMVR object !!\n",ToBeNewCmvrNoDup,ToBeNewCmvrNoDup);fflush(stdout);
						AOM_set_value_string(*new_item,"t5_IntentNumber", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"item_id", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"t5_CmvrNo", ToBeNewCmvrNoDup);
						AOM_set_value_string(*new_item,"t5_Intent_4", last4Dup);
						CALLAPI(AOM_lock(item_master_form));
						printf("\nB4 set ToBeNewCmvrNoDup :: %s in object_name\n",ToBeNewCmvrNoDup);fflush(stdout);
						AOM_set_value_string(item_master_form,"object_name", ToBeNewCmvrNoDup);
						CALLAPI(AOM_save(item_master_form));						
						CALLAPI(AOM_unlock(item_master_form));
						printf("\nAfter set ToBeNewCmvrNoDup :: %s in object_name for item_master_form\n",ToBeNewCmvrNoDup);fflush(stdout);
						char *rev_master_form_id=NULL;
						rev_master_form_id=MEM_alloc(30);
                        tc_strcpy(rev_master_form_id,ToBeNewCmvrNoDup); 
                        tc_strcat(rev_master_form_id,"/"); 
                        tc_strcat(rev_master_form_id,rev_id); 
						printf("\nB4 set ToBeNewCmvrNoDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
						CALLAPI(AOM_lock(item_rev_master_form));
                        CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
                        CALLAPI(AOM_save(item_rev_master_form));
                        CALLAPI(AOM_unlock(item_rev_master_form));
						printf("\nAfter set ToBeNewCmvrNoDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
					}
			}
			*/

			if(ifail == ITK_ok)
				{
					NotifyMsg = (char *) MEM_alloc( 150 * sizeof(char) );
					printf("\n CMVR object created with IntentNoToBeDup :: %s ToBeNewCmvrNoDup = %s",IntentNoToBeDup,ToBeNewCmvrNoDup); fflush(stdout);
					tc_strcpy(NotifyMsg,"Below CMVR created,Pls Check\n");
					tc_strcat(NotifyMsg,"CMVR object created with IntentNoToBeDup");
					tc_strcat (NotifyMsg,"[");
					tc_strcat(NotifyMsg,IntentNoToBeDup);
					tc_strcat (NotifyMsg,"]");
					
					
					printf( "NotifyMsg:%s\n", NotifyMsg);fflush(stdout);
			
					//EMH_store_error_s2(EMH_severity_information,ITK_err,"Below CMVR created,Pls Check \n",NotifyMsg);
					//EMH_store_error_s1(EMH_severity_information,ITK_err,NotifyMsg);
					//return ITK_err;
				}
			//MEM_free(cmvr_obj);
			//MEM_free(NotifyMsg);
			
		//}
	
	printf("\n 	 End tm_CmvrCreSaveFun for post action tm_Cmvr creation !! ");fflush(stdout);
	//MEM_free(IntNumStr);
	//MEM_free(NewCmvrNo);
	return 0;
	
}

extern int CMVRinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  cmvr_item_create;
	METHOD_id_t  cmvr_item_save;
	METHOD_id_t  cmvrdml_rev_iman_save;
	METHOD_id_t  cmvrdml_rev_imantype_init_intl_props;
	METHOD_id_t  lot_number_iman_save;
	METHOD_id_t  BoxQty_number_iman_save;
	METHOD_id_t  method2;
	METHOD_id_t methodpos;
	METHOD_id_t methodpos1;
	METHOD_id_t method4;
	printf("\n ############ After Rigister CMVRinitmodule");fflush(stdout);
	
	
	/* Overriding IMAN_Save of DML Master for setting the nomenclature while creation */
	//CALLAPI(METHOD_find_method("T5_cmvrDml", "IMAN_save", &cmvr_item_create));
	CALLAPI(METHOD_find_method("T5_CMVR", "ITEM_create", &cmvr_item_create));
//	CALLAPI(METHOD_find_method("T5_CMVR", "IMAN_save", &cmvr_item_save));
	//if (cmvr_item_create.id != NULLTAG)
	if (cmvr_item_create.id != 0)
    {	
		TC_write_syslog("\n before Rigister tm_cmvrdml_set_init_val");
		CALLAPI(METHOD_add_action(cmvr_item_create, METHOD_post_action_type,(METHOD_function_t)tm_CmvrCreFun ,NULL));
		//CALLAPI(METHOD_add_action(cmvr_item_create, METHOD_pre_action_type,(METHOD_function_t)tm_cmvrdml_set_init_val ,NULL));
		//CALLAPI(METHOD_add_action(cmvr_item_create, METHOD_post_action_type,(METHOD_function_t)tm_CmvrCreSaveFun ,NULL));
		TC_write_syslog("\n IN After Rigister tm_cmvrdml_set_init_val");
    }
	else
	{
		printf("\n IN After Rigister tm_cmvrdml_set_init_val  == NULL");fflush(stdout);
	}
	// End overriden 
	
	
	//if (cmvr_item_save.id != NULLTAG)
/*	if (cmvr_item_save.id != 0)
    {	
		TC_write_syslog("\n before Rigister tm_cmvrdml_set_init_val");
		CALLAPI(METHOD_add_action(cmvr_item_save, METHOD_post_action_type,(METHOD_function_t)tm_CmvrCreSaveFun ,NULL));
		//CALLAPI(METHOD_add_action(cmvr_item_create, METHOD_pre_action_type,(METHOD_function_t)tm_cmvrdml_set_init_val ,NULL));
		//CALLAPI(METHOD_add_action(cmvr_item_create, METHOD_post_action_type,(METHOD_function_t)tm_CmvrCreSaveFun ,NULL));
		TC_write_syslog("\n IN After Rigister tm_cmvrdml_set_init_val");
    }
	else
	{
		printf("\n IN After Rigister tm_cmvrdml_set_init_val  == NULL");fflush(stdout);
	}
*/	
	TC_write_syslog("\n  b4 t5_CmvrVeh METHOD_register_prop_method register\n"); 		
				CALLAPI(METHOD_register_prop_method("Design Revision", "t5_VehForCmvr",  PROP_ask_value_tag_msg, getCmvrRelationFrmVC, 0,  &method2 ));
				TC_write_syslog("\n  After t5_CmvrVeh METHOD_register_prop_method register\n");
				
//		ITKCALL(METHOD_register_method( "T5_EcuVersionListLov",LOV_ask_values_msg,&dynamic_ecuVerLov_ValuesMethod, 0,&methodpos));
		
		TC_write_syslog("\n  b4 METHOD_register_method for dynamic_CmvrInitiatorMethod \n"); 	
		ITKCALL(METHOD_register_method( "T5_InitiatedByLov",LOV_ask_values_msg,&dynamic_CmvrInitiator_ValuesMethod, 0,&methodpos));
		ITKCALL(METHOD_register_method( "T5_InitiatedByLov",LOV_ask_num_of_values_msg,&dynamic_CmvrInitiatorMethod,0,&methodpos));
		TC_write_syslog("\n  After METHOD_register_method for dynamic_CmvrInitiatorMethod \n"); 	

		TC_write_syslog("\n  b4 METHOD_register_method for dynamic_CmvrApproverLovMethod \n"); 
		ITKCALL(METHOD_register_method( "T5_ApproveByLov",LOV_ask_values_msg,&dynamic_CmvrApprover_ValuesMethod, 0,&methodpos1));		
		ITKCALL(METHOD_register_method( "T5_ApproveByLov",LOV_ask_num_of_values_msg,&dynamic_CmvrApproverLovMethod,0,&methodpos1));
		TC_write_syslog("\n  After METHOD_register_method for dynamic_CmvrApproverLovMethod \n");

		ifail = METHOD_find_method("T5_CmvrVeh", GRM_create_msg, &method4);
		if( ifail == ITK_ok )
		{
			TC_write_syslog("\n Before register method for GRM_create_msg in CMVR & VC relation create  \n");
			//if (method4.id != NULLTAG)
			if (method4.id != 0)
			{
				if( METHOD_add_action(method4, METHOD_post_action_type, (METHOD_function_t) CmvrToVcRelPostMsg, NULL)!=ITK_ok)
				TC_write_syslog("Registered as METHOD_pre_action_type for CMVR & VC relation create\n");
			}
			else
			printf("Method not found!GRM_create_msg for relation T5_CmvrVeh\n");
		}
		
	return ifail;
	
}

//Start for user service for CmvrCpyProc option

int CmvrCpyProc(void *retValue)
{
		const char				*prog_name 		="CmvrCpyProc";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* oldcmvrname  = NULL;
		char* cmvrdesc  = NULL;
		char* cmvrcertextnno  = NULL;
		char* CreUserId  = NULL;
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	BaseVCTag		= NULLTAG;
		tag_t	BaseVCRevTag		= NULLTAG;
		tag_t	NewVCTag		= NULLTAG;
		tag_t	NewVCRevTag		= NULLTAG;
				
				
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *BaseVCPartType=NULL;
				
		USERARG_get_string_argument(&oldcmvrname); 
		USERARG_get_string_argument(&cmvrdesc);
		USERARG_get_string_argument(&cmvrcertextnno);
		USERARG_get_string_argument(&CreUserId);
		printf("\nInside CmvrCpyProc user service\n");fflush(stdout);
		printf("\n--->>>>>input args oldcmvrname >> %s cmvrdesc >> %s cmvrcertextnno >> %s CreUserId >> %s",oldcmvrname,cmvrdesc,cmvrcertextnno,CreUserId);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="CpyCmvrIntent";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for CpyCmvrIntent.... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object CpyCmvrIntent CC  Found \n");fflush(stdout);
				
				
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for CpyCmvrIntent tm_CpyCmvrIntentProc ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_CpyCmvrIntentProc Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,oldcmvrname);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,cmvrdesc);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,cmvrcertextnno);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,CreUserId);
									
									printf("\n before-- Calling shell file tm_CpyCmvrIntentProc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_CpyCmvrIntentProc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
						
				
				
			}
			else
			{
				printf ("\n CmvrCpyProc shellpath for CpyCmvrIntent is NULL as control object CpyCmvrIntent not found ");fflush(stdout);
			}
		
		
		
		printf ("\n CmvrCpyProc  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int CmvrCpyProcFunc(int *decision, va_list args)
extern int CmvrCpyProcFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 4;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // Old Cmvr No
	inputArgTypes[1] = USERARG_STRING_TYPE; // New Cmvr Desc
	inputArgTypes[2] = USERARG_STRING_TYPE; // New Cmvr Cert Extn No
	inputArgTypes[3] = USERARG_STRING_TYPE; // New Cmvr Cert Extn No
	retValueType = USERARG_VOID_TYPE;
	ifail=USERSERVICE_register_method("CmvrCpyProc",(USER_function_t)CmvrCpyProc,nargs,inputArgTypes,retValueType);
// printf("\n CmvrCpyProcFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for user service for CmvrCpyProc option
extern int cmvrUsrServCall(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
 
	 printf("\n inside the  cmvrUsrServCall func");fflush(stdout);
	 ITK_CALL(CmvrCpyProcFunc());
	 printf("\n End the  cmvrUsrServCall func");fflush(stdout);
 
 }

extern DLLAPI int tm_cmvr_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	TC_write_syslog("\n Before registering tm_cmvr_register_callbacks....tm_cmvr");   
	ifail=CUSTOM_register_exit ( "tm_cmvr", "USER_init_module", (CUSTOM_EXIT_ftn_t)CMVRinitmodule);	
	TC_write_syslog("\n After registering tm_cmvr_register_callbacks");
	
	TC_write_syslog("\n Before registering userservice....cmvrUsrServCall");   
	ITK_CALL(CUSTOM_register_exit ( "tm_cmvr", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  cmvrUsrServCall));
	TC_write_syslog("\n After registering userservice....cmvrUsrServCall");
	return ( ITK_ok );
}


