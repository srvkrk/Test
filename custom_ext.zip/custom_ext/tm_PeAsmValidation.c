/****************************************************************************************************
*	File			:	tm_PeAsmValidation.c
*	Created By		:	Manindra Praharaj
*	Created On		:	05-July-2024
*	Purpose			:	PE Part Validations on PE Part Create/Check-In/Check-Out/Revise
*
*	Modification History	:  
*  S.No		Date			CR		Modified By			Modification Notes
******************************************************************************************************/
#include <epm/epm_toolkit_tc_utils.h>
#include "tm_apl_std_common_function.c"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}


#define ERROR_CALL(x){               \
						int stat;                     \
						char *err_string = NULL;             \
						if( (stat = (x)) != ITK_ok)   \
						{                             \
						EMH_ask_error_text (stat, &err_string);              \
						if(err_string != NULL) {\
						printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
						printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
						TC_write_syslog("FORM Property Migiration[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
						MEM_free (err_string);\
						err_string=NULL;\
						}\
						return (stat);          \
						}                         \
					}

static int report_error( char *file, int line, char *function, int return_code)			
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}																						

/************************* Adi ****************/

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int t5removeAllReleaseStatus (tag_t rev)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	ERROR_CALL (WSOM_ask_release_status_list(rev,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		CALLAPI(POM_class_of_instance(rev,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&rev));
		CALLAPI(POM_load_instances(1,&rev,class_id,1));
		CALLAPI(POM_is_loaded(rev,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_save_instances(1,&rev,1));

				CALLAPI(POM_refresh_instances(1,&rev,class_id,2));

				CALLAPI(AOM_lock(rev));

				CALLAPI(AOM_save_without_extensions(rev));
				CALLAPI(AOM_refresh(rev,1));

			}

			 CALLAPI(AOM_unlock(rev));
		}
		printf("\n Status removed");;fflush(stdout);
	}
		/*ERROR_CALL (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
		ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));
		//ERROR_CALL(ITK_set_bypass(TRUE));

		ERROR_CALL(AOM_refresh(rev,1));
		ERROR_CALL(AOM_save_without_extensions(rev));
	*/
		ERROR_CALL(AOM_unlock(rev));
}

extern DLLAPI int PERevMstCreValidation(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int ifail = ITK_ok;
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	
	printf("\n--->>>>> Hello From tm_PartGeneration_set_init_val ");fflush(stdout);
	if(*new_item != NULLTAG)
	{
		char*	PartNumber			= NULL;
		char*	FinalPartNo			= NULL;
		char*	itemid				= NULL;
		char*	revid				= NULL;
		char*	refprtnum			= NULL;
		char*	prtctgry			= NULL;
		char*	Clrid				= NULL;
		char*	objname				= NULL;
		//char*	ProjectName				= NULL;
		//ProjectName = (char *)MEM_alloc (desclength * sizeof(char));
		char *ProjectName = NULL;
		ProjectName=(char *) MEM_alloc(18);
		char*	ProjectName1			= NULL;
		char*	desgrp				= NULL;
		char*	DesRevDesc				= NULL; 
		int revdesccnt= 0;
		int desclength = 0;
		char   *ReplacedDesRevDesc		= NULL;
		char   *NewReplacedDescription		= NULL;
		
		
		
		printf("\n--->>>>> Hello From tm_PartGeneration_set_init_val  and found the item tag ");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(*new_item,"item_id",&itemid));
		printf("\n The Input Item_id is :  %s \n",itemid);fflush(stdout);	

		CALLAPI(AOM_ask_value_string(*new_rev,"item_revision_id",&revid));
		printf("\n The Input revision ID is :  %s \n",revid);fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(*new_item,"object_name",&objname));
		printf("\n The Input Name is :  %s \n",objname);fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(*new_rev,"t5_ProjectName",&ProjectName));
		printf("\n The Input ProjectName is :  %s \n",ProjectName);fflush(stdout);
		if( AOM_ask_value_string(*new_item,"object_desc",&DesRevDesc)!=ITK_ok);PrintErrorStack();
		// if( AOM_ask_value_string(objTag,"t5Material",&ItemMaterial)!=ITK_ok);
		printf("\nPE Part Master ID : [%s]	Desc : [%s]\n",itemid,DesRevDesc);fflush(stdout);
		
		if(strcmp(DesRevDesc,"")!=0)
		{
			desclength = strlen(DesRevDesc);
			for(revdesccnt=0;revdesccnt<desclength;revdesccnt++)
			{
				if(DesRevDesc[revdesccnt]=='\n')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='`')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='~')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='|')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='$')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='#')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='@')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='^')
					DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='!')
					DesRevDesc[revdesccnt] =' ';
				//printf("\n [%c]\n",DesRevDesc[revdesccnt]);fflush(stdout);
			}

			ReplacedDesRevDesc = (char *)MEM_alloc (desclength * sizeof(char));
			strcpy(ReplacedDesRevDesc,DesRevDesc);

			printf("\n AFTER PERevMstCreValidation ::ReplacedDesRevDesc=====>[%s]\n",ReplacedDesRevDesc);fflush(stdout);
			if(ReplacedDesRevDesc)
			{
				if(AOM_set_value_string(*new_item,"object_desc",ReplacedDesRevDesc)!=ITK_ok) PrintErrorStack();
				if(AOM_save_without_extensions(*new_item)!=ITK_ok) PrintErrorStack();
				if(AOM_unlock(*new_item))PrintErrorStack();
				if(AOM_ask_value_string(*new_item,"object_desc",&NewReplacedDescription)!=ITK_ok) PrintErrorStack();
				printf("\n AFTER SET PERevMstCreValidation :: NewReplacedDescription==>[%s]\n", NewReplacedDescription);fflush(stdout);
			}
		}
	
		CALLAPI(AOM_set_value_string(*new_rev,"t5_ProjectCode",ProjectName));
		CALLAPI(AOM_save_without_extensions(*new_rev));						
		CALLAPI(AOM_unlock(*new_rev));
		
		CALLAPI(AOM_ask_value_string(*new_rev,"t5_ProjectCode",&ProjectName1));
		printf("\n The Output ProjectName1  is :  %s \n",ProjectName1);fflush(stdout);
		MEM_free(ProjectName);
	}
		

	printf("\n Inside Production Engineering Pre Action of Revision  End   ***T5_PeDesignRevision***\n");fflush(stdout);

      return error_code;
}

extern DLLAPI int PERevCreValidationPost(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;
	char*	type_name=NULL;
	char	*desid			= NULL;
	char	*Desc			= NULL;
	char	*NewDesc		= NULL;
	char	*DerRoleNme		= NULL;
	char	*DerRoleNme1	= NULL;
	char	*NewDescription = NULL;
	char	*objname		= NULL;
	
	tag_t	rev			= NULLTAG;
	tag_t*	resultTags	= NULLTAG;
	
	char *DrwName		= NULL;
	char *DrwName1		= NULL;
	char *parent_name	= NULL;
	char *group_name	= NULL;
	char *Role_name		= NULL;
	char *Grp_name		= NULL;
	char *Desc_obj2		= NULL;
	char *item_rev_id	= NULL;
	char *currpro		= NULL;

	tag_t	attr_id ;
	tag_t	*attachments	= NULLTAG;

	int		cnt=0;
	int		ij=0;
	int		jk=0;
	int		jkl=0;
	int		Rolflag=0;
	int		dsflag=0;
	
	char	*qry_entries[2] = {"Name","Type"},	*qry_values[2]	= {"*","CMI2Drawing"};
	
	int     index,resultCount=0,j=0;
	
	char	*ObjectClassType	= NULL;
	char	*ObjectName		= NULL;
	char	*desi_grp		= NULL;
	char*	oojname			= NULL;
	
	tag_t	form_attr_id ;
	tag_t	relation_type	= NULLTAG;
	tag_t	DesRolTag		= NULLTAG;
	tag_t	Currproj		= NULLTAG;
	tag_t	GroupMem		= NULLTAG;
	tag_t	Roletag			= NULLTAG;
	tag_t	grptag			= NULLTAG;
	tag_t   projobj; 
	tag_t	dataset			= NULLTAG;
	tag_t	ActGm			= NULLTAG;
	tag_t	ActGm1			= NULLTAG;
	tag_t	status_rel		= NULLTAG;
	tag_t	projid			= NULLTAG;
	tag_t   tagItem			= NULLTAG;
	
	logical	checkout		= 0;
	logical	checkoutp		= 0;
	logical	retain			= 0;
	logical	promem			= 0;

	tag_t	reln_type			= NULLTAG;
	tag_t*  secondary_objects	= NULLTAG;
    tag_t	user_tag			= NULLTAG;

	char* username;
	const char		*reason		= "";
	const char		*change_id	= "";
	const char		*dir_name	= "";
	

	char* type_name2=NULL;
	double objWeightVal ;
	double roundedWtVal ;	 
	char wgtstr[100];
	tag_t   qryTag     = NULLTAG;  
	int     n_entry    = 1;             
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *)); 
	int     rsltCount      =  0;        
	tag_t   *CntrlObjectTag      = NULLTAG;
	char	*DesgTyp	= NULL;
	char	*info1	= NULL;
	char	*MPart_Desg	= NULL;
	char	*Part_DegGrp	= NULL;
	char	*Part_prj	= NULL;
	char	*DesgNo	= NULL;
	char	*sDesgNoG	= NULL;
	char	*sDesgNoT	= NULL;
	char	*sDesgNoVC	= NULL;
	char	*sDesgNoV	= NULL;
	char	*sDesgNoVCCR	= NULL;
	char	*PrtProj	= NULL;
	char	*info2	= NULL;
	char	*PrtDR	= NULL;
	char	*sDesgNoD	= NULL;
	char	*Part_Desg	= NULL;
	char	*Part_Proj	= NULL;
	char 	*Proj_typ		= NULL;
	tag_t	Project_t		= NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	char*	type_Proj=NULL;

	tag_t	TagQryContObjSite	= NULLTAG;
	char   *desidForTRL			= NULL;
	char   *sLastThreeChar		= NULL;
	char   *NewIDTRL			= NULL;

	int CntrCount = 0;
	int	n_Input = 2;

	char	*gov_class		= NULL;
	char	*RepalcedID		= NULL;
	char	*DesgTypTRL		= NULL;	
	char	*projcodeList	= NULL;
	char	*projcode		= NULL;
	tag_t	projobj1;

	int iTemp=0;
	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	tag_t		primary		= NULLTAG;

	if(1)
	{
		
		tag_t objTypeTag,item_tag = NULLTAG;
		char*	type_name=NULL;
		char	*desid			= NULL;
		char	*Desc			= NULL;
		char	*NewDesc		= NULL;
		char	*DerRoleNme		= NULL;
		char	*DerRoleNme1	= NULL;
		char	*NewDescription = NULL;
		char	*objname		= NULL;
		
		tag_t	rev			= NULLTAG;
		tag_t*	resultTags	= NULLTAG;
		
		char *DrwName		= NULL;
		char *DrwName1		= NULL;
		char *parent_name	= NULL;
		char *group_name	= NULL;
		char *Role_name		= NULL;
		char *Grp_name		= NULL;
		char *Desc_obj2		= NULL;
		char *item_rev_id	= NULL;
		char *currpro		= NULL;

		tag_t	attr_id ;
		tag_t	*attachments	= NULLTAG;

		int		cnt=0;
		int		ij=0;
		int		jk=0;
		int		jkl=0;
		int		Rolflag=0;
		int		dsflag=0;
		
		char	*qry_entries[2] = {"Name","Type"},	*qry_values[2]	= {"*","CMI2Drawing"};
		
		int     index,resultCount=0,j=0;
		
		char	*ObjectClassType	= NULL;
		char	*ObjectName		= NULL;
		char	*desi_grp		= NULL;
		char*	oojname			= NULL;
		
		tag_t	form_attr_id ;
		tag_t	relation_type	= NULLTAG;
		tag_t	DesRolTag		= NULLTAG;
		tag_t	Currproj		= NULLTAG;
		tag_t	GroupMem		= NULLTAG;
		tag_t	Roletag			= NULLTAG;
		tag_t	grptag			= NULLTAG;
		tag_t   projobj; 
		tag_t	dataset			= NULLTAG;
		tag_t	ActGm			= NULLTAG;
		tag_t	ActGm1			= NULLTAG;
		tag_t	status_rel		= NULLTAG;
		tag_t	projid			= NULLTAG;
		tag_t   tagItem			= NULLTAG;
		
		logical	checkout		= 0;
		logical	checkoutp		= 0;
		logical	retain			= 0;
		logical	promem			= 0;

		tag_t	reln_type			= NULLTAG;
		tag_t*  secondary_objects	= NULLTAG;
		tag_t	user_tag			= NULLTAG;

		char* username;
		const char		*reason		= "";
		const char		*change_id	= "";
		const char		*dir_name	= "";
		

		char* type_name2=NULL;
		double objWeightVal ;
		double roundedWtVal ;	 
		char wgtstr[100];
		tag_t   qryTag     = NULLTAG;  
		int     n_entry    = 1;             
		char    *qry_entry[1]  = {"SYSCD"};
		char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *)); 
		int     rsltCount      =  0;        
		tag_t   *CntrlObjectTag      = NULLTAG;
		char	*DesgTyp	= NULL;
		char	*info1	= NULL;
		char	*MPart_Desg	= NULL;
		char	*Part_DegGrp	= NULL;
		char	*Part_prj	= NULL;
		char	*DesgNo	= NULL;
		char	*sDesgNoG	= NULL;
		char	*sDesgNoT	= NULL;
		char	*sDesgNoVC	= NULL;
		char	*sDesgNoV	= NULL;
		char	*sDesgNoVCCR	= NULL;
		char	*PrtProj	= NULL;
		char	*info2	= NULL;
		char	*PrtDR	= NULL;
		char	*sDesgNoD	= NULL;
		char	*Part_Desg	= NULL;
		char	*Part_Proj	= NULL;
		char 	*Proj_typ		= NULL;
		tag_t	Project_t		= NULLTAG;
		tag_t	ObjTypProj	= NULLTAG;
		char*	type_Proj=NULL;

		tag_t	TagQryContObjSite	= NULLTAG;
		//tag_t *cntr_objects		= NULL;
		char   *desidForTRL			= NULL;
		char   *sLastThreeChar		= NULL;
		char   *NewIDTRL			= NULL;

		int CntrCount = 0;
		int	n_Input = 2;

		char	*gov_class		= NULL;
		char	*RepalcedID		= NULL;
		char	*DesgTypTRL		= NULL;	
		char	*projcodeList	= NULL;
		char	*projcode		= NULL;
		tag_t	projobj1;

		int iTemp=0;
		int desclength = 0,index1=0;
		int desccnt = 0,n_entries=2;
		int c_attchs = 0,p=0;
		tag_t		primary			= NULLTAG;

		tag_t query = NULLTAG, *cntr_objects = NULL;
			
		printf("\n Inside Production Engineering Pre Action of Revision  Start   ***PERevCreValidation***\n");fflush(stdout);
		if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)	PrintErrorStack();
		if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)		PrintErrorStack();
		POM_get_user(&username,&user_tag);

		printf("\n Session user %s\n",username);fflush(stdout);
		printf("\n Production Engineering Manin : PERevCreValidation objTypeTag [%s]\n",type_name);fflush(stdout);
		
		if(strcmp(type_name,"T5_PeDesignRevision")==0)
		{
			if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)==ITK_ok)
			if( AOM_ask_value_string(objTag,"t5_ProjectName",&projcode)==ITK_ok)
			printf("\nProject : %s ProjectList : [%s] Length : %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
			if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
			{
				if(strcmp(projcode,"")==0) //project_list
				{
					printf("\n Production Engineering Manin Project is  NULL \n");fflush(stdout);
				}
				else
				{
					printf("\n Production Engineering Manin TCDCProject from Object in else : %s\n",projcode);fflush(stdout);

					if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();

					if(projobj1 != NULLTAG)
					{
		//				printf("\nTCDCGetting Master Object for Project\n");fflush(stdout);
		//				if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
		//				printf("\nTCDCAfter Master Object for Project\n");fflush(stdout);
						if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok)PrintErrorStack();
						printf("\nPE Part Assigned to Project [%s]\n",projcode);fflush(stdout);
					}
					else
					{
						printf("\nPE Part Project not found [%s]\n",projcode);fflush(stdout);
					}
				}
			}
			else
			{
					printf("\nProjectlist already assigned Project : <%s> ProjectList : <%s>\n",projcode,projcodeList);fflush(stdout);
			}

			if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
			printf("\nDesc_obj1  = [%s]\n", Desc_obj2);fflush(stdout);

			if(POM_attr_id_of_attr("item_revision_id","T5_PeDesignRevision",&attr_id))	PrintErrorStack();

			if(strcmp(Desc_obj2,"NR")==0 )
			{
				printf("\n Inside PE Part NR check...\n");fflush(stdout);
				if(AOM_lock(objTag))PrintErrorStack();
				if(AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
				if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
				if(AOM_save_without_extensions(objTag))PrintErrorStack();
				if(AOM_unlock(objTag))PrintErrorStack();
				if(AOM_refresh(objTag,1))PrintErrorStack();

				printf("\nNR;1 updated\n");fflush(stdout);
				
				//if(RELSTAT_create_release_status("ERC Review",&status_rel))PrintErrorStack();
				//if(RELSTAT_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
			}

			if(AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok) PrintErrorStack();
			
			if(strcmp(Desc,"")!=0)
			{
				desclength = strlen(Desc);
				for(desccnt=0;desccnt<desclength;desccnt++)
				{	
					if(Desc[desccnt]=='\n')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='`')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='~')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='|')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='$')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='#')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='@')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='^')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='!')
						Desc[desccnt] =' ';
					//printf("\n [%c]\n",Desc[desccnt]);fflush(stdout);
				}
				//val=(char **)MEM_alloc(sizeof(char **));
				NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
				strcpy(NewDesc,Desc);

				printf("\nPeRevCreVal : NewDesc[%s]\n",NewDesc);fflush(stdout);

				if(NewDesc)
				{
					AOM_lock(objTag);
					if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok) PrintErrorStack();
					if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
					AOM_unlock(objTag);
					if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
					
					if(AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok) PrintErrorStack();
					printf("\nPeRevCreVal : NewDescription[%s]\n", NewDescription);fflush(stdout);
				}
			}
		}
		printf("\n Inside Production Engineering Pre Action of Revision  End   ***T5_PeDesignRevision***\n");fflush(stdout);
	}
	printf("\n Inside Production Engineering Post Action of Revision  Start   ***T5_PeDesignRevision***\n");fflush(stdout);
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)	PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)		PrintErrorStack();
	POM_get_user(&username,&user_tag);

	printf("\n Inside Production Engineering Manin : PERevCreValidationPost Session user %s\n",username);fflush(stdout);
	printf("\n Production Engineering Manin : PERevCreValidationPost objTypeTag [%s]\n",type_name);fflush(stdout);
	
	if(strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		if(AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\nObj_Revision Post  = [%s]\n", Desc_obj2);fflush(stdout);

		if(strcmp(Desc_obj2,"NR;1")==0)
		{

			if(GRM_list_secondary_objects_only(objTag,NULLTAG,&cnt,&attachments)!=ITK_ok)	PrintErrorStack();
			//if(GRM_list_all_related_objects_only(objTag,&cnt,&attachments)!=ITK_ok)	PrintErrorStack();
			printf("\nAttached secondary_objects1 : %d\n",cnt); fflush(stdout);
		
			for(ij=0;ij<cnt;ij++)
			{
				dataset = attachments[ij];
				if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

				if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")==0)
				{
					if(AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
					printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
					oojname=strtok(ObjectName,"/");
					strcat(oojname,"/");
					strcat(oojname,"NR;1");
					printf("\nName of Revision Master:%s\n",oojname);fflush(stdout);

					if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
					
					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
					if(AOM_save_without_extensions(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();
					if(AOM_refresh(dataset,1))PrintErrorStack();
					break;
				}
			}

			printf("\n Inside PE NR;1 Part Checkout Validation...\n"); fflush(stdout);
			if(RES_is_checked_out(objTag,&checkout)) PrintErrorStack();
			if (checkout==0)
			{
				//IMAN_master_form_rev
				//if(GRM_find_relation_type("IMAN_master_form_rev",&mstfm_reltype)!=ITK_ok) PrintErrorStack();
				printf("\n Inside PE Part Checkout");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,NULLTAG,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
				printf("\nAttached secondary_objects2 : %d\n",cnt);fflush(stdout);
			
				for(ij=0;ij<cnt;ij++)
				{
					dataset = attachments[ij];
					if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
					printf("\n\nDataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

					if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")==0)
					{
						if( AOM_ask_value_string(dataset,"gov_classification",&gov_class))PrintErrorStack();
						if (tc_strcmp(gov_class,"N") != 0)
						{
							AOM_lock(dataset);
							if(AOM_set_value_string(dataset,"gov_classification","Y"))PrintErrorStack();
							if(AOM_save_without_extensions(dataset))PrintErrorStack();
							if(AOM_unlock(dataset))PrintErrorStack();
							if(AOM_refresh(dataset,1))PrintErrorStack();

						}
						if( AOM_ask_value_string(dataset,"gov_classification",&gov_class))PrintErrorStack();
						printf("\nPeAsmRevisionMaster gov_classification :%s\n",gov_class);fflush(stdout);
					}
				}

				if (tc_strcmp(gov_class,"Y") == 0)
				{
					//t5removeAllReleaseStatus(objTag);
					if(RELSTAT_create_release_status("T5_LcsWorking",&status_rel)) PrintErrorStack();
					if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)) PrintErrorStack();

					printf("\n Inside checkout in PERevCreValidation for NR;1....");fflush(stdout);
					if(RES_checkout2(objTag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
				}
				//if(AOM_lock(objTag))PrintErrorStack();
				printf("\nAfter lock\n");fflush(stdout);
			}
			
			if(GRM_list_secondary_objects_only(objTag,NULLTAG,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
			printf("\nAttached secondary_objects3 : %d\n",cnt);fflush(stdout);
		
			for(ij=0;ij<cnt;ij++)
			{
				dataset = attachments[ij];
				if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

				if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")==0)
				{
					if(AOM_set_value_string(dataset,"gov_classification","N"))PrintErrorStack();
					if(AOM_save_without_extensions(dataset))PrintErrorStack();
					if(AOM_unlock(dataset))PrintErrorStack();

					if( AOM_ask_value_string(dataset,"gov_classification",&gov_class))PrintErrorStack();
					printf("\n\n gov_class gov_class lastttt:%s\n",gov_class);fflush(stdout);

				}
			}
		}
	}
	printf("\n Inside Production Engineering Post Action of Revision  End   ***T5_PeDesignRevision***\n");fflush(stdout);
	return error_code;
}

extern DLLAPI int PERevCheckOutValidation(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int n_entry = 1;
	int CtrCount = 0;
	int n_parents = 0;

	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;

	char*	type_name=NULL;
	char	*PEPrtNum		= NULL;
	char	*PartRevSeq		= NULL;
	char	*PartRevSeqFLG		= NULL;
	char	*PEDesc			= NULL;
	char	*PEPrtRelStat	= NULL;
	char	*Userinfo3		= NULL;
	char	*DCRNo			= NULL;
	char *qry_entry[1]  = {"SYSCD"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t DCRValiTag = NULLTAG;
	tag_t *CtrObjTag = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t   GroupMem = NULLTAG;

	char *group_name    = NULL;
	char *Role_name    = NULL;
	char *PEDesigngrp    = NULL;
	char *Grp_name    = NULL;
	char *roleName    = NULL;
	tag_t Roletag	= NULLTAG;
	tag_t grptag	= NULLTAG;
	//char roleName[SA_name_size_c+1];
	char *qry_entry1[1]  = {"SYSCD"};
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t PEValiTag = NULLTAG;
	int n_entry1 = 1;
	int CtrCount1 = 0;
	tag_t CurrentRoleTag = NULLTAG;

	logical	checkout		= 0;

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	//POM_get_user(&username,&user_tag);
	
	//printf("\n Inside Production Engineering Manin : PECheckInValidation Session user %s\n",username);fflush(stdout);
	printf("\n Production Engineering Manin : PERevCheckOutValidation PreAction objTypeTag [%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		if(AOM_ask_value_string(objTag,"current_id",&PEPrtNum)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"object_string",&PartRevSeq)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"item_revision_id",&PartRevSeqFLG)!=ITK_ok) PrintErrorStack();
		if(AOM_UIF_ask_value(objTag,"release_status_list",&PEPrtRelStat)!=ITK_ok) PrintErrorStack();
		printf("\nPartRevSeq : %s	ReleaseStatus : %s",PartRevSeq,PEPrtRelStat);

		if(tc_strstr(PEPrtRelStat,"ERC Released")!=NULL)
		{
			printf("\nPE Part %s Already ERC Released, Please Revise PE Part and then check out\n",PEPrtNum);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"PE Part is ERC Released, Please Revise this PE Part and then check out");
			return ITK_err;
		}
		/*vlidation 1 Only PE Group can check out*/
	
		if(QRY_find2("Control Objects...", &PEValiTag));
		if (PEValiTag)
		{
			printf("\n PERevCheckOutValidation-->L2:Found Query PEValiTag \n");fflush(stdout);
		}
		else
		{
			printf("\n PERevCheckOutValidation-->L3:Not Found Query PEValiTag \n");fflush(stdout);
		}
		qry_values1[0] = "PECheckValidation";
		if(QRY_execute(PEValiTag, n_entry1, qry_entry1, qry_values1, &CtrCount1, &CtrObjTag));
		printf(" \n PERevCheckOutValidation-->L4:CtrCount1 :%d:", CtrCount1); fflush(stdout);
		if(CtrCount1 > 0)
		{
			if (AOM_ask_value_string(CtrObjTag[0],"t5_Userinfo3",&Userinfo3)!=ITK_ok)   PrintErrorStack();
			printf("\n PERevCheckOutValidation-->L5:Userinfo3 is : [%s]\n", Userinfo3);fflush(stdout);

			if(tc_strstr(Userinfo3,"OFF") != NULL)
			{
				printf("\nPE Part can't be check out");
				EMH_store_error_s1(EMH_severity_error,ITK_err,"PE Part Check out is not currently Not possible,Please contact to PLM team.");
				return ITK_err;
				
			}
			
		}
		SA_ask_current_groupmember(&GroupMem);
		if(GroupMem !=NULLTAG)
		{
			if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok);
			printf("\ngroup_name session is  : %s\n",group_name);fflush(stdout);
			/* if (SA_ask_groupmember_role(GroupMem,&Roletag) !=ITK_ok);
			if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok);
			if((Roletag !=NULLTAG) && (grptag !=NULLTAG))
			{
				if (AOM_ask_value_string(Roletag,"object_name",&Role_name)!=ITK_ok);
				if (AOM_ask_value_string(grptag,"object_name",&Grp_name)!=ITK_ok);
				printf("\nRole_name session is pare  : %s %s\n",Role_name,Grp_name);
				printf("\nGrp_name is   :  %s :\n",Grp_name);
			} */
			int Byapss =0;
			int NRREVISION =0;
			printf("\nCurrent Revision sequence is : %s \n",PartRevSeqFLG);
			if(strcmp(PartRevSeqFLG,"NR;1")==0)
			{
				NRREVISION=1;
			}
			
			if(tc_strstr(group_name,"PLM_Support_Group")!=NULL)
			{
				Byapss =1;
				printf("\nHae Budddy You are from PLM Group Relaxed and Bypassed Allowed to you \n");fflush(stdout);
			}
			if ((Byapss ==0) && (NRREVISION ==0))
			{
				
				if(tc_strstr(group_name,"PE_CVBU")!=NULL)
				{
					printf("\n user is in PE_CVBU group\n");
					if(AOM_UIF_ask_value(objTag,"t5_PEDesignGrp",&PEDesigngrp)!=ITK_ok) PrintErrorStack();
					printf("\nPE Part design group is :: %s\n",PEDesigngrp);fflush(stdout);
					if(SA_ask_current_role(&CurrentRoleTag));
					if(SA_ask_role_name2(CurrentRoleTag,&roleName));
					printf("\n\n  Checkout_Pre_action---roleName : %s\n",roleName); fflush(stdout);
				
					if (tc_strcmp(PEDesigngrp,"PECAE")==0)
					{
						if (tc_strcmp(PEDesigngrp,"PECAE")==0 && tc_strcmp(roleName,"PE_DFM")==0)
						{
							printf("\n user is allow to check out as PECAE and PE_DFM is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is PECAE and PE_DFM is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to check out PECAE design group type Part..\nKindly Change Your Role to PE_DFM...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"SMTD")==0)
					{
						if (tc_strcmp(PEDesigngrp,"SMTD")==0 && tc_strcmp(roleName,"PE_DIE")==0)
						{
							printf("\n user is allow to check out as SMTD and PE_DIE is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is  SMTD and PE_DIE is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to check out SMTD design group type Part..\nKindly Change Your Role to PE_DIE...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"CJFD")==0)
					{
						if (tc_strcmp(PEDesigngrp,"CJFD")==0 && tc_strcmp(roleName,"PE_Figs")==0)
						{
							printf("\n user is allow to check out as CJFD. and PE_Figs is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is  CJFD and PE_Figs is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to check out CJFD design group type Part..\nKindly Change Your Role to PE_Figs...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"SMTDF")==0)
					{
						if (tc_strcmp(PEDesigngrp,"SMTDF")==0 && tc_strcmp(roleName,"PE_Fixture")==0)
						{
							printf("\n user is allow to check out as SMTDF and PE_Fixture is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user user Group and Role is  SMTDF and PE_Fixture is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to check out SMTDF design group type Part..\nKindly Change Your Role to PE_Fixture...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"CAM")==0)
					{
						if (tc_strcmp(PEDesigngrp,"CAM")==0 && tc_strcmp(roleName,"PE_CAM")==0)
						{
							printf("\n user is allow to check out as CAM and PE_CAM is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is  CAM and PE_CAM is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Check Out CAM design group type Part..\nKindly Change Your Role to PE_CAM...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"MPS")==0)
					{
						if (tc_strcmp(PEDesigngrp,"MPS")==0 && tc_strcmp(roleName,"PE_MPS")==0)
						{
							printf("\n user is allow to check out as MPS and PE_MPS is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is  MPS and PE_MPS is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Check out MPS design group type Part..\nKindly Change Your Role to PE_MPS...");
							return ITK_err;
						}
					}
					if (tc_strcmp(PEDesigngrp,"CTED")==0)
					{
						if (tc_strcmp(PEDesigngrp,"CTED")==0 && tc_strcmp(roleName,"PE_CTED")==0)
						{
							printf("\n user is allow to check out as CTED and PE_CTED is matched\n");
						}
						else
						{
							printf("\n user is not allowed to check out as user Group and Role is CTED and PE_CTED is matched Lets STOP !!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Check Out CTED design group type Part..\nKindly Change Your Role to PE_CTED...");
							return ITK_err;
						}
					}
					tag_t	status_rel		= NULLTAG;
					logical	retain			= 0;
					t5removeAllReleaseStatus(objTag);
					if(RELSTAT_create_release_status("T5_LcsWorking",&status_rel)) PrintErrorStack();
					if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)) PrintErrorStack();
					if(AOM_refresh(objTag,1));
					if(AOM_save_without_extensions(objTag));
					if(AOM_unlock(objTag));
					
				}
				else
				{
					printf("\n user is not in PE_CVBU group Lets STOP !!");
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Only PE user can check out PE Part..\n If You are From PE Group Then Kindly Change Your Group to PE_CVBU...");
					return ITK_err;
				}
				
			}
			
		}
	}
	
	if(QRY_find2("Control Objects...", &DCRValiTag));
	if (DCRValiTag)
	{
		printf("\n PERevCheckOutValidation-->L2:Found Query DCRValiTag \n");fflush(stdout);
	}
	else
	{
		printf("\n PERevCheckOutValidation-->L3:Not Found Query DCRValiTag \n");fflush(stdout);
	}
	qry_values[0] = "DCRVali";
	if(QRY_execute(DCRValiTag, n_entry, qry_entry, qry_values, &CtrCount, &CtrObjTag));
	printf(" \n PERevCheckOutValidation-->L4:CtrCount :%d:", CtrCount); fflush(stdout);
	if(CtrCount > 0)
	{
		if (AOM_ask_value_string(CtrObjTag[0],"t5_Userinfo3",&Userinfo3)!=ITK_ok)   PrintErrorStack();
		printf("\n PERevCheckOutValidation-->L5:Userinfo3 is : [%s]\n", Userinfo3);fflush(stdout);

		if(tc_strstr(Userinfo3,"ON") != NULL)
		{
			printf("\n Inside DCR Checkout Validation Loop");

			if(strcmp(type_name,"T5_GenDcrChngRepRevision")==0)
			{
				if(AOM_ask_value_string(objTag,"item_id",&DCRNo)!=ITK_ok) PrintErrorStack();
				printf("\nDCR No : [%s]	not allowed to check out",DCRNo);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"DCR Revision is not allowed to Check-Out, Please contact to BOM Process team.");
				return ITK_err;
			}
		}
		if(tc_strstr(Userinfo3,"P002") != NULL)
		{
			printf("\n Inside DML Checkout Validation Loop");

			if(strcmp(type_name,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(objTag,"item_id",&DCRNo)!=ITK_ok) PrintErrorStack();
				printf("\nDML No : [%s]	not allowed to check out",DCRNo);
				//EMH_store_error_s1(EMH_severity_error,ITK_err,"DML Revision is not allowed to Check-Out, as Selected DML Revision is in Workflow, Please contact to BOM Process team.");
				EMH_store_error_s1(EMH_severity_error,ITK_err,"This DML is Not Allowed to Check-Out. \nSolution:\nPlease try with option: Go to 'Tools > Product Structure Classes > DML Property Updation' to update DML \nOr please raise ticket to DML support team to get it aborted.");
				return ITK_err;
			}
		}
		if(tc_strstr(Userinfo3,"P001") != NULL)
		{
			printf("\n Inside DML Checkout Validation Loop");

			if(strcmp(type_name,"ChangeRequestRevision")==0)
			{
				printf("\nObject Being CHeck out is of type ERC DML");
				
				if(EPM_ask_active_job_for_target(objTag,&n_parents,&parents));
				printf("\n DML has active Jobs--> %d ",n_parents); fflush(stdout);
				
				if(n_parents > 0)
				{
					if(AOM_ask_value_string(objTag,"item_id",&DCRNo)!=ITK_ok) PrintErrorStack();
					printf("\nDML No : [%s]	not allowed to check out",DCRNo);
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"DML Revision is not allowed to Check-Out, as Selected DML Revision is in Workflow, Please contact to BOM Process team.");
					EMH_store_error_s1(EMH_severity_error,ITK_err,"This DML is in workflow so not allowed to update properties. \nSolution:\nPlease try with option: Go to 'Tools > Product Structure Classes > DML Property Updation' to update DML \nOr \nPlease abort it from workflow and then update. To abort DML use option Action – Abort \nOr please raise ticket to DML support team to get it aborted.");
					return ITK_err;
				}
			}
		}
	} 
	return error_code;
}
extern DLLAPI int PECheckInValidation(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;

	char*	type_name=NULL;
	
	char	*PEPrtNum		= NULL;
	char	*PartRevSeq		= NULL;
	char	*PartDrwInd		= NULL;
	char	*PEDesigngrp		= NULL;
	char	*PEWoNo		= NULL;
	
	tag_t	status_rel		= NULLTAG;
	tag_t	rev				= NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;
	tag_t SpecRel_tag = NULLTAG;
	tag_t SecObjDSTag = NULLTAG;
	tag_t SpecTypeTag = NULLTAG;
	tag_t qryTag = NULLTAG;
	tag_t GenRelation_type = NULLTAG;
	tag_t CreoGenRev = NULLTAG;
	tag_t Itemtag = NULLTAG;
	tag_t latestGenRev = NULLTAG;
	int SpecCount;
	int SpecCount1;
	
	tag_t *secondary_objectsGen = NULLTAG;
	//char Spectype_name[TCTYPE_name_size_c+1];
	char*	Spectype_name=NULL;
	int Drawing = 0;
	int GDT = 0;
	int ii = 0;
	
	
	logical	retain			= 0;
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	//POM_get_user(&username,&user_tag);

	//printf("\n Inside Production Engineering Manin : PECheckInValidation Session user %s\n",username);fflush(stdout);
	printf("\n Production Engineering Manin : PECheckInValidation objTypeTag [%s]\n",type_name); fflush(stdout);

	if(strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		/*Validation No-1 **Archiving of PE data is in progress. So check-in is not allowed now. Please try again later */
		printf("\n Inside Archiving of PE data validation ");fflush(stdout);

		int n_count =	3;
		char *SYNCqry_entry[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
		char **SYNCqry_values = (char **) MEM_alloc(50 * sizeof(char *));
		int SyncDmlCount=0;
		tag_t  SYNCCntrl_obj_Qtag	=	NULLTAG;
		tag_t  *QRY_SYNCcntrlobj = NULLTAG;
		
		//Control obj contains DCR and ERC cut off date (creation date) in info2 and info3 respectively

		if(QRY_find2("Control Objects...", &SYNCCntrl_obj_Qtag));
		if(SYNCCntrl_obj_Qtag!=NULLTAG)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			SYNCqry_values[0] = "PECHECKIN";
			SYNCqry_values[1] = "STOP";
			SYNCqry_values[2] = "0";

			ITKCALL(QRY_execute(SYNCCntrl_obj_Qtag, n_count, SYNCqry_entry, SYNCqry_values, &SyncDmlCount, &QRY_SYNCcntrlobj));
			printf("\nNo. of control object found : %d",SyncDmlCount);fflush(stdout);

			if(SyncDmlCount>0)
			{
				printf("\n So It is indicating to STOP check in PE PART as Stop Control object found...! lets Stop ..!");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error, ITK_errStore,"Archiving of PE data is in progress.\nSo check-in is not allowed now. Please try again later Otherwise Connect with PLM Team");
				return ITK_errStore;
			}
			/* else
			{
				printf("\n\nSynchCtrlObj not found\n\n");fflush(stdout);
				*SynchFlag = 1;
				return ifail;
			} */
		}
		else
		{
				printf("\n\n Control object query not found\n\n");fflush(stdout);
			/* 	*SynchFlag = 1;
				return ifail; */
		}
		
		
		if(AOM_ask_value_string(objTag,"current_id",&PEPrtNum)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"object_string",&PartRevSeq)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"t5_DrawingInd",&PartDrwInd)!=ITK_ok) PrintErrorStack();
		if(AOM_UIF_ask_value(objTag,"t5_PEDesignGrp",&PEDesigngrp)!=ITK_ok) PrintErrorStack();
		if(AOM_UIF_ask_value(objTag,"t5_WONo",&PEWoNo)!=ITK_ok) PrintErrorStack();
		printf("\nPE Part design group is :: %s\n",PEDesigngrp);fflush(stdout);

		printf("\nPartRevSeq : %s	Drawing Id : %s PEWoNo :%s ",PartRevSeq,PartDrwInd,PEWoNo); fflush(stdout);
		/*Second Validation Start For Drawing Indicator */
		
		if(1)
		{
			tag_t *SpecDoc_tags = NULLTAG;

			if(GRM_find_relation_type("IMAN_specification", &SpecRel_tag));

			if(GRM_list_secondary_objects_only(objTag,SpecRel_tag,&SpecCount,&SpecDoc_tags))PrintErrorStack();
			printf("\n SpecCount--Attached Datasets2: %d\n",SpecCount);fflush(stdout);
			Drawing = 0;
			for (ii=0;ii<SpecCount;ii++ )
			{
				SecObjDSTag = SpecDoc_tags[ii];

				if(TCTYPE_ask_object_type(SecObjDSTag,&SpecTypeTag));
				if(TCTYPE_ask_name2(SpecTypeTag,&Spectype_name));
				printf("\n     CheckIN_Pre_action--Spectype_name :: %s\n", Spectype_name); fflush(stdout);

				if(tc_strcmp(Spectype_name,"CMI2Drawing")==0) 
				{
					printf("\n CMI2Drawing Dataset found.");fflush(stdout);

					Drawing =1;
					break;
				}
			}
			
			if((strcmp(PartDrwInd,"D")==0) && (Drawing == 0))
			{
				printf("\n So It is indicating to STOP check as  PE PART's darwing indicator is Y and its drawing is not available...! lets Stop ..!");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error, ITK_errStore,"The part which you are trying to Check-IN doesn't have CAT Drwaing file and Its Drawing Indicator is D.\n Please Attach file to PE Part Else update Drawing Indicator to N If You don't want to add the CAT drawing file");
				return ITK_errStore;
			}
			if((strcmp(PartDrwInd,"N")==0) && (Drawing == 1))
			{
				printf("\n So It is indicating to STOP check as  PE PART's darwing indicator is N and its drawing is  available...! lets Stop ..!");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error, ITK_errStore,"Drawing Document Can not Be Added to Part If It Has Drawing Indicator As N.\n For Drawing Indicator N There Should Not Be Drawing Attached To Part.");
				return ITK_errStore;
			}
		}
		
		
		/*Third Validation If part is GDT type then minimum two PDF files should be present*/
		if (strncasecmp(PEPrtNum, "GDT", 3) == 0) 
		{
			tag_t *SpecDoc_tags = NULLTAG;
			ERROR_CALL(GRM_find_relation_type("IMAN_Rendering", &SpecRel_tag));
			if(GRM_list_secondary_objects_only(objTag,SpecRel_tag,&SpecCount1,&SpecDoc_tags))PrintErrorStack();
			printf("\n SpecCount1--Attached Datasets2: %d\n",SpecCount1);fflush(stdout);
			GDT = 0;
			for (ii=0;ii<SpecCount1;ii++ )
			{
				SecObjDSTag = SpecDoc_tags[ii];

				if(TCTYPE_ask_object_type(SecObjDSTag,&SpecTypeTag));
				if(TCTYPE_ask_name2(SpecTypeTag,&Spectype_name));
				printf("\n CheckIN_Pre_action--Spectype_name :: %s\n", Spectype_name); fflush(stdout);

				if(tc_strcmp(Spectype_name,"PDF")==0) 
				{
					printf("\n PDF Dataset found.");fflush(stdout);

					GDT++;
					
				}
			}
			if(GDT < 2)
			{
				printf("\n So This is a GDN Part so It must have atleast two PDF files to be attached .\n Please Attach PDF file to PE Part and try to Check-IN...! lets Stop ..!");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error, ITK_errStore,"This is a GDN Part ,so It must have atleast two PDF files to be attached .\n Please Attach PDF file to PE Part and try to Check-IN");
				return ITK_errStore;
			}
			
		}
		if (tc_strlen(PEDesigngrp) >0)
		{
			printf("\nPE Part design group length is above 1 and value is  :: %s\n",PEDesigngrp);fflush(stdout);
		}
		else
		{
			printf("\n PE design group for this part is NULL Lets STOP !!");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"PE design group for this part is NULL value..\n kindly Update the value...");
			return ITK_err;
		}
		
		
		//if (tc_strcmp(PEWoNo,"NA")==0 && tc_strcmp(PEWoNo,"")!=0)
		//if (tc_strcmp(PEWoNo, "NA") == 0 && tc_strcmp(PEWoNo, "") != 0)
		
		if( (tc_strcmp(PEWoNo,"") == 0) || PEWoNo == NULL ){
			printf("\n1Current/Mod WO No is NULL or NA value..\n kindly Update the real value...and value is  :: %s\n",PEWoNo);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Current/Mod WO No is NULL or NA value..\n kindly Update the real value...");
			return ITK_err;
		}
		if (tc_strcmp(PEWoNo, "NA") == 0 && (tc_strstr(PEPrtNum,"CAE") == NULL || tc_strstr(PEPrtNum,"FCR") == NULL || tc_strstr(PEPrtNum,"MP") == NULL)){
			printf("\n2Current/Mod WO No is NULL or NA value..\n kindly Update the real value...and value is  :: %s\n",PEWoNo);fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Current/Mod WO No is NULL or NA value..\n kindly Update the real value...");
			return ITK_err;
		}
		/* else
		{
			printf("\n PE design group for this part is NULL Lets STOP !!");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Current/Mod WO No is NULL or NA value..\n kindly Update the real value...");
			return ITK_err;
		} */

		t5removeAllReleaseStatus(objTag);
		if(RELSTAT_create_release_status("T5_LcsReview",&status_rel)) PrintErrorStack();
		if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)) PrintErrorStack();
		if(AOM_refresh(objTag,1));
		if(AOM_save_without_extensions(objTag));
		if(AOM_unlock(objTag));
	}

	return error_code;
}
extern  DLLAPI int PE_Revise_properties_Pre(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;

	char*		type_name=NULL;
	char*		Userinfo2=NULL;

	char		*PartRevSeq		= NULL;
	
	logical		checkout		= 0;
	char *qry_entry1[1]  = {"SYSCD"};
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t PEValiTag = NULLTAG;
	tag_t *CtrObjTag = NULLTAG;
	tag_t *parents = NULLTAG;
	int n_entry1 = 1;
	int CtrCount1 = 0;
	tag_t DCRValiTag = NULLTAG;

	tag_t   GroupMem = NULLTAG;
	char *group_name    = NULL;
	char *Role_name    = NULL;
	char *PEDesigngrp    = NULL;
	char *Grp_name    = NULL;
	char *roleName    = NULL;
	tag_t Roletag	= NULLTAG;
	tag_t grptag	= NULLTAG;
	//char roleName[SA_name_size_c+1];
	tag_t CurrentRoleTag = NULLTAG;



	printf("\n Inside PE_Revise_properties_Pre Function....\n");fflush(stdout);
	
	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	if(AOM_ask_value_string(objTag,"object_string",&PartRevSeq)!=ITK_ok) PrintErrorStack();

	if(RES_is_checked_out(objTag,&checkout)) PrintErrorStack();
	
	if(checkout>=1)
	{
		printf("\nPE Part %s Already Checked Out..!!!\n",PartRevSeq);fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_err,"PE Part Already Checked Out..!!!");
		return ITK_err;
	}
	//
	if(QRY_find2("Control Objects...", &PEValiTag));
	if (PEValiTag)
	{
		printf("\n PE Revise Validation-->L2:Found Query PEValiTag \n");fflush(stdout);
	}
	else
	{
		printf("\n PE Revise Validation-->L3:Not Found Query PEValiTag \n");fflush(stdout);
	}
	qry_values1[0] = "PECheckValidation";
	if(QRY_execute(PEValiTag, n_entry1, qry_entry1, qry_values1, &CtrCount1, &CtrObjTag));
	printf(" \n PE Revise Validation-->L4:CtrCount1 :%d:", CtrCount1); fflush(stdout);
	if(CtrCount1 > 0)
	{
		if (AOM_ask_value_string(CtrObjTag[0],"t5_Userinfo2",&Userinfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n PERevCheckOutValidation-->L5:Userinfo2 is : [%s]\n", Userinfo2);fflush(stdout);

		if(tc_strstr(Userinfo2,"OFF") != NULL)
		{
			printf("\nPE Part can't be Revise as off control object found");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"PE Part Revise is currently Not possible,Please contact to PLM team.");
			return ITK_err;
			
		}
		
	}

	SA_ask_current_groupmember(&GroupMem);
	if(GroupMem !=NULLTAG)
	{
		if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok);
		printf("\ngroup_name session is  : %s\n",group_name);fflush(stdout);
		int Byapss =0;

		if(tc_strstr(group_name,"PLM_Support_Group")!=NULL)
		{
			
			Byapss =1;
			printf("\nHae Budddy You are from PLM Group Relaxed and Bypassed Allowed to you \n");fflush(stdout);
		}
		if (Byapss ==0)
		{
			
			if(tc_strstr(group_name,"PE_CVBU")!=NULL)
			{
				printf("\n user is in PE_CVBU group\n");
				if(AOM_UIF_ask_value(objTag,"t5_PEDesignGrp",&PEDesigngrp)!=ITK_ok) PrintErrorStack();
				printf("\nPE Part design group is :: %s\n",PEDesigngrp);fflush(stdout);
				ERROR_CALL(SA_ask_current_role(&CurrentRoleTag));
				ERROR_CALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
				printf("\n\n  Checkout_Pre_action---roleName : %s\n",roleName); fflush(stdout);
			
				if (tc_strcmp(PEDesigngrp,"PECAE")==0)
				{
					if (tc_strcmp(PEDesigngrp,"PECAE")==0 && tc_strcmp(roleName,"PE_DFM")==0)
					{
						printf("\n user Group and Role PECAE and PE_DFM is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role PECAE and PE_DFM is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise PECAE design group type Part..\nKindly Change Your Role to PE_DFM...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"SMTD")==0)
				{
					if (tc_strcmp(PEDesigngrp,"SMTD")==0 && tc_strcmp(roleName,"PE_DIE")==0)
					{
						printf("\n user Group and Role SMTD and PE_DIE is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role SMTD and PE_DIE is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise SMTD design group type Part..\nKindly Change Your Role to PE_DIE...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"CJFD")==0)
				{
					if (tc_strcmp(PEDesigngrp,"CJFD")==0 && tc_strcmp(roleName,"PE_Figs")==0)
					{
						printf("\n user Group and Role CJFD. and PE_Figs is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role CJFD and PE_Figs is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise CJFD design group type Part..\nKindly Change Your Role to PE_Figs...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"SMTDF")==0)
				{
					if (tc_strcmp(PEDesigngrp,"SMTDF")==0 && tc_strcmp(roleName,"PE_Fixture")==0)
					{
						printf("\n user Group and Role SMTDF and PE_Fixture is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role SMTDF and PE_Fixture is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise SMTDF design group type Part..\nKindly Change Your Role to PE_Fixture...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"CAM")==0)
				{
					if (tc_strcmp(PEDesigngrp,"CAM")==0 && tc_strcmp(roleName,"PE_CAM")==0)
					{
						printf("\n user Group and Role CAM and PE_CAM is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role CAM and PE_CAM is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise CAM design group type Part..\nKindly Change Your Role to PE_CAM...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"MPS")==0)
				{
					if (tc_strcmp(PEDesigngrp,"MPS")==0 && tc_strcmp(roleName,"PE_MPS")==0)
					{
						printf("\n user Group and Role MPS and PE_MPS is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role MPS and PE_MPS is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise MPS design group type Part..\nKindly Change Your Role to PE_MPS...");
						return ITK_err;
					}
				}
				if (tc_strcmp(PEDesigngrp,"CTED")==0)
				{
					if (tc_strcmp(PEDesigngrp,"CTED")==0 && tc_strcmp(roleName,"PE_CTED")==0)
					{
						printf("\n user Group and Role CTED and PE_CTED is matched\n");
					}
					else
					{
						printf("\n user is not allowed to Revise as user Group and Role CTED and PE_CTED is matched Lets STOP !!");
						EMH_store_error_s1(EMH_severity_error,ITK_err,"You dont have access to Revise CTED design group type Part..\nKindly Change Your Role to PE_CTED...");
						return ITK_err;
					}
				}
				
				
			}
			else
			{
				printf("\n user is not in PE_CVBU group Lets STOP !!");
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Only PE user can Revise PE Part..\n If You are From PE Group Then Kindly Change Your Group to PE_CVBU...");
				return ITK_err;
			}
			
		}
		
	}
	

	return error_code;
}

extern  DLLAPI int PE_Revise_properties_Post(METHOD_message_t *m, va_list args)
{
	char   *ReleaseStatus=NULL;
	char*   type_name=NULL;
	tag_t  source_rev_Type_Tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	int	   ifail	=0;
	int	   ii=0;
	char   *text	=NULL;
	int	   status_count=0;
	char   *Item_string=NULL;
	logical			retain							= 0;
	int status;	
	int Desc_seq=0;
	int Desc_seq9=0;
	int Desc_seq1=0;
	int Desc_seq2=0;
	char			*Desc_obj	= NULL;
	char			*Desc_obj9	= NULL;
	char			*Desc_obj2	= NULL;
	//char			*Desc_seq3	= NULL;
	char   Desc_seq3[10];
	tag_t			objTypeTag									= NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t master=NULLTAG;
	logical      bypass                  = FALSE;
	tag_t	source_rev				 =va_arg (args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	char	*ReplacedRevision=NULL;
	char		   *ObjectClassType		= NULL;
	char		   *ObjectName		= NULL;
	tag_t			dataset										= NULLTAG;
	tag_t			*attachments								= NULLTAG;
	int revlength= 0;
	tag_t *revisions;
	int revision_count=0;
	tag_t attr_id ;
	tag_t form_attr_id ;
	tag_t			relation_type								= NULLTAG;
	char*			relation_name=NULL;

	const char	   reason;
	const char     change_id;
	const char     dir_name;
	const char	   reason1;
	const char     change_id1;
	const char     dir_name1;
	char* revi=NULL;
	char* oojname=NULL;
	 char   revi1[20];
	int				cnt=0;
	int				i=0;
	logical			checkout									= 0;

	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		= 0; 
	int			Rel_cnt					= 0; 
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ; 
	tag_t		tReleaseStatusList		= NULLTAG; 
	int			n_values				= 0; 
	int			cunt1					= 0; 
	tag_t*		attr_tags				= NULLTAG; 
	logical		*is_it_null				= NULL; 
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	/******Deepti End ariable initialisation***********/

	printf("\n Inside PE_Revise_properties_Post Function....\n");fflush(stdout);
	
	if (TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	
	if(ITEM_ask_item_of_rev(source_rev,&master) );

	if(ITEM_ask_latest_rev(master,&rev));

	if(ITEM_list_all_revs(master, &revision_count, &revisions));
	//MEM_free (revisions);
	printf("\nNumber of revision : %d\n",revision_count); fflush(stdout);

	if(WSOM_ask_release_status_list(revisions[revision_count-2],&status_count,&status_list)) PrintErrorStack();

	printf("\nNumber of statuses: %d \n",  status_count);fflush(stdout);
	for (ii = 0; ii < status_count; ii++)
	{
		AOM_ask_name(status_list[ii], &ReleaseStatus);
		printf("\nReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
	}

	if (AOM_ask_value_string(revisions[revision_count-2],"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
	printf("\nDesc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
	
	if (AOM_ask_value_int(revisions[revision_count-2],"sequence_id",&Desc_seq2)!=ITK_ok)   PrintErrorStack();
	printf("\nDesc_seq2  = [%d]\n", Desc_seq2);fflush(stdout);

	if((strcmp(ReleaseStatus,"ERC Review")==0)  || (strcmp(ReleaseStatus,"T5_LcsReview")==0))
	{
		if(AOM_ask_value_string(rev,"item_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
		printf("\n type_name = [%s]\n", type_name);fflush(stdout);
		printf("\n revision  = [%s]\n", Desc_obj);fflush(stdout);
		
		if (AOM_ask_value_int(rev,"sequence_id",&Desc_seq)!=ITK_ok)   PrintErrorStack();
		printf("\n sequence  = [%d]\n", Desc_seq);fflush(stdout);

		Desc_seq1 = Desc_seq2 + 1;
		printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

		printf("\nValue of Desc_obj : %s\n",Desc_obj2);fflush(stdout);
		revi=strtok(Desc_obj2,";");
		printf("\nValue of revi : %s\n",revi);fflush(stdout);
		strcat(revi,";");
		printf("\nValue of revi : %s\n",revi);fflush(stdout);

		sprintf(revi1, "%d", Desc_seq1);
		strcat(revi,revi1);
		printf("\nValue of revi : %s\n",revi);fflush(stdout);

		if(POM_set_attr_string(1, &rev, attr_id, revi)) PrintErrorStack();

		printf("\nUpdating start2\n");fflush(stdout);
		if(AOM_lock(rev));
		if(AOM_set_value_int(rev,"sequence_id",Desc_seq1))PrintErrorStack();
		if(AOM_save_without_extensions(rev))PrintErrorStack();
		if(AOM_unlock(rev))PrintErrorStack();
		printf("\nUpdating end2\n");fflush(stdout);

		t5removeAllReleaseStatus(rev);
		if(RELSTAT_create_release_status("T5_LcsWorking",&status_rel)) PrintErrorStack();
		if(RELSTAT_add_release_status(status_rel,1,&rev,retain)) PrintErrorStack();

		if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments))PrintErrorStack();
		printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
			
		if(RES_checkout2(rev,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
			
		for(i=0;i<cnt;i++)
		{
			dataset = attachments[i];
			
			if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

			if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")==0)
			{
				if(AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
				oojname=strtok(ObjectName,"/");
				strcat(oojname,"/");
				strcat(oojname,revi);
				printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
				
				if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
				
				if(AOM_lock(dataset));
				if(POM_set_attr_string(1,&dataset,form_attr_id,oojname)) PrintErrorStack();
				if(AOM_save_without_extensions(dataset))PrintErrorStack();
				if(AOM_unlock(dataset))PrintErrorStack();
			}
			
			if (strcmp(ObjectClassType,"T5_PeDesignRevision")!=0)
			{
				if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")!=0)
				{
					printf("\n\n Dataset ObjectClassType1 :%s\n",ObjectClassType);fflush(stdout);
					if(RES_is_checked_out(dataset,&checkout))PrintErrorStack();
					printf("\nValue of checkout : %d\n",checkout);fflush(stdout);
		
					if (checkout==0)
					{
						tag_t* relation_list = NULLTAG;
						int relcount = 0;
						tag_t relation_type1 = NULLTAG;
						if(GRM_find_relation_type("IMAN_reference",&relation_type1))PrintErrorStack();
						if(GRM_list_relations(rev,dataset,relation_type1,NULLTAG,&relcount,&relation_list))PrintErrorStack();
						printf("\nIMAN_references count : %d",relcount);
						printf("\n\ngoing to checkout :%s\n",ObjectClassType);fflush(stdout);
						if(relcount <= 0 )
						{
							if(RES_checkout2(dataset,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
							printf("\n %d DataSet Checked Out \n",dataset);
						}
						else
						{
							printf("\nSkipping IMAN_reference relation checkout");
						}
					}
				}
			}
		}
	}

	//For Revising PE Part Released Revision.

	if((strcmp(ReleaseStatus,"ERC Released")==0)  || (strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) )
	{
		if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments)) PrintErrorStack();
		printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
			dataset = attachments[i];
			
			if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

			if (strcmp(ObjectClassType,"T5_PeDesignRevisionMaster")==0)
			{
				if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
				printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
				oojname=strtok(ObjectName,"/");
				strcat(oojname,"/");
				printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
				break;
			}
		}

		revi=strtok(Desc_obj2,";");
		printf("\nValue of revi in revision : %s\n",revi);fflush(stdout);
		if(POM_attr_id_of_attr("item_revision_id", "T5_PeDesignRevision", &attr_id))PrintErrorStack();
		if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
		
		
		if(AOM_lock(rev));
		
		if (strcmp(revi,"NR")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"A;1")) PrintErrorStack(); 
			strcat(oojname,"A;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"A")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"B;1")) PrintErrorStack(); 
			strcat(oojname,"B;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"B")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"C;1")) PrintErrorStack(); 
			strcat(oojname,"C;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"C")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"D;1")) PrintErrorStack(); 
			strcat(oojname,"D;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"D")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"E;1")) PrintErrorStack(); 
			strcat(oojname,"E;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"E")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"F;1")) PrintErrorStack(); 
			strcat(oojname,"F;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"F")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"G;1")) PrintErrorStack(); 
			strcat(oojname,"G;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"G")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"H;1")) PrintErrorStack(); 
			strcat(oojname,"H;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"H")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"I;1")) PrintErrorStack(); 
			strcat(oojname,"I;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"I")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"J;1")) PrintErrorStack(); 
			strcat(oojname,"J;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"J")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"K;1")) PrintErrorStack(); 
			strcat(oojname,"K;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"K")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"L;1")) PrintErrorStack(); 
			strcat(oojname,"L;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"L")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"M;1")) PrintErrorStack(); 
			strcat(oojname,"M;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"M")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"N;1")) PrintErrorStack(); 
			strcat(oojname,"N;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"N")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"O;1")) PrintErrorStack(); 
			strcat(oojname,"O;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"O")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"P;1")) PrintErrorStack(); 
			strcat(oojname,"P;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"P")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Q;1")) PrintErrorStack(); 
			strcat(oojname,"Q;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Q")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"R;1")) PrintErrorStack(); 
			strcat(oojname,"R;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"R")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"S;1")) PrintErrorStack(); 
			strcat(oojname,"S;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"S")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"T;1")) PrintErrorStack(); 
			strcat(oojname,"T;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"T")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"U;1")) PrintErrorStack(); 
			strcat(oojname,"U;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"U")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"V;1")) PrintErrorStack(); 
			strcat(oojname,"V;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"V")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"W;1")) PrintErrorStack(); 
			strcat(oojname,"W;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"W")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"X;1")) PrintErrorStack(); 
			strcat(oojname,"X;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"X")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Y;1")) PrintErrorStack(); 
			strcat(oojname,"Y;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Y")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"Z;1")) PrintErrorStack(); 
			strcat(oojname,"Z;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}
		if (strcmp(revi,"Z")==0) 
		{ 
			if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack(); 
			strcat(oojname,"AA;1");
			if(AOM_lock(dataset));
			if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack(); 
			if(AOM_save_without_extensions(dataset))PrintErrorStack();
			if(AOM_unlock(dataset))PrintErrorStack();
		}

		if(AOM_save_without_extensions(dataset))PrintErrorStack();
		if(AOM_unlock(dataset))PrintErrorStack();

		if(AOM_save_without_extensions(rev))PrintErrorStack();
		if(AOM_unlock(rev))PrintErrorStack();
	
		t5removeAllReleaseStatus(rev);
		ERROR_CALL(RELSTAT_create_release_status("T5_LcsReview",&status_rel));      
		ERROR_CALL(RELSTAT_add_release_status(status_rel,1,&rev,retain));   				
		//ERROR_CALL(ITK_set_bypass(TRUE));                                     
																				
		ERROR_CALL(AOM_refresh(rev,1));                                         
		ERROR_CALL(AOM_save_without_extensions(rev));                                              			
		ERROR_CALL(AOM_unlock(rev));    
	}
	return ITK_ok;
}

extern int tm_PeAsmValidation_custom_exit(int *decision, va_list args)
{
	int ifail = ITK_ok;
	METHOD_id_t  PeRevMstCreVal;
	METHOD_id_t  PeRevCreVal;
	METHOD_id_t  PeRevCreValPost;
	METHOD_id_t  PeRevCheckOutVal;
	METHOD_id_t  PeCheckInVal;
	METHOD_id_t  PeRevCopyPre;
	METHOD_id_t  PeRevCopyPost;

	*decision = ALL_CUSTOMIZATIONS;

	//T5_PeDesign and T5_PeDesignRevision
	printf("\n\nStart tm_PeAsmValidation_custom_exit, METHOD_find_method\n");	fflush(stdout);

	if(METHOD_find_method("T5_PeDesign","ITEM_create",&PeRevMstCreVal) !=ITK_ok)		PrintErrorStack();
	if(METHOD_find_method("T5_PeDesignRevision","IMAN_save",&PeRevCreVal) !=ITK_ok)			PrintErrorStack();	
	if(METHOD_find_method(RES_Type, RES_checkout_msg,&PeRevCheckOutVal) !=ITK_ok)			PrintErrorStack();	//T5_PeDesign Revision Check-Out
	if(METHOD_find_method(RES_Type, RES_checkin_msg,&PeCheckInVal) !=ITK_ok)				PrintErrorStack();	//T5_PeDesign Revision Check-In
	if(METHOD_find_method("T5_PeDesignRevision","ITEM_copy_rev",&PeRevCopyPre)!=ITK_ok)		PrintErrorStack();	//T5_PeDesign Revision Revise Action
	if(METHOD_find_method("T5_PeDesignRevision","ITEM_copy_rev",&PeRevCopyPost)!=ITK_ok)	 	PrintErrorStack();	//T5_PeDesign Revision Revise Action
	
	
	if (PeRevMstCreVal.id != 0)
	{
		printf("\n Inside Production Engineering  ***T5_PeDesign***\n");	fflush(stdout);
		if( METHOD_add_action(PeRevMstCreVal, METHOD_post_action_type, (METHOD_function_t) PERevMstCreValidation, NULL)!=ITK_ok) ;
	}

	if (PeRevCreVal.id != 0)
	{
		printf("\nInside Production Engineering Post Action of Revision        ***T5_PeDesignRevision***\n");	fflush(stdout);
		if( METHOD_add_action(PeRevCreVal, METHOD_post_action_type, (METHOD_function_t) PERevCreValidationPost, NULL)!=ITK_ok) PrintErrorStack();
	}
	
	if (PeRevCheckOutVal.id != 0)
	{
		printf("\n Inside PeRevCheckOutVal\n");	fflush(stdout);
		if( METHOD_add_action(PeRevCheckOutVal, METHOD_pre_action_type, (METHOD_function_t) PERevCheckOutValidation, NULL)!=ITK_ok) PrintErrorStack();
	}

	if (PeCheckInVal.id != 0)
	{
		printf("\n Inside PeCheckInVal\n");	fflush(stdout);
		//if( METHOD_add_action(PeCheckInVal, METHOD_pre_action_type, (METHOD_function_t) PECheckInValidation, NULL)!=ITK_ok);PrintErrorStack();
		if(METHOD_add_pre_condition(PeCheckInVal,(METHOD_function_t)PECheckInValidation,NULL)!=ITK_ok) PrintErrorStack();
	}

	if (PeRevCopyPre.id != 0)
    {
        printf("\n Inside PeRevCopyPre\n");	fflush(stdout);
		if(METHOD_add_action(PeRevCopyPre,METHOD_pre_action_type,(METHOD_function_t)PE_Revise_properties_Pre, NULL)!=ITK_ok)	PrintErrorStack();
    }

	if (PeRevCopyPost.id != 0)
    {
        printf("\n Inside PeRevCopyPost\n");	fflush(stdout);
		if(METHOD_add_action(PeRevCopyPost,METHOD_post_action_type,(METHOD_function_t)PE_Revise_properties_Post, NULL)!=ITK_ok)	PrintErrorStack();
    } 
	printf("\n\nEnd tm_PeAsmValidation_custom_exit, METHOD_find_method\n");	fflush(stdout);

	return(ITK_ok);
}

extern DLLAPI int tm_PeAsmValidation_register_callbacks ()
{
	printf("\n\ntm_PeAsmValidation_register_callbacks :: Hello Teamcenter tm_PeAsmValidation\n");fflush(stdout);

	CUSTOM_register_exit ("tm_PeAsmValidation","USER_init_module",(CUSTOM_EXIT_ftn_t) tm_PeAsmValidation_custom_exit);
	return(ITK_ok);
}
