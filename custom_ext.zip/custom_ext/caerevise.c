/****************************************************************************************************
*  File            :   caerevise.c
*  Created By      :   Prachi Wade
*  Created On      :   
*  Purpose         :   
******************************************************************************************************/
#include <tc/tc.h>
#include <ae/dataset.h>
#include <epm/epm.h>
#include <ict/ict_userservice.h>
#include <property/prop.h>
#include <property/prop_errors.h>
#include <property/prop_msg.h>
#include <stdarg.h>
#include <res/res_itk.h>
#include <string.h>
#include <tc/envelope.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/method.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <sa/tcfile.h>
#include <sa/sa.h>
#include <user_exits/user_exits.h>
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002
#define CONNECT_FAILURE (EMH_USER_error_base + 30)
#include<tccore/tc_msg.h>

 
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
//    vsprintf(msg, format, args);
    printf(msg);
    va_end(args);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
	
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

extern DLLAPI int revise_validation(METHOD_message_t *m, va_list args)
{
	tag_t	source_rev				 = va_arg(args, tag_t);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	
	int	   status_count=0;
	tag_t* status_list = NULLTAG;
	int t =0;
	char   *release_status=NULL;
	char   *Item_string=NULL;
	char *s = NULL;
	
	TC_write_syslog("inside revise validations\n");fflush(stdout);	  
//	cae_tag = m->object_tag;
	if(source_rev!=NULLTAG)
	{ 	
		AOM_ask_value_string(source_rev,"object_string",&Item_string);
		TC_write_syslog("\t source_rev %s \n", Item_string);fflush(stdout);

		WSOM_ask_release_status_list(source_rev,&status_count,&status_list);
		TC_write_syslog("status_count:%d\n",status_count);fflush(stdout);
		if(status_count > 0 )
		{
 			  for (t = 0; t < status_count; t++)
			  {
					AOM_ask_name(status_list[t], &release_status);
					TC_write_syslog("\t release_status: %s\n", release_status);fflush(stdout); //release_status_list TCM Released
					if((strcmp(release_status,"Released")==0))  //   
			        {
						 TC_write_syslog("Revision is released, canbe revised\n");fflush(stdout);
				         return ITK_ok;
			        }
			  } 				 
		 }

	}

	TC_write_syslog("\n Part can't be revised unless released\n");fflush(stdout);
	EMH_clear_errors();
	//EMH_ask_error_text(CONNECT_FAILURE,&s);
	//EMH_store_error_s1(EMH_severity_error,CONNECT_FAILURE,s) ;
	EMH_store_error_s1(EMH_severity_error,ITK_err, "Item can't be revised. Release the revision before revising.");
	return ITK_err;
}
 
extern DLLAPI int checkout_validation(METHOD_message_t *m, va_list args)
{
	tag_t	source_rev				 = va_arg(args, tag_t);
 	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
  
 	char   *revision1=NULL; 
 	int     iseq1= 0; 
 	char   *revision2=NULL; 
	int     iseq2= 0; 
	//char	*seq1	 = NULL;
	//char	*seq2	 = NULL;
 
	tag_t	master		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
 
	TC_write_syslog("inside checkout validations\n");fflush(stdout);
 
	if(ITEM_ask_item_of_rev(source_rev,&master));
	if(ITEM_ask_latest_rev(master,&latestrev));

	if (AOM_ask_value_string(latestrev,"current_revision_id",&revision1)!=ITK_ok)   PrintErrorStack();
	if(AOM_ask_value_int(latestrev,"sequence_id",&iseq1)) PrintErrorStack();
 

	if (AOM_ask_value_string(source_rev,"current_revision_id",&revision2)!=ITK_ok)   PrintErrorStack();
	if(AOM_ask_value_int(source_rev,"sequence_id",&iseq2))PrintErrorStack();
 
	TC_write_syslog("\t latestrev %s %d\n", revision1,iseq1);fflush(stdout);
	TC_write_syslog("\t sourcerev %s %d\n", revision2,iseq2);fflush(stdout);

	if ((strcmp(revision1,revision2) !=0) || (iseq1 != iseq2))
	{
		TC_write_syslog("\n Part is not latest part,checkout of failed.\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_err, "Only latest revision can be checkedout.");
		return ITK_err;
	
	}
 	
	return ITK_ok;
} 

extern int caecheckout_register_method(int *decision, va_list args)
{
	METHOD_id_t  method;
	METHOD_id_t  method1;
	int	ifail = 0;
    *decision = ALL_CUSTOMIZATIONS;
	
	printf("\n Inside caecheckout_register_method  \n");;fflush(stdout); 
	 
	METHOD_find_method(RES_Type, RES_checkout_msg, &method);
    if (method.id != NULLTAG)
    {
        METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)checkout_validation,NULL);
		TC_write_syslog("\n\nAfter CAE Register Checkout\n");
		printf("\n CAE Checkout method found.... \n");fflush(stdout);
    } 

    METHOD_find_method("CAEItemRevision", "ITEM_copy_rev", &method1);  
 	if (method1.id != NULLTAG)
    {
        METHOD_add_pre_condition(method1, (METHOD_function_t)revise_validation,NULL);
		TC_write_syslog("\n\nAfter CAE Register Revise\n");
		printf("\n CAE Revise method found.... \n");fflush(stdout);
    }



    return ifail;	
}

extern DLLAPI int caerevise_register_callbacks ()
{
    printf("\n Inside caerevise_register_callbacks  \n");;fflush(stdout);
	CUSTOM_register_exit("caerevise", "USER_init_module", (CUSTOM_EXIT_ftn_t)caecheckout_register_method);
    TC_write_syslog("\nRegister caerevise_register_callbacks \n");
	printf("\n caerevise_register_callbacks called.   \n");;fflush(stdout);
	return ITK_ok;
}
