. /home/uadev/.bash_profile
#/home/uadev/devgroups/mohan/ITK/GMdmlRecursion/gm1_partupd/GateMaturationUpd -u=ercpsup  -pf=XYT1ESA  -g=dba -dmlno=$1
/user/uaprod/TC_ROOT_10/bin/tml_tools/GateMaturationUpd -u=ercpsup  -pf=XYT1ESA  -g=dba -dmlno=$1
