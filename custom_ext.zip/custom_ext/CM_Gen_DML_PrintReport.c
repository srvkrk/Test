/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Shivkumar Birnale
*  Module               :   Workflow Action Handler to create DML Print Report and attach to DML as MSWord dataset
*  Code                 :   CM_Gen_DML_PrintReport.c
*  Created on			:   March 22nd, 2018
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Action Handler		:		CM_Gen_DML_PrintReport
	Description			:		This handler generates DML Print Report and attaches to DML
*/
int CM_Gen_DML_PrintReport(EPM_action_message_t msg)
{
	int i=0;
	int status=ITK_ok;
	int attachmentCount=0, transfermodeCnt=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;

	char mainFile[50];
	char command[512];
	char docFile[50];

	tag_t rootTask_t=NULLTAG;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t specificationRel_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *transfermodes=NULLTAG;

	printf("\n CM_Gen_DML_PrintReport Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Gen_DML_PrintReport Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&specRelationType_t));

	for(i=0;i<attachmentCount;i++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[i],&obj_type));
		TC_write_syslog("Object Type = %s\n",obj_type);
		if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
		{
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"item_id",&dmlNumber));
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"item_revision_id",&revId));

			tc_strcpy(mainFile,"");
			tc_strcat(mainFile,"/tmp/");
			tc_strcat(mainFile,dmlNumber);
			tc_strcat(mainFile,"_");
			tc_strcat(mainFile,revId);
			tc_strcat(mainFile,".xml");
			TC_write_syslog("Main File = %s\n",mainFile);

			tc_strcpy(docFile,"");
			tc_strcat(docFile,"/tmp/dmlprint_report_");
			tc_strcat(docFile,dmlNumber);
			tc_strcat(docFile,"_");
			tc_strcat(docFile,revId);
			tc_strcat(docFile,".doc");
			TC_write_syslog("Doc File = %s\n",docFile);

			ITK_CALL(PIE_create_session(&PLMSession));
			ITK_CALL(PIE_session_set_file(PLMSession,mainFile));
			ITK_CALL(PIE_find_transfer_mode2("T5_DML_Print_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
			TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);
			ITK_CALL(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
			ITK_CALL(PIE_session_export_objects(PLMSession,1,&taskAttachments[i]));
			//sprintf(command,"java -classpath /home/uadev/TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadev/TC_ROOT/bin/tml_tools/DML_print_report_template.xsl >/tmp/wfout.log",mainFile,dmlNumber);
			sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/apply.sh %s %s",mainFile,docFile);
			TC_write_syslog("Command = %s\n",command);
			//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
			system(command);
			if(access(docFile,F_OK)!=-1)
			{
				TC_write_syslog("Doc file created successfully\n");
				ITK_CALL(AE_find_datasettype2("MSWord",&msWordType));
				if(msWordType == NULLTAG)
				{
					TC_write_syslog("Could not find Dataset Type MSWord. Please check data model\n");
					continue;
				}
				ITK_CALL(AE_create_dataset_with_id(msWordType,dmlNumber,"DML Print Report for DML","","",&wordDataset));
				ITK_CALL(AE_save_myself(wordDataset));
				ITK_CALL(GRM_create_relation(taskAttachments[i],wordDataset,specRelationType_t,NULLTAG,&specificationRel_t));
				ITK_CALL(AOM_load(specificationRel_t));
				ITK_CALL(GRM_save_relation(specificationRel_t));
				ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
				ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
				ITK_CALL(AE_import_named_ref(wordLatestDat_t,"word",docFile,NULL,SS_BINARY));
				ITK_CALL(AE_save_myself(wordLatestDat_t));
				remove(docFile);
			}
		}
	}
	printf("\n CM_Gen_DML_PrintReport Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Gen_DML_PrintReport Function end...");

	//return status;
	return 0;
}