/***********************************************************************************************************
*  File            :   tm_RCA_Doc_Validation.c
*  Created By      :   Sumit Radotra
*  Created On      :   30-03-2021
*  Project         :   TATA MOTORS LTD(TCUA)
*  Purpose         :   RCA document attachment validation for DML for particular reason code in TCUA. 
*  
*  Modification History :
*  S.No    Date        CR            TCUA  Modified By      Modification Notes
*  1	   30-03-2021  CR-FY21-0219	 1.57  Sumit Radotra    RCA document attachment validation for DML 
															for particular reason code in TCUA.
************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <ics/ics2.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>

#define	ADD	1
#define	DEL	-1
#define	NA	0

#define ITK_err 919006
static void ECHO(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}

#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
static int report_error(char *file, int line, char *call, int status,
	logical exit_on_error)
{
	if (status != ITK_ok)
	{
		int n_errors = 0;
		const int 
			*severities=NULL,
			*statuses=NULL;
	const char
		**messages;

	EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
	if (n_errors > 0)
	{
		ECHO("\n%s\n", messages[n_errors-1]);
		EMH_clear_errors();
	}
	else
	{
		char *error_message_string;
		EMH_ask_error_text(status, &error_message_string);
		ECHO("\n%s\n", error_message_string);
	}

	ECHO("error %d at line %d in %s\n", status, line, file);
	ECHO("%s\n", call);

	if (exit_on_error)
	{
		ECHO("Exiting program!\n");
		exit (status);
	}
	}

	return status;
}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
} 

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int getContrlObQry( char *syscd,char *subsyscd,char* info1,char* info2,char* info3,int  *n_found ,tag_t  **RetContrlObjs)
{
	int    ifail = ITK_ok;	
	tag_t  query = NULLTAG;	

	char  *qry_entries[] =  {"SYSCD","SUBSYSCD","Information-1","Information-2","Information-3","Delete Indicator"},
	      *qry_values []  = {syscd,subsyscd,info1,info2,info3,"0"};

	printf("\n RCA_8D_DOC in getContrlObQry func");fflush(stdout);
	printf("\n RCA_8D_DOC Input syscd=[%s] SUBSYSCD=[%s] \n",syscd,subsyscd);fflush(stdout);
	
	printf("\n RCA_8D_DOC b4 Qry getContrlObQry....");fflush(stdout);

	QRY_find2("Control Objects...", &query);
	printf("\n RCA_8D_DOC in after qry find getContrlObQry [%s] [%s] [%s] [%s] [%s]",syscd,subsyscd,info1,info2,info3);fflush(stdout);
	QRY_execute(query,6, qry_entries, qry_values, n_found, RetContrlObjs);	
	printf("\n RCA_8D_DOC End Qry for getContrlObQry control Changes object size [%d] \n",*n_found);fflush(stdout);

	return ifail;
}

/**********************************************************************************************************************
	Rule Handler		:		CM_Check_RCADocForERCDML
	Description			:		This Rule handler checks the RCA doc for ERC DML during sign-off from Designer end.
***********************************************************************************************************************/

extern EPM_decision_t DLLAPI tm_Check_RCADocForERCDML(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int  i=0,j=0,k=0,status=ITK_ok;
	int  ifail=0;
	int  Itemscnt=0;
	int  dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int  DcrItemscnt=0;
	int  attachmentCount=0,qryRetCnt=0;
	int  noAttachment=0;	
	int	 Dmlcnt=0;
	int	 resCnt =0;
	int	 flag =0;
	char *id;
	char *DocName;
	char *RelationName=NULL;
	char *revid=NULL;
	char *dmlNo=NULL;
	char *DmlDR=NULL;
	char *DMLtype=NULL;
	char *projectname=NULL;
	char *BusUnit=NULL;
	char *reason=NULL;
	char **reasondesc=NULL;
	char *ReasonVal=NULL;
	char *userinfo1=NULL;
	char *userinfo2=NULL;
	char *userinfo3=NULL;
	char *userinfo4=NULL;


	tag_t tsk_dml_rel_type;
	tag_t *DMLRevision = NULL;

	char *Match_Str = (char *)MEM_alloc(100 * sizeof(char *));
	char *ErrorMsg  = (char *)MEM_alloc(600 * sizeof(char *));
	char *DmlDRCpy  = (char *)MEM_alloc(100 * sizeof(char *));
	char *DMLtypeCpy= (char *)MEM_alloc(100 * sizeof(char *));
	char *reasonCpy = (char *)MEM_alloc(100 * sizeof(char *));
	char *obj_type=NULL;

	tag_t  rev				=NULLTAG;
	tag_t  rootTask_t		=NULLTAG;
	tag_t  *taskAttachments =NULLTAG;	
	int		count=0;
	int		resultCount = 0;
	int		n_entries = 1;
	int		Sqid = 0;
	char	*val;
	tag_t	*secondary_objects ;
	tag_t   item=NULLTAG;
	tag_t   DMLRev_Latest=NULLTAG;
		


	printf("inside CM_Check_RCADocForERCDML Rule Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	printf("\n CM_Check_RCADocForERCDML attachmentCount = %d\n",attachmentCount);fflush(stdout);
	if(attachmentCount>0)
	{
		for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
		{
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
			printf("\n CM_Check_RCADocForERCDML Object Type = %s\n",obj_type);fflush(stdout);
			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{
				printf("\n inside query \n");fflush(stdout);				
				char *id;
				char *Solid;
		
		
				CALLAPI(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
				printf("\n Task_id= [%s]",id);fflush(stdout);

				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				//printf("\n Task Release Type = [%s]",tsk_dml_rel_type);fflush(stdout);

				if (tsk_dml_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_primary_objects_only(taskAttachments[Itemscnt],tsk_dml_rel_type,&Dmlcnt,&DMLRevision));				  
				}
				printf("\n Dmlcnt= %d",Dmlcnt);fflush(stdout);

			//DML Details extraction -->
			if(Dmlcnt>0)
			{
			
				CALLAPI(ITEM_ask_item_of_rev (*DMLRevision, &item));
				CALLAPI(ITEM_ask_latest_rev(item, &DMLRev_Latest));

				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"item_id" , &dmlNo));
				printf("\n RCA_8D_DOC DML No : [%s]\n",dmlNo);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"item_revision_id" , &revid));
				printf("\n RCA_8D_DOC DML Rev : [%s]\n",revid);fflush(stdout);
				CALLAPI(AOM_ask_value_int(DMLRev_Latest,"sequence_id" , &Sqid));
				printf("\n RCA_8D_DOC DML Sqid : [%d]\n",Sqid);fflush(stdout);
			
				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"t5_cDRstatus",&DmlDR));
				printf("\n RCA_8D_DOC Dml DR Status : [%s]\n",DmlDR);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"t5_rlstype",&DMLtype));
				printf("\n RCA_8D_DOC DML Type : [%s]\n",DMLtype);fflush(stdout);
				
				CALLAPI(AOM_UIF_ask_value(DMLRev_Latest,"t5_cprojectcode",&projectname));
				printf("\n RCA_8D_DOC Projectname : [%s] \n",projectname);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"t5_ERCBusiUt",&BusUnit));
				printf("\n RCA_8D_DOC DML business unit  : [%s] \n",BusUnit);fflush(stdout);

				CALLAPI(AOM_ask_value_string(DMLRev_Latest,"t5_reason",&reason));
				printf("\n RCA_8D_DOC DML reason : [%s] \n",reason);fflush(stdout);
				
				CALLAPI(AOM_ask_displayable_values(DMLRev_Latest,"t5_reason",&resCnt, &reasondesc));
				printf("\n RCA_8D_DOC resCnt : [%d] \n",resCnt); fflush(stdout);
				if(resCnt>0) 
				ReasonVal = reasondesc[0];
				printf("\n RCA_8D_DOC Reason Desc : [%s]\n",ReasonVal);fflush(stdout);				
				
			}
			
			int controlObjCnt=0;
			tag_t *CntrlObjTags    = NULLTAG;
					
			tc_strcpy(DMLtypeCpy,"*");
			tc_strcat(DMLtypeCpy,DMLtype);
			tc_strcat(DMLtypeCpy,"*");
			printf("\n RCA_8D_DOC under DMLtypeCpy= %s",DMLtypeCpy);fflush(stdout);	

			tc_strcpy(reasonCpy,"*");
			tc_strcat(reasonCpy,reason);
			tc_strcat(reasonCpy,"*");
			printf("\n RCA_8D_DOC under reasonCpy= %s",reasonCpy);fflush(stdout);	

			tc_strcpy(DmlDRCpy,"*");
			tc_strcat(DmlDRCpy,DmlDR);
			tc_strcat(DmlDRCpy,"*");
			printf("\n RCA_8D_DOC under DmlDRCpy= %s",DmlDRCpy);fflush(stdout);
		
			CALLAPI(getContrlObQry( "RCA_8D_DOC",BusUnit,DMLtypeCpy,reasonCpy,DmlDRCpy,&controlObjCnt,&CntrlObjTags));
			
			printf("\n RCA_8D_DOC valid Business unit & Release type controlObjCnt size : %d\n",controlObjCnt);fflush(stdout);
			
			if(controlObjCnt>0)
			{					
				////Business process validation error.
				CALLAPI(AOM_ask_value_string(CntrlObjTags[0],"t5_Userinfo4", &userinfo4)); //Userinfo4=RCA_8D_Document_"
			    printf("\n RCA_8D_DOC Userinfo4 Value [%s]\n",userinfo4);fflush(stdout);
				//CALLAPI(AOM_ask_value_tags(DMLRev_Latest,"IMAN_reference",&count,&secondary_objects));
				tag_t dml_rel_type=NULLTAG;
				CALLAPI(GRM_find_relation_type("IMAN_reference", &dml_rel_type));
				if (dml_rel_type!=NULLTAG)
				{
					printf("\n Inside Attachments ... \n");fflush(stdout);
				    CALLAPI(GRM_list_secondary_objects_only(DMLRev_Latest,dml_rel_type,&count,&secondary_objects));
					//CALLAPI(AOM_ask_value_string(secondary_objects[0],"object_string" , &DocName));
					//printf("\n RCA_8D_DOC Document Name : [%s]\n",DocName);fflush(stdout);
				}				
				printf("\n RCA_8D_DOC count : [%d]\n",count);fflush(stdout);

				if(count>0)
				{
					tc_strcpy(Match_Str,userinfo4);
					tc_strcat(Match_Str,dmlNo);
					printf("\n RCA_8D_DOC Match_Str Value [%s]\n",Match_Str);fflush(stdout);
					for(i=0;i<count;i++)
					{
						printf("\n RCA_8D_DOC for Loop [%d]",i);fflush(stdout);
						CALLAPI(AOM_ask_value_string(secondary_objects[i],"object_string" , &DocName));
						printf("\n RCA_8D_DOC Document Name= %s",DocName);fflush(stdout);
						
						if(tc_strstr(DocName,Match_Str)!=NULL)
						{
							printf("\n RCA_8D_DOC Valid RCA Document is available -> [%s]",DocName);fflush(stdout);
							flag++;
							break;
						}									
					}			
					
					printf("\n flag [%d]",flag);fflush(stdout);
					if(flag>0)
					{
						printf("\n EPM_go for Valid RCA 8D Document is available");fflush(stdout);
						decision = EPM_go;
						return decision;
					}
					else
					{
						printf("\nRCA Document checks w.r.t ERC DML has completed");fflush(stdout);
					 
					}						
						
		  
				}
				else
				{
					//Display error message
					printf("\n EPM_nogo");fflush(stdout);
					//printf("\n %s",ErrorMsg);fflush(stdout);

					//EMH_clear_errors();
					//EMH_store_error_s1(EMH_severity_error,ITK_err, ErrorMsg);
					//decision = EPM_nogo;
					//return decision;
				}

				printf("\n EPM flag %d",flag);fflush(stdout);
				if (flag==0)
				{
						tc_strcpy(ErrorMsg,"DML having DR status");
						tc_strcat(ErrorMsg," [");
						tc_strcat(ErrorMsg,DmlDR);
						tc_strcat(ErrorMsg,"] ");
						tc_strcat(ErrorMsg,"Release Type");
						tc_strcat(ErrorMsg," [");					
						tc_strcat(ErrorMsg,DMLtype);
						tc_strcat(ErrorMsg,"] ");
						tc_strcat(ErrorMsg,"and ");
						tc_strcat(ErrorMsg,"Reason Type");
						tc_strcat(ErrorMsg," [");
						tc_strcat(ErrorMsg,ReasonVal);
						tc_strcat(ErrorMsg,"] ");
						tc_strcat(ErrorMsg,"\n");
						tc_strcat(ErrorMsg,"must have the RCA document attached with format RCA_8D_Document_");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"\n");
						printf("\n EPM_nogo");fflush(stdout);
						printf("\n %s",ErrorMsg);fflush(stdout);

						//EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, ErrorMsg);
						decision = EPM_nogo;
						return decision;
				}
				else
				{
					  decision = EPM_go;
						return decision;
				}

			} 
			else
			{
				 ////BYPASSING THE CASE FOR WHICH CONTROL OBJECT IS NOT CREATED
				 printf("\n Control Object Query not Found for business unit [%s] & release Type [%s]\n",BusUnit,DMLtype);fflush(stdout);
				 decision = EPM_go;
				 return decision;
			}		
		 }		
	  }
   }
   decision = EPM_go;
   return decision;
}

extern EPM_decision_t DLLAPI tm_CheckSignoffRole(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int i = 0;
	int k = 0;
	int Role_n_entry = 1;
	int RolersltCount = 0;
	int noAttachment = 0;
	int taskcount = 0;
	tag_t group_tag = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t RoleqryTag = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *RoleCntrlObjectTag = NULLTAG;
	char *username = NULL;
	char *CurrentTask = NULL;
	char *parent_name = NULL;
	char *group_name = NULL;
	char *wftaskname = NULL;
	char *Roleinfo1 = NULL;
	char *Roleinfo2 = NULL;
	char *Roleinfo3 = NULL;
	char *object_type = NULL;
	char *taskTempLT = NULL;
	char *role_qry_entry[1]  = {"SYSCD"};
	char **Role_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	POM_get_user_id (&username);
	printf("\n Inside the tm_CheckSignoffRole: Session User is : %s \n",username); fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Inside the tm_CheckSignoffRole after rootTask found ...\n");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n tm_CheckSignoffRole- CurrentTask: %s \n",CurrentTask);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n tm_CheckSignoffRole- parent Name: %s \n",parent_name);fflush(stdout);

	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n tm_CheckSignoffRole- Target Attachment:%d \n",noAttachment);fflush(stdout);

	if(QRY_find2("ControlObjects", &RoleqryTag));
	if (RoleqryTag)
	{
		printf("\n tm_CheckSignoffRole: CheckRole-->L2:Found Query SupportqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n tm_CheckSignoffRole: CheckRole-->L3:Not Found Query SupportqryTag \n");fflush(stdout);
	}
	Role_qry_values2[0] = "CheckRole";
	if(QRY_execute(RoleqryTag, Role_n_entry, role_qry_entry, Role_qry_values2, &RolersltCount, &RoleCntrlObjectTag));
	printf(" \n tm_CheckSignoffRole: CheckRole-->L4:DR_rsltCount :%d:", RolersltCount); fflush(stdout);
	if(RolersltCount > 0)
	{
		if (AOM_ask_value_string(RoleCntrlObjectTag[0],"t5_Userinfo1",&Roleinfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n tm_CheckSignoffRole: CheckRole-->L5:Roleinfo1 is : [%s]\n", Roleinfo1);fflush(stdout);

		if (AOM_ask_value_string(RoleCntrlObjectTag[0],"t5_Userinfo2",&Roleinfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n tm_CheckSignoffRole: CheckRole-->L6:Roleinfo2 is : [%s]\n", Roleinfo2);fflush(stdout);

		if (AOM_ask_value_string(RoleCntrlObjectTag[0],"t5_Userinfo3",&Roleinfo3)!=ITK_ok)   PrintErrorStack();
		printf("\n tm_CheckSignoffRole: CheckRole-->L6:Roleinfo3 is : [%s]\n", Roleinfo3);fflush(stdout);
		
		if(tc_strstr(Roleinfo1,"ROL001") == NULL)
		{
			if (noAttachment > 0)
			{
				POM_ask_group(&group_name, &group_tag);
				printf ("tm_CheckSignoffRole: CheckRole-->Logged in group:%s\n",group_name);fflush(stdout);
				for (k = 0; k < noAttachment ; k++ )
				{
					AOM_ask_value_string(attachments[k],"object_type",&object_type);
					printf("\n [%d] tm_CheckSignoffRole- object_type is :%s\n",k,object_type);fflush(stdout);
					
					if(tc_strstr(Roleinfo1,"ROL002") == NULL)
					{
						if((tc_strcmp(object_type,"ERC DML Revision")==0) || (tc_strcmp(object_type,"ChangeRequestRevision")==0))
						{
							if(tc_strstr(Roleinfo1,"ROL003") == NULL)
							{
								printf ("tm_CheckSignoffRole: Logged in group 1:%s\n",group_name);fflush(stdout);
								if (tc_strcmp(group_name,"Viewer_Group") == 0)
								{
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_warning,ITK_err, "You can not Signoff DML with 'Viewer_Group' Group, Kindly set correct Group from Application Banner.");
									decision = EPM_nogo;
								}
							}
							else
							{
								//OFF
								printf ("tm_CheckSignoffRole: Logged in group 2:%s\n",group_name);fflush(stdout);
								ITK_CALL(AOM_UIF_ask_value(attachments[k],"fnd0ActuatedInteractiveTsks",&taskTempLT));
								printf("\ntm_CheckSignoffRole---DML revision taskTempLT is : %s\n",taskTempLT);fflush(stdout);
								if(tc_strstr(Roleinfo2,taskTempLT) != NULL)
								{
									if (tc_strcmp(group_name,"Viewer_Group") == 0)
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_warning,ITK_err, "You can not Signoff DML with 'Viewer_Group' Group, Kindly change Group from Application Banner.");
										decision = EPM_nogo;
									}
								}
							}
						}
					}
					if(tc_strstr(Roleinfo1,"ROL004") == NULL)
					{
						if((tc_strcmp(object_type,"ERC Task Revision")==0) || (tc_strcmp(object_type,"T5_ChangeTaskRevision")==0))
						{
							if(tc_strstr(Roleinfo1,"ROL004") == NULL)
							{
								printf ("tm_CheckSignoffRole: Logged in group 3:%s\n",group_name);fflush(stdout);
								if (tc_strcmp(group_name,"Viewer_Group") == 0)
								{
									printf ("tm_CheckSignoffRole: CheckRole-->Logged in group:%s\n",group_name);fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_warning,ITK_err, "You can not Signoff Task with 'Viewer_Group' Group, Kindly change Group from Application Banner.");
									decision = EPM_nogo;
								}
							}
							else
							{
								//OFF
								printf ("tm_CheckSignoffRole: Logged in group 4:%s\n",group_name);fflush(stdout);
								ITK_CALL(AOM_UIF_ask_value(attachments[k],"fnd0ActuatedInteractiveTsks",&taskTempLT));
								printf("\ntm_CheckSignoffRole---DML task Revision taskTempLT is : %s\n",taskTempLT);fflush(stdout);
								if(tc_strstr(Roleinfo3,taskTempLT) != NULL)
								{
									if (tc_strcmp(group_name,"Viewer_Group") == 0)
									{
										printf ("tm_CheckSignoffRole: CheckRole-->Logged in group:%s\n",group_name);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_warning,ITK_err, "You can not Signoff Task with 'Viewer_Group' Group, Kindly change Group from Application Banner.");
										decision = EPM_nogo;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	else
	{
		printf("\n tm_CheckSignoffRole- Control Object CheckRole not Found");fflush(stdout);
	}
	return decision;
}

extern int RCADocForERCDML_register_methods(int *decision, va_list args)
{                           

	printf("\n Start  *****tm_RCA_Doc_Validation_register_methods***** \n");fflush(stdout);       
	int ifail = ITK_ok;
	METHOD_id_t  method1;
	METHOD_id_t  method2;

	*decision = ALL_CUSTOMIZATIONS;

   if(ITK_ok ==  EPM_register_rule_handler ("CM_Check_RCADocForERCDML","Rule handler to check RCA", (EPM_rule_handler_t) tm_Check_RCADocForERCDML))
   {
		printf("\t Registered Rule Handler tm_Check_RCADocForERCDML\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Rule Handler tm_Check_RCADocForERCDML\n");fflush(stdout);
   }

   //Prasad
   if(ITK_ok ==  EPM_register_rule_handler ("tm_CheckSignoffRole","Rule handler to check RCA", (EPM_rule_handler_t) tm_CheckSignoffRole))
   {
		printf("\t Registered Rule Handler tm_CheckSignoffRole\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Rule Handler tm_CheckSignoffRole\n");fflush(stdout);
   }
   return ITK_ok;
}

extern DLLAPI int tm_RCA_Doc_Validation_register_callbacks ()
{
	printf("\n tm_RCA_Doc_Validation_register_callbacks\n");fflush(stdout);

	ERROR_CHECK(CUSTOM_register_exit ( "tm_RCA_Doc_Validation", "USER_init_module",(CUSTOM_EXIT_ftn_t) RCADocForERCDML_register_methods ));

    return ITK_ok;
}

