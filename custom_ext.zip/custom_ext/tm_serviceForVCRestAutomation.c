#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

// /*
int ServiceForVCautomationCreationMaster(void *return_data)
{
	
	int 			status;
	int				ifail 				=	ITK_ok;
	char	command[1000];
    char * AplRevw = NULL;
    char * VEHID = NULL;
    char * VehRev = NULL;
	char * VehSeq = NULL;
    char * RowCntWindow1 = NULL;
    char * TotalRowSelc = NULL;
    char * wind2AElements = NULL;
    char * Rolename = NULL;
    char * responseString1 = NULL;

	printf("\n I am in main program");fflush(stdout);

    responseString1=(char *)MEM_alloc(200);
    USERARG_get_string_argument(&AplRevw);	
	USERARG_get_string_argument(&VEHID);	
	USERARG_get_string_argument(&VehRev);
	USERARG_get_string_argument(&VehSeq);
	USERARG_get_string_argument(&RowCntWindow1);
	USERARG_get_string_argument(&TotalRowSelc);
	USERARG_get_string_argument(&wind2AElements);
	USERARG_get_string_argument(&Rolename);
	
	printf("\n Input AplRevw :: %s ",AplRevw);fflush(stdout);
	printf("\n Input VEHID :: %s ",VEHID);fflush(stdout);
	printf("\n Input VehRev :: %s ",VehRev);fflush(stdout);
	printf("\n Input VehSeq :: %s ",VehSeq);fflush(stdout);
	printf("\n Input RowCntWindow1 :: %s ",RowCntWindow1);fflush(stdout);
	printf("\n Input TotalRowSelc :: %s ",TotalRowSelc);fflush(stdout);
    printf("\n Input wind2AElements :: %s ",wind2AElements);fflush(stdout);	
    printf("\n Input Rolename :: %s ",Rolename);fflush(stdout);	
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char     *qry_valuesCntrl1[3]= {"VCAutomation","ServiceToCC","0"};

    ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
       if (qryTagCntrl1)
       {
            printf("\n VCAutomation creation \n");fflush(stdout);
		    printf("\n Control Object VCAutomation creation Query Found \n");fflush(stdout);
			
			ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		    printf("\n No of Control Object VCAutomation creation  Found %d ",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
		    {
				char* t5_Userinfo1 = NULL;
				char Command[200];
				tag_t obj = list_of_WSO_cntrl_tags1[0];
				ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	

				sprintf(Command,"%s  %s %s %s %s %s %s %s %s",t5_Userinfo1,AplRevw,VEHID,VehRev,VehSeq,RowCntWindow1,TotalRowSelc,wind2AElements,Rolename);
				printf("Executing Command = %s",Command);fflush(stdout);
				TC_write_syslog("Command = %s\n",command);
				system(Command);
				printf("After executing Command");fflush(stdout);
		    }
		    else
		    {
				printf(" \n Control Object Not Found \n");
		    }
	   }


	return ifail;

	//sprintf(command,"/user/tcuaadev/devgroups/vishal/CR04/shell/tm_ServiceForF9X01Creation.sh  %s %s %s %s %s",selectedVehicle,selectedVehRev,selectedVehSeq,selectedTask,userName);
	//TC_write_syslog("Command = %s\n",command);
	//system(command);

}



extern int AllUserServiceForVCAutoCreation(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	int nargs = 8;
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	inputArgTypes[7] = USERARG_STRING_TYPE;
		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n AllUserServiceForVCAutoCreationCalling before....ServiceForVCautomationCreationMaster");fflush(stdout);  
	ifail=USERSERVICE_register_method("ServiceForVCautomationCreationMaster",(USER_function_t)ServiceForVCautomationCreationMaster,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

extern DLLAPI int tm_serviceForVCRestAutomation_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_serviceForVCRestAutomation");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_serviceForVCRestAutomation", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceForVCAutoCreation);
	printf("\n After registering userservice....tm_serviceForVCRestAutomation");fflush(stdout);
	return ( ITK_ok );
}


