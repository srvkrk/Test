/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_MR_SetOccEff.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int CM_MR_SetOccEff(EPM_action_message_t msg)
{
	int ifail				= ITK_ok;
	int Flag				= 0;
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int countDep			= 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *primary_obj		= NULLTAG;
	tag_t  primaryObj		= NULLTAG;
	tag_t  childObjTag		= NULLTAG;
	tag_t  ArchobjTypeTag	= NULLTAG;
	tag_t  ArchAssyTag		= NULLTAG;
	tag_t  primaryobjtype	= NULLTAG;
	tag_t  probj			= NULLTAG;
	


	char   *objecttype		= NULL;
	char   *objectId		= NULL;
	char   *objectrevId		= NULL;
	char   *objectdesc		= NULL;
	char   *objectrelstatus	= NULL;
	char   *objectDRstatus	= NULL;
	char   *type_name		= NULL;
	char   *archId			= NULL;
	char   *OccUIDattr		= NULL;

	char*	ObjTyp= NULL;
	char*    Archtype_name= NULL;

	int n_parents=0;
	int *levels = 0;
	tag_t *parents = NULL;
	
	char *username;
	tag_t user_tag=NULLTAG;
	char *userid;
	
	printf("\n CM_MR_SetOccEff Function started...");fflush(stdout);
	TC_write_syslog("\n CM_MR_SetOccEff Function started...");

	ifail = EPM_ask_root_task(msg.task, &roottask);
	ifail = EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments);
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* CM_MR_SetOccEff INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** CM_MR_SetOccEff Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				ifail = GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation);
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t CM_MR_SetOccEff DmlItemsRelation relation found......");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject);
					printf("\n\t count is : %d",count);
					if(count >0)
					{
						for(j=0;j<count;j++)
						{
						  ifail = AOM_ask_value_string(SecObject[j],"t5_PartType",&objecttype);
						  ifail = AOM_ask_value_string(SecObject[j],"item_revision_id",&objectrevId);
						  ifail = AOM_ask_value_string(SecObject[j],"item_id",&objectId);
						  ifail = AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus);

						  printf("CM_MR_SetOccEff objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("CM_MR_SetOccEff objectId = [%s]\n",objectId);fflush(stdout);
						  printf("CM_MR_SetOccEff objectrevId = [%s]\n",objectrevId);fflush(stdout);
						  printf("CM_MR_SetOccEff objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  //if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && (tc_strstr(objectrevId,"NR")== NULL) && (tc_strcmp(objecttype,"M")==0 ))
						  if ((tc_strcmp(objecttype,"M")==0) && (tc_strstr(objectrevId,"NR")!= NULL))
						  {
							 if(PS_where_used_all(SecObject[j],1,&n_parents,&levels,&parents));
							  printf("\n\t CM_MR_SetOccEff where_used count of objects are : %d",n_parents); fflush(stdout); // 1
							  if(n_parents >0)
							  {
								  for (k=0;k<n_parents;k++)
								  {
									 ArchAssyTag=parents[k];

									  ifail = AOM_UIF_ask_value(ArchAssyTag,"object_type",&type_name);
									 
									  if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
									  if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
									  printf("\n\t CM_MR_SetOccEff Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										  printf("\n\t CM_MR_SetOccEff Inside T5_ArchModuleRevision........");fflush(stdout);

										  ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&archId);

										  printf("\n\t CM_MR_SetOccEff Architecture ID is := %s", archId);fflush(stdout); //ItemRevision

										  ifail = ITEM_find_item(objectId, &childObjTag);
										  
										  if((ArchAssyTag != NULLTAG) && (childObjTag != NULLTAG))
										  {
												POM_get_user(&username,&user_tag);
												SA_ask_user_identifier2	(user_tag,&userid)	;
												printf ("CM_MR_SetOccEff Logged in user:%s %s\n",userid,username);fflush(stdout);
												if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0 && tc_strcmp(userid,"infodba")!=0)
												{
													printf("\n******* CM_MR_SetOccEff Function Called  ********\n");fflush(stdout);
												  ifail = Create_MR_occurance_effectivity(ArchAssyTag, objectId, objectrevId);
												  break;
												}
										  }
									  }
								  }
							  }
						  }
						}
					}
				}
			}
		}
	}
	printf("\n CM_MR_SetOccEff Function end...");fflush(stdout);
	TC_write_syslog("\n CM_MR_SetOccEff Function end...");
	//return ifail;
	return 0;
		
}

int Create_MR_occurance_effectivity(tag_t primaryObj, char* objectId, char* objectrevId)
{
	int		ifail			= ITK_ok;
	int		iy				= 0;
	int		iz				= 0;
	int		bvr_count		= 0;
	int		n_occs			= 0;
	int		Item_count		= 0;
	int		effcnt			= 0;	

	tag_t	*bvrs;
	tag_t   *occsal;
	tag_t	ChildItem		= NULLTAG;
	tag_t	*rev_list		= NULLTAG;
	tag_t	bvr				= NULLTAG;
	tag_t	bvrchild		= NULLTAG;
	tag_t	*Effobbj		= NULLTAG;
	tag_t	EffecTag		= NULLTAG;

	char	*dataset_name1	= NULL;
	char	*t5Des_Rev		= NULL;

	date_t	date_end		= NULLDATE;
	
	date_t dcreation_date;
	char* ccreation_date	= NULL;
	char* end_date			= NULL;
	ccreation_date = malloc(30 * sizeof (char *) );
	end_date = malloc(30 * sizeof (char *) );

	char* Effecsta			 = NULL;
	char* EffecEnd			 = NULL;

	char EffecRange[200];
	char EffecName[200];
	
	int i_ChildCount		 = 0;
	int iChldPrts			 = 0;
	int uidType				 = 0;
	int Uidlatest            = 0;
	int strcnt1            = 0;
	tag_t  t_BomLineWindow	 = NULLTAG;
	tag_t  t_Rule			 = NULLTAG;
	tag_t  t_TopLine		 = NULLTAG;
	tag_t  *t_PartChildren	 = NULLTAG;
	tag_t  t_Childobject	 = NULLTAG;
	char   *Child_SeqId		 = NULL;
	char   **ChildUID		 = NULL;
	char   *child_Uid   	 = NULL;

	printf("\n Create_MR_occurance_effectivity Function started...");fflush(stdout);
	TC_write_syslog("\n Create_MR_occurance_effectivity Function started...");
	ifail = ITK_string_to_date("31-Dec-2099 00:00", &date_end);

	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);
	printf("\n CM_MR_SetOccEff bvr count is...%d",bvr_count);fflush(stdout);
	if (bvr_count)
	{
		bvr = bvrs[0];
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
		printf("\n CM_MR_SetOccEff n_occs count is...%d",n_occs);fflush(stdout);
		for (iy = 0; iy<n_occs; iy++)
		{
			ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

			if (ChildItem)
			{
				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

				
				ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);

				if(Item_count > 0)
				{
					for (iz = 0; iz<Item_count; iz++)
					{
						ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
						printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);

						if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
						{
						  tc_strcpy(EffecName,"");
						  tc_strcat(EffecName,dataset_name1);
						  tc_strcat(EffecName,"_");
						  tc_strcat(EffecName,t5Des_Rev);

						  printf("\n CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);

						  ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
						  ITK_date_to_string(dcreation_date, &ccreation_date);
						  ITK_date_to_string(date_end, &end_date);
						  printf("\n\t CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
						  printf("\n\t CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);

						    Effecsta=subString(ccreation_date,0,11);
							EffecEnd=subString(end_date,0,11);

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,Effecsta);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EffecEnd);

							printf("\n CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

							ifail =  AOM_lock( bvr );

							ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

							printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
							if (effcnt == 0)
							{
								ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

								if (EffecTag)
								{
									printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

									ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

									ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange,FALSE);

									ifail = AOM_save_without_extensions(EffecTag);
									ifail = AOM_refresh(EffecTag, 0);

									//ifail = AOM_refresh(bvr, 1);
									ifail = AOM_save_without_extensions(bvr);
									ifail = AOM_unlock( bvr );
									//ifail = AOM_refresh(bvr, 0);

//									ifail = AOM_refresh(primaryObj, 1);
//									ifail = AOM_save_without_extensions(primaryObj);
//									ifail = AOM_unlock( primaryObj );
//									ifail = AOM_refresh(primaryObj, 0);
								}
							}
						}
					}
				}
			}
		}
	}

	ifail = BOM_create_window (&t_BomLineWindow);
		ifail = CFM_find("Latest Working", &t_Rule );
		ifail = BOM_set_window_config_rule( t_BomLineWindow, t_Rule );
		ifail = BOM_set_window_pack_all (t_BomLineWindow, false);
		ifail = BOM_set_window_top_line (t_BomLineWindow,NULLTAG,primaryObj, null_tag, &t_TopLine);

		//ifail = BOM_set_window_top_line_bvr(t_BomLineWindow,bvr,&t_TopLine);

		ifail = BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren);
		printf("\n CM_MR_SetOccEff Total Child Parts Found in BomLine are [%d]\n",i_ChildCount);fflush(stdout);

		if (i_ChildCount>0)
		{
			for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
			{
				t_Childobject=t_PartChildren[iChldPrts];

				if(AOM_ask_value_string(t_Childobject, "bl_item_item_id", &Child_SeqId));

				if	(tc_strcmp(Child_SeqId,objectId)==0)
				{
					
					if( AOM_ask_displayable_values(t_Childobject,"bl_occurrence_uid",&strcnt1,&ChildUID))PrintErrorStack();
					printf("\n CM_MR_SetOccEff ChildUID ======>>> %s \n",ChildUID);fflush(stdout);
					
					if(strcnt1>0)
					{
					ifail = AOM_lock( primaryObj );
					ifail = AOM_lock( t_Childobject );

					if(AOM_UIF_set_value(t_Childobject,"bl_occ_t5_uidsap",ChildUID[0]));
					
//					ifail = AOM_save_without_extensions(bvr);
//					ifail = AOM_refresh(bvr,1);
//					ifail = AOM_unlock( bvr );

					ifail = AOM_refresh(t_Childobject, 1);
					ifail = AOM_save_without_extensions(t_Childobject);
					ifail = AOM_unlock( t_Childobject );
					ifail = AOM_refresh(t_Childobject, 0);

					ifail = AOM_refresh(primaryObj, 1);
					ifail = AOM_save_without_extensions(primaryObj);
					ifail = AOM_unlock( primaryObj );
					ifail = AOM_refresh(primaryObj, 0);
					}
				}
			}
		}
	printf("\n Create_MR_occurance_effectivity Function end...");fflush(stdout);
	TC_write_syslog("\n Create_MR_occurance_effectivity Function end...");
	//MEM_free(bvrs);
	//MEM_free(EffecName);
	//MEM_free(EffecRange);
	return ifail;
}
