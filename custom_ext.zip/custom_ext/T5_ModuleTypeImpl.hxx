//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_ModuleTypeImpl
//

#ifndef TRL001__T5_MODULETYPEIMPL_HXX
#define TRL001__T5_MODULETYPEIMPL_HXX

#include <T5_newpartreq/T5_ModuleTypeGenImpl.hxx>

#include <T5_newpartreq/libt5_newpartreq_exports.h>


namespace TRL001
{
    class T5_ModuleTypeImpl; 
    class T5_ModuleTypeDelegate;
}

class  T5_NEWPARTREQ_API TRL001::T5_ModuleTypeImpl
    : public TRL001::T5_ModuleTypeGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_ModuleType
    explicit T5_ModuleTypeImpl( T5_ModuleType& busObj );

    ///
    /// Destructor
    virtual ~T5_ModuleTypeImpl();

private:
    ///
    /// Default Constructor for the class
    T5_ModuleTypeImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_ModuleTypeImpl( const T5_ModuleTypeImpl& );

    ///
    /// Copy constructor
    T5_ModuleTypeImpl& operator=( const T5_ModuleTypeImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_ModuleTypeDelegate;

};

#include <T5_newpartreq/libt5_newpartreq_undef.h>
#endif // TRL001__T5_MODULETYPEIMPL_HXX
