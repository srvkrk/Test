#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;
int cntSVRFlag = 0;


#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

/*
Deprecated api changes 14.3 (Sachin)
CR_create_release_status -->RELSTAT_create_release_status
EPM_add_release_status--> RELSTAT_add_release_status
QRY_find--> QRY_find2
TCTYPE_ask_name--> TCTYPE_ask_name2
AOM_save--> AOM_save_without_extensions
*/

void  GetPlantWiseRelStatPE( char * PLT_Code ,char * controlinfo,char  getLCS[40])
{	  

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 
	 char *controlinfolcs			= NULL;
	 

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="PEReleasestaus";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], controlinfo, &controlinfolcs);
				printf("\n controlinfolcs: %s\n",controlinfolcs);fflush(stdout);
				tc_strcpy(getLCS,controlinfolcs);
              
			}
			else
			{
				tc_strcpy(getLCS,"T5_LcsAPLpWrkg");
			}



	printf( "control info:%s and getLCS: %s\n",controlinfo, getLCS);

}



extern EPM_decision_t DLLAPI PEToolIndent_Signoff_Validation(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	int attchcount = 0;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Numofdummy = NULL;
    char *itemid = NULL;
	char *Tooltype = NULL;
    char *PELOB = NULL;
	
	tag_t * indenttagattch;
	int i = 0;
	int				n_found1			=	0;
	int				dmmyPartCnt1			=	0;
	int				PEPartCnt1			=	0;
	tag_t	        queryTag1	=	NULLTAG;
	tag_t	      *PEPartTags1				=	NULLTAG;
	tag_t	      *dmmyPartTags1				=	NULLTAG;
	tag_t         *Indentobj1 = NULLTAG;
	tag_t			Indenttag			= NULLTAG;

	printf("\n Calling PEToolIndent_Signoff_Validation %d.....\n",attchcount);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n PEToolIndent_Signoff_Validation \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &attchcount, &indenttagattch) );

	printf("\n attchcount %d.....\n",attchcount);
	
	ITKCALL(AOM_ask_value_string(indenttagattch[i],"t5_LOBOfPE",&PELOB));
	printf("\nPE LOB is: %s",PELOB);

  if((tc_strcmp(PELOB,"MPS-Metal Pattern Shop")==0) || (tc_strcmp(PELOB,"CTED-Central Tool Engineering Department")==0) || (tc_strcmp(PELOB,"CJFD-Central Jigs and Fixture design")==0))
  {	
	
	
	if((tc_strcmp(CurrentTask,"Generation of Dummy Tool")==0) || (tc_strcmp(CurrentTask,"Add PE Part to Indent By APLPlanner")==0) || (tc_strcmp(CurrentTask,"Add Actual and Dummy Tool to Indent")==0))
	{	
        char        *Indenthasdumy       = NULL;
		
	    for (i=0; i < attchcount; i++)
	    {

		  ITKCALL(AOM_ask_value_string(indenttagattch[i], "item_id",&itemid));
		  printf("\n indent id %s.....\n",itemid);
						
				
			
					   ITKCALL(QRY_find2("Item Revision...", &queryTag1));
				 
					   char
						*qry_entry[2] = {"Item ID", "Type"},
						*qry_vall[2] =  {itemid,"PE Tool Indent Revision"};
								 
					   ITKCALL(QRY_execute(queryTag1, 2, qry_entry, qry_vall, &n_found1, &Indentobj1));
					   printf("\n\t\t Indent tcnt : %d",n_found1); fflush(stdout);
					   if(n_found1>0)
					   {
						Indenttag=Indentobj1[0];
					   }
					  
                      ITKCALL(AOM_ask_value_string(Indenttag,"t5_ToolType",&Tooltype));
					  					 
				if((tc_strcmp(Tooltype,"NEW")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
				  ITKCALL(AOM_ask_value_string(Indenttag,"t5_NoofDmyToolbyPE",&Numofdummy));
				  printf("\nNumofdummy is: %s",Numofdummy);
				 
				 
						if(tc_strcmp(Numofdummy,"")==0)
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"No of Dummy Tool Required field for Indent is NULL. Please enter the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Update No of PE Dummy Tool Required");
						    decision = EPM_nogo;
						    return decision;
	
						}

				}		
						
				if(tc_strcmp(Tooltype,"NEW")==0)
				{	
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);				    
						
					if(dmmyPartCnt1==0)
					{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Dummy tool not generated. Please generate dummy tool using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Generation Of Dummy Tool and Update");
						    decision = EPM_nogo;
						    return decision;
	
					}
                }
				
				if((tc_strcmp(Tooltype,"OLD")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndentToPEPrtRel1",&PEPartCnt1,&PEPartTags1));
					printf("\n\n\t\t Dummy PEPartCnt1:%d",PEPartCnt1);fflush(stdout);
				
					if(PEPartCnt1==0)
					{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PE Part not present on indent. Please add PE Part using copy paste option.");
						    decision = EPM_nogo;
						    return decision;
	
					}
                }
				
				if(tc_strcmp(Tooltype,"MIX")==0)
				{	
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);
				
					if(dmmyPartCnt1==0)
					{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Dummy tool not generated. Please generate dummy tool using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Add Actual and Dummy Tool to Indent");
						    decision = EPM_nogo;
						    return decision;
	
					}
                }
				
				
				if(tc_strcmp(Tooltype,"OLD")==0)
				{
                  int			PEPartCnt1			=	0;					
                  tag_t	      *PEPartTags1	=	NULLTAG;
				  char        *PE_id1       = NULL;
				  tag_t         PETag = NULLTAG;
				  char        *apldesc       = NULL;
				  char        *assetno       = NULL;
				  char        *serialno       = NULL;
				  char        *pewrkordr       = NULL;
				  int k1=0;
				  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndentToPEPrtRel1",&PEPartCnt1,&PEPartTags1));
					printf("\n\n\t\t PEPartCnt1:%d",PEPartCnt1);fflush(stdout);
					if (PEPartCnt1>0)
					{
						for (k1=0;k1<PEPartCnt1 ;k1++ )
						{	
							PE_id1=NULL;
							PETag = NULLTAG;
							PETag=PEPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(PETag, "item_id", &PE_id1));
                            printf("\n PE id is =:%s",PE_id1);fflush(stdout);
							
								if(PETag != NULLTAG)
							    {								
									
			                      printf("\n  inside loop PE part\n");fflush(stdout);								  
								  ITKCALL(AOM_ask_value_string(PETag,"object_desc",&apldesc));
								  ITKCALL(AOM_ask_value_string(PETag,"t5_PAssetNo",&assetno));
								  ITKCALL(AOM_ask_value_string(PETag,"t5_SerialNo",&serialno));
								  ITKCALL(AOM_ask_value_string(PETag,"t5_PeModWrkOrdr",&pewrkordr));								 

                                   printf("\n  inside loop end\n");fflush(stdout);
							    }
								
								printf("\n apldesc:%d  assetno:%s  serialno:%s  pewrkordr:%s ",apldesc,assetno,serialno,pewrkordr);fflush(stdout);
								

						}
					}
							
				
					    if((tc_strlen(assetno)==0) || (tc_strlen(apldesc)==0) || (tc_strlen(serialno)==0) || (tc_strlen(pewrkordr)==0))
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"APL Tool Desc/Asset Number/Equipment Serial No/Parent Work Order field for PE Part is NULL. Please enter the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Add PE Part to Indent By APLPlanner");
						    decision = EPM_nogo;
						    return decision;
	
						}
                }
								
				

	   }

	}	
	
	if(tc_strcmp(CurrentTask,"Update of Tool Cost and PE Operation")==0)
	{	
			int				n_found1			=	0;
			int				k1			        =	0;
			int				dmmyPartCnt1			=	0;
			int				PEPartCnt1			=	0;
			char        *dummy_id1       = NULL;
			char        *PE_id1       = NULL;
			tag_t	        queryTag1	=	NULLTAG;
			tag_t			Indenttag1			= NULLTAG;
			tag_t			Dummytag			= NULLTAG;
			tag_t         IndentDummy_rel_type = NULLTAG;
			tag_t         IndentPE_rel_type = NULLTAG;
			tag_t         IndentDummy_rel = NULLTAG;
			tag_t         IndentPE_rel = NULLTAG;
			tag_t         dmmyTag = NULLTAG;
			tag_t         PETag = NULLTAG;
			tag_t	      *dmmyPartTags1	=	NULLTAG;
			tag_t	      *PEPartTags1	=	NULLTAG;
			tag_t         *Indentobj1 = NULLTAG;
			tag_t			Indenttag			= NULLTAG;
			char		*peoperatn       = NULL;
			char		*peestcost          = NULL;
			char        *Designcost       = NULL;
			char        *Manufactcost       = NULL;
			char        *Totlestcost       = NULL;
			char        *dummyopertion       = NULL;
			char        *Tooltype       = NULL;
            int				ordrqty			=	0;
	
	    for (i=0; i < attchcount; i++)
	    {

		 ITKCALL(AOM_ask_value_string(indenttagattch[i], "item_id",&itemid));
		 printf("\n indent id %s.....\n",itemid);
		 
		      	 ITKCALL(QRY_find2("Item Revision...", &queryTag1));
				 
	       char
	        *qry_entry[2] = {"Item ID", "Type"},
	        *qry_vall[2] =  {itemid,"PE Tool Indent Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag1, 2, qry_entry, qry_vall, &n_found1, &Indentobj1));
	       printf("\n\t\t Indent tcnt : %d",n_found1); fflush(stdout);
           if(n_found1>0)
	       {
            Indenttag=Indentobj1[0];
	       }	      	
				ITKCALL(AOM_ask_value_string(Indenttag,"t5_ToolType",&Tooltype));
				if((tc_strcmp(Tooltype,"NEW")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
                  GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&IndentDummy_rel_type);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);
					if (dmmyPartCnt1>0)
					{
						for (k1=0;k1<dmmyPartCnt1 ;k1++ )
						{	
							dummy_id1=NULL;
							dmmyTag = NULLTAG;
							dmmyTag=dmmyPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(dmmyTag, "item_id", &dummy_id1));
                            printf("\n dummy id is =:%s",dummy_id1);fflush(stdout);
							
								if(Indenttag != NULLTAG && dmmyTag != NULLTAG && IndentDummy_rel_type != NULLTAG)
							    {
									printf("\n  inside loop check\n");fflush(stdout);
									
								  ITKCALL(GRM_find_relation(Indenttag,dmmyTag,IndentDummy_rel_type,&IndentDummy_rel));
			                      printf("\n  inside loop check1111111\n");fflush(stdout);
								  ITKCALL(AOM_ask_value_int(IndentDummy_rel,"t5_OrdQty1",&ordrqty));
								  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_DToolDesignCost",&Designcost));
								  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_DToolManuCost",&Manufactcost));
								  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_PETotalTLCost",&Totlestcost));
								  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_OprN",&peoperatn));								 
                                  ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_CstEst",&peestcost));
                                   printf("\n  inside loop end\n");fflush(stdout);
							    }
								
								printf("\n ordrqty:%d  Designcost:%s  Manufactcost:%s  Totlestcost:%s peoperatn:%s peestcost:%s",ordrqty,Designcost,Manufactcost,Totlestcost,peoperatn,peestcost);fflush(stdout);
								

						}
					}
							
				
					    if((ordrqty==0) || (tc_strlen(Designcost)==0) || (tc_strlen(Manufactcost)==0) || (tc_strlen(Totlestcost)==0) || (tc_strlen(peoperatn)==0) || (tc_strlen(peestcost)==0))
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Design Cost/Manufacturing Cost/Total Estimate Cost/Total Tool Cost/Dummy Operation field for dummy tool is NULL. Please enter the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Update of Tool Cost and PE Operation");
						    decision = EPM_nogo;
						    return decision;
	
						}
                }
				
				if((tc_strcmp(Tooltype,"OLD")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
                  GRM_find_relation_type("T5_PEToolIndentToPEPrtRel1",&IndentPE_rel_type);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndentToPEPrtRel1",&PEPartCnt1,&PEPartTags1));
					printf("\n\n\t\t Dummy PEPartCnt1:%d",PEPartCnt1);fflush(stdout);
					if (PEPartCnt1>0)
					{
						for (k1=0;k1<PEPartCnt1 ;k1++ )
						{	
							PE_id1=NULL;
							PETag = NULLTAG;
							PETag=PEPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(PETag, "item_id", &PE_id1));
                            printf("\n dummy id is =:%s",PE_id1);fflush(stdout);
							
								if(Indenttag != NULLTAG && PETag != NULLTAG && IndentPE_rel_type != NULLTAG)
							    {								
									
								  ITKCALL(GRM_find_relation(Indenttag,PETag,IndentPE_rel_type,&IndentPE_rel));
			                      printf("\n  inside loop PE part\n");fflush(stdout);
								  ITKCALL(AOM_ask_value_int(IndentPE_rel,"t5_OrdQty1",&ordrqty));
								  ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_PePartDesignCost",&Designcost));
								  ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_PePartManCost",&Manufactcost));
								  ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_PETotalTLCost",&Totlestcost));
								  ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_OprN",&peoperatn));								 
                                  ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_CstEst",&peestcost));
                                   printf("\n  inside loop end\n");fflush(stdout);
							    }
								
								printf("\n ordrqty:%d  Designcost:%s  Manufactcost:%s  Totlestcost:%s peoperatn:%s peestcost:%s",ordrqty,Designcost,Manufactcost,Totlestcost,peoperatn,peestcost);fflush(stdout);
								

						}
					}
							
				
					    if((ordrqty==0) || (tc_strlen(Designcost)==0) || (tc_strlen(Manufactcost)==0) || (tc_strlen(Totlestcost)==0) || (tc_strlen(peoperatn)==0) || (tc_strlen(peestcost)==0))
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Design Cost/Manufacturing Cost/Total Estimate Cost/Total Tool Cost/Dummy Operation field for dummy tool is NULL. Please enter the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Update of Tool Cost and PE Operation");
						    decision = EPM_nogo;
						    return decision;
	
						}
                }

	   }

	}
	
	if(tc_strcmp(CurrentTask,"APL Review of Cost Estimate")==0)
	{	
        char        *npiproj       = NULL;
		char        *wbsno       = NULL;
		
	    for (i=0; i < attchcount; i++)
	    {

		   ITKCALL(AOM_ask_value_string(indenttagattch[i], "item_id",&itemid));
		   printf("\n indent id %s.....\n",itemid);
				
			     ITKCALL(AOM_ask_value_string(indenttagattch[i],"t5_NPIPJ",&npiproj));
				 printf("\npiproj : %s",npiproj);
				 
				 ITKCALL(AOM_ask_value_string(indenttagattch[i],"t5_PeWbsNo",&wbsno));
				 printf("\nwbsno : %s",wbsno);

				
					   if((tc_strlen(npiproj)==0)&&(tc_strlen(wbsno)==0))
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"NPI Project code/WBS No field for Indent is NULL. Please update the values using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->APL Review of Cost Estimate");
						    decision = EPM_nogo;
						    return decision;
	
						}


	   }

	}
	
	if(tc_strcmp(CurrentTask,"Assign WorkOrder by PE Planner")==0)
	{	
			int				n_found1			=	0;
			int				k1			        =	0;
			int				dmmyPartCnt1			=	0;
			int				PEPartCnt1			=	0;
			char        *dummy_id1       = NULL;
			char        *PE_id1       = NULL;
			tag_t	        queryTag1	=	NULLTAG;
			tag_t			Indenttag1			= NULLTAG;
			tag_t			Dummytag			= NULLTAG;
			tag_t         IndentDummy_rel_type = NULLTAG;
			tag_t         IndentPE_rel_type = NULLTAG;
			tag_t         IndentDummy_rel = NULLTAG;
			tag_t         IndentPE_rel = NULLTAG;
			tag_t         dmmyTag = NULLTAG;
			tag_t         PETag = NULLTAG;
			tag_t	      *dmmyPartTags1	=	NULLTAG;
			tag_t	      *PEPartTags1	=	NULLTAG;
			tag_t         *Indentobj1 = NULLTAG;
			tag_t			Indenttag			= NULLTAG;

			char        *workorder       = NULL;
			char        *workorderPE       = NULL;
            char        *Tooltype       = NULL;
	
	    for (i=0; i < attchcount; i++)
	    {

		 ITKCALL(AOM_ask_value_string(indenttagattch[i], "item_id",&itemid));
		 printf("\n indent id %s.....\n",itemid);
		 
		      	 ITKCALL(QRY_find2("Item Revision...", &queryTag1));
				 
	       char
	        *qry_entry[2] = {"Item ID", "Type"},
	        *qry_vall[2] =  {itemid,"PE Tool Indent Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag1, 2, qry_entry, qry_vall, &n_found1, &Indentobj1));
	       printf("\n\t\t Indent tcnt : %d",n_found1); fflush(stdout);
           if(n_found1>0)
	       {
            Indenttag=Indentobj1[0];
	       }	      	
				ITKCALL(AOM_ask_value_string(Indenttag,"t5_ToolType",&Tooltype));
				if((tc_strcmp(Tooltype,"NEW")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
                  GRM_find_relation_type("T5_PEToolIndentToDmyToolRel",&IndentDummy_rel_type);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndentToDmyToolRel",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);
					if (dmmyPartCnt1>0)
					{
						for (k1=0;k1<dmmyPartCnt1 ;k1++ )
						{	
							dummy_id1=NULL;
							dmmyTag=dmmyPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(dmmyTag, "item_id", &dummy_id1));
                            printf("\n\n\t\t dummy id is =:%s",dummy_id1);fflush(stdout);
						
							
								if(Indenttag != NULLTAG && dmmyTag != NULLTAG && IndentDummy_rel_type != NULLTAG)
							    {
								  ITKCALL(GRM_find_relation(Indenttag,dmmyTag,IndentDummy_rel_type,&IndentDummy_rel));
			                      ITKCALL(AOM_ask_value_string(IndentDummy_rel,"t5_APLWONo",&workorder));

							    }
								
								printf("\n workorder:%s ",workorder);fflush(stdout);
								

						}
					}
							
				
					    if(tc_strlen(workorder)==0)
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Work Order field for dummy tool is NULL. Please update the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Assign WorkOrder by PE Planner");
						    decision = EPM_nogo;
						    return decision;
	
						}
                }
				
				if((tc_strcmp(Tooltype,"OLD")==0)|| (tc_strcmp(Tooltype,"MIX")==0))
				{	
                  GRM_find_relation_type("T5_PEToolIndentToPEPrtRel",&IndentPE_rel_type);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndentToPEPrtRel",&PEPartCnt1,&PEPartTags1));
					printf("\n\n\t\t PEPartCnt1 is:%d",PEPartCnt1);fflush(stdout);
					if (PEPartCnt1>0)
					{
						for (k1=0;k1<PEPartCnt1 ;k1++ )
						{	
							PE_id1=NULL;
							PETag=PEPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(PETag, "item_id", &PE_id1));
                            printf("\n\n\t\t dummy id is =:%s",PE_id1);fflush(stdout);
						
							
								if(Indenttag != NULLTAG && PETag != NULLTAG && IndentPE_rel_type != NULLTAG)
							    {
								  ITKCALL(GRM_find_relation(Indenttag,PETag,IndentPE_rel_type,&IndentPE_rel));
			                      ITKCALL(AOM_ask_value_string(IndentPE_rel,"t5_APLWONo",&workorderPE));

							    }
								
								printf("\n workorderPE:%s ",workorderPE);fflush(stdout);
								

						}
					}
							
				
					    if(tc_strlen(workorderPE)==0)
						{
							printf("\n  under the error  statment\n");fflush(stdout);
                            EMH_clear_errors();
						    status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Work Order field for PE Part is NULL. Please update the value using below option. select the indent--> Goto-->Manufacturing-->PE-->PE Tool Indent-->Assign WorkOrder by PE Planner");
						    decision = EPM_nogo;
						    return decision;
	
						}
                }

	   }
	   
	}
  }
	decision = EPM_go;
	return decision;
}


int PEReleaseStatusStamp( EPM_action_message_t msg )
{

	int		status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;

	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int error_code	= ITK_ok;
	tag_t objTypeTag=NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *Indentplant 	   = NULL;
	int	  noAttachment = 0;
	tag_t IndentTag = NULLTAG;

	int              st_count1 = 0;
	int              cnt = 0;
	int              LCSFlag = 0;
    int cunt1 = 0;
	tag_t*    status_list1=NULLTAG;
    tag_t*		attr_tags_checkin		=	NULLTAG;
	
	char   *ReleaseStatus=NULL;
	char *WSO_Name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char*   type_name = NULL;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
    int n_values_checkin = 0;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	tag_t		class_id				=     NULLTAG;
	char *Release_Status = NULL;
	logical			log1;
	char			*class_name					= NULL;
		
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside PEReleaseStatusStamp***************\n ");fflush(stdout);


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n PEReleaseStatusStamp \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n 1 CurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n 1 Parent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf(" 1 Target Attachment:%d\n",noAttachment);fflush(stdout);

	 if(noAttachment > 0)
	 {
		IndentTag = attachments[0];
		if(TCTYPE_ask_object_type(IndentTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n   1  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	
      if((tc_strcmp(CurrentTask,"Generation of Dummy Tool")==0) || (tc_strcmp(CurrentTask,"Add PE Part to Indent By APLPlanner")==0) || (tc_strcmp(CurrentTask,"Add Actual and Dummy Tool to Indent")==0))
      {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);

			char LcsaplWrkg[40];
			char *Controlinfo 	   = "t5_Userinfo1";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,LcsaplWrkg);
			printf("\n 1 LcsaplWrkg: %s \n",LcsaplWrkg);fflush(stdout);

			strcpy(lcsToset,LcsaplWrkg);					
				
			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,LcsaplWrkg)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
     }
	 
      if(tc_strcmp(CurrentTask,"Update of Tool Cost and PE Operation")==0)
      {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsAPLWrkg_1")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char LcsPElWrkg[40];
			char *Controlinfo 	   = "t5_Userinfo2";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,LcsPElWrkg);
			printf("\n 1 LcsPElWrkg: %s \n",LcsPElWrkg);fflush(stdout);

			strcpy(lcsToset,LcsPElWrkg);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,LcsPElWrkg)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
        
	 }	  
        if(tc_strcmp(CurrentTask,"Review Estimated Cost")==0)
        {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsPEWrkg_1")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char Lcscostest[40];
			char *Controlinfo 	   = "t5_Userinfo3";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,Lcscostest);
			printf("\n 1 Lcscostest: %s \n",Lcscostest);fflush(stdout);

			strcpy(lcsToset,Lcscostest);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,Lcscostest)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
     }	 
      if(tc_strcmp(CurrentTask,"APL Review of Cost Estimate")==0)
      {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsEstimated")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char Lcscostest[40];
			char *Controlinfo 	   = "t5_Userinfo4";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,Lcscostest);
			printf("\n 1 Lcscostest: %s \n",Lcscostest);fflush(stdout);

			strcpy(lcsToset,Lcscostest);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,Lcscostest)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
       }
	   
        if(tc_strcmp(CurrentTask,"APLGrpLead Approval of Estimated Cost")==0)
        {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsAplRew")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char Lcscostest[40];
			char *Controlinfo 	   = "t5_Userinfo5";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,Lcscostest);
			printf("\n 1 Lcscostest: %s \n",Lcscostest);fflush(stdout);

			strcpy(lcsToset,Lcscostest);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,Lcscostest)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
       }
	   
       if(tc_strcmp(CurrentTask,"Assign WorkOrder by PE Planner")==0)
       {
			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsEstApp")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char Lcscostest[40];
			char *Controlinfo 	   = "t5_Userinfo6";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,Lcscostest);
			printf("\n 1 Lcscostest: %s \n",Lcscostest);fflush(stdout);

			strcpy(lcsToset,Lcscostest);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,Lcscostest)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
       
	   
        }
	 		 
	}
	
	return error_code;

}

int PERlzStamp( EPM_action_message_t msg )
{

	int		status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;

	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int error_code	= ITK_ok;
	tag_t objTypeTag=NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *Indentplant 	   = NULL;
	int	  noAttachment = 0;
	tag_t IndentTag = NULLTAG;

	int              st_count1 = 0;
	int              cnt = 0;
	int              LCSFlag = 0;
    int cunt1 = 0;
	tag_t*    status_list1=NULLTAG;
    tag_t*		attr_tags_checkin		=	NULLTAG;
	
	char   *ReleaseStatus=NULL;
	char *WSO_Name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char*   type_name = NULL;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
    int n_values_checkin = 0;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	tag_t		class_id				=     NULLTAG;
	char *Release_Status = NULL;
	logical			log1;
	char			*class_name					= NULL;
		
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside PEReleaseStatusStamp***************\n ");fflush(stdout);


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n PEReleaseStatusStamp \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n 1 CurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n 1 Parent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf(" 1 Target Attachment:%d\n",noAttachment);fflush(stdout);

	 if(noAttachment > 0)
	 {
		IndentTag = attachments[0];
		if(TCTYPE_ask_object_type(IndentTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n   1  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

			ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &itemid));
			ITKCALL(AOM_ask_value_string( IndentTag, "t5_ParentProductLine", &Indentplant));
			printf("\n 1 itemid:%s\n",itemid);fflush(stdout);
			
		    CALLAPI(POM_class_of_instance(IndentTag,&class_id));
		    CALLAPI(POM_name_of_class(class_id,&class_name));
		    printf("\n class_name is :%s\n",class_name);fflush(stdout);

		    CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		    CALLAPI(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
		    printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			CALLAPI( POM_length_of_attr(IndentTag, tReleaseStatusList_checkin, &n_values_checkin) );
			printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
			if(n_values_checkin>0)
			{
				CALLAPI( POM_ask_attr_tags(IndentTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
				printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
				
				for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
					if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				    printf("\n  Release_Status changes done: %s\n", Release_Status);fflush(stdout);
				   
						if( (tc_strcmp(Release_Status,"T5_LcsPLMRlzd")==0))
						{
							CALLAPI(POM_unload_instances (1,&IndentTag));
							CALLAPI(POM_load_instances(1,&IndentTag,class_id,1));
							CALLAPI(POM_is_loaded(IndentTag,&log1));

							CALLAPI(POM_remove_from_attr(1,&IndentTag,tReleaseStatusList_checkin,cunt1,1));
							printf("\n cunt is :%d\n",cunt1);fflush(stdout);

							CALLAPI(POM_save_instances(1,&IndentTag,1));

							CALLAPI(POM_refresh_instances(1,&IndentTag,class_id,2));

							CALLAPI(AOM_lock(IndentTag));

							CALLAPI(AOM_save_without_extensions(IndentTag));
							CALLAPI(AOM_refresh(IndentTag,1));
							CALLAPI(AOM_unlock(IndentTag));

						}


				}

			}	
			
			char Lcscostest[40];
			char *Controlinfo 	   = "t5_Userinfo7";
			GetPlantWiseRelStatPE(Indentplant,Controlinfo,Lcscostest);
			printf("\n 1 Lcscostest: %s \n",Lcscostest);fflush(stdout);

			strcpy(lcsToset,Lcscostest);


			if(strcmp(type_name,"T5_PEToolIndentRevision")==0)
			{
					printf("\n inside class T5_PEToolIndentRevision......\n");fflush(stdout);
					ITKCALL(AOM_ask_value_string( IndentTag, "item_id", &item_id));


					ITKCALL(WSOM_ask_release_status_list(IndentTag,&st_count1,&status_list1));
					printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

					if(st_count1>0)
					{
						for (cnt=0;cnt< st_count1;cnt++ )
						{
							WSO_Name=NULL;
							ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
							printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
							if(tc_strcmp(WSO_Name,"")!=0)
								{
									if (tc_strcmp(WSO_Name,Lcscostest)==0)
									{
										LCSFlag = 1;
									}
								}
						}
					}

					if(LCSFlag == 0)
					{
						CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
						CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
						printf("\n ******************* Indent ReleaseStatus : %s\n",ReleaseStatus);fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status2,1,&IndentTag,retain));
					}


			}
        
	 		 
	}
	
	return error_code;

}



extern int PE_Indent_handler_register(int *decision, va_list args)
{
    
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);

    if( ITK_ok == EPM_register_action_handler("PEReleaseStatusStamp", "", PEReleaseStatusStamp))
    {
		printf("\t\n Registered Action Handler PEReleaseStatusStamp\n");fflush(stdout);
    }else
    {
		printf("\t FAILED to register Action Handler PEReleaseStatusStamp\n");fflush(stdout);
    }
	
	if( ITK_ok == EPM_register_action_handler("PERlzStamp", "", PERlzStamp))
    {
		printf("\t\n Registered Action Handler PERlzStamp\n");fflush(stdout);
    }else
    {
		printf("\t FAILED to register Action Handler PERlzStamp\n");fflush(stdout);
    }
   
	if( ITK_ok == EPM_register_rule_handler ("PEToolIndent_Signoff_Validation","This Handler is used to display message",(EPM_rule_handler_t)PEToolIndent_Signoff_Validation)) 
	{
		printf("\t\n Registered Rule Handler PEToolIndent_Signoff_Validation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler PEToolIndent_Signoff_Validation\n");fflush(stdout);
	}
	

    return ITK_ok;
}

extern DLLAPI int tm_PEToolIndentvalidation_register_callbacks()
{
	 CUSTOM_register_exit("tm_PEToolIndentvalidation", "USER_init_module", (CUSTOM_EXIT_ftn_t)PE_Indent_handler_register);

     printf("\n registered function tm_PEToolIndentvalidation\n");	fflush(stdout);

	 return ( ITK_ok );
}