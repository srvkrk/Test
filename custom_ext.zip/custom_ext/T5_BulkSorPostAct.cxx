//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T5_BulkSorPostAct
 *
 */
#include <T5_tm_bulkPPPMPrjCodelib/T5_BulkSorPostAct.hxx>
//#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <tc/preferences.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include<iostream>
#include <res/res_itk.h>
#include <tccore/aom.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
//#ifdef LINUX
#include <unistd.h>	//dbk for linux
//#endif
#define ITK_err 919002
#define PLM_error1 (EMH_USER_error_base+26)
using namespace Teamcenter;
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error(const char* file, int line,const char* function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails); fflush(stdout);
		for (index = 0; index < n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]); fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line); fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char* time_stamp()
{

	char *timestamp = (char *)malloc(sizeof(char) * 30);
	time_t ltime;
	ltime=time(NULL);
	struct tm *tm_now;
	tm_now=localtime(&ltime);
	sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now->tm_year+1900, tm_now->tm_mon, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	//sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now.tm_year+1900, tm_now.tm_mon, tm_now.tm_mday, tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
	return timestamp;
}

int tm_check_info_control_object ( char *syscd, char *subsyscd, char *info1, char *info2 )
{
	int n_found = 0 ;
	int ifail = ITK_ok;
	int n_entries = 2 ;
	//char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	//char *qry_values[2] =  { syscd, subsyscd } ;

	char  *qry_entries[] = {(char *)"SYSCD",(char *)"SUBSYSCD"};
	char  *qry_values[] = {(char *)syscd,(char *)subsyscd};
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	char *l_info1 = NULL ;
	char *l_info2 = NULL ;

	ifail = ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ifail =  ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{
		ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
		tc_strcpy( info1, l_info1 );
		ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
		tc_strcpy( info2, l_info2 );

		TC_write_syslog ( "\ninfo1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	}

	return n_found ;
}


int tm_get_pppm_variant(tag_t objTag, char* dml_project_code, char* sor_t5_PPPMPrjCode_desc)
{
	char* username = NULL;
	int ifail = ITK_ok;
	tag_t user_tag = NULLTAG;
	char* userid = NULL;
	char fileName[200] = { 0 };
	char* timestamp = NULL;
	//char* var_cmd_to_execute = NULL;	//dbk
	char* command = NULL;
	//char command[512];
	FILE* file = NULL;
	//tag_t Currproj = NULLTAG;		//dbk
	//char* curr_proj_name = NULL;	//dbk
	char** variant_details = NULL;
	char** variant_details_read = NULL;
	int ij = 0;
	char line[250] = { 0 };
	char* sor_t5_PPPMPrjCode = NULL;
	int iIndex = 0;

	char* s_srl_no = NULL;
	char* s_volume_inf = NULL;
	char* s_var_id = NULL;
	char* s_location = NULL;
	char* s_var_name = NULL;

	int n_table_rows = 0;
	tag_t* table_rowsTag = NULLTAG;
	tag_t* table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	//const char* table_property_name = "t5_SORVar";
	const char* table_property_name = "t5_BSOR_VarTable";
	int num_rows_to_append = 0;
	char* sAutoSOR_CC_path = NULL;
	char hostbuffer[256];

	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char* tcua_uname = NULL;
	char* tcua_pf_file = NULL;
	char* info2 = NULL;
	char* info22 = NULL;
	char* shell_path = NULL;
	char* pppm_file_path = NULL;

	//host_tcua(hostbuffer);

	printf("\nhostbuffer : %s", hostbuffer);

	tcua_uname = (char*)MEM_alloc(50 * sizeof(char));
	tcua_pf_file = (char*)MEM_alloc(200 * sizeof(char));
	pppm_file_path = (char*)MEM_alloc(200 * sizeof(char));
	shell_path = (char*)MEM_alloc(200 * sizeof(char));
	info2 = (char*)MEM_alloc(200 * sizeof(char));
	info22 = (char*)MEM_alloc(200 * sizeof(char));

	n_found_SOR_PF_info = tm_check_info_control_object((char *) "AUTOSOR_PWFILE", (char *) "PATH", tcua_uname, tcua_pf_file);
	if (n_found_SOR_PF_info < 0)
	{
		TC_write_syslog("\nCreate hostname username and password file control object for host : %s", hostbuffer);
		return 0;
	}

	printf("\nhostbuffer : %s", hostbuffer);

	TC_write_syslog("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc before : [%s]", sor_t5_PPPMPrjCode_desc);


	if (tc_strcmp(sor_t5_PPPMPrjCode_desc, "") == 0)
	{
		printf("\ntm_get_pppm_variant: sor_t5_PPPMPrjCode_desc is null select from drop down"); fflush(stdout);
		TC_write_syslog("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc is null select from drop down");
		return -1;
	}

	ifail = (PREF_ask_char_value("AutoSOR_CC_path", 0, &sAutoSOR_CC_path));//preference
	//printf ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
	//TC_write_syslog ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;


	sor_t5_PPPMPrjCode = tc_strtok(sor_t5_PPPMPrjCode_desc, "$");

	printf("\ntm_get_pppm_variant : Project code after strtok : [%s]", sor_t5_PPPMPrjCode); fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant: sor_t5_PPPMPrjCode after strtok : [%s]", sor_t5_PPPMPrjCode);
	TC_write_syslog("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc after strtok : [%s]", sor_t5_PPPMPrjCode_desc);

	ifail = (POM_get_user(&username, &user_tag));
	ifail = (SA_ask_user_identifier2(user_tag, &userid));
	printf("\ntm_get_pppm_variant : Logged in user: [%s] [%s]", userid, username); fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant : Logged in user: [%s] [%s]", userid, username); fflush(stdout);

	n_found_SOR_PF_info = tm_check_info_control_object((char *)"AUTOSOR_PPPMFILE", (char *) "PPPM_CODE", pppm_file_path, info22);

	if (n_found_SOR_PF_info < 0)
	{
		TC_write_syslog("\nCreating PPPM code file on common location");
		return 0;
	}

	n_found_SOR_PF_info1 = tm_check_info_control_object((char *) "AUTOSOR_SHELL",(char *) "PPPM_CODE_VARIANT", shell_path, info2);

	if (n_found_SOR_PF_info1 < 0)
	{
		TC_write_syslog("\nexecuting shell for PPPM code info");
		return 0;
	}

	timestamp = time_stamp();
	sprintf(fileName, "/%s/pppm_var_%s_%s_%s.txt", pppm_file_path, userid, dml_project_code, timestamp);
	printf("\ntm_get_pppm_variant : fileName : [%s]", fileName); fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant : fileName : [%s]", fileName);
	command = (char*)MEM_alloc(500 * sizeof(char));
	//PPPMVariantInfo -u=infodba -p=infodba -d="2228" -m="M-L155.5-MHCV_PD-MHCV PRODUCTIONISED VC_TIPPER" -f="/tmp/a.txt"
	//sprintf ( var_cmd_to_execute, "/home/uadev/devgroups/dbk/PPPMProjectCodes_list/PPPMVariantInfo -d=\"%s\" -m=\"%s\" -f=\"%s\"", dml_project_code, sor_t5_PPPMPrjCode, fileName ) ;
	//sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
	//system( command );

//#ifdef LINUX
	if (access(shell_path, F_OK) == 0)
	{
		// file exists


		printf("\nshell_path : [%s]", shell_path);
		TC_write_syslog("\nshell_path : [%s]", shell_path);
		sprintf(command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"", shell_path, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file);
		system(command);
	}
	else
	{
		// file doesn't exist
		int tmp_n_found_SOR_PF_info1 = 0;
		char* shell_path_TMP_PATH = NULL;
		char* info2_TMP_PATH = NULL;


		shell_path_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));
		info2_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));

		tmp_n_found_SOR_PF_info1 = tm_check_info_control_object( (char *) "AUTOSOR_SHELL_TMP_PATH", (char *) "PPPM_CODE_VARIANT_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH);

		if (tmp_n_found_SOR_PF_info1 < 0)
		{
			TC_write_syslog("\nexecuting shell for PPPM code info");
			return 0;
		}
		printf("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
		TC_write_syslog("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
		//sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"",shell_path, curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
		sprintf(command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"", shell_path_TMP_PATH, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file);
		system(command);

	}
//#endif
	//printf("\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command); fflush(stdout);
	//TC_write_syslog("\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command);

	file = fopen(fileName, "r");

	if (!file)
	{
		printf("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName); fflush(stdout);
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName); fflush(stdout);
		return -1;
	}

	variant_details = (char**)MEM_alloc(200 * sizeof(char*));//no of project
	while (fgets(line, sizeof(line), file))
	{
		line[tc_strlen(line) - 2] = '\0';
		variant_details[ij] = (char*)MEM_alloc(200);	//project desc length
		tc_strcpy(variant_details[ij], line);
		printf("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%zd]", variant_details[ij], tc_strlen(variant_details[ij])); fflush(stdout);
		TC_write_syslog("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%zd]", variant_details[ij], tc_strlen(variant_details[ij])); fflush(stdout);
		ij = ij + 1;
	}
	fclose(file);

	printf("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij); fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij);

	//information same file read twice first for to count no of records

	file = fopen(fileName, "r");

	if (!file)
	{
		printf("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName); fflush(stdout);
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName); fflush(stdout);
		return -1;
	}

	//ifail = (AOM_ask_table_rows(objTag, "t5_SORVar", &n_table_rows, &table_rowsTag));
	ifail = (AOM_ask_table_rows(objTag, "t5_BSOR_VarTable", &n_table_rows, &table_rowsTag));
	printf("\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows);//need to delete old rows
	fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows);//need to delete old rows

	if (n_table_rows > 0)
	{

		TC_write_syslog("\ntm_get_pppm_variant : deleting old variant for PPPM project code selected \n");//need to delete old rows
		//ifail =  ( RES_checkout(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		//ifail = (AOM_lock(objTag));
		ifail = (AOM_refresh ( objTag,TRUE ) ); //lock
		//ifail = (AOM_delete_table_rows(objTag, "t5_SORVar", 0, n_table_rows));
		ifail = (AOM_delete_table_rows(objTag, "t5_BSOR_VarTable", 0, n_table_rows));

		ifail = (AOM_save_without_extensions(objTag));
		//ifail = (AOM_unlock(objTag));
		//ifail = (AOM_refresh(objTag, TRUE));
		ifail = ( AOM_refresh ( objTag,FALSE ) );//unlock

		TC_write_syslog("\ntm_get_pppm_variant : deleting old variant for previous PPPM project code completed... \n");//need to delete old rows

	}


	printf("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc);//need to delete old rows
	fflush(stdout);
	TC_write_syslog("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc);//need to delete old rows

	//if ( ( n_table_rows <= 0 ) && ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 ) )//no of rows are zero then only append
	if (tc_strcmp(sor_t5_PPPMPrjCode, "") != 0)//pppm project is not blank
	{
		num_rows_to_append = ij;
		//ifail =  ( RES_checkout(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		//ifail = (AOM_lock(objTag));
		ifail = (AOM_refresh ( objTag,TRUE ) );
		TC_write_syslog("\nquicksorobjTag locked BulkSOR Post Action");
		ifail = (AOM_append_table_rows(objTag, table_property_name, num_rows_to_append, &NewLevel, &table_rows1Tag));

		ITK_CALL (  AOM_save_without_extensions(objTag) ); //save
		TC_write_syslog("\nquicksorobjTag saved BulkSOR Post Action");
		ITK_CALL ( AOM_refresh ( objTag,FALSE ) );//unlock
		TC_write_syslog("\nquicksorobjTag unlocked BulkSOR Post Action");

		variant_details_read = (char**)MEM_alloc(200 * sizeof(char*));//no of project
		while (fgets(line, sizeof(line), file))
		{
			line[tc_strlen(line) - 2] = '\0';
			variant_details_read[iIndex] = (char*)MEM_alloc(200);	//project desc length
			tc_strcpy(variant_details_read[iIndex], line);
			//printf("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			//TC_write_syslog("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			variant_details_read[iIndex] = stripBlanks ( variant_details_read[iIndex] );

			TC_write_syslog("\ntm_get_quick_sor_pppm_variant : variant_details_read[iIndex] : [%s]",variant_details_read[iIndex]);

			s_srl_no = tc_strtok(variant_details_read[iIndex], "^");
			s_volume_inf = tc_strtok(NULL, "^");
			s_var_id = tc_strtok(NULL, "^");
			s_location = tc_strtok(NULL, "^");
			s_var_name = tc_strtok(NULL, "^");
			TC_write_syslog("\ntm_get_pppm_variant : s_srl_no : [%s]", s_srl_no);
			TC_write_syslog("\ntm_get_pppm_variant : s_volume_inf : [%s]", s_volume_inf);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_id : [%s]", s_var_id);
			TC_write_syslog("\ntm_get_pppm_variant : s_location : [%s]", s_location);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_name : [%s]\n", s_var_name);


			//ifail = (AOM_lock(table_rows1Tag[iIndex]));
			ifail = (AOM_refresh ( table_rows1Tag[iIndex],TRUE ));
			TC_write_syslog("\nquicksorobjTag table row locked BulkSOR Post Action");
			ifail = (AOM_set_value_string(table_rows1Tag[iIndex], "t5_BVariantID", s_var_id));
			ifail = (AOM_set_value_string(table_rows1Tag[iIndex], "t5_BVariantName", s_var_name));
			//ifail = (AOM_save(table_rows1Tag[iIndex]));
			ifail = (AOM_save_without_extensions ( table_rows1Tag[iIndex] ));
			TC_write_syslog("\nquicksorobjTag table row saved BulkSOR Post Action");
			//ifail = (AOM_unlock(table_rows1Tag[iIndex]));
			ifail = (AOM_refresh ( table_rows1Tag[iIndex],FALSE ));
			TC_write_syslog("\nquicksorobjTag table row unlocked BulkSOR Post Action");
			//ifail = (AOM_refresh(table_rows1Tag[iIndex], TRUE));
			iIndex = iIndex + 1;

		}
		fclose(file);

		//ifail = (AOM_save(objTag));
		//ifail = (AOM_save_without_extensions(objTag));
		//ifail = (AOM_unlock(objTag));
		//ifail = (AOM_refresh ( objTag,FALSE ));
		//ifail = (AOM_refresh(objTag, TRUE));

	}
	else
	{
		printf("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode is blank and no of table rows are zero");//need to delete old rows
		fflush(stdout);
		TC_write_syslog("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc is blank and no of table rows are zero ");//need to delete old rows

	}
	return (ITK_ok);
}



int BulkSOR_qSOR_Variant_set (tag_t BulkSor_tag)
{
	int ifail = ITK_ok;
	int qSORCount = 0;
	int i = 0;
	int Bulkn_table_rows = 0;
	int qn_table_rows = 0;
	int itable = 0;
	int NewLevel = 0;

	tag_t relation_type = NULLTAG;
	tag_t qSOR_tag = NULLTAG;
	tag_t *qSOR_Objects = NULLTAG;
	tag_t* Bulktable_rowsTag = NULLTAG;
	tag_t* qtable_rowsTag = NULLTAG;
	tag_t *qtable_rows1Tag = NULLTAG;

	char *s_var_id = NULL;
	char *s_var_name = NULL;
	char *table_property_name = (char *) "t5_qSORVar";
	
	ITK_CALL (GRM_find_relation_type("T5_Bulk_part_has_qSor",&relation_type));
	ITK_CALL (GRM_list_secondary_objects_only(BulkSor_tag,relation_type,&qSORCount,&qSOR_Objects));
	
	ITK_CALL (AOM_ask_table_rows(BulkSor_tag, "t5_BSOR_VarTable", &Bulkn_table_rows, &Bulktable_rowsTag));

	printf("\nAOM_ask_table_rows : Bulkn_table_rows %d \n", Bulkn_table_rows);
	TC_write_syslog("\nAOM_ask_table_rows : Bulkn_table_rows %d \n", Bulkn_table_rows);


	if (qSORCount > 0 )
	{

		for(i = 0 ; i < qSORCount ; i++ )
		{
			qSOR_tag = qSOR_Objects[i];
			
			if( Bulkn_table_rows > 0 )
			{
				//ITK_CALL ( AOM_ask_table_rows(qSOR_tag, "t5_qSORVar", &qn_table_rows, &qtable_rowsTag ) ) ;
				ITK_CALL ( AOM_ask_table_rows(qSOR_tag, "t5_qSORVar", &qn_table_rows, &qtable_rows1Tag ) ) ;//Shubham 12.09

				printf("\nBulkSOR_qSOR_Variant_set : qn_table_rows : [%d] \n", qn_table_rows);
				TC_write_syslog("\nBulkSOR_qSOR_Variant_set : qn_table_rows : [%d] \n", qn_table_rows);

				//ifail = (AOM_refresh(qSOR_tag,TRUE));
				if (qn_table_rows == 0)
				{
					NewLevel = 0 ;
					ITK_CALL ( AOM_refresh ( qSOR_tag, TRUE ) ) ;//Shubham 12.09
					ITK_CALL ( AOM_append_table_rows(qSOR_tag, table_property_name, Bulkn_table_rows, &NewLevel, &qtable_rows1Tag));
					ITK_CALL ( AOM_save_without_extensions ( qSOR_tag ) ) ;//Shubham 12.09
					ITK_CALL ( AOM_refresh ( qSOR_tag, FALSE ) ) ;//Shubham 12.09
				
				}

				for(itable=0 ; itable < Bulkn_table_rows ; itable++ )
				{
					ITK_CALL ( AOM_ask_value_string(Bulktable_rowsTag[itable], "t5_BVariantID", &s_var_id));
					ITK_CALL ( AOM_ask_value_string(Bulktable_rowsTag[itable], "t5_BVariantName", &s_var_name));

					printf("\nBulkSOR_qSOR_Variant_set : s_var_id : [%s] \n", s_var_id);
					printf("\nBulkSOR_qSOR_Variant_set : s_var_name : [%s] \n", s_var_name);

					TC_write_syslog("\nBulkSOR_qSOR_Variant_set : s_var_id : [%s] \n", s_var_id);
					TC_write_syslog("\nBulkSOR_qSOR_Variant_set : s_var_name : [%s] \n", s_var_name);

					
					ITK_CALL ( AOM_refresh ( qtable_rows1Tag[itable],TRUE ) );//lock
					TC_write_syslog("\nrefresh");
					printf("\nrefresh");
					ITK_CALL ( AOM_set_value_string ( qtable_rows1Tag[itable], "t5_qVariantId", s_var_id ) ) ;
					TC_write_syslog("\nAOM_set_value_string");
					printf("\nAOM_set_value_string");
					ITK_CALL ( AOM_set_value_string ( qtable_rows1Tag[itable], "t5_qVariant_Name", s_var_name ) ) ;
					TC_write_syslog("\nt5_VariantName");
					printf("\nt5_VariantName");
					ITK_CALL ( AOM_save_without_extensions ( qtable_rows1Tag[itable] ) );
					TC_write_syslog("\nAOM_save_without_extensions");
					printf("\nAOM_save_without_extensions");
					ITK_CALL ( AOM_refresh ( qtable_rows1Tag[itable],FALSE ) );//unlock
					TC_write_syslog("\ntable_rows1Tag[iIndex],FALSE");
					printf("\ntable_rows1Tag[iIndex],FALSE");
					

						
				}
			}
			
			ifail = (AOM_refresh(qSOR_tag,FALSE));
		}//for for quick sor objects
	}
	return 0;
}


int BulkSOR_qSOR_Rel_function (tag_t BulkSor_tag,char *BulkSor_name,char *partno,char *Rev,char *Seq)
{
	printf("\n....Inside BulkSOR_qSOR_Rel_function....");
	TC_write_syslog("\n....Inside BulkSOR_qSOR_Rel_function....");

	int ifail = ITK_ok;
	int n_entries = 2;
	int i = 0;
	int resultCount = 0;
	int SORCount = 0;

	char *SOR_object_type = NULL;
	char *SOR_no = NULL;
	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};

	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(5*sizeof(char));

	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);
	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;
	tag_t *SOR_Objects = NULLTAG;
	tag_t PartTag = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t SOR_Tag = NULLTAG;
	tag_t BulkRelationFind = NULLTAG;
	tag_t BulkSorRelTag = NULLTAG;
	tag_t *bulkSOR_Objects = NULLTAG;
	int bulk_sor_rel_count = 0;

	printf("\nBulkSOR_qSOR_Rel_function Querying Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);
	TC_write_syslog("\nBulkSOR_qSOR_Rel_function Querying Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		printf("\nBulkSOR_qSOR_Rel_function Unique RevSeq Query found");
		TC_write_syslog("\nBulkSOR_qSOR_Rel_function Unique RevSeq Query found");

		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

		printf("\nBulkSOR_qSOR_Rel_function Part Count in TCUA : [%d]",resultCount);
		TC_write_syslog("\nBulkSOR_qSOR_Rel_function Part Count in TCUA : [%d]",resultCount);

		if ( resultCount > 0 )
		{

			PartTag = partObjs[0];
			printf("\nnBulkSOR_qSOR_Rel_function find T5_PartSorRel");
			TC_write_syslog("\nnBulkSOR_qSOR_Rel_function find T5_PartSorRel");
			ifail =(GRM_find_relation_type("T5_PartSorRel",&relation_type));
			ifail =(GRM_list_secondary_objects_only(PartTag,relation_type,&SORCount,&SOR_Objects));

			printf("\nnBulkSOR_qSOR_Rel_function SORCount : [%d]",SORCount);
			TC_write_syslog("\nnBulkSOR_qSOR_Rel_function SORCount : [%d]",SORCount);

			if (SORCount > 0 )//check part and SOR relation exist and having count
			{
				for(i = 0 ; i < SORCount ; i++ )
				{

					SOR_Tag = SOR_Objects[i];

					ifail = ( AOM_ask_value_string ( SOR_Tag, "object_name", &SOR_no ) ) ;
					printf("\nBulkSOR_qSOR_Rel_function SOR_no : [%s]",SOR_no);
					TC_write_syslog("\nBulkSOR_qSOR_Rel_function SOR_no : [%s]",SOR_no);

					ifail = ( AOM_ask_value_string ( SOR_Tag, "object_type", &SOR_object_type ) ) ;
					printf("\nBulkSOR_qSOR_Rel_function SOR_object_type : [%s]",SOR_object_type);
					TC_write_syslog("\nBulkSOR_qSOR_Rel_function SOR_object_type : [%s]",SOR_object_type);

					if (tc_strcmp(SOR_object_type,"T5_quicksorRevision")==0)
					{
						printf("\nBulkSOR_qSOR_Rel_function SOR [%s] is Already Present For part",SOR_no);
						TC_write_syslog("\nBulkSOR_qSOR_Rel_function SOR [%s] is Already Present For part",SOR_no);

						ifail = ( GRM_find_relation_type ( "T5_Bulk_part_has_qSor", &BulkRelationFind ) ) ;

						if (BulkRelationFind != NULLTAG)
						{

							printf("\nT5_Bulk_part_has_qSor BulkRelationFind found");
							TC_write_syslog("\nT5_Bulk_part_has_qSor BulkRelationFind found");

							ifail =(GRM_list_primary_objects_only(SOR_Tag,BulkRelationFind,&bulk_sor_rel_count,&bulkSOR_Objects));
							if ( bulk_sor_rel_count <= 0 )
							{


								if (BulkSor_tag !=NULLTAG)
								{

									printf("\nBulkSOR_qSOR_Rel_function BulkSor_tag found");
									TC_write_syslog("\nBulkSOR_qSOR_Rel_function BulkSor_tag found");
									ifail = ( GRM_create_relation ( BulkSor_tag, SOR_Tag, BulkRelationFind, NULLTAG, &BulkSorRelTag ) ) ;
									ifail = ( GRM_save_relation ( BulkSorRelTag ) ) ;
									ifail = ( AOM_refresh ( BulkSor_tag, 0 ) );
									printf("\nBULKSOR POSTACT : qSOR [%s] and  BulkSOR [%s] relation created successfully\n",SOR_no, BulkSor_name );
									TC_write_syslog("\nBULKSOR POSTACT : qSOR [%s] and  BulkSOR [%s] relation created successfully\n",SOR_no, BulkSor_name );

								}
							}
							else
							{
								printf("\nBULKSOR POSTACT : Quick SOR [%s] already attached to Other Bulk SOR hence skipping to create relation with new Bulk SOR : [%s]", SOR_no, BulkSor_name );
								TC_write_syslog("\nBULKSOR POSTACT : Quick SOR [%s] already attached to Other Bulk SOR hence skipping to create relation with new Bulk SOR : [%s]", SOR_no, BulkSor_name );
							}

						}

					}

				}

			}
			else
			{
				printf("\nBULKSOR POSTACT : Part : [%s] with Rev : [%s] seq : [%s] not attached to SOR with relation T5_PartSorRel",partno,Rev,Seq);
				TC_write_syslog("\nBULKSOR POSTACT : Part : [%s] with Rev : [%s] seq : [%s]  not attached to SOR with relation T5_PartSorRel",partno,Rev,Seq);
			}

		}

	}

	return ifail;

}

int tm_check_info_control_object_BulkSorPostAct ( char *syscd, char *subsyscd)
{
	int ifail = ITK_ok;
	int n_found = 0 ;
	int n_entries = 2 ;
	char  *qry_entries[] = {(char *)"SYSCD",(char *)"SUBSYSCD"};
	char  *qry_values[] = {(char *)syscd,(char *)subsyscd};
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	//char *l_info1 = NULL ;
	//char *l_info2 = NULL ;

	ifail =  ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ifail =  ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	//if ( n_found > 0 )
	//{
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
	//	tc_strcpy( info1, l_info1 );
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
	//	tc_strcpy( info2, l_info2 );
	//
	//	printf ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//	TC_write_syslog ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//}

	return n_found ;
}
int BulkSOR_zip_rel_fuction ( tag_t BulkSor_tag, char *BulkSor_name )
{
	tag_t DatasetType = NULLTAG;
	tag_t ZipDataset = NULLTAG;
	tag_t BulkRelationFind = NULLTAG;
	tag_t BulkSorRelTag = NULLTAG;
	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;
	int n_found_QSOR_PDF = 0;

	char* info1 = NULL;
	char* info2 = NULL;

	printf("\nInside BulkSOR_pdf_rel_fuction....");
	TC_write_syslog("\nInside BulkSOR_pdf_rel_fuction....");

	info1 = (char*)MEM_alloc(200 * sizeof(char));
	info2 = (char*)MEM_alloc(200 * sizeof(char));

	n_found_QSOR_PDF = tm_check_info_control_object((char *)"QSORZIP", (char *) "ON", info1, info2);

	printf("\nn_found_QSOR_ZIP : [%d]",n_found_QSOR_PDF);
	TC_write_syslog("\nn_found_QSOR_ZIP : [%d]",n_found_QSOR_PDF);

	if ( n_found_QSOR_PDF > 0 )
	{


		ITK_CALL(AE_find_datasettype2("ZIP",&DatasetType));

		ITK_CALL(AE_create_dataset_with_id(DatasetType, BulkSor_name, "Bulk SOR ZIP", BulkSor_name, "", &ZipDataset));
		ITK_CALL(AE_save_myself(ZipDataset));

		printf("\nZIP Datase Created");
		TC_write_syslog("\nZIP Datase Created");

		ITK_CALL(RES_checkout2 ( ZipDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ));

		printf("\nZIP Datase checkedout");
		TC_write_syslog("\nZIP Datase checkedout");

		ITK_CALL(GRM_find_relation_type ( "T5_bulk_sor_has_doc", &BulkRelationFind ));

		ITK_CALL(GRM_create_relation ( BulkSor_tag, ZipDataset, BulkRelationFind, NULLTAG, &BulkSorRelTag )) ;

		printf("\nBulk sor and Zip Datase relation created");
		TC_write_syslog("\nBulk sor and Zip Datase relation created");

		ITK_CALL(GRM_save_relation ( BulkSorRelTag ));
		ITK_CALL(AOM_refresh ( BulkSor_tag, 0 ) );

		printf("\nZip Dateset created and attached");
		TC_write_syslog("\nZip Dateset created and attached");
	}

	return ITK_ok;
}
int BulkSOR_pdf_rel_fuction ( tag_t BulkSor_tag, char *BulkSor_name )
{
	tag_t DatasetType = NULLTAG;
	tag_t PdfDataset = NULLTAG;
	tag_t BulkRelationFind = NULLTAG;
	tag_t BulkSorRelTag = NULLTAG;
	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;
	int n_found_QSOR_PDF = 0;

	char* info1 = NULL;
	char* info2 = NULL;

	printf("\nInside BulkSOR_pdf_rel_fuction....");
	TC_write_syslog("\nInside BulkSOR_pdf_rel_fuction....");

	info1 = (char*)MEM_alloc(200 * sizeof(char));
	info2 = (char*)MEM_alloc(200 * sizeof(char));

	n_found_QSOR_PDF = tm_check_info_control_object((char *)"QSORPDF", (char *) "ON", info1, info2);

	printf("\nn_found_QSOR_PDF : [%d]",n_found_QSOR_PDF);
	TC_write_syslog("\nn_found_QSOR_PDF : [%d]",n_found_QSOR_PDF);

	if ( n_found_QSOR_PDF > 0 )
	{


		ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));

		ITK_CALL(AE_create_dataset_with_id(DatasetType, BulkSor_name, "Bulk SOR PDF", BulkSor_name, "", &PdfDataset));
		ITK_CALL(AE_save_myself(PdfDataset));

		printf("\nPDF Datase Created");
		TC_write_syslog("\nPDF Datase Created");

		ITK_CALL(RES_checkout2 ( PdfDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ));

		printf("\nPDF Datase checkedout");
		TC_write_syslog("\nPDF Datase checkedout");

		ITK_CALL(GRM_find_relation_type ( "T5_bulk_sor_has_doc", &BulkRelationFind ));

		ITK_CALL(GRM_create_relation ( BulkSor_tag, PdfDataset, BulkRelationFind, NULLTAG, &BulkSorRelTag )) ;

		printf("\nBulk sor and PDF Datase relation created");
		TC_write_syslog("\nBulk sor and PDF Datase relation created");

		ITK_CALL(GRM_save_relation ( BulkSorRelTag ));
		ITK_CALL(AOM_refresh ( BulkSor_tag, 0 ) );

		printf("\nPDF Dateset created and attached");
		TC_write_syslog("\nPDF Dateset created and attached");
	}

	return ITK_ok;
}

//Added by Shubham
//int check_if_dataset_exist( char *Dataset_ID , char *datasetType ) //"PDF"
//{
//	tag_t query = NULLTAG ;
//	int n_found = 0 ;
//	int n_entries = 2 ;
//	char *qry_entries[2] = { "Name", "Dataset Type" } ;
//	char *qry_values[2] =  { Dataset_ID, datasetType } ;
//	tag_t *dataset_objects = NULL ;
//
//	
//	ITK_CALL ( QRY_find2 ( "Dataset...", &query ) ) ;
//	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &dataset_objects ) ) ;
//	printf( "\nfound dataset [%s] of type [%s] n_found [%d]", Dataset_ID, datasetType, n_found ) ;
//	TC_write_syslog ( "\nfound dataset [%s] of type [%s] n_found [%d]", Dataset_ID, datasetType, n_found ) ;
//	if ( n_found > 0 )
//	{
//		return n_found;
//	}
//	return 0;
//}
//end

int get_previous_rev_sor_copy(tag_t Part_f_Tag,char *Rev, char *Seq  )
{
	int no_f_entries = 1;
	int result_f_Count = 0;
	tag_t query_f_Tag = NULLTAG;
	tag_t *part_f_Objs = NULLTAG;
	//tag_t Part_f_Tag = NULLTAG;
	tag_t f_relation_type = NULLTAG ;
	tag_t *q_SOR_Objects = NULLTAG ;
	char * partno =NULL;
	char * partnorevseq =NULL;
	char * part_f =NULL;
	char * part_f_rev =NULL;
	char * part_f_seq =NULL;
	char * revpartno =NULL;
	char *Release_status_f_qSOR = NULL; 
	char *prev_sor_quantity = NULL;
	//char *current_part_no = NULL;
	//char *curr_part_rev = NULL;
	//char *current_part_seq = NULL;
	

	int	n_to_sort = 1;//The number of the class attributes to be sorted
	char** keys = NULL;
    int orders[1] = { 2 };	//descending order sort

	ITK_CALL(AOM_ask_value_string(Part_f_Tag,"item_id",&partno));
	//ITK_CALL(AOM_ask_value_string(Part_f_Tag,"item_revision_id",partnorevseq));

	char *qry_f_entries[] = {(char *)"Item ID"};
	char  *qry_f_values[] = {(char *)partno};

	//char *qry_f_entries[] = {(char *)"item_revision_id"};
	//char  *qry_f_values[] = {(char *)partnorevseq};
	
	int i_f = 0 ;
	int SOR_f_Count=0;
	tag_t current_part_rev = NULLTAG;
	tag_t curr_relation_type = NULLTAG;
	int SOR_curr_Count = 0 ;
	tag_t *curr_q_SOR_Objects = NULLTAG;
	tag_t *prev_qSOR_Objects = NULLTAG;
	tag_t curr_qSOR_Obj = NULLTAG;
	tag_t dataset_relation_type = NULLTAG;
	tag_t* DatasetList = NULLTAG;
	tag_t relation_tag = NULLTAG;
	tag_t dataset_objTypeTag = NULLTAG;
	tag_t DS = NULLTAG;
	tag_t new_dataset = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation = NULLTAG;
	char *prev_qsorPMXU = NULL;
	char *prev_qCtrlSorCat = NULL;
	char *prev_qCtrlCommodity = NULL;
	char *sor_prev_PPPMPrjCode = NULL;
	char *sor_curr_PPPMPrjCode = NULL;
	char *RFQ_pdfdataset_name = NULL;
	char *DVP_pdfdataset_name = NULL;
	char *dataset_typename = NULL;
	char *secObjType = NULL;

	
	int it5_qQuantity = 0;
	int curr_ntablerows = 0 ;
	int ntablerows = 0 ;
	tag_t *curr_table_rows = NULL;
	tag_t *table_rows = NULL;
	int ci_j = 0 ;
	int i_j = 0 ;
	int dataset_cnt = 0 ;
	int iRelCntr = 0;

	RFQ_pdfdataset_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;
	DVP_pdfdataset_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;

	keys = (char**)MEM_alloc(1 * sizeof(char*));
	keys[0] = (char*)MEM_alloc(30);
	tc_strcpy(keys[0], "creation_date");

	
	ITK_CALL ( QRY_find2("Item Revision...", &query_f_Tag ) ) ;

	printf("\nQuery_QuickSOR_copy_attr Item Revision...Query found");
	TC_write_syslog("\nQuery_QuickSOR_copy_attr Item Revision...Query found");

	ITK_CALL ( QRY_execute_with_sort ( query_f_Tag, no_f_entries, qry_f_entries, qry_f_values,n_to_sort, keys, orders, &result_f_Count, &part_f_Objs ) );
	
	printf("\nresult_f_Count : [%d]", result_f_Count);
	TC_write_syslog("\nresult_f_Count : [%d]", result_f_Count);

	int found_index = -1 ;
	for(i_f = 0 ; i_f < result_f_Count  ; i_f++ )
	{  
		current_part_rev = part_f_Objs[i_f] ;
		//char *q__SORPart_no = NULL;
		char *q_f_SORPart_RevSeq = NULL;
		char *q_f_SORPart_Rev = NULL;
		char *q_f_SORPart_Seq = NULL;
		// ITK_CALL(AOM_ask_value_string(part_f_Objs[i_f],"item_id",partno));
		ITK_CALL ( AOM_ask_value_string ( part_f_Objs[i_f],"item_revision_id",&q_f_SORPart_RevSeq )) ;

		printf("\nq_f_SORPart_RevSeq : [%s]", q_f_SORPart_RevSeq);
		TC_write_syslog("\nq_f_SORPart_RevSeq : [%s]", q_f_SORPart_RevSeq);

		q_f_SORPart_Rev = strtok(q_f_SORPart_RevSeq,";");
		q_f_SORPart_Seq = strtok(NULL,"");

		printf("\nq_f_SORPart_Rev : [%s]", q_f_SORPart_Rev);
		TC_write_syslog("\nq_f_SORPart_Rev : [%s]", q_f_SORPart_Rev);

		printf("\nq_f_SORPart_Seq : [%s]", q_f_SORPart_Seq);
		TC_write_syslog("\nq_f_SORPart_Seq : [%s]", q_f_SORPart_Seq);

		if ( ( tc_strcmp ( Rev, q_f_SORPart_Rev ) == 0 ) && ( tc_strcmp ( Seq, q_f_SORPart_Seq ) == 0 ) )
		{
			found_index = i_f ;
			
				
			ITK_CALL (  GRM_find_relation_type ( "T5_PartSorRel", &curr_relation_type ) ) ;
			ITK_CALL (  GRM_list_secondary_objects_only ( current_part_rev, curr_relation_type, &SOR_curr_Count, &curr_q_SOR_Objects ) ) ;
			printf("\nfunction get_sor_attached_to_part SOR_curr_Count : [%d]",SOR_curr_Count);
			TC_write_syslog("\nfunction get_sor_attached_to_part SOR_curr_Count : [%d]",SOR_curr_Count);
			
			if( SOR_curr_Count > 0 )
			{
				curr_qSOR_Obj = curr_q_SOR_Objects [ 0 ] ;
			}


			break;
		}
	}
		//if ( ( Rev > q_f_SORPart_Rev) )
	if ( ( found_index + 1  ) < result_f_Count)
	{
			
		for ( i_f = found_index + 1 ; i_f < result_f_Count  ; i_f++ )
		{
			

			ITK_CALL (  GRM_find_relation_type ( "T5_PartSorRel", &f_relation_type ) ) ;
			ITK_CALL (  GRM_list_secondary_objects_only ( part_f_Objs[i_f], f_relation_type, &SOR_f_Count, &prev_qSOR_Objects ) ) ;
			printf("\nfunction get_sor_attached_to_part SOR_f_Count : [%d]",SOR_f_Count);
			TC_write_syslog("\nfunction get_sor_attached_to_part SOR_f_Count : [%d]",SOR_f_Count);

			if( SOR_f_Count>0 )
			{

				//ITK_CALL ( AOM_ask_value_string( prev_qSOR_Objects[0], "release_status_list", &Release_status_f_qSOR ));
				ITK_CALL ( AOM_UIF_ask_value( prev_qSOR_Objects[0], "release_status_list", &Release_status_f_qSOR ));
				printf("\nfunction get_sor_attached_to_part Release_status_f_qSOR : [%s]",Release_status_f_qSOR);
				TC_write_syslog("\nfunction get_sor_attached_to_part Release_status_f_qSOR : [%s]",Release_status_f_qSOR);

				if(strstr(Release_status_f_qSOR,"ERC Released")!=NULL)
				{

					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qSorPartNumber",&part_f));
					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qSorPartRevision",&part_f_rev));
					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qSorPartSeq",&part_f_seq));
					
					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qsorPMXU",&prev_qsorPMXU));
					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qCtrlSorCat",&prev_qCtrlSorCat));
					ITK_CALL(AOM_ask_value_string( prev_qSOR_Objects[0],"t5_qCtrlCommodity",&prev_qCtrlCommodity));
					
					ITK_CALL(AOM_ask_value_string(prev_qSOR_Objects[0], "t5_qPPPMPrjCode",&sor_prev_PPPMPrjCode));

					
					//ITK_CALL(AOM_UIF_ask_value(prev_qSOR_Objects[0], "t5_qQuantity",&prev_sor_quantity));

					printf("\nfunction get_sor_attached_to_part part_f : [%s]",part_f);
					TC_write_syslog("\nfunction get_sor_attached_to_part part_f : [%s]",part_f);

					printf("\nfunction get_sor_attached_to_part part_f_rev : [%s]",part_f_rev);
					TC_write_syslog("\nfunction get_sor_attached_to_part part_f_rev : [%s]",part_f_rev);

					printf("\nfunction get_sor_attached_to_part part_f_seq : [%s]",part_f_seq);
					TC_write_syslog("\nfunction get_sor_attached_to_part part_f_seq : [%s]",part_f_seq);

					
					printf("\nValue for prev sor_prev_PPPMPrjCode  : [%s]",sor_prev_PPPMPrjCode);
					TC_write_syslog("\nValue for prev sor_prev_PPPMPrjCode  : [%s]",sor_prev_PPPMPrjCode);

					//printf("\n prev_sor_quantity  : [%s]",prev_sor_quantity);
					//TC_write_syslog("\n prev_sor_quantity  : [%s]",prev_sor_quantity);
					
					
					
					break;


				}
				else
				{
					printf("\nSOR details Skiping from previous revision as Released status is not ERC Released :");
					TC_write_syslog("\nSOR details Skiping from previous revision as Released status is not ERC Released : \n ");
				
				}


			}


			
		}
		
		//
		ITK_CALL ( AOM_refresh ( curr_qSOR_Obj, TRUE ) ) ;
		TC_write_syslog ( "\nqBulkSOR Post Action set pmxu" ) ;
		if ( prev_qsorPMXU != NULL )
		{
			ITK_CALL ( AOM_set_value_string(curr_qSOR_Obj, "t5_qsorPMXU", prev_qsorPMXU ) ) ;
		}
		if ( prev_qCtrlSorCat != NULL )
		{
			ITK_CALL ( AOM_set_value_string(curr_qSOR_Obj, "t5_qCtrlSorCat", prev_qCtrlSorCat ) ) ;
		}
		if ( prev_qCtrlCommodity != NULL )
		{
			ITK_CALL ( AOM_set_value_string(curr_qSOR_Obj, "t5_qCtrlCommodity", prev_qCtrlCommodity ) ) ;
		}
			

		ITK_CALL(AOM_ask_value_string(curr_qSOR_Obj, "t5_qPPPMPrjCode",&sor_curr_PPPMPrjCode));

		printf("\n Value for current sor_curr_PPPMPrjCode  : [%s]",sor_curr_PPPMPrjCode);
		TC_write_syslog ( "\n Value for current sor_curr_PPPMPrjCode = [%s]",  sor_curr_PPPMPrjCode) ;

		

		ITK_CALL ( AOM_save_without_extensions ( curr_qSOR_Obj ) ) ;
		TC_write_syslog("\nBulkSOR Post Action" ) ;
		ITK_CALL ( AOM_refresh ( curr_qSOR_Obj, FALSE ) ) ;
		TC_write_syslog ( "\nqBulkSOR Post Action set pmxu : [%s]", prev_qsorPMXU ) ;
		TC_write_syslog ( "\nunlocked BulkSOR Post Action" ) ;

		//Shubham Added
		
		if (tc_strcmp(prev_qCtrlSorCat,"CAT 1")== 0 || 
			tc_strcmp(prev_qCtrlSorCat,"CAT 2")== 0 || 
			tc_strcmp(prev_qCtrlSorCat,"CAT 3")== 0 )
		{
			char *curr_qSOR_Part_no = NULL;
			char *curr_qSOR_Part_Rev = NULL;
			char *curr_qSOR__seq = NULL;

			//tag_t itemtag  = NULLTAG;
			//tag_t rev  = NULLTAG;

			//ITK_CALL(ITEM_find_item(curr_qSOR_Obj,&itemtag));
			//ITK_CALL(ITEM_find_revision(itemtag,curr_qSOR_Part_Rev, &rev));

			ITK_CALL(AOM_ask_value_string( curr_qSOR_Obj,"t5_qSorPartNumber",&curr_qSOR_Part_no));
			ITK_CALL(AOM_ask_value_string( curr_qSOR_Obj,"t5_qSorPartRevision",&curr_qSOR_Part_Rev));
			ITK_CALL(AOM_ask_value_string( curr_qSOR_Obj,"t5_qSorPartSeq",&curr_qSOR__seq));

			printf("\n Value for current curr_qSOR_Part_no  : [%s]",curr_qSOR_Part_no);
			TC_write_syslog ( "\n Value for current curr_qSOR_Part_no = [%s]",  curr_qSOR_Part_no) ;

			printf("\n Value for current curr_qSOR_Part_Rev  : [%s]",curr_qSOR_Part_Rev);
			TC_write_syslog ( "\n Value for current curr_qSOR_Part_Rev = [%s]",  curr_qSOR_Part_Rev) ;

			printf("\n Value for current curr_qSOR__seq  : [%s]",curr_qSOR__seq);
			TC_write_syslog ( "\n Value for current curr_qSOR__seq = [%s]",  curr_qSOR__seq) ;
			
			tag_t datasettype = NULLTAG;
			int ref_count = 0;
			char **ref_list;
			tag_t tool = NULLTAG;
			char *DsetID = NULL;
			tag_t aNewDataset = NULLTAG;
			tag_t Relatn_type1;
			tag_t relation = NULLTAG;

			const char *reason = "" ;
			const char *change_id = "" ;
			const char *dir_name = "" ;

			//int Quick_CR_DTSET = 0;
			//int pdf_dataset_cr_flag = 0;


			 //ITK_CALL ( AE_find_datasettype("PDF", &datasettype ) ) ;
			 ITK_CALL ( AE_find_datasettype2("PDF", &datasettype ) ) ; //RS14.3
			 ITK_CALL ( AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list) ) ;
			 printf("\n1ref_list[0] : %s",ref_list[0]);
			 TC_write_syslog("\n1ref_list[0] : %s",ref_list[0]);
			 
			 DsetID = NULL;
			 DsetID=(char *) MEM_alloc(32);
			 tc_strcpy(DsetID,"DVP");
			 tc_strcat(DsetID,"_");
			 tc_strcat(DsetID,curr_qSOR_Part_no);
			 tc_strcat(DsetID,"_");
			 tc_strcat(DsetID,curr_qSOR_Part_Rev);
			 tc_strcat(DsetID,"_");
			 tc_strcat(DsetID,curr_qSOR__seq);
			 TC_write_syslog("\nDsetID : [%s]",DsetID);
			 
			 //pdf_dataset_cr_flag = check_if_dataset_exist( DsetID , "PDF" );
			 //
			 //if ( pdf_dataset_cr_flag > 0 )
			 //{
			 //	printf("\nDataset already exist hence skipping creation");
			 //	TC_write_syslog("\nDataset already exist hence skipping creation");
			 //	return ITK_ok;
			 //}
			 
			 
			 ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"PDF Dataset",DsetID,"",&aNewDataset));
			 ITK_CALL(AOM_lock(aNewDataset));
			 ITK_CALL(AE_set_dataset_tool( aNewDataset, tool));
			 //ITK_CALL(AE_set_dataset_format(aNewDataset, "BINARY_REF"));
			 ITK_CALL(AE_set_dataset_format2(aNewDataset, "BINARY_REF")); //RS14.3
			 ITK_CALL(AOM_save_without_extensions(aNewDataset));
			 ITK_CALL(AOM_unlock(aNewDataset));
			 
			 TC_write_syslog("\nfind IMAN_specification");
			 
			 ITK_CALL(GRM_find_relation_type("IMAN_specification",&Relatn_type1));
			 //ITK_CALL(GRM_find_relation_type("Specifications",&Relatn_type1));

			 //ITK_CALL(GRM_find_relation_type("Specifications",&Relatn_type1));
			 TC_write_syslog("\ncreate_dataset_with_quicksor_no : GRM_create_relation create111111111");
			 ITK_CALL(GRM_create_relation(curr_qSOR_Obj,aNewDataset,Relatn_type1,NULLTAG,&relation));
			 printf("\nncreate_dataset_with_quicksor_no : after creating relation between dataset222222222222"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : after creating relation between dataset333333333"); fflush(stdout);
			 ITK_CALL(GRM_save_relation(relation));
			 printf("\nncreate_dataset_with_quicksor_no : GRM_save_relation444444444"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : GRM_save_relation55555555555"); fflush(stdout);
			 
			 printf("\nncreate_dataset_with_quicksor_no : AOM_save for  curr_qSOR_Obj666666666"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : AOM_save for  curr_qSOR_Obj7777777777"); fflush(stdout);
			 
			 //ITK_CALL ( RES_checkout ( aNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create
			 ITK_CALL ( RES_checkout2 ( aNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create //RS14.3

			tag_t datasettype1 = NULLTAG;
			int ref_count1 = 0;
			char **ref_list1;
			tag_t tool1 = NULLTAG;
			char *DsetID1 = NULL;
			tag_t aNewDataset1 = NULLTAG;
			tag_t Relatn_type2;
			tag_t relation1 = NULLTAG;

			const char *reason1 = "" ;
			const char *change_id1 = "" ;
			const char *dir_name1 = "" ;

			//int Quick_CR_DTSET = 0;
			//int pdf_dataset_cr_flag = 0;


			 //ITK_CALL ( AE_find_datasettype("PDF", &datasettype ) ) ;
			 ITK_CALL ( AE_find_datasettype2("PDF", &datasettype1 ) ) ; //RS14.3
			 ITK_CALL ( AE_ask_datasettype_refs(datasettype1, &ref_count1, &ref_list1) ) ;
			 printf("\n1ref_list[0] : %s",ref_list1[0]);
			 TC_write_syslog("\n1ref_list[0] : %s",ref_list1[0]);
			 
			 DsetID1 = NULL;
			 DsetID1=(char *) MEM_alloc(32);
			 tc_strcpy(DsetID1,"RFQ");
			 tc_strcat(DsetID1,"_");
			 tc_strcat(DsetID1,curr_qSOR_Part_no);
			 tc_strcat(DsetID1,"_");
			 tc_strcat(DsetID1,curr_qSOR_Part_Rev);
			 tc_strcat(DsetID1,"_");
			 tc_strcat(DsetID1,curr_qSOR__seq);
			 TC_write_syslog("\nDsetID : [%s]",DsetID1);
			 
			 //pdf_dataset_cr_flag = check_if_dataset_exist( DsetID , "PDF" );
			 //
			 //if ( pdf_dataset_cr_flag > 0 )
			 //{
			 //	printf("\nDataset already exist hence skipping creation");
			 //	TC_write_syslog("\nDataset already exist hence skipping creation");
			 //	return ITK_ok;
			 //}
			 
			 
			 ITK_CALL(AE_create_dataset_with_id(datasettype1,DsetID1,"PDF Dataset",DsetID1,"",&aNewDataset1));
			 ITK_CALL(AOM_lock(aNewDataset1));
			 ITK_CALL(AE_set_dataset_tool( aNewDataset1, tool));
			 //ITK_CALL(AE_set_dataset_format(aNewDataset, "BINARY_REF"));
			 ITK_CALL(AE_set_dataset_format2(aNewDataset1, "BINARY_REF")); //RS14.3
			 ITK_CALL(AOM_save_without_extensions(aNewDataset1));
			 ITK_CALL(AOM_unlock(aNewDataset1));
			 
			 TC_write_syslog("\nfind IMAN_specification");
			 
			 ITK_CALL(GRM_find_relation_type("IMAN_specification",&Relatn_type2));
			 //ITK_CALL(GRM_find_relation_type("Specifications",&Relatn_type2));
			 //ITK_CALL(GRM_find_relation_type("Specifications",&Relatn_type1));
			 TC_write_syslog("\ncreate_dataset_with_quicksor_no : GRM_create_relation create111111111");
			 ITK_CALL(GRM_create_relation(curr_qSOR_Obj,aNewDataset1,Relatn_type2,NULLTAG,&relation1));
			 printf("\nncreate_dataset_with_quicksor_no : after creating relation between dataset222222222222"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : after creating relation between dataset333333333"); fflush(stdout);
			 ITK_CALL(GRM_save_relation(relation1));
			 printf("\nncreate_dataset_with_quicksor_no : GRM_save_relation444444444"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : GRM_save_relation55555555555"); fflush(stdout);
			 
			 printf("\nncreate_dataset_with_quicksor_no : AOM_save for  curr_qSOR_Obj666666666"); fflush(stdout);
			 TC_write_syslog("\nncreate_dataset_with_quicksor_no : AOM_save for  curr_qSOR_Obj7777777777"); fflush(stdout);
			 
			 //ITK_CALL ( RES_checkout ( aNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create
			 ITK_CALL ( RES_checkout2 ( aNewDataset1, reason1, change_id1, dir_name1, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create //RS14.3
		}
//End
		
		
		//if(strcmp(sor_prev_PPPMPrjCode,sor_curr_PPPMPrjCode)==0)
		//{
		//	//ITK_CALL ( AOM_set_value_string(curr_qSOR_Obj, "t5_qQuantity", prev_sor_quantity ) ) ;
		//	ITK_CALL(AOM_ask_table_rows(curr_qSOR_Obj, "t5_qSORVar", &curr_ntablerows, &curr_table_rows));
		//	ITK_CALL(AOM_ask_table_rows(prev_qSOR_Objects[0], "t5_qSORVar", &ntablerows, &table_rows));
		//	printf("\nsor_t5_variant  checkin : [%d]", ntablerows); fflush(stdout);
		//	TC_write_syslog("\nsor_t5_variant  checkin : [%d]", ntablerows);
		//	
		//	
		//	//for ( ci_j = 0; ci_j < ntablerows; ci_j++)
		//	//{
		//	//	for ( i_j = 0; i_j < curr_ntablerows; i_j++)
		//	//	{
		//	//		if ( ci_j == i_j )
		//	//		{
		//	//		
		//	//			ITK_CALL(AOM_ask_value_int(table_rows[i_j], "t5_qQuantity", &it5_qQuantity));
		//	//			//printf("\nprev_sor_quantity : [%d]",it5_qQuantity);
		//	//			printf("\nprev_sor_quantity : [%d] from row [%d]",it5_qQuantity,ci_j);
		//	//			TC_write_syslog("\nprev_sor_quantity : [%d] from row [%d]",it5_qQuantity);
		//	//			ITK_CALL ( AOM_refresh ( curr_table_rows[ci_j], TRUE ) ) ;
		//	//			ITK_CALL(AOM_set_value_int(curr_table_rows[ci_j], "t5_qQuantity", it5_qQuantity));
		//	//			ITK_CALL ( AOM_save_without_extensions ( curr_table_rows[ci_j] ) ) ;
		//	//			TC_write_syslog("\nBulkSOR Post Action" ) ;
		//	//			ITK_CALL ( AOM_refresh ( curr_table_rows[ci_j], FALSE ) ) ;
		//	//			TC_write_syslog ( "\nqBulkSOR Post Action set it5_qQuantity : [%d]",  it5_qQuantity) ;
		//	//			TC_write_syslog ( "\nunlocked BulkSOR Post Action" ) ;
		//	//		}
		//	//	}
		//	//}
		//
		//	int min_rows = (ntablerows < curr_ntablerows) ? ntablerows : curr_ntablerows;
		//	
		//	for (ci_j = 0; ci_j < min_rows; ci_j++)
		//	{
		//	    int prev_quantity = 0;
		//	
		//	    ITK_CALL(AOM_ask_value_int(table_rows[ci_j], "t5_qQuantity", &prev_quantity));
		//	    printf("\nCopying Quantity [%d] from row [%d]", prev_quantity, ci_j);
		//	    TC_write_syslog("\nCopying Quantity : [%d] from row [%d]", prev_quantity, ci_j);
		//	
		//	    ITK_CALL(AOM_refresh(curr_table_rows[ci_j], TRUE)); // Lock row
		//	
		//	    // Option 1: direct integer set
		//	    ITK_CALL(AOM_set_value_int(curr_table_rows[ci_j], "t5_qQuantity", prev_quantity));
		//	
		//	    // Option 2: UIF set (use if Option 1 fails)
		//	    // char qty_buf[16];
		//	    // sprintf(qty_buf, "%d", prev_quantity);
		//	    // ITK_CALL(AOM_UIF_set_value(curr_table_rows[ci_j], "t5_qQuantity", qty_buf));
		//	
		//	    ITK_CALL(AOM_save_without_extensions(curr_table_rows[ci_j]));
		//	    ITK_CALL(AOM_refresh(curr_table_rows[ci_j], FALSE)); // Unlock
		//	}
		//
		//	// Save main object
		//	ITK_CALL(AOM_save_without_extensions(curr_qSOR_Obj));
		//
		//	for (ci_j = 0; ci_j < curr_ntablerows; ci_j++)
		//	{
		//	    int q = 0;
		//	    ITK_CALL(AOM_ask_value_int(curr_table_rows[ci_j], "t5_qQuantity", &q));
		//	    printf("\nPost-Copy: Row [%d] has Quantity: %d", ci_j, q);
		//	}
		//
		//	
		//}

		//if (strcmp(sor_prev_PPPMPrjCode, sor_curr_PPPMPrjCode) == 0) 
		//{
		//    // This block will execute if the project codes are equal
		//    printf("Project codes are equal. Copying quantities...\n");
		//    // Assuming you want to copy quantities here
		//    ITK_CALL(AOM_ask_table_rows(curr_qSOR_Obj, "t5_qSORVar", &curr_ntablerows, &curr_table_rows));
		//    ITK_CALL(AOM_ask_table_rows(prev_qSOR_Objects[0], "t5_qSORVar", &ntablerows, &table_rows));
		//    int min_rows = (ntablerows < curr_ntablerows) ? ntablerows : curr_ntablerows;
		//    for (int ci_j = 0; ci_j < min_rows; ci_j++) 
		//	{
		//        int prev_quantity = 0;
		//        ITK_CALL(AOM_ask_value_int(table_rows[ci_j], "t5_qQuantity", &prev_quantity));
		//        printf("Copying Quantity [%d] from row [%d]\n", prev_quantity, ci_j);
		//        TC_write_syslog("\nCopying Quantity [%d] from row [%d]\n", prev_quantity, ci_j");
		//        ITK_CALL(AOM_set_value_int(curr_table_rows[ci_j], "t5_qQuantity", prev_quantity));
		//        ITK_CALL(AOM_UIF_set_value(curr_table_rows[ci_j], "t5_qQuantity", prev_quantity));
		//        ITK_CALL(AOM_save_without_extensions(curr_table_rows[ci_j]));
		//        ITK_CALL(AOM_refresh(curr_table_rows[ci_j], FALSE)); // Unlock
		//    }
		//    // Save main object
		//    ITK_CALL(AOM_save_without_extensions(curr_qSOR_Obj));
		//}
		//else 
		//{
		//    printf("Project codes are not equal. Not copying quantities.\n");
		//    TC_write_syslog("\nuProject codes are not equal. Not copying quantities");
		//}

		//if (strcmp(sor_prev_PPPMPrjCode, sor_curr_PPPMPrjCode) == 0) 
		//{
		//    printf("Project codes are equal. Copying quantities...\n");
		//    
		//    int curr_ntablerows = 0, ntablerows = 0;
		//    tag_t *curr_table_rows = NULL;
		//    tag_t *table_rows = NULL;
		//
		//    ITK_CALL(AOM_ask_table_rows(curr_qSOR_Obj, "t5_qSORVar", &curr_ntablerows, &curr_table_rows));
		//    ITK_CALL(AOM_ask_table_rows(prev_qSOR_Objects[0], "t5_qSORVar", &ntablerows, &table_rows));
		//
		//    int min_rows = (ntablerows < curr_ntablerows) ? ntablerows : curr_ntablerows;
		//
		//    for (int ci_j = 0; ci_j < min_rows; ci_j++) 
		//    {
		//        int prev_quantity = 0;
		//        ITK_CALL(AOM_ask_value_int(table_rows[ci_j], "t5_qQuantity", &prev_quantity));
		//        printf("Copying Quantity [%d] from row [%d]\n", prev_quantity, ci_j);
		//        TC_write_syslog("\nCopying Quantity [%d] from row [%d]\n", prev_quantity, ci_j);
		//
		//        ITK_CALL(AOM_set_value_int(curr_table_rows[ci_j], "t5_qQuantity", prev_quantity));
		//        //ITK_CALL(AOM_UIF_set_value(curr_table_rows[ci_j], "t5_qQuantity", prev_quantity));
		//    }
		//    ITK_CALL(AOM_save_without_extensions(curr_qSOR_Obj));
		//
		//    ITK_CALL(AOM_refresh(curr_qSOR_Obj, FALSE));
		//} 
		//else 
		//{
		//    printf("Project codes are not equal. Not copying quantities.\n");
		//    TC_write_syslog("\nuProject codes are not equal. Not copying quantities");
		//}

		if ( tc_strcmp ( sor_prev_PPPMPrjCode, sor_curr_PPPMPrjCode ) == 0 ) 
		{	
			int n_found_QSOR_Copy = 0;

			char* info1 = NULL;
			char* info2 = NULL;
			
			info1 = (char*)MEM_alloc(200 * sizeof(char));
			info2 = (char*)MEM_alloc(200 * sizeof(char));
			
			n_found_QSOR_Copy = tm_check_info_control_object((char *)"QSORCOPY", (char *) "ON", info1, info2);
			
			printf("\nn_found_QSOR_COPY : [%d]",n_found_QSOR_Copy);
			TC_write_syslog("\nn_found_QSOR_COPY : [%d]",n_found_QSOR_Copy);
			
			if ( n_found_QSOR_Copy > 0 )
			{
			
				printf("Prev SOR Project codes [%s]\n", sor_prev_PPPMPrjCode);
				TC_write_syslog ( "\n Value for current sor_prev_PPPMPrjCode = [%s]", sor_prev_PPPMPrjCode) ;
				printf("Curr SOR Project codes [%s]\n", sor_curr_PPPMPrjCode);
				TC_write_syslog ( "\n Value for current sor_curr_PPPMPrjCode = [%s]", sor_curr_PPPMPrjCode) ;
				printf("Project codes are equal. Copying quantities...\n");
				TC_write_syslog("\nProject codes are equal. Copying quantities...");
		
				int curr_ntablerows = 0;
				int prev_ntablerows = 0;
				tag_t *curr_table_rows = NULL;
				tag_t *prev_table_rows = NULL;
		
				ITK_CALL(AOM_ask_table_rows(curr_qSOR_Obj, "t5_qSORVar", &curr_ntablerows, &curr_table_rows));
				ITK_CALL(AOM_ask_table_rows(prev_qSOR_Objects[0], "t5_qSORVar", &prev_ntablerows, &prev_table_rows));
		
				//int min_rows = (ntablerows < curr_ntablerows) ? ntablerows : curr_ntablerows;
				
				printf("\ncurr_ntablerows : [%d]",curr_ntablerows);
				TC_write_syslog("\ncurr_ntablerows : [%d]",curr_ntablerows);
				
				printf("\nprev_ntablerows : [%d]",prev_ntablerows);
				TC_write_syslog("\nprev_ntablerows : [%d]",prev_ntablerows);
				
				
				if ( curr_ntablerows <= 0 && prev_ntablerows > 0 ) //if current table row count is zero
				{
					printf("\nbefore AOM_append_table_rows");
					TC_write_syslog("\nbefore AOM_append_table_rows");
					
					int NewLevel = 0;
					curr_ntablerows = prev_ntablerows;
					
					printf("\nafter curr_ntablerows : [%d]",curr_ntablerows);
					TC_write_syslog("\nafter curr_ntablerows : [%d]",curr_ntablerows);
				
					
					ITK_CALL ( AOM_refresh ( curr_qSOR_Obj, TRUE ) ) ;
					ITK_CALL ( AOM_append_table_rows ( curr_qSOR_Obj, "t5_qSORVar", curr_ntablerows, &NewLevel, &curr_table_rows ) ) ;
					ITK_CALL ( AOM_save_without_extensions ( curr_qSOR_Obj ) ) ;
					ITK_CALL ( AOM_refresh ( curr_qSOR_Obj, FALSE ) ) ;
					
					printf("\nafter AOM_append_table_rows done");
					TC_write_syslog("\nafter AOM_append_table_rows done");
					
				}
				
				if ( curr_ntablerows == prev_ntablerows )
				{
					printf("\ncurrent and previous row count match copy qty now");
					TC_write_syslog("\ncurrent and previous row count match copy qty now");
					
					for (int ci_j = 0; ci_j < prev_ntablerows; ci_j++) 
					{
						int prev_quantity = 0;
						ITK_CALL ( AOM_ask_value_int(prev_table_rows[ci_j], "t5_qQuantity", &prev_quantity ) ) ;
						printf("Copying Quantity [%d] from row [%d]\n", prev_quantity, ci_j);
						TC_write_syslog("\nCopying Quantity [%d] from row [%d]", prev_quantity, ci_j);

						ITK_CALL ( AOM_refresh ( curr_table_rows[ci_j], TRUE ) ) ;
						ITK_CALL ( AOM_set_value_int ( curr_table_rows[ci_j], "t5_qQuantity", prev_quantity ) ) ;		
						ITK_CALL ( AOM_save_without_extensions ( curr_table_rows[ci_j] ) ) ;
						ITK_CALL ( AOM_refresh ( curr_table_rows[ci_j], FALSE ) ) ;

					}
				}
				else if ( curr_ntablerows != prev_ntablerows ) //if current table row count and previous table row count not matching then delete current rows and create again
				{
					printf("Table row count mismatch  curr : [%d] prev : [%d]", curr_ntablerows, prev_ntablerows );
					TC_write_syslog("Table row count mismatch  curr : [%d] prev : [%d]", curr_ntablerows, prev_ntablerows );
					
				}
			
			
			/*ITK_CALL(AOM_refresh (curr_qSOR_Obj, TRUE)) ;
			ITK_CALL(AOM_save_without_extensions(curr_qSOR_Obj));		
		    ITK_CALL(AOM_refresh(curr_qSOR_Obj, FALSE));
			*/
			}
		} 
		else 
		{
		    printf("Project codes are not equal. Not copying quantities.\n");
		    TC_write_syslog("\nProject codes are not equal. Not copying quantities");
		}
		
	}
	
return ITK_ok;
}

int get_sor_attached_to_part ( tag_t Part_e_Tag, char *Rev, char *Seq  )
{
	printf("\nfunction search_next_rev_quick_sor");
	TC_write_syslog("\nfunction search_next_rev_quick_sor");
	int ifail = ITK_ok;
	int i_e = 0 ;
	int SOR_e_Count = 0 ;
	tag_t objType_e_Tag = NULLTAG ;
	tag_t q_relation_type = NULLTAG ;
	tag_t *q_SOR_Objects = NULLTAG ;
	char *type_e_name = NULL ;
	char *Release_status_qSOR = NULL;
	char *s_qsorPMXU = NULL ;
	char *s_qCtrlSorCat = NULL ;
	char *s_qCtrlCommodity = NULL ;
	
	s_qsorPMXU = ( char * ) MEM_alloc ( 10 * sizeof ( char ) ) ;
	s_qCtrlSorCat = ( char * ) MEM_alloc ( 20 * sizeof ( char ) ) ;
	s_qCtrlCommodity = ( char * ) MEM_alloc ( 30 * sizeof ( char ) ) ;
	
	ifail = ( GRM_find_relation_type ( "T5_PartSorRel", &q_relation_type ) ) ;
	ifail = ( GRM_list_secondary_objects_only ( Part_e_Tag, q_relation_type, &SOR_e_Count, &q_SOR_Objects ) ) ;
	printf("\nfunction get_sor_attached_to_part SOR_e_Count : [%d]",SOR_e_Count);
	TC_write_syslog("\nfunction get_sor_attached_to_part SOR_e_Count : [%d]",SOR_e_Count);
			
	if ( SOR_e_Count > 0 )
	{
		for ( i_e = 0 ; i_e < SOR_e_Count  ; i_e++ )
		{
			ITK_CALL ( TCTYPE_ask_object_type ( q_SOR_Objects[i_e], &objType_e_Tag ) ) ;
			ITK_CALL ( TCTYPE_ask_name2 ( objType_e_Tag, &type_e_name ) );
			printf("\nfunction get_sor_attached_to_part type_e_name : [%s]",type_e_name);
			TC_write_syslog("\nfunction get_sor_attached_to_part type_e_name : [%s]",type_e_name);
			if ( tc_strcmp ( type_e_name, "T5_quicksorRevision" ) == 0 )
			{
				get_previous_rev_sor_copy(Part_e_Tag, Rev, Seq );
				//tc_strcpy ( s_qsorPMXU, "X" ) ; 
				//tc_strcpy ( s_qCtrlSorCat, "CAT 5" ) ; 
				//tc_strcpy ( s_qCtrlCommodity, "200000000" ) ; 
				//ITK_CALL ( AOM_refresh ( q_SOR_Objects[i_e], TRUE ) ) ;
				//TC_write_syslog ( "\nqBulkSOR Post Action set pmxu" ) ;
				//ITK_CALL ( AOM_set_value_string(q_SOR_Objects[i_e], "t5_qsorPMXU", s_qsorPMXU ) ) ;
				//ITK_CALL ( AOM_set_value_string(q_SOR_Objects[i_e], "t5_qCtrlSorCat", s_qCtrlSorCat ) ) ;
				//ITK_CALL ( AOM_set_value_string(q_SOR_Objects[i_e], "t5_qCtrlCommodity", s_qCtrlCommodity ) ) ;
				//ITK_CALL ( AOM_save_without_extensions ( q_SOR_Objects[i_e] ) ) ;
				//TC_write_syslog("\nBulkSOR Post Action" ) ;
				//ITK_CALL ( AOM_refresh ( q_SOR_Objects[i_e], FALSE ) ) ;
				//TC_write_syslog ( "\nqBulkSOR Post Action set pmxu : [%s]", s_qsorPMXU ) ;
				//TC_write_syslog ( "\nunlocked BulkSOR Post Action" ) ;
			}
		}

	}

	return ITK_ok;
}

int Query_Part_to_copy_attr_on_qsor_of_old_rev ( char *partno, char *Rev, char *Seq )
{
	int i_d = 0;
	int no_d_entries = 1;
	int result_d_Count = 0;
	tag_t query_d_Tag = NULLTAG;
	tag_t *part_d_Objs = NULLTAG;
	tag_t Part_d_Tag = NULLTAG;
	int n_found_BulkSorPostAct=0;

	int	n_to_sort = 1;//The number of the class attributes to be sorted
	char** keys = NULL;
    int orders[1] = { 2 };	//descending order sort
		
	char *qry_d_entries[] = {(char *)"Item ID"};
	char  *qry_d_values[] = {(char *)partno};
	
	keys = (char**)MEM_alloc(1 * sizeof(char*));
	keys[0] = (char*)MEM_alloc(30);
	tc_strcpy(keys[0], "creation_date");

	char *CopySorDetails = NULL;
	char *CopySorDetailsstatus = NULL;

	CopySorDetails = (char *)MEM_alloc(50 *sizeof(char));
	CopySorDetailsstatus = (char *)MEM_alloc(50 *sizeof(char));

	tc_strcpy(CopySorDetails,"SorDetails");
	tc_strcpy(CopySorDetailsstatus,"ON");

	n_found_BulkSorPostAct = tm_check_info_control_object_BulkSorPostAct ( CopySorDetails,CopySorDetailsstatus);

	printf("\nCopySorDetails : [%d]",n_found_BulkSorPostAct);
	TC_write_syslog("\n CopySorDetails : [%d]",n_found_BulkSorPostAct);

	if ( n_found_BulkSorPostAct > 0 )
	{

		ITK_CALL ( QRY_find2("Item Revision...", &query_d_Tag ) ) ;

		printf("\nQuery_QuickSOR_copy_attr Item Revision...Query found");
		TC_write_syslog("\nQuery_QuickSOR_copy_attr Item Revision...Query found");

		ITK_CALL ( QRY_execute_with_sort ( query_d_Tag, no_d_entries, qry_d_entries, qry_d_values,n_to_sort, keys, orders, &result_d_Count, &part_d_Objs ) );
		
		printf("\nresult_d_Count : [%d]", result_d_Count);
		TC_write_syslog("\nresult_d_Count : [%d]", result_d_Count);
		
		if ( result_d_Count > 0 )
		{
			for ( i_d = 0 ; i_d < result_d_Count ; i_d++ )
			{
					char *q_d_SORPart_no = NULL;
					char *q_d_SORPart_RevSeq = NULL;
					char *q_d_SORPart_Rev = NULL;
					char *q_d_SORPart_Seq = NULL;
					
					Part_d_Tag = part_d_Objs [i_d] ; 
					
					ITK_CALL ( AOM_ask_value_string ( Part_d_Tag, "item_id", &q_d_SORPart_no ) ) ;
					printf("\nq_a_SORPart_no : [%s]", q_d_SORPart_no);
					TC_write_syslog("\nq_a_SORPart_no : [%s]", q_d_SORPart_no);


					ITK_CALL ( AOM_ask_value_string ( Part_d_Tag, "item_revision_id", &q_d_SORPart_RevSeq ) ) ;
					printf("\nq_d_SORPart_RevSeq : [%s]", q_d_SORPart_RevSeq);
					TC_write_syslog("\nq_d_SORPart_RevSeq : [%s]", q_d_SORPart_RevSeq);

					q_d_SORPart_Rev = strtok(q_d_SORPart_RevSeq,";");
					q_d_SORPart_Seq = strtok(NULL,"");

					printf("\nq_d_SORPart_Rev : [%s]", q_d_SORPart_Rev);
					TC_write_syslog("\nq_d_SORPart_Rev : [%s]", q_d_SORPart_Rev);

					printf("\nq_d_SORPart_Seq : [%s]", q_d_SORPart_Seq);
					TC_write_syslog("\nq_d_SORPart_Seq : [%s]", q_d_SORPart_Seq);
					
					if ( ( tc_strcmp ( Rev, q_d_SORPart_Rev ) == 0 ) && ( tc_strcmp ( Seq, q_d_SORPart_Seq ) == 0 ) )
					{
						get_sor_attached_to_part ( Part_d_Tag, Rev, Seq  ) ;	
						break;
					}
			}
		}

	}
		
		
	return ITK_ok;
}

int T5_BulkSorPostAct( METHOD_message_t * msg, va_list /*args*/ )
{

	printf("\nT5_BulkSorPostAct...............");
	TC_write_syslog("\nT5_BulkSorPostAct...............");

	int ifail = ITK_ok;
	int qSORPartCnt = 0;
	int i = 0;
	int n_found_BulkSorPostAct = 0;
	char *BulkSor_name = NULL;
	char *partno = NULL;
	char *Rev = NULL;
	char *Seq = NULL;
	char **qSORPartnumber = NULL;
	char *qt5_BulkPPPMPrjCode = NULL;
	char *qBulkPrjCode = NULL;
	char *BulkSorPostActcheck = NULL;
	char *BulkSorPostActstatus = NULL;

	BulkSorPostActcheck = (char *)MEM_alloc(50 *sizeof(char));
	BulkSorPostActstatus = (char *)MEM_alloc(50 *sizeof(char));

	tc_strcpy(BulkSorPostActcheck,"BulkSorPostAct");
	tc_strcpy(BulkSorPostActstatus,"ON");

	n_found_BulkSorPostAct = tm_check_info_control_object_BulkSorPostAct ( BulkSorPostActcheck,BulkSorPostActstatus);
	

	printf("\nBulkSorPostAct n_found_BulkSorPostAct : [%d]",n_found_BulkSorPostAct);
	TC_write_syslog("\nBulkSorPostAct n_found_BulkSorPostAct : [%d]",n_found_BulkSorPostAct);

	if ( n_found_BulkSorPostAct > 0 )
	{
		tag_t BulkSor_tag = msg->object_tag;

		ifail =(AOM_ask_value_string(BulkSor_tag, "object_name", &BulkSor_name));
		printf ( "\nT5_BulkSorPostAct BulkSor_name : [%s]",BulkSor_name ) ;
		TC_write_syslog ( "\nT5_BulkSorPostAct BulkSor_name : [%s]",BulkSor_name ) ;

		ifail =(AOM_ask_value_strings(BulkSor_tag, "t5_SOR_Part_Numbers", &qSORPartCnt,&qSORPartnumber));

		printf ( "\nT5_BulkSorPostAct qSORPartCnt : [%d]",qSORPartCnt ) ;
		TC_write_syslog ( "\nT5_BulkSorPostAct qSORPartCnt : [%d]",qSORPartCnt ) ;

		ifail =(AOM_ask_value_string(BulkSor_tag, "t5_BulkPrjCode",&qBulkPrjCode));
		printf ( "\nT5_BulkSorPostAct qBulkPrjCode : [%s]",qBulkPrjCode ) ;
		TC_write_syslog ( "\nT5_BulkSorPostAct qBulkPrjCode : [%s]",qBulkPrjCode ) ;

		ifail =(AOM_ask_value_string(BulkSor_tag, "t5_BulkPPPMPrjCode",&qt5_BulkPPPMPrjCode));
		printf ( "\nT5_BulkSorPostAct qt5_BulkPPPMPrjCode : [%s]",qt5_BulkPPPMPrjCode ) ;
		TC_write_syslog ( "\nT5_BulkSorPostAct qt5_BulkPPPMPrjCode : [%s]",qt5_BulkPPPMPrjCode ) ;


		tm_get_pppm_variant(BulkSor_tag,qBulkPrjCode,qt5_BulkPPPMPrjCode);


		if (qSORPartCnt > 0)
		{

			for(i = 0 ; i < qSORPartCnt ; i++ )
			{

				printf ( "\nT5_BulkSorPostAct qSORPartnumber : [%d]\t[%s]",i,qSORPartnumber[i] ) ;
				TC_write_syslog ( "\nT5_BulkSorPostAct qSORPartnumber : [%d]\t[%s]",i,qSORPartnumber[i] ) ;

				partno = strtok(qSORPartnumber[i],",");
				Rev = strtok(NULL,",");
				Seq = strtok(NULL,",");



				BulkSOR_qSOR_Rel_function(BulkSor_tag,BulkSor_name,partno,Rev,Seq);
				
				
				Query_Part_to_copy_attr_on_qsor_of_old_rev ( partno, Rev, Seq ) ;

				//BulkSOR_qSOR_Variant_set(BulkSor_tag);
				//BulkSOR_pdf_rel_fuction ( BulkSor_tag, BulkSor_name ) ;
				
				//BulkSOR_zip_rel_fuction ( BulkSor_tag, BulkSor_name ) ;  //commented by Shubham on 15Apr2025

			}
			BulkSOR_pdf_rel_fuction ( BulkSor_tag, BulkSor_name ) ;

			BulkSOR_zip_rel_fuction ( BulkSor_tag, BulkSor_name ) ;

		}

		BulkSOR_qSOR_Variant_set(BulkSor_tag);
	}


	MEM_free(BulkSorPostActcheck);
	MEM_free(BulkSorPostActstatus);

	return ifail;

}
