#include "TMLLibrary_server_exits.h"

int tm_TLCChk(EPM_action_message_t msg)
{

    //int ifail = ITK_ok;

    int i			= 0;
    int no_attach	= 0;
    int count		= 0;
    int Tskcount	= 0;
    int p			= 0;
    int prtcnt		= 0;
    int k			= 0;

	char   *username		= NULL;
	char   *CurrentTask		= NULL;
	char   *parent_name		= NULL;
	char   *objTypeofTask	= NULL;
	char   *objType			= NULL;
	char   *DMLtype			= NULL;
	char   *sDMLDR			= NULL;
	char   *Tsk_object_type = NULL;
	char   *item_id			= NULL;
	char   *partid			= NULL;
	char   *parttype		= NULL;

	char   *sTLCInfo1  = NULL;
	char   *sTLCInfo2  = NULL;
	char   *sTLCInfo3  = NULL;
	char   *sTLCInfo4  = NULL;

	tag_t user_tag		= NULLTAG;
	tag_t roottask		= NULLTAG;
	tag_t DMLRevTag		= NULLTAG;
	tag_t query			= NULLTAG;
	tag_t objTypTag		= NULLTAG;
	tag_t TskTags1		= NULLTAG;

	tag_t *taskAttachments	= NULLTAG;
	tag_t *contrlObjs		= NULLTAG;
	tag_t *TskTags			= NULLTAG;
	tag_t *PrtsTag			= NULLTAG;


	logical is_latest;

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	

	printf("\n start:tm_TLCChk."); fflush(stdout);
	TC_write_syslog("\n start:tm_TLCChk.\n");

	POM_get_user(&username,&user_tag);
	printf("\n Starting for tm_TLCChk :%s....\n",username);fflush(stdout);




	//CALLAPI(SA_find_user2("infodba",&superuserTag));
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_TLCChk No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	char *dmlTaskNo =(char *) MEM_alloc(sizeof(char)* 50);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_TLCChk:INSIDE Attachments.");fflush(stdout);
			//DMLtsk_tag=taskAttachments[i];

			DMLRevTag=taskAttachments[i];

			printf("\n tm_TLCChk:INSIDE not null tag.");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="TLCCHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_TLCChk Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sTLCInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sTLCInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sTLCInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sTLCInfo4));
					printf("\n L1:sTLCInfo1 is : [%s]  L2:sTLCInfo2 is : [%s]  L3:sTLCInfo3 is : [%s] L4:sTLCInfo4 is : [%s]\n",sTLCInfo1,sTLCInfo2,sTLCInfo3,sTLCInfo4);fflush(stdout);

					if(tc_strstr(sTLCInfo1,"TLCOFF5") != NULL)
					{
					    return 0;
					}
					if(tc_strstr(sTLCInfo1,"TLCOFF1") == NULL)
					{
						
						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_TLCChk objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n tm_TLCChk object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&objType));
						    printf("\n tm_TLCChk item_id is %s\n", objType);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_TLCChk--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
							   printf("\n tm_TLCChk--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\n tm_TLCChk t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
								printf("\n tm_TLCChk sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

								if(tc_strstr(sTLCInfo1,"NPIOFF3") == NULL)
								{
									if((tc_strcmp(DMLtype,"Veh")==0) || (tc_strcmp(DMLtype,"TODR")==0))
									{
										if(tc_strstr(sTLCInfo1,"NPIOFF6") != NULL)
										{
											if((tc_strcmp(sDMLDR,"DR3")==0) || (tc_strcmp(sDMLDR,"AR3")==0))
											{
												//DR2_flag=1;
												printf("\ntm_TLCChk inside for condition");fflush(stdout);
												
												ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
												printf("\n tm_TLCChk 1.No of Parts found = %d\n",Tskcount);fflush(stdout);

												for(p=0;p<Tskcount;p++)
												{
													TskTags1=TskTags[p];
													if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
													printf("\n tm_TLCChk:Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

													if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
													{
														ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
														printf("\n tm_TLCChk item_id is = %s \n",item_id);fflush(stdout);

														if (tc_strstr(item_id,"_00")!=NULL)
														{
															if(tc_strcmp(DMLtype,"Veh")==0)
															{
																if(AOM_ask_value_tags(TskTags1,"CMHasSolutionItem",&prtcnt,&PrtsTag));
																printf("\n tm_TLCChk item_id:Now prtcnt:%d.",prtcnt);fflush(stdout);
															}
															else if (tc_strcmp(DMLtype,"TODR")==0)
															{
																if(AOM_ask_value_tags(TskTags1,"CMReferences",&prtcnt,&PrtsTag));
																printf("\n tm_TLCChk item_id:Now prtcnt:%d.",prtcnt);fflush(stdout);
															}
															else
															{
																printf("\n tm_TLCChk not applicable for TLC");fflush(stdout);
															}

															if (prtcnt>0)
															{
																for (k=0; k<prtcnt; k++)
																{
																	ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
																	printf("\n tm_TLCChk partid = %s \n",partid);fflush(stdout);


																	ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
																	printf("\n tm_TLCChk parttype = %s \n",parttype);fflush(stdout);
																	if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
																	{
																		return 0;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_TLCChk Control objects :Off");fflush(stdout);
						return 10002;
					}
				}
			}
		}
	}
	printf("\n tm_TLCChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_TLCChk Function end...");
	return 10002;

}