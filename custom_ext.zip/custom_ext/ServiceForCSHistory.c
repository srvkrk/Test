#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)


#define ITK_CALL(x) {           \
    int stat;                     \
    char *err_string;             \
    if( (stat = (x)) != ITK_ok)   \
    {                             \
    EMH_ask_error_text (stat, &err_string);                 \
    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
    if(err_string) MEM_free(err_string);                                \
    exit (EXIT_FAILURE);                                                   \
    }                                                                    \
}
// /*
int ServiceForCSHistoryMaster(void *return_data)
{
	
	int 			status;
	int				ifail 				=	ITK_ok;
	char 			*selectedPart	=	NULL;
	char 			*selectedPartRev		=	NULL;
	char 			*selectedPartSeq		=	NULL;
	char 			*selectedPlant		= 	NULL;
	
	char	command[1000];
	printf("\n I am in main program");fflush(stdout);
	USERARG_get_string_argument(&selectedPlant);
	USERARG_get_string_argument(&selectedPart);	
	USERARG_get_string_argument(&selectedPartRev);	
	USERARG_get_string_argument(&selectedPartSeq);	
	
	printf("\n Input selectedPlant :: %s ",selectedPlant);fflush(stdout);
	printf("\n Input selectedPart :: %s ",selectedPart);fflush(stdout);
	printf("\n Input selectedPartRev :: %s ",selectedPartRev);fflush(stdout);
	printf("\n Input selectedPartSeq :: %s ",selectedPartSeq);fflush(stdout);
	
	

	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char     *qry_valuesCntrl1[3]= {"CSHistory","Rpt","0"};

    ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
       if (qryTagCntrl1)
       {
            printf("\n CSHistory \n");fflush(stdout);
		    printf("\n Control Object CSHistory Query Found \n");fflush(stdout);
			
			ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		    printf("\n No of Control Object CSHistory  Found %d ",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
		    {
				char* t5_Userinfo1 = NULL;
				char Command[200];
				tag_t obj = list_of_WSO_cntrl_tags1[0];
				ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	

				sprintf(Command,"%s  %s %s %s %s",t5_Userinfo1,selectedPlant,selectedPart,selectedPartRev,selectedPartSeq);
				printf("Executing Command = %s",Command);fflush(stdout);
				TC_write_syslog("Command = %s\n",command);
				system(Command);
				printf("After executing Command");fflush(stdout);
		    }
		    else
		    {
				printf(" \n Control Object Not Found \n");
		    }
	   }


	return ifail;
}



extern int AllUserServiceForCSHistory(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	int nargs = 4;//To be recieved from RAC
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE; //Plant
	inputArgTypes[1] = USERARG_STRING_TYPE; //Part Number
	inputArgTypes[2] = USERARG_STRING_TYPE; //Rev
	inputArgTypes[3] = USERARG_STRING_TYPE; //Seq
		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n AllUserServiceForCSHistoryCalling before....ServiceForCSHistoryMaster");fflush(stdout);  
	ifail=USERSERVICE_register_method("ServiceForCSHistoryMaster",(USER_function_t)ServiceForCSHistoryMaster,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

extern DLLAPI int ServiceForCSHistory_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....ServiceForCSHistory");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "ServiceForCSHistory", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceForCSHistory);
	printf("\n After registering userservice....ServiceForCSHistory");fflush(stdout);
	return ( ITK_ok );
}


