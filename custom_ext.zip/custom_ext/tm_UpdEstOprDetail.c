/*******************
*  File            :   tm_UpdEstOprDetail.c
*  Created By      :   Vijay Khandare
*  Created On      :   15-02-2024
*  Purpose         :   Upload Estimate Operations details
*  TZ			   :   
*******************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;			

char* replace(char *str, const char *find, const char *replace) 
{
    // Allocate memory for the new string
    char *result;
    int i, count = 0;
    int find_len = strlen(find);
    int replace_len = strlen(replace);

    // Count the number of times the 'find' substring occurs in the original string
    for (i = 0; str[i] != '\0'; i++) 
	{
        if (strstr(&str[i], find) == &str[i])
		{
            count++;
           // Jump index to the next occurrence of the 'find' substring
            i += find_len - 1;
        }
    }
    // Allocate memory for the new string
    result = (char *)MEM_alloc(i + count * (replace_len - find_len) + 1);  
    i = 0;
    while (*str)
	{
        // Compare the substring with the result
        if (strstr(str, find) == str) 
		{
            strcpy(&result[i], replace);
            i += replace_len;
            str += find_len;
        } 
		else 
	    {
            result[i++] = *str++;
        }
    }
    result[i] = '\0';
    //printf("Replaced string: %s\n", result);
    return result;
}
;
int tm_UpdEstOprFn(char *EstimateShNo,char *Infiledata)
{
	
    int      noofEst            = 0;
    tag_t   *ESTSheetSet        = NULLTAG;
    tag_t    EstQrtag           = NULLTAG;
    char     *StringLine        = NULL;

    StringLine = (char *) MEM_alloc(sizeof(Infiledata));
    
    ITK_CALL(QRY_find2("Item Revision...", &EstQrtag));//API changed for 12.2 to 14.3 upgrade...
	if(EstQrtag != NULLTAG)
	{
		printf("General query found\n");fflush(stdout);
	} 
	else
		printf("General Query not found\n");fflush(stdout);

    char *attribute[2] = {"Item ID","Type"};
    char *values[2]; 
    values[0] = EstimateShNo;
    values[1] = "Estimate Sheet Revision";
    
    printf("tm_UpdEstOprFn ... Input Estimate sheet number is = %s\n",EstimateShNo);fflush(stdout);

    ITK_CALL(QRY_execute(EstQrtag,2,attribute,values,&noofEst,&ESTSheetSet));

    if(noofEst > 0)
    {
        printf("Estimate sheet found.....\n");fflush(stdout);

        tag_t     EstimateObj       = NULLTAG;
        tag_t     EstOperRel        = NULLTAG;
        int       NoofOper          = 0;
        tag_t     *EstOperSet       = NULLTAG;
        char      *EstObjName       = NULL;
        char      *EstRevId         = NULL;
        char      *EsRlzState       = NULL;
        char      *EstAgency        = NULL;

        EstimateObj = ESTSheetSet[0];
        ITK_CALL(AOM_ask_value_string(EstimateObj,"item_id",&EstObjName));
        printf("Estimate sheet Number = %s\n",EstObjName);fflush(stdout);

        ITK_CALL(AOM_ask_value_string(EstimateObj,"item_revision_id",&EstRevId));
        printf("Estimate revision id is = %s\n",EstRevId);fflush(stdout);

        ITK_CALL(AOM_ask_value_string(EstimateObj,"t5_PEAgency",&EstAgency));
        printf("Estimate revision Agency is = %s\n",EstAgency);fflush(stdout);

        ITK_CALL(AOM_UIF_ask_value(EstimateObj,"release_status_list",&EsRlzState));
        printf("Estimate sheet release state = %s\n",EsRlzState);fflush(stdout);

        ITK_CALL(GRM_find_relation_type("T5_EstimateOprationRelation",&EstOperRel));
        ITK_CALL(GRM_list_secondary_objects_only(EstimateObj,EstOperRel,&NoofOper,&EstOperSet));

        if(NoofOper > 0)
        {
            printf("Estimate sheet Operation found.....\n");fflush(stdout);
            StringLine = strtok(Infiledata,"\n");

            while(StringLine != NULL)
            {
                char          *UpdOprNo               = NULL;
                char          *UpdTime                = NULL;
                //char          *CPCCYCLE               = NULL;
                char          *UpdGangsize            = NULL;
                char          *StringLine1            = NULL;
                UpdOprNo = (char *) MEM_alloc(100 * sizeof(char *));
                //CPCCYCLE = (char *) MEM_alloc(100 * sizeof(char *));
                UpdTime = (char *) MEM_alloc(100 * sizeof(char *));
                UpdGangsize = (char *) MEM_alloc(100 * sizeof(char *));
                StringLine1 = (char *) MEM_alloc(100 * sizeof(char *));
                StringLine1 = StringLine;
                tc_strcpy(UpdOprNo,strsep(&StringLine1,","));
		        tc_strcpy(UpdTime,strsep(&StringLine1,","));
		        tc_strcpy(UpdGangsize,strsep(&StringLine1,","));
                
                StringLine = strtok(NULL,"\n");
            
                int EstOprItr = 0;
	            for(EstOprItr = 0 ; EstOprItr < NoofOper ; EstOprItr++)
	            {
                    tag_t      EstOperObj          = NULLTAG;
                    char       *OprNum            = NULL;
                    char       *APLTime           = NULL;
                    char       *PSDTime           = NULL;
                    char       *APLGang           = NULL;
                    char       *PSDGang           = NULL;
    
    
                    EstOperObj = EstOperSet[EstOprItr];
    
                    ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEOpnNumber",&OprNum));
                    //printf("Estimate sheet Operation Number = %s\n",OprNum);fflush(stdout);
    
                    ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PETimeOpnApl",&APLTime));
                    //printf("Estimate sheet Operation APL Time = %s\n",APLTime);fflush(stdout);
    
                    ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PETimeOpnPsd",&PSDTime));
                    //printf("Estimate sheet Operation PSD Time = %s\n",PSDTime);fflush(stdout);
    
                    ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEAplGangSize",&APLGang));
                    //printf("Estimate sheet Operation APL Gang = %s\n",APLGang);fflush(stdout);
    
                    ITK_CALL(AOM_ask_value_string(EstOperObj,"t5_PEGangSize",&PSDGang));
                    //printf("Estimate sheet Operation PSD Gang = %s\n",PSDGang);fflush(stdout);

                    if(tc_strcmp(UpdOprNo,OprNum)==0)
	                {
                        if(tc_strcmp(EstAgency,"APL")==0)
	                    {
                            ITK_CALL(AOM_lock(EstOperObj));
				    	    ITK_CALL (AOM_set_value_string(EstOperObj,"t5_PETimeOpnApl",UpdTime));
				    	    ITK_CALL (AOM_set_value_string(EstOperObj,"t5_PEAplGangSize",UpdGangsize));
				    	    ITK_CALL(AOM_save_with_extensions(EstOperObj));//API changed for 12.2 to 14.3 upgrade...
			                ITK_CALL(AOM_unlock(EstOperObj));
                        }
                        else if(tc_strcmp(EstAgency,"PSD")==0)
	                    {
                            ITK_CALL(AOM_lock(EstOperObj));
				    	    ITK_CALL (AOM_set_value_string(EstOperObj,"t5_PETimeOpnPsd",UpdTime));
				    	    ITK_CALL (AOM_set_value_string(EstOperObj,"t5_PEGangSize",UpdGangsize));
				    	    ITK_CALL(AOM_save_with_extensions(EstOperObj));//API changed for 12.2 to 14.3 upgrade...
			                ITK_CALL(AOM_unlock(EstOperObj));
                        }
                        else
                        {
                        }
                    }
                }
            }
        }
    }
    else
    {
        printf("Estimate sheet not found......\n");fflush(stdout);
    }

    return ITK_ok;
}

int UpdEstOpr()
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *EstimateNO         = NULL;
	char     *Infiledata         = NULL;		

	printf("\n inside the function DML_ImplosionRpt .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&EstimateNO);
	USERARG_get_string_argument(&Infiledata);

	printf("\n Input Estimate number :: %s \n",EstimateNO);fflush(stdout);
	printf("\n Input File data is   :: %s \n",Infiledata);fflush(stdout);

	//..........................................................
		
	tm_UpdEstOprFn(EstimateNO,Infiledata);

    return ifail;
}

extern int AllUserServiceFnUpdEstOprFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 2;
    int retValueType;
    int inputArgTypes[2] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //Estimate sheet Number 
    inputArgTypes[1] = USERARG_STRING_TYPE; //Input file data
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("UpdEstOpr",(USER_function_t)UpdEstOpr,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_UpdEstOprDetail_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_UpdEstOprDetail", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnUpdEstOprFn);
    return ifail;
}
