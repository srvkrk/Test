#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#define NUM_ENTRIES 1
#define TE_MAXLINELEN 128
#define _CRT_SECURE_NO_DEPRECATE
#include <Fnd0Participant/participant.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>

void removeparticipant(tag_t target_obj,char *participants)
{
    tag_t	mppaplplanner	= NULLTAG;
    char*	type_name;
    int		oldusrcount	   = 0;
    tag_t*	OldParticipantRel   	= NULLTAG;

    TCTYPE_find_type( participants, participants, &mppaplplanner);
    TCTYPE_ask_name2(mppaplplanner,&type_name);
    printf("\n Type name of participant:- %s",type_name );


    PARTICIPANT_ask_participants(target_obj,mppaplplanner,&oldusrcount,&OldParticipantRel);
    printf("\n Get the participant type" );
    PARTICIPANT_remove_participants(target_obj,oldusrcount,OldParticipantRel);

    
}
int RemoveRlzStat(tag_t Obj_tag, char* LCSToRemove)//function to remove release status of passed object
{
	tag_t class_id = NULLTAG;
	tag_t RlzStatLst_AttrID = NULLTAG;
	tag_t *RlzStatLst_Attr_tag;
	char *class_name = NULL;
	char *Release_Status = NULL;
	char *Obj_ID =NULL;
	logical	log1;
	logical	*is_it_null = NULL;
	logical	*is_it_empty = NULL;
	//int RlzStatLst_AttrID = 0;
	int RlzStatLst_Length = 0;
	int count=0;
	int	ifail=0;

		tag_t*    status_list1=NULLTAG;
	int              st_count1 = 0;

	(POM_class_of_instance(Obj_tag,&class_id)); 
	(POM_name_of_class(class_id,&class_name));
	printf("\n Class Name is :%s\n",class_name);

	(POM_attr_id_of_attr("release_status_list",class_name,&RlzStatLst_AttrID));
	(WSOM_ask_release_status_list(Obj_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	(POM_unload_instances(1,&Obj_tag));
	(POM_load_instances(1,&Obj_tag,class_id,1));
	(POM_is_loaded(Obj_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Faillure\n"  );


	( POM_length_of_attr(Obj_tag, RlzStatLst_AttrID, &RlzStatLst_Length) );
	( POM_ask_attr_tags(Obj_tag, RlzStatLst_AttrID, 0, RlzStatLst_Length, &RlzStatLst_Attr_tag, &is_it_null, &is_it_empty ));
	int flag = 0;
	for(count=0; count<RlzStatLst_Length;count++)
	{
		AOM_ask_value_string(Obj_tag,"item_id",&Obj_ID);		//to get object id
		printf("\n Object ID is :%s\n",Obj_ID);
		AOM_ask_name(RlzStatLst_Attr_tag[count], &Release_Status);
		printf("\n Release status is1 :%s:%s\n",Release_Status,LCSToRemove);

		if( (tc_strcmp(Release_Status,LCSToRemove)==0)|| (tc_strcmp(LCSToRemove,"T5_LcsApluReview")==0) )	
		{
			printf("\n Release status is2 :%s\n",Release_Status);
			
			(POM_remove_from_attr(1,&Obj_tag,RlzStatLst_AttrID,flag,1));  //Removes status from object
			(POM_save_instances(1,&Obj_tag,1));
			(POM_refresh_instances(1,&Obj_tag,class_id,2));
			(AOM_lock(Obj_tag));
			(AOM_save_without_extensions(Obj_tag));
			(AOM_refresh(Obj_tag,1));
			(AOM_unlock(Obj_tag));
			printf("\n Release Status Removed Successfully :%s\n");

		}
		flag++;
	}
	MEM_free(RlzStatLst_Attr_tag);
	return ITK_ok;
}

void GetGroup(char *plant,char *Input,char *PlantCode,char *PlantName,char *GroupName)
{
    printf("\n ************************************ \n");fflush(stdout);
    printf("\n inside function \n");fflush(stdout);
    char UserInfo1[100];
    tc_strcpy(UserInfo1,Input);
    //tc_strcat(UserInfo1,"1001-PNE;3100-UTK;1500-DWD;2001-JSR;3001-LKO;");
    printf("%s", UserInfo1);
    char PlantNameStored[100];
    tc_strcpy(PlantNameStored,"");
    char *token = strtok(UserInfo1, ";"); //1001-PNE
    while (token != NULL) 
    {
        printf("\n token : %s ", token);
        if(tc_strstr(token,plant)!=NULL)
        {
            tc_strcat(PlantNameStored,token);
        }
        token = strtok(NULL, ";");
    }
    printf("\n PlantNameStored = [%s] \n", PlantNameStored);
    char *PlantCode1 = NULL;
    char *PlantName1 = NULL;
    char *GroupName1 = NULL;
    PlantCode1 = tc_strtok(PlantNameStored,"-");
    PlantName1 = tc_strtok(NULL,"-");
    GroupName1 = tc_strtok(NULL,"-");
    printf("\n PlantCode = [%s] \n", PlantCode1);
    printf("\n PlantName = [%s] \n", PlantName1);
    printf("\n GroupName = [%s] \n", GroupName1);

    tc_strcpy(PlantCode,PlantCode1); // 1001
    tc_strcpy(PlantName,PlantName1); // PNE
    tc_strcpy(GroupName,GroupName1); // pBOP_APLPUNE

    //PNE-CHA-

    printf("\n ************************************ \n");fflush(stdout);
}

void PlannerReviewer(char *pbopplantcode, char *Aggregate,char *userinfo1,char* APLPlanner,char* APLReviewer,char *PSDPlanner,char *PSDReviewer,char *ReturnGroupName)
{  
    

    char *PlantCode  = NULL;
    char *PlantName = NULL;
    char *GroupName = NULL;

    PlantCode  = (char *) MEM_alloc(50 * sizeof(char *));
    PlantName = (char *) MEM_alloc(50 * sizeof(char *));
    GroupName = (char *) MEM_alloc(50 * sizeof(char *));

    GetGroup(pbopplantcode,userinfo1,PlantCode,PlantName,GroupName);

    tc_strcpy(ReturnGroupName,GroupName);

    tc_strcpy(APLPlanner,"");
    tc_strcat(APLPlanner,PlantName);
    tc_strcat(APLPlanner,"_");
    tc_strcat(APLPlanner,Aggregate);
    tc_strcat(APLPlanner,"_");
    tc_strcat(APLPlanner,"TS_Planner");

    tc_strcpy(APLReviewer,"");
    tc_strcat(APLReviewer,PlantName);
    tc_strcat(APLReviewer,"_");
    tc_strcat(APLReviewer,Aggregate);
    tc_strcat(APLReviewer,"_");
    tc_strcat(APLReviewer,"TS_Reviewer");;

    tc_strcpy(PSDPlanner,"");
    tc_strcat(PSDPlanner,PlantName);
    tc_strcat(PSDPlanner,"_");
    tc_strcat(PSDPlanner,Aggregate);
    tc_strcat(PSDPlanner,"_");
    tc_strcat(PSDPlanner,"PSD_Planner");

    tc_strcpy(PSDReviewer,"");
    tc_strcat(PSDReviewer,PlantName);
    tc_strcat(PSDReviewer,"_");
    tc_strcat(PSDReviewer,Aggregate);
    tc_strcat(PSDReviewer,"_");
    tc_strcat(PSDReviewer,"PSD_Reviewer");

    printf("\n ************************************ \n");fflush(stdout);
    printf("\n APLPlanner : [%s] \n",APLPlanner);fflush(stdout);
    printf("\n APLReviewer : [%s] \n",APLReviewer);fflush(stdout);
    printf("\n PSDPlanner : [%s] \n",PSDPlanner);fflush(stdout);
    printf("\n PSDReviewer : [%s] \n",PSDReviewer);fflush(stdout);
    printf("\n ************************************ \n");fflush(stdout);
}

void setAddTAG_1(int *count,tag_t **objlist,tag_t obj ) 
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


int AssignaplPlannerandreviewer(tag_t target_obj,char *aggrigate,char *groupName, char *pBOP_Planner_role ,char *pBOP_Reviewer_role)
{
    int	num_of_roles = 0;
    tag_t *role_tags = NULLTAG;
    char *rolename = NULL;
    int a= 0;
    int b= 0;
    int	num_of_members = 0;
    tag_t *member_tags = NULLTAG;
    tag_t user_tag = NULLTAG;
    
    tag_t	participant_type	= NULLTAG;
    tag_t	participant_tag		= NULLTAG;
    tag_t	group_tag = NULLTAG;

    printf("Aggrigate Name recived:- %s ",aggrigate);
    printf("Group Name:- %s ",groupName);
    printf("\nPlanner Role:- %s",pBOP_Planner_role );
    printf("\nReviewer Role:- %s",pBOP_Reviewer_role) ;

    SA_find_group(groupName,&group_tag);
    if (group_tag != NULLTAG)
    {
        printf("\n Inside group tag..............");fflush(stdout);
        SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags);
        if(num_of_roles>0)
        {
            printf("\n Role Name found.............");fflush(stdout);
            for (a=0;a<num_of_roles ;a++ )
            {
                SA_ask_role_name2(role_tags[a],&rolename);// 2 planner reviewer
                if(strcmp(rolename,pBOP_Planner_role)==0)
                {
                    printf("Role Name compared as Planner going to assing APL Planner....");
                    int b= 0;
                    int	num_of_members = 0;
                    tag_t *member_tags = NULLTAG;

                    printf("planner role ame is:-  %s\n", rolename);
                    SA_find_groupmember_by_role(role_tags[a],group_tag,&num_of_members,&member_tags);
                    if(num_of_members> 0)
                    {
                        for (b=0;b<num_of_members ;b++)
                        {
                            tag_t*	ptypes		= NULLTAG;
                            tag_t*	ptypes2		= NULLTAG;
                            int p1=0;
                            int p2=0;
                            tag_t* participant_list = NULLTAG;
                            tag_t user_tag = NULLTAG;
                            char *userid = NULL;
                            tag_t	participant_type	= NULLTAG;
                            logical bypass_assignable_check =true;
                            SA_ask_groupmember_user(member_tags[b],&user_tag);
                            SA_ask_user_identifier2(user_tag,&userid);
                            printf("\n Planner UserID:- %s\n",userid);

                            char *finalaplplanner  = NULL;
                            finalaplplanner  = (char *) MEM_alloc(50 * sizeof(char *));
                            tc_strcpy(finalaplplanner,"");
                            tc_strcat(finalaplplanner,aggrigate);
                            tc_strcat(finalaplplanner,"_TS_Planner");
                            printf("\n Final finalplanner:-  - %s\n",finalaplplanner);
                            

                            char *finalpsdplanner  = NULL;
                            finalpsdplanner  = (char *) MEM_alloc(50 * sizeof(char *));
                            tc_strcpy(finalpsdplanner,"");
                            tc_strcat(finalpsdplanner,aggrigate);
                            tc_strcat(finalpsdplanner,"_PSD_Planner");
                            printf("\n Final finalplanner:-  - %s\n",finalpsdplanner);

                            if(tc_strstr(rolename,finalaplplanner)!=NULL)
                            {
                                EPM_get_participanttype ("T5_mppaplplanner",&participant_type);

                            }
                            else if(tc_strstr(rolename,finalpsdplanner)!=NULL)
                            {
                                EPM_get_participanttype ("T5_mpppsdplanner",&participant_type);

                            }
                            setAddTAG_1(&p1,&ptypes,participant_type);
                            printf("\n Participant has been added....");
                            setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                            printf("\n Member has been added....");
                            AOM_lock(target_obj);	
                            PARTICIPANT_add_participants(target_obj,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list);
                            AOM_save_without_extensions(target_obj);
                            AOM_unlock(target_obj);
                            printf("\n Planner assigned to : %s\n",userid);fflush(stdout);

                        }
                        
                    }
                    AOM_refresh ( target_obj,TRUE);
                    printf("\n AOM Refresh added");fflush(stdout);

                }
                else if (strcmp(rolename, pBOP_Reviewer_role)==0)
                {
                    printf("Role Name compared as reviewer going to assing APL Reviewr....");
                    int b= 0;
                    int	num_of_members = 0;
                    tag_t *member_tags = NULLTAG;

                    printf("Reviewer role ame is:-  %s\n", rolename);
                    SA_find_groupmember_by_role(role_tags[a],group_tag,&num_of_members,&member_tags);
                    if(num_of_members> 0)
                    {
                        for (b=0;b<num_of_members ;b++)
                        {

                            tag_t*	ptypes		= NULLTAG;
                            tag_t*	ptypes2		= NULLTAG;
                            int p1=0;
                            int p2=0;
                            tag_t* participant_list = NULLTAG;
                            tag_t user_tag = NULLTAG;
                            char *userid = NULL;
                            tag_t	participant_type	= NULLTAG;
                            logical bypass_assignable_check =true;
                            SA_ask_groupmember_user(member_tags[b],&user_tag);
                            SA_ask_user_identifier2(user_tag,&userid);
                            printf("\n Reviewer UserID:- %s\n",userid);


                            char *finalaplreviewer  = NULL;
                            finalaplreviewer  = (char *) MEM_alloc(50 * sizeof(char *));
                            tc_strcpy(finalaplreviewer,"");
                            tc_strcat(finalaplreviewer,aggrigate);
                            tc_strcat(finalaplreviewer,"_TS_Reviewer");
                            printf("\n Final finalaplreviewer:-  - %s\n",finalaplreviewer);

                            char *finalpsdreviewer  = NULL;
                            finalpsdreviewer  = (char *) MEM_alloc(50 * sizeof(char *));
                            tc_strcpy(finalpsdreviewer,"");
                            tc_strcat(finalpsdreviewer,aggrigate);
                            tc_strcat(finalpsdreviewer,"_PSD_Reviewer");
                            printf("\n Final finalplanner:-  - %s\n",finalpsdreviewer);
                            

                            if(tc_strstr(rolename,finalaplreviewer)!=NULL)
                            {
                                EPM_get_participanttype ("T5_mppaplreviewer",&participant_type);
                            }
                            else if(tc_strstr(rolename,finalpsdreviewer)!=NULL)
                            {
                                EPM_get_participanttype ("T5_mpppsdreviewer",&participant_type);
                            }

                            setAddTAG_1(&p1,&ptypes,participant_type);
                            printf("\n Participant has been added....");
                            setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                            printf("\n Member has been added....");
                            AOM_lock(target_obj);	
                            PARTICIPANT_add_participants(target_obj,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list);
                            AOM_save_without_extensions(target_obj);
                            AOM_unlock(target_obj);
                            printf("\n Planner assigned to : %s\n",userid);fflush(stdout);

                        }
                        
                    }
                    AOM_refresh ( target_obj,TRUE);
                    printf("\n AOM Refresh added");fflush(stdout);


                }   
                else
                {
                    printf("Role Name not found");

                }
            }
        }
    }

    return ITK_ok;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
};
void  get_CtrlVal_APLStateInf( char * Plt_Code ,char  APlRevwLC[40],char  AplWrkngLC[40],char  AplRlzdLC[40],char  StdWrkngLC[40],char  StdRlzdLC[40], char PlantLCFlag[40], char StdPlant[40], char StdRevRule[40], char StdCLosRule[40],char StdView[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *APlRevw 			= NULL;
	 char *AplWrkng			= NULL;
	 char *AplRlzd			= NULL;
	 char *StdWrkng			= NULL;
	 char *StdRlzd			= NULL;
	 char *Plant			= NULL;
	 char *stdCode			= NULL;
	 char *RevRule		= NULL;
	 char *stdClsRule		= NULL;
	 char *stdBvr			= NULL;
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("\n Plt_Code:%s",Plt_Code);fflush(stdout);
	PlantOneChar=subString(Plt_Code,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(viewtocpy,"");
	tc_strcat(viewtocpy,"STD");
	tc_strcat(viewtocpy,PlantOneChar);
	tc_strcat(viewtocpy," View");
	printf("\n View to copy:%s",viewtocpy);fflush(stdout);
	 

	 if( QRY_find2("Control Objects...", &qryTagCntrl1));
    if (qryTagCntrl1)
    {
        printf("\n Control Object Query Found \n");fflush(stdout);
        qry_valuesCntrl1[0]="APLStateInf";
        qry_valuesCntrl1[1]=Plt_Code;
        qry_valuesCntrl1[2]="0";
        
        if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
    }
    else
    {
        printf("\n Control Object Query not Found \n");fflush(stdout);
    }	
    
    printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

    if(control_number_found1>0)
    {
        
        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &APlRevw);
        printf("\n APlRevw: %s\n",APlRevw);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &AplWrkng);
        printf("\n AplWrkng: %s\n",AplWrkng);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &AplRlzd);
        printf("\n AplRlzd: %s\n",AplRlzd);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &StdWrkng);
        printf("\n StdWrkng: %s\n",StdWrkng);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &StdRlzd);
        printf("\n StdRlzd: %s\n",StdRlzd);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &Plant);
        printf("\n Plant: %s\n",Plant);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &stdCode);
        printf("\n stdCode: %s\n",stdCode);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &RevRule);
        printf("\n RevRule: %s\n",RevRule);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &stdClsRule);
        printf("\n stdClsRule: %s\n",stdClsRule);fflush(stdout);

        //AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &stdBvr);
        //printf("\n stdBvr: %s\n",stdBvr);fflush(stdout);

                    
        if(tc_strlen(APlRevw)>0) 
        { 
            tc_strcpy(APlRevwLC,APlRevw);
        }
        if(tc_strlen(AplWrkng)>0) 
        { 
            tc_strcpy(AplWrkngLC,AplWrkng);
        }
        if(tc_strlen(AplRlzd)>0) 				
        {
            tc_strcpy(AplRlzdLC,AplRlzd);
        }
        if(tc_strlen(StdWrkng)>0) 
        {
            tc_strcpy(StdWrkngLC,StdWrkng);
        }
        if(tc_strlen(StdRlzd)>0) 
        {
            tc_strcpy(StdRlzdLC,StdRlzd);
        }
        if(tc_strlen(Plant)>0) 
        {
            tc_strcpy(PlantLCFlag,Plant);
        }
        if(tc_strlen(stdCode)>0) 
        {
            tc_strcpy(StdPlant,stdCode);
        }
        if(tc_strlen(RevRule)>0) 
        {
            tc_strcpy(StdRevRule,RevRule);
        }
        if(tc_strlen(stdClsRule)>0) 
        {
            tc_strcpy(StdCLosRule,stdClsRule);
        }
        if(tc_strlen(viewtocpy)>0) 
        {
            tc_strcpy(StdView,viewtocpy);
        }
    }
    else
    {
        tc_strcpy(APlRevwLC,"T5_LcsAplReview");
        tc_strcpy(AplWrkngLC,"T5_LcsAPLWrkg");
        tc_strcpy(AplRlzdLC,"T5_LcsAplRlzd");
        tc_strcpy(StdWrkngLC,"T5_LcsSTDWrkg");
        tc_strcpy(StdRlzdLC,"T5_LcsStdRlzd");		
        tc_strcpy(PlantLCFlag,"CAR");
        tc_strcpy(StdPlant,"STDC");
        tc_strcpy(StdRevRule,"APLC Release and above");
        tc_strcpy(StdCLosRule,"BOMViewClosureRuleSTDC");
        tc_strcpy(StdView,viewtocpy);
    }
}
