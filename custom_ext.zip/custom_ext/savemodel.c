/****************************************************************************************************
*  File                 :		savemodel.c
*  Created By			:		Yogendra Kumar Mahikwar
*  Created On			:		11-Aug-2012
*  Purpose				:		Validation on Behaviour Model on save operation.			
*								This is called at pre action of save.
*  Modification History :  
*  Modification Date    : 
*  Modification  By	    :
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#include <tc.h>
#include <tccore/custom.h>
#include <user_exits/user_exits.h>
#include <ict_userservice.h>
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include "ae.h"
#include "bom.h"
#include "cfm.h"
#include "emh.h"
#include "grm.h"
#include "grmtype.h"
#include "item.h"
#include "mem.h"
#include "pom.h"
#include "ps.h"
#include "ps_errors.h"
#include "sample_err.h"
#include "ss_const.h"
#include "tc.h"
#include "tc_string.h"
#include "tcfile.h"
#include "unidefs.h"
#include "workspaceobject.h"
#include <aom_prop.h>
#include <epm/epm_errors.h>
#include <sys/stat.h>
#include <bom.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <custom.h>
#include <dataset.h>
#include <grm.h>
#include <ict_userservice.h>
#include <itk/mem.h>
#include <tccore/method.h>
#include <ps/ps_errors.h>
#include <reservation.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc.h>
#include <tc/emh.h>
#include <tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcfile.h>
#include <tcinit/tcinit.h>
#include <tctype.h>
#include <time.h>
#include <unidefs.h>
#include <workspaceobject.h>
#include <item_msg.h>
#include <tccore/tc_msg.h>
#include <tccore/iman_msg.h>
#include <epm/epm.h>
#include <dataset_msg.h>
#define ITK_err 919002
#define CONNECT_FAIL (EMH_USER_error_base + 2)

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


extern DLLAPI int  save_method_3(METHOD_message_t *msg, va_list args)
{

      int error_code = ITK_ok;
      tag_t objTag = va_arg(args, tag_t);
      //logical flag = va_arg(args, logical);
      tag_t objTypeTag = NULLTAG;
      char   type_name[TCTYPE_name_size_c+1];

      char   *desid=NULL;
   
      char   *DesRevDesc=NULL;
      char   *ReplacedDesRevDesc=NULL;
      char   *NewReplacedDescription=NULL;
	char   *ItemMaterial=NULL;
   
int desidlength= 0;
int revdesccnt= 0;


      EPM_decision_t decision=EPM_go;

      printf("\n save_method_3::It's the time to save Bhm0BehaviorModl \n");fflush(stdout);


      if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	  printf("\n save_method_17::type_name :%s\n", type_name);fflush(stdout);

      if(strcmp(type_name,"Bhm0BehaviorModl")==0)
      {
            if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);


            printf("\n save_method_3::Bhm0BehaviorModl Item ID %s\n", desid);fflush(stdout);

		desidlength = strlen(desid);
		printf("\n save_method_3::Length %d\n", desidlength);fflush(stdout);
		if(desidlength != 17)
		{
			printf("\n	It's length more or less than 17\n");fflush(stdout);
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Length of Behaviour Model Id is not 17 characters");
			return ITK_err;
	
		}
   
      }
      return error_code;
}


extern int savemodel_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
    METHOD_id_t  method ;
    METHOD_id_t  method1 ;
   METHOD_id_t  method2 ;

    *decision = ALL_CUSTOMIZATIONS;  

    /* do something useful here, for now just return */
   printf("\n\n savemodel.c:it, via Custom User Exit.\n");fflush(stdout);
    if ( METHOD_find_method("Bhm0BehaviorModl", IMAN_save_msg, &method) !=ITK_ok);
 
    if (method.id != NULLTAG)
	{
		printf("\n !!!!!!!!!!!Bhm0BehaviorModl ---Method is  found!!!!!!!!!!\n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_3, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	    }

    return ifail;
}
extern DLLAPI int savemodel_register_callbacks ()
{
    printf("\n\nsavemodel_register_callbacks changed\n\n");fflush(stdout);
	
	
    if(CUSTOM_register_exit ( "savemodel", "USER_init_module", (CUSTOM_EXIT_ftn_t)  savemodel_register_method) !=ITK_ok)
     PrintErrorStack();
  return ( ITK_ok );
}
