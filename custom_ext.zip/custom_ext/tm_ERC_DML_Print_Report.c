
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_APLReport.c
*
* Description		: > This register custom user service. Implemented Custom ITK functions for generating APL Reports
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 31/05/2018   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/
#include<tccore/item.h>
#include<string.h>
#include<tccore/aom_prop.h>
#include<sa/tcfile.h>
#include<ae/dataset.h>
#include<unidefs.h>
#include <ict/ict_userservice.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <sa/imanfile.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/folder.h>

#define	ADD	1
#define	DEL	-1
#define	NA	0
#define	MOD	2
//#define ITKCALL( argument )                                             \
//{                                                                       \
//    int retcode = argument;                                             \
//    if ( retcode != ITK_ok ) {                                          \
//        char* s;                                                        \
//        printf( " "#argument "\n" );                                    \
//        printf( "  returns [%d]\n", retcode );                          \
//        EMH_ask_error_text (retcode, &s);                               \
//        printf( "  Teamcenter ERROR: [%s]\n", s);           \
//        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
//        if (s != 0) MEM_free (s);                                       \
//    }                                                                   \
//}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int		TotalAffectedGrp  = 0;
int 	TotalResltparts   = 0;
int 	TotalAddparts     = 0;
int 	TotalDelparts     = 0;
int 	TotalQtychngparts = 0;


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int APLDMLReleasedDates(char*,char*,int,char**,void*,char***,int*,char*);
int STDDMLReleaseddates(char*,char*,int,char**,void*,char***,int*,char*);
		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

typedef struct BomLineVector_
{
 int level;
 int line_count;
 tag_t *bom_lines;
} *BOMLineVector; 
	
/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTAG2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int getLatestStandardReleasedPart(char *partNumber,char *object_type, tag_t *latestPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemrevs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;

	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Release Status";
	qry_entries[1] = "Type";
	qry_entries[2] = "Item ID";
	
	qry_values[0] = "T5_LcsStdRlzd"; // STD Released state
	qry_values[1] = object_type;
	qry_values[2] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &itemrevs));
	
	printf("\n getLatestStandardReleasedPart: count==>%d", count);fflush(stdout);
	
	//get the latest released object by creation date
	int i=0;
	int	j=0;
	int max =0;
	long days=0;
	long days1 =0;
	char* partRev;
	char* creationDate;
	date_t creation_dt;
	date_t creation_dt1;
	int ans =0;
	if(count>0)
	{
		

		for(i=0; i<count-1;i++)
		{
			CALLAPI(AOM_ask_value_string(itemrevs[i],"item_revision_id",&partRev))	
			printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(itemrevs[i],"creation_date",&creationDate));
			printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
			CALLAPI(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
			
			max = i;
			for(j=i;j<count;j++)
			{
				CALLAPI(AOM_ask_value_string(itemrevs[j],"item_revision_id",&partRev))	
				printf("\ngetLatestStandardReleasedPart: Part Revision[%d]: %s",i,partRev);fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(itemrevs[j],"creation_date",&creationDate));
				printf("\ngetLatestStandardReleasedPart: Creation Date[%d]: %s",i,creationDate);fflush(stdout);
				CALLAPI(AOM_ask_value_date(itemrevs[j],"creation_date",&creation_dt1));
				CALLAPI(POM_compare_dates(creation_dt1, creation_dt, &ans));
				if(ans ==1) max =j;
			}
			
		}
		*latestPart = itemrevs[max];
		CALLAPI(AOM_ask_value_string(*latestPart,"item_revision_id",&partRev))
		printf("\ngetLatestStandardReleasedPart: Latest Part Revision: %s",partRev);fflush(stdout);
	}
	return ifail;
}

/* Get Item revs */
int getItemObjects(char *partNumber,char *object_type,int *count,tag_t **itemrevs)
{

	int ifail = ITK_ok;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;

	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Release Status";
	qry_entries[1] = "Type";
	qry_entries[2] = "Item ID";
	
	qry_values[0] = "T5_LcsStdRlzd"; //change to T5_LcsStdRlzd
	qry_values[1] = object_type;
	qry_values[2] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, count, itemrevs));
	
	return ifail;
}



void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}




void setAddBomLineVector(int *count,BOMLineVector **objlist,BOMLineVector obj )
{

	*count=*count+1;
	printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		printf("\n ****setAddBomLineVector1");fflush(stdout);
		(*objlist) = (BOMLineVector *)malloc((*count ) * sizeof(BOMLineVector ));
		printf("\n ***setAddBomLineVector2");fflush(stdout);
	}
	else
	{
		printf("\n **setAddBomLineVector3");fflush(stdout);
		(*objlist) = (BOMLineVector *)realloc((*objlist),(*count) * sizeof(BOMLineVector ));
		printf("\n ***setAddBomLineVector4");fflush(stdout);
		printf("\n **setAddBomLineVector5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	printf("\n **setAddBomLineVector6");fflush(stdout);
}



int getChildObjectsInView(tag_t window, tag_t VehicleObj,tag_t bom_view, int *lvl, int* lineVectorlistCnt, BOMLineVector** lineVectorlist,int* lineVectorlistLeafCnt, BOMLineVector** lineVectorLeaflist)
{
	int ifail				= ITK_ok;
	tag_t rule				= NULLTAG;
	tag_t top_line			= NULLTAG;	
	tag_t t_ItemTag 		= NULLTAG;	
	tag_t  *childs		    = NULLTAG;
	int child_count         = 0;
	int i                   = 0;	
	int hasChildAttrID      = 0;
	char *itemNumber, *revisionNumber = NULL;
	logical hasChildren     = false;	
	BOMLineVector lineVector = NULL;
	BOMLineVector lineVectorLeaf = NULL;
	int ruleConfigByID =0;
	char* rules_configured_by = NULL;
	
	printf("\ngetChildObjectsInView: Start of the function...\n");fflush(stdout);
	if(ITK_ok != (ifail = CFM_find("APLReleasedAndAboveRule", &rule)))
    {
		if(rule != NULLTAG) printf("\n APLReleasedAndAboveRule revision rule is selected...\n");fflush(stdout);
        if(ifail == CFM_cant_find_rev_rule)
        {
			CALLAPI(CFM_find("Latest Working", &rule ));
			printf("\n'APLReleasedAndAboveRule' revision rule not found...\n");fflush(stdout);
			printf("\n'Default OOTB revision' rule 'Latest Working' selected....\n");fflush(stdout);
        }
    }	
	//CALLAPI(CFM_find( "Latest Working", &rule ));
	CALLAPI(BOM_set_window_config_rule( window, rule ));
	//CALLAPI(BOM_set_window_pack_all (window, false));
	CALLAPI(BOM_set_window_top_line (window, t_ItemTag,VehicleObj, bom_view, &top_line));	
	CALLAPI(BOM_line_look_up_attribute("bl_has_children", &hasChildAttrID));
	CALLAPI(BOM_line_look_up_attribute("bl_config_string", &ruleConfigByID));
	if(top_line!= NULLTAG)
	{
	
		printf("\ngetChildObjectsInView:..111111111111\n");fflush(stdout);
		//CALLAPI(BOM_line_ask_all_child_lines(top_line, &child_count, &childs));	
		CALLAPI(BOM_line_ask_child_lines(top_line, &child_count, &childs));	
		printf("\ngetChildObjectsInView:child count==>%d\n", child_count);fflush(stdout);
		if(child_count >0)
		{
			tag_t* childLines = NULLTAG;
			tag_t* childLinesLeaf = NULLTAG;
			printf("\ngetChildObjectsInView: ..qqqqqqqq\n");fflush(stdout);
			*lvl = *lvl +1;

			int pp=0;
			int qq=0;
			for(i=0;i<child_count;i++)
			{
				hasChildren= false;
				if(childs[i] != NULLTAG)
				{
					CALLAPI(BOM_line_ask_attribute_string(childs[i], ruleConfigByID, &rules_configured_by))
					printf("\ngetChildObjectsInView:..rules_configured_by: %s \n",rules_configured_by);fflush(stdout);
					if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
						continue;
					CALLAPI(BOM_line_ask_attribute_logical(childs[i], hasChildAttrID, &hasChildren))
					if(hasChildren)
					{
						printf("\ngetChildObjectsInView:..adding assembly \n");fflush(stdout);
						setAddTAG(&pp,&childLines,childs[i]);
					}
					else
					{
						printf("\ngetChildObjectsInView: ..adding components \n");fflush(stdout);
						setAddTAG(&qq,&childLinesLeaf,childs[i]);
						//print report of remaining childs
					}
				}

			}
			printf("\ngetChildObjectsInView: ..mmmmmmmmm\n");fflush(stdout);
			if(pp>0)
			{
				lineVector = (BOMLineVector)malloc( sizeof(BOMLineVector ));
				lineVector->level = *lvl;
				lineVector->bom_lines = childLines;
				lineVector->line_count = pp;
				//memcpy(&lineVector->bom_lines,&childLines, sizeof(childLines));
				setAddBomLineVector(lineVectorlistCnt,lineVectorlist,lineVector );

			}

			if(qq>0)
			{
				lineVectorLeaf = (BOMLineVector)malloc( sizeof(BOMLineVector ));
				lineVectorLeaf->level = *lvl;
				lineVectorLeaf->bom_lines = childLinesLeaf;
				lineVectorLeaf->line_count = qq;
				//memcpy(&lineVector->bom_lines,&childLinesLeaf, sizeof(childLinesLeaf));
				setAddBomLineVector(lineVectorlistLeafCnt,lineVectorLeaflist,lineVectorLeaf );

			}
		
			printf("\ngetChildObjectsInView: ..nnnnnnnn\n");fflush(stdout);
		}
				

	}
	else
	{
		printf("\ngetChildObjectsInView: top_line tag is nulltag\n");fflush(stdout);
	}
	printf("\ngetChildObjectsInView: End of the function...\n");fflush(stdout);
	return ifail;
}
int bomLineExpansion(int *lvl, int* lineVectorlistCnt, BOMLineVector** lineVectorlist,int* lineVectorlistLeafCnt, BOMLineVector** lineVectorLeaflist)
{
	int ifail						= ITK_ok;
	tag_t rule						= NULLTAG;
	tag_t top_line					= NULLTAG;	
	tag_t  *childs		    		= NULLTAG;
	int child_count         		= 0;
	int i,ii 						= 0;	
	int hasChildAttrID      		= 0;
	logical hasChildren     		= false;
	BOMLineVector lineVector 		= NULL;
	BOMLineVector lineVectorLeaf 	= NULL;

	printf("\nbomLineExpansion: Start of the function...\n");fflush(stdout);
	CALLAPI(BOM_line_look_up_attribute("bl_has_children", &hasChildAttrID));
	printf("\nbomLineExpansion: lvl==>%d\n", *lvl);fflush(stdout);
	printf("\nbomLineExpansion: lineVectorlistCnt==>%d\n", *lineVectorlistCnt);fflush(stdout);	
	printf("\nbomLineExpansion: lineVectorlistLeafCnt==>%d\n", *lineVectorlistLeafCnt);fflush(stdout);

	
	//recursive call for assembly
	
	int pp =0;
	int qq =0;
	int initialLeafCount = *lineVectorlistLeafCnt;
	int initialAssyCount = *lineVectorlistCnt;
	int ruleConfigByID 	 =0;
	char* rules_configured_by = NULL;
	
	CALLAPI(BOM_line_look_up_attribute("bl_config_string", &ruleConfigByID));
	if(*lvl <99)
	{
				
		int assyCnt = (*(lineVectorlist[0] + (*lineVectorlistCnt-1)))->line_count;
		int cnt = *lineVectorlistCnt-1;
		printf("\nbomLineExpansion: assyCnt,cnt==>%d,%d\n",assyCnt,cnt);fflush(stdout);
		*lvl = *lvl +1;	
		printf("\nbomLineExpansion:lvl==>%d\n",*lvl);fflush(stdout);
		int flag =0;
		for(i=0;i<assyCnt;i++)
		{
			printf("\nbomLineExpansion: loop..i==>%d\n",i);fflush(stdout);
			child_count =0;
			//CALLAPI(BOM_line_ask_all_child_lines((*(lineVectorlist[0] + cnt))->bom_lines[i], &child_count, &childs));
			CALLAPI(BOM_line_ask_child_lines((*(lineVectorlist[0] + cnt))->bom_lines[i], &child_count, &childs));
			
			pp =0;
			qq =0;
			tag_t* childLines = NULLTAG;
			tag_t* childLinesLeaf = NULLTAG;
			hasChildren = false;	
			printf("\nbomLineExpansion: child_count==>%d\n",child_count);fflush(stdout);		
			for(ii=0;ii<child_count;ii++)
			{
				printf("\nbomLineExpansion: child_count loop..%d\n",ii);fflush(stdout);
				CALLAPI(BOM_line_ask_attribute_string(childs[ii], ruleConfigByID, &rules_configured_by))
				printf("\ngetChildObjectsInView:..rules_configured_by: %s \n",rules_configured_by);fflush(stdout);
				if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
					continue;				
				CALLAPI(BOM_line_ask_attribute_logical(childs[ii], hasChildAttrID, &hasChildren));
				if(hasChildren)
				{
					printf("\nbomLineExpansion: hasChildren..\n");fflush(stdout);
					setAddTAG(&pp,&childLines,childs[ii]);
					flag = 1;
				}
				else
				{
					setAddTAG(&qq,&childLinesLeaf,childs[ii]);
					//print report of remaining childs
				}

			}
			if(pp>0)
			{
				printf("\nIn bomLineExpansion. adding assy..\n");fflush(stdout);
				lineVector = (BOMLineVector)malloc( sizeof(BOMLineVector ));
				lineVector->level = *lvl;
				lineVector->bom_lines = childLines;
				lineVector->line_count = pp;
				//memcpy(&lineVector->bom_lines,&childLines, sizeof(childLines));
				setAddBomLineVector(lineVectorlistCnt,lineVectorlist,lineVector );

			}

			if(qq>0)
			{
				printf("\nIn bomLineExpansion. adding leaf..\n");fflush(stdout);
				lineVectorLeaf = (BOMLineVector)malloc( sizeof(BOMLineVector ));
				lineVectorLeaf->level = *lvl;
				lineVectorLeaf->bom_lines = childLinesLeaf;
				lineVectorLeaf->line_count = qq;
				//memcpy(&lineVector->bom_lines,&childLinesLeaf, sizeof(childLinesLeaf));
				setAddBomLineVector(lineVectorlistLeafCnt,lineVectorLeaflist,lineVectorLeaf );	

			}
			printf("\n*******************\n");fflush(stdout);
			printf("\n pp=======>%d\n",pp);fflush(stdout);
			printf("\n qq=======>%d\n",qq);fflush(stdout);
			printf("\n*******************\n");fflush(stdout);	
					
		}		

		if(flag==1)
		{
			printf("\nIn bomLineExpansion. calling recursively...\n");fflush(stdout);
			CALLAPI(bomLineExpansion(lvl,lineVectorlistCnt,lineVectorlist,lineVectorlistLeafCnt,lineVectorLeaflist));
			
		}	
		
	}
	printf("\nbomLineExpansion: End of the function...\n");fflush(stdout);
	return ifail;
}
int APLStructureXls(tag_t VehicleObj,void *retValue, char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail 				= ITK_ok;
	tag_t t_ItemTag 		= NULLTAG;
	tag_t rule				= NULLTAG;
	tag_t window			= NULLTAG;
	tag_t top_line			= NULLTAG;
	tag_t top_line_child	= NULLTAG;	
	int j					= 0;
	char *view_type_name    = NULL;
	tag_t view_type 		= NULLTAG;		
	tag_t erc_view 			= NULLTAG;
	tag_t apl_view 			= NULLTAG;
	tag_t dfma_view 		= NULLTAG;
	char* vehicleNumber 	= NULL;
	
	tag_t VehMaster 		= NULLTAG;
	int n_bom_views         = 0;
	tag_t *bom_views        = NULL;
	tag_t window1 	        = NULLTAG;
	int lvl 				= 0;
	int lineVectorlistCnt   = 0;
	BOMLineVector *lineVectorlist;
	int lineVectorlistLeafCnt = 0;
	BOMLineVector *lineVectorLeaflist;	
	int mm 					= 0;
	int nn					= 0;
	int name_attribute ,desc_attribute, rev_attribute,di_attribute,uom_attribute,qty_attribute,cs_attribute,ia_attribute=0;
	int loc_attribute,opcs_attribute ,ownername_attribute, parttype_attribute,coatedInd_attribute,spareInd_attribute,comCode_attribute,keywordDesc_attribute=0;
	char* name 					= NULL;
	char* desc 					= NULL;
	char* rev 					= NULL;
	char* di, *diStr 			= NULL;
	char* uom, *uomStr			= NULL;
	char* qty, *qtyStr 			= NULL;
	char* cs, *csStr 			= NULL;
	char* ia, *iaStr 			= NULL;
	char* loc, *locStr 			= NULL;
	char* opcs, *opcsStr 		= NULL;
	char* ownername, *ownernameStr 	= NULL;
	char* partType, *partTypeStr 	= NULL;
	char* coatedInd, *coatedIndStr 	= NULL;
	char* spareInd, *spareIndStr 	= NULL;
	char* compCode, *compCodeStr 	= NULL;
	char* keyword, *keywordStr 		= NULL;
	char *levelStr 					= NULL;
	char *partNoStr, *descStr 		= NULL;
	char *revStr 					= NULL;
	char *levelStr1 				= NULL;
	char *partNoStr1 				= NULL;	
	
	printf("\nAPLStructureXls: Start of the function...\n");fflush(stdout);
	if(VehicleObj == NULLTAG)
	{
		printf("\nAPLStructureXls: VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(ITEM_ask_item_of_rev(VehicleObj, &VehMaster)); // Get the Item from the revision
	CALLAPI(ITEM_list_bom_views(VehMaster, &n_bom_views, &bom_views )); //Get the bom views
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	// If having bom views
	if(n_bom_views>0)
	{
		printf("\nAPLStructureXls: %s having bom views...\n", vehicleNumber);fflush(stdout);
		for(j=0;j<n_bom_views;j++)
		{
			CALLAPI(PS_ask_bom_view_type(bom_views[j],&view_type))
			CALLAPI(PS_ask_view_type_name(view_type, &view_type_name));
			printf("\nAPLStructureXls: View Type===>%s\n", view_type_name);fflush(stdout);
			
			
			if(tc_strcmp(view_type_name, "view") == 0 )
			{
				erc_view = bom_views[j];

			}
			
			if(tc_strcmp(view_type_name, "T5_APLP") == 0 )// For APL View
			{
				apl_view = bom_views[j];
				
	
			}
			if(tc_strcmp(view_type_name,"T5_DFMA") == 0)
			{
				dfma_view = bom_views[j];
			}
			
		}
	}
	
	if(erc_view == NULLTAG && apl_view == NULLTAG)
	{
		printf("\n***********NO VIEW**********************");fflush(stdout);
		printf("\n***********No structure********************\n");fflush(stdout);
		return ifail;
	}



	
	CALLAPI(BOM_create_window (&window1));
	// Expand in ERC View later it need to be changed based on user location
	if(apl_view != NULLTAG) 
	{
		CALLAPI(getChildObjectsInView(window1, VehicleObj,apl_view, &lvl,&lineVectorlistCnt,&lineVectorlist,&lineVectorlistLeafCnt,&lineVectorLeaflist));
	}
	else // Expand in default view temporarily- need to change the logic later
	{
		CALLAPI(getChildObjectsInView(window1, VehicleObj,erc_view, &lvl,&lineVectorlistCnt,&lineVectorlist,&lineVectorlistLeafCnt,&lineVectorLeaflist));
	}

	
	printf("\nAPLStructureXls:First level child counts  lineVectorlist,lineVectorlistLeafCnt....==>%d,%d\n",lineVectorlistCnt,lineVectorlistLeafCnt);fflush(stdout);

	/* If no  child in the structure then return */
	if(lineVectorlistCnt ==0 && lineVectorlistLeafCnt ==0)
		return ifail;
	
	if(lineVectorlistCnt>0)
		printf("\nAPLStructureXls:lineVectorlist[0]->line_count....==>%d\n",lineVectorlist[0]->line_count);fflush(stdout);
	if(lineVectorlistLeafCnt>0)
		printf("\nAPLStructureXls:lineVectorLeaflist[0]->line_count....==>%d\n",lineVectorLeaflist[0]->line_count);fflush(stdout);
	
	//Call multi expansion only if any of the child is having bom structure
	if(lineVectorlistCnt>0)
	{
		CALLAPI(bomLineExpansion(&lvl,&lineVectorlistCnt,&lineVectorlist,&lineVectorlistLeafCnt,&lineVectorLeaflist));
	}
		
		
	

	//print xml for leaf elements..
		
	CALLAPI(BOM_line_look_up_attribute ("bl_item_item_id",&name_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_item_object_desc",&desc_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&rev_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_DrawingInd",&di_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_uom",&uom_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_quantity",&qty_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_CarMakeBuyIndicator",&cs_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_CarIntialAgency",&ia_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_CarStoreLocation",&loc_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&opcs_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_rev_owning_user",&ownername_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&parttype_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_Coated",&coatedInd_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_SpareInd",&spareInd_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_PrtCatCode",&comCode_attribute));
	CALLAPI(BOM_line_look_up_attribute ("bl_Design Revision_t5_CategoryName",&keywordDesc_attribute));	
	

	
	setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"<APLREPORT>");

	for(mm=0;mm<lineVectorlistLeafCnt;mm++)
	{
		
		for(nn =0; nn<lineVectorLeaflist[mm]->line_count;nn++)
		{
					
			if(lineVectorLeaflist[mm]->bom_lines[nn] != NULLTAG && name_attribute !=0)
			{
				levelStr = MEM_alloc(50*sizeof(*levelStr));
				partNoStr = MEM_alloc(100*sizeof(*partNoStr));
				descStr	= MEM_alloc(200*sizeof(*descStr));
				revStr	= MEM_alloc(50*sizeof(*revStr));
				diStr	= MEM_alloc(20*sizeof(*diStr));
				uomStr = MEM_alloc(50*sizeof(*uomStr));
				qtyStr = MEM_alloc(50*sizeof(*qtyStr));
				csStr	= MEM_alloc(100*sizeof(*csStr));
				iaStr	= MEM_alloc(100*sizeof(*iaStr));
				locStr	= MEM_alloc(100*sizeof(*locStr));
				ownernameStr = MEM_alloc(100*sizeof(*ownernameStr));
				partTypeStr = MEM_alloc(50*sizeof(*partTypeStr));
				coatedIndStr	= MEM_alloc(50*sizeof(*coatedIndStr));
				spareIndStr	= MEM_alloc(50*sizeof(*spareIndStr));
				compCodeStr	= MEM_alloc(50*sizeof(*compCodeStr));	
				keywordStr	= MEM_alloc(150*sizeof(*keywordStr));					
				setAddStr(buff_cnt,bufferedXmlStrOut,"<PART>");
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], name_attribute, &name));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], desc_attribute, &desc));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], rev_attribute, &rev));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], di_attribute, &di));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], uom_attribute, &uom));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], qty_attribute, &qty));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], cs_attribute, &cs));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], ia_attribute, &ia));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], loc_attribute, &loc));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], ownername_attribute, &ownername));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], parttype_attribute, &partType));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], coatedInd_attribute, &coatedInd));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], spareInd_attribute, &spareInd));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], comCode_attribute, &compCode));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorLeaflist[mm]->bom_lines[nn], keywordDesc_attribute, &keyword));				
				printf("\nAPLStructureXls:childln[%d]==>%s, level==>%d\n", nn,name,lineVectorLeaflist[mm]->level);fflush(stdout);
				sprintf(levelStr,"<LEVEL>%d</LEVEL>", lineVectorLeaflist[mm]->level);
				setAddStr(buff_cnt,bufferedXmlStrOut,levelStr);
				sprintf(partNoStr,"<ITEMID>%s</ITEMID>",name);
				setAddStr(buff_cnt,bufferedXmlStrOut,partNoStr);
				sprintf(descStr,"<ITEMDESC>%s</ITEMDESC>",desc);				
				setAddStr(buff_cnt,bufferedXmlStrOut,descStr);
				
				sprintf(revStr,"<REV>%s</REV>",rev);				
				setAddStr(buff_cnt,bufferedXmlStrOut,revStr);
				
				sprintf(diStr,"<DI>%s</DI>",di);				
				setAddStr(buff_cnt,bufferedXmlStrOut,diStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<DI>NA</DI>");
				
				sprintf(uomStr,"<UQ>%s</UQ>",uom);				
				setAddStr(buff_cnt,bufferedXmlStrOut,uomStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<UQ>NA</UQ>");
				sprintf(qtyStr,"<QTY>%s</QTY>",qty);				
				setAddStr(buff_cnt,bufferedXmlStrOut,qtyStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<QTY>NA</QTY>");
				sprintf(csStr,"<CS>%s</CS>",cs);				
				setAddStr(buff_cnt,bufferedXmlStrOut,csStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<CS>NA</CS>");
				sprintf(iaStr,"<IA>%s</IA>",ia);				
				setAddStr(buff_cnt,bufferedXmlStrOut,iaStr);					
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<IA>NA</IA>");
				sprintf(locStr,"<LOC>%s</LOC>",loc);				
				setAddStr(buff_cnt,bufferedXmlStrOut,locStr);	
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<LOC>NA</LOC>");						
				setAddStr(buff_cnt,bufferedXmlStrOut,"<SELN>NA</SELN>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<OPCS>NA</OPCS>");
				sprintf(ownernameStr,"<OWNERNAME>%s</OWNERNAME>",ownername);				
				setAddStr(buff_cnt,bufferedXmlStrOut,ownernameStr);		
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<OWNERNAME>NA</OWNERNAME>");
				sprintf(partTypeStr,"<PARTTYPE>%s</PARTTYPE>",partType);				
				setAddStr(buff_cnt,bufferedXmlStrOut,partTypeStr);							
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<PARTTYPE>NA</PARTTYPE>");
				sprintf(coatedIndStr,"<COATEDID>%s</COATEDID>",coatedInd);				
				setAddStr(buff_cnt,bufferedXmlStrOut,coatedIndStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<COATEDID>NA</COATEDID>");
				sprintf(spareIndStr,"<SPI>%s</SPI>",spareInd);				
				setAddStr(buff_cnt,bufferedXmlStrOut,spareIndStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<SPI>NA</SPI>");
				sprintf(compCodeStr,"<COMPCODE>%s</COMPCODE>",compCode);				
				setAddStr(buff_cnt,bufferedXmlStrOut,compCodeStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<COMPCODE>NA</COMPCODE>");
				sprintf(keywordStr,"<KEYWORDDESC>%s</KEYWORDDESC>",keyword);				
				setAddStr(buff_cnt,bufferedXmlStrOut,keywordStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<KEYWORDDESC>NA</KEYWORDDESC>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLWIDTH></BLWIDTH>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLTHICKNESS></BLTHICKNESS>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLLENGTH></BLLENGTH>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<COMPBLANKS></COMPBLANKS>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLWEIGHT></BLWEIGHT>");	
				setAddStr(buff_cnt,bufferedXmlStrOut,"<USAGE></USAGE>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</PART>");
				if(levelStr!=NULL)MEM_free(levelStr);	
				if(partNoStr!=NULL)MEM_free(partNoStr);	
				if(descStr!= NULL)MEM_free(descStr);
				if(revStr!=NULL)MEM_free(revStr);	
				if(uomStr!=NULL)MEM_free(uomStr);	
				if(qtyStr!= NULL)MEM_free(qtyStr);
				if(csStr!=NULL)MEM_free(csStr);					
				if(iaStr!=NULL)MEM_free(iaStr);						
				if(locStr!= NULL)MEM_free(locStr);
				if(ownernameStr!=NULL)MEM_free(ownernameStr);	
				if(partTypeStr!=NULL)MEM_free(partTypeStr);	
				if(coatedIndStr!= NULL)MEM_free(coatedIndStr);
				if(spareIndStr!=NULL)MEM_free(spareIndStr);	
				if(compCodeStr!=NULL)MEM_free(compCodeStr);	
				if(keywordStr!= NULL)MEM_free(keywordStr);
				
			}
			
		}
		
	}
	
	// print xml for non leaf parts
	for(mm=0;mm<lineVectorlistCnt;mm++)
	{

		for(nn =0; nn<lineVectorlist[mm]->line_count;nn++)
		{

			//printf("\n nn....%d\n",nn);fflush(stdout);
			if(lineVectorlist[mm]->bom_lines[nn] != NULLTAG)
			{
				levelStr1 = MEM_alloc(50*sizeof(*levelStr1));
				partNoStr1 = MEM_alloc(100*sizeof(*partNoStr1));
				descStr	= MEM_alloc(200*sizeof(*descStr));
				revStr	= MEM_alloc(50*sizeof(*revStr));
				diStr	= MEM_alloc(20*sizeof(*diStr));
				uomStr = MEM_alloc(50*sizeof(*uomStr));
				qtyStr = MEM_alloc(50*sizeof(*qtyStr));
				csStr	= MEM_alloc(100*sizeof(*csStr));
				iaStr	= MEM_alloc(100*sizeof(*iaStr));
				locStr	= MEM_alloc(100*sizeof(*locStr));
				ownernameStr = MEM_alloc(100*sizeof(*ownernameStr));
				partTypeStr = MEM_alloc(50*sizeof(*partTypeStr));
				coatedIndStr	= MEM_alloc(50*sizeof(*coatedIndStr));
				spareIndStr	= MEM_alloc(50*sizeof(*spareIndStr));
				compCodeStr	= MEM_alloc(50*sizeof(*compCodeStr));	
				keywordStr	= MEM_alloc(150*sizeof(*keywordStr));					
				setAddStr(buff_cnt,bufferedXmlStrOut,"<PART>");
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], name_attribute, &name));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], desc_attribute, &desc));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], rev_attribute, &rev));	
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], di_attribute, &di));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], uom_attribute, &uom));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], qty_attribute, &qty));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], cs_attribute, &cs));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], ia_attribute, &ia));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], loc_attribute, &loc));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], ownername_attribute, &ownername));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], parttype_attribute, &partType));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], coatedInd_attribute, &coatedInd));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], spareInd_attribute, &spareInd));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], comCode_attribute, &compCode));
				CALLAPI(BOM_line_ask_attribute_string(lineVectorlist[mm]->bom_lines[nn], keywordDesc_attribute, &keyword));					
				printf("\nAPLStructureXls:childln[%d]==>%s, level==>%d\n", nn,name,lineVectorlist[mm]->level);fflush(stdout);
				sprintf(levelStr1,"<LEVEL>%d</LEVEL>", lineVectorlist[mm]->level);
				setAddStr(buff_cnt,bufferedXmlStrOut,levelStr1);
				sprintf(partNoStr1,"<ITEMID>%s</ITEMID>",name);
				setAddStr(buff_cnt,bufferedXmlStrOut,partNoStr1);
				sprintf(descStr,"<ITEMDESC>%s</ITEMDESC>",desc);				
				setAddStr(buff_cnt,bufferedXmlStrOut,descStr);
				sprintf(revStr,"<REV>%s</REV>",rev);				
				setAddStr(buff_cnt,bufferedXmlStrOut,revStr);					
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<REV>NA</REV>");
				sprintf(diStr,"<DI>%s</DI>",di);				
				setAddStr(buff_cnt,bufferedXmlStrOut,diStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<DI>NA</DI>");
				
				sprintf(uomStr,"<UQ>%s</UQ>",uom);				
				setAddStr(buff_cnt,bufferedXmlStrOut,uomStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<UQ>NA</UQ>");
				sprintf(qtyStr,"<QTY>%s</QTY>",qty);				
				setAddStr(buff_cnt,bufferedXmlStrOut,qtyStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<QTY>NA</QTY>");
				sprintf(csStr,"<CS>%s</CS>",cs);				
				setAddStr(buff_cnt,bufferedXmlStrOut,csStr);
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<CS>NA</CS>");
				sprintf(iaStr,"<IA>%s</IA>",ia);				
				setAddStr(buff_cnt,bufferedXmlStrOut,iaStr);					
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<IA>NA</IA>");
				sprintf(locStr,"<LOC>%s</LOC>",loc);				
				setAddStr(buff_cnt,bufferedXmlStrOut,locStr);	
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<LOC>NA</LOC>");						
				setAddStr(buff_cnt,bufferedXmlStrOut,"<SELN>NA</SELN>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<OPCS>NA</OPCS>");
				sprintf(ownernameStr,"<OWNERNAME>%s</OWNERNAME>",ownername);				
				setAddStr(buff_cnt,bufferedXmlStrOut,ownernameStr);		
				
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<OWNERNAME>NA</OWNERNAME>");
				sprintf(partTypeStr,"<PARTTYPE>%s</PARTTYPE>",partType);				
				setAddStr(buff_cnt,bufferedXmlStrOut,partTypeStr);							
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<PARTTYPE>NA</PARTTYPE>");
				sprintf(coatedIndStr,"<COATEDID>%s</COATEDID>",coatedInd);				
				setAddStr(buff_cnt,bufferedXmlStrOut,coatedIndStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<COATEDID>NA</COATEDID>");
				sprintf(spareIndStr,"<SPI>%s</SPI>",spareInd);				
				setAddStr(buff_cnt,bufferedXmlStrOut,spareIndStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<SPI>NA</SPI>");
				sprintf(compCodeStr,"<COMPCODE>%s</COMPCODE>",compCode);				
				setAddStr(buff_cnt,bufferedXmlStrOut,compCodeStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<COMPCODE>NA</COMPCODE>");
				sprintf(keywordStr,"<KEYWORDDESC>%s</KEYWORDDESC>",keyword);				
				setAddStr(buff_cnt,bufferedXmlStrOut,keywordStr);						
				//setAddStr(buff_cnt,bufferedXmlStrOut,"<KEYWORDDESC>NA</KEYWORDDESC>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLWIDTH></BLWIDTH>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLTHICKNESS></BLTHICKNESS>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLLENGTH></BLLENGTH>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<COMPBLANKS></COMPBLANKS>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<BLWEIGHT></BLWEIGHT>");	
				setAddStr(buff_cnt,bufferedXmlStrOut,"<USAGE></USAGE>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</PART>");
				if(levelStr1!=NULL)MEM_free(levelStr1);	
				if(partNoStr1!=NULL)MEM_free(partNoStr1);	
				if(descStr!= NULL)MEM_free(descStr);	
				if(revStr!=NULL)MEM_free(revStr);	
				if(uomStr!=NULL)MEM_free(uomStr);	
				if(qtyStr!= NULL)MEM_free(qtyStr);
				if(csStr!=NULL)MEM_free(csStr);					
				if(iaStr!=NULL)MEM_free(iaStr);						
				if(locStr!= NULL)MEM_free(locStr);
				if(ownernameStr!=NULL)MEM_free(ownernameStr);	
				if(partTypeStr!=NULL)MEM_free(partTypeStr);	
				if(coatedIndStr!= NULL)MEM_free(coatedIndStr);
				if(spareIndStr!=NULL)MEM_free(spareIndStr);	
				if(compCodeStr!=NULL)MEM_free(compCodeStr);	
				if(keywordStr!= NULL)MEM_free(keywordStr);					
			}

			
		}
		
	}		
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"</APLREPORT>");
	CALLAPI(BOM_close_window(window1));			
	printf("\nAPLStructureXls: End of the function...\n");fflush(stdout);	
	return ifail;
}

int APLStructuringReport( void *retValue )
{
	int 					ifail 			= ITK_ok;
	char					**partList 		= NULL;
	int 					partSize 		= 0;
	int 					i 				= 0; 
	int 					partCnt 		= 0;
	USERSERVICE_array_t 	array_struct;
	int 					array_size 		= 0; 
	char 					**string_array 	= NULL;	
	char 					*object_type 	= "Design Revision"; //change to Design Revision
	int 					count 			= 0;
	tag_t 					*itemrevs 		= NULLTAG;	
	
	const char				*prog_name 		="APLStructuringReport";
	char*					reportFormat	= NULL;
	tag_t 					partObj 		= NULLTAG;
	
	printf("\nAPLStructuringReport: Start of the function...\n");fflush(stdout);
	printf("\nGet the argument....\n");fflush(stdout);
	USERARG_get_string_argument(&reportFormat);
	printf("\nReport Format===>%s\n", reportFormat);fflush(stdout);
	
	USERARG_get_string_array_argument(&partSize, &partList);
	printf("\nGot the argument....\n");fflush(stdout);
	printf("\nPart Size===>%d\n", partSize);fflush(stdout);
	for(i=0; i< partSize; i++)
	{
		printf("\nPart Number===>%s\n", partList[i]);fflush(stdout);
	}
	if(partSize>0)
	{
		//CALLAPI(getItemObjects(partList[0],object_type,&count,&itemrevs));
		//Get the latest standard release part
		CALLAPI(getLatestStandardReleasedPart(partList[0],object_type, &partObj));
	}
	else
	{
		printf("\nAPLStructuringReport:No part found in TCUA database : partSize==>%d\n", partSize);fflush(stdout);
	}
	
		
	
	if(partObj!=NULLTAG)
	{
		//printf("\n ** No of Object of Type %s found for part number %s is %d  ** \n",object_type,partList[0],count);fflush(stdout);
		
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;		
		//partObj = itemrevs[0];
		
		CALLAPI(APLStructureXls(partObj, retValue, &bufferedXmlStrOut,&buff_cnt));	

		int m =0;
		array_size = buff_cnt;
		string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
		for(m=0;m<buff_cnt;m++)
		{
			printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
			string_array[m] = bufferedXmlStrOut[m];
		}		
		
		ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

		if (array_struct.length != 0)
			*((USERSERVICE_array_t*) retValue) = array_struct;			
		MEM_free(string_array);
	}
	else
	{
		printf("\nAPLStructuringReport:No part found in TCUA database named %s....\n",partList[0]);fflush(stdout);
	}
	
	printf("\nAPLStructuringReport: End of the function...\n");fflush(stdout);
	return ifail;
	
}
//Manoj
int CalcDays(char* dt1)
{
	char 		*DateWtTime1		= 	NULL;
	char 		*Date1				= 	NULL;
	char 		*Month1				= 	NULL;;
	char 		*Year1				= 	NULL;
	char 		*DateCp				= 	NULL;
	int			iDay,iYear,iMonth	=   0;
	
	DateCp = strdup(dt1);
	
	printf("\n Hii... function CalcDays invoked");fflush(stdout);

	DateWtTime1 = strtok (DateCp," ");
	Date1 = strtok (DateWtTime1,"-");
	Month1 = strtok (NULL,"-");
	Year1 = strtok (NULL,"-");
	
	printf("\n 0000");fflush(stdout);
		
	iDay = atoi(Date1);
	iYear = atoi(Year1);
	
	printf("\n 1111");fflush(stdout);
	
	if(strcmp(Month1,"Jan")==0)
	{		
		iMonth=1;
	}
	else if(strcmp(Month1,"Feb")==0)
	{
		iMonth=2;
	}
	else if(strcmp(Month1,"Mar")==0)
	{
		iMonth=3;
	}
	else if(strcmp(Month1,"Apr")==0)
	{
		iMonth=4;
	}
	else if(strcmp(Month1,"May")==0)
	{
		iMonth=5;
	}
	else if(strcmp(Month1,"Jun")==0)
	{
		iMonth=6;
	}
	else if(strcmp(Month1,"Jul")==0)
	{
		iMonth=7;
	}
	else if(strcmp(Month1,"Aug")==0)
	{
		iMonth=8;
	}
	else if(strcmp(Month1,"Sep")==0)
	{
		iMonth=9;
	}
	else if(strcmp(Month1,"Oct")==0)
	{
		iMonth=10;
	}
	else if(strcmp(Month1,"Nov")==0)
	{
		iMonth=11;
	}
	else if(strcmp(Month1,"Dec")==0)
	{
		iMonth=12;
	}
	else
	{
		printf("\n No match found for Month1 !!!");fflush(stdout);
	}
	

	printf("\nYear is:%d, Month:%d, Date is:%d",iYear,iMonth,iDay); fflush(stdout);
	
	
    return (iDay + (153 * (iMonth + 12 * ((14 - iMonth) / 12) - 3) + 2) / 5 + 365 *
        (iYear + 4800 - ((14 - iMonth) / 12)) + (iYear + 4800 - ((14 - iMonth) / 12)) / 4 - 32083);
	
	printf("\n Hii... returned from function CalcDays ");fflush(stdout);
}

/* Start of my implementation of Report Generation */
int APLSummaryReport( void *return_data )
{
	int 		ifail 				= 	ITK_ok;
	int 		count 				= 	0;
	int 		count1				=	1;
	int 		k					=	0;
	char 		*FileName			=	NULLTAG;
	char 		*PlannrName			=	NULLTAG;
	char 		*PlantName			=	NULLTAG;
	char 		*FromDt				=	NULLTAG;
	char 		*ToDt				=	NULLTAG;
	char 		*objType 			= 	NULL;
	char 		*FinalPostFix		= 	NULL;
	char 		*FinalDMLApl		= 	NULL;
	tag_t		qryTag				= 	NULLTAG;
	tag_t		qryTagAPLWF			= 	NULLTAG;
	char		*ArgName[5];
	char		*ArgVal[5];
	char		*ArgName2[5];
	char		*ArgVal2[5];
	//char    	**ArgVal = (char **) MEM_alloc(10 * sizeof(char *));
	int 		resultsQry			=	0;
	int 		resultsQryWFAct		=	0;
	tag_t 		*rev				=	NULLTAG;
	tag_t 		*ObjsWFAct			=	NULLTAG;
	char 		*ERCDMLRevNum		= 	NULL;
	char 		*ListOfERCDML		= 	NULL;
	int 		dateDiff 			= 	0;
	int 		diffExcd15 			= 	0;
	int 		RlzExcd15Days		= 	0;
	int 		RlzExcd15DaysNot45	= 	0;
	int 		PndngWithIn15Days	= 	0;
	int 		PndngExcd15Days		= 	0;
	int 		AminusC				= 	0;
	float 		ResultII			= 	0;
	float 		hundred 			= 	100.00; 		
	FILE 		*DmlSummaryRptFile	=	NULL;
	float 		dmlHeadEffRes 		= 	0;
	char		*DmlHeadEffRes 		= 	0;
	DmlHeadEffRes = (char *) MEM_alloc( 5000 * sizeof(char) );
	int x;
	char 		*retValue			= 	NULL;
	const char* prog_name ="APLSummaryReport";
	
	printf("\n Server ITK....");fflush(stdout);		

	ListOfERCDML = (char *) MEM_alloc( 5000 * sizeof(char) );
	tc_strcpy(ListOfERCDML,"");
	
	char 		*ListOfRlzdAPLDML		= 	NULL;
	ListOfRlzdAPLDML = (char *) MEM_alloc( 5000 * sizeof(char) );
	tc_strcpy(ListOfRlzdAPLDML,"");	
	
	USERARG_get_string_argument(&FileName); 
	USERARG_get_string_argument(&PlannrName);
	USERARG_get_string_argument(&PlantName);
	USERARG_get_string_argument(&FromDt); 
	USERARG_get_string_argument(&ToDt);	
	printf(" File Name => %s || Planner Name => %s || Plant Name ==> %s || From Date ==> %s || To Date ==> %s ",FileName,PlannrName,PlantName,FromDt,ToDt);fflush(stdout);
	
	char 		*FromDt1			=	NULLTAG;
	char 		*ToDt1				=	NULLTAG;
	
	FromDt1 = strdup(FromDt);
	ToDt1 = strdup(ToDt);
	
	FinalPostFix = (char *) MEM_alloc( 5000 * sizeof(char) );

	/*if(tc_strcmp(PlantName,"CVBU JSR") == 0)
	{
		tc_strcpy(FinalPostFix,"APLJ");
		printf("\n PostFix Will Be APLJ based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else
	{
		tc_strcpy(FinalPostFix,"APLJ");
		printf("\n Else:: PostFix Will Be APLJ based on %s Plant... \n",PlantName);fflush(stdout);
	}*/
	if(tc_strcmp(PlantName,"CAR") == 0)
	{
		tc_strcpy(FinalPostFix,"APLC");
		printf("\n PostFix Will Be APLC based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"CVBU JSR") == 0)
	{
		tc_strcpy(FinalPostFix,"APLJ");
		printf("\n PostFix Will Be APLJ based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else if((tc_strcmp(PlantName,"CVBU LKO")==0) || (tc_strcmp(PlantName,"PCBU LKO")==0) || (tc_strcmp(PlantName,"PUVBU")==0))
	{
		tc_strcpy(FinalPostFix,"APLL");
		printf("\n PostFix Will Be APLL based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"CVBU PUNE")==0)
	{
		tc_strcpy(FinalPostFix,"APLP");
		printf("\n PostFix Will Be APLP based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"DHARWAD")==0)
	{
		tc_strcpy(FinalPostFix,"APLD");
		printf("\n PostFix Will Be APLD based on %s Plant... \n",PlantName);fflush(stdout);
	}
	else if((tc_strcmp(PlantName,"CVBU PNR")==0) || (tc_strcmp(PlantName,"SMALLCAR PNR")==0))	
	{
		tc_strcpy(FinalPostFix,"APLU");
		printf("\n PostFix Will Be APLD based on %s Plant... \n",PlantName);fflush(stdout);		
	}
	else if((tc_strcmp(PlantName,"PCBU")==0) || (tc_strcmp(PlantName,"PCBU and CVBU")==0) || (tc_strcmp(PlantName,"SMALLCAR AHD")==0))	
	{
		tc_strcpy(FinalPostFix,"APLP");
		printf("\n PostFix Will Be APLD based on %s Plant... \n",PlantName);fflush(stdout);		
	}	
	else
	{
		tc_strcpy(FinalPostFix,"APLC");
		printf("\n Else:: PostFix Will Be APLC based on %s Plant... \n",PlantName);fflush(stdout);
	}	
	
	if(QRY_find("General...", &qryTag));
	if (qryTag)
	{
		printf("\n Here:Found Query General... \n");fflush(stdout);
	}
	else
	{
		printf("\n Here:Not Found Query General... \n");fflush(stdout);
	}

	ArgName[0] = "Released After";
	ArgVal[0]  = FromDt1;	
	ArgName[1] = "Released Before";
	ArgVal[1]  = ToDt1;		
	ArgName[2] = "Owning User";
	ArgVal[2]  = PlannrName;
	ArgName[3] = "Type";
	ArgVal[3]  = "ERC DML Revision";
	ArgName[4] = "Release Status";
	ArgVal[4]  = "ERC Released";
	
	if(QRY_execute(qryTag, 5, ArgName, ArgVal, &resultsQry, &rev));
	
	printf(" resultsQry count:%d \n\t",resultsQry); fflush(stdout);
	if(resultsQry>0)
	{
		
		printf(" Item Revision exists in UA....resultsQry:%d \n\t",resultsQry); fflush(stdout);
		if(rev != NULLTAG)
		{
			int dm = 0;
			for (dm=0;dm<resultsQry;dm++ )
			{			
				CALLAPI(AOM_ask_value_string(rev[dm],"item_id",&ERCDMLRevNum));	
				if(strstr(ERCDMLRevNum,"_")!=NULL)
				{
					printf(" APLJ %s\t",ERCDMLRevNum); fflush(stdout);
				}
				else
				{			
					tc_strcat(ListOfERCDML,"#");
					tc_strcat(ListOfERCDML,ERCDMLRevNum);
				}
			}
		}
	}
	else
	{
		printf(" Item Revision Does not exists in UA....resultsQry:%d \n\t",resultsQry); fflush(stdout);
	}
	
	if(QRY_find("Audit - Workflow General_TML", &qryTagAPLWF));
	if (qryTagAPLWF)
	{
		printf("\n Here:Found Query Audit - Workflow General_TML... \n");fflush(stdout);
	}
	else
	{
		printf("\n Here:Not Found Query Audit - Workflow General_TML... \n");fflush(stdout);
	}
	
	char ercDmlObjs[50];	
	sprintf(ercDmlObjs, "%d", resultsQry);
	
	
	ArgName2[0] = "Job Name";
	ArgVal2[0]  = "*";
	ArgName2[1] = "End Date From";
	ArgVal2[1]  = FromDt1;	
	ArgName2[2] = "End Date To";
	ArgVal2[2]  = ToDt1;		
	ArgName2[3] = "Name";
	ArgVal2[3]  = "Work On DML"; 
	ArgName2[4] = "Event Type Name";
	ArgVal2[4]  = "Start"; 
	
	if(QRY_execute(qryTagAPLWF, 5, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));
	
	printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
	if(resultsQryWFAct>0)
	{
		printf(" Work On DML in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	else
	{
		printf(" Work On DML Does not exists in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	
	int j = 0;
	int	RlzWithIn15Days	= 0;
	int	PendingWithIn15Days	= 0;
	int	PendingAfter15Days	= 0;
	int	RlzAfterIn15Days	= 0;
	for (j=0;j<resultsQryWFAct;j++ )
	{
		tag_t 		Optfmly_tag 	= 	NULLTAG;
		char 		*jobName		= 	NULL;
		char 		*DMLAPL			= 	NULL;
		char 		*timeInDup		= 	NULL;
		int			ActDuration		= 	0;
		char 		*DMLRevNum		= 	NULL;
		char 		*rlzDateDup		= 	NULL;
		tag_t		*ReleaseStat	=	NULLTAG;
		int 		st_count		=	0;			
		Optfmly_tag = ObjsWFAct[j];
		CALLAPI(AOM_ask_value_int(Optfmly_tag,"fnd0ActualDuration",&ActDuration));
		printf("\n Work On DML Duration in Minute  :: %d\n",ActDuration);fflush(stdout);
		CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
		printf("\n Work On DML Job Name  :: %s\n",jobName);fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"fnd0StartDate",&timeInDup));					
		printf("\n\t fnd0StartDate:: [%s]\n\t",timeInDup);
		DMLAPL = strtok (jobName,"_");
		FinalDMLApl = (char *) MEM_alloc( 5000 * sizeof(char) );
		tc_strcpy(FinalDMLApl,DMLAPL);
		tc_strcat(FinalDMLApl,"_");
		tc_strcat(FinalDMLApl,FinalPostFix);
		
		printf("\n APL DML %s",FinalDMLApl);fflush(stdout);		
		tag_t		qryAPLTag	= NULLTAG;
		char		*ArgName3[1];
		char		*ArgVal3[1];
		int			resultsQryAPL = 0;
		tag_t		*revAPL	= NULLTAG;
		char* 		c_st_class_name	=	NULL;
		if(QRY_find("APL DML", &qryAPLTag));
		if (qryAPLTag)
		{
			printf("\n Here:Found Query APL DML... \n");fflush(stdout);
		}
		else
		{
			printf("\n Here:Not Found Query APL DML... \n");fflush(stdout);
		}
		
		ArgName3[0] = "ID";
		ArgVal3[0]  = FinalDMLApl;
		
		if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPL, &revAPL));
		
		
		printf(" resultsQry count:%d \n\t",resultsQryAPL); fflush(stdout);
		if(resultsQry>0)
		{
			printf("Item Revision exists in UA....resultsQry:%d \n\t",resultsQryAPL); fflush(stdout);
			int k = 0;
			for (k=0;k<resultsQryAPL;k++ )
			{
				tag_t 		APLMstr_tag = 	NULLTAG;
				char 		*DMLNum		= 	NULL;
				char 		*DMLNameDup	= 	NULL;
				tag_t 		revDML			=	NULLTAG;				
				APLMstr_tag = revAPL[k];
				CALLAPI(AOM_ask_value_string(APLMstr_tag,"item_id",&DMLNum));
				printf("\n APL DML Found  :: %s\n",DMLNum);fflush(stdout);	
				DMLNameDup = strtok(DMLNum, "_");
				ITEM_ask_latest_rev(APLMstr_tag,&revDML);	
				if(revDML != NULLTAG)
				{	
					CALLAPI(AOM_ask_value_string(revDML,"item_id",&DMLRevNum));
					printf("\n APL DML Revision Found  :: %s\n",DMLRevNum);fflush(stdout);	
					CALLAPI(WSOM_ask_release_status_list(revDML,&st_count,&ReleaseStat));
					printf("\n\n\t\t Release Status Count  is :%d",st_count);	fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(revDML,"date_released",&rlzDateDup));					
					printf("\n\t rlzDateDup:: [%s]\n\t",rlzDateDup);
					int			iStCnt			=  	0;	
					for (iStCnt=0;iStCnt<st_count ;iStCnt++ )//T5_LcsStdRlzd
					{								
						CALLAPI(AOM_ask_value_string(ReleaseStat[iStCnt],"object_name",&c_st_class_name));
						printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
					}
				 }
				if((tc_strcmp(c_st_class_name,"T5_LcsAplRlzd") == 0) || (tc_strcmp(c_st_class_name,"T5_LcsStdWrkg") == 0) || (tc_strcmp(c_st_class_name,"T5_LcsStdRlzd") == 0))
				{	
					printf("\nLifecyclestate equal and APL Released"); fflush(stdout);
					printf("\n TimeStampIn:%s, ReleaseDate:%s",timeInDup,rlzDateDup); fflush(stdout);
					dateDiff = (CalcDays(rlzDateDup) - CalcDays(timeInDup));
					
					if(dateDiff<=15)
					RlzWithIn15Days+=1;
					else
					{
						diffExcd15 = (CalcDays(ToDt) - CalcDays(rlzDateDup));
						printf("\n Difference of Dates in within 45 Days:%d",diffExcd15); fflush(stdout);
						if(diffExcd15<=45 && diffExcd15>0)
							RlzExcd15Days+=1;
						else
							RlzExcd15DaysNot45+=1;
					}									
					
					tc_strcat(ListOfRlzdAPLDML,DMLNum);
					tc_strcat(ListOfRlzdAPLDML,"#");			
				}
				else
				{			
					printf("\nLifecyclestate below APL Released"); fflush(stdout);
					printf("\n TimeStampIn:%s, ToDate:%s",timeInDup,ToDt); fflush(stdout);
					dateDiff = (CalcDays(ToDt) - CalcDays(timeInDup));
					printf("\nDifference between Dates:%d",  dateDiff);
					if(dateDiff<=15)
						PndngWithIn15Days+=1;
					else
						PndngExcd15Days+=1;
				}
			}
		}
		else
		{
			printf(" Item Revision Does not exists in UA....resultsQry:%d \n\t",resultsQry); fflush(stdout);
		}	
	}
	
	retValue = (char *) MEM_alloc( 5000 * sizeof(char) );		
	
	char DMlRlzWithIn15Days[10];	
	sprintf(DMlRlzWithIn15Days, "%d", RlzWithIn15Days);
	
	char RlzExcd15DaysChar[10];	
	sprintf(RlzExcd15DaysChar, "%d", RlzExcd15Days);
	
	char PndngWithIn15DaysChar[10];	
	sprintf(PndngWithIn15DaysChar, "%d", PndngWithIn15Days);
	printf("\n PndngWithIn15DaysChar:%s",PndngWithIn15DaysChar); fflush(stdout);
	
	char PendingAfter15DaysChar[10];	
	sprintf(PendingAfter15DaysChar, "%d", PndngExcd15Days);
	
	char DMlRlzAfte15Days[10];	
	sprintf(DMlRlzAfte15Days, "%d", RlzAfterIn15Days);
	
	char RlzExcd15DaysNot45Char[10];	
	sprintf(RlzExcd15DaysNot45Char, "%d", RlzExcd15DaysNot45);
	
	AminusC = (resultsQry - PndngWithIn15Days);
	printf("\n AminusC:%d",AminusC); fflush(stdout);
	ResultII = (hundred/AminusC);
	printf("\n ResultII:%f",ResultII); fflush(stdout);
	dmlHeadEffRes = (RlzWithIn15Days * ResultII);

	printf("\n Efficiency (B * 100 / (A-C)):%.2f", dmlHeadEffRes); fflush(stdout);
	sprintf(DmlHeadEffRes,"%.2f",dmlHeadEffRes);
	

	
	char 		*FrmDateF			= 	NULL;
	char 		*ToDateF			= 	NULL;
	FrmDateF = strtok (FromDt1," ");
	ToDateF = strtok (ToDt1," ");
	

	tc_strcpy(retValue,"<?xml version='1.0' encoding='UTF-8'?>");
	tc_strcat(retValue,"<AplRptData>");
	tc_strcat(retValue,"<FromDate>");
	tc_strcat(retValue,FrmDateF);
	tc_strcat(retValue,"</FromDate>");
	tc_strcat(retValue,"<ToDate>");
	tc_strcat(retValue,ToDateF);
	tc_strcat(retValue,"</ToDate>");
	tc_strcat(retValue,"<Planner>");
	tc_strcat(retValue,PlannrName);
	tc_strcat(retValue,"</Planner>");
	tc_strcat(retValue,"<cd>");
	tc_strcat(retValue,"<dmlRelByERC>");
	tc_strcat(retValue,ercDmlObjs);
	tc_strcat(retValue,"</dmlRelByERC>");
	tc_strcat(retValue,"<dmlrelwithinlimit>");
	tc_strcat(retValue,DMlRlzWithIn15Days);
	tc_strcat(retValue,"</dmlrelwithinlimit>");
	tc_strcat(retValue,"<dmlrelafterlimit>");
	tc_strcat(retValue,RlzExcd15DaysChar);
	tc_strcat(retValue,"</dmlrelafterlimit>");
	tc_strcat(retValue,"<dmlpndgafterlimit>");
	tc_strcat(retValue,PndngWithIn15DaysChar);
	tc_strcat(retValue,"</dmlpndgafterlimit>");
	tc_strcat(retValue,"<dmlpndgabovelimit>");
	tc_strcat(retValue,RlzExcd15DaysNot45Char);
	tc_strcat(retValue,"</dmlpndgabovelimit>");
	tc_strcat(retValue,"<effA>");
	tc_strcat(retValue,DmlHeadEffRes);
	tc_strcat(retValue,"</effA>");
	tc_strcat(retValue,"</cd>");
	
	printf("generated Output :: %s",retValue);
	
	char 		*apldmlno			= 	NULL;
	apldmlno = strtok (ListOfRlzdAPLDML,"#");
	if(apldmlno!=NULL)
	{
		printf("\n APL dml numver found");fflush(stdout);
	}
	else
	{
		printf("\n No DML found in date");fflush(stdout);
	}
		
	tc_strcat(retValue,"<ef>");	
	tc_strcat(retValue,"<DMLInternalActDec>0</DMLInternalActDec>");
	tc_strcat(retValue,"<DMLInternalActtobeDec>0</DMLInternalActtobeDec>");
	tc_strcat(retValue,"<DMLInternalActComlted>0</DMLInternalActComlted>");
	tc_strcat(retValue,"<DMLInternalActDecBtNComlted>0</DMLInternalActDecBtNComlted>");
	tc_strcat(retValue,"<DecEff>0.00</DecEff>");
	tc_strcat(retValue,"<CompEff>0.00</CompEff>");
	tc_strcat(retValue,"</ef>");
	
	
	tc_strcat(retValue,"<gh>");
	tc_strcat(retValue,"<ADDIRAPL>0</ADDIRAPL>");
	tc_strcat(retValue,"<IndActDec>0</IndActDec>");
	tc_strcat(retValue,"<DmlExeedFiftnDys>0</DmlExeedFiftnDys>");
	tc_strcat(retValue,"<IndNtReq>0</IndNtReq>");
	tc_strcat(retValue,"<IndAppBtNtRel>0</IndAppBtNtRel>");
	tc_strcat(retValue,"<Effiency>0.00</Effiency>");
	tc_strcat(retValue,"</gh>");
	tc_strcat(retValue,"</AplRptData>");
	
	*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(retValue ) + 1) * sizeof(char));

	strcpy( *((char **) return_data), retValue); 
	
	return ifail;		
}
//APLStatus Report Start
int TaskReleaseStatus1(tag_t item_tag_rev, char *ReleaseStat)
{
	int ifail = ITK_ok;
	int ii                         = 0;
	int	   			status_count					= 0;
	int 			status;	
	tag_t* status_list = NULLTAG;
	char *relStatus=NULL;
	char *lifecyclestat=NULL;
	lifecyclestat = (char *) MEM_alloc( 100 * sizeof(char) );  

	status=WSOM_ask_release_status_list(item_tag_rev,&status_count,&status_list);
	if(status==ITK_ok)
	{
		printf("\n number of statuses for Task: %d \n",  status_count);
		for (ii = 0; ii < status_count; ii++)
		{
			ITK_CALL (AOM_ask_name(status_list[ii], &relStatus));
			printf("\t ReleaseStat: %s\n", relStatus);fflush(stdout);
		}
	}
		 
	if (tc_strcmp(	relStatus,"T5_LcsAplRlzd")==0)
	{
		tc_strcpy(lifecyclestat,"APL RELEASED");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsAPLWrkg")==0)
	{
		tc_strcpy(lifecyclestat,"APL Working");
	}
	else if (tc_strcmp(	relStatus,"T5_APLFinalReleased")==0)
	{
		tc_strcpy(lifecyclestat,"APL Final Released");
	}
	else if (tc_strcmp(	relStatus,"T5_APLPre-Released")==0)
	{
		tc_strcpy(lifecyclestat,"APL Pre- Released");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsStdRlzd")==0)
	{
		tc_strcpy(lifecyclestat,"STDSI Released");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsSTDWrkg")==0)
	{
		tc_strcpy(lifecyclestat,"STDSI Working");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsErcRlzd")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC RELEASED");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsReview")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC REVIEW");
	}

	else if (tc_strcmp(	relStatus,"T5_LcsWorking")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC WORKING");
	}
	else
	{
		tc_strcpy(lifecyclestat,relStatus);
	}
	printf("\t Lifecycle stat: %s\n", lifecyclestat);fflush(stdout);

	tc_strcpy(ReleaseStat,lifecyclestat);

	MEM_free(lifecyclestat);

	return ifail;
}

int	QueryAplParticipant(tag_t task_rev_tag, char *TaskAplWrkOnDMLF,char *TaskAplRevF,char *TaskSTDCreEPAF,char *TaskSTDRevF)
{
	int         ifail               = ITK_ok;
	tag_t		qryTagAPLWF			= NULLTAG;
	char        *TaskId             = NULL;
	
	ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
	printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);
	
	char *JobID=NULL;
	JobID = (char *) MEM_alloc( 500 * sizeof(char) );
	tc_strcpy(JobID,TaskId);

	tc_strcat(JobID,"*");
	
	printf("\n\n JobID==%s \n",JobID);fflush(stdout);
	
	
	
	if(QRY_find("EPMTask_APLTaskQry", &qryTagAPLWF));
	if (qryTagAPLWF)
	{
		printf("\n Here:Found Query EPMTask_APLTaskQry... \n");fflush(stdout);
	}
	else
	{
		printf("\n Here:Not Found Query EPMTask_APLTaskQry... \n");fflush(stdout);
		return ifail;
	}
	
	
	
	char		*ArgName2[1];
	char		*ArgVal2[1];
		
	int 		resultsQryWFAct		=	0;
	tag_t 		*ObjsWFAct			=	NULLTAG;
		
	ArgName2[0] = "TASK ID";;
	ArgVal2[0]  = TaskId;
	
		
	if(QRY_execute(qryTagAPLWF, 1, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));
	
	printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
	if(resultsQryWFAct>0)
	{
		printf(" Work On DML in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	else
	{
		printf(" Work On DML Does not exists in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	int j=0;	
	for (j=0;j<resultsQryWFAct;j++ )
	{
		tag_t 		Optfmly_tag 	= 	NULLTAG;
		char 		*jobName		= 	NULL;
		char 		*DMLAPL			= 	NULL;
		char 		*timeInDup		= 	NULL;
		int			ActDuration		= 	0;
		char 		*DMLRevNum		= 	NULL;
		char 		*assgnname		= 	NULL;
		tag_t		*ReleaseStat	=	NULLTAG;
		int 		st_count		=	0;	
	 	char 		*Planner=NULL;	
		char* particType = NULL;	
		tag_t PlannerTag = NULLTAG;
		Optfmly_tag = ObjsWFAct[j];
		CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
		printf("\n Work On DML Job Name  :: %s\n",jobName);fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"object_name",&assgnname));					
		printf("\n\t assgnname:: [%s]\n\t",assgnname);
		
		if(strcmp(assgnname,"Work On DML")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));//fnd0Assignee
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n APL Planner :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskAplWrkOnDMLF,Planner);
			}

		}
		
		if(strcmp(assgnname,"Review The Changes Done By APL Planner")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			//ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Assignee",&PlannerTag));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n APL Reviewer :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskAplRevF,Planner);
			}
		}
		
		if(strcmp(assgnname,"Create EPA")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n STD Planner :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskSTDCreEPAF,Planner);
			}
			
		}
		
		if(strcmp(assgnname,"Review the Changes")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n STD Reviewer :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskSTDRevF,Planner);
			}			
			
		}
	
	}
	
		return ifail;
	}


int	QueryAplParticipants(tag_t task_rev_tag, char *TaskAplWrkOnDMLF,char *TaskAplRevF,char *TaskSTDCreEPAF,char *TaskSTDRevF)
{
	int         ifail               = ITK_ok;
	tag_t		qryTagAPLWF			= NULLTAG;
	char        *TaskId             = NULL;
	
	ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
	printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);
	
	char *JobID=NULL;
	JobID = (char *) MEM_alloc( 500 * sizeof(char) );
	tc_strcpy(JobID,TaskId);

	tc_strcat(JobID,"*");
	
	printf("\n\n JobID==%s \n",JobID);fflush(stdout);
	
	
	
	if(QRY_find("tm_APLTaskRevisionWFQry", &qryTagAPLWF));
	if (qryTagAPLWF)
	{
		printf("\n Here:Found Query tm_APLTaskRevisionWFQry... \n");fflush(stdout);
	}
	else
	{
		printf("\n Here:Not Found Query tm_APLTaskRevisionWFQry... \n");fflush(stdout);
		return ifail;
	}
	
	
	
	char		*ArgName2[1];
	char		*ArgVal2[1];
		
	int 		resultsQryWFAct		=	0;
	tag_t 		*ObjsWFAct			=	NULLTAG;
		
	ArgName2[0] = "TASK ID";;
	ArgVal2[0]  = TaskId;
	
		
	if(QRY_execute(qryTagAPLWF, 1, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));
	
	printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
	if(resultsQryWFAct>0)
	{
		printf(" Work On DML in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	else
	{
		printf(" Work On DML Does not exists in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
	}
	int j=0;	
	for (j=0;j<resultsQryWFAct;j++ )
	{
		tag_t 		Optfmly_tag 	= 	NULLTAG;
		char 		*jobName		= 	NULL;
		char 		*DMLAPL			= 	NULL;
		char 		*timeInDup		= 	NULL;
		int			ActDuration		= 	0;
		char 		*DMLRevNum		= 	NULL;
		char 		*assgnname		= 	NULL;
		tag_t		*ReleaseStat	=	NULLTAG;
		int 		st_count		=	0;	
	 	char 		*Planner=NULL;	
		char* particType = NULL;	
		tag_t PlannerTag = NULLTAG;
		Optfmly_tag = ObjsWFAct[j];
		CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
		printf("\n Work On DML Job Name  :: %s\n",jobName);fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"object_name",&assgnname));					
		printf("\n\t assgnname:: [%s]\n\t",assgnname);
		
		if(strcmp(assgnname,"Work On DML")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));//fnd0Assignee
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n APL Planner :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskAplWrkOnDMLF,Planner);
			}

		}
		
		if(strcmp(assgnname,"Review The Changes Done By APL Planner")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			//ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Assignee",&PlannerTag));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n APL Reviewer :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskAplRevF,Planner);
			}
		}
		
		if(strcmp(assgnname,"Create EPA")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n STD Planner :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskSTDCreEPAF,Planner);
			}
			
		}
		
		if(strcmp(assgnname,"Review the Changes")==0)
		{
			//ITK_CALL(AOM_ask_value_string(Optfmly_tag,"resp_party",&Planner));
			ITK_CALL(AOM_ask_value_tag(Optfmly_tag,"fnd0Performer",&PlannerTag));
			if(PlannerTag!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(PlannerTag,"object_string",&Planner));
				printf("\n STD Reviewer :: %s\n",Planner);fflush(stdout);
				tc_strcpy(TaskSTDRevF,Planner);
			}			
			
		}
	
	}
	
		return ifail;
}
	
int	QueryWorkFl(tag_t task_rev_tag, char *TaskAplWrkOnDMLF,char *TaskAplRevF,char *TaskSTDCreEPAF,char *TaskSTDRevF)
	{
	int             ifail                           = ITK_ok;
	tag_t		qryTagAPLWF			= 	NULLTAG;
	char        *TaskId                    = NULL;
	
	ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
	printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);
	
	char *JobID=NULL;
	JobID = (char *) MEM_alloc( 500 * sizeof(char) );
	tc_strcpy(JobID,TaskId);

	tc_strcat(JobID,"*");
	
	printf("\n\n JobID==%s \n",JobID);fflush(stdout);
	
	
	
	if(QRY_find("Audit - Workflow General_TML", &qryTagAPLWF));
		if (qryTagAPLWF)
		{
			printf("\n Here:Found Query Audit - Workflow General_TML... \n");fflush(stdout);
		}
		else
		{
			printf("\n Here:Not Found Query Audit - Workflow General_TML... \n");fflush(stdout);
		}
		
		char		*ArgName2[2];
		char		*ArgVal2[2];
		
		int 		resultsQryWFAct		=	0;
		tag_t 		*ObjsWFAct			=	NULLTAG;
		
		ArgName2[0] = "Job Name";
		ArgVal2[0]  = JobID;
	
		ArgName2[1] = "Name";
		ArgVal2[1]  = "*"; 
		
		if(QRY_execute(qryTagAPLWF, 2, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));
	
		printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
		if(resultsQryWFAct>0)
		{
			printf(" Work On DML in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
		}
		else
		{
			printf(" Work On DML Does not exists in UA....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
		}
	int j=0;	
	for (j=0;j<resultsQryWFAct;j++ )
	{
		tag_t 		Optfmly_tag 	= 	NULLTAG;
		char 		*jobName		= 	NULL;
		char 		*DMLAPL			= 	NULL;
		char 		*timeInDup		= 	NULL;
		int			ActDuration		= 	0;
		char 		*DMLRevNum		= 	NULL;
		char 		*assgnname		= 	NULL;
		tag_t		*ReleaseStat	=	NULLTAG;
		int 		st_count		=	0;	
	 	char 		*Planner=NULL;		
		Optfmly_tag = ObjsWFAct[j];
		CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
		printf("\n Work On DML Job Name  :: %s\n",jobName);fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"object_name",&assgnname));					
		printf("\n\t assgnname:: [%s]\n\t",assgnname);
		
		if(strcmp(assgnname,"Work On DML")==0)
		{
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"fnd0UserId",&Planner));
		printf("\n Work On DML Planner :: %s\n",Planner);fflush(stdout);
		tc_strcpy(TaskAplWrkOnDMLF,Planner);
		}
		
		if(strcmp(assgnname,"Review The Changes Done By APL Planner")==0)
		{
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"fnd0UserId",&Planner));
		printf("\n Work On DML Planner :: %s\n",Planner);fflush(stdout);
		tc_strcpy(TaskAplRevF,Planner);
		}
		
		if(strcmp(assgnname,"Create EPA")==0)
		{
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"fnd0UserId",&Planner));
		printf("\n Work On DML Planner :: %s\n",Planner);fflush(stdout);
		tc_strcpy(TaskSTDCreEPAF,Planner);
		}
		
		if(strcmp(assgnname,"Review the Changes")==0)
		{
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"fnd0UserId",&Planner));
		printf("\n Work On DML Planner :: %s\n",Planner);fflush(stdout);
		tc_strcpy(TaskSTDRevF,Planner);
		}
	
	}
	
		return ifail;
	}
	
	
void ReverseStr(char str[])
{
    int i,j;
    char temp[100];
    for(i=strlen(str)-1,j=0; i+1!=0; --i,++j)
    {
        temp[j]=str[i];
    }
    temp[j]='\0';
    strcpy(str,temp);
}
int t5GetTaskDmlLastValue(char *DmlTaskName,char *myPlant)
{

	//char *mod_name = "t5GetTaskDmlLastValue";
	char *myPlant1	=NULL;
	char *myPlant2	=NULL; //vit
	//string xx	=NULL;
	int ifail = ITK_ok;
	int LengthOfDmlTaskName=0;
	myPlant1 = (char *) MEM_alloc( 100 * sizeof(char) );


	printf("Inside  t5GetTaskDmlLastValue Function with input value %s\n",DmlTaskName);fflush(stdout);


	// Getting t5GetTaskDmlLastValue truncation.
	LengthOfDmlTaskName = strlen(DmlTaskName);
	if(tc_strcmp(DmlTaskName,NULL)==0 || tc_strcmp(DmlTaskName,"")==0 )
	{
	tc_strcpy(myPlant1,"");
	}
	else
	{
	tc_strcpy(myPlant1,DmlTaskName);
	}
	
	//if (!nlsIsStrNull(myPlant1))
	if(tc_strcmp(myPlant1,NULL)!=0 || tc_strcmp(myPlant1,"")!=0 )
	{
		ReverseStr(myPlant1);
		//myPlant = strtok (myPlant1,"_");
		myPlant2 = strtok (myPlant1,"_");
		ReverseStr(myPlant2);
		printf("\nmyPlant=%s",myPlant2);
		if(tc_strcmp(myPlant1,NULL)!=0 || tc_strcmp(myPlant1,"")!=0 )
		{
		tc_strcpy(myPlant,myPlant2);
		}
		//if(!nlsIsStrNull(myPlant2)) nlsStrCpy(myPlant,myPlant2);
		printf("\n myPlant = %s",myPlant);fflush(stdout);
	}
	return ifail;
}
int APLStatusReport( void *return_data )
{
		int ifail = ITK_ok;
		char*   DMLNumber                      = NULL;
		
		tag_t  *dml_tag                                  = NULLTAG;

		ITK_initialize_text_services (0);
		printf("\n Auto login ");fflush(stdout);
        date_t         a_date_from;
		date_t         a_date_to;
		date_t   vals[2];
		char 		*FileName			=	NULLTAG;
		//char 		*PlantName			=	NULLTAG;
		char 		*DmlType			=	NULLTAG;
		char 		*FromDt				=	NULLTAG;
		char 		*ToDt				=	NULLTAG;
		
		USERARG_get_string_argument(&FileName); 
		//USERARG_get_string_argument(&PlantName);
		USERARG_get_string_argument(&DmlType);
		USERARG_get_string_argument(&FromDt); 
		USERARG_get_string_argument(&ToDt);	
		
		
	//printf(" File Name => %s || Planner Name => %s || Plant Name ==> %s || From Date ==> %s || To Date ==> %s ",FileName,PlannrName,PlantName,FromDt,ToDt);fflush(stdout);
		printf(" File Name => %s From Date ==> %s || To Date ==> %s DML Type %s ",FileName,FromDt,ToDt,DmlType);fflush(stdout);
	
		char 		*FromDt1			=	NULLTAG;
		char 		*ToDt1				=	NULLTAG;
		char 		*DMLType1				=	NULLTAG;
		
		FromDt1 = strdup(FromDt);
		ToDt1 = strdup(ToDt);
		DMLType1 = strdup(DmlType);
		printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
		const char*    find_Dml_Number=NULL;
		const char * select_attrs[]={"puid"};
		int projlen=0;
		char** Project_code_Num=NULL;
		USERARG_get_string_array_argument(&projlen,&Project_code_Num);
		char 		*PrjCdId			= 	NULL;
		PrjCdId = (char *) MEM_alloc( 100 * sizeof(char) );
		int k;
		tc_strcpy(PrjCdId,"");
		for(k=0;k<projlen;k++)
		{
			
			printf("\n Project[%d]==[%s]",k+1,Project_code_Num[k]);
			tc_strcat(PrjCdId,Project_code_Num[k]);	
			tc_strcat(PrjCdId,";");	
			
		}

		ITK_string_to_date(FromDt1,&a_date_from);
		ITK_string_to_date(ToDt1,&a_date_to);
		vals[0]=a_date_from;
		vals[1]=a_date_to;
		int  rows = 0, columns = 0;
		void ***report;
		
		char 		*FromDt11			= 	NULL;
		char 		*ToDt11			= 	NULL;
		
		FromDt11 = strtok (FromDt1," ");						
		ToDt11 = strtok (ToDt1," ");	
		
		char 		*retValApStRpt			= 	NULL;
		retValApStRpt = (char *) MEM_alloc( 50000 * sizeof(char) );				

		tc_strcpy(retValApStRpt,"<?xml version='1.0' encoding='UTF-8'?>");
		tc_strcat(retValApStRpt,"<APLStatusRptData>");
		tc_strcat(retValApStRpt,"<PrjCode>");
		tc_strcat(retValApStRpt,PrjCdId);
		tc_strcat(retValApStRpt,"</PrjCode>");
		tc_strcat(retValApStRpt,"<FromDate>");
		tc_strcat(retValApStRpt,FromDt11);
		tc_strcat(retValApStRpt,"</FromDate>");
		tc_strcat(retValApStRpt,"<ToDate>");
		tc_strcat(retValApStRpt,ToDt11);
		tc_strcat(retValApStRpt,"</ToDate>");
		tc_strcat(retValApStRpt,"<dType>");
		tc_strcat(retValApStRpt,DMLType1);
		tc_strcat(retValApStRpt,"</dType>");
		
		
		// tag_t		qryPrjTag	= NULLTAG;
		// int			resultsQryPrj = 0;
		// tag_t		*PrjTag	= NULLTAG;
			
		// if(QRY_find("QueryProject", &qryPrjTag));
		
		// if (qryPrjTag)
		// {
			// printf("\n Here:Found Query project... \n");fflush(stdout);
		// }
		// else
		// {
			// printf("\n Here:Not Found Query Query project... \n");fflush(stdout);
		// }
		
		// char
	   // *ArgPrj1[] = {"Project ID","Active"},
	   // *ArgPrjVal1[]       = {"*","TRUE"};
	   
		// if(QRY_execute(qryPrjTag, 1, ArgPrj1, ArgPrjVal1, &resultsQryPrj, &PrjTag));

		// printf(" resultsQryPrj Poo count:%d \n\t",resultsQryPrj); fflush(stdout);
		// int NumOfPrj =0;
		// if(resultsQryPrj>0)
		// {
		// for (NumOfPrj=0;NumOfPrj<resultsQryPrj;NumOfPrj++ )
		// {
		// tag_t 		PrjTagObj = 	NULLTAG;
		// char 		*PrjNum		= 	NULL;
		// PrjTagObj = PrjTag[NumOfPrj];
		
		// CALLAPI(AOM_ask_value_string(PrjTagObj,"object_name",&PrjNum));
		// printf("\n PrjNum:: %s\n",PrjNum);fflush(stdout);

		// Project_code_Num[NumOfPrj]={PrjNum};
		// projlen++;		
		
		// }
		// }
	
	/** Creating a POM Query **/
	CALLAPI(POM_enquiry_create("find_Dml_Number"));

	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);

	/** Adding select attribute to Query **/

	CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));

	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);

	/**Adding Bind Variables to the Query.....**/

	CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_Num,POM_enquiry_bind_value));

	/**Setting Released Date **/
	CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));

	/** creating between Expression **/

	CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","creation_date",POM_enquiry_between,"expr_dates"));


	printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);

	 CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));			 

	/**creating And Expression **/

	CALLAPI(POM_enquiry_set_expr ( "find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));		

	printf("******Check After POM_enquiry_set_attr_expr*********\n");fflush(stdout);

	/**Setting the Where Expression **/

	printf("******Before Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));

	printf("******After  Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);
	
	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	POM_enquiry_add_order_attr ("find_Dml_Number", "POM_application_object", "t5_cprojectcode", POM_enquiry_asc_order);
	CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));
	
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	CALLAPI(POM_enquiry_delete("find_Dml_Number"));
	
	printf(" \n number of rows %d and coloumn %d\n",rows,columns);fflush(stdout);

	char	*SrNum			= NULL;
	int				line	= 0;	
	int ii;
	int NoPlntDML = 0;
	
	if (rows != 0)
	{
		for (ii = 0; ii < rows; ii++ )
		{
			int NoDMLTask = 0;
			 tag_t	query		= NULLTAG;
			 int	n_found		= 0;
			 tag_t	*t_item1	= NULLTAG;
			 tag_t objtag =NULLTAG;
			 char *AplDMLNum =NULL;
			 char *DMLDesignGroup =NULL;
			 char **DesignGroupList;
			 char        *DMLProjectCode	                      	= NULL;
			int num=0,k;
			char *Aplrlzdate = NULL;
			char *objdesc = NULL;
			char *Ercrlzdate = NULL;
			 objtag  = *(tag_t*)(report[ii][0]);
			 
			 char 		*FromDt11			= 	NULL;
			char 		*ToDt11			= 	NULL;
			
			FromDt11 = strtok (FromDt1," ");						
			ToDt11 = strtok (ToDt1," ");	
			 
			 CALLAPI(AOM_ask_value_string(objtag,"item_id",&AplDMLNum));
			 printf("\n--->>>>> AplDMLNum>>==%s\n",AplDMLNum);fflush(stdout);
			 printf("\n--->>>>> DMLType>>==%s\n",DMLType1);fflush(stdout);
			 char	*myPlant			= NULL;
			  myPlant=(char *) MEM_alloc(100 * sizeof(char ));
			  ITK_CALL(t5GetTaskDmlLastValue(AplDMLNum,myPlant));
			 //if (dstat=t5GetTaskDmlLastValue(AplDMLNum,myPlant)) goto EXIT;
			  printf("\n--->>>>> myPlant>>==%s\n",myPlant);fflush(stdout);
			 // if(strcmp(DMLSuff,"APLD")==0)
			  //{}
			 
			// DMLSuff = strtok (AplDMLNum,"_");
			 // printf("\n--->>>>> DMLSuff>>==%s\n",DMLSuff);fflush(stdout);
			 // printf("\n--->>>>> dml lenght>>==%d\n",dmllen);fflush(stdout);
			 //if(tc_strcmp(Ercrlzdate,NULL)==0 || tc_strcmp(Ercrlzdate,"")==0 )
			 if(tc_strcmp(myPlant,DMLType1)==0)
			 {
			 NoPlntDML = 1;
			 SrNum=(char *) MEM_alloc(100 * sizeof(char ));
			 line=line+1;
			 sprintf(SrNum,"%d",line);
			
			 tc_strcat(retValApStRpt,"<ASrptrow1>");
			 
			tc_strcat(retValApStRpt,"<SrNo>");
			tc_strcat(retValApStRpt,SrNum);
			tc_strcat(retValApStRpt,"</SrNo>");
			
			tc_strcat(retValApStRpt,"<DmlNum>");
			tc_strcat(retValApStRpt,AplDMLNum);
			tc_strcat(retValApStRpt,"</DmlNum>");
				
			// ITK_CALL(AOM_ask_value_strings(objtag,"t5_crdesigngroup",&num,&DesignGroupList));

			//for (k=0;k<num;k++)
			//{
			//	tc_strdup(DesignGroupList[k],&DMLDesignGroup);
			//	printf("\n  DMLDesignGroup : %s \n",DMLDesignGroup); fflush(stdout);

			//}
			
			ITK_CALL (AOM_ask_value_string(objtag,"t5_cprojectcode",&DMLProjectCode));
			printf("\n  DMLProjectCode : %s \n",DMLProjectCode); fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(objtag,"object_desc",&objdesc));
			printf("\n\t itemid--objdesc:: [%s]\n\t",objdesc);;fflush(stdout);
			
			
			//CALLAPI(AOM_UIF_ask_value(objtag,"date_released",&Aplrlzdate));
			//ITK_date_to_string(AplrelDate, &Aplrlzdate);
			//printf("\n\t itemid--Aplrlzdate:: [%s]\n\t",Aplrlzdate);;fflush(stdout);
			int st_count		=	0;
			int iStCnt		=	0;
			tag_t*			status_list			=	NULLTAG;
			ITKCALL(WSOM_ask_release_status_list(objtag,&st_count,&status_list));
			printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
			if (st_count>0)
			{
				for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsAplRlzd
				{
					char* c_st_class_name	=	NULL;
					char* c_st_ObjType	=	NULL;
					ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
					printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_type",&c_st_ObjType));
					printf("\n rlz status object_type: %s\n",c_st_ObjType);fflush(stdout);
					
					if(tc_strcmp(c_st_class_name,"T5_LcsAplRlzd")==0)
					{
						printf("\n Revision s is APL released");fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(status_list[iStCnt],"date_released",&Aplrlzdate));
						printf("\n\t itemid--Aplrlzdate:: [%s]\n\t",Aplrlzdate);;fflush(stdout);
						break;

					}
				}
			}
			else
			{
				printf("\n%s has no status, so part is not released from any agency");fflush(stdout);
			}
			
			if(strstr(AplDMLNum,"AM")==NULL)
						{
							char 		*DMLERC			= 	NULL;
							tag_t		qryERCTag	= NULLTAG;
							//char		*ArgERCNum1[1];
							//char		*ArgERCVal1[1];
							int			resultsQryERC = 0;
							tag_t		*revERC	= NULLTAG;
							
							DMLERC = strtok (AplDMLNum,"_");
							
							printf("\n ERC DML number  :: %s\n",DMLERC);fflush(stdout);
							
							if(QRY_find("Item Revision...", &qryERCTag));
							
							if (qryERCTag)
							{
								printf("\n Here:Found Query ERC DML MYTML Poo... \n");fflush(stdout);
							}
							else
							{
								printf("\n Here:Not Found Query ERC DML MYTML Poo... \n");fflush(stdout);
							}
							
							char
						   *ArgERCNum1[] = {"Item ID","Type"},
						   *ArgERCVal1[]       = {DMLERC,"ERC DML Revision"};
						   
							if(QRY_execute(qryERCTag, 1, ArgERCNum1, ArgERCVal1, &resultsQryERC, &revERC));
		
							printf(" resultsQryERC Poo count:%d \n\t",resultsQryERC); fflush(stdout);
							
							//printf("\n\t NOt AM DML",itemid);;fflush(stdout);
							
							if(resultsQryERC>0)
							{
								printf("Item Revision exists in UA....resultsQry:%d \n\t",resultsQryERC); fflush(stdout);
								int k = 0;
									tag_t 		ERCDML_tag = 	NULLTAG;
									char 		*ERCDMLNum		= 	NULL;
									char 		*DMLNameDup	= 	NULL;
									tag_t 		revDML			=	NULLTAG;
																	
									ERCDML_tag = revERC[0];
									CALLAPI(AOM_ask_value_string(ERCDML_tag,"item_id",&ERCDMLNum));
									printf("\n ERC DML Found poo :: %s\n",ERCDMLNum);fflush(stdout);	
									
									CALLAPI(AOM_UIF_ask_value(ERCDML_tag,"date_released",&Ercrlzdate));
									printf("\n\t itemid--ERCrlzdate:: [%s]\n\t",Ercrlzdate);;fflush(stdout);
							}
							//tc_strcat(retValApStRpt,"<ERCRlzDate>");
							//tc_strcat(retValApStRpt,Ercrlzdate);
							//tc_strcat(retValApStRpt,"</ERCRlzDate>");

						}
						else
						{
						//tc_strcat(retValApStRpt,"<ERCRlzDate>");
						//tc_strcat(retValApStRpt,"NA");
						//tc_strcat(retValApStRpt,"</ERCRlzDate>");

						}
			
			tag_t relatnType_tag                            = NULLTAG;
			int  noOfTask           = 0;
			tag_t *task_obj_tag                        		= NULLTAG;
			
			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
			
		if (relatnType_tag!=NULLTAG)
		{
			if ( (ifail = GRM_list_secondary_objects_only( objtag, relatnType_tag, &noOfTask, &task_obj_tag )) != ITK_ok )
			{
				return ifail;
			}
            printf("\n DMLTaskRel : No of Tasks are : %d \n",noOfTask); fflush(stdout);
			int i=0;
			if(noOfTask>0)
			{			
			for (i=0;i<noOfTask ;i++ )
			{	
				NoDMLTask=1;

				// Retrieve the Task-Revision Tag.
				tag_t task_rev_tag                              = NULLTAG;

				task_rev_tag=task_obj_tag[i];
				if (task_rev_tag  != NULLTAG)
				{

					int Tskcnt=0;
					int TskcntInPart=0;

					tag_t *TaskRevision=NULLTAG;
					tag_t relatnType_tag=NULLTAG;
					char  *TaskType   = NULL;
					char *TaskNum=NULL;


					ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskNum));
					printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskNum); fflush(stdout);
					
					char **DesignGroupList;
					char *TaskDesignGroup;
					int taskDgnum,k=0;
					ITK_CALL(AOM_ask_value_strings(task_rev_tag,"t5_crdesigngroup",&taskDgnum,&DesignGroupList));

					for (k=0;k<taskDgnum;k++)
					{
						tc_strdup(DesignGroupList[k],&TaskDesignGroup);
						printf("\n  TaskDesignGroup : %s \n",TaskDesignGroup); fflush(stdout);

					}
					if(i!=0)
					{
					tc_strcat(retValApStRpt,"<ASrptrow1>");
					
					tc_strcat(retValApStRpt,"<SrNo>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</SrNo>");
					
					tc_strcat(retValApStRpt,"<DmlNum>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</DmlNum>");
					}
					if(tc_strcmp(TaskDesignGroup,NULL)==0 || tc_strcmp(TaskDesignGroup,"")==0 )
					{
					tc_strcat(retValApStRpt,"<TskDgGrp>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</TskDgGrp>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<TskDgGrp>");
					tc_strcat(retValApStRpt,TaskDesignGroup);
					tc_strcat(retValApStRpt,"</TskDgGrp>");
					}
					
					if(i==0)
					{
						if(tc_strcmp(DMLProjectCode,NULL)==0 || tc_strcmp(DMLProjectCode,"")==0 )
						{
						tc_strcat(retValApStRpt,"<DmlPrjcode>");
						tc_strcat(retValApStRpt," ");
						tc_strcat(retValApStRpt,"</DmlPrjcode>");
						}
						else
						{
						tc_strcat(retValApStRpt,"<DmlPrjcode>");
						tc_strcat(retValApStRpt,DMLProjectCode);
						tc_strcat(retValApStRpt,"</DmlPrjcode>");
						}
					}
					else
					{
					tc_strcat(retValApStRpt,"<DmlPrjcode>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</DmlPrjcode>");
					}					
					
					
					char        *TaskAplWrkOnDML           = NULL;
					char        *TaskAplRev           = NULL;
					char        *TaskSTDCreEPA           = NULL;
					char        *TaskSTDRev           = NULL;
					TaskAplWrkOnDML = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskAplRev = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDCreEPA = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDRev = (char *) MEM_alloc( 100 * sizeof(char) );
					
					tc_strcpy(TaskAplWrkOnDML,"");
					tc_strcpy(TaskAplRev,"");
					tc_strcpy(TaskSTDCreEPA,"");
					tc_strcpy(TaskSTDRev,"");
					
					ITK_CALL (QueryWorkFl(task_rev_tag,TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev));
					printf("\n  Process His of APL/STD Planner and rev: APLWorkOnDML[%s] APL REv[%s] STD Create EPA [%s] STD Rev[%s] \n",TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev); fflush(stdout);
					
					if(tc_strcmp(TaskAplWrkOnDML,NULL)==0 || tc_strcmp(TaskAplWrkOnDML,"")==0 )
					{
					tc_strcat(retValApStRpt,"<AplPlanner>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</AplPlanner>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<AplPlanner>");
					tc_strcat(retValApStRpt,TaskAplWrkOnDML);
					tc_strcat(retValApStRpt,"</AplPlanner>");
					}
					
					if(tc_strcmp(TaskSTDCreEPA,NULL)==0 || tc_strcmp(TaskSTDCreEPA,"")==0 )
					{
					tc_strcat(retValApStRpt,"<StdPlanner>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</StdPlanner>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<StdPlanner>");
					tc_strcat(retValApStRpt,TaskSTDCreEPA);
					tc_strcat(retValApStRpt,"</StdPlanner>");
					}
					if(i==0)
					{
						if(tc_strcmp(Ercrlzdate,NULL)==0 || tc_strcmp(Ercrlzdate,"")==0 )
						{
						tc_strcat(retValApStRpt,"<ERCRlzDate>");
						tc_strcat(retValApStRpt," ");
						tc_strcat(retValApStRpt,"</ERCRlzDate>");
						}
						else
						{
						tc_strcat(retValApStRpt,"<ERCRlzDate>");
						tc_strcat(retValApStRpt,Ercrlzdate);
						tc_strcat(retValApStRpt,"</ERCRlzDate>");
						}
					}
					else
					{
					tc_strcat(retValApStRpt,"<ERCRlzDate>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</ERCRlzDate>");
					}
					printf("\n  calling function"); fflush(stdout);
					char        *TaskReleaseStat           = NULL;
					TaskReleaseStat = (char *) MEM_alloc( 100 * sizeof(char) );
					ITK_CALL(TaskReleaseStatus1(task_rev_tag,TaskReleaseStat));
					printf("\n  LC State of task : %s \n",TaskReleaseStat); fflush(stdout);
					
					
					if(tc_strcmp(TaskReleaseStat,NULL)==0 || tc_strcmp(TaskReleaseStat,"")==0 )
					{
					tc_strcat(retValApStRpt,"<TskLcStat>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</TskLcStat>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<TskLcStat>");
					tc_strcat(retValApStRpt,TaskReleaseStat);
					tc_strcat(retValApStRpt,"</TskLcStat>");
					}
					
					tc_strcat(retValApStRpt,"<IndtxtAtt>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndtxtAtt>");
					
					if(tc_strcmp(TaskAplRev,NULL)==0 || tc_strcmp(TaskAplRev,"")==0 )
					{
					tc_strcat(retValApStRpt,"<AplRev>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</AplRev>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<AplRev>");
					tc_strcat(retValApStRpt,TaskAplRev);
					tc_strcat(retValApStRpt,"</AplRev>");
					}
					
					if(tc_strcmp(TaskSTDRev,NULL)==0 || tc_strcmp(TaskSTDRev,"")==0 )
					{
					tc_strcat(retValApStRpt,"<StdRev>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</StdRev>");
					}
					else
					{
					tc_strcat(retValApStRpt,"<StdRev>");
					tc_strcat(retValApStRpt,TaskSTDRev);
					tc_strcat(retValApStRpt,"</StdRev>");
					}
					tc_strcat(retValApStRpt,"<IndRev>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndRev>");
					
					tc_strcat(retValApStRpt,"<IndCreDate>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndCreDate>");
					
					tc_strcat(retValApStRpt,"<IndAppDate>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndAppDate>");
					
					tc_strcat(retValApStRpt,"<IndStatus>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndStatus>");
					
					tc_strcat(retValApStRpt,"<IndComment>");
					tc_strcat(retValApStRpt,"Not Available");
					tc_strcat(retValApStRpt,"</IndComment>");
					
					if(i==0)
					{
						if(tc_strcmp(Aplrlzdate,NULL)==0 || tc_strcmp(Aplrlzdate,"")==0 )
						{
						tc_strcat(retValApStRpt,"<APLRlzDate>");
						tc_strcat(retValApStRpt," ");
						tc_strcat(retValApStRpt,"</APLRlzDate>");
						}
						else
						{
						tc_strcat(retValApStRpt,"<APLRlzDate>");
						tc_strcat(retValApStRpt,Aplrlzdate);
						tc_strcat(retValApStRpt,"</APLRlzDate>");
						}
					}
				else
					{
					tc_strcat(retValApStRpt,"<APLRlzDate>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</APLRlzDate>");
					}
					if(i==0)
					{
						if(tc_strcmp(objdesc,NULL)==0 || tc_strcmp(objdesc,"")==0 )
						{
						tc_strcat(retValApStRpt,"<Dmldesc>");
						tc_strcat(retValApStRpt," ");
						tc_strcat(retValApStRpt,"</Dmldesc>");
						}
						else
						{
						tc_strcat(retValApStRpt,"<Dmldesc>");
						tc_strcat(retValApStRpt,objdesc);
						tc_strcat(retValApStRpt,"</Dmldesc>");
						}
					}
					else
					{
					tc_strcat(retValApStRpt,"<Dmldesc>");
					tc_strcat(retValApStRpt," ");
					tc_strcat(retValApStRpt,"</Dmldesc>");
					}
					tc_strcat(retValApStRpt,"</ASrptrow1>");
				
				}
			}
			}
		}
		printf("\n value of NoDMLTask :%d",NoDMLTask);fflush(stdout);
		if (NoDMLTask == 0)
		{

		tc_strcat(retValApStRpt,"<TskDgGrp>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</TskDgGrp>");
		
		tc_strcat(retValApStRpt,"<DmlPrjcode>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</DmlPrjcode>");
		
		tc_strcat(retValApStRpt,"<AplPlanner>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</AplPlanner>");
		
		tc_strcat(retValApStRpt,"<StdPlanner>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</StdPlanner>");
		
		tc_strcat(retValApStRpt,"<ERCRlzDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</ERCRlzDate>");
		
		tc_strcat(retValApStRpt,"<TskLcStat>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</TskLcStat>");
		
		tc_strcat(retValApStRpt,"<IndtxtAtt>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndtxtAtt>");
		
		tc_strcat(retValApStRpt,"<AplRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</AplRev>");
		
		tc_strcat(retValApStRpt,"<StdRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</StdRev>");
		
		tc_strcat(retValApStRpt,"<IndRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndRev>");
		tc_strcat(retValApStRpt,"<IndCreDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndCreDate>");
		tc_strcat(retValApStRpt,"<IndAppDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndAppDate>");
		tc_strcat(retValApStRpt,"<IndStatus>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndStatus>");
		tc_strcat(retValApStRpt,"<IndComment>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndComment>");
		
		tc_strcat(retValApStRpt,"<APLRlzDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</APLRlzDate>");
		
		tc_strcat(retValApStRpt,"<Dmldesc>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</Dmldesc>");
		tc_strcat(retValApStRpt,"</ASrptrow1>");
		}
		}
		else
		{
		printf("\n  DML last digit not matched"); fflush(stdout);
		}
		}
	}
	if (NoPlntDML == 1)
	{
	tc_strcat(retValApStRpt,"</APLStatusRptData>");
	}
	printf("\n value of NoPlntDML :%d",NoPlntDML);fflush(stdout);
			
	if (NoPlntDML == 0)
	{
		tc_strcat(retValApStRpt,"<ASrptrow1>");
		tc_strcat(retValApStRpt,"<SrNo>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</SrNo>");
		
		tc_strcat(retValApStRpt,"<DmlNum>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</DmlNum>");
		
		tc_strcat(retValApStRpt,"<TskDgGrp>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</TskDgGrp>");
		
		tc_strcat(retValApStRpt,"<DmlPrjcode>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</DmlPrjcode>");
		
		tc_strcat(retValApStRpt,"<AplPlanner>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</AplPlanner>");
		
		tc_strcat(retValApStRpt,"<StdPlanner>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</StdPlanner>");
		
		tc_strcat(retValApStRpt,"<ERCRlzDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</ERCRlzDate>");
		
		tc_strcat(retValApStRpt,"<TskLcStat>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</TskLcStat>");
		
		tc_strcat(retValApStRpt,"<IndtxtAtt>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndtxtAtt>");
		
		tc_strcat(retValApStRpt,"<AplRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</AplRev>");
		
		tc_strcat(retValApStRpt,"<StdRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</StdRev>");
		
		tc_strcat(retValApStRpt,"<IndRev>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndRev>");
		tc_strcat(retValApStRpt,"<IndCreDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndCreDate>");
		tc_strcat(retValApStRpt,"<IndAppDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndAppDate>");
		tc_strcat(retValApStRpt,"<IndStatus>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndStatus>");
		tc_strcat(retValApStRpt,"<IndComment>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</IndComment>");
		
		tc_strcat(retValApStRpt,"<APLRlzDate>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</APLRlzDate>");
		
		tc_strcat(retValApStRpt,"<Dmldesc>");
		tc_strcat(retValApStRpt," ");
		tc_strcat(retValApStRpt,"</Dmldesc>");
		tc_strcat(retValApStRpt,"</ASrptrow1>");
		
		tc_strcat(retValApStRpt,"</APLStatusRptData>");
	
					
	}
	printf("\n copy value");fflush(stdout);
	*((char **) return_data) = 	(char *) MEM_alloc( (strlen(retValApStRpt ) + 1) * sizeof(char));

	strcpy( *((char **) return_data), retValApStRpt); 
	printf("\n return value");fflush(stdout);
	
	if(retValApStRpt!= NULL)MEM_free(retValApStRpt);
	if(SrNum!= NULL)MEM_free(SrNum);
	if(PrjCdId!= NULL)MEM_free(PrjCdId);
	return ifail;		
}
//APL Status Report End
//Poonam implementation
int PlannerWiseDMLReport( void *return_data )
{
	int 		ifail 				= 	ITK_ok;
	int status;
	char			*lineStr						= NULL;
	int				line						= 0;
	char 		*retValue			= 	NULL;
	int reportGen = 0;
	const char* prog_name ="PlannerWiseDMLReport";
	printf("\n I am in main program");fflush(stdout);
	char 		*FileName			=	NULLTAG;
	char 		*PlannrName			=	NULLTAG;
	char 		*FromDt				=	NULLTAG;
	char 		*ToDt				=	NULLTAG;
	
	USERARG_get_string_argument(&FileName); 
	USERARG_get_string_argument(&PlannrName);
	USERARG_get_string_argument(&FromDt); 
	USERARG_get_string_argument(&ToDt);	
	printf(" File Name => %s || Planner Name => %s || From Date ==> %s || To Date ==> %s ",FileName,PlannrName,FromDt,ToDt);fflush(stdout);
	
	char 		*FromDt1			= 	NULL;
	char 		*ToDt1			= 	NULL;
	
	FromDt1 = strtok (FromDt," ");						
	ToDt1 = strtok (ToDt," ");			

	tag_t queryTag = NULLTAG;
	if(QRY_find("General...", &queryTag));
	printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);
	
	
	if (queryTag)
	{
		printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
	}
	else
	{
		printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
	}				
	
    char  *critNames[4];
	char *critValues[4];
	
	critNames[0] = "Current Task";
	critValues[0] = "*";
	
	critNames[1] = "Owning User";
	//critValues[1] = "apljsr1";
	critValues[1] = PlannrName;
	
	critNames[2] = "Created After";
	//critValues[2] = "01-Jun-2018 10:21";
	critValues[2] = FromDt;
	
	critNames[3] = "Created Before";
	//critValues[3] = "03-Jun-2018 10:21";
	critValues[3] = ToDt;
	
	int resultCount=0;
	tag_t *rev=NULLTAG;
	if(QRY_execute(queryTag, 4, critNames, critValues, &resultCount, &rev));

	printf(" resultCount:%d \n\t",resultCount); fflush(stdout);
	
	retValue = (char *) MEM_alloc( 50000 * sizeof(char) );				

	tc_strcpy(retValue,"<?xml version='1.0' encoding='UTF-8'?>");
	tc_strcat(retValue,"<PlannerWiseAPlRpdData>");
	tc_strcat(retValue,"<Planner>");
	tc_strcat(retValue,PlannrName);
	tc_strcat(retValue,"</Planner>");
	tc_strcat(retValue,"<FromDate>");
	tc_strcat(retValue,FromDt1);
	tc_strcat(retValue,"</FromDate>");
	tc_strcat(retValue,"<ToDate>");
	tc_strcat(retValue,ToDt1);
	tc_strcat(retValue,"</ToDate>");

	if(resultCount>0)
	{
		printf(" Item Revision already exists in UA....resultCount:%d \n\t",resultCount); fflush(stdout);
		int j=0;
		for (j=0;j<resultCount;j++ )
		{
			//DatasetExistFlag = 0;
			//ApplnOwnerFlag = 0;
			//tc_strcpy(ApplnOwnerStr,"");
			tag_t item_tag = NULLTAG;
			item_tag = rev[j];
			
			char *objname =  NULL;
			char *objtype = NULL;
			char *itemid = NULL;
			//char *EcnType = NULL;
			char *Aplrlzdate = NULL;
			char *objdesc = NULL;
			char *credate = NULL;
			char *DMLDRStstus = NULL;
			date_t AplrelDate;
			
										
			CALLAPI(AOM_UIF_ask_value(item_tag,"creation_date",&credate));
			printf("\n\t credate--credate:: [%s]\n\t",credate);;fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(item_tag,"object_name",&objname));
			printf("\n\t ItemDesc--object_name:: [%s]\n\t",objname);;fflush(stdout);
			
									
			CALLAPI(AOM_ask_value_string(item_tag,"object_type",&objtype));
			printf("\n\t Itemtype--object_type:: [%s]\n\t",objtype);;fflush(stdout);
		
								
			//CALLAPI(AOM_ask_value_string(item_tag,"t5_EcnType",&EcnType));
			//printf("\n\t itemid--EcnType:: [%s]\n\t",EcnType);;fflush(stdout);
		
			char   type_name[TCTYPE_name_size_c+1];

			tag_t objTypeTag=NULLTAG;

			if(TCTYPE_ask_object_type(item_tag,&objTypeTag));
			TCTYPE_ask_name(objTypeTag,type_name);
			
			printf("\n\t type_name: [%s]\n\t",type_name);;fflush(stdout);
			int				count				= 0;
			int				TaskCnt				= 0;
			tag_t	relation_type = NULLTAG;
			tag_t*			TaskRevision		= NULLTAG;
			
			if(strcmp(type_name,"T5_APLDMLRevision")==0)
			{
				reportGen = 1;	

				printf("\n value reportGen %d",reportGen);fflush(stdout);
			
				lineStr=(char *) MEM_alloc(100 * sizeof(char ));
				line=line+1;
				sprintf(lineStr,"%d",line);

				tc_strcat(retValue,"<rptrow1>");
				tc_strcat(retValue,"<SrNo>");
				tc_strcat(retValue,lineStr);
				tc_strcat(retValue,"</SrNo>");
				
				CALLAPI(AOM_ask_value_string(item_tag,"item_id",&itemid));
				printf("\n\t itemid--itemid:: [%s]\n\t",itemid);;fflush(stdout);
				
				tc_strcat(retValue,"<DmlNum>");
				tc_strcat(retValue,itemid);
				tc_strcat(retValue,"</DmlNum>");
				
				CALLAPI(AOM_ask_value_string(item_tag,"object_desc",&objdesc));
				printf("\n\t itemid--objdesc:: [%s]\n\t",objdesc);;fflush(stdout);
					
				tc_strcat(retValue,"<DmlNumDes>");
				tc_strcat(retValue,objdesc);
				tc_strcat(retValue,"</DmlNumDes>");

				if(strstr(itemid,"AM")==NULL)
				{
					char 		*DMLERC			= 	NULL;
					tag_t		qryERCTag	= NULLTAG;
					int			resultsQryERC = 0;
					tag_t		*revERC	= NULLTAG;
					
					DMLERC = strtok (itemid,"_");
					
					printf("\n ERC DML number  :: %s\n",DMLERC);fflush(stdout);
					
					if(QRY_find("Item Revision...", &qryERCTag));
					
					if (qryERCTag)
					{
						printf("\n Here:Found Query ERC DML ... \n");fflush(stdout);
					}
					else
					{
						printf("\n Here:Not Found Query ERC DML ... \n");fflush(stdout);
					}
					
					char
				   *ArgERCNum1[] = {"Item ID","Type"},
				   *ArgERCVal1[]       = {DMLERC,"ERC DML Revision"};
					

					if(QRY_execute(qryERCTag, 1, ArgERCNum1, ArgERCVal1, &resultsQryERC, &revERC));

					printf(" resultsQryERC Poo count:%d \n\t",resultsQryERC); fflush(stdout);
					
					printf("\n\t NOt AM DML",itemid);;fflush(stdout);
					char *Ercrlzdate = NULL;
					if(resultsQryERC>0)
					{
						printf("Item Revision exists in UA....resultsQry:%d \n\t",resultsQryERC); fflush(stdout);
						int k = 0;
						tag_t 		ERCDML_tag = 	NULLTAG;
						char 		*ERCDMLNum		= 	NULL;
						char 		*DMLNameDup	= 	NULL;
						tag_t 		revDML			=	NULLTAG;
														
						ERCDML_tag = revERC[0];
						CALLAPI(AOM_ask_value_string(ERCDML_tag,"item_id",&ERCDMLNum));
						printf("\n ERC DML Found poo :: %s\n",ERCDMLNum);fflush(stdout);	
						
						CALLAPI(AOM_UIF_ask_value(ERCDML_tag,"date_released",&Ercrlzdate));
						printf("\n\t itemid--Aplrlzdate:: [%s]\n\t",Ercrlzdate);;fflush(stdout);
					}
					tc_strcat(retValue,"<ERCRlzDate>");
					tc_strcat(retValue,Ercrlzdate);
					tc_strcat(retValue,"</ERCRlzDate>");

				}
				else
				{
					tc_strcat(retValue,"<ERCRlzDate>");
					tc_strcat(retValue,"NA");
					tc_strcat(retValue,"</ERCRlzDate>");

				}
					
				CALLAPI(AOM_UIF_ask_value(item_tag,"date_released",&Aplrlzdate));
				//ITK_date_to_string(AplrelDate, &Aplrlzdate);
				printf("\n\t itemid--Aplrlzdate:: [%s]\n\t",Aplrlzdate);;fflush(stdout);
				
				if(tc_strcmp(Aplrlzdate,NULL)==0 || tc_strcmp(Aplrlzdate,"")==0 )
				{
					tc_strcat(retValue,"<APLRlzDate>");
					tc_strcat(retValue,"NA");
					tc_strcat(retValue,"</APLRlzDate>");
				}
				else
				{
					tc_strcat(retValue,"<APLRlzDate>");
					tc_strcat(retValue,Aplrlzdate);
					tc_strcat(retValue,"</APLRlzDate>");
				}
				
				tc_strcat(retValue,"<StdRlzDate>");
				tc_strcat(retValue,"not available");
				tc_strcat(retValue,"</StdRlzDate>");
				
				CALLAPI(AOM_ask_value_string(item_tag,"t5_cDRstatus",&DMLDRStstus));
				printf("\n\t itemid--objdesc:: [%s]\n\t",DMLDRStstus);;fflush(stdout);
				
				tc_strcat(retValue,"<TaskNum>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</TaskNum>");
				
				tc_strcat(retValue,"<Pnum>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</Pnum>");
				
				tc_strcat(retValue,"<Prev>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</Prev>");
				
				tc_strcat(retValue,"<PDesc>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</PDesc>");
				
				tc_strcat(retValue,"<PDModDet>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</PDModDet>");
				
				tc_strcat(retValue,"<AddInd>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</AddInd>");
				
				tc_strcat(retValue,"<AmaInd>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</AmaInd>");
				
				tc_strcat(retValue,"<Epanum>");
				tc_strcat(retValue," ");
				tc_strcat(retValue,"</Epanum>");
				
					
				if(tc_strcmp(DMLDRStstus,NULL)==0 || tc_strcmp(DMLDRStstus,"")==0 )
				{
					tc_strcat(retValue,"<DmlDRStatus>");
					tc_strcat(retValue,"NA");
					tc_strcat(retValue,"</DmlDRStatus>");
				}
				else
				{
					tc_strcat(retValue,"<DmlDRStatus>");
					tc_strcat(retValue,DMLDRStstus);
					tc_strcat(retValue,"</DmlDRStatus>");
				}
				tc_strcat(retValue,"</rptrow1>");

				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				 /// Solution Item start

				CALLAPI(GRM_list_secondary_objects_only(item_tag,relation_type,&count,&TaskRevision));
				printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
						
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					tc_strcat(retValue,"<rptrow1>");
					tc_strcat(retValue,"<SrNo>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</SrNo>");
					
					tc_strcat(retValue,"<DmlNum>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</DmlNum>");
					
					tc_strcat(retValue,"<DmlNumDes>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</DmlNumDes>");
					
					tc_strcat(retValue,"<ERCRlzDate>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</ERCRlzDate>");
					
					tc_strcat(retValue,"<APLRlzDate>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</APLRlzDate>");
					
					tc_strcat(retValue,"<StdRlzDate>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</StdRlzDate>");
					
					char *taskitemid = NULL;
					tag_t			TaskRevTag			= NULLTAG;
					char*			tskobject_type			= NULL;
					TaskRevTag = TaskRevision[TaskCnt];
					CALLAPI(AOM_ask_value_string(TaskRevTag,"item_id",&taskitemid));
					printf("\n\t itemid--itemid:: [%s]\n\t",taskitemid);;fflush(stdout);
					
					tc_strcat(retValue,"<TaskNum>");
					tc_strcat(retValue,taskitemid);
					tc_strcat(retValue,"</TaskNum>");
					
					tc_strcat(retValue,"<Pnum>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</Pnum>");
					
					tc_strcat(retValue,"<Prev>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</Prev>");
					
					tc_strcat(retValue,"<PDesc>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</PDesc>");
					
					tc_strcat(retValue,"<PDModDet>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</PDModDet>");
					
					tc_strcat(retValue,"<AddInd>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</AddInd>");
					
					tc_strcat(retValue,"<AmaInd>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</AmaInd>");
					
					tc_strcat(retValue,"<Epanum>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</Epanum>");
					
					tc_strcat(retValue,"<DmlDRStatus>");
					tc_strcat(retValue," ");
					tc_strcat(retValue,"</DmlDRStatus>");
					tc_strcat(retValue,"</rptrow1>");
					CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&tskobject_type));
					printf("\n\n\t\t object_type is :%s",tskobject_type);fflush(stdout);
					
					if(strcmp(tskobject_type,"T5_APLTaskRevision")==0)
					{
						int PartCnt=0;
						int k=0;
						tag_t*			PartTags			= NULLTAG;
						CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
						printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
						if (PartCnt>0)
						{
							tag_t			tsk_part_sol_rel_type= NULLTAG;
							tag_t			AssyTag				= NULLTAG;
							char*			Part_no				= NULL;
							char*			RevisionS				= NULL;
							char*			PartDRStat				= NULL;
							char*			prtdesc				= NULL;
							GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
							for (k=0;k<PartCnt ;k++ )
							{
								tc_strcat(retValue,"<rptrow1>");
								tc_strcat(retValue,"<SrNo>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</SrNo>");
								
								tc_strcat(retValue,"<DmlNum>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</DmlNum>");
								
								tc_strcat(retValue,"<DmlNumDes>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</DmlNumDes>");
								
								tc_strcat(retValue,"<ERCRlzDate>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</ERCRlzDate>");
								
								tc_strcat(retValue,"<APLRlzDate>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</APLRlzDate>");
								
								tc_strcat(retValue,"<StdRlzDate>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</StdRlzDate>");
								
								tc_strcat(retValue,"<TaskNum>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</TaskNum>");
				
					
								printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
								AssyTag=PartTags[k];

								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);
								
								tc_strcat(retValue,"<Pnum>");
								tc_strcat(retValue,Part_no);
								tc_strcat(retValue,"</Pnum>");
								
								CALLAPI(AOM_ask_value_string(AssyTag,"item_revision_id",&RevisionS));
								printf("\n  part rev  : %s \n",RevisionS); fflush(stdout);
								
								tc_strcat(retValue,"<Prev>");
								tc_strcat(retValue,RevisionS);
								tc_strcat(retValue,"</Prev>");
								
								CALLAPI(AOM_ask_value_string(AssyTag,"object_desc",&prtdesc));
								printf("\n  part desc  : %s \n",prtdesc); fflush(stdout);
								
								tc_strcat(retValue,"<PDesc>");
								tc_strcat(retValue,prtdesc);
								tc_strcat(retValue,"</PDesc>");
								
								tc_strcat(retValue,"<PDModDet>");
								tc_strcat(retValue,"Not Available");
								tc_strcat(retValue,"</PDModDet>");
							
								tc_strcat(retValue,"<AddInd>");
								tc_strcat(retValue,"Not Available");
								tc_strcat(retValue,"</AddInd>");
								
								tc_strcat(retValue,"<AmaInd>");
								tc_strcat(retValue,"Not Available");
								tc_strcat(retValue,"</AmaInd>");
								
								tc_strcat(retValue,"<Epanum>");
								tc_strcat(retValue,"Not Available");
								tc_strcat(retValue,"</Epanum>");
								
								tc_strcat(retValue,"<DmlDRStatus>");
								tc_strcat(retValue," ");
								tc_strcat(retValue,"</DmlDRStatus>");
								
								tc_strcat(retValue,"</rptrow1>");

							}
						}
						
						
					}
				}
			}
			
		}
		if (reportGen == 1)
		{
			tc_strcat(retValue,"</PlannerWiseAPlRpdData>");
		}
	}
			
	printf("\n value of reportGen :%d",reportGen);fflush(stdout);
	
	if (reportGen == 0)
	{
	
		tc_strcat(retValue,"<rptrow1>");
		tc_strcat(retValue,"<SrNo>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</SrNo>");
		
		tc_strcat(retValue,"<DmlNum>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</DmlNum>");
		
		tc_strcat(retValue,"<DmlNumDes>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</DmlNumDes>");
		
		tc_strcat(retValue,"<ERCRlzDate>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</ERCRlzDate>");
		
		tc_strcat(retValue,"<APLRlzDate>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</APLRlzDate>");
		
		tc_strcat(retValue,"<StdRlzDate>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</StdRlzDate>");
		
		tc_strcat(retValue,"<TaskNum>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</TaskNum>");
		
		tc_strcat(retValue,"<Pnum>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</Pnum>");
		
		tc_strcat(retValue,"<Prev>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</Prev>");
		
		tc_strcat(retValue,"<PDesc>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</PDesc>");
		
		tc_strcat(retValue,"<PDModDet>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</PDModDet>");

		tc_strcat(retValue,"<AddInd>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</AddInd>");
		
		tc_strcat(retValue,"<AmaInd>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</AmaInd>");
		
		tc_strcat(retValue,"<Epanum>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</Epanum>");
		
		tc_strcat(retValue,"<DmlDRStatus>");
		tc_strcat(retValue," ");
		tc_strcat(retValue,"</DmlDRStatus>");
		
		tc_strcat(retValue,"</rptrow1>");
		
		tc_strcat(retValue,"</PlannerWiseAPlRpdData>");
	}
					
	
	*((char **) return_data) = 	(char *) MEM_alloc( (strlen(retValue ) + 1) * sizeof(char));

	strcpy( *((char **) return_data), retValue); 

	return ifail;	
}

//Varun
int AplDmlReleaseBetweenDates( void *retValue )
//int AplDmlReleaseBetweenDates( void *retValue )
{
	
	int ifail = ITK_ok;
	logical found;
	char *dmlNumber	= NULL;
	char *Datefrom =NULL;
	char *Dateto =NULL;
	char *Agency=NULL;//Agency received from Front End(changed 07July 2018)......
	char *Plant=NULL;
	//char *PlantDup=NULL;
	char *Project_code=NULL;
	tag_t owner=NULLTAG;
	char *Owner_Name=NULL;
	tag_t dmlObject=NULLTAG;
	char* objectTypeStr = NULL;
	tag_t	query		= NULLTAG;
	tag_t	*t_item1	= NULLTAG;
	FILE * DmlRelFile=NULL;
	tag_t		filetag = NULLTAG;
	IMF_file_t	fileDescriptor;
	tag_t		datasettype = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	char ReportGeneration_str[26] = {'\0'};
	char PlantDup[10]={'\0'};
	int		n_found		= 0;
	int count=0;
	int buff_cnt=0;
	char** bufferedXmlStrOut;
	int Dmlcount=0;//Added on 22nd June 2018
	tag_t *DmlList = NULLTAG;
	const char*    find_Dml_Number=NULL;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	//char *DatefromDup1=NULL;
	//char *DatefromDup=NULL;
	//char *Return_String=NULL;
	//Return_String=(char *) MEM_alloc( 5000 * sizeof(char) );
	//char *tokenized_to_Date=NULL;
	
	/**Commenting for Test ***/
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Agency);
	USERARG_get_string_argument(&Plant);
	int projlen=0;
    char** Project_code_ids=NULL;	
	
	USERARG_get_string_array_argument(&projlen,&Project_code_ids);
	
		int k;
		for(k=0;k<projlen;k++)
		{
			
			printf("\n Project[%d]==[%s]",k+1,Project_code_ids[k]);
			
		}
	   // tc_strcpy(DatefromDup,""); 
		printf("Argument Received(AplDmlReleaseBetweenDates) =%s\n",Datefrom);fflush(stdout);
		//tc_strcpy(DatefromDup,"");
		
		//Function to be created based on agency APL,STD (Argument passed to Function FromDate,ToDate,ProjectId Length,Array of Project Codes)
		
		printf("Agency Received=%s\n",Agency);fflush(stdout);
		printf("Plant Received=%s\n",Plant);fflush(stdout);
		//Translating Plant Name Here.......
		if(tc_strcmp(Plant,"CVBU JSR")==0)
		{
			tc_strcpy(PlantDup,"");
			tc_strcpy(PlantDup,"*APLJ");
			printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
			
		}else if(tc_strcmp(Plant,"CVBU LKO")==0)
		{
			tc_strcpy(PlantDup,"");
			tc_strcpy(PlantDup,"*APLL");
			printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		}else if(tc_strcmp(Plant,"CVBU PUNE")==0)
		{
			tc_strcpy(PlantDup,"");
			tc_strcpy(PlantDup,"*APL");
			printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		}else if(tc_strcmp(Plant,"DHARWAD")==0)
		{
			tc_strcpy(PlantDup,"");
			tc_strcpy(PlantDup,"*APLD");
			printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		}else if(tc_strcmp(Plant,"CVBU PNR")==0)
		{
			tc_strcpy(PlantDup,"");
			tc_strcpy(PlantDup,"*APLU");
			printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		}
		
		if(tc_strcmp(Agency,"APL")==0)
		{
		    printf("Calling APL Function\n");fflush(stdout);	
			CALLAPI(APLDMLReleasedDates(Datefrom,Dateto,projlen,Project_code_ids,retValue, &bufferedXmlStrOut,&buff_cnt,PlantDup));
		}
		else if(tc_strcmp(Agency,"STD")==0)
		{
			printf("Calling STD Function\n");fflush(stdout);
			CALLAPI(STDDMLReleaseddates(Datefrom,Dateto,projlen,Project_code_ids,retValue, &bufferedXmlStrOut,&buff_cnt,PlantDup));
		}	
		
			int m =0;
			printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
			array_size = buff_cnt;
			string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
			for(m=0;m<buff_cnt;m++)
			{
				printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
				string_array[m] = bufferedXmlStrOut[m];
			}
			
				printf("\nBefore returning Value\n");fflush(stdout);
	
				ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

				//if (array_struct.length != 0)
				//*((USERSERVICE_array_t*) retValue) = array_struct;

             if (array_struct.length != 0)
				*((USERSERVICE_array_t*) retValue) = array_struct;				

			printf("After returning Value\n");fflush(stdout);
	
	////////
	
	
	return ifail;
	
	
}

int APLDMLReleasedDates(char* Datefrom,char*Dateto,int projlen,char**Project_code_ids,void *retValue,char*** bufferedXmlStrOut, int *buff_cnt,char *Plant)
		{
		
            int ifail = ITK_ok;		
			char *DatefromDup=NULL;
			char *DatetoDup=NULL;
			char *DatetoDup1=NULL;
			char *DayTo=NULL;
			char *MonthTo=NULL;
			char *YearTo=NULL;
			int Day=0;
			char *ModifiedDayTo=NULL;
			char *Datemodified=NULL;
			ModifiedDayTo=(char *)malloc(10 * sizeof(char));
			Datemodified=(char *)malloc(10 * sizeof(char));
			char *tokenized_from_Date=NULL;
			tokenized_from_Date=(char *) MEM_alloc( 10 * sizeof(char) );
			char *tokenized_to_Date=NULL;
			tokenized_to_Date=(char *) MEM_alloc( 10 * sizeof(char) );
			date_t         a_date_from;
			date_t         a_date_to;
			date_t   vals[2];
			time_t now;
			struct tm* now_tm;
			char ReportFiredDate[26] = {'\0'};
			const char *Plant_received[]={Plant};//Plant};
			//char **Plant_received=&Plant;
			const char * select_attrs[]={"puid"};
			
			
			char ReportFiredDatestr[26] = {'\0'};
			char *tokenized_from_Datestr=NULL;
			char *tokenized_to_Datestr=NULL;
			tokenized_from_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
			//tokenized_from_Datestr = (char *)malloc(10 * sizeof(char));
			tokenized_to_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
			char * Project_id,* Project_idstr = NULL;
			char **design_group,*design_groupstr=NULL;
			char * DRStatus,* DRStatusstr= NULL;
			char * dml_desc,* dml_descstr= NULL;
			char * requestor,* requestorstr= NULL;
			char *EcnType,*EcnTypestr=NULL;
			int	taskcount= 0;
			tag_t *taskList = NULLTAG;
			int	partcount = 0;
			tag_t *PartList = NULLTAG;
			char *revision_id_tokenized,*revision_id_tokenizedstr=NULL;
			
			
			char * dml_number,* dml_numberstr = NULL;
			char * dml_description,* dml_descriptionstr = NULL;
			dml_numberstr = (char *)malloc(100 * sizeof(char));
			char * released_date,* released_datestr= NULL;
			released_datestr = (char *)malloc(100 * sizeof(char));
			dml_descriptionstr = (char *)malloc(100 * sizeof(char));
			Project_idstr = (char *)malloc(100 * sizeof(char));
			dml_descstr = (char *)malloc(100 * sizeof(char));
			requestorstr = (char *)malloc(100 * sizeof(char));
			DRStatusstr = (char *)malloc(100 * sizeof(char));
			design_groupstr = (char *)malloc(100 * sizeof(char));
			revision_id_tokenizedstr = (char *)malloc(100 * sizeof(char));
			
			
			tc_strdup(Datefrom,&DatefromDup);
			printf("Copied Date obtained=%s\n",DatefromDup);fflush(stdout);
			tc_strdup(Dateto,&DatetoDup);
			tc_strdup(DatetoDup,&DatetoDup1);
			printf("Copied Date To obtained=%s\n",DatetoDup1);fflush(stdout);
			DayTo=tc_strtok(DatetoDup1,"-");
			MonthTo=tc_strtok(NULL,"-");
			YearTo=tc_strtok(NULL,"-");
			printf("Day[%s]month[%s]Year[%s]",DayTo,MonthTo,YearTo);fflush(stdout);
			Day=atoi(DayTo);
			Day=Day+1;
			printf("Incremented Date=%d\n",Day);
			sprintf(ModifiedDayTo,"%d",Day);
			
			tc_strcpy(Datemodified,"");
			tc_strcat(Datemodified,ModifiedDayTo);
			tc_strcat(Datemodified,"-");
			tc_strcat(Datemodified,MonthTo);
			tc_strcat(Datemodified,"-");
			tc_strcat(Datemodified,YearTo);
		
			printf("Modified Date To obtained=%s\n",Datemodified);fflush(stdout);
			
			tokenized_from_Date=tc_strtok(DatefromDup," ");
			tokenized_to_Date=tc_strtok(DatetoDup," ");
			printf("Tokenized Date From=%s\n",tokenized_from_Date);fflush(stdout);
			printf("Tokenized Date To=%s\n",tokenized_to_Date);fflush(stdout);
			printf("Plant recieved in Function=%s\n",Plant);fflush(stdout);
			 
			const char * argument_received_Datefrom[1];
			//argument_received_Datefrom[0]=Datefrom;
			argument_received_Datefrom[0]=Datefrom;

			const char * argument_received_Dateto[1];
			//argument_received_Dateto[0]=Dateto;
			  argument_received_Dateto[0]=Datemodified;
			  
			printf("Date Before converting to Date=%s\n",DatefromDup);
			ITK_string_to_date(Datefrom,&a_date_from);

			//ITK_string_to_date(Dateto,&a_date_to);
			ITK_string_to_date(Datemodified,&a_date_to);
		  
			vals[0]=a_date_from;
			vals[1]=a_date_to;
		  
			const char* prog_name ="AplDmlReleaseBetweenDates";
			printf("\nGet the argument....\n");fflush(stdout);
		
			printf("Argument Received(AplDmlReleaseBetweenDates) =%s\n",Datefrom);fflush(stdout);
			printf("Argument Received(AplDmlReleaseBetweenDates) =%s\n",Dateto);fflush(stdout);
			printf("\n Got the argument(AplDmlReleaseBetweenDates)....\n");fflush(stdout);
			printf("\n AplDmlReleaseBetweenDates user service call(AplDmlReleaseBetweenDates)....\n");fflush(stdout);
			
			time(&now);
			now_tm = localtime(&now);
			//strftime (ReportGeneration_str, 26, "%a_%b__%d_%H_%M_%S_%Y", now_tm);
			strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
			printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);
		
		
		
			/***Formatting a File***/
			
		   printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
		   
		  /** Creating a POM Query **/
		  CALLAPI(POM_enquiry_create("find_Dml_Number"));
		  
		  printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
		  
		  /** Adding select attribute to Query **/
		  
		  CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));
		  
		  printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
		  
		   /**Setting Released Date **/
		   CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
		   
		   /** creating between Expression **/
		   
		   CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","date_released",POM_enquiry_between,"expr_dates"));
		   
		  
		  printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
		  
			/**Adding Bind Variables to the Query.....**/
			
			/**Need to Check if Plant received if Plant is Null then go for Project Codes**/
		if(tc_strcmp(Plant,"")==0)
		{
			printf("Entered into Plant Section\n");fflush(stdout);
			CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
			CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
			printf("exited from Plant Section\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
		}
       else
		{
			printf("Entered into Else Section\n");fflush(stdout);
			//Need to use join Expression between t5DMLRevision class and ItemRevision Class........
			CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));
			printf("Check 1\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));
			printf("Check 1_1\n");fflush(stdout);
			
			
			
			CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));
			
			//CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "attr_expr1","T5_APLDML", "item_id", POM_enquiry_equal,"Plant_expr"));
			
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));
			
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));
			
			printf("Check 1_2\n");fflush(stdout);
			
			POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );
			
			printf("Check 2\n");fflush(stdout);
			
		}					  
		  
			printf("******Check After POM_enquiry_set_attr_expr*********\n");fflush(stdout);
		  
		  /**Setting the Where Expression **/
		  
		  printf("******Before Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);
		  
		  
		  
		  printf("******After  Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);
	  
		  /** Executing the Query ***/
		  
			int  rows = 0, columns = 0;
			void ***report;
			char item_id_val_copy[5]={'\0'};
			char *item_id_tokenized=NULL;
			char * item_idval,*item_idvalstr=NULL;
			char *Date_released,*Date_releasedstr=NULL;
			char *lifecycle_state,*lifecycle_statestr=NULL;
			char *Reason,*Reasonstr=NULL;
			tag_t objtag =NULLTAG;
			int ii;
			char *dml_number_erc,*dml_number_ercstr=NULL;
			char *erc_released_date,*erc_released_datestr=NULL;
			char *designer_erc,*designer_ercstr=NULL;
			char *partnumber,*partnumberstr=NULL;
			char *revision_id,*revision_idstr =NULL;
			char *reviewer,*reviewerstr=NULL;
			char revision_id_cpy[2]={'\0'};
			char *revision_id_cpystr[2]={'\0'};
			char *PartDescription,*PartDescriptionstr=NULL;
			int sequence;
			char *serial_num,*serial_numstr =NULL;
			char *sequence_number,*sequence_numberstr =NULL;
			item_idvalstr = (char *)malloc(100 * sizeof(char));
			Date_releasedstr = (char *)malloc(100 * sizeof(char));
			lifecycle_statestr = malloc(100 * sizeof(char));
			Reasonstr = (char *)malloc(100 * sizeof(char));
			partnumberstr = (char *)malloc(100 * sizeof(char));
			revision_idstr = (char *)malloc(100 * sizeof(char));
			serial_numstr = (char *)malloc(100 * sizeof(char));
			sequence_numberstr = (char *)malloc(100 * sizeof(char));
			PartDescriptionstr =(char *) malloc(100 * sizeof(char));
			erc_released_datestr=(char *)malloc(100 * sizeof(char));
			designer_ercstr=(char *)malloc(100 * sizeof(char));
			reviewerstr=(char *)malloc(100 * sizeof(char));
			serial_num = (char *) MEM_alloc( 10 * sizeof(char) );
			
			
			printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));
			
			printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_delete("find_Dml_Number"));
			printf("Check 1\n");fflush(stdout);
			//setAddStr(&buff_cnt,&bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
			printf("Check 2\n");fflush(stdout);
			setAddStr(buff_cnt,bufferedXmlStrOut,"<APLDMLBetweenDateReport>");
			sprintf(ReportFiredDatestr,"<ReportFiredDate>%s</ReportFiredDate>",ReportFiredDate);
			setAddStr(buff_cnt,bufferedXmlStrOut,ReportFiredDatestr);
			printf("Check 3\n");fflush(stdout);
			sprintf(tokenized_from_Datestr,"<fromDate>%s</fromDate>",tokenized_from_Date);
			setAddStr(buff_cnt,bufferedXmlStrOut,tokenized_from_Datestr);
					
			sprintf(tokenized_to_Datestr,"<ToDate>%s</ToDate>",tokenized_to_Date);
			setAddStr(buff_cnt,bufferedXmlStrOut,tokenized_to_Datestr);
			
		
		
			if (rows != 0)
			{

				for (ii = 0; ii < rows; ii++ )
				{
					 tag_t	query		= NULLTAG;
					 int	n_found		= 0;
					 tag_t	*t_item1	= NULLTAG;
					 int num;
					
					 objtag  = *(tag_t*)(report[ii][0]);
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
					
					CALLAPI(AOM_UIF_ask_value(objtag,"release_status_list",&lifecycle_state);fflush(stdout));
					printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
					if(tc_strstr(lifecycle_state,"APL Released")!=NULL)
					{
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>","APL Released");
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						
					}
					 else
					 {
						 setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
						 break;
					 }
					
					sprintf(serial_num,"<SrNo>%d</SrNo>",(ii+1));
					setAddStr(buff_cnt,bufferedXmlStrOut,serial_num);
					
					 CALLAPI(AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id));
					//AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id);
					
					printf("\n--->>>>> project_ids_val>>==%s\n",Project_id);fflush(stdout);
					sprintf(Project_idstr,"<Project_Code>%s</Project_Code>",Project_id);
					setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
					
					//CALLAPI(AOM_ask_value_string(objtag,"t5_crdesigngroup",&design_group));
					
						  printf("\nCheck 4\n");fflush(stdout);
				   CALLAPI(AOM_ask_value_strings(objtag,"t5_crdesigngroup",&num,&design_group));
				   printf("\nCheck 5\n");fflush(stdout);
					
					//AOM_ask_value_string(objtag,"t5_crdesigngroup",&design_group);
					if(num>0)
					{
						printf("\n--->>>>> DesignGroup_val>>==%s\n",design_group[0]);fflush(stdout);
					   sprintf(design_groupstr,"<Design_Group>%s</Design_Group>",design_group[0]);
					
					}
					else
						sprintf(design_groupstr,"<Design_Group>NA</Design_Group>");
					
					   setAddStr(buff_cnt,bufferedXmlStrOut,design_groupstr);
					
					CALLAPI(AOM_ask_value_string(objtag,"item_id",&item_idval));
					
					printf("\n--->>>>> item_idval>>==%s\n",item_idval);fflush(stdout);
					sprintf(item_idvalstr,"<DML_Number>%s</DML_Number>",item_idval);
					setAddStr(buff_cnt,bufferedXmlStrOut,item_idvalstr);
					
					tc_strcpy(item_id_val_copy,item_idval);
					
					/*Finding ERC DML from APL DML**/
					item_id_tokenized=strtok(item_id_val_copy,"_");
					printf("Tokenized DML Number Obtained=%s\n",item_id_tokenized);
					
					//Need to use Query Builder to get ERC DML and then Release Date from there.....
					char *qry_entries3[] = {"ID"};
					char *qry_values3[] = {item_id_tokenized};
					qry_values3[0]=item_id_tokenized;
					
					CALLAPI(QRY_find("ERC DML", &query));
					CALLAPI(QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1));
					if(n_found!=0)
					{
						
						printf("Found an ERC DML\n");fflush(stdout);
						CALLAPI(AOM_ask_value_string(t_item1[0] ,"item_id", &dml_number_erc));//Getting DML Number.......
						
						printf("ERC DML Found=%s\n",dml_number_erc);fflush(stdout);
						
						CALLAPI(AOM_UIF_ask_value(t_item1[0],"date_released",&erc_released_date));
						//AOM_ask_value_string(t_item1[0],"date_released",&erc_released_date);
						printf("ERC Released Date found=%s\n",erc_released_date);fflush(stdout);
						
						sprintf(erc_released_datestr,"<ERC_Released_Date>%s</ERC_Released_Date>",erc_released_date);
						setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
						printf("ERC Released Date obtained=%s\n",erc_released_datestr);fflush(stdout);
					
						CALLAPI(AOM_ask_value_string(t_item1[0] ,"requestor_user_id", &designer_erc));
						
						printf("Designer Obtined=%s\n",designer_erc);
						sprintf(designer_ercstr,"<Designer>%s</Designer>",designer_erc);
						setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
					}
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_cDRstatus", &DRStatus));
					printf("\n--->>>>> DRStatus_val>>==%s\n",DRStatus);fflush(stdout);
					sprintf(DRStatusstr,"<DR_Status>%s</DR_Status>",DRStatus);
					setAddStr(buff_cnt,bufferedXmlStrOut,DRStatusstr);
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<DCR_Status>NA</DCR_Status>");
					
					CALLAPI(AOM_ask_value_string(objtag,"object_desc", &dml_desc));
					printf("\n--->>>>> object_desc_val>>==%s\n",dml_desc);fflush(stdout);
					sprintf(dml_descstr,"<DML_Description>%s</DML_Description>",dml_desc);
					setAddStr(buff_cnt,bufferedXmlStrOut,dml_descstr);
					
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_reason",&Reason));
					printf("\n--->>>>> Reason_val>>==%s\n",Reason);fflush(stdout);
					sprintf(Reasonstr,"<Reason_Description>%s</Reason_Description>",Reason);
					setAddStr(buff_cnt,bufferedXmlStrOut,Reasonstr);
					
					
					CALLAPI(AOM_ask_value_string(objtag,"requestor_user_id", &requestor));
					printf("\n--->>>>> requestor_val>>==%s\n",requestor);fflush(stdout);
					sprintf(requestorstr,"<APL_Planner>%s</APL_Planner>",requestor);
					setAddStr(buff_cnt,bufferedXmlStrOut,requestorstr);
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_EcnType",&EcnType));
					printf("\n--->>>>> EcnType_val>>==%s\n",EcnType);fflush(stdout);
					
					
					/* CALLAPI(AOM_UIF_ask_value(objtag,"date_released",&Date_released);fflush(stdout));
					printf("\n--->>>>> DateReleased_val>>==%s\n",Date_released);fflush(stdout);
					sprintf(Date_releasedstr,"<APL_released_Date>%s</APL_released_Date>",Date_released);
					setAddStr(buff_cnt,bufferedXmlStrOut,Date_releasedstr); */
					
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<STD_PLanner>NA</STD_PLanner>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<STD_Release_Date>NA</STD_Release_Date>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number>NA</EPA_Number>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status>NA</EPA_Status>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date>NA</EPA_finalized_Date>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Remarks>NA</Remarks>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<MBPA_Number>NA</MBPA_Number>");
					
					
					CALLAPI(AOM_ask_value_tags(objtag,"T5_DMLTaskRelation",&taskcount,&taskList));
					printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
					
					
					if(taskcount>0)
					{
						int i;
						for(i=0;i<taskcount;i++)
						{
							tag_t task=taskList[i];
							
							int  count_release_status =0; 
							tag_t *release_status_object=NULLTAG;
							char  name[WSO_name_size_c+1]    = {'\0'};
							printf("\nBefore Release Status Count\n");fflush(stdout);
							CALLAPI(WSOM_ask_release_status_list(task,&count_release_status,&release_status_object));
							printf("After Release Status Count\n");fflush(stdout);
							printf("Release Status Count Obtained=%d\n",count_release_status);fflush(stdout);
							if(count_release_status>0)
							{
								int k;
								for(k=0;k<count_release_status;k++)
								{
									char* date_rel=NULL;
									char* date_relstr=NULL;
									date_relstr=(char*)malloc(100*sizeof(char));
									tag_t release_status = release_status_object[k];
									CALLAPI(CR_ask_release_status_type(release_status,name));
									printf("Release Status Name obtained=%s\n",name);fflush(stdout);
									if(tc_strcmp(name,"T5_LcsAplRlzd")==0)
									{
										CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
										printf("APL Released Date=%s\n",date_rel);fflush(stdout);
										sprintf(date_relstr,"<APL_released_Date>%s</APL_released_Date>",date_rel);
										setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
										
									}
										if(date_relstr!=NULL)free(date_relstr);
								}
								
							}
							
							CALLAPI(AOM_ask_value_string(taskList[i] ,"change_specialist1_user_id",&reviewer));
							sprintf(reviewerstr,"<Reviewer>%s</Reviewer>",reviewer);
							setAddStr(buff_cnt,bufferedXmlStrOut,reviewerstr);
							
							sequence_number= (char *) MEM_alloc( 10 * sizeof(char) );
							
							CALLAPI(AOM_ask_value_tags(task,"CMHasSolutionItem",&partcount,&PartList));
							printf("\n No of Parts found in the Task ====>[%d]\n", partcount);fflush(stdout);
							if(partcount>0)
							{
								int k;
								for(k=0;k<partcount;k++)
								{
									CALLAPI(AOM_ask_value_string(PartList[k] ,"item_id",&partnumber));
									printf("Part Number Found for Part =%s\n",partnumber);fflush(stdout);
									sprintf(partnumberstr,"<Part_Number>%s</Part_Number>",partnumber);
									setAddStr(buff_cnt,bufferedXmlStrOut,partnumberstr);
									
									CALLAPI(AOM_ask_value_string(PartList[k] ,"item_revision_id",&revision_id));
									printf("Revision Found for Part =%s\n",revision_id);fflush(stdout);
									
									tc_strcpy(revision_id_cpy,revision_id);
									revision_id_tokenized=strtok(revision_id_cpy,";");
									printf("Tokenized Revision Id=%s\n",revision_id_tokenized);fflush(stdout);
									sprintf(revision_id_tokenizedstr,"<Revision>%s</Revision>",revision_id_tokenized);
									setAddStr(buff_cnt,bufferedXmlStrOut,revision_id_tokenizedstr);
									
									CALLAPI(AOM_ask_value_int(PartList[k],"sequence_id",&sequence));
									printf("Sequence Found for Part  =%d\n",sequence);fflush(stdout);
									sprintf(sequence_numberstr,"<Sequence>%d</Sequence>",sequence);
									setAddStr(buff_cnt,bufferedXmlStrOut,sequence_numberstr);
									
									CALLAPI(AOM_ask_value_string(PartList[k],"t5_DocRemarks",&PartDescription));
									printf("Description Found for Part  =%s\n",PartDescription);fflush(stdout);
									sprintf(PartDescriptionstr,"<Part_Description>%s</Part_Description>",PartDescription);
									setAddStr(buff_cnt,bufferedXmlStrOut,PartDescriptionstr);
									
									
								}

							}
								 
								 
						}
					}
									setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
									
				}
				  
			}
		      
		      setAddStr(buff_cnt,bufferedXmlStrOut,"</APLDMLBetweenDateReport>");
			  
				
		
			printf("Outside For Loop\n");fflush(stdout);
		
			//Need to find out Lifecycle State and Released Date of DML..........
		
			
	
			/* *((char **) retValue) = 
			(char *) MEM_alloc( (strlen(Return_String ) + 1) * sizeof(char));  //Commented on 21St June 2018

			strcpy( *((char **) retValue), Return_String); */

			/* *((char **) Return_String) = 
			(char *) MEM_alloc( (strlen(retValue ) + 1) * sizeof(char));

			strcpy( *((char **) Return_String), retValue); */	
	
			/////////////
			
			
	printf("Start After Freeing ALL\n");fflush(stdout); 
	if(ModifiedDayTo!=NULL) free(ModifiedDayTo);
	if(Datemodified!=NULL)free(Datemodified);
	if(item_idvalstr!=NULL)free(item_idvalstr);
	printf("\nStart After Freeing ALL1\n");fflush(stdout); 
	if(Date_releasedstr!=NULL)free(Date_releasedstr);
	printf("Start After Freeing ALL2\n");fflush(stdout); 
	if(lifecycle_statestr!=NULL)free(lifecycle_statestr);
	printf("Start After Freeing ALL3\n");fflush(stdout);
	if(Reasonstr!=NULL)free(Reasonstr);
	printf("Start After Freeing ALL4\n");fflush(stdout);
	if(partnumberstr!=NULL)free(partnumberstr); 
	printf("Start After Freeing ALL5\n");fflush(stdout);
	if(revision_idstr!=NULL)free(revision_idstr); 
	printf("Start After Freeing ALL6\n");fflush(stdout);
	if(serial_numstr!=NULL)free(serial_numstr); 
	printf("Between After Freeing ALL");fflush(stdout); 
	if(sequence_numberstr!=NULL)free(sequence_numberstr); 
	if(PartDescriptionstr!=NULL)free(PartDescriptionstr);
	printf("Middle  After Freeing ALL\n");fflush(stdout); 
	
	if(erc_released_datestr!=NULL)free(erc_released_datestr);
	if(designer_ercstr!=NULL)free(designer_ercstr);
	if(reviewerstr!=NULL)free(reviewerstr);
	//MEM_free(serial_num);
	//if(serial_num!=NULL)free(serial_num);
	printf("1 After Freeing ALL\n");fflush(stdout); 

	printf("2 After Freeing ALL\n");fflush(stdout); 
	if(Project_idstr!=NULL)free(Project_idstr);
	if(dml_numberstr!=NULL)free(dml_numberstr);
	if(dml_descstr!=NULL)free(dml_descstr); 
	if(requestorstr!=NULL)free(requestorstr); 
	if(DRStatusstr!=NULL)free(DRStatusstr); 
	if(released_datestr!=NULL)free(released_datestr); 
	if(design_groupstr!=NULL)free(design_groupstr); 
	if(dml_descriptionstr!=NULL)free(dml_descriptionstr); 
	printf("3 After Freeing ALL\n");fflush(stdout); 
	if(revision_id_tokenizedstr!=NULL)free(revision_id_tokenizedstr);
	printf("4 After Freeing ALL\n");fflush(stdout); 
			
			return ifail;

}
		
int STDDMLReleaseddates(char* Datefrom,char*Dateto,int projlen,char**Project_code_ids,void *retValue,char*** bufferedXmlStrOut, int *buff_cnt,char* Plant)
{
		
            int ifail = ITK_ok;		
			char *DatefromDup=NULL;
			char *DatetoDup=NULL;
			char *DatetoDup1=NULL;
			char *DayTo=NULL;
			char *MonthTo=NULL;
			char *YearTo=NULL;
			int Day=0;
			char *ModifiedDayTo=NULL;
			char *Datemodified=NULL;
			ModifiedDayTo=(char *)malloc(10 * sizeof(char));
			Datemodified=(char *)malloc(10 * sizeof(char));
			char *tokenized_from_Date=NULL;
			tokenized_from_Date=(char *) MEM_alloc( 10 * sizeof(char) );
			char *tokenized_to_Date=NULL;
			tokenized_to_Date=(char *) MEM_alloc( 10 * sizeof(char) );
			date_t         a_date_from;
			date_t         a_date_to;
			date_t   vals[2];
			time_t now;
			struct tm* now_tm;
			char ReportFiredDate[26] = {'\0'};
			//char **Plant_received=&Plant;
			const char *Plant_received[]={Plant};
			const char * select_attrs[]={"puid"};
			
			
			char ReportFiredDatestr[26] = {'\0'};
			char *tokenized_from_Datestr=NULL;
			char *tokenized_to_Datestr=NULL;
			tokenized_from_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
			//tokenized_from_Datestr = (char *)malloc(10 * sizeof(char));
			tokenized_to_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
			char * Project_id,* Project_idstr = NULL;
			char **design_group,*design_groupstr=NULL;
			char * DRStatus,* DRStatusstr= NULL;
			char * dml_desc,* dml_descstr= NULL;
			char * requestor,* requestorstr= NULL;
			char *EcnType,*EcnTypestr=NULL;
			int	taskcount= 0;
			tag_t *taskList = NULLTAG;
			int	partcount = 0;
			tag_t *PartList = NULLTAG;
			char *revision_id_tokenized,*revision_id_tokenizedstr=NULL;
			
			
			char * dml_number,* dml_numberstr = NULL;
			char * dml_description,* dml_descriptionstr = NULL;
			dml_numberstr = (char *)malloc(100 * sizeof(char));
			char * released_date,* released_datestr= NULL;
			released_datestr = (char *)malloc(100 * sizeof(char));
			dml_descriptionstr = (char *)malloc(100 * sizeof(char));
			Project_idstr = (char *)malloc(100 * sizeof(char));
			dml_descstr = (char *)malloc(100 * sizeof(char));
			requestorstr = (char *)malloc(100 * sizeof(char));
			DRStatusstr = (char *)malloc(100 * sizeof(char));
			design_groupstr = (char *)malloc(100 * sizeof(char));
			revision_id_tokenizedstr = (char *)malloc(100 * sizeof(char));
			
			
			tc_strdup(Datefrom,&DatefromDup);
			printf("Copied Date obtained=%s\n",DatefromDup);fflush(stdout);
			tc_strdup(Dateto,&DatetoDup);
			tc_strdup(DatetoDup,&DatetoDup1);
			printf("Copied Date To obtained=%s\n",DatetoDup1);fflush(stdout);
			DayTo=tc_strtok(DatetoDup1,"-");
			MonthTo=tc_strtok(NULL,"-");
			YearTo=tc_strtok(NULL,"-");
			printf("Day[%s]month[%s]Year[%s]",DayTo,MonthTo,YearTo);fflush(stdout);
			Day=atoi(DayTo);
			Day=Day+1;
			printf("Incremented Date=%d\n",Day);
			sprintf(ModifiedDayTo,"%d",Day);
			
			tc_strcpy(Datemodified,"");
			tc_strcat(Datemodified,ModifiedDayTo);
			tc_strcat(Datemodified,"-");
			tc_strcat(Datemodified,MonthTo);
			tc_strcat(Datemodified,"-");
			tc_strcat(Datemodified,YearTo);
		
			printf("Modified Date To obtained=%s\n",Datemodified);fflush(stdout);
			
			tokenized_from_Date=tc_strtok(DatefromDup," ");
			tokenized_to_Date=tc_strtok(DatetoDup," ");
			printf("Tokenized Date From=%s\n",tokenized_from_Date);fflush(stdout);
			printf("Tokenized Date To=%s\n",tokenized_to_Date);fflush(stdout);
			 
			const char * argument_received_Datefrom[1];
			//argument_received_Datefrom[0]=Datefrom;
			argument_received_Datefrom[0]=Datefrom;

			const char * argument_received_Dateto[1];
			//argument_received_Dateto[0]=Dateto;
			  argument_received_Dateto[0]=Datemodified;
			  
			printf("Date Before converting to Date=%s\n",DatefromDup);
			ITK_string_to_date(Datefrom,&a_date_from);

			//ITK_string_to_date(Dateto,&a_date_to);
			ITK_string_to_date(Datemodified,&a_date_to);
		  
			vals[0]=a_date_from;
			vals[1]=a_date_to;
		  
			const char* prog_name ="AplDmlReleaseBetweenDates";
			printf("\nGet the argument....\n");fflush(stdout);
		
			printf("Argument Received(STDDmlReleaseBetweenDates) =%s\n",Datefrom);fflush(stdout);
			printf("Argument Received(STDDmlReleaseBetweenDates) =%s\n",Dateto);fflush(stdout);
			printf("\n Got the argument(STDDmlReleaseBetweenDates)....\n");fflush(stdout);
			printf("\n STDDmlReleaseBetweenDates user service call(STDDmlReleaseBetweenDates)....\n");fflush(stdout);
			
			time(&now);
			now_tm = localtime(&now);
			//strftime (ReportGeneration_str, 26, "%a_%b__%d_%H_%M_%S_%Y", now_tm);
			strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
			printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);
		
		
		
			/***Formatting a File***/
			
		   printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
		   
		  /** Creating a POM Query **/
		  CALLAPI(POM_enquiry_create("find_Dml_Number"));
		  
		  printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
		  
		  /** Adding select attribute to Query **/
		  
		  CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));
		  
		  printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
		  
		  /**Adding Bind Variables to the Query.....**/
		  
		   //CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		   
		   /**Setting Released Date **/
		   CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
		   
		   /** creating between Expression **/
		   
		   CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","date_released",POM_enquiry_between,"expr_dates"));
		   
		  
		  printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
					
			
		if(tc_strcmp(Plant,"")==0)
		{
			printf("Entered into Plant Section\n");fflush(stdout);
			CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
			CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
			printf("exited from Plant Section\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
		}
       else
		{
			printf("Entered into Else Section\n");fflush(stdout);
			//Need to use join Expression between t5DMLRevision class and ItemRevision Class........
			CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));
			printf("Check 1\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));
			printf("Check 1_1\n");fflush(stdout);
			
			
			
			CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));
			
			//CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "attr_expr1","T5_APLDML", "item_id", POM_enquiry_equal,"Plant_expr"));
			
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));
			
			CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));
			
			printf("Check 1_2\n");fflush(stdout);
			
			POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );
			
			printf("Check 2\n");fflush(stdout);
			
		}
              
			  /**Implemented on 14 July 2018 **/
              //CALLAPI(POM_enquiry_set_expr ( "find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"expr_lifecyclestate_in"));			  
		  
			printf("******Check After POM_enquiry_set_attr_expr*********\n");fflush(stdout);
		  
		  /**Setting the Where Expression **/
		  
		  printf("******Before Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);
		  
		  //CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
		  
		  printf("******After  Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);
	  
		  /** Executing the Query ***/
		  
			int  rows = 0, columns = 0;
			void ***report;
			char item_id_val_copy[5]={'\0'};
			char *item_id_tokenized=NULL;
			char * item_idval,*item_idvalstr=NULL;
			char *Date_released,*Date_releasedstr=NULL;
			char *lifecycle_state,*lifecycle_statestr=NULL;
			char *Reason,*Reasonstr=NULL;
			tag_t objtag =NULLTAG;
			int ii;
			char *dml_number_erc,*dml_number_ercstr=NULL;
			char *erc_released_date,*erc_released_datestr=NULL;
			char *designer_erc,*designer_ercstr=NULL;
			char *partnumber,*partnumberstr=NULL;
			char *revision_id,*revision_idstr =NULL;
			char *reviewer,*reviewerstr=NULL;
			char revision_id_cpy[2]={'\0'};
			char *revision_id_cpystr[2]={'\0'};
			char *PartDescription,*PartDescriptionstr=NULL;
			int sequence;
			char *serial_num,*serial_numstr =NULL;
			char *sequence_number,*sequence_numberstr =NULL;
			item_idvalstr = (char *)malloc(100 * sizeof(char));
			Date_releasedstr = (char *)malloc(100 * sizeof(char));
			lifecycle_statestr = malloc(100 * sizeof(char));
			Reasonstr = (char *)malloc(100 * sizeof(char));
			partnumberstr = (char *)malloc(100 * sizeof(char));
			revision_idstr = (char *)malloc(100 * sizeof(char));
			serial_numstr = (char *)malloc(100 * sizeof(char));
			sequence_numberstr = (char *)malloc(100 * sizeof(char));
			PartDescriptionstr =(char *) malloc(100 * sizeof(char));
			erc_released_datestr=(char *)malloc(100 * sizeof(char));
			designer_ercstr=(char *)malloc(100 * sizeof(char));
			reviewerstr=(char *)malloc(100 * sizeof(char));
			serial_num = (char *) MEM_alloc( 10 * sizeof(char) );
			
			
			printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));
			
			printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
			
			CALLAPI(POM_enquiry_delete("find_Dml_Number"));
			printf("Check 1\n");fflush(stdout);
			//setAddStr(&buff_cnt,&bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
			printf("Check 2\n");fflush(stdout);
			setAddStr(buff_cnt,bufferedXmlStrOut,"<APLDMLBetweenDateReport>");
			sprintf(ReportFiredDatestr,"<ReportFiredDate>%s</ReportFiredDate>",ReportFiredDate);
			setAddStr(buff_cnt,bufferedXmlStrOut,ReportFiredDatestr);
			printf("Check 3\n");fflush(stdout);
			sprintf(tokenized_from_Datestr,"<fromDate>%s</fromDate>",tokenized_from_Date);
			setAddStr(buff_cnt,bufferedXmlStrOut,tokenized_from_Datestr);
					
			sprintf(tokenized_to_Datestr,"<ToDate>%s</ToDate>",tokenized_to_Date);
			setAddStr(buff_cnt,bufferedXmlStrOut,tokenized_to_Datestr);
			
		
		
			if (rows != 0)
			{

				for (ii = 0; ii < rows; ii++ )
				{
					 tag_t	query		= NULLTAG;
					 int	n_found		= 0;
					 tag_t	*t_item1	= NULLTAG;
					 int num;
					 int taskcount = 0;
					 tag_t	*taskList = NULLTAG;
					
					 objtag  = *(tag_t*)(report[ii][0]);
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
					
					/**Check if STD Released Data is there then proceed Ahead **/
					
					CALLAPI(AOM_UIF_ask_value(objtag,"release_status_list",&lifecycle_state);fflush(stdout));
					printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
					if(tc_strstr(lifecycle_state,"STDSI Released")!=NULL)
					{
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>","STDSI Released");
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						
					}
					else
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
						break;
						
					}
					
					sprintf(serial_num,"<SrNo>%d</SrNo>",(ii+1));
					setAddStr(buff_cnt,bufferedXmlStrOut,serial_num);
					
					 CALLAPI(AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id));
					//AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id);
					
					printf("\n--->>>>> project_ids_val>>==%s\n",Project_id);fflush(stdout);
					sprintf(Project_idstr,"<Project_Code>%s</Project_Code>",Project_id);
					setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
					
					//CALLAPI(AOM_ask_value_string(objtag,"t5_crdesigngroup",&design_group));
					
						  printf("\nCheck 4\n");fflush(stdout);
				   CALLAPI(AOM_ask_value_strings(objtag,"t5_crdesigngroup",&num,&design_group));
				   printf("\nCheck 5\n");fflush(stdout);
					
					//AOM_ask_value_string(objtag,"t5_crdesigngroup",&design_group);
					if(num>0)
					{
						printf("\n--->>>>> DesignGroup_val>>==%s\n",design_group[0]);fflush(stdout);
					   sprintf(design_groupstr,"<Design_Group>%s</Design_Group>",design_group[0]);
					
					}
					else
						sprintf(design_groupstr,"<Design_Group>NA</Design_Group>");
					
					   setAddStr(buff_cnt,bufferedXmlStrOut,design_groupstr);
					
					CALLAPI(AOM_ask_value_string(objtag,"item_id",&item_idval));
					
					printf("\n--->>>>> item_idval>>==%s\n",item_idval);fflush(stdout);
					sprintf(item_idvalstr,"<DML_Number>%s</DML_Number>",item_idval);
					setAddStr(buff_cnt,bufferedXmlStrOut,item_idvalstr);
					
					tc_strcpy(item_id_val_copy,item_idval);
					
					/*Finding ERC DML from APL DML**/
					item_id_tokenized=strtok(item_id_val_copy,"_");
					printf("Tokenized DML Number Obtained=%s\n",item_id_tokenized);
					
					//Need to use Query Builder to get ERC DML and then Release Date from there.....
					char *qry_entries3[] = {"ID"};
					char *qry_values3[] = {item_id_tokenized};
					qry_values3[0]=item_id_tokenized;
					
					CALLAPI(QRY_find("ERC DML", &query));
					CALLAPI(QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1));
					if(n_found!=0)
					{
						
						printf("Found an ERC DML\n");fflush(stdout);
						CALLAPI(AOM_ask_value_string(t_item1[0] ,"item_id", &dml_number_erc));//Getting DML Number.......
						
						printf("ERC DML Found=%s\n",dml_number_erc);fflush(stdout);
						
						CALLAPI(AOM_UIF_ask_value(t_item1[0],"date_released",&erc_released_date));
						//AOM_ask_value_string(t_item1[0],"date_released",&erc_released_date);
						printf("ERC Released Date found=%s\n",erc_released_date);fflush(stdout);
						
						sprintf(erc_released_datestr,"<ERC_Released_Date>%s</ERC_Released_Date>",erc_released_date);
						setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
						printf("ERC Released Date obtained=%s\n",erc_released_datestr);fflush(stdout);
					
						CALLAPI(AOM_ask_value_string(t_item1[0] ,"requestor_user_id", &designer_erc));
						
						printf("Designer Obtined=%s\n",designer_erc);
						sprintf(designer_ercstr,"<Designer>%s</Designer>",designer_erc);
						setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
					}
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_cDRstatus", &DRStatus));
					printf("\n--->>>>> DRStatus_val>>==%s\n",DRStatus);fflush(stdout);
					sprintf(DRStatusstr,"<DR_Status>%s</DR_Status>",DRStatus);
					setAddStr(buff_cnt,bufferedXmlStrOut,DRStatusstr);
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<DCR_Status>NA</DCR_Status>");
					
					CALLAPI(AOM_ask_value_string(objtag,"object_desc", &dml_desc));
					printf("\n--->>>>> object_desc_val>>==%s\n",dml_desc);fflush(stdout);
					sprintf(dml_descstr,"<DML_Description>%s</DML_Description>",dml_desc);
					setAddStr(buff_cnt,bufferedXmlStrOut,dml_descstr);
					
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_reason",&Reason));
					printf("\n--->>>>> Reason_val>>==%s\n",Reason);fflush(stdout);
					sprintf(Reasonstr,"<Reason_Description>%s</Reason_Description>",Reason);
					setAddStr(buff_cnt,bufferedXmlStrOut,Reasonstr);
					
					
					CALLAPI(AOM_ask_value_string(objtag,"requestor_user_id", &requestor));
					printf("\n--->>>>> requestor_val>>==%s\n",requestor);fflush(stdout);
					sprintf(requestorstr,"<APL_Planner>%s</APL_Planner>",requestor);
					setAddStr(buff_cnt,bufferedXmlStrOut,requestorstr);
					
					CALLAPI(AOM_ask_value_string(objtag,"t5_EcnType",&EcnType));
					printf("\n--->>>>> EcnType_val>>==%s\n",EcnType);fflush(stdout);
					
					CALLAPI(AOM_ask_value_tags(objtag,"T5_DMLTaskRelation",&taskcount,&taskList));
					printf("\n No of Task Found ====>[%d]", taskcount);fflush(stdout);
					
					CALLAPI(AOM_UIF_ask_value(objtag,"date_released",&Date_released);fflush(stdout));//Need to check for object ask_release_status_list
					printf("\n--->>>>> DateReleased_val>>==%s\n",Date_released);fflush(stdout);
					
					sprintf(Date_releasedstr,"<APL_released_Date>%s</APL_released_Date>","NA");//modified on 18 July 2018
					setAddStr(buff_cnt,bufferedXmlStrOut,Date_releasedstr);
					
					/* CALLAPI(AOM_UIF_ask_value(objtag,"release_status_list",&lifecycle_state);fflush(stdout));
					printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
					if(tc_strstr(lifecycle_state,"APL Released")!=NULL)
					{
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						
					} */	
					setAddStr(buff_cnt,bufferedXmlStrOut,"<STD_PLanner>NA</STD_PLanner>");
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number>NA</EPA_Number>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status>NA</EPA_Status>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date>NA</EPA_finalized_Date>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Remarks>NA</Remarks>");
					setAddStr(buff_cnt,bufferedXmlStrOut,"<MBPA_Number>NA</MBPA_Number>");
					
					
					CALLAPI(AOM_ask_value_tags(objtag,"T5_DMLTaskRelation",&taskcount,&taskList));
					printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
					
					
					if(taskcount>0)
					{
						int i;
						for(i=0;i<taskcount;i++)
						{
							tag_t task=taskList[i];
							int  count_release_status =0; 
							tag_t *release_status_object=NULLTAG;
							char  name[WSO_name_size_c+1]    = {'\0'};
							printf("\nBefore Release Status Count\n");fflush(stdout);
							CALLAPI(WSOM_ask_release_status_list(task,&count_release_status,&release_status_object));
							printf("After Release Status Count\n");fflush(stdout);
							printf("Release Status Count Obtained=%d\n",count_release_status);fflush(stdout);
							if(count_release_status>0)
							{
								int k;
								for(k=0;k<count_release_status;k++)
								{
									char* date_rel=NULL;
									char* date_relstr=NULL;
									date_relstr=(char*)malloc(100*sizeof(char));
									tag_t release_status = release_status_object[k];
									CALLAPI(CR_ask_release_status_type(release_status,name));
									printf("Release Status Name obtained=%s\n",name);fflush(stdout);
									if(tc_strcmp(name,"T5_LcsStdRlzd")==0)
									{
										CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
										printf("STD Released Date=%s\n",date_rel);fflush(stdout);
										sprintf(date_relstr,"<STD_Release_Date>%s</STD_Release_Date>",date_rel);
										setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
										
									}
										if(date_relstr!=NULL)free(date_relstr);
								}
								
							}
							
							CALLAPI(AOM_ask_value_string(taskList[i] ,"change_specialist1_user_id",&reviewer));
							sprintf(reviewerstr,"<Reviewer>%s</Reviewer>",reviewer);
							setAddStr(buff_cnt,bufferedXmlStrOut,reviewerstr);
							
							sequence_number= (char *) MEM_alloc( 10 * sizeof(char) );
							
							CALLAPI(AOM_ask_value_tags(task,"CMHasSolutionItem",&partcount,&PartList));
							printf("\n No of Parts found in the Task ====>[%d]\n", partcount);fflush(stdout);
							if(partcount>0)
							{
								int k;
								for(k=0;k<partcount;k++)
								{
									CALLAPI(AOM_ask_value_string(PartList[k] ,"item_id",&partnumber));
									printf("Part Number Found for Part =%s\n",partnumber);fflush(stdout);
									sprintf(partnumberstr,"<Part_Number>%s</Part_Number>",partnumber);
									setAddStr(buff_cnt,bufferedXmlStrOut,partnumberstr);
									
									CALLAPI(AOM_ask_value_string(PartList[k] ,"item_revision_id",&revision_id));
									printf("Revision Found for Part =%s\n",revision_id);fflush(stdout);
									
									tc_strcpy(revision_id_cpy,revision_id);
									revision_id_tokenized=strtok(revision_id_cpy,";");
									printf("Tokenized Revision Id=%s\n",revision_id_tokenized);fflush(stdout);
									sprintf(revision_id_tokenizedstr,"<Revision>%s</Revision>",revision_id_tokenized);
									setAddStr(buff_cnt,bufferedXmlStrOut,revision_id_tokenizedstr);
									
									CALLAPI(AOM_ask_value_int(PartList[k],"sequence_id",&sequence));
									printf("Sequence Found for Part  =%d\n",sequence);fflush(stdout);
									sprintf(sequence_numberstr,"<Sequence>%d</Sequence>",sequence);
									setAddStr(buff_cnt,bufferedXmlStrOut,sequence_numberstr);
									
									CALLAPI(AOM_ask_value_string(PartList[k],"t5_DocRemarks",&PartDescription));
									printf("Description Found for Part  =%s\n",PartDescription);fflush(stdout);
									sprintf(PartDescriptionstr,"<Part_Description>%s</Part_Description>",PartDescription);
									setAddStr(buff_cnt,bufferedXmlStrOut,PartDescriptionstr);
									
									
								}

							}
								 
								 
						}
					}
									setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
									
				}
				  
			}
		      
		      setAddStr(buff_cnt,bufferedXmlStrOut,"</APLDMLBetweenDateReport>");
			  
				
		
			printf("Outside For Loop\n");fflush(stdout);
		
			//Need to find out Lifecycle State and Released Date of DML..........
		
			
	
			/* *((char **) retValue) = 
			(char *) MEM_alloc( (strlen(Return_String ) + 1) * sizeof(char));  //Commented on 21St June 2018

			strcpy( *((char **) retValue), Return_String); */

			/* *((char **) Return_String) = 
			(char *) MEM_alloc( (strlen(retValue ) + 1) * sizeof(char));

			strcpy( *((char **) Return_String), retValue); */	
	
			/////////////
			
			
	printf("Start After Freeing ALL\n");fflush(stdout); 
	if(ModifiedDayTo!=NULL) free(ModifiedDayTo);
	if(Datemodified!=NULL)free(Datemodified);
	if(item_idvalstr!=NULL)free(item_idvalstr);
	printf("\nStart After Freeing ALL1\n");fflush(stdout); 
	if(Date_releasedstr!=NULL)free(Date_releasedstr);
	printf("Start After Freeing ALL2\n");fflush(stdout); 
	if(lifecycle_statestr!=NULL)free(lifecycle_statestr);
	printf("Start After Freeing ALL3\n");fflush(stdout);
	if(Reasonstr!=NULL)free(Reasonstr);
	printf("Start After Freeing ALL4\n");fflush(stdout);
	if(partnumberstr!=NULL)free(partnumberstr); 
	printf("Start After Freeing ALL5\n");fflush(stdout);
	if(revision_idstr!=NULL)free(revision_idstr); 
	printf("Start After Freeing ALL6\n");fflush(stdout);
	if(serial_numstr!=NULL)free(serial_numstr); 
	printf("Between After Freeing ALL");fflush(stdout); 
	if(sequence_numberstr!=NULL)free(sequence_numberstr); 
	if(PartDescriptionstr!=NULL)free(PartDescriptionstr);
	printf("Middle  After Freeing ALL\n");fflush(stdout); 
	
	if(erc_released_datestr!=NULL)free(erc_released_datestr);
	if(designer_ercstr!=NULL)free(designer_ercstr);
	if(reviewerstr!=NULL)free(reviewerstr);
	//MEM_free(serial_num);
	//if(serial_num!=NULL)free(serial_num);
	printf("1 After Freeing ALL\n");fflush(stdout); 

	printf("2 After Freeing ALL\n");fflush(stdout); 
	if(Project_idstr!=NULL)free(Project_idstr);
	if(dml_numberstr!=NULL)free(dml_numberstr);
	if(dml_descstr!=NULL)free(dml_descstr); 
	if(requestorstr!=NULL)free(requestorstr); 
	if(DRStatusstr!=NULL)free(DRStatusstr); 
	if(released_datestr!=NULL)free(released_datestr); 
	if(design_groupstr!=NULL)free(design_groupstr); 
	if(dml_descriptionstr!=NULL)free(dml_descriptionstr); 
	printf("3 After Freeing ALL\n");fflush(stdout); 
	if(revision_id_tokenizedstr!=NULL)free(revision_id_tokenizedstr);
	
	printf("4 After Freeing ALL\n");fflush(stdout); 
			
			return ifail;

}

//sneha - DML Print Report 
typedef struct delta_bom
{
	int count;
	char **uidlist;
	int *status;
	
	
}Delta_Bom;
	

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}


void  getAllPlantDetails( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if((strcmp(PlantName,"APLJ")==0))
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}
	
	
void getIndex(char **view_list,int count,char *str,int *found)
{

	printf("\n **setFindStr");fflush(stdout);
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{
			*found=k;
			break;
		}

	}
	printf("\n **setFindStr found= %d",*found);fflush(stdout);


}

void getStrByIndex(char **view_list,int count,int idx,char **str)
{

	printf("\n **getStrByIndex");fflush(stdout);

	*str =view_list[idx];
	 
}
	

int printObject(tag_t objtag)
{

	int                prop_count=0;
	char**             prop_names=NULL;
	int        num_values=0;
	char**     values =NULL;
	tag_t                   class_tag=NULLTAG;
	char                     *class_name=NULL;
	int j=0,k=0;

	logical propConstReqBool=false;

	int ifail=ITK_ok;

	printf("\n printObject()->");fflush(stdout);

	if(objtag==NULLTAG)
	{
		printf("\nNULLTAG");fflush(stdout);
		return ifail;
	}

	char *type_name=NULL;
	tag_t type_tag = NULLTAG;
	ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

	ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



	ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
	printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
	// printf("\n printObject2 %d",prop_count);fflush(stdout);

	for (k=0;k<prop_count;k++)
	{
		ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values));

		tag_t prop_tag = NULLTAG;
		ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
		printf("\n %s:{,[",prop_names[k]);fflush(stdout);

		propConstReqBool=false;
		char *prop_dispay_name=NULL;
		PROP_value_type_t valtype;
		char *valtypeName=NULL;
		ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

		printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
		ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
		printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
		ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
		printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
		printf("\n]\n");fflush(stdout);

		for(j=0;j<num_values;j++)
		{
			printf("\n\t%s,",values[j]);fflush(stdout);
		}

		printf("\n },");fflush(stdout);

	}
	printf("\n]");fflush(stdout);
	return ifail;
}
	


int getQueryItemRevision( const char *val,tag_t* items,char *type)
{
	int ifail = ITK_ok;

	printf("\n\n RowsVal DML==%s \n",val);fflush(stdout);
	printf("\n\n DML type==%s \n",type);fflush(stdout);

	tag_t        query           = NULLTAG;
	tag_t        *t_item1        = NULLTAG;
	int          n_found         = 0;
	char *qry_entries3[] = {"Item ID","Type"},
		 *qry_values3[]   = {(char *)val,type};
        
	QRY_find("Item Revision...", &query);
	QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &t_item1);
	printf("\n\n getQueryItemRevision Rows555==%s %d\n",val,n_found);fflush(stdout);

	*items=t_item1[0];

	return ifail;
}


int getQueryAllTask( const char *val,int   *n_found ,tag_t    **t_item1)
{
	int ifail = ITK_ok;
	printf("\n in getQueryAllTask");fflush(stdout);
	printf("\n\n RowsVal DML==%s \n",val);fflush(stdout);
	tag_t        query           = NULLTAG;
	char *TaskID=NULL;
	TaskID = (char *) MEM_alloc( 200 * sizeof(char) );
	tc_strcpy(TaskID,val);
	tc_strcat(TaskID,"*");
	printf("\n\n DML type==%s \n",TaskID);fflush(stdout);

	char  *qry_entries3[] = {"ECN No."},
	*qry_values3[]       = {TaskID};

	printf("\n in getQueryAllTask1");fflush(stdout);

	QRY_find("Change Notice Revision...", &query);
	printf("\n in getQueryAllTask2");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, t_item1);
	printf("\n\n getQueryAllTask Rows7777==%s \n",TaskID);fflush(stdout);

	return ifail;
}


void printBOM(int srcchcnt,tag_t *srcbomchld)
{
	char            *ChildPartLC            =  NULL;
	char            *cp_ItemType_str        =  NULL;
	char            *cp_ItemID_str          =  NULL;
	char            *cp_ItemRev_str         =  NULL;
	char            *cp_ItemStatus_str      =  NULL;
	char            *ChildPartType          =  NULL;
	char            *UserId                         =  NULL;
	char            *cp_ItemID_str1         =  NULL;
	int     iChldPrts       =0;
	int     iItemRevId      =0;
	int     iItemId         =0;
	int     iqty            =0;
	int     ifindno         =0;
	int     iChldPrts1      =0;
	int     iqty1   =0;
	int     i_ChildCount            =0;
	int     iItemId1                =0;
	int     ifindno1                =0;
	char    *childfindnum   = NULL;
	char *real_quantity = NULL;
	char *childqty=NULL;

	int f;
	tag_t bomline=NULLTAG;
	printf("\n************Start Print BOM===");fflush(stdout);
	printf("\n************srcchcnt8888===%d",srcchcnt);fflush(stdout);
	for(f=0;f<srcchcnt;f++)
	{

		printf("\n************Start  Print BOMLine===%d",f);fflush(stdout);
		bomline=srcbomchld[f];
		if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
		if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
		if(BOM_line_ask_attribute_string(bomline, iItemId, &cp_ItemID_str));
		if(BOM_line_ask_attribute_string(bomline, iItemRevId, &cp_ItemRev_str));
		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",cp_ItemRev_str,cp_ItemID_str);fflush(stdout);
		if( BOM_line_look_up_attribute ("bl_quantity",&iqty));
		if(BOM_line_ask_attribute_string(bomline, iqty, &childqty));
		printf("\n childqty Of Selected Item Is= [%s]\n",childqty);fflush(stdout);
		if( BOM_line_look_up_attribute ("bl_sequence_no",&ifindno));
		if(BOM_line_ask_attribute_string(bomline, ifindno, &childfindnum));
		printf("\n FindNumber Of Selected Item Is= [%s]\n",childfindnum);fflush(stdout);
		if( BOM_line_look_up_attribute ("fnd0bl_real_quantity",&iqty1));
		if(BOM_line_ask_attribute_string(bomline, iqty1, &real_quantity));
		//MEM_free(bomline);
		printf("\n************END  Print BOMLine===%d",f);fflush(stdout);


	}

	printf("\n************END Print BOM===");fflush(stdout);



}
	
	

//func for getting prev BOM

void getPrevRevitem(tag_t Currentitemrev,tag_t *item,tag_t *PrevitemRevtag)
{
	//tag_t item;
	*PrevitemRevtag=NULLTAG;
	int count=0;
	char *item_id=NULL;
	char *item_rev=NULL;
	char *revOf_item_rev=NULL;
	tag_t * rev_list; 
	int i =0;
	printf("\n************Inside getPrevRevitem*************");fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(Currentitemrev,"item_id",&item_id));
	ITK_CALL(AOM_ask_value_string(Currentitemrev,"item_revision_id",&item_rev));
	if(tc_strstr(item_rev,"NR"))
	{
		printf("\nitem[%s] is NR rev so no previous rev will traverse",item_id);fflush(stdout);
	}
	else
	{
		ITK_CALL(ITEM_ask_item_of_rev(Currentitemrev,item));

		ITK_CALL(ITEM_list_all_revs(*item,&count,&rev_list));
		if(count>1)
		{
			for(i=0;i<count;i++)
			{
				ITK_CALL(AOM_ask_value_string(rev_list[i],"item_revision_id",&revOf_item_rev));
				if(tc_strcmp(revOf_item_rev,item_rev)!=0)
				{
					*PrevitemRevtag=rev_list[i];
				}
				else
				{
					break;
				}
				
			}
		}

	}
				
				
				
}


	

static void create_bom_window(tag_t item, tag_t itemrev,char *view_name, tag_t *top_line)
{
    int
        num_of_boms,
        ii;
    char
        *type_name;
    tag_t
        rule,
        window,
        bom_view = NULLTAG,
        *bvs,
        view_type;
        
    ITK_CALL(BOM_create_window (&window));
    ITK_CALL(CFM_find("Latest Working", &rule));
    ITK_CALL(BOM_set_window_config_rule(window, rule));
    ITK_CALL(BOM_set_window_pack_all(window, TRUE));
        
    ITK_CALL(ITEM_list_bom_views( item, &num_of_boms, &bvs));
    for (ii = 0; ii < num_of_boms; ii++)
    {   
        ITK_CALL(PS_ask_bom_view_type(bvs[ii], &view_type));
        ITK_CALL(PS_ask_view_type_name(view_type, &type_name));
        if (!strcmp(type_name, view_name)) bom_view = bvs[ii];                   
    }
    if (bom_view == NULLTAG) 
        printf("BOMview: \"%s\" not found!\nUsing default BOMview.\n\n", view_name);
    ITK_CALL(BOM_set_window_top_line(window, item, itemrev, bom_view, top_line));     
}

static void getBOMPart(tag_t item,tag_t itemrev,tag_t *top_line, char *view_name,int *srcchcnt,tag_t **srcbomchld )
{

	*top_line=NULLTAG;

	char            *ChildPartNum           =  NULL;
	char            *ChildPartLC            =  NULL;
	char            *cp_ItemType_str        =  NULL;
	char            *cp_ItemID_str          =  NULL;
	char            *cp_ItemRev_str         =  NULL;
	char            *cp_ItemStatus_str      =  NULL;
	char            *ChildPartType          =  NULL;
	char            *UserId                 =  NULL;
	char            *cp_ItemID_str1         =  NULL;
	
	
	int     iChldPrts       =0;
	int     iItemRevId      =0;
	int     iItemId         =0;
	int     iqty            =0;
	int     ifindno         =0;
	int     iChldPrts1      =0;
	int     iqty1   =0;
	int     i_ChildCount            =0;
	int     iItemId1                =0;
	int     ifindno1                =0;
	char    *childfindnum   = NULL;
	char *real_quantity = NULL;
	int count;

	tag_t
	*children;
	*srcchcnt=0;

	tag_t t_Childobject=NULLTAG;


	char *childqty= NULL;


	int
		num_of_boms,
		ii;
	char
		*type_name;
	tag_t
		rule,
		*bvs,
		view_type;
		
		
	create_bom_window(item,itemrev,view_name,top_line);

	printf("\n print_bom");fflush(stdout);
	ITK_CALL(BOM_line_ask_child_lines(*top_line, &count, &children));
	for (ii = 0; ii < count; ii++) //print_bom (children[ii], indention);
	{
		t_Childobject=children[ii];
		BOM_line_unpack(t_Childobject);
	}

	BOM_line_ask_child_lines (*top_line, &count, &children);
	for (ii = 0; ii < count; ii++)
	{
		if(t_Childobject) t_Childobject=NULLTAG;

		t_Childobject=children[ii];
		printf("\n************start setAddTAG inside printing child===");fflush(stdout);
		setAddTAG(srcchcnt,srcbomchld,t_Childobject);

		printf("\n************END setAddTAG ===");fflush(stdout);

	}


	//ITK_CALL(BOM_close_window(window));
    printf("\n************END Print BOM===");fflush(stdout);

}

		
		
		
int getDeltaBOM_CompareBOM(tag_t parentitemrev,char *srcview,int srcchcnt,tag_t *srcbomchld,int tgtcnt,tag_t *tgtbomchld,int *deltacnt,tag_t **delta_bom,int *statuscount, int **status)
{

	int i,j,k;
	char *item_id;
	char *item_rev;


	char *J5QtyID1=NULL;
	char *J5BOMSource1=NULL;


	char *J5QtyID2=NULL;
	char *J5BOMSource2=NULL;

	char *J5ParentSource2=NULL;
	char *J5ParentSource2Dup=NULL;
	char *J5ParentNumDup=NULL;
	char *J5ParentRev=NULL;
	char *bom_note_view=NULL;




	char **curidlist=NULL;
	int  curidlist_cnt=0;
	char **previdlist=NULL;
	int  previdlist_cnt=0;

	char **prevqtylist=NULL;
	int  prevqtylist_cnt=0;

	char **curqtylist=NULL;
	int  curqtylist_cnt=0;

	char **prevloclist=NULL;
	int  prevloclist_cnt=0;


	tag_t tgtchild=NULLTAG;
	tag_t srcchlid=NULLTAG;

	const char*     delimit="/-";
	*deltacnt=0;

	*statuscount=0;

	int toqty;
	int toadd;
	int todel;

	printf("\n*************************getDeltaBOM_CompareBOM");fflush(stdout);
	ITK_CALL(AOM_ask_value_string(parentitemrev,"item_id",&item_id));
	ITK_CALL(AOM_ask_value_string(parentitemrev,"item_revision_id",&item_rev));


	for(j=0;j<srcchcnt;j++)
	{
			srcchlid=srcbomchld[j];

			//occ_id
			ITK_CALL(AOM_ask_value_string(srcchlid, "bl_clone_stable_occurrence_id", &J5BOMSource1));
			setAddStr(&curidlist_cnt,&curidlist,J5BOMSource1);
			
			ITK_CALL(AOM_ask_value_string(srcchlid, "bl_quantity", &J5QtyID1));
			setAddStr(&curqtylist_cnt,&curqtylist,J5QtyID1);			
	}

	for(i=0;i<tgtcnt;i++)
	{
		tgtchild=tgtbomchld[i];
		ITK_CALL(AOM_ask_value_string(tgtchild, "bl_clone_stable_occurrence_id", &J5BOMSource2));
		setAddStr(&previdlist_cnt,&previdlist,J5BOMSource2);
		
		//Quantity
		
		ITK_CALL(AOM_ask_value_string(tgtchild, "bl_quantity", &J5QtyID2));
		setAddStr(&prevqtylist_cnt,&prevqtylist,J5QtyID2);
						
	}

				
					
						//Addition 
	for(j=0;j<srcchcnt;j++)
	{

		srcchlid=srcbomchld[j];


		ITK_CALL(AOM_ask_value_string(srcchlid, "bl_clone_stable_occurrence_id", &J5BOMSource1));
		setFindStr(previdlist,tgtcnt,J5BOMSource1,&toadd);
		
		printf(" \n PPPPADD 11==%d",toadd);fflush(stdout);
		if(toadd==0)//NEW ADDED
		{
			printf("\n Inside new added object Found");fflush(stdout);
			
			setAddTAG(deltacnt, delta_bom,srcchlid);
			
			char            *cp_ItemID_str          =  NULL;
			char            *iItemId          =  NULL;
			
			if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
			
			if(BOM_line_ask_attribute_string(srcchlid, iItemId, &cp_ItemID_str));
			
			ITK_CALL(AOM_ask_value_string(srcchlid, "bl_quantity", &J5QtyID1));
									
			printf("\n bl_item_item_id=%s",cp_ItemID_str);fflush(stdout);
			
			
			//for qty chg		

			int matched=0;					
			for(i=0;i<tgtcnt;i++)
			{


				tgtchild=tgtbomchld[i];


				char            *cp_ItemID_str_1          =  NULL;
				char            *iItemId_1          =  NULL;

				if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId_1));

				if(BOM_line_ask_attribute_string(tgtchild, iItemId_1, &cp_ItemID_str_1));

				if(tc_strcmp(cp_ItemID_str_1,cp_ItemID_str)==0)
				{
					matched=1;
					break;
				}

							
			}



			//Quantity
			printf("matched=%d",matched);
			if(matched==1)
			{
											
				printf("SAme item");fflush(stdout);
				setAddInt(statuscount,status,MOD);	
								
				
			}				
			else	
			{
				printf("not SAme item");fflush(stdout);			
				setAddInt(statuscount,status,ADD);

			}								
						 
		}

	}

					

	//Deletion 

	for(i=0;i<tgtcnt;i++)
	{


		tgtchild=tgtbomchld[i];

		ITK_CALL(AOM_ask_value_string(tgtchild, "bl_clone_stable_occurrence_id", &J5BOMSource2));
		setFindStr(curidlist,srcchcnt,J5BOMSource2,&todel);
			
		if(todel==0)// DELETED PART 
		{

			printf("\n Inside new deleted  object Found");fflush(stdout);
			printf("\n *****DELETING in DELTA7777777**** delete structure change found");fflush(stdout);
			
			setAddTAG(deltacnt, delta_bom,tgtchild);
			setAddInt(statuscount,status,DEL);

		}
		

	}
					
					
	/*quantity changed*/
					

	for(j=0;j<srcchcnt;j++)
	{

		srcchlid=srcbomchld[j];
		ITK_CALL(AOM_ask_value_string(srcchlid, "bl_clone_stable_occurrence_id", &J5BOMSource1));
		setFindStr(previdlist,tgtcnt,J5BOMSource1,&toadd);		
		
		if(toadd==1)
		{
			int idx=-1;
			char *str=NULL;
			getIndex(previdlist,tgtcnt,J5BOMSource1,&idx);
			getStrByIndex(prevqtylist,prevqtylist_cnt,idx,&str);
			
			ITK_CALL(AOM_ask_value_string(srcchlid, "bl_quantity", &J5QtyID2));
			if(tc_strcmp(str,J5QtyID2)!=0)
			{
				setAddInt(statuscount,status,MOD);
			}
		
		}
		

	}					

}




int getStructureModification(tag_t item,tag_t itemrev,char *view_name,tag_t **deltabom,int *deltacount,int **status)
{
	int             ifail                           = ITK_ok;

	////tag_t *delta_bom=NULLTAG;
	tag_t bomwin1=NULLTAG;
	tag_t *srcbomchld=NULLTAG;
	int srcchcnt=0,deltacnt;
	int statuscount;


	getBOMPart(item,itemrev,&bomwin1,view_name,&srcchcnt,&srcbomchld );

	printBOM(srcchcnt,srcbomchld);

	tag_t bomwin2=NULLTAG;
	tag_t itemprev=NULLTAG;
	tag_t *prevbom=NULLTAG;
	tag_t PrevitemRev=NULLTAG;
	int prevbomcnt=0;

	printf("\n************going to previous revision************************************");fflush(stdout);
	getPrevRevitem(itemrev,&itemprev,&PrevitemRev);
	 
	if (PrevitemRev!=NULLTAG)
	{
		printf("\n************Taking out structure Difference between Two revision===");fflush(stdout);
		//printObject(PrevitemRev);
		getBOMPart(item,PrevitemRev,&bomwin2,view_name,&prevbomcnt,&prevbom );

		printBOM(prevbomcnt,prevbom);
	}

	getDeltaBOM_CompareBOM(itemrev,view_name,srcchcnt,srcbomchld,prevbomcnt,prevbom,deltacount, deltabom,&statuscount,status);	
	
	return ifail;
}
		
		
		
		
int ReleaseStatus(tag_t item_tag_rev, char *ReleaseStat)
{
	int ifail = ITK_ok;
	int ii                         = 0;
	int	   			status_count					= 0;
	int 			status;	
	tag_t* status_list = NULLTAG;
	char *relStatus=NULL;
	char *lifecyclestat=NULL;
	lifecyclestat = (char *) MEM_alloc( 100 * sizeof(char) );  

	status=WSOM_ask_release_status_list(item_tag_rev,&status_count,&status_list);
	if(status==ITK_ok)
	{
		printf("\n number of statuses for Task: %d \n",  status_count);
		for (ii = 0; ii < status_count; ii++)
		{
			ITK_CALL (AOM_ask_name(status_list[ii], &relStatus));
			printf("\t ReleaseStat: %s\n", relStatus);fflush(stdout);
		}
	}
		 
	if (tc_strcmp(	relStatus,"T5_LcsAplRlzd")==0)
	{
		tc_strcpy(lifecyclestat,"APL RELEASED");
	}

	else if (tc_strcmp(	relStatus,"T5_LcsStdRlzd")==0)
	{
		tc_strcpy(lifecyclestat,"STD RELEASED");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsErcRlzd")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC RELEASED");
	}
	else if (tc_strcmp(	relStatus,"T5_LcsReview")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC REVIEW");
	}

	else if (tc_strcmp(	relStatus,"T5_LcsWorking")==0) 
	{
		tc_strcpy(lifecyclestat,"ERC WORKING");
	}
	else
	{
		tc_strcpy(lifecyclestat,relStatus);
	}
	printf("\t Lifecycle stat: %s\n", lifecyclestat);fflush(stdout);

	tc_strcpy(ReleaseStat,lifecyclestat);

	MEM_free(lifecyclestat);

	return ifail;
}	
			
		

int printChildBOMInFile(int count,tag_t *bomchld,int *status,FILE * FileContent,int *addparts,int *delParts,int *qtyChngParts,int **statuscnt,char*** bufferedXmlStrOut, int *buff_cnt,int DesignGrpCnt)
{

	int             ifail                           = ITK_ok;
	char            *ChildPartLC            =  NULL;
	char            *cp_ItemType_str        =  NULL;
	char            *cp_ItemID_str          =  NULL;
	char            *cp_ItemRev_str         =  NULL;
	char            *cp_ItemStatus_str      =  NULL;
	char            *ChildPartType          =  NULL;
	char            *cp_desc_str         =  NULL;
	char            *cp_location_str         =  NULL;
	char            *cp_CS_str         =  NULL;
	char            *cp_release_str         =  NULL;
	char    		*childfindnum   = NULL;
	char 			*real_quantity = NULL;
	char 			*childqty=NULL;
	char 			*statusDesc=NULL;
	char 			*statusDescPDF=NULL;
	char 			*Parentofchild=NULL;
	statusDesc = (char *) MEM_alloc( 30 * sizeof(char) );
	statusDescPDF = (char *) MEM_alloc( 30 * sizeof(char) );
	Parentofchild = (char *) MEM_alloc( 200 * sizeof(char) );

	char            *cp_CI_str          = NULL;
	char    		*cp_QRI_str		    = NULL;
	char 			*cp_SI_str 			= NULL;
	char 			*cp_EPA_str			= NULL;
	char 			*cp_ES_str			= NULL;
	char 			*cp_RI_str			= NULL;
	char 			*cp_IPTV_str		= NULL;
	char 			*cp_IC_str			= NULL;
	char 			*cp_REPLACE_str		= NULL;


	int     iChldPrts       =0;
	int     iItemRevId      =0;
	int     iItemId         =0;
	int     iqty            =0;
	int     ifindno         =0;
	int     iChldPrts1      =0;
	int     iqty1   		=0;
	int     i_ChildCount    =0;
	int     Desc            =0;
	int     location        =0;
	int     JSRcs           =0;
	int     release         =0;


	 *addparts=0;
	 *delParts=0;
	 *qtyChngParts=0;

	int f;
	tag_t bomline=NULLTAG;
	printf("\n************Start Print BOM in file===");fflush(stdout);

	fprintf(FileContent,"\n	   %-2s		%-2s     %-2s	%-2s	%-2s	%-2s 	%-2s 	%-2s   	%-2s	%-2s	%-2s	%-2s 	%-2s 	%-2s   	%-2s	%-2s ","Restructuring","Part Number","Description","Rev,Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","RI","IPTV","Replaces_Part","LifeCycleState"); fflush(FileContent);
	
	for(f=0;f<count;f++)
	{

		printf("\n************Start  Print BOMLine===%d",f);fflush(stdout);
		bomline=bomchld[f];
		if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
		if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
		if(BOM_line_ask_attribute_string(bomline, iItemId, &cp_ItemID_str));
		if(BOM_line_ask_attribute_string(bomline, iItemRevId, &cp_ItemRev_str));
		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",cp_ItemRev_str,cp_ItemID_str);fflush(stdout);
		if( BOM_line_look_up_attribute ("bl_quantity",&iqty));
		if(BOM_line_ask_attribute_string(bomline, iqty, &childqty));
		printf("\n childqty Of Selected Item Is= [%s]\n",childqty);fflush(stdout);
		if( BOM_line_look_up_attribute ("bl_sequence_no",&ifindno));
		if(BOM_line_ask_attribute_string(bomline, ifindno, &childfindnum));
		//printf("\n FindNumber Of Selected Item Is= [%s]\n",childfindnum);fflush(stdout);
		if( BOM_line_look_up_attribute ("fnd0bl_real_quantity",&iqty1));
		if(BOM_line_ask_attribute_string(bomline, iqty1, &real_quantity));

		if( BOM_line_look_up_attribute ("bl_item_object_desc",&Desc));
		if( BOM_line_look_up_attribute ("bl_Design Revision_t5_JsrStoreLocation",&location));
		if( BOM_line_look_up_attribute ("bl_Design Revision_t5_JsrMakeBuyIndicator",&JSRcs));
		if( BOM_line_look_up_attribute ("bl_rev_last_release_status",&release));

		if(BOM_line_ask_attribute_string(bomline, Desc, &cp_desc_str));
		if(BOM_line_ask_attribute_string(bomline, location, &cp_location_str));
		if(BOM_line_ask_attribute_string(bomline, JSRcs, &cp_CS_str));
		if(BOM_line_ask_attribute_string(bomline, release, &cp_release_str));

		printf("\n cp_desc_str= [%s]\n",cp_desc_str);fflush(stdout);
		printf("\n cp_location_str= [%s]\n",cp_location_str);fflush(stdout);
		printf("\n cp_CS_str= [%s]\n",cp_CS_str);fflush(stdout);
		printf("\ncp_release_str= [%s]\n",cp_release_str);fflush(stdout);
		printf("\nstatus= [%d]\n",status[f]);fflush(stdout);

		if (status[f]==ADD)
		{
			setAddInt(addparts,statuscnt,ADD);	
			//*addparts=*addparts+1;
			tc_strcpy(statusDesc,"ADDED PART");
			tc_strcpy(statusDescPDF,"A");
		}
		else if (status[f]==DEL)
		{
			setAddInt(delParts,statuscnt,DEL);	
			//*delParts=*delParts+1;
			tc_strcpy(statusDesc,"DELETED PART");
			tc_strcpy(statusDescPDF,"D");
		}
		else if (status[f]==MOD)
		{
			setAddInt(qtyChngParts,statuscnt,MOD);	
			//*qtyChngParts=*qtyChngParts+1;
			tc_strcpy(statusDesc,"QTY CHANGE");
			tc_strcpy(statusDescPDF,"C");
		}



		fprintf(FileContent,"\n	   %-2s			%-2s     %-2s	%-2s	%-2s	%-2s 	%-2s 	%-2s	%-2s	%-2s 	%-2s 	%-2s   	%-2s	%-2s	 %-2s   	%-2s	%-2s ",statusDesc,cp_ItemID_str,cp_desc_str,cp_ItemRev_str,cp_CS_str,cp_CI_str,childqty,cp_QRI_str,cp_location_str,cp_SI_str,cp_EPA_str,cp_ES_str,cp_RI_str,cp_IPTV_str,cp_IC_str,cp_REPLACE_str,cp_release_str); fflush(FileContent);

		printf("\n************END  Print BOMLine===%d",f);fflush(stdout);


		/*Genearting XML Tags */

		setAddStr(buff_cnt,bufferedXmlStrOut,"<partdetail>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<partdetailid>");
		sprintf (Parentofchild,"%d",DesignGrpCnt);
		setAddStr(buff_cnt,bufferedXmlStrOut,Parentofchild);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</partdetailid>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<srl>");
		if(statusDescPDF!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,statusDescPDF);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</srl>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childPart>");
		if(cp_ItemID_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,cp_ItemID_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childPart>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childDesc>");
		if(cp_desc_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_desc_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childDesc>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childRevision>");
		if(cp_ItemRev_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_ItemRev_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childRevision>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childCS>");
		if(cp_CS_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_CS_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childCS>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childCI>");
		if(cp_CI_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_CI_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childCI>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childQRI>");
		if(cp_QRI_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_QRI_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childQRI>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childSI>");
		if(cp_SI_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_SI_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childSI>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childEPA>");
		if(cp_EPA_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_EPA_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childEPA>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childES>");
		if(cp_ES_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_ES_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childES>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childRI>");
		if(cp_RI_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_RI_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childRI>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childIPTV>");
		if(cp_IPTV_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_IPTV_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childIPTV>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childIC>");
		if(cp_IC_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_IC_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childIC>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childREPLACE>");
		if(cp_REPLACE_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_REPLACE_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childREPLACE>");


		setAddStr(buff_cnt,bufferedXmlStrOut,"<childQty>");
		if(childqty!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, childqty);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childQty>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childLoc>");
		if(cp_location_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_location_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childLoc>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"<childRelstatus>");
		if(cp_release_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, cp_release_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</childRelstatus>");

		setAddStr(buff_cnt,bufferedXmlStrOut,"</partdetail>");

	}
	printf("\n printChildBOMInFile = Added Parts=%d",*addparts);fflush(stdout);
	printf("\n printChildBOMInFile = Delete Parts=%d",*delParts);fflush(stdout);
	printf("\n printChildBOMInFile = Change Parts=%d",*qtyChngParts);fflush(stdout);
	printf("\n************END printChildBOMInFile");fflush(stdout);


	MEM_free(statusDesc);
	MEM_free(statusDescPDF);
	MEM_free(Parentofchild);

	return ifail=0;
}

//Get the Release Type
char*  FetchECNType(char* ECNType)
{
	char* DMLTypeDup=NULL;
	char* TypeDesc=NULL;
	
	TypeDesc=(char *) MEM_alloc( 200 * sizeof(char) );

	
	if(ECNType!=NULL) 
	{


		tc_strdup(ECNType,&DMLTypeDup);


		if( (tc_strcmp(DMLTypeDup,"TPL")==0))
		tc_strdup("Technical Part List",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"Veh")==0))
		tc_strdup("Vehicle Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"VCMDU")==0))
		tc_strdup("VC/TPL Master Data Update",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"WFO")==0))
		tc_strdup("Withdraw From Obsolete",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"XO")==0))
		tc_strdup("Gate Maturation",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"TOO")==0) )
		tc_strdup("Transfer of Design Site Ownership",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"VOD")==0) )
		tc_strdup("Vehicle Offer/Pass off Norms Drawing",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"WT")==0) )
		tc_strdup("Withdraw TPL",&TypeDesc);		


		else if( (tc_strcmp(DMLTypeDup,"CQ")==0))
		tc_strdup("Change Quantity",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"ECU")==0))
		tc_strdup("ECU Parts Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"PR")==0))
		tc_strdup("Prototype Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"CP1")==0))
		tc_strdup("CP1",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"PDR")==0))
		tc_strdup("Positional Dummy Release",&TypeDesc);


		else if( (tc_strcmp(DMLTypeDup,"COL")==0) )
		tc_strdup("Comp Code and Colour Indicator Update",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"TK")==0) )
		tc_strdup("TPL with Spare Kit Release",&TypeDesc);		





		else if( (tc_strcmp(DMLTypeDup,"CKR")==0))
		tc_strdup("Cabin Kit Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"K")==0))
		tc_strdup("Kit and Spare Part Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"SPR")==0))
		tc_strdup("Standard Part Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"DTR")==0))
		tc_strdup("Dummy TPL Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"CP")==0))
		tc_strdup("Colour Part Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"D")==0) )
		tc_strdup("Deviation List",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"SPS")==0) )
		tc_strdup("SPS",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"CL")==0) )
		tc_strdup("CL",&TypeDesc);		



		else if( (tc_strcmp(DMLTypeDup,"SPT")==0))
		tc_strdup("SPT",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"CM")==0))
		tc_strdup("Colour Modification Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"XO1")==0))
		tc_strdup("XO1",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"TS1")==0))
		tc_strdup("TS1",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"TS")==0))
		tc_strdup("Tech Spec Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"WTR")==0) )
		tc_strdup("Work Shop Tool Release",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"PPR")==0) )
		tc_strdup("Production Part Regularization",&TypeDesc);

		else if( (tc_strcmp(DMLTypeDup,"RDL")==0) )
		tc_strdup("Reference Drawing Linkage",&TypeDesc);	

		else
			tc_strdup(DMLTypeDup,&TypeDesc);

	}    
	printf ("\n Release type of DML :[%s]",TypeDesc);
	return TypeDesc;

}

	
	
int PrintDMLInFile(char *dmlNumber,tag_t dml_rev_tag,FILE * FileContent, char*** bufferedXmlStrOut, int *buff_cnt)
{
	int             ifail                           = ITK_ok;
	//DML Property
	char        *ReleaseType           = NULL;
	char        *Department           = NULL;
	char        *Reason           = NULL;
	char        *ReasonDesc           = NULL;
	char        *Synopsis           = NULL;
	char        *Type           = NULL;
	char        *DMLID           = NULL;
	char        *DMLItemRev          = NULL;
	char        *creatorStr           = NULL;
	char        *requestorStr           = NULL;
	char        *DMLDRstat           = NULL;
	char        *DMLDesignGroup           = NULL;
	char        *DMLProjectCode	                      	= NULL;
	char        *DMLReleaseNotes                     	= NULL;
	char        *DMLReleaseStatus                    	= NULL;
	char        *DMLDescription                    	= NULL;
	char        *DMLECNType                    	= NULL;
	char        *TaskId                    = NULL;
	char        *TaskReleaseStat           = NULL;
	TaskReleaseStat = (char *) MEM_alloc( 100 * sizeof(char) );
	ReleaseType = (char *) MEM_alloc( 100 * sizeof(char) );

	date_t relDate;
	date_t relDate1;
	char* APLrelDate_str = NULL;
	char* STDrelDate_str = NULL;
	char* relDate_str1 = NULL;
	char **DesignGroupList;
	int num=0,k;
	int             n_tasksFnd                      = 0;
	tag_t *task_obj_tag                        		= NULLTAG;

	DMLReleaseStatus = (char *) MEM_alloc( 100 * sizeof(char) );

	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"item_id",&DMLID))
	printf("\n DMLID: %s ", DMLID);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"item_revision_id",&DMLItemRev))
	printf("\n DMLItemRev: %s ", DMLItemRev);fflush(stdout);

	ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_rlstype",&ReleaseType));
	printf("\n DML release type : %s \n",ReleaseType); fflush(stdout);
	ReleaseType = FetchECNType(ReleaseType);

	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"object_type",&Type))
	printf("\n Type: %s ", Type);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_strings(dml_rev_tag,"t5_crdesigngroup",&num,&DesignGroupList));

	for (k=0;k<num;k++)
	{
		tc_strdup(DesignGroupList[k],&DMLDesignGroup);
		printf("\n  DMLDesignGroup : %s \n",DMLDesignGroup); fflush(stdout);

	}
											
	ITK_CALL (AOM_ask_value_string(dml_rev_tag,"project_ids",&DMLProjectCode));
	printf("\n  DMLProjectCode : %s \n",DMLProjectCode); fflush(stdout);
	
	
	ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_reason",&Reason));
	printf("\n  Reason : %s \n",Reason); fflush(stdout);
	
	
	ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_reasondesc",&ReasonDesc));
	printf("\n  ReasonDesc : %s \n",ReasonDesc); fflush(stdout);
	
	ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_cDRstatus",&DMLDRstat));
	printf("\n  DMLDRstat : %s \n",DMLDRstat); fflush(stdout);
	
	//ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_rlsltrnotesA",&DMLReleaseNotes));
	//printf("\n  DMLReleaseNotes : %s \n",DMLReleaseNotes); fflush(stdout);
	
	
	ITK_CALL(AOM_ask_value_date(dml_rev_tag,"date_released",&relDate))
	ITK_CALL(ITK_date_to_string(relDate, &APLrelDate_str))
			printf("\nReleased date of DML: %s\n",APLrelDate_str);fflush(stdout);
	
	ITK_CALL(AOM_UIF_ask_value(dml_rev_tag,"owning_user",&creatorStr))
	printf("\n creatorStr: %s ", creatorStr);fflush(stdout);
	
	
	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"requestor_user_id",&requestorStr))
	printf("\n requestorStr: %s ", requestorStr);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"object_name",&Synopsis))
	printf("\n Synopsis: %s ", Synopsis);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(dml_rev_tag,"object_desc",&DMLDescription))
	printf("\n DMLDescription: %s ", DMLDescription);fflush(stdout);
	
	// ITK_CALL(AOM_ask_value_string(dml_rev_tag,"t5_EcnType",&DMLECNType))
	// printf("\n DMLECNType: %s ", DMLECNType);fflush(stdout);
	
	ITK_CALL (ReleaseStatus(dml_rev_tag,DMLReleaseStatus));
	
	
	/** generating XML tags for PDF Format**/	
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmldetail>");
	/*1*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlno>");
	setAddStr(buff_cnt,bufferedXmlStrOut,dmlNumber);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlno>");

	/*2*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlDept>");
	setAddStr(buff_cnt,bufferedXmlStrOut," ");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlDept>");

	/*3*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlRelType>");
		if(ReleaseType!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, ReleaseType);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlRelType>");

	/*4*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlDsgGrp>");
		if(DMLDesignGroup!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, DMLDesignGroup);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlDsgGrp>");

	/*5*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlProj>");
		if(DMLProjectCode!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, DMLProjectCode);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlProj>");

	/*6*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlReason>");
		if(Reason!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, Reason);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlReason>");

	/*7*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlCre>");
		if(creatorStr!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, creatorStr);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlCre>");

	/*8*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlDRStat>");
		if(DMLDRstat!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, DMLDRstat);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlDRStat>");

	/*9*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlERCRev>");
		if(requestorStr!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, requestorStr);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlERCRev>");

	/*10*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlDesc>");
		if(Synopsis!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut, Synopsis);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlDesc>");

	/*11*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlReasondesc>");
		if(ReasonDesc!=NULL)
	setAddStr(buff_cnt,bufferedXmlStrOut,ReasonDesc);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlReasondesc>");

	/*12*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlRelNote>");
	setAddStr(buff_cnt,bufferedXmlStrOut," ");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlRelNote>");

	/*13*/
	setAddStr(buff_cnt,bufferedXmlStrOut,"<dmlOthDsgGrpAff>");

	setAddStr(buff_cnt,bufferedXmlStrOut," ");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmlOthDsgGrpAff>");
		
	setAddStr(buff_cnt,bufferedXmlStrOut,"</dmldetail>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"<tasksdetail>");

	if (tc_strstr(dmlNumber,"AM")==NULL) //DML IS NOT AMDML
	{
		fprintf(FileContent,"\n    DML NUMBER 	   			:%-25s  	", dmlNumber);	 	fflush(FileContent); 	
		fprintf(FileContent,"	  			Department 		:%-10s 		"," ");	fflush(FileContent);	  		
		fprintf(FileContent,"				Release Type 	:%-10s		",ReleaseType);		fflush(FileContent);
		fprintf(FileContent,"\n    Design Group 			:%-25s		",DMLDesignGroup);	fflush(FileContent);	
		fprintf(FileContent,"				Project code 	:%-10s		",DMLProjectCode);	fflush(FileContent);		
		fprintf(FileContent,"				Reason 			:%-10s		",Reason);			fflush(FileContent);
		fprintf(FileContent,"\n    Creator 	   			:%-25s			",creatorStr);	 	fflush(FileContent); 	
		fprintf(FileContent,"				DML DR-Status 	:%-10s		",DMLDRstat);	  	fflush(FileContent); 		
		fprintf(FileContent,"				ERC Reviewer 	:%-10s		",requestorStr);	fflush(FileContent);
		fprintf(FileContent,"\n    Synopsis 	   			:%-25s		",Synopsis);		fflush(FileContent);
		fprintf(FileContent,"\n    Reason Description 	 	:%-10s		",ReasonDesc);		fflush(FileContent);
		fprintf(FileContent,"\n    Release Notes		 	:%-10s		", " ");	fflush(FileContent);
	
	
	
		// Expand the DML-Revision using relation "T5_DMLTaskRelation" to get Task tag.
		tag_t relatnType_tag=NULLTAG;
		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
		if (relatnType_tag!=NULLTAG)
		{
			if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag, relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
			{
				return ifail;
			}
			printf("\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);

			int i=0;
			for (i=0;i<n_tasksFnd ;i++ )
			{

				// Retrieve the Task-Revision Tag.
				tag_t task_rev_tag = NULLTAG;

				task_rev_tag=task_obj_tag[i];
				if (task_rev_tag  != NULLTAG)
				{
					ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
					ITK_CALL (ReleaseStatus(task_rev_tag,TaskReleaseStat));
					ITK_CALL(AOM_ask_value_date(task_rev_tag,"date_released",&relDate1))
					ITK_CALL(ITK_date_to_string(relDate1, &relDate_str1))
							printf("\nReleased date of ATTACHED TASK: %s\n",relDate_str1);fflush(stdout);
					fprintf(FileContent,"\n    Life Cycle State	[%10s]:%-10s 		 %10s DATE:	%10s	", TaskId,TaskReleaseStat,TaskReleaseStat,relDate_str1);fflush(FileContent);

					char        	*TaskType           	   = NULL;
					ITK_CALL (AOM_ask_value_string(task_rev_tag,"object_type",&TaskType));
					printf("\n DMLTaskRel : Task-Rev TaskType : %s \n",TaskType); fflush(stdout);
					if (tc_strcmp(TaskType,"T5_APLDMLRevision")==0)
					{
						if((tc_strcmp(	DMLReleaseStatus,"STD RELEASED")==0) || (tc_strcmp(	DMLReleaseStatus,"T5_LcsStdRlzd")==0) )
						{
							fprintf(FileContent,"			STD Released Date 	:%10s		", STDrelDate_str);fflush(FileContent);												
							
						}
					}
						
					/*genearating XML tag */
					setAddStr(buff_cnt,bufferedXmlStrOut,"<taskdetail>");
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<taskno>");
					setAddStr(buff_cnt,bufferedXmlStrOut,TaskId);
					setAddStr(buff_cnt,bufferedXmlStrOut,"</taskno>");
					
					setAddStr(buff_cnt,bufferedXmlStrOut,"<taskLCS>");
					if(TaskReleaseStat!=NULL)
						setAddStr(buff_cnt,bufferedXmlStrOut,TaskReleaseStat);
					setAddStr(buff_cnt,bufferedXmlStrOut,"</taskLCS>");
						
					if (tc_strcmp(TaskType,"T5_APLDMLRevision")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<taskercreldate>");
						setAddStr(buff_cnt,bufferedXmlStrOut," ");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</taskercreldate>");
						
						setAddStr(buff_cnt,bufferedXmlStrOut,"<taskaplreldate>");
						if(relDate_str1!=NULL)
							setAddStr(buff_cnt,bufferedXmlStrOut,relDate_str1);
						setAddStr(buff_cnt,bufferedXmlStrOut,"</taskaplreldate>");
					}
					else
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<taskercreldate>");
						if(relDate_str1!=NULL)
							setAddStr(buff_cnt,bufferedXmlStrOut,relDate_str1);
						setAddStr(buff_cnt,bufferedXmlStrOut,"</taskercreldate>");
						
						setAddStr(buff_cnt,bufferedXmlStrOut,"<taskaplreldate>");
						setAddStr(buff_cnt,bufferedXmlStrOut," ");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</taskaplreldate>");
					}
					setAddStr(buff_cnt,bufferedXmlStrOut,"<taskstdreldate>");
					if(STDrelDate_str!=NULL)
						setAddStr(buff_cnt,bufferedXmlStrOut,STDrelDate_str);
					else
						setAddStr(buff_cnt,bufferedXmlStrOut," ");
					setAddStr(buff_cnt,bufferedXmlStrOut,"</taskstdreldate>");
					printf("stddreeellll");fflush(stdout);
					setAddStr(buff_cnt,bufferedXmlStrOut,"</taskdetail>");
				}
			}
		}
			
					
	}
	else // IF DML IS AMDML
	{
		fprintf(FileContent,"\n    DML NUMBER		:%-25s", dmlNumber);fflush(FileContent);
		fprintf(FileContent,"\n    Project code 	:%-25s", DMLProjectCode);fflush(FileContent);
		fprintf(FileContent,"\n    Description 	  	:%-25s", DMLDescription);fflush(FileContent);
		fprintf(FileContent,"\n    Synopsis 	   	:%-25s",Synopsis);fflush(FileContent);
		fprintf(FileContent,"\n    Life Cycle State	[%10s]:%-10s 		 APL Released Date 	:%10s	", dmlNumber,DMLReleaseStatus,APLrelDate_str);fflush(FileContent);
		
	
		if((tc_strcmp(	DMLReleaseStatus,"STD RELEASED")==0) || (tc_strcmp(	DMLReleaseStatus,"T5_LcsStdRlzd")==0) )
		{
			fprintf(FileContent,"			STD Released Date 	:%10s		", STDrelDate_str);fflush(FileContent);
			
		}

		/*genearating XML tag */
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskdetail>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskno>");
		setAddStr(buff_cnt,bufferedXmlStrOut,dmlNumber);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskno>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskLCS>");
			if(DMLReleaseStatus!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,DMLReleaseStatus);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskLCS>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskercreldate>");
		setAddStr(buff_cnt,bufferedXmlStrOut," ");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskercreldate>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskaplreldate>");
			if(APLrelDate_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,APLrelDate_str);
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskaplreldate>");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskstdreldate>");
			if(STDrelDate_str!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,STDrelDate_str);
			else
		setAddStr(buff_cnt,bufferedXmlStrOut," ");
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskstdreldate>");
		printf("stddreeel2222");fflush(stdout);
		
		setAddStr(buff_cnt,bufferedXmlStrOut,"</taskdetail>");
	}
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"</tasksdetail>");

		
	fprintf(FileContent,"\n=============================================================================================================================================================================================================");fflush(FileContent);
	fprintf(FileContent,"\n																								");fflush(FileContent);
	fprintf(FileContent,"\n																								");fflush(FileContent);
	
	
	
					
	MEM_free(DMLReleaseStatus);
	MEM_free(TaskReleaseStat);		
	
	return ifail;
}



	
		
int PrintTaskRevisionInFile(tag_t task_rev_tag,FILE * FileContent,char *agency,char*** bufferedXmlStrOut, int *buff_cnt, int DesignGrpCnt)
{
	// Task properties
	int             ifail                           = ITK_ok;

	char        *TaskId                    = NULL;
	char        *TaskDesc              	   = NULL;
	char        *TaskDesignGroup           = NULL;
	char        *TaskDisposition           = NULL;
	char        *TaskRequestor             = NULL;
	char        *TaskAnalyst               = NULL;
	char        *TaskReleaseStat           = NULL;
	char 		*Planner=NULL;
	char   		*DMLNo=NULL;
	char   		*DMLNoDup=NULL;
	char 		*STDAnalyst=NULL;

	TaskReleaseStat = (char *) MEM_alloc( 100 * sizeof(char) );
	
	ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
	printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);
	if (TaskId)
	{

	}
				

	ITK_CALL (AOM_ask_value_string(task_rev_tag,"object_desc",&TaskDesc));
	printf("\n DMLTaskRel : Task-Rev TaskDesc : %s \n",TaskDesc); fflush(stdout);
	if (TaskDesc)
	{

	}

	   
	ITK_CALL (AOM_ask_value_string(task_rev_tag,"CMDisposition",&TaskDisposition));
	printf("\n DMLTaskRel : Task-Rev TaskDisposition : %s \n",TaskDisposition); fflush(stdout);
	if (TaskDisposition)
	{
	 
	}
		
	 

	ITK_CALL (AOM_ask_value_string(task_rev_tag,"analyst_user_id",&TaskAnalyst));
	printf("\n DMLTaskRel : Task-Rev TaskAnalyst : %s \n",TaskAnalyst); fflush(stdout);
	if (TaskAnalyst)
	{
	
	}
		
		
	ITK_CALL (ReleaseStatus(task_rev_tag,TaskReleaseStat));
		
		
	if (tc_strcmp(agency,"APL")==0)
	{
		char **DesignGroupList;
		int num,k=0;
		ITK_CALL(AOM_ask_value_strings(task_rev_tag,"t5_crdesigngroup",&num,&DesignGroupList));

		for (k=0;k<num;k++)
		{
			tc_strdup(DesignGroupList[k],&TaskDesignGroup);
			printf("\n  TaskDesignGroup : %s \n",TaskDesignGroup); fflush(stdout);

		}

		if (tc_strstr(TaskId,"AM")!=NULL)
		{
			TotalAffectedGrp++;
			printf("****************AM DML TotalAffectedGrp=%d",TotalAffectedGrp);
		}
	}	 
	else if (tc_strcmp(agency,"ERC")==0)
	{

		tc_strdup(TaskId,&DMLNoDup);
		DMLNo = strtok( DMLNoDup, "_" );
		TaskDesignGroup	  = strtok ( NULL, "_" );
		printf("\n\n\t\t taskGrp is :%s",TaskDesignGroup); fflush(stdout);
		TotalAffectedGrp++;
		printf("****************ERC DML TotalAffectedGrp=%d",TotalAffectedGrp);
	}

		
	/* To get the DML WORK FLOW*/
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	char *JobID=NULL;
	JobID = (char *) MEM_alloc( 500 * sizeof(char) );
	tc_strcpy(JobID,TaskId);

	tc_strcat(JobID,"*");
		

	char
		   *qry_entries3[] = {"Job Name","Name"},
		   *qry_values3[]       = {JobID,"Work On DML"};

	printf("\n\n Rows111==%s \n",JobID);fflush(stdout);

			 
	QRY_find("Audit - Workflow General_TML", &query);
	printf("\n\n Workflow General_TML Rows2222==%s \n",JobID);fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &t_item1);

	printf("\n\n Workflow General_TML item found Rows666==%s %d\n",JobID,n_found);fflush(stdout);

	int j=0;
	for (j=0;j<n_found;j++ )
	{

		char 		*jobName		= 	NULL;
		char 		*DMLAPL			= 	NULL;

		tag_t workjob_tag = NULLTAG;
		workjob_tag = t_item1[j];
		ITK_CALL(AOM_ask_value_string(workjob_tag,"responsible_partyDisp",&Planner));
		printf("\n Work On DML Planner :: %s\n",Planner);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(workjob_tag,"job_name",&jobName));
		printf("\n Work On DML Job Name  :: %s\n",jobName);fflush(stdout);

	}
		
	printf("\n The task for design group number =%d ",DesignGrpCnt);fflush(stdout);
	char *taskcount=NULL;									 
	taskcount=(char *) MEM_alloc( 100 * sizeof(char) );							 

	fprintf(FileContent,"\n	 %-5s   %-25s  %-25s  %-25s  %-25s	%-25s  ",TaskDesignGroup,TaskId,TaskDesc,TaskAnalyst,Planner,STDAnalyst);fflush(FileContent);
	
		
	/*Generating XML Tags */

	setAddStr(buff_cnt,bufferedXmlStrOut,"<tasksDsgdetails>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<DsgGrpid>");
	sprintf(taskcount,"%d",DesignGrpCnt);
	setAddStr(buff_cnt,bufferedXmlStrOut,taskcount);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</DsgGrpid>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<desgrp>");
	if(TaskDesignGroup!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,TaskDesignGroup);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</desgrp>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<taskid>");
	if(TaskId!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,TaskId);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</taskid>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<taskdesc>");
	if(TaskDesc!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, TaskDesc);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</taskdesc>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<ERCAna>");
	if(TaskAnalyst!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, TaskAnalyst);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</ERCAna>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<APLAna>");
	if(Planner!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, Planner);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</APLAna>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<STDAna>");
	if(STDAnalyst!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, STDAnalyst);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</STDAna>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</tasksDsgdetails>");

	MEM_free(TaskReleaseStat);	
	return ifail;
}


int PrintPartInFile(tag_t part_rev_tag,FILE * FileContent,int count,char*** bufferedXmlStrOut, int *buff_cnt,int DesignGrpCnt)
{

	int             ifail                           = ITK_ok;
	//Part properties
	char       *PartNumberS                    			= NULL;
	char        *RevisionS                              = NULL;
	int        	SequenceS                           	= 0;
	char        *PartCS                              	= NULL;
	char        *PartDRStat                          	= NULL;
	char        *PartDesignGrp                       	= NULL;
	char        *ProjectCode	                      	= NULL;
	char        *PartReleaseStats                      	= NULL;
	char 		*EPAtask	= NULL;
	char 		*PartDescription= NULL;
	char 		*PartIA =NULL;
	char 		*PartSI =NULL;
	char 		*PartCI =NULL;
			

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];

	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	ITK_CALL(AOM_ask_value_string(part_rev_tag,"item_id",&PartNumberS));
	printf("\n  part-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);


	ITK_CALL (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
	printf("\n  part-Rev RevisionS : %s \n",RevisionS); fflush(stdout);

	ITK_CALL (AOM_ask_value_int(part_rev_tag,"sequence_id",&SequenceS));
	printf("\n  part-Rev SequenceS : %d \n",SequenceS); fflush(stdout);


	ITK_CALL (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDescription));
	printf("\n    part-Rev PartDescription : %s \n",PartDescription); fflush(stdout);
	if (PartDescription==NULL)
	{
		tc_strdup("NA",&PartDescription);
	}

	ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_PartStatus",&PartDRStat));
	printf("\n  part-Rev PartDRStat : %s \n",PartDRStat); fflush(stdout);


	ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_DesignGrp",&PartDesignGrp));
	printf("\n  part-Rev PartDesignGrp : %s \n",PartDesignGrp); fflush(stdout);




	getAllPlantDetails(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);

	ITK_CALL (AOM_ask_value_string(part_rev_tag,PlantCS,&PartCS));
	printf("\n : part-Rev PartCS : %s \n",PartCS); fflush(stdout);

	ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_ProjectCode",&ProjectCode));
	printf("\n  part-Rev ProjectCode : %s \n",ProjectCode); fflush(stdout);

	PartReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
	ITK_CALL (ReleaseStatus(part_rev_tag,PartReleaseStats));
	fprintf(FileContent,"\n	%d    %-15s     %-15s      	%-15s %-10s %-10s %-10s  %-10s	%-10s		%-10s   	%-10s",count,PartNumberS,PartDescription,RevisionS,PartIA,PartCS,PartSI,PartCI,EPAtask,PartDRStat,PartReleaseStats);fflush(FileContent);


	char *serialno=NULL;
	serialno= (char *) MEM_alloc( 100 * sizeof(char) );

	char *taskcnt=NULL;
	taskcnt= (char *) MEM_alloc( 100 * sizeof(char) );


	printf("\n The Design Number count for which Task is printing =%d ",DesignGrpCnt);fflush(stdout);

	/*Genearting XML Tags */

	setAddStr(buff_cnt,bufferedXmlStrOut,"<partAddMod>");


	setAddStr(buff_cnt,bufferedXmlStrOut,"<PartAddModid>");
	sprintf(taskcnt,"%d",DesignGrpCnt);
	setAddStr(buff_cnt,bufferedXmlStrOut,taskcnt);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</PartAddModid>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<srl>");
	sprintf(serialno,"%d",count);
	setAddStr(buff_cnt,bufferedXmlStrOut,serialno);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</srl>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<assy>");
	if(PartNumberS!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,PartNumberS);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</assy>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<desc>");
	if(PartDescription!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut,PartDescription);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</desc>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<revseq>");
	if(RevisionS!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, RevisionS);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</revseq>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<IA>");
	if(PartIA!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartIA);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</IA>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<CS>");
	if(PartCS!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartCS);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</CS>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<SI>");
	if(PartSI!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartSI);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</SI>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<CI>");
	if(PartCI!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartCI);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</CI>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<EPATask>");
	if(EPAtask!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, EPAtask);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</EPATask>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<PartDR>");
	if(PartDRStat!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartDRStat);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</PartDR>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<PartRelstatus>");
	if(PartReleaseStats!=NULL)
		setAddStr(buff_cnt,bufferedXmlStrOut, PartReleaseStats);
	setAddStr(buff_cnt,bufferedXmlStrOut,"</PartRelstatus>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"</partAddMod>");


	MEM_free(serialno);	
	MEM_free(taskcnt);						

	return ifail;
}
	
	
int DrawingIndicatorInFile(int DesignGrpCnt,FILE * FileContent,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail =ITK_ok;
	fprintf(FileContent,"\n																		");fflush(FileContent);
	fprintf(FileContent,"\n	DRAWINGS ADDED / MODIFIED											");fflush(FileContent);
	fprintf(FileContent,"\n	-------------------------											");fflush(FileContent);
	
	
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"<drawInd>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<drawIndid>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</drawIndid>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<srl>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</srl>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<assy>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</assy>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"<desc>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"</desc>");


	setAddStr(buff_cnt,bufferedXmlStrOut, "<modDesc>");
	setAddStr(buff_cnt,bufferedXmlStrOut, "</modDesc>");

	setAddStr(buff_cnt,bufferedXmlStrOut, "<lcStat>");
	setAddStr(buff_cnt,bufferedXmlStrOut, "</lcStat>");

	setAddStr(buff_cnt,bufferedXmlStrOut,"</drawInd>");
				
	return ifail;
}


int AllPartsInTask(int n_parts, tag_t *part_obj_tag,int DesignGrpCnt,int *countParts, FILE * DmlRelFile,char*** bufferedXmlStrOut, int *buff_cnt)
{

	int j=0;

	int ifail	= ITK_ok;

	tag_t part_rev_tag = NULLTAG;
								
	if (n_parts>0)
	{
				
		/* Number of Total resultant Parts */
		TotalResltparts=TotalResltparts+n_parts;

		setAddStr(buff_cnt,bufferedXmlStrOut,"<partAddMods  AV=\"true\">");
		//int countParts=0;
		for (j=0;j<n_parts ;j++ )
		{
			part_rev_tag = NULLTAG;

			part_rev_tag=part_obj_tag[j];
			
			 *countParts=*countParts+1;
			 printf("cccccc count parts =%d",*countParts);
			
			 /**********Print the Part description in File */
			 PrintPartInFile(part_rev_tag,DmlRelFile,*countParts,bufferedXmlStrOut,buff_cnt,DesignGrpCnt); //Function for Part Related attribute
		 
		 
		}
		setAddStr(buff_cnt,bufferedXmlStrOut,"</partAddMods>");														
		printf("\n TotalResltparts=%d",TotalResltparts); fflush(stdout);

		
	}
	else
	{
		fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
	}
												
												
	return ifail=0;

}


int StructureChangesInParts(int n_parts, tag_t *part_obj_tag,int DesignGrpCnt, FILE * DmlRelFile,char*** bufferedXmlStrOut, int *buff_cnt)
	{
	
		int j=0;
		int ifail  = ITK_ok;
		tag_t part_rev_tag = NULLTAG;
		char PlantCS[40];
		char PlantOptCS[40];
		char PlantIA[40];
		char PlantStore[40];
		char UserAgency[40];
		tag_t  CurrentRoleTag = NULLTAG;
		char       roleName[SA_name_size_c+1]  ;
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

		char *childofTask = NULL; childofTask = (char *) MEM_alloc( 200 * sizeof(char) );  
		char *serialNo = NULL; serialNo = (char *) MEM_alloc( 200 * sizeof(char) );  


	if (n_parts>0)
	{
		int ParentCnt=0;
		/* For RESTRUCTURE PORTION */
		for (j=0;j<n_parts ;j++ )
		{

			part_rev_tag = NULLTAG;

			part_rev_tag=part_obj_tag[j];
			char        *RevisionS                              = NULL;
			char        *PartCS                              	= NULL;
			char        *PartDesc                              	= NULL;

			tag_t *deltabom=NULLTAG;

			int deltacount=0;
			int addparts;
			int delParts;
			int qtyChngParts;
			int *statusFnd;
			int *statusCnt;
			tag_t item;
			char *parentpart=NULL;
			ITK_CALL(AOM_ask_value_string(part_rev_tag,"item_id",&parentpart));
			ITEM_ask_item_of_rev  ( part_rev_tag,&item);

			ITK_CALL (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
			printf("\n  structchng RevisionS : %s \n",RevisionS); fflush(stdout);

			getAllPlantDetails(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
			ITK_CALL (AOM_ask_value_string(part_rev_tag,PlantCS,&PartCS));
			printf("\n : structchng PartCS : %s \n",PartCS); fflush(stdout);


			ITK_CALL (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDesc));
			printf("\n    part-Rev PartDesc : %s \n",PartDesc); fflush(stdout);
			if (PartDesc==NULL)
			{
			tc_strdup("NA",&PartDesc);
			}

			getStructureModification(item,part_rev_tag,"T5_DFMA",&deltabom,&deltacount,&statusFnd);   //Function to get structure changes in part




			if (deltacount>0)
			{
			ParentCnt++;
			fprintf(DmlRelFile,"\n	%d 		%25s	%10s	%10s   %10s",ParentCnt,parentpart,PartDesc,RevisionS,PartCS);	

			setAddStr(buff_cnt,bufferedXmlStrOut,"<partdetail>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<partdetailid>");
			sprintf (childofTask,"%d",DesignGrpCnt);
			setAddStr(buff_cnt,bufferedXmlStrOut,childofTask);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</partdetailid>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<srl>"); 
			sprintf (serialNo,"%d",ParentCnt);
			setAddStr(buff_cnt,bufferedXmlStrOut,serialNo);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</srl>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<childPart>");
			if(parentpart!=NULL)
			setAddStr(buff_cnt,bufferedXmlStrOut,parentpart);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</childPart>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<childDesc>");
			if(PartDesc!=NULL)
			setAddStr(buff_cnt,bufferedXmlStrOut, PartDesc);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</childDesc>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<childRevision>");
			if(RevisionS!=NULL)
			setAddStr(buff_cnt,bufferedXmlStrOut, RevisionS);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</childRevision>");

			setAddStr(buff_cnt,bufferedXmlStrOut,"<childCS>");
			if(PartCS!=NULL)
			setAddStr(buff_cnt,bufferedXmlStrOut, PartCS);
			setAddStr(buff_cnt,bufferedXmlStrOut,"</childCS>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</partdetail>");	

			printChildBOMInFile(deltacount,deltabom,statusFnd,DmlRelFile,&addparts,&delParts,&qtyChngParts,&statusCnt,bufferedXmlStrOut,buff_cnt,DesignGrpCnt);   //function to print the structure changes
			printf("\n Added Parts=%d",addparts);fflush(stdout);
			printf("\n delParts Parts=%d",delParts);fflush(stdout);
			printf("\nqtyChngParts Parts=%d",qtyChngParts);fflush(stdout);

			/* Number of Total Restructured Parts-add/del/modify qty */
			TotalAddparts=TotalAddparts+addparts;
			TotalDelparts=TotalDelparts+delParts;
			TotalQtychngparts=TotalQtychngparts+qtyChngParts;

			}
			fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);									
		}

	}
	else
	{
		fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
	}
													

	MEM_free(serialNo);	
	MEM_free(childofTask);	

	return ifail=0;
	
	
}
		
int GenerateDMLReport(tag_t seldmlobj,char*dmlNumber, char*** bufferedXmlStrOut, int *buff_cnt)
{

	printf("\nitem_id of selected object:%s\n",dmlNumber);fflush(stdout);
	int  i,j                  = 0;
	int  n_tasksFnd           = 0;
	int  n_parts              = 0;
	int  countParts			  = 0;
	int  ifail                = ITK_ok;
	time_t now;
	struct tm* now_tm;
	char*   item_type       = NULL;
	char *Filename			= NULL;
	char *FileLoc			= NULL;
	char *dataSetName 		= NULL;
	char ReleasedDateTime_str[26] = {'\0'};
	char * relation_type_name = NULL;
	FILE * DmlRelFile		=NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t  	relation_type = NULLTAG;
	tag_t  	relation    = NULLTAG;
	tag_t   seldmlobjrev=NULLTAG;
	char *DMLNo=NULL;
	char *username=NULL;
	tag_t dml_tag                        			= NULLTAG;
	tag_t dml_rev_tag                        		= NULLTAG;
	tag_t *task_obj_tag                        		= NULLTAG;
	tag_t *part_obj_tag                             = NULLTAG;
	tag_t relatnType_tag                            = NULLTAG;
	tag_t partRelatn_Type_tag                       = NULLTAG;
	tag_t task_rev_tag                              = NULLTAG;
	tag_t part_rev_tag                              = NULLTAG;
	int DesignGrpCnt=0;
	char *DesignID = NULL; 
	DesignID = (char *) MEM_alloc( 200 * sizeof(char) ); 

	ITK_CALL(ITEM_ask_latest_rev(seldmlobj,&seldmlobjrev));
	

	// Query the DML in PLM. 
	ifail = ITEM_find_item( dmlNumber, &dml_tag );
	char*	item_type_DML				= NULL;
	char*	Revision_type_DML				= NULL;
	Revision_type_DML = (char *) MEM_alloc( 100 * sizeof(char) );
	if (dml_tag != NULLTAG)
	{
		// find the type of dml_tag
		ifail = ITEM_ask_type2 (dml_tag, &item_type_DML);
		printf("\n Input DML Type : item_typeS [%s] \n",item_type_DML);  fflush(stdout);
	}

	if (tc_strcmp(item_type_DML,"ChangeRequest")==0)
	{
		printf("\n The DML is ERC DML");fflush(stdout);
		tc_strdup("ERC DML Revision",&Revision_type_DML);
		ITK_CALL(getQueryItemRevision(dmlNumber,&dml_rev_tag,Revision_type_DML)); //Function for Query Item Revision

	}
	else if (tc_strcmp(item_type_DML,"T5_APLDML")==0)
	{
		if (tc_strstr(dmlNumber,"AM")!=NULL)
		{
			printf("\n The DML is AMDML");fflush(stdout);
			tc_strdup("APL DML Revision",&Revision_type_DML);
			ITK_CALL(getQueryItemRevision(dmlNumber,&dml_rev_tag,Revision_type_DML)); //Function for Query Item Revision

		}
		else
		{
			printf("\n The DML is APLJ DML");fflush(stdout);
			tc_strdup(dmlNumber,&DMLNo);
			DMLNo = strtok( DMLNo, "_" );
			tc_strdup("ERC DML Revision",&Revision_type_DML);
			ITK_CALL(getQueryItemRevision(DMLNo,&dml_rev_tag,Revision_type_DML)); //Function for Query Item Revision
		}
	}
			
	printf("\n The DML :%s",dmlNumber);fflush(stdout);
		
	/***get session user **/
	ITK_CALL (POM_get_user_id (&username));
	printf("\n\n  Session login User1 for MR : %s\n",username); fflush(stdout);
			
	/******creating the File for writting ********/
	time(&now);
	now_tm = localtime(&now);
	 //strftime (ReleasedDateTime_str, 20, "%Y-%m-%d-%H-%m-%S", now_tm);
	strftime (ReleasedDateTime_str, 26, "%a_%b__%d_%H_%M_%S_%Y", now_tm);
	//17JM014001_REL_LETTER_RPT_Mon_Sep__4_11_17_53_2017.txt
	printf("\n ReleasedDateTime_str is===>[%s]",ReleasedDateTime_str);fflush(stdout);

	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,dmlNumber);
	tc_strcat(Filename,"_ERCPrintRep_");
	tc_strcat(Filename,ReleasedDateTime_str);
	tc_strcat(Filename,".txt");
	printf("\n Filename: %s", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/tmp/");
	tc_strcat(FileLoc,Filename);
	printf("\n FileLoc: %s\n", FileLoc);fflush(stdout);

	DmlRelFile = fopen(FileLoc, "w");
	fprintf(DmlRelFile,"=============================================================================================================================================================================================================");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n																D M L    H E A D E R:												");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n																----------------------												\n");fflush(DmlRelFile);


	setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"<report>");

	if (dml_rev_tag  != NULLTAG)
	{

		/** ArrayList for Creating XML Tags in buffer **/

		/**********Print the DML description in File */
		PrintDMLInFile(dmlNumber,dml_rev_tag,DmlRelFile,bufferedXmlStrOut,buff_cnt); //Function for DML Related attribute

		fprintf(DmlRelFile,"\n																						AFFECTED  DESIGN  GROUPS												");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																						----------------------												");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n 	TASK 	DESCRIPTION											");fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n	-------------------											");fflush(DmlRelFile);
		
		// Expand the DML-Revision using relation "T5_DMLTaskRelation" to get Task tag.
		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
		if (relatnType_tag!=NULLTAG)
		{
			if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag, relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
			{
				return ifail;
			}
            printf("\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);
																
			for (i=0;i<n_tasksFnd ;i++ )
			{

				// Retrieve the Task-Revision Tag.
				task_rev_tag = NULLTAG;

				task_rev_tag=task_obj_tag[i];
				if (task_rev_tag  != NULLTAG)
				{

					int Tskcnt=0;
					int TskcntInPart=0;

					tag_t *TaskRevision=NULLTAG;
					tag_t relatnType_tag=NULLTAG;
					char  *TaskType   = NULL;
					char *TaskId=NULL;


					ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
					printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);

					ITK_CALL (AOM_ask_value_string(task_rev_tag,"object_type",&TaskType));
					printf("\n DMLTaskRel : Task-Rev TaskType : %s \n",TaskType); fflush(stdout);


					if (tc_strcmp(TaskType,"T5_APLDMLRevision")==0)
					{
						//Dont consider
						//Dont consider
						printf("\n YOU ARE IN APL DML REVISION \n",TaskType); fflush(stdout);
					}
					else if (tc_strcmp(TaskType,"T5_APLTaskRevision")==0) //APL TASK REVISION
					{
						printf("\n YOU ARE IN APL TASK REVISION \n",TaskType); fflush(stdout);
						//int DesignGrpCnt=0;
						DesignGrpCnt++;
						TskcntInPart++; //to get the task count number
						Tskcnt++;
						fprintf(DmlRelFile,"\n  	 %-5s   %-25s  %-25s  %-25s  %-25s	%-25s  ","DesGrp","Task Id","Synopsis","ERC Analyst","APL Planner","STDS1 Planner");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n  	----------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);


						setAddStr(buff_cnt,bufferedXmlStrOut,"<task>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<DsgGrpBaseDetails id=\"");
						sprintf (DesignID,"%d",DesignGrpCnt);
						setAddStr(buff_cnt,bufferedXmlStrOut,DesignID);
						setAddStr(buff_cnt,bufferedXmlStrOut,"\">");


						setAddStr(buff_cnt,bufferedXmlStrOut,"<tasksDsgs  AV=\"true\">");
						PrintTaskRevisionInFile(task_rev_tag,DmlRelFile,"APL",bufferedXmlStrOut,buff_cnt,DesignGrpCnt);
						setAddStr(buff_cnt,bufferedXmlStrOut,"</tasksDsgs>");								

						// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
						ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
						if (partRelatn_Type_tag!=NULLTAG)
						{

							if ( (ifail = GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
							{
								return ifail;
							}
							printf("\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
						}

						/* For Number of Parts in  All Task of a particular design group */		

						fprintf(DmlRelFile,"\n			");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n			");fflush(DmlRelFile);

						fprintf(DmlRelFile,"\n	PARTS ADDED / MODIFIED											");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	----------------------											");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	%s     %-15s     %-15s      	%-20s %-10s %-10s %-10s  %-10s	%-10s		%-10s   	%-10s" ,"Srl","Assy-Partno","Assy-Part-Description","Rev,Seq","IA", "CS" ,"SI","CI","Epa Task","Part Status","LifecycleState");	fflush(DmlRelFile);						

						countParts=0;
						AllPartsInTask(n_parts,part_obj_tag,DesignGrpCnt,&countParts,DmlRelFile,bufferedXmlStrOut,buff_cnt);  /// print parts


						/*For Drawing Indicator ************************/
						setAddStr(buff_cnt,bufferedXmlStrOut,"<draws  AV=\"true\">");
						DrawingIndicatorInFile(DesignGrpCnt,DmlRelFile,bufferedXmlStrOut,buff_cnt);  //Function for Drawing Indicator
						setAddStr(buff_cnt,bufferedXmlStrOut,"</draws>");



						/* ForStrcuture Changes in Parts */	
						fprintf(DmlRelFile,"\n																								");
						fprintf(DmlRelFile,"\n	STRUCTURE CHANGES											");		
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");	fflush(DmlRelFile);					

						setAddStr(buff_cnt,bufferedXmlStrOut,"<strucChgs  AV=\"true\">");
						StructureChangesInParts(n_parts,part_obj_tag,DesignGrpCnt,DmlRelFile,bufferedXmlStrOut,buff_cnt);	
						setAddStr(buff_cnt,bufferedXmlStrOut,"</strucChgs>");

						/* AFFECTED VC */
						fprintf(DmlRelFile,"\n																								");
						fprintf(DmlRelFile,"\n	 AFFECTED VCs											");		
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
						setAddStr(buff_cnt,bufferedXmlStrOut,"<affVC AV=\"false\">");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<vcs></vcs>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</affVC>");


						setAddStr(buff_cnt,bufferedXmlStrOut,"</DsgGrpBaseDetails>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</task>");				

					}
					else if (tc_strcmp(TaskType,"T5_ChangeTaskRevision")==0) //ERC TASK REVISION
					{
						printf("\n YOU ARE IN ERC TASK REVISION \n",TaskType); fflush(stdout);

						int taskcnt=0;

						tag_t *dmltask_rev_obj                        		= NULLTAG;
						ITK_CALL(getQueryAllTask(TaskId,&taskcnt,&dmltask_rev_obj)); //Function for Query All task  Revision



						DesignGrpCnt++;


						setAddStr(buff_cnt,bufferedXmlStrOut,"<task>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<DsgGrpBaseDetails id=\"");
						sprintf (DesignID,"%d",DesignGrpCnt);
						setAddStr(buff_cnt,bufferedXmlStrOut,DesignID);
						setAddStr(buff_cnt,bufferedXmlStrOut,"\">");

						int mm=0;
						/* For printing  All Task of a particular design group */	
						setAddStr(buff_cnt,bufferedXmlStrOut,"<tasksDsgs  AV=\"true\">");
						for (mm=0;mm<taskcnt;mm++)
						{

							tag_t Task_tag =NULLTAG;
							Task_tag = dmltask_rev_obj[mm];
							char        	*Type           	   = NULL;

							if (Task_tag  != NULLTAG)
							{
								ITK_CALL (AOM_ask_value_string(Task_tag,"object_type",&Type));
								printf("\n getQueryAllTask : Task-Rev Type : %s \n",Type); fflush(stdout);

								if (tc_strcmp(Type,"T5_APLTaskRevision")==0) //APL TASK REVISION
								{
									Tskcnt++;
									PrintTaskRevisionInFile(Task_tag,DmlRelFile,"APL",bufferedXmlStrOut,buff_cnt,DesignGrpCnt);
								}
								else if (tc_strcmp(Type,"T5_ChangeTaskRevision")==0) //ERC TASK REVISION
								{
								Tskcnt++;
								fprintf(DmlRelFile,"\n  	 %-5s   %-25s  %-25s  %-25s  %-25s	%-25s  ","DesGrp","Task Id","Synopsis","ERC Analyst","APL Planner","STDS1 Planner");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n  	----------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);

								PrintTaskRevisionInFile(Task_tag,DmlRelFile,"ERC",bufferedXmlStrOut,buff_cnt,DesignGrpCnt);
								}
							}

						}
						setAddStr(buff_cnt,bufferedXmlStrOut,"</tasksDsgs>");																	
						fprintf(DmlRelFile,"\n			");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n			");fflush(DmlRelFile);

						fprintf(DmlRelFile,"\n	PARTS ADDED / MODIFIED											");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	----------------------											");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	%s     %-15s     %-15s      	%-20s %-10s %-10s %-10s  %-10s	%-10s		%-10s   	%-10s" ,"Srl","Assy-Partno","Assy-Part-Description","Rev,Seq","IA", "CS" ,"SI","CI","Epa Task","Part Status","LifecycleState");	fflush(DmlRelFile);						

						/* For Number of Parts in  All Task of a particular design group */			
						for (mm=0;mm<taskcnt;mm++)
						{

							tag_t Task_tag =NULLTAG;
							Task_tag = dmltask_rev_obj[mm];
							TskcntInPart++; //to get the task count number
							char        	*Type           	   = NULL;

							if (Task_tag  != NULLTAG)
							{	

								ITK_CALL (AOM_ask_value_string(Task_tag,"object_type",&Type));
								printf("\n getQueryAllTask : Task-Rev Type : %s \n",Type); fflush(stdout);
								if (tc_strcmp(Type,"T5_ChangeTaskRevision")==0) //ERC TASK REVISION
								{
									// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
									ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
									if (partRelatn_Type_tag!=NULLTAG)
									{

										if ( (ifail = GRM_list_secondary_objects_only( Task_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
										{
											return ifail;
										}
										printf("\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
									}
									countParts=0;					

									AllPartsInTask(n_parts,part_obj_tag,DesignGrpCnt,&countParts,DmlRelFile,bufferedXmlStrOut,buff_cnt);  
								}
							}
						}	
						/********End Number of Parts in  All Task of a particular design group */		



						setAddStr(buff_cnt,bufferedXmlStrOut,"<draws  AV=\"true\">");
						/*For Drawing Indicator ************************/
						DrawingIndicatorInFile(DesignGrpCnt,DmlRelFile,bufferedXmlStrOut,buff_cnt);  //Function for Drawing Indicator
						setAddStr(buff_cnt,bufferedXmlStrOut,"</draws>");


						fprintf(DmlRelFile,"\n																								");
						fprintf(DmlRelFile,"\n	STRUCTURE CHANGES											");		
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");	fflush(DmlRelFile);					

						/* ***************For Structure Changes in Parts *********************************/
						for (mm=0;mm<taskcnt;mm++)
						{


							tag_t Task_tag =NULLTAG;
							Task_tag = dmltask_rev_obj[mm];
							TskcntInPart++; //to get the task count number

							char        	*Type           	   = NULL;

							if (Task_tag  != NULLTAG)
							{	

								ITK_CALL (AOM_ask_value_string(Task_tag,"object_type",&Type));
								printf("\n getQueryAllTask : Task-Rev Type : %s \n",Type); fflush(stdout);

								if (tc_strcmp(Type,"T5_ChangeTaskRevision")==0) //ERC TASK REVISION
								{
									// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
									ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
									if (partRelatn_Type_tag!=NULLTAG)
									{

										if ( (ifail = GRM_list_secondary_objects_only( Task_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
										{
											return ifail;
										}
										printf("\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
									}
									setAddStr(buff_cnt,bufferedXmlStrOut,"<strucChgs  AV=\"true\">");
									StructureChangesInParts(n_parts,part_obj_tag,DesignGrpCnt,DmlRelFile,bufferedXmlStrOut,buff_cnt);
									setAddStr(buff_cnt,bufferedXmlStrOut,"</strucChgs>");

								}	
							}
						}	
						/* ***************End Structure Changes in Parts *********************************/	

						/*Affected VCs **/
						setAddStr(buff_cnt,bufferedXmlStrOut,"<affVC AV=\"false\">");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<vcs></vcs>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</affVC>");

						fprintf(DmlRelFile,"\n																								");
						fprintf(DmlRelFile,"\n	 AFFECTED VCs											");		
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
						fprintf(DmlRelFile,"\n	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);


						setAddStr(buff_cnt,bufferedXmlStrOut,"</DsgGrpBaseDetails>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</task>");
					}

				}

			}
																			
		}
													
		fprintf(DmlRelFile,"\n=============================================================================================================================================================================================================");				fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			R E C O R D    S U M M A R Y    F O R    D M L																					");					fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			----------------------------------------------																					");						fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			No of affected groups               =	%d																						",TotalAffectedGrp);	fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			No of Resultant Parts               =	%d																						",TotalResltparts);		fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			No of Parts Added in Assy           =  	%d																						",TotalAddparts);		fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			No of Parts Deleted from Assy       =  	%d																						",TotalDelparts);		fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n																			No of Parts Qty Changed from assy   =  	%d																						",TotalQtychngparts);	fflush(DmlRelFile);

		fprintf(DmlRelFile,"\n=============================================================================================================================================================================================================");
		fprintf(DmlRelFile,"\n");
		fprintf(DmlRelFile,"\n");

							
		/* generating XML tags **/
		char *TotalAffectGrpStr = malloc(100*sizeof(*TotalAffectGrpStr));
		char *TotalPartsStr = malloc(100*sizeof(*TotalPartsStr));
		char *TotalAddStr	= malloc(100*sizeof(*TotalAddStr));
		char *TotalDelStr	= malloc(100*sizeof(*TotalDelStr));
		char *TotalChngStr = malloc(100*sizeof(*TotalChngStr));
		
						
								

		setAddStr(buff_cnt,bufferedXmlStrOut,"<result>");

		sprintf(TotalAffectGrpStr,"<TotalAffectGrp>%d</TotalAffectGrp>",TotalAffectedGrp);
		setAddStr(buff_cnt,bufferedXmlStrOut,TotalAffectGrpStr);
		sprintf(TotalPartsStr,"<TotalParts>%d</TotalParts>", TotalResltparts);
		setAddStr(buff_cnt,bufferedXmlStrOut,TotalPartsStr);
		sprintf(TotalAddStr,"<TotalAdd>%d</TotalAdd>", TotalAddparts);
		setAddStr(buff_cnt,bufferedXmlStrOut,TotalAddStr);
		sprintf(TotalDelStr,"<TotalDel>%d</TotalDel>",TotalDelparts);
		setAddStr(buff_cnt,bufferedXmlStrOut,TotalDelStr);
		sprintf(TotalChngStr,"<TotalChng>%d</TotalChng>",TotalQtychngparts);
		setAddStr(buff_cnt,bufferedXmlStrOut,TotalChngStr);

		setAddStr(buff_cnt,bufferedXmlStrOut,"</result>");




		setAddStr(buff_cnt,bufferedXmlStrOut,"<SOR AV=\"false\">");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<grp> </grp>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<taskId> </taskId>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<part> </part>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<SOR> </SOR>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PPPM> </PPPM>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Proj> </Proj>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Commod> </Commod>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<ProcessType> </ProcessType>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<SORCat> </SORCat>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<PPPMProj> </PPPMProj>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Prodstat> </Prodstat>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</SOR>");	

	}// end of dml_rev_tag
				
	fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n																								");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n																			 E N D    O F     R E P O R T																								");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n***************************************************************************************************************************************************************************************************************");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n	=============================================================================================================================================================================================================");fflush(DmlRelFile);
	fclose(DmlRelFile);
		
	setAddStr(buff_cnt,bufferedXmlStrOut,"</report>");


	/**Creating dataset for storing the Text File **************************************************/

	dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,dmlNumber);
	tc_strcat(dataSetName,"_DML_PRINT_RPT_");
	tc_strcat(dataSetName,ReleasedDateTime_str);

	CALLAPI(AE_find_datasettype("Text", &datasettype))
	CALLAPI(AE_find_tool2("Notepad", &tool))
	CALLAPI(AE_create_dataset_with_id(datasettype,dataSetName,"", NULL, NULL, &Newdataset))
	CALLAPI(AE_set_dataset_tool(Newdataset,tool))
	CALLAPI(AE_set_dataset_format(Newdataset, "TEXT_REF"))
	CALLAPI(AOM_save(Newdataset))	
	CALLAPI(IMF_fmsfile_import(FileLoc, Filename,SS_TEXT, &filetag, &fileDescriptor))
	if(filetag == NULLTAG)
	{
		printf("file tag not found.....");fflush(stdout);
	}
	CALLAPI(AOM_refresh(Newdataset, TRUE));
	CALLAPI(AE_add_dataset_named_ref2(Newdataset, "Text", AE_PART_OF, filetag))
	CALLAPI(AOM_save(Newdataset))
	//Attaching the dataset to Reference folder

	relation_type_name = (char*)MEM_alloc(70*sizeof(char));
	sprintf ( relation_type_name, "%s","CMReferences" );

	CALLAPI(GRM_find_relation_type(relation_type_name,&relation_type))
	if(relation_type != NULLTAG)
	{
		CALLAPI(GRM_create_relation(seldmlobjrev,Newdataset,relation_type, NULLTAG, &relation))
		if(relation != NULLTAG)
		{
			printf("\nThe dataset is attached to the Reference folder of DML");fflush(stdout);
		}
		else
		{
			printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
		}
		CALLAPI(GRM_save_relation(relation))
	}


	printf("\nCompleted....");fflush(stdout);
	
	/****************************************************************************************************************/

	/*reseting the values to Zero**/
	TotalAffectedGrp				= 0;
	TotalResltparts					= 0;
	TotalAddparts					= 0;
	TotalDelparts					= 0;
	TotalQtychngparts				= 0;
		

	return ifail;
}


int DMLPrintReportServiceCall(void *retValue)
{
	const char				*prog_name 		="DMLPrintReportServiceCall";
	char*   DMLNumber                      = NULL;
	tag_t dml_object = NULLTAG;
	int ifail = ITK_ok;

	char **bufferedXmlStrOut = NULL;
	int buff_cnt =0;
	USERSERVICE_array_t 	array_structure;
	int 					array_size 		= 0; 
	char 					**string_array 	= NULL;	

	USERARG_get_tag_argument(&dml_object);
	ITK_CALL(AOM_ask_value_string(dml_object,"item_id",&DMLNumber));
	printf("\nitem_id of selected object:%s\n",DMLNumber);fflush(stdout);

	if (dml_object != NULLTAG)
	{
		printf("\n Inside to call function GenerateDMLReport");	  
		ITK_CALL(GenerateDMLReport(dml_object,DMLNumber, &bufferedXmlStrOut,&buff_cnt));

	}
		
		
	int m =0;
	for(m=0;m<buff_cnt;m++)
	{
		printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
	}		

	printf ("\n After bufferedXmlStrOut");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)bufferedXmlStrOut, buff_cnt, &array_structure);

	if (array_structure.length != 0)
	{
		printf ("\n array_structure");fflush(stdout);
		*((USERSERVICE_array_t*) retValue) = array_structure;			
	}

	printf ("\n Repprt Completed ..return ");fflush(stdout);
	return ifail;
}

//End - sneha


//Start Sanjoy common dml reports


int dmlReleaseBetweenDates( char* Datefrom, char* Dateto, char* releaseStatusStr, char* Plant, int projlen, char** Project_code_ids, int colmnLen, char** additional_attrs, char* Planner, char*** bufferedXmlStrOut, int *buff_cnt  )
{
	int ifail = ITK_ok;
	int k;
	char *DatefromDup	=NULL;
	char *DatetoDup		=NULL;
	char *DatetoDup1	=NULL;
	char *DayTo			=NULL;
	char *MonthTo		=NULL;
	char *YearTo		=NULL;	
	//char *ModifiedDayTo		 =NULL;
	//char *Datemodified		 =NULL;
	int Day=0;
	date_t   a_date_from;
	date_t   a_date_to;	
	date_t   vals[2];	
	
	const char *Plant_received[]={Plant};
	const char * select_attrs[]={"puid"};
	
	printf("Plant recieved in Function=%s\n",Plant);fflush(stdout);
	printf("From Date=%s\n",Datefrom);fflush(stdout);
	printf("To Date=%s\n",Dateto);fflush(stdout);
	
	ITK_string_to_date(Datefrom,&a_date_from);
	ITK_string_to_date(Dateto,&a_date_to);

	vals[0]=a_date_from;
	vals[1]=a_date_to;
	

	for(k=0;k<projlen;k++)
	{
		
		printf("\n Project[%d]==[%s]",k+1,Project_code_ids[k]);
		
	}
	printf("Argument Received Datefrom(AplDmlReleaseBetweenDates) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received Dateto(AplDmlReleaseBetweenDates) =%s\n",Dateto);fflush(stdout);
	printf("Release Status Received (AplDmlReleaseBetweenDates) =%s\n",releaseStatusStr);fflush(stdout);
	printf("Plant Received (AplDmlReleaseBetweenDates) =%s\n",Plant);fflush(stdout);
	
	
	printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
	
	/** Creating a POM Query **/
	CALLAPI(POM_enquiry_create("find_Dml_Number"));
	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
	
	/** Adding select attribute to Query **/
	CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));
	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
	
	/**Setting Released Date **/
	CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
	
	if(tc_strcmp(releaseStatusStr,"APL Released")==0 || tc_strcmp(releaseStatusStr,"STD Released")==0 || tc_strcmp(releaseStatusStr,"PENDING")==0)
	{
		/** creating between Expression **/
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","date_released",POM_enquiry_between,"expr_dates"));
	}
	else 
	{
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","creation_date",POM_enquiry_between,"expr_dates"));
	}
	
	printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
	 /**Need to Check if Plant received if Plant is Null then go for Project Codes**/
	if(((tc_strcmp(Plant,"")==0 || Plant == NULL)) && projlen>0)
	{
		printf("Entered into Plant Section\n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Plant Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
	}
	else if((tc_strcmp(Plant,"")!=0) && projlen==0)
	{
		printf("Entered into Else Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );

		printf("Check 2\n");fflush(stdout);		
	}
	else  if((tc_strcmp(Plant,"")!=0) && projlen >0){
		printf("Both Plant and project not null.... Need to implement the logic\n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		//POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );	


		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression2","expr_AND_expression1",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Plant Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression2"));		

		printf("Check 2222\n");fflush(stdout);				

		
	}
	else
	{
		printf("Both Plant and project  null.... Need to implement the logic\n");fflush(stdout);
	}
	
	char *lifecycle_state = NULL;
	tag_t objtag =NULLTAG;
	int  rows = 0, columns = 0;
	void ***report;
	int ii, num=0;
	char * Project_id = NULL;
	char **design_group=NULL;
	char* apl_dml_number = NULL;
	char* dml_desc = NULL;
	
	char* lifecycle_statestr = NULL;
	char* serial_num = NULL;
	char* Project_idstr = NULL;
	char* design_groupstr = NULL;
	char* apl_dml_numberStr = NULL;
	char* dml_descstr = NULL;	
	char *Reason,*Reasonstr					=NULL;
	char * DRStatus,* DRStatusstr  = NULL;
	char *dml_number_erc =NULL;
	char *erc_released_date,*erc_released_datestr=NULL;
	char *designer_erc,*designer_ercstr	=NULL;
	
	lifecycle_statestr = (char *)MEM_alloc(200 * sizeof(char));
	serial_num = (char *) MEM_alloc( 10 * sizeof(char) );
	Project_idstr = (char *)MEM_alloc(100 * sizeof(char));
	design_groupstr = (char *)MEM_alloc(100 * sizeof(char));
	apl_dml_numberStr = (char *)MEM_alloc(100 * sizeof(char));
	dml_descstr = (char *)MEM_alloc(300 * sizeof(char));
	Reasonstr = (char *)MEM_alloc(100 * sizeof(char));
	DRStatusstr = (char *)malloc(100 * sizeof(char));
	erc_released_datestr=(char *)malloc(100 * sizeof(char));
	designer_ercstr=(char *)malloc(100 * sizeof(char));

	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));

	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_delete("find_Dml_Number"));

	printf("Check 1\n");fflush(stdout);
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"<APLDMLBetweenDateReport>");
	
	if(rows > 0)
	{
		char item_id_val_copy[5]={'\0'};
		char *item_id_tokenized	=NULL;
		 tag_t	query		= NULLTAG;
		 int	n_found		= 0;
		 tag_t	*t_item1	= NULLTAG;
		 int num;
		int	taskcount= 0;
		tag_t *taskList = NULLTAG;
		int srno = 0;
		int flgOther = 0;
		for (ii = 0; ii < rows; ii++ )
		{

			
			objtag  = *(tag_t*)(report[ii][0]);
			CALLAPI(AOM_UIF_ask_value(objtag,"release_status_list",&lifecycle_state);fflush(stdout));
			printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
			
			int st_count		=	0;
			tag_t*			status_list			=	NULLTAG;
			int iStCnt		=	0;
			CALLAPI(WSOM_ask_release_status_list(objtag,&st_count,&status_list));
			printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
			int cntFlg =0;
			if(st_count>0)
			{
				for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsAplRlzd
				{
					char* c_st_class_name	=	NULL;
					char* c_st_ObjType	=	NULL;
					CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
					printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_type",&c_st_ObjType));
					printf("\n rlz status object_type: %s\n",c_st_ObjType);fflush(stdout);	
					//printObject(status_list[iStCnt]);	
					if(tc_strcmp(c_st_class_name,"T5_LcsAplRlzd")==0 && tc_strcmp(releaseStatusStr,"APL Released")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(c_st_class_name,"T5_LcsStdRlzd")==0 && tc_strcmp(releaseStatusStr,"STD Released")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);	
						flgOther++;
						break;	
					}
					else if((tc_strcmp(c_st_class_name,"T5_LcsAPLWrkg")==0 ||  tc_strcmp(c_st_class_name,"T5_LcsAplReview")==0)&& tc_strcmp(releaseStatusStr,"APLPENDING")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(c_st_class_name,"T5_LcsSTDWrkg")==0  && tc_strcmp(releaseStatusStr,"STDPENDING")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(releaseStatusStr,"ALL Status")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;

					}	
					else
					{
						cntFlg = 1;
						break;
					}
											
					
				}
			}
			else
			{
				if(tc_strcmp(releaseStatusStr,"ALL Status")==0)
				{
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
					sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
					setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);

				}		
				else
				{
					
					printf("\n No status attached to the DML....\n");fflush(stdout);
					continue;	
				}
			}
			if(cntFlg ==1)
			{
				continue;
			}
			
		
			
			if(Planner != NULL)
			{
				
			}
			srno = srno + 1;
			sprintf(serial_num,"<SrNo>%d</SrNo>",srno);
			setAddStr(buff_cnt,bufferedXmlStrOut,serial_num);
					  
			CALLAPI(AOM_ask_value_string(objtag,"item_id",&apl_dml_number));

			printf("\n--->>>>> apl_dml_number>>==%s\n",apl_dml_number);fflush(stdout);
			sprintf(apl_dml_numberStr,"<DML_Number>%s</DML_Number>",apl_dml_number);
			setAddStr(buff_cnt,bufferedXmlStrOut,apl_dml_numberStr);	
			
			CALLAPI(AOM_ask_value_string(objtag,"object_desc", &dml_desc));
			printf("\n--->>>>> object_desc_val>>==%s\n",dml_desc);fflush(stdout);
			sprintf(dml_descstr,"<DML_Description>%s</DML_Description>",dml_desc);
			setAddStr(buff_cnt,bufferedXmlStrOut,dml_descstr);	
			
		
			int resCnt =0;
			char** Reasons = NULL;
			CALLAPI(AOM_ask_displayable_values(objtag,"t5_reason",&resCnt, &Reasons));
			if(resCnt>0) 
				Reason = Reasons[0];
			//CALLAPI(AOM_ask_value_string(objtag,"t5_reason",&Reason));
			printf("\n--->>>>> Reason_val>>==%s\n",Reason);fflush(stdout);
			sprintf(Reasonstr,"<Reason_Description>%s</Reason_Description>",Reason);
			setAddStr(buff_cnt,bufferedXmlStrOut,Reasonstr);			
			
			CALLAPI(AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id));
			if(tc_strcmp(Project_id,"") != 0 || Project_id !=NULL)
			{
				sprintf(Project_idstr,"<Project_Code>%s</Project_Code>",Project_id);
			    setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
			}
			else
			{
				sprintf(Project_idstr,"<Project_Code>%s</Project_Code>","");
			    setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
			}


			CALLAPI(AOM_ask_value_strings(objtag,"t5_crdesigngroup",&num,&design_group));
			if(num>0)
			{
			   printf("\n--->>>>> DesignGroup_val>>==%s\n",design_group[0]);fflush(stdout);
			   sprintf(design_groupstr,"<Design_Group>%s</Design_Group>",design_group[0]);

			}
			else
			   sprintf(design_groupstr,"<Design_Group>NA</Design_Group>");
			  setAddStr(buff_cnt,bufferedXmlStrOut,design_groupstr);				
			
			CALLAPI(AOM_ask_value_string(objtag,"t5_cDRstatus", &DRStatus));
			printf("\n--->>>>> DRStatus_val>>==%s\n",DRStatus);fflush(stdout);
			sprintf(DRStatusstr,"<DR_Status>%s</DR_Status>",DRStatus);
			setAddStr(buff_cnt,bufferedXmlStrOut,DRStatusstr);
			
			tc_strcpy(item_id_val_copy,apl_dml_number);
			
			/*Finding ERC DML from APL DML**/
			item_id_tokenized=strtok(item_id_val_copy,"_");
			printf("Tokenized DML Number Obtained=%s\n",item_id_tokenized);
			
			//Using Query Builder to get ERC DML and then Release Date from there.....
			char *qry_entries3[] = {"ID"};
			char *qry_values3[] = {item_id_tokenized};
			qry_values3[0]=item_id_tokenized;
			
			CALLAPI(QRY_find("ERC DML", &query));
			CALLAPI(QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1));
			if(n_found!=0)
			{
				
				printf("Found an ERC DML\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(t_item1[0] ,"item_id", &dml_number_erc));
				
				printf("ERC DML Found=%s\n",dml_number_erc);fflush(stdout);
				
				CALLAPI(AOM_UIF_ask_value(t_item1[0],"date_released",&erc_released_date));
				printf("ERC Released Date found=%s\n",erc_released_date);fflush(stdout);
				
				sprintf(erc_released_datestr,"<ERC_Released_Date>%s</ERC_Released_Date>",erc_released_date);
				setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
				printf("ERC Released Date obtained=%s\n",erc_released_datestr);fflush(stdout);
			
				CALLAPI(AOM_ask_value_string(t_item1[0] ,"requestor_user_id", &designer_erc));
				
				printf("Designer Obtined=%s\n",designer_erc);
				sprintf(designer_ercstr,"<Designer>%s</Designer>",designer_erc);
				setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
			}
			else//Does not have erc dml may be AM/SM dml
			{
				sprintf(erc_released_datestr,"<ERC_Released_Date>NA</ERC_Released_Date>");
				setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
				sprintf(designer_ercstr,"<Designer>NA</Designer>");
				setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
				
			}
								
			//Logic for EPA details
			int epaNochk =0;
			int epaStatusChk =0;
			int epaFinalizedDateChk = 0;
			setFindStr(additional_attrs,colmnLen,"EPA No",&epaNochk);
			setFindStr(additional_attrs,colmnLen,"EPA Status",&epaStatusChk);
			setFindStr(additional_attrs,colmnLen,"EPA Finalized Date",&epaFinalizedDateChk);
			if(epaNochk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number>NA</EPA_Number>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number></EPA_Number>");
			}
			if(epaStatusChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status>NA</EPA_Status>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status></EPA_Status>");
			}
			if(epaFinalizedDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date>NA</EPA_finalized_Date>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date></EPA_finalized_Date>");
			}
					
			//Logic for Indent with SOR Details
			/*		indentList.add("Indent Reviewer");
			indentList.add("Indent Creation Date");
			indentList.add("Indent Approval Date");
			indentList.add("Indent Status");
			indentList.add("Indent Comments");
			//data.put("Indent Details", indentList);
			data.put("Indent with SOR Details", indentList);//Indent with SOR Details*/
			
			int indentReviewerChk =0;
			int indentCreDateChk =0;
			int indentApprDateChk =0;
			int indentStatusChk =0;
			int indentCommentsChk =0;
			setFindStr(additional_attrs,colmnLen,"Indent Reviewer",&indentReviewerChk);
			setFindStr(additional_attrs,colmnLen,"Indent Creation Date",&indentCreDateChk);
			setFindStr(additional_attrs,colmnLen,"Indent Approval Date",&indentApprDateChk);		  
			setFindStr(additional_attrs,colmnLen,"Indent Status",&indentStatusChk);
			setFindStr(additional_attrs,colmnLen,"Indent Comments",&indentCommentsChk);	
			if(indentReviewerChk ==1)
			{
				//Need to implement the logic later
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Reviewer>NA</Indent_Reviewer>");
			}
			else
			{
				//Need to implement the logic later
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Reviewer></Indent_Reviewer>");
			}
			if(indentCreDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_CreDate>NA</Indent_CreDate>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_CreDate></Indent_CreDate>");
			}
			if(indentApprDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_ApprDate>NA</Indent_ApprDate>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_ApprDate></Indent_ApprDate>");
			}			
			if(indentStatusChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Status>NA</Indent_Status>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Status></Indent_Status>");
			}
			
			if(indentCommentsChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Comments>NA</Indent_Comments>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Comments></Indent_Comments>");
			}			


		
//Task logic		
			CALLAPI(AOM_ask_value_tags(objtag,"T5_DMLTaskRelation",&taskcount,&taskList));
			printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
			
			if(taskcount > 0)
			{
				int i;

				for(i=0;i<taskcount;i++)
				{	
					tag_t task=taskList[i];
					char* apl_task_class = NULL;
					
					CALLAPI(AOM_ask_value_string(task,"object_type",&apl_task_class));
					printf("\nTask class======================================>%s\n", apl_task_class);fflush(stdout);
					if(tc_strcmp(apl_task_class,"T5_APLTaskRevision")!=0)
					{
						printf("\nTask class is not T5_APLTaskRevision. It is: %s\n", apl_task_class);fflush(stdout);
						continue;
					}

					setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");	
					int  count_release_status =0; 
					tag_t *release_status_object=NULLTAG;
					char  name[WSO_name_size_c+1]    = {'\0'};
					int flagApl =0;
					int flagStd = 0;
					char* apl_task_number = NULL;
					char* task_number_str=NULL;
					task_number_str=(char*)malloc(100*sizeof(char));
					
					
					CALLAPI(AOM_ask_value_string(task,"item_id",&apl_task_number));
					printf("\nTask number: %s\n", apl_task_number);fflush(stdout);
					
					
					sprintf(task_number_str,"<Task_Number>%s</Task_Number>",apl_task_number);
					setAddStr(buff_cnt,bufferedXmlStrOut,task_number_str);
					
					printf("\nBefore Release Status Count\n");fflush(stdout);
					CALLAPI(WSOM_ask_release_status_list(task,&count_release_status,&release_status_object));
					printf("After Release Status Count\n");fflush(stdout);
					printf("Release Status Count Obtained=%d\n",count_release_status);fflush(stdout);	
					if(count_release_status>0)
					{	
						int k;
						int cnt =0;
						int cnt1 = 0;
						for(k=0;k<count_release_status;k++)
						{
							char* date_rel=NULL;
							char* date_relstr=NULL;

							date_relstr=(char*)malloc(100*sizeof(char));
							char* date_relstr1=NULL;
							date_relstr1=(char*)malloc(100*sizeof(char));
							tag_t release_status = release_status_object[k];
							CALLAPI(CR_ask_release_status_type(release_status,name));
							printf("Release Status Name obtained=%s\n",name);fflush(stdout);

							if(tc_strcmp(name,"T5_LcsAplRlzd")==0)
							{
								CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
								//CALLAPI(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
								printf("APL Released Date=%s\n",date_rel);fflush(stdout);


								if(cnt ==0)
								{
									sprintf(date_relstr,"<APL_released_Date>%s</APL_released_Date>",date_rel);
									setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
									flagApl = 1;
								}
										
								cnt++;							
								
							}
							else if(tc_strcmp(name,"T5_LcsStdRlzd")==0)
							{
								CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
								printf("STD Released Date=%s\n",date_rel);fflush(stdout);						
								if(cnt1 ==0)
								{
									sprintf(date_relstr1,"<STD_Release_Date>%s</STD_Release_Date>",date_rel);
									setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr1);
									flagStd = 1;
								}
									
									
								cnt1++;
								
							}

							if(date_relstr!=NULL)free(date_relstr);	
							if(date_relstr1!=NULL)free(date_relstr1);							
						}
						
						char* date_relstr2=NULL;
						date_relstr2=(char*)malloc(100*sizeof(char));
						char* date_relstr3=NULL;
						date_relstr3=(char*)malloc(100*sizeof(char));
						
						if(flagApl ==0 && flagStd ==1)
						{
							sprintf(date_relstr2,"<APL_released_Date>NA</APL_released_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr2);
						}
						else if(flagStd ==0 && flagApl ==1)
						{
							sprintf(date_relstr3,"<STD_Release_Date>NA</STD_Release_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr3);	
						
						}
						else if(flagStd ==0 && flagApl ==0)
						{
							sprintf(date_relstr2,"<APL_released_Date>NA</APL_released_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr2);
							sprintf(date_relstr3,"<STD_Release_Date>NA</STD_Release_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr3);	
						}					
						if(date_relstr2!=NULL)free(date_relstr2);	
						if(date_relstr3!=NULL)free(date_relstr3);	

					}
					else
					{
						//char* date_rel=NULL;
						char* date_relstr=NULL;
						date_relstr=(char*)malloc(100*sizeof(char));
						char* date_relstr1=NULL;
						date_relstr1=(char*)malloc(100*sizeof(char));
						
					
						sprintf(date_relstr,"<APL_released_Date>NA</APL_released_Date>");
						setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
						sprintf(date_relstr1,"<STD_Release_Date>NA</STD_Release_Date>");
						setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr1);	

		
						if(date_relstr!=NULL)free(date_relstr);	
						if(date_relstr1!=NULL)free(date_relstr1);	
					}
					
					/****************************************/
					//From poonam code logic...
					char        *TaskAplWrkOnDML           = NULL;
					char        *TaskAplRev           = NULL;
					char        *TaskSTDCreEPA           = NULL;
					char        *TaskSTDRev           = NULL;
					TaskAplWrkOnDML = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskAplRev = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDCreEPA = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDRev = (char *) MEM_alloc( 100 * sizeof(char) );

					tc_strcpy(TaskAplWrkOnDML,"");
					tc_strcpy(TaskAplRev,"");
					tc_strcpy(TaskSTDCreEPA,"");
					tc_strcpy(TaskSTDRev,"");
						
					
					//CALLAPI(QueryWorkFl(task,TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev));
					CALLAPI(QueryAplParticipants(task,TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev));
					
					printf("\n  Process His of APL/STD Planner and rev: APLWorkOnDML[%s] APL REv[%s] STD Create EPA [%s] STD Rev[%s] \n",TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev); fflush(stdout);
					
					if(TaskAplWrkOnDML==NULL || tc_strcmp(TaskAplWrkOnDML,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<AplPlanner>NA</AplPlanner>");
					}
					else
					{
						char* aplPlannerStr =(char*)malloc(150*sizeof(char));
						sprintf(aplPlannerStr,"<AplPlanner>%s</AplPlanner>", TaskAplWrkOnDML);
						setAddStr(buff_cnt,bufferedXmlStrOut,aplPlannerStr);
						if(aplPlannerStr != NULL) free(aplPlannerStr);
					}
					
					if(TaskSTDCreEPA==NULL || tc_strcmp(TaskSTDCreEPA,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<StdPlanner>NA</StdPlanner>");
					}
					else
					{
						char* stdPlannerStr =(char*)malloc(100*sizeof(char));
						sprintf(stdPlannerStr,"<StdPlanner>%s</StdPlanner>", TaskSTDCreEPA);
						setAddStr(buff_cnt,bufferedXmlStrOut,stdPlannerStr);
						if(stdPlannerStr != NULL) free(stdPlannerStr);
					}
					if(TaskAplRev==NULL || tc_strcmp(TaskAplRev,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<AplRev>NA</AplRev>");
					}
					else
					{
						char* aplReviewerStr =(char*)malloc(100*sizeof(char));
						sprintf(aplReviewerStr,"<AplRev>%s</AplRev>", TaskAplRev);
						setAddStr(buff_cnt,bufferedXmlStrOut,aplReviewerStr);
						if(aplReviewerStr != NULL) free(aplReviewerStr);
					}
					if(TaskSTDRev==NULL || tc_strcmp(TaskSTDRev,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<StdRev>NA</StdRev>");
					}
					else
					{
						char* stdReviewerStr =(char*)malloc(100*sizeof(char));
						sprintf(stdReviewerStr,"<StdRev>%s</StdRev>", TaskSTDRev);
						setAddStr(buff_cnt,bufferedXmlStrOut,stdReviewerStr);
						if(stdReviewerStr != NULL) free(stdReviewerStr);
					}	
					
					if(TaskAplWrkOnDML != NULL) MEM_free(TaskAplWrkOnDML);
					if(TaskAplRev != NULL) MEM_free(TaskAplRev);
					if(TaskSTDCreEPA != NULL) MEM_free(TaskSTDCreEPA);
					if(TaskSTDRev != NULL) MEM_free(TaskSTDRev);
		
					//Part tags...
					int	partcount = 0;
					tag_t *PartList = NULLTAG;
					
					CALLAPI(AOM_ask_value_tags(task,"CMHasSolutionItem",&partcount,&PartList));	
					if(partcount>0)
					{
						int k;
						char *partnumber,*partnumberstr		=NULL;
						char *revision_id =NULL;
						char revision_id_cpy[2]={'\0'};
						char *revision_id_tokenized,*revision_id_tokenizedstr=NULL;
						int sequence;
						char *sequence_numberstr =NULL;
						char *PartDescription,*PartDescriptionstr=NULL;
						
						revision_id_tokenizedstr = (char *)malloc(100 * sizeof(char));				
						partnumberstr = (char *)malloc(100 * sizeof(char));
						sequence_numberstr = (char *)malloc(100 * sizeof(char));
						//PartDescriptionstr =(char *) malloc(100 * sizeof(char));
						
						char* partType = NULL;
						int designCnt = 0;
						for(k=0;k<partcount;k++)
						{
							
							CALLAPI(AOM_ask_value_string(PartList[k] ,"object_type",&partType));
							printf("Part Type: %s\n",partType);fflush(stdout);
							
							
							if(tc_strcmp(partType,"Design Revision")==0)
							{
								designCnt++;
								setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
								CALLAPI(AOM_ask_value_string(PartList[k] ,"item_id",&partnumber));
								printf("Part Number Found for Part =%s\n",partnumber);fflush(stdout);
								sprintf(partnumberstr,"<Part_Number>%s</Part_Number>",partnumber);
								setAddStr(buff_cnt,bufferedXmlStrOut,partnumberstr);

								CALLAPI(AOM_ask_value_string(PartList[k] ,"item_revision_id",&revision_id));
								printf("Revision Found for Part =%s\n",revision_id);fflush(stdout);

								tc_strcpy(revision_id_cpy,revision_id);
								revision_id_tokenized=strtok(revision_id_cpy,";");
								printf("Tokenized Revision Id=%s\n",revision_id_tokenized);fflush(stdout);
								sprintf(revision_id_tokenizedstr,"<Revision>%s</Revision>",revision_id_tokenized);
								setAddStr(buff_cnt,bufferedXmlStrOut,revision_id_tokenizedstr);

								CALLAPI(AOM_ask_value_int(PartList[k],"sequence_id",&sequence));
								printf("Sequence Found for Part  =%d\n",sequence);fflush(stdout);
								sprintf(sequence_numberstr,"<Sequence>%d</Sequence>",sequence);
								setAddStr(buff_cnt,bufferedXmlStrOut,sequence_numberstr);	
								
								//Sor logic
								int sorNumChk =0;
								int sorPPPMProjStatChk =0;
								int sorCatChk =0;
								int refPartNumChk =0;
								int refSorNumChk =0;
								
								int sorDmlNumChk =0;
								int sorPppmProjCodeChk =0;
								int sorReviewerChk =0;
								int starSorNumChk =0;
								int sorRejFlagChk =0;	
								
								int sorRemarkChk =0;
								int sorVariantChk =0;			
								
								setFindStr(additional_attrs,colmnLen,"SOR Number",&sorNumChk);
								setFindStr(additional_attrs,colmnLen,"PPPM Project Status",&sorPPPMProjStatChk);
								setFindStr(additional_attrs,colmnLen,"SOR Category",&sorCatChk);		  
								setFindStr(additional_attrs,colmnLen,"Ref Part Number",&refPartNumChk);
								setFindStr(additional_attrs,colmnLen,"Ref SOR Number",&refSorNumChk);	
								
								setFindStr(additional_attrs,colmnLen,"SOR Dml Number",&sorDmlNumChk);
								setFindStr(additional_attrs,colmnLen,"PPPM Project Code",&sorPppmProjCodeChk);
								setFindStr(additional_attrs,colmnLen,"SOR Reviewer",&sorReviewerChk);		  
								setFindStr(additional_attrs,colmnLen,"Star SOR Number",&starSorNumChk);
								setFindStr(additional_attrs,colmnLen,"SOR Rejection Flag",&sorRejFlagChk);			
								setFindStr(additional_attrs,colmnLen,"SOR Remark",&sorRemarkChk);
								setFindStr(additional_attrs,colmnLen,"SOR Variant",&sorVariantChk);	
								
								//Sor logic if the below condn true
								if(sorNumChk ==1 || sorPPPMProjStatChk ==1 ||  sorCatChk ==1 || refPartNumChk ==1 || refSorNumChk==1 || sorDmlNumChk == 1 || sorPppmProjCodeChk == 1 || sorReviewerChk == 1 || starSorNumChk ==1 || sorRejFlagChk == 1 || sorVariantChk== 1)
								{
									printf("\nInside Sor logic.........\n");fflush(stdout);
									int sorCnt = 0;
									tag_t *sorObjList = NULLTAG;
									tag_t relatnTypeSor_tag   = NULLTAG;
									int cntr = 0;
									//CALLAPI(AOM_ask_value_tags(PartList[k],"T5_PartSorRel",&sorCnt,&sorObjList));	
									//CALLAPI(GRM_find_relation_type("T5_PartSorRel",&relatnTypeSor_tag));
									CALLAPI(GRM_find_relation_type("IMAN_specification",&relatnTypeSor_tag));
									if(relatnTypeSor_tag != NULLTAG)
									{
										printf("\nInside Sor logic1.........\n");fflush(stdout);
										CALLAPI(GRM_list_secondary_objects_only(PartList[k], relatnTypeSor_tag, &sorCnt, &sorObjList));
										//CALLAPI(GRM_list_primary_objects_only(PartList[k], relatnTypeSor_tag, &sorCnt, &sorObjList));
										printf("\nSor count for the Part(%s)=============>%d\n",partnumber,sorCnt);fflush(stdout);
										
										if(sorCnt>0)
										{
											
											char* sorNumber = NULL;
											char* sorNumberStr = (char *)MEM_alloc(100 * sizeof(char));
											char* pppmProjStatus = NULL;
											char* pppmProjStatusStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorCategory = NULL;
											char* sorCategoryStr = (char *)MEM_alloc(100 * sizeof(char));
											char* refPartNum = NULL;
											char* refPartNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* refSorNum = NULL;
											char* refSorNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorDmlNum = NULL;
											char* sorDmlNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* pppmProjCode = NULL;
											char* pppmProjCodeStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorReviewer = NULL;
											char* sorReviewerStr = (char *)MEM_alloc(100 * sizeof(char));
											char* starSorNum = NULL;
											char* starSorNumStr = (char *)MEM_alloc(100 * sizeof(char));
											logical sorRejFlag = false;
											char* sorRejFlagStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorRemark = NULL;
											char* sorRemarkStr = (char *)MEM_alloc(100 * sizeof(char));
											char** variantNames = NULL;
											char* variantNameStr = (char *)MEM_alloc(300 * sizeof(char));										

											for(cntr = 0; cntr< sorCnt ;cntr++)
											{
												
												char* sorObjType;
												tag_t sorObj = 	sorObjList[cntr];
												CALLAPI(AOM_ask_value_string(sorObj ,"object_type",&sorObjType));
												printf("\nSOR class======================================>%s\n", sorObjType);fflush(stdout);
												if(tc_strcmp(sorObjType,"T5_AutoSorRevision")==0)
												{
													setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
													
													//CALLAPI(AOM_ask_value_logical(sorObj,"t5_RejFlag",&sorRejFlag));
												
													CALLAPI(AOM_ask_value_string(sorObj ,"item_id",&sorNumber));
													printf("SOR Number Found for Part =%s\n",sorNumber);fflush(stdout);
													if(sorNumber != NULL)
													{
														sprintf(sorNumberStr,"<Sor_Number>%s</Sor_Number>",sorNumber);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorNumberStr);
													}										
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number>NA</Sor_Number>");
													}

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_PPPMProjStatus",&pppmProjStatus));
													printf("PPPM Proj status =%s\n",pppmProjStatus);fflush(stdout);
													if(pppmProjStatus!=NULL)
													{
														sprintf(pppmProjStatusStr,"<Sor_PppmProjStat>%s</Sor_PppmProjStat>",pppmProjStatus);
														setAddStr(buff_cnt,bufferedXmlStrOut,pppmProjStatusStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat>NA</Sor_PppmProjStat>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorCat",&sorCategory));
													printf("sorCategory =%s\n",sorCategory);fflush(stdout);
													if(sorCategory!=NULL)
													{
														sprintf(sorCategoryStr,"<Sor_Category>%s</Sor_Category>",sorCategory);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorCategoryStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category>NA</Sor_Category>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_RefPrtNum",&refPartNum));
													printf("refPartNum =%s\n",refPartNum);fflush(stdout);
													if(refPartNum!=NULL)
													{
														sprintf(refPartNumStr,"<Sor_refPartNum>%s</Sor_refPartNum>",refPartNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,refPartNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum>NA</Sor_refPartNum>");
													}	

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_RefSOR",&refSorNum));
													printf("refSorNum =%s\n",refSorNum);fflush(stdout);
													if(refSorNum!=NULL)
													{
														sprintf(refSorNumStr,"<Sor_refSorNum>%s</Sor_refSorNum>",refSorNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,refSorNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum>NA</Sor_refSorNum>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_DmlNumber",&sorDmlNum));
													printf("sorDmlNum =%s\n",sorDmlNum);fflush(stdout);
													if(sorDmlNum!=NULL)
													{
														sprintf(sorDmlNumStr,"<Sor_dmlNum>%s</Sor_dmlNum>",sorDmlNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorDmlNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum>NA</Sor_dmlNum>");
													}												

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_PPPMPrjCode",&pppmProjCode));
													printf("pppmProjCode =%s\n",refPartNum);fflush(stdout);
													if(pppmProjCode!=NULL)
													{
														sprintf(pppmProjCodeStr,"<Sor_pppmProjCode>%s</Sor_pppmProjCode>",pppmProjCode);
														setAddStr(buff_cnt,bufferedXmlStrOut,pppmProjCodeStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode>NA</Sor_pppmProjCode>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorReviewer",&sorReviewer));
													printf("sorReviewer =%s\n",sorReviewer);fflush(stdout);
													if(sorReviewer!=NULL)
													{
														sprintf(sorReviewerStr,"<Sor_reviewer>%s</Sor_reviewer>",sorReviewer);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorReviewerStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer>NA</Sor_reviewer>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_StarSorNum",&starSorNum));
													printf("starSorNum =%s\n",starSorNum);fflush(stdout);
													if(starSorNum!=NULL)
													{
														sprintf(starSorNumStr,"<Sor_starSorNum>%s</Sor_starSorNum>",starSorNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,starSorNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum>NA</Sor_starSorNum>");
													}
													CALLAPI(AOM_ask_value_logical(sorObj,"t5_RejFlag",&sorRejFlag));
													printf("sorRejFlag =%d\n",sorRejFlag);fflush(stdout);
													sprintf(sorRejFlagStr,"<Sor_RejFlag>%d</Sor_RejFlag>",sorRejFlag);
													setAddStr(buff_cnt,bufferedXmlStrOut,sorRejFlagStr);

			
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorRemark",&sorRemark));
													printf("sorRemark =%s\n",sorRemark);fflush(stdout);
													if(sorRemark!=NULL)
													{
														sprintf(sorRemarkStr,"<Sor_Remark>%s</Sor_Remark>",sorRemark);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorRemarkStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark>NA</Sor_Remark>");
													}
													int varSz = 0;
													int varCnt =0;
													CALLAPI(AOM_ask_value_strings(sorObj ,"t5_VariantName",&varSz, &variantNames));
													for(varCnt =0; varCnt<varSz; varCnt++)
													{
														printf("variantName[%d] =%s\n",varCnt,variantNames[varCnt]);fflush(stdout);
													}
													
													if(varCnt>0)
													{
														sprintf(variantNameStr,"<Sor_Variant>%s</Sor_Variant>",variantNames[0]);
														setAddStr(buff_cnt,bufferedXmlStrOut,variantNameStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant>NA</Sor_Variant>");
													}												
													setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");												
														
												}
												else
												{
													printf("\nSOR class is not T5_AutoSorRevision. It is: %s\n", sorObjType);fflush(stdout);
													setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
													setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
												}
												
												
												
											}
											if(sorNumberStr!=NULL) MEM_free(sorNumberStr);
											if(pppmProjStatusStr!=NULL) MEM_free(pppmProjStatusStr);
											if(sorCategoryStr!=NULL) MEM_free(sorCategoryStr);
											if(refPartNumStr!=NULL) MEM_free(refPartNumStr);
											if(refSorNumStr!=NULL) MEM_free(refSorNumStr);
											if(sorDmlNumStr!=NULL) MEM_free(sorDmlNumStr);
											if(pppmProjCodeStr!=NULL) MEM_free(pppmProjCodeStr);
											if(sorReviewerStr!=NULL) MEM_free(sorReviewerStr);
											if(starSorNumStr!=NULL) MEM_free(starSorNumStr);
											if(sorRejFlagStr!=NULL) MEM_free(sorRejFlagStr);
											if(sorRemarkStr!=NULL) MEM_free(sorRemarkStr);
											if(variantNameStr!=NULL) MEM_free(variantNameStr);
											
										}
										else
										{
											
											setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");										
										}
										
									}
																
								}								
								else
								{
									printf("\nOutside Sor logic.........\n");fflush(stdout);
									setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
								}
												
								setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");	
							}
							else
							{
								if(designCnt == 0)
								{
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Number></Part_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Revision></Revision>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sequence></Sequence>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
									
								}
								
							}
											
						}
						if(partnumberstr != NULL) free(partnumberstr);
						if(revision_id_tokenizedstr != NULL) free(revision_id_tokenizedstr);
						if(sequence_numberstr != NULL) free(sequence_numberstr);
						
					}
					else
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Number></Part_Number>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Revision></Revision>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sequence></Sequence>");
						
						setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");


						setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
					}


					
					setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
					if(task_number_str != NULL) free(task_number_str);
				}	//end for loop task	
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
			}



		
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
			
			

			

		}
		printf("\n flgOther=====================>%d\n", flgOther);fflush(stdout);
		if(flgOther == 0)
		{
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");	
		}
		
		
	}
	else
	{
		
		printf("\n NO DML found for the given criteria...\n");fflush(stdout);
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
		
		
	}
	setAddStr(buff_cnt,bufferedXmlStrOut,"</APLDMLBetweenDateReport>");

	if(dml_descstr != NULL) MEM_free(dml_descstr);
	if(apl_dml_numberStr != NULL) MEM_free(apl_dml_numberStr);
	if(design_groupstr != NULL) MEM_free(design_groupstr);
	if(Project_idstr != NULL) MEM_free(Project_idstr);
	if(serial_num != NULL) MEM_free(serial_num);
	if(lifecycle_statestr != NULL) MEM_free(lifecycle_statestr);
	if(Reasonstr != NULL) MEM_free(Reasonstr);
	
	return ifail;
	
	
}




int dmlReleaseBetweenDates_new( char* Datefrom, char* Dateto, char* releaseStatusStr, char* Plant, int projlen, char** Project_code_ids, int colmnLen, char** additional_attrs, char* Planner, char*** bufferedXmlStrOut, int *buff_cnt  )
{
	int ifail = ITK_ok;
	int k;
	date_t   a_date_from;
	date_t   a_date_to;	
	date_t   vals[2];	
	
	const char *Plant_received[]={Plant};
	const char * select_attrs[]={"puid"};
	
	printf("Plant recieved in Function=%s\n",Plant);fflush(stdout);
	printf("From Date=%s\n",Datefrom);fflush(stdout);
	printf("To Date=%s\n",Dateto);fflush(stdout);
	
	ITK_string_to_date(Datefrom,&a_date_from);
	ITK_string_to_date(Dateto,&a_date_to);

	vals[0]=a_date_from;
	vals[1]=a_date_to;
	

	for(k=0;k<projlen;k++)
	{
		
		printf("\n Project[%d]==[%s]",k+1,Project_code_ids[k]);
		
	}
	printf("Argument Received Datefrom(dmlReleaseBetweenDates_new) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received Dateto(dmlReleaseBetweenDates_new) =%s\n",Dateto);fflush(stdout);
	printf("Release Status Received (dmlReleaseBetweenDates_new) =%s\n",releaseStatusStr);fflush(stdout);
	printf("Plant Received (dmlReleaseBetweenDates_new) =%s\n",Plant);fflush(stdout);
	
	
	printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
	
	/** Creating a POM Query **/
	CALLAPI(POM_enquiry_create("find_Dml_Number"));
	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
	
	/** Adding select attribute to Query **/
	CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));
	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
	
	/**Setting Released Date **/
	CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
	
	if(tc_strcmp(releaseStatusStr,"APL Released")==0 || tc_strcmp(releaseStatusStr,"STD Released")==0)
	{
		/** creating between Expression **/
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","date_released",POM_enquiry_between,"expr_dates"));
	}
	else 
	{
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","creation_date",POM_enquiry_between,"expr_dates"));
	}
	
	printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
	 /**Need to Check if Plant received if Plant is Null then go for Project Codes**/
	if(((tc_strcmp(Plant,"")==0 || Plant == NULL)) && projlen>0)
	{
		printf("Entered into Project list Section\n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Project list Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
	}
	else if((tc_strcmp(Plant,"")!=0) && projlen==0)
	{
		printf("Entered into Plant Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );

		printf("Check 2\n");fflush(stdout);		
	}
	else  if((tc_strcmp(Plant,"")!=0) && projlen >0){
		printf("Both Plant and project not null.... \n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		//POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );	


		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression2","expr_AND_expression1",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Plant & project Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression2"));		

		printf("Check 2222\n");fflush(stdout);				

		
	}
	else
	{
		printf("Both Plant and project  null.... Need to implement the logic\n");fflush(stdout);
	}
	
	char *lifecycle_state = NULL;
	tag_t objtag =NULLTAG;
	int  rows = 0, columns = 0;
	void ***report;
	int ii, num=0;
	char * Project_id = NULL;
	char **design_group=NULL;
	char* apl_dml_number = NULL;
	char* dml_desc = NULL;
	
	char* lifecycle_statestr = NULL;
	char* serial_num = NULL;
	char* Project_idstr = NULL;
	char* design_groupstr = NULL;
	char* apl_dml_numberStr = NULL;
	char* dml_descstr = NULL;	
	char *Reason,*Reasonstr					=NULL;
	char * DRStatus,* DRStatusstr  = NULL;
	char *dml_number_erc =NULL;
	char *erc_released_date,*erc_released_datestr=NULL;
	char *designer_erc,*designer_ercstr	=NULL;
	
	lifecycle_statestr = (char *)MEM_alloc(200 * sizeof(char));
	serial_num = (char *) MEM_alloc( 10 * sizeof(char) );
	Project_idstr = (char *)MEM_alloc(100 * sizeof(char));
	design_groupstr = (char *)MEM_alloc(100 * sizeof(char));
	apl_dml_numberStr = (char *)MEM_alloc(100 * sizeof(char));
	dml_descstr = (char *)MEM_alloc(300 * sizeof(char));
	Reasonstr = (char *)MEM_alloc(100 * sizeof(char));
	DRStatusstr = (char *)malloc(100 * sizeof(char));
	erc_released_datestr=(char *)malloc(100 * sizeof(char));
	designer_ercstr=(char *)malloc(100 * sizeof(char));

	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));

	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_delete("find_Dml_Number"));

	printf("Check 1\n");fflush(stdout);
	
	setAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
	setAddStr(buff_cnt,bufferedXmlStrOut,"<APLDMLBetweenDateReport>");
	
	printf("\ndmlReleaseBetweenDates_new....After POM query execution....No of ROWs=====>%d",rows);fflush(stdout);
	if(rows > 0)
	{
		char item_id_val_copy[5]={'\0'};
		char *item_id_tokenized	=NULL;
		 tag_t	query		= NULLTAG;
		 int	n_found		= 0;
		 tag_t	*t_item1	= NULLTAG;
		 int num;
		int	taskcount= 0;
		tag_t *taskList = NULLTAG;
		int srno = 0;
		int flgOther = 0;
		for (ii = 0; ii < rows; ii++ )
		{

			
			objtag  = *(tag_t*)(report[ii][0]);
			if(objtag==NULLTAG)
			{
				printf("\n dmlReleaseBetweenDates_new : Null Tag so skipping.......\n");fflush(stdout);
				continue;
			}
			CALLAPI(AOM_UIF_ask_value(objtag,"release_status_list",&lifecycle_state);fflush(stdout));
			printf("\n--->>>>> ReleaseStatus_val>>==%s\n",lifecycle_state);fflush(stdout);//Need to check if APL Released........
			
			int st_count		=	0;
			tag_t*			status_list			=	NULLTAG;
			int iStCnt		=	0;
			CALLAPI(WSOM_ask_release_status_list(objtag,&st_count,&status_list));
			printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
			int cntFlg =0;
			if(st_count>0)
			{
				for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsAplRlzd
				{
					char* c_st_class_name	=	NULL;
					char* c_st_ObjType	=	NULL;
					CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
					printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
					
					CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_type",&c_st_ObjType));
					printf("\n rlz status object_type: %s\n",c_st_ObjType);fflush(stdout);	
					//printObject(status_list[iStCnt]);	
					if(tc_strcmp(c_st_class_name,"T5_LcsAplRlzd")==0 && tc_strcmp(releaseStatusStr,"APL Released")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(c_st_class_name,"T5_LcsStdRlzd")==0 && tc_strcmp(releaseStatusStr,"STD Released")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);	
						flgOther++;
						break;	
					}
					else if((tc_strcmp(c_st_class_name,"T5_LcsAPLWrkg")==0 ||  tc_strcmp(c_st_class_name,"T5_LcsAplReview")==0)&& tc_strcmp(releaseStatusStr,"APLPENDING")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(c_st_class_name,"T5_LcsSTDWrkg")==0  && tc_strcmp(releaseStatusStr,"STDPENDING")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;
					}
					else if(tc_strcmp(releaseStatusStr,"ALL Status")==0)
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
						sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
						setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);
						flgOther++;
						break;

					}	
					else
					{
						cntFlg = 1;
						break;
					}
											
					
				}
			}
			else
			{
				if(tc_strcmp(releaseStatusStr,"ALL Status")==0)
				{
					setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
					sprintf(lifecycle_statestr,"<LifecycleState>%s</LifecycleState>",lifecycle_state);
					setAddStr(buff_cnt,bufferedXmlStrOut,lifecycle_statestr);

				}		
				else
				{
					
					printf("\n No status attached to the DML....\n");fflush(stdout);
					continue;	
				}
			}
			if(cntFlg ==1)
			{
				continue;
			}
			
		
			
			if(Planner != NULL)
			{
				
			}
			srno = srno + 1;
			sprintf(serial_num,"<SrNo>%d</SrNo>",srno);
			setAddStr(buff_cnt,bufferedXmlStrOut,serial_num);
					  
			CALLAPI(AOM_ask_value_string(objtag,"item_id",&apl_dml_number));

			printf("\n--->>>>> apl_dml_number>>==%s\n",apl_dml_number);fflush(stdout);
			sprintf(apl_dml_numberStr,"<DML_Number>%s</DML_Number>",apl_dml_number);
			setAddStr(buff_cnt,bufferedXmlStrOut,apl_dml_numberStr);	
			
			//CALLAPI(AOM_ask_value_string(objtag,"object_desc", &dml_desc));
			CALLAPI(AOM_ask_value_string(objtag,"object_name", &dml_desc));
			printf("\n--->>>>> object_desc_val>>==%s\n",dml_desc);fflush(stdout);
			sprintf(dml_descstr,"<DML_Description>%s</DML_Description>",dml_desc);
			setAddStr(buff_cnt,bufferedXmlStrOut,dml_descstr);	
			
		
			int resCnt =0;
			char** Reasons = NULL;
			CALLAPI(AOM_ask_displayable_values(objtag,"t5_reason",&resCnt, &Reasons));
			if(resCnt>0) 
				Reason = Reasons[0];
			//CALLAPI(AOM_ask_value_string(objtag,"t5_reason",&Reason));
			printf("\n--->>>>> Reason_val>>==%s\n",Reason);fflush(stdout);
			sprintf(Reasonstr,"<Reason_Description>%s</Reason_Description>",Reason);
			setAddStr(buff_cnt,bufferedXmlStrOut,Reasonstr);			
			
			CALLAPI(AOM_ask_value_string(objtag,"t5_cprojectcode", &Project_id));
			if(tc_strcmp(Project_id,"") != 0 || Project_id !=NULL)
			{
				sprintf(Project_idstr,"<Project_Code>%s</Project_Code>",Project_id);
			    setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
			}
			else
			{
				sprintf(Project_idstr,"<Project_Code>%s</Project_Code>","");
			    setAddStr(buff_cnt,bufferedXmlStrOut,Project_idstr);
			}


			CALLAPI(AOM_ask_value_strings(objtag,"t5_crdesigngroup",&num,&design_group));
			if(num>0)
			{
			   printf("\n--->>>>> DesignGroup_val>>==%s\n",design_group[0]);fflush(stdout);
			   sprintf(design_groupstr,"<Design_Group>%s</Design_Group>",design_group[0]);

			}
			else
			   sprintf(design_groupstr,"<Design_Group>NA</Design_Group>");
			  setAddStr(buff_cnt,bufferedXmlStrOut,design_groupstr);				
			
			CALLAPI(AOM_ask_value_string(objtag,"t5_cDRstatus", &DRStatus));
			printf("\n--->>>>> DRStatus_val>>==%s\n",DRStatus);fflush(stdout);
			sprintf(DRStatusstr,"<DR_Status>%s</DR_Status>",DRStatus);
			setAddStr(buff_cnt,bufferedXmlStrOut,DRStatusstr);
			
			tc_strcpy(item_id_val_copy,apl_dml_number);
			
			/*Finding ERC DML from APL DML**/
			item_id_tokenized=strtok(item_id_val_copy,"_");
			printf("Tokenized DML Number Obtained=%s\n",item_id_tokenized);
			
			//Using Query Builder to get ERC DML and then Release Date from there.....
			char *qry_entries3[] = {"ID"};
			char *qry_values3[] = {item_id_tokenized};
			qry_values3[0]=item_id_tokenized;
			
			CALLAPI(QRY_find("ERC DML", &query));
			CALLAPI(QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1));
			if(n_found!=0)
			{
				
				printf("Found an ERC DML\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(t_item1[0] ,"item_id", &dml_number_erc));
				
				printf("ERC DML Found=%s\n",dml_number_erc);fflush(stdout);
				
				CALLAPI(AOM_UIF_ask_value(t_item1[0],"date_released",&erc_released_date));
				printf("ERC Released Date found=%s\n",erc_released_date);fflush(stdout);
				
				sprintf(erc_released_datestr,"<ERC_Released_Date>%s</ERC_Released_Date>",erc_released_date);
				setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
				printf("ERC Released Date obtained=%s\n",erc_released_datestr);fflush(stdout);
			
				CALLAPI(AOM_ask_value_string(t_item1[0] ,"requestor_user_id", &designer_erc));
				
				printf("Designer Obtined=%s\n",designer_erc);
				sprintf(designer_ercstr,"<Designer>%s</Designer>",designer_erc);
				setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
			}
			else//Does not have erc dml may be AM/SM dml
			{
				sprintf(erc_released_datestr,"<ERC_Released_Date>NA</ERC_Released_Date>");
				setAddStr(buff_cnt,bufferedXmlStrOut,erc_released_datestr);
				sprintf(designer_ercstr,"<Designer>NA</Designer>");
				setAddStr(buff_cnt,bufferedXmlStrOut,designer_ercstr);
				
			}
								
			//Logic for EPA details
			int epaNochk =0;
			int epaStatusChk =0;
			int epaFinalizedDateChk = 0;
			setFindStr(additional_attrs,colmnLen,"EPA No",&epaNochk);
			setFindStr(additional_attrs,colmnLen,"EPA Status",&epaStatusChk);
			setFindStr(additional_attrs,colmnLen,"EPA Finalized Date",&epaFinalizedDateChk);
			if(epaNochk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number>NA</EPA_Number>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Number></EPA_Number>");
			}
			if(epaStatusChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status>NA</EPA_Status>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_Status></EPA_Status>");
			}
			if(epaFinalizedDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date>NA</EPA_finalized_Date>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<EPA_finalized_Date></EPA_finalized_Date>");
			}
					
			//Logic for Indent with SOR Details
			/*		indentList.add("Indent Reviewer");
			indentList.add("Indent Creation Date");
			indentList.add("Indent Approval Date");
			indentList.add("Indent Status");
			indentList.add("Indent Comments");
			//data.put("Indent Details", indentList);
			data.put("Indent with SOR Details", indentList);//Indent with SOR Details*/
			
			int indentReviewerChk =0;
			int indentCreDateChk =0;
			int indentApprDateChk =0;
			int indentStatusChk =0;
			int indentCommentsChk =0;
			setFindStr(additional_attrs,colmnLen,"Indent Reviewer",&indentReviewerChk);
			setFindStr(additional_attrs,colmnLen,"Indent Creation Date",&indentCreDateChk);
			setFindStr(additional_attrs,colmnLen,"Indent Approval Date",&indentApprDateChk);		  
			setFindStr(additional_attrs,colmnLen,"Indent Status",&indentStatusChk);
			setFindStr(additional_attrs,colmnLen,"Indent Comments",&indentCommentsChk);	
			if(indentReviewerChk ==1)
			{
				//Need to implement the logic later
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Reviewer>NA</Indent_Reviewer>");
			}
			else
			{
				//Need to implement the logic later
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Reviewer></Indent_Reviewer>");
			}
			if(indentCreDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_CreDate>NA</Indent_CreDate>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_CreDate></Indent_CreDate>");
			}
			if(indentApprDateChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_ApprDate>NA</Indent_ApprDate>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_ApprDate></Indent_ApprDate>");
			}			
			if(indentStatusChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Status>NA</Indent_Status>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Status></Indent_Status>");
			}
			
			if(indentCommentsChk ==1)
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Comments>NA</Indent_Comments>");
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Indent_Comments></Indent_Comments>");
			}			


		
//Task logic		
			CALLAPI(AOM_ask_value_tags(objtag,"T5_DMLTaskRelation",&taskcount,&taskList));
			printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
			
			if(taskcount > 0)
			{
				int i;

				for(i=0;i<taskcount;i++)
				{	
					tag_t task=taskList[i];
					char* apl_task_class = NULL;
					
					CALLAPI(AOM_ask_value_string(task,"object_type",&apl_task_class));
					printf("\nTask class======================================>%s\n", apl_task_class);fflush(stdout);
					if(tc_strcmp(apl_task_class,"T5_APLTaskRevision")!=0)
					{
						printf("\nTask class is not T5_APLTaskRevision. It is: %s\n", apl_task_class);fflush(stdout);
						continue;
					}

					setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");	
					int  count_release_status =0; 
					tag_t *release_status_object=NULLTAG;
					char  name[WSO_name_size_c+1]    = {'\0'};
					int flagApl =0;
					int flagStd = 0;
					char* apl_task_number = NULL;
					char* task_number_str=NULL;
					task_number_str=(char*)malloc(100*sizeof(char));
					
					
					CALLAPI(AOM_ask_value_string(task,"item_id",&apl_task_number));
					printf("\nTask number: %s\n", apl_task_number);fflush(stdout);
					
					
					sprintf(task_number_str,"<Task_Number>%s</Task_Number>",apl_task_number);
					setAddStr(buff_cnt,bufferedXmlStrOut,task_number_str);
					
					printf("\nBefore Release Status Count\n");fflush(stdout);
					CALLAPI(WSOM_ask_release_status_list(task,&count_release_status,&release_status_object));
					printf("After Release Status Count\n");fflush(stdout);
					printf("Release Status Count Obtained=%d\n",count_release_status);fflush(stdout);	
					if(count_release_status>0)
					{	
						int k;
						int cnt =0;
						int cnt1 = 0;
						for(k=0;k<count_release_status;k++)
						{
							char* date_rel=NULL;
							char* date_relstr=NULL;

							date_relstr=(char*)malloc(100*sizeof(char));
							char* date_relstr1=NULL;
							date_relstr1=(char*)malloc(100*sizeof(char));
							tag_t release_status = release_status_object[k];
							CALLAPI(CR_ask_release_status_type(release_status,name));
							printf("Release Status Name obtained=%s\n",name);fflush(stdout);

							if(tc_strcmp(name,"T5_LcsAplRlzd")==0)
							{
								CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
								//CALLAPI(AOM_ask_value_date(itemrevs[i],"creation_date",&creation_dt));
								printf("APL Released Date=%s\n",date_rel);fflush(stdout);


								if(cnt ==0)
								{
									sprintf(date_relstr,"<APL_released_Date>%s</APL_released_Date>",date_rel);
									setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
									flagApl = 1;
								}
										
								cnt++;							
								
							}
							else if(tc_strcmp(name,"T5_LcsStdRlzd")==0)
							{
								CALLAPI(AOM_UIF_ask_value(release_status,"date_released",&date_rel));
								printf("STD Released Date=%s\n",date_rel);fflush(stdout);						
								if(cnt1 ==0)
								{
									sprintf(date_relstr1,"<STD_Release_Date>%s</STD_Release_Date>",date_rel);
									setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr1);
									flagStd = 1;
								}
									
									
								cnt1++;
								
							}

							if(date_relstr!=NULL)free(date_relstr);	
							if(date_relstr1!=NULL)free(date_relstr1);							
						}
						
						char* date_relstr2=NULL;
						date_relstr2=(char*)malloc(100*sizeof(char));
						char* date_relstr3=NULL;
						date_relstr3=(char*)malloc(100*sizeof(char));
						
						if(flagApl ==0 && flagStd ==1)
						{
							sprintf(date_relstr2,"<APL_released_Date>NA</APL_released_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr2);
						}
						else if(flagStd ==0 && flagApl ==1)
						{
							sprintf(date_relstr3,"<STD_Release_Date>NA</STD_Release_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr3);	
						
						}
						else if(flagStd ==0 && flagApl ==0)
						{
							sprintf(date_relstr2,"<APL_released_Date>NA</APL_released_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr2);
							sprintf(date_relstr3,"<STD_Release_Date>NA</STD_Release_Date>");
							setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr3);	
						}					
						if(date_relstr2!=NULL)free(date_relstr2);	
						if(date_relstr3!=NULL)free(date_relstr3);	

					}
					else
					{
						//char* date_rel=NULL;
						char* date_relstr=NULL;
						date_relstr=(char*)malloc(100*sizeof(char));
						char* date_relstr1=NULL;
						date_relstr1=(char*)malloc(100*sizeof(char));
						
					
						sprintf(date_relstr,"<APL_released_Date>NA</APL_released_Date>");
						setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr);
						sprintf(date_relstr1,"<STD_Release_Date>NA</STD_Release_Date>");
						setAddStr(buff_cnt,bufferedXmlStrOut,date_relstr1);	

		
						if(date_relstr!=NULL)free(date_relstr);	
						if(date_relstr1!=NULL)free(date_relstr1);	
					}
					
					/****************************************/
					//From poonam code logic...
					char        *TaskAplWrkOnDML           = NULL;
					char        *TaskAplRev           = NULL;
					char        *TaskSTDCreEPA           = NULL;
					char        *TaskSTDRev           = NULL;
					TaskAplWrkOnDML = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskAplRev = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDCreEPA = (char *) MEM_alloc( 100 * sizeof(char) );
					TaskSTDRev = (char *) MEM_alloc( 100 * sizeof(char) );

					tc_strcpy(TaskAplWrkOnDML,"");
					tc_strcpy(TaskAplRev,"");
					tc_strcpy(TaskSTDCreEPA,"");
					tc_strcpy(TaskSTDRev,"");
						
					
					//CALLAPI(QueryWorkFl(task,TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev));
					CALLAPI(QueryAplParticipants(task,TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev));
					
					printf("\n  Process His of APL/STD Planner and rev: APLWorkOnDML[%s] APL REv[%s] STD Create EPA [%s] STD Rev[%s] \n",TaskAplWrkOnDML,TaskAplRev,TaskSTDCreEPA,TaskSTDRev); fflush(stdout);
					
					if(TaskAplWrkOnDML==NULL || tc_strcmp(TaskAplWrkOnDML,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<AplPlanner>NA</AplPlanner>");
					}
					else
					{
						char* aplPlannerStr =(char*)malloc(150*sizeof(char));
						sprintf(aplPlannerStr,"<AplPlanner>%s</AplPlanner>", TaskAplWrkOnDML);
						setAddStr(buff_cnt,bufferedXmlStrOut,aplPlannerStr);
						if(aplPlannerStr != NULL) free(aplPlannerStr);
					}
					
					if(TaskSTDCreEPA==NULL || tc_strcmp(TaskSTDCreEPA,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<StdPlanner>NA</StdPlanner>");
					}
					else
					{
						char* stdPlannerStr =(char*)malloc(100*sizeof(char));
						sprintf(stdPlannerStr,"<StdPlanner>%s</StdPlanner>", TaskSTDCreEPA);
						setAddStr(buff_cnt,bufferedXmlStrOut,stdPlannerStr);
						if(stdPlannerStr != NULL) free(stdPlannerStr);
					}
					if(TaskAplRev==NULL || tc_strcmp(TaskAplRev,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<AplRev>NA</AplRev>");
					}
					else
					{
						char* aplReviewerStr =(char*)malloc(100*sizeof(char));
						sprintf(aplReviewerStr,"<AplRev>%s</AplRev>", TaskAplRev);
						setAddStr(buff_cnt,bufferedXmlStrOut,aplReviewerStr);
						if(aplReviewerStr != NULL) free(aplReviewerStr);
					}
					if(TaskSTDRev==NULL || tc_strcmp(TaskSTDRev,"")==0 )
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<StdRev>NA</StdRev>");
					}
					else
					{
						char* stdReviewerStr =(char*)malloc(100*sizeof(char));
						sprintf(stdReviewerStr,"<StdRev>%s</StdRev>", TaskSTDRev);
						setAddStr(buff_cnt,bufferedXmlStrOut,stdReviewerStr);
						if(stdReviewerStr != NULL) free(stdReviewerStr);
					}	
					
					if(TaskAplWrkOnDML != NULL) MEM_free(TaskAplWrkOnDML);
					if(TaskAplRev != NULL) MEM_free(TaskAplRev);
					if(TaskSTDCreEPA != NULL) MEM_free(TaskSTDCreEPA);
					if(TaskSTDRev != NULL) MEM_free(TaskSTDRev);
		
					//Part tags...
					int	partcount = 0;
					tag_t *PartList = NULLTAG;
					
					CALLAPI(AOM_ask_value_tags(task,"CMHasSolutionItem",&partcount,&PartList));	
					if(partcount>0)
					{
						int k;
						char *partnumber,*partnumberstr		=NULL;
						char *revision_id =NULL;
						char revision_id_cpy[2]={'\0'};
						char *revision_id_tokenized,*revision_id_tokenizedstr=NULL;
						int sequence;
						char *sequence_numberstr =NULL;
						char *PartDescription,*PartDescriptionstr=NULL;
						
						revision_id_tokenizedstr = (char *)malloc(100 * sizeof(char));				
						partnumberstr = (char *)malloc(100 * sizeof(char));
						sequence_numberstr = (char *)malloc(100 * sizeof(char));
						//PartDescriptionstr =(char *) malloc(100 * sizeof(char));
						
						char* partType = NULL;
						int designCnt = 0;
						for(k=0;k<partcount;k++)
						{
							
							CALLAPI(AOM_ask_value_string(PartList[k] ,"object_type",&partType));
							printf("Part Type: %s\n",partType);fflush(stdout);
							
							
							if(tc_strcmp(partType,"Design Revision")==0)
							{
								designCnt++;
								setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
								CALLAPI(AOM_ask_value_string(PartList[k] ,"item_id",&partnumber));
								printf("Part Number Found for Part =%s\n",partnumber);fflush(stdout);
								sprintf(partnumberstr,"<Part_Number>%s</Part_Number>",partnumber);
								setAddStr(buff_cnt,bufferedXmlStrOut,partnumberstr);

								CALLAPI(AOM_ask_value_string(PartList[k] ,"item_revision_id",&revision_id));
								printf("Revision Found for Part =%s\n",revision_id);fflush(stdout);

								tc_strcpy(revision_id_cpy,revision_id);
								revision_id_tokenized=strtok(revision_id_cpy,";");
								printf("Tokenized Revision Id=%s\n",revision_id_tokenized);fflush(stdout);
								sprintf(revision_id_tokenizedstr,"<Revision>%s</Revision>",revision_id_tokenized);
								setAddStr(buff_cnt,bufferedXmlStrOut,revision_id_tokenizedstr);

								CALLAPI(AOM_ask_value_int(PartList[k],"sequence_id",&sequence));
								printf("Sequence Found for Part  =%d\n",sequence);fflush(stdout);
								sprintf(sequence_numberstr,"<Sequence>%d</Sequence>",sequence);
								setAddStr(buff_cnt,bufferedXmlStrOut,sequence_numberstr);	
								
								//Sor logic
								int sorNumChk =0;
								int sorPPPMProjStatChk =0;
								int sorCatChk =0;
								int refPartNumChk =0;
								int refSorNumChk =0;
								
								int sorDmlNumChk =0;
								int sorPppmProjCodeChk =0;
								int sorReviewerChk =0;
								int starSorNumChk =0;
								int sorRejFlagChk =0;	
								
								int sorRemarkChk =0;
								int sorVariantChk =0;			
								
								setFindStr(additional_attrs,colmnLen,"SOR Number",&sorNumChk);
								setFindStr(additional_attrs,colmnLen,"PPPM Project Status",&sorPPPMProjStatChk);
								setFindStr(additional_attrs,colmnLen,"SOR Category",&sorCatChk);		  
								setFindStr(additional_attrs,colmnLen,"Ref Part Number",&refPartNumChk);
								setFindStr(additional_attrs,colmnLen,"Ref SOR Number",&refSorNumChk);	
								
								setFindStr(additional_attrs,colmnLen,"SOR Dml Number",&sorDmlNumChk);
								setFindStr(additional_attrs,colmnLen,"PPPM Project Code",&sorPppmProjCodeChk);
								setFindStr(additional_attrs,colmnLen,"SOR Reviewer",&sorReviewerChk);		  
								setFindStr(additional_attrs,colmnLen,"Star SOR Number",&starSorNumChk);
								setFindStr(additional_attrs,colmnLen,"SOR Rejection Flag",&sorRejFlagChk);			
								setFindStr(additional_attrs,colmnLen,"SOR Remark",&sorRemarkChk);
								setFindStr(additional_attrs,colmnLen,"SOR Variant",&sorVariantChk);	
								
								//Sor logic if the below condn true
								if(sorNumChk ==1 || sorPPPMProjStatChk ==1 ||  sorCatChk ==1 || refPartNumChk ==1 || refSorNumChk==1 || sorDmlNumChk == 1 || sorPppmProjCodeChk == 1 || sorReviewerChk == 1 || starSorNumChk ==1 || sorRejFlagChk == 1 || sorVariantChk== 1)
								{
									printf("\nInside Sor logic.........\n");fflush(stdout);
									int sorCnt = 0;
									tag_t *sorObjList = NULLTAG;
									tag_t relatnTypeSor_tag   = NULLTAG;
									int cntr = 0;
									//CALLAPI(AOM_ask_value_tags(PartList[k],"T5_PartSorRel",&sorCnt,&sorObjList));	
									//CALLAPI(GRM_find_relation_type("T5_PartSorRel",&relatnTypeSor_tag));
									CALLAPI(GRM_find_relation_type("IMAN_specification",&relatnTypeSor_tag));
									if(relatnTypeSor_tag != NULLTAG)
									{
										printf("\nInside Sor logic1.........\n");fflush(stdout);
										CALLAPI(GRM_list_secondary_objects_only(PartList[k], relatnTypeSor_tag, &sorCnt, &sorObjList));
										//CALLAPI(GRM_list_primary_objects_only(PartList[k], relatnTypeSor_tag, &sorCnt, &sorObjList));
										printf("\nSor count for the Part(%s)=============>%d\n",partnumber,sorCnt);fflush(stdout);
										
										if(sorCnt>0)
										{
											
											char* sorNumber = NULL;
											char* sorNumberStr = (char *)MEM_alloc(100 * sizeof(char));
											char* pppmProjStatus = NULL;
											char* pppmProjStatusStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorCategory = NULL;
											char* sorCategoryStr = (char *)MEM_alloc(100 * sizeof(char));
											char* refPartNum = NULL;
											char* refPartNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* refSorNum = NULL;
											char* refSorNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorDmlNum = NULL;
											char* sorDmlNumStr = (char *)MEM_alloc(100 * sizeof(char));
											char* pppmProjCode = NULL;
											char* pppmProjCodeStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorReviewer = NULL;
											char* sorReviewerStr = (char *)MEM_alloc(100 * sizeof(char));
											char* starSorNum = NULL;
											char* starSorNumStr = (char *)MEM_alloc(100 * sizeof(char));
											logical sorRejFlag = false;
											char* sorRejFlagStr = (char *)MEM_alloc(100 * sizeof(char));
											char* sorRemark = NULL;
											char* sorRemarkStr = (char *)MEM_alloc(100 * sizeof(char));
											char** variantNames = NULL;
											char* variantNameStr = (char *)MEM_alloc(300 * sizeof(char));										

											for(cntr = 0; cntr< sorCnt ;cntr++)
											{
												
												char* sorObjType;
												tag_t sorObj = 	sorObjList[cntr];
												CALLAPI(AOM_ask_value_string(sorObj ,"object_type",&sorObjType));
												printf("\nSOR class======================================>%s\n", sorObjType);fflush(stdout);
												if(tc_strcmp(sorObjType,"T5_AutoSorRevision")==0)
												{
													setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
													
													//CALLAPI(AOM_ask_value_logical(sorObj,"t5_RejFlag",&sorRejFlag));
												
													CALLAPI(AOM_ask_value_string(sorObj ,"item_id",&sorNumber));
													printf("SOR Number Found for Part =%s\n",sorNumber);fflush(stdout);
													if(sorNumber != NULL)
													{
														sprintf(sorNumberStr,"<Sor_Number>%s</Sor_Number>",sorNumber);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorNumberStr);
													}										
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number>NA</Sor_Number>");
													}

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_PPPMProjStatus",&pppmProjStatus));
													printf("PPPM Proj status =%s\n",pppmProjStatus);fflush(stdout);
													if(pppmProjStatus!=NULL)
													{
														sprintf(pppmProjStatusStr,"<Sor_PppmProjStat>%s</Sor_PppmProjStat>",pppmProjStatus);
														setAddStr(buff_cnt,bufferedXmlStrOut,pppmProjStatusStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat>NA</Sor_PppmProjStat>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorCat",&sorCategory));
													printf("sorCategory =%s\n",sorCategory);fflush(stdout);
													if(sorCategory!=NULL)
													{
														sprintf(sorCategoryStr,"<Sor_Category>%s</Sor_Category>",sorCategory);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorCategoryStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category>NA</Sor_Category>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_RefPrtNum",&refPartNum));
													printf("refPartNum =%s\n",refPartNum);fflush(stdout);
													if(refPartNum!=NULL)
													{
														sprintf(refPartNumStr,"<Sor_refPartNum>%s</Sor_refPartNum>",refPartNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,refPartNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum>NA</Sor_refPartNum>");
													}	

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_RefSOR",&refSorNum));
													printf("refSorNum =%s\n",refSorNum);fflush(stdout);
													if(refSorNum!=NULL)
													{
														sprintf(refSorNumStr,"<Sor_refSorNum>%s</Sor_refSorNum>",refSorNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,refSorNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum>NA</Sor_refSorNum>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_DmlNumber",&sorDmlNum));
													printf("sorDmlNum =%s\n",sorDmlNum);fflush(stdout);
													if(sorDmlNum!=NULL)
													{
														sprintf(sorDmlNumStr,"<Sor_dmlNum>%s</Sor_dmlNum>",sorDmlNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorDmlNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum>NA</Sor_dmlNum>");
													}												

													CALLAPI(AOM_ask_value_string(sorObj ,"t5_PPPMPrjCode",&pppmProjCode));
													printf("pppmProjCode =%s\n",refPartNum);fflush(stdout);
													if(pppmProjCode!=NULL)
													{
														sprintf(pppmProjCodeStr,"<Sor_pppmProjCode>%s</Sor_pppmProjCode>",pppmProjCode);
														setAddStr(buff_cnt,bufferedXmlStrOut,pppmProjCodeStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode>NA</Sor_pppmProjCode>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorReviewer",&sorReviewer));
													printf("sorReviewer =%s\n",sorReviewer);fflush(stdout);
													if(sorReviewer!=NULL)
													{
														sprintf(sorReviewerStr,"<Sor_reviewer>%s</Sor_reviewer>",sorReviewer);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorReviewerStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer>NA</Sor_reviewer>");
													}
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_StarSorNum",&starSorNum));
													printf("starSorNum =%s\n",starSorNum);fflush(stdout);
													if(starSorNum!=NULL)
													{
														sprintf(starSorNumStr,"<Sor_starSorNum>%s</Sor_starSorNum>",starSorNum);
														setAddStr(buff_cnt,bufferedXmlStrOut,starSorNumStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum>NA</Sor_starSorNum>");
													}
													CALLAPI(AOM_ask_value_logical(sorObj,"t5_RejFlag",&sorRejFlag));
													printf("sorRejFlag =%d\n",sorRejFlag);fflush(stdout);
													sprintf(sorRejFlagStr,"<Sor_RejFlag>%d</Sor_RejFlag>",sorRejFlag);
													setAddStr(buff_cnt,bufferedXmlStrOut,sorRejFlagStr);

			
													CALLAPI(AOM_ask_value_string(sorObj ,"t5_SorRemark",&sorRemark));
													printf("sorRemark =%s\n",sorRemark);fflush(stdout);
													if(sorRemark!=NULL)
													{
														sprintf(sorRemarkStr,"<Sor_Remark>%s</Sor_Remark>",sorRemark);
														setAddStr(buff_cnt,bufferedXmlStrOut,sorRemarkStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark>NA</Sor_Remark>");
													}
													int varSz = 0;
													int varCnt =0;
													CALLAPI(AOM_ask_value_strings(sorObj ,"t5_VariantName",&varSz, &variantNames));
													for(varCnt =0; varCnt<varSz; varCnt++)
													{
														printf("variantName[%d] =%s\n",varCnt,variantNames[varCnt]);fflush(stdout);
													}
													
													if(varCnt>0)
													{
														sprintf(variantNameStr,"<Sor_Variant>%s</Sor_Variant>",variantNames[0]);
														setAddStr(buff_cnt,bufferedXmlStrOut,variantNameStr);
													}
													else
													{
														setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant>NA</Sor_Variant>");
													}												
													setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");												
														
												}
												else
												{
													printf("\nSOR class is not T5_AutoSorRevision. It is: %s\n", sorObjType);fflush(stdout);
													setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
													setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
												}
												
												
												
											}
											if(sorNumberStr!=NULL) MEM_free(sorNumberStr);
											if(pppmProjStatusStr!=NULL) MEM_free(pppmProjStatusStr);
											if(sorCategoryStr!=NULL) MEM_free(sorCategoryStr);
											if(refPartNumStr!=NULL) MEM_free(refPartNumStr);
											if(refSorNumStr!=NULL) MEM_free(refSorNumStr);
											if(sorDmlNumStr!=NULL) MEM_free(sorDmlNumStr);
											if(pppmProjCodeStr!=NULL) MEM_free(pppmProjCodeStr);
											if(sorReviewerStr!=NULL) MEM_free(sorReviewerStr);
											if(starSorNumStr!=NULL) MEM_free(starSorNumStr);
											if(sorRejFlagStr!=NULL) MEM_free(sorRejFlagStr);
											if(sorRemarkStr!=NULL) MEM_free(sorRemarkStr);
											if(variantNameStr!=NULL) MEM_free(variantNameStr);
											
										}
										else
										{
											
											setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
											setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");										
										}
										
									}
																
								}								
								else
								{
									printf("\nOutside Sor logic.........\n");fflush(stdout);
									setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
								}
												
								setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");	
							}
							else
							{
								if(designCnt == 0)
								{
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Number></Part_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Revision></Revision>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sequence></Sequence>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
									setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
									
								}
								
							}
											
						}
						if(partnumberstr != NULL) free(partnumberstr);
						if(revision_id_tokenizedstr != NULL) free(revision_id_tokenizedstr);
						if(sequence_numberstr != NULL) free(sequence_numberstr);
						
					}
					else
					{
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Number></Part_Number>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Revision></Revision>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sequence></Sequence>");
						
						setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Number></Sor_Number>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_PppmProjStat></Sor_PppmProjStat>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Category></Sor_Category>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refPartNum></Sor_refPartNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_refSorNum></Sor_refSorNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_dmlNum></Sor_dmlNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_pppmProjCode></Sor_pppmProjCode>");					
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_reviewer></Sor_reviewer>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_starSorNum></Sor_starSorNum>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_RejFlag></Sor_RejFlag>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Remark></Sor_Remark>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"<Sor_Variant></Sor_Variant>");
						setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");


						setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
					}


					
					setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
					if(task_number_str != NULL) free(task_number_str);
				}	//end for loop task	
			}
			else
			{
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
				setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
			}



		
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
			
			

			

		}
		printf("\n flgOther=====================>%d\n", flgOther);fflush(stdout);
		if(flgOther == 0)
		{
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
			setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");	
		}
		
		
	}
	else
	{
		
		printf("\n NO DML found for the given criteria...\n");fflush(stdout);
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Task_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<Part_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"<SorObject>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</SorObject>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Part_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Task_Object>");
		setAddStr(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
		
		
	}
	setAddStr(buff_cnt,bufferedXmlStrOut,"</APLDMLBetweenDateReport>");

	if(dml_descstr != NULL) MEM_free(dml_descstr);
	if(apl_dml_numberStr != NULL) MEM_free(apl_dml_numberStr);
	if(design_groupstr != NULL) MEM_free(design_groupstr);
	if(Project_idstr != NULL) MEM_free(Project_idstr);
	if(serial_num != NULL) MEM_free(serial_num);
	if(lifecycle_statestr != NULL) MEM_free(lifecycle_statestr);
	if(Reasonstr != NULL) MEM_free(Reasonstr);
	
	return ifail;
	
	
}




int CommonAPLDMLBetweenReports(void *retValue)
{
	const char	*prog_name 	="CommonAPLDMLBetweenReports";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\n Start----CommonAPLDMLBetweenReports....\n");fflush(stdout);
	char* releaseStatusStr = NULL;
	char* Datefrom = NULL;
	char* Dateto = NULL;
	char* Plant = NULL;
	int projlen=0;
    char** Project_code_ids=NULL;	
	char* Planner = NULL;
	int colmnLen = 0;
	char** additional_attrs = NULL;
	char* includeSummaryStr = NULL;
	char PlantDup[10]={'\0'};
	
	USERARG_get_string_argument(&releaseStatusStr);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Plant);	
	USERARG_get_string_array_argument(&projlen,&Project_code_ids);		
	USERARG_get_string_argument(&Planner);
	USERARG_get_string_array_argument(&colmnLen,&additional_attrs);
	USERARG_get_string_argument(&includeSummaryStr);
	//print input parameters
	printf("releaseStatusStr==>%s\nDatefrom==>%s\nDateto==>%s\nPlant==>%s\nPlanner==>%s\nincludeSummaryStr==>%s\n",releaseStatusStr,Datefrom,Dateto,Plant,Planner,includeSummaryStr);fflush(stdout);
	int i =0;
	for(i=0; i<projlen; i++)
	{
		printf("Project_code_ids[%d]==>%s\n", i,Project_code_ids[i]);fflush(stdout);
	}
	for(i=0; i<colmnLen; i++)
	{
		printf("additional_attrs[%d]==>%s\n", i,additional_attrs[i]);fflush(stdout);
	}	
	
	//end print input parameters
	
	//Translating Plant Name Here.......
/*
		 plantList.add("CAR");        
		 plantList.add("CVBU JSR");
		 plantList.add("CVBU LKO");
		 plantList.add("CVBU PNR");
		 plantList.add("CVBU PUNE");
		 plantList.add("PCBU");
		 plantList.add("PCBU and CVBU");
		 plantList.add("PCBU LKO");
		 plantList.add("SMALLCAR AHD");
		 plantList.add("SMALLCAR PNR");
		 plantList.add("DHARWAD");
		 plantList.add("PUVBU");
*/	
	if(tc_strcmp(Plant,"CAR")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLC");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		
	}
	else if(tc_strcmp(Plant,"CVBU JSR")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLJ");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		
	}else if((tc_strcmp(Plant,"CVBU LKO")==0) || (tc_strcmp(Plant,"PCBU LKO")==0) || (tc_strcmp(Plant,"PUVBU")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLL");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}else if(tc_strcmp(Plant,"CVBU PUNE")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLP");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}else if(tc_strcmp(Plant,"DHARWAD")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLD");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}else if((tc_strcmp(Plant,"CVBU PNR")==0) || (tc_strcmp(Plant,"SMALLCAR PNR")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLU");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}
	else if((tc_strcmp(Plant,"PCBU")==0) || (tc_strcmp(Plant,"PCBU and CVBU")==0) || (tc_strcmp(Plant,"SMALLCAR AHD")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLP");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);	
	}


	CALLAPI(dmlReleaseBetweenDates_new(Datefrom,Dateto,releaseStatusStr,PlantDup, projlen, Project_code_ids, colmnLen, additional_attrs, Planner,&bufferedXmlStrOut,&buff_cnt));
	
	
	int m =0;
	printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	printf("\nBefore returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

		printf("After returning Value\n");fflush(stdout);	
		printf("\n End----CommonAPLDMLBetweenReports....\n");fflush(stdout);
	return ifail;
}
//End Sanjoy 




int getDmlTagsBetweenDates( char* Datefrom, char* Dateto, char* releaseStatusStr, char* Plant, int projlen, char** Project_code_ids, int colmnLen, char** additional_attrs, char* Planner, tag_t** tagSetOut, int *tag_cnt  )
{
	
	printf("\nStart of getDmlTagsBetweenDates function....................\n");fflush(stdout);
	int ifail = ITK_ok;
	int k;
	date_t   a_date_from;
	date_t   a_date_to;	
	date_t   vals[2];	
	
	const char *Plant_received[]={Plant};
	const char * select_attrs[]={"puid"};
	
	printf("Plant recieved in Function=%s\n",Plant);fflush(stdout);
	printf("From Date=%s\n",Datefrom);fflush(stdout);
	printf("To Date=%s\n",Dateto);fflush(stdout);
	
	ITK_string_to_date(Datefrom,&a_date_from);
	ITK_string_to_date(Dateto,&a_date_to);

	vals[0]=a_date_from;
	vals[1]=a_date_to;
	

	for(k=0;k<projlen;k++)
	{
		
		printf("\n Project[%d]==[%s]",k+1,Project_code_ids[k]);
		
	}
	printf("Argument Received Datefrom(getDmlTagsBetweenDates) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received Dateto(getDmlTagsBetweenDates) =%s\n",Dateto);fflush(stdout);
	printf("Release Status Received (getDmlTagsBetweenDates) =%s\n",releaseStatusStr);fflush(stdout);
	printf("Plant Received (getDmlTagsBetweenDates) =%s\n",Plant);fflush(stdout);
	
	
	printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
	
	/** Creating a POM Query **/
	CALLAPI(POM_enquiry_create("find_Dml_Number"));
	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
	
	/** Adding select attribute to Query **/
	CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));
	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
	
	/**Setting Released Date **/
	CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
	
	if(tc_strcmp(releaseStatusStr,"APL Released")==0 || tc_strcmp(releaseStatusStr,"STD Released")==0)
	{
		/** creating between Expression **/
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","date_released",POM_enquiry_between,"expr_dates"));
	}
	else 
	{
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","creation_date",POM_enquiry_between,"expr_dates"));
	}
	
	printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
	 /**Need to Check if Plant received if Plant is Null then go for Project Codes**/
	if(((tc_strcmp(Plant,"")==0 || Plant == NULL)) && projlen>0)
	{
		printf("Entered into Project list Section\n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Project list Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
	}
	else if((tc_strcmp(Plant,"")!=0) && projlen==0)
	{
		printf("Entered into Plant Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );

		printf("Check 2\n");fflush(stdout);		
	}
	else  if((tc_strcmp(Plant,"")!=0) && projlen >0){
		printf("Both Plant and project not null.... \n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","Plant_expr",1,Plant_received,POM_enquiry_bind_value));

		printf("******Creating a Join expression*********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_join_expr("find_Dml_Number", "join_expr","T5_APLDMLRevision", "items_tag", POM_enquiry_equal, "T5_APLDML", "puid"));

		printf("******Creating a like Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_attr_expr("find_Dml_Number", "like_expr","T5_APLDML", "item_id", POM_enquiry_like,"Plant_expr"));

		printf("******Creating and Expression *********\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"join_expr"));

		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression1","expr_AND_expression",POM_enquiry_and,"like_expr"));

		printf("******Before Where Expression (Plant Logic) *********\n");fflush(stdout);

		/**Setting the Where Expression **/

		//POM_enquiry_set_where_expr ( "find_Dml_Number","expr_AND_expression1" );	


		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","T5_APLDMLRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression2","expr_AND_expression1",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Plant & project Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression2"));		

		printf("Check 2222\n");fflush(stdout);				

		
	}
	else
	{
		printf("Both Plant and project  null.... Need to implement the logic\n");fflush(stdout);
	}
	

	tag_t objtag =NULLTAG;
	int  rows = 0, columns = 0;
	void ***report;
	int ii, num=0;




	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));

	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_delete("find_Dml_Number"));

	printf("Check 1\n");fflush(stdout);
	

	printf("\ngetDmlTagsBetweenDates....After POM query execution....No of ROWs=====>%d",rows);fflush(stdout);
	if(rows > 0)
	{

		for (ii = 0; ii < rows; ii++ )
		{			
			objtag  = *(tag_t*)(report[ii][0]);
			if(objtag!=NULLTAG)
			{
				setAddTAG(tag_cnt,tagSetOut,objtag);
				
			}
			
		}
	}
	printf("\n End getDmlTagsBetweenDates.............. \n");fflush(stdout);
	return ifail;
	
	
}



int CommonAPLDMLBetweenReportsNew(void *retValue)
{
	
	printf("\n Start----CommonAPLDMLBetweenReportsNew....\n");fflush(stdout);
	
	const char	*prog_name 	="CommonAPLDMLBetweenReportsNew";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	int tag_cnt=0;
	tag_t* tagSetOut = NULL;
	
	
	char* releaseStatusStr = NULL;
	char* Datefrom = NULL;
	char* Dateto = NULL;
	char* Plant = NULL;
	int projlen=0;
    char** Project_code_ids=NULL;	
	char* Planner = NULL;
	int colmnLen = 0;
	char** additional_attrs = NULL;
	char* includeSummaryStr = NULL;
	char PlantDup[10]={'\0'};
	
	USERARG_get_string_argument(&releaseStatusStr);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Plant);	
	USERARG_get_string_array_argument(&projlen,&Project_code_ids);		
	USERARG_get_string_argument(&Planner);
	USERARG_get_string_array_argument(&colmnLen,&additional_attrs);
	USERARG_get_string_argument(&includeSummaryStr);
	//print input parameters
	printf("releaseStatusStr==>%s\nDatefrom==>%s\nDateto==>%s\nPlant==>%s\nPlanner==>%s\nincludeSummaryStr==>%s\n",releaseStatusStr,Datefrom,Dateto,Plant,Planner,includeSummaryStr);fflush(stdout);
	int i =0;
	for(i=0; i<projlen; i++)
	{
		printf("Project_code_ids[%d]==>%s\n", i,Project_code_ids[i]);fflush(stdout);
	}
	for(i=0; i<colmnLen; i++)
	{
		printf("additional_attrs[%d]==>%s\n", i,additional_attrs[i]);fflush(stdout);
	}	
	
	//end print input parameters
	
	//Translating Plant Name Here.......

	if((tc_strcmp(Plant,"CAR")==0) || (tc_strcmp(Plant,"PCBU")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLC");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		
	}
	else if(tc_strcmp(Plant,"CVBU JSR")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLJ");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
		
	}
	else if((tc_strcmp(Plant,"CVBU LKO")==0) || (tc_strcmp(Plant,"PCBU LKO")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLL");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}
	else if(tc_strcmp(Plant,"PUVBU")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLV");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}
	else if(tc_strcmp(Plant,"CVBU PUNE")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLP");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}else if(tc_strcmp(Plant,"DHARWAD")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLD");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}else if((tc_strcmp(Plant,"CVBU PNR")==0) || (tc_strcmp(Plant,"SMALLCAR PNR")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLU");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}
	else if((tc_strcmp(Plant,"PCBU")==0) || (tc_strcmp(Plant,"PCBU and CVBU")==0))
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLP");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);	
	}
	else if(tc_strcmp(Plant,"SMALLCAR AHD")==0)
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLA");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);	
	}
	else
	{
		tc_strcpy(PlantDup,"");
		tc_strcpy(PlantDup,"*APLP");
		printf("PLant Translated=%s\n",PlantDup);fflush(stdout);
	}
	CALLAPI(getDmlTagsBetweenDates(Datefrom,Dateto,releaseStatusStr,PlantDup, projlen, Project_code_ids, colmnLen, additional_attrs, Planner,&tagSetOut,&tag_cnt));
	
	int m =0;
	printf("\nTag count=%d\n",tag_cnt);fflush(stdout);
	array_size = tag_cnt;
	if(tag_cnt<=0)
	{
		return ifail;
	}
	
	//string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	tag_array = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	
	for(m=0;m<tag_cnt;m++)
	{
		tag_array[m] = tagSetOut[m];
	}

	printf("\nBefore returning Value\n");fflush(stdout);

	//ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);
	
	ifail = USERSERVICE_return_tag_array((const tag_t*)tag_array,array_size,&array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	printf("After returning Value\n");fflush(stdout);	
	printf("\n End----CommonAPLDMLBetweenReportsNew....\n");fflush(stdout);
	return ifail;
}
//End Sanjoy 





int getERCDmlTagsBetweenDates( char* Datefrom, char* Dateto, int projlen, char** Project_code_ids, tag_t** tagSetOut, int *tag_cnt  )
{
	
	printf("\nStart of getERCDmlTagsBetweenDates function....................\n");fflush(stdout);
	int ifail = ITK_ok;
	int k;
	date_t   a_date_from;
	date_t   a_date_to;	
	date_t   vals[2];	
	
	const char * select_attrs[]={"puid"};
	
	printf("From Date=%s\n",Datefrom);fflush(stdout);
	printf("To Date=%s\n",Dateto);fflush(stdout);
	
	ITK_string_to_date(Datefrom,&a_date_from);
	ITK_string_to_date(Dateto,&a_date_to);

	vals[0]=a_date_from;
	vals[1]=a_date_to;
	

	for(k=0;k<projlen;k++)
	{
		
		printf("\n Project[%d]==[%s]",k+1,Project_code_ids[k]);
		
	}
	printf("Argument Received Datefrom(getERCDmlTagsBetweenDates) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received Dateto(getERCDmlTagsBetweenDates) =%s\n",Dateto);fflush(stdout);

	
	printf("******Before creating POM_enquiry_create*********\n");fflush(stdout);
	
	/** Creating a POM Query **/
	CALLAPI(POM_enquiry_create("find_Dml_Number"));
	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);
	
	/** Adding select attribute to Query **/
	CALLAPI(POM_enquiry_add_select_attrs ("find_Dml_Number","ChangeRequestRevision",1,select_attrs));
	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);
	
	/**Setting Released Date **/
	CALLAPI(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));
	
	/** creating between Expression **/
	CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","ChangeRequestRevision","date_released",POM_enquiry_between,"expr_dates"));	
	
	
	printf("******Check Before POM_enquiry_set_attr_expr*********\n");fflush(stdout);
	 /**If project code is supplied as input**/
	if(projlen>0)
	{
		printf("Entered into Project list Section\n");fflush(stdout);
		CALLAPI(POM_enquiry_set_string_value ("find_Dml_Number","project_code_expr",projlen,(const char**)Project_code_ids,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_proj_in","ChangeRequestRevision","t5_cprojectcode",POM_enquiry_in,"project_code_expr"));	
		CALLAPI(POM_enquiry_set_expr ("find_Dml_Number","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_proj_in"));
		printf("exited from Project list Section\n");fflush(stdout);

		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_AND_expression"));
	}
	
	else
	{
		CALLAPI(POM_enquiry_set_where_expr ("find_Dml_Number","expr_dates_between"));
		printf("Project is null.... query erc dml rev only based on release dates\n");fflush(stdout);
	}
	

	tag_t objtag =NULLTAG;
	int  rows = 0, columns = 0;
	void ***report;
	int ii, num=0;




	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));

	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);

	CALLAPI(POM_enquiry_delete("find_Dml_Number"));

	printf("Check 1\n");fflush(stdout);
	

	printf("\ngetDmlTagsBetweenDates....After POM query execution....No of ROWs=====>%d",rows);fflush(stdout);
	if(rows > 0)
	{

		for (ii = 0; ii < rows; ii++ )
		{			
			objtag  = *(tag_t*)(report[ii][0]);
			if(objtag!=NULLTAG)
			{
				
				setAddTAG(tag_cnt,tagSetOut,objtag);
				
			}
			
		}
	}
	printf("\n End getDmlTagsBetweenDates.............. \n");fflush(stdout);
	return ifail;
	
	
}


//Start- sanjoy
int DmlTraceabilityReportServ(void *retValue)
{
	
	printf("\n Start----DmlTraceabilityReportServ....\n");fflush(stdout);
	
	const char	*prog_name 	="DmlTraceabilityReportServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	int tag_cnt=0;
	tag_t* tagSetOut = NULL;
	
	
	char* datefrom = NULL;
	char* dateto = NULL;
	int projlen=0;
    char** project_code_ids=NULL;	

	USERARG_get_string_argument(&datefrom);
	USERARG_get_string_argument(&dateto);	
	USERARG_get_string_array_argument(&projlen,&project_code_ids);		

	//print input parameters
	printf("datefrom==>%s\ndateto==>%s\n",datefrom,dateto);fflush(stdout);
	int i =0;
	for(i=0; i<projlen; i++)
	{
		printf("project_code_ids[%d]==>%s\n", i,project_code_ids[i]);fflush(stdout);
	}

	//end print input parameters
	


	
	
	//CALLAPI(getDmlTagsBetweenDates(Datefrom,Dateto,releaseStatusStr,PlantDup, projlen, Project_code_ids, colmnLen, additional_attrs, Planner,&tagSetOut,&tag_cnt));
	
	CALLAPI(getERCDmlTagsBetweenDates(datefrom,dateto,projlen,project_code_ids,&tagSetOut,&tag_cnt));
	
	int m =0;
	printf("\nTag count=%d\n",tag_cnt);fflush(stdout);
	array_size = tag_cnt;
	if(tag_cnt<=0)
	{
		return ifail;
	}
	
	tag_array = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	
	for(m=0;m<tag_cnt;m++)
	{
		tag_array[m] = tagSetOut[m];
	}

	printf("\nBefore returning Value\n");fflush(stdout);

	
	ifail = USERSERVICE_return_tag_array((const tag_t*)tag_array,array_size,&array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	printf("After returning Value\n");fflush(stdout);	
	printf("\n End----DmlTraceabilityReportServ....\n");fflush(stdout);
	return ifail;
}
//End Sanjoy 


//Sanjoy-DML Print Report

int getERCDmlOfPart(tag_t partTag, int *cnt ,tag_t **dmlTags)
{
	int ifail = ITK_ok;
	
	tag_t task_part_rel=NULLTAG;
	int task_cnt=0;
	CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &task_part_rel));

	tag_t* dmlTasks = NULLTAG;
	if(task_part_rel != NULLTAG)
	{
		CALLAPI(GRM_list_primary_objects_only(partTag,task_part_rel,&task_cnt,&dmlTasks));
		printf("\n task_cnt========>%d\n",task_cnt);fflush(stdout);
		if(task_cnt>0)
		{
			int i = 0;
			tag_t dml_task_rel = NULLTAG;
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel));
			if(dml_task_rel!=NULLTAG)
			{
				char* dml_task_class = NULL;
				int dml_cnt = 0;
				tag_t *dmls = NULLTAG;
				int j=0;
				char* dml_class = NULL;
				for(i=0;i<task_cnt;i++)
				{
					
					CALLAPI (AOM_ask_value_string(dmlTasks[i],"object_type",&dml_task_class));
					printf("\n dml_task_class========>%s\n",dml_task_class);fflush(stdout);
					if(tc_strcmp(dml_task_class,"T5_ChangeTaskRevision")==0)
					{	
						CALLAPI(GRM_list_primary_objects_only(dmlTasks[i],dml_task_rel,&dml_cnt,&dmls));
						printf("\n dml_cnt========>%d\n",dml_cnt);fflush(stdout);
						for(j=0;j<dml_cnt;j++)
						{
							CALLAPI (AOM_ask_value_string(dmls[i],"object_type",&dml_class));
							printf("\n dml_class========>%s\n",dml_class);fflush(stdout);
							if(tc_strcmp(dml_class,"ChangeRequestRevision")==0)
							{
								setAddTAG(cnt,dmlTags,dmls[j]);
							}
							
						}
						
					}
				}
			}
			else
			{
				printf("\n dml_task_rel is null tag\n");fflush(stdout);
			}
			
					
		}
		
	}	
	
	return ifail;
}
int getERCReleasedDate(tag_t dmlObj, char** ercRlzDate)
{
	int ifail = ITK_ok;
	
	//*ercRlzDate="test";

	int st_count		=	0;
	tag_t*			status_list			=	NULLTAG;
	int iStCnt		=	0;
	char* ercReleasedDate = NULL;
	CALLAPI(WSOM_ask_release_status_list(dmlObj,&st_count,&status_list));
	printf("\nChild Status Count  is :%d",st_count);	fflush(stdout);
	
	if(st_count>0)
	{
		for (iStCnt=0;iStCnt<st_count ;iStCnt++ )
		{
			char* c_st_class_name	=	NULL;
			char* c_st_ObjType	=	NULL;
			CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
			printf("\n c_st_class_name: %s\n",c_st_class_name);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(status_list[iStCnt],"object_type",&c_st_ObjType));
			printf("\n rlz status object_type: %s\n",c_st_ObjType);fflush(stdout);	

			
			if(tc_strcmp(c_st_class_name,"T5_LcsErcRlzd")==0)
			{
				
				CALLAPI(AOM_UIF_ask_value(status_list[iStCnt],"date_released",&ercReleasedDate));
				printf("\n ERC Released Date: %s\n",ercReleasedDate);fflush(stdout);
				*ercRlzDate= ercReleasedDate;
				break;

			}
		}
	}
	if(ercReleasedDate==NULL)
		*ercRlzDate="";
	
	return ifail;
}

int tmPrintDMLInFile(char *dmlNumber,tag_t dml_rev_tag,FILE * FileContent, char*** buffStr, int *cnt)
{
	int	ifail = ITK_ok;
	char* ReleaseType=NULL;
	char* Reason = NULL;
	char* projectCode = NULL;
	char **DesignGroupList;
	char *DMLDesignGroup = NULL;
	char* creatorStr = NULL;
	char* Synopsis = NULL;
	char* ReasonDesc = NULL;
	char* DMLobjectType = NULL;
	char* relzNote = NULL;
	char* ercReviewer = NULL;
	tag_t objectTypeTag = NULLTAG;
	char* drStatus = NULL;
	char* relzDate = NULL;
	char* aplrelzDate = NULL;
	char* stdsrelzDate = NULL;
	char* dmlLCS = NULL;
	char* relzType = NULL;
	char* trgPlnt = NULL;
	char* mmDmlType = NULL;
	char* mmDmlType1 = NULL;
	char* aplDMLType = NULL;
	char* aplDMLType1 = NULL;
	char* smDmlType = NULL;
	char* smDmlType1 = NULL;
	char* DmlDup = NULL;
	char* DmlDupID = NULL;
	tag_t itemDUP =NULLTAG;
	int k =0;
	int num=0;
	tag_t DML_Task_tag  = NULLTAG;
	tag_t Class_ID  = NULLTAG;
    tag_t *objectset_tag   = NULLTAG;
    int findDML = 0;
	int Q1 =0;
	char* objType = NULL;
	char* DMLNUM = NULL;
	

	
	//fprintf(DmlRelFile,"\n%135s","--------------------");fflush(stdout);
	printf("\n\n inside tmPrintDMLInFile :  \n"); fflush(stdout);

	if((tc_strstr(dmlNumber,"MM")==NULL)&&(tc_strstr(dmlNumber,"AM")==NULL)&&((tc_strstr(dmlNumber,"MBOM")!=NULL)||(tc_strstr(dmlNumber,"APL")!=NULL)))
	{
		printf("\t  DmlNumber : %s \n",dmlNumber); fflush(stdout);
		DmlDup=(char *) MEM_alloc(80);
		DmlDup = tc_strtok(dmlNumber,"_");
		printf("\t  DmlDup : %s \n",DmlDup); fflush(stdout);
		CALLAPI(ITEM_find_item(DmlDup,&itemDUP));
		ITKCALL(ITEM_ask_latest_rev(itemDUP,&dml_rev_tag));
		CALLAPI (AOM_UIF_ask_value(dml_rev_tag,"item_id",&DmlDupID));
	    printf("\t  DmlDupID : %s \n",DmlDupID); fflush(stdout);
	}
	
	CALLAPI (AOM_UIF_ask_value(dml_rev_tag,"t5_reason",&Reason));
	printf("\t  Reason : %s \n",Reason); fflush(stdout);
    CALLAPI(POM_class_of_instance(dml_rev_tag,&Class_ID));	
	CALLAPI(POM_name_of_class(Class_ID,&DMLobjectType));
	printf("\t  POM DMLobjectType : %s \n",DMLobjectType); fflush(stdout);
	CALLAPI (AOM_UIF_ask_value(dml_rev_tag,"t5_cprojectcode",&projectCode));
	printf("\t  Project Code : %s \n",projectCode); fflush(stdout);
	CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"owning_user",&creatorStr))
	printf("\t  creatorStr: %s \n", creatorStr);fflush(stdout);
	CALLAPI(AOM_ask_value_strings(dml_rev_tag,"t5_crdesigngroup",&num,&DesignGroupList));
	for (k=0;k<num;k++)
	{
		tc_strdup(DesignGroupList[k],&DMLDesignGroup);
		printf("\t  DMLDesignGroup : %s \n",DMLDesignGroup); fflush(stdout);

	}
	if(DMLDesignGroup==NULL) DMLDesignGroup="";
	CALLAPI(AOM_ask_value_string(dml_rev_tag,"object_name",&Synopsis))
	printf("\t  Synopsis: %s ", Synopsis);fflush(stdout);	
	
	CALLAPI (AOM_ask_value_string(dml_rev_tag,"t5_reasondesc",&ReasonDesc));
	printf("\n\t  ReasonDesc : %s \n",ReasonDesc); fflush(stdout);	
		
	CALLAPI (AOM_ask_value_string(dml_rev_tag,"t5_rlsltrnotes",&relzNote));
	printf("\t  Release Notes : %s \n",relzNote); fflush(stdout);
	CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"ChangeReviewBoard",&ercReviewer))
	printf("\t ERC Reviewer: %s ", ercReviewer);fflush(stdout);	
	CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"release_status_list",&dmlLCS))
	printf("\n\t LC State of DML: %s ", dmlLCS);fflush(stdout);
	CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_cDRstatus",&drStatus))
	printf("\n\t DR Status of  DML: %s ", drStatus);fflush(stdout);
	
	//CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"date_released",&relzDate))//tbi
//	CALLAPI(getERCReleasedDate(dml_rev_tag,&relzDate));
//	printf("\n Release Date  DML: %s ", relzDate);fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_TargetPlant",&trgPlnt))
	printf("\n\t Target Plant of  DML: %s ", trgPlnt);fflush(stdout);
	
	fprintf(FileContent,"\n%-26s","DML NO");fflush(stdout);
	fprintf(FileContent,": %-26s",dmlNumber);fflush(stdout);
//	fprintf(FileContent,"%-26s","Department");fflush(stdout);
//	fprintf(FileContent,": %-11s","");fflush(stdout);//tbi

	if(tc_strstr(dmlNumber,"MBOM")!=NULL)
	{
		fprintf(FileContent,"%-26s"," Department");fflush(stdout);
	    fprintf(FileContent,": %-11s","MBOM");fflush(stdout);
		if(tc_strstr(dmlNumber,"MM")!=NULL)
		{
		  CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_MBOMRlzType",&mmDmlType));
    	  printf("\n\n\t MMDml Type  full name : %s \n",mmDmlType); fflush(stdout);
		  CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_MBOMRlzType",&mmDmlType1));
    	  printf("\n\t MMDml Type   : %s \n",mmDmlType1); fflush(stdout);

		}
		else
		{
		  CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_rlstype",&mmDmlType));
	      printf("\n DML release type full name : %s \n",mmDmlType); fflush(stdout);	
          CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_rlstype",&relzType));
	      printf("\n DML release type  : %s \n",relzType); fflush(stdout);
		}
		fprintf(FileContent,"%-26s"," MBOM ReleaseType");fflush(stdout);
	    fprintf(FileContent,": %s",mmDmlType);fflush(stdout);

		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"date_released",&relzDate))
		printf("\n Release Date  DML: %s ", relzDate);fflush(stdout);
		//ReleasedDate to get and add
		//Department to add	

	}
	else if((tc_strstr(dmlNumber,"APL")!=NULL))
	{
		fprintf(FileContent,"%-26s"," Department");fflush(stdout);
	    fprintf(FileContent,": %-11s","APL");fflush(stdout);

		if((tc_strstr(dmlNumber,"AM")!=NULL))
		{
		  CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_EcnType",&aplDMLType));
    	  printf("\n\t AplDML Type  full name : %s \n",aplDMLType); fflush(stdout);
		  CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_EcnType",&aplDMLType1));
    	  printf("\n\t AplDML Type  : %s \n",aplDMLType1); fflush(stdout);
		  fprintf(FileContent,"%-26s"," ECN Type");fflush(stdout);
	      fprintf(FileContent,": %s",aplDMLType);fflush(stdout);

		}
		else
		{
		  CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_rlstype",&ReleaseType));
	      printf("\n DML release type full name : %s \n",ReleaseType); fflush(stdout);	
          CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_rlstype",&relzType));
	      printf("\n DML release type  : %s \n",relzType); fflush(stdout);
		  fprintf(FileContent,"%-26s"," Release Type");fflush(stdout);
	      fprintf(FileContent,": %s",ReleaseType);fflush(stdout);

		}

		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_APLReleaseDate",&aplrelzDate));
    	printf("\n AplDML t5_APLReleaseDate  : %s \n",aplrelzDate); fflush(stdout);
		fprintf(FileContent,"%-35s","   APLReleaseDate");fflush(stdout);
	    fprintf(FileContent," : %s",aplrelzDate);fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"CMClosureDate",&stdsrelzDate))
	    printf("\n STD Released  DML: %s ", stdsrelzDate);fflush(stdout);
		//ReleasedDate to get and add 
		//Department to add
	
	}
	else if((tc_strstr(dmlNumber,"SM")!=NULL))
	{
		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_SMDMLType",&smDmlType));
    	printf("\n SmDmlType  full name : %s \n",smDmlType); fflush(stdout);
		CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_SMDMLType",&smDmlType1));
    	printf("\n SmDmlType1  : %s \n",smDmlType1); fflush(stdout);

		fprintf(FileContent,"%-26s"," Department");fflush(stdout);
	    fprintf(FileContent,": %-11s","STD");fflush(stdout);
		fprintf(FileContent,"%-26s"," SMDML Type");fflush(stdout);
	    fprintf(FileContent,": %s",smDmlType);fflush(stdout);

		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"CMClosureDate",&stdsrelzDate))
		printf("\n STD Date  DML: %s ", stdsrelzDate);fflush(stdout);

		//ReleasedDate to get and add
		//Department to add

	}
	else
	{
		
		CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"t5_rlstype",&ReleaseType));
	    printf("\n DML release type full name : %s \n",ReleaseType); fflush(stdout);	
        CALLAPI(AOM_ask_value_string(dml_rev_tag,"t5_rlstype",&relzType));
	    printf("\n DML release type  : %s \n",relzType); fflush(stdout);	
		CALLAPI(getERCReleasedDate(dml_rev_tag,&relzDate));
	    printf("\n Release Date  DML: %s ", relzDate);fflush(stdout);

		fprintf(FileContent,"%-26s"," Department");fflush(stdout);
	    fprintf(FileContent,": %-11s","ERC");fflush(stdout);
		fprintf(FileContent,"%-26s"," Release Type");fflush(stdout);
	    fprintf(FileContent,": %s",ReleaseType);fflush(stdout);
	}
	
//	fprintf(FileContent,"%-26s","Release Type");fflush(stdout);
//	fprintf(FileContent," : %s",ReleaseType);fflush(stdout);
	
	fprintf(FileContent,"\n%-26s","Design Group");fflush(stdout);
	fprintf(FileContent,": %-26s",DMLDesignGroup);fflush(stdout);
	fprintf(FileContent,"%-26s","Project code");fflush(stdout);
	fprintf(FileContent,": %-11s",projectCode);fflush(stdout);
	
	fprintf(FileContent,"%-26s","Reason");fflush(stdout);
	fprintf(FileContent,": %s",Reason);fflush(stdout);
	
	fprintf(FileContent,"\n%-26s","Creator");fflush(stdout);
	fprintf(FileContent,": %-26s",creatorStr);fflush(stdout);
	
	fprintf(FileContent,"%-26s","DML DR-Status");fflush(stdout);
	fprintf(FileContent,": %-11s",drStatus);fflush(stdout);
	
	fprintf(FileContent,"%-26s","ERC Reviewer");fflush(stdout);
	fprintf(FileContent,": %s",ercReviewer);fflush(stdout);
	
	
	fprintf(FileContent,"\n%-26s","Synopsis");fflush(stdout);
	fprintf(FileContent,": %s",Synopsis);fflush(stdout);
	
	
	fprintf(FileContent,"\n%-26s","Reason Description");fflush(stdout);
	fprintf(FileContent,": %s",ReasonDesc);fflush(stdout);
	
	fprintf(FileContent,"\n%-26s","Release Notes");fflush(stdout);
	fprintf(FileContent,": %s",relzNote);fflush(stdout);	
	
	fprintf(FileContent,"\nLife Cycle State[%s]",dmlNumber);fflush(stdout);
	fprintf(FileContent,": %s",dmlLCS);fflush(stdout);	
	
	if((tc_strstr(dmlNumber,"APL")!=NULL) || (tc_strstr(dmlNumber,"SM")!=NULL)) 
	{
		fprintf(FileContent,"     STD Released Date");fflush(stdout);
	    fprintf(FileContent,": %s",stdsrelzDate);fflush(stdout);
	}
	else if(tc_strstr(dmlNumber,"MM")!=NULL)
	{
		fprintf(FileContent,"     MBOM Released Date");fflush(stdout);
	    fprintf(FileContent,": %s",relzDate);fflush(stdout);
	}
	else
	{
	  fprintf(FileContent,"     ERC Released Date");fflush(stdout);
	  fprintf(FileContent,": %s",relzDate);fflush(stdout);
	}
	
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&DML_Task_tag));
    if(DML_Task_tag!=NULLTAG)
     {
         tag_t  DMLRevQTag = NULLTAG;
        tag_t  *objectset_tag = NULLTAG;
		char* TempDml=NULL;
		char* Tempvalue1=NULL;
        char    *qry_DmlRev[1]  	= 	{"Item ID"};
        char	 **qry_ValueDMlRev	= 	(char **) MEM_alloc(5 * sizeof(char *));
        char 	 *keys[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
        int     num_to_sort =	1;
        int  	 orders[]  	=	{1};
        int     n_entries = 1;
        int     findDML   =   0;
        if(QRY_find("Item Revision...", &DMLRevQTag));
		if(DMLRevQTag!=NULLTAG)
        {
        	printf("\n\n  DML :%s\n",dmlNumber);fflush(stdout);
        	if((tc_strstr(dmlNumber,"APL")==NULL)&&(tc_strstr(dmlNumber,"MBOM")==NULL)&&(tc_strstr(dmlNumber,"SM")==NULL))
        	{
				Tempvalue1=(char *)MEM_alloc(80);
				tc_strcpy(Tempvalue1,"");
				tc_strcpy(Tempvalue1,dmlNumber);
				Tempvalue1=tc_strcat(Tempvalue1,"*");
        		qry_ValueDMlRev[0]=Tempvalue1;
        	}
        	else
        	{
             TempDml=(char *)MEM_alloc(80);
             Tempvalue1=(char *)MEM_alloc(80);
             tc_strcpy(TempDml,"");
             tc_strcpy(TempDml,dmlNumber);                     
             Tempvalue1 = tc_strtok(TempDml,"_");
			 Tempvalue1=tc_strcat(Tempvalue1,"*");
             qry_ValueDMlRev[0]=Tempvalue1;
        	}
			printf("\n tmPrintDMLInFile The Item num for query :%s\n",Tempvalue1);fflush(stdout);
			printf("\t DmlNumber : %s \n",dmlNumber);
             if(QRY_execute_with_sort(DMLRevQTag, n_entries, qry_DmlRev, qry_ValueDMlRev,num_to_sort, keys, orders, &findDML, &objectset_tag));
             printf("\n\t No. of Task Item Revision found : %d",findDML);fflush(stdout);
		     printf("\n\t DMLTaskRel : No of objects  found check is it erc dml  : %d \n",findDML); fflush(stdout);
		  for(Q1=0;Q1<findDML;Q1++)
		  {
			tag_t foundinset = NULLTAG;
			foundinset = objectset_tag[Q1];
			CALLAPI(AOM_ask_value_string(foundinset,"object_type",&objType));
            printf("\t Task Type: %s \n",objType); fflush(stdout);
			if((tc_strcmp(objType,"T5_MBOMDMLRevision")==0)||(tc_strcmp(objType,"T5_APLDMLRevision")==0))
				{
				  CALLAPI(AOM_ask_value_string(foundinset,"item_id",&DMLNUM));
                  printf("\t DMLNUM: %s \n",DMLNUM); fflush(stdout);
                  printf("\t dmlNumber: %s \n",dmlNumber); fflush(stdout);
				if(tc_strcmp(DMLNUM,dmlNumber)!=0)
				{
				  CALLAPI(AOM_UIF_ask_value(foundinset,"release_status_list",&dmlLCS))
	              printf("\t LC State of DML: %s ", dmlLCS);fflush(stdout);
				  fprintf(FileContent,"\nLife Cycle State[%s]",DMLNUM);fflush(stdout);
	              fprintf(FileContent," : %s",dmlLCS);fflush(stdout);
				  if(tc_strcmp(objType,"T5_MBOMDMLRevision")==0)
				 	{
		             CALLAPI(AOM_UIF_ask_value(foundinset,"date_released",&relzDate))
		             printf("\t Release Date  DML: %s ", relzDate);fflush(stdout);
				     fprintf(FileContent,"     MBOM Released Date");fflush(stdout);
	                 fprintf(FileContent," : %s",relzDate);fflush(stdout);
				 	}
				  if(tc_strcmp(objType,"T5_APLDMLRevision")==0)
				 	{
				 	 CALLAPI(AOM_UIF_ask_value(foundinset,"t5_APLReleaseDate",&aplrelzDate));
    	             printf("\t  APLReleaseDate  : %s \n",aplrelzDate); fflush(stdout);
		             fprintf(FileContent,"%-25s","   APLReleaseDate");fflush(stdout);
	                 fprintf(FileContent," : %s",aplrelzDate);fflush(stdout);
				 	}
		          CALLAPI(AOM_UIF_ask_value(foundinset,"CMClosureDate",&stdsrelzDate))
		          printf("\t STD Date  DML: %s \n", stdsrelzDate);fflush(stdout);
				  fprintf(FileContent,"     STD Released Date");fflush(stdout);
	              fprintf(FileContent,": %s",stdsrelzDate);fflush(stdout);
			   }
		     }
		   }
	   }

     }

	if((tc_strcmp(relzType,"XO")==0) || (tc_strcmp(relzType,"TODR")==0))
	{
		fprintf(FileContent,"\nTARGET PLANT");fflush(stdout);
		fprintf(FileContent,": %s",trgPlnt);fflush(stdout);//tbi	
	}
	else
	{
		fprintf(FileContent,"\nOther Design Group Affected");fflush(stdout);
		fprintf(FileContent,": %s","");fflush(stdout);
	}
	printf("\n at end of tmPrintDMLInFile : ..\n"); fflush(stdout);

	return ifail;
}

int tmPrintTaskRevisionInFile(tag_t task_rev_tag,FILE* DmlRelFile, char*** buffStr, int *cnt)
{
	int ifail=ITK_ok;
	char* TaskId = NULL;
	char* DMLNoDup = NULL;
	char* DMLNo = NULL;
	char* TaskDesignGroup = NULL;
	char* TaskSynopsis = NULL;
	char* TaskAnalyst = NULL;
	char* TaskAPlPlanner = NULL;
	char* Stdplanner= NULL;
	/*
	DesGrp     Task Id           Synopsis                                      ERC Analyst            APL Planner         STDS1 Planner
	-----------------------------------------------------------------------------------------------------------------------------------
	54    13PP266079_1054       X451-E&E TPL RELEASE FOR PHYSICAL FDJ          ashwini vinod tijare
	*/	

	
	fprintf(DmlRelFile,"\n%-10s%-22s%-70s%-30s%-30s%-30s","DesGrp","Task Id","Synopsis","ERC Analyst","APL Planner","STDS1 Planner");fflush(stdout);
	fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	
	
	//Get the required fields
	CALLAPI(AOM_UIF_ask_value(task_rev_tag,"item_id",&TaskId));
	printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);

	//get the task design group
	tc_strdup(TaskId,&DMLNoDup);
	DMLNo = strtok( DMLNoDup, "_" );
	TaskDesignGroup	  = strtok ( NULL, "_" );
	
	printf("\nTask ID==>%s\nDML No==>%s\nDesg Grp==>%s\n",TaskId,DMLNo,TaskDesignGroup);fflush(stdout);
	
	CALLAPI(AOM_UIF_ask_value(task_rev_tag,"object_desc",&TaskSynopsis));
	printf("\n DMLTaskRel : Task-Rev Synopsis : %s \n",TaskSynopsis); fflush(stdout);
	
	CALLAPI (AOM_ask_value_string(task_rev_tag,"analyst_user_id",&TaskAnalyst));
	printf("\n DMLTaskRel : Task-Rev TaskAnalyst : %s \n",TaskAnalyst); fflush(stdout);
	
	fprintf(DmlRelFile,"\n%-10s%-22s%-70s%-30s%-30s%-30s",TaskDesignGroup,TaskId,TaskSynopsis,TaskAnalyst," "," ");fflush(stdout);//tbi - Planner and STDSI Planner
	
	
	
	return ifail;
}

int tmPrintTaskRevisionInFile1(tag_t task_rev_tag,FILE* DmlRelFile, char*** buffStr, int *cnt,int DFlg)
{
	int ifail=ITK_ok;
	char* TaskId = NULL;
	char* DMLNoDup = NULL;
	char* DMLNo = NULL;
	char* TaskType = NULL;
	char* TaskDesignGroup = NULL;
	char* TaskSynopsis = NULL;
	char* TaskAnalyst = NULL;
	char* TaskRqstr = NULL;
	char* taskChgSp= NULL;
	char* taskChgSp2= NULL;
	/*
	DesGrp     Task Id           Synopsis                                      ERC Analyst            APL Planner         STDS1 Planner
	-----------------------------------------------------------------------------------------------------------------------------------
	54    13PP266079_1054       X451-E&E TPL RELEASE FOR PHYSICAL FDJ          ashwini vinod tijare
	*/	
    
	printf("\n inside tmPrintTaskRevisionInFile1 \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(task_rev_tag,"object_type",&TaskType));
    printf("\t Task Type: %s \n",TaskType); fflush(stdout);
	printf("\t DFlg : Task-Rev item_id flag : %d \n",DFlg); fflush(stdout);
	if(tc_strcmp(TaskType,"T5_MBOMTASKRevision")==0)
	{
		fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s","","","","MBOM Designer","MBOM Reviewer","MBOM Manager Reviewer");fflush(stdout);
	    //fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	
	}
	else if(tc_strcmp(TaskType,"T5_APLTaskRevision")==0)
	{
	   fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s","","","","APL Planner","APL Reviwer","STDS1 Analyst");fflush(stdout);
	   //fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	}
	else if(tc_strcmp(TaskType,"T5_SMDMLTaskRevision")==0)
	{
	   fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s","","","","","STDS1 Analyst","STDS1 Reviwer");fflush(stdout);
	   //fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	}
	else 
	{
		//FOR ERC dml driven
		fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s","","","","ERC Analyst","APL Planner","STDS1 Planner");fflush(stdout);
	    //fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	}
	

	//Get the required fields
	CALLAPI(AOM_UIF_ask_value(task_rev_tag,"item_id",&TaskId));
	printf("\t DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);

	//get the task design group
	tc_strdup(TaskId,&DMLNoDup);
	DMLNo = strtok( DMLNoDup, "_" );
	TaskDesignGroup	  = strtok ( NULL, "_" );
	
	printf("\t Task ID==>%s\nDML No==>%s\nDesg Grp==>%s\n",TaskId,DMLNo,TaskDesignGroup);fflush(stdout);
	
	CALLAPI(AOM_UIF_ask_value(task_rev_tag,"object_desc",&TaskSynopsis));
	printf("\t DMLTaskRel : Task-Rev Synopsis : %s \n",TaskSynopsis); fflush(stdout);
	
	CALLAPI (AOM_ask_value_string(task_rev_tag,"analyst_user_id",&TaskAnalyst));
	printf("\t DMLTaskRel : Task-Rev TaskAnalyst : %s \n",TaskAnalyst); fflush(stdout);

	CALLAPI (AOM_ask_value_string(task_rev_tag,"requestor_user_id",&TaskRqstr));
	printf("\t DMLTaskRel : Task-Rev TaskRqstr : %s \n",TaskRqstr); fflush(stdout);

	CALLAPI (AOM_ask_value_string(task_rev_tag,"change_specialist1_user_id",&taskChgSp));
	printf("\t DMLTaskRel : Task-Rev taskChgSpecialist : %s \n",taskChgSp); fflush(stdout);

	CALLAPI (AOM_ask_value_string(task_rev_tag,"change_specialist2_user_id",&taskChgSp2));
	printf("\t DMLTaskRel : Task-Rev taskChgSpecialist2 : %s \n",taskChgSp2); fflush(stdout);

	if(tc_strcmp(TaskType,"T5_MBOMTASKRevision")==0)
	{
		fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s",TaskDesignGroup,TaskId,TaskSynopsis,TaskRqstr,taskChgSp,taskChgSp2);fflush(stdout);//tbi - Planner and STDSI Planner  
	}
	else if(tc_strcmp(TaskType,"T5_APLTaskRevision")==0)
	{	
		fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s",TaskDesignGroup,TaskId,TaskSynopsis,TaskRqstr,taskChgSp,taskChgSp2);fflush(stdout);//tbi - Planner and STDSI Planner
	}
	else if(tc_strcmp(TaskType,"T5_SMDMLTaskRevision")==0)
	{	   
	   fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s",TaskDesignGroup,TaskId,TaskSynopsis," ",TaskRqstr,taskChgSp);fflush(stdout);//tbi - Planner and STDSI Planner
	}
	else 
	{
		fprintf(DmlRelFile,"\n%-10s%-25s%-90s%-30s%-30s%-30s",TaskDesignGroup,TaskId,TaskSynopsis,TaskAnalyst,taskChgSp,taskChgSp2);fflush(stdout);//tbi - Planner and STDSI Planner
	}
	printf("\n   at end of tmPrintTaskRevisionInFile1 \n"); fflush(stdout);
	return ifail;
}



int tmPrintPartsInFile(tag_t part_rev_tag,FILE * DmlRelFile,int prtcnt,char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	char* partNum = NULL;
	char* partDesc = NULL;
	char* rev = NULL;
	char* revStr = NULL;
	char* seq = NULL;
	char* seqStr = NULL;
	char* iaStr = NULL;
	char* csStr = NULL;
	char* ciStr = NULL;
	char* siStr = NULL;
	char* epaTask = NULL;
	char* esStr = NULL;
	char* rsfapStr = NULL;
	char* checkedBy = NULL;
	char* modDesc = NULL;
	//Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
	prtcnt++;
	//Assy-Partno
	CALLAPI(AOM_ask_value_string(part_rev_tag,"item_id",&partNum));
	printf("\ntmPrintPartsInFile:partNum: %s",partNum); fflush(stdout);
	
	//Assy-Part-Description
	CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&partDesc));
	printf("\ntmPrintPartsInFile:partDesc: %s",partDesc); fflush(stdout);
	if (partDesc==NULL)
	{
		tc_strdup("NA",&partDesc);
	}
	
	
	CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&rev));
	printf("\ntmPrintPartsInFile:rev:%s\n",rev); fflush(stdout);
	
	if(tc_strstr(rev,";") != NULL)
	{
		revStr = tc_strtok ( rev,";") ;
		//seqStr = tc_strtok ( NULL,";") ;	
	}
	

	CALLAPI (AOM_UIF_ask_value(part_rev_tag,"sequence_id",&seq));
	printf("\ntmPrintPartsInFile:seq:%s",seq); fflush(stdout);
	//IA
	
	//CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_CarIntialAgency",&iaStr));
	CALLAPI(AOM_ask_value_string(part_rev_tag,"t5_CarIntialAgency",&iaStr));
	printf("\ntmPrintPartsInFile:iaStr: %s",iaStr); fflush(stdout);
	
	//CS
	//CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_CarMakeBuyIndicator",&csStr));
	CALLAPI(AOM_ask_value_string(part_rev_tag,"t5_CarMakeBuyIndicator",&csStr));
	printf("\ntmPrintPartsInFile:csStr: %s",csStr); fflush(stdout);
	
	
	//SI
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_SpareInd",&siStr));
	printf("\ntmPrintPartsInFile:siStr: %s",siStr); fflush(stdout);
	
	//CI
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_ColourInd",&ciStr));
	printf("\ntmPrintPartsInFile:siStr: %s",ciStr); fflush(stdout);
	
	
	//Epa Task 
	//ES - 
	//RSFAP-DI(previous revision)
	//Checked By
	//Modification Description - t5_DocRemarks
	
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_DocRemarks",&modDesc));
	printf("\ntmPrintPartsInFile:modDesc: %s",modDesc); fflush(stdout);
	//,"\n%-5s%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s",
	fprintf(DmlRelFile,"\n%-5d%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s",prtcnt,partNum,partDesc,revStr,seq,iaStr,csStr,siStr,ciStr,"","","","",modDesc);fflush(stdout);
	
	return ifail;
}

int tmPrintPartsInFile1(char *DMLPlant,char *DMLDept,tag_t part_rev_tag,FILE * DmlRelFile,int prtcnt,char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	char* partNum = NULL;
	char* partDesc = NULL;
	char* rev = NULL;
	char* revStr = NULL;
	char* seq = NULL;
	char* seqStr = NULL;
	char* iaStr = NULL;
	char* csStr = NULL;
	char* ciStr = NULL;
	char* siStr = NULL;
	char* epaTasktmp = NULL;
	char* epaTask = NULL;
	char* esStrtmp = NULL;
	char* esStr = NULL;
	char* rsfapStr = NULL;
	char* checkedBy = NULL;
	char* modDesc = NULL;
	char* revtmp = NULL;

      tag_t	Cntl_obj_Qtag1	=	NULLTAG;
      tag_t	dml_task_rel	=	NULLTAG;
	  tag_t	*qry_cntrlobjval	=	NULLTAG;
	  tag_t	*primary_obj	=	NULLTAG;

	  printf("\n inside tmPrintPartsInFile1.... ");fflush(stdout);
	  printf("\n DMLPlant : %s",DMLPlant);fflush(stdout);
	  printf("\n DMLDept : %s",DMLDept);fflush(stdout);


		int n_entries1 =	3;
		int l =	0,u=0 ;
		int EPaES_cnt =	0;
		int resultCnt1 =	0;
		char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
		char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));

		char *InitailAgency	   = NULL;
		char *Info1	   = NULL;
		char *Info2	   = NULL;
        char *CSinfo 	   = NULL;

		if(QRY_find("Control Objects...", &Cntl_obj_Qtag1));
		if(Cntl_obj_Qtag1!=NULLTAG)
		{
			printf("\n NONERC DMLPRINT Control Object Query Found \n");fflush(stdout);
			qry_values11[0] ="NONERC";
			qry_values11[1] ="DMLPRINT";
			qry_values11[2] ="0";

			resultCnt1=0;
			
			CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries11, qry_values11, &resultCnt1, &qry_cntrlobjval));
			printf("\nNo. of control object found : %d\n",resultCnt1);fflush(stdout);

			if((resultCnt1>0) && ((tc_strcmp(DMLPlant,"")!=0) || (tc_strcmp(DMLDept,"")!=0)))
			{

			 for(l=0;l<resultCnt1;l++)
			 {
				printf("\nControl object result count is greater than 0 found \n");fflush(stdout);
				printf("\n\t\t found l : %d\n",l);fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[l], "t5_Userinfo1", &Info1));
				  printf("\n Info1 : %s",Info1);fflush(stdout);

				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[l], "t5_Userinfo2", &Info2));
				  printf("\n Info2 : %s",Info2);fflush(stdout);
				    if((tc_strcmp(Info1,DMLPlant)==0) && (tc_strstr(Info2,DMLDept)!=NULL))
				          {

							if(resultCnt1>0)
							 {
						          printf("\nControl object result count is greater than 0 dept and plant found \n");fflush(stdout);
								  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[l], "t5_Userinfo6", &InitailAgency));
								  printf("\n InitailAgency : %s",InitailAgency);fflush(stdout);

								  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[l], "t5_Userinfo7", &CSinfo));
								  printf("\n CSinfo : %s",CSinfo);fflush(stdout);
								  break;

							 }
						  }
						  else if(l==(resultCnt1-1))
				          {
							  InitailAgency=(char *) MEM_alloc(100);
			                  tc_strcpy(InitailAgency,"t5_CarIntialAgency");		                   
			                  CSinfo=(char *) MEM_alloc(100);
			                  tc_strcpy(CSinfo,"t5_CarMakeBuyIndicator");  
			                  printf("\n InitailAgency : %s",InitailAgency);fflush(stdout);
			                  printf("\n CSinfo : %s",CSinfo);fflush(stdout);
						  }
						  else
				          {
							  printf("\n Continue the loop to find PLANT details in CONTROL objects : ");fflush(stdout);
						  }
			  }
			}
			else
			{
				resultCnt1=0;
				printf("\nControl object result count is greater than 0 not found else loop \n");fflush(stdout);
				InitailAgency=(char *) MEM_alloc(100);
				tc_strcpy(InitailAgency,"t5_CarIntialAgency");

				CSinfo=(char *) MEM_alloc(100);
				tc_strcpy(CSinfo,"t5_CarMakeBuyIndicator");

				printf("\n InitailAgency : %s",InitailAgency);fflush(stdout);
			    printf("\n CSinfo : %s",CSinfo);fflush(stdout);
			}

		}
		
	//Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
	prtcnt++;
	//Assy-Partno
	CALLAPI(AOM_ask_value_string(part_rev_tag,"item_id",&partNum));
	printf("\ntmPrintPartsInFile1:partNum: %s",partNum); fflush(stdout);
	
	//Assy-Part-Description
	CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&partDesc));
	printf("\ntmPrintPartsInFile1:partDesc: %s",partDesc); fflush(stdout);
	if (partDesc==NULL)
	{
		tc_strdup("NA",&partDesc);
	}
	
	
	CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&rev));
	CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&revtmp));
	printf("\ntmPrintPartsInFile1:rev:%s\n",rev); fflush(stdout);
	
	if(tc_strstr(rev,";") != NULL)
	{
		revStr = tc_strtok ( rev,";") ;
		//seqStr = tc_strtok ( NULL,";") ;	
	}
	
	CALLAPI (AOM_UIF_ask_value(part_rev_tag,"sequence_id",&seq));
	printf("\ntmPrintPartsInFile1:seq:%s",seq); fflush(stdout);
	//IA
	
	//CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_CarIntialAgency",&iaStr));
	CALLAPI(AOM_ask_value_string(part_rev_tag,InitailAgency,&iaStr));
	printf("\ntmPrintPartsInFile1:iaStr: %s",iaStr); fflush(stdout);
	
	//CS
	//CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_CarMakeBuyIndicator",&csStr));
	CALLAPI(AOM_ask_value_string(part_rev_tag,CSinfo,&csStr));
	printf("\ntmPrintPartsInFile1:csStr: %s",csStr); fflush(stdout);
	
	
	//SI
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_SpareInd",&siStr));
	printf("\ntmPrintPartsInFile1:siStr: %s",siStr); fflush(stdout);
	
	//CI
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_ColourInd",&ciStr));
	printf("\ntmPrintPartsInFile1:ciStr: %s",ciStr); fflush(stdout);
	
	
	//Epa Task 
	tag_t part_EPA_REL = NULLTAG;
    tag_t part_ES_rel = NULLTAG;
    tag_t part_master = NULLTAG;
    tag_t part_add = NULLTAG;
    
    tag_t	*primary_objES	=	NULLTAG;
    int EPAOBcnt =0;
    int ESOBcnt =0;
    u =0;
    int ES1 = 0;
    char* epaTaskidtmp = NULL;
    char* esStridtmp = NULL;

	CALLAPI(ITEM_find_item(partNum,&part_master));
	if(part_master!=NULLTAG)
    {
    	printf("\nntmPrintPartsInFile1:ES Estimate_Relation part_master found"); fflush(stdout);
    }
	CALLAPI(ITEM_find_revision(part_master,revtmp,&part_add));
    CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &part_EPA_REL));
    CALLAPI(GRM_list_primary_objects_only(part_add,part_EPA_REL,&EPAOBcnt,&primary_obj));
    printf("\nntmPrintPartsInFile1:EPAOBcnt: %d ",EPAOBcnt); fflush(stdout);
    epaTask=(char *) MEM_alloc(100);
    tc_strcpy(epaTask,"");
    for(u=0;u<EPAOBcnt;u++)
    {
    	CALLAPI(AOM_UIF_ask_value(primary_obj[u],"object_type",&epaTasktmp));
        printf("\nntmPrintPartsInFile1:epaTask: %s",epaTasktmp); fflush(stdout);
    	if(tc_strcmp(epaTasktmp,"EPA Task Revision")==0)
    	{
    		CALLAPI(AOM_UIF_ask_value(primary_obj[u],"item_id",&epaTaskidtmp));
            printf("\nntmPrintPartsInFile1:epaTask: %s",epaTaskidtmp); fflush(stdout);
    		tc_strcpy(epaTask,epaTaskidtmp);
    		break;
    	}
    }
    CALLAPI(GRM_find_relation_type("T5_Design_Estimate_Relation", &part_ES_rel));

    CALLAPI(GRM_list_secondary_objects_only(part_master,part_ES_rel,&ESOBcnt,&primary_objES));
    printf("\ntmPrintPartsInFile1:ESOBcnt: %d ",ESOBcnt); fflush(stdout);
    esStr=(char *) MEM_alloc(300);
    tc_strcpy(esStr,"");
    for(ES1=0;ES1<ESOBcnt;ES1++)
    {
    	CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"object_type",&esStrtmp));
        printf("\nntmPrintPartsInFile1:esStrtmp: %s",esStrtmp); fflush(stdout);
    	//ES -
    	if(tc_strcmp(esStrtmp,"Estimate Sheet Revision")==0)
    	{
    		CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"item_id",&esStridtmp));
            printf("\nntmPrintPartsInFile1:esStridtmp: %s",esStridtmp); fflush(stdout);
    		tc_strcat(esStr,esStridtmp);
    		tc_strcat(esStr,",");
    	}
    
    }
    if(tc_strcmp(epaTask,"")==0)
    {
    	tc_strcpy(epaTask,"-");
    }
    if(tc_strcmp(esStr,"")==0)
    {
    	tc_strcpy(esStr,"-");
    }
	//RSFAP-DI(previous revision)
	//Checked By
	//Modification Description - t5_DocRemarks
	
	CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_DocRemarks",&modDesc));
	printf("\ntmPrintPartsInFile1:modDesc: %s",modDesc); fflush(stdout);
	//,"\n%-5s%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s",
	fprintf(DmlRelFile,"\n%-5d%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s",prtcnt,partNum,partDesc,revStr,seq,iaStr,csStr,siStr,ciStr,epaTask,esStr,"","",modDesc);fflush(stdout);
	
	return ifail;
}

int isPdfAttached(tag_t DesignRevTag, logical *result)
{
	int	ifail =	ITK_ok;
	tag_t refType = NULLTAG;
	int attchCnt = 0;
	tag_t* dsTags = NULLTAG;
	int i =0;
	tag_t dsTag = NULLTAG;
	char* partno = NULL;
	tag_t* namRefObjects = NULLTAG;
	*result = FALSE;
	
	CALLAPI(GRM_find_relation_type("IMAN_Rendering", &refType));
	if(refType != NULLTAG)
	{
		char* type_name = NULL;
		
		CALLAPI(AOM_ask_value_string(DesignRevTag,"item_id",&partno));
		CALLAPI(GRM_list_secondary_objects_only(DesignRevTag, refType, &attchCnt, &dsTags));
		printf("\nTotal no of attachs = %d \n",attchCnt);fflush(stdout);
		for(i=0;i<attchCnt;i++)
		{
			dsTag = dsTags[i];
			CALLAPI(AOM_ask_value_string(dsTag,"object_type",&type_name));
			if(tc_strcmp(type_name,"PDF") ==0)
			{
				int ref_count = 0;
				CALLAPI(AE_ask_dataset_named_refs(dsTag,&ref_count, &namRefObjects));
				printf("ref_count Count: %d\n", ref_count);

				if(ref_count > 0)
				{
					*result = TRUE;
					printf("\nPDF Drawing is attached to the part %d\n", partno);fflush(stdout);
					break;
				}

			}
			
			
		}
	}
	if(namRefObjects!= NULLTAG) MEM_free(namRefObjects);
	if(dsTags!=NULLTAG) MEM_free(dsTags);

	
	return ifail;
	
}


int isPdfAttachedAsImanSpec(tag_t DesignRevTag, logical *result)
{
	int	ifail =	ITK_ok;
	tag_t refType = NULLTAG;
	int attchCnt = 0;
	tag_t* dsTags = NULLTAG;
	int i =0;
	tag_t dsTag = NULLTAG;
	char* partno = NULL;
	tag_t* namRefObjects = NULLTAG;
	*result = FALSE;
	
	CALLAPI(GRM_find_relation_type("IMAN_specification", &refType));
	if(refType != NULLTAG)
	{
		char* type_name = NULL;
		
		CALLAPI(AOM_ask_value_string(DesignRevTag,"item_id",&partno));
		CALLAPI(GRM_list_secondary_objects_only(DesignRevTag, refType, &attchCnt, &dsTags));
		printf("\nTotal no of attachs = %d \n",attchCnt);fflush(stdout);
		for(i=0;i<attchCnt;i++)
		{
			dsTag = dsTags[i];
			CALLAPI(AOM_ask_value_string(dsTag,"object_type",&type_name));
			if(tc_strcmp(type_name,"PDF") ==0)
			{
				int ref_count = 0;
				CALLAPI(AE_ask_dataset_named_refs(dsTag,&ref_count, &namRefObjects));
				printf("ref_count Count: %d\n", ref_count);

				if(ref_count > 0)
				{
					*result = TRUE;
					printf("\nPDF Drawing is attached to the part %d\n", partno);fflush(stdout);
					break;
				}

			}
			
			
		}
	}
	if(namRefObjects!= NULLTAG) MEM_free(namRefObjects);
	if(dsTags!=NULLTAG) MEM_free(dsTags);

	
	return ifail;
	
}

int tmDrwgsDetails(int n_parts,tag_t* part_obj_tag,FILE* DmlRelFile,char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	int i=0;
	int drgCnt =0;
	
	if(n_parts>0)
	{
		drgCnt = 0;
		tag_t partRevTag = NULLTAG;
		char* partNumber = NULL;
		char* partRev = NULL;
		char* partSeq = NULL;
		int dataset_count = 0;
		tag_t* datasetObjects = NULLTAG;
		for(i=0;i<n_parts;i++)
		{
			partRevTag = part_obj_tag[i];
			char* datasetObjectType = NULL;
			char* datasetName = NULL;
			char* datasetDesc = NULL;
			int dataCnt = 0;
			char* modDesc = NULL;
			char* drawingNo = NULL;
			char* drawingNoDup = NULL;
			char* drwRev = NULL;
			char* drwSeq = NULL;
			char* drwNo = NULL;
			char* drwRevSeq = NULL;
			if(partRevTag!=NULLTAG)
			{
				CALLAPI((AOM_ask_value_string(partRevTag,"item_id",&partNumber)));
				CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev));
				CALLAPI(AOM_UIF_ask_value(partRevTag,"sequence_id",&partSeq));
				printf("\n partNumber-->[%s]\n",partNumber);fflush(stdout);
				printf("\n partRev-->[%s]\n",partRev);fflush(stdout);
				printf("\n partSeq-->[%s]\n",partSeq);fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(partRevTag,"t5_DocRemarks",&modDesc));
				printf("\ntmDrwgsDetails:modDesc: %s",modDesc); fflush(stdout);
				
				CALLAPI(AOM_UIF_ask_value(partRevTag,"t5_DrawingNo",&drawingNo));
				printf("\ntmDrwgsDetails:t5_DrawingNo: %s",drawingNo); fflush(stdout);
				
				if(drawingNo != NULL)
				{
					drawingNoDup = (char*)MEM_alloc(40*sizeof(char));
					drawingNoDup = tc_strtok ( drawingNo,"/") ;
					//tc_strcpy(drawingNoDup,drawingNo);
					printf("\nDrw No drawingNo : %s\n",drawingNo);fflush(stdout);
					printf("\nDrw No drawingNoDup : %s\n",drawingNoDup);fflush(stdout);
					if(tc_strstr(drawingNoDup,"_"))
					{
						drwNo = tc_strtok ( drawingNoDup,"_") ;
						drwRev = tc_strtok ( NULL,"_") ;
						drwSeq = tc_strtok ( NULL,"_") ;
					}
					printf("\nDrw Rev : %s\n",drwRev);fflush(stdout);
					printf("\nDrw Seq : %s\n",drwSeq);fflush(stdout);
					

					if(drwRev!=NULL && drwSeq !=NULL)
					{
						drwRevSeq = (char*)MEM_alloc(20*sizeof(char));
						tc_strcpy(drwRevSeq,drwRev);
						tc_strcat(drwRevSeq,";");
						tc_strcat(drwRevSeq,drwSeq);
					}
					else
					{
						drwRevSeq = "";				
					}

					if(drawingNoDup) MEM_free(drawingNoDup);
					
				}
				
				//Get the IMAN_specification objects(cad objects) for the parts
				CALLAPI(AOM_ask_value_tags (partRevTag,"IMAN_specification",&dataset_count, &datasetObjects));
				printf("\ntmDrwgsDetails:dataset_count:%d\n",dataset_count);fflush(stdout);
				if(dataset_count==0)
				{
					printf("\ntmDrwgsDetails: No Dataset objects...\n");fflush(stdout);
				}
				for(dataCnt=0; dataCnt<dataset_count; dataCnt++)
				{
					CALLAPI(AOM_ask_value_string(datasetObjects[dataCnt],"object_type",&datasetObjectType));
					CALLAPI(AOM_ask_value_string(datasetObjects[dataCnt],"object_name",&datasetName));
					CALLAPI(AOM_ask_value_string(datasetObjects[dataCnt],"object_desc",&datasetDesc));
					
					if(tc_strcmp(datasetObjectType,"CMI2Drawing")==0 || tc_strcmp(datasetObjectType,"Creo drawing")==0 || tc_strcmp(datasetObjectType,"T5_AutoCADDrw")==0 || tc_strcmp(datasetObjectType,"ProDrw")==0) //T5_AutoCADDrw,CMI2Drawing, ProDrw,Creo drawing
					{
						logical pdfFlg = false;
						logical pdfFlg1 = false;
						
						CALLAPI(isPdfAttached(partRevTag,&pdfFlg));
						printf("\n PDF Flag == %d \n",pdfFlg);fflush(stdout);
						
						CALLAPI(isPdfAttachedAsImanSpec(partRevTag,&pdfFlg1));
						printf("\n PDF Flag (Iman spec)== %d \n",pdfFlg1);fflush(stdout);
						
						if(pdfFlg || pdfFlg1)
						{
							drgCnt++;
							printf("\n Data set of Drawing found\n");fflush(stdout);
							fprintf(DmlRelFile,"\n%-5d%-20s%-6s%-70s%-100s",drgCnt, datasetName,drwRevSeq,datasetDesc,modDesc);fflush(stdout);
						}
						

					}
					
				}
				
				printf("\nDrwaing count===>%d\n", drgCnt);fflush(stdout);
				
				//if(drwRevSeq) MEM_free(drwRevSeq);
			}
		}
	}
	
	
	return ifail;
}

typedef struct PartModel_
{
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel6");fflush(stdout);
}

typedef struct QtyChangeModel_
{
 tag_t currLineItem;
 tag_t prevLineItem;
 char* currQty;
 char* prevQty;
} *QtyChangeModel;

void setAddQtyChangeModel(int *count,QtyChangeModel **objlist,QtyChangeModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (QtyChangeModel *)malloc((*count ) * sizeof(QtyChangeModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (QtyChangeModel *)realloc((*objlist),(*count) * sizeof(QtyChangeModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel6");fflush(stdout);
}

int getRevisionRuleObject(char *revisionRuleName, tag_t *revisonRuleObj)
{
	int ifail = ITK_ok;
	int flagRevRule =0;
	//get the Revision Rule Object
	

	CALLAPI(CFM_find(revisionRuleName, revisonRuleObj));
	if (revisonRuleObj != NULLTAG)
	{
		printf("\nFind revRule\n");fflush(stdout);
		flagRevRule = 1;
		
	}
	
	printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	
	return ifail;
}

int getClosureRuleObject(char* closureRuleName,tag_t *closureRuleObj)
{
	int ifail = ITK_ok;
	PIE_scope_t scope;
	int closureTagCnt = 0;
	tag_t *closureTags = NULLTAG;
	int flagClosureRule = 0;
	//get the Revision Rule Object
	


	scope=PIE_TEAMCENTER;
	CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&closureTagCnt,&closureTags));
	printf("\n closureTagCnt:%d ..............",closureTagCnt);fflush(stdout);
	if(closureTagCnt==1)
	{
		*closureRuleObj=closureTags[0];
		flagClosureRule=1;
	}
	printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	
	return ifail;
}

int getBomViewRevObject(tag_t partRevObj,char* bvrName, tag_t* bomViewObj)
{
	int ifail = ITK_ok;
	const char	*prog_name 		="getBomViewRevObject";
	tag_t partMaster 		= NULLTAG;
	int n_bom_views         = 0;
	tag_t *bom_views        = NULL;
	tag_t viewObj 			= NULLTAG;
	tag_t view_type 		= NULLTAG;
	char* view_type_name = NULL;
	char* partNumber = NULL;
	char* partRev = NULL;
	if(partRevObj == NULLTAG)
	{
		printf("\ngetBomViewRevObject: Part Object is NULLTAG\n");fflush(stdout);
		return ifail;
	}	
	// Get the Item from the revision
	CALLAPI(ITEM_ask_item_of_rev(partRevObj, &partMaster)); 
	
	//Get the tags of all bom views related to the Item.
	CALLAPI(ITEM_list_bom_views(partMaster, &n_bom_views, &bom_views ));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_id",&partNumber));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_revision_id",&partRev));
	printf("\n Part number===>%s,%s\n",partNumber,partRev);fflush(stdout);	
	printf("\n Part n_bom_views===>%d \n",n_bom_views);fflush(stdout);	


	if(n_bom_views>0)
	{
		int j = 0;
		printf("\ngetBomViewRevObject: %s.%s having below bom views...\n", partNumber,partRev);fflush(stdout);
		for(j=0;j<n_bom_views;j++)
		{
			//Get the view type of the BOMView
			CALLAPI(PS_ask_bom_view_type(bom_views[j],&view_type))
			
			//Get the name of the view type
			CALLAPI(PS_ask_view_type_name(view_type, &view_type_name));
			printf("\nview_type_name ===>%s\n", view_type_name);fflush(stdout);
			printf("\nbvrName===>%s\n", bvrName);fflush(stdout);
			
			
			if(tc_strcmp(view_type_name, bvrName) == 0 )
			{
				printf("\ngot BVR----->test\n");fflush(stdout);
				viewObj = bom_views[j];
				break;
			}
			else
			{
				printf("\n NO BVR----->test\n");fflush(stdout);
			}
			
		}
		*bomViewObj = viewObj;
		
	}
	return ifail;
	
}


int getFirstLevelChildObjs(tag_t window, tag_t partRevObj, PartModel** partModelList, int *partModelListCnt, char* bvrViewName, char * revisionRuleName, char* closureRuleName)
{
	int ifail = ITK_ok;
	
	tag_t partRevisionRule = NULLTAG;
	tag_t bomViewObj = NULLTAG;
	int flagRevRule = 0;
	
	printf("\nRevision rule name:====>%s",revisionRuleName);fflush(stdout);
	CALLAPI(getRevisionRuleObject(revisionRuleName,&partRevisionRule));
	if(partRevisionRule !=NULLTAG)
	{
		printf("\n Revision Rule not null........\n");fflush(stdout);
		flagRevRule = 1;
	}
	else
	{
		flagRevRule = 0;
	}
	
	printf("\n flagRevRule============>[%d] ",flagRevRule);fflush(stdout);
	
		
	CALLAPI(getBomViewRevObject(partRevObj,bvrViewName, &bomViewObj));	
	if(bomViewObj == NULLTAG)
	{
		printf("\n BOM VIEW Revision does not exist........\n");fflush(stdout);
		return ifail;
	}
	else
	{
		if(flagRevRule == 1)
		{
			tag_t closureRuleObj = NULLTAG;
			int flagClosureRule = 0;
			tag_t t_ItemTag 		= NULLTAG;
			tag_t top_line			= NULLTAG;
			tag_t  *childs		    = NULLTAG;
			int child_count         = 0;
			int i=0;			
			CALLAPI(getClosureRuleObject(closureRuleName,&closureRuleObj));
			if(closureRuleObj!=NULLTAG)
			{
				
				printf("\n Closure Rule not null........\n");fflush(stdout);
				flagClosureRule = 1;
			}
			else
			{
				printf("\n Closure Rule NULL........\n");fflush(stdout);
				flagClosureRule = 0;
			}
			printf("\n flagClosureRule================>%d\n", flagClosureRule);fflush(stdout);
			
			//tag_t window = NULLTAG;
			//CALLAPI(BOM_create_window (&window));
			CALLAPI(BOM_set_window_config_rule(window,partRevisionRule));
			if(flagClosureRule ==1)
				CALLAPI(BOM_window_set_closure_rule(window,closureRuleObj,0,NULL,NULL));
			
			
			CALLAPI(BOM_set_window_top_line(window, t_ItemTag,partRevObj ,bomViewObj, &top_line));
			CALLAPI(BOM_line_ask_child_lines (top_line, &child_count, &childs));
			printf("\nNo of child objects are n : %d\n",child_count);fflush(stdout);
			
		
			tag_t childItemTag = NULLTAG;
			tag_t childItemRevObj = NULLTAG;
			char* partNumberStr1 = NULL;
			PartModel partMdl = NULL;
			

			for (i = 0; i< child_count; i++)
			{
				//CALLAPI(BOM_line_unpack (childs[i]));
				CALLAPI(BOM_line_pack(childs[i]));
				CALLAPI(BOM_line_look_up_attribute (( char * )bomAttr_lineItemRevTag , &childItemTag));
				CALLAPI(BOM_line_ask_attribute_tag(childs[i], childItemTag, &childItemRevObj));
				if(childItemRevObj != NULLTAG)
				{
					
					CALLAPI(AOM_ask_value_string(childItemRevObj,"item_id",&partNumberStr1));
					printf("\n partNumberStr1================>%s\n", partNumberStr1);fflush(stdout);
					partMdl = (PartModel)malloc(sizeof(PartModel));
					partMdl->childItemRev = childItemRevObj;
					partMdl->childBomLine = childs[i];

					setAddPartModel(partModelListCnt, partModelList, partMdl);
					printf("\n partModelListCnt from partmodel================>%d\n", *partModelListCnt);fflush(stdout);
				}
			}
			//Close bom window
			//if(window !=NULLTAG) CALLAPI(BOM_close_window(window));
		}
	}
	
	
	return ifail;
}

int getPrevOfficialRev(tag_t itemMstr, tag_t curTag, tag_t* prevTag)
{
	int ifail = ITK_ok;
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULLTAG;
	
	char* currItemId = NULL;
	char* currPartRev = NULL;
	
	date_t curr_creation_dt;
	date_t prev_creation_dt;
	int ans =0;
	CALLAPI(AOM_ask_value_string(curTag,"item_id",&currItemId))
	CALLAPI(AOM_ask_value_string(curTag,"item_revision_id",&currPartRev))
	CALLAPI(AOM_ask_value_date(curTag,"creation_date",&curr_creation_dt));

	
	CALLAPI(ITEM_list_all_revs (itemMstr, &partRevCnt, &partRevTagObjs));
	printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
	if(partRevCnt>0)
	{
		int i=0;
		tag_t partRevTag = NULLTAG;
		for(i=partRevCnt-1;i>=0;i--)
		{
			partRevTag = partRevTagObjs[i];
			char* itemId = NULL;
			char* partRev = NULL;
			char* rel_status = NULL;
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))	
			
			
			CALLAPI(AOM_ask_value_date(partRevTag,"creation_date",&prev_creation_dt));
			CALLAPI(POM_compare_dates(prev_creation_dt, curr_creation_dt, &ans));
			if(ans==1) continue;//Ignore the part created later that the current part
			
			if(tc_strcmp(partRev,currPartRev)==0)
			{
				continue;
			}
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				*prevTag = partRevTag;
				printf("\nPrevious official revision of part %s;%s is %s;%s\n",currItemId,currPartRev,itemId,partRev);fflush(stdout);
				break;
			}
			
				
		}
	}
	
	
	return ifail;
}

int getPrevOfficialRev1(tag_t itemMstr,char* rlsinfo,tag_t curTag, tag_t* prevTag)
{
	int ifail = ITK_ok;
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULLTAG;
	
	char* currItemId = NULL;
	char* currPartRev = NULL;
	
	date_t curr_creation_dt;
	date_t prev_creation_dt;
	int ans =0;
	CALLAPI(AOM_ask_value_string(curTag,"item_id",&currItemId))
	CALLAPI(AOM_ask_value_string(curTag,"item_revision_id",&currPartRev))
	CALLAPI(AOM_ask_value_date(curTag,"creation_date",&curr_creation_dt));

	
	CALLAPI(ITEM_list_all_revs (itemMstr, &partRevCnt, &partRevTagObjs));
	printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
	
	if(partRevCnt>0)
	{
		int i=0;
		tag_t partRevTag = NULLTAG;
		for(i=partRevCnt-1;i>=0;i--)
		{
			partRevTag = partRevTagObjs[i];
			char* itemId = NULL;
			char* partRev = NULL;
			char* rel_status = NULL;
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))	

			printf("\t\tPart Revision rls status to cmpr with rlsinfo :%s\n",rlsinfo);fflush(stdout);
			printf("\t\tPart Revision  rel_status :%s\n",rel_status);fflush(stdout);
			
			CALLAPI(AOM_ask_value_date(partRevTag,"creation_date",&prev_creation_dt));
			CALLAPI(POM_compare_dates(prev_creation_dt, curr_creation_dt, &ans));
			
			if(ans==1) continue;//Ignore the part created later that the current part
			
			if(tc_strcmp(partRev,currPartRev)==0)
			{
				continue;
			}
			if(tc_strstr(rel_status,rlsinfo)!=NULL)
			{
				*prevTag = partRevTag;
				printf("\nPrevious official revision of part %s;%s is %s;%s\n",currItemId,currPartRev,itemId,partRev);fflush(stdout);
				break;
			}
			
				
		}
	}
	
	
	return ifail;
}

int tmStructureChanges(int n_parts,tag_t* part_obj_tag, FILE* DmlRelFile,char*** buffStr, int *cnt, int *prtAddCnt, int *prtDelCnt, int *prtQtyChngCnt)
{
	int ifail = ITK_ok;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;	
	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);	
	
	if(n_parts>0)
	{
		int j=0;
		tag_t curr_rev_tag = NULLTAG;
		char* parentpartId = NULLTAG;
		char* RevisionS = NULL;
		char* obj_desc = NULL;
		tag_t itemMstr = NULLTAG;
		tag_t prev_rev_tag = NULLTAG;
		int srNo =0;
		for(j=0;j<n_parts;j++)
		{
			curr_rev_tag=NULLTAG;
			curr_rev_tag=part_obj_tag[j];
			prev_rev_tag = NULLTAG;
			PartModel * currPartModelList;
			int currPartModelListCnt = 0;
			PartModel* prevPartModelList;
			int prevPartModelListCnt =0;
			tag_t* addedChildLine = NULLTAG;
			int addedChildLineCnt = 0;
			tag_t* delChildLine = NULLTAG;
			int delChildLineCnt = 0;
			tag_t* qtyChildLine = NULLTAG;
			int qtyChildLineCnt = 0;	
			char** prevQtyStr = NULL;
			int prevQtyStrCnt = 0;			
			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&parentpartId));
			ITEM_ask_item_of_rev(curr_rev_tag,&itemMstr);

			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_revision_id",&RevisionS));
			printf("\ntmStructureChanges:RevisionS %s \n",RevisionS); fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(curr_rev_tag,"object_desc",&obj_desc));
			printf("\ntmStructureChanges:obj_desc %s \n",obj_desc); fflush(stdout);
			
			tag_t window = NULLTAG;
			tag_t window1 = NULLTAG;
			CALLAPI(BOM_create_window (&window));
			//Get Child objs of currnt rev objs)
			CALLAPI(getFirstLevelChildObjs(window,curr_rev_tag,&currPartModelList,&currPartModelListCnt, "view", "Latest Working", ""));//T5_DFMA, view
			
			printf("\n Child Count of Current Part============>%d\n",currPartModelListCnt);fflush(stdout);
			//Get previous official Revision of the part object.
			CALLAPI(getPrevOfficialRev(itemMstr,curr_rev_tag,&prev_rev_tag));
			
			
			if(prev_rev_tag != NULLTAG)
			{
				
				CALLAPI(BOM_create_window (&window1))
				CALLAPI(getFirstLevelChildObjs(window1, prev_rev_tag,&prevPartModelList,&prevPartModelListCnt, "view", "Latest Working", ""));//T5_DFMA, view
			}
			else
			{
				printf("\n No previous official revision for part %s:%s\n",parentpartId,RevisionS);fflush(stdout);
				
			}
			printf("\n Child Count of Prev official rev  Part============>%d\n",prevPartModelListCnt);fflush(stdout);
			
			
			//CALLAPI(tmStructureChangesFunc(curr_rev_tag,curr_rev_tag,currPartModelListCnt,currPartModelList,prevPartModelListCnt,prevPartModelList,prtAddCnt,prtDelCnt,prtQtyChngCnt));
			
			if(prev_rev_tag==NULLTAG)//The part is getting released first time - no structure change
			{
				//print the currPartModelList as added parts.
				continue;
			}
			else
			{
				
				//fprintf(DmlRelFile,"\n -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				int c=0;
				int p =0;
				tag_t currChild = NULLTAG;
				tag_t currChildLine = NULLTAG;
				tag_t prevChild = NULLTAG;
				tag_t prevChildLine = NULLTAG;
				int  itemId_attribute = 0;
				int  rev_attribute = 0;
				int  qty_attribute = 0;
				char* currQty = NULL;
				char* currRev = NULL;
				char* currItemId = NULL;
				char* prevItemId = NULL;
				char* prevRev = NULL;
				char* prevQty = NULL;
				
				char* currOccId = NULL;
				char **curidlist=NULL;
				int  curidlist_cnt=0;
				int curQtylist_cnt = 0;
				char** curQtylist = NULL;
				
				char* prevOccId = NULL;
				char **previdlist=NULL;
				int  previdlist_cnt=0;
				int prevQtylist_cnt = 0;
				char** prevQtylist = NULL;
				
				
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine = currPartModelList[c]->childBomLine;
					if(currChildLine == NULLTAG)
						printf("\n currChildLine is null tag\n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setAddStr(&curidlist_cnt,&curidlist,currOccId);

					CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQty));
					setAddStr(&curQtylist_cnt,&curQtylist,currQty);
				
				}
				
				for(p=0;p<prevPartModelListCnt;p++)
				{
					prevChildLine = prevPartModelList[p]->childBomLine;
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_clone_stable_occurrence_id", &prevOccId));
					setAddStr(&previdlist_cnt,&previdlist,prevOccId);
					
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_quantity", &prevQty));
					setAddStr(&prevQtylist_cnt,&prevQtylist,prevQty);					
					
				}
				
				//Addition logic
				int toadd = 0;
				
				addedChildLine = NULLTAG;
				addedChildLineCnt = 0;
				
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine = currPartModelList[c]->childBomLine;
					
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setFindStr(previdlist,previdlist_cnt,currOccId,&toadd);
					
					//addition logic
					if(toadd==0)
					{
						printf("\n Inside new added object Found");fflush(stdout);
						char *currItemIdStr =  NULL;
						char* currQtyStr = NULL;
						int d = 0;
						*prtAddCnt = *prtAddCnt + 1;
						
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_item_item_id", &currItemIdStr));
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQtyStr));
						printf("\n Part Added ==>%s, Quantity====>%s\n",currItemIdStr,currQtyStr);
						setAddTAG(&addedChildLineCnt, &addedChildLine,currChildLine);
						

					}
					
					
				}
				
				//Deletion logic
				int todel = 0;
				delChildLine = NULLTAG;
				delChildLineCnt = 0;				
				for(c=0;c<prevPartModelListCnt;c++)
				{
					prevChildLine = prevPartModelList[c]->childBomLine;
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_clone_stable_occurrence_id", &prevOccId));
					setFindStr(curidlist,curidlist_cnt,prevOccId,&todel);
					if(todel ==0)
					{
						//printf deleted part details
						*prtDelCnt = *prtDelCnt + 1;
						setAddTAG(&delChildLineCnt, &delChildLine,prevChildLine);
					}						
					
				}
				
				//Quantity change
				int toQty = 0;
				qtyChildLine = NULLTAG;
				qtyChildLineCnt = 0;	
				prevQtyStr = NULL;
				prevQtyStrCnt = 0;
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine =currPartModelList[c]->childBomLine;
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setFindStr(previdlist,previdlist_cnt,currOccId,&toQty);
					
					if(toQty == 1)
					{
						int idx=-1;
						char *prevQnty=NULL;
						char* curQtyStr = NULL;
						getIndex(previdlist,previdlist_cnt,currOccId,&idx);
						getStrByIndex(prevQtylist,prevQtylist_cnt,idx,&prevQnty);
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &curQtyStr));
						if(tc_strcmp(curQtyStr,prevQnty)!=0)
						{
							//printf quantity change parts
							*prtQtyChngCnt =*prtQtyChngCnt + 1;
							setAddTAG(&qtyChildLineCnt, &qtyChildLine,currChildLine);
							setAddStr(&prevQtyStrCnt, &prevQtyStr,prevQnty);
						}
						
					}
					
				}
				
				
			}
			
			//print header part
			if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
			{
				fprintf(DmlRelFile,"\n\n STRUCTURE CHANGES");fflush(DmlRelFile);
				fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				//parentpartId,RevisionS
				srNo++;
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s%-5s",srNo, parentpartId,RevisionS,obj_desc);fflush(stdout);
			}
			//print add part details
			
			if(addedChildLineCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   REPLACES_PARTNO
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","","Added Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","REPLACES_PARTNO");fflush(stdout);
	
				int k=0;
				char* addPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				
				for(k=0;k<addedChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_item_item_id", &addPartId));
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(addedChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_item_revision_id",&rev));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(addedChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task

					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",addPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,"","","","");fflush(stdout);
				}
			}
			
			//print del part details
			if(delChildLineCnt>0)
			{
				
				
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","","Deleted Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","RSFAP(DI)");fflush(stdout);
				int k=0;
				char* delPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				for(k=0;k<delChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_item_item_id", &delPartId));
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(delChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(delChildLine[k],"bl_rev_item_revision_id",&rev));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(delChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task					
					//fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",delPartId,"","","","","","","","","","","","","-----");fflush(stdout);
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",delPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,"","","","");fflush(stdout);
				}
			}			
			
			//print qty change details.
			
			if(qtyChildLineCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-5s%-25s%-5s%-5s","","Change In Qty","Description","Rev","Seq","CS","CI","Old","Qty","QRI","Loc","SI","Epa Task","ES","IC");fflush(stdout);
				int k=0;
				char* qtyPartId = NULL;
				char* oldQtyStr = NULL;
				char* newQtyStr = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* siStr = NULL;				
				for(k=0;k<qtyChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(qtyChildLine[k], "bl_item_item_id", &qtyPartId));
					CALLAPI(AOM_ask_value_string(qtyChildLine[k], "bl_quantity", &newQtyStr));
					oldQtyStr = prevQtyStr[k];
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(qtyChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(qtyChildLine[k],"bl_rev_item_revision_id",&rev));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(qtyChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));					
					//CI
					CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					//CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));					
					
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-5s%-25s%-5s%-5s","",qtyPartId,partDesc,revStr,seqStr,csStr,ciStr,oldQtyStr,newQtyStr,"","",siStr,"","","");fflush(stdout);
				}
			}
			
			
			//print footer structure change
			if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
			{
					fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
			}		
			
			if(window!=NULLTAG) CALLAPI(BOM_close_window(window));
			if(window1!=NULLTAG) CALLAPI(BOM_close_window(window1));

			
			
		}
		
		
	}
	
	return ifail;
}

//NON_erc Structure chnages funtion defination
int tmStructureChanges1(char *DMLPlant,char *DMLDept,int n_parts,tag_t* part_obj_tag, FILE* DmlRelFile,char*** buffStr, int *cnt, int *prtAddCnt, int *prtDelCnt, int *prtQtyChngCnt)   
{
	printf("\n inside  tmStructureChanges1 for non_ERC :: "); fflush(stdout); 
	int ifail = ITK_ok;
	tag_t  CurrentRoleTag = NULLTAG;
	tag_t* Suppressedpart_objfind_tag = NULLTAG;
	int suppresedCOUNT = 0;
	char       roleName[SA_name_size_c+1]  ;	
	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	
	printf("\n DMLPlant :: %s",DMLPlant); fflush(stdout);
	printf("\n DmlDept :: %s",DMLDept); fflush(stdout);
	char *qry_entries1[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_infovalues1 = (char **) MEM_alloc(50 * sizeof(char *));
	
	if(n_parts>0)
	{
		int j=0;
		tag_t curr_rev_tag = NULLTAG;
		char* parentpartId = NULLTAG;
		char* parentpartId1 = NULLTAG;
		char* RevisionS = NULL;
		tag_t itemMstr = NULLTAG;
		tag_t prev_rev_tag = NULLTAG;
		
		int srNo =0;

		for(j=0;j<n_parts;j++)
		{
			curr_rev_tag=NULLTAG;
			curr_rev_tag=part_obj_tag[j];
			prev_rev_tag = NULLTAG;
			PartModel * currPartModelList;
			int currPartModelListCnt = 0;
			PartModel* prevPartModelList;
			int prevPartModelListCnt =0;
			tag_t* addedChildLine = NULLTAG;
			int addedChildLineCnt = 0;
			tag_t* delChildLine = NULLTAG;
			int delChildLineCnt = 0;
			tag_t* qtyChildLine = NULLTAG;
			int qtyChildLineCnt = 0;	
			char** prevQtyStr = NULL;
			int prevQtyStrCnt = 0;
			int 	n_values_bvr=0;
			int assbvr=0;
	        int bvrfound=0;
			char *view_name=NULL;
			char*	partTok		=NULL;
	        char*	viewTok		=NULL;
			tag_t			*bvr_assy_part= NULLTAG;
			tag_t	Cntl_obj_Qtag1	=	NULLTAG;
			tag_t	*qry_cntrlobjval	=	NULLTAG;

			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&parentpartId));
			ITEM_ask_item_of_rev(curr_rev_tag,&itemMstr);

			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_revision_id",&RevisionS));
			printf("\ntmStructureChanges1:RevisionS %s \n",RevisionS); fflush(stdout);

			int n_entries1 =	3;
			int resultCnt1 =	0;
			int lk =	0;

			char *bvrinfo	   = NULL;
			char *bvrviewtypeinfo	   = NULL;
	        char *RevRuleinfo 	   = NULL;
	        char *ClosureRlinfo	   = NULL;
	        char *CSBomLine   = NULL;
	        char *Info1   = NULL;
	        char *Info2   = NULL;

			if(QRY_find("Control Objects...", &Cntl_obj_Qtag1));
			if(Cntl_obj_Qtag1!=NULLTAG)
			{
				printf("\n NONERC DMLPRINT Control Object Query Found \n");fflush(stdout);
				qry_values1[0] ="NONERC";
				qry_values1[1] ="DMLPRINT";
				//qry_values1[2] =DMLPlant;
				//qry_values1[3] =DMLDept;
				qry_values1[2] ="0";

				resultCnt1=0;
				
				CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_values1, &resultCnt1, &qry_cntrlobjval));
				printf("\nNo. of control object found : %d\n",resultCnt1);fflush(stdout);
				if((resultCnt1>0) && ((tc_strcmp(DMLPlant,"")!=0) || (tc_strcmp(DMLDept,"")!=0)))
			    {

				for(lk=0;lk<resultCnt1;lk++)
				{
                  printf("\nControl object result count is greater than 0 found \n");fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo1", &Info1));
				  printf("\n Info1 : %s",Info1);fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo2", &Info2));
				  printf("\n Info2 : %s",Info2);fflush(stdout);
				  if((tc_strcmp(Info1,DMLPlant)==0) && (tc_strstr(Info2,DMLDept)!=NULL))
				  {
				    
                      printf("\nControl object result count is greater than 0 found and Matched on basis of dmlplant \n");fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo3", &bvrinfo));
					  printf("\n bvrinfo : %s",bvrinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo4", &RevRuleinfo));
					  printf("\n RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo5", &ClosureRlinfo));
					  printf("\n ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo8", &CSBomLine));
					  printf("\n CSBomLine : %s",CSBomLine);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo9", &bvrviewtypeinfo));
					  printf("\n bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&parentpartId1));
	                  printf("\n Part number===>%s\n",parentpartId1);fflush(stdout);
					  ITKCALL(ITEM_rev_list_bom_view_revs(curr_rev_tag, &n_values_bvr, &bvr_assy_part));
	                  printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

					  if(n_values_bvr>0)
					   {
                          printf("\n BVR found");fflush(stdout);
						  bvrfound=0;
						  for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						   {
							  CALLAPI(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							  printf("\n tmStructureChanges1 view_name %s",view_name);fflush(stdout);
							  partTok = strtok (view_name,"-");
							  viewTok = strtok (NULL,"-");
							  printf("\n viewTok %s",viewTok);fflush(stdout);
								  if(strlen(viewTok)>0)
								  {
									 if(tc_strcmp(viewTok,bvrinfo)==0)
									 {
										bvrfound++;
										printf("\n viewTok %s",viewTok);fflush(stdout);
										printf("\n bvrinfo %s",bvrinfo);fflush(stdout);
										printf("\n bvrviewtypeinfo %s",bvrviewtypeinfo);fflush(stdout);
										printf("\n part bvr found and matched as per CObj\n");fflush(stdout);																				
										break;
									 }
								  }
						   }

						   if(bvrfound!=1)
							{
							    bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrinfo updated : %s",bvrinfo);fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
							}
					   }
					   else
					   {
						        bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
					   }
                         break;

				     }
					 else if (lk==(resultCnt1-1))
					 {
						 bvrviewtypeinfo=(char *) MEM_alloc(100);
						 tc_strcpy(bvrviewtypeinfo,"view");
						 RevRuleinfo=(char *) MEM_alloc(100);
						 tc_strcpy(RevRuleinfo,"Latest Working");
						 ClosureRlinfo=(char *) MEM_alloc(100);
						 tc_strcpy(ClosureRlinfo,"");
						 CSBomLine=(char *) MEM_alloc(100);
				         tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
					 }
					 else
					 {
						 printf("\n as control object based as plant and dept not match so continue : ");fflush(stdout);
					 }
				 }
			  }
			  else
			  {
				  printf("\n as control object based on plant and dept loop not entered in else loop : ");fflush(stdout);
				  resultCnt1=0;
			  }

			}

			tag_t window = NULLTAG;
			tag_t window1 = NULLTAG;
			
			CALLAPI(BOM_create_window (&window));
			//Get Child objs of currnt rev objs)
			if(resultCnt1>0)
			{
				printf("\n inside window bvrinfo : %s",bvrinfo);fflush(stdout);
				printf("\n inside window bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				printf("\n inside window RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				printf("\n inside window ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
				CALLAPI(getFirstLevelChildObjs(window,curr_rev_tag,&currPartModelList,&currPartModelListCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule

				//CALLAPI(BOM_create_window (&window2));
				//CALLAPI(getFirstLevelChildObjs(window2,curr_rev_tag,&currPartERCModelList,&currPartERCModelListCnt, bvrviewtypeinfo, "Latest Working", ""));

				//CALLAPI(BOM_create_window (&window3));
				//CALLAPI(getFirstLevelChildObjs(window3,curr_rev_tag,&currPartMBOMModelList,&currPartMBOMModelListCnt, bvrviewtypeinfo, "MBOM Working and Above", "BOMViewClosureRuleMBOM"));

				//CALLAPI(BOM_create_window (&window4));
				//CALLAPI(getFirstLevelChildObjs(window4,curr_rev_tag,&currPartAPLModelList,&currPartAPLModelListCnt, bvrviewtypeinfo, "Latest Working", ""));
			}
			else
			{
			   CALLAPI(getFirstLevelChildObjs(window,curr_rev_tag,&currPartModelList,&currPartModelListCnt, "view", "Latest Working", ""));//T5_DFMA, view

				   CSBomLine=(char *) MEM_alloc(100);
				   tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
			}
			printf("\n Child Count of Current Part============>%d\n",currPartModelListCnt);fflush(stdout);
			//Get previous official Revision of the part object.
			if((tc_strstr(Info2,DMLDept)!=NULL)&&(tc_strcmp(Info2,DMLDept)!=0))
			{
			   CALLAPI(getPrevOfficialRev1(itemMstr,Info2,curr_rev_tag,&prev_rev_tag));
			}
			else
			{
			   CALLAPI(getPrevOfficialRev(itemMstr,curr_rev_tag,&prev_rev_tag));
			}
			
			
			if(prev_rev_tag != NULLTAG)
			{
				
				CALLAPI(BOM_create_window (&window1))
				if(resultCnt1>0)
				{
					printf("\n inside window1 bvrinfo : %s",bvrinfo);fflush(stdout);
					printf("\n inside window1 bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				    printf("\n inside window1 RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				    printf("\n inside window1 ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					CALLAPI(getFirstLevelChildObjs(window1, prev_rev_tag,&prevPartModelList,&prevPartModelListCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule
				}
				else
				{
				  CALLAPI(getFirstLevelChildObjs(window1, prev_rev_tag,&prevPartModelList,&prevPartModelListCnt, "view", "Latest Working", ""));//T5_DFMA, view
				}
			}
			else
			{
				printf("\n No previous official revision for part %s:%s\n",parentpartId,RevisionS);fflush(stdout);
				
			}
			printf("\n Child Count of Prev official rev  Part============>%d\n",prevPartModelListCnt);fflush(stdout);
			
			
			//CALLAPI(tmStructureChangesFunc(curr_rev_tag,curr_rev_tag,currPartModelListCnt,currPartModelList,prevPartModelListCnt,prevPartModelList,prtAddCnt,prtDelCnt,prtQtyChngCnt));
			 char* parentpartPartCodeDup = NULL;
		     char*	partModBA		=NULL;
			 char *Cobjinfo1	   = NULL;
             char *Cobjinfo2	   = NULL;
             char *Cobjinfo3	   = NULL;
             char *Cobjinfo4	   = NULL;
             char *Cobjinfo5	   = NULL;
             char *Cobjinfo6	   = NULL;
             char *Cobjinfo7	   = NULL;
             tag_t itemMstrSupres  = NULLTAG;
	      	 int resultinfoCnt1 =0;
	      	 int A7 =0;
	      	 tag_t	*qry_infocntrlobjval	=	NULLTAG;

			if(prev_rev_tag==NULLTAG)//The part is getting released first time - no structure change
			{
				tag_t currChildLine = NULLTAG;
				tag_t Suprs_Prt_tag = NULLTAG;
				char* currQty = NULL;
				char* currOccId = NULL;
				char **curidlist=NULL;
				int  curidlist_cnt=0;
				int curQtylist_cnt = 0;
				int c = 0;
				char** curQtylist = NULL;
				
				addedChildLine = NULLTAG;
				addedChildLineCnt = 0;

				//print the currPartModelList as added parts.
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine = currPartModelList[c]->childBomLine;
					if(currChildLine == NULLTAG)
					printf("\n currChildLine is null tag\n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setAddStr(&curidlist_cnt,&curidlist,currOccId);

					CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQty));
					setAddStr(&curQtylist_cnt,&curQtylist,currQty);

					    printf("\n\t\t Inside new added object Found");fflush(stdout);
						char *currItemIdStr =  NULL;
						char* currQtyStr = NULL;
						char* currRevStr = NULL;
						int d = 0;
						*prtAddCnt = *prtAddCnt + 1;
						
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_item_item_id", &currItemIdStr));
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQtyStr));
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_rev_item_revision_id", &currRevStr));
						printf("\n Part Added ==>%s, Quantity====>%s\n",currItemIdStr,currQtyStr);
						setAddTAG(&addedChildLineCnt, &addedChildLine,currChildLine);
	             		 
                        itemMstrSupres  = NULLTAG;
	             		parentpartPartCodeDup=subString(currItemIdStr,6,1);
	             		partModBA=subString(currItemIdStr,4,5);
	             		printf("\ntmStructureChanges1:parentpartPartCodeDup : %s \n",parentpartPartCodeDup); fflush(stdout);
	             		printf("\ntmStructureChanges1:partModBA45 : %s \n",partModBA); fflush(stdout);
                         qry_infovalues1[0]="NONERC_DMLPRINT";
	                     qry_infovalues1[1]=DMLDept;
	                     qry_infovalues1[2]="0";
	             		CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_infovalues1, &resultinfoCnt1, &qry_infocntrlobjval));
	             		printf("\nNo. of control object found : %d\n",resultinfoCnt1);fflush(stdout);
	             		  if(resultinfoCnt1>0)
	             		   {
	             			for(A7=0;A7<resultinfoCnt1;A7++)
	             			 {
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo1", &Cobjinfo1));
	             			    printf("\n Cobjinfo1 : %s",Cobjinfo1);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo2", &Cobjinfo2));
	             			    printf("\n Cobjinfo2 : %s",Cobjinfo2);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo3", &Cobjinfo3));
	             			    printf("\n Cobjinfo3 : %s",Cobjinfo3);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo4", &Cobjinfo4));
	             			    printf("\n Cobjinfo4 : %s",Cobjinfo4);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo5", &Cobjinfo5));
	             			    printf("\n Cobjinfo5 : %s",Cobjinfo5);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo6", &Cobjinfo6));
	             			    printf("\n Cobjinfo6 : %s",Cobjinfo6);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo7", &Cobjinfo7));
	             			    printf("\n Cobjinfo7 : %s",Cobjinfo7);fflush(stdout);
	             
	             			 }
	             			 if((tc_strstr(Cobjinfo7,parentpartPartCodeDup)==NULL))
	             			   {
	             			   if((tc_strstr(currItemIdStr,Cobjinfo1)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo2)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo3)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo4)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo5)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo6)==NULL))
	             				  {
								    printf("\n tmStructureChanges1 inside control object found to and not match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
	             					 //continue;
	             					 //PROPUNE
	             					 //PROLKO
	             					 //PROJSR
	             					 //  W X Y Z  --- manufacturing parts
	             					 //Compared MBOM and APL parts info from control objects 
	             				     //APLPUNE
	             				     //TELPUNE
	             				     //R20  R40
	             				  }
	             			    else
	             			      {
	             				  printf("\n tmStructureChanges1 inside control object found to and match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
								  CALLAPI(ITEM_find_item(currItemIdStr,&itemMstrSupres));
			                      CALLAPI(ITEM_find_revision(itemMstrSupres,currRevStr,&Suprs_Prt_tag));
								     if(Suprs_Prt_tag==NULLTAG)
									  {
									    printf("\n tmStructureChanges1 Suprs_Prt_tag is nulltag  ");fflush(stdout);
									    continue;
								      }
								     setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
								 
	             			      }
	             			   }
							  else
	             			  {
	             				  printf("\n tmStructureChanges1 inside control object found to and match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
								   CALLAPI(ITEM_find_item(currItemIdStr,&itemMstrSupres));
			                      CALLAPI(ITEM_find_revision(itemMstrSupres,currRevStr,&Suprs_Prt_tag));
								     if(Suprs_Prt_tag==NULLTAG)
									  {
									    printf("\n tmStructureChanges1 Suprs_Prt_tag is nulltag  ");fflush(stdout);
									    continue;
								      }
								     setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
								  //setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
	             			  }
							 							  
	             
	             		   }
	             			
				}
				if (addedChildLineCnt==0)
				{
					continue;
				}
				
				//continue;
			}
			else
			{
				
				//fprintf(DmlRelFile,"\n -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				int c=0;
				int p =0;
				tag_t currChild = NULLTAG;
				tag_t Suprs_Prt_tag = NULLTAG;
				tag_t currChildLine = NULLTAG;
				tag_t prevChild = NULLTAG;
				tag_t prevChildLine = NULLTAG;
				int  itemId_attribute = 0;
				int  rev_attribute = 0;
				int  qty_attribute = 0;
				char* currQty = NULL;
				char* currRev = NULL;
				char* currItemId = NULL;
				char* prevItemId = NULL;
				char* prevRev = NULL;
				char* prevQty = NULL;
				
				char* currOccId = NULL;
				char **curidlist=NULL;
				int  curidlist_cnt=0;
				int curQtylist_cnt = 0;
				char** curQtylist = NULL;
				
				char* prevOccId = NULL;
				char **previdlist=NULL;
				int  previdlist_cnt=0;
				int prevQtylist_cnt = 0;
				char** prevQtylist = NULL;
				
				
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine = currPartModelList[c]->childBomLine;
					if(currChildLine == NULLTAG)
						printf("\n currChildLine is null tag\n");fflush(stdout);
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setAddStr(&curidlist_cnt,&curidlist,currOccId);

					CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQty));
					setAddStr(&curQtylist_cnt,&curQtylist,currQty);
				
				}
				
				for(p=0;p<prevPartModelListCnt;p++)
				{
					prevChildLine = prevPartModelList[p]->childBomLine;
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_clone_stable_occurrence_id", &prevOccId));
					setAddStr(&previdlist_cnt,&previdlist,prevOccId);
					
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_quantity", &prevQty));
					setAddStr(&prevQtylist_cnt,&prevQtylist,prevQty);					
					
				}
				
				//Addition logic
				int toadd = 0;
				
				addedChildLine = NULLTAG;
				addedChildLineCnt = 0;
				
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine = currPartModelList[c]->childBomLine;
					
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setFindStr(previdlist,previdlist_cnt,currOccId,&toadd);
					
					//addition logic
					if(toadd==0)
					{
						printf("\n Inside new added object Found");fflush(stdout);
						char *currItemIdStr =  NULL;
						char* currQtyStr = NULL;
						char* currRevStr = NULL;
						int d = 0;
						*prtAddCnt = *prtAddCnt + 1;
						
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_item_item_id", &currItemIdStr));
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &currQtyStr));
						printf("\n Part Added ==>%s, Quantity====>%s\n",currItemIdStr,currQtyStr);
						setAddTAG(&addedChildLineCnt, &addedChildLine,currChildLine);

						itemMstrSupres  = NULLTAG;
	             		parentpartPartCodeDup=subString(currItemIdStr,6,1);
	             		partModBA=subString(currItemIdStr,4,5);
	             		printf("\ntmStructureChanges1:parentpartPartCodeDup : %s \n",parentpartPartCodeDup); fflush(stdout);
	             		printf("\ntmStructureChanges1:partModBA46 : %s \n",partModBA); fflush(stdout);
                         /*qry_infovalues1[0]="NONERC_DMLPRINT";
	                     qry_infovalues1[1]=DMLDept;
	                     qry_infovalues1[2]="0";
	             		CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_infovalues1, &resultinfoCnt1, &qry_infocntrlobjval));
	             		printf("\nNo. of control object found : %d\n",resultinfoCnt1);fflush(stdout);
	             		  if(resultinfoCnt1>0)
	             		   {
	             			for(A7=0;A7<resultinfoCnt1;A7++)
	             			 {
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo1", &Cobjinfo1));
	             			    printf("\n Cobjinfo1 : %s",Cobjinfo1);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo2", &Cobjinfo2));
	             			    printf("\n Cobjinfo2 : %s",Cobjinfo2);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo3", &Cobjinfo3));
	             			    printf("\n Cobjinfo3 : %s",Cobjinfo3);fflush(stdout);
	             			    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo4", &Cobjinfo4));
	             			    printf("\n Cobjinfo4 : %s",Cobjinfo4);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo5", &Cobjinfo5));
	             			    printf("\n Cobjinfo5 : %s",Cobjinfo5);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo6", &Cobjinfo6));
	             			    printf("\n Cobjinfo6 : %s",Cobjinfo6);fflush(stdout);
	             				CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo7", &Cobjinfo7));
	             			    printf("\n Cobjinfo7 : %s",Cobjinfo7);fflush(stdout);
	             
	             			 }
	             			 if((tc_strstr(Cobjinfo7,parentpartPartCodeDup)==NULL))
	             			   {
	             			   if((tc_strstr(currItemIdStr,Cobjinfo1)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo2)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo3)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo4)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo5)==NULL)&&(tc_strstr(currItemIdStr,Cobjinfo6)==NULL))
	             				  {
								    printf("\n tmStructureChanges1 inside control object found to and not match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
	             					 //continue;
	             					 //PROPUNE
	             					 //PROLKO
	             					 //PROJSR
	             					 //  W X Y Z  --- manufacturing parts
	             					 //Compared MBOM and APL parts info from control objects 
	             				     //APLPUNE
	             				     //TELPUNE
	             				     //R20  R40
	             				  }
	             			    else
	             			      {
	             				  printf("\n tmStructureChanges1 inside control object found to and match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
								  CALLAPI(ITEM_find_item(currItemIdStr,&itemMstrSupres));
			                      CALLAPI(ITEM_find_revision(itemMstrSupres,currRevStr,&Suprs_Prt_tag));
								     if(Suprs_Prt_tag==NULLTAG)
									  {
									    printf("\n tmStructureChanges1 Suprs_Prt_tag is nulltag  ");fflush(stdout);
									    continue;
								      }
								     setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
								 
	             			      }
	             			   }
							  else
	             			  {
	             				  printf("\n tmStructureChanges1 inside control object found to and match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
								   CALLAPI(ITEM_find_item(currItemIdStr,&itemMstrSupres));
			                      CALLAPI(ITEM_find_revision(itemMstrSupres,currRevStr,&Suprs_Prt_tag));
								     if(Suprs_Prt_tag==NULLTAG)
									  {
									    printf("\n tmStructureChanges1 Suprs_Prt_tag is nulltag  ");fflush(stdout);
									    continue;
								      }
								     setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
								  //setAddTAG(&suppresedCOUNT, &Suppressedpart_objfind_tag,Suprs_Prt_tag);
	             			  }
							 							  
	             
						 }*/
						

					}
					
					
				}
				
				//Deletion logic
				int todel = 0;
				delChildLine = NULLTAG;
				delChildLineCnt = 0;				
				for(c=0;c<prevPartModelListCnt;c++)
				{
					prevChildLine = prevPartModelList[c]->childBomLine;
					CALLAPI(AOM_ask_value_string(prevChildLine, "bl_clone_stable_occurrence_id", &prevOccId));
					setFindStr(curidlist,curidlist_cnt,prevOccId,&todel);
					if(todel ==0)
					{
						//printf deleted part details
						*prtDelCnt = *prtDelCnt + 1;
						setAddTAG(&delChildLineCnt, &delChildLine,prevChildLine);
					}						
					
				}
				
				//Quantity change
				int toQty = 0;
				qtyChildLine = NULLTAG;
				qtyChildLineCnt = 0;	
				prevQtyStr = NULL;
				prevQtyStrCnt = 0;
				for(c=0;c<currPartModelListCnt;c++)
				{
					currChildLine =currPartModelList[c]->childBomLine;
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_clone_stable_occurrence_id", &currOccId));
					setFindStr(previdlist,previdlist_cnt,currOccId,&toQty);
					
					if(toQty == 1)
					{
						int idx=-1;
						char *prevQnty=NULL;
						char* curQtyStr = NULL;
						getIndex(previdlist,previdlist_cnt,currOccId,&idx);
						getStrByIndex(prevQtylist,prevQtylist_cnt,idx,&prevQnty);
						CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &curQtyStr));
						if(tc_strcmp(curQtyStr,prevQnty)!=0)
						{
							//printf quantity change parts
							*prtQtyChngCnt =*prtQtyChngCnt + 1;
							setAddTAG(&qtyChildLineCnt, &qtyChildLine,currChildLine);
							setAddStr(&prevQtyStrCnt, &prevQtyStr,prevQnty);
						}
						
					}
					
				}
				
				
			}
			
			//print header part
			if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
			{
				fprintf(DmlRelFile,"\n\n STRUCTURE CHANGES");fflush(DmlRelFile);
				fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				//parentpartId,RevisionS
				srNo++;
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s",srNo, parentpartId,RevisionS);fflush(stdout);
			}
			//print add part details
			
			if(addedChildLineCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   REPLACES_PARTNO
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","","Added Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","REPLACES_PARTNO");fflush(stdout);
	
				int k=0;
				char* addPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revtmp = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				
				for(k=0;k<addedChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_item_item_id", &addPartId));
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(addedChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_item_revision_id",&rev));
					CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_item_revision_id",&revtmp));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(addedChildLine[k],CSBomLine,&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task
                    
                        tag_t part_EPA_REL = NULLTAG;
                        tag_t part_ES_rel = NULLTAG;
                        tag_t part_master = NULLTAG;
                        tag_t part_add = NULLTAG;
                        tag_t	*primary_obj	=	NULLTAG;
                        tag_t	*primary_objES	=	NULLTAG;
                        int EPAOBcnt =0;
                        int ESOBcnt =0;
                        int u =0;
                        int ES1 = 0;
                        char* epaTasktmp = NULL;
                        char* epaTaskidtmp = NULL;
                        char* epaTask = NULL;
                        char* esStrtmp = NULL;
                        char* esStridtmp = NULL;
                        char* esStr = NULL;

						CALLAPI(ITEM_find_item(addPartId,&part_master));
						if(part_master!=NULLTAG)
                        {
                        	printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                        }
						CALLAPI(ITEM_find_revision(part_master,revtmp,&part_add));
                        CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &part_EPA_REL));
                        CALLAPI(GRM_list_primary_objects_only(part_add,part_EPA_REL,&EPAOBcnt,&primary_obj));
                        printf("\ntmStructureChanges1:EPAOBcnt: %d ",EPAOBcnt); fflush(stdout);
                        epaTask=(char *) MEM_alloc(100);
                        tc_strcpy(epaTask,"");
                        for(u=0;u<EPAOBcnt;u++)
                        {
                        	CALLAPI(AOM_UIF_ask_value(primary_obj[u],"object_type",&epaTasktmp));
                            printf("\ntmStructureChanges1:epaTask: %s",epaTasktmp); fflush(stdout);
                        	if(tc_strcmp(epaTasktmp,"EPA Task Revision")==0)
                        	{
                        		CALLAPI(AOM_UIF_ask_value(primary_obj[u],"item_id",&epaTaskidtmp));
                                printf("\ntmStructureChanges1:epaTask: %s",epaTaskidtmp); fflush(stdout);
                        		tc_strcpy(epaTask,epaTaskidtmp);
                        		break;
                        	}
                        }
                        CALLAPI(GRM_find_relation_type("T5_Design_Estimate_Relation", &part_ES_rel));
                  
                        CALLAPI(GRM_list_secondary_objects_only(part_master,part_ES_rel,&ESOBcnt,&primary_objES));
                        printf("\ntmStructureChanges1:ESOBcnt: %d ",ESOBcnt); fflush(stdout);
                        esStr=(char *) MEM_alloc(300);
                        tc_strcpy(esStr,"");
                        for(ES1=0;ES1<ESOBcnt;ES1++)
                        {
                        	CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"object_type",&esStrtmp));
                            printf("\ntmStructureChanges1:esStrtmp: %s",esStrtmp); fflush(stdout);
                        	//ES -
                        	if(tc_strcmp(esStrtmp,"Estimate Sheet Revision")==0)
                        	{
                        		CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"item_id",&esStridtmp));
                                printf("\ntmStructureChanges1:esStridtmp: %s",esStridtmp); fflush(stdout);
                        		tc_strcat(esStr,esStridtmp);
                        		tc_strcat(esStr,",");
                        	}
                        
                        }
                        if(tc_strcmp(epaTask,"")==0)
                        {
                        	tc_strcpy(epaTask,"-");
                        }
                        if(tc_strcmp(esStr,"")==0)
                        {
                        	tc_strcpy(esStr,"-");
                        }

					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","",addPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,epaTask,esStr,"","");fflush(stdout);
				}
			}
			
			//print del part details
			if(delChildLineCnt>0)
			{
				
				
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","","Deleted Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","RSFAP(DI)");fflush(stdout);
				int k=0;
				char* delPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revtmp = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				for(k=0;k<delChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_item_item_id", &delPartId));
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(delChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(delChildLine[k],"bl_rev_item_revision_id",&rev));
					CALLAPI (AOM_UIF_ask_value(delChildLine[k],"bl_rev_item_revision_id",&revtmp));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(delChildLine[k],CSBomLine,&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task
		
                        tag_t part_EPA_REL = NULLTAG;
                        tag_t part_ES_rel = NULLTAG;
                        tag_t part_master = NULLTAG;
                        tag_t part_del = NULLTAG;
                        tag_t	*primary_obj	=	NULLTAG;
                        tag_t	*primary_objES	=	NULLTAG;
                        int EPAOBcnt =0;
                        int ESOBcnt =0;
                        int u =0;
                        int ES1 = 0;
                        char* epaTasktmp = NULL;
                        char* epaTaskidtmp = NULL;
                        char* epaTask = NULL;
                        char* esStrtmp = NULL;
                        char* esStridtmp = NULL;
                        char* esStr = NULL;
						
						CALLAPI(ITEM_find_item(delPartId,&part_master));
						if(part_master!=NULLTAG)
                        {
                        	printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                        }
						CALLAPI(ITEM_find_revision(part_master,revtmp,&part_del));
                        CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &part_EPA_REL));
                        CALLAPI(GRM_list_primary_objects_only(part_del,part_EPA_REL,&EPAOBcnt,&primary_obj));
                        printf("\ntmStructureChanges1:EPAOBcnt: %d ",EPAOBcnt); fflush(stdout);
                        epaTask=(char *) MEM_alloc(100);
                        tc_strcpy(epaTask,"");
                        for(u=0;u<EPAOBcnt;u++)
                        {
                        	CALLAPI(AOM_UIF_ask_value(primary_obj[u],"object_type",&epaTasktmp));
                            printf("\ntmStructureChanges1:epaTask: %s",epaTasktmp); fflush(stdout);
                        	if(tc_strcmp(epaTasktmp,"EPA Task Revision")==0)
                        	{
                        		CALLAPI(AOM_UIF_ask_value(primary_obj[u],"item_id",&epaTaskidtmp));
                                printf("\ntmStructureChanges1:epaTask: %s",epaTaskidtmp); fflush(stdout);
                        		tc_strcpy(epaTask,epaTaskidtmp);
                        		break;
                        	}
                        }
                        CALLAPI(GRM_find_relation_type("T5_Design_Estimate_Relation", &part_ES_rel));
                        CALLAPI(ITEM_find_item(delPartId,&part_master));
                        if(part_master!=NULLTAG)
                        {
                        	printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                        }
                        CALLAPI(GRM_list_secondary_objects_only(part_master,part_ES_rel,&ESOBcnt,&primary_objES));
                        printf("\ntmStructureChanges1:ESOBcnt: %d ",ESOBcnt); fflush(stdout);
                        esStr=(char *) MEM_alloc(300);
                        tc_strcpy(esStr,"");
                        for(ES1=0;ES1<ESOBcnt;ES1++)
                        {
                        	CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"object_type",&esStrtmp));
                            printf("\ntmStructureChanges1:esStrtmp: %s",esStrtmp); fflush(stdout);
                        	//ES -
                        	if(tc_strcmp(esStrtmp,"Estimate Sheet Revision")==0)
                        	{
                        		CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"item_id",&esStridtmp));
                                printf("\ntmStructureChanges1:esStridtmp: %s",esStridtmp); fflush(stdout);
                        		tc_strcat(esStr,esStridtmp);
                        		tc_strcat(esStr,",");
                        	}
                        
                        }
                        if(tc_strcmp(epaTask,"")==0)
                        {
                        	tc_strcpy(epaTask,"-");
                        }
                        if(tc_strcmp(esStr,"")==0)
                        {
                        	tc_strcpy(esStr,"-");
                        }
					//fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",delPartId,"","","","","","","","","","","","","-----");fflush(stdout);
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","",delPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,epaTask,esStr,"","");fflush(stdout);
				}
			}			
			
			//print qty change details.
			
			if(qtyChildLineCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
				
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-15s%-25s%-5s%-5s","","Change In Qty","Description","Rev","Seq","CS","CI","Old","Qty","QRI","Loc","SI","Epa Task","ES","IC");fflush(stdout);
				int k=0;
				char* qtyPartId = NULL;
				char* oldQtyStr = NULL;
				char* newQtyStr = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revtmp = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* siStr = NULL;				
				for(k=0;k<qtyChildLineCnt;k++)
				{
					CALLAPI(AOM_ask_value_string(qtyChildLine[k], "bl_item_item_id", &qtyPartId));
					CALLAPI(AOM_ask_value_string(qtyChildLine[k], "bl_quantity", &newQtyStr));
					oldQtyStr = prevQtyStr[k];
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(qtyChildLine[k],"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					
					
					CALLAPI (AOM_UIF_ask_value(qtyChildLine[k],"bl_rev_item_revision_id",&rev));
					CALLAPI (AOM_UIF_ask_value(qtyChildLine[k],"bl_rev_item_revision_id",&revtmp));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					
					//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(qtyChildLine[k],CSBomLine,&csStr));					
					//CI
					CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					//CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(qtyChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
				
                    tag_t part_EPA_REL = NULLTAG;
                    tag_t part_ES_rel = NULLTAG;
                    tag_t part_master = NULLTAG;
                    tag_t part_qty = NULLTAG;
                    tag_t	*primary_obj	=	NULLTAG;
                    tag_t	*primary_objES	=	NULLTAG;
                    int EPAOBcnt =0;
                    int ESOBcnt =0;
                    int u =0;
                    int ES1 = 0;
                    char* epaTasktmp = NULL;
                    char* epaTaskidtmp = NULL;
                    char* epaTask = NULL;
                    char* esStrtmp = NULL;
                    char* esStridtmp = NULL;
                    char* esStr = NULL;
					
					CALLAPI(ITEM_find_item(qtyPartId,&part_master));
					if(part_master!=NULLTAG)
                    {
                       printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                    }
					CALLAPI(ITEM_find_revision(part_master,revtmp,&part_qty));
                    CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &part_EPA_REL));
                    CALLAPI(GRM_list_primary_objects_only(part_qty,part_EPA_REL,&EPAOBcnt,&primary_obj));
                    printf("\ntmStructureChanges1:EPAOBcnt: %d ",EPAOBcnt); fflush(stdout);
                    epaTask=(char *) MEM_alloc(100);
                    tc_strcpy(epaTask,"");
                    for(u=0;u<EPAOBcnt;u++)
                    {
                    	CALLAPI(AOM_UIF_ask_value(primary_obj[u],"object_type",&epaTasktmp));
                        printf("\ntmStructureChanges1:epaTask: %s",epaTasktmp); fflush(stdout);
                    	if(tc_strcmp(epaTasktmp,"EPA Task Revision")==0)
                    	{
                    		CALLAPI(AOM_UIF_ask_value(primary_obj[u],"item_id",&epaTaskidtmp));
                            printf("\ntmStructureChanges1:epaTask: %s",epaTaskidtmp); fflush(stdout);
                    		tc_strcpy(epaTask,epaTaskidtmp);
                    		break;
                    	}
                    }
                    CALLAPI(GRM_find_relation_type("T5_Design_Estimate_Relation", &part_ES_rel));
                    CALLAPI(ITEM_find_item(qtyPartId,&part_master));
                    if(part_master!=NULLTAG)
                    {
                    	printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                    }
                    CALLAPI(GRM_list_secondary_objects_only(part_master,part_ES_rel,&ESOBcnt,&primary_objES));
                    printf("\ntmStructureChanges1:ESOBcnt: %d ",ESOBcnt); fflush(stdout);
                    esStr=(char *) MEM_alloc(300);
                    tc_strcpy(esStr,"");
                    for(ES1=0;ES1<ESOBcnt;ES1++)
                    {
                    	CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"object_type",&esStrtmp));
                        printf("\ntmStructureChanges1:esStrtmp: %s",esStrtmp); fflush(stdout);
                    	//ES -
                    	if(tc_strcmp(esStrtmp,"Estimate Sheet Revision")==0)
                    	{
                    		CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"item_id",&esStridtmp));
                            printf("\ntmStructureChanges1:esStridtmp: %s",esStridtmp); fflush(stdout);
                    		tc_strcat(esStr,esStridtmp);
                    		tc_strcat(esStr,",");
                    	}
                    
                    }
                    if(tc_strcmp(epaTask,"")==0)
                    {
                    	tc_strcpy(epaTask,"-");
                    }
                    if(tc_strcmp(esStr,"")==0)
                    {
                    	tc_strcpy(esStr,"-");
                    }
					
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-15s%-25s%-5s%-5s","",qtyPartId,partDesc,revStr,seqStr,csStr,ciStr,oldQtyStr,newQtyStr,"","",siStr,epaTask,esStr,"");fflush(stdout);
				}
			}
			
			
			//print footer structure change
			if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
			{
					fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
			}		
			
			if(window!=NULLTAG) CALLAPI(BOM_close_window(window));
			if(window1!=NULLTAG) CALLAPI(BOM_close_window(window1));

			printf("\nNo. of suppresedCOUNT found : %d\n",suppresedCOUNT);fflush(stdout);

			
			
		}
		
		printf("\n at end tmStructureChanges1 for non_ERC : \n"); fflush(stdout); 
	}
	printf("\nNo. of suppresedCOUNT found : %d\n",suppresedCOUNT);fflush(stdout);
		int APLSupressedcnt=0;
		if(suppresedCOUNT>0)
		{
		int j=0;
		APLSupressedcnt=0;
		tag_t curr_Suprev_tag = NULLTAG;
		char* parentpartId = NULL;
		char* parentpartDsgnOwn = NULL;
		char* parentpartuser = NULL;
		char* parentpartPartCode = NULL;
		char* parentpartPartCodeDup = NULL;
		char* parentpartDesgnDept = NULL;
		char* parentpartId1 = NULL;
		char* RevisionS = NULL;
		tag_t itemMstr = NULLTAG;
		tag_t prev_rev_tag = NULLTAG;
		int suprNo =0;
		for(j=0;j<suppresedCOUNT;j++)
		{
			//curr_rev_tag=NULLTAG;
			curr_Suprev_tag=Suppressedpart_objfind_tag[j];
			prev_rev_tag = NULLTAG;
			tag_t part_sup = NULLTAG;
			PartModel * PartRevModelLst;
			int PartRevModelLstCnt = 0;
			PartModel* prevPartModelLst;
			int prevPartModelLstCnt =0;
			tag_t* addedChldLine = NULLTAG;
			int addedChldLineCnt = 0;
			tag_t* delChldLine = NULLTAG;
			int delChldLineCnt = 0;
			tag_t* qtyChildLne = NULLTAG;
			int qtyChildLneCnt = 0;	
			char** prevQtyStr = NULL;
			int prevQtyStrCnt = 0;
			int 	n_values_bvr=0;
			int assbvr=0;
	        int bvrfound=0;
			char *view_name=NULL;
			char*	partTok		=NULL;
	        char*	viewTok		=NULL;
	        char*	partModBA		=NULL;
			tag_t			*bvr_assy_part= NULLTAG;
			tag_t	Cntl_obj_Qtag1	=	NULLTAG;
			tag_t	*qry_cntrlobjval	=	NULLTAG;
			tag_t	*qry_infocntrlobjval	=	NULLTAG;

			if(curr_Suprev_tag==NULLTAG)
			{
				printf("\ntmSupressedParts:parentpartId : inside nulltag \n"); fflush(stdout);
			}

				
			CALLAPI(AOM_ask_value_string(Suppressedpart_objfind_tag[j],"item_id",&parentpartId));
			printf("\ntmSupressedParts:parentpartId :   %s \n",parentpartId); fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(Suppressedpart_objfind_tag[j],"item_revision_id",&RevisionS));
			printf("\ntmSupressedParts:RevisionS :   %s \n",RevisionS); fflush(stdout);
			CALLAPI(ITEM_find_item(parentpartId,&itemMstr));
			CALLAPI(ITEM_find_revision(itemMstr,RevisionS,&part_sup));
			//ITEM_ask_item_of_rev(curr_rev_tag,&itemMstr);

			//CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_DsgnOwn",&parentpartDsgnOwn));
			//printf("\ntmSupressedParts:parentpartDsgnOwn : %s \n",parentpartDsgnOwn); fflush(stdout);
			//CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"owning_user",&parentpartuser));
			//printf("\ntmSupressedParts:parentpartuser : %s \n",parentpartuser); fflush(stdout);
			//CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_PartCode",&parentpartPartCode));
			//printf("\ntmSupressedParts:parentpartPartCode : %s \n",parentpartPartCode); fflush(stdout);
			//CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_DsgnDept",&parentpartDesgnDept));
			//printf("\ntmSupressedParts:parentpartDesgnDept : %s \n",parentpartDesgnDept); fflush(stdout);
			
			int n_entries1 =	3;
			int resultCnt1 =	0;
			int resultinfoCnt1 =	0;
			int lk,A7 =	0;

			char *bvrinfo	   = NULL;
			char *bvrviewtypeinfo	   = NULL;
	        char *RevRuleinfo 	   = NULL;
	        char *ClosureRlinfo	   = NULL;
	        char *CSBomLine   = NULL;
	        char *Info1   = NULL;
	        char *Info2   = NULL;

			if(QRY_find("Control Objects...", &Cntl_obj_Qtag1));
			if(Cntl_obj_Qtag1!=NULLTAG)
			{
				printf("\n NONERC DMLPRINT Control Object Query Found \n");fflush(stdout);
				qry_values1[0] ="NONERC";
				qry_values1[1] ="DMLPRINT";
				qry_values1[2] ="0";

				resultCnt1=0;
				CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_values1, &resultCnt1, &qry_cntrlobjval));
				printf("\nNo. of control object found : %d\n",resultCnt1);fflush(stdout);
				if((resultCnt1>0) && ((tc_strcmp(DMLPlant,"")!=0) || (tc_strcmp(DMLDept,"")!=0)))
			    {

				for(lk=0;lk<resultCnt1;lk++)
				{
                  printf("\nControl object result count is greater than 0 found \n");fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo1", &Info1));
				  printf("\n Info1 : %s",Info1);fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo2", &Info2));
				  printf("\n Info2 : %s",Info2);fflush(stdout);
				  if((tc_strcmp(Info1,DMLPlant)==0) && (tc_strcmp(Info2,DMLDept)==0))
				  {
				    
                      printf("\nControl object result count is greater than 0 found and Matched on basis of dmlplant \n");fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo3", &bvrinfo));
					  printf("\n bvrinfo : %s",bvrinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo4", &RevRuleinfo));
					  printf("\n RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo5", &ClosureRlinfo));
					  printf("\n ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo8", &CSBomLine));
					  printf("\n CSBomLine : %s",CSBomLine);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo9", &bvrviewtypeinfo));
					  printf("\n bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(part_sup,"item_id",&parentpartId1));
	                  printf("\n Part number===>%s\n",parentpartId1);fflush(stdout);
					  ITKCALL(ITEM_rev_list_bom_view_revs(part_sup, &n_values_bvr, &bvr_assy_part));
	                  printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

					  if(n_values_bvr>0)
					   {
                          printf("\n BVR found");fflush(stdout);
						  bvrfound=0;
						  for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						   {
							  CALLAPI(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							  printf("\n view_name %s",view_name);fflush(stdout);
							  partTok = strtok (view_name,"-");
							  viewTok = strtok (NULL,"-");
							  printf("\n viewTok %s",viewTok);fflush(stdout);
								  if(strlen(viewTok)>0)
								  {
									 if(tc_strcmp(viewTok,bvrinfo)==0)
									 {
										bvrfound++;
										printf("\n viewTok %s",viewTok);fflush(stdout);
										printf("\n bvrinfo %s",bvrinfo);fflush(stdout);
										printf("\n bvrviewtypeinfo %s",bvrviewtypeinfo);fflush(stdout);
										printf("\n part bvr found and matched as per CObj\n");fflush(stdout);																				
										break;
									 }
								  }
						   }

						   if(bvrfound!=1)
							{
							    bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrinfo updated : %s",bvrinfo);fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
							}
					   }
					   else
					   {
						        bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
					   }
                         break;

				     }
					 else if (lk==(resultCnt1-1))
					 {
						 bvrviewtypeinfo=(char *) MEM_alloc(100);
						 tc_strcpy(bvrviewtypeinfo,"view");
						 RevRuleinfo=(char *) MEM_alloc(100);
						 tc_strcpy(RevRuleinfo,"Latest Working");
						 ClosureRlinfo=(char *) MEM_alloc(100);
						 tc_strcpy(ClosureRlinfo,"");
						 CSBomLine=(char *) MEM_alloc(100);
				         tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
					 }
					 else
					 {
						 printf("\n as control object based as plant and dept not match so continue : ");fflush(stdout);
					 }
				 }
			  }
			  else
			  {
				  printf("\n as control object based on plant and dept loop not entered in else loop : ");fflush(stdout);
				  resultCnt1=0;
			  }

			
			}

			tag_t window2 = NULLTAG;
			tag_t window3 = NULLTAG;
			CALLAPI(BOM_create_window (&window2));
			//Get Child objs of currnt rev objs)
			if(resultCnt1>0)
			{
				printf("\n tmSupressedParts inside window2 bvrinfo : %s",bvrinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window2 bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window2 RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window2 ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
				CALLAPI(getFirstLevelChildObjs(window2,part_sup,&PartRevModelLst,&PartRevModelLstCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule
			}
			else
			{
			   CALLAPI(getFirstLevelChildObjs(window2,part_sup,&PartRevModelLst,&PartRevModelLstCnt, "view", "Latest Working", ""));//T5_DFMA, view

				   CSBomLine=(char *) MEM_alloc(100);
				   tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
			}
			printf("\n tmSupressedParts Child Count of Current Part============>%d\n",PartRevModelLstCnt);fflush(stdout);
			//Get previous official Revision of the part object.
			//CALLAPI(getPrevOfficialRev(itemMstr,part_sup,&prev_rev_tag));
			
			
			if(prev_rev_tag != NULLTAG)
			{	
				CALLAPI(BOM_create_window (&window3))
				if(resultCnt1>0)
				{
					printf("\n tmSupressedParts inside window3 bvrinfo : %s",bvrinfo);fflush(stdout);
					printf("\n tmSupressedParts inside window3 bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				    printf("\n tmSupressedParts inside window3 RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				    printf("\n tmSupressedParts inside window3 ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					CALLAPI(getFirstLevelChildObjs(window3, prev_rev_tag,&prevPartModelLst,&prevPartModelLstCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule
				}
				else
				{
				  CALLAPI(getFirstLevelChildObjs(window3, prev_rev_tag,&prevPartModelLst,&prevPartModelLstCnt, "view", "Latest Working", ""));//T5_DFMA, view
				}
			}
			else
			{
				printf("\n tmSupressedParts No previous official revision for part %s:%s\n",parentpartId,RevisionS);fflush(stdout);
				
			}
			printf("\n tmSupressedParts Child Count of Prev official rev  Part============>%d\n",prevPartModelLstCnt);fflush(stdout);
			
			
			//print header part
			if(PartRevModelLstCnt>0)
			{
				fprintf(DmlRelFile,"\n\n Supressed Parts  ");fflush(DmlRelFile);
				fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				//parentpartId,RevisionS
				suprNo++;
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s",suprNo, parentpartId,RevisionS);fflush(stdout);
			}
			//print add part details
			
			if(PartRevModelLstCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   REPLACES_PARTNO
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","","Supressed ERC Modules","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","REPLACES_PARTNO");fflush(stdout);
	
				int k=0;
				char* addPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revStr = NULL;
				char* revtmp = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				tag_t currChildLine = NULLTAG;
				
				for(k=0;k<PartRevModelLstCnt;k++)
				{
					currChildLine =PartRevModelLst[k]->childBomLine;
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_item_item_id", &addPartId));
					printf("\ntmSupressedParts:addPartId: %s",addPartId); fflush(stdout);
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(currChildLine,"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					CALLAPI (AOM_UIF_ask_value(currChildLine,"bl_rev_item_revision_id",&rev));
					CALLAPI (AOM_UIF_ask_value(currChildLine,"bl_rev_item_revision_id",&revtmp));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					//CALLAPI (AOM_UIF_ask_value(currChildLine,"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(currChildLine,CSBomLine,&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task
					tag_t part_EPA_REL = NULLTAG;
                    tag_t part_ES_rel = NULLTAG;
                    tag_t part_master = NULLTAG;
                    tag_t part_fndS = NULLTAG;
                    tag_t	*primary_obj	=	NULLTAG;
                    tag_t	*primary_objES	=	NULLTAG;
                    int EPAOBcnt =0;
                    int ESOBcnt =0;
                    int u =0;
                    int ES1 = 0;
                    char* epaTasktmp = NULL;
                    char* epaTaskidtmp = NULL;
                    char* epaTask = NULL;
                    char* esStrtmp = NULL;
                    char* esStridtmp = NULL;
                    char* esStr = NULL;


					CALLAPI(ITEM_find_item(addPartId,&part_master));
					if(part_master!=NULLTAG)
                    {
                       printf("\ntmStructureChanges1:ES Estimate_Relation part_master found"); fflush(stdout);
                    }
					CALLAPI(ITEM_find_revision(part_master,revtmp,&part_fndS));
                    CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &part_EPA_REL));
                    CALLAPI(GRM_list_primary_objects_only(part_fndS,part_EPA_REL,&EPAOBcnt,&primary_obj));
                    printf("\ntmSupressedParts:EPAOBcnt: %d ",EPAOBcnt); fflush(stdout);
                    epaTask=(char *) MEM_alloc(100);
                    tc_strcpy(epaTask,"");
                    for(u=0;u<EPAOBcnt;u++)
                    {
                    	CALLAPI(AOM_UIF_ask_value(primary_obj[u],"object_type",&epaTasktmp));
                        printf("\ntmSupressedParts:epaTask: %s",epaTasktmp); fflush(stdout);
                    	if(tc_strcmp(epaTasktmp,"EPA Task Revision")==0)
                    	{
                    		CALLAPI(AOM_UIF_ask_value(primary_obj[u],"item_id",&epaTaskidtmp));
                            printf("\ntmSupressedParts:epaTask: %s",epaTaskidtmp); fflush(stdout);
                    		tc_strcpy(epaTask,epaTaskidtmp);
                    		break;
                    	}
                    }
                    CALLAPI(GRM_find_relation_type("T5_Design_Estimate_Relation", &part_ES_rel));
                    CALLAPI(ITEM_find_item(addPartId,&part_master));
                    if(part_master!=NULLTAG)
                    {
                    	printf("\ntmSupressedParts:ES Estimate_Relation part_master found"); fflush(stdout);
                    }
                    CALLAPI(GRM_list_secondary_objects_only(part_master,part_ES_rel,&ESOBcnt,&primary_objES));
                    printf("\ntmSupressedParts:ESOBcnt: %d ",ESOBcnt); fflush(stdout);
                    esStr=(char *) MEM_alloc(300);
                    tc_strcpy(esStr,"");
                    for(ES1=0;ES1<ESOBcnt;ES1++)
                    {
                    	CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"object_type",&esStrtmp));
                        printf("\ntmSupressedParts:esStrtmp: %s",esStrtmp); fflush(stdout);
                    	//ES -
                    	if(tc_strcmp(esStrtmp,"Estimate Sheet Revision")==0)
                    	{
                    		CALLAPI(AOM_UIF_ask_value(primary_objES[ES1],"item_id",&esStridtmp));
                            printf("\ntmSupressedParts:esStridtmp: %s",esStridtmp); fflush(stdout);
                    		tc_strcat(esStr,esStridtmp);
                    		tc_strcat(esStr,",");
                    	}
                    
                    }
                    if(tc_strcmp(epaTask,"")==0)
                    {
                    	tc_strcpy(epaTask,"-");
                    }
                    if(tc_strcmp(esStr,"")==0)
                    {
                    	tc_strcpy(esStr,"-");
                    }

					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-15s%-25s%-5s%-5s%-25s","",addPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,epaTask,esStr,"","");fflush(stdout);
				}
			}
			
			//print footer supressed change
			if(PartRevModelLstCnt>0)
			{
				    APLSupressedcnt=PartRevModelLstCnt+APLSupressedcnt;
					printf("\n tmSupressedParts APLSupressedcnt ============>%d \n",APLSupressedcnt);fflush(stdout);
					//fprintf(DmlRelFile,"\n -----------------------Total supressed parts count is :  %d  -----------------------------------------------------------",*APLSupressedcnt);fflush(DmlRelFile);
					fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
			}		
			
			if(window2!=NULLTAG) CALLAPI(BOM_close_window(window2));
			if(window3!=NULLTAG) CALLAPI(BOM_close_window(window3));	
			
		}

		}
		
		fprintf(DmlRelFile,"\n -----------------------Total supressed parts count is :  %d  -----------------------------------------------------------",APLSupressedcnt);fflush(DmlRelFile);
		fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
	printf("\n at end tmStructureChanges1  supressed for non_ERC : \n"); fflush(stdout);
	
	return ifail;
}
//int tmStructureChanges1(char *DMLPlant,char *DMLDept,int n_parts,tag_t* part_obj_tag, FILE* DmlRelFile,char*** buffStr, int *cnt, int *prtAddCnt, int *prtDelCnt, int *prtQtyChngCnt)
int tmSupressedParts(char *DMLPlant,char *DMLDept,int n_parts,tag_t* part_obj_tag,FILE* DmlRelFile,char*** buffStr,int *cnt,int *APLSupressedcnt,int *MBOMSupressedcnt)
{
	printf("\n inside  tmSupressedParts for non_ERC : "); fflush(stdout); 
	int ifail = ITK_ok;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;	
	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	printf("\n DMLPlant :: %s",DMLPlant); fflush(stdout);
	printf("\n DmlDept :: %s",DMLDept); fflush(stdout);
	
	if(n_parts>0)
	{
		int j=0;
		tag_t curr_rev_tag = NULLTAG;
		char* parentpartId = NULL;
		char* parentpartDsgnOwn = NULL;
		char* parentpartuser = NULL;
		char* parentpartPartCode = NULL;
		char* parentpartPartCodeDup = NULL;
		char* parentpartDesgnDept = NULL;
		char* parentpartId1 = NULL;
		char* RevisionS = NULL;
		tag_t itemMstr = NULLTAG;
		tag_t prev_rev_tag = NULLTAG;
		int srNo =0;

		char *qry_entries1[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
		char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
		char **qry_infovalues1 = (char **) MEM_alloc(50 * sizeof(char *));

		for(j=0;j<n_parts;j++)
		{
			curr_rev_tag=NULLTAG;
			curr_rev_tag=part_obj_tag[j];
			prev_rev_tag = NULLTAG;
			PartModel * PartRevModelLst;
			int PartRevModelLstCnt = 0;
			PartModel* prevPartModelLst;
			int prevPartModelLstCnt =0;
			tag_t* addedChldLine = NULLTAG;
			int addedChldLineCnt = 0;
			tag_t* delChldLine = NULLTAG;
			int delChldLineCnt = 0;
			tag_t* qtyChildLne = NULLTAG;
			int qtyChildLneCnt = 0;	
			char** prevQtyStr = NULL;
			int prevQtyStrCnt = 0;
			int 	n_values_bvr=0;
			int assbvr=0;
	        int bvrfound=0;
			char *view_name=NULL;
			char*	partTok		=NULL;
	        char*	viewTok		=NULL;
	        char*	partModBA		=NULL;
			tag_t			*bvr_assy_part= NULLTAG;
			tag_t	Cntl_obj_Qtag1	=	NULLTAG;
			tag_t	*qry_cntrlobjval	=	NULLTAG;
			tag_t	*qry_infocntrlobjval	=	NULLTAG;

			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&parentpartId));
			printf("\ntmSupressedParts:parentpartId :   %s \n",parentpartId); fflush(stdout);
			ITEM_ask_item_of_rev(curr_rev_tag,&itemMstr);

			CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"item_revision_id",&RevisionS));
			printf("\ntmSupressedParts:RevisionS :   %s \n",RevisionS); fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_DsgnOwn",&parentpartDsgnOwn));
			printf("\ntmSupressedParts:parentpartDsgnOwn : %s \n",parentpartDsgnOwn); fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"owning_user",&parentpartuser));
			printf("\ntmSupressedParts:parentpartuser : %s \n",parentpartuser); fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_PartCode",&parentpartPartCode));
			printf("\ntmSupressedParts:parentpartPartCode : %s \n",parentpartPartCode); fflush(stdout);
			CALLAPI(AOM_UIF_ask_value(curr_rev_tag,"t5_DsgnDept",&parentpartDesgnDept));
			printf("\ntmSupressedParts:parentpartDesgnDept : %s \n",parentpartDesgnDept); fflush(stdout);
			
			int n_entries1 =	3;
			int resultCnt1 =	0;
			int resultinfoCnt1 =	0;
			int lk,A7 =	0;

			char *bvrinfo	   = NULL;
			char *bvrviewtypeinfo	   = NULL;
	        char *RevRuleinfo 	   = NULL;
	        char *ClosureRlinfo	   = NULL;
	        char *CSBomLine   = NULL;
	        char *Info1   = NULL;
	        char *Info2   = NULL;

			if(QRY_find("Control Objects...", &Cntl_obj_Qtag1));
			if(Cntl_obj_Qtag1!=NULLTAG)
			{
				printf("\n NONERC DMLPRINT Control Object Query Found \n");fflush(stdout);
				qry_values1[0] ="NONERC";
				qry_values1[1] ="DMLPRINT";
				qry_values1[2] ="0";

				resultCnt1=0;
				CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_values1, &resultCnt1, &qry_cntrlobjval));
				printf("\nNo. of control object found : %d\n",resultCnt1);fflush(stdout);
				if((resultCnt1>0) && ((tc_strcmp(DMLPlant,"")!=0) || (tc_strcmp(DMLDept,"")!=0)))
			    {

				for(lk=0;lk<resultCnt1;lk++)
				{
                  printf("\nControl object result count is greater than 0 found \n");fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo1", &Info1));
				  printf("\n Info1 : %s",Info1);fflush(stdout);
				  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo2", &Info2));
				  printf("\n Info2 : %s",Info2);fflush(stdout);
				  if((tc_strcmp(Info1,DMLPlant)==0) && (tc_strcmp(Info2,DMLDept)==0))
				  {
				    
                      printf("\nControl object result count is greater than 0 found and Matched on basis of dmlplant \n");fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo3", &bvrinfo));
					  printf("\n bvrinfo : %s",bvrinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo4", &RevRuleinfo));
					  printf("\n RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo5", &ClosureRlinfo));
					  printf("\n ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo8", &CSBomLine));
					  printf("\n CSBomLine : %s",CSBomLine);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(qry_cntrlobjval[lk], "t5_Userinfo9", &bvrviewtypeinfo));
					  printf("\n bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
					  CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&parentpartId1));
	                  printf("\n Part number===>%s\n",parentpartId1);fflush(stdout);
					  ITKCALL(ITEM_rev_list_bom_view_revs(curr_rev_tag, &n_values_bvr, &bvr_assy_part));
	                  printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

					  if(n_values_bvr>0)
					   {
                          printf("\n BVR found");fflush(stdout);
						  bvrfound=0;
						  for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						   {
							  CALLAPI(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							  printf("\n view_name %s",view_name);fflush(stdout);
							  partTok = strtok (view_name,"-");
							  viewTok = strtok (NULL,"-");
							  printf("\n viewTok %s",viewTok);fflush(stdout);
								  if(strlen(viewTok)>0)
								  {
									 if(tc_strcmp(viewTok,bvrinfo)==0)
									 {
										bvrfound++;
										printf("\n viewTok %s",viewTok);fflush(stdout);
										printf("\n bvrinfo %s",bvrinfo);fflush(stdout);
										printf("\n bvrviewtypeinfo %s",bvrviewtypeinfo);fflush(stdout);
										printf("\n part bvr found and matched as per CObj\n");fflush(stdout);																				
										break;
									 }
								  }
						   }

						   if(bvrfound!=1)
							{
							    bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrinfo updated : %s",bvrinfo);fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
							}
					   }
					   else
					   {
						        bvrviewtypeinfo=(char *) MEM_alloc(100);
							    tc_strcpy(bvrviewtypeinfo,"view");
								printf("\n bvr not found and matched so set default view ..\n");fflush(stdout);
								printf("\n bvrviewtypeinfo updated : %s",bvrviewtypeinfo);fflush(stdout);
					   }
                         break;

				     }
					 else if (lk==(resultCnt1-1))
					 {
						 bvrviewtypeinfo=(char *) MEM_alloc(100);
						 tc_strcpy(bvrviewtypeinfo,"view");
						 RevRuleinfo=(char *) MEM_alloc(100);
						 tc_strcpy(RevRuleinfo,"Latest Working");
						 ClosureRlinfo=(char *) MEM_alloc(100);
						 tc_strcpy(ClosureRlinfo,"");
						 CSBomLine=(char *) MEM_alloc(100);
				         tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
					 }
					 else
					 {
						 printf("\n as control object based as plant and dept not match so continue : ");fflush(stdout);
					 }
				 }
			  }
			  else
			  {
				  printf("\n as control object based on plant and dept loop not entered in else loop : ");fflush(stdout);
				  resultCnt1=0;
			  }

			char *Cobjinfo1	   = NULL;
            char *Cobjinfo2	   = NULL;
            char *Cobjinfo3	   = NULL;
            char *Cobjinfo4	   = NULL;
            char *Cobjinfo5	   = NULL;
            char *Cobjinfo6	   = NULL;
            char *Cobjinfo7	   = NULL;
			parentpartPartCodeDup=subString(parentpartId,6,1);
			partModBA=subString(parentpartId,4,5);
			printf("\ntmSupressedParts:parentpartPartCodeDup : %s \n",parentpartPartCodeDup); fflush(stdout);
			printf("\ntmSupressedParts:partModBA : %s \n",partModBA); fflush(stdout);
            qry_infovalues1[0]="NONERC_DMLPRINT";
	        qry_infovalues1[1]=DMLDept;
	        qry_infovalues1[2]="0";
			CALLAPI(QRY_execute(Cntl_obj_Qtag1, n_entries1, qry_entries1, qry_infovalues1, &resultinfoCnt1, &qry_infocntrlobjval));
			printf("\nNo. of control object found : %d\n",resultinfoCnt1);fflush(stdout);
			  if(resultinfoCnt1>0)
			   {
				for(A7=0;A7<resultinfoCnt1;A7++)
				 {
				    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo1", &Cobjinfo1));
				    printf("\n Cobjinfo1 : %s",Cobjinfo1);fflush(stdout);
				    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo2", &Cobjinfo2));
				    printf("\n Cobjinfo2 : %s",Cobjinfo2);fflush(stdout);
				    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo3", &Cobjinfo3));
				    printf("\n Cobjinfo3 : %s",Cobjinfo3);fflush(stdout);
				    CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo4", &Cobjinfo4));
				    printf("\n Cobjinfo4 : %s",Cobjinfo4);fflush(stdout);
					CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo5", &Cobjinfo5));
				    printf("\n Cobjinfo5 : %s",Cobjinfo5);fflush(stdout);
					CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo6", &Cobjinfo6));
				    printf("\n Cobjinfo6 : %s",Cobjinfo6);fflush(stdout);
					CALLAPI(AOM_ask_value_string(qry_infocntrlobjval[A7], "t5_Userinfo7", &Cobjinfo7));
				    printf("\n Cobjinfo7 : %s",Cobjinfo7);fflush(stdout);

				 }
				 if((tc_strstr(Cobjinfo7,parentpartPartCodeDup)==NULL))
				   {
				   if((tc_strstr(parentpartId,Cobjinfo1)==NULL)&&(tc_strstr(parentpartId,Cobjinfo2)==NULL)&&(tc_strstr(parentpartId,Cobjinfo3)==NULL)&&(tc_strstr(parentpartId,Cobjinfo4)==NULL)&&(tc_strstr(parentpartId,Cobjinfo5)==NULL)&&(tc_strstr(parentpartId,Cobjinfo6)==NULL))
					{
						 continue;
						 //PROPUNE
						 //PROLKO
						 //PROJSR
						 //  W X Y Z  --- manufacturing parts
						 //Compared MBOM and APL parts info from control objects 
					     //APLPUNE
					     //TELPUNE
					     //R20  R40
					}
				   else
				    {
					  printf("\n tmSupressedParts inside control object found to and match with COBJECT so fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
				    }
				   }
	
			   }
			   else
			   {
				   printf("\n tmSupressedParts inside as no control object found to fetch manufacturing parts for dept  %s ",DMLDept);fflush(stdout);
				   break;
			   }
			}

			tag_t window = NULLTAG;
			tag_t window1 = NULLTAG;
			CALLAPI(BOM_create_window (&window));
			//Get Child objs of currnt rev objs)
			if(resultCnt1>0)
			{
				printf("\n tmSupressedParts inside window bvrinfo : %s",bvrinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				printf("\n tmSupressedParts inside window ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
				CALLAPI(getFirstLevelChildObjs(window,curr_rev_tag,&PartRevModelLst,&PartRevModelLstCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule
			}
			else
			{
			   CALLAPI(getFirstLevelChildObjs(window,curr_rev_tag,&PartRevModelLst,&PartRevModelLstCnt, "view", "Latest Working", ""));//T5_DFMA, view

				   CSBomLine=(char *) MEM_alloc(100);
				   tc_strcpy(CSBomLine,"bl_Design Revision_t5_CarMakeBuyIndicator");
			}
			printf("\n tmSupressedParts Child Count of Current Part============>%d\n",PartRevModelLstCnt);fflush(stdout);
			//Get previous official Revision of the part object.
			//CALLAPI(getPrevOfficialRev(itemMstr,curr_rev_tag,&prev_rev_tag));
			
			
			if(prev_rev_tag != NULLTAG)
			{	
				CALLAPI(BOM_create_window (&window1))
				if(resultCnt1>0)
				{
					printf("\n tmSupressedParts inside window1 bvrinfo : %s",bvrinfo);fflush(stdout);
					printf("\n tmSupressedParts inside window1 bvrviewtypeinfo : %s",bvrviewtypeinfo);fflush(stdout);
				    printf("\n tmSupressedParts inside window1 RevRuleinfo : %s",RevRuleinfo);fflush(stdout);
				    printf("\n tmSupressedParts inside window1 ClosureRlinfo : %s",ClosureRlinfo);fflush(stdout);
					CALLAPI(getFirstLevelChildObjs(window1, prev_rev_tag,&prevPartModelLst,&prevPartModelLstCnt, bvrviewtypeinfo, RevRuleinfo, ClosureRlinfo));//NON_ERC bvr,revisionrule and closure rule
				}
				else
				{
				  CALLAPI(getFirstLevelChildObjs(window1, prev_rev_tag,&prevPartModelLst,&prevPartModelLstCnt, "view", "Latest Working", ""));//T5_DFMA, view
				}
			}
			else
			{
				printf("\n tmSupressedParts No previous official revision for part %s:%s\n",parentpartId,RevisionS);fflush(stdout);
				
			}
			printf("\n tmSupressedParts Child Count of Prev official rev  Part============>%d\n",prevPartModelLstCnt);fflush(stdout);
			
			
			//print header part
			if(PartRevModelLstCnt>0)
			{
				fprintf(DmlRelFile,"\n\n Supressed Parts  ");fflush(DmlRelFile);
				fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				//parentpartId,RevisionS
				srNo++;
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s",srNo, parentpartId,RevisionS);fflush(stdout);
			}
			//print add part details
			
			if(PartRevModelLstCnt>0)
			{
				//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   REPLACES_PARTNO
				fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","","Supressed ERC Modules","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","REPLACES_PARTNO");fflush(stdout);
	
				int k=0;
				char* addPartId = NULL;
				char* partDesc = NULL;
				char* rev = NULL;
				char* revStr = NULL;
				char* seqStr = NULL;
				char* csStr = NULL;
				char* ciStr = NULL;
				char* qtyStr = NULL;
				char* siStr = NULL;
				tag_t currChildLine = NULLTAG;
				
				for(k=0;k<PartRevModelLstCnt;k++)
				{
					currChildLine =PartRevModelLst[k]->childBomLine;
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_item_item_id", &addPartId));
					//Assy-Part-Description
					CALLAPI (AOM_ask_value_string(currChildLine,"bl_item_object_desc",&partDesc));
					
					if (partDesc==NULL)
					{
						tc_strdup("NA",&partDesc);
					}
					CALLAPI (AOM_UIF_ask_value(currChildLine,"bl_rev_item_revision_id",&rev));
					//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
					
					if(tc_strstr(rev,";") != NULL)
					{
						revStr = tc_strtok ( rev,";") ;
						seqStr = tc_strtok ( NULL,";") ;	
					}
					//CALLAPI (AOM_UIF_ask_value(currChildLine,"bl_rev_sequence_id",&seq));
									
					//CS
					//CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
					CALLAPI(AOM_ask_value_string(currChildLine,CSBomLine,&csStr));	
					//CI
					CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_ColourInd",&ciStr));
					//Qty
					CALLAPI(AOM_ask_value_string(currChildLine, "bl_quantity", &qtyStr));
					//SI
					CALLAPI(AOM_UIF_ask_value(currChildLine,"bl_Design Revision_t5_SpareInd",&siStr));
					//QRI, Loc, Epa Task

					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",addPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,"","","","");fflush(stdout);
				}
			}
			
			//print footer supressed change
			if(PartRevModelLstCnt>0)
			{
				    *APLSupressedcnt=PartRevModelLstCnt;
					fprintf(DmlRelFile,"\n -----------------------Total supressed parts count is :  %d  -----------------------------------------------------------",*APLSupressedcnt);fflush(DmlRelFile);
					fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
			}		
			
			if(window!=NULLTAG) CALLAPI(BOM_close_window(window));
			if(window1!=NULLTAG) CALLAPI(BOM_close_window(window1));	
			
		}
		
		
		printf("\n at end tmSupressedParts for non_ERC : \n"); fflush(stdout); 
	}
	
	return ifail;
}

int getTopLineOfItem(tag_t window, tag_t partRevObj, tag_t* top_line,char * revisionRuleName, char* closureRuleName)
{
	int ifail = ITK_ok;
	tag_t partRevisionRule = NULLTAG;
	int flagRevRule = 0;
	int flagClosureRule = 0;
	tag_t closureRuleObj = NULLTAG;
	tag_t top_line_curr = NULLTAG;
	int n =0;
	tag_t* children = NULLTAG;
	printf("\nRevision rule name:====>%s",revisionRuleName);fflush(stdout);
	CALLAPI(getRevisionRuleObject(revisionRuleName,&partRevisionRule));
	if(partRevisionRule !=NULLTAG)
	{
		printf("\n Revision Rule not null........\n");fflush(stdout);
		flagRevRule = 1;
	}
	else
	{
		flagRevRule = 0;
	}
	//CALLAPI(getBomViewRevObject(partRevObj,bvrViewName, &bomViewObj));	
	
	if(flagRevRule == 1)
	{
		CALLAPI(getClosureRuleObject(closureRuleName,&closureRuleObj));
		if(closureRuleObj!=NULLTAG)
		{
			
			printf("\n Closure Rule not null........\n");fflush(stdout);
			flagClosureRule = 1;
		}
		else
		{
			printf("\n Closure Rule NULL........\n");fflush(stdout);
			flagClosureRule = 0;
		}
		printf("\n flagClosureRule================>%d\n", flagClosureRule);fflush(stdout);
		
		CALLAPI(BOM_set_window_config_rule(window,partRevisionRule));
		if(flagClosureRule ==1)
				CALLAPI(BOM_window_set_closure_rule(window,closureRuleObj,0,NULL,NULL));
			
		CALLAPI(BOM_set_window_pack_all (window, true))
		CALLAPI(BOM_set_window_top_line (window, NULLTAG, partRevObj, NULLTAG, &top_line_curr))
		CALLAPI(BOM_line_ask_child_lines (top_line_curr, &n, &children))
		printf("\nCurrent part child count : %d",n);fflush(stdout);	
		*top_line = top_line_curr;
	}
	
	
	return ifail;
}
int tmStructureChanges_new(int n_parts,tag_t* part_obj_tag, FILE* DmlRelFile,char*** buffStr, int *cnt, int *prtAddCnt, int *prtDelCnt, int *prtQtyChngCnt)
{
	int ifail = ITK_ok;
	tag_t  CurrentRoleTag = NULLTAG;
	char   roleName[SA_name_size_c+1]  ;	
	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	
	if(n_parts>0)
	{	
		int j =0;
		tag_t curr_rev_tag = NULLTAG;
		tag_t itemMstr = NULLTAG;
		tag_t prev_rev_tag = NULLTAG;
		char* curr_prtNo = NULL;
		char* curr_prtRev = NULL;
		for(j=0;j<n_parts;j++)
		{
			curr_rev_tag=NULLTAG;
			curr_rev_tag=part_obj_tag[j];			
			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_id",&curr_prtNo));
			CALLAPI(AOM_ask_value_string(curr_rev_tag,"item_revision_id",&curr_prtRev));
			printf("\nCurrent part: %s %s",curr_prtNo,curr_prtRev);fflush(stdout);	
			
			if(tc_strstr(curr_prtRev,"NR")==NULL)
			{
				tag_t bomViewObj = NULLTAG;
				tag_t* addedChildLine = NULLTAG;
				int addedChildLineCnt = 0;
				tag_t* delChildLine = NULLTAG;
				int delChildLineCnt = 0;
				QtyChangeModel* qtyChildLine = NULLTAG;
				int qtyChildLineCnt = 0;				
				tag_t window = NULLTAG;
				tag_t window1 = NULLTAG;
				tag_t top_line_curr = NULLTAG;
				tag_t top_line_prev = NULLTAG;				
				//Get Bom View object
				CALLAPI(getBomViewRevObject(curr_rev_tag,"view", &bomViewObj));	
				if(bomViewObj != NULLTAG)
				{
					

					//Get top line of current part
				
					//getTopLineOfItem(tag_t window, tag_t partRevObj, tag_t* top_line,char * revisionRuleName, char* closureRuleName)
					CALLAPI(BOM_create_window (&window));
				    CALLAPI(getTopLineOfItem(window,curr_rev_tag,&top_line_curr,"Latest Working",""));//ERC Review And Above
					if(top_line_curr == NULLTAG)
					{
						printf("\n top_line of current part is NULLTAG. So skipping this part.......\n");fflush(stdout);
						continue;
					}
					
					
					//Get previous official revision.
					ITEM_ask_item_of_rev(curr_rev_tag,&itemMstr);
					CALLAPI(getPrevOfficialRev(itemMstr,curr_rev_tag,&prev_rev_tag));
					if(prev_rev_tag != NULLTAG)
					{
						tag_t bomViewObj1 = NULLTAG;
						CALLAPI(getBomViewRevObject(prev_rev_tag,"view", &bomViewObj1));
						if(bomViewObj1==NULLTAG)
						{
							printf("\nbomViewObj1 is NULLTAG\n");fflush(stdout);
							//continue;
						}
							
						
						CALLAPI(BOM_create_window (&window1));
						CALLAPI(getTopLineOfItem(window1,prev_rev_tag,&top_line_prev,"Latest Working",""));//ERC Review And Above
						 
						 //Bom compare
						CALLAPI(BOM_compare_execute(NULLTAG, top_line_curr, top_line_prev,"IMAN_bcm_ext_var_level" , BOM_compare_output_report))
						int report_length = 0;
						char** report_lines =NULL;
						tag_t* report_items=NULL;
						CALLAPI(BOM_compare_report(top_line_curr, &report_length, &report_lines,&report_items))
						if(report_length>0)
						{
							int j =0;
							for(j=0;j<report_length;j++)
							{
								tag_t my_cmp_item = NULLTAG;
								my_cmp_item = report_items[j];
								
								int count1=0;
								tag_t* bomline_list1 = NULLTAG;
								int count2 =0;
								tag_t* bomline_list2 = NULLTAG;
								BOM_compare_list_bomlines(my_cmp_item,&count1,&bomline_list1,&count2,&bomline_list2);
								
								if(count1 && !count2)
								{
									//Added parts
									char* blItemid1 = NULL;
									char* blrev1 = NULL;
									CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_item_item_id",&blItemid1));
									CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_item_revision_id",&blrev1));
									printf("\ncurrent bl item ===>%s %s",blItemid1,blrev1);fflush(stdout);
									setAddTAG(&addedChildLineCnt, &addedChildLine,bomline_list1[0]);
									*prtAddCnt = *prtAddCnt + 1;
									
								}
								
								if(!count1 && count2)
								{
									//deleted parts
									char* blItemid2 = NULL;
									char* blrev2 = NULL;
									CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_item_item_id",&blItemid2));
									CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_rev_item_revision_id",&blrev2));
									printf("\nprev bl item ===>%s %s",blItemid2,blrev2);fflush(stdout);
									setAddTAG(&delChildLineCnt, &delChildLine,bomline_list2[0]);
									*prtDelCnt = *prtDelCnt + 1;
								}
								if(count1 && count2)
								{
									//changed parts
									char* blItemid1 = NULL;
									char* blrev1 = NULL;
									char* blqt1 = NULL;
									CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_item_item_id",&blItemid1));
									CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_item_revision_id",&blrev1));
									CALLAPI(AOM_UIF_ask_value(bomline_list1[0],"bl_quantity",&blqt1));
									printf("\ncurrent bl item ===>%s %s",blItemid1,blrev1);fflush(stdout);
									
									printf("\ncurrent bl item quantity ===>%s",blqt1);fflush(stdout);
									char* blItemid2 = NULL;
									char* blrev2 = NULL;
									char* blqt2 = NULL;
									CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_item_item_id",&blItemid2));
									CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_rev_item_revision_id",&blrev2));
									CALLAPI(AOM_UIF_ask_value(bomline_list2[0],"bl_quantity",&blqt2));
									printf("\nprev bl item ===>%s %s",blItemid2,blrev2);fflush(stdout);
									printf("\nprev bl item quantity ===>%s",blqt2);fflush(stdout);
									
									if(tc_strcmp(blqt1,blqt2)!=0)
									{
										QtyChangeModel qtyChMdl = (QtyChangeModel)malloc(sizeof(QtyChangeModel));
										
										qtyChMdl->currLineItem = bomline_list1[0];
										qtyChMdl->prevLineItem = bomline_list2[0];
										qtyChMdl->currQty = blqt1;
										qtyChMdl->prevQty = blqt2;
										setAddQtyChangeModel(&qtyChildLineCnt,&qtyChildLine,qtyChMdl);
										*prtQtyChngCnt = *prtQtyChngCnt + 1;
									}
									 
									
									
								}
								

							}
						}						
						
					}
					else
					{
						printf("\n No previous official revision for part %s:%s\n",curr_prtNo,curr_prtRev);fflush(stdout);
						
					}
				}
				else
				{
					printf("\n BOM VIEW Revision does not exist for view........\n");fflush(stdout);
				}
				
				//print in file
				int srNo =0;
							//print header part
				if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
				{
					fprintf(DmlRelFile,"\n\n STRUCTURE CHANGES");fflush(DmlRelFile);
					fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
					//parentpartId,RevisionS
					srNo++;
					fprintf(DmlRelFile,"\n%-5d%-20s%-5s",srNo, curr_prtNo,curr_prtRev);fflush(stdout);
				}
				//print add part details
				
				if(addedChildLineCnt>0)
				{
					//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   REPLACES_PARTNO
					
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","","Added Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","REPLACES_PARTNO");fflush(stdout);
		
					int k=0;
					char* addPartId = NULL;
					char* partDesc = NULL;
					char* rev = NULL;
					char* revStr = NULL;
					char* seqStr = NULL;
					char* csStr = NULL;
					char* ciStr = NULL;
					char* qtyStr = NULL;
					char* siStr = NULL;
					
					for(k=0;k<addedChildLineCnt;k++)
					{
						CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_item_item_id", &addPartId));
						//Assy-Part-Description
						CALLAPI (AOM_ask_value_string(addedChildLine[k],"bl_item_object_desc",&partDesc));
						
						if (partDesc==NULL)
						{
							tc_strdup("NA",&partDesc);
						}
						
						
						CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_item_revision_id",&rev));
						//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
						
						if(tc_strstr(rev,";") != NULL)
						{
							revStr = tc_strtok ( rev,";") ;
							seqStr = tc_strtok ( NULL,";") ;	
						}
						
						//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
										
						//CS
						//CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));
						CALLAPI(AOM_ask_value_string(addedChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));						
						//CI
						CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
						//Qty
						CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
						//SI
						CALLAPI(AOM_UIF_ask_value(addedChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
						//QRI, Loc, Epa Task

						fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",addPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,"","","","");fflush(stdout);
					}
				}
				
				//print del part details
				if(delChildLineCnt>0)
				{
					
					
					//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
					
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","","Deleted Parts","Description","Rev","Seq","CS","CI","Qty","QRI","Loc","SI","Epa Task","ES","IC","RSFAP(DI)");fflush(stdout);
					int k=0;
					char* delPartId = NULL;
					char* partDesc = NULL;
					char* rev = NULL;
					char* revStr = NULL;
					char* seqStr = NULL;
					char* csStr = NULL;
					char* ciStr = NULL;
					char* qtyStr = NULL;
					char* siStr = NULL;
					for(k=0;k<delChildLineCnt;k++)
					{
						CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_item_item_id", &delPartId));
						//Assy-Part-Description
						CALLAPI (AOM_ask_value_string(delChildLine[k],"bl_item_object_desc",&partDesc));
						
						if (partDesc==NULL)
						{
							tc_strdup("NA",&partDesc);
						}
						
						
						CALLAPI (AOM_UIF_ask_value(delChildLine[k],"bl_rev_item_revision_id",&rev));
						//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
						
						if(tc_strstr(rev,";") != NULL)
						{
							revStr = tc_strtok ( rev,";") ;
							seqStr = tc_strtok ( NULL,";") ;	
						}
						
						//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
										
						//CS
						//CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));	
						CALLAPI(AOM_ask_value_string(delChildLine[k],"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));						
						//CI
						CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_ColourInd",&ciStr));
						//Qty
						CALLAPI(AOM_ask_value_string(delChildLine[k], "bl_quantity", &qtyStr));
						//SI
						CALLAPI(AOM_UIF_ask_value(delChildLine[k],"bl_Design Revision_t5_SpareInd",&siStr));
						//QRI, Loc, Epa Task					
						//fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",delPartId,"","","","","","","","","","","","","-----");fflush(stdout);
						fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-10s%-10s%-5s%-25s%-5s%-5s%-25s","",delPartId,partDesc,revStr,seqStr,csStr,ciStr,qtyStr,"","",siStr,"","","","");fflush(stdout);
					}
				}			
				
				//print qty change details.
				
				if(qtyChildLineCnt>0)
				{
					//Added Parts        Description                              Rev,Seq  CS     CI            Qty   QRI Loc   SI  Epa Task                       ES IC   RSFAP(DI)
					
					fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-5s%-25s%-5s%-5s","","Change In Qty","Description","Rev","Seq","CS","CI","Old","Qty","QRI","Loc","SI","Epa Task","ES","IC");fflush(stdout);
					int k=0;
					char* qtyPartId = NULL;
					char* oldQtyStr = NULL;
					char* newQtyStr = NULL;
					char* partDesc = NULL;
					char* rev = NULL;
					char* revStr = NULL;
					char* seqStr = NULL;
					char* csStr = NULL;
					char* ciStr = NULL;
					char* siStr = NULL;				
					for(k=0;k<qtyChildLineCnt;k++)
					{
						tag_t currentLineItem = NULLTAG;
						currentLineItem = qtyChildLine[k]->currLineItem;
						CALLAPI(AOM_ask_value_string(currentLineItem, "bl_item_item_id", &qtyPartId));
						CALLAPI(AOM_ask_value_string(currentLineItem, "bl_quantity", &newQtyStr));
						oldQtyStr = qtyChildLine[k]->prevQty;
						//Assy-Part-Description
						CALLAPI (AOM_ask_value_string(currentLineItem,"bl_item_object_desc",&partDesc));
						
						if (partDesc==NULL)
						{
							tc_strdup("NA",&partDesc);
						}
						
						
						CALLAPI (AOM_UIF_ask_value(currentLineItem,"bl_rev_item_revision_id",&rev));
						//printf("\ntmPrintPartsInFile:rev:%d\n",rev); fflush(stdout);
						
						if(tc_strstr(rev,";") != NULL)
						{
							revStr = tc_strtok ( rev,";") ;
							seqStr = tc_strtok ( NULL,";") ;	
						}
						
						//CALLAPI (AOM_UIF_ask_value(addedChildLine[k],"bl_rev_sequence_id",&seq));
										
						//CS
						//CALLAPI(AOM_UIF_ask_value(currentLineItem,"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));
						CALLAPI(AOM_ask_value_string(currentLineItem,"bl_Design Revision_t5_CarMakeBuyIndicator",&csStr));
						//CI
						CALLAPI(AOM_UIF_ask_value(currentLineItem,"bl_Design Revision_t5_ColourInd",&ciStr));
						//Qty
						//CALLAPI(AOM_ask_value_string(addedChildLine[k], "bl_quantity", &qtyStr));
						//SI
						CALLAPI(AOM_UIF_ask_value(currentLineItem,"bl_Design Revision_t5_SpareInd",&siStr));					
						
						fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-25s%-10s%-5s%-5s%-10s%-10s%-5s%-25s%-5s%-5s","",qtyPartId,partDesc,revStr,seqStr,csStr,ciStr,oldQtyStr,newQtyStr,"","",siStr,"","","");fflush(stdout);
					}
				}
				
				
				//print footer structure change
				if(addedChildLineCnt>0 || delChildLineCnt>0 || qtyChildLineCnt>0)
				{
						fprintf(DmlRelFile,"\n --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(DmlRelFile);
				}		
				
				if(window!=NULLTAG) CALLAPI(BOM_close_window(window));
				if(window1!=NULLTAG) CALLAPI(BOM_close_window(window1));				
				
			}
			else
			{
					printf("\n It is NR Part. So NO structure difference of Current part: %s %s",curr_prtNo,curr_prtRev);fflush(stdout);
			}
			
			
			
		}
	}

		
	
	
	return ifail;
}


int tmPrintPartMasterInFile(tag_t partMasterTag,FILE * DmlRelFile,int prtcnt,char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	char* partNum = NULL;
	char* partDesc = NULL;
	char* rev = NULL;
	char* revStr = NULL;
	char* seq = NULL;
	char* seqStr = NULL;
	char* siStr = NULL;
	char* siOldStr = NULL;

	//Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
	prtcnt++;
	//Assy-Partno
	CALLAPI(AOM_ask_value_string(partMasterTag,"item_id",&partNum));
	printf("\ntmPrintPartMasterInFile:partNum: %s",partNum); fflush(stdout);
	
	int cnt1 =0;
	tag_t* partListTag = NULLTAG;
	tag_t part_rev_tag = NULLTAG;
	//CALLAPI(getLatestReleasedAndWIPPart(partMasterTag,&cnt1, &partListTag));
	if(cnt1>0)
	{
		int m = 0;
		for(m=0;m<cnt1;m++)
		{
			part_rev_tag = partListTag[m];
			
			//Assy-Part-Description
			CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&partDesc));
			printf("\ntmPrintPartMasterInFile:partDesc: %s",partDesc); fflush(stdout);
			if (partDesc==NULL)
			{
				tc_strdup("NA",&partDesc);
			}
			CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&rev));
			printf("\ntmPrintPartMasterInFile:rev:%d\n",rev); fflush(stdout);
			
			if(tc_strstr(rev,";") != NULL)
			{
				revStr = tc_strtok ( rev,";") ;
				//seqStr = tc_strtok ( NULL,";") ;	
			}

			CALLAPI (AOM_UIF_ask_value(part_rev_tag,"sequence_id",&seq));
			printf("\ntmPrintPartMasterInFile:seq:%s",seq); fflush(stdout);
			//IA
			
			
			
			//SI
			CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_SpareInd",&siStr));
			printf("\ntmPrintPartMasterInFile:siStr: %s",siStr); fflush(stdout);
			if(tc_strcmp(siStr,"False")==0)
			{
				siOldStr = "True";
			}
			if(tc_strcmp(siStr,"True")==0)
			{
				siOldStr = "False";
			}
			
			if(m >0)
			{
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s%-5s%-20s%-20s",prtcnt,"",revStr,seq,siOldStr,siStr);fflush(stdout);
			}
			else
			{
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s%-5s%-20s%-20s",prtcnt,partNum,revStr,seq,siOldStr,siStr);fflush(stdout);
			}
			
						
		}
									
	}
	

	
	



	return ifail;
}




int tmPrintPartRevInFile(tag_t partMasterTag,FILE * DmlRelFile,int prtcnt,char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	char* partNum = NULL;
	char* partDesc = NULL;
	char* rev = NULL;
	char* revStr = NULL;
	char* seq = NULL;
	char* seqStr = NULL;
	char* siStr = NULL;
	char* siOldStr = NULL;

	//Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
	prtcnt++;
	//Assy-Partno
	CALLAPI(AOM_ask_value_string(partMasterTag,"item_id",&partNum));
	printf("\ntmPrintPartMasterInFile:partNum: %s",partNum); fflush(stdout);
	
	//int cnt1 =0;
	//tag_t* partListTag = NULLTAG;
	tag_t part_rev_tag = NULLTAG;
	//CALLAPI(getLatestReleasedAndWIPPart(partMasterTag,&cnt1, &partListTag))
	//if(cnt1>0)
	{
		int m = 0;
		//for(m=0;m<cnt1;m++)
		{
			part_rev_tag = partMasterTag;
			
			//Assy-Part-Description
			CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&partDesc));
			printf("\ntmPrintPartMasterInFile:partDesc: %s",partDesc); fflush(stdout);
			if (partDesc==NULL)
			{
				tc_strdup("NA",&partDesc);
			}
			CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&rev));
			printf("\ntmPrintPartMasterInFile:rev:%d\n",rev); fflush(stdout);
			
			if(tc_strstr(rev,";") != NULL)
			{
				revStr = tc_strtok ( rev,";") ;
				//seqStr = tc_strtok ( NULL,";") ;	
			}

			CALLAPI (AOM_UIF_ask_value(part_rev_tag,"sequence_id",&seq));
			printf("\ntmPrintPartMasterInFile:seq:%s",seq); fflush(stdout);
			//IA
			
			
			
			//SI
			CALLAPI(AOM_UIF_ask_value(part_rev_tag,"t5_SpareInd",&siStr));
			printf("\ntmPrintPartMasterInFile:siStr: %s",siStr); fflush(stdout);
			if(tc_strcmp(siStr,"False")==0)
			{
				siOldStr = "True";
			}
			if(tc_strcmp(siStr,"True")==0)
			{
				siOldStr = "False";
			}
			
			if(m >0)
			{
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s%-5s%-20s%-20s",prtcnt,"",revStr,seq,siOldStr,siStr);fflush(stdout);
			}
			else
			{
				fprintf(DmlRelFile,"\n%-5d%-20s%-5s%-5s%-20s%-20s",prtcnt,partNum,revStr,seq,siOldStr,siStr);fflush(stdout);
			}
			
						
		}
									
	}
	

	
	



	return ifail;
}


int tm_generateDMLReport(tag_t dmlObj, char*** buffStr, int *cnt)
{
	int ifail = ITK_ok;
	char* username = NULL;
	char* dmlNumber = NULL;
	time_t now;
	struct tm* now_tm;
	char ReleasedDateTime_str[26] = {'\0'};
	char *Filename			= NULL;
	char *FileLoc			= NULL;	
	FILE * DmlRelFile		=NULL;
	int affectedGrp = 0;
	int resPartsCnt =0;
	int prtAddCnt =0;
	int APLSupressedcnt =0;
	int MBOMSupressedcnt =0;
	int prtDelCnt =0;
	int prtAddCnt1 =0;
	int prtDelCnt1 =0;
	int prtQtyChngCnt =0;
	int DFlg =0;
	
	char* relType = NULL;
	char* relType1 = NULL;
	char* MMDmlType = NULL;
	char* MMDmlType1 = NULL;
	char* AplDMLType = NULL;
	char* AplDMLType1 = NULL;
	char* SmDmlType = NULL;
	char* SmDmlType1 = NULL;
	char* DMLPlant = NULL;
	char* DMLDept = NULL;
	
	printf("\n\n Start of function tm_generateDMLReport.....\n");fflush(stdout);
	/***get session user **/
	CALLAPI(POM_get_user_id (&username));
	printf("\t Session login User: %s\n",username); fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(dmlObj,"item_id",&dmlNumber));
	printf("\n\t DML :%s\n",dmlNumber);fflush(stdout);
    
	//Non_ERC DML PRINT
	if((tc_strstr(dmlNumber,"MBOM")!=NULL) && (tc_strstr(dmlNumber,"MM")!=NULL))
	{
		CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_MBOMRlzType",&MMDmlType));
    	printf("\t MMDml Type  full name : %s \n",MMDmlType); fflush(stdout);
		CALLAPI(AOM_ask_value_string(dmlObj,"t5_MBOMRlzType",&MMDmlType1));
    	printf("\t MMDml Type  : %s \n",MMDmlType1); fflush(stdout);
		DMLPlant=subString(dmlNumber,11,4);
		printf("\t DMLPlant  : %s \n",DMLPlant); fflush(stdout);
		DMLDept=subString(dmlNumber,11,4);
		printf("\t DMLDept : %s \n",DMLDept); fflush(stdout);
		DFlg=1;
		printf("\t DFlg  : %d \n",DFlg); fflush(stdout);

	}
	else if((tc_strstr(dmlNumber,"AM")!=NULL))
	{
		CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_EcnType",&AplDMLType));
    	printf("\t AplDML Type  full name : %s \n",AplDMLType); fflush(stdout);
		CALLAPI(AOM_ask_value_string(dmlObj,"t5_EcnType",&AplDMLType1));
    	printf("\t AplDML Type  : %s \n",AplDMLType1); fflush(stdout);
		DMLPlant=subString(dmlNumber,14,1);
		printf("\t DMLPlant  : %s \n",DMLPlant); fflush(stdout);
		DMLDept=subString(dmlNumber,11,4);
		printf("\t DMLDept  : %s \n",DMLDept); fflush(stdout);
		DFlg=2;
		printf("\t DFlg: %d \n",DFlg); fflush(stdout);
	}
	else if((tc_strstr(dmlNumber,"SM")!=NULL))
	{
		CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_SMDMLType",&SmDmlType));
    	printf("\t SmDmlType  full name : %s \n",SmDmlType); fflush(stdout);
		CALLAPI(AOM_ask_value_string(dmlObj,"t5_SMDMLType",&SmDmlType1));
    	printf("\t SmDmlType1   : %s \n",SmDmlType1); fflush(stdout);
		DMLPlant=subString(dmlNumber,14,1);
		printf("\t DMLPlant  : %s \n",DMLPlant); fflush(stdout);
		DMLDept=subString(dmlNumber,11,4);
		printf("\t DMLDept  : %s \n",DMLDept); fflush(stdout);
		DFlg=3;
		printf("\t DFlg : %d \n",DFlg); fflush(stdout);
	}
	else
	{
		printf("\nNON_ERC DML type not FOUND . checked ..! "); fflush(stdout);
		if((tc_strstr(dmlNumber,"AM")==NULL) && (tc_strstr(dmlNumber,"APL")!=NULL))
		{
	      printf("\nNON_ERC DML FOUND check for APL_DML ERC DRIVEN ...  \n"); fflush(stdout);		
			   CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_rlstype",&relType));
			   printf("\t DML release type full name : %s \n",relType); fflush(stdout);	
			   CALLAPI(AOM_ask_value_string(dmlObj,"t5_rlstype",&relType1));
			   printf("\t DML release type  : %s \n",relType1); fflush(stdout);
			   DMLPlant=subString(dmlNumber,14,1);
		       printf("\t DMLPlant  : %s \n",DMLPlant); fflush(stdout);
		       DMLDept=subString(dmlNumber,11,4);
		       printf("\t DMLDept  : %s \n",DMLDept); fflush(stdout);
			   DFlg=4;
		}
		else if((tc_strstr(dmlNumber,"MM")==NULL) && (tc_strstr(dmlNumber,"MBOM")!=NULL))
		{
		  printf("\nNON_ERC DML FOUND check for MBOM_DM ERCL DRIVEN ...  \n"); fflush(stdout);		
			   CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_rlstype",&relType));
			   printf("\t DML release type full name : %s \n",relType); fflush(stdout);	
			   CALLAPI(AOM_ask_value_string(dmlObj,"t5_rlstype",&relType1));
			   printf("\t DML release type  : %s \n",relType1); fflush(stdout);
			   DMLPlant=subString(dmlNumber,11,4);
		       printf("\t DMLPlant  : %s \n",DMLPlant); fflush(stdout);
		       DMLDept=subString(dmlNumber,11,4);
		       printf("\t DMLDept : %s \n",DMLDept); fflush(stdout);
			   DFlg=5;
		}
		else
		{
			  CALLAPI(AOM_UIF_ask_value(dmlObj,"t5_rlstype",&relType));
			  printf("\t DML release type full name : %s \n",relType); fflush(stdout);		
			  CALLAPI(AOM_ask_value_string(dmlObj,"t5_rlstype",&relType1));
			  printf("\t DML release type  : %s \n",relType1); fflush(stdout);
		}
	}
	printf("\t DFlg found is  : %d \n",DFlg); fflush(stdout);
	char* Tempdmlvalue1 = NULL;
	Tempdmlvalue1=(char *)MEM_alloc(80);
    tc_strcpy(Tempdmlvalue1,"");
	tc_strcpy(Tempdmlvalue1,dmlNumber); 
	printf("\t DML number   : %s \n",Tempdmlvalue1); fflush(stdout);
	

	/******creating the File for writting ********/
	
	time(&now);
	now_tm = localtime(&now);
	strftime (ReleasedDateTime_str, 26, "%d%m%y%H%M%S", now_tm);
	printf("\n\n ReleasedDateTime_str is===>[%s]",ReleasedDateTime_str);fflush(stdout);	
	
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,dmlNumber);
	tc_strcat(Filename,"_ERCPrintRep_");
	tc_strcat(Filename,ReleasedDateTime_str);
	tc_strcat(Filename,".txt");
	printf("\n Filename: %s", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/tmp/");
	tc_strcat(FileLoc,Filename);
	printf("\n FileLoc: %s\n", FileLoc);fflush(stdout);
	
	DmlRelFile = fopen(FileLoc, "w");
	
	fprintf(DmlRelFile,"==============================================================================================================================================================================================================================================================================");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n%135s","D M L    H E A D E R");fflush(stdout);
	fprintf(DmlRelFile,"\n%135s","--------------------");fflush(stdout);
	
	/**********Print the DML description in File */
	
	CALLAPI(tmPrintDMLInFile(dmlNumber,dmlObj,DmlRelFile,buffStr,cnt)); //Function for DML Related attribute
	
	fprintf(DmlRelFile,"\n==============================================================================================================================================================================================================================================================================");fflush(DmlRelFile);
	
	
	fprintf(DmlRelFile,"\n%135s","AFFECTED  DESIGN  GROUPS");fflush(stdout);
	fprintf(DmlRelFile,"\n%135s","------------------------");fflush(stdout);
	
	
	//Get the task revision
	tag_t relatnType_tag  = NULLTAG;
	tag_t *Erctask_obj_tag   = NULLTAG;
	tag_t *MBOMTsk_obj_tag   = NULLTAG;
	tag_t *MBTsk_obj_tag   = NULLTAG;
	tag_t *APLtask_obj_tag   = NULLTAG;
	tag_t *STDtask_obj_tag   = NULLTAG;
	tag_t* task_obj_set   = NULLTAG;
	tag_t *task_primary_obj_tag   = NULLTAG;
	tag_t *apltsk_obj_tag   = NULLTAG;
	tag_t *mbomtask_obj_tag   = NULLTAG;
	tag_t task_rev_tag    = NULLTAG;
	tag_t aplDML_rev_tag    = NULLTAG;
	tag_t MbomDML_rev_tag    = NULLTAG;
	tag_t apltask_rev_tag    = NULLTAG;
	tag_t Mbomtask_rev_tag    = NULLTAG;
	tag_t *task_obj_tag = NULLTAG;
	char* TaskType = NULL;
	char* DMLobjType = NULL;
	char* TaskID = NULL;
	char* TaskIDDUP = NULL;
	char* TaskItemID = NULL;
	char* TaskObjectType = NULL;
	char* TaskTypeobj = NULL;
	char* ercdmlType = NULL;
	char* ercTaskType = NULL;
	char* ercTaskID = NULL;
	char* ercTaskdsn = NULL;
	char* APLTaskType = NULL;
	char* MBOMTaskType = NULL;
	char* APLdmlnum = NULL;
	char* TempDml = NULL;
	char* Tempvalue1 = NULL;
	char* MBOMdmlnum = NULL;
	char* REVstr = NULL;
	char* REVstrtmp = NULL;
	char* REVstrFinal = NULL;
	char* REVstrFinaltmp = NULL;
	int Task_count = 0;
	int STDtask_num =0;
	int APLtask_num =0;
	int MBtask_num =0;
	int MBOMtask_num =0;
	int erctask_num =0;
	int  n_tasksFnd           = 0;
	int  n_erctasksFnd           = 0;
	int  n_MBOMtasksFnd           = 0;
	int  n_APLtasksFnd           = 0;
	int  n_tasksFound           = 0;
	int  n_STDtasksFnd           = 0;
	int  n_mbomtasksFound           = 0;
	int MatchFLG=0;
	int i = 0;
	int t = 0,g=0,get=0;
	int dsn = 0;
	int Q3 = 0,Q5=0,Q6=0,Q7 = 0,Q8=0;
	affectedGrp=0;

	CALLAPI(AOM_ask_value_string(dmlObj,"object_type",&DMLobjType));
	printf("\n tm_generateDMLReport DML DMLobjType : %s \n",DMLobjType); fflush(stdout);
	tag_t  TaskRevQTag = NULLTAG;
	tag_t  *TaskSetTag = NULLTAG;
	tag_t  TaskObtTag = NULLTAG;
	char    *qry_TaskRev[1]  	= 	{"Item ID"};
    char	 **qry_ValueTaskRev	= 	(char **) MEM_alloc(5 * sizeof(char *));
    char 	 *keys[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
    int     num_to_sort =	1;
    int  	 orders[]  	=	{1};
    int     n_entries = 1;
    int     cnt_Task_found   =   0;
	if(QRY_find("Item Revision...", &TaskRevQTag));
	if(TaskRevQTag!=NULLTAG)
	{
		printf("\t The DML :%s\n",dmlNumber);fflush(stdout);
		if(tc_strcmp(DMLobjType,"ChangeRequestRevision")==0)
		{
           Tempvalue1=(char *)MEM_alloc(80);
           tc_strcpy(Tempvalue1,"");
           tc_strcpy(Tempvalue1,dmlNumber);                     
           Tempvalue1 = tc_strcat(Tempvalue1,"*");
	       qry_ValueTaskRev[0]=Tempvalue1;
		}
		else
		{
         TempDml=(char *)MEM_alloc(80);
         Tempvalue1=(char *)MEM_alloc(80);
         tc_strcpy(TempDml,"");
         tc_strcpy(TempDml,dmlNumber);                     
         Tempvalue1 = tc_strtok(TempDml,"_");
         Tempvalue1 = tc_strcat(Tempvalue1,"*");
	     qry_ValueTaskRev[0]=Tempvalue1;
		}
		printf("\t tm_generateDMLReport The Item num for query is : %s\n",Tempvalue1);fflush(stdout);
	     if(QRY_execute_with_sort(TaskRevQTag, n_entries, qry_TaskRev, qry_ValueTaskRev,num_to_sort, keys, orders, &cnt_Task_found, &TaskSetTag));
	     printf("\n\t tm_generateDMLReport No. of Task Item Revision found : %d",cnt_Task_found);fflush(stdout);
		 for(t=0;t<cnt_Task_found;t++)
		 {
			 TaskObtTag=NULLTAG;
			 TaskObtTag=TaskSetTag[t];
			 CALLAPI(AOM_ask_value_string(TaskObtTag,"object_type",&TaskObjectType));
	         printf("\n\t task TaskObjectType : %s \n",TaskObjectType); fflush(stdout);
             CALLAPI(AOM_ask_value_string(TaskObtTag,"item_id",&TaskID));
	         printf("\t DML TaskID : %s \n",TaskID); fflush(stdout);
			 if(tc_strcmp(TaskObjectType,"T5_ChangeTaskRevision")==0)
			 {
				 //Erctask_obj_tag[erctask_num]=TaskSetTag[t];
				 //task_obj_set[Task_count]=TaskSetTag[t];
				 setAddTAG(&Task_count,&task_obj_set,TaskObtTag);
				 erctask_num++;
				 printf("\t ERC Task Item Revision found : %d\n",erctask_num);fflush(stdout);
			 }
			 else if((tc_strcmp(TaskObjectType,"T5_MBOMTASKRevision")==0)&&(tc_strstr(TaskID,"MB_")==NULL))
			 {
				 //MBOMTsk_obj_tag[MBOMtask_num]=TaskSetTag[t];
				 setAddTAG(&Task_count,&task_obj_set,TaskObtTag);
				 MBOMtask_num++;
				 printf("\t MBOM Task Item Revision found : %d\n",MBOMtask_num);fflush(stdout);
			 }
			 else if((tc_strcmp(TaskObjectType,"T5_MBOMTASKRevision")==0)&&(tc_strstr(TaskID,"MB_")!=NULL))
			 {
				// MBTsk_obj_tag[MBtask_num]=TaskSetTag[t];
				 setAddTAG(&Task_count,&task_obj_set,TaskObtTag);
				 MBtask_num++;
				 printf("\t MBOM MB Task Item Revision found : %d\n",MBtask_num);fflush(stdout);
			 }
			 else if(tc_strcmp(TaskObjectType,"T5_APLTaskRevision")==0)
			 {
				 //APLtask_obj_tag[APLtask_num]=TaskSetTag[t];
				 setAddTAG(&Task_count,&task_obj_set,TaskObtTag);
				 APLtask_num++;
				 printf("\t APL Task Item Revision found : %d\n",APLtask_num);fflush(stdout);
			 }
			 else if(tc_strcmp(TaskObjectType,"T5_SMDMLTaskRevision")==0)
			 {
				 //STDtask_obj_tag[STDtask_num]=TaskSetTag[t];
				 setAddTAG(&Task_count,&task_obj_set,TaskObtTag);
				 STDtask_num++;
				 printf("\t STDS1 Task Item Revision found : %d\n",STDtask_num);fflush(stdout);
			 }
			 else
			 {
				 printf("\t As task ObjectType  : %s so continue\n",TaskObjectType); fflush(stdout);
				 continue;
			 }
		 }
	  printf("\nTask Item Revision found ..! \n\t ERC Task : %d\t MBOM Task : %d\t MBOM MB Task : %d\t APL Task : %d\t STDS1 Task : %d \n",erctask_num,MBOMtask_num,MBtask_num,APLtask_num,STDtask_num);fflush(stdout);
	  printf("Task Item Revision found ..! \n\t Total Task_count : %d\n",Task_count);fflush(stdout);
	}
	
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
	if(relatnType_tag!=NULLTAG)
	{
		if((ifail = GRM_list_secondary_objects_only(dmlObj, relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
		{
			return ifail;
		}
		printf("\n\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);
		
		//t5_crdesigngroup
		//affectedGrp =0;
		resPartsCnt = 0;
		for (i=0;i<n_tasksFnd ;i++ )
		{
			task_rev_tag = NULLTAG;
			task_rev_tag=task_obj_tag[i];
			
			if(task_rev_tag!=NULLTAG)
			{
					CALLAPI(AOM_ask_value_string(task_rev_tag,"object_type",&TaskType));
					printf("\n Task Type: %s \n",TaskType); fflush(stdout);

					if(tc_strcmp(TaskType,"T5_ChangeTaskRevision")==0)
					{
						printf("\n\t YOU ARE IN ERC TASK REVISION %s \n",TaskType); fflush(stdout);

						affectedGrp++;
						CALLAPI(tmPrintTaskRevisionInFile(task_rev_tag,DmlRelFile,buffStr,cnt)); //Function for DML Task Related attribute
						
						
						tag_t partRelatn_Type_tag = NULLTAG;
						tag_t* part_obj_tag = NULLTAG;
						int n_parts = 0;
						//Logic for DML Release type SPIUP
						if(tc_strcmp(relType1,"SPIUP")==0)
						{
							CALLAPI(GRM_find_relation_type("CMReferences",&partRelatn_Type_tag));
							if (partRelatn_Type_tag!=NULLTAG)
							{
								if((ifail = GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
								{
									return ifail;
								}
								printf("\n  No of TC Part master attached to the Task are : %d \n",n_parts); fflush(stdout);
								fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
								//fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n PARTS ADDED / MODIFIED");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n ----------------------");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n%-5s%-20s%-5s%-5s%-20s%-20s","Srl","Assy-Partno","Rev","Seq","Old Spare Indicator", "New Spare Indicator");fflush(stdout);
								resPartsCnt = resPartsCnt + n_parts;
								tag_t part_mstr_tag = NULLTAG;
								char* objectTpe = NULL;
								if(n_parts>0)
								{
									int j=0;
									int k =0;
									for(j=0;j<n_parts ;j++ )
									{
										part_mstr_tag = part_obj_tag[j];
										CALLAPI(AOM_ask_value_string(part_mstr_tag,"object_type",&objectTpe));
										if(objectTpe==NULL)objectTpe="";
										if(tc_strcmp(objectTpe,"Design")==0)
										{
											CALLAPI(tmPrintPartMasterInFile(part_mstr_tag,DmlRelFile,j,buffStr,cnt));
										}
										else if(tc_strcmp(objectTpe,"Design Revision")==0)
										{
											CALLAPI(tmPrintPartRevInFile(part_mstr_tag,DmlRelFile,j,buffStr,cnt));
										}
											
									}
								}
							}
							
						}
						else
						{
							// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
                                                if(tc_strcmp(relType1,"TODR")==0)
                                                {
                                                        CALLAPI(GRM_find_relation_type("CMReferences",&partRelatn_Type_tag));
                                                }
                                                else
                                                {
                                                        CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
                                                }
                                                        if (partRelatn_Type_tag!=NULLTAG)
                                                        {

                                                                if((ifail = GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
                                                                {
                                                                        return ifail;
                                                                }
                                                                printf("\n\t  No of TC Parts attached to the nonerc Task are : %d \n",n_parts); fflush(stdout);

                                                                fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
                                                                //fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
                                                                fprintf(DmlRelFile,"\n PARTS ADDED / MODIFIED");fflush(DmlRelFile);
                                                                fprintf(DmlRelFile,"\n ----------------------");fflush(DmlRelFile);

                                                                if(tc_strcmp(relType1,"TODR")==0)
                                                                {
                                                                 fprintf(DmlRelFile,"\n%-5s%-20s%-7s%-15s%-15s%-25s%-20s%-70s%-30s","SRL","Part Number","Rev","Seq","DR-Status","DML","OWNER Design Unit"," Desc","Release-status");fflush(stdout);

                                //loop for parts added/modified
                                tag_t part_rev_tag = NULLTAG;
                                resPartsCnt = resPartsCnt + n_parts;
                                  if(n_parts>0)
                                  {
                                        int j=0;
                                        int lgm=0;
                                        char* partrevtyp = NULL;
                                        for(j=0;j<n_parts ;j++ )
                                        {
                                                part_rev_tag = part_obj_tag[j];
                                                                                //lgm = j;
                                                //here add object type
                                                CALLAPI(AOM_ask_value_string(part_rev_tag,"object_type",&partrevtyp));
                                            printf("\n\t\t partrevtyp Type: %s \n",partrevtyp); fflush(stdout);
                                                 if(tc_strcmp("Folder",partrevtyp)==0)
                                                 {
                                             //FL_sort_criteria_t       sort_criteria ;
                                             int  FlderObjCount = 0;
                                             tag_t* FolderObj_tag = NULLTAG;

                                                                                         if(FL_ask_references(part_rev_tag,FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag));
                                                                                         printf("\n\t\t FlderObjCount----->: %d \n",FlderObjCount); fflush(stdout);
                                                                                         if(FlderObjCount>0)
                                                                                         {
                                                                                                 tag_t part_rev_tagGM = NULLTAG;
                                                 resPartsCnt = resPartsCnt + FlderObjCount;
                                                                                                 int gm=0;
                                                                                                 for(gm=0;gm<FlderObjCount;gm++ )
                                                      {
                                                            part_rev_tagGM = FolderObj_tag[gm];
                                                                                                        CALLAPI(tmPrintPartsInFileGM1(DMLPlant,DMLDept,part_rev_tagGM,DmlRelFile,lgm,buffStr,cnt));
                                                                                                        lgm++;

                                                                                                  }

                                                                                         } /**/
                                                                                         continue;


                                                 }

                                                CALLAPI(tmPrintPartsInFileGM1(DMLPlant,DMLDept,part_rev_tag,DmlRelFile,lgm,buffStr,cnt));
                                                                                lgm++;
                                        }

                                  }


                                                                fprintf(DmlRelFile,"\n\n DRAWINGS ADDED / MODIFIED");fflush(DmlRelFile);
                                                                fprintf(DmlRelFile,"\n -------------------------");fflush(DmlRelFile);
                                                                //loop for drwaing added/modified - check if catdrwaing is there
                                                                printf("\n calling tmDrwgsDetails : \n"); fflush(stdout);
                                                                CALLAPI(tmDrwgsDetails(n_parts,part_obj_tag,DmlRelFile,buffStr,cnt));fflush(stdout);

                                                                //Structure changes
                                                                printf("\n calling tmStructureChangesGM1 : \n"); fflush(stdout);
                                                                //CALLAPI(tmStructureChangesGM1(DMLPlant,DMLDept,n_parts,part_obj_tag,DmlRelFile,buffStr,cnt,&prtAddCnt,&prtDelCnt,&prtQtyChngCnt));   //NON_erc Structure changes funtn    //NON_erc Structure changes funtn
                                                                }
                                                                else
                                                                {
                                                                //Srl   Assy-Partno     Assy-Part-Description                      Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
                                                                fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s","Srl","Assy-Partno","Assy-Part-Description","Rev","Seq","IA","CS","SI","CI","Epa Task","ES","RSFAP-DI(previous revision)","Checked By","Modification Description");fflush(stdout);

                                                                //loop for parts added/modified
                                                                tag_t part_rev_tag = NULLTAG;
                                                                tag_t Aplpart_rev_tag = NULLTAG;
                                                                tag_t Mbompart_rev_tag = NULLTAG;
                                                                int Apl_prt_cnt=0;
                                                                int MBom_prt_cnt=0;
                                                                resPartsCnt = resPartsCnt + n_parts;
                                                                if(n_parts>0)
                                                                {
                                                                        int j=0;
                                                                        int k =0;
                                                                        for(j=0;j<n_parts ;j++ )
                                                                        {
                                                                                part_rev_tag = part_obj_tag[j];
                                                                                CALLAPI(tmPrintPartsInFile1(DMLPlant,DMLDept,part_rev_tag,DmlRelFile,j,buffStr,cnt));
                                                                        }

                                                                }

                                                                fprintf(DmlRelFile,"\n\n DRAWINGS ADDED / MODIFIED");fflush(DmlRelFile);
                                                                fprintf(DmlRelFile,"\n -------------------------");fflush(DmlRelFile);
                                                                //loop for drwaing added/modified - check if catdrwaing is there
                                                                printf("\n calling tmDrwgsDetails : \n"); fflush(stdout);
                                                                CALLAPI(tmDrwgsDetails(n_parts,part_obj_tag,DmlRelFile,buffStr,cnt));fflush(stdout);

                                                                //Structure changes
                                                                //fprintf(DmlRelFile,"\n\n STRUCTURE CHANGES");fflush(DmlRelFile);
                                                                printf("\n calling tmStructureChanges1 : \n"); fflush(stdout);
                                                                printf("\t DFlg found is  : %d \n",DFlg); fflush(stdout);
                                                                CALLAPI(tmStructureChanges1(DMLPlant,DMLDept,n_parts,part_obj_tag,DmlRelFile,buffStr,cnt,&prtAddCnt,&prtDelCnt,&prtQtyChngCnt));   //NON_erc Structure changes funtn    //NON_erc Structure changes funtn
                                                                }

                                                                printf("\n\n\n all calling completed now in info to update summary  : \n"); fflush(stdout);

                                                                fprintf(DmlRelFile,"\n===================================================================================================================================================================");fflush(stdout);
                                                                fprintf(DmlRelFile,"\n AFFECTED VCs");fflush(stdout);
                                                                fprintf(DmlRelFile,"\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
                                                                fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
                                                                fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
                                                                fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);


                                                        }

                                                        fprintf(DmlRelFile,"\n");fflush(stdout);
							
						}

						fprintf(DmlRelFile,"\n");fflush(stdout);
					}
					//Non_ERC DML PRINT

					if((tc_strcmp(TaskType,"T5_MBOMTASKRevision")==0) || (tc_strcmp(TaskType,"T5_APLTaskRevision")==0) || (tc_strcmp(TaskType,"T5_SMDMLTaskRevision")==0))
				    {
						printf("\n  YOU ARE IN NON_ERC TASK REVISION %s \n",TaskType); fflush(stdout);
						affectedGrp++;	
						TaskID=NULL;
					    printf("\t affectedGrp  : %d \n",affectedGrp); fflush(stdout);
						//CALLAPI(tmPrintTaskRevisionInFile1(task_rev_tag,DmlRelFile,buffStr,cnt,DFlg)); //Function for DML Task Related attribute
						CALLAPI(AOM_ask_value_string(task_rev_tag,"item_id",&TaskID));
	                    printf("\t DML TaskID : %s \n",TaskID); fflush(stdout);
						CALLAPI(AOM_ask_value_string(task_rev_tag,"object_type",&TaskObjectType));
	                    printf("\t DML TaskObjectType : %s \n",TaskObjectType); fflush(stdout);   //object type for erc task
						if(tc_strcmp(TaskObjectType,"T5_ChangeTaskRevision")==0)
						{
							REVstr=(char *)MEM_alloc(80);
							tc_strcpy(REVstr,"");
							tc_strcpy(REVstr,TaskID);
							printf("\t REVSTR ERC DML TaskID : %s \n",REVstr); fflush(stdout);
						}
						else if((tc_strcmp(TaskID,"")!=0) || (tc_strcmp(TaskID,NULL)!=0))
						{
						  REVstr=(char *)MEM_alloc(80);
						  printf("\t inside DML TaskID : %s \n",TaskID); fflush(stdout);
						  ReverseStr(TaskID);
						  printf("\t inside rev DML TaskID : %s \n",TaskID); fflush(stdout);
						  //REVstrtmp=tc_strtok(TaskID,"_");
						  //printf("\n REVstrtmp DML TaskID : %s \n",REVstrtmp); fflush(stdout);
						  Q5=tc_strlen(TaskID);
						  printf("\t Q5 length DML TaskID : %d \n",Q5); fflush(stdout);
						  REVstr=subString(TaskID,5,Q5);
						  ReverseStr(REVstr);
					      printf("\n\t REVSTR NON_ERC DML TaskID : %s \n",REVstr); fflush(stdout);
						}
						else
						{
							printf("\n REVSTR DML TaskID : %s \n",REVstr); fflush(stdout);
						}
						for(get=0;get<Task_count;get++)
						{
							CALLAPI(AOM_ask_value_string(task_obj_set[get],"item_id",&TaskIDDUP));
	                        printf("\n\t DML TaskIDDUP : %s \n",TaskIDDUP); fflush(stdout);
							CALLAPI(AOM_ask_value_string(task_obj_set[get],"object_type",&TaskTypeobj));
	                        printf("\t DML Taskobject Type: %s \n",TaskTypeobj); fflush(stdout);
							if(tc_strcmp(TaskTypeobj,"T5_ChangeTaskRevision")==0)
						    {
							  REVstrFinal=(char *)MEM_alloc(80);
							  tc_strcpy(REVstrFinal,"");
							  tc_strcpy(REVstrFinal,TaskIDDUP);
							  printf("\t REVstrFinal ERC DML TaskID : %s \n",REVstrFinal); fflush(stdout);
						    }
							else if((tc_strcmp(TaskIDDUP,"")!=0) || (tc_strcmp(TaskIDDUP,NULL)!=0))
							{
							  REVstrFinal=(char *)MEM_alloc(80);
							  ReverseStr(TaskIDDUP);
						      //REVstrFinaltmp=tc_strtok(TaskIDDUP,"_");
							  Q7=tc_strlen(TaskIDDUP);
						      printf("\t Q7 DML TaskID : %d \n",Q7); fflush(stdout);
							  REVstrFinal=subString(TaskIDDUP,5,Q7);
						      ReverseStr(REVstrFinal);
							  printf("\t REVstrFinal DML TaskID : %s \n",REVstrFinal); fflush(stdout);
							}
							else
							{
								printf("\t REVstrFinal DML TaskID : %s \n",REVstrFinal); fflush(stdout);
							}
							if(tc_strcmp(REVstrFinal,REVstr)==0)
							{
							  printf("\t REVstrFinal TaskID is : %s  and REVstr  is : %s \n",REVstrFinal,REVstr); fflush(stdout);
							  printf("\n\t Calling tmPrintTaskRevisionInFile1 .......  \n"); fflush(stdout);
							  CALLAPI(tmPrintTaskRevisionInFile1(task_obj_set[get],DmlRelFile,buffStr,cnt,DFlg)); //Function for DML Task Related attribute
							}
							else
							{
							  printf("\t REVstrFinal TaskID is : %s  and REVstr  is : %s \n",REVstrFinal,REVstr); fflush(stdout);
							}
						}
												
						tag_t partRelatn_Type_tag = NULLTAG;
						tag_t* part_obj_tag = NULLTAG;
						int n_parts = 0;

						// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
							CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
							if (partRelatn_Type_tag!=NULLTAG)
							{
								
								if((ifail = GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
								{
									return ifail;
								}
								printf("\n\t  No of TC Parts attached to the nonerc Task are : %d \n",n_parts); fflush(stdout);
								
								fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
								//fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n PARTS ADDED / MODIFIED");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n ----------------------");fflush(DmlRelFile);
								//Srl   Assy-Partno     Assy-Part-Description                      Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
								fprintf(DmlRelFile,"\n%-5s%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s","Srl","Assy-Partno","Assy-Part-Description","Rev","Seq","IA","CS","SI","CI","Epa Task","ES","RSFAP-DI(previous revision)","Checked By","Modification Description");fflush(stdout);
								
								//loop for parts added/modified
								tag_t part_rev_tag = NULLTAG;
								tag_t Aplpart_rev_tag = NULLTAG;
								tag_t Mbompart_rev_tag = NULLTAG;
								int Apl_prt_cnt=0;
								int MBom_prt_cnt=0;
								resPartsCnt = resPartsCnt + n_parts;
								if(n_parts>0)
								{
									int j=0;
									int k =0;
									for(j=0;j<n_parts ;j++ )
									{
										part_rev_tag = part_obj_tag[j];
										CALLAPI(tmPrintPartsInFile1(DMLPlant,DMLDept,part_rev_tag,DmlRelFile,j,buffStr,cnt));
									}
								
								}	
								
								fprintf(DmlRelFile,"\n\n DRAWINGS ADDED / MODIFIED");fflush(DmlRelFile);
								fprintf(DmlRelFile,"\n -------------------------");fflush(DmlRelFile);
								//loop for drwaing added/modified - check if catdrwaing is there
								printf("\n calling tmDrwgsDetails : \n"); fflush(stdout);
								CALLAPI(tmDrwgsDetails(n_parts,part_obj_tag,DmlRelFile,buffStr,cnt));fflush(stdout);
								
								//Structure changes
								//fprintf(DmlRelFile,"\n\n STRUCTURE CHANGES");fflush(DmlRelFile);
								printf("\n calling tmStructureChanges1 : \n"); fflush(stdout);
								CALLAPI(tmStructureChanges1(DMLPlant,DMLDept,n_parts,part_obj_tag,DmlRelFile,buffStr,cnt,&prtAddCnt,&prtDelCnt,&prtQtyChngCnt));   //NON_erc Structure changes funtn 
								//printf("\n\n calling tmSupressedParts : \n"); fflush(stdout);
								//CALLAPI(tmSupressedParts(DMLPlant,DMLDept,n_parts,part_obj_tag,DmlRelFile,buffStr,cnt,&APLSupressedcnt,&MBOMSupressedcnt));   //NON_ERC Supressed parts funtn 
								printf("\n\n\n all calling completed now in info to update summary  : \n"); fflush(stdout);

								fprintf(DmlRelFile,"\n===================================================================================================================================================================");fflush(stdout);
								fprintf(DmlRelFile,"\n AFFECTED VCs");fflush(stdout);
								fprintf(DmlRelFile,"\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
								fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
								fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
								fprintf(DmlRelFile,"\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
								
								
							}

							fprintf(DmlRelFile,"\n");fflush(stdout);

					}

					
			}
				
			
		}
		
	}
	

		printf("\nNo of affected groups==>%d",affectedGrp);fflush(stdout);
	    printf("\nNo of Resultant Parts==>%d",resPartsCnt);fflush(stdout);
	    printf("\nNo of Parts Added in Assy==>%d",prtAddCnt);fflush(stdout);
	    printf("\nNo of Parts Deleted from Assy==>%d",prtDelCnt);fflush(stdout);
	    printf("\nNo of Parts Qty Changes from assy==>%d\n",prtQtyChngCnt);fflush(stdout);

		fprintf(DmlRelFile,"\n                                                                                                                R E C O R D    S U M M A R Y    F O R    D M L");fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                ----------------------------------------------");fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                   No of affected groups               = %d",affectedGrp);fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                   No of Resultant Parts               = %d",resPartsCnt);fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                   No of Parts Added in Assy           = %d",prtAddCnt);fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                   No of Parts Deleted from Assy       = %d",prtDelCnt);fflush(stdout);
		fprintf(DmlRelFile,"\n                                                                                                                   No of Parts Qty Changes from assy   = %d",prtQtyChngCnt);fflush(stdout);
	
	
	
	
	fprintf(DmlRelFile,"\n==============================================================================================================================================================================================================================================================================");fflush(DmlRelFile);
	fprintf(DmlRelFile,"\n%135s","E N D    O F     R E P O R T");fflush(stdout);
	fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	fprintf(DmlRelFile,"\nCS  :Condition Of Supply 		QRI  :Qty Reqt Info 		SI  :Spare Indicator 		RSFAP(DI) :Disposal Instruction");fflush(stdout);
	fprintf(DmlRelFile,"\nIA  :Initial Agency 			ES  :Epa Status 		IC  :Interchangeable            CI :Colour Indicator");fflush(stdout);
	fprintf(DmlRelFile,"\nDisposal Instruction :-");fflush(stdout);
	fprintf(DmlRelFile,"\nA   :Use Up  			        N    :Rectify                   V   :Scrap       W   :Continue As Spares               -  : NA");fflush(stdout);
	fprintf(DmlRelFile,"\nR   :RAW                                S    : SHOP                     F   : FINISHED                  A   : ASSEMBLED                          P : SPARE PARTS");fflush(stdout);
	fprintf(DmlRelFile,"\nInterchangeable :-");fflush(stdout);
	fprintf(DmlRelFile,"\nNA  :Not Applicable  	   X  :Two Way Interchangeability            Y  :One Way Interchangeability              N  :Non Interchange Replacement");fflush(stdout);
	fprintf(DmlRelFile,"\nA  :New Part added        D :Extra Part Deleted");fflush(stdout);
	fprintf(DmlRelFile,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
	
	if(DmlRelFile!=NULL) fclose(DmlRelFile);
	
	
	/**Creating dataset for storing the Text File **************************************************/
	
	char *dataSetName 		= NULL;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	IMF_file_t	fileDescriptor;
	//char * relation_type_name = NULL;
	tag_t  	relation_type = NULLTAG;
	tag_t  	relation    = NULLTAG;

	dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,Tempdmlvalue1);
	tc_strcat(dataSetName,"_ERCdmlreport_");
	tc_strcat(dataSetName,ReleasedDateTime_str);

	CALLAPI(AE_find_datasettype("Text", &datasettype))
	CALLAPI(AE_find_tool2("Notepad", &tool))
	CALLAPI(AE_create_dataset_with_id(datasettype,dataSetName,"", NULL, NULL, &Newdataset))
	CALLAPI(AE_set_dataset_tool(Newdataset,tool))
	CALLAPI(AE_set_dataset_format(Newdataset, "TEXT_REF"))
	CALLAPI(AOM_save(Newdataset))	
	CALLAPI(IMF_fmsfile_import(FileLoc, Filename,SS_TEXT, &filetag, &fileDescriptor))
	if(filetag == NULLTAG)
	{
		printf("file tag not found.....");fflush(stdout);
	}
	CALLAPI(AOM_refresh(Newdataset, TRUE));
	CALLAPI(AE_add_dataset_named_ref2(Newdataset, "Text", AE_PART_OF, filetag))
	CALLAPI(AOM_save(Newdataset))
	//Attaching the dataset to Reference folder

	//relation_type_name = (char*)MEM_alloc(70*sizeof(char));
	//sprintf ( relation_type_name, "%s","CMReferences" );

	//CALLAPI(GRM_find_relation_type(relation_type_name,&relation_type))
	if(GRM_find_relation_type("IMAN_reference", &relation_type)!=ITK_ok)PrintErrorStack();
	if(relation_type != NULLTAG)
	{
		CALLAPI(GRM_create_relation(dmlObj,Newdataset,relation_type, NULLTAG, &relation))
		if(relation != NULLTAG)
		{
			printf("\nThe dataset is attached to the Reference folder of DML");fflush(stdout);
		}
		else
		{
			printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
		}
		CALLAPI(GRM_save_relation(relation))
	}


	printf("\nCompleted....");fflush(stdout);
	
	
	
	/****************************************************************************************************************/	
	
	
	//Free memory 
	if(dataSetName!=NULL) MEM_free(dataSetName);
	//if(relation_type_name!=NULL) MEM_free(relation_type_name);
	
	if(Filename!=NULL) MEM_free(Filename);
	if(FileLoc!=NULL) MEM_free(FileLoc);
	
	
	return ifail;
}

int tmPrintPartsInFileGM1(char *DMLPlant,char *DMLDept,tag_t part_rev_tag,FILE * DmlRelFile,int prtcnt,char*** buffStr, int *cnt)
{
        int ifail = ITK_ok;
        char* partNum = NULL;
        char* partDesc = NULL;
        char* rev = NULL;
        char* revStr = NULL;
        char* seq = NULL;
        char* seqStr = NULL;
        char* iaStr = NULL;
        char* csStr = NULL;
        char* ciStr = NULL;
        char* siStr = NULL;
        char* epaTasktmp = NULL;
        char* epaTask = NULL;
        char* esStrtmp = NULL;
        char* esStr = NULL;
        char* rsfapStr = NULL;
        char* checkedBy = NULL;
        char* modDesc = NULL;
        char* revtmp = NULL;
        char* partstatus = NULL;
        char* partunit = NULL;
        char* partrlstatus = NULL;
        char* partchngdmltyp = NULL;
        char* partchngdml = NULL;
        char* partdmltyp = NULL;

      tag_t     Cntl_obj_Qtag1  =       NULLTAG;
      tag_t     dml_task_rel    =       NULLTAG;
          tag_t *qry_cntrlobjval        =       NULLTAG;
          tag_t *primary_obj    =       NULLTAG;

    printf("\n inside tmPrintPartsInFileGM1.... ");fflush(stdout);
        int n_entries1 =        3;
        int l = 0,u=0 ;
        //Rev,Seq   IA    CS        SI     CI      Epa Task                   ES      RSFAP-DI(previous revision)   Checked By     Modification Description
        prtcnt++;
        //Assy-Partno
        CALLAPI(AOM_ask_value_string(part_rev_tag,"item_id",&partNum));
        printf("\ntmPrintPartsInFile1:partNum: %s",partNum); fflush(stdout);

        //Assy-Part-Description
        CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&partDesc));
        printf("\ntmPrintPartsInFile1:partDesc: %s",partDesc); fflush(stdout);
        CALLAPI (AOM_ask_value_string(part_rev_tag,"t5_PartStatus",&partstatus));
        printf("\ntmPrintPartsInFile1:partstatus: %s",partstatus); fflush(stdout);
        CALLAPI (AOM_ask_value_string(part_rev_tag,"t5_DsgnOwn",&partunit));
        printf("\ntmPrintPartsInFile1:partunit: %s",partunit); fflush(stdout);
        CALLAPI (AOM_UIF_ask_value(part_rev_tag,"release_status_list",&partrlstatus));
        printf("\ntmPrintPartsInFile1:partrlstatus: %s",partrlstatus); fflush(stdout);
        if (partDesc==NULL)
        {
                tc_strdup("NA",&partDesc);
        }


        CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&rev));
        CALLAPI (AOM_UIF_ask_value(part_rev_tag,"item_revision_id",&revtmp));
        printf("\ntmPrintPartsInFile1:rev:%s\n",rev); fflush(stdout);

        if(tc_strstr(rev,";") != NULL)
        {
                revStr = tc_strtok ( rev,";") ;
                //seqStr = tc_strtok ( NULL,";") ;
        }


        int n_parents=0;
        int* levels=0;
        int n_referencers = 0;
        char** relationWS = NULL;
        tag_t*  part_parents = NULLTAG;
        CALLAPI (AOM_UIF_ask_value(part_rev_tag,"sequence_id",&seq));

        CALLAPI (WSOM_where_referenced  (part_rev_tag,2,&n_parents,&levels,&part_parents,&relationWS));
        printf("\ntmPrintPartsInFile1:n_parents:%d\n",n_parents); fflush(stdout);

        tag_t parentItm = NULLTAG;
        int jk=0;
        for(jk=0;jk<n_parents;jk++)
        {
                parentItm = NULLTAG;
        parentItm =part_parents[jk];
                CALLAPI(AOM_ask_value_string(parentItm,"object_type",&partchngdmltyp));
                printf("\n\t\t partchngdmltyp Type----: %s \n",partchngdmltyp); fflush(stdout);
                if((tc_strcmp("ChangeRequestRevision",partchngdmltyp)==0)||(tc_strcmp("ERC DML Revision",partchngdmltyp)==0))
                {
                        CALLAPI(AOM_ask_value_string(parentItm,"t5_rlstype",&partdmltyp));
                    printf("\n\t\t partdmltyp Type----: %s \n",partdmltyp); fflush(stdout);
                        if(tc_strcmp(partdmltyp,"TODR")!=0)
                        {
                                CALLAPI(AOM_ask_value_string(parentItm,"item_id",&partchngdml));
                        printf("\n\t\t partchngdml ERC ----: %s \n",partchngdml); fflush(stdout);
                                break;
                        }

                }
        }

        //,"\n%-5s%-20s%-70s%-5s%-5s%-15s%-20s%-15s%-15s%-18s%-15s%-18s%-25s%-50s",
        fprintf(DmlRelFile,"\n%-5d%-20s%-7s%-15s%-15s%-25s%-20s%-75s%-30s",prtcnt,partNum,revStr,seq,partstatus,partchngdml,partunit,partDesc,partrlstatus);fflush(stdout);
        printf("\n At end tmPrintPartsInFileGM1.... ");fflush(stdout);

        return ifail;
}
//sanjoy-dml print report action handler
//Write the logic for dml print report handler
int  tm_ercdml_printreportfn(char* DMLNumber)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULLTAG;
	int targetobjects_count = 0;
	char* dmlNo = NULL;	
	
	 printf("\n DML Number == %s\n", DMLNumber);fflush(stdout);
	char **qry_valuesDML=(char **) MEM_alloc(50 * sizeof(char *));
	char *qry_entriesDML[1] = {"ID"};
	qry_valuesDML[0] = DMLNumber;//{"13PP266105"};
	int	n_entriesDML= 1;
	tag_t TagDMLControl		= NULLTAG;
	int	n_foundDML = 0;
	tag_t   *DMLRevision	= NULLTAG;
	if(QRY_find2("ERC DML", &TagDMLControl));
		     
		     if(QRY_execute(TagDMLControl,n_entriesDML, qry_entriesDML, qry_valuesDML, &n_foundDML, &DMLRevision));
		     printf("\n DML Revision Count == %d\n", n_foundDML);fflush(stdout);
			 
	if(n_foundDML > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  type_name[TCTYPE_name_size_c+1];
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<n_foundDML;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (DMLRevision[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name( objectTypeTag, type_name));
			printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(DMLRevision[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(DMLRevision[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nDML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				dmlTag=DMLRevision[i];
				break;

			}
		}
		if(dmlTag==NULLTAG)
		{
			printf("\nTarget Object is not ERC DML Revision ");fflush(stdout);
			return ifail;
		}	
		//Call the Report logic function
		char **buffStr = NULL;
		int cnt =0;
		CALLAPI(tm_generateDMLReport(dmlTag, &buffStr,&cnt));
		
	}
	
	return ifail;
}



//Sanjoy - ERC DML Print report user service - start
int tm_ERCDmlPrintReportServ(void *retValue)
{
	
	char*   DMLNumber = NULL;
	tag_t dml_object = NULLTAG;
	int ifail = ITK_ok;

	char **bufferedXmlStrOut = NULL;
	int buff_cnt =0;
	int m =0;
	
	USERSERVICE_array_t 	array_structure;
	int 					array_size 		= 0; 
	char 					**string_array 	= NULL;	

	USERARG_get_tag_argument(&dml_object);
	CALLAPI(AOM_ask_value_string(dml_object,"item_id",&DMLNumber));
	printf("\nitem_id of selected object:%s\n",DMLNumber);fflush(stdout);

	if (dml_object != NULLTAG)
	{
		printf("\n Inside to call function tm_ERCDmlPrintReportServ");	  
		CALLAPI(tm_generateDMLReport(dml_object, &bufferedXmlStrOut,&buff_cnt));

	}
		
		
	
	for(m=0;m<buff_cnt;m++)
	{
		printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
	}		

	printf ("\n After bufferedXmlStrOut");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)bufferedXmlStrOut, buff_cnt, &array_structure);

	if (array_structure.length != 0)
	{
		printf ("\n array_structure");fflush(stdout);
		*((USERSERVICE_array_t*) retValue) = array_structure;			
	}

	printf ("\n ERC DML Rev Print report completed..return ");fflush(stdout);
	return ifail;
}

//Sanjoy - ERC DML Print report user service - end


//All user services
/*extern int AllAplReportUserServiceFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 2;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	input_arg_type[0]=USERARG_STRING_TYPE;
	input_arg_type[1]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	ret_value_type = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
 	
	
	printf("\n AllAplReportUserServiceFn: Before registering APLStructuringReport userservice...");  
	ifail=USERSERVICE_register_method("APLStructuringReport",(USER_function_t)APLStructuringReport,n_args,input_arg_type,ret_value_type);
	printf("\n AllAplReportUserServiceFn: After registering APLStructuringReport userservice....");  
	
	//Manoj - APL Summary Report
	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
		
	// Refer ict_userservice.h for more arg types
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ;
	printf("\n AllUserServiceFnSummaryRpt before....APLSummaryRpt");fflush(stdout);
	ifail=USERSERVICE_register_method("APLSummaryReport",(USER_function_t)APLSummaryReport,nargs,inputArgTypes,retValueType);
	//End Manoj
	
	//Poonam - Planner wise DML Report
	int nargs1 = 4;
	int retValueType1;
	int inputArgTypes1[4] = {0,0,0,0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE;
	inputArgTypes1[2] = USERARG_STRING_TYPE;
	inputArgTypes1[3] = USERARG_STRING_TYPE;
	retValueType1 = USERARG_STRING_TYPE ; 
	printf("\n AllAplReportUserServiceFn before....PlannerWiseDMLReport");fflush(stdout);  
	ifail=USERSERVICE_register_method("PlannerWiseDMLReport",(USER_function_t)PlannerWiseDMLReport,nargs1,inputArgTypes1,retValueType1);
	//End Poonam
	
	//Poonam - APL Status Report
	int nargsAplStsRpt = 5;
	int retValueAplStsRpt;
	int inputArgAplStsRpt[5] = {0,0,0,0,0};
	//int *inputArgAplStsRpt;
	//inputArgAplStsRpt=(int *)MEM_alloc(n_args * sizeof(int));
	
	inputArgAplStsRpt[0] = USERARG_STRING_TYPE;
	inputArgAplStsRpt[1] = USERARG_STRING_TYPE;
	inputArgAplStsRpt[2] = USERARG_STRING_TYPE;
	inputArgAplStsRpt[3] = USERARG_STRING_TYPE;
	inputArgAplStsRpt[4] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	retValueAplStsRpt = USERARG_STRING_TYPE;
	printf("\n AllAplReportUserServiceFn before....APLStatusReport");fflush(stdout);  
	ifail=USERSERVICE_register_method("APLStatusReport",(USER_function_t)APLStatusReport,nargsAplStsRpt,inputArgAplStsRpt,retValueAplStsRpt);
	//End Poonam
	
	//Varun - APL DML Release Between Dates Report
	int nargs2 = 5;
	int retValueType2;
	int inputArgTypes2[2];
	printf("\n before calling *decision(AplDmlReleaseBetweenDates)");fflush(stdout);
	*decision=ALL_CUSTOMIZATIONS;
	printf(" \n After  calling *decision(AplDmlReleaseBetweenDates)");fflush(stdout);

	// Refer ict_userservice.h for more arg types
	inputArgTypes2[0] = USERARG_STRING_TYPE;

	inputArgTypes2[1] = USERARG_STRING_TYPE;
	inputArgTypes2[2] = USERARG_STRING_TYPE;
	inputArgTypes2[3] = USERARG_STRING_TYPE;
	
	inputArgTypes2[4] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;

	retValueType2 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	
    ifail=USERSERVICE_register_method("AplDmlReleaseBetweenDates",(USER_function_t)AplDmlReleaseBetweenDates,nargs2,inputArgTypes2,retValueType2);

	
	printf("Exited from AplDmlBetweenDatesUserServiceFn......\n");
	//End varun
	
	//DML Print report- sneha
	int nargs3 = 1;
	int retValueType3;
	int *inputArgTypes3 = (int *) MEM_alloc ( nargs3 * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes3[0] = USERARG_TAG_TYPE;
	retValueType3 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	printf("\n DMLPrintReportServiceFnc before....DMLPrintReportServiceCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("DMLPrintReportServiceCall",(USER_function_t)DMLPrintReportServiceCall,nargs3,inputArgTypes3,retValueType3);
	
	//Sanjoy - common report
	int nargs4 = 8;
	int retValueType4;
	int *inputArgTypes4;
	inputArgTypes4=(int *)MEM_alloc(nargs4 * sizeof(int));
	
	inputArgTypes4[0] = USERARG_STRING_TYPE; // String Release status
	inputArgTypes4[1] = USERARG_STRING_TYPE; // From Date
	inputArgTypes4[2] = USERARG_STRING_TYPE; // To Date
	inputArgTypes4[3] = USERARG_STRING_TYPE; // Plant Name	
	inputArgTypes4[4] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // selected Project 
	inputArgTypes4[5] = USERARG_STRING_TYPE; // Planner Name	
	inputArgTypes4[6] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // selected additional columns
	inputArgTypes4[7] = USERARG_STRING_TYPE; // Included Summary reports (True/False)	

	retValueType4 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	
	
	printf("\n Start--CommonAPLDMLBetweenReports service call...");fflush(stdout);  
	ifail=USERSERVICE_register_method("CommonAPLDMLBetweenReports",(USER_function_t)CommonAPLDMLBetweenReports,nargs4,inputArgTypes4,retValueType4);
	
	printf("\n End--CommonAPLDMLBetweenReports service call...");fflush(stdout);	
	
	//End Sanjoy
	//Start-Sanjoy improve performance common report

	int nargs5 = 8;
	int retValueType5;
	int *inputArgTypes5;
	inputArgTypes5=(int *)MEM_alloc(nargs5 * sizeof(int));
	
	inputArgTypes5[0] = USERARG_STRING_TYPE; // String Release status
	inputArgTypes5[1] = USERARG_STRING_TYPE; // From Date
	inputArgTypes5[2] = USERARG_STRING_TYPE; // To Date
	inputArgTypes5[3] = USERARG_STRING_TYPE; // Plant Name	
	inputArgTypes5[4] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // selected Project 
	inputArgTypes5[5] = USERARG_STRING_TYPE; // Planner Name	
	inputArgTypes5[6] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // selected additional columns
	inputArgTypes5[7] = USERARG_STRING_TYPE; // Included Summary reports (True/False)	

	retValueType5 = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;
	
	
	printf("\n Start--CommonAPLDMLBetweenReportsNew service call...");fflush(stdout);  
	ifail=USERSERVICE_register_method("CommonAPLDMLBetweenReportsNew",(USER_function_t)CommonAPLDMLBetweenReportsNew,nargs5,inputArgTypes5,retValueType5);
	
	printf("\n End--CommonAPLDMLBetweenReportsNew service call...");fflush(stdout);	

	// End-Sanjoy improve performance common report 	
	
	//Start-Sanjoy DML Traceability Report

	int nargs6 = 3;
	int retValueType6;
	int *inputArgTypes6;
	inputArgTypes6=(int *)MEM_alloc(nargs6 * sizeof(int));
	
	inputArgTypes6[0] = USERARG_STRING_TYPE; // From Date
	inputArgTypes6[1] = USERARG_STRING_TYPE; // To Date
	inputArgTypes6[2] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // selected Project 

	retValueType6 = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;	
	printf("\n Start--DML Traceablity report service DmlTraceabilityReportServ call...");fflush(stdout);  
	ifail=USERSERVICE_register_method("DmlTraceabilityReportServ",(USER_function_t)DmlTraceabilityReportServ,nargs6,inputArgTypes6,retValueType6);
	
	printf("\n End--DmlTraceabilityReportServ service call...");fflush(stdout);	

	// End-Sanjoy DML Traceability Report
	
	//Start- Sanjoy ERC DML Print report
	int nargs7 = 1;
	int retValueType7;
	int *inputArgTypes7 = (int *) MEM_alloc ( nargs3 * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes7[0] = USERARG_TAG_TYPE;
	retValueType7 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//later might be used for generating the report in pdf/xls format.
	printf("\n ERC DML print report service start");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_ERCDmlPrintReportServ",(USER_function_t)tm_ERCDmlPrintReportServ,nargs7,inputArgTypes7,retValueType7);	
	if(ifail==ITK_ok)
	{
		printf("\n ERC DML print report service registered successfully");fflush(stdout);
	}
	else
	{
		printf("\n ERC DML print report service not registered.Pls check");fflush(stdout);
	}
		
	//End - Sanjoy ERC DML Print report
	
	
	return ifail;
	
} */

int ITK_user_main(int argc, char *argv[])
{
	
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* DMLNumber					= NULL;
	int ifail =0;

	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	DMLNumber       = ITK_ask_cli_argument("-DML_No=");
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = tm_ercdml_printreportfn(DMLNumber);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/*extern int APLReportHandlerFn(int *decision, va_list args)
{
	 int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
    printf("\nBefore registering action handler tm_ercdml_printreport....");            
	ifail = EPM_register_action_handler("tm_ercdml_printreport", "tm_ercdml_printreport",tm_ercdml_printreportfn);	
	printf("\nAfter registering action handler tm_ercdml_printreport...."); 
	
    printf("\nBefore registering action handler tm_nonercdml_printreport....");            
	ifail = EPM_register_action_handler("tm_nonercdml_printreport", "tm_nonercdml_printreport",tm_nonercdml_printreport);	
	printf("\nAfter registering action handler tm_nonercdml_printreport...."); 	
	
	return ifail;
}

//End - Sanjoy DML Print Report
extern DLLAPI int tm_APLReport_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_APLReport_register_callbacks: Before registering userservice....11111");   
	ifail=CUSTOM_register_exit ( "tm_APLReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllAplReportUserServiceFn);
	printf("\n tm_APLReport_register_callbacks: After registering userservice....22222");

	printf("\n Before registorig APLReportHandlerFn...");  
    ifail=CUSTOM_register_exit ( "tm_APLReport", "USER_init_module", (CUSTOM_EXIT_ftn_t)APLReportHandlerFn);
	printf("\n After  registorig APLReportHandlerFn...");
	
	return ( ITK_ok );
}*/
