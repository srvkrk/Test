/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE


extern int tm_PalmSysInterfaceServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	char *EstNumber= NULL;
	char *EstRev= NULL;
	char *EstSeq= NULL;
	char *EstEdnNo= NULL;
	char *EstPlant= NULL;
	char *EstShop= NULL;
	char *EstPEShop= NULL;
	
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 4;
	char    *qry_entryCntrl1[4]  = {"SYSCD","SUBSYSCD","Information-1","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;


	//USERARG_get_string_argument(&countValidPart);
	USERARG_get_string_argument(&EstNumber);
	USERARG_get_string_argument(&EstRev);
	USERARG_get_string_argument(&EstSeq);
	USERARG_get_string_argument(&EstEdnNo);
	USERARG_get_string_argument(&EstPlant);
	USERARG_get_string_argument(&EstShop);
	USERARG_get_string_argument(&EstPEShop);
	

	// ScheckArcLen_VC  

	
	printf("\nArgument tm_PalmSysInterfaceServiceFnc EstNumber=%s\n",EstNumber);fflush(stdout);	
	printf("\t EstRev=%s\t",EstRev);fflush(stdout);	
	printf("\t EstSeq=%s \t",EstSeq);fflush(stdout);	
	printf("\t  EstEdnNo=%s \t",EstEdnNo);fflush(stdout);	
	printf("\t  EstPlant=%s \t",EstPlant);fflush(stdout);	
	printf("\t  EstShop=%s \t",EstShop);fflush(stdout);	
	printf("\t  EstPEShop=%s \t",EstPEShop);fflush(stdout);	
	
	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	printf("\n QRY_find2 API changed-------- \n");fflush(stdout);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="PLMPALMSYS";
		qry_valuesCntrl1[1]="PalmSysPath";
		qry_valuesCntrl1[2]=EstPlant;
		qry_valuesCntrl1[3]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found .... \n");fflush(stdout);
		
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	
	if(control_number_found1>0)
	{
	
		AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo2",&shellpath);
						
		printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
		if(tc_strlen(shellpath)>0)
		{
			printf("\ninside EBOMMBOMRepExePath Execute through client code......\n");fflush(stdout);
			
			
			sysCmnd=(char *) MEM_alloc(400);
			tc_strcpy(sysCmnd,shellpath);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,EstNumber);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,EstRev);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,EstSeq);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,EstEdnNo);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,EstPlant);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,EstShop);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd,EstPEShop);
			tc_strcat(sysCmnd,"\"");
			tc_strcat(sysCmnd," ");
			
			printf("\n before-- Calling shell file tm_PalmSysInterfaceServiceFnc using client system command: %s\n",sysCmnd);fflush(stdout);
			system(sysCmnd);
			
			printf("\n after --- Calling shell file tm_PalmSysInterfaceServiceFnc using client system command: %s\n",sysCmnd);fflush(stdout);
			
			MEM_free(sysCmnd);
		}
	
	
	}



	return ifail;
}


extern int tm_PalmSysInterfaceRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 7;
	int retValueType;
	int validRowCntInt=0;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE; //Estimate Sheet ID;
	inputArgTypes[1] = USERARG_STRING_TYPE; // Estimate Sheet Rev
	inputArgTypes[2] = USERARG_STRING_TYPE;  // Estimate Sheet Seq
	inputArgTypes[3] = USERARG_STRING_TYPE;  // Estimate Sheet Edn No
	inputArgTypes[4] = USERARG_STRING_TYPE;  // Estimate Sheet Plant
	inputArgTypes[5] = USERARG_STRING_TYPE;  // Estimate Sheet Shop
	inputArgTypes[6] = USERARG_STRING_TYPE;  // Estimate Sheet PE Shop
	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n tm_PalmSysInterface before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_PalmSysInterfaceServiceFnc",(USER_function_t)tm_PalmSysInterfaceServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_PalmSysServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(tm_PalmSysInterfaceRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_PalmSysInterface_register_callbacks ()
{
	int ifail    = ITK_ok;

	ifail=CUSTOM_register_exit ( "tm_PalmSysInterface", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_PalmSysServiceFnc);
	
	return ( ITK_ok );
}

