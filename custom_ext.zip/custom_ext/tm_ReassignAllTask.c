
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ReassignAllTask.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   22-01-2025
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 22-01-2025  	 Amar Kate				    tm_Reassign All Task

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

/* Function to add string into a set of string */
void setuidAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int tm_ReassignAllTask_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	InputTask				= NULL;
	char*	selFromUserName			= NULL;
	char*	selToAssignUserName		= NULL;
	char*	Comments		= NULL;

	printf("\n Amar Inside tm_ReassignAllTask_Call .....\n");
	
	USERARG_get_string_argument(&InputTask);
	USERARG_get_string_argument(&selFromUserName);
	USERARG_get_string_argument(&selToAssignUserName);              
	USERARG_get_string_argument(&Comments);              
	 
	printf("\n Amar InputTask => %s\n",InputTask);fflush(stdout);	
	printf("\n Amar selFromUserName => %s\n",selFromUserName);fflush(stdout);
	printf("\n Amar selToAssignUserName => %s\n",selToAssignUserName);fflush(stdout);
	printf("\n Amar Comments => %s\n",Comments);fflush(stdout);

	
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"ReassignAllTask","ReassignAllTask","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n Amar control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			sprintf(cmd,"%s/ReassignAllTask.sh %s %s %s %s &",t5_Userinfo1,InputTask,selFromUserName,selToAssignUserName,Comments);
			printf("\nAmar Excuting For ReassignAllTask Command = %s\n",cmd);fflush(stdout);
			system(cmd);
			printf("\nAfter executing Command\n");fflush(stdout);
	   }
	}
	return ifail;
}

int tm_ReassignAllTaskMulti_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	combinedAllowString				= NULL;


	printf("\n Amar Inside tm_ReassignAllTaskMulti_Call .....\n");
	
	USERARG_get_string_argument(&combinedAllowString);
            	 
	printf("\n Amar combinedAllowString => %s\n",combinedAllowString);fflush(stdout);		

	
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"ReassignAllTask","ReassignAllTask","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;
	
	int n_entryCntrl1=3;
	
	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	
		printf("\n Amar control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo2 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo2",&t5_Userinfo2));	
			sprintf(cmd,"%s/ReassignAllTaskMulti.sh %s &",t5_Userinfo2,combinedAllowString);
			printf("\nAmar Excuting For ReassignAllTask Command = %s\n",cmd);fflush(stdout);
			system(cmd);
			printf("\nAfter executing Command\n");fflush(stdout);
	   }
	}
	return ifail;
}

int tm_PopulateUserList_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	int buff_cnt = 0;
	char **useridList = NULL;
	char* user_id = NULL;
	
	char*	ValueOfUserList				= NULL;

	USERSERVICE_array_t 	array_struct;


	printf("\n Amar Inside tm_PopulateUserList_Call .....\n");
	
	USERARG_get_string_argument(&ValueOfUserList);
            	 
	printf("\n Amar ValueOfUserList => %s\n",ValueOfUserList);fflush(stdout);		

	
	// Control Object for EXE
	char    *qry_entryCntrl1[1]  = {"Id"};    
    char    *qry_valuesCntrl1[1]= {"*"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;
	
	int n_entryCntrl1=1;
	
	CALLAPI(QRY_find2("UserFind", &qryTagCntrl1));
	
	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	
		printf("\n Amar control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
	   {
			for (int i = 0; i < control_number_found1; i++) 
			{
				CALLAPI(AOM_ask_value_string(list_of_WSO_cntrl_tags1[i],"user_id",&user_id));
				printf("\n Amar user_id is : %s\n",user_id);fflush(stdout);
				
				setuidAddStr(&buff_cnt, &useridList, user_id);
			}

	   }
	}

	ITK_CALL(USERSERVICE_return_string_array((const char**)useridList, buff_cnt, &array_struct));
	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) return_data) = array_struct;
	//MEM_free(uuids);
	printf("After returning Value\n");fflush(stdout);

	return ifail;
}

extern int tm_ReassignAllTasktinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for Action Plan Report

	int nargs1 = 4;
	int retValueType1;
	int inputArgTypes1[4] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE;   
	inputArgTypes1[3] = USERARG_STRING_TYPE;   

	retValueType1 = USERARG_STRING_TYPE ; 
	
	printf("\n tm_ReassignAllTasktinitmodule before....tm_ReassignAllTask_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_ReassignAllTask_Call",(USER_function_t)tm_ReassignAllTask_Call,nargs1,inputArgTypes1,retValueType1);

	
	int nargs = 1;
	int retValueType;
	int inputArgTypes[1] = {0};
		
	inputArgTypes[0] = USERARG_STRING_TYPE;
	
	retValueType = USERARG_STRING_TYPE ;

	printf("\n tm_ReassignAllTasktinitmodule before....tm_ReassignAllTaskMulti_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_ReassignAllTaskMulti_Call",(USER_function_t)tm_ReassignAllTaskMulti_Call,nargs,inputArgTypes,retValueType);

	int nargs2 = 1;
	int retValueType2;
	int inputArgTypes2[1] = {0};
		
	inputArgTypes2[0] = USERARG_STRING_TYPE;
	
	retValueType2 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;

	printf("\n tm_ReassignAllTasktinitmodule before....tm_PopulateUserList_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_PopulateUserList_Call",(USER_function_t)tm_PopulateUserList_Call,nargs2,inputArgTypes2,retValueType2);

	return ifail;	
}

extern DLLAPI int tm_ReassignAllTask_register_callbacks()
{	
	int ifail    = ITK_ok;
	//printf("\n Amar Before registoring userservice....tm_ReassignAllTask");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ReassignAllTask", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_ReassignAllTasktinitmodule);
	printf("\n Amar After registoring userservice....tm_ReassignAllTask");fflush(stdout);
	return ( ITK_ok );
}