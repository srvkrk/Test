#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#define NUM_ENTRIES 1
#define TE_MAXLINELEN 128
#define _CRT_SECURE_NO_DEPRECATE
#include <Fnd0Participant/participant.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h> //Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <math.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>


#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

void keywordstrcat(char **src,char* dest)
		{
			
			// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
			 char * desc = dest ? dest : "NA";
			
			//printf("\n autoresizestrcat src len==%d",strlen(*src));
			//printf("\n autoresizestrcat desc len==%d",strlen(desc));
			const size_t a = strlen(*src);
			const size_t b = strlen(desc);
			const size_t size_ab = a + b + 2;

		   // src = MEM_realloc(src, size_ab);
			
			*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

			tc_strcat(*src , desc);


		}
int tm_keyword_desc_internal(char *ext_1,char **output)
{

        int status=0;
        int i=0;
        int count=0;

        tag_t query=NULLTAG;
        tag_t *result=NULLTAG;


        char **Qry_Values = (char **) MEM_alloc(1* sizeof(char*));

		char *name= NULL;

		char *names[2];
        names[0]="Name";
		names[1]="ext_1";


                        ITK_CALL(QRY_find2("QryKyWrd_iDsgGrp_oClsfObj",&query));

                        Qry_Values[0]="*";
						Qry_Values[1]=ext_1;
						
						ITK_CALL(QRY_execute(query,2,names,Qry_Values,&count,&result));
						printf("\n QryKyWrd_iDsgGrp_oClsfObj Query search results count:-->%d",count);fflush(stdout);
						tc_strcpy(*output,"");
						for(i=0;i<count;i++)
						{
						ITK_CALL(AOM_UIF_ask_value(result[i],"name",&name));
                        //printf("name:%s",name);fflush(stdout);

						keywordstrcat(output,name);
						keywordstrcat(output,"#");

						
						}
						printf("\n output:%s",*output);fflush(stdout);

						return 0;

}


int ITK_user_main(int argc, char* argv[])
{
		int status=0;
	    char *s= NULL;
		char *output=NULL;
			
		output = (char *) MEM_alloc( 100 * sizeof(char) );
     
		char *ext_1=NULL;
		ext_1 = ITK_ask_cli_argument("-d=");
		//ITK_CALL( ITK_init_module("sjj919305","XYT1ESA" ,"APLPNR"));
		//ITK_CALL( ITK_init_module("infodba","infodba" ,"dba"));
		ITK_CALL( ITK_init_module("loader","loader123" ,"dba"));

        ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
        //ITK_CALL(ITK_auto_login());
        ITK_set_bypass(true);
        ITK_CALL(ITK_set_journalling(TRUE));

        if (status == 0 )
        {
        printf("\n login successful \n");fflush(stdout);
        }
        else
        {
          printf("\n Error code:%d",status);fflush(stdout);
          EMH_ask_error_text(status,&s);
          printf("\n Error message:%s",s);fflush(stdout);
        }
		tm_keyword_desc_internal(ext_1,&output);
		
		
		return 0;
	}

int tm_keyword_desc(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	char *inp_design_group=NULL;
	char *output=NULL;
			
	output = (char *) MEM_alloc( 100 * sizeof(char) );

	USERARG_get_string_argument(&inp_design_group);  //design group
                                              
	tm_keyword_desc_internal( inp_design_group, &output);

	printf("output:%s",output);fflush(stdout); 
	
	*((char **) return_data) = 
			   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output); 
			
			return ifail;

}



extern int AllUserServicekeyWorddescSAFtn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 

	int nargs = 1;
	int retValueType;
	int inputArgTypes[1] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes[0] = USERARG_STRING_TYPE;   //design group
	retValueType = USERARG_STRING_TYPE ; 
	//printf("\n AllUserServicekeyWorddescSAFtn before....tm_keyword_desc");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_keyword_desc",(USER_function_t)tm_keyword_desc,nargs,inputArgTypes,retValueType);

 return ifail;
 
}


extern DLLAPI int tm_keyWorddescSA_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registoring userservice....tm_keyWorddescSA");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_keyWorddescSA", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServicekeyWorddescSAFtn);
	//printf("\n After registoring userservice....tm_keyWorddescSA");fflush(stdout);
	return ( ITK_ok );
}

