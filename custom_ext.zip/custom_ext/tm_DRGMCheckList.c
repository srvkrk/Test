/*VS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_DRGMCheckList.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   29-10-2018
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>

#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h> 
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 919006
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)




////


#include <tc/tc.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
/*#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>*/
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>

#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>




/*
#include <cxpom/attributeaccessor.hxx>


#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
*/
#include <tccore/grm.h>
#include <tccore/grmtype.h>

//////

//using namespace std;
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


 int queryControlObject(char* qry_values[] ,int *n_cntrObj, tag_t** cntrObj)
{
	int ifail = ITK_ok;

	printf("\n Inside queryControlObject......");fflush(stdout);

	tag_t        query           = NULLTAG;

	char
	*qry_entries[] = { "SYSCD","SUBSYSCD"};
	//*qry_values[]  = {"WRKLock","DRGateLock"};
	
	printf("\n query Values [%s, %s]",qry_values[0],qry_values[1]);fflush(stdout);

	CALLAPI(QRY_find2("ControlObjQry", &query));
	printf("\n query found");fflush(stdout);
	CALLAPI(QRY_execute(query,2, qry_entries, qry_values, n_cntrObj, cntrObj));
	printf("\n query executed");fflush(stdout);

	printf("\n\n queryControlObject ==[%d] \n",*n_cntrObj);fflush(stdout);

	return ifail;
} 



int create_relation(char *relation_type,tag_t primary_object_tag, tag_t secondary_object_tag,tag_t *relation_tag)
{
	printf("\n****************inside create_relation****************");fflush(stdout);
    int ifail = ITK_ok;
    tag_t relation_type_tag  = NULLTAG;
    CALLAPI(GRM_find_relation_type(relation_type, &relation_type_tag));

    CALLAPI(GRM_create_relation(primary_object_tag, secondary_object_tag,relation_type_tag, NULLTAG, relation_tag));
    CALLAPI(GRM_save_relation(*relation_tag));
   // return relation_tag;
   return ifail;
}


int getDrStatusCondition(tag_t* new_item, tag_t* new_rev, char** vehDr)
{
	printf("\n****************getDrStatusCondition****************");fflush(stdout);
	
	int ifail = ITK_ok;
	char* dmlRelType = NULL;
	
	CALLAPI(AOM_ask_value_string(*new_rev,"t5_DMLRelType", &dmlRelType));
	
	printf("\n t5_DMLRelType: [%s]",dmlRelType);
	
	if(tc_strcmp(dmlRelType,"Veh")==0)
	{
	
		//CALLAPI(AOM_ask_value_string(*new_item,"t5_DMLDRARStatus", vehDr));
		CALLAPI(AOM_ask_value_string(*new_rev,"t5_DMLDRARStatus", vehDr));
		printf("\n t5_DMLDRARStatus: [%s]",*vehDr);
	}
	else if(tc_strcmp(dmlRelType,"TODR")==0)
	{
		CALLAPI(AOM_ask_value_string(*new_item,"t5_DRARStatus", vehDr));
		printf("\n t5_DRARStatus: [%s]",*vehDr);
	}
	else
	{
		printf("\n getDrStatusCondition outside condition");fflush(stdout);
			CALLAPI(AOM_ask_value_string(*new_item,"t5_VehicleDRARStatus", vehDr));
		printf("\n t5_VehicleDRARStatus: [%s]",*vehDr);
		
	}
	
	return ifail;
}
 

/* FUNCTION TO CREATE DRGM CHECKLIST */
int tm_drgmchklist_create( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;

	
/*	
	@param const char* item_id
    @param const char* item_name
    @param const char* type_name
    @param const char* rev_id
    @param tag_t*      new_item
    @param tag_t*      new_rev
    @param tag_t       item_master_form
    @param tag_t       item_rev_master_form
*/	
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	
	printf("\n********************** Entering tm_drgmchklist_create()*******************");fflush(stdout);
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	drgmChckStr1			= NULL;
	char*	vehNo			= NULL;
	char*	vehRev			= NULL;
	char*	itemid			= NULL;
	int		vehSeq			= 0;
	char*	vehDr			= NULL;
	
	

	CALLAPI(AOM_ask_value_string(*new_item,"t5_VehicleNumber", &vehNo));
	CALLAPI(AOM_ask_value_string(*new_item,"t5_VehicleRevision", &vehRev));
	CALLAPI(AOM_ask_value_int(*new_item,"t5_VehicleSequence", &vehSeq));
	//CALLAPI(AOM_ask_value_string(*new_item,"t5_VehicleDRARStatus", &vehDr));
	
	drgmChckStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	CALLAPI(getDrStatusCondition(new_item,new_rev,&vehDr));
	
	if(tc_strlen(vehDr) > 3)
	{
		printf("\n tc_strlen(vehDr): [%d]",tc_strlen(vehDr));fflush(stdout);
		
		int start = 0;
		int end = 0;
		
		start = tc_strlen(vehDr) - 3;
		end = tc_strlen(vehDr);
		
		char* drdr = NULL;
		drdr = (char *) MEM_alloc( 10 * sizeof(char) );		
		
		tc_strcpy(drdr,vehDr);
		
		vehDr = NULL;
		
		vehDr = subString(drdr,start,end);
		
		printf("\nvehDr [%s]",vehDr);fflush(stdout);
	}
	else
	{
		printf("\n tc_strlen(vehDr): [%d]",tc_strlen(vehDr));fflush(stdout);
	}
	
	sprintf(drgmChckStr1,"%s_%s_%d_%s_Gateway_CheckList",vehNo,vehRev,vehSeq,vehDr);
	
		if(drgmChckStr1!= NULL)
		{
			if(*new_item != NULLTAG )
			{
			CALLAPI(AOM_lock(*new_item));
			CALLAPI(AOM_set_value_string(*new_item,"item_id", drgmChckStr1));
			CALLAPI(AOM_save_without_extensions(*new_item));						
			CALLAPI(AOM_unlock(*new_item));
      
			CALLAPI(AOM_lock(item_master_form));
			CALLAPI(AOM_set_value_string(item_master_form,"object_name", drgmChckStr1));
			CALLAPI(AOM_save_without_extensions(item_master_form));						
			CALLAPI(AOM_unlock(item_master_form));

			char *rev_master_form_id=NULL;
			rev_master_form_id=(char *)MEM_alloc(100);
		    tc_strcpy(rev_master_form_id,drgmChckStr1); 
		    tc_strcat(rev_master_form_id,"/"); 
		    tc_strcat(rev_master_form_id,rev_id); 

			CALLAPI(AOM_lock(item_rev_master_form));
            CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
            CALLAPI(AOM_save_without_extensions(item_rev_master_form));
            CALLAPI(AOM_unlock(item_rev_master_form));

			printf("\n DML Item ID Updated With %s",drgmChckStr1);fflush(stdout);			

			MEM_free(rev_master_form_id);
			MEM_free(drgmChckStr1);

			}
			else
			{
				printf("\n NULLTAG new_item");fflush(stdout);
			}

		}	
		
		printf("\n name update complete");fflush(stdout);

			char *bu;
			char *drStat;
			int c_drgmparam;
			tag_t* drgmparam;
			tag_t drParamQuery;
			tag_t parent;
			
			//CALLAPI(ITEM_ask_item_of_rev(*new_item,&parent));

			//CALLAPI(AOM_get_value_string(parent,"t5BusinessUnit", &bu));
			
			//vehDr
			//CALLAPI(AOM_get_value_string(*new_item,"t5_VehicleDRARStatus", &drStat));
			printf("\n vehDr: [%s]",vehDr);fflush(stdout);

			//if((bu != NULL) && (drStat != NULL))
			if(vehDr != NULL)
			{
				//char *qry_entries[] = {"Business Unit","Applicable DR"};
				char *qry_entries[] = {"Applicable DR"};
				//char *qry_values[]  = {bu,drStat};
				char *qry_values[]  = {vehDr};
				char *keys[1] = {"t5_ParameterID"};
				int  	 orders[1]  ={1};
				
				ifail = QRY_find2("DRGMParameter", &drParamQuery);
				
				if(ifail == ITK_ok)
				{
					printf("\n drParamQuery found");fflush(stdout);
				}
				else
				{
					printf("\n drParamQuery not found");fflush(stdout);
				}
				
				printf("\n before QRY_execute_with_sort");fflush(stdout);
				
				CALLAPI(QRY_execute_with_sort(drParamQuery,1,qry_entries,qry_values,1,keys,orders,&c_drgmparam,&drgmparam))
				
				printf("\n after QRY_execute_with_sort, c_drgmparam [%d]",c_drgmparam);fflush(stdout);
				
				if (c_drgmparam > 0)
				{
					printf("\n inside creating relation");fflush(stdout);
					int x;
					for(x=0;x<c_drgmparam;x++)
						{
							char *drgmid;

							tag_t reltag=NULLTAG;
							
							CALLAPI(AOM_get_value_string(drgmparam[x],"t5_ParameterID", &drgmid));
							printf("\n %d. drgmid [%s]",x+1, drgmid);fflush(stdout);
							
							ifail=create_relation("T5_DRGMParamRel",*new_rev,drgmparam[x],&reltag);
							
							if(ifail == ITK_ok)
							{
								printf("\n create relation success");fflush(stdout);
							}
							else
							{
								printf("\n create relation failed");fflush(stdout);
							}
							CALLAPI(AOM_refresh(reltag, TRUE));
							CALLAPI(AOM_set_value_string(reltag,"t5_ParamStatus","Open"));
							CALLAPI(AOM_save_without_extensions(reltag));
							CALLAPI(AOM_refresh(reltag, FALSE));
						}

				}
				
				if(drgmparam)
					MEM_free(drgmparam);
		
				
			}


	

	
	return 0;
}



int tm_drgmchklist_dataset( METHOD_message_t *msg, va_list args )
{
	printf("\n*******************welcome Pratik**********************");fflush(stdout);
	int ifail = ITK_ok;
/**
    @param tag_t               datasetTag     (I)
    @param char*               referenceName  (I)
    @param AE_reference_type_t referenceType  (I)
    @param char*               osFullPathName (I)
    @param char*               fileName       (I)
    @param int                 fileTypeFlag   (I)
*/

	tag_t  datasetTag = va_arg(args, tag_t);
	char*  referenceName = va_arg(args, char*);
	char*  fileName = va_arg(args, char*);
	AE_reference_type_t  referenceType = va_arg(args, AE_reference_type_t);
	
	
	if(datasetTag != NULLTAG)
	{
		printf("\n inside tm_drgmchklist_dataset");fflush(stdout);
		
		char* type;
		
		ifail = WSOM_ask_object_type2(datasetTag,&type);
		printf("\n DatasetType [%s]",type);fflush(stdout);
		printf("\n referenceName [%s]",referenceName);fflush(stdout);
		
		if(tc_strcmp(type,"PDF")==0)
		{
			int priObjCount = 0;
			tag_t* priObj;
			
			ifail = GRM_list_primary_objects_only(datasetTag,NULLTAG,&priObjCount,&priObj);
			printf("\nPrimary object count [%d]", priObjCount);fflush(stdout);
			
			if(priObjCount>0)
			{
				int count = 0;
				
				for(count=0;count<priObjCount;count++)
				{
					char* priObjtype;
					
					ifail = WSOM_ask_object_type2(priObj[count],&priObjtype);
					
					printf("\nPrimary object type [%s]", priObjtype);fflush(stdout);
					
					if(tc_strcmp(priObjtype,"T5_DRGMCheckListRevision")==0)
					{
						int namedRefCount;
						tag_t* namedReference;
						
						
						
						ifail = AE_ask_dataset_named_refs(datasetTag,&namedRefCount,&namedReference);
						
						printf("\n inside if of T5_DRGMCheckListRevision");fflush(stdout);
						if(ifail == ITK_ok)
						{
							printf("\n AE_ask_dataset_named_refs count [%d]",namedRefCount);fflush(stdout);
							//printf("\n named reference count [%d]",namedRefCount);fflush(stdout);
						
							if(namedRefCount>0)
							{
								char* pdfname;
								char* usrInfo1;
								char path[1000];
								int n_cntrlObj;
								tag_t* cntrlObj;
								
								char *qry_values[]  = {"WRKLock","DRGateLock"};
							
								CALLAPI(queryControlObject(qry_values,&n_cntrlObj, &cntrlObj));
								printf("\n queryControlObject outside [%d]",n_cntrlObj);fflush(stdout);
								
								CALLAPI(AOM_ask_value_string(cntrlObj[0],"t5_Userinfo1", &usrInfo1));
								
								printf("\n usrInfo1 [%s]",usrInfo1);fflush(stdout);
								
								ifail = IMF_ask_original_file_name2(namedReference[0],&pdfname);
								
								tc_strcpy(path,"");
								tc_strcpy(path,usrInfo1);
								tc_strcat(path,pdfname);
								
								printf("\n total path [%s]",path);fflush(stdout);
								
								ifail = AE_export_named_ref(datasetTag,referenceName,path);

								
								if(ifail == ITK_ok)
								{
									printf("\n AE_export_named_ref successfull");fflush(stdout);
								}
								else
								{
									printf("\n AE_export_named_ref Unsuccessfull");fflush(stdout);
									
								}
								
							}
							
							
						}
						else
						{
							printf("\n AE_ask_all_dataset_named_refs2 not ok");fflush(stdout);
						}
						
						
					}
				}
				
			}
			
		}
	}
	
	
	return 0;
}

int DRGMChecklistUpdate(void *retValue)
{
	const char				*prog_name 		="DRGMChecklistUpdate";
	int ifail = ITK_ok;
	tag_t drgmchklstRev = NULLTAG;
	char 			*ckddmlno				= NULL;
	char 			*type				= NULL;
	
	USERARG_get_tag_argument(&drgmchklstRev); 
	
	ITK_CALL(WSOM_ask_object_type2(drgmchklstRev,&type));
	printf("\n drgmchklstRev Type [%s]",type);fflush(stdout);
	
	if(tc_strcmp(type,"T5_DRGMCheckListRevision")==0)
	{
		tag_t relatnType_tag = NULLTAG;
		tag_t* rel_drgmrev = NULL;
		int relCount;
		
		
		ITK_CALL(GRM_find_relation_type("T5_DRGMParamRel",&relatnType_tag));
		
		
		ITK_CALL(GRM_list_secondary_objects_only(drgmchklstRev,relatnType_tag,&relCount,&rel_drgmrev));
		
		printf("\n drgmchklstRev relCount [%d]",relCount);fflush(stdout);
		
		if(relCount>0)
		{
			tag_t type_tag = NULLTAG;
			tag_t property_tag = NULLTAG;
			tag_t base_prop_tag = NULLTAG;
			tag_t base_type_tag = NULLTAG;
			tag_t* sorted_rel_drgmrev = NULL;
			int n_sorted_relCount;
			
			
			
			int *order = (int *) MEM_alloc(sizeof(int));
			
			order[0] = 0;
			
			
			printf("\nbefore TCTYPE_find_type");fflush(stdout);
			ITK_CALL(TCTYPE_find_type("T5_DRGMParameter","T5_DRGMParameter",&type_tag));
			
			printf("\nbefore TCTYPE_ask_property_by_name");fflush(stdout);
			ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"t5_ParameterID",&property_tag));
			
			printf("\nbefore PROPDESC_ask_base_descriptor");fflush(stdout);
			ITK_CALL(PROPDESC_ask_base_descriptor(property_tag,&base_prop_tag, &base_type_tag));
			
			printf("\nbefore AOM_sort_tags_by_properties");fflush(stdout);
			ITK_CALL(AOM_sort_tags_by_properties(relCount,rel_drgmrev,1,&base_prop_tag,order, &n_sorted_relCount, &sorted_rel_drgmrev)); 
			
			
			if(n_sorted_relCount>0)
			{
				tag_t *retModules=NULLTAG;
				int moduleTagList_cnt;
				int x;
				
				for(x=0;x<n_sorted_relCount;x++)
				{

					tag_t drgmparam_obj = sorted_rel_drgmrev[x];
					
					setAddTagP(&moduleTagList_cnt,&retModules,drgmparam_obj);
					
					char *param_id;
					ITK_CALL(AOM_ask_value_string(drgmparam_obj, "t5_ParameterID", &param_id ));
					printf("\n [%d] DRGM Parameter ID=%s",x,param_id);fflush(stdout);
				}
				
				printf("\n before USERSERVICE_return_tag_array call with values moduleTagList_cnt[%d]",moduleTagList_cnt);fflush(stdout);
				ITK_CALL(USERSERVICE_return_tag_array(retModules,moduleTagList_cnt,(USERSERVICE_array_t*)retValue));
				printf("\n after USERSERVICE_return_tag_array call");fflush(stdout);
			}
		}
		else
		{
			printf("\n no relation found");fflush(stdout);
		}
		
	}
 
 return ifail;
	
}

int tm_drgmrev_iman_save( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	tag_t new_item         = NULLTAG;
	tag_t* cntrlObj   ;
	int isnew              = 0;
	int n_cntrlObj              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	printf("\n DML Revision tm_drgmrev_iman_save invoked ");fflush(stdout);

	char *bu;
	
	CALLAPI(AOM_get_value_string(new_item,"t5_BusinessUnit", &bu));
	
		const char *valuelist[]={bu};
		const char *attr="t5_BusinessUnit";
		const char *sel_attrs[1] = {"puid"};
		
		char *qry_values[]  = {"CVBU","DR0"};
		
		CALLAPI(queryControlObject(qry_values,&n_cntrlObj, &cntrlObj));
		printf("\n queryControlObject outside [%d]",n_cntrlObj);fflush(stdout);
		
		if(n_cntrlObj>0)
		{
			int info = 10;
			int usrInfo;
			int arrayVal = 0;
			int i = 0;
			
			char* userTok;
			char *paramid[100];
			
			for(usrInfo=0;usrInfo<info;usrInfo++)
			{
				char* userdataAttr = NULL;
				char* userData = NULL;
				
				userData = (char *) MEM_alloc( usrInfo * sizeof(char) );
				
				sprintf(userdataAttr,"t5_Userinfo%d",usrInfo+1);
				
				CALLAPI(AOM_get_value_string(cntrlObj[0],userdataAttr, &userData));
				
				if(userData == NULL)
				{
					printf("\n %s is NULL",userdataAttr);fflush(stdout);
					break;
				}
				else
				{
					continue;
				}
				
				userTok = tc_strtok(userData,",");
				
				while (userTok != NULL)
				{
					paramid[arrayVal++] = userTok;
					userTok = tc_strtok(NULL, ",");
					
				}
				
			}
			
			for(i=0;i<sizeof(paramid);i++)
			{
				if(paramid[i] != NULL)
				{
					printf("%d. user paramid: [%s]",i+1,paramid[i]);fflush(stdout);
				}
				
			}
		}
		
		
		/*CALLAPI(POM_enquiry_create("dr_gm_param_enq"));
		CALLAPI(POM_enquiry_add_select_attrs("dr_gm_param_enq", "T5_DRGMParameter", 1, sel_attrs));
		CALLAPI(POM_enquiry_set_string_value("dr_gm_param_enq", "value", 1, valuelist,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("dr_gm_param_enq", "expression", "T5_DRGMParameter", attr, POM_enquiry_equal, "value"));
		CALLAPI(POM_enquiry_set_where_expr ( "dr_gm_param_enq", "expression" ));

		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		CALLAPI(POM_enquiry_add_order_attr ( "dr_gm_param_enq","T5_DRGMParameter","t5_ParamSrl",POM_enquiry_asc_order));

		CALLAPI(POM_enquiry_execute("dr_gm_param_enq", &rows, &columns, &report));
		
		if (rows != 0)
		{
			int x;	
			for(x=0;x<rows;x++)
				{
				
					objtag  = *(tag_t*)(report[x][0]);
					tag_t reltag=NULLTAG;	
					CALLAPI(create_relation("T5_DRGMParamRel",new_item,objtag,&reltag));
				
				}
		
		}*/

	
	return ifail;
}




extern int tm_DRGMCheckListinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  drgmrev_iman_save;
	METHOD_id_t  drgmchklist_create;
	METHOD_id_t  drgmchklist_dataset;
	
	
	
	// printf("\n ############ After Rigister tm_DRGMCheckListinitmodule");fflush(stdout);


	/* Overriding IMAN_Save of T5_DRGMCheckList  */

	CALLAPI(METHOD_find_method("T5_DRGMCheckList", "ITEM_create", &drgmchklist_create));
	if (drgmchklist_create.id != NULLTAG)
    	{	
		// printf("\n before Rigister T5_DRGMCheckList");fflush(stdout);
		CALLAPI(METHOD_add_action(drgmchklist_create, METHOD_post_action_type,(METHOD_function_t)tm_drgmchklist_create ,NULL));	
		// printf("\n IN After Rigister T5_DRGMCheckList");fflush(stdout);
    	}
	else
	{
		printf("\n IN After Rigister T5_DRGMCheckList  == NULL");fflush(stdout);
	}
	

	
	//CALLAPI(METHOD_find_method("ImanRelation", GRM_create_msg, &drgmchklist_dataset));
	CALLAPI(METHOD_find_method("PDF", AE_import_file_msg, &drgmchklist_dataset));
	if (drgmchklist_dataset.id != NULLTAG)
    	{	
		// printf("\n before Rigister T5_DRGMCheckList");fflush(stdout);
		CALLAPI(METHOD_add_action(drgmchklist_dataset, METHOD_post_action_type,(METHOD_function_t)tm_drgmchklist_dataset ,NULL));
		
		// printf("\n IN After Rigister drgmchklist_dataset");fflush(stdout);
    	}
	else
	{
		printf("\n IN After Rigister drgmchklist_dataset  == NULL");fflush(stdout);
	}
	
	
	
	/* Overriding IMAN_Save of T5_DRGMCheckListRevision  */
	/*CALLAPI(METHOD_find_method("T5_DRGMCheckListRevision", "IMAN_save", &drgmrev_iman_save));
	
	if (drgmrev_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_ckddml_set_init_val");fflush(stdout);
		CALLAPI(METHOD_add_action(drgmrev_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_drgmrev_iman_save ,NULL));
		
		printf("\n IN After Rigister tm_drgmrev_iman_save");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_drgmrev_iman_save  == NULL");fflush(stdout);
	}*/
	/* End overriden */
	
	
	
	return ifail;
	
}






//

extern int tm_DRGMCheckListServiceinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	int nargs = 1;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	// printf("\n ############ inside tm_DRGMCheckListServiceinitmodule");fflush(stdout);	
	
	
	inputArgTypes[0] = USERARG_TAG_TYPE;

	retValueType = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE ; 
	
	// printf("\n tm_DRGMCheckListServiceinitmodule before....DRGMChecklistUpdate");fflush(stdout);  
	ifail=USERSERVICE_register_method("DRGMChecklistUpdate",(USER_function_t)DRGMChecklistUpdate,nargs,inputArgTypes,retValueType);	
	// printf("\n tm_DRGMCheckListServiceinitmodule after....DRGMChecklistUpdate");fflush(stdout);  

	return ifail;	
}


//extern "C" DLLAPI int tm_DRGMCheckList_register_callbacks ()
extern DLLAPI int tm_DRGMCheckList_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	// printf("\n Before registoring userservice....tm_DRGMCheckList");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_DRGMCheckList", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_DRGMCheckListinitmodule);
	ifail=CUSTOM_register_exit ( "tm_DRGMCheckList", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_DRGMCheckListServiceinitmodule);
	// printf("\n After registoring userservice....tm_DRGMCheckList");fflush(stdout);
	return ( ITK_ok );
}
