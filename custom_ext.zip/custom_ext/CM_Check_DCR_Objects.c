/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Shivkumar Birnale, Dhiraj Agarwal
*  Module               :   Workflow Rule Handler to check if DML implements the appropriate DCR based on Control Objects
*  Code                 :   CM_Check_DCR_Objects.c
*  Created on			:   April 16th, 2018
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		CM_Check_DCR_Objects
	Description			:		This handler checks the DCR implemented by DML
*/


struct
 {  
	char DCRItemsName[30];
 } dcrItems[1000];

struct
 {  
	char DMLItemsName[30];
 } DmlItems[1000];


EPM_decision_t CM_Check_DCR_Objects(EPM_rule_message_t msg)
{
	char *obj_type=NULL;
	char *DcrItemNumber=NULL;
	char *DmlItemNumber=NULL;
	char *dmlProjID=NULL;
	char *dmlDRStatus=NULL;
	char *usrInfo1=NULL;

	int attachmentCount,ItmCnt = 0;
	int taskCnt,dmlItemCnt,taskcnt = 0;
	int	i,j,status = 0;
	int	match,qryRetCnt = 0;
	int Itemscnt, dcrItemCnt = 0;

	tag_t rootTask_t=NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t ctrlObjQry=NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	EPM_decision_t EPM_Decision;

	printf("\n CM_Check_DCR_Objects Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Check_DCR_Objects Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));

	for(i=0;i<attachmentCount;i++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[i],&obj_type));
		TC_write_syslog("Object Type = %s\n",obj_type);
		if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
		{
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
			ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));

			if(ctrlObjQry!=NULLTAG)
			{
				char *qryEntries[]={"SYSCD","SUBSYSCD"};
				char *qryValues[]={"PRTCHDCR",dmlProjID};
				ITK_CALL(QRY_execute(ctrlObjQry,2,qryEntries,qryValues,&qryRetCnt,&qryResults));
			}
			else
			{
				TC_write_syslog("Control Objects... query not found, Please contact TC Admin\n");
			}

			if(qryRetCnt == 0)
			{
				TC_write_syslog("No Control Objects found\n");
				EMH_store_error_s1(EMH_severity_error,CONTROL_OBJ_NOT_FOUND,"No Control Objects found for DCR, kindly Contact to TCUA PLM Admin Team.");
				return EPM_go;
			}

			if(qryRetCnt == 1)
			{
				ITK_CALL(AOM_ask_value_string(qryResults[0],"t5_Userinfo1",&usrInfo1));
				TC_write_syslog("DML DR Status is [%s] , and Control Obj DR Status is [%s]\n",dmlDRStatus,usrInfo1);

				if(tc_strstr(usrInfo1,dmlDRStatus)!=NULL)
				{
					// Calling DCR Items Functions..
					ITK_CALL(status = check_DCRItem_Status(taskAttachments[i], &dcrItemCnt));
					if(status == 0)
						return EPM_nogo;
					

					// Calling DML Items Functions..
					ITK_CALL(status = check_DMLItem_Status(taskAttachments[i], &dmlItemCnt));
					if(status == 0)
						return EPM_nogo;

					if(dcrItemCnt > 0 && dmlItemCnt > 0)
					{
						for(i=0;i<dmlItemCnt;i++)
						{		
							match = 0;
							DmlItemNumber = (char	*)MEM_alloc(50);
							tc_strcpy(DmlItemNumber,DmlItems[i].DMLItemsName);

							for(j=0;j<dcrItemCnt;j++)
							{
								DcrItemNumber = (char	*)MEM_alloc(50);
								tc_strcpy(DcrItemNumber,dcrItems[j].DCRItemsName);

								if(tc_strcmp(DmlItemNumber,DcrItemNumber) == 0)
								{
									match++;
									break;
								}else
								{
									//TC_write_syslog("Do nothing.. continue..\n");
									//continue;
								}
							}
							if(match == 0)
							{
								TC_write_syslog("\nTC Item %s is not found in DCR Objects\n",DmlItemNumber);
								//EMH_store_error_s1(EMH_severity_error,EPM_TASK_NOTFOUND,"\tTask is not attached with DML Revision\t");
								EMH_store_error_s3(EMH_severity_error,ITEM_NOTMATCH,"Please attach ",DmlItemNumber," in Problem items relationship with DCR ");
								return EPM_nogo;
							}
						}
					}
					else if(dcrItemCnt == 0)
					{
						TC_write_syslog("\nItems not availble in DCR. Hence returning EPM_nogo.Kindly attached Items in Approved DCR\n");
						EMH_store_error_s1(EMH_severity_error,ITEMS_NOTFOUND_DCR,"Please attach Items in Problem items relationship with DCR.");
						return EPM_nogo;
					}
					else if(dmlItemCnt == 0)
					{
						TC_write_syslog("\nItems not availble in DML. Hence returning EPM_nogo.Kindly attached Items in DML\n");
						EMH_store_error_s1(EMH_severity_error,ITEMS_NOTFOUND_DML,"Please attach Items in Solution items relationship with DML.");
						return EPM_nogo;
					}
				}
				else
				{
					TC_write_syslog("\nDML DR and Control Obj DR Status are not match, kindly check the DR Status of DML.\n");
					EMH_store_error_s1(EMH_severity_error,DR_NOT_MATCH,"DML DR and Control Obj DR Status are not match, kindly check the DR Status of DML.");
					return EPM_nogo;
				}
			}
		}
		else
		{
			TC_write_syslog("\nObject Type is not ChangeRequestRevision. Hence returning EPM_nogo\n");
			EMH_store_error_s1(EMH_severity_error,DML_REVISION_NOT_FOUND,"Please Submit DML Revision in Work Flow.");
			return EPM_nogo;
		}
	}
	printf("\n CM_Check_DCR_Objects Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Check_DCR_Objects Function end...");
}


int check_DCRItem_Status(tag_t taskAttachment, int *dcrItemCnt)
{
	int		Dcrcnt,j,k	 = 0;
	int		DcrItemscnt  = 0;
	int		status = 0;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DcrItemObj=NULLTAG;

	tag_t *DcrList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;

	char *ItemNumber=NULL;
	*dcrItemCnt = 0;
	printf("\n check_DCRItem_Status Function started...");fflush(stdout);
	TC_write_syslog("\n check_DCRItem_Status Function started...");
	ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasProblemItem",&DcrProblmItemsRelType));

	if(implemRelationType_t != NULLTAG)
	{
		ITK_CALL(GRM_list_secondary_objects_only(taskAttachment,implemRelationType_t,&Dcrcnt,&DcrList));
		TC_write_syslog("\n DCR count = %d\n",Dcrcnt);
		if(Dcrcnt==0)
		{
			TC_write_syslog("\nNo DCR attached to DML, Hence returning EPM_nogo\n");
			EMH_store_error_s1(EMH_severity_error,EPM_DCR_NOTFOUND,"\tDCR is not attached with DML Revision, Kindly attach Approved DCR with DML Revision in Implements relation\t");
			//return status;
		}

		// get the all Items in DCR in one Structure..
		if(Dcrcnt > 0)
		{
			TC_write_syslog("DCR Count attached to DML = %d\n",Dcrcnt);
			
			if(DcrProblmItemsRelType != NULLTAG)
			{
				for(j=0;j<Dcrcnt;j++)
				{
					ITK_CALL(GRM_list_secondary_objects_only(DcrList[j],DcrProblmItemsRelType,&DcrItemscnt,&DcrItemsList));
					TC_write_syslog("Items Count attached to DCR = %d\n",DcrItemscnt);

					if(DcrItemscnt > 0)
					{
						for(k=0;k<DcrItemscnt;k++)
						{
							DcrItemObj = DcrItemsList[k];
							AOM_ask_value_string(DcrItemObj,"item_id",&ItemNumber);	
							TC_write_syslog("ItemNumber = %s\n",ItemNumber);

							if((tc_strlen(ItemNumber)) == 12)
							{
								tc_strcpy(dcrItems[*dcrItemCnt].DCRItemsName,ItemNumber);
								*dcrItemCnt = *dcrItemCnt + 1;								
							}		
							status++;
						}									
					}
				}
				TC_write_syslog("dcrItemCnt = %d\n",*dcrItemCnt);
			}
			else
			{
				TC_write_syslog("\nCMHasProblemItem Relation not found in DCR Objects. Hence returning status\n");
				//return status;
			}					
		}
	}
	else
	{
		TC_write_syslog("\nCMImplements Relation not found. Hence returning status\n");
		//return status;
	}

	printf("\n check_DCRItem_Status Function end...");fflush(stdout);
	TC_write_syslog("\n check_DCRItem_Status Function end...");
	return status;
}



int check_DMLItem_Status(tag_t taskAttachment, int *dmlItemCnt)
{
	int taskCnt	=0;
	int taskcnt	=0;
	int ItmCnt	=0;
	int Itemscnt	=0;
	int status	=0;
	char *ItemNumberwithDml=NULL;
	char *ItemNumberRev=NULL;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t ItemObj=NULLTAG;

	*dmlItemCnt = 0;
	
	printf("\n check_DMLItem_Status Function started...");fflush(stdout);
	TC_write_syslog("\n check_DMLItem_Status Function started...");
	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));

	// get the all Items of DML Objects in one Structure
	if(DmlTaskRelationType_t != NULLTAG)
	{
		ITK_CALL(GRM_list_secondary_objects_only(taskAttachment,DmlTaskRelationType_t,&taskCnt,&taskList));
		TC_write_syslog("\nTask Count attached to DML = %d\n",taskCnt);

		if(taskCnt==0)
		{
			TC_write_syslog("\nNo Task attached to DML, Hence returning EPM_nogo\n");
			EMH_store_error_s1(EMH_severity_error,EPM_TASK_NOTFOUND,"\tTask is not attached with DML Revision, kindly Create Task and attch with Break Down into Plan Item Relation with DML Revision\t");
			//return EPM_nogo;
		}
		
		
		if(taskCnt > 0)
		{
			if(DmlItemsRelation_t != NULLTAG)
			{
				for(taskcnt=0;taskcnt<taskCnt;taskcnt++)
				{
					ITK_CALL(GRM_list_secondary_objects_only(taskList[taskcnt],DmlItemsRelation_t,&Itemscnt,&ItemsList));
					TC_write_syslog("\nItems Count attached to DML = %d\n",Itemscnt);

					if(Itemscnt > 0)
					{						
						for(ItmCnt=0;ItmCnt<Itemscnt;ItmCnt++)
						{
							ItemObj = ItemsList[ItmCnt];
							AOM_ask_value_string(ItemObj,"item_id",&ItemNumberwithDml);		
							AOM_ask_value_string(ItemObj,"item_revision_id",&ItemNumberRev);	
								
							if(tc_strstr(ItemNumberRev,"NR") != NULL)
							{
								continue;
							}
							else
							{	
								TC_write_syslog("ItemNumberwithDml = %s\n",ItemNumberwithDml);
								if((tc_strlen(ItemNumberwithDml)) == 12)
								{
									tc_strcpy(DmlItems[*dmlItemCnt].DMLItemsName,ItemNumberwithDml);									
									*dmlItemCnt = *dmlItemCnt + 1;
								}
							}
							status++;
						}
						TC_write_syslog("\ndmlItemCnt = %d\n",*dmlItemCnt);
					}
				}
			}
			else
			{
				TC_write_syslog("\nCMHasSolutionItem Relation Objects not found. Hence returning EPM_nogo\n");
				//return EPM_nogo;
			}
		}
	}
	else
	{
		TC_write_syslog("\nT5_DMLTaskRelation Relation not found. Hence returning EPM_nogo\n");
		//return EPM_nogo;
	}

	//MEM_free(taskList);
	//MEM_free(ItemsList);
	printf("\n check_DMLItem_Status Function end...");fflush(stdout);
	TC_write_syslog("\n check_DMLItem_Status Function end...");

	return status;
}