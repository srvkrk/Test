/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: GateMaturationUpd.c
**
**
**	Date							Author					Modification
**	02-04-2019						Mohan Tayade			Code creation
**	06-05-2019						Mohan Tayade			Handle DR3P/AR3P.
**
** command to run:
GateMaturationUpd -u=hpp05653 -pf=hpp05653 -g=dba -file=input.txt
GateMaturationUpd -u=ercpsup  -pf=XYT1ESA  -g=dba -file=input.txt
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int GateMaturationUpd(char* item_id);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	
	 ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	/*output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/

		//ifail = read_value_from_file(Filename);
		ifail = GateMaturationUpd(dmlnob);
		CHECK_FAIL;

	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*design_group			= NULL;
	char 			*dr_status				= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s",itemid);


		//ifail = tm_DesignRevBOM(itemid,"13PP254028","DR2");
				//ifail = GateMaturationUpd(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}

int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	//MT end
	printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		printf("\n FUN:Inside Find for part no:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		printf("\n FUN:count n_tags_foundd2 :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int GateMaturationUpd(char* item_id)
{
	int		ifail 		= ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	int      no_attach      =  0;
	char	*PlntToPlnt1		=  NULL;
	char	*PlntToPlnt		=  NULL;
	char	*class_name1	=  NULL;
	char	*TaskProj		=  NULL;
	char	*PartMstr_no	=  NULL;
	char	*DMLProj		=  NULL;
	char	*TskNm			=  NULL;
	char	*TaskDesg		=  NULL;
	char	*DMLNo			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*Partno		=  NULL;
	char	*Toplnt		=  NULL;
	char	*PrtDRst		=  NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	int     count,j		=  0;
	int	rel_status_cunt	=  0;
	int	crr	=  0;
	int	ii	=  0;
	int	UpdateAllow	= 0;
	int	Tskcnt	= 0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	CMRefcount	= 0;
	char*	 Chld_Rel_Stus = NULL;
	tag_t DMLRevTag = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	PartTag	= NULLTAG;
	tag_t	AssyMstrtag	= NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t*	rel_status_lst	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *GMinfo5 =NULL;
	char   *ToValue =NULL;
	char   *FrmValueStr =NULL;
	char   *PRTSubStr =NULL;
	char   *relation_name =NULL;
	logical is_latest;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	int     DR_n_entry    = 1;
	int     PRTSTVAL      =  0;
	int     FrmValueIntg      =  0;
	int     RelRevFlag      =  0;
	int     DR_rsltCount      =  0;
	char DRStrng[20];
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n##....Inside Gate Maturation DML...\n",item_id);fflush(stdout);
	if(ITEM_find_item (item_id, &item_tag)!=ITK_ok)PrintErrorStack();
	//item_tag= t5GetItemRevison(item_id);
	if(item_tag==NULLTAG)
	{
		printf("\n GM:item_tag is NULL.\n");fflush(stdout);
		return 0;
	}
	else
	{
		printf("\n GM:item_tag found.\n");fflush(stdout);
		if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
		if(DMLTag==NULLTAG)
		{
			printf("\n Object not found in Teamcenter...!!\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n Object Found...!!");fflush(stdout);
			if(TCTYPE_ask_object_type(DMLTag,&objTypTag)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name(objTypTag,ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n DR: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//DML Details:
				if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
				printf("\n GM: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s]",DMLtype,DMLProj,PlntToPlnt);fflush(stdout);
				if(tc_strcmp(DMLtype,"TODR")==0)
				{
					if(QRY_find("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "CREVali";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n CREVali:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&GMinfo5)!=ITK_ok)   PrintErrorStack();
						printf("\n GMinfo5 is  = [%s]\n", GMinfo5);fflush(stdout);
					}

					if(PlntToPlnt!=NULL)
					{
						//AR0 to AR1
						if(tc_strstr(GMinfo5,PlntToPlnt) != NULL)
						{
							if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0))
							{
								//DR3P to DR4
								printf("GM:P2:Plant to plant:%s",PlntToPlnt);fflush(stdout);
								FromPlnt=subString(PlntToPlnt, 0, 4);
								Toplnt=subString(PlntToPlnt, 8, 3);

								ToValue=NULL;
								ToValue=subString(Toplnt, 2, 1);
								printf("\n GM:P2: ToValue: %s",ToValue);fflush(stdout);
								FrmValueIntg=0;
								FrmValueStr=NULL;
								FrmValueStr=subString(FromPlnt, 2, 1);
								FrmValueIntg=atoi(FrmValueStr);
								printf("\n GM:P2: FrmValueStr: %s, FrmValueIntg: %d",FrmValueStr,FrmValueIntg);fflush(stdout);
							}
							else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
							{
								//AR3 to AR3P
								printf("GM:P1:Plant to plant:%s",PlntToPlnt);fflush(stdout);
								FromPlnt=subString(PlntToPlnt, 0, 3);
								Toplnt=subString(PlntToPlnt, 7, 4);

								ToValue=NULL;
								ToValue=subString(Toplnt, 2, 2);
								printf("\n GM:P1: ToValue: %s",ToValue);fflush(stdout);
								FrmValueIntg=0;
								FrmValueStr=NULL;
								FrmValueStr=subString(FromPlnt, 2, 1);
								FrmValueIntg=atoi(FrmValueStr);
								printf("\n GM:P1: FrmValueStr: %s, FrmValueIntg: %d",FrmValueStr,FrmValueIntg);fflush(stdout);
							}
							else
							{
								//DR3 to DR4
								FromPlnt=subString(PlntToPlnt, 0, 3);
								Toplnt=subString(PlntToPlnt, 7, 3);
								printf("\n GM:P3: FromPlnt:[%s] FromPlnt:[%s]\n", FromPlnt,Toplnt);fflush(stdout);
								ToValue=NULL;
								ToValue=subString(Toplnt, 2, 1);
								printf("\n GM:P3: ToValue: %s",ToValue);fflush(stdout);
								FrmValueIntg=0;
								FrmValueStr=NULL;
								FrmValueStr=subString(FromPlnt, 2, 1);
								FrmValueIntg=atoi(FrmValueStr);
								printf("\n GM:P3: FrmValueStr: %s, FrmValueIntg: %d",FrmValueStr,FrmValueIntg);fflush(stdout);
							}

							Tskcnt=0;
							if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
							printf("\n GM:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
							if (Tskcnt>0)
							{
								for (tsk=0;tsk<Tskcnt ;tsk++ )
								{
									if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
									printf("\n GM:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

									if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
										if(TaskDsgGrp) TaskDsgGrp=NULL;
										if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
										TaskDsgGrp=subString(TskNm,11,2);
										printf("\n GM: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
										if(tc_strstr(TskNm,"CO")==NULL)
										{
											if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
											if (tsk_CMRef_type!=NULLTAG)
											{
												CMRefcount=0;
												if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
												printf("\n GM: Task CMRefcount: %d",CMRefcount);fflush(stdout);
												if(CMRefcount > 0)
												{
													Mstr=0;
													for (Mstr=0;Mstr<CMRefcount ;Mstr++)
													{
														printf("\n GM:Design Mstr:%d",Mstr);fflush(stdout);
														if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
														// put condition for desi rev , to avoid other attachments.
														if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
														printf("\n GM:Part Mstr_no:%s",PartMstr_no);	fflush(stdout);
														Item_count=0;
														//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
														All_item_tag= t5GetItemRevison(PartMstr_no);
														if(All_item_tag==NULLTAG)
														{
															printf("\n GM:ERROR:All_item_tag is NULL.\n");fflush(stdout);
															//return 0;
														}
														else
														{
															if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
															printf("\n GM:Total rev found: %d.", Item_count);fflush(stdout);
															if(Item_count > 0)
															{
																ii=0;
																for(ii=Item_count-1;ii>=0;ii--)
																{
																	rel_status_cunt=0;
																	if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																	if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																	if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																	printf("\n GM:Part %s rev:%s and Rel Status:%s", Partno,rev_idd,rel_status);fflush(stdout);
																	//Release status.
																	if(WSOM_ask_release_status_list (rev_list[ii], &rel_status_cunt, &rel_status_lst)!=ITK_ok)PrintErrorStack();
																	printf("\n DR:rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);
																	if(rel_status_cunt > 0)
																	{
																		crr=0;
																		RelRevFlag=0;
																		for(crr=0;crr<rel_status_cunt;crr++)
																		{
																			if(AOM_ask_value_string (rel_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
																			printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
																			if((tc_strstr(rel_status,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
																			{
																				RelRevFlag=1;
																				PrtDRst=NULL;
																				if(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&PrtDRst)!=ITK_ok)PrintErrorStack();
																				printf("\n GM: Partno:%s rev_idd:%s PrtDRst:%s Toplnt:%s", Partno,rev_idd,PrtDRst,Toplnt);fflush(stdout);
																				if((tc_strcmp(PrtDRst,"")==0) || (tc_strcmp(PrtDRst,"NA")==0))
																				{
																					printf("\n GM:A:Part updation...");fflush(stdout);
																					if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																					if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																					if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																					if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																					if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																					printf(" done for part:%s\n",Partno);fflush(stdout);
																				}
																				else 
																				{
																					PRTSTVAL=0;
																					PRTSubStr=NULL;
																					if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR4")==0))
																					{
																						if ((tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0))
																						{
																							tc_strcpy(DRStrng,"");
																							if(tc_strstr(PrtDRst,"DR") != NULL)
																							{
																								tc_strcpy(DRStrng,"DR4");
																								if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																								if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																								if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																								printf("\n P1:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																							}
																							else
																							{
																								tc_strcpy(DRStrng,"AR4");
																								if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																								if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																								if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																								printf("\n P2:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																							}
																						}
																						else
																						{
																							printf("\n GM:Other DR-status part:%s\n",Partno);fflush(stdout);
																						}
																					}
																					else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
																					{
																						if ((tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0))
																						{
																							tc_strcpy(DRStrng,"");
																							if(tc_strstr(PrtDRst,"DR") != NULL)
																							{
																								tc_strcpy(DRStrng,"DR3P");
																								if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																								if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																								if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																								printf("\n P1:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																							}
																							else
																							{
																								tc_strcpy(DRStrng,"AR3P");
																								if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																								if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																								if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																								printf("\n P2:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																							}
																						}
																						else
																						{
																							printf("\n GM:Other DR-status part:%s\n",Partno);fflush(stdout);
																						}
																					}
																					else
																					{
																						PRTSubStr=subString(PrtDRst, 2, 1);
																						PRTSTVAL=atoi(PRTSubStr);
																						printf("\n GM: PRTSubStr: %s, PRTSTVAL: %d FrmValueIntg:%d ToValue:%s",PRTSubStr,PRTSTVAL,FrmValueIntg,ToValue);fflush(stdout);
																						//From plant value == Part current DR-status
																						if (FrmValueIntg == PRTSTVAL)
																						{
																							tc_strcpy(DRStrng,"");
																							if(tc_strstr(PrtDRst,"DR") != NULL)
																							{
																								tc_strcpy(DRStrng,"DR");
																							}
																							else
																							{
																								tc_strcpy(DRStrng,"AR");
																							}
																							tc_strcat(DRStrng,ToValue);
																							printf("\n GM:A:Part updation..with status:%s ",DRStrng);fflush(stdout);
																							if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																							if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																							if(AOM_save (rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																							printf(" done for part:%s\n",Partno);fflush(stdout);
																						}
																						else
																						{
																							printf("\n Part not allow for updation:%s\n",Partno);fflush(stdout);
																						}
																					}
																				}
																				break;
																			}
																		}
																		if (RelRevFlag >0)
																		{
																			break;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										else
										{
											printf("\n GM: No Expanssion for CO task.");fflush(stdout);
										}
									}
								}
							}
						}
					}
					else
					{
						//Blank value
						printf("\n GM: Blank value..");fflush(stdout);
					}
					if(TaskCMRef) MEM_free(TaskCMRef);
					if(rev_list) MEM_free(rev_list);
				}
				printf("\n GM: ......Updation Function end for GM DML.");fflush(stdout);
				//break;
			}
		}
	}

	return ifail;
}

