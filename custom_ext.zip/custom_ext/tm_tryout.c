#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/aom_prop.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <tccore/item_msg.h>
#include <pie/pie.h>
#include <Fnd0Participant/participant.h>

#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define POM_enquiry_desc_order 1
#define POM_enquiry_like 16001

int cnt = 0;
int cntFlag = 0;

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
int val(char c)
{
    if (c >= '0' && c <= '9')
        return (int)c - '0';
    else
        return (int)c - 'A' + 10;
}

int toDeci(char *str, int base)
{
    int len = strlen(str);
    int power = 1; // Initialize power of base
    int num = 0;  // Initialize result
    int i;
 
    // Decimal equivalent is str[len-1]*1 +
    // str[len-1]*base + str[len-1]*(base^2) + ...
    for (i = len - 1; i >= 0; i--)
    {
        // A digit in input number must be
        // less than number's base
        if (val(str[i]) >= base)
        {
           printf("Invalid Number");
           return -1;
        }
 
        num += val(str[i]) * power;
        power = power * base;
    }
 
    return num;
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

extern EPM_decision_t DLLAPI tryout_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
    int status3;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char * SetPrevRevNotification=NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char *type_name=NULL;

	char  *type_itemRev=NULL;
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char       *roleName=NULL;
	char *lcsToset=NULL;
   cnt = 0;
   cntFlag = 0;

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	printf("\n Calling std_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_signoff_checks_Func \n"); fflush(stdout);


	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	/*
	EPM_signoff_decision_t  	ddecision;
	char * 	comments;
	date_t  	decision_date;
	EPM_ask_signoff_decision(rootTask,&ddecision,&comments,&decision_date);
	
	if(ddecision=EPM_approve_decision)
	{
		printf("\n\n  Approved"); fflush(stdout);
	}
	else if(ddecision=EPM_reject_decision)
	{
		printf("\n\n  Rejected"); fflush(stdout);
	}
	else if(ddecision=EPM_no_decision)
	{
		printf("\n\n  no dec "); fflush(stdout);
	}
	else
	{
			printf("\n\n  errrrrr"); fflush(stdout);
	}
	*/

 	ITKCALL( TCTYPE_find_type("T5_TryoutRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);

			if (!SetStdRelErr) MEM_free(SetStdRelErr);
			SetStdRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetStdRelErr,"");

			if(tc_strcmp(type_itemRev,"T5_TryoutRevision" )==0)
			{
					char*	VQAReviewer;
					char*	ManReviewer;
					char*	TSReviewer;
					char*	VDReviewer;
					char*	QAReviewer;
					char*	STDReviewer;
					char*	QAHead;
					char*	FactHead;
					char*	SCMReviewer;
					char*	TOBatchSize;
					char*	TOVenName;
					char **TOArea;
					char*	TOTryOutDt;
					char*	TOFitment;
					char*	TOBatchSize1;
					char*	TOVinNo;
					char*	TOVinNo1;
					char*	TOVinNo2;
					char*	TOVinNo3;
					char*	TOVinNo4;
					char *  Errr = NULL;
					char	intBatchSStr[50];
					char	VinCntStr[50];
					int numarea=0;

						if (tc_strcmp(Errr,"NULL") !=0) MEM_free(Errr);
						Errr=(char *)MEM_alloc(3000);
						tc_strcpy(Errr," ");


					ITKCALL(AOM_ask_value_string(item_rev_tag, "item_id",&itemid));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVQAReviewer",&VQAReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOManReviewer",&ManReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOTSReviewer",&TSReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVDReviewer",&VDReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOQAReviewer",&QAReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOSTDReviewer",&STDReviewer));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOQAHead",&QAHead));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOFactHead",&FactHead));
					ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOSCMReviewer",&SCMReviewer));

					printf("\n itemid %s.....\n",itemid);fflush(stdout);
					printf("\n VQAReviewer %s.....\n",VQAReviewer);fflush(stdout);
					printf("\n ManReviewer %s.....\n",ManReviewer);fflush(stdout);
					printf("\n TSReviewer %s.....\n",TSReviewer);fflush(stdout);
					printf("\n VDReviewer %s.....\n",VDReviewer);fflush(stdout);
					printf("\n QAReviewer %s.....\n",QAReviewer);fflush(stdout);
					printf("\n STDReviewer %s.....\n",STDReviewer);fflush(stdout);
					printf("\n QAHead %s.....\n",QAHead);fflush(stdout);
					printf("\n FactHead %s.....\n",FactHead);fflush(stdout);
					printf("\n SCMReviewer %s.....\n",SCMReviewer);fflush(stdout);

			
					//if( (strlen(VQAReviewer)>0) && (strlen(ManReviewer)>0) && (strlen(TSReviewer)>0) && (strlen(VDReviewer)>0) && (strlen(QAReviewer)>0) && (strlen(STDReviewer)>0) && (strlen(QAHead)>0) && (strlen(FactHead)>0) && (strlen(SCMReviewer)>0) )
					if( (strlen(VQAReviewer)>0) && (strlen(ManReviewer)>0) && (strlen(TSReviewer)>0) && (strlen(VDReviewer)>0) && (strlen(QAReviewer)>0) && (strlen(STDReviewer)>0) ) // removed QAHead,FactHead,SCM REviewer as per discussion with nana 
					{
						printf("\n All participants given.. no prob");fflush(stdout);
					}
					else
					{
						printf("\n All participants not given.. prob\n");fflush(stdout);
						EMH_clear_errors();
						status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Assign all Reviewer before Sign Off Complete\nSelect Tryout -> Right Click -> Edit Properties -> Assign Reviewer");
						decision = EPM_nogo;
						return ITK_errStore;
						printf("\ndone\n");fflush(stdout);
					}
				

					if( tc_strcmp(CurrentTask,"TryOut VD Review" )==0 || tc_strcmp(CurrentTask,"Confirm Readiness" )==0)
					{
						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOBatchSize",&TOBatchSize));
						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVenName",&TOVenName));

						printf("\n TOBatchSize %s.....\n",TOBatchSize);fflush(stdout);
						printf("\n TOVenName %s.....\n",TOVenName);fflush(stdout);

						if( (strlen(TOBatchSize)>0) )
						{
							printf("\n  Batch Size given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Batch Size not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Batch Size.(Batch Size is mandatory for VD) \nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}


						if( (strlen(TOVenName)>0) )
						{
							printf("\n  Vendor Name given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Vendor Name not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Vendor Name.(Vendor Name is mandatory for VD) \nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}

					if( tc_strcmp(CurrentTask,"TryOut TS Review" )==0 || tc_strcmp(CurrentTask,"TryOut TS/APL Review" )==0)
					{
						//ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOArea",&TOArea));
						ITKCALL(AOM_ask_value_strings(item_rev_tag,"t5_TOArea",&numarea,&TOArea));
						//printf("\n TOArea %s.....\n",TOArea);fflush(stdout);
						printf("\n numarea %d.....\n",numarea);fflush(stdout);

						if( (numarea>0) )
						{
							printf("\n  Area given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Area not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Area/Subarea and Affected Shops.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}


					if( tc_strcmp(CurrentTask,"TryOut Manufacturing Review" )==0 )
					{
						//ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOTryOutDt",&TOTryOutDt));
						ITKCALL(AOM_UIF_ask_value(item_rev_tag,"t5_TOTryOutDt",&TOTryOutDt));
						printf("\n TOTryOutDt %s.....\n",TOTryOutDt);fflush(stdout);

						if( (strlen(TOTryOutDt)>0) )
						{
							printf("\n  Tryout Date given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Tryout Date not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Tryout Date.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

					}


					if( tc_strcmp(CurrentTask,"TryOut CQ Review" )==0 )
					{
						int			intBatchS		= 0;

						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOFitment",&TOFitment));
						printf("\n TOFitment %s.....\n",TOFitment);fflush(stdout);

						if( (strlen(TOFitment)>0) )
						{
							printf("\n  Tryout Fitment given.. no prob");fflush(stdout);
						}
						else
						{
							printf("\n Tryout Fitment not given.. prob");fflush(stdout);
							EMH_clear_errors();
							status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease Enter Fitment Disposition.\nSelect Tryout, Manufacturing -> Implementation -> Tryout -> Update Tryout ");
							decision = EPM_nogo;
							return ITK_errStore;
						}

						ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOBatchSize",&TOBatchSize1));
						printf("\n TOBatchSize1 %s.....\n",TOBatchSize1);fflush(stdout);

						intBatchS=atoi(TOBatchSize1);
						printf("\n  intBatchS:[%d]",intBatchS);fflush(stdout);
						
						if(intBatchS>0)
						{
							int VinCnt=0;

							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo",&TOVinNo));
							printf("\n TOVinNo %s.....\n",TOVinNo);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo1",&TOVinNo1));
							printf("\n TOVinNo1 %s.....\n",TOVinNo1);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo2",&TOVinNo2));
							printf("\n TOVinNo2 %s.....\n",TOVinNo2);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo3",&TOVinNo3));
							printf("\n TOVinNo3 %s.....\n",TOVinNo3);fflush(stdout);
							ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_TOVinNo4",&TOVinNo4));
							printf("\n TOVinNo4 %s.....\n",TOVinNo4);fflush(stdout);

							if( (strlen(TOVinNo)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo1)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo2)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo3)>0) )
							{
								VinCnt++;
							}
							if( (strlen(TOVinNo4)>0) )
							{
								VinCnt++;
							}

							printf("\n  VinCnt:[%d]",VinCnt);fflush(stdout);

							  if(intBatchS==VinCnt)
							 	{
							 		printf("\nValidation Pass For BatchSize1==VinCnt\n"); fflush(stdout);
							 	}
							 	else if(intBatchS<VinCnt)
							 	{
									printf("\nVin no are Greter Then Batch Size BatchSize1<VinCnt\n"); fflush(stdout);
									sprintf(intBatchSStr,"%d",intBatchS);
									sprintf(VinCntStr,"%d",VinCnt);
									printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
									printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

									//Softcheck
									/*
									   *.TXT t5TryOutBatchSizeConfim1
									   *.Batch Size entered is #BATCHSIZE3# and VIN NO Entered are #VIN3#.
									   *.Batch Size is less then Number of VIN NO Entered, Still Wants to Continue.
									   *.HLP
									   *.For Any Query Please contact PLM Admin.
									*/
							 
							 	}
								else if(intBatchS>VinCnt)
								{    
									printf("\nValidation Error For BatchSize1>VinCnt\n"); fflush(stdout);
									if( intBatchS>5 && VinCnt==5 )
									 {
									 	printf("\nValidation Pass For BatchSize1>VinCnt\n"); fflush(stdout);
									 }
								    else if(intBatchS>=5&&VinCnt<5)
									{
										printf("\nYou Must Enter 5 Vin No Because Batch Size if Greter Then 5\n"); fflush(stdout);
										sprintf(intBatchSStr,"%d",intBatchS);
										sprintf(VinCntStr,"%d",VinCnt);
										printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
										printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

										tc_strcat(Errr,"\nBatch Size entered is ");
										tc_strcat(Errr,intBatchSStr);
										tc_strcat(Errr," and VIN NO Entered are ");
										tc_strcat(Errr,VinCntStr);
										tc_strcat(Errr,"\nIf Batch Size is Greater than or Equals to 5 Then You must have to Enter 5 VIN NO.");
										
										printf("\n Tryout Fitment not given.. prob");fflush(stdout);
										EMH_clear_errors();
										status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
										decision = EPM_nogo;
										return ITK_errStore;


									}else if(intBatchS<=5&&VinCnt<5)
									{
										printf("\nBatch Size and Vin No Count is not matched for Please Fill VIN No\n"); fflush(stdout);
										sprintf(intBatchSStr,"%d",intBatchS);
										sprintf(VinCntStr,"%d",VinCnt);
										printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);
										printf("\n VinCntStr: [%s]\n",VinCntStr); fflush(stdout);

										tc_strcat(Errr,"\nBatch Size entered is ");
										tc_strcat(Errr,intBatchSStr);
										tc_strcat(Errr," and VIN NO Entered are ");
										tc_strcat(Errr,VinCntStr);
										tc_strcat(Errr,"\nIf Batch Size is less then or Equals to 5 Then You must have to Enter Equivalent VIN NO");

										printf("\n Tryout Fitment not given.. prob");fflush(stdout);
										EMH_clear_errors();
										status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
										decision = EPM_nogo;
										return ITK_errStore;
									}
								    else
								    {
								    	printf("\nCondition Pass\n"); fflush(stdout);
								    }
								}  
								else
								{
									printf("\nCondition Pass1\n"); fflush(stdout);
								}

						}
						else
						{
							printf("\n else ...."); fflush(stdout);
							sprintf(intBatchSStr,"%d",intBatchS);
							printf("\n intBatchSStr: [%s]\n",intBatchSStr); fflush(stdout);

							//Softcheck
							/*
							   *.TXT t5TryOutBatchSizeConfim2
							   *.Batch Size entered is #BATCHSIZE4# Or Less Then Zero.
							   *.Still Wants to Continue.
							   *.HLP
							   *.For Any Query Please contact PLM Admin.
							*/


						}

											



					}

			}
       }
  }
 
 CLEANUP:
	 printf("\n hi ..inside cleanup");fflush(stdout);
	decision = EPM_go;
	return decision;
}


void  GetTryoutPlant( char * TryoutPlant ,char  PlantF[40])
{
		printf( "\n GetTryoutPlant TryoutPlant:%s", TryoutPlant);fflush(stdout);

			if(tc_strcmp(TryoutPlant,"CAR")==0)
			{
				strcpy(PlantF,"Z");
			}
			else if(tc_strcmp(TryoutPlant,"CVBU JSR")==0)
			{
				strcpy(PlantF,"J");
			}
			else if(tc_strcmp(TryoutPlant,"CVBU LKO")==0)
			{
				strcpy(PlantF,"L");
			}
			else if(tc_strcmp(TryoutPlant,"CVBU PNR")==0)
			{
				strcpy(PlantF,"U");
			}
			else if(tc_strcmp(TryoutPlant,"CVBU PUNE")==0)
			{
				strcpy(PlantF,"C");
			}
			else if(tc_strcmp(TryoutPlant,"PCBU")==0)
			{
				strcpy(PlantF,"P");
			}
			else if(tc_strcmp(TryoutPlant,"PCBU and CVBU")==0)
			{
				strcpy(PlantF,"P");
			}
			else if(tc_strcmp(TryoutPlant,"PCBU LKO")==0)
			{
				strcpy(PlantF,"L");
			}
			else if(tc_strcmp(TryoutPlant,"SMALLCAR AHD")==0)
			{
				strcpy(PlantF,"S");
			}
			else if(tc_strcmp(TryoutPlant,"SMALLCAR PNR")==0)
			{
				strcpy(PlantF,"U");
			}
			else if(tc_strcmp(TryoutPlant,"DHARWAD")==0)
			{
				strcpy(PlantF,"D");
			}
			else if(tc_strcmp(TryoutPlant,"TMLDL JSR")==0)
			{
				strcpy(PlantF,"J");
			}
			else if(tc_strcmp(TryoutPlant,"PUVBU")==0)
			{
				strcpy(PlantF,"V");
			}
			else
			{
				strcpy(PlantF,TryoutPlant);
			}
	printf( "\n PlantF:%s", PlantF);fflush(stdout);

}

void  GetTryoutAggregate( char * Aggregate ,char  Aggregt[40])
{
		printf( "\n GetTryoutAggregate Aggregate:%s", Aggregate);fflush(stdout);

			if(tc_strcmp(Aggregate,"Trims")==0)
			{
				strcpy(Aggregt,"TR");
			}
			else if(tc_strcmp(Aggregate,"Chassis")==0)
			{
				strcpy(Aggregt,"CH");
			}
			else if(tc_strcmp(Aggregate,"Electricals")==0)
			{
				strcpy(Aggregt,"EL");
			}
			else if(tc_strcmp(Aggregate,"Engine")==0)
			{
				strcpy(Aggregt,"EN");
			}
			else if(tc_strcmp(Aggregate,"Transaxle")==0)
			{
				strcpy(Aggregt,"TA");
			}
			else if(tc_strcmp(Aggregate,"BIW")==0)
			{
				strcpy(Aggregt,"BI");
			}
			else if(tc_strcmp(Aggregate,"Axle")==0)
			{
				strcpy(Aggregt,"AX");
			}
			else if(tc_strcmp(Aggregate,"Propeller Shaft")==0)
			{
				strcpy(Aggregt,"PS");
			}
			else if(tc_strcmp(Aggregate,"Streeing")==0)
			{
				strcpy(Aggregt,"ST");
			}
			else if(tc_strcmp(Aggregate,"Frame")==0)
			{
				strcpy(Aggregt,"FM");
			}
			else if(tc_strcmp(Aggregate,"VQA")==0)
			{
				strcpy(Aggregt,"VQ");
			}
			else if(tc_strcmp(Aggregate,"Gear Box")==0)
			{
				strcpy(Aggregt,"GB");
			}
			else if(tc_strcmp(Aggregate,"Front Suspension")==0)
			{
				strcpy(Aggregt,"FS");
			}
			else if(tc_strcmp(Aggregate,"Rear Suspension")==0)
			{
				strcpy(Aggregt,"RS");
			}
			else if(tc_strcmp(Aggregate,"Cooling System")==0)
			{
				strcpy(Aggregt,"CS");
			}
			else if(tc_strcmp(Aggregate,"Power Streeing")==0)
			{
				strcpy(Aggregt,"PO");
			}
			else if(tc_strcmp(Aggregate,"Brakes")==0)
			{
				strcpy(Aggregt,"BR");
			}
			else if(tc_strcmp(Aggregate,"Fuel System")==0)
			{
				strcpy(Aggregt,"FL");
			}
			else if(tc_strcmp(Aggregate,"Tyres & Wheels")==0)
			{
				strcpy(Aggregt,"TW");
			}
			else if(tc_strcmp(Aggregate,"Transfer Lables & Mascots")==0)
			{
				strcpy(Aggregt,"LM");
			}
			else if(tc_strcmp(Aggregate,"Glass")==0)
			{
				strcpy(Aggregt,"GL");
			}
			else if(tc_strcmp(Aggregate,"Exhaust System")==0)
			{
				strcpy(Aggregt,"ES");
			}
			else if(tc_strcmp(Aggregate,"HVAC")==0)
			{
				strcpy(Aggregt,"HV");
			}
			else if(tc_strcmp(Aggregate,"Transmission")==0)
			{
				strcpy(Aggregt,"TM");
			}
			else if(tc_strcmp(Aggregate,"Control System")==0)
			{
				strcpy(Aggregt,"CT");
			}
			else if(tc_strcmp(Aggregate,"Engine Mounts")==0)
			{
				strcpy(Aggregt,"EM");
			}
			else if(tc_strcmp(Aggregate,"Accelarator")==0)
			{
				strcpy(Aggregt,"AL");
			}
			else if(tc_strcmp(Aggregate,"Front Axle")==0)
			{
				strcpy(Aggregt,"FA");
			}
			else if(tc_strcmp(Aggregate,"Rear Axle")==0)
			{
				strcpy(Aggregt,"RA");
			}
			else if(tc_strcmp(Aggregate,"Load Body")==0)
			{
				strcpy(Aggregt,"LB");
			}
			else if(tc_strcmp(Aggregate,"Air Intake System")==0)
			{
				strcpy(Aggregt,"AI");
			}
			else if(tc_strcmp(Aggregate,"Fial_Trims")==0)
			{
				strcpy(Aggregt,"FT");
			}
			else if(tc_strcmp(Aggregate,"Fial_Chassis")==0)
			{
				strcpy(Aggregt,"FC");
			}
			else if(tc_strcmp(Aggregate,"Fial_Electricals")==0)
			{
				strcpy(Aggregt,"FE");
			}
			else if(tc_strcmp(Aggregate,"Fial_Engine")==0)
			{
				strcpy(Aggregt,"FG");
			}
			else if(tc_strcmp(Aggregate,"Fial_Transaxle")==0)
			{
				strcpy(Aggregt,"FX");
			}
			else
			{
				strcpy(Aggregt,Aggregate);
			}

	printf( "\n Aggregt:%s", Aggregt);fflush(stdout);

}

void  GetTryoutSrlNo( char * AggregtValQry ,char  TryNewNo[40])
{
	printf( "\n inside GetTryoutSrlNo :%s", AggregtValQry);fflush(stdout);

					int cnttSkpRev=0;
					tag_t			CntrlTagSkpRev		= NULLTAG;
					tag_t query1SkpRev = NULLTAG;
					int n_entries1SkpRev=1;
					int n_found1SkpRev=0;
  				    tag_t	*CntrlObjsSkpRev	= NULLTAG;
					int				max_char_size		= 100;
					
					char *NxtNo 	   = NULL;
					int				tmp_int_nxt_srl		= 0;
					char tmp_str_nxt_srl[20];
					int				Deci_srl			= 0;
					char nxt_srl[20];
					int				int_nxt_srl			= 0;
					char* tmpStr	 	   = NULL;
					char* CRName	 	   = NULL;
					char* Lat_CRNm	 	   = NULL;
					char* creationdate	 	   = NULL;
					char* creationdate2	 	   = NULL;
					char* CRName2	 	   = NULL;
					char* Date_Created	 	   = NULL;
					int iCntl2=0;

					char
					 *qry_entrySkpRev[1] = {"ID"},
					 *qry_vallSkpRev[1] =  {AggregtValQry};

					ITKCALL(QRY_find2("tm_GetLatestTryoutQry", &query1SkpRev));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1SkpRev, n_entries1SkpRev, qry_entrySkpRev, qry_vallSkpRev, &n_found1SkpRev, &CntrlObjsSkpRev));
					printf("\n n_found1SkpRev: %d", n_found1SkpRev);fflush(stdout);

					if(n_found1SkpRev>0)
					{
							CntrlTagSkpRev=NULLTAG;
							CntrlTagSkpRev=CntrlObjsSkpRev[0];

							//Get Latest Tryout
							ITKCALL(AOM_UIF_ask_value(CntrlTagSkpRev,"creation_date",&creationdate));												
								AOM_ask_value_string(CntrlTagSkpRev, "item_id", &CRName);
								printf("\n\n creationdate : %s, CRName : %s",creationdate,CRName);fflush(stdout);
								
								Lat_CRNm=NULL;
								Lat_CRNm=(char *)MEM_alloc(max_char_size * sizeof(char));
								strcpy(Lat_CRNm,CRName);
								printf("\n Lat_CRNm:%s",Lat_CRNm);fflush(stdout);

								Date_Created=NULL;
								Date_Created=(char *)MEM_alloc(max_char_size * sizeof(char));
								strcpy(Date_Created,creationdate);
								

								for (iCntl2=0;iCntl2<n_found1SkpRev;iCntl2++ )
								{
									ITKCALL(AOM_UIF_ask_value(CntrlObjsSkpRev[iCntl2],"creation_date",&creationdate2));
									AOM_ask_value_string( CntrlObjsSkpRev[iCntl2], "item_id", &CRName2);
									printf("\n\n creationdate2 : %s, CRName2 : %s",creationdate2,CRName2);fflush(stdout);
									printf("\n\n Date_Created : %s",Date_Created);fflush(stdout);

									if(strcmp(Date_Created,creationdate2) <= 0)
									{
										Lat_CRNm=NULL;
										Lat_CRNm=(char *)MEM_alloc(max_char_size * sizeof(char));
										strcpy(Lat_CRNm,CRName2);
										printf("\n hi Lat_CRNm:%s",Lat_CRNm);fflush(stdout);
										Date_Created=NULL;
										Date_Created=(char *)MEM_alloc(max_char_size * sizeof(char));
										strcpy(Date_Created,creationdate2);
									}						
								}

							 printf("\n Latest Tryout is:[%s]",Lat_CRNm);fflush(stdout);	

							 NxtNo = subString(Lat_CRNm,4,4);

							 tmp_int_nxt_srl=(atoi(NxtNo)+1);
							 sprintf(tmp_str_nxt_srl,"%d",tmp_int_nxt_srl);	
							printf("\n tmp_str_nxt_srl:%s",tmp_str_nxt_srl);fflush(stdout);
							Deci_srl=toDeci(tmp_str_nxt_srl,10);

							printf("\n Deci_srl:%d",Deci_srl);fflush(stdout);

							int_nxt_srl=Deci_srl;
							printf("\n int_nxt_srl:%d",int_nxt_srl);fflush(stdout);
							sprintf(nxt_srl,"%d",int_nxt_srl);
							printf("converted to string %s \n",nxt_srl);fflush(stdout);
							
								tmpStr=NULL;
								tmpStr=(char *)MEM_alloc(max_char_size * sizeof(char));			

								if( strlen(nxt_srl) == 1)
								{
									strcpy(tmpStr,"000");
								}
								else
								if( strlen(nxt_srl) == 2)
								{
									strcpy(tmpStr,"00");
								}
								else
								if( strlen(nxt_srl) == 3)
								{
									strcpy(tmpStr,"0");
								}
								else
								if( strlen(nxt_srl) == 4)
								{
									strcpy(tmpStr,"");
								}
								strcat(tmpStr,nxt_srl);
								strcpy(TryNewNo,tmpStr);
					}
					else
					{
						strcpy(TryNewNo,"0000");
					}


	printf( "\n TryNewNo:%s", TryNewNo);fflush(stdout);

}


void  GetPlantWiseTryoutRoles( char * roleName ,char  TRYOUT_TS_role[40],char  TRYOUT_ADMIN_role[40],char  TRYOUT_CQ_role[40],char  TRYOUT_FACTHEAD_role[40],char  TRYOUT_Manufacturing_role[40],char  TRYOUT_QAHEAD_role[40],char TRYOUT_SCM_role[40],char TRYOUT_VD_role[40],char TRYOUT_VQA_role[40])
{
  
	  printf( "inside GetPlantWiseTryoutRoles roleName:%s\n", roleName);fflush(stdout);
	 	
		if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"CAR"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CAR");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CAR");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CAR");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CAR");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CAR");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CAR");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CAR");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CAR");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CAR");
		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"CVJSR"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CVJSR");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CVJSR");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CVJSR");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CVJSR");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CVJSR");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CVJSR");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CVJSR");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CVJSR");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CVJSR");
			
		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"CVPUNE"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CVPUNE");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CVPUNE");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CVPUNE");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CVPUNE");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CVPUNE");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CVPUNE");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CVPUNE");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CVPUNE");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CVPUNE");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"CVLKO"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CVLKO");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CVLKO");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CVLKO");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CVLKO");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CVLKO");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CVLKO");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CVLKO");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CVLKO");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CVLKO");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"CVPNR"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CVPNR");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CVPNR");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CVPNR");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CVPNR");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CVPNR");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CVPNR");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CVPNR");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CVPNR");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CVPNR");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"PVPUNE"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_PVPUNE");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_PVPUNE");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_PVPUNE");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_PVPUNE");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_PVPUNE");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_PVPUNE");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_PVPUNE");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_PVPUNE");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_PVPUNE");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"PVLKO"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_PVLKO");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_PVLKO");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_PVLKO");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_PVLKO");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_PVLKO");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_PVLKO");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_PVLKO");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_PVLKO");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_PVLKO");
		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"UVPUNE"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_UVPUNE");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_UVPUNE");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_UVPUNE");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_UVPUNE");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_UVPUNE");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_UVPUNE");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_UVPUNE");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_UVPUNE");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_UVPUNE");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"PVAHD"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_PVAHD");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_PVAHD");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_PVAHD");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_PVAHD");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_PVAHD");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_PVAHD");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_PVAHD");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_PVAHD");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_PVAHD");

		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"PVPNR"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_PVPNR");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_PVPNR");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_PVPNR");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_PVPNR");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_PVPNR");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_PVPNR");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_PVPNR");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_PVPNR");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_PVPNR");


		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"DWD"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_DWD");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_DWD");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_DWD");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_DWD");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_DWD");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_DWD");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_DWD");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_DWD");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_DWD");
		}
		else if(strstr(roleName,"TRYOUT") &&  strstr(roleName,"TMLDLJSR"))
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_TMLDLJSR");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_TMLDLJSR");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_TMLDLJSR");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_TMLDLJSR");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_TMLDLJSR");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_TMLDLJSR");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_TMLDLJSR");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_TMLDLJSR");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_TMLDLJSR");
		}
		else
		{
			tc_strcpy(TRYOUT_TS_role,"TRYOUT_TS_CVPUNE");
			tc_strcpy(TRYOUT_ADMIN_role,"TRYOUT_ADMIN_CVPUNE");
			tc_strcpy(TRYOUT_CQ_role,"TRYOUT_CQ_CVPUNE");
			tc_strcpy(TRYOUT_FACTHEAD_role,"TRYOUT_FACTHEAD_CVPUNE");
			tc_strcpy(TRYOUT_Manufacturing_role,"TRYOUT_MFG_CVPUNE");
			tc_strcpy(TRYOUT_QAHEAD_role,"TRYOUT_QAHEAD_CVPUNE");
			tc_strcpy(TRYOUT_SCM_role,"TRYOUT_SCM_CVPUNE");
			tc_strcpy(TRYOUT_VD_role,"TRYOUT_VD_CVPUNE");
			tc_strcpy(TRYOUT_VQA_role,"TRYOUT_VQA_CVPUNE");

		}

}

void  GetCurrentYear( char  Cur_Yearr[40])
{
	printf( "\n GetCurrentYear ");fflush(stdout);

	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);
	printf("\n strYear : %s\n",strYear);fflush(stdout);
	
	char *YearLasttwo 	   = NULL;
	YearLasttwo = subString(strYear,2,2);

	strcpy(Cur_Yearr,YearLasttwo);
	printf( "\n Cur_Yearr:%s", Cur_Yearr);fflush(stdout);

}

int Save_Tryout_Msg( METHOD_message_t *msg, va_list  args )
{
    tag_t	TaskTag		= va_arg(args, const tag_t);
	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *item_id 			= NULL;
	char *TryoutPlant 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *groupName 	   = NULL;
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;

	char *TOTSReviewer 	   = NULL;
	char *TOVDReviewer 	   = NULL;
	char *TOQAHead 	   = NULL;
	char *TOVQAReviewer 	   = NULL;
	char *TOSTDReviewer 	   = NULL;
	char *TOFactHead 	   = NULL;
	char *TOManReviewer 	   = NULL;
	char *TOQAReviewer 	   = NULL;
	char *TOSCMReviewer 	   = NULL;

	//const char*   CR_EM_role = "CR_ERC_EM";
char       *roleName=NULL;
	char TRYOUT_TS_role[40];
	char TRYOUT_ADMIN_role[40];
	char TRYOUT_CQ_role[40];
	char TRYOUT_FACTHEAD_role[40];
	char TRYOUT_Manufacturing_role[40];
	char TRYOUT_QAHEAD_role[40];
	char TRYOUT_SCM_role[40];
	char TRYOUT_VD_role[40];
	char TRYOUT_VQA_role[40];
tag_t  CurrentRoleTag = NULLTAG;
/*
	const char*   TRYOUT_TS_role = "TRYOUT-TS";
	const char*   TRYOUT_ADMIN_role = "TRYOUT-ADMIN";
	const char*   TRYOUT_CQ_role = "TRYOUT-CQ";
	const char*   TRYOUT_FACTHEAD_role = "TRYOUT-FACTHEAD";
	const char*   TRYOUT_Manufacturing_role = "TRYOUT-Manufacturing";
	const char*   TRYOUT_QAHEAD_role = "TRYOUT-QAHEAD";
	const char*   TRYOUT_SCM_role = "TRYOUT-SCM";
	const char*   TRYOUT_VD_role = "TRYOUT-VD";
	const char*   TRYOUT_VQA_role = "TRYOUT-VQA";
*/
	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;
	tag_t			user_tag			= NULLTAG;

	char   *type_name=NULL;
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name3[TCTYPE_name_size_c+1];
	char   *userid=NULL;
	WSO_search_criteria_t  	criteria;

	groupName = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"TRYOUT");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

    printf("\n **************inside Save_Tryout_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject: {%s}\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_TryoutRevision")==0)
	{
		    printf("\n inside class T5_TryoutRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskTag, "item_id", &item_id);
			printf("\n inside class T5_TryoutRevision item_id......: %s",item_id);fflush(stdout);

			AOM_ask_value_string( TaskTag, "t5_Plant", &TryoutPlant);
			printf("\n inside class T5_TryoutRevision TryoutPlant......: %s",TryoutPlant);fflush(stdout);

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			GetPlantWiseTryoutRoles(roleName,TRYOUT_TS_role,TRYOUT_ADMIN_role,TRYOUT_CQ_role,TRYOUT_FACTHEAD_role,TRYOUT_Manufacturing_role,TRYOUT_QAHEAD_role,TRYOUT_SCM_role,TRYOUT_VD_role,TRYOUT_VQA_role);
			printf("\n TRYOUT_TS_role:  %s \n",TRYOUT_TS_role);fflush(stdout);
			printf("\n TRYOUT_ADMIN_role:  %s \n",TRYOUT_ADMIN_role);fflush(stdout);
			printf("\n TRYOUT_CQ_role:  %s \n",TRYOUT_CQ_role);fflush(stdout);
			printf("\n TRYOUT_FACTHEAD_role:  %s \n",TRYOUT_FACTHEAD_role);fflush(stdout);
			printf("\n TRYOUT_Manufacturing_role:  %s \n",TRYOUT_Manufacturing_role);fflush(stdout);
			printf("\n TRYOUT_QAHEAD_role:  %s \n",TRYOUT_QAHEAD_role);fflush(stdout);
			printf("\n TRYOUT_SCM_role:  %s \n",TRYOUT_SCM_role);fflush(stdout);
			printf("\n TRYOUT_VD_role:  %s \n",TRYOUT_VD_role);fflush(stdout);
			printf("\n TRYOUT_VQA_role:  %s \n",TRYOUT_VQA_role);fflush(stdout);

			//TS/APL Reviewer
			//VD/AQ REviewer
			//QA-Head Permission
			//VQA Reviewer
			//Admin/STDSI Reviewer
			//Factory-Head Permission
			//Mfg/CX Reviewer
			//CQ/Final-QA Reviewer
			//SCM Reviewer

			AOM_ask_value_string( TaskTag,"t5_TOTSReviewer", &TOTSReviewer);
			printf("\n inside class T5_TryoutRevision TOTSReviewer......: %s",TOTSReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOVDReviewer", &TOVDReviewer);
			printf("\n inside class T5_TryoutRevision TOVDReviewer......: %s",TOVDReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOQAHead", &TOQAHead);
			printf("\n inside class T5_TryoutRevision TOQAHead......: %s",TOQAHead);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOVQAReviewer", &TOVQAReviewer);
			printf("\n inside class T5_TryoutRevision TOVQAReviewer......: %s",TOVQAReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOSTDReviewer", &TOSTDReviewer);
			printf("\n inside class T5_TryoutRevision TOSTDReviewer......: %s",TOSTDReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOFactHead", &TOFactHead);
			printf("\n inside class T5_TryoutRevision TOFactHead......: %s",TOFactHead);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOManReviewer", &TOManReviewer);
			printf("\n inside class T5_TryoutRevision TOManReviewer......: %s",TOManReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOQAReviewer", &TOQAReviewer);
			printf("\n inside class T5_TryoutRevision TOQAReviewer......: %s",TOQAReviewer);fflush(stdout);

			AOM_ask_value_string( TaskTag,"t5_TOSCMReviewer", &TOSCMReviewer);
			printf("\n inside class T5_TryoutRevision TOSCMReviewer......: %s",TOSCMReviewer);fflush(stdout);

			int				count		= 0;
			int				stdCnt		= 0;
			tag_t			*ParticipantRel			= NULLTAG;
			tag_t			ParticipantRelTag		= NULLTAG;
			tag_t			ObjTypTask			= NULLTAG;
			char			*type_namee_task=NULL;
			char*			TaskAssignee		= NULL;

			GRM_find_relation_type("HasParticipant", &relation_type);
			CALLAPI(GRM_list_secondary_objects_only(TaskTag,relation_type,&count,&ParticipantRel));
			printf("\n 222 count :[%d]\n",count);fflush(stdout);

			if(count == 0) //TZ1.42 compilation by Deepti
			{
				printf("\n No issuess...");fflush(stdout);
			}
			else
			{
				for(stdCnt=0;stdCnt<count;stdCnt++)
				{
							printf("\n Inside remving the relation...");fflush(stdout);
							ParticipantRelTag=NULLTAG;
							ParticipantRelTag = ParticipantRel[stdCnt];
							
							printf("\n 11 Inside remving the relation...");fflush(stdout);
							ObjTypTask=NULLTAG;
							if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
							if(TCTYPE_ask_name2(ObjTypTask,&type_namee_task));
							printf("\n Task: Participants Name: %s", type_namee_task);fflush(stdout);

							if ((tc_strcmp(type_namee_task,"T5_TOTSReviewer")==0))
							{
								printf("\n Removing T5_TOTSReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOVDReviewer")==0))
							{
								printf("\n Removing T5_TOVDReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOQAHead")==0))
							{
								printf("\n Removing T5_TOQAHead");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOVQAReviewer")==0))
							{
								printf("\n Removing T5_TOVQAReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOSTDReviewer")==0))
							{
								printf("\n Removing T5_TOSTDReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOFactHead")==0))
							{
								printf("\n Removing T5_TOFactHead");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOManReviewer")==0))
							{
								printf("\n Removing T5_TOManReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOQAReviewer")==0))
							{
								printf("\n Removing T5_TOQAReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}

							if ((tc_strcmp(type_namee_task,"T5_TOSCMReviewer")==0))
							{
								printf("\n Removing T5_TOSCMReviewer");fflush(stdout);
								TaskAssignee=NULL;
								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
								AOM_lock(TaskTag);
								ITKCALL(PARTICIPANT_remove_participant (TaskTag,ParticipantRelTag)!=ITK_ok);
								AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
								AOM_unlock(TaskTag);
							}
				}

			}


			if(TOTSReviewer!=NULL)
			{
				printf("\n TOTSReviewer ....:[%s]",TOTSReviewer);fflush(stdout);

				//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOTSReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOTSReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOTSReviewer: %s\n",TOTSReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_TS_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOTSReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOTSReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOTSReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOTSReviewer userid:[%s]\n",userid);
						printf("\n TOTSReviewer [%s,%s]\n",TOTSReviewer,User_Id);

						//if(strcmp(member_name,TOTSReviewer)==0)
						//if(tc_strstr(TOTSReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOTSReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOTSReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok);
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOTSReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOVDReviewer!=NULL)
			{
				printf("\n TOVDReviewer ....:[%s]",TOVDReviewer);fflush(stdout);
				//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOVDReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);
					}
				//end of Getting User name from person name

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOVDReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOVDReviewer: %s\n",TOVDReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_VD_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOVDReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOVDReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOVDReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOVDReviewer userid:[%s]\n",userid);
						printf("\n TOVDReviewer [%s,%s]\n",TOVDReviewer,User_Id);

						//if(strcmp(member_name,TOVDReviewer)==0)
						//if(tc_strstr(TOVDReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOVDReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOVDReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOVDReviewer Assigned..DoneXXXX\n");
						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOQAHead!=NULL)
			{
				printf("\n TOQAHead ....:[%s]",TOQAHead);fflush(stdout);

				//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOQAHead};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name
				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOQAHead,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOQAHead: %s\n",TOQAHead);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);

				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_QAHEAD_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOQAHead CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOQAHead CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOQAHead member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOQAHead userid:[%s]\n",userid);
						printf("\n TOQAHead [%s,%s]\n",TOQAHead,User_Id);

						//if(strcmp(member_name,TOQAHead)==0)
						//if(tc_strstr(TOQAHead,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOQAHead assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOQAHead",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOQAHead Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOVQAReviewer!=NULL)
			{
				printf("\n TOVQAReviewer ....:[%s]",TOVQAReviewer);fflush(stdout);

					//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOVQAReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name
				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOVQAReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOVQAReviewer: %s\n",TOVQAReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_VQA_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOVQAReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOVQAReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOVQAReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOVQAReviewer userid:[%s]\n",userid);
						printf("\n TOVQAReviewer [%s,%s]\n",TOVQAReviewer,User_Id);

						//if(strcmp(member_name,TOVQAReviewer)==0)
						//if(tc_strstr(TOVQAReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOVQAReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOVQAReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOVQAReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOSTDReviewer!=NULL)
			{
				printf("\n TOSTDReviewer ....:[%s]",TOSTDReviewer);fflush(stdout);

					//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOSTDReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOSTDReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOSTDReviewer: %s\n",TOSTDReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);

				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_ADMIN_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOSTDReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOSTDReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOSTDReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOSTDReviewer userid:[%s]\n",userid);
						printf("\n TOSTDReviewer [%s,%s]\n",TOSTDReviewer,User_Id);

						//if(strcmp(member_name,TOSTDReviewer)==0)
						//if(tc_strstr(TOSTDReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOSTDReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOSTDReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOSTDReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOFactHead!=NULL)
			{
				printf("\n TOFactHead ....:[%s]",TOFactHead);fflush(stdout);

					//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOFactHead};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOFactHead,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOFactHead: %s\n",TOFactHead);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);


				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_FACTHEAD_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOFactHead CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOFactHead CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOFactHead member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOFactHead userid:[%s]\n",userid);
						printf("\n TOFactHead [%s,%s]\n",TOFactHead,User_Id);

						//if(strcmp(member_name,TOFactHead)==0)
						//if(tc_strstr(TOFactHead,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOFactHead assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOFactHead",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOFactHead Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOManReviewer!=NULL)
			{
				printf("\n TOManReviewer ....:[%s]",TOManReviewer);fflush(stdout);

					//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOManReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name

				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOManReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOManReviewer: %s\n",TOManReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);

				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_Manufacturing_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOManReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOManReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOManReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOManReviewer userid:[%s]\n",userid);
						printf("\n TOManReviewer [%s,%s]\n",TOManReviewer,User_Id);

						//if(strcmp(member_name,TOManReviewer)==0)
						//if(tc_strstr(TOManReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOManReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOManReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;

							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag); //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOManReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOQAReviewer!=NULL)
			{
				printf("\n TOQAReviewer ....:[%s]",TOQAReviewer);fflush(stdout);

									//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOQAReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];
							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);

							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name
				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOQAReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOQAReviewer: %s\n",TOQAReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);

				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_CQ_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOQAReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOQAReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOQAReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOQAReviewer userid:[%s]\n",userid);
						printf("\n TOQAReviewer [%s,%s]\n",TOQAReviewer,User_Id);

						//if(strcmp(member_name,TOQAReviewer)==0)
						//if(tc_strstr(TOQAReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOQAReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOQAReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOQAReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}


			if(TOSCMReviewer!=NULL)
			{
				printf("\n TOSCMReviewer ....:[%s]",TOSCMReviewer);fflush(stdout);

					//Getting User name from person name
				   	tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=1;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *User_Id 	   = NULL;
					char *obj_str 	   = NULL;

					char
					 *qry_entry[1] = {"Name"},
					 *qry_vall[1] =  {TOSCMReviewer};

					ITKCALL(QRY_find2("tm_FindUserByPerson", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[0];

							AOM_ask_value_string( CntrlTag, "user_id", &User_Id);
							printf("\n User_Id: %s\n",User_Id);fflush(stdout);
							
							obj_str=NULL;
							AOM_ask_value_string( CntrlTag, "object_string", &obj_str);
							printf("\n obj_str: %s\n",obj_str);fflush(stdout);

					}
				//end of Getting User name from person name
				char*			PersonName				= NULL;
				char*			Usr_ID				= NULL;
				char*			FinalUsrId				= NULL;
				PersonName=tc_strtok(TOSCMReviewer,"(");
				Usr_ID = tc_strtok(NULL,"_");
				printf("\n PersonName: %s\n",PersonName);fflush(stdout);
				printf("\n TOSCMReviewer: %s\n",TOSCMReviewer);fflush(stdout);
				printf("\n Usr_ID: %s\n",Usr_ID);fflush(stdout);
				FinalUsrId=tc_strtok(Usr_ID,")");
				printf("\n FinalUsrId: %s\n",FinalUsrId);fflush(stdout);

				Grp_tag1=NULLTAG;
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();

				CR_GrHd_Tag			= NULLTAG;
				if(SA_find_role2(TRYOUT_SCM_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();

				GHTags		= NULLTAG;
				No_GH=0;
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n TOSCMReviewer CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					ii=0;
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n TOSCMReviewer CR:EM no: [%d]",ii);fflush(stdout);
						member_name=NULL;
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						printf("\n TOSCMReviewer member_name :[%s]\n",member_name);

						user_tag=NULLTAG;
						CALLAPI(SA_ask_groupmember_user(GHTags[ii],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));

						printf("\n TOSCMReviewer userid:[%s]\n",userid);
						printf("\n TOSCMReviewer [%s,%s]\n",TOSCMReviewer,User_Id);

						//if(strcmp(member_name,TOSCMReviewer)==0)
						//if(tc_strstr(TOSCMReviewer,userid)!=NULL)
						if(tc_strcmp(FinalUsrId,userid)==0)
						{
							printf("\n Inside TOSCMReviewer assigning.... ");
							participant_type2	= NULLTAG;
							if(EPM_get_participanttype ("T5_TOSCMReviewer",&participant_type2)!=ITK_ok)PrintErrorStack();
							printf("\n Test2");
							participant_tag2	= NULLTAG;
							logical bypass_assignable_check =true;
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test3");
							AOM_lock(TaskTag);			
							if(PARTICIPANT_add_participant(TaskTag,bypass_assignable_check,participant_tag2)!=ITK_ok)PrintErrorStack();
							printf("\n Test4");
							AOM_save_without_extensions(TaskTag);  //Depricated API Changes TC-12.2
							AOM_unlock(TaskTag);
							printf("\n TOSCMReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
			}

	}

    return error_code;

}

int create_Tryout( METHOD_message_t *msg, va_list  args )
{
    //tag_t			TaskTag					= va_arg(args, const tag_t);
	tag_t			TaskTag					= va_arg(args, tag_t);
	tag_t			CRTypeTag				= NULLTAG;
	tag_t			CRCreInTag				= NULLTAG;
	tag_t			CRRevTypeTag			= NULLTAG;
	tag_t			CRRevCreInTag			= NULLTAG;
	tag_t			CRCreatedTag			= NULLTAG;
	tag_t			attr_id					= NULLTAG;;
	tag_t			cur_id					= NULLTAG;;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			item_rev_cld_tag		= NULLTAG;
	tag_t			Master_Item_Rel			= NULLTAG;
	tag_t			Master_Rev_Item_Rel		= NULLTAG;	
	tag_t			item					= NULLTAG;
	tag_t			rev						= NULLTAG;
  
	int				status;
	int				max_char_size		= 80;
	int				error_code			= ITK_ok;
	int				iCntl				= 0;
	int				iCntl2				= 0;
	int				day, month, year	= 0;
	int				FYyear				= 0;
	int				ifail				= 0;
	int				number_found		= 0;
	int				ch					= 0;
	int				int_nxt_srl			= 0;
	int				tmp_int_nxt_srl		= 0;
	int				Deci_srl			= 0;
	int				count_Mstr			= 0;
	int				j					= 0;
	int				i					= 0;
	int				count_Rev_Mstr		= 0;
	
	
	char *CR_AppName 	   = NULL;
	char *CR_OrgName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CR_DeptName 	   = NULL;
	char* username		   = NULL;
	char* creationdate 	   = NULL;
	char* creationdate2	   = NULL;
	char* CRName	 	   = NULL;
	char* CRName2	 	   = NULL;
	char* Lat_CRNm	 	   = NULL;
	char* Cls_Nm	 	   = NULL;
	char* Fyr_no	 	   = NULL;
	char* Srl_no	 	   = NULL;
	char* plnt_nm	 	   = NULL;
	char* dept_nm	 	   = NULL;
	char* tmpStr	 	   = NULL;
	char* tempString 	   = NULL;
	char* CR_Name 		   = NULL;
	char* Date_Created	   = NULL;
	char* Mstr_Nm 		   = NULL;
	char* Rev_Mstr_Nm 	   = NULL;
	char  *ObjectClassType = NULL;
	char  *TryoutPlant = NULL;
	char  *Block = NULL;
	char  *Aggregate = NULL;


	char pAccessDate[20];
	char cur_yearFY[20];
	char tmp_str_nxt_srl[20];
	char nxt_srl[20];
	char cur_year[20];	
	char * currentYearYY;
	char * currentYearFY;
	
	char *TOTSReviewer 	   = NULL;
	char *TOVDReviewer 	   = NULL;
	char *TOQAHead 	   = NULL;
	char *TOVQAReviewer 	   = NULL;
	char *TOSTDReviewer 	   = NULL;
	char *TOFactHead 	   = NULL;
	char *TOManReviewer 	   = NULL;
	char *TOQAReviewer 	   = NULL;
	char *TOSCMReviewer 	   = NULL;

	time_t temp;

	struct tm *timeptr;
	
	
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *Item_Rev_Master_Tags = NULLTAG;
	tag_t *Item_Master_Tags = NULLTAG;
	

	char**			stringArrayCR		= NULL;

	char   type_name[TCTYPE_name_size_c+1];
	WSO_search_criteria_t  	criteria;

	char cCurrentAccessDate[20]={0};

	char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *New_Rev_Mstr_Nm = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *wbs_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));

	char *AggregtValQry = (char *)MEM_alloc(max_char_size * sizeof(char));
	//char *TryNewNo = (char *)MEM_alloc(max_char_size * sizeof(char));

    printf("\n **************inside create_Tryout***************\n ");fflush(stdout);	

//	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
//	if(TCTYPE_ask_name(objTypeTag,type_name));
//	printf("\n     type_name changes done: for workspaceobject:[%s]\n", type_name);fflush(stdout);
//
//
//	POM_get_user(&username,&user_tag);
//	printf("\nStarting for username :%s....\n",username);fflush(stdout);
//
//		   // item_rev_cld_tag = T5_TryoutRevision
//		   // TaskTag = T5_Tryout

//	if(strcmp(type_name,"T5_Tryout")==0)
//	{
//		   // printf("\n inside class T5_PrRpItRevision......\n");fflush(stdout);
//
//		   ITKCALL(ITEM_ask_latest_rev(TaskTag,&item_rev_cld_tag));
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_Plant",&TryoutPlant);
//			AOM_ask_value_string( item_rev_cld_tag,"t5_Block",&Block);
//			AOM_ask_value_string( item_rev_cld_tag,"t5_Aggregate",&Aggregate);
//
//			printf("\n TryoutPlant : %s\n",TryoutPlant);fflush(stdout);
//			printf("\n Block : %s\n",Block);fflush(stdout);
//
//		  //Plant
//			char PlantF[40];
//			GetTryoutPlant(TryoutPlant,PlantF);
//			printf("\n PlantF: %s \n",PlantF);
//
//			//GetCurrentYear
//			char Cur_Yearr[40];
//			GetCurrentYear(Cur_Yearr);
//			printf("\n Cur_Yearr: %s \n",Cur_Yearr);
//
//		 //Aggregate
//			char Aggregt[40];
//			GetTryoutAggregate(Aggregate,Aggregt);
//			printf("\n Aggregt: %s \n",Aggregt);
//
//			strcpy(AggregtValQry,"*");
//			strcat(AggregtValQry,PlantF);
//			strcat(AggregtValQry,Block);
//			strcat(AggregtValQry,Aggregt);
//			strcat(AggregtValQry,"*");
//			strcat(AggregtValQry,Cur_Yearr);
//
//
//			//Next Serial number
//			char TryNewNo[40];
//			GetTryoutSrlNo(AggregtValQry,TryNewNo);
//			printf("\n TryNewNo: %s \n",TryNewNo);
//
//
//			//strcpy(item_id_dup,"ZDTA000119");
//			strcpy(item_id_dup,PlantF);
//			strcat(item_id_dup,Block);
//			strcat(item_id_dup,Aggregt);
//			strcat(item_id_dup,TryNewNo);
//			strcat(item_id_dup,Cur_Yearr);
//
//			//strcat(wbs_id_dup,"*");
//			printf("\n item_id_dup : %s\n",item_id_dup);fflush(stdout);
//			
//			printf("NEXT CUSTOMER REQUEST NAME IS %s\n",item_id_dup);fflush(stdout);
//
//char * TryoutPlant;
//char * item_id;
//
//			printf("\n inside class T5_TryoutRevision......\n");fflush(stdout);
//			AOM_ask_value_string( item_rev_cld_tag, "item_id", &item_id);
//			printf("\n inside class T5_TryoutRevision item_id......: %s",item_id);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag, "t5_Plant", &TryoutPlant);
//			printf("\n inside class T5_TryoutRevision TryoutPlant......: %s",TryoutPlant);fflush(stdout);
//			//TS/APL Reviewer
//			//VD/AQ REviewer
//			//QA-Head Permission
//			//VQA Reviewer
//			//Admin/STDSI Reviewer
//			//Factory-Head Permission
//			//Mfg/CX Reviewer
//			//CQ/Final-QA Reviewer
//			//SCM Reviewer
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOTSReviewer", &TOTSReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOTSReviewer......: %s",TOTSReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOVDReviewer", &TOVDReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOVDReviewer......: %s",TOVDReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOQAHead", &TOQAHead);
//			printf("\n inside create_Tryout T5_TryoutRevision TOQAHead......: %s",TOQAHead);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOVQAReviewer", &TOVQAReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOVQAReviewer......: %s",TOVQAReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOSTDReviewer", &TOSTDReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOSTDReviewer......: %s",TOSTDReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOFactHead", &TOFactHead);
//			printf("\n inside create_Tryout T5_TryoutRevision TOFactHead......: %s",TOFactHead);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOManReviewer", &TOManReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOManReviewer......: %s",TOManReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOQAReviewer", &TOQAReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOQAReviewer......: %s",TOQAReviewer);fflush(stdout);
//
//			AOM_ask_value_string( item_rev_cld_tag,"t5_TOSCMReviewer", &TOSCMReviewer);
//			printf("\n inside create_Tryout T5_TryoutRevision TOSCMReviewer......: %s",TOSCMReviewer);fflush(stdout);
//
//				/*
//						  tag_t  TryoutNumber = NULLTAG;
//							
//						   CALLAPI(AOM_lock(TaskTag));
//						   CALLAPI(POM_attr_id_of_attr("item_id","T5_Tryout",&TryoutNumber));
//						   
//						   if(AOM_refresh(TaskTag,TRUE));
//						   if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
//						   if(POM_set_attr_string(1,&TaskTag,TryoutNumber,item_id_dup));
//						   if(AOM_save_with_extensions(TaskTag));
//						   if(AOM_refresh(TaskTag,TRUE));
//						   CALLAPI(AOM_save_with_extensions(TaskTag));
//						   CALLAPI(AOM_unlock(TaskTag));
//
//			CALLAPI(AOM_set_value_string(TaskTag,"object_name",item_id_dup))PrintErrorStack();
//			ITKCALL(AOM_save_with_extensions(TaskTag));
//			ITKCALL(AOM_refresh(TaskTag,1));	
//
//			printf("Test1");fflush(stdout);
//
//
//
//			//CALLAPI(AOM_set_value_string(TaskTag,"item_id",item_id_dup))PrintErrorStack();			
//			
//			ITKCALL(GRM_list_secondary_objects_only(TaskTag,Master_Item_Rel,&count_Mstr,&Item_Master_Tags));
//			printf("\n\n\t\t count_Mstr : %d",count_Mstr);fflush(stdout);
//
//			for (j=0;j<count_Mstr ;j++ )
//			{
//				AOM_ask_value_string( Item_Master_Tags[j], "object_name", &Mstr_Nm);
//				printf("\n Mstr_Nm:%s",Mstr_Nm);fflush(stdout);
//
//				ObjectClassType=NULL;
//				if (AOM_ask_value_string(Item_Master_Tags[j],"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
//				printf("\n\n  ObjectClassType :%s\n",ObjectClassType);fflush(stdout);
//
//				if(strcmp(ObjectClassType,"T5_TryoutMaster")==0)
//				{
//					printf("\n\n  inside set master name");fflush(stdout);
//					CALLAPI(AOM_set_value_string(Item_Master_Tags[j],"object_name",item_id_dup))PrintErrorStack();
//					ITKCALL(AOM_save_with_extensions(Item_Master_Tags[j]));
//					ITKCALL(AOM_refresh(Item_Master_Tags[j],1));
//				}
//			}
//
//			tag_t  TryoutNumber1 = NULLTAG;
//			
//			CALLAPI(AOM_lock(item_rev_cld_tag));
//			CALLAPI(POM_attr_id_of_attr("item_id","T5_Tryout",&TryoutNumber1));
//			
//			if(AOM_refresh(item_rev_cld_tag,TRUE));
//			if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
//			if(POM_set_attr_string(1,&item_rev_cld_tag,TryoutNumber1,item_id_dup));
//			if(AOM_save_with_extensions(item_rev_cld_tag));
//			if(AOM_refresh(item_rev_cld_tag,TRUE));
//			CALLAPI(AOM_save_with_extensions(item_rev_cld_tag));
//			CALLAPI(AOM_unlock(item_rev_cld_tag));
//			
//			CALLAPI(AOM_set_value_string(item_rev_cld_tag,"object_name",item_id_dup))PrintErrorStack();
//			ITKCALL(AOM_save_with_extensions(item_rev_cld_tag));
//			ITKCALL(AOM_refresh(item_rev_cld_tag,1));	
//			
//
//			ITKCALL(GRM_list_secondary_objects_only(item_rev_cld_tag,Master_Rev_Item_Rel,&count_Rev_Mstr,&Item_Rev_Master_Tags));
//			printf("\n\n\t\t count_Rev_Mstr : %d",count_Rev_Mstr);fflush(stdout);
//
//			for (i=0;i<count_Rev_Mstr ;i++ )
//			{
//				AOM_ask_value_string( Item_Rev_Master_Tags[i], "object_name", &Rev_Mstr_Nm);
//				printf("\n Rev_Mstr_Nm:%s",Rev_Mstr_Nm);fflush(stdout);
//
//				strcpy(New_Rev_Mstr_Nm,item_id_dup);
//				strcat(New_Rev_Mstr_Nm,"/A");
//
//				printf(" \n New_Rev_Mstr_Nm:%s",New_Rev_Mstr_Nm);fflush(stdout);
//
//				ObjectClassType=NULL;
//				if (AOM_ask_value_string(Item_Rev_Master_Tags[i],"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
//				printf("\n\n  hi ObjectClassType :%s\n",ObjectClassType);fflush(stdout);
//
//				if(strcmp(ObjectClassType,"T5_TryoutRevisionMaster")==0)
//				{
//					printf("\n\n  inside set REV master name");fflush(stdout);
//					CALLAPI(AOM_set_value_string(Item_Rev_Master_Tags[i],"object_name",New_Rev_Mstr_Nm))PrintErrorStack();
//					ITKCALL(AOM_save_with_extensions(Item_Rev_Master_Tags[i]));
//					ITKCALL(AOM_refresh(Item_Rev_Master_Tags[i],1));
//				}
//			}
//
//			*/
//					
//	}

    return error_code;

}


extern int tm_tryout_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method;
    int ifail=0;  

 
  
  /*
  if ( METHOD_find_method("T5_TryoutRevision", ITEM_create_msg, &method1) !=ITK_ok);PrintErrorStack();
  

   if (method1.id != NULLTAG)
   {
			if( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) create_Tryout, NULL)!=ITK_ok);PrintErrorStack();
			printf("\n rrrrrrrrRegistered as Post-Action for create_Tryout_Msg  Creation create_Tryout_Msg\n");fflush(stdout);
   }else
		{
			printf("\nMethod not found!create_Tryout_Msg\n");fflush(stdout);
		}
 */


   ifail = METHOD_find_method("T5_TryoutRevision", TC_save_msg, &method);
   if (method.id != NULL)
   {
			ifail = METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Save_Tryout_Msg, NULL)!=ITK_ok;
			printf("\nrrrrrrrrRegistered as Post-Action for T5_TryoutRevision Save\n");fflush(stdout);
   }else
		{
			printf("\nMethod not found!TC_save_msg T5_TryoutRevision\n");fflush(stdout);
		}


	  if( ITK_ok == EPM_register_rule_handler ("tryout_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)tryout_signoff_checks_Func))
	   {
			printf("\t\n Registered Rule Handler tryout_signoff_checks_Func\n");fflush(stdout);
	   }else
	   {
			printf("\t FAILED to register Rule Handler tryout_signoff_checks_Func\n");fflush(stdout);
	   }

  

    return ITK_ok;

}

extern DLLAPI int tm_tryout_register_callbacks()
{
	 CUSTOM_register_exit("tm_tryout", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_tryout_register_method);

     printf("\n registered function tm_tryout\n");	fflush(stdout);

	 return ( ITK_ok );
}
