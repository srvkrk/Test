/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Bhaskar Dimble
*  Module               :   Workflow Action Handler to Fill instruction on perform task
*  Code                 :   CM_FillInstru.c
*  Created on			:   June 4th, 2019
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Action Handler		:		CM_FillInstru
	Description			:		Workflow Action Handler to Fill instruction on perform task
*/



void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int CM_FillInstru(EPM_action_message_t msg)
{	
	int				ifail				= ITK_ok;
	int				count				= 0;
	int				j				= 0;
	int				l				= 0;
	int				k				= 0;
	int				jd				= 0;
	int				n				= 0;
	int				p1				= 0;
	tag_t   Childobject=NULLTAG;

	tag_t			relation1			= NULLTAG;
	tag_t			relation2			= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t			root_task			= NULLTAG;
	tag_t			dataset1			= NULLTAG;
	tag_t			dataset2			= NULLTAG;
	tag_t			rel_type			= NULLTAG;
	tag_t			dml_rev_tag			= NULLTAG;
	int DupVarFr = 0;
	tag_t	objTypeTag1=NULLTAG;

	tag_t ref_instancesTemp = NULLTAG;
	tag_t   window,rule,item_tag = null_tag,top_line,top_line1,bom_rule,bomtop_line;

	char*	 object_type		= NULL;
	char*	 Object_PartType		= NULL;

	char*	 t5current_name		= NULL;
	char*	 t5current_name1		= NULL;
	char*	 DMLtype		= NULL;
	char*	 Part_no			= NULL;
	char*	 ReChkPart_no			= NULL;

	char*	 Arch_obj			= NULL;
	char*	 Arch_obj_str			= NULL;
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	char*	 ContextobjName			= NULL;
	char*	 CtxtrimobjName			= NULL;

	char*	 TargetThread			= NULL;
	char*	 ReleaseStatus		= NULL;
	char*	 current_name		= NULL;
	char*	 projectname		= NULL;
	tag_t  	master =	NULLTAG;
	tag_t relation_type;
	tag_t tsk_dml_rel_type;
	int   n_attchs,partcnt = 0;
	int 	 sequence_id;
	tag_t  *children1=NULLTAG;
	tag_t  *bomchild=NULLTAG;
	tag_t  *children=NULLTAG;
	tag_t  *secondary_objects1	= NULLTAG;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  *CtxSecObject	= NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  objTypeTagDi=NULLTAG;
	char*   type_name3=NULL;
	char  *Context_Str=NULL;
	char *class_nameCtx=NULL;
	int n_parents,n1_parents = 0;
	char*	 DMLNo		= NULL;
	tag_t tAttchPartTag = NULLTAG;
	tag_t tPrntTag = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	char * ItemPType ;
	char * ItemName1 ;
	char *  HangingPrtErr = NULL;
	char *  ColIndYPrt = NULL;
	char *  Part_type = NULL;
	char *  ErrorText = NULL;
	int *levels = 0;
	tag_t *parents = NULL;
	tag_t *parents1 = NULL;
	tag_t   StrChkArchObj=NULLTAG;
	char*   type_name4=NULL;
	char*   Config_CtxType=NULL;
	char*   Archtype_name=NULL;
	char*   Ctxtype_name=NULL;
	char   objecttype[WSO_name_size_c+1];

	char *  SetHangingPrtErr = NULL;
	int PartNoStrucCnt =0;
	tag_t *PartsTag= NULLTAG;
	tag_t AssyTag = NULLTAG;
	tag_t ArchAssyTag = NULLTAG;
	tag_t CtxAssyTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t ArchobjTypeTag=NULLTAG;
	tag_t ctxobjTypeTag=NULLTAG;
	tag_t  relation_dep	= NULLTAG;
	tag_t  relation_Ctx	= NULLTAG;
	char *child_item_id=NULL;
	char *StrChk_item_id=NULL;
	char *child_bl_formula=NULL;
	char *Strchk_bl_formula=NULL;
	char *Trim_bl_formula=NULL;
	int PartStrNoParentCnt =0;
	char PartStrNoStruc[1500];
	char PartStrNoParent[1500];

	logical is_latest;
	tag_t			*attachments		= NULL;
	char			*dataset_name1		= NULL;
	char			*dataset_name2		= NULL;
	char*   type_name1= NULL;
	char*   type_name= NULL;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	char MudleDupcpy[1500];

	printf("\n CM_FillInstru Function started...");fflush(stdout);
	TC_write_syslog("\n CM_FillInstru Function started...");

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n CM_FillInstru: Root task found...!!");fflush(stdout);

	ifail = EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
	printf("\n\n\t\t EPM_ask_attachments of :: %d",count);fflush(stdout);
	if(count>0)
	{
		printf("\n CM_FillInstru: Root Task Count is [%d]\n",count);fflush(stdout);
		for(j=0;j<count;j++)
		{
			DMLRevTag=attachments[j];
			if(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n CM_FillInstru: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
				printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);
				ifail = AOM_ask_value_string(msg.task, "object_type", &dataset_name2);

				//printf("\ndataset name:%s", dataset_name1);fflush(stdout);
				printf("\ndataset name2:%s", dataset_name2);fflush(stdout);

				if((strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"DFMR")==0))
				{
					tc_strcpy(MudleDupcpy,"");
							ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
							if (relation_type!=NULLTAG)
							{
							  ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
							  printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
							  tc_strcpy(PartStrNoParent,""); //sks start end
							  if(n_attchs>0)
							  {
								for (l=0;l<n_attchs ;l++ )
								{
									 ifail = AOM_ask_value_string(secondary_objects[l],"object_type",&object_type);
												 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
									 {
									  ifail = AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag);
									  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

									  if (partcnt>0)
									  {
										for (k=0;k<partcnt ;k++ )
										{
											AssyTag=PartsTag[k];
											ifail = AOM_ask_value_string(AssyTag,"item_id",&Part_no);
											printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout);		     //003906
											
											ifail = AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type);
											printf("\n\n\t CP Part_no  is :%s",Part_type);	fflush(stdout);		     //003906

										   if(strcmp(Part_type,"M")==0)
											{

											if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
											if(TCTYPE_ask_name2(objTypeTag,&type_name));
											printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

											ifail = PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents);
											printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1

											if(n_parents>0)
											{
											  for (jd=0;jd<n_parents;jd++ )
											  {
												ArchAssyTag=parents[jd];
												ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj);    //003915
												printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

												if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
												if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
												printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

												if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
												{
												  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
												  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
												  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
												  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

												  if(top_line!=NULLTAG)
												  {
													if(BOM_line_ask_child_lines (top_line, &n, &children1));
													printf("\n\t No of child objects are n : %d",n);fflush(stdout);

													if (n >0)
													{
													  for (p1=0;p1<n ;p1++ )
													  {
														if(Childobject) Childobject=NULLTAG;
														Childobject=children1[p1];
														ifail = AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id );
														printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

														if(tc_strcmp(Part_no,child_item_id)==0)
														{
														   ifail = AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula );
														   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

													

															printf("\n\t Main Part => %s with his Complete Variant formula = %s\n",Part_no,child_bl_formula); fflush(stdout);
																if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
																if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
																if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
																if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
																if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();

																if(top_line1!=NULLTAG)
																{
																	if(BOM_line_ask_child_lines (top_line1, &n, &children1));
																	printf("\n\t No of child objects are n : %d",n);fflush(stdout);

																	if (n >0)
																	{
																	  for (p1=0;p1<n ;p1++ )
																	  {
																		if(StrChkArchObj) StrChkArchObj=NULLTAG;
																		StrChkArchObj=children1[p1];
																		ifail = AOM_ask_value_string(StrChkArchObj, "bl_item_item_id", &StrChk_item_id );

																		if(tc_strcmp(Part_no,StrChk_item_id)!=0)
																		{
																			printf("\n\t StrChk_item_id Object ===> :: %s",StrChk_item_id); fflush(stdout);
																			ifail = AOM_ask_value_string(StrChkArchObj, "bl_formula", &Strchk_bl_formula );
																			printf("\n\t Strchk_bl_formula--------------> %s\n",Strchk_bl_formula); fflush(stdout);

																			if(tc_strcmp(child_bl_formula,Strchk_bl_formula)==0)
																			{
																				printf("\n inside cmptlecnt loop \n"); fflush(stdout);
																				DupVarFr++;

																				tc_strcat(MudleDupcpy,"Variant formula of new module '");
																				tc_strcat(MudleDupcpy,Part_no);
																				tc_strcat(MudleDupcpy,"'is same as variant formula of existing module '");
																				tc_strcat(MudleDupcpy,StrChk_item_id);
																				tc_strcat(MudleDupcpy,"'");
																				tc_strcat(MudleDupcpy,"Press 'True' if you want to replace existing module with new module.");
																				tc_strcat(MudleDupcpy,"\n");
																				tc_strcat(MudleDupcpy,"'False' will move the DML to Analyst to change the variant formula");
																				//printf("\n\n\t\t for other parttypes MudleDupcpy : %s = %d\n",MudleDupcpy,DupVarFr);fflush(stdout);
																				
																			}
																		}
																	  }
																	}
																}
														}
													  }
													}
												  }
												}
											  }
											}
											}
										}
									  }
									 }
								
								}
							  }
							}
						  }
						  
				if(tc_strlen(MudleDupcpy) != 0)
				{
					ifail = AOM_set_value_string(msg.task, "object_desc", MudleDupcpy);
				}

				if(ITK_ok != (ifail = AOM_save_without_extensions(msg.task)))
				{
					return ifail;
				}
			}
		}
	}

	printf("\n CM_FillInstru Function end...");fflush(stdout);
	TC_write_syslog("\n CM_FillInstru Function end...");
	
	//return ifail;
	return 0;
}

int Create_occ_effectivity(tag_t parenttag,tag_t Revmas, tag_t NewRev)
{
	int		ifail		= ITK_ok;
	int		bvr_count = 0;	
	int		g = 0;	
	int		effcnt = 0;	
	int	in = 0;	
	int	en = 0;	
	int	en1 = 0;	
	int	EFFECTIVITY_closed=0;	
	tag_t   bom_window=NULLTAG;
	tag_t  *bomchild=NULLTAG;
	tag_t  *Effobbj=NULLTAG;
	int		iy = 0;	
	int	cnt = 0;	
	int n_occs=0;
	char cNextDate[20]={0};
	char EffecName[200];
	char EffecNameNew[200];
	char EffecRange[200];
	char EffecRange1[200];
	char EffecRange2[200];
	date_t *Rel_start_end_values	= NULL;
	tag_t			EffecTag						= NULLTAG;
	tag_t			*OldexistEffe						= NULLTAG;
	tag_t			*OldexistEffe1						= NULLTAG;
	tag_t			revTag						= NULLTAG;
	tag_t			dateinf						= NULLTAG;
	tag_t			dateinf1						= NULLTAG;
	tag_t			EffecTagrr						= NULLTAG;
	tag_t			*EffecTagrrww						= NULLTAG;
	tag_t			bvr						= NULLTAG;
	tag_t			ChildItem						= NULLTAG;
	tag_t			bom_rule,bomtop_line;
	char			*mycusdate1				= NULL;
	char			*dataset_name1				= NULL;
	char			*child_item_id				= NULL;
	char			*dataset_name12				= NULL;
	char			*t5Des_Rev				= NULL;
	char			*t5Des_RevNew				= NULL;
	char			*Effeids				= NULL;
	char			*new_item_id				= NULL;
	char			*Effeid				= NULL;
	char			*RevIdN				= NULL;
	char			*RevId				= NULL;
	char			*Seq				= NULL;
	char			*SeqN				= NULL;
	char			*ErrorText			= NULL;
	tag_t			bvrchild						= NULLTAG;
	tag_t			*bvrs ;	

	date_t			test_date_1				= NULLDATE;
	date_t			test_date_2				= NULLDATE;
	date_t			test_date_3				= NULLDATE;
	date_t			Ltest_date_2				= NULLDATE;
	date_t			Ltest_date_1				= NULLDATE;
	//WSOM_open_ended_status_t  	EFFECTIVITY_closed  ;---old 
	
	char* EffecEnd = NULL;
	char* Effecsta = NULL;

	char* EffecEnd1 = NULL;
	char* Effecsta1 = NULL;

	char* EffecEnd2 = NULL;
	char* Effecsta2 = NULL;
	char cCurrentAccessDate[20]={0};
	char	*old_to_date			= NULL;
	logical date_is_valid  ;

	date_t  *eff_dates_arr;
	date_t  *eff_dates_arr1;
	date_t  *Lstart_end_date;


	tag_t *occsal;


	//	if(BOM_create_window(&bom_window)!=ITK_ok);
	//	if(CFM_find( "Latest Working", &bom_rule )!=ITK_ok);
	//	if(BOM_set_window_config_rule(bom_window, bom_rule )!=ITK_ok);
	//	if(BOM_set_window_pack_all(bom_window, false)!=ITK_ok);
	//	if(BOM_set_window_top_line(bom_window, null_tag,parenttag , null_tag, &bomtop_line)!=ITK_ok);
	//if(BOM_line_ask_child_lines (bomtop_line, &g, &bomchild));
	//ifail = ITEM_ask_latest_rev(Revmas, &revTag);
	printf("\n Create_occ_effectivity Function started...");fflush(stdout);
	TC_write_syslog("\n Create_occ_effectivity Function started...");

	ifail = ITEM_rev_list_bom_view_revs(parenttag,&bvr_count, &bvrs);

	printf("\nRevision not found1144...!!\n");fflush(stdout);

	getNextDate(cNextDate);
	printf("\n cNextDate:%s",cNextDate);
	//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

	if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
	{
		return ifail;
	}
	if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_3 )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = ITK_string_to_date("01-Jan-2016 00:00", &test_date_2 )))
	{
		return ifail;
	}


    getCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
	{
		return ifail;
	}

	 eff_dates_arr = (date_t*)malloc(sizeof(date_t) * 2);
	 eff_dates_arr1 = (date_t*)malloc(sizeof(date_t) * 2);

	printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

	eff_dates_arr[0] = test_date_2;
	eff_dates_arr[1] = Ltest_date_2;

	eff_dates_arr1[0] = test_date_1;
	eff_dates_arr1[1] = test_date_3;


	Effecsta=subString("01-Jan-2016 00:00",0,11);
	EffecEnd=subString(cCurrentAccessDate,0,11);

								tc_strcpy(EffecRange,"");

									tc_strcat(EffecRange,Effecsta);
									tc_strcat(EffecRange," to ");
									tc_strcat(EffecRange,EffecEnd);


	Effecsta1=subString(cNextDate,0,11);
	EffecEnd1=subString("31-Dec-9999 00:00",0,11);

								tc_strcpy(EffecRange1,"");

									tc_strcat(EffecRange1,Effecsta1);
									tc_strcat(EffecRange1," to ");
									tc_strcat(EffecRange1,EffecEnd1);

	
     


	//ifail = ITK_date_to_string(date_start, &mycusdate1);
	//		printf("\n date_start is :%s ",mycusdate1);fflush(stdout);

	//		ifail = CFM_effectivity_find("Test",&EffecTag);

	

	//			ifail = CFM_effectivity_ask_date_ranges(EffecTag,&cnt,&date_start1,&date_end1);

	//			printf("\n count is...%d",&cnt);fflush(stdout);

	//		ifail = ITK_date_to_string(date_start1, &mycusdate1);
	//		printf("\n date_start is :%s ",mycusdate1);fflush(stdout);
			

			ifail = AOM_ask_value_string(Revmas, "bl_item_item_id", &dataset_name12);
				printf("\n Revi master name is  :%s ",dataset_name12);fflush(stdout);
       //if (revTag)
      // {
		   	ifail = AOM_ask_value_string(Revmas,"bl_rev_item_revision_id",&t5Des_Rev);
			printf("\n\n\t\t t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);
      // }

	  ifail =  AOM_ask_value_string( NewRev, "bl_item_item_id", &new_item_id);

	  	ifail = AOM_ask_value_string(NewRev,"bl_rev_item_revision_id",&t5Des_RevNew);
			printf("\n\n\t\t t5Des_RevNew is :%s",t5Des_RevNew); fflush(stdout);

				RevId = tc_strtok(t5Des_Rev,";");
				 Seq=tc_strtok(NULL,";");


				 RevIdN = tc_strtok(t5Des_RevNew,";");
				 SeqN=tc_strtok(NULL,";");
			

			tc_strcpy(EffecName,"");
			tc_strcat(EffecName,dataset_name12);
			tc_strcat(EffecName,"_");
			tc_strcat(EffecName,RevId);
			tc_strcat(EffecName,"_");
			tc_strcat(EffecName,Seq);

			tc_strcpy(EffecNameNew,"");
			tc_strcat(EffecNameNew,new_item_id);
			tc_strcat(EffecNameNew,"_");
			tc_strcat(EffecNameNew,RevIdN);
			tc_strcat(EffecNameNew,"_");
			tc_strcat(EffecNameNew,SeqN);

			printf("\n\n\t\t Effectivity ID's is %s:%s",EffecName,EffecNameNew); fflush(stdout);


		

		//	ifail = CFM_effectivity_create(EffecName,&EffecTag);

			if (EffecTag)
			{
				printf("\nRevision not found11444...!!\n");fflush(stdout);

			//	ifail = CFM_effectivity_set_date_ranges(EffecTag,1,eff_dates_arr,eff_dates_arr1);

			//	ifail = AOM_save_without_extensions(EffecTag);
			//		ifail = AOM_refresh(EffecTag, 0);

			}


	//ifail = CFM_effectivity_set_date_ranges(EffecTag,1,&date_start,&date_end);

	


	if (bvr_count)

		{
			bvr = bvrs[0];
			// ifail =  AOM_lock( bvr );
			//  ifail =  AOM_lock( Revmas );
			 //  ifail =  AOM_lock( parenttag );


			// if(BOM_set_window_top_line_bvr(bom_window,bvr,&bomtop_line));

          //     if(BOM_line_ask_all_child_lines(bomtop_line,&g,&bomchild));
          //     printf("\n BOM_line_ask_all_child_lines %d\n",g);

         //   	printf("\nRevision not found22...!!\n");fflush(stdout);

	/*
			  for (cnt = 0; cnt<g; cnt++)
				  {
				
				 
						//if(bomChildobject) bomChildobject=NULLTAG;
						//bomChildobject=bomchild[iy];
						
						if(AOM_ask_value_string(bomchild[cnt], "bl_item_item_id", &dataset_name1));
						printf("\n\t t5childitems_id ===> :: %s",dataset_name1); fflush(stdout);

						if	(tc_strcmp(dataset_name1,dataset_name12)==0)
					{
							BOM_line_set_attribute_string(bomchild[cnt],"bl_has_date_effectivity",EffecName);
							 if(AOM_save_without_extensions(bomtop_line));
							printf("\n using AOM_save_without_extensions: ...top_bom_line.......\n");fflush(stdout);

							if(BOM_save_window(bom_window));

							if(BOM_close_window(bom_window));
					}
				  }
	*/

			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );

		  for (iy = 0; iy<n_occs; iy++)
			  {

						ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

						ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
						printf("\n Master name is  :%s ",dataset_name1);fflush(stdout);

                 // for old child

					if	(tc_strcmp(dataset_name1,dataset_name12)==0)
						{
							 ifail =  AOM_lock( bvr );
						//	ifail = CFM_occ_set_effectivity(bvr,occsal[iy],EffecTag);
							printf("\nRevision not found33...!!\n");fflush(stdout);

							ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

							printf("\n count is...%d",effcnt);fflush(stdout);

						//	ifail = CFM_effectivity_find(EffecName,&OldexistEffe);

						CFM_find_effectivities(EffecName,&en,&OldexistEffe,&dateinf);
						printf("\n count effect is...%d",en);fflush(stdout);

							if ((effcnt == 0) && (en == 0))
							{
							

							ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

							printf("\nRevision not found3344...!!\n");fflush(stdout);

							ifail = AOM_save_without_extensions(EffecTag);
							ifail = AOM_refresh(EffecTag, 0);

						//	ifail = PS_occ_eff_add_eff(bvr,occsal[iy],EffecTag);

								if (EffecTag)
									{

									//ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);

									ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

									//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,1,eff_dates_arr,EFFECTIVITY_closed,FALSE);

									ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange,FALSE);

									
                                  if(ifail != ITK_ok)
                                  {
                                   AOM_unlock(bvr);
                                  EMH_ask_error_text(ifail,&ErrorText);
                                  }
                                  else
                                  {
                                  AOM_save_without_extensions(bvr);
                                  AOM_refresh(bvr,0);
                                  AOM_unlock(bvr);
                                  }
								
									}
							}

							else if ((effcnt == 0) && (en == 1))
							{


								ifail = PS_occ_eff_add_eff(bvr,occsal[iy],OldexistEffe[0]);

								printf("\nRevision not found334433...!!\n");fflush(stdout);

                                if(ifail != ITK_ok)
                                  {
                                   AOM_unlock(bvr);
                                  EMH_ask_error_text(ifail,&ErrorText);
                                  }
                                  else
                                  {
                                  AOM_save_without_extensions(bvr);
                                  AOM_refresh(bvr,0);
                                  AOM_unlock(bvr);
                                  }
								//if (EffecTag)
									//{

									//ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);

									//ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

									//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,1,eff_dates_arr,EFFECTIVITY_closed,FALSE);


									ifail = PS_occ_eff_ask_dates(bvr,occsal[iy],OldexistEffe[0],&g,&Rel_start_end_values,&EFFECTIVITY_closed);//Prajaka--chnaged Declaration of 6 th argu


						//ifail = PS_occ_eff_remove_eff(bvr,occsal[iy],Effobbj[0]);

						//ifail = AOM_save_without_extensions(bvr);
								//	ifail = AOM_unlock( bvr );

					//	ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

					//	ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

						//	ifail = AOM_save_without_extensions(EffecTag);
						//	ifail = AOM_refresh(EffecTag, 0);


						if(g > 0)
								{
									if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
									{
										return ifail;
									}
									printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
									if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
									{
										return ifail;
									}
									printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
									if(date_is_valid != true)
									{
										printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
									}
									else
									{
										printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									}
								}

								


								Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								Lstart_end_date[0] = Ltest_date_1;
								Lstart_end_date[1] = Ltest_date_2;

									Effecsta2=subString(old_to_date,0,11);
									EffecEnd2=subString(cCurrentAccessDate,0,11);

								tc_strcpy(EffecRange2,"");

									tc_strcat(EffecRange2,Effecsta2);
									tc_strcat(EffecRange2," to ");
									tc_strcat(EffecRange2,EffecEnd2);


									ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],OldexistEffe[0],EffecRange2,FALSE);

									

									

									
									
									//ifail = AOM_refresh(bvr, 1);
									if(ifail != ITK_ok)
                                  {
                                   AOM_unlock(bvr);
                                  EMH_ask_error_text(ifail,&ErrorText);
                                  }
                                  else
                                  {
                                  AOM_save_without_extensions(bvr);
                                  AOM_refresh(bvr,0);
                                  AOM_unlock(bvr);
                                  }
									//ifail = AOM_refresh(bvr, 0);
					  
//									ifail = AOM_refresh(Revmas, 1);
//									ifail = AOM_save_without_extensions(Revmas);
//									ifail = AOM_unlock( Revmas );
//									ifail = AOM_refresh(Revmas, 0);
//
//									ifail = AOM_refresh(parenttag, 1);
//									ifail = AOM_save_without_extensions(parenttag);
//									ifail = AOM_unlock( parenttag );
//									ifail = AOM_refresh(parenttag, 0);
							

							}
					else 
					{

						ifail = PS_occ_eff_ask_dates(bvr,occsal[iy],Effobbj[0],&g,&Rel_start_end_values,&EFFECTIVITY_closed);


						ifail = PS_occ_eff_remove_eff(bvr,occsal[iy],Effobbj[0]);

						       if(ifail != ITK_ok)
                                  {
                                   AOM_unlock(bvr);
                                  EMH_ask_error_text(ifail,&ErrorText);
                                  }
                                  else
                                  {
                                  AOM_save_without_extensions(bvr);
                                  AOM_refresh(bvr,0);
                                  AOM_unlock(bvr);
                                  }

						ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

						ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

							if(ifail != ITK_ok)
                              {
                               AOM_unlock(EffecTag);
                              EMH_ask_error_text(ifail,&ErrorText);
                              }
                              else
                              {
                              AOM_save_without_extensions(EffecTag);
                              AOM_refresh(EffecTag,0);
                              AOM_unlock(EffecTag);
                              }


						if(g > 0)
								{
									if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
									{
										return ifail;
									}
									printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
									if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
									{
										return ifail;
									}
									printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
									if(date_is_valid != true)
									{
										printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
									}
									else
									{
										printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									}
								}

								


								Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								Lstart_end_date[0] = Ltest_date_1;
								Lstart_end_date[1] = Ltest_date_2;

									Effecsta2=subString(old_to_date,0,11);
									EffecEnd2=subString(cCurrentAccessDate,0,11);

								tc_strcpy(EffecRange2,"");

									tc_strcat(EffecRange2,Effecsta2);
									tc_strcat(EffecRange2," to ");
									tc_strcat(EffecRange2,EffecEnd2);


						//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,1,Lstart_end_date,EFFECTIVITY_closed,FALSE);

						ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange2,FALSE);

						if(ifail != ITK_ok)
    {
     AOM_unlock(bvr);
    EMH_ask_error_text(ifail,&ErrorText);
    }
    else
    {
    AOM_save_without_extensions(bvr);
    AOM_refresh(bvr,0);
    AOM_unlock(bvr);
    }
									//ifail = AOM_refresh(bvr, 0);
					  
//									ifail = AOM_refresh(Revmas, 1);
//									ifail = AOM_save_without_extensions(Revmas);
//									ifail = AOM_unlock( Revmas );
//									ifail = AOM_refresh(Revmas, 0);
//
//									ifail = AOM_refresh(parenttag, 1);
//									ifail = AOM_save_without_extensions(parenttag);
//									ifail = AOM_unlock( parenttag );
//									ifail = AOM_refresh(parenttag, 0);

					}
				}

				// for old child end


				// for newly added part

					if	(tc_strcmp(dataset_name1,new_item_id)==0)
						{
							 ifail =  AOM_lock( bvr );
						//	ifail = CFM_occ_set_effectivity(bvr,occsal[iy],EffecTag);
							printf("\nRevision not found33...!!\n");fflush(stdout);

							ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

							CFM_find_effectivities(EffecNameNew,&en1,&OldexistEffe1,&dateinf1);

							printf("\n count is...%d",effcnt);fflush(stdout);

							if ((effcnt == 0) && (en1 == 0))
							{
							

							ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);
                           if(ifail != ITK_ok)
                               {
                                AOM_unlock(EffecTag);
                               EMH_ask_error_text(ifail,&ErrorText);
                               }
                               else
                               {
                               AOM_save_without_extensions(EffecTag);
                               AOM_refresh(EffecTag,0);
                               AOM_unlock(EffecTag);
                               }
                           
						//	ifail = PS_occ_eff_add_eff(bvr,occsal[iy],EffecTag);

								if (EffecTag)
									{

									//ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);

									ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecNameNew);

									//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,1,eff_dates_arr1,EFFECTIVITY_open_ended,FALSE);
									ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange1,FALSE);

									

									

									
									
									//ifail = AOM_refresh(bvr, 1);
									if(ifail != ITK_ok)
                                        {
                                         AOM_unlock(bvr);
                                        EMH_ask_error_text(ifail,&ErrorText);
                                        }
                                        else
                                        {
                                        AOM_save_without_extensions(bvr);
                                        AOM_refresh(bvr,0);
                                        AOM_unlock(bvr);
                                        }
									//ifail = AOM_refresh(bvr, 0);
					  
									ifail = AOM_refresh(Revmas, 1);
									ifail = AOM_save_without_extensions(Revmas);
									ifail = AOM_unlock( Revmas );
									ifail = AOM_refresh(Revmas, 0);

									ifail = AOM_refresh(parenttag, 1);
									ifail = AOM_save_without_extensions(parenttag);
									ifail = AOM_unlock( parenttag );
									ifail = AOM_refresh(parenttag, 0);

									  // if(AOM_save_without_extensions(bomtop_line));
									  //  printf("\n using AOM_save_without_extensions: ...top_bom_line.......\n");fflush(stdout);

									 //   if(BOM_save_window(bom_window));

									 //   if(BOM_close_window(bom_window));

									//ifail = PS_occ_eff_ask_id(bvr,occsal[iy],&EffecTagrr);

								//	ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

								//	printf("\n count is...%d",&effcnt);fflush(stdout);

								//					if (EffecTagrr)
								//					{
								//                       ifail = CFM_effectivity_ask_id(EffecTagrr,&Effeid);
								//					   printf("\n Effec ID is  :%s ",Effeid);fflush(stdout);
								//					}

									}
							}

							else if ((en1 == 1) && (effcnt == 0))
							{


								ifail = PS_occ_eff_add_eff(bvr,occsal[iy],OldexistEffe1[0]);

								printf("\nRevision not found334433...!!\n");fflush(stdout);

                                if(ifail != ITK_ok)
                                {
                                 AOM_unlock(bvr);
                                EMH_ask_error_text(ifail,&ErrorText);
                                }
                                else
                                {
                                AOM_save_without_extensions(bvr);
                                AOM_refresh(bvr,0);
                                AOM_unlock(bvr);
                                }
					


									ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],OldexistEffe1[0],EffecRange1,FALSE);

									if(ifail != ITK_ok)
                                {
                                 AOM_unlock(bvr);
                                EMH_ask_error_text(ifail,&ErrorText);
                                }
                                else
                                {
                                AOM_save_without_extensions(bvr);
                                AOM_refresh(bvr,0);
                                AOM_unlock(bvr);
                                }

							}

					else 
					{

						ifail = PS_occ_eff_ask_dates(bvr,occsal[iy],Effobbj[0],&g,&Rel_start_end_values,&EFFECTIVITY_closed);


						ifail = PS_occ_eff_remove_eff(bvr,occsal[iy],Effobbj[0]);

						if(ifail != ITK_ok)
                                {
                                 AOM_unlock(bvr);
                                EMH_ask_error_text(ifail,&ErrorText);
                                }
                                else
                                {
                                AOM_save_without_extensions(bvr);
                                AOM_refresh(bvr,0);
                                AOM_unlock(bvr);
                                }

						ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

						ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecNameNew);
                                if(ifail != ITK_ok)
                                {
                                 AOM_unlock(EffecTag);
                                EMH_ask_error_text(ifail,&ErrorText);
                                }
                                else
                                {
                                AOM_save_without_extensions(EffecTag);
                                AOM_refresh(EffecTag,0);
                                AOM_unlock(EffecTag);
                                }


						if(g > 0)
								{
									if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
									{
										return ifail;
									}
									printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
									if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
									{
										return ifail;
									}
									printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
									if(date_is_valid != true)
									{
										printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
									}
									else
									{
										printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									}
								}

								


								Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								Lstart_end_date[0] = Ltest_date_1;
								Lstart_end_date[1] = Ltest_date_2;


						//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,1,eff_dates_arr1,EFFECTIVITY_closed,FALSE);

						ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange1,FALSE);
                               if(ifail != ITK_ok)
                                {
                                 AOM_unlock(bvr);
                                EMH_ask_error_text(ifail,&ErrorText);
                                }
                                else
                                {
                                AOM_save_without_extensions(bvr);
                                AOM_refresh(bvr,0);
                                AOM_unlock(bvr);
                                }
									//ifail = AOM_refresh(bvr, 0);
					  
									ifail = AOM_refresh(Revmas, 1);
									ifail = AOM_save_without_extensions(Revmas);
									ifail = AOM_unlock(Revmas);
									ifail = AOM_refresh(Revmas, 0);

									ifail = AOM_refresh(parenttag, 1);
									ifail = AOM_save_without_extensions(parenttag);
									ifail = AOM_unlock(parenttag);
									ifail = AOM_refresh(parenttag, 0);

					}
				}

				// newly added part end
			}
             /*if(bvrs)
			 {
			MEM_free(bvrs);
			 }*/
		
		}
		
	
	if(ifail == ITK_ok)
	{
		printf("\nValue updated...!!");fflush(stdout);
	}
	printf("\n Create_occ_effectivity Function end...");fflush(stdout);
	TC_write_syslog("\n Create_occ_effectivity Function end...");

	//return ifail;
	return 0;
}

int CM_ApplyOccuEffect(EPM_action_message_t msg)
{	
	int				ifail				= ITK_ok;
	int				count				= 0;
	int				l				= 0;
	int				k				= 0;
	int				jd				= 0;
	int				n				= 0;
	int				p1				= 0;
	tag_t   Childobject=NULLTAG;

	tag_t			relation1			= NULLTAG;
	tag_t			relation2			= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t			root_task			= NULLTAG;
	tag_t			dataset1			= NULLTAG;
	tag_t			dataset2			= NULLTAG;
	tag_t			rel_type			= NULLTAG;
	tag_t			dml_rev_tag			= NULLTAG;
	int DupVarFr = 0;
	tag_t	objTypeTag1=NULLTAG;

	tag_t ref_instancesTemp = NULLTAG;
    tag_t   window,rule,item_tag = null_tag,top_line,top_line1,bom_rule,bomtop_line;

  char*	 object_type		= NULL;
  char*	 Object_PartType		= NULL;

  char*	 t5current_name		= NULL;
  char*	 t5current_name1		= NULL;
  char*	 DMLtype		= NULL;
  char*	 Part_no			= NULL;
  char*	 ReChkPart_no			= NULL;

  char*	 Arch_obj			= NULL;
  char*	 Arch_obj_str			= NULL;
  char*	 SmVCContext			= NULL;
  char*	 SmCrIDContext			= NULL;
  char*	 ContextobjName			= NULL;
  char*	 CtxtrimobjName			= NULL;

  char*	 TargetThread			= NULL;
  char*	 ReleaseStatus		= NULL;
  char*	 current_name		= NULL;
  char*	 projectname		= NULL;
  char*	 ErrorText		= NULL;
  tag_t  	master =	NULLTAG;
   tag_t relation_type;
  tag_t tsk_dml_rel_type;
  int   n_attchs,partcnt = 0;
  int 	 sequence_id;
  tag_t  *children1=NULLTAG;
  tag_t  *bomchild=NULLTAG;
  tag_t  *children=NULLTAG;
  tag_t  *secondary_objects1	= NULLTAG;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  *CtxSecObject	= NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  objTypeTagDi=NULLTAG;
	char*   type_name3=NULL;
	char  *Context_Str=NULL;
	char *class_nameCtx=NULL;
	int n_parents,n1_parents = 0;
	char*	 DMLNo		= NULL;
	tag_t tAttchPartTag = NULLTAG;
	tag_t tPrntTag = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
    char * ItemPType ;
    char * ItemName1 ;
	char *  HangingPrtErr = NULL;
	char *  ColIndYPrt = NULL;
	char *  Part_type = NULL;
	int *levels = 0;
	tag_t *parents = NULL;
	tag_t *parents1 = NULL;
	tag_t   StrChkArchObj=NULLTAG;
	char*   type_name4=NULL;
	char*   Config_CtxType=NULL;
	char*   Archtype_name=NULL;
	char*   Ctxtype_name=NULL;
	char   objecttype[WSO_name_size_c+1];
	int TaskResult;

	char *  SetHangingPrtErr = NULL;
	int PartNoStrucCnt =0;
	tag_t *PartsTag= NULLTAG;
  tag_t AssyTag = NULLTAG;
  tag_t ArchAssyTag = NULLTAG;
  tag_t CtxAssyTag = NULLTAG;
  tag_t objTypeTag=NULLTAG;
  tag_t ArchobjTypeTag=NULLTAG;
  tag_t ctxobjTypeTag=NULLTAG;
  tag_t  relation_dep	= NULLTAG;
  tag_t  relation_Ctx	= NULLTAG;
  char *child_item_id=NULL;
	char *StrChk_item_id=NULL;
	char *child_bl_formula=NULL;
	char *Strchk_bl_formula=NULL;
	char *Trim_bl_formula=NULL;
	int PartStrNoParentCnt =0;
	char PartStrNoStruc[1500];
	char PartStrNoParent[1500];

  logical is_latest;
	tag_t			*attachments		= NULL;
	char			*dataset_name1		= NULL;
	char			*dataset_name2		= NULL;
	char*   type_name1=NULL;
	char*   type_name=NULL;
	int jm=0;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	char MudleDupcpy[1500];

	printf("\n CM_ApplyOccuEffect Function started...");fflush(stdout);
	TC_write_syslog("\n CM_ApplyOccuEffect Function started...");

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n\n\t Root task found...!!");fflush(stdout);

	ifail = EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
	printf("\n\n\t\t EPM_ask_attachments of :: %d",count);
	if(count>0)
	{
		printf("\n CM_FillInstru: Root Task Count is [%d]\n",count);fflush(stdout);
		for(jm=0;jm<count;jm++)
		{
			DMLRevTag=attachments[jm];
			if(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n CM_FillInstru: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
				printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);
				ifail = AOM_ask_value_string(msg.task, "object_type", &dataset_name2);

				//printf("\ndataset name:%s", dataset_name1);fflush(stdout);
				printf("\ndataset name2:%s", dataset_name2);fflush(stdout);

				if((strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"DFMR")==0))
				{
					tc_strcpy(MudleDupcpy,"");
					ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
					if (relation_type!=NULLTAG)
					{
					  ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
					  printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
					  tc_strcpy(PartStrNoParent,""); //sks start end
					  if(n_attchs>0)
					  {
						for (l=0;l<n_attchs ;l++ )
						{
							 ifail = AOM_ask_value_string(secondary_objects[l],"object_type",&object_type);
										 printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
						 if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
							 {
							  ifail = AOM_ask_value_tags(secondary_objects[l],"CMHasSolutionItem",&partcnt,&PartsTag);
							  printf("\n\n\t\t Now partcnt:%d",partcnt);fflush(stdout);

							  if (partcnt>0)
							  {
								for (k=0;k<partcnt ;k++ )
								{
									AssyTag=PartsTag[k];
									ifail = AOM_ask_value_string(AssyTag,"item_id",&Part_no);
									printf("\n\n\t CP Part_no  is :%s",Part_no);	fflush(stdout);		     //003906
									
									ifail = AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type);
									printf("\n\n\t CP Part_no  is :%s",Part_type);	fflush(stdout);		     //003906

								   if(strcmp(Part_type,"M")==0)
									{

									if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
									if(TCTYPE_ask_name2(objTypeTag,&type_name));
									printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

									ifail = PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents);
									printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1

									if(n_parents>0)
									{
									  for (jd=0;jd<n_parents;jd++ )
									  {
										ArchAssyTag=parents[jd];
										ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj);    //003915
										printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

										if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
										if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
										printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

										if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
										{
										  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
										  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
										  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
										  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
										  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
										  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

										  if(top_line!=NULLTAG)
										  {
											if(BOM_line_ask_child_lines (top_line, &n, &children1));
											printf("\n\t No of child objects are n : %d",n);fflush(stdout);

											if (n >0)
											{
											  for (p1=0;p1<n ;p1++ )
											  {
												if(Childobject) Childobject=NULLTAG;
												Childobject=children1[p1];
												ifail = AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id );
												printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

												if(tc_strcmp(Part_no,child_item_id)==0)
												{
												   ifail = AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula );
												   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

											

													printf("\n\t Main Part => %s with his Complete Variant formula = %s\n",Part_no,child_bl_formula); fflush(stdout);
														if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
														if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();

														if(top_line1!=NULLTAG)
														{
															if(BOM_line_ask_child_lines (top_line1, &n, &children1));
															printf("\n\t No of child objects are n : %d",n);fflush(stdout);

															if (n >0)
															{
															  for (p1=0;p1<n ;p1++ )
															  {
																if(StrChkArchObj) StrChkArchObj=NULLTAG;
																StrChkArchObj=children1[p1];
																ifail = AOM_ask_value_string(StrChkArchObj, "bl_item_item_id", &StrChk_item_id );

																if(tc_strcmp(Part_no,StrChk_item_id)!=0)
																{
																	printf("\n\t StrChk_item_id Object ===> :: %s",StrChk_item_id); fflush(stdout);
																	ifail = AOM_ask_value_string(StrChkArchObj, "bl_formula", &Strchk_bl_formula );
																	printf("\n\t Strchk_bl_formula--------------> %s\n",Strchk_bl_formula); fflush(stdout);

																	if(tc_strcmp(child_bl_formula,Strchk_bl_formula)==0)
																	{
																		printf("\n inside cmptlecnt loop \n"); fflush(stdout);
																		DupVarFr++;
																		ifail = Create_occ_effectivity(ArchAssyTag, Childobject, StrChkArchObj);

																		//tc_strcat(MudleDupcpy,"Same variant formula is already available for Modules '");
																		//tc_strcat(MudleDupcpy,Part_no);
																		//tc_strcat(MudleDupcpy,"' and '");
																		//tc_strcat(MudleDupcpy,StrChk_item_id);
																		//tc_strcat(MudleDupcpy,"'");
																		//tc_strcat(MudleDupcpy,"Press "true" if you want to replace existing module with new module. "False" will move the DML to Analyst to change the variant formula'");
																		//tc_strcat(MudleDupcpy,"\n");
																		//tc_strcat(MudleDupcpy,",");
																		//printf("\n\n\t\t for other parttypes MudleDupcpy : %s = %d\n",MudleDupcpy,DupVarFr);fflush(stdout);
																		
																	}
																}
															  }
															}
														}
												}
											  }
											}
										  }
										}
									  }
									}
									}
								}
							  }
							 }
						
						}
					  }
					}
				}
			}
		}
	}
			  
  //  if(tc_strlen(MudleDupcpy) != 0)
//	{
//	ifail = AOM_set_value_string(msg.task, "object_desc", MudleDupcpy);
//	}
	printf("\n CM_ApplyOccuEffect Function end...");fflush(stdout);
	TC_write_syslog("\n CM_ApplyOccuEffect Function end...");

return 0;

}