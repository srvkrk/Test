#include "TMLLibrary_server_exits.h"

int tm_part_type_Action(EPM_action_message_t msg)
{
	printf("\n *********** ::start here:: **********");fflush(stdout);


	tag_t  roottask				   = NULLTAG;
	tag_t  *Attachments			   = NULLTAG;
	tag_t	idtag				   = NULLTAG;
	tag_t rev					   = NULLTAG;
	tag_t dml_tsk_rel_type		   = NULLTAG;
	tag_t task_tag				   = NULLTAG;
	tag_t Part_tag				   = NULLTAG;
	tag_t *part_task_t			   = NULLTAG;
	tag_t *secondary_objects	   = NULLTAG;
	tag_t *contrlObjs	   = NULLTAG;
	tag_t *TskTags	   = NULLTAG;
	tag_t *PrtsTag	   = NULLTAG;
	tag_t part_Dml_rel_type_t	   = NULLTAG;
	tag_t DMLRevTag	   = NULLTAG;
	tag_t objTypTag	   = NULLTAG;
	tag_t TskTags1	   = NULLTAG;
	tag_t query	   = NULLTAG;
	char *Relstslist			   = NULL;
	char*DMLRlsType				   = NULL;
	char*parttype				   = NULL;
	char*DMLtype				   = NULL;
	char *item_id				   = NULL;
	char *itemid				   = NULL;
	char* 	objType				   = NULL;
	char* 	sVCCRInfo1				   = NULL;
	char* 	sVCCRInfo2				   = NULL;
	char* 	sVCCRInfo3				   = NULL;
	char* 	sVCCRInfo4				   = NULL;
	char* 	objTypeofTask				   = NULL;
	char* 	sDMLDR				   = NULL;
	char* 	partid				   = NULL;
	char* 	Tsk_object_type				   = NULL;
	int no_attach				   = 0;
	int i						   = 0;
	int k						   = 0;
	int Tskcount				   = 0;
	int Part_task_c				   = 0;
	int ifail					   = 0;
	int error_code				   = ITK_ok;
	int count				   = 0;
	int prtcnt				   = 0;
	int VCCRFlag				   = 0;
	int p				   = 0;
	logical is_latest;

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));

	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_part_type_Action Function started...");fflush(stdout);
	TC_write_syslog("\n tm_part_type_Action Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_part_type_Action: No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			DMLRevTag=Attachments[i];

			printf("\n tm_part_type_Action:INSIDE not null tag.");fflush(stdout);

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="VCCRCHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_part_type_Action: Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sVCCRInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sVCCRInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sVCCRInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sVCCRInfo4));
					printf("\n L1:sVCCRInfo1 is : [%s]  L2:sVCCRInfo2 is : [%s]  L3:sVCCRInfo3 is : [%s] L4:sVCCRInfo4 is : [%s]\n",sVCCRInfo1,sVCCRInfo2,sVCCRInfo3,sVCCRInfo4);fflush(stdout);

					if(tc_strstr(sVCCRInfo1,"VCCROFF1") != NULL)
					{
					  return 1;
					}

					if(tc_strstr(sVCCRInfo1,"VCCROFF2") == NULL)
					{

						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n tm_part_type_Action: objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n tm_part_type_Action: object_type is %s\n", objTypeofTask);fflush(stdout);

						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{

							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&itemid));
						    printf("\n tm_part_type_Action: item_id is %s\n", itemid);fflush(stdout);

							if(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest));
							printf("\n tm_part_type_Action: --is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
							   printf("\n tm_part_type_Action: --is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\n  tm_part_type_Action: t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
								printf("\n  tm_part_type_Action: sDMLDR is : [%s]\n", sDMLDR); fflush(stdout);

								if(tc_strcmp(DMLtype,"Veh")==0)
							    {
									ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Tskcount,&TskTags)); //Change References
								    printf("\n tm_part_type_Action: 1.No of Tasks found = %d\n",Tskcount);fflush(stdout);
									{
										for(p=0;p<Tskcount;p++)
										{
											TskTags1=TskTags[p];
											if(AOM_ask_value_string(TskTags1,"object_type",&Tsk_object_type));
											printf("\n tm_part_type_Action: :Tsk_object_type is :%s.",Tsk_object_type);fflush(stdout);

											if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
											{
												ITK_CALL(AOM_UIF_ask_value(TskTags1,"item_id",&item_id));
												printf("\n tm_part_type_Action: item_id is = %s \n",item_id);fflush(stdout);

												if (tc_strstr(item_id,"_00")!=NULL)
												{
													if(AOM_ask_value_tags(TskTags1,"CMHasSolutionItem",&prtcnt,&PrtsTag));
													printf("\n tm_part_type_Action: Now prtcnt:%d.",prtcnt);fflush(stdout);

													if (prtcnt>0)
													{
														for (k=0; k<prtcnt; k++)
														{
															ITK_CALL(AOM_ask_value_string(PrtsTag[k],"item_id",&partid));
															printf("\n tm_part_type_Action partid = %s \n",partid);fflush(stdout);


															ITK_CALL(AOM_UIF_ask_value(PrtsTag[k],"t5_PartType",&parttype));
															printf("\n tm_part_type_Action parttype = %s \n",parttype);fflush(stdout);

															if ((tc_strcmp(parttype,"Vehicle Combination CR")==0)||(tc_strcmp(parttype,"VCCR")==0))
															{
																VCCRFlag=1;
																break;
															}
														}
														if (VCCRFlag>0)
														{
															return 1;
														}
														else
														{
															return 0;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					else
					{
						printf("\n Control objects :Off");fflush(stdout);
						return 1;
					}
				}
			}
		}
	}

	printf("\n tm_part_type_Action Function end...");fflush(stdout);
	TC_write_syslog("\n tm_part_type_Action Function end...");
	//return error_code;
	return 0;
}