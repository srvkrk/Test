//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_bulkPPPMPrjCodeDynLOVImpl
//

#ifndef TRL001__T5_BULKPPPMPRJCODEDYNLOVIMPL_HXX
#define TRL001__T5_BULKPPPMPRJCODEDYNLOVIMPL_HXX

#include <T5_tm_bulkPPPMPrjCodelib/T5_bulkPPPMPrjCodeDynLOVGenImpl.hxx>

#include <T5_tm_bulkPPPMPrjCodelib/libt5_tm_bulkpppmprjcodelib_exports.h>


namespace TRL001
{
    class T5_bulkPPPMPrjCodeDynLOVImpl; 
    class T5_bulkPPPMPrjCodeDynLOVDelegate;
}

class  T5_TM_BULKPPPMPRJCODELIB_API TRL001::T5_bulkPPPMPrjCodeDynLOVImpl
    : public TRL001::T5_bulkPPPMPrjCodeDynLOVGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_bulkPPPMPrjCodeDynLOV
    explicit T5_bulkPPPMPrjCodeDynLOVImpl( T5_bulkPPPMPrjCodeDynLOV& busObj );

    ///
    /// Destructor
    virtual ~T5_bulkPPPMPrjCodeDynLOVImpl();

private:
    ///
    /// Default Constructor for the class
    T5_bulkPPPMPrjCodeDynLOVImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_bulkPPPMPrjCodeDynLOVImpl( const T5_bulkPPPMPrjCodeDynLOVImpl& );

    ///
    /// Copy constructor
    T5_bulkPPPMPrjCodeDynLOVImpl& operator=( const T5_bulkPPPMPrjCodeDynLOVImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_bulkPPPMPrjCodeDynLOVDelegate;

};

#include <T5_tm_bulkPPPMPrjCodelib/libt5_tm_bulkpppmprjcodelib_undef.h>
#endif // TRL001__T5_BULKPPPMPRJCODEDYNLOVIMPL_HXX
