//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_basicdmlLOVImpl
//

#ifndef TRL001__T5_BASICDMLLOVIMPL_HXX
#define TRL001__T5_BASICDMLLOVIMPL_HXX

#include <T5_basicdml/T5_basicdmlLOVGenImpl.hxx>

#include <T5_basicdml/libt5_basicdml_exports.h>


namespace TRL001
{
    class T5_basicdmlLOVImpl; 
    class T5_basicdmlLOVDelegate;
}

class  T5_BASICDML_API TRL001::T5_basicdmlLOVImpl
    : public TRL001::T5_basicdmlLOVGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_basicdmlLOV
    explicit T5_basicdmlLOVImpl( T5_basicdmlLOV& busObj );

    ///
    /// Destructor
    virtual ~T5_basicdmlLOVImpl();

private:
    ///
    /// Default Constructor for the class
    T5_basicdmlLOVImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_basicdmlLOVImpl( const T5_basicdmlLOVImpl& );

    ///
    /// Copy constructor
    T5_basicdmlLOVImpl& operator=( const T5_basicdmlLOVImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_basicdmlLOVDelegate;

};

#include <T5_basicdml/libt5_basicdml_undef.h>
#endif // TRL001__T5_BASICDMLLOVIMPL_HXX
