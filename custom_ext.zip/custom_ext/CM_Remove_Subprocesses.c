/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Shivkumar Birnale
*  Module               :   Workflow Action Handler to delete DML Task subprocesses on rejection
*  Code                 :   CM_Gen_DML_PrintReport.c
*  Created on			:   March 22nd, 2018
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Action Handler		:		CM_Remove_Subprocesses
	Description			:		This handler removes/deletes DML Task subprocesses
*/

int CM_Remove_Subprocesses(EPM_action_message_t msg)
{
	int attachmentCount=0, parentProcessCnt=0,subProcessCnt=0, subTaskCnt=0, rvwSubTaskCnt=0, dmlTaskattchCnt=0, peerReviewersCnt=0, remPeerRevwrsCnt=0;
	int i=0,j=0,k=0,m=0, n=0, p=0,q=0;

	char *taskName=NULL;
	char *sourcetaskName=NULL;
	char *userID, *taskType=NULL;

	char rejectComment[500];

	tag_t rootTask_t=NULLTAG,subrootTask_t=NULLTAG;
	tag_t curJob_t=NULLTAG;
	tag_t sourceTask_t=NULLTAG, parentProcess=NULLTAG;;
	tag_t *taskAttachments,*subTasks, *dmlTaskAttchs, *peerReviewers_t, *remPeerReviewers_t, *reviewSubTasks=NULLTAG;
	tag_t *parent_processes_tags=NULLTAG;
	tag_t *sub_processes_tags=NULLTAG;
	tag_t signOffTask_t,currUser, currGrpMember, peerPrticType=NULLTAG;


	EPM_signoff_decision_t apprDecision_e=EPM_approve_decision;

	printf("\n CM_Remove_Subprocesses Function started...");fflush(stdout);
	TC_write_syslog("\n CM_Remove_Subprocesses Function started...");

	ITK_CALL(POM_get_user(&userID,&currUser));
	ITK_CALL(SA_ask_current_groupmember(&currGrpMember));
	ITK_CALL(EPM_get_participanttype("T5_PeerReviewer",&peerPrticType));

	tc_strcpy(rejectComment,"");
	tc_strcat(rejectComment,"Task rejected by ");
	tc_strcat(rejectComment,userID);
	tc_strcat(rejectComment," from sibling process");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(AOM_ask_value_string(rootTask_t,"object_name",&sourcetaskName));
	TC_write_syslog("Root Task Name = %s\n",sourcetaskName);
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	TC_write_syslog("No of attachments = %d\n",attachmentCount);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&taskName));
	TC_write_syslog("Current Task Name = %s\n",taskName);
	ITK_CALL(EPM_ask_job(msg.task,&curJob_t));
	ITK_CALL(EPM_ask_parent_processes(curJob_t,&parentProcessCnt,&parent_processes_tags));
	TC_write_syslog("EPM Parent Process Count = %d\n",parentProcessCnt);
	for (i=0;i<parentProcessCnt ;i++ )
	{
		ITK_CALL(AOM_ask_value_string(parent_processes_tags[i],"object_name",&taskName));
		TC_write_syslog("Parent Process Name = %s\n",taskName);
		ITK_CALL(EPM_ask_sub_processes(parent_processes_tags[i],&subProcessCnt,&sub_processes_tags));
		TC_write_syslog("EPM Sub Process Count = %d\n",subProcessCnt);

		for (j=0;j< subProcessCnt; j++)
		{
			if(curJob_t==sub_processes_tags[j])
			{
				TC_write_syslog("Rejecting Job found\n");
			}
			else 
			{
				ITK_CALL(EPM_ask_root_task(sub_processes_tags[j],&subrootTask_t));
				ITK_CALL(AOM_ask_value_string(subrootTask_t,"object_name",&taskName));

				if(tc_strcmp(taskName,sourcetaskName)==0)
				{
					TC_write_syslog("Sibling subprocess found\n");

					ITK_CALL(EPM_ask_attachments(subrootTask_t, EPM_target_attachment, &dmlTaskattchCnt,&dmlTaskAttchs));
					TC_write_syslog("No of attachment in Sibling process = %d\n",dmlTaskattchCnt);
					ITK_CALL(PARTICIPANT_ask_participants(dmlTaskAttchs[0], peerPrticType, &peerReviewersCnt, &peerReviewers_t));
					TC_write_syslog("No of Peer Reviewers = %d\n",peerReviewersCnt);
					
					ITK_CALL(EPM_ask_sub_tasks(subrootTask_t,&subTaskCnt,&subTasks));
					TC_write_syslog("No. of subtasks in sibling process = %d\n",subTaskCnt);
					for (k=0;k<subTaskCnt;k++)
					{
						ITK_CALL(AOM_ask_value_string (subTasks[k],"task_type",&taskType));
						if(tc_strcmp(taskType,"EPMReviewTask")==0)
						{
							ITK_CALL(EPM_ask_sub_tasks(subTasks[k],&rvwSubTaskCnt,&reviewSubTasks));
							TC_write_syslog("No of subtasks = %d\n",rvwSubTaskCnt);
							for (m=0;m < rvwSubTaskCnt ; m++ )
							{
								ITK_CALL(AOM_ask_value_string (reviewSubTasks[m],"task_type",&taskType));
								if(tc_strcmp(taskType,"EPMPerformSignoffTask")==0)
								{
									ITK_CALL(EPM_ask_attachments(reviewSubTasks[m],EPM_signoff_attachment,&attachmentCount,&taskAttachments));
									TC_write_syslog("No of signoff attachments in sibling = %d\n",attachmentCount);
									if(attachmentCount>0)		//Assuming only one approval is sufficient for SignOff task to complete.
									{
										ITK_CALL(EPM_delegate_signoff(taskAttachments[0],currGrpMember,true));	//This changes the Participant value of DML Task. Needs to reassign the previous user, Remedy :  ITEM_rev_ask_participant
										ITK_CALL(EPM_refresh_job(sub_processes_tags[j]));
										ITK_CALL(EPM_set_task_decision3(reviewSubTasks[m],taskAttachments[0],apprDecision_e,rejectComment));
										/*ITK_CALL(AOM_refresh(dmlTaskAttchs[0],true));
										ITK_CALL(PARTICIPANT_ask_participants (dmlTaskAttchs[0], peerPrticType, &remPeerRevwrsCnt, &remPeerReviewers_t));
										for (q=0;q< remPeerRevwrsCnt;q++ )
										{
											ITK_CALL(ITEM_rev_remove_participant(dmlTaskAttchs[0],remPeerReviewers_t[q]));
										}
										ITK_CALL(ITEM_rev_set_participants(dmlTaskAttchs[0],peerReviewersCnt,peerReviewers_t));*/
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n CM_Remove_Subprocesses Function end...");fflush(stdout);
	TC_write_syslog("\n CM_Remove_Subprocesses Function end...");
	//return ITK_ok;
	return 0;
}