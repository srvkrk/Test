/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>


#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int ConsmbltbleUpdServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	char *countValidPart= NULL;
	char *Consumabletemp= NULL;
	char *detailValValid= NULL;
	//char *detailValInValid= NULL;
	char *validRowCnt= NULL;
	//char *InvalidRowCnt= NULL;
	//char *detailVal2= NULL;
	//char *detailVal3= NULL;
	char *srno_ValPrt= NULL;
	char *PrtType_ValPrt= NULL;
	char *PrtNo_ValPrt= NULL;
	char *PrtDesc_ValPrt= NULL;
	char *PrtRevSeq_ValPrt= NULL;
	char *PrtCS_ValPrt= NULL;
	char *PrtChgeType_ValPrt= NULL;
	char *PrtOldQty_ValPrt= NULL;
	char *validRowData= NULL;
	char *invalidRowData= NULL;
	char *fectinvalidRowData= NULL;
	char *fectValidRowData= NULL;
	char *PrtRev= NULL;
	char *PrtSeq= NULL;

	char *srno_InValPrt= NULL;
	char *PrtType_InValPrt= NULL;
	char *PrtNo_InValPrt= NULL;
	char *PrtDesc_InValPrt= NULL;
	char *PrtRevSeq_InValPrt= NULL;
	char *PrtCS_InValPrt= NULL;
	char *PrtChgeType_InValPrt= NULL;
	char *PrtOldQty_InValPrt= NULL;
	char *PrtRev1= NULL;
	char *PrtSeq1= NULL;
	char *new_srno_ValPrtSt= NULL;
	char *new_srno_InValPrtSt= NULL;
	char *srNoValid= NULL;
	char *srNoInValid= NULL;
	char *partTypeInValid= NULL;
	char *partTypeValid= NULL;
	char *cnsmpartTQTY= NULL;
	char *cnsmpartTClass= NULL;

	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	int intvalidRowCnt=0;
	int intInvalidRowCnt=0;
	int n_valid_rows=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t* valid_Table_rows = NULLTAG;
	tag_t* valid_rowsTag = NULLTAG;
	tag_t* invalid_rowsTag = NULLTAG;
	tag_t* invalid_Table_rows = NULLTAG;
	int rcnt=0;
	int rcnt1=0;
	int rcnt2=0;
	int rcntVal=0;
	int srNoValidInt=0;
	int srno_ValPrtInt=0;
	int iValCnt=0;
	int new_srno_ValPrtInt=0;
	int n_invalid_rows=0;
	int iInValCnt=0;
	int srNoInValidInt=0;
	int srno_InValPrtInt=0;
	int new_srno_InValPrtInt=0;


	USERARG_get_string_argument(&Consumabletemp);
	USERARG_get_string_argument(&validRowCnt);
	USERARG_get_string_argument(&detailValValid);
	
		
	printf("\nArgument Received(ConsmbltbleUpdServiceFnc) Consumabletemp=%s\n",Consumabletemp);fflush(stdout);	
	printf("\nArgument Received(ConsmbltbleUpdServiceFnc) vRowCnt=%s\n",validRowCnt);fflush(stdout);	
	printf("\nArgument Received(ConsmbltbleUpdServiceFnc) detailVal=%s\n",detailValValid);fflush(stdout);	
	

	if(tc_strcmp(Consumabletemp,"")!=0)
	{
			
		qry_entries[0] ="item_id";
		qry_values[0] = Consumabletemp;

		printf("\n Qurying the EPA");fflush(stdout);

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		if(itemclass != NULLTAG )
		{
			item = itemclass[0];
			
			ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
			if(epa_rev_tag!=NULLTAG)
			{
			
				printf("\n Qurying the COnsubmale TeMplATE rEV done and foudn the cONS tEMP rEV Tag..");fflush(stdout);

				intvalidRowCnt = atoi(validRowCnt); // Using atoi()
				printf("\nThe value of intvalidRowCnt : %d", intvalidRowCnt);fflush(stdout);

					
				if((intvalidRowCnt>0))
				{
					ITKCALL(AOM_lock(epa_rev_tag));
					
					

					if(intvalidRowCnt>0)
					{
					
						char *arrayVadDt[intvalidRowCnt];
						
						for(rcntVal=0;rcntVal<intvalidRowCnt;rcntVal++)
						{
							if(tc_strcmp(detailValValid,"")!=0)
							{
								
								if(rcntVal==0)
								{
									validRowData=tc_strtok(detailValValid,"~");
								}
								else
								{
									validRowData=tc_strtok(NULL,"~");
								}

								printf("\n consumbale table :[%s] \n",validRowData);fflush(stdout);

								arrayVadDt[rcntVal]=validRowData;
								printf("\n Arryas [rcntVal] :[%s] \n",arrayVadDt[rcntVal]);fflush(stdout);					
													

							}					

						}

							
						ITKCALL(AOM_insert_table_rows(epa_rev_tag, "t5_ConsumbleTble", 0,intvalidRowCnt, &valid_Table_rows));
						printf("\n\n Inside else of Table Rows Inserted Success\n");fflush(stdout);
						
						
						for(rcnt=0;rcnt<intvalidRowCnt;rcnt++)
						{
								
							fectValidRowData=arrayVadDt[rcnt];
							printf("\n fectValidRowData :[%s] \n",fectValidRowData);fflush(stdout);
							
							srno_ValPrt=tc_strtok(fectValidRowData,"-");
							PrtType_ValPrt = tc_strtok(NULL,"-");
							PrtNo_ValPrt = tc_strtok(NULL,"-");
							PrtDesc_ValPrt = tc_strtok(NULL,"-");


							printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]\n",srno_ValPrt,PrtType_ValPrt,PrtNo_ValPrt,PrtDesc_ValPrt);fflush(stdout);
							
					
							if((tc_strcmp(srno_ValPrt,"")!=0) && (tc_strcmp(srno_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PSrNo", srno_ValPrt));
							if((tc_strcmp(PrtType_ValPrt,"")!=0) && (tc_strcmp(PrtType_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_ConsmPartNo", PrtType_ValPrt));
							if((tc_strcmp(PrtNo_ValPrt,"")!=0) && (tc_strcmp(PrtNo_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_ConsumblQty", PrtNo_ValPrt));
							if((tc_strcmp(PrtDesc_ValPrt,"")!=0) && (tc_strcmp(PrtDesc_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_ConsumblClass", PrtDesc_ValPrt));
							
							ITKCALL(AOM_save_with_extensions(valid_Table_rows[rcnt]));
							printf("\n\n Save Success");fflush(stdout);

						}

						
						ITKCALL(AOM_ask_table_rows(epa_rev_tag,"t5_ConsumbleTble", &n_valid_rows,&valid_rowsTag));
						printf("\n no of table rows for consumable table revision is  %d \n", n_valid_rows);fflush(stdout);
						if(n_valid_rows>0)
						{
							for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
							{
								ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_PSrNo", &srNoValid));
								printf("\n Consumable part sr [%s]..",srNoValid);fflush(stdout);
								
								ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_ConsmPartNo", &partTypeValid));
								printf("\n Consumable part No [%s]..",partTypeValid);fflush(stdout);	


								ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_ConsumblQty", &cnsmpartTQTY));
								printf("\n Consumable part QTY is [%s]..",cnsmpartTQTY);fflush(stdout);	

							ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_ConsumblClass", &cnsmpartTClass));
								printf("\n Consumable part Class is[%s]..",cnsmpartTClass);fflush(stdout);	

								
							}
						}
					}
					


					ITKCALL(AOM_unlock(epa_rev_tag));

					ITKCALL(AOM_refresh(epa_rev_tag, FALSE));
					printf("\n\n Refresh the Consumable Template revision Object");fflush(stdout);
					
				}
			
			}
		}
	
	
	}


	return ifail;
}


extern int ConsmblTbleUpdRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 3;
	int retValueType;
	int validRowCntInt=0;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );

	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;


	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n ConsmbltbleUpdServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("ConsmbltbleUpdServiceFnc",(USER_function_t)ConsmbltbleUpdServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_ConsmblTbleFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(ConsmblTbleUpdRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_ConsmblTbleUpdFuncs_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_ConsmblTbleUpdFuncs...."); 
	printf("\n Before registoring userservice tm_ConsmblTbleUpdFuncs ...."); 
	ifail=CUSTOM_register_exit ( "tm_ConsmblTbleUpdFuncs", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_ConsmblTbleFuncServiceFnc);
	printf("\n After registoring userservice tm_ConsmblTbleUpdFuncs....");
	return ( ITK_ok );
}

