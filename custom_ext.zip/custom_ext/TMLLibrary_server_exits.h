#ifndef TMLLibrary_REGISTER_SERVER_EXIT_H
#define TMLLibrary_REGSITER_SERVER_EXIT_H

#include "iman_header.h"

extern DLLAPI int TML_register_custom_handlers(int *decision, va_list args);
extern DLLAPI int TMLLibrary_register_callbacks();

extern int TML_register_action_handlers();
extern int TML_register_rule_handlers();
extern int TML_register_pre_actions();
extern int TML_register_post_actions();

extern int CM_Gen_DML_PrintReport(EPM_action_message_t msg);
extern int CM_Remove_Subprocesses(EPM_action_message_t msg);
extern int DCR_ChngSpeclist_assign(EPM_action_message_t msg);
extern int data_share_process(EPM_action_message_t msg);
extern int CM_ImpactAnalysisReport(EPM_action_message_t msg);
extern int SnapShotFormSave(METHOD_message_t *msg, va_list args);
extern int SVR_ChildSVR_Rel( METHOD_message_t *msg, va_list  args );
extern int Set_Chasis_details( METHOD_message_t *msg, va_list  args );
extern int Set_tskdesc( METHOD_message_t *msg, va_list  args );

extern EPM_decision_t CM_Check_Implements_Objects(EPM_rule_message_t msg);


#endif