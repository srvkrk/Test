/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Manindra Praharaj
*  Module		 :   It will compare the BOM in structure manager between ERC and APL ,Also APL Module Compare for ERC on giving specific plant location
*  Code			 :   tm_BOM_ERCAPLCompareRpt.c
*  Created on	 :   Nov 11 ,2023
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>



static FILE *output;

#define Debug TRUE

#define ITK_CALL_API(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}	 								\


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int BOM_ERCAPLCompareReport(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *Inputpartno        = NULL;
	char     *sequence          = NULL; 
	char     *Revision          = NULL; 
	char     *Plant           = NULL; 
	char     *output			 = NULL;
	char				command[1000];
			
	output = (char *) MEM_alloc( 90000000 * sizeof(char*) );

	printf("\n inside the function BOM_ERCAPLCompareReport.....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&Inputpartno);
	USERARG_get_string_argument(&Revision);
	USERARG_get_string_argument(&sequence);
	USERARG_get_string_argument(&Plant);

	printf("\n Input part no :: %s ",Inputpartno);fflush(stdout);
	printf("\n Input Revision is  :: %s ",Revision);fflush(stdout);
	printf("\n Input Sequnce is  :: %s ",sequence);fflush(stdout);
	printf("\n Input Plant is  :: %s ",Plant);fflush(stdout);
	
	printf("\n Going to call tm_BOM_ERCAPLCompareRpt EXE file............\n\n ");fflush(stdout);
	sprintf(command,"/user/cvprod/shells/APL/tm_BOM_ERCAPLCompareRpt.sh  %s %s %s %s",Inputpartno,Revision,sequence,Plant);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	tc_strcpy(output,"");

	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(output);

	printf("\n After free...!\n");fflush(stdout);
    return ifail;
}


extern int ERCAPLCompareRptUserServiceFntFn()
{

	int ifail = ITK_ok;
	int nargs = 4;
    int retValueType;
    int inputArgTypes[4] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //part Number 
    inputArgTypes[1] = USERARG_STRING_TYPE; //Revision 
	inputArgTypes[2] = USERARG_STRING_TYPE; //Sequence 
	inputArgTypes[3] = USERARG_STRING_TYPE; //Plant name 
    

    retValueType = USERARG_STRING_TYPE ;
   printf("\n ERCAPLCompareRptUserServiceFntFn before....BOM_ERCAPLCompareReport");fflush(stdout);
    ifail=USERSERVICE_register_method("BOM_ERCAPLCompareReport",(USER_function_t)BOM_ERCAPLCompareReport,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceERCAPLCompareRptFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(ERCAPLCompareRptUserServiceFntFn());

    return ifail;
}

extern DLLAPI int tm_BOM_ERCAPLCompareRpt_register_callbacks ()
{

    int ifail    = ITK_ok;
   printf("\n Before registering userservice....tm_BOM_ERCAPLCompareRpt -");fflush(stdout);
    ifail = CUSTOM_register_exit("tm_BOM_ERCAPLCompareRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceERCAPLCompareRptFn);
    printf("\n After registering userservice....tm_BOM_ERCAPLCompareRpt");fflush(stdout);
    return(ITK_ok);
}