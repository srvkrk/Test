/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       t5_UplMbom.c
*
* Description   : > This register custom user service. Implemented Custom ITK functions for generating UPLMBOM Object and Reports.
*                                 > This ITK functions are called in Rich Client
* Module
* Since             :   28-11-2022
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 18/01/2024     Sandeep Goyal/Abineswar Bisoi                      Base Code
*
* -----------------------------------------------------------------------------
*
*****************************************************************************/

#
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pie/pie.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}



int MBPATableUpdcsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;
	char*                   InputEPA                               = NULL;
	char*                   InputMBPA                               = NULL;
	char*                   LineItem                                =       NULL;
	LineItem                     =(char *) MEM_alloc(1000);
    int                     SysReturn                               =       0;
	
 
    printf("\n MBPATableUpdcsvr Calling ");fflush(stdout);
	
	
	
    USERARG_get_string_argument(&InputEPA);
    USERARG_get_string_argument(&InputMBPA);
 
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n InputEPA :: %s ",InputEPA);fflush(stdout);
    printf("\n InputMBPA :: %s ",InputMBPA);fflush(stdout);
    
    strcpy(LineItem,"/user/cvprod/shells/STD/MBPATableUpd.sh");
    strcat(LineItem," ");
    strcat(LineItem,InputEPA);
    strcat(LineItem," ");
    strcat(LineItem,InputMBPA);
    printf("\n LineItem = %s",LineItem);fflush(stdout);
    SysReturn = system(LineItem);
	
	
	
    return ifail;
}



extern int MBOMUserServiceFnMBPATableUpdtFn()
{
    int ifail = ITK_ok;
    int nargs = 2;
    int retValueType;
    int inputArgTypes[2] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; 
    inputArgTypes[1] = USERARG_STRING_TYPE; 
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("MBPATableUpdcsvr",(USER_function_t)MBPATableUpdcsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceMBPATableUpdFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(MBOMUserServiceFnMBPATableUpdtFn());

    return ifail;
}

extern DLLAPI int tm_MBPATableUpd_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_MBPATableUpd", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceMBPATableUpdFn);
    return(ITK_ok);
}


