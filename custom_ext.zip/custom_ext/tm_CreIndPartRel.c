/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Poonam
*  Module       :   PLM-SAP Interface
*  Description  :   User Services For BOM loading in SAP 
*  File Name    :   tm_PLMSAPInterface.c
*  Created on   :   
*  Usage        :   tm_PLMSAPInterface
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  
***************************************************************************/
				
#include <stdlib.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#include <ics/ics2.h>
#include <ics/ics.h>


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
char *ltrim(char *s)
{
    while(isspace(*s)) s++;
    return s;
}

char *rtrim(char *s)
{
    char* back;
    int len = strlen(s);

    if(len == 0)
        return(s);

    back = s + len;
    while(isspace(*--back));
    *(back+1) = '\0';
    return s;
}

char *trim(char *s)
{
    return rtrim(ltrim(s));
}

void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}



	int queryObject(char* PartNum, char* PrtRevSeq,tag_t *prtObjTag)
	{
			int ifail=ITK_ok;
			
			printf("\n\n Inside queryObject......");fflush(stdout);
			printf("\n\n Inside queryObject with item id :%s",PartNum);fflush(stdout);
			
			tag_t TagQryContObj = NULLTAG,*Des_objects = NULL;
			
			int	n_entries = 1;
			int n_found = 0;
			
			char *qry_entries[1]={"Item ID"};
			char *qry_values[1]={PartNum};
	
			
			
			if(QRY_find2("Item Revision...", &TagQryContObj));
			printf("\n CurrentTask:\n");
			
			

			if (TagQryContObj)
				{
					printf("\nFound Query Part  \n");fflush(stdout);
				}
				else
				{
					printf("\nNotFound Query Part");fflush(stdout);
				}
					
			if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &Des_objects));
			printf("\n Objects for Query Design rev == %d", n_found);fflush(stdout);

				int ia=0;
				if(n_found>0)
				{
				for (ia=0;ia<n_found;ia++ )
				{
					printf(" in for loop of numbber of parts [%d] \n",n_found);fflush(stdout);
					*prtObjTag = Des_objects[ia];
					
					char	*type_name2		=	NULL;
	
					tag_t	secObjTypeTag			=	NULLTAG;
					char 	*designrevName			= NULL;
					char 	*designrevNameObjstr			= NULL;
					char 	*designrev			= NULL;
					
					printf(" loop number [%d] \n",ia);fflush(stdout);
					if (TCTYPE_ask_object_type(*prtObjTag,&secObjTypeTag)!=ITK_ok);
					if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					//TC_write_syslog("sec obj type_name ::  %s\n", type_name2);
					
					AOM_ask_value_string(*prtObjTag,"item_id",&designrevName);
					printf(" designrevName %s\n",designrevName);fflush(stdout);
	
					AOM_ask_value_string(*prtObjTag,"object_string",&designrevNameObjstr);
					printf(" designrevNameObjstr %s\n",designrevNameObjstr);fflush(stdout);
					
					

					 AOM_ask_value_string(*prtObjTag,"item_revision_id",&designrev);
					 //TC_write_syslog("designrev ::  %s\n", designrev);
					 printf(" designrev %s\n",designrev);fflush(stdout);
					  printf(" input PrtRevSeq %s\n",PrtRevSeq);fflush(stdout);
		 
					if(strcmp(PrtRevSeq,designrev)==0)
					{
						printf(" match input rev seq[%s]",PrtRevSeq,designrev);fflush(stdout);
						printf(" Part Num[%s],Rev Seq[%s]",designrevName,PrtRevSeq);fflush(stdout);
						break;
					}
					else
					{
						printf(" input rev seq[%s]",PrtRevSeq,designrev);fflush(stdout);
					}
				}
				}
			
			//if(n_found>0)
				//*modobj=items[0];


			return ifail;


	}

int tm_CreIndPartRelFuncation(char *IndNO,char *Infiledata)
{
	int ifail = ITK_ok;

    int           noofEst                = 0;
    tag_t         *IndNumSet           = NULLTAG;
    tag_t         IndNumtag               = NULLTAG;
    char          *StringLine            = NULL;
//    char          *TempInfiledata            = NULL;
	
	tag_t		IndTag		= NULLTAG;
	tag_t		IndRevTag		= NULLTAG;
	char		   *t5rlz_list	=NULL;
	tag_t prevoffRev_tag= NULLTAG;

//	char *StringLine2 = NULL;
	
	char*         IndArrInfo[1000]      ;

    
//	TempInfiledata = (char*)malloc(3000);

	int StorIdx = 0;
	printf("\n 1111111111Input file data is  is : %s",Infiledata);fflush(stdout);
	StringLine = (char *) MEM_alloc(1 * sizeof(Infiledata));
//	tc_strcpy(TempInfiledata,Infiledata);
//	printf("\n ssssssInput file data is  is : %s",TempInfiledata);fflush(stdout);
	StringLine = strtok(Infiledata,"\n");
	while(StringLine!=NULL)
	{
		IndArrInfo[StorIdx] = (char*)malloc(300);
		strcpy(IndArrInfo[StorIdx],StringLine);
		StringLine = strtok(NULL,"\n");
		StorIdx ++;
	}
	printf("\n 22222222222Input file data is  is : %s",Infiledata);fflush(stdout);
	printf("\n 33333333333Input file data is  is : %s",StringLine);fflush(stdout);
	printf(" Total StorIdx.... = %d\n",StorIdx);fflush(stdout);
	
	printf("Input Indent number is = [%s]",IndNO);fflush(stdout);
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	qry_entriesInd[0] = "Type";
	qry_entriesInd[1] = "Item ID";
	
	qry_valuesInd[0] = "T5_ERCInd";
	qry_valuesInd[1] = IndNO;
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	tag_t IndentMaster = NULLTAG;	
	
	QRY_find2("Item...", &queryInd);
	QRY_execute(queryInd, 2, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Indent Item Master: count==>%d", count);fflush(stdout);
	char*			obj_type		= NULL;
	if(count>0)
	{
		IndentMaster = itemObj[0];
		int IndRevCnt=0;
		tag_t* IndentRevTagObjs = NULLTAG;
		
		ITEM_list_all_revs (IndentMaster, &IndRevCnt, &IndentRevTagObjs);
		printf("\n Indent Revision counts :%d\n",IndRevCnt);fflush(stdout);
		if(IndRevCnt>0)
		{
			tag_t			uaindObj		= NULLTAG;
			uaindObj = IndentRevTagObjs[0];
			WSOM_ask_object_type2(uaindObj,&obj_type);
			
			printf("\n Indent obj_type :[%s]",obj_type);fflush(stdout);
			if(tc_strcmp(obj_type, "T5_ERCIndRevision") == 0)
			{
				char*			indRefNo		= NULL;
				AOM_ask_value_string(uaindObj,"t5RefNo",&indRefNo);
				printf("\n Indent indRefNo :[%s]",indRefNo);fflush(stdout);
				
				int      IndInpt   = 0;
				 char* Ind_Part = NULL;
				 Ind_Part=MEM_alloc(80);
				 
				char* Ind_PartRevSeq = NULL;
				 Ind_PartRevSeq=MEM_alloc(100);
				 
				 
				 char*	latest_PartRevSeq =NULL;
				 char*	Ind_PartRevSeq_NR =NULL;
				 char*	prev_rev_RevId =NULL;
				 
				 latest_PartRevSeq = (char *) MEM_alloc(100);
				 Ind_PartRevSeq_NR = (char *) MEM_alloc(100);
				 prev_rev_RevId = (char *) MEM_alloc(100);
				 
				 char* ERCIndQtySet = NULL;
				 ERCIndQtySet=MEM_alloc(10);
				 
				 char* ERCIndReqdSet = NULL;
				 ERCIndReqdSet=MEM_alloc(10);
				 
				 char* ERIndIR = NULL;
				 ERIndIR=MEM_alloc(50);
				 
				 char* RemarkForIndenticalPart = NULL;
				 RemarkForIndenticalPart=MEM_alloc(100);
				 
				 char* PartIndDisposal = NULL;
				 PartIndDisposal=MEM_alloc(100);
				 
				 char* ERCIndCompltQtySet = NULL;
				 ERCIndCompltQtySet=MEM_alloc(20);
				 
				 char* ERIndIRAvl = NULL;
				 ERIndIRAvl=MEM_alloc(100);
				 
				 char* PartIndCategory = NULL;
				 PartIndCategory=MEM_alloc(100);
				 
				 char* ERCIndentee = NULL;
				 ERCIndentee=MEM_alloc(100);
				 
				 char* ERCIndRemark = NULL;
				 ERCIndRemark=MEM_alloc(100);
				 
				 char* SupplierName = NULL;
				 SupplierName=MEM_alloc(100);
				 
				 char* TkoStatus = NULL;
				 TkoStatus=MEM_alloc(100);
				 
				 char* TRSOStatus = NULL;
				 TRSOStatus=MEM_alloc(100);
				 
				  char* IndPrtEstCost = NULL;
				 IndPrtEstCost=MEM_alloc(100);
					 
				//	 char          *StringLine1            = NULL;
					 
				for(IndInpt = 0 ; IndInpt < StorIdx ; IndInpt++)
				{
					char *StringLine1 = NULL;
					StringLine1 = (char *) MEM_alloc(1000 * sizeof(char *));
				//	StringLine2 = strtok(TempInfiledata,"\n");
					 printf("IndArrInfo[%d]: %s\n", IndInpt, IndArrInfo[IndInpt]);fflush(stdout);
				//	 printf("44444444444 StringLine2 is %s\n",StringLine2);fflush(stdout);
					 
					 //tc_strcpy(StringLine1,"");
					 tc_strcpy(StringLine1,IndArrInfo[IndInpt]);
					 printf("44444444444 StringLine1 is %s\n",StringLine1);
					 
					 tc_strcpy(Ind_Part,"");
				//	 tc_strcpy(Ind_PartRevSeq,"");
					 tc_strcpy(ERCIndQtySet,"");
					 tc_strcpy(ERCIndReqdSet,"");
					 tc_strcpy(ERIndIR,"");
					 tc_strcpy(RemarkForIndenticalPart,"");
					 tc_strcpy(PartIndDisposal,"");
					 tc_strcpy(ERCIndCompltQtySet,"");
					 tc_strcpy(ERIndIRAvl,"");
					 tc_strcpy(PartIndCategory,"");
					 tc_strcpy(ERCIndentee,"");
					 tc_strcpy(ERCIndRemark,"");
					 tc_strcpy(SupplierName,"");
					 tc_strcpy(TkoStatus,"");
					 tc_strcpy(TRSOStatus,"");
					 tc_strcpy(IndPrtEstCost,"");
				
					printf("SSSSSSSS--->StringLine1 is.... = %s\n",StringLine1);fflush(stdout);
					
					Ind_Part=strtok(StringLine1,"~"); trim(Ind_Part);  //1
					printf("\n Ind_Part : %s",Ind_Part);fflush(stdout);
					
				//	Ind_PartRevSeq=strtok(NULL,"~"); trim(Ind_PartRevSeq);  //2
				//	printf("\n Ind_PartRevSeq : %s",Ind_PartRevSeq);fflush(stdout);
					
					ERCIndQtySet=strtok(NULL,"~"); trim(ERCIndQtySet);  //2
					printf("\n ERCIndQtySet : %s",ERCIndQtySet);fflush(stdout);
					
					ERCIndReqdSet=strtok(NULL,"~"); trim(ERCIndReqdSet);  //3
					printf("\n ERCIndReqdSet : %s",ERCIndReqdSet);fflush(stdout);
					
					ERIndIR=strtok(NULL,"~"); trim(ERIndIR);  //4
					printf("\n ERIndIR : %s",ERIndIR);fflush(stdout);
					
					RemarkForIndenticalPart=strtok(NULL,"~"); trim(RemarkForIndenticalPart);  //5
					printf("\n RemarkForIndenticalPart : %s",RemarkForIndenticalPart);fflush(stdout);
					
					PartIndDisposal=strtok(NULL,"~"); trim(PartIndDisposal);  //6
					printf("\n PartIndDisposal : %s",PartIndDisposal);fflush(stdout);
					
					ERCIndCompltQtySet=strtok(NULL,"~"); trim(ERCIndCompltQtySet);  //7
					printf("\n ERCIndCompltQtySet : %s",ERCIndCompltQtySet);fflush(stdout);
					
					ERIndIRAvl=strtok(NULL,"~"); trim(ERIndIRAvl);  //8
					printf("\n ERIndIRAvl : %s",ERIndIRAvl);fflush(stdout);
					
					PartIndCategory=strtok(NULL,"~"); trim(PartIndCategory);  //9
					printf("\n PartIndCategory : %s",PartIndCategory);fflush(stdout);
					
					ERCIndentee=strtok(NULL,"~"); trim(ERCIndentee);  //10
					printf("\n ERCIndentee : %s",ERCIndentee);fflush(stdout);
					
					ERCIndRemark=strtok(NULL,"~"); trim(ERCIndRemark);  //11
					printf("\n ERCIndRemark : %s",ERCIndRemark);fflush(stdout);
					
					SupplierName=strtok(NULL,"~"); trim(SupplierName);  //12
					printf("\n SupplierName : %s",SupplierName);fflush(stdout);
					
					TkoStatus=strtok(NULL,"~"); trim(TkoStatus);  //13
					printf("\n TkoStatus : %s",TkoStatus);fflush(stdout);
					
					TRSOStatus=strtok(NULL,"~"); trim(TRSOStatus);  //14
					printf("\n TRSOStatus : %s",TRSOStatus);fflush(stdout);
					
					IndPrtEstCost=strtok(NULL,"~"); trim(IndPrtEstCost);  //15
					printf("\n IndPrtEstCost : %s",IndPrtEstCost);fflush(stdout);
					
					
					
					tag_t prtObjTag=NULLTAG;
					printf("\n Before calling function");fflush(stdout);
					
					ITEM_find_item(Ind_Part,&IndTag);
					if(IndTag !=NULLTAG)
					{
						ITEM_ask_latest_rev(IndTag,&IndRevTag);
						AOM_UIF_ask_value(IndRevTag,"release_status_list",&t5rlz_list);
						printf("\n t5rlz_list is :%s",t5rlz_list); fflush(stdout);
						
						AOM_ask_value_string(IndRevTag,"item_revision_id",&Ind_PartRevSeq);
						printf("\n Ind_PartRevSeq is :%s",Ind_PartRevSeq); fflush(stdout);
						
						if((tc_strstr(t5rlz_list,"Released")!=NULL) || (tc_strstr(t5rlz_list,"T5_LcsErcRlzd")!=NULL) || (tc_strstr(t5rlz_list,"ERC Released")!=NULL))
						{
							AOM_ask_value_string(IndRevTag,"item_revision_id",&latest_PartRevSeq);
							printf("\n latest_PartRevSeq is :%s",latest_PartRevSeq); fflush(stdout);
							
							if(tc_strlen(latest_PartRevSeq) >0)
							{
								tc_strcpy(Ind_PartRevSeq,latest_PartRevSeq);
							}
						}
						
						else
						{
							if(tc_strstr(Ind_PartRevSeq,"NR")!=NULL)
							{
								printf("\n Ind_PartRevSeq contains NR");
								if((tc_strstr(t5rlz_list,"Released")!=NULL) || (tc_strstr(t5rlz_list,"T5_LcsErcRlzd")!=NULL) || (tc_strstr(t5rlz_list,"ERC Released")!=NULL))
								{
									AOM_ask_value_string(IndRevTag,"item_revision_id",&Ind_PartRevSeq_NR);
									printf("\n Ind_PartRevSeq_NR is :%s",Ind_PartRevSeq_NR); fflush(stdout);
									
									if(tc_strlen(Ind_PartRevSeq_NR) >0)
										
									{
									tc_strcpy(Ind_PartRevSeq,Ind_PartRevSeq_NR);
									}
								}
								else
								{	
									printf("\n latest NR revision doesn't have ERC Released status");
								}
								
								
								
							}
							else
							{
								
								printf("\n Ind_PartRevSeq doesn't contains NR");
								tm_find_Prev_Official_Rev(Ind_Part,IndRevTag,&prevoffRev_tag);
								if(prevoffRev_tag!=NULLTAG)
								{
									printf("\nPrevious official Revision found \n");fflush(stdout);
					
									AOM_ask_value_string(prevoffRev_tag,"item_revision_id",&prev_rev_RevId);
									printf("\n previous_prev_rev_RevId is  :%s\n",prev_rev_RevId);fflush(stdout);
									
									if(tc_strlen(prev_rev_RevId) >0)
									{
									tc_strcpy(Ind_PartRevSeq,prev_rev_RevId);
									}
								}	
							}
						}
							
					}
					printf("\n Ind_PartRevSeq is %s",Ind_PartRevSeq);
					queryObject(Ind_Part,Ind_PartRevSeq,&prtObjTag);
					printf("\n After calling function");fflush(stdout);
					char* Primary_item_id=NULL;
					AOM_UIF_ask_value(prtObjTag,"item_id",&Primary_item_id);
					printf("\n Primary_item_id[%s]",Primary_item_id);fflush(stdout);
					tag_t relation_type=NULLTAG;
					int count=0;
					GRM_find_relation_type("T5ERCDtl",&relation_type);
					tag_t *PartRevisionObj=NULLTAG;
					GRM_list_primary_objects_only(uaindObj,relation_type,&count,&PartRevisionObj);
					printf("\n count of primary obj PartRevisionObj is:%d",count);fflush(stdout);
					int k=0;
					int item_found=0;
					
					if(count > 0)
					{
						for(k=0;k<count;k++ )
						{
							char* secondry_item_id=NULL;
							 tag_t PartRevision_tag=NULLTAG;
							PartRevision_tag = PartRevisionObj[k];
							AOM_UIF_ask_value(PartRevision_tag,"item_id",&secondry_item_id);
							printf("\n secondry_object_item_id---->[%s]",secondry_item_id);fflush(stdout);
							printf("\n Primary_itemid---->[%s]",Primary_item_id);fflush(stdout);
							if(tc_strcmp(secondry_item_id,Primary_item_id)==0)
							{
								item_found++;
							}
						}
					}
					printf("\n item_found---->%d",item_found);fflush(stdout);
					if(item_found>=0)
					{
						tag_t item_create_input_tag = NULLTAG;
						 char* reltypeUID=NULL;
						 char* l_rev_tagtypeUID=NULL;
						 char* r_rev_tagtypeUID=NULL;
						 
						 tag_t  inter_item_type_tag=NULLTAG;
						tag_t	PartIndrel				=   NULLTAG;
						GRM_find_relation_type("T5ERCDtl",&PartIndrel);
						TCTYPE_find_type("T5ERCDtl", NULL , &inter_item_type_tag);
						
						if(PartIndrel==NULLTAG)
						{
							printf("\n releation NOT found");fflush(stdout);
						}
						else
						{
							printf("\n releation found");fflush(stdout);
						}
						
						if(inter_item_type_tag==NULLTAG)
						{
							printf("\n releation type NOT found");fflush(stdout);
						}
						else
						{
							printf("\n releation type found");fflush(stdout);
						}
						 
						 TCTYPE_construct_create_input (inter_item_type_tag, &item_create_input_tag);
						 if(item_create_input_tag==NULLTAG)
						 {
							 printf("\n releation NOT created");fflush(stdout);
						 }
						 else
						 {
							 printf("\n releation created");fflush(stdout);
						 }
						 
						AOM_tag_to_string( PartIndrel, &reltypeUID );
						printf("\n releation reltypeUID=[%s]",reltypeUID);fflush(stdout);
						char	*IndentName			=	NULL;
						AOM_ask_value_string(uaindObj,"item_id",&IndentName);
						printf("\n Indent number [%s]",IndentName);fflush(stdout);

						AOM_tag_to_string( uaindObj, &l_rev_tagtypeUID );
						printf("\n Indent l_rev_tagtypeUID=[%s]",l_rev_tagtypeUID);fflush(stdout);
						
						char	*prtNum		= NULL;
						AOM_ask_value_string(prtObjTag,"item_id",&prtNum);

						printf("\n prtNum [%s]",prtNum);fflush(stdout);
						
						AOM_tag_to_string( prtObjTag, &r_rev_tagtypeUID );
						printf("\n part r_rev_tagtypeUID=[%s]",r_rev_tagtypeUID);fflush(stdout);
						
						const char* ol_rev_tagtypeUID[]={l_rev_tagtypeUID};
						const char* or_rev_tagtypeUID[]={r_rev_tagtypeUID};
						const char* oreltypeUID[]={reltypeUID};
						
						if(item_create_input_tag!=NULLTAG)
						{
							printf("\n hhhh1 ");fflush(stdout);
							TCTYPE_set_create_display_value(item_create_input_tag, "primary_object", 1,  ol_rev_tagtypeUID);
							printf("\n  indent ol_rev_tagtypeUID=[%s]",ol_rev_tagtypeUID[0]);fflush(stdout);
							printf("\n 2");fflush(stdout);
						  
							TCTYPE_set_create_display_value(item_create_input_tag, "secondary_object",  1,  or_rev_tagtypeUID);
							printf("\n Part or_rev_tagtypeUID=[%s]",or_rev_tagtypeUID[0]);fflush(stdout);
							printf("\n 3");fflush(stdout);;
							TCTYPE_set_create_display_value(item_create_input_tag, "relation_type",1,  oreltypeUID);
							printf("\n reltation oreltypeUID=[%s]",oreltypeUID[0]);fflush(stdout);
							
							 printf("\n ERCIndQtySet=[%s]",ERCIndQtySet);fflush(stdout);
							 printf("\n ERCIndReqdSet=[%s]",ERCIndReqdSet);fflush(stdout);
							 printf("\n ERIndIR=%s",ERIndIR);fflush(stdout);
							 printf("\n RemarkForIndenticalPart=[%s]",RemarkForIndenticalPart);fflush(stdout);
							 printf("\n PartIndDisposal=[%s]",PartIndDisposal);fflush(stdout);
							 printf("\n ERCIndCompltQtySet=[%s]",ERCIndCompltQtySet);fflush(stdout);
							 printf("\n ERIndIRAvl=[%s]",ERIndIRAvl);fflush(stdout);
							 printf("\n PartIndCategory=[%s]",PartIndCategory);fflush(stdout);
							 printf("\n ERCIndentee=[%s]",ERCIndentee);fflush(stdout);
							 printf("\n ERCIndRemark=[%s]",ERCIndRemark);fflush(stdout);
							 printf("\n SupplierName=[%s]",SupplierName);fflush(stdout);
							 printf("\n TkoStatus=[%s]",TkoStatus);fflush(stdout);
							 printf("\n TRSOStatus=[%s]",TRSOStatus);fflush(stdout);
							 printf("\n IndPrtEstCost=[%s]",IndPrtEstCost);fflush(stdout);
							 
							AOM_set_value_string(item_create_input_tag, "t5_ERCIndQtySet",  ERCIndQtySet);
							AOM_set_value_string(item_create_input_tag, "t5_ERCIndReqdSet",ERCIndReqdSet);
							AOM_set_value_string(item_create_input_tag, "t5ERIndIR",ERIndIR);
							AOM_set_value_string(item_create_input_tag, "t5_RemarkForIndenticalPart",RemarkForIndenticalPart);
							AOM_set_value_string(item_create_input_tag, "t5_PartIndDisposal",  PartIndDisposal);
							AOM_set_value_string(item_create_input_tag, "t5_ERCIndCompltQtySet",ERCIndCompltQtySet);
							AOM_set_value_string(item_create_input_tag, "t5ERIndIRAvl",ERIndIRAvl);
							AOM_set_value_string(item_create_input_tag, "t5_PartIndCategory",PartIndCategory);
							AOM_set_value_string(item_create_input_tag, "t5_ERCIndRemarkIndentee",  ERCIndentee);
							AOM_set_value_string(item_create_input_tag, "t5ERCIndRemark",ERCIndRemark);
							AOM_set_value_string(item_create_input_tag, "t5_SupplierName",SupplierName);
							AOM_set_value_string(item_create_input_tag, "t5_TkoStatus",TkoStatus);
							AOM_set_value_string(item_create_input_tag, "t5_TRSOStatus",TRSOStatus);
							AOM_set_value_string(item_create_input_tag, "t5_ERCIndPrtEstCost",IndPrtEstCost);

							tag_t item_tag = NULLTAG;				
							printf("\n After seting value\n");fflush(stdout);	
							
							TCTYPE_create_object(item_create_input_tag, &item_tag );
							 if(item_tag==NULLTAG)
							 {
								  printf("\n item_tag1null");fflush(stdout);	
							 }
							 else
							 {
								 printf("\n item_tag1 mot null");fflush(stdout);
								AOM_save_with_extensions(item_tag);								 
							 }
							 printf("\n After seting value relation created \n");fflush(stdout);
						}
					}
					
				}
			}
		}
	}
	
return ITK_ok;
}
int tm_CreIndPartRelServ()
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *IndentNO         = NULL;
	char     *Infiledata         = NULL;		

	printf("\n inside the function DML_ImplosionRpt .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&IndentNO);
	USERARG_get_string_argument(&Infiledata);

	printf("\n Input Indent number :: [%s]",IndentNO);fflush(stdout);
	printf("\n Input File data is   :: [%s]",Infiledata);fflush(stdout);

	//..........................................................
		
	tm_CreIndPartRelFuncation(IndentNO,Infiledata);

    return ifail;
}


extern int tm_CreIndPartRelFunc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 2;
	int ret_value_type;
	int input_arg_type[2] = {0};
	
	input_arg_type[0]=USERARG_STRING_TYPE;//Indent Number number
	input_arg_type[1]=USERARG_STRING_TYPE;//file data 
	ret_value_type = USERARG_STRING_TYPE;
 	
	
	printf("\n Before registing ...tm_CreIndPartRelServ\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_CreIndPartRelServ",(USER_function_t)tm_CreIndPartRelServ,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_CreIndPartRelServ\n");fflush(stdout);
	
		
	
	
	return ifail;
}




// extern int tm_CreIndPartRel_register_method(int *decision, va_list args)
// {
    // int ifail = ITK_ok;
	// *decision = ALL_CUSTOMIZATIONS;
	
   // //Define Rule/Action handler here

	
    // return ifail;
// }


extern DLLAPI int tm_CreIndPartRel_register_callbacks ()
{	
    int ifail    = ITK_ok;
	//printf("\n tm_CreIndPartRel_register_callbacks:Before registoring....");  
    //ifail=CUSTOM_register_exit ( "tm_CreIndPartRel", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_CreIndPartRel_register_method);
	//printf("\n tm_CreIndPartRel_register_callbacks: After registoring....");
	
	//printf("\n Started- Registering user service function tm_CreIndPartRelFunc...");
	ifail=CUSTOM_register_exit ( "tm_CreIndPartRel", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_CreIndPartRelFunc);//user service not use
	//printf("\n Completed- Registering user service function tm_CreIndPartRelFunc...");
	
  return ( ITK_ok );
}


