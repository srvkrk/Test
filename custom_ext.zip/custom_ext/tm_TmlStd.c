/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_TmlStd.c
* Created By                   : Sudhir
* Created On                   : 01-June-2020
* Project                      : TML Standard Document
* Methods Defined              : CUSTOM_EXIT
* Description                  : On TML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
//#define _CRT_SECURE_NO_DEPRECATE					
#include <stdlib.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64 
#define PROJ_name_size_c   32 
#define	t9TMLSTD_Val001 (EMH_USER_error_base+21)
#define	t9ISSTD_Val001 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val005 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val006 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val007 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val008 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val009 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val010 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val011 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val012 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val013 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val014 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val015 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val016 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val017 (EMH_USER_error_base+21)
#define	t9TMLSTD_Val018 (EMH_USER_error_base+21)

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

char *newval = (char*) malloc(12);

strncpy(newval, val,11);
printf("\n newval=%s",newval);fflush(stdout);

return newval;

}
char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(30);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	TC_write_syslog("\n start:getCurrentDateTime.\n");
	printf("\n getCurrentDateTime calling..........:\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate::%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
	TC_write_syslog("\n End:getCurrentDateTime.\n");
}

int t5removeAllReleaseStatus (tag_t rev)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	WSOM_ask_release_status_list(rev,&status_count,&status_list);

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		POM_class_of_instance(rev,&class_id);
		POM_name_of_class(class_id,&class_name);
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList);fflush(stdout);

		POM_unload_instances (1,&rev);
		POM_load_instances(1,&rev,class_id,1);
		POM_is_loaded(rev,&log1);
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		POM_length_of_attr(rev, tReleaseStatusList, &n_values);
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty );
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1);
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				POM_save_instances(1,&rev,1);

				POM_refresh_instances(1,&rev,class_id,2);

				AOM_lock(rev);

				AOM_save_without_extensions(rev);
				AOM_refresh(rev,1);

			}

			 AOM_unlock(rev);
		}
		printf("\n Status removed");;fflush(stdout);
	}
		AOM_unlock(rev);

		return ifail;
}

int tm_CreSetstatus(tag_t InpObjTag,char *inprelstat)
{
	tag_t   release_status 			=	NULLTAG;
	char* 	ReleaseStatus			=	NULL;
	char* 	Obj_type			=	NULL;
	int 	status	= 0;
	int		ifail					=	0;
	int	   	status_count			=	0;
	tag_t* 	status_list 			= NULLTAG;
	logical retain_released_date 	= false;
	char cCurrentAccessDate[20]={0};
	date_t	Current_date;

	printf("\n\t inside tm_CreSetstatus func with inprelstat --> %s",inprelstat);fflush(stdout);

	ReleaseStatus =(char *) MEM_alloc(20 * sizeof(char *));
	tc_strcpy(ReleaseStatus,inprelstat);
	printf("\n\t ReleaseStatus --> %s",ReleaseStatus);fflush(stdout);
	if(InpObjTag != NULLTAG)
	{
		if(ReleaseStatus)
		{
			WSOM_ask_release_status_list(InpObjTag,&status_count,&status_list);
			printf("\n\t REV status_count: %d",status_count);fflush(stdout);
			if (status_count == 0)
			{
				printf("---No Status, so the Design is created first time ");fflush(stdout);
				printf(" *****  Stamping Review Status on Design Revision *****");fflush(stdout);
				//CALLAPI(CR_create_release_status(ReleaseStatus,&release_status));
				RELSTAT_create_release_status(ReleaseStatus,&release_status);
				AOM_ask_name(release_status, &ReleaseStatus);
				printf("\t Value of ReleaseStatus: %s \n",ReleaseStatus);fflush(stdout);
				//CALLAPI(EPM_add_release_status(release_status, 1,&InpObjTag,false));
				RELSTAT_add_release_status(release_status,1,&InpObjTag,retain_released_date);
				printf("\t Value of ReleaseStatus after adding the status is : %s \n",ReleaseStatus);fflush(stdout);
				if((tc_strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0) || (tc_strcmp(ReleaseStatus,"ERC Released")==0))
				{
					AOM_ask_value_string(InpObjTag,"object_type",&Obj_type);
					printf("\n Under tm_CreSetstatus Object type value is %s",Obj_type);fflush(stdout);
					
					if(tc_strcmp(Obj_type,"T5_TMLStdRevision")==0 || tc_strcmp(Obj_type,"TML Std Revision")==0)
					{
						printf("\n Under tm_CreSetstatus ITK_string_to_date..value_date");fflush(stdout);
			
						getCurrentDateTime(cCurrentAccessDate);
						printf("\n Under tm_CreSetstatus cCurrentAccessDate : %s",cCurrentAccessDate);
				
						ITK_string_to_date(cCurrentAccessDate,&Current_date);
						printf("\n Under tm_CreSetstatus ITK_string_to_date..Current_date");fflush(stdout);
						
						AOM_lock(InpObjTag);
						printf("\n Under tm_CreSetstatus object is locked for updation");fflush(stdout);
						AOM_set_value_date(InpObjTag,"t5_TSRelDate",Current_date);
						AOM_save_without_extensions(InpObjTag);
						AOM_unlock(InpObjTag);
					}
					else
					{
						printf("\n Object Type is different.");fflush(stdout);
					}
				}
			}
		}
	}

	printf ("\n--------------tm_CreSetstatus=Completed--------------------\n");	fflush(stdout);

	return ifail;
}

void LovsetAddStr(int *count,char ***strset,char* str)
{
               //printf("\n 1 LovsetAddStr %d",*count);fflush(stdout);
			   *count=*count+1;
               //printf("\n 2 LovsetAddStr %d",*count);fflush(stdout);
               if(*count==1)
               {
                             // (*strset) = (char **)malloc((*count ) * sizeof(char *));
                              (*strset) = (char **)MEM_alloc((*count ) * sizeof(char *));
               }
               else
               {
                            //  (*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
                              (*strset) = (char **)MEM_realloc((*strset),(*count ) * sizeof(char *));
               }
              // (*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
               (*strset)[*count-1] = MEM_alloc((strlen(str)+1) * sizeof(char));
               tc_strcpy((*strset)[*count-1],str);
               //printf("\n LovsetAddStr::Added in Set ===%s",(*strset)[*count-1]);fflush(stdout);
			   //printf("\n 3 LovsetAddStr %d",*count);fflush(stdout);
}


int GetIStdLOVValuesMethod( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *tml_std_number = NULL;
	char *tml_std_numberDup = NULL;
	char *is_std_number = NULL;
	char *is_std_numberDup = NULL;
	char *stringList1 = NULL;
	char *stringList2 = NULL;
	char *sStdInd = NULL;
	char *sStdIndDup = NULL;
	char *sStdPart = NULL;
	char *sStdPartDup = NULL;
	char *sStdSec = NULL;
	char *sStdSecDup = NULL;
	char *sAmendment = NULL;
	char *sAmendmentDup = NULL;
	char	**LovSetValues = NULL;//Make a string array
	int status;

    int
        error_code = ITK_ok,
        n_entries = 1,
        n_entries1 = 1,
        n_found = 0,
        n_found1 = 0,
        ii = 0,
		icount = 0,
		kk = 0,
        jj = 0;
    tag_t
        query = NULLTAG,
        query1 = NULLTAG,
        *tmlstd_objects = NULLTAG,
        *isstd_objects = NULLTAG,
        user = NULLTAG;
    char
         *qry_entries[1] = {"ID"},
        *qry_values[1] =  {"*"};

	char
         *qry_entries1[1] = {"ID"},
        *qry_values1[1] =  {"*"};

	printf("\n GetIStdLOVValuesMethod--");fflush(stdout);

    QRY_find2("TML Standard Document", &query);
	printf("\nquery---");fflush(stdout);
	if (query)
	{
		printf("\n MT:Found Query");fflush(stdout);
	}
	else
	{
		printf("\n MT:Not Found Query");fflush(stdout);
	}
    QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &tmlstd_objects);
    printf("\n n_found %d", n_found);fflush(stdout);
	QRY_find2("IS Standard Document", &query1);
	printf("\n query1---");fflush(stdout);
    QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &isstd_objects);
    printf("\n n_found1 %d", n_found1);fflush(stdout);

	LovSetValues = (char**)MEM_alloc(1 * sizeof *LovSetValues);
	for(ii = 0; ii < n_found; ii++)
	{
		
		AOM_ask_value_string(tmlstd_objects[ii],"item_id",&tml_std_numberDup);
		if(tml_std_numberDup)tml_std_number = strdup(tml_std_numberDup);
		//printf("\n tml_std_number [%s]\n", tml_std_number);fflush(stdout);
		if (tc_strcmp(stringList1,"NULL") !=0) MEM_free(stringList1);
		stringList1 = (char *) MEM_alloc(40);
		tc_strcpy(stringList1,tml_std_number);
		tc_strcat(stringList1,",TS");
		//printf("\n stringList1=====> [%s]\n", stringList1);fflush(stdout);
		if(tml_std_number!=NULL)
		{
			//printf("\n ii===> %d", ii);fflush(stdout);			
			LovsetAddStr(&icount,&LovSetValues,stringList1);
			
		}
	}
	for (jj = 0; jj < n_found1; jj++)
	{
		AOM_ask_value_string(isstd_objects[jj],"item_id",&is_std_numberDup);
		AOM_ask_value_string(isstd_objects[jj],"t5_IsStdIndicator",&sStdIndDup);
		AOM_ask_value_string(isstd_objects[jj],"t5_IsStdPar",&sStdPartDup);
		AOM_ask_value_string(isstd_objects[jj],"t5_IsStdSec",&sStdSecDup);
		AOM_ask_value_string(isstd_objects[jj],"t5_IsStdYear",&sAmendmentDup);
		if(is_std_numberDup)is_std_number = strdup(is_std_numberDup);
		if(sStdIndDup)sStdInd = strdup(sStdIndDup);
		if(sStdPartDup)sStdPart = strdup(sStdPartDup);
		if(sStdSecDup)sStdSec = strdup(sStdSecDup);
		if(sAmendmentDup)sAmendment = strdup(sAmendmentDup);
		if (tc_strcmp(stringList2,"NULL") !=0) MEM_free(stringList2);
		stringList2 = (char *) MEM_alloc(50);
		tc_strcpy(stringList2,is_std_number);
		tc_strcat(stringList2 ,",");
		if(sStdInd)
		{
			tc_strcat(stringList2,sStdInd);
		}
		else
		{
			tc_strcat(stringList2," ");
		}
		tc_strcat(stringList2,",");
		if(sStdPart)
		{
			tc_strcat(stringList2,sStdPart);
		}
		else
		{
			tc_strcat(stringList2," ");
		}
		tc_strcat(stringList2,",");
		if(sStdSec)
		{
			tc_strcat(stringList2,sStdSec);
		}
		else
		{
			tc_strcat(stringList2," ");
		}
		tc_strcat(stringList2,",");
		if(sAmendment)
		{
			tc_strcat(stringList2,sAmendment);
		}
		else
		{
			tc_strcat(stringList2," ");
		}
		//printf("\n stringList2=====> [%s]\n", stringList2);fflush(stdout);
		if(is_std_number!=NULL)
		{
			//printf("\n jj===> %d", jj);fflush(stdout);			
			LovsetAddStr(&icount,&LovSetValues,stringList2);
			
		}
	}
	*n_values = n_found + n_found1;
	*values = (char **)MEM_alloc (*n_values * sizeof(char*));

	for(kk=0;kk<n_found+n_found1;kk++)
	{
		//printf("LovSetValues[%d]=====>[%s]",kk,LovSetValues[kk]);fflush(stdout);
		(*values)[kk] = (char *) MEM_alloc (n_found+n_found1 + 50);
		tc_strcpy((*values)[kk], LovSetValues[kk]);
	}
    TAG_free(tmlstd_objects);
    TAG_free(isstd_objects);
    TAG_free(stringList2);
    TAG_free(stringList1);
    return error_code;
}

/*

int ISDOCSENDMAIL(tag_t object_tag)
{
	int		ifail					=	0;
	
	tag_t Partowner=NULLTAG;
	char	*ownername=NULL;
	char	*STD_ind=NULL;
	char	*STD_no=NULL;
	char	*STD_sec=NULL;
	char	*Ctrl_cpy=NULL;
	char	*Amend=NULL;
	char	*STD_desc=NULL;
	char	*STD_yr=NULL;
	char	*Remark=NULL;
	char	*UserId=NULL;
	char	*STD_prt=NULL;
	
	
	char*env_subject=NULL;
	char*env_body=NULL;
	char*buff=NULL;
	tag_t	envelope					= NULLTAG;
	tag_t	session					= NULLTAG;
	tag_t	user_tag					= NULLTAG;
	
	POM_ask_session(&session);
	//POM_get_user_id(&UserId);
	POM_get_user_id(&UserId);
	printf("\n TMLSTD::UserId====>[%s]", UserId);fflush(stdout);
	SA_find_user2 (UserId, &user_tag);

	AOM_ask_value_string(object_tag,"t5_IsStdIndicator",&STD_ind);
	AOM_ask_value_string(object_tag,"item_id",&STD_no);
	AOM_ask_value_string(object_tag,"t5_IsStdPar",&STD_prt);
	AOM_ask_value_string(object_tag,"t5_IsStdSec",&STD_sec);
	AOM_ask_value_string(object_tag,"t5_CtrlCpy",&Ctrl_cpy);
	AOM_ask_value_string(object_tag,"t5_Amendment",&Amend);
	AOM_ask_value_string(object_tag,"t5_IsStdDesc",&STD_desc);
	AOM_ask_value_string(object_tag,"t5_IsStdYear",&STD_yr);
	AOM_ask_value_string(object_tag,"t5_Remarks",&Remark);
	//AOM_ask_value_string(object_tag,"Ow",&creator);
	
	AOM_ask_owner(object_tag,&Partowner);
	SA_ask_user_identifier2(Partowner,&ownername);
	
	printf("\n IS DOC Standard Indicator is %s",STD_ind);fflush(stdout);
	printf("\n IS DOC Standard Number is %s",STD_no);fflush(stdout);
	printf("\n IS DOC Standard Part is %s",STD_prt);fflush(stdout);
	printf("\n IS DOC Standard Section is %s",STD_sec);fflush(stdout);
	printf("\n IS DOC Control Copy is %s",Ctrl_cpy);fflush(stdout);
	printf("\n IS DOC Amendment is %s",Amend);fflush(stdout);
	printf("\n IS DOC Standard Description is %s",STD_desc);fflush(stdout);
	printf("\n IS DOC Standard Year is %s",STD_yr);fflush(stdout);
	printf("\n IS DOC IS Remarks is %s",Remark);fflush(stdout);
	printf("\n IS DOC Creator %s",ownername);fflush(stdout);
	
	env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
	tc_strcpy(env_subject,"Notification: ISO ");
	tc_strcat(env_subject,STD_no);
	tc_strcat(env_subject," has been Modified.");
	
	printf("\n Mail Subject is created");fflush(stdout);
	
	printf("\n Entering to write mail body");fflush(stdout);
	
	
	env_body = (char *) MEM_alloc( 10000 * sizeof(char) );
	tc_strcpy(env_body,"Dear User,");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Following National/International standard/s has been modified. Please review for the effects thereof & implementation of the same in existing referred designs to fulfil QMS adherence.");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"The status of the following National/International standard used by your department has been changed as mentioned below:");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Indicator......: ");
	tc_strcat(env_body,STD_ind);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Number.......: ");
	tc_strcat(env_body,STD_no);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Part.............: ");
	tc_strcat(env_body,STD_prt);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Section........: ");
	tc_strcat(env_body,STD_sec);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Control Copy..............: ");
	tc_strcat(env_body,Ctrl_cpy);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Amendment...............: ");
	tc_strcat(env_body,Amend);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Description..: ");
	tc_strcat(env_body,STD_desc);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Standard Year.............: ");
	tc_strcat(env_body,STD_yr);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"IS Remarks..................: ");
	tc_strcat(env_body,Remark);
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Creator........................: ");
	tc_strcat(env_body,ownername);
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"We request you to check effects of the same, If these are referred on the TML ERC Auto Drawings, TML Standards, Supply Specifications etc.");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"And take corrective action to update the documents accordingly to fulfill QMS and other requirements to give effect to TML product.");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"You can fired report to get details of IS and its affected Drawings");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Path: Info > CADBOM & DOC Reports > Standards and Drawing cross reference Reports");
	
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"Regards,");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"Knowledge Centre, ERC, Pune");
	tc_strcat(env_body,"\n");
	tc_strcat(env_body,"020-6613 2353");
	tc_strcat(env_body,"\n");

	printf("\n 1111111Mail body is created");fflush(stdout);
	
	buff=(char *) MEM_alloc(10000 * sizeof(char *));
	printf("\n 22222222under buff");fflush(stdout);
	
		if(user_tag != NULLTAG)
		{
	
			char *Analyst_email_addr= NULL;
			tag_t	Analyst_person_tag = NULLTAG;
			tag_t	*recievers = NULLTAG;
			int countenvelop = 0;
			AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
			SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
			if(tc_strlen(Analyst_email_addr)>0)
			{
				sprintf(buff,"( echo \"%s\"   )  | mail  -s \"%s\" -c \"sudhirs1.ttl@tatamotors.com\"  \"sm925545.ttl@tatamotors.com\" ",env_body,env_subject);

				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",env_body,env_subject,eMailCC,eMailTo);								
				
				
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
				printf("\n 2222222222exit under buff");fflush(stdout);
			}
		}
	
	//sprintf(buff,"( echo \"%s\"   )  | mail  -s \"%s\" -c \"sudhirs1.ttl@tatamotors.com\"  \"sm925545.ttl@tatamotors.com\" ",env_body,env_subject);								
	//printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
	//system(buff);
	//printf("\n 2222222222exit under buff");fflush(stdout);
	
	//tag_t	Env_tag	=NULLTAG;
	//tag_t	Env_create_input_tag	=NULLTAG;
	
	
	//TCTYPE_find_type("Envelope", "Envelope",&Env_tag);
	//TCTYPE_construct_create_input(Env_tag, &Env_create_input_tag);
	//AOM_set_value_string(Env_create_input_tag,"object_name",env_subject);
	//AOM_set_value_string(Env_create_input_tag, "object_desc", env_body);
	
	//TCTYPE_create_object(Env_create_input_tag, &envelope);
	//AOM_save_without_extensions(envelope);
	
	
	//MAIL_create_envelope(env_subject, env_body, &envelope);
	//printf("\n 111111envelope is created");fflush(stdout);
	
	/*
	if(envelope!=NULLTAG)
	{
		MAIL_initialize_envelope2(envelope, env_subject, env_body);
		
		printf("\n 444444444444 inside MAIL_initialize_envelope2");fflush(stdout);
		if(user_tag != NULLTAG)
		{
			char *Analyst_email_addr= NULL;
			tag_t	Analyst_person_tag = NULLTAG;
			tag_t	*recievers = NULLTAG;
			int countenvelop = 0;
			AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
			SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
			printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
			if(tc_strlen(Analyst_email_addr)>0)
			{
				MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
				printf("\n mail send to analyst");fflush(stdout);
			}
			else
			{
				MAIL_add_external_receiver(envelope, MAIL_send_to,"sudhirs1.ttl@tatamotors.com");
				printf("\n mail send to sudhir Srivastava");fflush(stdout);
			}
			//MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
			MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
			MAIL_send_envelope(envelope);
			
			MEM_free(Analyst_email_addr);
			//MEM_free(Analyst_person_tag);
			MEM_free(recievers);
		}
	}
	//else
	//{
	//	printf("\n 1111111envelope tag is NULL" );fflush(stdout);
	//}
	MEM_free(STD_ind);	
	MEM_free(STD_no);	
	MEM_free(STD_prt);	
	MEM_free(STD_sec);	
	MEM_free(Ctrl_cpy);	
	MEM_free(Amend);	
	MEM_free(STD_desc);	
	MEM_free(STD_yr);	
	MEM_free(Remark);	
	MEM_free(ownername);	
	MEM_free(env_body);	
	MEM_free(env_subject);	
	//MEM_free(envelope);	
	//MEM_free(session);	
	//MEM_free(user_tag);	
	MEM_free(UserId);	
	//MEM_free(Partowner);
	return ifail;
}
*/

int ISDOCSENDMAIL(tag_t object_tag)
{
	int		ifail					=	0;
	
	tag_t Partowner=NULLTAG;
	char	*ownername=NULL;
	char	*STD_ind=NULL;
	char	*STD_no=NULL;
	char	*STD_sec=NULL;
	char	*Ctrl_cpy=NULL;
	char	*Amend=NULL;
	char	*STD_desc=NULL;
	char	*STD_yr=NULL;
	char	*Remark=NULL;
	char	*UserId=NULL;
	char	*STD_prt=NULL;
	char	*STD_desc_dup=NULL;
	
	
	char*env_subject=NULL;
	char*env_body=NULL;
	char*buff=NULL;
	tag_t	envelope					= NULLTAG;
	tag_t	session					= NULLTAG;
	tag_t	user_tag					= NULLTAG;
	
	POM_ask_session(&session);
	//POM_get_user_id(&UserId);
	POM_get_user_id(&UserId);
	printf("\n TMLSTD::UserId====>[%s]", UserId);fflush(stdout);
	SA_find_user2 (UserId, &user_tag);

	AOM_ask_value_string(object_tag,"t5_IsStdIndicator",&STD_ind);
	AOM_ask_value_string(object_tag,"item_id",&STD_no);
	AOM_ask_value_string(object_tag,"t5_IsStdPar",&STD_prt);
	AOM_ask_value_string(object_tag,"t5_IsStdSec",&STD_sec);
	AOM_ask_value_string(object_tag,"t5_CtrlCpy",&Ctrl_cpy);
	AOM_ask_value_string(object_tag,"t5_Amendment",&Amend);
	AOM_ask_value_string(object_tag,"t5_IsStdDesc",&STD_desc);
	AOM_ask_value_string(object_tag,"t5_IsStdYear",&STD_yr);
	AOM_ask_value_string(object_tag,"t5_Remarks",&Remark);
	//AOM_ask_value_string(object_tag,"Ow",&creator);
	
	AOM_ask_owner(object_tag,&Partowner);
	SA_ask_user_identifier2(Partowner,&ownername);
	
	printf("\n IS DOC Standard Indicator is %s",STD_ind);fflush(stdout);
	printf("\n IS DOC Standard Number is %s",STD_no);fflush(stdout);
	printf("\n IS DOC Standard Part is %s",STD_prt);fflush(stdout);
	printf("\n IS DOC Standard Section is %s",STD_sec);fflush(stdout);
	printf("\n IS DOC Control Copy is %s",Ctrl_cpy);fflush(stdout);
	printf("\n IS DOC Amendment is %s",Amend);fflush(stdout);
	printf("\n IS DOC Standard Description is %s",STD_desc);fflush(stdout);
	printf("\n IS DOC Standard Year is %s",STD_yr);fflush(stdout);
	printf("\n IS DOC IS Remarks is %s",Remark);fflush(stdout);
	printf("\n IS DOC Creator %s",ownername);fflush(stdout);
	
	env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
	tc_strcpy(env_subject,"Notification: ISO ");
	tc_strcat(env_subject,STD_no);
	tc_strcat(env_subject," has been Modified.");
	
	printf("\n Mail Subject is created");fflush(stdout);
	
	printf("\n Entering to write mail body");fflush(stdout);
	
	
	env_body = (char *) MEM_alloc( 10000 * sizeof(char) );
	tc_strcpy(env_body,"\nDear User,");
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nFollowing National/International standard/s has been modified. Please review for the effects thereof & implementation of the same in existing referred designs to fulfil QMS adherence.");
	tc_strcat(env_body,"\nThe status of the following National/International standard used by your department has been changed as mentioned below:");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nStandard Indicator......: ");
	tc_strcat(env_body,STD_ind);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nStandard Number.......: ");
	tc_strcat(env_body,STD_no);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nStandard Part.............: ");
	tc_strcat(env_body,STD_prt);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nStandard Section........: ");
	tc_strcat(env_body,STD_sec);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nControl Copy..............: ");
	tc_strcat(env_body,Ctrl_cpy);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nAmendment...............: ");
	tc_strcat(env_body,Amend);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nStandard Description..: ");
	tc_strcat(env_body,STD_desc);
	
	//STRNG_replace_str(STD_desc,"\\n"," ",&STD_desc_dup);
	//tc_strcat(env_body,STD_desc_dup);
	//tc_strcat(env_body,"\n");
	
	//STRNG_replace_str(STD_desc,"\\n"," ",&STD_desc);
	//tc_strcat(env_body,STD_desc);
	
	tc_strcat(env_body,"\nStandard Year.............: ");
	tc_strcat(env_body,STD_yr);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nIS Remarks..................: ");
	tc_strcat(env_body,Remark);
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nCreator........................: ");
	tc_strcat(env_body,ownername);
	//tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nWe request you to check effects of the same, If these are referred on the TML ERC Auto Drawings, TML Standards, Supply Specifications etc.");
	
	tc_strcat(env_body,"\nAnd take corrective action to update the documents accordingly to fulfill QMS and other requirements to give effect to TML product.");
	
	
	
	tc_strcat(env_body,"\nYou can fired report to get details of IS and its affected Drawings");
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nPath: Info > CADBOM & DOC Reports > Standards and Drawing cross reference Reports");
	
	//tc_strcat(env_body,"\n");
	//tc_strcat(env_body,"\n");
	
	tc_strcat(env_body,"\nRegards,");
	//tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\nKnowledge Centre, ERC, Pune");
	//tc_strcat(env_body,"\n");
	tc_strcat(env_body,"\n020-6613 2353");
	tc_strcat(env_body,"\n");

	printf("\n 1111111Mail body is created");fflush(stdout);
	
	buff=(char *) MEM_alloc(10000 * sizeof(char *));
	printf("\n 22222222under buff");fflush(stdout);
	
	
		if(user_tag != NULLTAG)
		{
			char *Analyst_email_addr= NULL;
			tag_t	Analyst_person_tag = NULLTAG;
			tag_t	*recievers = NULLTAG;
			int countenvelop = 0;
			AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
			SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
			printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
			if(tc_strlen(Analyst_email_addr)>0 && tc_strstr(Analyst_email_addr,".com")!=NULL)
			{
				//sprintf(buff,"( echo \"%s\"   )  | mail  -s \"%s\" -c \"sudhirs1.ttl@tatamotors.com\"  \"sm925545.ttl@tatamotors.com\" ",env_body,env_subject);								
				
				//sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"   ",env_body,env_subject,Analyst_email_addr);	

				sprintf(buff,"( echo \"%s\"   )  | mail  -s \"%s\" -c \"sudhirs1.ttl@tatamotors.com\"  \"%s\" ",env_body,env_subject,Analyst_email_addr);
				
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
				printf("\n 2222222222exit after sending mail with buff");fflush(stdout);
				printf("\n mail send to analyst");fflush(stdout);
			}
			else
			{
				printf("\n User Email address is blank.");fflush(stdout);
				
				sprintf(buff,"( echo \"%s\"   )  | mail  -s \"%s\" -c \"sudhirs1.ttl@tatamotors.com\"  \"sm925545.ttl@tatamotors.com\" ",env_body,env_subject);
				
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
			MEM_free(Analyst_email_addr);
		}
		else
			{
				printf("\n User tag is NULL");fflush(stdout);
			}
		
	
	
	
	//tag_t	Env_tag	=NULLTAG;
	//tag_t	Env_create_input_tag	=NULLTAG;
	
	
	//TCTYPE_find_type("Envelope", "Envelope",&Env_tag);
	//TCTYPE_construct_create_input(Env_tag, &Env_create_input_tag);
	//AOM_set_value_string(Env_create_input_tag,"object_name",env_subject);
	//AOM_set_value_string(Env_create_input_tag, "object_desc", env_body);
	
	//TCTYPE_create_object(Env_create_input_tag, &envelope);
	//AOM_save_without_extensions(envelope);
	
	
	/*MAIL_create_envelope(env_subject, env_body, &envelope);
	printf("\n 111111envelope is created");fflush(stdout);
	
	//if(envelope!=NULLTAG)
	//{
		MAIL_initialize_envelope2(envelope, env_subject, env_body);
		
		printf("\n 444444444444 inside MAIL_initialize_envelope2");fflush(stdout);
		if(user_tag != NULLTAG)
		{
			char *Analyst_email_addr= NULL;
			tag_t	Analyst_person_tag = NULLTAG;
			tag_t	*recievers = NULLTAG;
			int countenvelop = 0;
			AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
			SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
			printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
			if(tc_strlen(Analyst_email_addr)>0)
			{
				MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
				printf("\n mail send to analyst");fflush(stdout);
			}
			else
			{
				MAIL_add_external_receiver(envelope, MAIL_send_to,"sudhirs1.ttl@tatamotors.com");
				printf("\n mail send to sudhir Srivastava");fflush(stdout);
			}
			//MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
			MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
			MAIL_send_envelope(envelope);
			
			MEM_free(Analyst_email_addr);
			//MEM_free(Analyst_person_tag);
			MEM_free(recievers);
		}*/
	//}
	//else
	//{
	//	printf("\n 1111111envelope tag is NULL" );fflush(stdout);
	//}
	MEM_free(STD_ind);	
	MEM_free(STD_no);	
	MEM_free(STD_prt);	
	MEM_free(STD_sec);	
	MEM_free(Ctrl_cpy);	
	MEM_free(Amend);	
	MEM_free(STD_desc);	
	MEM_free(STD_yr);	
	MEM_free(Remark);	
	MEM_free(ownername);	
	MEM_free(env_body);	
	MEM_free(env_subject);	
	//MEM_free(envelope);	
	//MEM_free(session);	
	//MEM_free(user_tag);	
	MEM_free(UserId);	
	//MEM_free(Partowner);
	return ifail;
}

extern DLLAPI int TMLSTDCheckin(METHOD_message_t *m, va_list args)
{
	tag_t	object_tag			= va_arg (args, tag_t);
	char *Obj_type=NULL;
	int checkin =0;
	int		ifail					=	0;
	
	printf("\n In TMLSTDCheckin Entering into RES Checkin Postaction TMLSTDCheckin");fflush(stdout);
	AOM_ask_value_string(object_tag,"object_type",&Obj_type);
	printf("\n Object type value is %s",Obj_type);fflush(stdout);
	
	//if(tc_strcmp(Obj_type,"T5_TMLStdRevision")==0 || tc_strcmp(Obj_type,"T5_IStdRevision")==0)
	if(tc_strcmp(Obj_type,"T5_TMLStdRevision")==0 || tc_strcmp(Obj_type,"T5_IStdRevision")==0 || tc_strcmp(Obj_type,"TML Std Revision")==0 || tc_strcmp(Obj_type,"IS Standard Class Revision")==0)
	{
		checkin =0;
		printf("\n Object type is TML STD Revision OR IS STD Revision");fflush(stdout);
		
		printf("\n Entering into function for removing release status on Object");fflush(stdout);
		t5removeAllReleaseStatus(object_tag);
		printf("\n Release Status have been removed");fflush(stdout);
		
		printf("\n 22222 Entering into function for adding checkin Release Status");fflush(stdout);
		tm_CreSetstatus(object_tag,"T5_LcsReview");
		printf("\n 22222 ERC Review Status has been stamped on checkin Objcet");fflush(stdout);
		printf("\n Checkin completed for TML STD/IS STD Document");fflush(stdout);
		
		checkin++;
	}
	if(checkin>0 && tc_strcmp(Obj_type,"T5_IStdRevision")==0)
	{	
		ISDOCSENDMAIL(object_tag);
	}
	
	
	printf("\n Exit from RES Checkin Postaction TMLSTDCheckin");
	return ifail;
	
}

extern DLLAPI int TMLSTDCheckout(METHOD_message_t *m, va_list args)
{
	tag_t	object_tag			= va_arg (args, tag_t);
	char *Obj_type=NULL;
	int checkin =0;
	int ifail = ITK_ok;
	
	printf("\n Entering into RES Checkout Postaction TMLSTDCheckout");fflush(stdout);
	AOM_ask_value_string(object_tag,"object_type",&Obj_type);
	printf("\n Object type value is %s",Obj_type);fflush(stdout);
	
	if(tc_strcmp(Obj_type,"T5_TMLStdRevision")==0 || tc_strcmp(Obj_type,"T5_IStdRevision")==0 || tc_strcmp(Obj_type,"TML Std Revision")==0 || tc_strcmp(Obj_type,"IS Standard Class Revision")==0)
	{
		checkin =0;
		printf("\n In TMLSTDCheckout Object type is TML STD Revision OR IS STD Revision");fflush(stdout);
		
		printf("\n In TMLSTDCheckout Entering into function for removing release status on Object");fflush(stdout);
		t5removeAllReleaseStatus(object_tag);
		printf("\n In TMLSTDCheckout Release Status have been removed");fflush(stdout);
		
		printf("\n In TMLSTDCheckout Entering into function for adding checkout Release Status");fflush(stdout);
		tm_CreSetstatus(object_tag,"T5_LcsWorking");
		printf("\n In TMLSTDCheckout ERC Working Status has been stamped on checkin Objcet");fflush(stdout);
		printf("\n In TMLSTDCheckout Checkout completed for TML STD/IS STD Document");fflush(stdout);
	}
	printf("\n Exit from RES Checkout Postaction TMLSTDCheckout");fflush(stdout);
	return ifail;
	
}

int tm_TMLStdVolupdateServ(void *return_data)
{
	int ifail = ITK_ok;

    int           noofEst                = 0;
    tag_t         *IndNumSet           = NULLTAG;
    tag_t         IndNumtag               = NULLTAG;
    char          *StringLine            = NULL;
	char          *Volume_no            = NULL;
	char          *output            = NULL;
	
	tag_t		IndTag		= NULLTAG;
	tag_t		IndRevTag		= NULLTAG;
	char		   *t5rlz_list	=NULL;
	tag_t prevoffRev_tag= NULLTAG;
	logical DelInd		= false;
	const char	*Syscd ="t5TStd";
	const char	*Subsyscd ="t5DVolNo";
	char *control_objname	=NULL;
	
	USERARG_get_string_argument(&Volume_no);

//	char *StringLine2 = NULL;	
	
	printf("\n Entering into tm_TMLStdVolupdateFunction ");fflush(stdout);
	
	//printf("\n Input Syscd is = [%s]",Syscd);fflush(stdout);
	//printf("\n Input SubSyscd is = [%s]",Subsyscd);fflush(stdout);
	printf("\n Input Volume_no is = [%s]",Volume_no);fflush(stdout);
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	int  create_flag 	= 0;
	
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	output = (char *) MEM_alloc(100 * sizeof(char *));
	control_objname = (char *) MEM_alloc(100 * sizeof(char *));
	
	qry_entriesInd[0] = "SYSCD";
	qry_entriesInd[1] = "SUBSYSCD";
	qry_entriesInd[2] = "Delete Indicator";
	qry_entriesInd[3] = "Information-1";
	
	qry_valuesInd[0] = "t5TStd";
	qry_valuesInd[1] = "t5DVolNo";
	qry_valuesInd[2] = "FALSE";
	qry_valuesInd[3] = Volume_no;
	
	QRY_find2("Control Objects...", &queryInd);
	QRY_execute(queryInd,4, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Control Object: count==>%d", count);fflush(stdout);
	
	if(count>0)
	{
		printf("\n Control Object is already found for this Volume ");fflush(stdout);
	}
	else
	{
		tag_t TmlStd_type_tag			= NULLTAG;
		tag_t object_create_input_tag   = NULLTAG;
		tag_t control_obj_tag   = NULLTAG;
		create_flag = 0;
		
		TCTYPE_find_type("T5_ControlObject", "T5_ControlObject",&TmlStd_type_tag);
		TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag);
		
		printf("\n Going for creation to Control object");fflush(stdout);
		
		tc_strcpy(control_objname,"t5TStd-t5DVolNo-");
		tc_strcat(control_objname,Volume_no);
		
		AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
		AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
		AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
		AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", Subsyscd);
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Volume_no);
		AOM_set_value_logical(object_create_input_tag,"t5_DelInd",DelInd);
		
		create_flag++;
		
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		
		if(create_flag > 0)
		{
			TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
			if(control_obj_tag !=NULLTAG)
			{
				AOM_lock(control_obj_tag);
				printf("\n object is locked for updation");fflush(stdout);
				AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
				AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
				AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
				AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", Subsyscd);
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Volume_no);
				AOM_set_value_logical(object_create_input_tag,"t5_DelInd",DelInd);
				AOM_save_without_extensions(control_obj_tag);
				AOM_unlock(control_obj_tag);
				printf("\n object is Unlocked for updation");fflush(stdout);
				tc_strcpy(output,Volume_no);
				tc_strcat(output,"#");
			}
		}
		
		//TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
		//AOM_save_without_extensions(control_obj_tag);
		
		printf("\n Control Object is created");fflush(stdout);
	}
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	MEM_free(itemObj);
	MEM_free(Volume_no);
	
	
	
return ITK_ok;
}

int tm_TMLStdKeyworServ(void *return_data)
{
	int ifail = ITK_ok;

	char          *Keyword1            = NULL;
	char          *Keyword2           = NULL;
	char          *Keyword3            = NULL;
	char          *output            = NULL;
	char          *KeywordComb            = NULL;

	const char	*Syscd ="StdKeyWord";
	char *control_objname	=NULL;
	
	USERARG_get_string_argument(&Keyword1);
	USERARG_get_string_argument(&Keyword2);
	USERARG_get_string_argument(&Keyword3);

//	char *StringLine2 = NULL;	
	
	printf("\n Entering into tm_TMLStdKeyworServ ");fflush(stdout);
	
	//printf("\n Input Syscd is = [%s]",Syscd);fflush(stdout);
	//printf("\n Input SubSyscd is = [%s]",Subsyscd);fflush(stdout);
	printf("\n Input Keyword1 is = [%s]",Keyword1);fflush(stdout);
	printf("\n Input Keyword2 is = [%s]",Keyword2);fflush(stdout);
	printf("\n Input Keyword3 is = [%s]",Keyword3);fflush(stdout);
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	int  create_flag 	= 0;
	
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	output = (char *) MEM_alloc(100 * sizeof(char *));
	KeywordComb = (char *) MEM_alloc(100 * sizeof(char *));
	control_objname = (char *) MEM_alloc(100 * sizeof(char *));
	
	qry_entriesInd[0] = "SYSCD";
	qry_entriesInd[1] = "Information-1";
	qry_entriesInd[2] = "Information-2";
	qry_entriesInd[3] = "Information-3";
	
	qry_valuesInd[0] = "StdKeyWord";
	qry_valuesInd[1] = Keyword1;
	qry_valuesInd[2] = Keyword2;
	qry_valuesInd[3] = Keyword3;
	
	
	QRY_find2("Control Objects...", &queryInd);
	QRY_execute(queryInd,4, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Control Object: count==>%d", count);fflush(stdout);
	
	if(count>0)
	{
		printf("\n Control Object is already found for this Keyword combination ");fflush(stdout);
	}
	else
	{
		tag_t TmlStd_type_tag			= NULLTAG;
		tag_t object_create_input_tag   = NULLTAG;
		tag_t control_obj_tag   = NULLTAG;
		create_flag = 0;
		
		TCTYPE_find_type("T5_ControlObject", "T5_ControlObject",&TmlStd_type_tag);
		TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag);
		
		printf("\n Going for creation to Control object");fflush(stdout);
		
		tc_strcpy(control_objname,"StdKeyWord-StdKeyWord-");
		//tc_strcat(control_objname,Keyword1);
		
		AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
		AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
		AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
		AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Keyword1);
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo2", Keyword2);
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo3", Keyword3);
		
		create_flag++;
		
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		
		if(create_flag > 0)
		{
			TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
			if(control_obj_tag !=NULLTAG)
			{
				AOM_lock(control_obj_tag);
				printf("\n object is locked for updation");fflush(stdout);
				AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
				AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
				AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
				AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Keyword1);
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo2", Keyword2);
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo3", Keyword3);
				AOM_save_without_extensions(control_obj_tag);
				AOM_unlock(control_obj_tag);
				printf("\n object is Unlocked for updation");fflush(stdout);
				
				tc_strcpy(KeywordComb,Keyword1);
				tc_strcat(KeywordComb,",");
				tc_strcat(KeywordComb,Keyword2);
				tc_strcat(KeywordComb,",");
				tc_strcat(KeywordComb,Keyword3);
				
				tc_strcpy(output,KeywordComb);
				tc_strcat(output,"#");
			}
		}
		
		printf("\n Control Object is created");fflush(stdout);
	}
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	MEM_free(itemObj);
	MEM_free(Keyword1);	
	MEM_free(Keyword2);	
	MEM_free(Keyword3);	
return ITK_ok;
}




int tm_TMLStdKeywor1Serv(void *return_data)
{
	int ifail = ITK_ok;

	char          *Keyword1            = NULL;
	char          *output            = NULL;

	const char	*Syscd ="StdKeyWord";
	char *control_objname	=NULL;
	
	USERARG_get_string_argument(&Keyword1);

//	char *StringLine2 = NULL;	
	
	printf("\n Entering into tm_TMLStdKeywor1Serv ");fflush(stdout);
	
	//printf("\n Input Syscd is = [%s]",Syscd);fflush(stdout);
	//printf("\n Input SubSyscd is = [%s]",Subsyscd);fflush(stdout);
	printf("\n Input Keyword1 is = [%s]",Keyword1);fflush(stdout);
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	int  create_flag 	= 0;
	
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	output = (char *) MEM_alloc(100 * sizeof(char *));
	control_objname = (char *) MEM_alloc(100 * sizeof(char *));
	
	qry_entriesInd[0] = "SYSCD";
	qry_entriesInd[1] = "Information-1";
	
	qry_valuesInd[0] = "StdKeyWord";
	qry_valuesInd[1] = Keyword1;
	
	
	QRY_find2("Control Objects...", &queryInd);
	QRY_execute(queryInd,2, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Control Object: count==>%d", count);fflush(stdout);
	
	if(count>0)
	{
		printf("\n Control Object is already found for this Keyword1 ");fflush(stdout);
	}
	else
	{
		tag_t TmlStd_type_tag			= NULLTAG;
		tag_t object_create_input_tag   = NULLTAG;
		tag_t control_obj_tag   = NULLTAG;
		create_flag = 0;
		
		TCTYPE_find_type("T5_ControlObject", "T5_ControlObject",&TmlStd_type_tag);
		TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag);
		
		printf("\n Going for creation to Control object");fflush(stdout);
		
		tc_strcpy(control_objname,"StdKeyWord-StdKeyWord-");
		tc_strcat(control_objname,Keyword1);
		
		AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
		AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
		AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
		AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Keyword1);
		
		create_flag++;
		
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		
		if(create_flag > 0)
		{
			TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
			if(control_obj_tag !=NULLTAG)
			{
				AOM_lock(control_obj_tag);
				printf("\n object is locked for updation");fflush(stdout);
				AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
				AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
				AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
				AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo1", Keyword1);
				AOM_save_without_extensions(control_obj_tag);
				AOM_unlock(control_obj_tag);
				printf("\n object is Unlocked for updation");fflush(stdout);
				tc_strcpy(output,Keyword1);
				tc_strcat(output,"#");
			}
		}
		
		printf("\n Control Object is created");fflush(stdout);
	}
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	MEM_free(itemObj);
	MEM_free(Keyword1);	
return ITK_ok;
}

int tm_TMLStdKeywor2Serv(void *return_data)
{
	int ifail = ITK_ok;

	char          *Keyword2            = NULL;
	char          *output            = NULL;

	const char	*Syscd ="StdKeyWord";
	char *control_objname	=NULL;
	
	USERARG_get_string_argument(&Keyword2);

//	char *StringLine2 = NULL;	
	
	printf("\n Entering into tm_TMLStdKeywor2Serv ");fflush(stdout);
	
	//printf("\n Input Syscd is = [%s]",Syscd);fflush(stdout);
	//printf("\n Input SubSyscd is = [%s]",Subsyscd);fflush(stdout);
	printf("\n Input Keyword2 is = [%s]",Keyword2);fflush(stdout);
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	int  create_flag 	= 0;
	
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	output = (char *) MEM_alloc(100 * sizeof(char *));
	control_objname = (char *) MEM_alloc(100 * sizeof(char *));
	
	qry_entriesInd[0] = "SYSCD";
	qry_entriesInd[1] = "Information-2";
	
	qry_valuesInd[0] = "StdKeyWord";
	qry_valuesInd[1] = Keyword2;
	
	
	QRY_find2("Control Objects...", &queryInd);
	QRY_execute(queryInd,2, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Control Object: count==>%d", count);fflush(stdout);
	
	if(count>0)
	{
		printf("\n Control Object is already found for this Keyword1 ");fflush(stdout);
	}
	else
	{
		tag_t TmlStd_type_tag			= NULLTAG;
		tag_t object_create_input_tag   = NULLTAG;
		tag_t control_obj_tag   = NULLTAG;
		create_flag = 0;
		
		TCTYPE_find_type("T5_ControlObject", "T5_ControlObject",&TmlStd_type_tag);
		TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag);
		
		printf("\n Going for creation to Control object");fflush(stdout);
		
		tc_strcpy(control_objname,"StdKeyWord-StdKeyWord-");
		tc_strcat(control_objname,Keyword2);
		
		AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
		AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
		AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
		AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo2", Keyword2);
		
		create_flag++;
		
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		
		if(create_flag > 0)
		{
			TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
			if(control_obj_tag !=NULLTAG)
			{
				AOM_lock(control_obj_tag);
				printf("\n object is locked for updation");fflush(stdout);
				AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
				AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
				AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
				AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo2", Keyword2);
				AOM_save_without_extensions(control_obj_tag);
				AOM_unlock(control_obj_tag);
				printf("\n object is Unlocked for updation");fflush(stdout);
				tc_strcpy(output,Keyword2);
				tc_strcat(output,"#");
			}
		}
		
		printf("\n Control Object is created");fflush(stdout);
	}
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	MEM_free(itemObj);
	MEM_free(Keyword2);	
return ITK_ok;
}

int tm_TMLStdKeywor3Serv(void *return_data)
{
	int ifail = ITK_ok;

	char          *Keyword3            = NULL;
	char          *output            = NULL;

	const char	*Syscd ="StdKeyWord";
	char *control_objname	=NULL;
	
	USERARG_get_string_argument(&Keyword3);

//	char *StringLine2 = NULL;	
	
	printf("\n Entering into tm_TMLStdKeywor2Serv ");fflush(stdout);
	
	//printf("\n Input Syscd is = [%s]",Syscd);fflush(stdout);
	//printf("\n Input SubSyscd is = [%s]",Subsyscd);fflush(stdout);
	printf("\n Input Keyword3 is = [%s]",Keyword3);fflush(stdout);
	
	tag_t queryInd = NULLTAG;
	tag_t *itemObj = NULLTAG;
	int  count 	= 0;
	int  create_flag 	= 0;
	
	
	char **qry_entriesInd = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesInd = (char **) MEM_alloc(10 * sizeof(char *));
	
	output = (char *) MEM_alloc(100 * sizeof(char *));
	control_objname = (char *) MEM_alloc(100 * sizeof(char *));
	
	qry_entriesInd[0] = "SYSCD";
	qry_entriesInd[1] = "Information-3";
	
	qry_valuesInd[0] = "StdKeyWord";
	qry_valuesInd[1] = Keyword3;
	
	
	QRY_find2("Control Objects...", &queryInd);
	QRY_execute(queryInd,2, qry_entriesInd, qry_valuesInd, &count, &itemObj);
	printf("\n Control Object: count==>%d", count);fflush(stdout);
	
	if(count>0)
	{
		printf("\n Control Object is already found for this Keyword1 ");fflush(stdout);
	}
	else
	{
		tag_t TmlStd_type_tag			= NULLTAG;
		tag_t object_create_input_tag   = NULLTAG;
		tag_t control_obj_tag   = NULLTAG;
		create_flag = 0;
		
		TCTYPE_find_type("T5_ControlObject", "T5_ControlObject",&TmlStd_type_tag);
		TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag);
		
		printf("\n Going for creation to Control object");fflush(stdout);
		
		tc_strcpy(control_objname,"StdKeyWord-StdKeyWord-");
		tc_strcat(control_objname,Keyword3);
		
		AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
		AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
		AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
		AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
		AOM_set_value_string(object_create_input_tag, "t5_Userinfo3", Keyword3);
		
		create_flag++;
		
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		
		if(create_flag > 0)
		{
			TCTYPE_create_object(object_create_input_tag, &control_obj_tag);
			if(control_obj_tag !=NULLTAG)
			{
				AOM_lock(control_obj_tag);
				printf("\n object is locked for updation");fflush(stdout);
				AOM_set_value_string(object_create_input_tag,"object_string",control_objname);
				AOM_set_value_string(object_create_input_tag,"object_name",control_objname);
				AOM_set_value_string(object_create_input_tag,"t5_Syscd",Syscd);
				AOM_set_value_string(object_create_input_tag, "t5_SubSyscd", "StdKeyWord");
				AOM_set_value_string(object_create_input_tag, "t5_Userinfo3", Keyword3);
				AOM_save_without_extensions(control_obj_tag);
				AOM_unlock(control_obj_tag);
				printf("\n object is Unlocked for updation");fflush(stdout);
				tc_strcpy(output,Keyword3);
				tc_strcat(output,"#");
			}
		}
		
		printf("\n Control Object is created");fflush(stdout);
	}
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	MEM_free(itemObj);
	MEM_free(Keyword3);	
return ITK_ok;
}


int tm_STD_ReleaseServ(void *return_data)
{
	int ifail = ITK_ok;
	char *STD_no=NULL;
	char *Type_value=NULL;
	char *typename=NULL;
	tag_t tItemobj = NULLTAG;
	tag_t STDMasterTag = NULLTAG;
	tag_t STDlatestRev = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char* RelStat = NULL;
	char* output = NULL;
	
	USERARG_get_string_argument(&STD_no);
	USERARG_get_string_argument(&Type_value);
	

	output = (char *) MEM_alloc(100 * sizeof(char *));
	
	printf("\n Entering into tm_STD_ReleaseServ ");fflush(stdout);
	
	
	printf("\n Input STD_no is = [%s]",STD_no);fflush(stdout);
	printf("\n Input Type_value is = [%s]",Type_value);fflush(stdout);
	
	QRY_find2("All Sequences",&tItemobj);
	if(tItemobj != NULLTAG)
	{
		printf("\n14.3 - All Sequences Query Found Successfully..!!");fflush(stdout);
				
		char *cEntries[2]  = {"Item ID","Type"};
		char *cValues[2]  = {STD_no,Type_value};
		
		QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			
				ITEM_ask_item_of_rev(titemobj_results[0],&STDMasterTag); 
				if (STDMasterTag!=NULLTAG)
				{
				
					ITEM_ask_latest_rev(STDMasterTag,&STDlatestRev);
					printf("\n latest rev tag found");fflush(stdout);
					
					AOM_ask_value_string(STDlatestRev,"object_type",&typename);
					printf("\n typename is %s",typename);fflush(stdout);
		
					if(tc_strcmp(typename,"T5_TMLStdRevision")==0 || tc_strcmp(typename,"T5_IStdRevision")==0 || tc_strcmp(typename,"TML Std Revision")==0 || tc_strcmp(typename,"IS Standard Class Revision")==0)
					{
						AOM_UIF_ask_value(STDlatestRev,"release_status_list",&RelStat);
						if(tc_strstr(RelStat,"ERC Released")!=NULL)
						{
							printf("\n  STD document is already ERC Released"); fflush(stdout);
							ifail=t9TMLSTD_Val005;
							EMH_store_error_s1(EMH_severity_error,ifail,"STD Document is already ERC Released");
							return ifail;
						}
						if(tc_strstr(RelStat,"ERC Review")!=NULL)
						{
							t5removeAllReleaseStatus(STDlatestRev);
							tm_CreSetstatus(STDlatestRev,"T5_LcsErcRlzd");
							tc_strcpy(output,"ERC Released");
							tc_strcat(output,"#");
						}
					}
					else
					{
						printf("\n typename is not matched");fflush(stdout);
					}
				}
				else
				{
					printf("\n Master Tag is NULL");fflush(stdout);
				}
		}
	}
	
	
	*((char **) return_data) = (char *) MEM_alloc((strlen(output)+1) * sizeof(char *));
	strcpy(*((char **) return_data),output);
	MEM_free(output);
	
	return ITK_ok;
}


extern int tm_TMLStdVolupdate()
{
	int ifail = ITK_ok;
	int n_args = 1;
	int ret_value_type;
	int input_arg_type[1] = {0};
	input_arg_type[0]=USERARG_STRING_TYPE;//Volume_no
	ret_value_type = USERARG_STRING_TYPE;
	printf("\n Before registing ...tm_TMLStdVolupdate\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_TMLStdVolupdateServ",(USER_function_t)tm_TMLStdVolupdateServ,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_TMLStdVolupdateServ\n");fflush(stdout);
	return ifail;
}

extern int tm_TMLStdKeywordupdate()
{
	int ifail = ITK_ok;
	int n_args = 3;
	int ret_value_type;
	int input_arg_type[3] = {0};
	input_arg_type[0]=USERARG_STRING_TYPE;//keyword 1
	input_arg_type[1]=USERARG_STRING_TYPE;//keyword 2
	input_arg_type[2]=USERARG_STRING_TYPE;//keyword 3
	ret_value_type = USERARG_STRING_TYPE;
	printf("\n Before registing ...tm_TMLStdKeywordupdate\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_TMLStdKeyworServ",(USER_function_t)tm_TMLStdKeyworServ,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_TMLStdKeywordupdate\n");fflush(stdout);
	return ifail;
}

extern int tm_TMLStdKeyword1update()
{
	int ifail = ITK_ok;
	int n_args = 1;
	int ret_value_type;
	int input_arg_type[1] = {0};
	input_arg_type[0]=USERARG_STRING_TYPE;//Volume_no
	ret_value_type = USERARG_STRING_TYPE;
	printf("\n Before registing ...tm_TMLStdKeyword1update\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_TMLStdKeywor1Serv",(USER_function_t)tm_TMLStdKeywor1Serv,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_TMLStdKeyword1update\n");fflush(stdout);
	return ifail;
}
extern int tm_TMLStdKeyword2update()
{
	int ifail = ITK_ok;
	int n_args = 1;
	int ret_value_type;
	int input_arg_type[1] = {0};
	input_arg_type[0]=USERARG_STRING_TYPE;//Volume_no
	ret_value_type = USERARG_STRING_TYPE;
	printf("\n Before registing ...tm_TMLStdKeyword2update\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_TMLStdKeywor2Serv",(USER_function_t)tm_TMLStdKeywor2Serv,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_TMLStdKeyword2update\n");fflush(stdout);
	return ifail;
}
extern int tm_TMLStdKeyword3update()
{
	int ifail = ITK_ok;
	int n_args = 1;
	int ret_value_type;
	int input_arg_type[1] = {0};
	input_arg_type[0]=USERARG_STRING_TYPE;//Volume_no
	ret_value_type = USERARG_STRING_TYPE;
	printf("\n Before registing ...tm_TMLStdKeyword3update\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_TMLStdKeywor3Serv",(USER_function_t)tm_TMLStdKeywor3Serv,n_args,input_arg_type,ret_value_type);
	printf("\n After registing ...tm_TMLStdKeyword3update\n");fflush(stdout);
	return ifail;
}

extern int tm_STD_Release()
{
	int ifail = ITK_ok;
	int n_args = 2;
	int ret_value_type;
	int input_arg_type[2] = {0};
	
	input_arg_type[0]=USERARG_STRING_TYPE;//STD_No
	input_arg_type[1]=USERARG_STRING_TYPE;//Type
	ret_value_type = USERARG_STRING_TYPE;
	
	/*input_arg_type = (int *) MEM_alloc(n_args * sizeof(int));
	input_arg_type[0]=USERARG_STRING_TYPE;//STD_No
	input_arg_type[1]=USERARG_STRING_TYPE;//Type
	ret_value_type = USERARG_STRING_TYPE;*/
	
	
	printf("\n Before registing ...tm_STD_Release\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_STD_ReleaseServ",(USER_function_t)tm_STD_ReleaseServ,n_args,input_arg_type,ret_value_type);	
	printf("\n After registing ...tm_STD_ReleaseServ\n");fflush(stdout);
	return ifail;
}

int TML_STD_revise_post_action( METHOD_message_t *msg, va_list args )
{
	int 	ifail 		= 	ITK_ok;
	int 	isNew		=	0;
	//tag_t  	DesRevTag 	= 	va_arg(args, tag_t);
	//isNew 		= 	va_arg(args, int);

	tag_t  source_rev_tag = va_arg(args, tag_t);
    char   *rev_id = va_arg(args, char *);
    tag_t  *new_rev_tag = va_arg(args, tag_t  *);
    tag_t  item_rev_master_tag = va_arg(args, tag_t);

	tag_t	objTypeTag	=	NULLTAG;
	tag_t	Revise_Part_Tag	=	NULLTAG;
	char* RelStat = NULL;
	char* type_name = NULL;
	
	TCTYPE_ask_object_type(source_rev_tag,&objTypeTag);
	TCTYPE_ask_name2(objTypeTag,&type_name);
	printf("\nTML_STD_revise_post_action:: Type name is [%s]\n", type_name);fflush(stdout);
	printf("\nTML_STD_revise_post_action::rev_id is [%s]\n", rev_id);fflush(stdout);
	
	AOM_UIF_ask_value(source_rev_tag,"release_status_list",&RelStat);
	if(tc_strstr(RelStat,"ERC Released")!=NULL)
	{
	
		Revise_Part_Tag = *new_rev_tag;
		if(tc_strcmp(type_name,"T5_TMLStdRevision")==0 || tc_strcmp(type_name,"TML Std Revision")==0)
		{
			t5removeAllReleaseStatus(Revise_Part_Tag);
			tm_CreSetstatus(Revise_Part_Tag,"T5_LcsReview");
		}
	}
	else
	{
		printf("\n TML STD document is ERC Released"); fflush(stdout);
		ifail=t9TMLSTD_Val001;
		EMH_store_error_s1(EMH_severity_error,ifail,"Revise is not allowed for Non ERC Released TML STD Document!");
		return ifail;
	}
	
	return ifail;
}



extern DLLAPI int STD_checkin_pre_condition(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;	
	int latest_revtag_found=0;	
    
    tag_t itemrev  = va_arg(args, tag_t);
	char *item_type=NULL;
	char *Rev_ID=NULL;
	char *latest_Rev_ID=NULL;
	char *RelStat=NULL;
	
	AOM_ask_value_string(itemrev,"object_type",&item_type);
	printf("\n **STD_checkin_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	
	AOM_ask_value_string(itemrev,"item_revision_id",&Rev_ID);
	printf("\n **Rev_ID of selescted Object is = [%s]\n", Rev_ID);fflush(stdout);
	
	if(tc_strcmp(item_type,"T5_TMLStd")==0 || tc_strcmp(item_type,"T5_IStd")==0 || tc_strcmp(item_type,"IS Standard Class")==0 || tc_strcmp(item_type,"TML Standard Class")==0)
	{
		ifail=t9TMLSTD_Val006;
		EMH_store_error_s1(EMH_severity_error,ifail,"Checkin is not allowed for Master. Please select the latest Revision!");
		return ifail;
	}
	if(tc_strcmp(item_type,"T5_TMLStdRevision")==0 || tc_strcmp(item_type,"T5_IStdRevision")==0 || tc_strcmp(item_type,"TML Std Revision")==0 || tc_strcmp(item_type,"IS Standard Class Revision")==0)
	{
		tag_t	STDMasterTag =NULLTAG;
		tag_t	STDlatestRev =NULLTAG;
		
		latest_revtag_found =0;
		ITEM_ask_item_of_rev(itemrev,&STDMasterTag);
		ITEM_ask_latest_rev(STDMasterTag,&STDlatestRev);
		printf("\n latest rev tag found");fflush(stdout);
		
		AOM_ask_value_string(STDlatestRev,"item_revision_id",&latest_Rev_ID);
		printf("\n **latest_Rev_ID of object is = [%s]\n", latest_Rev_ID);fflush(stdout);
		
		if(tc_strcmp(Rev_ID,latest_Rev_ID)==0)
		{
			latest_revtag_found++;
		}
		else
		{
			ifail=t9TMLSTD_Val008;
			EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Latest Revision!");
			return ifail;
		}
		
		if(latest_revtag_found>0)
		{
			
			
			AOM_UIF_ask_value(STDlatestRev,"release_status_list",&RelStat);
			if(tc_strstr(RelStat,"ERC Working")!=NULL)
			{
				printf("\n ** Revision have ERC Working Status");fflush(stdout);
			}
			else if(tc_strstr(RelStat,"ERC Review")!=NULL)
			{
				printf("\n ** Revision have ERC Review Status");fflush(stdout);
				ifail=t9TMLSTD_Val017;
				EMH_store_error_s1(EMH_severity_error,ifail,"Latest Revision is already Checked In!");
				return ifail;
			}
			else
			{
				ifail=t9TMLSTD_Val007;
				EMH_store_error_s1(EMH_severity_error,ifail,"Only ERC Working Revision is allowed for Checkin!");
				return ifail;
			}
		}
		MEM_free(RelStat);
	}
   return ifail;
}

extern DLLAPI int STD_checkout_pre_condition(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;	
	int latest_revtag_found=0;	
    
    tag_t itemrev  = va_arg(args, tag_t);
	char *item_type=NULL;
	char *Rev_ID=NULL;
	char *latest_Rev_ID=NULL;
	char *RelStat=NULL;
	
	AOM_ask_value_string(itemrev,"object_type",&item_type);
	printf("\n **STD_checkout_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	
	AOM_ask_value_string(itemrev,"item_revision_id",&Rev_ID);
	printf("\n **STD_checkout_pre_condition Rev_ID of selected Object is = [%s]\n", Rev_ID);fflush(stdout);

	if(tc_strcmp(item_type,"T5_TMLStd")==0 || tc_strcmp(item_type,"T5_IStd")==0 || tc_strcmp(item_type,"IS Standard Class")==0 || tc_strcmp(item_type,"TML Standard Class")==0)
	{
		ifail=t9TMLSTD_Val009;
		EMH_store_error_s1(EMH_severity_error,ifail,"Checkout is not allowed for Master. Please select the latest Revision!");
		return ifail;
	}
	if(tc_strcmp(item_type,"T5_TMLStdRevision")==0 || tc_strcmp(item_type,"T5_IStdRevision")==0 || tc_strcmp(item_type,"TML Std Revision")==0 || tc_strcmp(item_type,"IS Standard Class Revision")==0)
	{
		tag_t	STDMasterTag =NULLTAG;
		tag_t	STDlatestRev =NULLTAG;
		
		latest_revtag_found =0;
		ITEM_ask_item_of_rev(itemrev,&STDMasterTag);
		ITEM_ask_latest_rev(STDMasterTag,&STDlatestRev);
		printf("\n STD_checkout_pre_condition latest rev tag found");fflush(stdout);
		
		AOM_ask_value_string(STDlatestRev,"item_revision_id",&latest_Rev_ID);
		printf("\n **STD_checkout_pre_condition latest_Rev_ID of object is = [%s]\n", latest_Rev_ID);fflush(stdout);
		
		if(tc_strcmp(Rev_ID,latest_Rev_ID)==0)
		{
			latest_revtag_found++;
		}
		else
		{
			ifail=t9TMLSTD_Val010;
			EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Latest Revision!");
			return ifail;
		}
		
		if(latest_revtag_found>0)
		{
			
			
		AOM_UIF_ask_value(STDlatestRev,"release_status_list",&RelStat);
		
		if(tc_strstr(RelStat,"ERC Review") != NULL || tc_strstr(RelStat,"T5_LcsReview") != NULL)
		{
			printf("\n ** STD_checkout_pre_condition Revision have ERC Review Status");fflush(stdout);
		}
		else
		{
			ifail=t9TMLSTD_Val011;
			EMH_store_error_s1(EMH_severity_error,ifail,"Only ERC Review Revision is allowed for Checkout!");
			return ifail;
		}
		}
		MEM_free(RelStat);
	}
   return ifail;
}

extern DLLAPI int TML_STD_revise_pre_condition(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;	
	int latest_revtag_found=0;	
    
    tag_t itemrev  = va_arg(args, tag_t);
	char *item_type=NULL;
	char *Rev_ID=NULL;
	char *latest_Rev_ID=NULL;
	
	AOM_ask_value_string(itemrev,"object_type",&item_type);
	printf("\n **TML_STD_revise_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	
	AOM_ask_value_string(itemrev,"item_revision_id",&Rev_ID);
	printf("\n **TML_STD_revise_pre_condition Rev_ID of selected Object is = [%s]\n", Rev_ID);fflush(stdout);
	
	if(tc_strcmp(item_type,"T5_TMLStd")==0 || tc_strcmp(item_type,"TML Standard Class")==0)
	{
		ifail=t9TMLSTD_Val012;
		EMH_store_error_s1(EMH_severity_error,ifail,"Revise is not allowed for Master. Please select the latest Revision!");
		return ifail;
	}
	if(tc_strcmp(item_type,"T5_TMLStdRevision")==0 || tc_strcmp(item_type,"TML Std Revision")==0)
	{
		tag_t	STDMasterTag =NULLTAG;
		tag_t	STDlatestRev =NULLTAG;
		
		latest_revtag_found =0;
		ITEM_ask_item_of_rev(itemrev,&STDMasterTag);
		ITEM_ask_latest_rev(STDMasterTag,&STDlatestRev);
		printf("\n TML_STD_revise_pre_condition latest rev tag found");fflush(stdout);
		
		AOM_ask_value_string(STDlatestRev,"item_revision_id",&latest_Rev_ID);
		printf("\n **TML_STD_revise_pre_condition latest_Rev_ID of object is = [%s]\n", latest_Rev_ID);fflush(stdout);
		
		if(tc_strcmp(Rev_ID,latest_Rev_ID)==0)
		{
			latest_revtag_found++;
		}
		else
		{
			ifail=t9TMLSTD_Val013;
			EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Latest Revision!");
			return ifail;
		}
		
		if(latest_revtag_found>0)
		{
			char *RelStat=NULL;
			
			AOM_UIF_ask_value(STDlatestRev,"release_status_list",&RelStat);
			if(tc_strstr(RelStat,"ERC Released")!=NULL)
			{
				printf("\n ** Revision have ERC Released Status");fflush(stdout);
			}
			else
			{
				ifail=t9TMLSTD_Val014;
				EMH_store_error_s1(EMH_severity_error,ifail,"Only ERC Released Revision is allowed for Revise!");
				return ifail;
			}
		}
	}
	
	return ifail;
}
extern DLLAPI int IS_revise_pre_condition(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;	
	int latest_revtag_found=0;	
    
    tag_t itemrev  = va_arg(args, tag_t);
	char *item_type=NULL;
	char *Rev_ID=NULL;
	char *latest_Rev_ID=NULL;
	
	AOM_ask_value_string(itemrev,"object_type",&item_type);
	printf("\n **IS_revise_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	
	AOM_ask_value_string(itemrev,"item_revision_id",&Rev_ID);
	printf("\n **IS_revise_pre_condition Rev_ID of selected Object is = [%s]\n", Rev_ID);fflush(stdout);
	
	if(tc_strcmp(item_type,"T5_IStd")==0 || tc_strcmp(item_type,"IS Standard Class")==0)
	{
		ifail=t9TMLSTD_Val015;
		EMH_store_error_s1(EMH_severity_error,ifail,"Revise is not allowed for Master. Please select the latest Revision!");
		return ifail;
	}
	if(tc_strcmp(item_type,"T5_IStdRevision")==0 || tc_strcmp(item_type,"IS Standard Class Revision")==0)
	{
		tag_t	STDMasterTag =NULLTAG;
		tag_t	STDlatestRev =NULLTAG;
		
		latest_revtag_found =0;
		ITEM_ask_item_of_rev(itemrev,&STDMasterTag);
		ITEM_ask_latest_rev(STDMasterTag,&STDlatestRev);
		printf("\n IS_revise_pre_condition latest rev tag found");fflush(stdout);
		
		AOM_ask_value_string(STDlatestRev,"item_revision_id",&latest_Rev_ID);
		printf("\n **IS_revise_pre_condition latest_Rev_ID of object is = [%s]\n", latest_Rev_ID);fflush(stdout);
		
		if(tc_strcmp(Rev_ID,latest_Rev_ID)==0)
		{
			latest_revtag_found++;
		}
		else
		{
			ifail=t9TMLSTD_Val016;
			EMH_store_error_s1(EMH_severity_error,ifail,"Please select the Latest Revision!");
			return ifail;
		}
		
		if(latest_revtag_found>0)
		{
			char *RelStat=NULL;
			
			AOM_UIF_ask_value(STDlatestRev,"release_status_list",&RelStat);
			if(tc_strstr(RelStat,"ERC Released")!=NULL)
			{
				printf("\n ** Revision have ERC Released Status");fflush(stdout);
			}
			else
			{
				ifail=t9TMLSTD_Val017;
				EMH_store_error_s1(EMH_severity_error,ifail,"Only ERC Released Revision is allowed for Revise!");
				return ifail;
			}
		}
	}
	
	return ifail;
}

int IS_Doc_revise_post_action( METHOD_message_t *msg, va_list args )
{
	int 	ifail 		= 	ITK_ok;
	int 	isNew		=	0;
	//tag_t  	DesRevTag 	= 	va_arg(args, tag_t);
	//isNew 		= 	va_arg(args, int);

	tag_t  source_rev_tag = va_arg(args, tag_t);
    char   *rev_id = va_arg(args, char *);
    tag_t  *new_rev_tag = va_arg(args, tag_t  *);
    tag_t  item_rev_master_tag = va_arg(args, tag_t);

	tag_t	objTypeTag	=	NULLTAG;
	tag_t	Revise_Part_Tag	=	NULLTAG;
	char* RelStat = NULL;
	char* type_name = NULL;
	
	TCTYPE_ask_object_type(source_rev_tag,&objTypeTag);
	TCTYPE_ask_name2(objTypeTag,&type_name);
	printf("\nIS_Doc_revise_post_action:: Type name is [%s]\n", type_name);fflush(stdout);
	printf("\nIS_Doc_revise_post_action::rev_id is [%s]\n", rev_id);fflush(stdout);
	
	AOM_UIF_ask_value(source_rev_tag,"release_status_list",&RelStat);
	if(tc_strstr(RelStat,"ERC Released")!=NULL)
	{
		Revise_Part_Tag = *new_rev_tag;
		if(tc_strcmp(type_name,"T5_IStdRevision")==0 || tc_strcmp(type_name,"IS Standard Class Revision")==0)
		{
			t5removeAllReleaseStatus(Revise_Part_Tag);
			tm_CreSetstatus(Revise_Part_Tag,"T5_LcsReview");
		}
	}
	else
	{
		printf("\n IS STD document is ERC Released"); fflush(stdout);
		ifail=t9ISSTD_Val001;
		EMH_store_error_s1(EMH_severity_error,ifail,"Revise is not allowed for Non ERC Released IS STD Document!");
		return ifail;
	}
	
	
	
	return ifail;
}

int ISSTD_save_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	char*	revid	=NULL;
	
	
	printf("\n--->>>>> Hello From ISSTD_save_init_val");fflush(stdout);
	if(*new_item != NULLTAG)
	{
		printf("\n entering after creation ISSTD DOcument");fflush(stdout);
		printf("\n Before Update rev_id is %s",rev_id);fflush(stdout);
		
		
		AOM_refresh(*new_rev,TRUE);
		AOM_set_value_string(*new_rev,"item_revision_id","1");
		AOM_save_without_extensions(*new_rev);
		AOM_refresh(*new_rev,FALSE);
		AOM_ask_value_string(*new_rev,"item_revision_id",&revid);
		printf("\n The revision ID after update is :  %s \n",revid);fflush(stdout);
		
		tm_CreSetstatus(*new_rev,"T5_LcsReview");
		ISDOCSENDMAIL(*new_rev);
		printf("\n EXIT after creation ISSTD DOcument and email send");fflush(stdout);
	}
	

	
	return ifail;
}

extern DLLAPI int  ModDate_Set_pre_action(METHOD_message_t *msg, va_list args)
{
	
	/** va_list for PROP_set_value_string_msg **/

	printf("\n Inside ModDate_Set_pre_action  ") ;fflush(stdout);
	int ifail = ITK_ok;
	
	char cCurrentAccessDate[20]={0};
	date_t Current_date_2;
	date_t value_date;
	date_t ModDate;
	int answer;
	tag_t  object = NULLTAG;
	tag_t  object_type = NULLTAG;
	char *type_name=NULL;
	
	int n_entries0 =2;
	tag_t	CtrlObjTag	=	NULLTAG;
	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount=0;
	tag_t *qry_cntrlobj= NULLTAG;
	
	
	int error_code = ITK_ok;
	tag_t  prop = va_arg(args, tag_t );
	date_t  value = va_arg(args, date_t );
	//printf("\n Given date is [%s]\n", value);fflush(stdout);
	
	if(QRY_find2("Control Objects...",&CtrlObjTag));
	if(CtrlObjTag!=NULLTAG)
	{
		
		printf("\n CtrlObjTag tag is not NULL"); fflush(stdout);
		qry_values[0] = "TMLSTD";
		qry_values[1] = "ON";
		
		QRY_execute(CtrlObjTag, 2, qry_entries, qry_values,&resultCount,&qry_cntrlobj);
		printf("\n Result found for the Query is %d\n", resultCount);fflush(stdout);
		
		if(resultCount>0)
		{
		
		//ITK_string_to_date(value,&value_date);
		printf("\n ITK_string_to_date..value_date");fflush(stdout);
		
		getCurrentDateTime(cCurrentAccessDate);
		printf("\n cCurrentAccessDate : %s",cCurrentAccessDate);
		
		ITK_string_to_date(cCurrentAccessDate,&Current_date_2);
		printf("\n ITK_string_to_date..Current_date_2");fflush(stdout);
		
		
		METHOD_PROP_MESSAGE_OBJECT(msg, object); 
		TCTYPE_ask_object_type(object, &object_type);
		TCTYPE_ask_name2(object_type, &type_name);
		
		printf("\n- ModDate_Set_pre_action - object type: %s", type_name);fflush(stdout);
		
			if(strcmp(type_name,"T5_TMLStdRevision")==0 || strcmp(type_name,"TML Std Revision")==0) 
			{
				
				//AOM_ask_value_date(object,"t5_TSMod_Date",ModDate);
				//printf("\nType of ProjectCode is [%d]  ",ModDate);fflush(stdout);
				
				POM_compare_dates(value,Current_date_2,&answer);
				printf("value of answer is %d",answer);fflush(stdout);
				{
					if(answer==1)
					{
						ifail=t9TMLSTD_Val018;
						EMH_store_error_s1(EMH_severity_error,ifail,"Modification Date can't be greater than Current Date.Not allowed to update.");
						return ifail;
					}
					else if(answer == 0 || answer == -1)
					{
						printf("\n You can update.");fflush(stdout);
					}
					
				}
			}
		}
	}
	else
	{
		printf("\n CtrlObjTag:Not Found ControlObjects \n");fflush(stdout);
	}
	return ifail;
}

extern DLLAPI int  TMLRevSTD_save_init_val(METHOD_message_t *msg, va_list args)
{
	
	

	printf("\n Inside TMLRevSTD_save_init_val") ;fflush(stdout);
	int ifail = ITK_ok;
	
	char cCurrentAccessDate[20]={0};
	date_t Current_date_2;
	date_t value_date;
	date_t ModDate;
	int answer;
	//tag_t  object = NULLTAG;
	tag_t  object_type = NULLTAG;
	char *type_name=NULL;
	
	int n_entries0 =2;
	tag_t	CtrlObjTag	=	NULLTAG;
	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount=0;
	tag_t *qry_cntrlobj= NULLTAG;
	
	
	int error_code = ITK_ok;
	tag_t  object = va_arg(args, tag_t );
	logical isNew = va_arg(args, int );
	//date_t  value = va_arg(args, date_t );
	printf("\n isNew is [%d]\n", isNew);fflush(stdout);
	
	if(isNew==1 || isNew==true)
	{
		if(QRY_find2("Control Objects...",&CtrlObjTag));
		if(CtrlObjTag!=NULLTAG)
		{
			
			printf("\n 11111CtrlObjTag tag is not NULL"); fflush(stdout);
			qry_values[0] = "TMLSTD";
			qry_values[1] = "ON";
			
			QRY_execute(CtrlObjTag, 2, qry_entries, qry_values,&resultCount,&qry_cntrlobj);
			printf("\n 11111Result found for the Query is %d\n", resultCount);fflush(stdout);
			
			if(resultCount>0)
			{
			
			//ITK_string_to_date(value,&value_date);
			printf("\n 11111ITK_string_to_date..value_date");fflush(stdout);
			
			getCurrentDateTime(cCurrentAccessDate);
			printf("\n 11111cCurrentAccessDate : %s",cCurrentAccessDate);
			
			ITK_string_to_date(cCurrentAccessDate,&Current_date_2);
			printf("\n 11111ITK_string_to_date..Current_date_2");fflush(stdout);
			
			
			//METHOD_PROP_MESSAGE_OBJECT(msg, object); 
			TCTYPE_ask_object_type(object, &object_type);
			TCTYPE_ask_name2(object_type, &type_name);
			
			printf("\n- 11111ModDate_Set_pre_action - object type: %s", type_name);fflush(stdout);
			
				if(strcmp(type_name,"T5_TMLStdRevision")==0 || strcmp(type_name,"TML Std Revision")==0) 
				{
					
					AOM_ask_value_date(object,"t5_TSMod_Date",&ModDate);
					//printf("\nType of ProjectCode is [%d]  ",ModDate);fflush(stdout);
					
					POM_compare_dates(ModDate,Current_date_2,&answer);
					printf("11111value of answer is %d",answer);fflush(stdout);
					{
						if(answer==1)
						{
							ifail=t9TMLSTD_Val018;
							EMH_store_error_s1(EMH_severity_error,ifail,"Modification Date can't be greater than Current Date.Not allowed to update.");
							return ifail;
						}
						else if(answer == 0 || answer == -1)
						{
							printf("\n You can update.");fflush(stdout);
						}
						
					}
				}
			}
		}
		else
		{
			printf("\n CtrlObjTag:Not Found ControlObjects \n");fflush(stdout);
		}
	}
	
	return ifail;
}

extern DLLAPI int  RelDate_Set_pre_action(METHOD_message_t *msg, va_list args)
{
	
	/** va_list for PROP_set_value_string_msg **/

	printf("\n Inside RelDate_Set_pre_action  ") ;fflush(stdout);
	int ifail = ITK_ok;
	
	char cCurrentAccessDate[20]={0};
	date_t Current_date_2;
	date_t value_date;
	date_t ModDate;
	int answer;
	tag_t  object = NULLTAG;
	tag_t  object_type = NULLTAG;
	char *type_name=NULL;
	
	int n_entries0 =2;
	tag_t	CtrlObjTag	=	NULLTAG;
	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount=0;
	tag_t *qry_cntrlobj= NULLTAG;
	
	
	int error_code = ITK_ok;
	tag_t  prop = va_arg(args, tag_t );
	date_t  value = va_arg(args, date_t );
	//printf("\n Given date is [%s]\n", value);fflush(stdout);
	
	if(QRY_find2("Control Objects...",&CtrlObjTag));
	if(CtrlObjTag!=NULLTAG)
	{
		
		printf("\n CtrlObjTag tag is not NULL"); fflush(stdout);
		qry_values[0] = "TMLSTD";
		qry_values[1] = "Release";
		
		QRY_execute(CtrlObjTag, 2, qry_entries, qry_values,&resultCount,&qry_cntrlobj);
		printf("\n Result found for the Query is %d\n", resultCount);fflush(stdout);
		
		if(resultCount>0)
		{
		
		//ITK_string_to_date(value,&value_date);
		printf("\n under RelDate_Set_pre_action ITK_string_to_date..value_date");fflush(stdout);
		
		getCurrentDateTime(cCurrentAccessDate);
		printf("\n under RelDate_Set_pre_action cCurrentAccessDate : %s",cCurrentAccessDate);
		
		ITK_string_to_date(cCurrentAccessDate,&Current_date_2);
		printf("\n under RelDate_Set_pre_action ITK_string_to_date..Current_date_2");fflush(stdout);
		
		
		METHOD_PROP_MESSAGE_OBJECT(msg, object); 
		TCTYPE_ask_object_type(object, &object_type);
		TCTYPE_ask_name2(object_type, &type_name);
		
		printf("\n- RelDate_Set_pre_action - object type: %s", type_name);fflush(stdout);
		
			if(strcmp(type_name,"T5_TMLStdRevision")==0 || strcmp(type_name,"TML Std Revision")==0) 
			{
				
				//AOM_ask_value_date(object,"t5_TSMod_Date",ModDate);
				//printf("\nType of ProjectCode is [%d]  ",ModDate);fflush(stdout);
				
				POM_compare_dates(value,Current_date_2,&answer);
				printf("under RelDate_Set_pre_action value of answer is %d",answer);fflush(stdout);
				{
					if(answer==1)
					{
						ifail=t9TMLSTD_Val018;
						EMH_store_error_s1(EMH_severity_error,ifail,"TS Released Date can't be greater than Current Date.Not allowed to update.");
						return ifail;
					}
					else if(answer == 0 || answer == -1)
					{
						printf("\n You can update.");fflush(stdout);
					}
					
				}
			}
		}
	}
	else
	{
		printf("\n CtrlObjTag:Not Found ControlObjects \n");fflush(stdout);
	}
	return ifail;
}



int TMLSTD_save_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	
	printf("\n--->>>>> Hello From TMLSTD_save_init_val");fflush(stdout);
	if(*new_item != NULLTAG)
	{
		printf("\n 111111 Entering after creation TMLSTD DOcument");fflush(stdout);
		tm_CreSetstatus(*new_rev,"T5_LcsReview");
		printf("\n 111111 Exit after creation TMLSTD DOcument");fflush(stdout);
	}
	return ifail;
}




/****************************************************************************
Function:       MYTPE_tm_TmlStd
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

extern int MYTPE_tm_TmlStd(int *decision, va_list args)
{
    int          ifail = ITK_ok;
   	METHOD_id_t  method;
   	METHOD_id_t  method1;
   	METHOD_id_t  method2;
   	METHOD_id_t  method3;
   	METHOD_id_t  method4;
   	METHOD_id_t  method5;
   	METHOD_id_t  TMLSTDRevisemethod;
   	METHOD_id_t  ISDocRevisemethod;
   	METHOD_id_t  TMLSTD_save;
   	METHOD_id_t  ISSTD_save;
   	METHOD_id_t  Rev_Mod_Date;
	METHOD_id_t  method_ModDate;
	METHOD_id_t  method_RelDate;
	TC_argument_list_t
        *myArgs;
	//METHOD_function_t ;
    *decision = ALL_CUSTOMIZATIONS;

    /* Create the method by registering the base action.*/
	printf("\n MYTPE_tm_TmlStd - ");fflush(stdout);
	if( ifail == ITK_ok )
    {
		printf("\n Start T5_RefStdNoVVSet LOVType............................\n");fflush(stdout);
		ifail = METHOD_register_method("T5_RefStdNoVVSet",LOV_ask_values_msg,&GetIStdLOVValuesMethod,0,&method1);
		printf("\n End T5_RefStdNoVVSet LOVType............................\n");fflush(stdout);
	}
	METHOD_find_method(RES_Type, RES_checkin_msg, &method2);
    if (method2.id)
    {
		printf("\n  Before Register preaction STD_checkin_pre_condition \n");fflush(stdout);
		METHOD_add_action(method2, METHOD_pre_action_type,(METHOD_function_t)STD_checkin_pre_condition,NULL);
		printf("\n  After Register preaction STD_checkin_pre_condition \n");fflush(stdout);
		
		printf("\n  Before Register TMLSTD RES_checkin_msg \n");fflush(stdout);
		METHOD_add_action(method2, METHOD_post_action_type,(METHOD_function_t)TMLSTDCheckin,NULL);
		printf("\n  After Register TMLSTD RES_checkin_msg \n");fflush(stdout);
		
		
    }
	
	/*METHOD_find_method(RES_Type, RES_checkin_msg, &method4);
    if (method4.id)
    {
		printf("\n  Before Register STD_checkin_pre_condition \n");fflush(stdout);
		METHOD_add_pre_condition(method4, (METHOD_function_t) STD_checkin_pre_condition, NULL);	
		printf("\n  After Register STD_checkin_pre_condition \n");fflush(stdout);
    }*/
	
	
	/*METHOD_find_method(RES_Type, RES_checkout_msg, &method5);
    if (method5.id)
    {
		printf("\n  Before Register STD_checkout_pre_condition \n");fflush(stdout);
		METHOD_add_pre_condition(method5, (METHOD_function_t) STD_checkout_pre_condition, NULL);	
		printf("\n  After Register STD_checkout_pre_condition \n");fflush(stdout);
    }*/
	
	METHOD_find_method(RES_Type, RES_checkout_msg, &method3);
	
	if(method3.id)
	{
		printf("\n  Before Register STD_checkout_pre_condition \n");fflush(stdout);
		METHOD_add_action(method3, METHOD_pre_action_type,(METHOD_function_t)STD_checkout_pre_condition,NULL);
		printf("\n  After Register STD_checkout_pre_condition \n");fflush(stdout);
		
		printf("\n  Before Register TMLSTD RES_checkout_msg \n");fflush(stdout);
		METHOD_add_action(method3, METHOD_post_action_type,(METHOD_function_t)TMLSTDCheckout,NULL);
		printf("\n  After Register TMLSTD RES_checkout_msg \n");fflush(stdout);
		
		
	}
		METHOD_find_method("T5_TMLStdRevision", "ITEM_copy_rev", &TMLSTDRevisemethod);
		METHOD_find_method("T5_IStdRevision", "ITEM_copy_rev", &ISDocRevisemethod);
		
	if (TMLSTDRevisemethod.id)
	{
	
		METHOD_add_action(TMLSTDRevisemethod, METHOD_post_action_type,(METHOD_function_t)TML_STD_revise_post_action ,NULL);
		printf("\n After Rigister TML_STD_revise_post_action");fflush(stdout);
		METHOD_add_pre_condition(TMLSTDRevisemethod, (METHOD_function_t) TML_STD_revise_pre_condition, NULL);
		printf("\n IN After Rigister TML_STD_revise_pre_condition");fflush(stdout);
	}
	if (ISDocRevisemethod.id)
	{
		
		METHOD_add_action(ISDocRevisemethod, METHOD_post_action_type,(METHOD_function_t)IS_Doc_revise_post_action ,NULL);
		printf("\n After Rigister IS_Doc_revise_post_action");fflush(stdout);
		METHOD_add_pre_condition(ISDocRevisemethod, (METHOD_function_t) IS_revise_pre_condition, NULL);
		printf("\n IN After Rigister IS_revise_pre_condition");fflush(stdout);
	}
		
		METHOD_find_method("T5_TMLStd", "ITEM_create", &TMLSTD_save);
		if (TMLSTD_save.id)
		{	
			printf("\n before Rigister TMLSTD_save");fflush(stdout);
			//CALLAPI(METHOD_add_action(TMLSTD_save, METHOD_pre_action_type ,(METHOD_function_t)tm_Design_set_PreAction_init_val, NULL));
			METHOD_add_action(TMLSTD_save, METHOD_post_action_type,(METHOD_function_t)TMLSTD_save_init_val ,NULL);
			printf("\n IN After Rigister TMLSTD_save_init_val");fflush(stdout);
		}
		else
		{
			printf("\n IN After Rigister TMLSTD_save_init_val  == NULL");fflush(stdout);
		}
		
		METHOD_find_method("T5_IStd", "ITEM_create", &ISSTD_save);
		if (ISSTD_save.id)
		{	
			printf("\n before Rigister ISSTD_save");fflush(stdout);
			//CALLAPI(METHOD_add_action(TMLSTD_save, METHOD_pre_action_type ,(METHOD_function_t)tm_Design_set_PreAction_init_val, NULL));
			METHOD_add_action(ISSTD_save, METHOD_post_action_type,(METHOD_function_t)ISSTD_save_init_val ,NULL);
			printf("\n IN After Rigister ISSTD_save_init_val");fflush(stdout);
		}
		else
		{
			printf("\n IN After Rigister ISSTD_save_init_val  == NULL");fflush(stdout);
		}
		
		METHOD_find_prop_method("T5_TMLStdRevision", "t5_TSMod_Date", PROP_set_value_date_msg/*PROP_UIF_set_value_msg*/, &method_ModDate);
		
		if(method_ModDate.id)
		{
			printf("\n Before Rigister Modification Date_Set_pre_action");fflush(stdout);
			METHOD_add_action(method_ModDate,METHOD_pre_action_type ,(METHOD_function_t)ModDate_Set_pre_action, NULL);
			//METHOD_add_action(method_ModDate, METHOD_post_action_type, (METHOD_function_t) ModDate_Set_pre_action, NULL);
			printf("\n After Rigister Modification Date_Set_pre_action");fflush(stdout);
		}
		
		METHOD_find_method("T5_TMLStdRevision",TC_save_msg, &Rev_Mod_Date);
		if(Rev_Mod_Date.id)
		{
			printf("\n Before Rigister TMLRevSTD_save_init_val");fflush(stdout);
			METHOD_add_action(Rev_Mod_Date, METHOD_pre_action_type,(METHOD_function_t)TMLRevSTD_save_init_val ,NULL);
			printf("\n After Rigister TMLRevSTD_save_init_val");fflush(stdout);
		}
		
		METHOD_find_prop_method("T5_TMLStdRevision", "t5_TSRelDate", PROP_set_value_date_msg/*PROP_UIF_set_value_msg*/, &method_RelDate);
		
		if(method_RelDate.id)
		{
			printf("\n Before Rigister RelDate_Set_pre_action");fflush(stdout);
			METHOD_add_action(method_RelDate,METHOD_pre_action_type ,(METHOD_function_t)RelDate_Set_pre_action, NULL);
			//METHOD_add_action(method_ModDate, METHOD_post_action_type, (METHOD_function_t) ModDate_Set_pre_action, NULL);
			printf("\n After Rigister RelDate_Set_pre_action");fflush(stdout);
		}
	
    return ifail;
}
extern int tm_TMLStdVolupdateFunc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	ifail = tm_TMLStdVolupdate();
	ifail = tm_STD_Release();
	ifail = tm_TMLStdKeyword1update();
	ifail = tm_TMLStdKeyword2update();
	ifail = tm_TMLStdKeyword3update();
	ifail = tm_TMLStdKeywordupdate();
	return ifail;
}

/*extern int tm_STD_ReleaseFunc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	
	printf("\n Calling function tm_STD_Release\n");fflush(stdout);
	ifail = tm_STD_Release();
	return ifail;
}*/



/****************************************************************************
    Function:       tm_TmlStd_register_callbacks
    Description:    Registering custom entry point

    Input:          int *decision
					va_list args

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

extern DLLAPI int tm_TmlStd_register_callbacks ()
{
    int ifail    = ITK_ok;
    printf("\n tm_TmlStd");fflush(stdout);
	if(CUSTOM_register_exit ( "tm_TmlStd", "USER_init_module", (CUSTOM_EXIT_ftn_t)  MYTPE_tm_TmlStd) !=ITK_ok);
	if(CUSTOM_register_exit ( "tm_TmlStd", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  tm_TMLStdVolupdateFunc) !=ITK_ok);
//	if(CUSTOM_register_exit ( "tm_TmlStd", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  tm_STD_ReleaseFunc) !=ITK_ok);
    printf("\n after calling tm_TmlStd\n");fflush(stdout);

  return ( ITK_ok );
}
