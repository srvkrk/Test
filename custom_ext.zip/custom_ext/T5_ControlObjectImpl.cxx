//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_ControlObjectImpl
//

#include <T5_tm_controlObj/T5_ControlObjectImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define ITK_err (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_ControlObjectImpl::T5_ControlObjectImpl(T5_ControlObject& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_ControlObjectImpl::T5_ControlObjectImpl( T5_ControlObject& busObj )
   : T5_ControlObjectGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_ControlObjectImpl::~T5_ControlObjectImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_ControlObjectImpl::~T5_ControlObjectImpl()
{
}

//----------------------------------------------------------------------------------
// T5_ControlObjectImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_ControlObjectImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_ControlObjectGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// desc for validate for create
/// @param creInput - desc for creInput parameter
/// @return - ret desc for validate for create
///
int  T5_ControlObjectImpl::validateCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;

    // Call the parent Implementation
    ifail = super_validateCreateInputBase(  creInput );

    // Your Implementation

    try
    {
        //Validation Start
        bool isNull=false;
        std::string t5_Syscd;
        std::string t5_SubSyscd;
        creInput->getString("t5_Syscd", t5_Syscd, isNull );
        creInput->getString("t5_SubSyscd", t5_SubSyscd, isNull );

        char *loggedinuser = NULL;
        ifail = POM_get_user_id (&loggedinuser);
        printf("\nControl Object Creation Logged In Use : %s",loggedinuser); fflush(stdout);

        if(tc_strcmp(t5_Syscd.c_str(),"PlantDML")==0 && tc_strcmp(loggedinuser,"infodba")!=0 && tc_strcmp(loggedinuser,"loader")!=0)
        {
            WSO_search_criteria_t   criteria;
            int number_found;
            tag_t *list_of_WSO_tags=NULLTAG;
            ifail = WSOM_clear_search_criteria(&criteria);
            strcpy(criteria.name,t5_SubSyscd.c_str());
            strcpy(criteria.class_name,"T5_Project");
            ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
            printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);
            if(number_found > 0)
            {
                int secobjectcnt;
                tag_t prjObj = NULLTAG;
                tag_t relation_type = NULLTAG;
                tag_t *secondary_obj = NULLTAG;

                prjObj=list_of_WSO_tags[0];
                ifail = GRM_find_relation_type("T5_ProjReqRel",&relation_type);
                if(relation_type!= NULLTAG)
                {
                    ifail = GRM_list_primary_objects_only(prjObj, relation_type, &secobjectcnt, &secondary_obj);
                    printf("No of Prj Req Found %d",secobjectcnt); fflush(stdout);
                    if(secobjectcnt < 1)
                    {
                        printf("\n\t Project Request not found..........\n\n" );fflush(stdout);
                        EMH_store_error_s1(EMH_severity_error,ITK_err, "No Project Request found with Project");
                        return ITK_err;
                    }
                    else
                    {
                        char *CurrectTaskFlow = NULL;
                        char *item_id = NULL;
                        tag_t prjReqObj = NULLTAG;
                        int i = 0;
                        int j = 0;
                        int wfStage = 0;
                        int validUser = 0;
                        for (i = 0; i < secobjectcnt; ++i)
                        {
                            prjReqObj=secondary_obj[i];
                            ifail =  AOM_ask_value_string(prjReqObj,"item_id",&item_id);
                            printf("\nProject Req NO %s",item_id); fflush(stdout);
                            ifail =  AOM_UIF_ask_value(prjReqObj,"fnd0MyWorkflowTasks",&CurrectTaskFlow);
                            printf("\n Present Lifecycle Status .. %s\n",CurrectTaskFlow);fflush(stdout);
                            if (tc_strstr(CurrectTaskFlow,"Create PlantDML Control Object")!=NULL)
                            {
                                wfStage = 1;
                            }
                        }

                        tag_t group_tag = NULLTAG;
                        int num_of_roles = 0;
                        tag_t* role_tags = NULLTAG;
                        tag_t role_tag = NULLTAG;
                        int num_of_members = 0;
                        tag_t* member_tags = NULLTAG;
                        tag_t user_tag = NULLTAG;
                        char *memUserId = NULL;
                        ifail = SA_find_group("APL_PLM_SPOC",&group_tag);
                        if (group_tag != NULLTAG)
                        {
                            ifail = SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  );
                            if (role_tags != NULLTAG)
                            {
                                if(num_of_roles>0)
                                {
                                    for (i=0;i<num_of_roles ;i++ )
                                    {
                                        role_tag = role_tags[i];
                                        ifail = SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags);
                                        if (member_tags != NULLTAG)
                                        {
                                            if(num_of_members>0)
                                            {
                                                for (j=0;j<num_of_members ;j++  )
                                                {
                                                    ifail = SA_ask_groupmember_user(member_tags[j],&user_tag);
                                                    ifail =  AOM_ask_value_string(user_tag,"user_id",&memUserId);
                                                    printf("APL_PLM_SPOC %d : %s",j,memUserId); fflush(stdout);
                                                    if (tc_strstr(memUserId,loggedinuser) != NULL)
                                                    {
                                                        validUser = 1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (wfStage == 0 || validUser == 0)
                        {
                            printf("\n\t Not at Create PlantDML Stage \n\n" );fflush(stdout);
                            EMH_store_error_s1(EMH_severity_error,ITK_err, "Project Request Object is not in Create PlantDML Control Object Stage OR You are not a member of APL_PLM_SPOC Group");
                            return ITK_err;
                        }
                    }
                }
                else
                {
                    printf("\n\t Not Valid relation_type \n\n" );fflush(stdout);
                    EMH_store_error_s1(EMH_severity_error,ITK_err, "T5_ProjReqRel is not a Valid relation_type.");
                    return ITK_err;
                }
            }
            else
            {
                printf("\nNo valid project found");
                EMH_store_error_s1(EMH_severity_error,ITK_err, "Entered Project Number is not valid.");
                return ITK_err;
            }
        }
        //Validation End
    }
    catch( const IFail& ex )
    {
        ifail = ex.ifail();
    }

    return ifail;
}
