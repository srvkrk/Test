#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <unidefs.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <property/prop.h>
#include <pie/pie.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <textsrv/textserver.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_errStore2 (EMH_USER_error_base + 6)
#define ITK_errErr1 (EMH_USER_error_base + 4)
#define ITK_errErr (EMH_USER_error_base + 99)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
#define VOO_HASH_SIZE 4099
#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int ifail = ITK_ok;
int QuantityAttrId=0;
char *ClrSchmToVf = NULL;
char *NoColSchemeMatchPrts = NULL;
tag_t tsk_HSI_rel_type = NULLTAG;
tag_t tRelationFind = NULLTAG;
tag_t windowClr = NULLTAG;
tag_t ruleNC = NULLTAG;
tag_t ClrPartQryTag = NULLTAG;
tag_t qryCTOTag = NULLTAG;
tag_t SchmqueryTag = NULLTAG;
tag_t GeneralQryTag = NULLTAG;
tag_t SchmWithCmpcdRel = NULLTAG;
char *info7ClrSchmMsg=NULL;
char *info2SchmCre=NULL;

int tm_ProcessColourPart(int taskCnt, tag_t *Dml_tasks, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, int ColSchmCnt, tag_t *ColSchme_tags, char *NewColourPart);
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

typedef struct
{
    int     size;
    int     capacity;
    int     increment;
    void  **content;
} vector_t;

struct modstruct
 {  
	   //part details

		char parent_part[100];
		int child;

 } childstr[10000];

typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];
static vector_t *vector_new( int capacity, int increment );
static vector_t *vector_add( vector_t *v, void *element );
static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
static vector_t *vector_ensure_capacity( vector_t *v, int n );
static vector_t *vector_free( vector_t *v );
static vector_t *vector_insert( vector_t *in, void *element );
static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
static void *vector_get( const vector_t *v, int index );
static int vector_size( const vector_t *v );
static int vector_rem_at( vector_t *in, int n );
static int vector_rem_n_at( vector_t *in, int n, int at );
static int       VOO_debug                     = FALSE;
static char     *VOO_prog                      = (char *)"UnitBOM";

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static double token_to_double ( const char *str )
{
    return strtod( str, NULL);
}

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

int multiple_module_status( EPM_action_message_t msg )
{	
	
	int			ifail				= 0;
	int         stat                    = ITK_ok;
    char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId               = NULL;
	char        *SVRType                = NULL;
    tag_t        rev                    = NULLTAG;
    tag_t        rev1                   = NULLTAG;
	tag_t		 view_type				= NULLTAG;
	int    n_bom_views=0;
	int    j=0;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	int    bom_view_index=0;
	int    noAttachment=0;
	tag_t  item=NULLTAG;
	tag_t        bom_view					=NULLTAG;
	tag_t			*attachments			=NULLTAG;
	tag_t			dataset					= NULLTAG;
	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t			relation_type		= NULLTAG;
	char *child_item_id15=NULL;
	char *objecttype=NULL;
	char *objectname=NULL;
	logical modB=FALSE;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	int i,cnt = 0;
	tag_t  primary1=NULLTAG;
	tag_t			rootTask			=NULLTAG;

	tag_t  objTypeTagDi=NULLTAG;
	tag_t  objTypeTagDi1=NULLTAG;
	tag_t  opt_tag=NULLTAG;
	tag_t  master_tag=NULLTAG;
	tag_t  Itemmaster_tag=NULLTAG;
	tag_t  *opts=NULLTAG;
	tag_t  *rootLine=NULL;
	tag_t * 	bom_variant_config=NULL;
	tag_t  *opt_revs=NULLTAG;
	tag_t  *secondaries=NULL;
	tag_t  *occs=NULL;
	tag_t  relation_dep	= NULLTAG;
	tag_t *occsal;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  *secondary_objects1	= NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	tag_t   *status_list          = NULLTAG;
	int p34=0;
	tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	int    n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
	tag_t			*attachments1							= NULLTAG;
	char*			username				=NULL;
	char **rulename = NULL;
    char **rulevalue = NULL;
	tag_t  	objTypeTag=NULLTAG;
	tag_t  	objTypeTag1=NULLTAG;
	tag_t *closurerule = NULL;
	
	tag_t *bvs, *bvrs;
    int    bv_count, bvr_count;
	tag_t        bv,bvr,parentBvr,bv1,bvr1       = NULLTAG;
	tag_t        Childrev                = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	int rulefound= 0;

	tag_t close_tag;
	tag_t ** 	variant_rule_list= NULLTAG;
	tag_t top_bomline;
	tag_t clause_list = NULLTAG; 

	tag_t X4ItemTag = NULLTAG;		  
	tag_t X4ItemRevTag = NULLTAG;	
	char  typeName[TCTYPE_name_size_c+1];
	char  typeName1[TCTYPE_name_size_c+1];
	int iChildItemTag;
	tag_t t_ChildItemRev=NULLTAG;
	char *Arcbl_Item_id = NULL;
	char *dml_rlstype = NULL;
	char *ClrSvr_Name = NULL;
	char *Svr_Project = NULL;
	int no_bom_lines =0;
	tag_t *child_bom_lines;
	
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;

	CALLAPI(POM_get_user(&username,&user_tag));
	printf("\n Starting for taskbreskdownnn :%s....\n",username);fflush(stdout);	
	
	CALLAPI(QRY_find("Control Objects...", &Cntl_obj_Qtag11));
	qry_values11[0] = "ClrSvrOnX4" ;
	qry_values11[1] = "ClrSvrOnX4" ;
	CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	printf("\n Control Object count for ClrSvrOnX4---------->%d\n",resultCount11);fflush(stdout);

	if(resultCount11>0)
	{		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
		printf("\n Target Attachment:%d\n",noAttachment);fflush(stdout);

		if(noAttachment > 0)
		{
			DMLTag = attachments[0];			    	
		}	
		
		//CALLAPI(AOM_UIF_ask_value(DMLTag,"t5_rlstype",&dml_rlstype));
		CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&dml_rlstype));
		printf("\n dml_rlstype is : %s\n",dml_rlstype);fflush(stdout);

		if(tc_strcmp(dml_rlstype,"CP")==0)
		{	
			CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type));
			if(relation_type != NULLTAG)
			{
			  CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
			  printf("\n Checkin- impacted items:%d\n",cnt);fflush(stdout);
				
			  for(i=0;i<cnt;i++)
			  {
					  printf("\n to find impacted items\n");fflush(stdout);
					  rev1 = attachments1[i]; 

					  if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					  if(AOM_ask_value_string(rev1,"object_name",&objectname));

					  if (strcmp(objecttype,"VariantRule")==0)
					  {
						  primary1=rev1;
					  }	
			  }

			  CALLAPI(AOM_ask_value_string(primary1,"object_name",&ClrSvr_Name));
			  printf("\n ClrSvr_Name is : %s\n",ClrSvr_Name); fflush(stdout);
			
			  Svr_Project=subString(ClrSvr_Name, 0, 4);
			  printf("\n Svr_Project is : %s\n",Svr_Project); fflush(stdout);

			  if (strcmp(Svr_Project,"5445")==0)
			  {
				  printf("\n Color SVR Name is---------->%s\n",objectname ); fflush(stdout);
				  CALLAPI(ITEM_find_item("X4",&X4ItemTag));
				  printf("\n ITEM_find_item------------>\n" ); fflush(stdout);
				  
				  CALLAPI(ITEM_ask_latest_rev(X4ItemTag,&X4ItemRevTag));
				  printf("\n ITEM_ask_latest_rev---------->\n" ); fflush(stdout);
			
				  if(TCTYPE_ask_object_type(X4ItemRevTag,&objTypeTag));
				  if(TCTYPE_ask_name(objTypeTag,typeName));
				  printf("\n\nT5_PlatformRevision is----->%s\n",typeName); fflush(stdout);			
					 
				  if (strcmp(typeName,"T5_PlatformRevision")==0)
				  {
						printf( "\n INside platform\n"); fflush(stdout);
						if ( X4ItemRevTag !=NULLTAG )
						{
							CALLAPI ( PS_find_view_type( "view", &view_type ));
							printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

							if ( view_type != NULLTAG )
							{
								CALLAPI ( ITEM_ask_item_of_rev( X4ItemRevTag, &item ));
								CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

								bom_view = bom_views[0];
							}
							else
							printf("\nView not found check.......\n"); fflush(stdout);
						}

						if ( bom_view != NULLTAG )
						{
							printf(" before BOM_create_window..\n");	fflush(stdout);	
							CALLAPI(BOM_create_window( &bom_window ));
							CALLAPI(CFM_find("Color ERC Review and above", &rule ));
							CALLAPI(BOM_set_window_config_rule(bom_window, rule ));	
							CALLAPI(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule));
							if (rulefound > 0)
							{
								close_tag = closurerule[0];
								printf ("closure rule found \n");fflush(stdout);
							}
							CALLAPI(BOM_window_set_closure_rule(bom_window,close_tag, 0, rulename,rulevalue));
							CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
							CALLAPI(BOM_set_window_top_line(bom_window , NULLTAG, X4ItemRevTag, NULLTAG, &top_line ));
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
							printf("\n before hiide LLlast Before setting option n_lines1 : %d \n", n_lines1);

							if(bom_window != NULLTAG)
							{
								CALLAPI(BOM_window_hide_unconfigured(bom_window));
								CALLAPI(BOM_window_show_variants(bom_window));
								CALLAPI(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
								CALLAPI(BOM_variant_config_apply(bom_variant_config));
								CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&primary1));
								CALLAPI(BOM_window_hide_variants(bom_window));
								CALLAPI(BOM_window_ask_is_modified(bom_window,&modB));
								if(modB) { printf( "\n modified bom window:..\n"); } else {
								printf( "\n not modfiifed ..\n"); }
								if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
								printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);
							}					
							
							if (n_lines1 >0)
							{
								for (p1=0;p1<n_lines1 ;p1++ )
								{		
									CALLAPI(BOM_line_look_up_attribute((char *) bomAttr_lineItemRevTag , &iChildItemTag));
									CALLAPI(BOM_line_ask_attribute_tag(lines[p1], iChildItemTag, &t_ChildItemRev));
								
									CALLAPI(AOM_ask_value_string(lines[p1], "bl_item_item_id", &Arcbl_Item_id));
									printf("\n\n Arcbl_Item_id is---------------->%s\n",Arcbl_Item_id); fflush(stdout);

									if(TCTYPE_ask_object_type(t_ChildItemRev,&objTypeTag1));
									if(TCTYPE_ask_name(objTypeTag1,typeName1));
									printf("\n Module Class Name is----->%s\n",typeName1); fflush(stdout);	
									
									if(tc_strcmp(typeName1,"T5_ArchModuleRevision")==0)
									{
										CALLAPI(BOM_line_ask_child_lines(lines[p1], &no_bom_lines, &child_bom_lines));
										printf("\n BOM_line_ask_child_lines for Module is: %d\n\n", no_bom_lines); fflush(stdout);										
										tc_strcpy(MulModule,"");
										tc_strcat(MulModule,Arcbl_Item_id);
										tc_strcat(MulModule,"==>");

										if (no_bom_lines >1)
										{
											for (p34=0;p34<no_bom_lines ;p34++ )
											{
												if(Childobject33) Childobject33=NULLTAG;
												Childobject33=child_bom_lines[p34];
												
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
												printf("\n child_item_id15 is----->%s\n",child_item_id15); fflush(stdout);
												
												tc_strcat(MulModule,"[");
												tc_strcat(MulModule,child_item_id15);
												tc_strcat(MulModule,"]");
												tc_strcat(MulModule,",");
												errorflag=errorflag+1;
												printf("\n.....mulmodule is after..%s\n",MulModule);fflush(stdout);
											}
											
											printf("\n errorflag----->%d\n",errorflag); fflush(stdout);
											if (errorflag>0)
											{
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"MORE THAN ONE MODULES IS PRESENT UNDER ARCHITECHTURE NODE",MulModule," PLEASE CORRECT THE COLOR SVR & SIGNOFF");
												return ITK_Prjerr;									
											}

										}else
										printf("\n Module count is not more than one...........>%d\n",no_bom_lines); fflush(stdout);
									}
								}
							}					 						 
							CALLAPI(BOM_save_window(bom_window));
							CALLAPI(BOM_close_window(bom_window));
						}
					}
				}else
				printf("\n Project code of Color SVR is other than 5445--------------->\n"); fflush(stdout);			
			}
		}else
		printf("\n DML type is other than Color Part release(CP)--------------->\n"); fflush(stdout);
	}
	return ITK_ok;
}

int tm_DMLPostColRlzProcess(char* dml_no)
{
	int tskcnt,i=0;
	int partcnt,k=0;
	int NCAssyChildFlag=0;
	tag_t *Dml_tasks=NULLTAG;
	tag_t *PartsTag=NULLTAG;
	tag_t dml_tag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t RevTypTag = NULLTAG;
	tag_t NonClrPartTag = NULLTAG;
	char *RevTyp = NULL;
	char *dmlNumber = NULL;
	char *DMLRevId = NULL;
	char *DML_rlstype = NULL;
	char *DMLProj = NULL;

	if(ITEM_find_item(dml_no, &dml_tag)!=ITK_ok)PrintErrorStack();
	if (dml_tag != NULLTAG)
	{
		if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));

		if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
		printf(" and DML_rlstype: [%s]", DML_rlstype);fflush(stdout);

		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
		printf("\n RevTyp type: [%s]\n", RevTyp);fflush(stdout);

		if((strcmp(DML_rlstype,"Veh")==0) || (strcmp(DML_rlstype,"MR")==0))
		{
			// START---define Query/Control objects/Relation type
			if(GRM_find_relation_type("CMHasSolutionItem", &tsk_HSI_rel_type)!=ITK_ok)PrintErrorStack();
			if(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind)!=ITK_ok)PrintErrorStack();
			if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel)!=ITK_ok)PrintErrorStack();

			if(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId)!=ITK_ok)PrintErrorStack();

			if(QRY_find("ClrPart", &ClrPartQryTag));
			if (ClrPartQryTag) {
				printf("\n CM=Found Query ClrPartQryTag \n"); fflush(stdout);
			}
			else {
				printf("\n\t CM=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(stdout);

				return ifail;
			}

			if(QRY_find("ControlObjects", &qryCTOTag));
			if (qryCTOTag)
			{
				printf("\n qryCTOTag:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n qryCTOTag:Not Found Query ControlObjects \n");fflush(stdout);
			}

			if(QRY_find("ClrScheme", &SchmqueryTag));
			if (SchmqueryTag)
			{
				printf("\n CM=Found Query SchmqueryTag"); fflush(stdout);
			}else
			{
				printf("\n CM=Not Found Query SchmqueryTag \n"); fflush(stdout);
				if(POM_logout(false)!=ITK_ok)PrintErrorStack();
				return ifail;
			}

			if(QRY_find("General...", &GeneralQryTag));
			if (GeneralQryTag)
			{
				printf("\nGeneral... Found Query");	fflush(stdout);
			}
			else
			{
				printf("\n General...:Not Found Query \n");fflush(stdout);
				if(POM_logout(false)!=ITK_ok)PrintErrorStack();
				return ifail;
			}
			// END---define Query/Control objects/Relation type

			//DML DETAILS.................
			if(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber)!=ITK_ok)PrintErrorStack();
			printf("\n DML Number: [%s]", dmlNumber);fflush(stdout);

			if(AOM_ask_value_string(DMLRevTag,"item_revision_id",&DMLRevId)!=ITK_ok)PrintErrorStack();
			printf("  DMLRevId: [%s]", DMLRevId);fflush(stdout);

			if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
			printf("  DML_rlstype: [%s]", DML_rlstype);fflush(stdout);

			//if(AOM_ask_value_string(DMLRevTag,"t5_ProjectCode",&DMLProj)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode ",&DMLProj)!=ITK_ok)PrintErrorStack();
			printf("  DMLProj: [%s]", DMLProj);fflush(stdout);

			if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
			printf("\n No. of tskcnt: %d ",tskcnt);fflush(stdout);

			if (tskcnt>0)
			{
				/////////////////////////////Color Scheme is Queryed/////////////////////////////////////////
				tag_t *ColSchme_tags = NULLTAG;
				tag_t *CmpCodeOfClrScheme = NULLTAG;
				tag_t *ClrPrtTags = NULLTAG;
				tag_t *Col_Rlz_St_list = NULLTAG;
				tag_t *sec_objects = NULLTAG;
				tag_t *CtrlObjTag = NULLTAG;
				tag_t *CntrolObjectTag = NULLTAG;
				tag_t *ProjSetObs = NULLTAG;

				tag_t ColorSchemetag = NULLTAG;
				tag_t ColSchmTypeTag=NULLTAG;
				tag_t ColSchmRevTag = NULLTAG;
				tag_t CmpCodeObjTag=NULLTAG;
				tag_t ColItemTag = NULLTAG;
				tag_t ColorRevTag = NULLTAG;
				tag_t NewColorRevTag = NULLTAG;
				tag_t ReltnExist = NULLTAG;
				tag_t reltask = NULLTAG;
				tag_t secObjTypeTag	= NULLTAG;
				tag_t PrjCdObj	= NULLTAG;

				int resultColSchm=0;
				int co , rs, RlzRevFlag=0;
				int status_count=0;
				int Cmpcount , g1=0;
				int n_ClrPrt_tags, ColRlzStatusCnt, ss2, ColRlzRevFlag=0;
				int n_attchs , st = 0;
				int resultCountObs = 0;
				int n_entriesObs = 2;

				char type_name2[TCTYPE_name_size_c+1];

				char* tsk_object_type = NULL;
				char* tsk_object_name = NULL;
				char* Part_no = NULL;
				char* sPartColInd = NULL;
				char *Clrscheme = NULL;
				char *CpyClrscheme = NULL;
				char *ClSrlName=NULL;
				char *ClSuffix=NULL;
				char *ColSchmRlzSt = NULL;
				char *SchmCmpCode = NULL;
				char *t5ClSrl = NULL;
				char *Suffix=NULL;
				char *ColourID=NULL;
				char *ColPrtLatestRlzSt=NULL;
				char *NewColPartRevSeq=NULL;
				char *NewColourPart=NULL;
				char *info1S=NULL;
				char *ProjectVehClass=NULL;
				char *NCPrtRevision=NULL;

				char *qry_entries4[1] = {"ID"};
				char *qry_entries[1] = {"ID"};
				char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
				char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
				char ColSchm_name[TCTYPE_name_size_c+1];

				NewColourPart=(char *) MEM_alloc(50 * sizeof(char ));
				CpyClrscheme=(char *) MEM_alloc(50 * sizeof(char ));

				int n_entryCT = 1;
				int n_entryClrSchm = 2;
				int rsltCnt, rsltCount, ct, PrjPltfmSchmFlag = 0;

				char *qry_entriesObs[2] = {"Name","Type"};
				char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
				char *qry_entryCT[1]  = {"SYSCD"};
				char *qry_entrySchm[2]  = {"SYSCD","SUBSYSCD"};
				char **qryCT_values =  (char **) MEM_alloc(10 * sizeof(char *));
				char **qrySchm_values =  (char **) MEM_alloc(10 * sizeof(char *));

				if (GeneralQryTag!=NULLTAG)
				{
					qry_valuesObs[0] = DMLProj ;	
					qry_valuesObs[1] = "Project" ;

					if(QRY_execute(GeneralQryTag,n_entriesObs,qry_entriesObs,qry_valuesObs,&resultCountObs,&ProjSetObs));
					printf("\n11 Unique General... Query resultCount :%d:\n", resultCountObs); fflush(stdout);

					if (resultCountObs > 0)
					{
						PrjCdObj = ProjSetObs[0];
						if(AOM_ask_value_string(PrjCdObj,"t5_VehicleClass ",&ProjectVehClass) != ITK_ok);
						printf("\nCM--ProjectVehClass= [%s]",ProjectVehClass);fflush(stdout);
					}
				}

				////CpyClrscheme =  strtok(Clrscheme,",");
				////CpyClrscheme =  "CLRSCM-X4/19/0004" ;
				////CpyClrscheme =  "CLRSCM-X4/19/0005" ;
				//CpyClrscheme =  "CLRSCM-X4/*";
				tc_strcpy(CpyClrscheme,"");
				tc_strcpy(CpyClrscheme,"CLRSCM-");
				if (qryCTOTag!=NULLTAG)
				{
					printf("\n A--Found Query ControlObjects---");fflush(stdout);
					qryCT_values[0] = "ERCVali";
					if(QRY_execute(qryCTOTag, n_entryCT, qry_entryCT, qryCT_values, &rsltCnt, &CtrlObjTag));
					printf(" \n ERCVali:ctrlObj rsltCnt :%d:", rsltCnt); fflush(stdout);
					if(rsltCnt > 0)
					{
						if (AOM_ask_value_string(CtrlObjTag[0],"t5_Userinfo7",&info7ClrSchmMsg)!=ITK_ok)   PrintErrorStack();
						printf("\n info7ClrSchmMsg is = [%s]\n", info7ClrSchmMsg);fflush(stdout); //SchmMsgON
					}

					printf("\n B--Found Query ControlObjects---");fflush(stdout);
					qrySchm_values[0] = "ClrSchm";
					qrySchm_values[1] = DMLProj;
					if(QRY_execute(qryCTOTag, n_entryClrSchm, qry_entrySchm, qrySchm_values, &rsltCount, &CntrolObjectTag));
					printf(" \n ClrSchm:ctrlObj rsltCount :%d:", rsltCount); fflush(stdout);
					info2SchmCre=(char *) MEM_alloc(20 * sizeof(char ));
					strcpy(info2SchmCre,"");
					if(rsltCount > 0)
					{
						for (ct=0; ct<rsltCount ; ct++)
						{
							if (AOM_ask_value_string(CntrolObjectTag[ct],"t5_Userinfo1",&info1S)!=ITK_ok)   PrintErrorStack();
							printf("\n ClrSchm:info1S= [%s]", info1S);fflush(stdout);
							if (AOM_ask_value_string(CntrolObjectTag[ct],"t5_Userinfo2",&info2SchmCre)!=ITK_ok)   PrintErrorStack();
							printf("\n ClrSchm:info2SchmCre= [%s]", info2SchmCre);fflush(stdout);
						}
						if ((strlen(info1S)>0) && (info1S!=NULL))
						{
							tc_strcat(CpyClrscheme,info1S);
						}
					}
				}
				tc_strcat(CpyClrscheme,"*");

				printf ("\n CM=CpyClrscheme --> [%s]\n", CpyClrscheme); fflush(stdout);
				valuesColSchm[0] = CpyClrscheme ;
				if(QRY_execute(SchmqueryTag, 1, qry_entries4, valuesColSchm, &resultColSchm, &ColSchme_tags));
				printf("\n CM=resultColSchm count is-------->  : %d",resultColSchm);fflush(stdout);

				///////////////////////////// For loop for DML task and Queryed CMReferences Item /////////////////////////////////////////
				for (i=0;i<tskcnt ;i++ )
				{
					if(AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(Dml_tasks[i],"object_name",&tsk_object_name)!=ITK_ok)PrintErrorStack();
					printf("\n CM=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(stdout);

					if(tc_strcmp(tsk_object_type,"T5_ChangeTaskRevision")==0)
					{
						if(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem", &partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
						printf("\n CM=No. of partcnt: %d",partcnt);fflush(stdout);

						if (partcnt>0)
						{
							NCAssyChildFlag=0;
							NoColSchemeMatchPrts = (char *) MEM_alloc(10000 * sizeof(char));

							ifail = BOM_create_window (&windowClr);
							CHECK_FAIL;
							//ifail = CFM_find( "Latest Working", &ruleNC );
							ifail = CFM_find( "ERC release and above", &ruleNC );
							CHECK_FAIL;
							ifail = BOM_set_window_config_rule( windowClr, ruleNC );
							CHECK_FAIL;

							tc_strcpy(NewColourPart,"");

							for (k=0; k<partcnt ;k++ )
							{
								NCAssyChildFlag=1;
								NonClrPartTag=PartsTag[k];

								ifail = AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no); CHECK_FAIL;
								printf("\nCL=k: %d----------------Assembly: %s --------------------------------------------------------",k,Part_no);fflush(stdout);

								ifail = AOM_ask_value_string(NonClrPartTag,"item_revision_id",&NCPrtRevision);
								printf("\n Non-Color Part Revision : %s \n",NCPrtRevision); fflush(stdout);

								//if(tc_strstr(NCPrtRevision,"NR")==NULL)
								//{
									//check latest ERC Released Non-Colour should be attached to DML
									ifail = AOM_UIF_ask_value(NonClrPartTag, "t5_ColourInd", &sPartColInd); CHECK_FAIL;
									printf("  ColInd: %s",sPartColInd);fflush(stdout);

									if(tc_strcmp(sPartColInd,"Y")==0)
									{
										tm_ProcessColourPart(tskcnt, Dml_tasks, Dml_tasks[i], NCAssyChildFlag, NonClrPartTag, resultColSchm, ColSchme_tags, NewColourPart);
									}
								//}
								//printf("\n\t CM=NewColourPart: [%s]",NewColourPart);fflush(stdout);
							} //for loop end for partcnt
							
							/*
							printf("\n info7ClrSchmMsg= [%s]  strlen(NoColSchemeMatchPrts): %d", info7ClrSchmMsg,strlen(NoColSchemeMatchPrts));fflush(stdout); //SchmMsgON
							if ((tc_strcmp(info7ClrSchmMsg,"SchmMsgON")==0)&&(strlen(NoColSchemeMatchPrts)>0))
							{
								tc_strcat(NoColSchemeMatchPrts,"\n Colour Scheme match not found for above list of colour Parts DML.\nPls contact PLM colour support team.\n");
								NoColSchemeMatchPrts[strlen(NoColSchemeMatchPrts)] = '\0';

								printf("\nList NoColSchemeMatchPrts: [%s]",NoColSchemeMatchPrts);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,NoColSchemeMatchPrts);

								return ITK_errStore1;
							}
							*/
						} //if end of partcnt
					} //if end of tsk_object_type
				} //for loop end for tskcnt
			} //if end of tskcnt
		} //if end of RevTyp=ChangeRequestRevision
		else
		{
			printf("\nDML is not of CM hence skipping from validatn tm_ColourModificatnRlz. \n");fflush(stdout);
		}
	} //if end of dml tag
	else
	{
		printf("\n Else--Input DML does not present...\n");fflush(stdout);
	}

	printf("\n\n CL Task-Process is Finished..\n");fflush(stdout);

	return ITK_ok;
}

int ValColAndNonColBomForRevise_CL(tag_t NonClrRev,tag_t Clrrev,int ColRevRlzStatus, tag_t ColSchmRevTag)
{
	int ifail = ITK_ok;
	int no_bom_linesN, jnc=0;
	int no_bom_linesC, jc=0;
	int FlagchildPresentInBom=0;
	int FlagBomDiff=0;
	int Cmpcount2, k2, CompCodeMatchFlag=0;

	tag_t windowNC=NULLTAG;
	tag_t windowClr=NULLTAG;
	tag_t rule = NULLTAG;
	tag_t ruleClr = NULLTAG;
	tag_t top_lineNC = NULLTAG;
	tag_t top_lineClr = NULLTAG;
	tag_t CmpCodeObj2 = NULLTAG;

	tag_t *child_bom_linesNC = NULLTAG;
	tag_t *child_bom_linesC = NULLTAG;
	tag_t *CmpCodeOfClrScheme2 = NULLTAG;

	char *child_item_idN = NULL;
	char *child_item_idN2 = NULL;
	char *ChildRevSeqN = NULL;
	char *ChildColIndN = NULL;
	char *child_item_idC = NULL;
	char *ChildRevSeqC = NULL;
	char *ChildColIndC = NULL;
	char *CmpCodeCmp2 = NULL;
	char *t5ClSrl = NULL;
	char *Suffix = NULL;
	char *ColourID = NULL;
	char *ChildNCCompCode = NULL;
	child_item_idN2=(char *) MEM_alloc(50);
	
	ifail = BOM_create_window (&windowNC);
	ifail = BOM_create_window (&windowClr);
	ifail = CFM_find("ERC Review And Above", &rule);	//Non-colour
	ifail = BOM_set_window_config_rule(windowNC, rule);	//Non-colour
	ifail = BOM_set_window_top_line(windowNC, null_tag, NonClrRev, null_tag, &top_lineNC);
	ifail = BOM_window_show_suppressed(windowNC);
	ifail = BOM_line_ask_child_lines(top_lineNC, &no_bom_linesN, &child_bom_linesNC);
	//colour
	if (ColRevRlzStatus==1)
	{
		ifail = CFM_find( "Color ERC release and above", &ruleClr );//colour
	}
	else
	{
		ifail = CFM_find( "Color ERC Review and above", &ruleClr );//colour
	}
	ifail = BOM_set_window_config_rule( windowClr, ruleClr ); 
	ifail = BOM_set_window_top_line (windowClr, null_tag, Clrrev, null_tag, &top_lineClr);
	ifail = BOM_window_show_suppressed ( windowClr );
	ifail = BOM_line_ask_child_lines (top_lineClr, &no_bom_linesC, &child_bom_linesC);
	
	printf("\n\t no_bom_linesN: %d   no_bom_linesC: %d",no_bom_linesN,no_bom_linesC);fflush(stdout);
	FlagBomDiff=0;
	for (jnc = 0; jnc < no_bom_linesN; jnc++) //Non-Colour Bom loop
	{
		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
		if (strstr(child_item_idN,"_")!=NULL)
		{
			continue;
		}
		if (strcmp(subString(child_item_idN,0,1),"G")==0)
		{
			continue;
		}

		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
		//ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);
		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndN);

		printf("\n\t A--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

		strcpy(child_item_idN2,"");
		tc_strcpy(child_item_idN2,child_item_idN);
		CompCodeMatchFlag==0;
		if (strcmp(ChildColIndN,"Y")==0)
		{
			ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_PrtCatCode",&ChildNCCompCode);
			if (SchmWithCmpcdRel != NULLTAG)
			{
				ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
				printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d",Cmpcount2); fflush(stdout);
				if(Cmpcount2 > 0)
				{
					for (k2=0;k2<Cmpcount2 ;k2++ )
					{
						if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
						CmpCodeObj2=CmpCodeOfClrScheme2[k2];
						ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
						printf("\n\t\t CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode); fflush(stdout);
						if(tc_strcmp(ChildNCCompCode,CmpCodeCmp2)==0)
						{
							printf(" -- Match Foun compcode "); fflush(stdout);
							CompCodeMatchFlag=1;
							ifail = AOM_ask_value_string(CmpCodeObj2, "t5_ClSrl", &t5ClSrl );
							Suffix =  strtok(t5ClSrl,";");
							ColourID  =  strtok(NULL,";");
							
							tc_strcat(child_item_idN2,Suffix);

							break;
						}
					}
				}
			}
		}
			FlagchildPresentInBom=0;
			for (jc = 0; jc < no_bom_linesC; jc++)
			{
				//ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndC);

				//if ((strcmp(ChildColIndC,"Y")==0)||(strcmp(ChildColIndC,"C")==0))
				//{
					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
					if (strstr(child_item_idC,"_")!=NULL)
					{
						continue;
					}
					if (strcmp(subString(child_item_idC,0,1),"G")==0)
					{
						continue;
					}

					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);

					printf("\n\t A--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
					
					//if ((strstr(child_item_idC,child_item_idN)!=NULL) && ((strcmp(ChildColIndC,"C")==0)||(strcmp(ChildColIndC,"N")==0)||(strcmp(ChildColIndC,"Y")==0)))
					//if (strstr(child_item_idC,child_item_idN)!=NULL)
					
					printf("\n\t\t child_item_idC: %s  child_item_idN: %s   child_item_idN2: %s  ",child_item_idC,child_item_idN,child_item_idN2);fflush(stdout);
					if (strstr(child_item_idC,child_item_idN)!=NULL)
					{
						if (strcmp(child_item_idC,child_item_idN2)==0)
						{
							FlagchildPresentInBom=1;
							break;
						}
					}
				//}
			}
			if (FlagchildPresentInBom==0)
			{
				FlagBomDiff++;
			}
			printf(" -- FlagchildPresentInBom: %d  FlagBomDiff: %d",FlagchildPresentInBom,FlagBomDiff); fflush(stdout);
		//}
	}
	printf("\n\t A--FlagBomDiff: %d",FlagBomDiff);fflush(stdout);
	if (FlagBomDiff==0)
	{
		for (jc = 0; jc < no_bom_linesC; jc++) //Colour Bom loop
		{
			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
			if (strstr(child_item_idC,"_")!=NULL)
			{
				continue;
			}
			if (strcmp(subString(child_item_idC,0,1),"G")==0)
			{
				continue;
			}

			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);
			printf("\n\t B--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
			
			FlagchildPresentInBom=0;
			for (jnc = 0; jnc < no_bom_linesN; jnc++)
			{
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
				if (strstr(child_item_idN,"_")!=NULL)
				{
					continue;
				}
				if (strcmp(subString(child_item_idN,0,1),"G")==0)
				{
					continue;
				}

				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);

				printf("\n\t B--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

				if (strstr(child_item_idC,child_item_idN)!=NULL)
				{
					FlagchildPresentInBom=1;
					break;
				}

			}
			if (FlagchildPresentInBom==0)
			{
				FlagBomDiff++;
			}
		}
	}
	printf("\n\t In ValColAndNonColBomAttrForRevise function,  FlagBomDiff: %d",FlagBomDiff);fflush(stdout);

	/*if (FlagBomDiff==0)
	{
		if (SchmWithCmpcdRel != NULLTAG)
		{
			ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
			printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d\n\n",Cmpcount2); fflush(stdout);
			if(Cmpcount2 > 0)
			{
				for (k2=0;k2<Cmpcount2 ;k2++ )
				{
					if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
					CmpCodeObj2=CmpCodeOfClrScheme2[k2];
					ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
					printf("\n CmpCodeCmp2 & t5PrtCatCd status--> : %s-%s\n",CmpCodeCmp2,t5PrtCatCd); fflush(stdout);
					//if(tc_strcmp(t5PrtCatCd,CmpCodeCmp2)==0)
					//{
					//	ClrGrpPartPresentFlag=0;
					//	ifail = AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl );
					//	Suffix =  strtok(t5ClSrl,";");
					//	ColourID  =  strtok(NULL,";");
					//}
				}
			}
		}
	}*/

	return FlagBomDiff;
}

int tm_ProcessColourPart(int taskCnt, tag_t *DmlTaskTags, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, int ColSchmCnt, tag_t *ColSchme_tags, char *NewColourPart)
{
	int co, rs, RlzRevFlag=0;
	int status_count=0;
	int RlzStatusCnt , ss =0;
	int n_ClrPrt_tags, ColRlzStatusCnt, ss2, n_ClrChild_tags=0;
	int n_attchs , st = 0;
	int no_bom_lines, j = 0;
	int ncItem_count , ik , relRev2Flag = 0;
	int NonClrChildCnt, nc, NonClrPrevChildCnt, ncp = 0;
	int childNotExitFlag=0;
	int SchmRevCnt, sc, SchmRevRlzFlag=0;
	int ClrCount, zp, ColRlzRevFlag, zp1 =0;
	int Cmpcount, g1, MatchColSchemeFlag = 0;
	int nc2, NClrQty, p2 = 0;
	int colPrtCnt=0;

	tag_t *ClrPrtTags = NULLTAG;
	tag_t *Col_Rlz_St_list = NULLTAG;
	tag_t *sec_objects = NULLTAG;
	tag_t *relStatus_list = NULLTAG;
	tag_t *child_bom_lines = NULLTAG;
	tag_t *ncRev_list = NULLTAG;
	tag_t *NonClrChilds = NULLTAG;
	tag_t *NonClrPrevChilds = NULLTAG;
	tag_t *SchmRev_list = NULLTAG;
	tag_t *ClrPart_tag = NULLTAG;
	tag_t *CmpCodeOfClrScheme = NULLTAG;
	tag_t *ClrChildTags = NULLTAG;
	tag_t *ColPrtUniqTags = NULLTAG;

	tag_t NonClrItemMstrTag = NULLTAG;
	tag_t NonClrItemRevTag = NULLTAG;
	tag_t ColorSchemetag = NULLTAG;
	tag_t ColSchmTypeTag = NULLTAG;
	tag_t ColSchmRevTag = NULLTAG;
	tag_t CmpCodeObjTag = NULLTAG;
	tag_t ColItemTag = NULLTAG;
	tag_t ColorRevTag = NULLTAG;
	tag_t NewColorRevTag = NULLTAG;
	tag_t ReltnExist = NULLTAG;
	tag_t reltask = NULLTAG;
	tag_t secObjTypeTag	= NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t ColChilditemMstr = NULLTAG;
	tag_t ColChilditemRev = NULLTAG;
	tag_t Child_item_revTag = NULLTAG;
	tag_t tPrevRelationExist = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t NClrItemMstrTag = NULLTAG;
	tag_t NonClrPrtPrevRevTag = NULLTAG;
	tag_t windowNonClr = NULLTAG;
	tag_t top_lineNonClr = NULLTAG;
	tag_t windowNonClrPrev = NULLTAG;
	tag_t top_lineNonClrPrev = NULLTAG;
	tag_t latestClrRev = NULLTAG;
	tag_t Childobject = NULLTAG;
	tag_t NCChildItemTag = NULLTAG;
	tag_t ClrItemMstrTag = NULLTAG;
	tag_t ClrItemRevTag = NULLTAG;

	char* Part_no = NULL;
	char* Col_Ind = NULL;
	char* Comp_Code = NULL;
	char* PartType = NULL;
	char* RevSeqTmp = NULL;
	char* RevStr = NULL;
	char* SeqStr = NULL;
	char* LatestRlzSt = NULL;
	char* ColPartNo = NULL;
	char* ColPartRev = NULL;
	char* ColPrtRelSt = NULL;

	char type_name2[TCTYPE_name_size_c+1];

	char *Clrscheme = NULL;
	char *CpyClrscheme = NULL;
	char *ClSrlName=NULL;
	char *ClSuffix=NULL;
	char* SchmName=NULL;
	char* SchmRev=NULL;
	char* SchmRel_status=NULL;
	char *ColSchmRlzSt = NULL;
	char *SchmCmpCode = NULL;
	char *t5ClSrl = NULL;
	char *Suffix=NULL;
	char *ColourID=NULL;
	char *ColPrtLatestRlzSt=NULL;
	char *NewColPartRevSeq=NULL;
	char *child_item_id = NULL;
	char *ChildRevSeq = NULL;
	char *ChildColInd = NULL;
	char *Part_noLatest = NULL;
	char *RevSeqTmpLatest = NULL;
	char *ncPartno=NULL;
	char *ncPartRev=NULL;
	char *ncRel_status=NULL;
	char *NCRevChild=NULL;
	char *NCPrevRevChild=NULL;
	char *NCChild = NULL;
	char *NCChildRevSeq = NULL;
	char *NCChildColInd = NULL;
	char *NCChildCompCode = NULL;
	char *NCChildQty = NULL;
	tag_t ruleRev = NULLTAG;

	char *NonClrChildSet=NULL;
	char *ClrAssySet=NULL;
	char *DMLNo=NULL;
	char *sTaskName=NULL;

	tag_t queryds = NULLTAG;
	char *qry_entriesds[1] = {"ID"};
	char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
	int n_entries = 1;
	int TaskClSet =0;
	tag_t	*TaskClTag	= NULLTAG;

	char *qry_entries4[1] = {"ID"};
	char *qry_entries[1] = {"ID"};
	char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
	char ColSchm_name[TCTYPE_name_size_c+1];

	NonClrChildSet = (char *) MEM_alloc(10000 * sizeof(char));
	DMLNo = (char *) MEM_alloc(20 * sizeof(char));

	if(AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrPartTag,"item_revision_id",&RevSeqTmp)!=ITK_ok)PrintErrorStack();
	printf("\n\t Part_no: [%s,%s]",Part_no,RevSeqTmp); fflush(stdout);

	if(AOM_ask_value_string(NonClrPartTag,"t5_ColourInd",&Col_Ind)!=ITK_ok)PrintErrorStack();
	printf("  Col_Ind: [%s]",Col_Ind);	fflush(stdout);

	if(AOM_ask_value_string(NonClrPartTag,"t5_PrtCatCode",&Comp_Code)!=ITK_ok)PrintErrorStack();
	printf("  Comp_Code: [%s]",Comp_Code);	fflush(stdout);

	if(AOM_ask_value_string(NonClrPartTag, "t5_PartType", &PartType)!=ITK_ok)PrintErrorStack();
	printf("  PartType: [%s]",PartType);	fflush(stdout);

	if(ITEM_find_item(Part_no, &NonClrItemMstrTag)!=ITK_ok)PrintErrorStack();

	if(ITEM_ask_latest_rev(NonClrItemMstrTag,&NonClrItemRevTag)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrItemRevTag,"item_id",&Part_noLatest)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrItemRevTag,"item_revision_id",&RevSeqTmpLatest)!=ITK_ok)PrintErrorStack();

	if(tc_strcmp(Col_Ind,"Y")==0)
	{
		if(WSOM_ask_release_status_list(NonClrPartTag, &RlzStatusCnt, &relStatus_list)!=ITK_ok)PrintErrorStack();
		printf("  RlzStatusCnt: %d",RlzStatusCnt);	fflush(stdout);

		if (RlzStatusCnt > 0)
		{
			RlzRevFlag=0;
			for(ss=0; ss<RlzStatusCnt ; ss++)
			{
				if(AOM_ask_value_string(relStatus_list[ss],"object_name",&LatestRlzSt)!=ITK_ok)PrintErrorStack();
				printf("  LatestRlzSt: %s",LatestRlzSt);fflush(stdout);

				//if((tc_strcmp(LatestRlzSt,"ERC Released")==0) || (tc_strcmp(LatestRlzSt,"T5_LcsErcRlzd")==0))
				if(tc_strcmp(LatestRlzSt,"T5_LcsReview")==0)
				{
					RlzRevFlag=1;

					//Get child from BOM of latest released and previous released revision---START------
					tc_strcpy(NonClrChildSet,"");

					if(ITEM_list_all_revs (NonClrItemMstrTag, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
					printf("\n\t CM=ncItem_count::%d:\n\t", ncItem_count);fflush(stdout);

					if(ncItem_count > 0)
					{
						//relRev2Flag = 0;
						for(ik=ncItem_count-1;ik>=0;ik--)
						{
							if(AOM_UIF_ask_value(ncRev_list[ik], "item_id", &ncPartno)!=ITK_ok)PrintErrorStack();
							if(AOM_UIF_ask_value(ncRev_list[ik], "item_revision_id", &ncPartRev)!=ITK_ok)PrintErrorStack();
							if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
							if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
							{
								printf("  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(stdout);
								NonClrPrtPrevRevTag=ncRev_list[ik];
								break;
							}							
						}
					}

					if(BOM_create_window(&windowNonClr)!=ITK_ok)PrintErrorStack();
					if(CFM_find("ERC Review And Above", &ruleRev)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_top_line(windowNonClr, null_tag, NonClrPartTag, null_tag, &top_lineNonClr)!=ITK_ok)PrintErrorStack();
					if(BOM_window_show_suppressed(windowNonClr)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_pack_all(windowNonClr, true)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_config_rule(windowNonClr, ruleRev)!=ITK_ok)PrintErrorStack();
					if(BOM_line_ask_child_lines(top_lineNonClr, &NonClrChildCnt, &NonClrChilds)!=ITK_ok)PrintErrorStack();

					if (NonClrPrtPrevRevTag!=NULLTAG)
					{
						if(BOM_create_window(&windowNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_top_line(windowNonClrPrev, null_tag, NonClrPrtPrevRevTag, null_tag, &top_lineNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_window_show_suppressed(windowNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_pack_all(windowNonClrPrev, true)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_config_rule(windowNonClrPrev, ruleNC)!=ITK_ok)PrintErrorStack();
						if(BOM_line_ask_child_lines(top_lineNonClrPrev, &NonClrPrevChildCnt, &NonClrPrevChilds)!=ITK_ok)PrintErrorStack();

						for (nc = 0; nc < NonClrChildCnt; nc++)
						{
							childNotExitFlag=0;
							if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
							for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
							{
								if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();

								if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
								{
									childNotExitFlag=1;
									break;
								}
							}
							if (childNotExitFlag==0)
							{
								if (strlen(NonClrChildSet)==0)
								{
									tc_strcpy(NonClrChildSet,NCRevChild);
									tc_strcat(NonClrChildSet,",");
								}
								else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
								{
									tc_strcat(NonClrChildSet,NCRevChild);
									tc_strcat(NonClrChildSet,",");
								}
							}
						} //End of loop NonClrChildCnt

						if (strlen(NonClrChildSet)==0)
						{
							for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
							{
								childNotExitFlag=0;
								if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();
								for (nc = 0; nc < NonClrChildCnt; nc++)
								{
									if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
									if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
									{
										childNotExitFlag=1;
										break;
									}
								}
								if (childNotExitFlag==0)
								{
									if (strlen(NonClrChildSet)==0)
									{
										tc_strcpy(NonClrChildSet,NCRevChild);
										tc_strcat(NonClrChildSet,",");
									}
									else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
									{
										tc_strcat(NonClrChildSet,NCRevChild);
										tc_strcat(NonClrChildSet,",");
									}
								}
							} //End of loop NonClrPrevChildCnt				
						} //End of condn if (strlen(NonClrChildSet)==0)
					}
					printf("\t NonClrChildCnt= %d  NonClrPrevChildCnt= %d  strlen(NonClrChildSet)= %d ",NonClrChildCnt,NonClrPrevChildCnt,strlen(NonClrChildSet)); fflush(stdout);
					//Get child from BOM of latest released and previous released revision---END------
									// ----------------START-Get Colour Parts-------------------------------------------
					if(tRelationFind!=NULLTAG)
					{
						printf("\n\n\t CM=ColSchmCnt-----> %d",ColSchmCnt);fflush(stdout);
						if(GRM_list_primary_objects_only(NonClrPartTag,tRelationFind,&ClrCount,&ClrPart_tag)!=ITK_ok)PrintErrorStack();
						printf("\n\t ClrCount: %d",ClrCount);fflush(stdout);

						tag_t ColItemMstrTag = NULLTAG;
						tag_t ColLatestRevTag = NULLTAG;
						tag_t owningUserSchm = NULLTAG;
						int zp2 = 0;
						char useridSchm[SA_user_size_c+1];

						if(ClrCount>0)
						{
							colPrtCnt=0;

							ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
							ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));

							tc_strcpy(ClrAssySet,"");

							for(zp1 = 0; zp1<ClrCount; zp1++)
							{
								latestClrRev=ClrPart_tag[zp1];
								if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(latestClrRev,"item_revision_id",&ColPartRev)!=ITK_ok)PrintErrorStack();

								printf("\n\t %d--ColPartNo: %s/%s",zp1,ColPartNo,ColPartRev);fflush(stdout);

								if(ITEM_find_item(ColPartNo, &ColItemMstrTag)!=ITK_ok)PrintErrorStack();
								if(ITEM_ask_latest_rev(ColItemMstrTag,&ColLatestRevTag)!=ITK_ok)PrintErrorStack();

								if (strlen(ClrAssySet)==0)
								{
									tc_strcpy(ClrAssySet,ColPartNo);
									tc_strcat(ClrAssySet,",");

									ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
									colPrtCnt=colPrtCnt+1;
								}
								else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
								{
									tc_strcat(ClrAssySet,ColPartNo);
									tc_strcat(ClrAssySet,",");

									ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
									colPrtCnt=colPrtCnt+1;
								}
							}
							printf("\n\t Distinct colPrtCnt: %d",colPrtCnt);fflush(stdout);

							//for(zp2 = 0; zp2<colPrtCnt; zp2++)
							//{
							//	latestClrRev=ColPrtUniqTags[zp2];
							//
							//	if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();
							//	if(AOM_ask_value_string(latestClrRev,"item_revision_id",&ColPartRev)!=ITK_ok)PrintErrorStack();
							//	printf("\n\t %d  ColPartNo: %s-%s",zp2,ColPartNo,ColPartRev);fflush(stdout);
							//}

							//for(zp = 0; zp<ClrCount; zp++)
							for(zp = 0; zp<colPrtCnt; zp++)
							{
								ColRlzRevFlag=0;
								
								latestClrRev=NULLTAG;
								//latestClrRev=ClrPart_tag[zp];
								latestClrRev=ColPrtUniqTags[zp];

								if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();

								if(AOM_UIF_ask_value (latestClrRev, "release_status_list", &ColPrtRelSt)!=ITK_ok)PrintErrorStack();
								if((tc_strstr(ColPrtRelSt,"ERC Released")!=NULL)||(tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL))
								{
									ColRlzRevFlag=1;
								}
								printf("\n\n =======CM=ColAssy--zp: %d  ColourPart: %s  ColRlzRevFlag: %d===============================================",zp,ColPartNo,ColRlzRevFlag);fflush(stdout);

								// ----------------Colour Scheme-START---------------------------------------------
								if (ColSchmCnt > 0)
								{
									MatchColSchemeFlag=0;
									SchmRevRlzFlag=0;
									for(co = 0; co < ColSchmCnt; co++)
									{
										ColorSchemetag = ColSchme_tags[co];

										//if(TCTYPE_ask_object_type(ColorSchemetag,&ColSchmTypeTag)!=ITK_ok)PrintErrorStack();
										//if(TCTYPE_ask_name(ColSchmTypeTag,ColSchm_name)!=ITK_ok)PrintErrorStack();
										//printf("\n\t CM=ColSchm_name Class------> %s",ColSchm_name);fflush(stdout);

										if(ITEM_ask_latest_rev(ColorSchemetag , &ColSchmRevTag)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(ColSchmRevTag, "object_string", &SchmName)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(ColSchmRevTag, "item_revision_id", &SchmRev)!=ITK_ok)PrintErrorStack();

										//if(WSOM_ask_release_status_list(ColSchmRevTag, &status_count, &relStatus_list)!=ITK_ok)PrintErrorStack();
										//if(status_count > 0)
										//{
										//	for(rs = 0; rs < status_count; rs++)
										//	{
										//		if(AOM_ask_name(relStatus_list[rs], &ColSchmRlzSt)==ITK_ok)
										//		printf("\t ColSchm Release status:%s ", ColSchmRlzSt);fflush(stdout);
										//		if ((tc_strcmp(ColSchmRlzSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ColSchmRlzSt,"ERC Released")==0) )
										//		{
										//			break;
										//		}
										//	}
										//}

										if(AOM_UIF_ask_value (ColSchmRevTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
										if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
										{
											//printf(" --A-SchmRel_status");
											SchmRevRlzFlag=1;
											fflush(stdout);
										}
										else
										{
											//printf(" --B-SchmRel_status"); fflush(stdout);
											if(ITEM_list_all_revs (ColorSchemetag, &SchmRevCnt, &SchmRev_list)!=ITK_ok)PrintErrorStack();
											for(sc = 0; sc < status_count; sc++)
											{
												ColSchmRevTag=SchmRev_list[sc];
												if(AOM_UIF_ask_value (ColSchmRevTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
												if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
												{
													SchmRevRlzFlag=1;
													break;
												}									
											}								
										}
										if (SchmRevRlzFlag==0)
										{
											printf("\n  Scheme--co: %d ==>No Revision of scheme Released [%s], hence skipping ??",co,SchmName); fflush(stdout);
											//continue;
										}
										else if ( (SchmRevRlzFlag==1) && (ColSchmRevTag!=NULLTAG) )
										{
											printf("\n  info2SchmCre: [%s]  strlen(info2SchmCre): %d \n",info2SchmCre,strlen(info2SchmCre)); fflush(stdout);
											if ((strlen(info2SchmCre)>1) &&(strcmp(info2SchmCre,"loader")==0))
											{
												if( AOM_ask_owner( ColSchmRevTag, &owningUserSchm )!=ITK_ok);
												if( SA_ask_user_identifier(owningUserSchm,useridSchm)!=ITK_ok);
												printf(" == useridSchm: [%s]",useridSchm); fflush(stdout);

												if (strstr(useridSchm,"loader")!=0)
												{
													printf(" ----skipping"); fflush(stdout);
													continue;
												}
											}

											//if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSrl", &ClSrlName)!=ITK_ok)PrintErrorStack();
											//printf("\n\t CM=ClSrlName is --> : %s",ClSrlName); fflush(stdout);
											//
											//ClSuffix=tc_strtok(ClSrlName,";");
											//printf("\n\t CM=ClSuffix => %s ",ClSuffix );fflush(stdout);
											//
											//ClrSchmToVf = (char *) MEM_alloc( 50 * sizeof(char) );
											//strcpy(ClrSchmToVf,"");
											//tc_strcat(ClrSchmToVf,CpyClrscheme);
											//printf ("\n\t CM=ClrSchmToVf-------------------------------------> [%s]\n", ClrSchmToVf); fflush(stdout);

											if (SchmWithCmpcdRel!=NULLTAG)
											{
												if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok)PrintErrorStack();
												printf("\n  CM=Comp Code Cmpcount for Color Scheme: %d",Cmpcount); fflush(stdout);

												if(Cmpcount > 0)
												{
													for(g1=0;g1<Cmpcount;g1++ )
													{
														//printf("\n inside if loop for g1----> %d\n",g1); fflush(stdout);
														int NonClrflag=0;
														if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;
														CmpCodeObjTag=CmpCodeOfClrScheme[g1];
														if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok)PrintErrorStack();
														//printf("\n SchmCmpCode & Comp_Code is --> : %s = %s\n",SchmCmpCode,Comp_Code); fflush(stdout);
														if(tc_strcmp(SchmCmpCode,Comp_Code)==0)
														{
															printf("\n\n  co: %d ==>SchmName--> %s/%s",co,SchmName,SchmRev); fflush(stdout);
															printf("\n    SchmCmpCode & Comp_Code-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,Comp_Code); fflush(stdout);
															n_ClrPrt_tags=0;
															NonClrflag=1;
															if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok)PrintErrorStack();
															printf("\n    t5ClSrl --> : %s",t5ClSrl); fflush(stdout);

															if(tc_strstr(t5ClSrl,";")!=NULL)
															{
																Suffix =  strtok(t5ClSrl,";");
																//printf("\n    CM=Suffix --> : %s",Suffix); fflush(stdout);

																ColourID  =  strtok(NULL,";");
																//printf("\n\t CM=ColourID --> : %s",ColourID); fflush(stdout);
															}
															else
															{
																Suffix =  strtok(t5ClSrl,",");
																//printf("\n    CM=Suffix --> : %s",Suffix); fflush(stdout);

																ColourID  =  strtok(NULL,",");
																//printf("\n    CM=ColourID --> : %s",ColourID); fflush(stdout);
															}

															char *ColItem = NULL;
															logical checkout;

															if(tc_strcmp(PartType,"G")==0)
															{
																//printf("\n  before NewUniqGroupIDNum\n"); fflush(stdout);
																//ResponseStr = NewUniqGroupIDNum();
																//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																//
																//ColItem = NULL;
																//ColItem=(char *) MEM_alloc(25);														
																//strcpy(ColItem,"");
																//strcat(ColItem,ResponseStr);
																printf("\n    Colour Part for Group ID---->%s\n",ColItem);
															}
															else
															{
																ColItem=(char *) MEM_alloc(25);
																strcpy(ColItem,"");
																strcpy(ColItem,Part_no);
																strcat(ColItem,Suffix);
															}

															if (tc_strcmp(ColPartNo,ColItem)==0)
															{
																printf("\n\n    SchemeColourPart: %s == ColPartNo: %s --------------->ColPart Match Found......",ColItem,ColPartNo); fflush(stdout);
																MatchColSchemeFlag=1;
															}
															else
															{
																continue;
															}

															if (strlen(ColItem)>=1)
															{
																if (ClrPartQryTag!=NULLTAG) 
																{
																	//printf("\n    CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																	valuesClrPrt[0] = ColItem;
																	if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrPrt_tags, &ClrPrtTags));
																	printf("\n    1.ClrPart count is--------> %d ",n_ClrPrt_tags);fflush(stdout);
																}
																else
																{
																	printf("\n    Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
																	break;
																}
															}
															else{
																printf("\n    2.ClrPart count = 0");fflush(stdout);
																break;
															}

															tc_strcpy(NewColourPart,ColItem);

															printf("\t NCAssyChildFlag: %d   NewColourPart: [%s]",NCAssyChildFlag,NewColourPart);fflush(stdout);
															/////if (tc_strcmp(Part_noLatest,"544272300104")==0)
															/////{
															/////	NCAssyChildFlag=0;
															/////}
//															if (NCAssyChildFlag==1)
//															{
															tag_t ClritemTag = NULLTAG;
															tag_t clrbv = NULLTAG;
															tag_t  clrbvrTag = NULLTAG;
															tag_t *clr_bvs = NULLTAG;
															tag_t *clr_bvrs = NULLTAG;
															int bv_clrcount =0;
															int i1, TskHSICnt, ci, PartAttachtoDmlFlag =0;
															char *ColPartRev = NULL;
															char *tsk_name = NULL;
															char *TskSolutnItem = NULL;
															tag_t *TskHSItems = NULLTAG;

															if(n_ClrPrt_tags > 0)
															{
																ColItemTag = ClrPrtTags[0];

																if(ITEM_ask_latest_rev(ColItemTag,&ColorRevTag)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(ColorRevTag, "item_revision_id", &ColPartRev)!=ITK_ok)PrintErrorStack();
																printf("  ColPartRev: %s",ColPartRev);	fflush(stdout);

																if(WSOM_ask_release_status_list(ColorRevTag, &ColRlzStatusCnt, &Col_Rlz_St_list)!=ITK_ok)PrintErrorStack();
																printf("\t ColRlzStatusCnt: %d",ColRlzStatusCnt);	fflush(stdout);
																
																ColRlzRevFlag=0;
																if (ColRlzStatusCnt > 0)
																{
																	for(ss2=0; ss2<ColRlzStatusCnt ; ss2++)
																	{
																		if(AOM_ask_value_string(Col_Rlz_St_list[ss2],"object_name",&ColPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
																		if((tc_strcmp(ColPrtLatestRlzSt,"ERC Released")==0) || (tc_strcmp(ColPrtLatestRlzSt,"T5_LcsErcRlzd")==0))
																		{
																			printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
																			ColRlzRevFlag=1;
																			break;
																		}
																	}
																} //End of if (ColRlzStatusCnt > 0)

																if (ColRlzRevFlag==0)
																{
																	printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
																	////printf(" ----Latest ColourPart revision is not in ERC Released Status, hence skipping its colour colour part revise ??? \n");fflush(stdout);
																	
																	//START--Check ERC Review colour if attached to same working DML then proceed for bom change
																	PartAttachtoDmlFlag=0;
																	if (taskCnt>0)
																	{
																		for (i1=0;i1<taskCnt ;i1++ )
																		{
																			if(AOM_ask_value_string(DmlTaskTags[i1],"object_name",&tsk_name)==ITK_ok)
																			//printf("\n tsk_object_type is :%s\n",tsk_object_type);fflush(stdout);

																			if (tsk_HSI_rel_type!=NULLTAG)
																			{
																				if(GRM_list_secondary_objects_only(DmlTaskTags[i1], tsk_HSI_rel_type, &TskHSICnt, &TskHSItems)!=ITK_ok)PrintErrorStack();
																				printf("\n    i1: %d  Task: %s --->> TskHSICnt partcnt:  %d ",i1, tsk_name, TskHSICnt);fflush(stdout);

																				if (TskHSICnt > 0)
																				{
																					for (ci = 0; ci < TskHSICnt ; ci ++)
																					{
																						if( AOM_ask_value_string(TskHSItems[ci],"item_id",&TskSolutnItem)==ITK_ok)
																						//printf("\n\t\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);

																						if (tc_strcmp(ColItem,TskSolutnItem)==0)
																						{
																							printf("\n\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);
																							printf(" ---Match-Colour attached found to DML task"); fflush(stdout);
																							PartAttachtoDmlFlag=1;
																							break;
																						}
																					}
																				}
																			}
																			if (PartAttachtoDmlFlag==1)
																			{
																				break;
																			}
																		}
																	}
																	printf("\n\n\t PartAttachtoDmlFlag: %d  for ColItem: %s ",PartAttachtoDmlFlag, ColItem);fflush(stdout);
																	if (PartAttachtoDmlFlag==0)
																	{
																		printf(" ---ColourPart is not attached to same DML, hence skipping ????"); fflush(stdout);
																		//If Colour attached to another DML if not then attach to current DML and preoceed bom--add code
																	}
																	//END--Check ERC Review colour if attached to same working DML then proceed for bom change
																}
																
																//if (ColRlzRevFlag>0)
																if ((ColRlzRevFlag>0) || (PartAttachtoDmlFlag==1))
																{
																	int ReviseStatus = ValColAndNonColBomForRevise_CL(NonClrPartTag,ColorRevTag,ColRlzRevFlag,ColSchmRevTag);
																	printf("\n\t ColRlzRevFlag:%d  ReviseStatus: %d  NonColPartBomDiff: %d",ColRlzRevFlag, ReviseStatus, strlen(NonClrChildSet));fflush(stdout);

																	if ((ReviseStatus==0)&&(strlen(NonClrChildSet)==0))
																	{
																		printf("\t ---B--No need to revive Colour: %s/%s [%s] --No BOM Difference ..",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
																	}
																	else
																	{

																	if(RES_is_checked_out(ColorRevTag,&checkout)!=ITK_ok)PrintErrorStack();
																	//printf("\n\t CM=ColPart--Value of checkout: %d ",checkout);fflush(stdout);
																	printf(" 333checkout: %d ",checkout);fflush(stdout);
																	if (checkout==0)
																	{
																	printf("---Latest and previous Rlz NC_Rev bom difference present1...\n"); fflush(stdout);
																	int count2=0;
																	int z=0;
																	int bvr_count=0;
																	int n_occs_clr=0;
																	int ic = 0;
																	tag_t *occs_clr = NULLTAG;
																	tag_t *secondary_objects = NULLTAG;
																	tag_t *occs=NULL;
																	tag_t objTypeTag2 = NULLTAG;
																	char type_name1[TCTYPE_name_size_c+1];
																	char *object_type = NULL;
																	char *chname= NULL;

																	tag_t	NewTskObjOP		= NULLTAG;
																	tag_t	item			= NULLTAG;
																	tag_t	ERCDMLTag		= NULLTAG;
																	char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
																	int n_entriesDML = 1;
																	char *qry_entries5[1] = {"ID"};
																	int resultDMLNo=0;
																	tag_t *DMLNotags=NULLTAG;
																	tag_t ERCDMLObjtag = NULLTAG;
																	tag_t reln_type_tag = NULLTAG;
																	tag_t relation = NULLTAG;
																	char *Dml_taskNo = NULL;
																		
																	printf("---Latest and previous Rlz NC_Rev bom difference present...2\n"); fflush(stdout);
																	if(GRM_find_relation_type("T5_DMLTaskRelation",&reln_type_tag)!=ITK_ok)PrintErrorStack();
																	if(AOM_ask_value_string(Dml_task,"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
																	printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);

																	DMLNo = subString(Dml_taskNo,0,10);
																	printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);

																	if(QRY_find("ERC DML", &ERCDMLTag));
																	valuesERCDML[0] = DMLNo ;
																	if(QRY_execute(ERCDMLTag, n_entriesDML, qry_entries5, valuesERCDML, &resultDMLNo, &DMLNotags));
																	printf("\n resultDMLNo count is-------->  : %d",resultDMLNo);fflush(stdout);
																	if (resultDMLNo > 0)
																	{
																		ERCDMLObjtag = DMLNotags[0];
																	}

																	sTaskName = NULL;
																	sTaskName=(char *) MEM_alloc(50);
																	tc_strcpy(sTaskName,DMLNo);
																	tc_strcat(sTaskName,"_CL");																
																	printf("\n TaskName is ===> [%s]\n",sTaskName);fflush(stdout);

																	if(QRY_find("ERC DML Task", &queryds)!=ITK_ok)PrintErrorStack();
																	qry_valuesds[0] = sTaskName;
																	if(QRY_execute(queryds, n_entries, qry_entriesds, qry_valuesds, &TaskClSet, &TaskClTag)!=ITK_ok)PrintErrorStack();
																	printf("\n TaskClSet is :: %d\n", TaskClSet);fflush(stdout);

																	if(TaskClSet>0)
																	{
																		NewTskObjOP=TaskClTag[0];
																	}else
																	{
																		if(TaskClSet == 0)
																		{
																			if(ITEM_create_item(sTaskName,sTaskName,"T5_ChangeTask",sTaskName,&item,&NewTskObjOP)!=ITK_ok)PrintErrorStack();
																			printf("\n CL Task created first time------------>\n");fflush(stdout);
																			if(AOM_save(item)!=ITK_ok)PrintErrorStack();
																			if(AOM_save(NewTskObjOP)!=ITK_ok)PrintErrorStack();
																			if(GRM_create_relation(ERCDMLObjtag, NewTskObjOP, reln_type_tag,  NULLTAG, &relation)!=ITK_ok)PrintErrorStack();
																			if(GRM_save_relation(relation)!=ITK_ok)PrintErrorStack();																		
																		}																		
																	}
												
																	if (ColRlzRevFlag>0)
																	{
																	if(ITEM_copy_rev(ColorRevTag,NULL,&NewColorRevTag)!=ITK_ok)PrintErrorStack();  //Revise
																	//printf("\n....25....");fflush(stdout);
																	if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&NewColPartRevSeq)!=ITK_ok)PrintErrorStack();
																	printf("\n\t CM=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(stdout);
																	//printf("\n....26....");fflush(stdout);
												
																	if (NewColorRevTag!=NULLTAG)
																	{
																		if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																		{
																			if(GRM_find_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																			if (ReltnExist==NULLTAG)
																			{
																				if(GRM_create_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																				if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																				if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
																				printf("\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
																			}
																		}
																		if (tRelationFind!=NULLTAG)
																		{
																			////ifail = GRM_find_relation(ColorRevTag,NonClrPartTag,tRelationFind,&tPrevRelationExist);
																			//if( GRM_find_relation(ColorRevTag,NonClrItemRevTag,tRelationFind,&tPrevRelationExist)!=ITK_ok)PrintErrorStack();
																			//printf("\n....2....");fflush(stdout);
																			//if (tPrevRelationExist!=NULLTAG)  //remove previous colour child Rel from latest Non-Colour
																			//{
																			//	printf("\n....3....");fflush(stdout);
																			//	if( GRM_delete_relation(tPrevRelationExist)!=ITK_ok)PrintErrorStack();
																			//	printf("\nA--Previous Colour-Non_Colour child part Relation is removed Successfully \n");fflush(stdout);
																			//}
												
																			if( GRM_find_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																			if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																			{
																				if( GRM_create_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																				printf("\nAssy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																				if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
																				if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
																			}
																		}
																	}
																	}
																	else
																	{
																		NewColorRevTag=ColorRevTag; //For ERC Review
																	}
																		if (NewColorRevTag!=NULLTAG)
																		{
																		//Create Assembly BVR
																		if(ITEM_ask_item_of_rev(NewColorRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
																		if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
																		printf("\n\t bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
												
																		 if (bv_clrcount!=NULLTAG)
																		 {
																			clrbv = clr_bvs[0];
																			MEM_free(clr_bvs);
																		 }
																		 else
																		 {
																			if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
																			if(AOM_save( clrbv )!=ITK_ok)PrintErrorStack();
																			if(AOM_save( ClritemTag )!=ITK_ok)PrintErrorStack();
																			if(AOM_unlock( ClritemTag )!=ITK_ok)PrintErrorStack();
																			printf("\n\t inside PS_create_bom_view..\n");fflush(stdout);
																		 }
												
																		if(clrbv !=NULLTAG)
																		{
																		//printf("\n Before clrbvrTag find...");fflush(stdout);
											
																		if(ITEM_rev_list_bom_view_revs( NewColorRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
																		printf("\n\t CM--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
																		if (bvr_count > 0)
																		{
																			clrbvrTag=clr_bvrs[0];
																			MEM_free(clr_bvrs);
											
																			if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																			if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();\
																			printf("\n\t CM-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
																			for (ic = 0; ic<n_occs_clr; ic++)
																			{
																				if(PS_delete_occurrence( clrbvrTag, occs_clr[ic] )!=ITK_ok)PrintErrorStack();
																			}
																			if(AOM_save( clrbvrTag )!=ITK_ok)PrintErrorStack();
																			if(AOM_unlock( clrbvrTag )!=ITK_ok)PrintErrorStack();
																			MEM_free(occs_clr);
																		}
																		else{
																			if(PS_create_bvr( clrbv, "", "", false, NewColorRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
																			if(clrbvrTag !=NULLTAG)
																			{								
																				if(AOM_save( clrbvrTag)!=ITK_ok)PrintErrorStack();
																				if(AOM_save( NewColorRevTag )!=ITK_ok)PrintErrorStack();
																				if(AOM_unlock( NewColorRevTag )!=ITK_ok)PrintErrorStack();
																				printf( "\n\t inside  PS_create_bvr..\n");fflush(stdout);
																			}
																		}

																		//--START--Adding Childs under New Colour Assy bvr-----------
																		if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																		printf("\n\t Part_no/RevSeq= %s/%s   NonClrChildCnt= %d",Part_no,RevSeqTmp,NonClrChildCnt); fflush(stdout);
																		for (nc2 = 0; nc2 < NonClrChildCnt; nc2++)
																		{
																			if(Childobject) Childobject=NULLTAG;
																			Childobject=NonClrChilds[nc2];

																			if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();
																			if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &NCChildQty)!=ITK_ok)PrintErrorStack();
																			NClrQty=atoi(NCChildQty);

																			printf("\n\n  nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(stdout);

																			if(tc_strcmp(NCChildColInd,"N")==0)
																			{
																				printf("\t ---child ColInd==> N \n"); fflush(stdout);
																				if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																				if(NClrQty==0)
																				{
																					if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				}
																				else
																				{
																					for (p2=0;p2<NClrQty ;p2++ )
																					{													
																						if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																						printf("\n    p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																					}
																				}
																			}
																			else if(tc_strcmp(NCChildColInd,"Y")==0)
																			{
																				char *ClrChildItem = NULL;
																				logical checkout2;
																				int CompCodeClrSrlMatchFlag = 0;

																				printf("\t ---child ColInd==> Y \n"); fflush(stdout);
																				//START--Child comp code Process------------------------------------------------
																				for(g1=0;g1<Cmpcount;g1++ )
																				{
																					if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;
																					CmpCodeObjTag=CmpCodeOfClrScheme[g1];
																					if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok)PrintErrorStack();
																					//printf("\n SchmCmpCode & NCChildCompCode is --> : %s = %s\n",SchmCmpCode,NCChildCompCode); fflush(stdout);
																					
																					if(tc_strcmp(SchmCmpCode,NCChildCompCode)==0)
																					{
																						printf("\n\n\t   Chile-SchmName--> %s/%s",SchmName,SchmRev); fflush(stdout);
																						printf("\n\t   SchmCmpCode & NCChildCompCode-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,NCChildCompCode); fflush(stdout);

																						if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok)PrintErrorStack();
																						printf("\n\t   t5ClSrl --> : %s",t5ClSrl); fflush(stdout);

																						if(tc_strstr(t5ClSrl,";")!=NULL) {
																							Suffix =  strtok(t5ClSrl,";");
																							ColourID  =  strtok(NULL,";");
																						}
																						else {
																							Suffix =  strtok(t5ClSrl,",");
																							ColourID  =  strtok(NULL,",");
																						}
																						//printf("\n\t   CM=Suffix --> : %s",Suffix); fflush(stdout);
																						//printf("\n\t   CM=ColourID --> : %s",ColourID); fflush(stdout);


																						if(tc_strcmp(PartType,"G")==0)
																						{
																							printf("\n  In GroupID if condition===\n"); fflush(stdout);
																							//ResponseStr = NewUniqGroupIDNum();
																							//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																							//
																							//ClrChildItem = NULL;
																							//ClrChildItem=(char *) MEM_alloc(25);														
																							//strcpy(ClrChildItem,"");
																							//strcat(ClrChildItem,ResponseStr);
																							//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
																							fflush(stdout);
																						}
																						else
																						{
																							ClrChildItem=(char *) MEM_alloc(25);
																							strcpy(ClrChildItem,"");
																							strcpy(ClrChildItem,NCChild);
																							strcat(ClrChildItem,Suffix);
																						}
																						printf("\n\t   Child_ColPartNo: %s ",ClrChildItem); fflush(stdout);

																						if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
																						{
																							CompCodeClrSrlMatchFlag = 1;
																							//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																							valuesClrPrt[0] = ClrChildItem;
																							if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrChild_tags, &ClrChildTags));
																							printf("\t ClrPart_QryCount------> %d ",n_ClrChild_tags);fflush(stdout);

																							if(ITEM_find_item(NCChild, &ClrItemMstrTag)!=ITK_ok)PrintErrorStack();
																							if(ITEM_ask_latest_rev(ClrItemMstrTag,&ClrItemRevTag)!=ITK_ok)PrintErrorStack();

																							if (n_ClrChild_tags==0)
																							{
																								if(ITEM_create_item(ClrChildItem,ClrChildItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColChilditemRev)!=ITK_ok)PrintErrorStack();
																						
																								if(ColChilditemRev != NULLTAG)
																								{
																									printf("\n\t T5_ClrPart is created---------->\n");fflush(stdout);
																						
																									char *t5PrtCatCd = NULL;
																									char *t5object_desc = NULL;
																									char *clrdesc = NULL;
																									char *t5PartStatus = NULL;
																									char *t5DesignGrp = NULL;
																									char *t5ProjectCode = NULL;
																									char *t5DocRemarks = NULL;
																									char *t5DrawingInd = NULL;
																									char *t5PartCode = NULL;
																									char *t5AhdMakeBuyIndicator = NULL;
																									char *t5PunPCBUMakeBuyIndicator = NULL;
																									char *t5PunMakeBuyIndicator = NULL;
																									char *t5DwdMakeBuyIndicator = NULL;
																									char *t5Coated = NULL;
																									char *UnitOfMeasureS = NULL;
																						
																									if( AOM_ask_value_string(NonClrPartTag, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																									if( AOM_ask_value_string(NonClrPartTag, "t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																						
																									printf("\n\t   ClrChildItem ---->%s",ClrChildItem);fflush(stdout);
																									printf("\n\t   Col_Ind ---->%s",Col_Ind);fflush(stdout);
																									printf("\n\t   t5PrtCatCd---->%s",t5PrtCatCd);fflush(stdout);
																									printf("\n\t   ColourID---->%s",ColourID);fflush(stdout);
																									printf("\n\t   t5Coated---->%s",t5Coated);fflush(stdout);
																									printf("\n\t   t5PartStatus---->%s",t5PartStatus);fflush(stdout);
																									printf("\n\t   t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
																									printf("\n\t   t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
																									printf("\n\t   mod_desc---->%s",t5DocRemarks);fflush(stdout);
																									printf("\n\t   t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
																									printf("\n\t   PartType---->%s",PartType);fflush(stdout);
																									printf("\n\t   t5PartCode---->%s",t5PartCode);fflush(stdout);
																									printf("\n\t   t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
																									printf("\n\t   t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
																									printf("\n\t   t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
																									printf("\n\t   t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);
																						
																									clrdesc=(char *) MEM_alloc(200);
																									strcpy(clrdesc,"");
																									strcpy(clrdesc,ColourID);
																									strcat(clrdesc,"-");
																									strcat(clrdesc,t5object_desc);
																						
																									printf("\n\t   Part Desc ---->%s \n",clrdesc);fflush(stdout);
																						
																									//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
																									//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);
																						
																									if(tm_setAttributesOnDesignRev2(&ColChilditemRev,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,Part_no)!=ITK_ok)PrintErrorStack();
																									printf("\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
																						
																									if(tm_CreateReleasestatus(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																									printf("\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
																						
																									if(tm_AssignProject(ColChilditemRev,t5ProjectCode)!=ITK_ok)PrintErrorStack();
																									printf("\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
																						
																									//Going to update UserOwner Name
																									//if(AOM_set_ownership(ColChilditemRev,user_tag ,group)!=ITK_ok)PrintErrorStack();
																									//printf("\n\t   property Value set...!!\n");fflush(stdout);
																						
																									if (ColChilditemRev!=NULLTAG)
																									{
																										if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																										{
																											if(GRM_find_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																											if (ReltnExist==NULLTAG)
																											{
																												if(GRM_create_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																												if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																												if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
																												printf("\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(stdout);
																											}
																										}
																						
																										if (tRelationFind!=NULLTAG)
																										{
																											if(GRM_find_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																											if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																											{
																												if(GRM_create_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																												printf("\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																												if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
																												if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
																											}
																										}
																									}

																									if(NClrQty==0)
																									{
																										if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									}
																									else
																									{
																										for (p2=0;p2<NClrQty ;p2++ )
																										{													
																											if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																											printf("\n\t p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																										}
																									}

																									//START--check non-colour child have BVR then add colour bom

																									////tm_ProcessColourPart(Child_item_revTag, Cmpcount, CmpCodeOfClrScheme, Dml_task, 0, NewColourPart);
																									////tm_ProcessColourPart(Dml_task, 2, NonClrItemRevTag, 0, NULLTAG, ClrChildItem);
																								}
																							}
																							else
																							{
																								printf("\nCM=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(stdout);
																								if(NClrQty==0)
																								{
																									if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																								}
																								else
																								{
																									for (p2=0;p2<NClrQty ;p2++ )
																									{													
																										if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																										printf("\n\t p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																									}
																								}
																							}
																						}
																						else
																						{
																							printf("\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
																						}
																						break; //for if match condn then break loop
																					}
																				}
																				if (CompCodeClrSrlMatchFlag==0)
																				{
																					printf("\n\n\t ---child ColInd==> Y, but not comp_code or colour serial match found in scheme, hence skipping ??? \n"); fflush(stdout);
																					if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																					if(NClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					}
																					else
																					{
																						for (p2=0;p2<NClrQty ;p2++ )
																						{													
																							if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n\n\t   p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																						}
																					}
																				}
																				//END--Child comp code Process------------------------------------------------
																			}
																			else if(tc_strcmp(ChildColInd,"")==0)
																			{
																				printf("\t ---child ColInd==> NULL \n"); fflush(stdout);
																				if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();
																				if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			}
																		} // end of for loop NonClrChildCnt
																		//--END--Adding Childs under New Colour Assy bvr-----------
																		}
																		printf("\n After clrbvrTag creation...");fflush(stdout);
																		if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
																		if(AOM_unlock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																	}
																	} //End of condn checkout
																	} // Else of (ReviseStatus==0)&&(strlen(NonClrChildSet)==0)
																}
																else
																{
																	printf("\t ---A--No need to revive Colour: %s/%s [%s]",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
																}
															}
//															} //End of if condn (NCAssyChildFlag==1)
//															else if (NCAssyChildFlag==0)
//															{
//																if (n_ClrPrt_tags==0)
//																{
//																	if(ITEM_create_item(ColItem,ColItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColChilditemRev)!=ITK_ok)PrintErrorStack();
//																
//																	if(ColChilditemRev != NULLTAG)
//																	{
//																		printf("\n T5_ClrPart is created---------->\n");fflush(stdout);
//																
//																		char *t5PrtCatCd = NULL;
//																		char *t5object_desc = NULL;
//																		char *clrdesc = NULL;
//																		char *t5PartStatus = NULL;
//																		char *t5DesignGrp = NULL;
//																		char *t5ProjectCode = NULL;
//																		char *t5DocRemarks = NULL;
//																		char *t5DrawingInd = NULL;
//																		char *t5PartCode = NULL;
//																		char *t5AhdMakeBuyIndicator = NULL;
//																		char *t5PunPCBUMakeBuyIndicator = NULL;
//																		char *t5PunMakeBuyIndicator = NULL;
//																		char *t5DwdMakeBuyIndicator = NULL;
//																		char *t5Coated = NULL;
//																		char *UnitOfMeasureS = NULL;
//																
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
//																		if( AOM_ask_value_string(NonClrPartTag, "t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
//																
//																		printf("\n ColItem ---->%s",ColItem);fflush(stdout);
//																		printf("\n Col_Ind ---->%s",Col_Ind);fflush(stdout);
//																		printf("\n t5PrtCatCd---->%s",t5PrtCatCd);fflush(stdout);
//																		printf("\n ColourID---->%s",ColourID);fflush(stdout);
//																		printf("\n t5Coated---->%s",t5Coated);fflush(stdout);
//																		printf("\n t5PartStatus---->%s",t5PartStatus);fflush(stdout);
//																		printf("\n t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
//																		printf("\n t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
//																		printf("\n mod_desc---->%s",t5DocRemarks);fflush(stdout);
//																		printf("\n t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
//																		printf("\n PartType---->%s",PartType);fflush(stdout);
//																		printf("\n t5PartCode---->%s",t5PartCode);fflush(stdout);
//																		printf("\n t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
//																		printf("\n t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
//																		printf("\n t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
//																		printf("\n t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);
//																
//																		clrdesc=(char *) MEM_alloc(200);
//																		strcpy(clrdesc,"");
//																		strcpy(clrdesc,ColourID);
//																		strcat(clrdesc,"-");
//																		strcat(clrdesc,t5object_desc);
//																
//																		printf("\n Part Desc ---->%s \n",clrdesc);fflush(stdout);
//																
//																		//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
//																		//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);
//																
//																		if(tm_setAttributesOnDesignRev2(&ColChilditemRev,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,Part_no)!=ITK_ok)PrintErrorStack();
//																		printf("\n Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
//																
//																		if(tm_CreateReleasestatus(ColChilditemRev)!=ITK_ok)PrintErrorStack();
//																		printf("\n CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
//																
//																		if(tm_AssignProject(ColChilditemRev,t5ProjectCode)!=ITK_ok)PrintErrorStack();
//																		printf("\n Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
//																
//																		//Going to update UserOwner Name
//																		//if(AOM_set_ownership(ColChilditemRev,user_tag ,group)!=ITK_ok)PrintErrorStack();
//																		printf("\nproperty Value set...!!\n");fflush(stdout);
//																
//																		if (ColChilditemRev!=NULLTAG)
//																		{
//																			if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
//																			{
//																				if(GRM_find_relation(Dml_task,ColChilditemRev,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
//																				if (ReltnExist==NULLTAG)
//																				{
//																					if(GRM_create_relation(Dml_task,ColChilditemRev,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
//																					if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
//																					if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
//																					printf("\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
//																				}
//																			}
//																
//																			//if(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind)!=ITK_ok)PrintErrorStack();
//																			//printf("\n ..r1..");fflush(stdout);
//																			if (tRelationFind!=NULLTAG)
//																			{
//																				printf("\n ..r2..");fflush(stdout);
//																				//if(GRM_find_relation(ColChilditemRev,NonClrPartTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
//																				if(GRM_find_relation(ColChilditemRev,NonClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
//																				if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
//																				{
//																					printf("\n ..r3..");fflush(stdout);
//																					//if(GRM_create_relation(ColChilditemRev,NonClrPartTag,tRelationFind,NULLTAG,&Rel_task);
//																					if(GRM_create_relation(ColChilditemRev,NonClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
//																					printf("\nChild-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
//																					if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
//																					if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
//																					printf("\n ..r4..");fflush(stdout);
//																				}
//																				//printf("\n ..r5..");fflush(stdout);
//																			}
//																			printf("\n ..r6..");fflush(stdout);
//																		}
//																	}
//																}
//																else
//																{
//																	printf("\nCM=ColItem: %s Already present in PLM-TCUA, hence no need to create....\n",ColItem);fflush(stdout);
//																}
//															} //End of else condn (NCAssyChildFlag==0)

															break;
														} // End of condn if(tc_strcmp(SchmCmpCode,Comp_Code)==0)
													} //End of Cmpcount for loop
												}
											}
											else
											{
												printf("\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
											}
										}
										else
										{
											printf("\n\t\t Tag of ColSchmRevTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
										}

										if (MatchColSchemeFlag==1)
										{
											break;
										}
									} //End of scheme loop

									if (MatchColSchemeFlag==0)
									{
										printf("\n\t  No matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(stdout);

										if (strlen(NoColSchemeMatchPrts)==0)
										{
											strcpy(NoColSchemeMatchPrts,ColPartNo);
											strcat(NoColSchemeMatchPrts,",");
										}
										else
										{
											strcat(NoColSchemeMatchPrts,ColPartNo);
											strcat(NoColSchemeMatchPrts,",");
										}
									}
								} //if end of resultColSchm
								else
								{
									printf ("\n resultColSchm not present  ??? \n"); fflush(stdout);
									//printf ("\n resultColSchm not present  [%s]\n", Clrscheme); fflush(stdout);
									//exit (0);
									//return ifail;
								}
								// ----------------Colour Scheme-END---------------------------------------------
							} //End of loop for(zp = 0; zp<ClrCount; zp++)
						} //End of condn if(ClrCount>0)
					} //End of condn if(tRelationFind!=NULLTAG)
					// ----------------END--Get Colour Parts---------------------------------------------
//					} //End of condn if (strlen(NonClrChildSet)>2)
//					else
//					{
//						printf("---No NC-Rev bom difference present...\n"); fflush(stdout);
//					}
					break;
				} //if end of LatestRlzSt
			} //for loop end of RlzStatusCnt

			if (RlzRevFlag==0)
			{
				printf("\t----Attached Non-colour is not in ERC Released Status, hence skipping its colour colour part ??? \n");fflush(stdout);
			}
			/*else
			{
				tc_strcpy(NewColourPart,"");
			}*/
		} //if end of RlzStatusCnt
		else
		{
			tc_strcpy(NewColourPart,"");
		}
	} //if end of Col_Ind=Y && (strlen(Comp_Code)>0)
	else
	{
		printf("\t ----Skipping Non-colour part of col ind=N ????\n"); fflush(stdout);
	//	if ((tc_strcmp(Col_Ind,"Y")==0) && (strlen(Comp_Code)<=0))
	//	{
	//		printf("\t Comp_Code is not available, Plz check ????\n"); fflush(stdout);
	//	}
	//	/*else
	//	{
	//		tc_strcpy(NewColourPart,"");
	//	}*/
	}

	printf("\n");fflush(stdout);

	return ITK_ok;
}

int setAttributesOnDesign(tag_t* item,char* desc,char* UnitOfMeasureS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	if(AOM_set_value_string(*item,"object_desc",desc)!=ITK_ok)PrintErrorStack();
	if(AOM_save(*item)!=ITK_ok)PrintErrorStack();

/*	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {
		strcpy(ent_uom,FOUR);
	}

	if((strcmp(ent_uom,"FOUR")!=0) && (strcmp(ent_uom,"4-Nos")!=0))
	{
		if(UOM_find_by_symbol(ent_uom,&unit_of_measure)!=ITK_ok)PrintErrorStack();
		printf("\n ent_uom:%s  \n",ent_uom);fflush(stdout);
		if(ITEM_set_unit_of_measure(*item, unit_of_measure)!=ITK_ok)PrintErrorStack();
	}
	if(AOM_save(*item)!=ITK_ok)PrintErrorStack();*/
}

int tm_setAttributesOnDesignRev2(tag_t* rev,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart)
{
	int status;
	double dweight=0;
	tag_t  projobj=NULLTAG;
	if(AOM_lock(*rev)!=ITK_ok)PrintErrorStack();	
	if(AOM_set_value_string(*rev,"object_desc",desc)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_Coated",t5CoatedS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_NcPartNo",NonColorPart)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_DesignGrp",designgroup)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ProjectCode",projectcode)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc)!=ITK_ok)PrintErrorStack();

	if(AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS)!=ITK_ok)PrintErrorStack();
	if (strstr(PartTypeS,"D")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","D")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"A")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","A")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"C")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","C")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"VC")!=NULL){ if( AOM_set_value_string(*rev,"t5_PartType","VC")!=ITK_ok)PrintErrorStack();}
	if (strstr(PartTypeS,"V")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","V")!=ITK_ok)PrintErrorStack(); }

	if(AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS)!=ITK_ok)PrintErrorStack();
	if(tc_strcmp(t5AhdMakeBuyIndS,"-")==0)	{
		if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",t5AhdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(tc_strcmp(t5PunPCBUMakeBuyIndS,"-")==0) { 
		if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(tc_strcmp(t5PunMakeBuyIndS,"-")==0) { 
		if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}
	
	if(tc_strcmp(t5DwdMakeBuyIndS,"-")==0) {
		if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",t5DwdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}	
		
	if(AOM_save(*rev)!=ITK_ok)PrintErrorStack();
	if(AOM_unlock(*rev)!=ITK_ok)PrintErrorStack();
}
int tm_CreateReleasestatus(tag_t ColourRev)
{
	tag_t   release_status =NULLTAG;
	char   *ReleaseStatus=NULL;
	char* ReviewStatus=NULL;
	int status;
	int		ifail	=0;
	int	   status_count=0;
	tag_t* status_list = NULLTAG;
	logical  retain_released_date =false;

	ReviewStatus =(char *) MEM_alloc(20 * sizeof(char *));
	tc_strcpy(ReviewStatus,"T5_LcsReview");
	printf("\n\t ReviewStatus --> %s",ReviewStatus);fflush(stdout);

	if((strcmp(ReviewStatus,"T5_LcsReview")==0))
	{
		if(ITK_ok != (ifail = WSOM_ask_release_status_list(ColourRev,&status_count,&status_list)))
		{
		   return ifail;
		}
		printf("\n\t REV status_count: %d",status_count);fflush(stdout);
		if (status_count == 0)
		{
			printf("---No Status, so the Item is not yet Released....");fflush(stdout);
			printf(" *****  Stamping Releasing item  *****");fflush(stdout);
			if(ITK_ok != (ifail = CR_create_release_status(ReviewStatus,&release_status)))	 return ifail;
			if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
			printf("\t ReleaseStatus: %s \n",ReleaseStatus);fflush(stdout);
			if( EPM_add_release_status(release_status,1,&ColourRev,retain_released_date)!=ITK_ok)PrintErrorStack();
		}
	}
	return status;
}
int tm_AssignProject(tag_t  itemRev,char* projectcode)
{
	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

	printf("\n projectcode [%s]\n",projectcode);fflush(stdout);
	if(PROJ_find(projectcode,&projobj)!=ITK_ok)PrintErrorStack();
	printf("\n Assigned to Project111\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		if(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev)!=ITK_ok)PrintErrorStack();
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
  return status;
}

int tm_OccurSetTopLineClr(tag_t  clrbvrTag, char* UsesPartNo)
{
	int stat = ITK_ok;
	int status;
	int ifail = ITK_ok;
    tag_t UseMaster = NULLTAG;
	tag_t Nrev = NULLTAG;
	char *ChildPartNo = NULL;
	char *ChildPartRevSeq = NULL;
	tag_t objNameType=NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	tag_t *occs=NULL;

	printf("\n Uses Part Number is ------> %s",UsesPartNo);fflush(stdout);
    if(ITEM_find_item(UsesPartNo,&UseMaster)!=ITK_ok)PrintErrorStack();
	printf("\n UseMaster found------>");fflush(stdout);
	
	if(ITEM_ask_latest_rev(UseMaster, &Nrev)!=ITK_ok)PrintErrorStack();
	printf("\n Childrev found------>");fflush(stdout);
	
	if(AOM_ask_value_string(Nrev,"item_id",&ChildPartNo)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(Nrev,"item_revision_id",&ChildPartRevSeq)!=ITK_ok)PrintErrorStack();
	printf("\n ChildPartNo: %s--%s ..............",ChildPartNo,ChildPartRevSeq);fflush(stdout);

	if(TCTYPE_ask_object_type(Nrev,&objNameType)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name(objNameType,type_name)!=ITK_ok)PrintErrorStack();
	printf("\t type_name:: [%s] \n",type_name);

	if(PS_create_occurrences(clrbvrTag, UseMaster, NULLTAG,1, &occs )!=ITK_ok)PrintErrorStack();
	printf("\n PS_create_occurrences successfully in PSE------->");fflush(stdout);

	if(AOM_save( clrbvrTag) !=ITK_ok)PrintErrorStack();
	printf("\n AOM_save successfully of clrbvrTag------->");fflush(stdout);

	if(AOM_refresh(clrbvrTag,0)!=ITK_ok)PrintErrorStack();
	printf("\n AOM_refresh successfully of clrbvrTag------->\n"); fflush(stdout);

	return ITK_ok;
}

int cl_task_status( EPM_action_message_t msg )
{		
	int			ifail		= 0;
	int         stat        = ITK_ok;
	char*		username	= NULL;
	tag_t		user_tag	= NULLTAG;
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	tag_t  rootTask			= NULLTAG;
	int    noAttachment=0;
	tag_t  *attachments		= NULLTAG;
	tag_t  DMLTag = NULLTAG;
	char   *Item_id = NULL;

	//12PP555556 - DML for CL Creation on uadev
	CALLAPI(POM_get_user(&username,&user_tag));
	printf("\n Starting for taskbreskdownnn of CL Task----------->%s\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n EPM_ask_root_task----------> \n"); fflush(stdout);

	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	printf("\n Target Attachment--------------->%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0) {
		DMLTag = attachments[0];			    	
	}
	
	CALLAPI(QRY_find("Control Objects...", &Cntl_obj_Qtag11));
	qry_values11[0] = "ClrRlz" ;
	qry_values11[1] = "5442" ;
	CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	printf("\n Control Object count for CL Task---------->%d\n",resultCount11);fflush(stdout);

	if(resultCount11 > 0)
	{		
		if ( DMLTag != NULLTAG )
		{
			CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&Item_id));
			printf("\n DML Item_id is : %s\n",Item_id);fflush(stdout);
			if(tm_DMLPostColRlzProcess(Item_id)!=ITK_ok)PrintErrorStack();
		}else
		printf("\n DMLTag found NULL--------------->\n"); fflush(stdout);
	}else
	printf("\n Control object not available Hence DML not go for CL task creation--------------->\n"); fflush(stdout);
	return ITK_ok;
}

extern int ApplySVRonX4_register_method(int *decision, va_list args)
{
	int ifail=0;
    *decision = ALL_CUSTOMIZATIONS;
	tag_t objTag = va_arg(args, tag_t);

   if( ITK_ok == EPM_register_action_handler("multiple_module", "", multiple_module_status))
   {
		printf("\t\n Registered Action Handler multiple_module\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler multiple_module\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("cl_task_creation", "", cl_task_status))
   {
		printf("\t\n Registered Action Handler cl_task_creation\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler cl_task_creation\n");fflush(stdout);
   }

	return ITK_ok;
}

extern DLLAPI int ApplySVRonX4_register_callbacks()
{     
	 CUSTOM_register_exit("ApplySVRonX4", "USER_init_module", (CUSTOM_EXIT_ftn_t) ApplySVRonX4_register_method);

     printf("\n vc_release_register_callbacks--------------->\n");fflush(stdout);

	 return ( ITK_ok );
}
