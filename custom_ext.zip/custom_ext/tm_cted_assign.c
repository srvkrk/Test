/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_cted_assign.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating Modular MBOM Accuracy check report for VC.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   18-02-2025
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18-02-2025  	 Pravin Jagdale						    Base Code
* 			

* -----------------------------------------------------------------------------
* 
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#define ITK_err 919002
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <string.h>
#include <sys/stat.h>
#include <Fnd0Participant/participant.h>
#include <fclasses/tc_date.h>

//#include <epm/cr_effectivity.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define PLM_error (EMH_USER_error_base + 100)

static int report_error( char *file, int line, char *function, int return_code)
{
 
                if (return_code != ITK_ok)
                {
                                int                                                           index = 0;
                                int                                                           n_ifails = 0;
                                const int*                            severities = 0;
                                const int*                            ifails = 0;
                                const char**      texts = NULL;
 
                                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                                printf("%3d error(s)\n", n_ifails);
                                for( index=0; index<n_ifails; index++)
                                {
                                                printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                                                TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                                }
                                EMH_clear_errors();
				 }
                return return_code;
 
}

/*
 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
/*
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
 
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
*/

char*			Task_no				= NULL;

//int AssignCTEDPlanner(tag_t object_type,char*		Proj_Code)

void setAddTAG_1(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan TZ 1.76

{

	*count=*count+1;

	if(*count==1)

	{

		//printf("\n ****setAddTAG_11");fflush(stdout);

		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}

	else

	{

		//printf("\n ****setAddTAG_12");fflush(stdout);

		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));

	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}
 
int AssignCTEDIncharge(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	//char*			CTED_Designer_Grp	= NULL;
	char*			CTED_Incharge_Grp	= NULL;
	char*			CTED				= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignCTEDIncharge=0;
		

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n CTED Inside AssignCTEDIncharge \n");

	(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n CTED : AssignCTEDIncharge:CTED_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n CTED for AssignCTEDIncharge Temp_CTED_no :%s \n", Temp_Task_no);fflush(stdout);
	
	
	//---------------------------CTED Incharge GRP------------------------------------------------//

	CTED_Incharge_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(CTED_Incharge_Grp,PLT_CodeS);
	

	(SA_find_group("CTED",&group_tag));
	
	printf("\n Test0.14.. -CTED-- Incharge Group Name-1111:\n");fflush(stdout);

	if (group_tag != NULLTAG)
	(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n CTED Incharge: No of Role found in CTED Group are :%d\n",num_of_roles);fflush(stdout);


	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			
			if(strstr(rolename,"00") && (strstr(rolename,"CTED") && strstr(rolename,"Incharge")&& strstr(rolename,"Default")==NULL ))
			{
				
				printf("\n Match Found for CTED Incharge => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n CTED Incharge : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n CTEDIncharge : User ID Name :[%s]\n",userid);

						FlaggAssignCTEDIncharge = 1;

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							printf("\n ChangeSpecialist1 Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignCTEDIncharge==1)
				{
					printf("\n CTED Incharge : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	//
	printf("\n FlaggAssignCTEDIncharge for default : [%d]\n",FlaggAssignCTEDIncharge);fflush(stdout);

	
	return ITK_ok;

}

//int AssignCTEDPlanner(tag_t object_type,char*		Proj_Code)
int AssignCTEDPlanner(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			CTED_Designer_Grp	= NULL;
	char*			CTED				= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignCTEDPlanner=0;

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n CTED Inside AssignCTEDPlanner \n");

	(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n CTED : AssignCTEDPlanner:cted_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n CTED for AssignCTEDPlanner Temp_cted_no :%s \n", Temp_Task_no);fflush(stdout);
	
	
	//CTED DESIGN GRP---------
	CTED_Designer_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(CTED_Designer_Grp,PLT_CodeS);
	

	(SA_find_group("CTED",&group_tag));
	
	printf("\n Test0.14.. -CTED-- Designer Group Name-1111:\n");fflush(stdout);

	if (group_tag != NULLTAG)
	(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n CTED Planner: No of Participant found in CTED Designer Group are :%d\n",num_of_roles);fflush(stdout);


	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			
			if(strstr(rolename,"00") && (strstr(rolename,"CTED") && strstr(rolename,"Designer")&& strstr(rolename,"Default")==NULL ))
			{
				
				printf("\n Match Found for CTED Designer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n Designer : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n CTED Designer : User ID Name :[%s]\n",userid);

						FlaggAssignCTEDPlanner = 1;

							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							printf("\n Analyst Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Analyst Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Analyst Test ended 4444 \n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignCTEDPlanner==1)
				{
					printf("\n Designer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	//
	printf("\n FlaggAssignCTEDPlanner for default : [%d]\n",FlaggAssignCTEDPlanner);fflush(stdout);

	
	return ITK_ok;

}

//----------------- Code end - for assign CTED Incharge -------------------------------------//

//-----------------amm Code Started- for assign CTED Buyer /Reviewer Start-------------------------------------//

//int AssignCTEDPlanner(tag_t object_type,char*		Proj_Code)
int AssignCTEDBuyerCode(tag_t object_type)							
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			CTED_BuyerCode_Grp	= NULL;				//CTED Buyer CodeUpdate
	//char*			CTED_Incharge_Grp	= NULL;
	char*			CTED				= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignCTEDBuyerCode=0;
		

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n CTED Inside AssignCTEDBuyerCode \n");

	(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n CTED : AssignCTEDBuyerCode:CTED_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n CTED for AssignCTEDBuyerCode Temp_CTED_no :%s \n", Temp_Task_no);fflush(stdout);
	
	
	//---------------------------CTED Reviewer GRP------------------------------------------------//

	CTED_BuyerCode_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(CTED_BuyerCode_Grp,PLT_CodeS);
	

	(SA_find_group("CTED",&group_tag));
	
	printf("\n Test0.14.. -CTED-- Incharge Group Name-1111:\n");fflush(stdout);

	if (group_tag != NULLTAG)
	(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n CTED Reviewer: No of Role found in CTED Group are :%d\n",num_of_roles);fflush(stdout);


	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			
			if(strstr(rolename,"CTED") && strstr(rolename,"CodeUpdate")&& strstr(rolename,"Default")==NULL )
			{
				
				printf("\n Match Found for CTED Reviewer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n CTED Reviewer : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n CTEDReviewer : User ID Name :[%s]\n",userid);

						FlaggAssignCTEDBuyerCode = 1;

							TCTYPE_find_type("ChangeReviewBoard", "ChangeReviewBoard", &participant_type);
							printf("\n ChangeReviewBoard Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n ChangeReviewBoard Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n ChangeReviewBoard Test ended 4444 \n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignCTEDBuyerCode==1)
				{
					printf("\n CTED Reviewer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	//
	printf("\n FlaggAssignCTEDBuyerCode for default : [%d]\n",FlaggAssignCTEDBuyerCode);fflush(stdout);

	
	return ITK_ok;

}

//----------------- Code end - for assign CTED Incharge -------------------------------------//


//Start code  for assign Assign CTED Buyer Reviewer(tag_t object_type,char*		Proj_Code)
int AssignCTEDBuyerReviewer(tag_t object_type)							
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			CTED_Reviewer_Grp	= NULL;
	//char*			CTED_Incharge_Grp	= NULL;
	char*			CTED				= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignCTEDBuyerReviewer=0;
		

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n CTED Inside Assign CTED Buyer Reviewer \n");

	(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n CTED : Assign CTED Buyer Reviewer:CTED_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n CTED for Assign CTED Buyer Reviewer Temp_CTED_no :%s \n", Temp_Task_no);fflush(stdout);
	
	
	//---------------------------CTED Buyer Reviewer GRP------------------------------------------------//

	CTED_Reviewer_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(CTED_Reviewer_Grp,PLT_CodeS);
	

	(SA_find_group("CTED",&group_tag));
	
	printf("\n Test0.14.. -CTED-- Buyer Reviewer Group Name-1111:\n");fflush(stdout);

	if (group_tag != NULLTAG)
	(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n CTED  Buyer Reviewer: No of Role found in CTED Group are :%d\n",num_of_roles);fflush(stdout);


	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			
			if(strstr(rolename,"CTED") && strstr(rolename,"Reviewer")&& strstr(rolename,"Default")==NULL )
			{
				
				printf("\n Match Found for CTED Buyer Reviewer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n CTED Buyer Reviewer : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n CTED Buyer Reviewer : User ID Name :[%s]\n",userid);

						FlaggAssignCTEDBuyerReviewer = 1;

							TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);      //T5_DMUReviewer
							printf("\n T5_DMUReviewer Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n T5_DMUReviewer Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n T5_DMUReviewer Test ended 4444 \n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignCTEDBuyerReviewer==1)
				{
					printf("\n CTED Buyer Reviewer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	//
	printf("\n FlaggAssign CTED Buyer Reviewer for default : [%d]\n",FlaggAssignCTEDBuyerReviewer);fflush(stdout);

	
	return ITK_ok;

}


int cted_task_assigment(EPM_action_message_t msg)
{

    int error_code = ITK_ok;
    int ifail = 0;

    char *Proj_Code = NULL;
    char *item_type = NULL;
     char	*type_name				=	NULL;
    char *object_name1 = NULL;
    char *DML_no = NULL;
    char **DesignGroupList;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    char *ecntypeVal = NULL;

    int TaskCnt = 0;
    int count = 0;
    int noAttachment, noTaskAttachment = 0;
    tag_t APLTaskRevT = NULLTAG;
    tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
    tag_t relation_type = NULLTAG;
    tag_t *TaskRevision = NULLTAG;

    // date_t Release_date;

    printf("\n Inside Registered Action Handler cted_task_assigment\n ");
    fflush(stdout);

    if (EPM_ask_root_task(msg.task, &rootTask))
        ;
    printf("\n cted_task_assigment \n");
    fflush(stdout);

    if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask))
        ;
    printf("\nCurrentTask of cted:%s\n", CurrentTask);
    if (AOM_ask_value_string(rootTask, "object_name", &parent_name))
        ;
    printf("\nParent Name cted:%s\n", parent_name);
    fflush(stdout);
    if (EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments))
        ;
    printf("Target Attachment cted:%d\n", noAttachment);
    fflush(stdout);
    if (noAttachment > 0)
    {
        dml_rev_tag = attachments[0];
        if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
            ;
        if (TCTYPE_ask_name2(objTypeTag, &type_name))
            ;
        printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);
        fflush(stdout);
    }

    if (strcmp(type_name, "T5_CTEDRevision") == 0)
	{
       printf("\n inside class T5_CTEDInd......\n");
        fflush(stdout);
       AOM_ask_value_string(dml_rev_tag, "object_name", &object_name1);
		printf("\n inside class object_name...... ;%s\n", object_name1);
		fflush(stdout);
        AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no);fflush(stdout);
		printf("\n inside class current_id......  ;%s\n", DML_no );
		fflush(stdout);

         //if ((ecntypeVal!=NULL) && (tc_strcmp(ecntypeVal, "ME") == 0)) 
         //{
			 printf("\n inside class T5_CTED......\n");
			 fflush(stdout);
			 AOM_ask_value_string(dml_rev_tag, "object_name", &object_name1);
			 printf("\n inside class object_name...... ;%s\n", object_name1);

            printf("\n PLJ User created CTED task: %s assigning to Planner / CTED Incharge / Updation Of Buyer Code /  Review Buyer Code \n",object_name1);fflush(stdout);
			//DLLAPI(AssignCTEDPlanner(dml_rev_tag, Proj_Code));
			DLLAPI(AssignCTEDPlanner(dml_rev_tag));
			printf("\n assigning CTED Planner \n");fflush(stdout);
			ITK_CALL(AssignCTEDIncharge(dml_rev_tag));
			printf("\n assigning CTED Incharge \n");fflush(stdout);
			ITK_CALL(AssignCTEDBuyerCode(dml_rev_tag));
			printf("\n assigning CTED Buyer Code--- \n");fflush(stdout);
			ITK_CALL(AssignCTEDBuyerReviewer(dml_rev_tag));
			printf("\n assigning CTED Buyer Reviewer-- \n");fflush(stdout);
          //}
           
                //}
            //}
        //}
		}
    else
    {
        printf("\n No proper class T5_CTED......\n");
        fflush(stdout);
    }

    return error_code;
}


//-----------------Code added by amm- for assign CTED planner start -------------------------------------//




//-----------------amm Code end - for assign CTED planner end -------------------------------------//



//-----------------amm Code Started- for assign CTED Incharge Start-------------------------------------//


//----------------- Code end - for assign Assign CTED Buyer Reviewer -------------------------------------//

//---------------------------------------------------PE_Part_signoff_val_CTED Start --------------------------------------------//

//int PE_Part_signoff_val_CTED(EPM_rule_message_t msg)	    //PE_Part_signoff_val_CTED						
//{
extern EPM_decision_t DLLAPI PE_Part_signoff_val_CTED(EPM_rule_message_t msg) 
{
	EPM_decision_t decision;
	int status;
	
	//	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	//char*			CTED_Reviewer_Grp	= NULL;
	//char*			CTED_Incharge_Grp	= NULL;
	char*			CTED				= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	//char*			PLT_CodeS			= NULL;
	//char*			Object_Name			= NULL;

	//tag_t			group_tag			= NULLTAG;
	//tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	//tag_t			participant_type	= NULLTAG;
	//tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;

	char	*object_type					= NULL;
	tag_t			rootTask				=NULLTAG;
	char*			parent_name				=NULL;
	char*			CurrentTask				=NULL;
	tag_t			dml_rev_tag				= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	char			*type_name				=NULL;
	char			*DML_no					= NULL;
	char			*CTPEPrtReq				= NULL;
	char            *newid                  =NULL;


	tag_t			rel_PE			= NULLTAG;
	char *CTEDPEPartTR_attr=NULL;			//CTEDPEPartTR_attr=NULL;
	char *CTEDPEPartDescTR_attr=NULL;
	tag_t qryTagCntrlobj = NULLTAG;
	char* IndUnit_no = NULL;
	

	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignCTEDBuyerReviewer=0;
	int valid_rows =0;
	tag_t * ValidRowsTag =NULL;
	int iValCnt=0;

	int part_cnt       = 0;
	tag_t *Part_objects		  = NULLTAG;
	tag_t *list_of_cntrl_tags = NULLTAG;
		

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	int iNumAttch = 0;
	tag_t *TargetAttch = NULLTAG;
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n CTED Inside --PE_Part signoff validation CTED task no ----- \n");

  //-----------cted code modification for PE_Part signoff validation CTED task ------------------------------------

	 ITKCALL(EPM_ask_root_task(msg.task, &rootTask));
    printf("\n -----------Inside PE_Part_signoff_val_CTED amm 111---------  \n");
    fflush(stdout);

    ITKCALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
    printf("\n CTED PE_Part signoff valli --- CurrentTask is :%s\n", CurrentTask);
    fflush(stdout);
    ITKCALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
    printf("\n CTED PE_Part signoff valli --- Parent Name is :%s\n", parent_name);
    fflush(stdout);

	  ITKCALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch));
        printf("\n CTED No of Target Attachements is :%d\n", iNumAttch);
        fflush(stdout);

    if (iNumAttch > 0)
       {
			dml_rev_tag = TargetAttch[0];

		ITKCALL(TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag));
		ITKCALL(TCTYPE_ask_name2(objTypeTag, &type_name));
	
		printf("\n CTED workspaceobject type_name is :  %s\n", type_name);
		fflush(stdout);
	
	 
	    ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &Task_no));
	    ITKCALL(AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no));
	    printf("\n CTED current task item id is : %s", Task_no);
	
	
		(AOM_ask_value_string(dml_rev_tag,"item_id",&Task_no));
		(AOM_ask_value_string(dml_rev_tag,"t5_CTPEPrtReq",&CTPEPrtReq));

		//(AOM_ask_value_string(dml_rev_tag,"t5_CtdWRNumber",&WrkRcd_no));							//wrkrecd no.      T5_CTHasWrk
		//printf("\n CTED : CTED PE_Part signoff validation: CTED_no  is :%s  \n",WrkRcd_no);	fflush(stdout);
		
		
		printf("\n CTED : CTED PE_Part signoff validation: CTED_no  is :%s  :%s\n",Task_no,CTPEPrtReq);	fflush(stdout);
		tc_strcpy(Temp_Task_no, Task_no);
	    printf("\n CTED PE_Part signoff validation :%s \n", Temp_Task_no);fflush(stdout);

		///////Attach PE Part to releation 

////////Pravin PE Part

				{
						ITK_CALL(AOM_UIF_ask_value(dml_rev_tag,"item_id",&newid));						//t5_CTImpNrml
						printf("\n PE newid1122--- :%s\n",newid);fflush(stdout);

						ITK_CALL(AOM_ask_table_rows(dml_rev_tag,"t5_CTEDPEtableRev", &valid_rows,&ValidRowsTag));				
						printf("\n\t Pravin PE Part count against PE part from table valid_rows is333--  :%d\n",valid_rows);fflush(stdout);

						for(iValCnt=0;iValCnt<valid_rows;iValCnt++)
						{
							
						
							CTEDPEPartTR_attr=NULL;
							CTEDPEPartDescTR_attr=NULL;

							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartTR", &CTEDPEPartTR_attr));					
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartDescTR", &CTEDPEPartDescTR_attr));							
							
							
							printf("\n\t  PLJ PE Part ----> :[%s] \n",CTEDPEPartTR_attr);fflush(stdout);
							printf("\n\t  PLJ PE Part Desc ---> :[%s] \n",CTEDPEPartDescTR_attr);fflush(stdout);
						
					
						
							if(tc_strcmp(CTEDPEPartTR_attr,"NULL")==0 ||tc_strlen(CTEDPEPartTR_attr) == 0) //||(tc_strcmp(CTEDByerRmrkByrTR_attr,"NULL")==0))				//t5_RmrkByrTR
							{
								printf("\n\t PLJ PE Part no not attached  ---->  :%s \n",CTEDPEPartTR_attr);fflush(stdout);

								
							}
							else

							{
								printf("\n\t PLJ PE Part no is attached  ---->  :%s \n",CTEDPEPartTR_attr);fflush(stdout);

								
							}

		//-----------------Code For releation Creation PE Part -----------------------------------------//
		
//		(AOM_ask_value_string(IndUtobjTag,"object_name",&IndUnit_no));							//wrkrecd no.      T5_CTHasWrk
//		 printf("\n CTED : Code For releation Creation work order with CTED :%s  \n",IndUnit_no);	
//		 fflush(stdout);
        
		if (CTEDPEPartTR_attr != NULL) // plj
			//printf("\n Indivisual Object IndUtobjTag---22-- : %d \n",IndUtobjTag);
		{
		char *qry_entryCntrlformat[1] = {"ID"};
		//char *qry_entryCntrlformat[0] = {"ID"};
        char **qry_valuesCntrlformat = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound = 0;
        int n_entryCntrlobj = 1;

        if (QRY_find2("Cted_PEpart_Query", &qryTagCntrlobj));

        if (qryTagCntrlobj)
        {
            printf("\n PE Part Query Found---111 \n");
            fflush(stdout);
            qry_valuesCntrlformat[0] = CTEDPEPartTR_attr;  //IndUnit_no;

            if (QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags))
                ;
        }
			printf("\n PE Part Found; %d\n",controlObjfound);
		if (controlObjfound > 0)
		{
			tag_t IndUt_obj = list_of_cntrl_tags[0];

			GRM_find_relation_type("T5_CTEDHasPEPart", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(dml_rev_tag, IndUt_obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);


		}
		else
		 {
			 printf("\t  PE Part Query Not Found \n");
			fflush(stdout);
		}

		}

//// 
		//----------------- Code For releation Creation  PE Part with CTED -----------------------------------------//


							

						}
		
					}
	
	
		//-----------------------////CTED relation---------------------
	
		printf ("\nInside the function PE_Part signoff validation_CTED--amm--\n");
		
		
		if((strcmp(CTPEPrtReq,"PE Part Required")==0) || (strcmp(CTPEPrtReq,"WithPEPart")==0) )
		{

		//		ITKCALL(GRM_find_relation_type("T5_CTEDPEHasPEPart", &rel_PE));						//t5_CTPEPrtReq		=		PE Part Required
		ITKCALL(GRM_find_relation_type("T5_CTEDHasPEPart", &rel_PE));
		printf ("\n Expanding CTED Rev. to Parts relation--\n");
	
		ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, rel_PE, &part_cnt, &Part_objects));
		printf("\n PE Part-- Attached--- CTED part_cnt is : [%d]\n",part_cnt);fflush(stdout);

	//	if ( part_cnt > 0 )
	//		{
	//
	//			printf("\n Attached CTED part_cnt : [%d]\n",part_cnt);fflush(stdout);
	//		
	//		}

	if ( part_cnt > 0 )
		{	
		
			printf("\n PE Part Attached to CTED part_cnt aaaa : [%d]",part_cnt);fflush(stdout);

		}
		else
			{
			printf ("\n-------------- PE part / Trial Report not attached VALIDATION = Completed--------------------\n");fflush(stdout);
			//return 0;

			EMH_clear_errors();
			//EMH_store_error_s2(EMH_severity_error,ITK_err,"\n JT/PDF not attached under MBOM stage assembly ,Please attach and proceed for approval.\n",part_cnt);
			EMH_store_error_s2(EMH_severity_error,ITK_err,"\n PE part / Trial Report not attached ,Please attach and proceed.\n", "error");
			//MEM_free(part_cnt);
			return ITK_err;					//PE part / Trial Report not attached
			}
			}





			}
			//return 0;
			decision = EPM_go;
			return decision;
}

//---------------------------------------------------PE_Part_signoff_val_CTED End --------------------------------------------//

//---------------------------------------------------CTED_checkin_PreCond_Validation Start -  --------------------------------------------//

int CTED_checkin_PreCond_Validation(METHOD_message_t* msg, va_list args)					//SOR_checkin_PreCond_Validation
{

	tag_t Primary_Obj = va_arg(args, tag_t);
	tag_t Primary_Obj_Type = NULLTAG;
	tag_t* table_rows = NULLTAG;


	int ntablerows = 0;
	int i = 0;
	int int_CompareDatasetfile = 0;
	int int_CompareNamedReffile = 0;


	char* Primary_Obj_name = NULL;
	char* qCtrlCommodity = NULL;
	char* sor_qBarrelCode = NULL;
	//char* sor_qSORnumber = NULL;
	char* CTED_item_id		= NULL;
	char* sor_qSORPartDesc = NULL;
	char* sor_qSorCat = NULL;
	char* sor_qSorPrtClrInd = NULL;
	char* sor_qSorPartNumber = NULL;
	char* sor_qSorPartRevision = NULL;
	char* sor_qSorPartSeq = NULL;
	char* sor_qPPPMPrjCode = NULL;
	char* st5_qQuantity = NULL;
	char *object_desc1 = NULL;

    char *newid=NULL;
	int PartCnt =0;
	tag_t * PartTags =NULL;
	int valid_rows =0;
	tag_t * ValidRowsTag =NULL;
	int iValCnt=0;
	char *CTPERelRmrkTR_attr=NULL;
	char *CTPERelBuyerCdTR_attr=NULL;
	char *CTEDByerRmrkByrTR_attr=NULL;
	char *CTEDPEPartTR_attr=NULL;			//CTEDPEPartTR_attr=NULL;
	char *CTEDPEPartDescTR_attr=NULL;

	tag_t *list_of_cntrl_tags = NULLTAG;

	tag_t *ValCntrlObjectTagT = NULLTAG;
    tag_t qryTagCntrl1 = NULLTAG;
	tag_t qryTagCntrlobj = NULLTAG; 
    //tag_t controlobj = NULLTAG;
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};




	// control object for CTED_checkin_PreCond_Validation // 

		QRY_find2("Control Objects...", &qryTagCntrl1);

        printf("\n Control Object Query Found CTED_checkin_PreCond_Validation\n");				//CTED_checkin_PreCond_Validation
        fflush(stdout);
        qry_valuesCntrl1[0] = "CTED_checkin_Validation";
        qry_valuesCntrl1[1] = "CTED_checkin_Validation";
        qry_valuesCntrl1[2] = "0";

        printf("\n Before Control Object Query Found CTED_checkin_PreCond_Validation\n");
        fflush(stdout);
        int control_number_found1 = 0;
        tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
        if (QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1))
            ;
        printf("\n Number of control object found for CTED_checkin_PreCond_Validation is  :%d", control_number_found1);
        fflush(stdout);

        if (control_number_found1 > 0)
        {



			ITK_CALL(TCTYPE_ask_object_type(Primary_Obj, &Primary_Obj_Type));
			ITK_CALL(TCTYPE_ask_name2(Primary_Obj_Type, &Primary_Obj_name));

			printf("\n CTED checkin_PreCond_Validation CTED Primary_Obj_name:  [%s]\n", Primary_Obj_name); fflush(stdout);
	
		//	int buyerremarkflag=0;    //buyercodePEflag
			int buyercodePEflag=0;
			int buyerremarkflag1 = 0;
			if (tc_strcmp(Primary_Obj_name, "T5_CTEDRevision") == 0)								//
			{

				ITKCALL(AOM_ask_value_tags(Primary_Obj,"t5_CTEDPEtableRev",&PartCnt,&PartTags));
				printf("\n CTED form object found in Reference Folder is---  : %d",PartCnt);fflush(stdout);

					if (PartCnt > 0)
					{
						ITK_CALL(AOM_UIF_ask_value(Primary_Obj,"item_id",&newid));						//t5_CTImpNrml
						printf("\n newid1122--- :%s\n",newid);fflush(stdout);

						ITK_CALL(AOM_ask_table_rows(Primary_Obj,"t5_CTEDPEtableRev", &valid_rows,&ValidRowsTag));				
						printf("\n\t Part count against PE part from table valid_rows is333--  :%d\n",valid_rows);fflush(stdout);

						for(iValCnt=0;iValCnt<valid_rows;iValCnt++)
						{
							//CTPERelRmrkTR_attr=NULL;
							CTPERelBuyerCdTR_attr=NULL;
							//CTEDByerRmrkByrTR_attr=NULL;
							CTEDPEPartTR_attr=NULL;
							CTEDPEPartDescTR_attr=NULL;

							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartTR", &CTEDPEPartTR_attr));					
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartDescTR", &CTEDPEPartDescTR_attr));			
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelOrQtyTR", &CTPERelOrQtyTR_attr));				
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelQtyPerSetTR", &tCTPERelQtyPerSetTR_attr));		
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelDrwNoStatTR", &CTPERelDrwNoStatTR_attr));		
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelRplcDrgTR", &CTPERelRplcDrgTR_attr));
							
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelRmrkTR", &CTPERelRmrkTR_attr));	//Remark	
							
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelToolTypeTR", &CTPERelToolTypeTR_attr));			
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelCatTR", &CTPERelCatTR_attr));					
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelBuyerCdTR", &CTPERelBuyerCdTR_attr));//	Buyer Code		
							
	
							//("\n\t PE Part  :%s PE Part Desc :%s \n",CTEDPEPartTR_attr,CTEDPEPartDescTR_attr);fflush(stdout);
							//printf("\n\t Order Qty/MOQ  :%s Quantity/Set :%s \n",CTPERelOrQtyTR_attr,tCTPERelQtyPerSetTR_attr);fflush(stdout);
							//printf("\n\t Drg Status  :%s Replace Drg :%s \n",CTPERelDrwNoStatTR_attr,CTPERelRplcDrgTR_attr);fflush(stdout);
							//printf("\n\t Remark  :%s Tool Type :%s \n",CTPERelRmrkTR_attr,CTPERelToolTypeTR_attr);fflush(stdout);
							//printf("\n\t Category  :%s Buyer Code :%s \n",CTPERelCatTR_attr,CTPERelBuyerCdTR_attr);fflush(stdout);
							
							printf("\n\t  PE Part ----> :[%s] \n",CTEDPEPartTR_attr);fflush(stdout);
							printf("\n\t  PE Part Desc ---> :[%s] \n",CTEDPEPartDescTR_attr);fflush(stdout);
							printf("\n\t  Buyer Code111 is---> :[%s] \n",CTPERelBuyerCdTR_attr);fflush(stdout);
							//printf("\n\t Buyer Remark222  :%s Buyer Code222 :%s \n",CTEDByerRmrkByrTR_attr,CTPERelBuyerCdTR_attr);fflush(stdout);

							

                            //// PE part Desc start Pravin

		if (CTEDPEPartTR_attr != NULL) // plj
			//printf("\n Indivisual Object IndUtobjTag---22-- : %d \n",IndUtobjTag);
		{
		char *qry_entryCntrlformat[1] = {"ID"};
		//char *qry_entryCntrlformat[0] = {"ID"};
        char **qry_valuesCntrlformat = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound = 0;
        int n_entryCntrlobj = 1;

        if (QRY_find2("Cted_PEpart_Query", &qryTagCntrlobj));

        if (qryTagCntrlobj)
        {
            printf("\n PE Part Query Found---111 \n");
            fflush(stdout);
            qry_valuesCntrlformat[0] = CTEDPEPartTR_attr;  //IndUnit_no;

            if (QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags))
                ;
        }
			printf("\n PLJ PE Part Found; %d\n",controlObjfound);
		if (controlObjfound > 0)
		{
			int				n_strings			=	1;
			int				index			=	1;
			int				l_strings			=	300;
			char**			stringArrayMBOM		= 	NULL;
 
			stringArrayMBOM = (char**)malloc( n_strings * sizeof *stringArrayMBOM );
			for( index=0; index<n_strings; index++ )
			{
				stringArrayMBOM[index] = (char*)malloc( l_strings + 1 );
			}

			tag_t IndUt_obj = list_of_cntrl_tags[0];

			AOM_ask_value_string(IndUt_obj, "object_desc", &object_desc1);
		    printf("\n Pravin inside class object_Desc...... ;%s\n", object_desc1);
		   fflush(stdout);

//			GRM_find_relation_type("T5_CTEDHasPEPart", &relation_type);
//	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
//			GRM_create_relation(dml_rev_tag, IndUt_obj, relation_type, NULLTAG, &relation);
//			GRM_save_relation(relation);

           //tc_strcpy( stringArrayMBOM[0], object_desc1);
		   //printf("\n stringArrayMBOM : %s",stringArrayMBOM[0]);fflush(stdout);
		   //ITK_CALL( TCTYPE_set_create_display_value( IndUtobjcre, "t5_PeDesignUntClm", 1,(const char**)stringArrayMBOM) );
		  // ITK_CALL( TCTYPE_set_create_display_value( ValidRowsTag[iValCnt], "t5_CTEDPEPartDescTR", 1,(const char**)stringArrayMBOM) );
		  ITKCALL(AOM_lock(ValidRowsTag[iValCnt]));
		   ITKCALL(AOM_set_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartDescTR",object_desc1));
		   ITKCALL(AOM_save_without_extensions(ValidRowsTag[iValCnt])); 
		   ITKCALL(AOM_unlock(ValidRowsTag[iValCnt]));


		}
		else
		 {
			 printf("\t  PE Part Query Not Found \n");
			fflush(stdout);
		}

		}



   //// PE part Desc start Pravin








						//	if(tc_strcmp(CTPERelRmrkTR_attr,"NULL")==0 ||(tc_strcmp(CTPERelBuyerCdTR_attr,"NULL")==0))
							if(tc_strcmp(CTPERelBuyerCdTR_attr,"NULL")==0 ||tc_strlen(CTPERelBuyerCdTR_attr) == 0) //||(tc_strcmp(CTEDByerRmrkByrTR_attr,"NULL")==0))				//t5_RmrkByrTR
							{
								printf("\n\t CONDITION 1: Buyer Code is NULL ---->  :%s \n",CTPERelBuyerCdTR_attr);fflush(stdout);

								buyercodePEflag++;     //buyercodePEflag
							}
								printf("\n\t buyercodePEflag at NULL condition is : %d  \n",buyercodePEflag);fflush(stdout);
							//if(tc_strcmp(CTPERelRmrkTR_attr," ")==0 ||(tc_strcmp(CTPERelBuyerCdTR_attr," ")==0)){
							//if ((tc_strlen(CTPERelRmrkTR_attr) > 0 || tc_strlen(CTPERelBuyerCdTR_attr) > 0 ))
							if (tc_strlen(CTPERelBuyerCdTR_attr) > 0) //|| tc_strlen(CTEDByerRmrkByrTR_attr) > 0 ))
							{
								printf("\n\t CONDITION 2 : Buyer Code  is updated > 0 ----> :%s \n",CTPERelBuyerCdTR_attr);fflush(stdout);
								buyerremarkflag1++;
							}
								printf("\n\t buyerremarkflag1 at >0 condition is : %d  \n",buyerremarkflag1);fflush(stdout);

						}
		
					}
						printf("\n\t Buyer Code555 :%s \n",CTPERelBuyerCdTR_attr);fflush(stdout);

				//added by amol

				int y=0;
				int numOfWFtasks=0;
				char *taskNumberfromTag = NULL;
				char *taskName=NULL;
				char *taskResult=NULL;
				tag_t *valuesOfWFtasksTag=NULLTAG;

				//ITKCALL(AOM_ask_value_tags(Primary_Obj, "fnd0ActuatedInteractiveTsks", &numOfWFtasks, &valuesOfWFtasksTag ));		//	fnd0ActuatedInteractiveTsks
				ITKCALL(AOM_ask_value_tags(Primary_Obj, "fnd0StartedWorkflowTasks", &numOfWFtasks, &valuesOfWFtasksTag ));
				printf("\n CTED Total Workflow Tasks  %d ",numOfWFtasks);fflush(stdout);
				//for(y=0;y<numOfWFtasks;y++)
				if(numOfWFtasks>0)
				{
					ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[1], "fnd0AliasTaskName", &taskName));				//Actuated Interactive Tasks
					printf("\n CTED Task taskName_2  : %s ",taskName);fflush(stdout);
					
					//if(tc_strcmp(taskName,"PE Part attachment Asg")==0 && tc_strcmp(taskResult,"Unset")==0)	//&& tc_strcmp(taskResult,"Approved")==0)
					if(tc_strcmp(taskName,"PE Part attachment Asg")==0 )	//&& tc_strcmp(taskResult,"Approved")==0)
					{
					//	printf("\n CTED inside Assignmnet PE Part attachment Asg condition75756464 = %d " ,buyerremarkflag);fflush(stdout);
						printf("\n CTED inside Assignmnet PE Part attachment Asg condition75756464 = %d " ,buyerremarkflag1);fflush(stdout);

						//ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[y], "task_result", &taskResult));
						//printf("\n  CTED Task taskResult PE Part attachment Asg : %s ",taskResult);fflush(stdout);


						if (buyerremarkflag1 > 0 )
						//if (tc_strlen(CTPERelRmrkTR_attr) > 0 && tc_strlen(CTPERelBuyerCdTR_attr) > 0 )
						{

							printf("\n CTED inside Assignmnet PE Part attachment Asg & taskresult cnd added condition99999999999910--- ");fflush(stdout);

							EMH_store_error_s1(EMH_severity_error, PLM_error, "Buyer code should be Updated by Buyer, Please remove the Buyer Code then check-in");
							return PLM_error;
						}
							printf("\n CTED as is PE Part attachment Asg ");fflush(stdout);
						//	break;
					}
					//else if (tc_strcmp(taskName,"Buyer Code update")==0 && tc_strcmp(taskResult,"Unset")==0)
					else if (tc_strcmp(taskName,"Buyer Code update")==0 )
					{
						//printf("\n CTED Task taskResult Buyer Code update : %s & Buyer Code update : %s ",taskResult,taskName);fflush(stdout);
						printf("\n CTED Buyer Code update : %s ",taskName);fflush(stdout);
						printf("\n CTED inside Assignmnet Buyer Code update condition is check buyercodePEflag 2222Amm =%d ", buyercodePEflag);fflush(stdout);

						//if (tc_strlen(CTPERelRmrkTR_attr) == 0 && tc_strlen(CTPERelBuyerCdTR_attr) == 0 )
						if ((buyercodePEflag) > 0 )
						{
							printf("\n CTED as is Buyer Code update assignment 2223344455 amm at CTED_checkin_PreCond_Validation ");fflush(stdout);
							printf("\n CTED Buyer Code is at CTED_checkin_PreCond_Validation---> = %s ",CTPERelBuyerCdTR_attr);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error, PLM_error, "Buyer code are not Updated, Please update the Buyer code then check-in");
							return PLM_error;
						}
							printf("\n CTED as is Buyer Code update assignmentTTT--- ");fflush(stdout);

					}
					else
					{
						printf("\n Not Buyer Code update - condition not validsss-- \n");fflush(stdout);
					}
				}
		}
		else
		{
			printf("\n CTED class not found -------\n"); fflush(stdout);
		}
		
	}
	else
	{
		printf("\n control obj not found \n");fflush(stdout);
	}


	return (ITK_ok);
}

//---------------------------------------------------CTED_checkin_PreCond_Validation End -  --------------------------------------------//


//----------------------------------------------------------- Buyer_CodeUpdate_Assignment_signoff_validation Start -------------------------------//
extern EPM_decision_t DLLAPI Buyer_CodeUpdate_Assignment_signoff_validation(EPM_rule_message_t msg) 
{
	EPM_decision_t decision;

	tag_t *pTagAttch;
	tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
	tag_t rel_PE = NULLTAG;
	tag_t *PartTag = NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	char* Primary_Obj_name = NULL;
	char *newid=NULL;
	tag_t * PartTags =NULL;
	int valid_rows =0;
	tag_t * ValidRowsTag =NULL;
	int iValCnt=0;
	//char *CTPERelRmrkTR_attr=NULL;
	char *CTPERelBuyerCdTR_attr=NULL;
	//char *CTEDByerRmrkByrTR_attr=NULL;
	//char *CTEDPEPartTR_attr=NULL;			//CTEDPEPartTR_attr=NULL;
	//char *CTEDPEPartDescTR_attr=NULL;
	//tag_t Primary_Obj = va_arg(args, tag_t);
	int buyerremarkflag=0;
	int buyerremarkflag1 = 0;
	int buyerremarkflag3 = 0;
	//tag_t Primary_Obj = va_arg(args, tag_t);

    char* CurrentTask = NULL;
    char* parent_name = NULL;
	char* type_name	= NULL;
	char* Validation = NULL;
	char* PEPrtTab = NULL;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
    
	int iNumAttch = 0;
	int control_number_found1 = 0;
	int n_entryCntrl1 = 3;
    int noAttachment = 0;
	int PartCnt = 0;
    	 
	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For BuyerCodeUpdRuleValid\n");fflush(stdout);
		qry_valuesCntrl1[0] = "BuyerCodeUpdRuleValid";
		qry_valuesCntrl1[1] = "BuyerCodeUpdRuleValid";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{
		Validation = (char *)MEM_alloc(3000 * sizeof(char));
		tc_strcpy(Validation," ");

		printf("\n Inside Registered Rule Handler Buyer_CodeUpdate_Assignment_signoff_validation \n ");
		fflush(stdout);

		if (EPM_ask_root_task(msg.task, &rootTask))
			;
		if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask))
			;
		printf("\n CurrentTask of Cted :%s\n", CurrentTask);
		if (AOM_ask_value_string(rootTask, "object_name", &parent_name))
			;
		printf("\n Parent Name Cted:%s\n", parent_name);
		fflush(stdout);
		if (EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments))
			;
		printf("\n Target Attachment Cted:%d\n", noAttachment);
		fflush(stdout);
		if (noAttachment > 0)
		{
			dml_rev_tag = attachments[0];
			if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
				;
			if (TCTYPE_ask_name2(objTypeTag, &type_name))
				;
			printf("\n type_name changes done: for workspaceobject  :%s\n", type_name);
			fflush(stdout);
		}

		if ((tc_strcmp(type_name, "T5_CTEDRevision") == 0) && (tc_strcmp(CurrentTask, "Buyer Code update") == 0))
		{
	//-----------------------------------------------//-------------------------------------------//
	//				if (tc_strcmp(Primary_Obj_name, "T5_CTEDRevision") == 0)								//
	//			{
		//	{
				ITKCALL(AOM_ask_value_tags(dml_rev_tag,"t5_CTEDPEtableRev",&PartCnt,&PartTags));
				printf("\n CTED form object found in Reference Folder is---  : %d",PartCnt);fflush(stdout);

				if (PartCnt > 0)
				{
					ITK_CALL(AOM_UIF_ask_value(dml_rev_tag,"item_id",&newid));						//t5_CTImpNrml
					printf("\n newid1122--- :%s\n",newid);fflush(stdout);

					ITK_CALL(AOM_ask_table_rows(dml_rev_tag,"t5_CTEDPEtableRev", &valid_rows,&ValidRowsTag));				
					printf("\n\t Part count against PE part from table valid_rows is333--  :%d\n",valid_rows);fflush(stdout);

					for(iValCnt=0;iValCnt<valid_rows;iValCnt++)
					{
						
						CTPERelBuyerCdTR_attr=NULL;
							
						ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelBuyerCdTR", &CTPERelBuyerCdTR_attr));//	Buyer Code		

						printf("\n\t  Buyer Code at Buyer Code update assign is---> :[%s] \n",CTPERelBuyerCdTR_attr);fflush(stdout);
			
							//if (tc_strlen(CTPERelBuyerCdTR_attr) == 0) //|| tc_strlen(CTEDByerRmrkByrTR_attr) > 0 ))
							if(tc_strcmp(CTPERelBuyerCdTR_attr,"")==0)
							{
								printf("\n\t CONDITION 2 : Buyer Code  is updated > 0 ----> :%s \n",CTPERelBuyerCdTR_attr);fflush(stdout);
								buyerremarkflag3++;
							}
								printf("\n\t buyerremarkflag3 at >0 condition is : %d  \n",buyerremarkflag3);fflush(stdout);

					}
		
				//	}
						printf("\n\t Buyer Code--6666 :%s \n",CTPERelBuyerCdTR_attr);fflush(stdout);

				//added by amol

				int y=0;
				int numOfWFtasks=0;
				char *taskNumberfromTag = NULL;
				char *taskName=NULL;
			//	char *taskResult=NULL;
				tag_t *valuesOfWFtasksTag=NULLTAG;

				// ITKCALL(AOM_ask_value_tags(type_name, "fnd0StartedWorkflowTasks", &numOfWFtasks, &valuesOfWFtasksTag ));		//	fnd0ActuatedInteractiveTsks
				// printf("\n CTED Total Workflow Tasks  %d ",numOfWFtasks);fflush(stdout);
				// //for(y=0;y<numOfWFtasks;y++)
				// if(numOfWFtasks>0)
				// {
				// 	ITKCALL(AOM_ask_value_string( valuesOfWFtasksTag[1], "object_name", &taskName));				//Actuated Interactive Tasks
				// 	printf("\n CTED Task taskName_2  : %s ",taskName);fflush(stdout);
				
				// 	if (tc_strcmp(taskName,"Buyer Code update")==0 )
				// 	{
				// 		printf("\n CTED Task taskResult Buyer Code update : %s & Buyer Code update : %s ",taskResult,taskName);fflush(stdout);
				// 		printf("\n CTED inside Assignmnet Buyer Code update condition is check buyerremarkflag 2222Amm =%d ", buyerremarkflag);fflush(stdout);

						//if (tc_strlen(CTPERelRmrkTR_attr) == 0 && tc_strlen(CTPERelBuyerCdTR_attr) == 0 )
						if ((buyerremarkflag3) > 0 )
						{
							printf("\n  Buyer Code updated successfully = %s \n",CTPERelBuyerCdTR_attr);fflush(stdout);
							printf("\n CTED as is Buyer Code update assignment 2223344455 amm ");fflush(stdout);
							printf("\n CTED Buyer Code is---> = %s ",CTPERelBuyerCdTR_attr);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error, PLM_error, "Buyer code are not Updated, Please update the Buyer code then sign off");
							return PLM_error;
							
						}
							printf("\n CTED as is Buyer Code update assignmentTTT--- ");fflush(stdout);

					// }
					// else
					// {
					// 	printf("\n Task name is not Buyer Code update");fflush(stdout);
					// // 	printf("\n CTED Buyer Code is---> = %s ",CTPERelBuyerCdTR_attr);fflush(stdout);
					// // 	EMH_store_error_s1(EMH_severity_error, PLM_error, "Buyer code are not Updated, Please update the Buyer code then check in");
					// // 	return PLM_error;
					// }
				// }
		}
	}
		else
		{
			printf("\n CTED class not found -------\n"); fflush(stdout);
		}
	}
	decision = EPM_go;
	return decision;
}
//----------------------------------------------------------- Buyer_CodeUpdate_Assignment_signoff_validation Start -------------------------------//


//---------------------------------------------------Work_Record_IndUt_Creation Start -  --------------------------------------------//

int Work_Record_IndUt_Creation(METHOD_message_t* msg, va_list args)					//Work_Record_IndUt_Creation
{

	tag_t Primary_Obj = va_arg(args, tag_t);
	tag_t Primary_Obj_Type = NULLTAG;
	tag_t* table_rows = NULLTAG;
	tag_t *list_of_cntrl_tags = NULLTAG;


	int ntablerows = 0;
	int i = 0;
	int int_CompareDatasetfile = 0;
	int int_CompareNamedReffile = 0;


	char* Primary_Obj_name = NULL;
	char* qCtrlCommodity = NULL;
	char* sor_qBarrelCode = NULL;
	//char* sor_qSORnumber = NULL;
	char* CTED_item_id		= NULL;
	char* sor_qSORPartDesc = NULL;
	char* sor_qSorCat = NULL;
	char* sor_qSorPrtClrInd = NULL;
	char* sor_qSorPartNumber = NULL;
	char* sor_qSorPartRevision = NULL;
	char* sor_qSorPartSeq = NULL;
	char* sor_qPPPMPrjCode = NULL;
	char* st5_qQuantity = NULL;

    char *newid=NULL;
	int PartCnt =0;
	tag_t * PartTags =NULL;
	int valid_rows =0;
	tag_t * ValidRowsTag =NULL;
	int iValCnt=0;
	char *CTPERelRmrkTR_attr=NULL;
	char *CTPERelBuyerCdTR_attr=NULL;
	char *CTEDByerRmrkByrTR_attr=NULL;

	char *PeDesignerRev_attr=NULL;
	char *PeDesignUntRev_attr=NULL;
	char *PeDesignUntClmRev_attr=NULL;

	tag_t *ValCntrlObjectTagT = NULLTAG;
    tag_t qryTagCntrl1 = NULLTAG;
    //tag_t controlobj = NULLTAG;
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};

	char *item_id_dup 	   = NULL;
	item_id_dup = (char *)MEM_alloc(50 * sizeof(char *));
	tag_t IndUtobj=NULLTAG;
	tag_t IndUtobjcre=NULLTAG;
	tag_t IndUtobjTag=NULLTAG;
	char* IndUtobjNumber=NULL;

	//amm_6_aug------
	tag_t qryTagCntrlobj = NULLTAG;   
	tag_t relation_type, relation, propTag = NULLTAG;



	// control object for Work_Record_IndUt_Creation // 

		QRY_find2("Control Objects...", &qryTagCntrl1);

        printf("\n Control Object Query Found Work_Record_IndUt_Creation\n");				//Work_Record_IndUt_Creation
        fflush(stdout);
        qry_valuesCntrl1[0] = "Work_Record_IndUt_Creation";
        qry_valuesCntrl1[1] = "Work_Record_IndUt_Creation";
        qry_valuesCntrl1[2] = "0";

        printf("\n Before Control Object Query Found Work_Record_IndUt_Creation\n");
        fflush(stdout);
        int control_number_found1 = 0;
        tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
        if (QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1))
            ;
        printf("\n Number of control object found for Work_Record_IndUt_Creation is  :%d", control_number_found1);
        fflush(stdout);

        if (control_number_found1 > 0)
        {
			int				n_strings			=	1;
			int				index			=	1;
			int				l_strings			=	300;
			char**			stringArrayMBOM		= 	NULL;

			stringArrayMBOM = (char**)malloc( n_strings * sizeof *stringArrayMBOM );
			for( index=0; index<n_strings; index++ )
			{
				stringArrayMBOM[index] = (char*)malloc( l_strings + 1 );
			}

			ITK_CALL(TCTYPE_ask_object_type(Primary_Obj, &Primary_Obj_Type));
			ITK_CALL(TCTYPE_ask_name2(Primary_Obj_Type, &Primary_Obj_name));

			printf("\n Work_Record_IndUt_Creation ---work record Primary_Obj_name:  [%s]\n", Primary_Obj_name); fflush(stdout);
	
			int buyerremarkflag=0;
			int buyerremarkflag1 = 0;
			if (tc_strcmp(Primary_Obj_name, "T5_WorkReRevision") == 0)								//T5_WorkReRevision
			{

				ITKCALL(AOM_ask_value_tags(Primary_Obj,"t5_IndunitTableAttrer",&PartCnt,&PartTags));		//t5_IndunitTableAttrer
				printf("\n Work record form object found in Reference Folder is---  : %d",PartCnt);fflush(stdout);

					if (PartCnt > 0)
					{
						ITK_CALL(AOM_UIF_ask_value(Primary_Obj,"item_id",&newid));						//t5_CTImpNrml
						printf("\n Work record newid1122--- :%s\n",newid);fflush(stdout);

						ITK_CALL(AOM_ask_table_rows(Primary_Obj,"t5_IndunitTableAttrer", &valid_rows,&ValidRowsTag));				
						printf("\n\t Part count against Work record from table valid_rows is4444--  :%d\n",valid_rows);fflush(stdout);

						for(iValCnt=0;iValCnt<valid_rows;iValCnt++)
						{
							PeDesignerRev_attr=NULL;
							PeDesignUntRev_attr=NULL;
							PeDesignUntClmRev_attr=NULL;

							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartTR", &CTEDPEPartTR_attr));					
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTEDPEPartDescTR", &CTEDPEPartDescTR_attr));			
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelOrQtyTR", &CTPERelOrQtyTR_attr));				
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelQtyPerSetTR", &tCTPERelQtyPerSetTR_attr));		
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelDrwNoStatTR", &CTPERelDrwNoStatTR_attr));		
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelRplcDrgTR", &CTPERelRplcDrgTR_attr));
							
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelRmrkTR", &CTPERelRmrkTR_attr));	//Remark	
							
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelToolTypeTR", &CTPERelToolTypeTR_attr));			
							//ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_CTPERelCatTR", &CTPERelCatTR_attr));					
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_PeDesignerRev", &PeDesignerRev_attr));//	t5_PeDesignerRev	= Designer	
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_PeDesignUntRev", &PeDesignUntRev_attr));//	t5_PeDesignUntRev	= Current designer unit	
							ITK_CALL(AOM_ask_value_string(ValidRowsTag[iValCnt], "t5_PeDesignUntClmRev", &PeDesignUntClmRev_attr));//	t5_PeDesignUntClmRev = Total Unit
							
							printf("\n\t  Wrk rec Row is--->[%d] :PeDesignerRev_attr = [%s] PeDesignUntRev_attr = [%s] PeDesignUntClmRev_attr = [%s]\n",iValCnt+1,PeDesignerRev_attr,PeDesignUntRev_attr,PeDesignUntClmRev_attr);fflush(stdout);
							//printf("\n\t  Wrk rec DesignUntRev is--->[%d] :[%s] \n",PeDesignUntRev_attr);fflush(stdout);
							//printf("\n\t Wrk rec DesignUnt is--->[%d] :[%s] \n",PeDesignUntClmRev_attr);fflush(stdout);


							//Create obj
							

							//char *item_id_dup 	   = NULL;
							//item_id_dup = (char *)MEM_alloc(50 * sizeof(char *));

							ITK_CALL( TCTYPE_find_type( "T5_IndUt", NULL, &IndUtobj) );
							ITK_CALL( TCTYPE_construct_create_input( IndUtobj, &IndUtobjcre) );

							//ITK_CALL(TCTYPE_create_object(IndUtobjcre,&IndUtobjTag));
					
							//printf("\n Indivisual Object Created. \n");fflush(stdout);


							strcpy(item_id_dup, newid);			//newid                              
							strcat(item_id_dup, "_");                                                
							strcat(item_id_dup, PeDesignerRev_attr);                                 
							strcat(item_id_dup, "_");                                                
							strcat(item_id_dup, PeDesignUntRev_attr);                                
							strcat(item_id_dup, "_");                                                
							strcat(item_id_dup, PeDesignUntClmRev_attr);                             
							//strcat(item_id_dup, "_");                                                
							//strcat(item_id_dup, Suffix);                                            
							
							 printf("\n item_id_dup is %s \n",item_id_dup);fflush(stdout);

							 //Find out exsiting obj

						                                                                                                    
						tag_t qryTagCntr24 = NULLTAG;                                                                                                            
						//tag_t controlobj = NULLTAG;                                                                                                            
						char **qry_valuesCntrl24 = (char **)MEM_alloc(5 * sizeof(char *));                                                                          
						int n_entryCntr24 = 1;                                                                                                                     
						char *qry_entryCntrl24[1] = {"Name"}; 
						char* IndUnit_no = NULL;
						                                                                                                                                           
						printf("\n Individual unit creation code start\n");                                                                                        
						                                                                                                                                           
						// control object for Work_Record_IndUt_Creation //                                                                                        
						                                                                                                                                           
						QRY_find2("IND_UNIT_CTED_Qry", &qryTagCntr24);                                                                                        
						                                                                                                                                           
						 printf("\n Control Object Query Found IND_UNIT_CTED_Qry---1\n");				//Work_Record_IndUt_Creation                       
						 fflush(stdout);                                                                                                                      
						 qry_valuesCntrl24[0] = item_id_dup;                                                                                  
						 //qry_valuesCntrl24[1] = "Work_Record_IndUt_Creation";                                                                                  
						 //qry_valuesCntrl24[2] = "0";                                                                                                           
						                                                                                                                                      
						 printf("\n Before Control Object Query Found IND_UNIT_CTED_Qry----2\n");                                                         
						 fflush(stdout);                                                                                                                      
						 int control_number_found24 = 0;                                                                                                       
						 tag_t *list_of_WSO_cntrl_tags24 = NULLTAG;                                                                                            
						 if (QRY_execute(qryTagCntr24, n_entryCntr24, qry_entryCntrl24, qry_valuesCntrl24, &control_number_found24, &list_of_WSO_cntrl_tags24));    
						                                                                                                                                    
						 printf("\n Number of control object found for Work_Record_IndUt_Creation is  :%d", control_number_found24);                           
						 fflush(stdout);                                                                                                                      
						                                                                                                                                      
						 if (control_number_found24 > 0)                                                                                                        
						{  
							printf("\n control_number_found24 Individual unit creation continue 111-- \n");fflush(stdout);
							continue;
					
						}
						else
							{
						
							tc_strcpy( stringArrayMBOM[0], item_id_dup);
							printf("\n stringArrayMBOM : %s",stringArrayMBOM[0]);fflush(stdout);
							ITK_CALL( TCTYPE_set_create_display_value( IndUtobjcre, "object_name", 1,(const char**)stringArrayMBOM) );
							//
							tc_strcpy( stringArrayMBOM[0], PeDesignerRev_attr);
							printf("\n stringArrayMBOM : %s",stringArrayMBOM[0]);fflush(stdout);
							ITK_CALL( TCTYPE_set_create_display_value( IndUtobjcre, "t5_PeDesigner", 1,(const char**)stringArrayMBOM) );
							
							tc_strcpy( stringArrayMBOM[0], PeDesignUntRev_attr);
							printf("\n stringArrayMBOM : %s",stringArrayMBOM[0]);fflush(stdout);
							ITK_CALL( TCTYPE_set_create_display_value( IndUtobjcre, "t5_PeDesignUnt", 1,(const char**)stringArrayMBOM) );
							
							tc_strcpy( stringArrayMBOM[0], PeDesignUntClmRev_attr);
							printf("\n stringArrayMBOM : %s",stringArrayMBOM[0]);fflush(stdout);
							ITK_CALL( TCTYPE_set_create_display_value( IndUtobjcre, "t5_PeDesignUntClm", 1,(const char**)stringArrayMBOM) );

							ITK_CALL(TCTYPE_create_object(IndUtobjcre,&IndUtobjTag));
							printf("\n Indivisual Object Created. \n");fflush(stdout);
							

							ITK_CALL(AOM_save_without_extensions(IndUtobjTag)); 
							ITK_CALL(AOM_refresh(IndUtobjTag,1));
							
						}

							////
							//-----------------Code For releation Creation Indivisual Unit with work order -----------------------------------------//
		
		(AOM_ask_value_string(IndUtobjTag,"object_name",&IndUnit_no));							//wrkrecd no.      T5_CTHasWrk
		 printf("\n CTED : Code For releation Creation work order with CTED :%s  \n",IndUnit_no);	
		 fflush(stdout);
        
		if (IndUnit_no != NULL) // plj
			//printf("\n Indivisual Object IndUtobjTag---22-- : %d \n",IndUtobjTag);
		{
		char *qry_entryCntrlformat[1] = {"Name"};
		//char *qry_entryCntrlformat[0] = {"ID"};
        char **qry_valuesCntrlformat = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound = 0;
        int n_entryCntrlobj = 1;

        if (QRY_find2("IND_UNIT_CTED_Qry", &qryTagCntrlobj));

        if (qryTagCntrlobj)
        {
            printf("\n Indivisual Object WrokRec  Query Found---111 \n");
            fflush(stdout);
            qry_valuesCntrlformat[0] = IndUnit_no;

            if (QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags))
                ;
        }
			printf("\n Indivisual Object controlObjfound Found; %d\n",controlObjfound);
		if (controlObjfound > 0)
		{
			tag_t IndUt_obj = list_of_cntrl_tags[0];

			GRM_find_relation_type("T5_WrkhasIndUnitRev", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(Primary_Obj, IndUt_obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);

			GRM_find_relation_type("T5_UnitHasWrk", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(IndUt_obj, Primary_Obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);
		}
		else
		 {
			 printf("\t Indivisual Object WrokRec Control Object Query Not Found \n");
			fflush(stdout);
		}

		}

//// 
		//-----------------Code For releation Creation trial Report with CTED-----------------------------------------//



						}
		
					}
				

	
					
				}
		}
		
	
	else
	{
		printf("\n control obj not found \n");fflush(stdout);
	}


	return (ITK_ok);
}

//---------------------------------------------------Work_Record_IndUt_Creation End -  --------------------------------------------//

//---------------------------------------------------tm_cted_release_letter_Report Start -  --------------------------------------------//
int tm_cted_release_letter_Report(EPM_action_message_t  msg)
{
	EPM_decision_t decision;
	int status;

	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULLTAG;
	int targetobjects_count = 0;
	char* dmlNo = NULL;	
	POM_get_user(&username,&user_tag);
	printf("\n Starting for username :%s....\n",username);fflush(stdout);
	printf("\n Starting tm_cted_release_letter_Report......\n");fflush(stdout);
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n CTED Root task found");fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\n CTED Current Task:%s\n",currentTaskName);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\n CTED Parent Name:%s\n",parentTaskName);fflush(stdout);	

	int n_entries11 =	3;
	char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	int resultCount=0;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	tag_t *qry_cntrlobj11= NULLTAG;
	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	{
		printf("\n CTED Control Object Query Found \n");fflush(stdout);
		qry_values11[0] =	"CTEDReleaseLetterReport" ;
		qry_values11[1] =	"active" ;
		qry_values11[2] =	"0" ;

		ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11));
		printf("\n CTED No. of control object found : %d :%d",resultCount, targetobjects_count);fflush(stdout);        // print resultCount, targetobjects_count

		if(resultCount>0)
		{		
			ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
		    printf("\n CTED Release Letter Report Cntrl OBJECT --> usrinfo1 ---> [ %s ]\n", usrinf1);fflush(stdout);
		}
	}

	ITK_CALL(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects));
	if((targetobjects_count > 0) && (resultCount>0))
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char*  type_name=NULL;
		char* dmlType = NULL;
		char	*DML_no					= NULL;
		char* dmlTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			ITK_CALL(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			//ITK_CALL(TCTYPE_ask_name2( objectTypeTag,type_name));
			ITK_CALL(TCTYPE_ask_name2( objectTypeTag,&type_name));
			printf("\n CTED type_name ==> %s\n", type_name);fflush(stdout);

			ITKCALL(AOM_ask_value_string(targetobjects[i], "item_id", &DML_no));
		    printf("\n CTED NO     %s\n", DML_no);fflush(stdout);

           if(tc_strcmp(type_name,"T5_CTEDRevision")==0)
			{
   	          printf("\n MMDml Type  full name : %s \n",dmlType); fflush(stdout);
			  dmlTag=targetobjects[i];
			   break;
		    }
			else
			{

				 printf("\n CTED REVISION OBJ NOT FOUND \n"); fflush(stdout);

			}

		}
		if(dmlTag==NULLTAG)
		{
			printf("\nTarget Object is not NON_ERC DML Revision dmlTag Not found \n");fflush(stdout);
			return ifail;
		}	
		
		//Call the Report logic function
		if(tc_strcmp(usrinf1,"ActiveShell")==0)
		{
			ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo2", &usrinf2));
		    printf("\n CTED Release letter Cntrl OBJECT --> usrinfo2 ---> [ %s ]\n", usrinf2);fflush(stdout);
			ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo3", &usrinf3));
		    printf("\n CTED Release letter Cntrl OBJECT --> usrinfo3 ---> [ %s ]\n", usrinf3);fflush(stdout);
			printf("\n CTED Release letter ------>   [ %s ] \n", DML_no);fflush(stdout);

			char* report_ip = NULL;
			report_ip=(char *)MEM_alloc(200);
			tc_strcpy(report_ip,"");
			tc_strcat(report_ip,usrinf2);
			tc_strcat(report_ip," ");
			tc_strcat(report_ip,DML_no);
			system(report_ip);

		}
		else
		{
			 printf("\n CTED SHELL PATH NOT FOUND \n"); fflush(stdout);
		}

		
	}
	
	return ifail;
//	decision = EPM_go;
//	return ifail;
}

//---------------------------------------------------tm_cted_release_letter_Report End -  --------------------------------------------//


//---------------------------------------------------tm_cted_release_letter_Report_mail_notification AT Assignment Buyer Code Update Start -  --------------------------------------------//

///user/cvprod/NON_ERC_PUNE/TEST_CC/Sanjay/AMOL
int tm_cted_release_letter_Report_mail_notification(EPM_action_message_t  msg)					//AT Assignment Buyer Code Update Start
{
	tag_t  roottask									= NULLTAG;
	tag_t  Rev										= NULLTAG;
	tag_t  *Attachments								= NULLTAG;
	tag_t	DmlRev_tag								= NULLTAG;
	tag_t	Reftag									= NULLTAG;
	tag_t   sec_obj									= NULLTAG;
	tag_t*	secondary_objects						= NULLTAG;							              
	char*       Obj_N								= NULL;
	char*       Obj_S								= NULL;
	int no_attach									= 0;
	int error_code									= ITK_ok;
	int i											= ITK_ok;
	int jm											= ITK_ok;
    int	ifail										= ITK_ok;
	int   count										= 0;
	tag_t	objTypTag								=NULLTAG;
	char*   ObjTyp									= NULL;
	char *Obj_N_Rev									=NULL;
	char *type										=NULL;
	int count2										=0;
	int count3										=0;
	tag_t *ref										=NULLTAG;
	tag_t *ref1										=NULLTAG;
	char *ref_name									=NULL;
	char *path										=NULL;
	int k											=0;
	char *ref_name2									=NULL;
	char *path1										=NULL;
	int j											=0;
	int targetobjects_count							= 0;
	char *newpath									=NULL;
	newpath											=(char*) MEM_alloc(sizeof(path)+100);
	char *cmd[100];
	char *shellname									=NULL;
 
	printf("\n tm_cted_release_letter_Report_mail_notification..");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok);
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok);
	printf("\tm_part_type_Action:No of Attachements::--------[%d]", no_attach);fflush(stdout);

	//added by amol
	int n_entries11 =	3;
	char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *CtIndSubjct = NULL;
	int resultCount=0;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	tag_t *qry_cntrlobj11= NULLTAG;
	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	{
		printf("\n CTED Control Object Query Found for CTEDReleaseLetterReport_mail_attch \n");fflush(stdout);
		qry_values11[0] =	"CTEDReleaseLetterReport_mail_attch" ;
		qry_values11[1] =	"active" ;
		qry_values11[2] =	"0" ;

		ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11));
		printf("\n CTED No. of control object found for CTEDReleaseLetterReport_mail_attch  :%d",resultCount);fflush(stdout);        // print resultCount, targetobjects_count

		if(resultCount>0)
		{		
			ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
		    printf("\n CTED Release Letter Report Cntrl OBJECT for CTEDReleaseLetterReport_mail_attch --> usrinfo1 ---> [ %s ]\n", usrinf1);fflush(stdout);
		}
	}

	//end 
 
	if(resultCount>0)
	{
		if(no_attach >0)
		{
			for(jm=0;jm<no_attach;jm++)
			{
				Rev=Attachments[jm];
				if(TCTYPE_ask_object_type(Rev,&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n : Workfow obj type: [%s]\n\n\n", ObjTyp);fflush(stdout);
				if(tc_strcmp(ObjTyp,"T5_CTEDRevision")==0)
				{
					ifail = ITEM_ask_latest_rev(Rev,&DmlRev_tag); 

					ifail=AOM_UIF_ask_value(Rev,"item_id",&Obj_N_Rev);
					printf("\n :object_name : %s\n ",Obj_N_Rev);fflush(stdout);

					ifail=AOM_UIF_ask_value(Rev,"t5_CtIndSubjct",&CtIndSubjct);
					printf("\n :CtIndSubjct : %s\n ",CtIndSubjct);fflush(stdout);
					
					ifail = GRM_find_relation_type("IMAN_reference",&Reftag);
					printf("\n :rel found \n ");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(Rev,Reftag,&count,&secondary_objects);
					printf("\n :Dataset Count is : %d\n ",count);fflush(stdout);
					tc_strcpy(newpath,"");
	 
					for (i=0; i< count; i++)
					{
						sec_obj=secondary_objects[i];
	 
						ifail=AOM_UIF_ask_value(sec_obj,"object_name",&Obj_N);
						printf("\n :object_name : %s\n ",Obj_N);fflush(stdout);
	 
						ifail=AOM_UIF_ask_value(sec_obj,"object_string",&Obj_S);
						printf("\n :object_string : %s\n ",Obj_S);fflush(stdout);

						ifail=WSOM_ask_object_type2(sec_obj,&type);
						printf("\n :type \n  : %s \n ",type);fflush(stdout);

						if((tc_strcmp(type,"PDF")==0) )
						
						{

							ifail=AE_ask_all_dataset_named_refs2(sec_obj,"PDF_Reference",&count2,&ref);
							printf("\n\n\n\n cted attached count2=%d\n\n\n\n",count2); 
							for(k=0;k<count2;k++)
							{
								IMF_ask_original_file_name2(ref[k],&ref_name);
								if(ifail==ITK_ok)
								{
									printf("\n\n\t ref name:%s \n\n\n\n",ref_name);
								}
									path=(char*) MEM_alloc(sizeof(path)+100);
									tc_strcpy(path,"/tmp/");				
									///home/apldev/devgroups/Amol/CTED_releaseletter/cted_sj
									//tc_strcpy(path,"/home/apldev/devgroups/Amol/CTED_releaseletter/cted_sj/");
									tc_strcat(path,ref_name);
									ifail=AE_export_named_ref(sec_obj,"PDF_Reference",path);
									printf("\n\n\t path:%s  \n\n\n\n",path);
									tc_strcat(newpath,path);
									tc_strcat(newpath,"^");	
									if(ifail==ITK_ok)
									{
										printf("\n\n\t Export Successfull to cted release letter folder \n\n\n\n");
									}
							}

						}
								
						else if(tc_strcmp(type,"Text")==0)
						{

							ifail=AE_ask_all_dataset_named_refs2(sec_obj,"Text",&count3,&ref1);
							printf("\n\n\n\n\n cted attached count3=%d\n\n\n\n\n",count3); 
							for(j=0;j<count3;j++)
							{
								IMF_ask_original_file_name2(ref1[j],&ref_name2);
								if(ifail==ITK_ok)
								{
									printf("\n\n\t ref name2:%s",ref_name2);
								}
									path1=(char*) MEM_alloc(sizeof(path1)+100);
									tc_strcpy(path1,"/tmp/");
									tc_strcat(path1,ref_name2);
									printf("\n\n\t ref path1:%s",path1);
									ifail=AE_export_named_ref(sec_obj,"Text",path1);
									if(ifail==ITK_ok)
									{
										printf("\n\n\t Export Successfull");
									}
									tc_strcat(newpath,path1);
									tc_strcat(newpath,"^");

							}

						}
						else
						{
							printf("\n\n\t CTED letter object not found");
						}
					}
					printf("\n \n \n \n -------------newpath value---------:- %s \n \n \n", newpath);fflush(stdout);
					printf("\n\n\t AMOL-------------------------- Successfull \n\n\n");

					ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo2", &shellname));
					printf("\n\n\n\n CTEDReleaseLetterReport_mail_attch CO [usrinfo2] value:- %s\n\n\n\n", shellname);fflush(stdout);

					sprintf(cmd,"%s %s %s %s",shellname,newpath,Obj_N_Rev,CtIndSubjct);
					printf("\n\n\n \n AMOL Excuting Command =%s \n\n\n\n", cmd);fflush(stdout);
					system(cmd);
					printf("\n\n\n\n After executing Command\n\n\n");fflush(stdout);
					printf("\n\n\t AMOL1-------------------------- Successfull\n\n\n");
						
				}
		   }

		}

	}
	else
	{
		printf("\n\n\n\n control object is not found");fflush(stdout);
	}

	printf("\n tm_Dataset_Check Function end...");fflush(stdout);

	return 0;
}


//---------------------------------------------------tm_cted_release_letter_Report_mail_notification AT Assignment Buyer Code Update End -  --------------------------------------------//

//---------------------------------------------------CTED_Intimation_closed_email AT - Assignment Updation of Status By Creator Start -  --------------------------------------------//
///user/cvprod/NON_ERC_PUNE/TEST_CC/Sanjay/AMOL
int CTED_Intimation_closed_email(EPM_action_message_t  msg)					//AT - Assignment Updation of Status By Creator
{
	tag_t  roottask									= NULLTAG;
	tag_t  Rev										= NULLTAG;
	tag_t  *Attachments								= NULLTAG;
	tag_t	DmlRev_tag								= NULLTAG;
	tag_t	Reftag									= NULLTAG;
	tag_t   sec_obj									= NULLTAG;
	tag_t*	secondary_objects						= NULLTAG;							              
	char*       Obj_N								= NULL;
	char*       Obj_S								= NULL;
	int no_attach									= 0;
	int error_code									= ITK_ok;
	int i											= ITK_ok;
	int jm											= ITK_ok;
    int	ifail										= ITK_ok;
	int   count										= 0;
	tag_t	objTypTag								=NULLTAG;
	char*   ObjTyp									= NULL;
	char *Obj_N_Rev									=NULL;
	char *type										=NULL;
	int count2										=0;
	int count3										=0;
	tag_t *ref										=NULLTAG;
	tag_t *ref1										=NULLTAG;
	char *ref_name									=NULL;
	char *path										=NULL;
	int k											=0;
	char *ref_name2									=NULL;
	char *path1										=NULL;
	int j											=0;
	int targetobjects_count							= 0;
	char *newpath									=NULL;
	newpath											=(char*) MEM_alloc(sizeof(path)+100);
	char *cmd[100];
	char *shellname									=NULL;
 
	printf("\n CTED_Intimation_closed_email..");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok);
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok);
	printf("\tm_part_type_Action at at Upd of Status By Creator:No of Attachements::--------[%d]", no_attach);fflush(stdout);

	//added by amol
	int n_entries11 =	3;
	char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *CtIndSubjct = NULL;
	int resultCount=0;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	tag_t *qry_cntrlobj11= NULLTAG;
	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	{
		printf("\n CTED Control Object Query Found for CTED_wf_complete_mail_at_Upd_of_Status_By_Creator \n");fflush(stdout);    //CTED_Intimation_closed_email
		qry_values11[0] =	"CTED_wf_complete_mail_at_Upd_of_Status_By_Creator" ;		//CTED_wf_complete_mail_at_Upd_of_Status_By_Creator
		qry_values11[1] =	"active" ;
		qry_values11[2] =	"0" ;

		ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11));
		printf("\n CTED No. of control object found for CTED_wf_complete_mail_at_Upd_of_Status_By_Creator  :%d",resultCount);fflush(stdout);        // print resultCount, targetobjects_count

		if(resultCount>0)
		{		
			ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
		    printf("\n CTED Release Letter Report Cntrl OBJECT for mail_at_Upd_of_Status_By_Creator --> usrinfo1 ---> [ %s ]\n", usrinf1);fflush(stdout);
		}
	}

	//end 
 
	if(resultCount>0)
	{
		if(no_attach >0)
		{
			for(jm=0;jm<no_attach;jm++)
			{
				Rev=Attachments[jm];
				if(TCTYPE_ask_object_type(Rev,&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n : Workfow obj type at Upd of Status By Creator : [%s]\n\n\n", ObjTyp);fflush(stdout);
				if(tc_strcmp(ObjTyp,"T5_CTEDRevision")==0)
				{
					ifail = ITEM_ask_latest_rev(Rev,&DmlRev_tag); 

					ifail=AOM_UIF_ask_value(Rev,"item_id",&Obj_N_Rev);
					printf("\n :object_name at Upd of Status By Creator : %s\n ",Obj_N_Rev);fflush(stdout);

					ifail=AOM_UIF_ask_value(Rev,"t5_CtIndSubjct",&CtIndSubjct);
					printf("\n :CtIndSubjct at Upd of Status By Creator : %s\n ",CtIndSubjct);fflush(stdout);
					
					ifail = GRM_find_relation_type("IMAN_reference",&Reftag);
					printf("\n :rel found at Upd of Status By Creator \n ");fflush(stdout);
					ifail = GRM_list_secondary_objects_only(Rev,Reftag,&count,&secondary_objects);
					printf("\n :Dataset Count is at Upd of Status By Creator : %d\n ",count);fflush(stdout);
					tc_strcpy(newpath,"");
	 
					for (i=0; i< count; i++)
					{
						sec_obj=secondary_objects[i];
	 
						ifail=AOM_UIF_ask_value(sec_obj,"object_name",&Obj_N);
						printf("\n :object_name at Upd of Status By Creator: %s\n ",Obj_N);fflush(stdout);
	 
						ifail=AOM_UIF_ask_value(sec_obj,"object_string",&Obj_S);
						printf("\n :object_string at Upd of Status By Creator : %s\n ",Obj_S);fflush(stdout);

						ifail=WSOM_ask_object_type2(sec_obj,&type);
						printf("\n :type at Upd of Status By Creator \n  : %s \n ",type);fflush(stdout);

//						if((tc_strcmp(type,"PDF")==0) )
//						
//						{
//
//							ifail=AE_ask_all_dataset_named_refs2(sec_obj,"PDF_Reference",&count2,&ref);
//							printf("\n\n\n\n cted attached count2=%d\n\n\n\n",count2); 
//							for(k=0;k<count2;k++)
//							{
//								IMF_ask_original_file_name2(ref[k],&ref_name);
//								if(ifail==ITK_ok)
//								{
//									printf("\n\n\t ref name:%s \n\n\n\n",ref_name);
//								}
//									path=(char*) MEM_alloc(sizeof(path)+100);
//									tc_strcpy(path,"/tmp/");				
//									///home/apldev/devgroups/Amol/CTED_releaseletter/cted_sj
//									//tc_strcpy(path,"/home/apldev/devgroups/Amol/CTED_releaseletter/cted_sj/");
//									tc_strcat(path,ref_name);
//									ifail=AE_export_named_ref(sec_obj,"PDF_Reference",path);
//									printf("\n\n\t path:%s  \n\n\n\n",path);
//									tc_strcat(newpath,path);
//									tc_strcat(newpath,"^");	
//									if(ifail==ITK_ok)
//									{
//										printf("\n\n\t Export Successfull to cted release letter folder \n\n\n\n");
//									}
//							}
//
//						}
								
						if(tc_strcmp(type,"Text")==0)

						{

							ifail=AE_ask_all_dataset_named_refs2(sec_obj,"Text",&count3,&ref1);
							printf("\n\n\n\n\n cted attached count3 at Upd of Status By Creator=%d\n\n\n\n\n",count3); 
							for(j=0;j<count3;j++)
							{
								IMF_ask_original_file_name2(ref1[j],&ref_name2);
								if(ifail==ITK_ok)
								{
									printf("\n\n\t ref name2 at Upd of Status By Creator:%s",ref_name2);
								}
									path1=(char*) MEM_alloc(sizeof(path1)+100);
									tc_strcpy(path1,"/tmp/");
									tc_strcat(path1,ref_name2);
									printf("\n\n\t ref path1 at Upd of Status By Creator :%s",path1);
									ifail=AE_export_named_ref(sec_obj,"Text",path1);
									if(ifail==ITK_ok)
									{
										printf("\n\n\t Export Successfull at Upd of Status By Creator");
									}
									tc_strcat(newpath,path1);
									tc_strcat(newpath,"^");

							}

						}
						else
						{
							printf("\n\n\t CTED letter object not found at Upd of Status By Creator");
						}
					}
					printf("\n \n \n \n -------------newpath value at Upd of Status By Creator---------:- %s \n \n \n", newpath);fflush(stdout);
					printf("\n\n\t AMOL-------------------------- Successfull at Upd of Status By Creator \n\n\n");

					ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo2", &shellname));
					printf("\n\n\n\n CTEDReleaseLetterReport mail at Upd of Status By Creator CO [usrinfo2] value:- %s\n\n\n\n", shellname);fflush(stdout);

					sprintf(cmd,"%s %s %s %s",shellname,newpath,Obj_N_Rev,CtIndSubjct);
					printf("\n\n\n \n AMOL Excuting Command at Upd of Status By Creator =%s \n\n\n\n", cmd);fflush(stdout);
					system(cmd);
					printf("\n\n\n\n After executing Command at Upd of Status By Creator\n\n\n");fflush(stdout);
					printf("\n\n\t AMOL1-------------------------- Successfull at Upd of Status By Creator\n\n\n");
						
				}
		   }

		}

	}
	else
	{
		printf("\n\n\n\n control object is not found at Upd of Status By Creator");fflush(stdout);
	}

	printf("\n CTEDReleaseLetterReport mail at Upd of Status By Creator Function end...");fflush(stdout);

	return 0;
}

//---------------------------------------------------CTED_Intimation_closed_email AT Assignment Updation of Status By Creator End -  --------------------------------------------//


int tm_CTED_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	tag_t new_item				= NULLTAG;
	tag_t item_master_form		= NULLTAG;
	tag_t item_rev_master_form  = NULLTAG;
	int isnew              = 0;		
	
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	tag_t relation_type, relation, propTag = NULLTAG;
	char*			WrkRcd_no1			= NULL;
	char*			TicRepo_no			= NULL;

	printf("\n Inside CTED Creation >> tm_CTED_set_init_val \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	tag_t qryTagCntrlobj = NULLTAG;
	tag_t qryTagCntrlobj1 = NULLTAG;
	tag_t *list_of_cntrl_tags = NULLTAG;
	tag_t *list_of_cntrl_tags1 = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	CTED_item_id		= NULL;
	char*	BscDmlA			= NULL;
	char*	BscDml			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[100]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s \n",CurrYear);fflush(stdout);
	
	
	
	printf("\n Current CTED String >> %s \n",BscDml);fflush(stdout);
	if(new_item != NULLTAG && isnew==1)
	{
		tag_t			CTEDTagrev		= NULLTAG;
		if(ITEM_ask_latest_rev(new_item,&CTEDTagrev));
		
		AOM_ask_value_string( CTEDTagrev, "item_id", &CTED_item_id);
		printf("\n CTED_item_id >> %s \n",CTED_item_id);fflush(stdout);

		tag_t template_tag = NULLTAG;
		tag_t test_job_a = NULLTAG;
		int attachment_types = 1;

		char* ECR_Number = NULL;
		
		ITKCALL(EPM_find_template2("CTED Tool Intimation WF",0,&template_tag));
		if (template_tag!=NULLTAG)
		{
			ITKCALL(AOM_ask_value_string( CTEDTagrev, "object_string", &ECR_Number));
			printf("\n ECR_Number is : %s",ECR_Number);fflush(stdout);
		
			ITKCALL(EPM_create_process(ECR_Number,"",template_tag,1, &CTEDTagrev,&attachment_types,&test_job_a));
			
			printf("\n Submit CTED in to workflow process complete\n");fflush(stdout);							
		}
		
		//-----------------Code For releation Creation work order with CTED-----------------------------------------//

		(AOM_ask_value_string(CTEDTagrev,"t5_CtdWRNumber",&WrkRcd_no1));							//wrkrecd no.      T5_CTHasWrk
		 printf("\n CTED : Code For releation Creation work order with CTED :%s  \n",WrkRcd_no1);	
		 fflush(stdout);

        if (WrkRcd_no1 != NULL) // plj
		{
		char *qry_entryCntrlformat[1] = {"ID"};
        char **qry_valuesCntrlformat = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound = 0;
        int n_entryCntrlobj = 1;

        if (QRY_find2("CTED_WORKRECORDS_Qry", &qryTagCntrlobj));

        if (qryTagCntrlobj)
        {
            printf("\n WrokRec Control Object Query Found \n");
            fflush(stdout);
            qry_valuesCntrlformat[0] = WrkRcd_no1;

            if (QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags))
                ;
        }
		if (controlObjfound > 0)
		{
			tag_t WrkRcd_obj = list_of_cntrl_tags[0];

			GRM_find_relation_type("T5_CTHasWrk", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(CTEDTagrev, WrkRcd_obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);
		}
		else
		 {
			 printf("\t WrokRec Control Object Query Not Found \n");
			fflush(stdout);
		}
		
	}

			//-----------------Code For releation Creation trial Report with CTED-----------------------------------------//

		(AOM_ask_value_string(CTEDTagrev,"t5_TicRepon",&TicRepo_no));							//TicRepo_no no.      T5_CTHasWrk
		 printf("\n CTED : Code For releation Creation trial Report with CTED :%s  \n",TicRepo_no);	
		 fflush(stdout);
        
		if (TicRepo_no != NULL) // plj
      
		{
		char *qry_entryCntrlformat1[1] = {"ID"};
        char **qry_valuesCntrlformat1 = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound1 = 0;
        int n_entryCntrlobj1 = 1;

        if (QRY_find2("Trial_Report_NumQry", &qryTagCntrlobj1));

        if (qryTagCntrlobj1)
        {
            printf("\n CTED trial Report Control Object Query Found_1113322 \n");
            fflush(stdout);
            qry_valuesCntrlformat1[0] = TicRepo_no;

            if (QRY_execute(qryTagCntrlobj1, n_entryCntrlobj1, qry_entryCntrlformat1, qry_valuesCntrlformat1, &controlObjfound1, &list_of_cntrl_tags1))
                ;
        }
		if (controlObjfound1 > 0)
		{
			tag_t TicRepo_obj = list_of_cntrl_tags1[0];

			GRM_find_relation_type("T5_CTHasTraiRp", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(CTEDTagrev, TicRepo_obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);
		}
		else
		 {
			 printf("\t CTED trial Report Control Object Query Not Found \n");
			fflush(stdout);
		}

		}


	}
	return 0;
}

//-----------------------------------trial Report start--------------------------//   T5_TICtr PLJ

int tm_TrialReport_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	tag_t new_item				= NULLTAG;
	tag_t item_master_form		= NULLTAG;
	tag_t item_rev_master_form  = NULLTAG;
	int isnew              = 0;		
	
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	tag_t relation_type, relation, propTag = NULLTAG;
	char*			WrkRcd_no			= NULL;

	printf("\n Inside Trial Repor Creation >> tm_TrialReport_set_init_val PravinJ \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	tag_t qryTagCntrlobj = NULLTAG;
	tag_t *list_of_cntrl_tags = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	TrialReport_item_id		= NULL;
	char*	BscDmlA			= NULL;
	char*	BscDml			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[100]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s \n",CurrYear);fflush(stdout);
	
	
	
	printf("\n Current Trial Report String >> %s \n",BscDml);fflush(stdout);
	if(new_item != NULLTAG && isnew==1)
	{
		tag_t			TrialTagrev		= NULLTAG;
		if(ITEM_ask_latest_rev(new_item,&TrialTagrev));
		
		AOM_ask_value_string( TrialTagrev, "item_id", &TrialReport_item_id);
		printf("\n Trial_item_id >> %s \n",TrialReport_item_id);fflush(stdout);

		tag_t template_tag = NULLTAG;
		tag_t test_job_a = NULLTAG;
		int attachment_types = 1;

		char* ECR_Number = NULL;
		
		ITKCALL(EPM_find_template2("Trial Report Workflow",0,&template_tag));
		if (template_tag!=NULLTAG)
		{
			ITKCALL(AOM_ask_value_string( TrialTagrev, "object_string", &ECR_Number));
			printf("\n ECR_Number is : %s",ECR_Number);fflush(stdout);
		
			ITKCALL(EPM_create_process(ECR_Number,"",template_tag,1, &TrialTagrev,&attachment_types,&test_job_a));
			
			printf("\n Submit Trial Report in to workflow process complete\n");fflush(stdout);							
		}
		
		//-----------------Code For releation Creation work order with Trial Report-----------------------------------------// PLJ releation

		(AOM_ask_value_string(TrialTagrev,"t5_TICPeSrNoR",&WrkRcd_no));							//wrkrecd no.      T5_TraiRpHasWrkRev
		 printf("\n CTED : Code For releation Creation work order with CTED :%s  \n",WrkRcd_no);	
		 fflush(stdout);


		char *qry_entryCntrlformat[1] = {"ID"};
        char **qry_valuesCntrlformat = (char **)MEM_alloc(5 * sizeof(char *));

        int controlObjfound = 0;
        int n_entryCntrlobj = 1;

        if (QRY_find2("CTED_WORKRECORDS_Qry", &qryTagCntrlobj))
            ;

        if (qryTagCntrlobj)
        {
            printf("\n Trial_rpt WrokRec Control Object Query Found \n");
            fflush(stdout);
            qry_valuesCntrlformat[0] = WrkRcd_no;

            if (QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags))
                ;
        }
		if (controlObjfound > 0)
		{
			tag_t WrkRcdTrial_obj = list_of_cntrl_tags[0];

			GRM_find_relation_type("T5_TraiRpHasWrkRev", &relation_type);
	   //	GRM_create_relation(TaskTagrev, rev, relation_type,  NULLTAG, &relation);
			GRM_create_relation(TrialTagrev, WrkRcdTrial_obj, relation_type, NULLTAG, &relation);
			GRM_save_relation(relation);
		}
		else
		 {
			 printf("\t WrokRec Control Object Query Not Found \n");
			fflush(stdout);
		}

		// PLJ releation
		
	}
	return 0;
}

//-----------------------------------trial Report End--------------------------//   T5_TICtr

//-----------------------------------Work Record start--------------------------//   T5_TICtr PLJ

int tm_WorkRecord_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	tag_t new_item				= NULLTAG;
	tag_t item_master_form		= NULLTAG;
	tag_t item_rev_master_form  = NULLTAG;
	int isnew              = 0;		
	
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	tag_t relation_type, relation, propTag = NULLTAG;
	char*			WrkRcd_no			= NULL;

	printf("\n Inside Work Record Creation >> tm_WorkRecord_set_init_val PravinJ \n");fflush(stdout);
	
	tag_t object = NULLTAG;
	tag_t qryTagCntrlobj = NULLTAG;
	tag_t *list_of_cntrl_tags = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	WorkRecord_item_id		= NULL;
	char*	BscDmlA			= NULL;
	char*	BscDml			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[100]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s \n",CurrYear);fflush(stdout);
	
	
	
	printf("\n Current Work Record String >> %s \n",BscDml);fflush(stdout);
	if(new_item != NULLTAG && isnew==1)
	{
		tag_t			TrialTagrev		= NULLTAG;
		if(ITEM_ask_latest_rev(new_item,&TrialTagrev));
		
		AOM_ask_value_string( TrialTagrev, "item_id", &WorkRecord_item_id);
		printf("\n WorkRecord_item_id >> %s \n",WorkRecord_item_id);fflush(stdout);

		tag_t template_tag = NULLTAG;
		tag_t test_job_a = NULLTAG;
		int attachment_types = 1;

		char* ECR_Number = NULL;
		
		ITKCALL(EPM_find_template2("Work Record Workflow",0,&template_tag));
		if (template_tag!=NULLTAG)
		{
			ITKCALL(AOM_ask_value_string( TrialTagrev, "object_string", &ECR_Number));
			printf("\n ECR_Number is : %s",ECR_Number);fflush(stdout);
		
			ITKCALL(EPM_create_process(ECR_Number,"",template_tag,1, &TrialTagrev,&attachment_types,&test_job_a));
			
			printf("\n Submit Work Record in to workflow process complete\n");fflush(stdout);							
		}
		
		
	}
	return 0;
}

//-----------------------------------Work Record End--------------------------//   T5_TICtr


extern int tm_cted_assign_register_method(int *decision, va_list args)							//PE_Part_signoff_val_CTED
{
	METHOD_id_t  CTED_iman_save;
	METHOD_id_t  method_cted_checkin;
	METHOD_id_t  TrialReport_iman_save;
	METHOD_id_t  WorkRecort_iman_save;
	METHOD_id_t  method_WorkRecord_checkin;
	int	ifail = 0;
	
	if (ITK_ok == EPM_register_action_handler("cted_task_assigment", "", cted_task_assigment))
    {
        printf("\t\n Registered Action Handler cted_task_assigment\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler cted_task_assigment\n");
        fflush(stdout);
    }

	///-----------------------------------CTED_checkin_PreCond_Validation-----------------------------//

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_cted_checkin));
	if (method_cted_checkin.id != NULL)
	{
		
		
		ITK_CALL(METHOD_add_pre_condition(method_cted_checkin, (METHOD_function_t)CTED_checkin_PreCond_Validation, NULL));
		printf("\n cted 1method_cted_checkin found\n"); fflush(stdout);
	}
	else
	{
		printf("\n cted 1method_cted_checkin not found\n"); fflush(stdout);
		
	}

///-----------------------------------CTED_checkin_PreCond_Validation End -----------------------------------------------------//

//---------------------------------- Work_Record_IndUt_Creation Start ---------------------------------------------------------//

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_WorkRecord_checkin));					//Work_Record_IndUt_Creation
	if (method_WorkRecord_checkin.id != NULL)
	{
		//printf("\n Work_Record_IndUt_Creation found\n"); fflush(stdout);
		
		ITK_CALL(METHOD_add_pre_condition(method_WorkRecord_checkin, (METHOD_function_t)Work_Record_IndUt_Creation, NULL));
		printf("\n Work_Record_IndUt_Creation found\n"); fflush(stdout);
	}
	else
	{
		printf("\n Work_Record_IndUt_Creation not found\n"); fflush(stdout);
		
	}

//---------------------------------- Work_Record_IndUt_Creation End ------------------------------------------------------------//


//-----------------------------------tm_cted_release_letter_Report Start--------------------------------------------------------//		tm_cted_release_letter_Report

	if (ITK_ok == EPM_register_action_handler("tm_cted_release_letter_Report", "", tm_cted_release_letter_Report))
    {
        printf("\t\n Registered Action Handler tm_cted_release_letter_Report\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler tm_cted_release_letter_Report\n");
        fflush(stdout);
    }

//-----------------------------------   tm_cted_release_letter_Report End         ---------------------------------------------------------------//

//-----------------------------------   tm_cted_release_letter_Report_mail_notification Start       -------------------------------------------//		tm_cted_release_letter_Report

	if (ITK_ok == EPM_register_action_handler("tm_cted_release_letter_Report_mail_notification", "", tm_cted_release_letter_Report_mail_notification))
    {
        printf("\t\n Registered Action Handler tm_cted_release_letter_Report_mail_notification\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler tm_cted_release_letter_Report_mail_notification\n");
        fflush(stdout);
    }

//----------------------------------- ----- tm_cted_release_letter_Report_mail_notification End    ------------ ---------------------------------------------//

//---------------------------------------------------   CTED_Intimation_closed_email _EPM_register_action_handler Start      ------------------------------------------------------------------------------------------//		tm_cted_release_letter_Report

	if (ITK_ok == EPM_register_action_handler("CTED_Intimation_closed_email", "", CTED_Intimation_closed_email))
    {
        printf("\t\n Registered Action Handler CTED_Intimation_closed_email\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler CTED_Intimation_closed_email\n");
        fflush(stdout);
    }

//----------------------------------------------------       CTED_Intimation_closed_email _EPM_register_action_handler End   ---------------------------------------------------------------------------//

	ITKCALL(METHOD_find_method("T5_CTED",TC_save_msg, &CTED_iman_save));
	if (CTED_iman_save.id != NULL)
    {	
		printf("\n before Rigister tm_CTED_set_init_val");fflush(stdout);
		ITKCALL(METHOD_add_action(CTED_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_CTED_set_init_val ,NULL));
		printf("\n IN After Rigister tm_CTED_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_CTED_set_init_val  == NULL");fflush(stdout);
	}
//	//-----------------------------------trial Report--------------------------//   T5_TICtr 

	ITKCALL(METHOD_find_method("T5_TrialRepo",TC_save_msg, &TrialReport_iman_save));
	if (TrialReport_iman_save.id != NULL)
    {	
		printf("\n before Rigister tm_TrialReport_set_init_val");fflush(stdout);
		ITKCALL(METHOD_add_action(TrialReport_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_TrialReport_set_init_val ,NULL));
		printf("\n IN After Rigister tm_TrialReport_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_TrialReport_set_init_val  == NULL");fflush(stdout);
	}

	//-----------------------------------trial Report end--------------------------//   T5_TrialRepo 


	//	//-----------------------------------Work Record Report--------------------------//   T5_TICtr 

	ITKCALL(METHOD_find_method("T5_WorkRe",TC_save_msg, &WorkRecort_iman_save));
	if (WorkRecort_iman_save.id != NULL)
    {	
		printf("\n before Rigister tm_WorkRecord_set_init_val");fflush(stdout);
		ITKCALL(METHOD_add_action(WorkRecort_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_WorkRecord_set_init_val ,NULL));
		printf("\n IN After Rigister tm_WorkRecord_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_WorkRecord_set_init_val  == NULL");fflush(stdout);
	}

	//-----------------------------------Work Record Report end--------------------------//   T5_WorkRe 


//	//-----------------------------------tm_cted_release_letter_Report--------------------------//		tm_cted_release_letter_Report
//
//
//	ITKCALL(METHOD_find_method("T5_CTEDRevision",TC_save_msg, &CTED_iman_save));
//	if (CTED_iman_save.id != NULLTAG)
//    {	
//		printf("\n before Rigister tm_cted_release_letter_Report");fflush(stdout);
//		ITKCALL(METHOD_add_action(CTED_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_cted_release_letter_Report ,NULL));
//		printf("\n IN After Rigister tm_cted_release_letter_Report");fflush(stdout);
//    }
//	else
//	{
//		printf("\n IN After Rigister tm_CTED_set_init_val  == NULL");fflush(stdout);
//	}

	//-----------------------------------PE_Part_attachement_signoff_Vald--------------------------//		PE_Part_signoff_val_CTED

	if( ITK_ok == EPM_register_rule_handler ("PE_Part_signoff_val_CTED","This Handler is used to display message",(EPM_rule_handler_t)PE_Part_signoff_val_CTED))
	{
		printf("\t\n Registered Rule Handler PE_Part_signoff_val_CTED\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler PE_Part_signoff_val_CTED\n");fflush(stdout);
	}
	//-----------------------------------PE_Part_attachement_signoff_Vald--------------------------//

	//--------------------------------------------- EPM_register_rule_handler - Buyer_CodeUpdate_Assignment_signoff_validation Start //---------------------------------------------

	if(ifail == EPM_register_rule_handler("Buyer_CodeUpdate_Assignment_signoff_validation","This Handler is used to display message",(EPM_rule_handler_t)Buyer_CodeUpdate_Assignment_signoff_validation))
	{
		printf("\n Registered Rule Handler Buyer_CodeUpdate_Assignment_signoff_validation \n");
        fflush(stdout);
	}
	else
	{
		printf("\n FAILED to register Rule Handler Buyer_CodeUpdate_Assignment_signoff_validation \n");
        fflush(stdout);
	}

	//--------------------------------------------- EPM_register_rule_handler - Buyer_CodeUpdate_Assignment_signoff_validation End //---------------------------------------------
	
return (ITK_ok);	
}


extern DLLAPI int tm_cted_assign_register_callbacks()
{
    CUSTOM_register_exit("tm_cted_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_cted_assign_register_method);
 
    printf("\n registered function tm_cted_assign\n");
    fflush(stdout);
 
    return (ITK_ok);
}