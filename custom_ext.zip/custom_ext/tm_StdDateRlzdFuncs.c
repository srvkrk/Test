/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

int cntFlag = 0;

extern int DateRlzdStmpServiceFnc( void *retValue)
{
	int				ifail 	= ITK_ok;
	int n_objects = 0;
    tag_t *objects = NULL;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;	
	char *partNumber= NULL;
	char *partRevSeq= NULL;
	char *releaseStatus= NULL;
	char *itemRevSeq= NULL;
	char *date_item= NULL;
	char** bufferedXmlStrOut;
	int buff_cnt=0;	
	int m =0;
	int j =0;
	int Stat_Cnt =0;
	const char *attrs[1];
	const char *values[1];
	int n_tags_found= 0;
	tag_t *tags_found = NULL;
    int status;
	tag_t rev=NULLTAG;
	char	*part_rlsstatus				=	NULL;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	char *RlzStatusName = NULL;
	tag_t  DateRlzdDtAttrId = NULLTAG;
	tag_t  DateRlzdDtAttrId2 = NULLTAG;
	date_t apl_date_1;
	tag_t item=NULLTAG;

	USERARG_get_string_argument(&partNumber);
	USERARG_get_string_argument(&partRevSeq);
	USERARG_get_string_argument(&releaseStatus);
	USERARG_get_string_argument(&date_item);
		
		
	printf("\nArgument Received(DateRlzdStmpServiceFnc) partNumber=%s\n",partNumber);fflush(stdout);	
	printf("Argument Received(DateRlzdStmpServiceFnc) partRevSeq=%s\n",partRevSeq);fflush(stdout);	
	printf("Argument Received(DateRlzdStmpServiceFnc) releaseStatus=%s\n",releaseStatus);fflush(stdout);	
	printf("Argument Received(DateRlzdStmpServiceFnc) date_item=%s\n",date_item);fflush(stdout);	
	
	attrs[0] ="item_id";
	values[0] = (char *)partNumber;
	//Querying with item id
	ITKCALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
	if(n_tags_found>0)
	{
		printf("n_tags_found %d\n",n_tags_found);fflush(stdout);

		item = tags_found[0];
		printf("Item already exists\n");fflush(stdout);

		itemRevSeq = NULL;
		itemRevSeq=(char *) MEM_alloc(30);
		strcpy(itemRevSeq,partRevSeq);
		
		printf(" itemRevSeq [%s]\n",itemRevSeq);fflush(stdout);

		ITKCALL(ITEM_find_revision(item,itemRevSeq,&rev));
		if(rev != NULLTAG)
		{
		
			ITKCALL(AOM_UIF_ask_value(rev,"release_status_list",&part_rlsstatus));
			printf(" part_rlsstatus [%s]\n",part_rlsstatus);fflush(stdout);

			ITKCALL(ITK_string_to_date(date_item, &apl_date_1 )); 
			ITKCALL(WSOM_ask_release_status_list(rev,&Stat_Cnt,&Stat_list));

			for(j=0;j<Stat_Cnt;j++)
			{
				Stat_tag = Stat_list[j];
				ITKCALL(AOM_ask_name(Stat_tag, &RlzStatusName));
				printf("\n Part`s Release status is : %s\n",RlzStatusName);fflush(stdout);

												
				if (tc_strcmp(RlzStatusName,releaseStatus)==0)
				{
					ITKCALL(POM_attr_id_of_attr("date_released","ReleaseStatus",&DateRlzdDtAttrId));
					ITKCALL(AOM_refresh(Stat_tag,TRUE));
					ITKCALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					ITKCALL(POM_set_attr_date(1,&Stat_tag,DateRlzdDtAttrId,apl_date_1));
					//API change
					//ITKCALL(AOM_save(Stat_tag));
					ITKCALL(AOM_save_with_extensions(Stat_tag));
					ITKCALL(AOM_refresh(Stat_tag, 0 ));
					break;

				}
			}



       printf("\n Going to Set Date on Revision as STDS Flag: \n");fflush(stdout);
	
				    ITKCALL(POM_attr_id_of_attr("date_released","ItemRevision",&DateRlzdDtAttrId2));
				    ITKCALL(AOM_lock(rev));
					ITKCALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					ITKCALL(POM_set_attr_date(1,&rev,DateRlzdDtAttrId2,apl_date_1));
					// API change
               		//ITKCALL(AOM_save(rev));	
					ITKCALL(AOM_save_with_extensions(rev));				
					ITKCALL(AOM_unlock(rev));
					ITKCALL(AOM_refresh(rev, 0 ));
					
  
					printf("\n  Set Date on Revision as APL Flag Sucessfully: \n");fflush(stdout);


		}

	
	}
		
	
	

	return ifail;
}

extern int DateRlzdStmpRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 4;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;

	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n DateRlzdStmpServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("DateRlzdStmpServiceFnc",(USER_function_t)DateRlzdStmpServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_STDFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(DateRlzdStmpRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_StdDateRlzdFuncs_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_StdDateRlzdFuncs_register_callbacks...."); 
	printf("\n Before registoring userservice tm_StdDateRlzdFuncs ...."); 
	ifail=CUSTOM_register_exit ( "tm_StdDateRlzdFuncs", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_STDFuncServiceFnc);
	printf("\n After registoring userservice tm_StdDateRlzdFuncs....");
	return ( ITK_ok );
}