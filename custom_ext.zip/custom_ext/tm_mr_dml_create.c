#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <epm/epm.h>



#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define ITK_CALL(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

 //autoresizeTagMbomAddMem(cabBomLineCount,&*cabBomLineForD9Z01,t_ChildItemRev);
/* void autoresizeTagMbomAddMem(int *count,tag_t *objlist,tag_t obj )
{
        printf("\n 1234 [%d]",*count);fflush(stdout);
        char* childItemName =NULL;
        *count=*count+1;
        if(*count==1)
        {
                printf("\n hajdbjashchjhd [%d]",*count);fflush(stdout);
                (*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
        }
        else
        {
                printf("\n else [%d]",*count);fflush(stdout);
                (*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
        }
        printf("\n 9999999999 : [%d]",*count);fflush(stdout);
        (*objlist)[*count-1] = obj;
        ITK_CALL(AOM_ask_value_string((*objlist)[*count-1],"item_id",&childItemName));
        printf("\n Memory Allocated for  :[%s] ",childItemName);fflush(stdout);
} */

//int ITK_user_main(int argc,char *argv[])
int mr_dml_create(EPM_action_message_t msg)
{
	int 			ifail 				= 	ITK_ok;
	/*int 			z;
	char 			*s					=	NULL;

	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	//ITK_CALL(ITK_auto_login());
	//ITK_CALL(ITK_init_module ("infodba","infodba","dba"));
	ITK_set_bypass(true);
	ITK_CALL(ITK_set_journalling(TRUE));
	if(z==ITK_ok)
	{
		printf("\n User Id, Password, Group are Ok");
	}
	else
	{
		EMH_ask_error_text(z,&s);
		printf("\n Error: %s",s);
	} */
	//********************************************** Query control object ***************************************************
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int 	cntrlcnt					=		0;
	int  	control_number_found1		=		0;
	int     n_entryCntrl1    			= 		3;
	char 	*ctrlObj_Info1 				= 		NULL;
	tag_t   qryTagCntrl1     			= 		NULLTAG;
	tag_t 	*cntr_objects				=		NULLTAG;

	if(QRY_find("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="MBOMAplDsgGrp1";
		qry_valuesCntrl1[1]="MBOMAplDsgGrp1";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &cntr_objects))
		printf("\n Control Object Query Found after execute\n");fflush(stdout);
		printf("\n total control object found : %d",control_number_found1);fflush(stdout);
	}
	else
	{
		printf("\n Control Object Query not Found \n");fflush(stdout);
	}
	if(control_number_found1>0)
	{
		AOM_ask_value_string( cntr_objects[0], "t5_Userinfo1", &ctrlObj_Info1);
		printf("\n Information 1 : %s\n",ctrlObj_Info1);fflush(stdout);
		//********************************************** ERC DML Query *********************************************************
		if (tc_strstr(ctrlObj_Info1,"00") != NULL )
		{
			/* tag_t ERC_DML = NULLTAG;
			if(QRY_find("Item Revision...", &ERC_DML));
			if(ERC_DML != NULLTAG)
			{
				printf("\nFound Query ERCDMLTag \n"); fflush(stdout);
				int 		n_entries			=	2;
				int 		Qry_Found 			;
				tag_t 		ERCDMLObjtag 		= 	NULLTAG;
				tag_t 		*erc_DML_Result 	= 	NULLTAG;
				char 		*qry_entries[2] 	= 	{"Item ID","Type"};
				char 		**qry_values 		= 	(char **) MEM_alloc(10 * sizeof(char *));
				qry_values[0]					=	ERCDML;
				qry_values[1]					=	"ERC DML Revision";

				//
					char		*erc_dml_qry_entries[1];
					erc_dml_qry_entries[0] ="item_id";

					
				//
				 */
				//******************************************************************************************
				tag_t   rootTask   =NULLTAG;
				char*   CurrentTask  = NULL;
				//char*   parent_name   = NULL;  
				char *parent_name = NULL;    
				int      noAttachment = 0;
				tag_t*   attachments  =NULLTAG;
				char*    ERCDML  =NULL;
				int m =0;
				ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
		        printf("\n WO DML............. \n"); fflush(stdout);
				ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		        printf("\n CurrentTask: %s\n",CurrentTask);
				ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		        printf("\n Parent Name: %s\n",parent_name);fflush(stdout);         
				ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
				printf("\n Number of attachment : %s ",noAttachment);fflush(stdout);
				if(noAttachment>0)
				{

					ITK_CALL(AOM_ask_value_string(attachments[0],"item_id",&ERCDML));
					printf("\n ERCDML is : %s\n",ERCDML);fflush(stdout);
				}
			//***********************************************************************************************
				//ITKCALL(ITEM_find_item_revs_by_key_attributes(1,erc_dml_qry_entries,erc_dml_qry_values,"NR",&Qry_Found,&erc_DML_Result));
				//printf("\n Total DML found : %d",Qry_Found);fflush(stdout);
				if(noAttachment > 0)
				{
					printf("\n DML Found \n ");fflush(stdout);
					char			*ERCDMLNumber		=	NULL;
					char			*ERCDMLECNType		=	NULL;
					char 			*erc_dr_status  	= 	NULL;
					char 			*DML_no			  	= 	NULL;
					char 			*DesignGroupList  	= 	NULL;
					char 			*Proj_Code		  	= 	NULL;
					char 			*erc_dml_name	  	= 	NULL;
					char 			*erc_dml_desc	  	= 	NULL;
					char 			*erc_rel_type	  	= 	NULL;
					char 			*erc_FrmToPlnt	  	= 	NULL;
					char			*tempString			= 	NULL;
					char			*eRcbUsuNit			= 	NULL;
					char			*eRctAsknAme		= 	NULL;
					char			*Temp				= 	NULL;

					tag_t			MBOMDML				= 	NULLTAG;
					tag_t			MBOMDMLCre			= 	NULLTAG;
					tag_t			MBOMDMLRevTag		= 	NULLTAG;
					tag_t			MBOMDMLRevTagCre	= 	NULLTAG;
					tag_t			MBOMDMLTag			= 	NULLTAG;
					tag_t			MBOMDMLRevObjTag	= 	NULLTAG;
					tag_t			ErcTaskRel			= 	NULLTAG;
					tag_t			ErcTaskTag			= 	NULLTAG;


					tag_t			*ErcTask			= 	NULLTAG;
					tag_t			*ErcTask_List		= 	NULLTAG;
					tag_t			*MBOMTask_List		= 	NULLTAG;
					
					int 			Erctask_count		= 	0;
					int				ErcTaskIterator		=	0;
					int 			ErcTaskFlag			=	0;
					int 			MEM_allocator		=	1;

					char**			stringArrayMBOM		= NULL;
					stringArrayMBOM = (char**)malloc( 10 * sizeof *stringArrayMBOM );
					tag_t 		ERCDMLObjtag 		= 	NULLTAG;
					//ITKCALL(ITEM_ask_latest_rev(erc_DML_Result[0],&ERCDMLObjtag));
					ERCDMLObjtag = attachments[0];

					AOM_ask_value_string(ERCDMLObjtag,"item_id",&ERCDMLNumber);
					AOM_ask_value_string(ERCDMLObjtag, "current_id", &DML_no);
					AOM_ask_value_string(ERCDMLObjtag,"t5_crdesigngroup",&DesignGroupList);
					AOM_ask_value_string(ERCDMLObjtag, "t5_cprojectcode", &Proj_Code);
					AOM_ask_value_string(ERCDMLObjtag, "object_name", &erc_dml_name);
					AOM_ask_value_string(ERCDMLObjtag, "object_desc", &erc_dml_desc);
					AOM_ask_value_string(ERCDMLObjtag, "t5_rlstype", &erc_rel_type);
					AOM_ask_value_string(ERCDMLObjtag, "t5_cDRstatus", &erc_dr_status);
					AOM_ask_value_string(ERCDMLObjtag, "t5_PlntToPlnt", &erc_FrmToPlnt);
					AOM_ask_value_string(ERCDMLObjtag, "t5_ERCBusiUt", &eRcbUsuNit);
					AOM_ask_value_string(ERCDMLObjtag, "object_type", &Temp);

					printf("\n ERC DML Number 			: %s\n",ERCDMLNumber);fflush(stdout);
					printf("\n Proj_Code 				: %s\n",Proj_Code);fflush(stdout);
					printf("\n DML_no 					: %s\n",DML_no);fflush(stdout);
					printf("\n DesignGroup 				: %s\n",DesignGroupList);fflush(stdout);
					printf("\n ERC DML Name  			: %s\n",erc_dml_name);fflush(stdout);
					printf("\n ERC DML Desc  			: %s\n",erc_dml_desc);fflush(stdout);
					printf("\n ERC DML Release Type  	: %s\n",erc_rel_type);fflush(stdout);
					printf("\n ERC DML Status  			: %s\n",erc_dr_status);fflush(stdout);
					printf("\n Businedd Unit  			: %s\n",eRcbUsuNit);fflush(stdout);
					printf("\n Object Type ERC DML		: %s\n",Temp);fflush(stdout);

					GRM_find_relation_type("T5_DMLTaskRelation",&ErcTaskRel);
					GRM_list_secondary_objects_only	(ERCDMLObjtag, ErcTaskRel, &Erctask_count,&ErcTask);

					printf("\n Total ERC Task found : %d",Erctask_count);fflush(stdout);
					//autoresizeTagMbomAddMem(Erctask_count,&*ErcTask_List,ErcTaskTag);
					
					for(ErcTaskIterator = 0 ; ErcTaskIterator < Erctask_count ; ErcTaskIterator++)
					{
						ErcTaskTag = ErcTask[ErcTaskIterator];
						AOM_ask_value_string(ErcTaskTag,"item_id",&eRctAsknAme);
						printf("\n ERC Task Name 			: %s\n",eRctAsknAme);fflush(stdout);
						
						if(!tc_strstr (eRctAsknAme,"BOM") && !tc_strstr (eRctAsknAme,"APL") && !tc_strstr (eRctAsknAme,"STD"))
						{	
							printf("\n ErcTaskFlag : %d\n",ErcTaskFlag);fflush(stdout);
							//(*ErcTask_List) = (tag_t *)malloc(MEM_allocator * sizeof(tag_t ));
							//ErcTask_List[ErcTaskFlag] = ErcTaskTag;
							//autoresizeTagMbomAddMem(ErcTaskFlag,&ErcTask_List,ErcTaskTag);
							if(ErcTaskFlag == 0)
							{
								 (ErcTask_List) = (tag_t* )malloc((1 ) * sizeof(tag_t ));
							}
							else
							{
								(ErcTask_List) = (tag_t* )realloc((ErcTask_List),(1 ) * sizeof(tag_t ));
							}
							ErcTask_List[ErcTaskFlag] = ErcTaskTag;
							AOM_ask_value_string(ErcTask_List[ErcTaskFlag],"item_id",&Temp);
							printf("\n Temp 			: %s\n",Temp);fflush(stdout);
							AOM_ask_value_string(ErcTask_List[ErcTaskFlag],"object_type",&Temp);
							printf("\n Temp ERC Task			: %s\n",Temp);fflush(stdout);
							ErcTaskFlag++;
							printf("\n After Adding to  ErcTask_List\n");fflush(stdout);
							
						}

					}

					printf("\n Before DML Creation \n ");fflush(stdout);

					ITK_CALL( TCTYPE_find_type( "T5_APLDML", NULL, &MBOMDML) );
					ITK_CALL( TCTYPE_construct_create_input( MBOMDML, &MBOMDMLCre) );

					ITK_CALL( TCTYPE_find_type( "T5_APLDMLRevision", NULL, &MBOMDMLRevTag) );
					ITK_CALL( TCTYPE_construct_create_input( MBOMDMLRevTag, &MBOMDMLRevTagCre) );

					tc_strcpy( stringArrayMBOM[0], DML_no);
					tc_strcat( stringArrayMBOM[0],"_MBOM");

					printf("\n MBOM DML Number : %s",stringArrayMBOM[0]);fflush(stdout);
					
					ITKCALL( TCTYPE_set_create_display_value( MBOMDMLCre, "item_id", 1,(const char**)stringArrayMBOM) );

					ITK_CALL( TCTYPE_set_create_display_value( MBOMDMLCre, "object_name", 1, (const char**)stringArrayMBOM));

					tc_strcpy( stringArrayMBOM[0], erc_dml_desc);
					ITK_CALL( TCTYPE_set_create_display_value( MBOMDMLCre, "object_desc", 1, (const char**)stringArrayMBOM) );

					

					ITK_CALL( AOM_tag_to_string(MBOMDMLRevTagCre, &tempString) );
					tc_strcpy( stringArrayMBOM[0], tempString);

					printf("\nTest0.D1..[%s]\n",stringArrayMBOM[0]);

					ITK_CALL( TCTYPE_set_create_display_value( MBOMDMLCre, "revision", 1,(const char**)stringArrayMBOM) );

					tc_strcpy( stringArrayMBOM[0], "NR");
					ITK_CALL( TCTYPE_set_create_display_value( MBOMDMLRevTagCre, "item_revision_id", 1, (const char**)stringArrayMBOM) );

					printf("\nTest1..\n");
					ITK_CALL( TCTYPE_create_object(MBOMDMLCre, &MBOMDMLTag) );
					ITK_CALL( TCTYPE_create_object(MBOMDMLRevTagCre, &MBOMDMLRevObjTag) );
					printf("\nTest2..\n");

					AOM_save(MBOMDMLTag);
					AOM_save(MBOMDMLRevObjTag);
					//ITK_CALL(ITEM_ask_latest_rev(MBOMDMLTag,&MBOMDMLRevTagCre));
					/* ITEM_create_item	(	const char * 	item_id,
					const char * 	item_name,
					const char * 	item_type,
					const char * 	rev_id,
					tag_t * 	item,
					tag_t * 	rev 
					)	 */	
					

					tag_t  	 TasktoDMLrel		= NULLTAG;
					tag_t  	 EDMLMDMLRel		= NULLTAG;
					tag_t	 MBOMDMLLtRev		= NULLTAG;
					tag_t	 ErcDMLLtRev		= NULLTAG;
					tag_t	 MBOMDMLType		= NULLTAG;

					char	MBOMDMLTypeName[40];

					int 	 DMLTaskIterator	= 0;
					tag_t 		*APL_DML_Result 	= 	NULLTAG;
					int APLDMLCOUNT = 0;
					const char		*erc_dml_qry_entries[1];
					erc_dml_qry_entries[0] ="item_id";
					const char		*erc_dml_qry_values[1];
					tc_strcat( ERCDML ,"_MBOM");
					erc_dml_qry_values[0] = ERCDML;
					
					
					//if(QRY_execute(ERC_DML,n_entries,qry_entries,qry_values,&Qry_Found,&erc_DML_Result));
					ITKCALL(ITEM_find_item_revs_by_key_attributes(1,erc_dml_qry_entries,erc_dml_qry_values,"NR",&APLDMLCOUNT,&APL_DML_Result));
					printf("\n Total APL DML rev found %d \n ",APLDMLCOUNT);fflush(stdout);
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&TasktoDMLrel));
					if (TasktoDMLrel != NULLTAG)
					{	
						ITK_CALL(ITEM_ask_latest_rev(MBOMDMLTag,&MBOMDMLLtRev));
						if(MBOMDMLLtRev == NULLTAG)
						{
							printf("\n No MBOM DML Revision \n ");fflush(stdout);
						}
						AOM_ask_value_string(MBOMDMLLtRev,"object_type",&Temp);
						printf("\n Temp 	MBOM		: %s\n",Temp);fflush(stdout);
						//ITK_CALL(ITEM_ask_latest_rev(ERCDMLObjtag,&ErcDMLLtRev));
						if(MBOMDMLLtRev =! NULLTAG)
						{
							int MBOMDMLTaskCount 	=		0;
							TCTYPE_ask_object_type(MBOMDMLLtRev,&MBOMDMLType);
							TCTYPE_ask_name(MBOMDMLType,MBOMDMLTypeName);
							printf("\n Secondary_object type_name is	:	%s",MBOMDMLTypeName);fflush(stdout);
							printf("\n Relation found .... Going to Create Releation ERC DML AND MBOM DML!!!");fflush(stdout);
							ITK_CALL(GRM_create_relation(ERCDMLObjtag,APL_DML_Result[0],TasktoDMLrel,NULLTAG,&EDMLMDMLRel));
							if(EDMLMDMLRel == NULLTAG)
							{
								printf("\n EDMLMDMLRel does not exist \n ");fflush(stdout);
							}
							else
							{
								ITK_CALL(GRM_save_relation(EDMLMDMLRel));
								printf("\n ERC DML to MBOM DML relation created \n");fflush(stdout);

							}
							/* for(DMLTaskIterator = 0; DMLTaskIterator < ErcTaskFlag ; DMLTaskIterator++)
							{
								//tag_t	 ERCTaskRevTag		= NULLTAG;
								//ITK_CALL(ITEM_ask_latest_rev(ErcTask_List[DMLTaskIterator],&ERCTaskRevTag));
								
								ITK_CALL(GRM_create_relation(MBOMDMLLtRev,ErcTask_List[DMLTaskIterator],TasktoDMLrel,NULLTAG,&EDMLMDMLRel));
								ITK_CALL(GRM_save_relation(EDMLMDMLRel));
								printf("\n MBOM_DML to ERC Task relation created \n");fflush(stdout);

							}
							//GRM_find_relation_type("T5_DMLTaskRelation",&ErcTaskRel);
							GRM_list_secondary_objects_only	(MBOMDMLTag, ErcTaskRel, &MBOMDMLTaskCount,&MBOMTask_List);

							printf("\n Total MBOM Task found : %d",MBOMDMLTaskCount);fflush(stdout); */
						}
					}
					printf("\n END OF CODE \n ");fflush(stdout);
					// ************************************************************* MB TASK Creation ************************************************
					/*
					tag_t	APLMRTypeTag			= NULLTAG;
					tag_t	APLMRCreInTag		= NULLTAG;
					tag_t	APLMRRevTypeTag		= NULLTAG;
					tag_t	APLMRRevCreInTag		= NULLTAG;
					tag_t	APLMRTaskTag			= NULLTAG;
					tag_t 	APLMRTaskRevTag	    = NULLTAG;
					int		l_strings		  =	500;
					int		index			  =	0;
					int		n_strings		  =	1;
					
					//char**			stringArrayAPLT		=	NULL;
					char*	tempStringt1		  = NULL;
					char 	*APLTaskID			= NULL;
					char 	*APLTaskName		= NULL;

					char**	stringArrayMR	  =	NULL;
					//stringArrayMR = (char**)malloc(20 * sizeof *stringArrayMR );
							
					stringArrayMR = (char**)malloc( n_strings * sizeof *stringArrayMR );
					for( index=0; index<n_strings; index++ )
					{
						stringArrayMR[index] = (char*)malloc( l_strings + 1 );
					}
					
					ITKCALL( TCTYPE_find_type("T5_APLTask", NULL, &APLMRTypeTag) );
					printf("\n Query Found ... T5_APLTask \n");fflush(stdout);
					if(APLMRTypeTag != NULLTAG)
					{
						ITKCALL( TCTYPE_construct_create_input( APLMRTypeTag, &APLMRCreInTag) );
						ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &APLMRRevTypeTag) );
						ITKCALL( TCTYPE_construct_create_input( APLMRRevTypeTag, &APLMRRevCreInTag) );

						tc_strcpy( stringArrayMR[0],DML_no);
						tc_strcat( stringArrayMR[0],"_MB_MBOM");
						printf("\n Task number  : %s \n",stringArrayMR[0]);fflush(stdout);
						ITKCALL( TCTYPE_set_create_display_value( APLMRCreInTag, "item_id", 1,(const char**)stringArrayMR) );
						printf("\n item_id/Task id : %s\n", stringArrayMR[0]);fflush(stdout);
						tc_strcpy( stringArrayMR[0],DML_no);
						tc_strcat( stringArrayMR[0],"_MB_MBOM");
						ITKCALL( TCTYPE_set_create_display_value( APLMRCreInTag, "object_name", 1,(const char**)stringArrayMR) );
						printf("\n Task Name ...%s\n",stringArrayMR[0]);fflush(stdout);

						tc_strcpy( stringArrayMR[0],erc_dml_desc);
						ITKCALL( TCTYPE_set_create_display_value( APLMRCreInTag, "object_desc", 1,(const char**)stringArrayMR) );
						printf("\n Task Description  ...%s\n", stringArrayMR[0]);fflush(stdout);
						ITKCALL( AOM_tag_to_string(APLMRRevCreInTag, &tempStringt1) );
						tc_strcpy( stringArrayMR[0],tempStringt1);
						ITKCALL( TCTYPE_set_create_display_value( APLMRCreInTag,"revision", 1,(const char**) stringArrayMR) );
						printf("\n Task Revision  : %s \n",stringArrayMR[0]);fflush(stdout);


						tc_strcpy( stringArrayMR[0], "A");
						ITKCALL( TCTYPE_set_create_display_value( APLMRRevCreInTag,"item_revision_id", 1,(const char**)stringArrayMR) );
						printf("\n Task Item Revision  : %s \n",stringArrayMR[0]);fflush(stdout);

						tc_strcpy( stringArrayMR[0], "00");
						ITKCALL( TCTYPE_set_create_display_value( APLMRRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayMR) );
						printf("\n Task Design Group : %s \n",stringArrayMR[0]);fflush(stdout);

						tc_strcpy( stringArrayMR[0],Proj_Code);
						ITKCALL( TCTYPE_set_create_display_value( APLMRRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayMR) );
						printf("\n Task Project Code : %s \n",stringArrayMR[0]);fflush(stdout);
						ITKCALL( TCTYPE_create_object( APLMRCreInTag, &APLMRTaskTag) );
						ITKCALL( AOM_save(APLMRTaskTag));
						ITKCALL(ITEM_ask_latest_rev(APLMRTaskTag,&APLMRTaskRevTag));
						printf("\n Save APL TASK ITEM AND REV\n");fflush(stdout);
						if (APLMRTaskTag!=NULLTAG)
						{
							printf("\n TASK ITEM IS CREATED\n");fflush(stdout);
							if (APLMRTaskRevTag!=NULLTAG)
							{
								printf("\n TASK ITEM REV IS CREATED\n");fflush(stdout);
							}
							else
							{
								printf("\n TASK ITEM REV IS NOT CREATED\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n TASK ITEM IS NOT CREATED\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n APL Qurey Not Found !!!!!! ");fflush(stdout);
					}
					*/
				}
				else
				{
					printf("\n No DML found");fflush(stdout);
				}
			/* }	
			else 
			{
				printf("\n Query Not Found !!!!!!!"); fflush(stdout);
				//ifail = POM_logout(false);
			} */
		}
		else
		{
			printf("\n Design Group not 00 \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n No Control Object Found \n");fflush(stdout);
	}
  return ifail;
}

/* int mr_dml_create(EPM_action_message_t msg)
{
	int 			status;
	int				ifail 				=	ITK_ok;
	char 			*selectedVehicle	=	NULL;
	char 			*selectedVehRev		=	NULL;
	char 			*selectedVehSeq		=	NULL;
	char 			*selectedTask		= 	NULL;
	char 			*userName			= 	NULL;
	
	printf("\n I am in main program");fflush(stdout);
	AOM_ask_value_string(ERCDMLObjtag,"item_id",&ERCDMLNumber);
	AOM_ask_value_string(ERCDMLObjtag, "current_id", &DML_no);
	printf("\n Input selectedVehicle :: %s ",selectedVehicle);fflush(stdout);
	printf("\n Input selectedVehRev :: %s ",selectedVehRev);fflush(stdout);
	printf("\n Input selectedVehSeq :: %s ",selectedVehSeq);fflush(stdout);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	printf("\n Input userName :: %s ",userName);fflush(stdout);

	return ifail;
} */



extern int mr_dml_create_register_method(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 5;
	int retValueType;
	//int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	char* objTag = va_arg(args, char*);
	
	//inputArgTypes[0] = USERARG_STRING_TYPE; //vehicle Number
		
	//retValueType = USERARG_STRING_TYPE ; 
	printf("\n mr_dml_create_register_method before....mr_dml_create_register");fflush(stdout);  
	if( ITK_ok == EPM_register_action_handler("mr_dml_create", "", mr_dml_create))
   {
		printf("\t\n Registered Action Handler mr_dml_create_register_method\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler mr_dml_create_register_method\n");fflush(stdout);
   }
	return ifail;
	
}

extern DLLAPI int mr_dml_create_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ModCabBomRest");fflush(stdout); 
	ifail = CUSTOM_register_exit("tm_mr_dml_create", "USER_init_module",(CUSTOM_EXIT_ftn_t)9);
	printf("\n After registering userservice....tm_mr_dml_create");fflush(stdout);
	return(ITK_ok);
}