#include "TMLLibrary_server_exits.h"


EPM_decision_t tm_SubModuleValiRule(EPM_rule_message_t msg)
{
	int no_attach	=  0;
	int	i	=  0;
	int	submod_rsltCount	=  0;
	tag_t	roottask        =  NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char*	CurrentTask		= NULL;
	char	*PlntToPlnt		= NULL;
	char	*TskNm			= NULL;
	char	*FromPlnt		= NULL;
	char	*rev_idd		= NULL;
	char	*DMLtype		= NULL;
	char	*inTaskDsgGrp		= NULL;
	char	*TaskDsgGrp		= NULL;
	char	*BomComInfo9		= NULL;
	char	*DMLBUnit		= NULL;
	char	*Partno		= NULL;
	char	*Toplnt		= NULL;
	char	*PartMstr_no		= NULL;
	char	*rel_sstatss =NULL;
	char	*Obj_PrtTypp =NULL;
	char	*rev_iiddd =NULL;
	char	*PrtDRstuss =NULL;
	char	*ChildPartQty =NULL;
	char	*PrtProjjj =NULL;
	char	*MDLAddress =NULL;
	char	*sChildMdlAddd =NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   *ObjTyp=  NULL;
	int	rel_status_cunt	=  0;
	int	NManSOAddFlag	=  0;
	int	iNManSODupFlag	=  0;
	int	ii	=  0;
	int	jk	=  0;
	int	NManMOAddFlag	= 0;
	int	iChildPartQty	= 0;
	int	iChildqty	= 0;
	int	mdlcunt	= 0;
	int	VCChildCunt	= 0;
	int	piStringCount	= 0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	chkBOMComFlag	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	iManSOFlag	= 0;
	int	iManMOErrFlag	= 0;
	int	ManSOAddFlag	= 0;
	int	iManSODupFlag	= 0;
	int	CMRefcount	= 0;
	int	ManMOAddFlag	= 0;
	int	iChild	= 0;
	int	Tskcnt	= 0;
	int MDLrulefound =0;
	int     MDL_n_entry2    = 2;
	int     MDL_n_entry3    = 2;
	int     MDL_n_entry4    = 2;
	int     submod_n_entry    = 1;
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     iBOMComp      =  0;
	int     iBomComInfo2      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	int     CPModuleAvailFlag      =  0;
	int     sCPModuleFlag      =  0;
	int     Conut_Mst      =  0;
	int     iChildd      =  0;
	int     iQtyAflag      =  0;
	int     cnt_ccvcls      =  0;
	int     RelRevFlag      =  0;
	int     DR_rsltCount      =  0;
	int     MDL_rsltCount2      =  0;
	int     MDL_rsltCount3      =  0;
	int     MDL_rsltCount4      =  0;
	int j =0;
	int countt =0;

	char **MDLrulevalueXO = NULL;
	char **MDLrulenameXO = NULL;
	char   *sChildMdlAdd =NULL;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *BomComInfo1 =NULL;
	char   *Prtrel_status =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;
	char   *p_child_item_id=NULL;
	char   *rel_sstats=NULL;
	char   *Obj_PrtTyp=NULL;
	char   *rev_iidd=NULL;
	char   *PrtDRstus=NULL;
	char   *PrtProjj=NULL;
	char   *PartTyp =NULL;
	char   *submodvali1 =NULL;
	char   *submodvali2 =NULL;
	char   *submodvali3 =NULL;
	char   *submodvali4 =NULL;
	char   *BOMComp =NULL;
	char   *DMLProj =NULL;
	char	*sUnladenWeightt		=  NULL;
	char	*sdegreesWttDup		=  NULL;
	char	*sdegreesWtt		=  NULL;
	char	*sPrtColInd		=  NULL;
	char	*PartPlfFrm		=  NULL;

	char	*sWeightRollup		=  NULL;
	char	*sDMLBUnit		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*AttrVal		=  NULL;
	char	*ErorStrg		=  NULL;
	char	*sdegreesWttDupp		=  NULL;
	char	*eptr		=  NULL;
	char	*sUnladenWeight		=  NULL;
	char	*sDMLDR		=  NULL;
	char **	AStringList =NULL;
	char **	BStringList =NULL;
	char **	CStringList =NULL;
	char **	DStringList =NULL;
	char DRStrng[20];
	char	*BomComInfo7		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char   *sPartObjyp =  NULL;
	tag_t *MDLclosureruleee = NULLTAG;
	tag_t	p_window 	= NULLTAG;
	tag_t	MDLClosureTag 	= NULLTAG;
	tag_t	MDL_rule 	= NULLTAG;
	tag_t	p_top_line 	= NULLTAG;
	tag_t *VCChildobject=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*submodTag = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTagg 		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *ClsObjTag= NULLTAG;
	tag_t   *MDL_Obj_Tag      = NULLTAG;
	tag_t   *MDL_Obj_Tag3      = NULLTAG;
	tag_t   *MDL_Obj_Tag4      = NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   *ccvMstrTag      = NULLTAG;
	tag_t   part_tsk_rel_typ      = NULLTAG;
	tag_t   master     = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	tag_t   MdlQry_Tag     = NULLTAG;
	tag_t   MdlQry_Tag3     = NULLTAG;
	tag_t   MdlQry_Tag4     = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t submodqryTag =NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	logical is_latest;
	char    *submod_qry_entry[1]  = {"SYSCD"};
	char    *MDL_qry_entry2[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry3[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry4[2]  = {"SYSCD","SUBSYSCD"};
	char    **submod_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values3     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values4     =  (char **) MEM_alloc(50 * sizeof(char *));
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLBUnit =(char *) MEM_alloc(40 * sizeof(char *));
	sDMLDR =(char *) MEM_alloc(20 * sizeof(char *));
	ErorStrg =(char *) MEM_alloc(200 * sizeof(char *));
	sUnladenWeightt =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWttDup =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWtt =(char *) MEM_alloc(200 * sizeof(char *));
	EPM_decision_t decision = EPM_go;

	printf("\n tm_SubModuleValiRule Function started...");fflush(stdout);
	TC_write_syslog("\n tm_SubModuleValiRule Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n tm_SubModuleValiRule: Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n tm_SubModuleValiRule :CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_SubModuleValiRule:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n tm_SubModuleValiRule: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find2("ControlObjects", &submodqryTag));
			if (submodqryTag)
			{
				printf("\n tm_SubModuleValiRule:P7:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n tm_SubModuleValiRule:P8:Not Found Query ControlObjects \n");fflush(stdout);
			}

			submod_qry_values2[0] = "SUBMODVAL";
			if(QRY_execute(submodqryTag, submod_n_entry, submod_qry_entry, submod_qry_values2, &submod_rsltCount, &submodTag));
			printf(" \n tm_SubModuleValiRule:P9:submod_rsltCount :%d:", submod_rsltCount); fflush(stdout);
			if(submod_rsltCount > 0)
			{
				//ON/OFF and DR0/AR0 not considered for Veh DML
				if (AOM_ask_value_string(submodTag[0],"t5_Userinfo1",&submodvali1)!=ITK_ok)   PrintErrorStack();

				// FROM to Plant not considered for GM DML-TODR
				if (AOM_ask_value_string(submodTag[0],"t5_Userinfo2",&submodvali2)!=ITK_ok)   PrintErrorStack();
				//Part type to check BOM: ,V,VCCR,
				if (AOM_ask_value_string(submodTag[0],"t5_Userinfo3",&submodvali3)!=ITK_ok)   PrintErrorStack();
				//Closure rule on off
				if (AOM_ask_value_string(submodTag[0],"t5_Userinfo4",&submodvali4)!=ITK_ok)   PrintErrorStack();
				printf(" \n tm_SubModuleValiRule:P9:submod_rsltCount submodvali1:%s: submodvali2 %s submodvali3 %s submodvali4 %s", submodvali1,submodvali2,submodvali3,submodvali4); fflush(stdout);
			}


			if(tc_strstr(submodvali1,"M001") == NULL)
			{
				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					if(tc_strstr(submodvali1,"M002") == NULL)
					{

						printf("\n tm_SubModuleValiRule:P12:inside T5_ChangeTaskRevision .....\n");fflush(stdout);
						//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						printf("\n tm_SubModuleValiRule:P13:sDMLtaskno:[%s].",sDMLtaskno);fflush(stdout);
						inTaskDsgGrp=subString(sDMLtaskno,11,2);
						printf(" tm_SubModuleValiRule :Desg Grp:[%s].",inTaskDsgGrp);fflush(stdout);
						if(tc_strstr(inTaskDsgGrp,"00") != NULL)
						{

							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n tm_SubModuleValiRule:P14:DML Revision from Task for MR : %d",countt);fflush(stdout);
								for (j=0;j<countt ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n tm_SubModuleValiRule:P15: is_latest MR is : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n tm_SubModuleValiRule:P16:is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];
										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										printf("\n tm_SubModuleValiRule:P17:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);
										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
										printf("\n tm_SubModuleValiRule:P21: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
										if(AOM_ask_value_string(DMLRevTg,"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
										printf("\n tm_SubModuleValiRule:P21:DMLBUnit:: %s ",DMLBUnit);fflush(stdout);

										tc_strcpy(sDMLDR,"");
										tc_strcpy(sDMLDR,",");
										tc_strcat(sDMLDR,DMLDR);
										tc_strcat(sDMLDR,",");
										printf("\n tm_SubModuleValiRule:P23:sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);

										if(tc_strstr(submodvali1,sDMLDR) == NULL)
										{

											if(tc_strstr(DMLtype,"Veh") != NULL)
											{
												Tskcnt=0;
													if(AOM_ask_value_tags(DMLRevTg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
													printf("\n tm_SubModuleValiRule:V:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
													if (Tskcnt>0)
													{
														for (tsk=0;tsk<Tskcnt ;tsk++ )
														{
															if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
															printf("\n tm_SubModuleValiRule:V:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

															if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
															{
																if(TaskDsgGrp) TaskDsgGrp=NULL;
																if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																TaskDsgGrp=subString(TskNm,11,2);
																printf("\n tm_SubModuleValiRule:V:P24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
																if(tc_strstr(TaskDsgGrp,"00") != NULL)
																{
																	if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																	if (tsk_CMRef_type!=NULLTAG)
																	{
																		//Getting parts from CMReferences
																		CMRefcount=0;
																		if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																		printf("\n tm_SubModuleValiRule:V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																		if(CMRefcount > 0)
																		{
																			Mstr=0;
																			for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																			{
																				printf("\n tm_SubModuleValiRule:V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																				if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																				printf("\n tm_SubModuleValiRule:V:P27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																				if(strcmp(Prt_object_type,"Folder")!=0)
																				{
																					if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																					printf("\n tm_SubModuleValiRule:V:P28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);
																					Item_count=0;
																					//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																					All_item_tag= t5GetItemRevison(PartMstr_no);
																					if(All_item_tag==NULLTAG)
																					{
																						printf("\n tm_SubModuleValiRule:V:P29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																						//return 0;
																					}
																					else
																					{
																						if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																						printf("\n tm_SubModuleValiRule:V:P30:Total rev found: %d.", Item_count);fflush(stdout);
																						if(Item_count > 0)
																						{
																							ii=0;
																							sCPModuleFlag=0;
																							for(ii=Item_count-1;ii>=0;ii--)
																							{
																								PartPlfFrm=NULL;
																								PartPlfFrm =(char *) MEM_alloc(200 * sizeof(char *));
																								rel_status_cunt=0;
																								if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_Platform", &PartPlfFrm)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																								if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																								if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																								printf("\n tm_SubModuleValiRule:V:P31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s PartPlfFrm:[%s]", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,PartPlfFrm);fflush(stdout);
																								//check revison
																								chkBOMComFlag=0;
																								printf("\n tm_SubModuleValiRule:V:P32:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);

																								printf ("\n tm_SubModuleValiRule:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																								if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																								//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																								if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																								if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																								if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																								if(BOM_set_window_top_line (p_window, NULLTAG, rev_list[ii], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();

																								printf ("\n tm_SubModuleValiRule:V:P44: PartTyp:%s \n",PartTyp);fflush(stdout);
																								if((tc_strcmp(PartTyp,"V")==0)||(tc_strcmp(PartTyp,"Vehicle")==0))
																								{
																									//if(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									if(tc_strstr(submodvali4,"CON03") == NULL)
																									{
																										printf ("\n tm_SubModuleValiRule:Veh:CON03: BOMViewClosureRuleERC applied \n");fflush(stdout);
																										if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									}
																									else
																									{
																										printf ("\n tm_SubModuleValiRule:Veh:CON03: TMLBOMExpandByQty applied \n");fflush(stdout);
																										if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									}
																								}
																								else
																								{
																									printf ("\n tm_SubModuleValiRule:V:P45:: TMLBOMExpandByQty applied \n");fflush(stdout);
																									//if(PIE_find_closure_rules("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									if(tc_strstr(submodvali4,"VC001") == NULL)
																									{
																										printf ("\n tm_SubModuleValiRule:Veh:CON03: BOMViewClosureRuleERC applied \n");fflush(stdout);
																										if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									}
																									else
																									{
																										printf ("\n tm_SubModuleValiRule:Veh:CON03: TMLBOMExpandByQty applied \n");fflush(stdout);
																										if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																									}
																								}
																								printf ("\n tm_SubModuleValiRule:GM:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																								if (MDLrulefound > 0)
																								{
																									MDLClosureTag = MDLclosureruleee[0];
																									printf ("\n tm_SubModuleValiRule:GM:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																								}
																								if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																								//0qty
																								if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																								printf("\n tm_SubModuleValiRule:GM:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);

																								printf(" tm_SubModuleValiRule: start.\n");fflush(stdout);
																								iChild=0;
																								for(iChild =0 ; iChild < VCChildCunt; iChild++)
																								{
																									p_child_item_id=NULL;
																									rel_sstats=NULL;
																									Obj_PrtTyp=NULL;
																									rev_iidd=NULL;
																									PrtDRstus=NULL;
																									PrtProjj=NULL;

																									if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																									printf("\n tm_SubModuleValiRule:GM:P48: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																									//NEED TO DISCUSS BELOW LCs
																									//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																									//If child is NR WIP, it should be in same DML.
																									if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																									{
																										if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																										printf("\n tm_SubModuleValiRule:GM:P48: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																										if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																										{
																											printf("\n tm_SubModuleValiRule:GM:P48:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																										}
																										else
																										{
																											if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																											{
																												sChildMdlAdd=NULL;
																												sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																												tc_strcpy (sChildMdlAdd,"" );
																												sChildMdlAdd = subString(p_child_item_id,4,5);
																												printf("\n tm_SubModuleValiRule:GM:P48: and  sChildMdlAdd:[%s]\n",sChildMdlAdd);fflush(stdout);
																												if(tc_strcmp(sChildMdlAdd,"Z1Z01")==0)
																												{
																													ManMOAddFlag ++;
																													printf("\n tm_SubModuleValiRule:GM:P48:module address found.:[%d] ", ManMOAddFlag);fflush(stdout);
																													printf("\n tm_SubModuleValiRule:GM:P61:FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
																													EMH_clear_errors();
																													EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"ERROR:For DR2 and above Vehicle or CR VC, 'Z1Z01' module address module is not allowed under it. Please checkout vehicle and modify BOM.");
																													decision = EPM_nogo;
																													return decision;
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
											}
										}
									}
								}
							}
						}
					}
				}
				else if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
				{
					if(tc_strstr(submodvali1,"M003") == NULL)
					{
						printf("\n tm_SubModuleValiRule:GM:P12:inside ChangeRequestRevision loop for GM DML.\n");fflush(stdout);
						//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
						printf("\n tm_SubModuleValiRule:GM:P13:sDMLno....:%s.",sDMLno);fflush(stdout);
						//DML Details:
						if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
						printf("\n tm_SubModuleValiRule:GM:P17: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
						printf("\n tm_SubModuleValiRule:GM:P21:DMLBUnit:: %s ",DMLBUnit);fflush(stdout);


						if(tc_strstr(submodvali2,PlntToPlnt) == NULL)
						{
							Tskcnt=0;
							if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
							printf("\n tm_SubModuleValiRule:GM:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
							if (Tskcnt>0)
							{
								for (tsk=0;tsk<Tskcnt ;tsk++ )
								{
									if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
									printf("\n tm_SubModuleValiRule:GM:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

									if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
										if(TaskDsgGrp) TaskDsgGrp=NULL;
										if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
										TaskDsgGrp=subString(TskNm,11,2);
										printf("\n tm_SubModuleValiRule:GM:P24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
										if(tc_strstr(TaskDsgGrp,"00") != NULL)
										{
											if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
											if (tsk_CMRef_type!=NULLTAG)
											{
												//Getting parts from CMReferences
												CMRefcount=0;
												if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
												printf("\n tm_SubModuleValiRule:GM:P25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
												if(CMRefcount > 0)
												{
													Mstr=0;
													for (Mstr=0;Mstr<CMRefcount ;Mstr++)
													{
														printf("\n tm_SubModuleValiRule:GM:P26:Design Mstr:%d",Mstr);fflush(stdout);
														if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n tm_SubModuleValiRule:GM:P27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
														if(strcmp(Prt_object_type,"Folder")!=0)
														{
															// put condition for desi rev , to avoid other attachments.
															if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
															if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
															if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
															printf("\n tm_SubModuleValiRule:GM:P28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

															Item_count=0;
															//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
															All_item_tag= t5GetItemRevison(PartMstr_no);
															if(All_item_tag==NULLTAG)
															{
																printf("\n tm_SubModuleValiRule:GM:P29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																//return 0;
															}
															else
															{
																if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																printf("\n tm_SubModuleValiRule:GM:P30:Total rev found: %d.", Item_count);fflush(stdout);
																if(Item_count > 0)
																{
																	ii=0;
																	sCPModuleFlag=0;
																	for(ii=Item_count-1;ii>=0;ii--)
																	{
																		PartPlfFrm=NULL;
																		PartPlfFrm =(char *) MEM_alloc(200 * sizeof(char *));
																		rel_status_cunt=0;
																		if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(rev_list[ii], "t5_Platform", &PartPlfFrm)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																		if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																		if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																		printf("\n tm_SubModuleValiRule:GM:P31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s PartPlfFrm:[%s]", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,PartPlfFrm);fflush(stdout);
																		//check revison
																		chkBOMComFlag=0;
																		printf("\n tm_SubModuleValiRule:GM:P32:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);

																		tc_strcpy(sPartTyp,"");
																		tc_strcpy(sPartTyp,",");
																		tc_strcat(sPartTyp,PartTyp);
																		tc_strcat(sPartTyp,",");
																		printf("\n tm_SubModuleValiRule:GM:P34:sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																		if(tc_strstr(submodvali3,sPartTyp) != NULL)
																		{
																			//Expanding first level BOM for VC
																			printf ("\n tm_SubModuleValiRule:GM:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																			if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																			if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																			if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																			if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																			if(BOM_set_window_top_line (p_window, NULLTAG, rev_list[ii], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																			//0qty
																			printf ("\n tm_SubModuleValiRule:V:P44:: PartTyp:%s\n",PartTyp);fflush(stdout);
																			if((tc_strcmp(PartTyp,"V")==0)||(tc_strcmp(PartTyp,"Vehicle")==0))
																			{
																				//if(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				if(tc_strstr(submodvali4,"CON03") == NULL)
																				{
																					printf ("\n tm_SubModuleValiRule:Veh:CON03: BOMViewClosureRuleERC applied \n");fflush(stdout);
																					if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																				else
																				{
																					printf ("\n tm_SubModuleValiRule:Veh:CON03: TMLBOMExpandByQty applied \n");fflush(stdout);
																					if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																			}
																			else
																			{
																				printf ("\n tm_SubModuleValiRule:V:P45:: TMLBOMExpandByQty applied \n");fflush(stdout);
																				//if(PIE_find_closure_rules("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				if(tc_strstr(submodvali4,"VC001") == NULL)
																				{
																					printf ("\n tm_SubModuleValiRule:Veh:CON03: BOMViewClosureRuleERC applied \n");fflush(stdout);
																					if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																				else
																				{
																					printf ("\n tm_SubModuleValiRule:Veh:CON03: TMLBOMExpandByQty applied \n");fflush(stdout);
																					if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																				}
																			}
																			printf ("\n tm_SubModuleValiRule:GM:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																			if (MDLrulefound > 0)
																			{
																				MDLClosureTag = MDLclosureruleee[0];
																				printf ("\n tm_SubModuleValiRule:GM:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																			}
																			if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																			//0qty
																			if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																			printf("\n tm_SubModuleValiRule:GM:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);


																			printf(" tm_SubModuleValiRule:start..\n");fflush(stdout);
																			iChild=0;
																			for(iChild =0 ; iChild < VCChildCunt; iChild++)
																			{
																				p_child_item_id=NULL;
																				rel_sstats=NULL;
																				Obj_PrtTyp=NULL;
																				rev_iidd=NULL;
																				PrtDRstus=NULL;
																				PrtProjj=NULL;

																				if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																				printf("\n tm_SubModuleValiRule:GM:P49: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																				//NEED TO DISCUSS BELOW LCs
																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																				//If child is NR WIP, it should be in same DML.
																				if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																				{
																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																					printf("\n tm_SubModuleValiRule:GM:P49: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																					if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																					{
																						printf("\n tm_SubModuleValiRule:GM:P49: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																					}
																					else
																					{
																						if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																						{
																							sChildMdlAdd=NULL;
																							sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																							tc_strcpy (sChildMdlAdd,"" );
																							sChildMdlAdd = subString(p_child_item_id,4,5);
																							printf("\n tm_SubModuleValiRule:GM:P49:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																							if(tc_strcmp(sChildMdlAdd,"Z1Z01")==0)
																							{
																								ManSOAddFlag ++;
																								printf("\n tm_SubModuleValiRule:GM:P49:ManSOAddFlag.:[%d] ", ManSOAddFlag);fflush(stdout);
																								printf("\n tm_SubModuleValiRule:GM:P61:FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
																								EMH_clear_errors();
																								EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"ERROR:For DR2 and above Vehicle or CR VC, 'Z1Z01' module address module is not allowed under it. Please revise it and modify BOM.");
																								decision = EPM_nogo;
																								return decision;
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					printf("\n tm_SubModuleValiRule:Final...........\n");fflush(stdout);
				}
			}
		}
	}
	printf("\n tm_SubModuleValiRule Function end...");fflush(stdout);
	TC_write_syslog("\n tm_SubModuleValiRule Function end...");
	return decision;
}