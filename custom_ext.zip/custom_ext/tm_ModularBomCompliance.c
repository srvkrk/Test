/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ModularBomCompliance.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating Modular BOM Accuracy check report for VC.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   18-04-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Vaibhav Bodkhe						    Base Code
* 			

* -----------------------------------------------------------------------------
* 
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation 
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration								 
FILE*   	 FP_Report       	  	  = NULL;
char*        stamptime        	  	  = NULL;
int      	 APLIndex     	     	  = 0;
int      	 ERCPrtIndex         	  = 0;
int      	 PartIndex1        	 	  = 0; 
int      	 Duplicate        	 	  = 0; 
int      	 VCAPLIdx        	 	  = 0; 
int      	 VCindx        	 	 	  = 0; 
int      	 Dupindx        	 	  = 0; 
int      	 Matchindx        	 	  = 0; 
int      	 NotMatchindx        	  = 0; 
int      	 QntyMismatch         	  = 0;
int      	 ERCIndex        	  	  = 0;
int      	 IERC        	 		  = 0;
int      	 ID9Z01        	 		  = 0;
int      	 V        	 			  = 0;
int      	 W        	 			  = 0;
int      	 Count        	 		  = 0;
int      	 countD9Z01        	 	  = 0;
int      	 E        	 			  = 0;
int      	 ErcModNtinD9Z01     	  = 0;
int      	 D9Z01PrtNotInERC     	  = 0;

char*        ERC_ChildsetR40[10000];
char*        ERC_ChildModAddsetR40[10000];
char*        APLVCChildsetR40[10000];
char*        APLVModAddsetR40[10000];
char*        ERCModuleprsnt[10000];
char*        ERCModprsntModadd[10000];
char*      	 D9Z01childobjAPL[10000];
char*      	 VehChildObjAPLVModAdd[10000];
char*      	 DuplicatedModAdd[10000];
char*      	 D9Z01childModAddApl[10000];
char*      	 partNotInERC[10000];
char*      	 NotPresentinD9Z01[10000];

char*      	 VehChildObjAPLV1        = NULL;
int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )    
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ReportModCompliance(char *selectedTask, int n_tags_found, tag_t* tags_found )
{
	printf("\n Inside Function.......\n");fflush(stdout);
	int 			status;
	int				iFail 								= ITK_ok;
	int				tsk 								= 0;
	int				Eligibleforaccrcycheck				= 0;
	int				stamptaskstatus						= 0;
	int		  		IsERCModuleprsnt					= 0;
	int		  		ISD9Z01Prsnt						= 0;
	int		  		IsD9Y01Prsnt						= 0;
	int		  		IsD9W01Prsnt						= 0;
	
	tag_t    	  	Task  								= NULL;
	tag_t     	 	DMLtag  							= NULL;
	tag_t      	 	DMLRelation         				= NULL;
	tag_t* 			DML_tag 							= NULL;
	tag_t  			*vcPartTags 						= NULL;
	tag_t  			vcpart  							= NULL;
	tag_t  			vcrev  								= NULL;

	int 			n_dml_found							= 0;
	int 			dml									= 0;
	int 			vcpartcount							= 0;
	int 			prt      							= 0;
	int				stamptaskstatusasPassFail			= 0;
	char*      		taskid         	  		   			= NULL;
	char*     	    DMLid         	   					= NULL;
	char*       	partid         	    				= NULL;
	char*       	partrevid      	    				= NULL;
	char*       	vcmakebuy      	    				= NULL;
	char*       	partdesc      	    				= NULL;
	
	char*       	Parttypetag         				= NULL;
	char*       	t5_PartStatus  	    				= NULL;
	char*       	itemid123  	    					= NULL;
	char			*PartitmID							= NULL;
	char**     		setofmoduleAdd       				= NULL;
	
	int 	   cld							= 0;
	int		   VC_ERC_childcount			= 0;
	int		   ctr_count					= 0;
	int		   VCNPrntctr_count				= 0;
	int		   VehDupAdd_Count				= 0;
	int		   vehdup						= 0;
	int		   CntrR						= 0;
	tag_t      window						= NULLTAG;
	tag_t      top_bom_line					= NULLTAG;
	tag_t      ERC_Rev_rule					= NULLTAG;
	tag_t      *VCERC_child					= NULLTAG;
	tag_t      Erc1Lvlchild					= NULLTAG;

	char		*levelA						= NULL;
	char		*ERC_Child_revseq			= NULL;
	char		*partstatusA				= NULL;
	char		*CAR_makebuy				= NULL;
	char		*R40Modl01					= NULL;
	char		*R40Modl02					= NULL;
	char		*R40Modl03					= NULL;
	char		*R40Modl04					= NULL;
	char		*R40Modl05					= NULL;
	char		*R40Modl06					= NULL;
	char		*VehNtPrsnt01				= NULL;
	char		*VehNtPrsnt02				= NULL;
	char		*VehNtPrsnt03				= NULL;
	char		*VehNtPrsnt04				= NULL;
	char		*VehNtPrsnt05				= NULL;
	char		*VehNtPrsnt06				= NULL;
	char		*VehNtPrsnt07				= NULL;
	char		*VehDupAdd01				= NULL;
	char		*VehDupAdd02				= NULL;
	char		*VehDupAdd03				= NULL;
	char		*VehDupAdd04				= NULL;
	char		*VehDupAdd05				= NULL;
	char		*VehDupAdd06				= NULL;
	char		*VehDupAdd07				= NULL;
	char		*VehDupAdd08				= NULL;
	char		*VehDupAdd09				= NULL;
	char		*VehDupAdd10				= NULL;
	char		*vcchldprtAddr				= NULL;
	int    		levelA1						= 0;
	int    		quantityblerc				= 0;
	int    		quantitybl				= 0;
	char	   *blquantityerc			   = NULL;
	int 		ERC_CRule_found 			= 0;
	tag_t 		*ERC_Closure_Tag  	   		= NULLTAG;
	tag_t 		ERC_Closure_Rule         	= NULLTAG;
	tag_t 		queryFound             		= NULLTAG;
	tag_t 		*ctr_tag			   		= NULLTAG;
	tag_t 		*VCNPrntctr_tag				= NULLTAG;
	tag_t 		*VehDupAdd_tag				= NULLTAG;
	char    	*qentryCtr[2]				= {"SYSCD","SUBSYSCD"};	
	char		**qvaluesCtr= (char **) MEM_alloc(5 * sizeof(char *));
	
	int				ifail 				=	ITK_ok;
	
	//Date & Time
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	char str1[100]; 
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	stamptime = (char *) MEM_alloc (sizeof (char) * 128);
	sprintf(str1, "%d", tm.tm_mday);
	sprintf(str2, "%d", tm.tm_mon + 1);
	sprintf(str3, "%d", tm.tm_year + 1900);
	sprintf(str4, "%d", tm.tm_hour);
	sprintf(str5, "%d", tm.tm_min);
	tc_strcpy(stamptime, str1);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str2);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str3);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str4);
	tc_strcat(stamptime, "_");
	tc_strcat(stamptime, str5);
	
	char*       MBOMReportFileName            = NULL;
	MBOMReportFileName = (char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(MBOMReportFileName,"");
	tc_strcat(MBOMReportFileName,selectedTask);
	tc_strcat(MBOMReportFileName,"_");
	tc_strcat(MBOMReportFileName,stamptime);
	tc_strcat(MBOMReportFileName,".txt");
	printf("\n File Name is :- %s",MBOMReportFileName);fflush(stdout);
	/////////////////////////
	//Query control object
 	ITK_CALL(QRY_find("Control Objects...",&queryFound));
	if(queryFound!=NULLTAG)
	{
		printf("\n R40Modl Control Object Found\n");fflush(stdout);
		qvaluesCtr[0]="R40Modl";
		qvaluesCtr[1]="*";
		ITK_CALL(QRY_execute(queryFound, 2, qentryCtr, qvaluesCtr, &ctr_count, &ctr_tag));
		printf("\n R40Modl Number of query found %d",ctr_count);fflush(stdout);
		for(CntrR = 0; CntrR < ctr_count; CntrR++)
		{
			
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo1", &R40Modl01));    
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo2", &R40Modl02));    
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo3", &R40Modl03));    
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo4", &R40Modl04));    
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo5", &R40Modl05));    
			ITK_CALL(AOM_ask_value_string( ctr_tag[0],"t5_Userinfo6", &R40Modl06));    
			printf("\n User info 1 %s",R40Modl01);fflush(stdout);//,D1B05,D1B07,D1B08,D1B09,D1B10,D1B11,D1B12,D1B13,D1B14,D1B15,D1B16,D1B17,D1B18,D1B19,D1B20,D1B21,D1B24,D1B25,D1C03,D1C04,D1C06,D1C07,D1C08,D1C09,D1C10,D1C11,D1C13,D1C15,D1C16,D1C17,D1C18,D1D05,D1D06,
			printf("\n User info 2 %s",R40Modl02);fflush(stdout);//,D1D07,D1D08,D2A01,D2A02,D2A03,D2A05,D2A06,D2A07,D2A08,D2A09,D2A10,D2A11,D2B01,D2B02,D2B03,D2B04,D2B05,D2B06,D2B07,D2B08,D2B09,D2B10,D2B11,D2B12,D2B13,D2B14,D2B15,D2B16,D2B17,D2B18,D2B19,D2B20,D2B21, 
			printf("\n User info 3 %s",R40Modl03);fflush(stdout);//,D2B22,D2B23,D2B24,D2B25,D2C01,D2C02,D2C03,D2C04,D2C05,D2C06,D2C07,D2C08,D2C09,D2C10,D2C11,D2D01,D2D02,D2D03,D2D04,D2D05,D2D06,D2D07,D2D08,D2D09,D2D10,D3A01,D3A04,D3A05,D3A06,D3A07,F1E01,F1E02,F1E03,                  
			printf("\n User info 4 %s",R40Modl04);fflush(stdout);//,F1E04,F1E06,F1E07,F1E08,F1E09,F2B01,F2B03,F5A13,F5A21,F5A25,G1A01,G1A02,G1A08,G1B02,G1B04,G1B05,G1B06,G1C02,G1C03,G2A01,G2A02,G2A03,G2A04,G2A05,G2A06,G2A07,D2A04,G2A10,G2A11,G2A12,G2A13,G2A14,G3A01,                             
			printf("\n User info 5 %s",R40Modl05);fflush(stdout);//,G3A02,G3A03,G3A04,G3A05,G3A06,G3B01,G3B02,G3B03,G3B04,G3B05,G3B06,G3B07,G3B08,G3B09,G4A01,G4A02,G4A08,G4A09,G4A12,G4A18,G4B01,G4B04,G4B05,G4B06,G4B07,G4B08,G4B09,G4B10,G4B11,G4B12,G4B13,G4B14,G4B15,                             
			printf("\n User info 6 %s \n",R40Modl06);fflush(stdout);//,G4B17,G4B18,G4B19,G4B21,G4B22,G4B23,G4B25,G4C01,G4C02,G4C03,G4C04,G4C05,G4C06,G4C07,G4C08,G4C09,G4C10,
		}
	}
	if(queryFound!=NULLTAG)
	{
		printf("\n VehNtPrsnt Control Object Found\n");fflush(stdout);
		qvaluesCtr[0]="VehNtPrsnt";
		qvaluesCtr[1]="1";
		ITK_CALL(QRY_execute(queryFound, 2, qentryCtr, qvaluesCtr, &VCNPrntctr_count, &VCNPrntctr_tag));
		printf("\n VehNtPrsnt Number of query found %d",VCNPrntctr_count);fflush(stdout);
		if(VCNPrntctr_tag != NULLTAG)
		{
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo1", &VehNtPrsnt01));  
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo2", &VehNtPrsnt02));    
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo3", &VehNtPrsnt03));
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo4", &VehNtPrsnt04));
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo5", &VehNtPrsnt05));
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo6", &VehNtPrsnt06));
			ITK_CALL(AOM_ask_value_string( VCNPrntctr_tag[0],"t5_Userinfo7", &VehNtPrsnt07));
			printf("\n VehNtPrsnt User info 1 %s",VehNtPrsnt01);fflush(stdout);//D1A01;D1A02;D1A03;D1A04;D1A05;D1A06;D1A07;D1A08;D1A09; 
			printf("\n VehNtPrsnt User info 2 %s",VehNtPrsnt02);fflush(stdout);//D1A10;D1A11;D1A12;D1A13;D1A14;D1A15;D1A16;D1A17;D1A18; 
			printf("\n VehNtPrsnt User info 3 %s",VehNtPrsnt03);fflush(stdout);//D1A20;D1A22;D1A23;D1B01;D1B02;D1B03;D1B04;D1B06; 
			printf("\n VehNtPrsnt User info 4 %s",VehNtPrsnt04);fflush(stdout);//F2A01;F2A02;F2A03;F2A04;F2A05;F2A06;F5A01;F5A02;H2B01; 
			printf("\n VehNtPrsnt User info 5 %s",VehNtPrsnt05);fflush(stdout);//F1A01;F4A01;F4B01; 
			printf("\n VehNtPrsnt User info 6 %s",VehNtPrsnt06);fflush(stdout);//H2D01;H2D02;F5A03;F5A04;F5A05;F5A06;
			printf("\n VehNtPrsnt User info 7 %s",VehNtPrsnt07);fflush(stdout);//A1B01;A1B05;D1D06;D1D01;D1D02;D1D03;D1D04;D1D05;D1D07;D1D08;F3C04;D9Y01;
		}
		else
		{
			printf("\n VehNtPrsnt control object NOT found ");fflush(stdout);
		}
	}
	
	
 	if(queryFound!=NULLTAG)
	{
		qvaluesCtr[0]="VehDupAdd";
		qvaluesCtr[1]="*";
		ITK_CALL(QRY_execute(queryFound, 1, qentryCtr, qvaluesCtr, &VehDupAdd_Count, &VehDupAdd_tag));
		printf("\n VehDupAdd_Count Number of query found %d",VehDupAdd_Count);fflush(stdout);
		if(VehDupAdd_tag !=NULLTAG)
		{
			for(vehdup = 0; vehdup < VehDupAdd_Count; vehdup++)
			{
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo1", &VehDupAdd01));  
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo2", &VehDupAdd02));    
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo3", &VehDupAdd03));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo4", &VehDupAdd04));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo5", &VehDupAdd05));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo6", &VehDupAdd06));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo7", &VehDupAdd07));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo8", &VehDupAdd08));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_Userinfo9", &VehDupAdd09));
				ITK_CALL(AOM_ask_value_string( VehDupAdd_tag[vehdup],"t5_userinfo10", &VehDupAdd10));
				printf("\n VehDupAdd User info 1 %s",VehDupAdd01);fflush(stdout);
				printf("\n VehDupAdd User info 2 %s",VehDupAdd02);fflush(stdout);
				printf("\n VehDupAdd User info 3 %s",VehDupAdd03);fflush(stdout);
				printf("\n VehDupAdd User info 4 %s",VehDupAdd04);fflush(stdout);
				printf("\n VehDupAdd User info 5 %s",VehDupAdd05);fflush(stdout);
				printf("\n VehDupAdd User info 6 %s",VehDupAdd06);fflush(stdout);
				printf("\n VehDupAdd User info 7 %s",VehDupAdd07);fflush(stdout);
				printf("\n VehDupAdd User info 8 %s",VehDupAdd08);fflush(stdout);
				printf("\n VehDupAdd User info 9 %s",VehDupAdd09);fflush(stdout);
				printf("\n VehDupAdd User info 10 %s",VehDupAdd10);fflush(stdout); 
			}
			
		}
		else
		{
			printf("\n VehDupAdd control object NOT found ");fflush(stdout);
		}

	}

	if(n_tags_found > 0)
	{
		FP_Report = fopen(MBOMReportFileName,"w");fflush(FP_Report);
		fprintf(FP_Report,"****************************************MODULAR BOM ACCURACY CHECK****************************************\t\t");fflush(FP_Report);
		fprintf(FP_Report,"\n\n	TaskNum : %s\t",selectedTask );fflush(FP_Report);
		//fprintf(FP_Report,"Vehicle Details : %s %s %s\t",partid,partrevid,partdesc);fflush(FP_Report);
		printf("\n	TaskNum : %s\t",selectedTask);fflush(stdout);
					
		for(tsk = 0 ;tsk < n_tags_found; tsk++)
		{	
			Task=tags_found[tsk];
			int status = 0;
			int    VC_count   = 0;
			int    VC   = 0;
			char* msg =NULL;
			
			tag_t       tDataSetType      = NULL;
			tag_t       tDataSet          = NULL;
			tag_t       tRelation         = NULL;
			tag_t       PRelation         = NULL;
			tag_t       taskRevTag        = NULL;
			tag_t       tRlnWithDataSet   = NULL;
			tag_t  		vcpart  						= NULL;
			tag_t  		Taskrev  						= NULL;
			tag_t 		wordLatestDat_t	  = NULLTAG;
			tag_t* 		vcPartTags	      	  = NULLTAG;
			char*       FilePath          = NULL;
			char*       taskid            = NULL;
			char*       taskdisc          = NULL;
			char*       obj_name          = NULL;
			char* 		datasetItemId 	  = NULL;
			char*       reference_nameDS  = NULL;
			
			tag_t 		file_tag    	  = NULLTAG;
			IMF_file_t 	file_descriptor;
			AE_reference_type_t			tagRefTypeText	= 1;
			
			ITK_CALL(AOM_ask_value_string(Task,"item_id",&taskid));
			printf("\n Task id is : %s ",taskid);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(Task,"object_desc",&taskdisc));
			printf("\n  task id  is : %s ",taskdisc);fflush(stdout);
			ITK_CALL(ITEM_ask_latest_rev(Task,&Taskrev));
			//Get part from task
			ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&PRelation));
			ITK_CALL(GRM_list_secondary_objects_only(Task,PRelation,&vcpartcount,&vcPartTags));
			//ITK_CALL(AOM_ask_value_tags(Task,"CMHasSolutionItem",&vcpartcount,&vcPartTags));  //Get part from Task revision.  CMHasSolutionItem    CMReferences
			if(vcpartcount > 0)
			{
				for(VC = 0; VC < vcpartcount;VC++)
				{
					printf("\n Inside VC \n");fflush(stdout);
					vcpart=vcPartTags[VC];
					ITK_CALL(ITEM_ask_latest_rev(vcpart,&vcrev));
					//ITK_CALL(AOM_ask_value_string(vcrev,"item_id",&partid));
					//printf("\n vcpart id is : %s ",partid);fflush(stdout);
					ITK_CALL(AOM_ask_value_string(vcrev,"t5_PartType",&Parttypetag));
					printf("\n object type is : %s ",Parttypetag);fflush(stdout);
					stamptaskstatus=0;
					if(tc_strcmp(Parttypetag, "V") == 0)
					{
						ITK_CALL(AOM_ask_value_string(vcrev,"item_id",&partid));
						printf("\n vcpart id is : %s ",partid);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(vcrev,"item_revision_id",&partrevid));
						//printf("\n Part rev id is : %s ",partrevid);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(vcrev,"t5_PunMakeBuyIndicator",&vcmakebuy));  //make buy indicator 
						//printf("\n vc makebuy indicator is : %s ",vcmakebuy);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(vcrev,"object_desc",&partdesc));
						//printf("\n Part Desccription is : %s ",partdesc);fflush(stdout);
						fprintf(FP_Report,"Vehicle Details : %s %s %s\t",partid,partrevid,partdesc);fflush(FP_Report);

						printf ("\n \n BOM Expansion ERC view......... \n");fflush(stdout);
						ITK_CALL(BOM_create_window(&window));
						ITK_CALL(CFM_find("ERC release and above (Modified)", &ERC_Rev_rule));
						ITK_CALL(PIE_find_closure_rules( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &ERC_CRule_found, &ERC_Closure_Tag ));
						printf ("ERC closure rule count %d \n",ERC_CRule_found);fflush(stdout);
						if (ERC_CRule_found > 0)
						{
							ERC_Closure_Rule = ERC_Closure_Tag[0];
							printf ("closure rule found \n");fflush(stdout);
						
						
							ITK_CALL(BOM_window_set_closure_rule(window,ERC_Closure_Rule,0,NULL,NULL));
							ITK_CALL(BOM_set_window_config_rule( window, ERC_Rev_rule ));
							//ITK_CALL(BOM_set_window_pack_all (window, true));//grouping 
							ITK_CALL(BOM_set_window_top_line(window, NULLTAG, vcrev, NULLTAG, &top_bom_line));
							ITK_CALL(BOM_line_ask_all_child_lines(top_bom_line, &VC_ERC_childcount, &VCERC_child));   //ERC Expansion.
							printf("\n\n Number of child of Vehicle found in << ERC View >> : %d",VC_ERC_childcount);fflush(stdout);
							
							
							for(cld =0; cld<VC_ERC_childcount;cld++)
							{
								Erc1Lvlchild=VCERC_child[cld];
								ITK_CALL(AOM_ask_value_string(Erc1Lvlchild,"bl_item_item_id",&PartitmID));  
								//printf("\n Child Part Item ID= %s\n",PartitmID);fflush(stdout);
								ITK_CALL(AOM_UIF_ask_value(Erc1Lvlchild,"bl_level_starting_0",&levelA));
								int levelA1 = atoi(levelA);
								//printf("\n LEVEL :--> %d\n",levelA1);fflush(stdout);
								
								ITK_CALL(AOM_ask_value_string(Erc1Lvlchild,"awb0BomLineRevId",&ERC_Child_revseq));  //awb0BomLineRevId  bl_rev_item_revision_id
								printf("\n ERC Child Part rev seq  = %s\n",ERC_Child_revseq);fflush(stdout);
								//ITK_CALL(AOM_ask_value_string(Erc1Lvlchild,"bl_Design Revision_t5_PartStatus",&partstatusA));  
								//printf("\n Child partstatus Name = %s\n",partstatusA);fflush(stdout);
								//Query Control Object
								vcchldprtAddr=subString(PartitmID,4,5);
								printf("\n Vehicle 1st lvl child part Number in ERC view : %s &  Address: %s",PartitmID,vcchldprtAddr);fflush(stdout);
								if(tc_strstr(R40Modl01,vcchldprtAddr) != NULL || 
									tc_strstr(R40Modl02,vcchldprtAddr) != NULL || 
									tc_strstr(R40Modl03,vcchldprtAddr) != NULL ||
									tc_strstr(R40Modl04,vcchldprtAddr) != NULL ||
									tc_strstr(R40Modl05,vcchldprtAddr) != NULL || 
									tc_strstr(R40Modl06,vcchldprtAddr) != NULL)
									{
										printf("\n Vehicle ERC view 1st lvl child part belongs to R40 : %s &  Address: %s",PartitmID,vcchldprtAddr);fflush(stdout);
										ITK_CALL(AOM_UIF_ask_value(Erc1Lvlchild,"bl_quantity",&blquantityerc));
										int quantityblerc = atoi(blquantityerc);
										printf("\nERC child Module quantity --> %s[%d]",PartitmID,quantityblerc);fflush(stdout);
										ERC_ChildsetR40[ERCPrtIndex] = PartitmID;
										ERC_ChildModAddsetR40[ERCPrtIndex] = vcchldprtAddr;
										ERCPrtIndex = ERCPrtIndex + 1;
									}
							}
						} 							

		//[Check 1]     :- MFG Modules not present under vehicle in APL view                    //[D9Z01,D9Y01,D9W01]this 3 modules should be present under vehicle	
						printf("\n Inside APL view BOM Expansion \n");fflush(stdout);
						int 	   APL					= 0;
						int		   APLC_count			= 0;
						int		   APLD_count			= 0;
						int		   APLY_count			= 0;
						//int		   ISD9Z01Prsnt		= 0;
						tag_t      windowAPL			= NULLTAG;
						tag_t      APLtop_bom_line		= NULLTAG;
						tag_t      DDAPLtop_bom_line	= NULLTAG;
						tag_t      Revrule				= NULLTAG;
						tag_t      *vcchildAPL			= NULLTAG;
						tag_t      *D9Z01child			= NULLTAG;
						tag_t      *D9Y01child			= NULLTAG;
						tag_t      vcchildAPL1			= NULLTAG;
			
						char		*APLpartID			= NULL;
						char		*vcaplchild			= NULL;
						char		*DDPartID			= NULL;
						char		*level				= NULL;
						char		*revseq				= NULL;
						char		*partstatus			= NULL;
						//char		*CAR_makebuy		= NULL;
						char		*APLpartModAddrs	= NULL;
						char		*APLVModAdd			= NULL;
						int    		level1				= 0;
						int 		rulefound 			= 0;
						int 		APLc 				= 0;
						int 		DD 					= 0;
						int 		WW 					= 0;
						tag_t 		*tClosurerule  		= NULLTAG;
						tag_t 		closer_tag     		= NULLTAG;
								
						char		*Cabchildpartid		= NULL;
						char		*blquantity			= NULL;
						char		*BIWchildid			= NULL;
						char		*cabchildModAdd		= NULL;
						char		*BIWchildModAdd		= NULL;
						char		*ClosureRule		= NULL;
						char		*RevisionRule		= NULL;
						
						/////////////
						if(tc_strstr(taskid,"APLJ")!= NULL) //jsr
						{
							tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLJ");
							tc_strcpy(RevisionRule,"APLJ Release and Above");
							
						}
						else if(tc_strstr(taskid,"APLL")!= NULL) //lko
						{
							tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLL");
							tc_strcpy(RevisionRule,"APLL Release and Above");
							
						}
						else if(tc_strstr(taskid,"APLD")!= NULL) //dharwad
						{
							tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLD");
							tc_strcpy(RevisionRule,"APLD Release and Above");
							
						}
						else if(tc_strstr(taskid,"APLP")!= NULL)  //pune
						{
							tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLP");
							tc_strcpy(RevisionRule,"APLP Release and Above");
							
						}
						else if(tc_strstr(taskid,"APLU")!= NULL)  //pant nagar
						{
							tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLU");
							tc_strcpy(RevisionRule,"APLU Release and Above");
							
						}
						printf("\n Closure Rule is %s & Revision Rule is %s ",ClosureRule,RevisionRule);fflush(stdout);
						/////////////
						
						
						
						
						ITK_CALL(BOM_create_window(&windowAPL));
						ITK_CALL(CFM_find(RevisionRule, &Revrule));
						//ITK_CALL(CFM_find("APLJ Release and Above", &Revrule));
						ITK_CALL(PIE_find_closure_rules(ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
						//ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleAPLJ",PIE_TEAMCENTER, &rulefound, &tClosurerule));
						printf ("rule count %d \n",rulefound);fflush(stdout);
						if (rulefound > 0)
						{
							closer_tag = tClosurerule[0];
							printf ("closure rule found \n");fflush(stdout);
							ITK_CALL(BOM_window_set_closure_rule(windowAPL,closer_tag,0,NULL,NULL));
							ITK_CALL(BOM_set_window_config_rule( windowAPL,Revrule));
							//ITK_CALL(BOM_set_window_pack_all (windowAPL, true));//for grouping 
							ITK_CALL(BOM_set_window_top_line(windowAPL, NULLTAG, vcrev, NULLTAG, &APLtop_bom_line));
							ITK_CALL(BOM_line_ask_all_child_lines(APLtop_bom_line, &APLC_count, &vcchildAPL));       //got vc child
							printf("\n\n Number of Vehicle child in APL View : %d",APLC_count);fflush(stdout);
							ISD9Z01Prsnt=0;
							IsERCModuleprsnt=0;
							for(APLc =0; APLc<APLC_count;APLc++)
							{

								vcchildAPL1=vcchildAPL[APLc];
								ITK_CALL(AOM_ask_value_string(vcchildAPL1,"bl_item_item_id",&APLpartID));
								APLpartModAddrs=subString(APLpartID,4,5);					
								//printf("\n VC Child Part in APL View = %s\n",APLpartID);fflush(stdout);
								ITK_CALL(AOM_UIF_ask_value(vcchildAPL1,"bl_level_starting_0",&level));
								int level1 = atoi(level);
								//printf("\n LEVEL>>> %d\n",level1);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(vcchildAPL1,"bl_rev_item_revision_id",&revseq));  
								//printf("\n Child Part revseq = %s\n",revseq);fflush(stdout);
								//ITK_CALL(AOM_ask_value_string(vcchildAPL1,"bl_Design Revision_t5_PartStatus",&partstatus));  //part status
								//printf("\n Child partstatus Name = %s\n",partstatus);fflush(stdout);
								printf("\n APL Module Address:=%s  & APL part id := %s",APLpartModAddrs,APLpartID);fflush(stdout);
								VehChildObjAPLVModAdd[VCAPLIdx] = APLpartModAddrs;
								VCAPLIdx = VCAPLIdx + 1;
								
								if(tc_strcmp(APLpartModAddrs,"D9Z01") == 0)
								{
									ISD9Z01Prsnt++;
									printf("\n Module address %s [%s] is present under APL view Hence NO ISSUE \n",APLpartModAddrs,APLpartID);fflush(stdout);
										
		//  Modules with address D9Y01 should be present in D9Z01
									ITK_CALL(BOM_line_ask_all_child_lines(vcchildAPL1, &APLD_count, &D9Z01child));
									printf("\n\n Number of child found in D9Z01  : %d",APLD_count);fflush(stdout);
									IsD9Y01Prsnt=0;
									 for(DD = 0; DD < APLD_count ; DD++)
									{
										ITK_CALL(AOM_ask_value_string(D9Z01child[DD],"bl_item_item_id",&Cabchildpartid));
										ITK_CALL(AOM_UIF_ask_value(D9Z01child[DD],"bl_quantity",&blquantity));
										int quantitybl = atoi(blquantity);
										printf("\n D9Z01 child Module quantity --> %s[%d]",Cabchildpartid,quantitybl);fflush(stdout);
										cabchildModAdd=subString(Cabchildpartid,4,5);
										printf("\n D9Z01 child Module Address:=%s  & part id := %s",cabchildModAdd,Cabchildpartid);fflush(stdout);
										
										D9Z01childobjAPL[PartIndex1] = Cabchildpartid;   //D9Z01 child 
										D9Z01childModAddApl[PartIndex1] = cabchildModAdd; 
										PartIndex1 = PartIndex1 + 1;
										if(tc_strcmp(cabchildModAdd,"D9Y01") == 0)
										{
											printf("\n Part with Module Address %s [%s] present Under D9Z01",cabchildModAdd,Cabchildpartid);fflush(stdout);
											IsD9Y01Prsnt++;
		//	 Modules D9W01 Should be present under D9Y01								
											ITK_CALL(BOM_line_ask_all_child_lines(D9Z01child[DD], &APLY_count, &D9Y01child));
											printf("\n\n Number of child found in D9Y01  : %d",APLY_count);fflush(stdout);
											IsD9W01Prsnt=0;
											for(WW = 0;WW < APLY_count;WW++)
											{
												ITK_CALL(AOM_ask_value_string(D9Y01child[WW],"bl_item_item_id",&BIWchildid));
												BIWchildModAdd=subString(BIWchildid,4,5);
												printf("\n D9Y01 child Module Address:=%s  & part id := %s",BIWchildModAdd,BIWchildid);fflush(stdout);
												if(tc_strcmp(BIWchildModAdd,"D9W01") == 0)
												{
													printf("\n Part with Module Address %s [%s] present Under D9Y01 ",BIWchildModAdd,BIWchildid);fflush(stdout);
													IsD9W01Prsnt++;
												}
											}
										}
										
									}
									
								}
		//[Check 2]     :- ERC Modules present under vehicle in APL view.
								if(tc_strstr(R40Modl01,APLpartModAddrs) != NULL  || 
									tc_strstr(R40Modl02,APLpartModAddrs) != NULL || 
									tc_strstr(R40Modl03,APLpartModAddrs) != NULL ||
									tc_strstr(R40Modl04,APLpartModAddrs) != NULL ||
									tc_strstr(R40Modl05,APLpartModAddrs) != NULL || 
									tc_strstr(R40Modl06,APLpartModAddrs) != NULL)
									{
										IsERCModuleprsnt++;
										printf("\n APL Parts belongs to R40 & Mod Address-->> %s [%s]\n",APLpartID,APLpartModAddrs);fflush(stdout);
										APLVCChildsetR40[APLIndex] = APLpartID;
										APLVModAddsetR40[APLIndex] = APLpartModAddrs;
										APLIndex = APLIndex + 1;
									}

							}
						}
						else
						{
							printf ("APL closure rule not found \n");fflush(stdout);
							exit;
						}

						
						for(IERC =0 ; IERC < ERCPrtIndex; IERC++)
						{
							printf(" \n ERC child part Belongs to R40 [%s]",ERC_ChildsetR40[IERC]);fflush(stdout);
						}
						
						for(ID9Z01 =0 ; ID9Z01 < PartIndex1; ID9Z01++)
						{
							printf(" \n D9z01 child part [%s]",D9Z01childobjAPL[ID9Z01]);fflush(stdout);
						}
						
		// [check 3] :-  Modules present in ERC view under vehicle but not present under D9Z01 in APL view
						printf("\n Check 3 Modules present in ERC view under vehicle but not present under D9Z01 in APL View \n");fflush(stdout);
						QntyMismatch =0;
						if(ERCPrtIndex == (PartIndex1-1))
						{
							printf("\n  ERC child parts & D9Z01 child part equal\n");
						}
						else
						{
							QntyMismatch++;
							printf("\n  ERC child parts & D9Z01 child part NOT equal\n");
						}
						ErcModNtinD9Z01 = 0;
						for(IERC =0 ; IERC < ERCPrtIndex; IERC++)
						{
							int FlagERC =0;
							for(ID9Z01 =0 ; ID9Z01 < PartIndex1; ID9Z01++)
							{
								if(tc_strcmp(D9Z01childobjAPL[ID9Z01],ERC_ChildsetR40[IERC]) == 0) 
								{
									FlagERC = 1 ;
									break;
								}
							}
							if(FlagERC == 0)
							{
								ErcModNtinD9Z01++;
								NotPresentinD9Z01[NotMatchindx]= ERC_ChildsetR40[IERC];         //ERC module not present in D9Z01
								NotMatchindx = NotMatchindx + 1;
							}
							
						}		
						for(V =0 ; V < NotMatchindx;V++)
						{
							printf("\n  ERC part Not present in D9Z01    %s",NotPresentinD9Z01[V]);fflush(stdout);
						}
						
						
		//  [check 4] :- Modules presnt under D9Z01 but not present under vehicle in ERC view.	
						printf("\n Check 4 :- Modules presnt under D9Z01 but not present under vehicle in ERC view.\n");fflush(stdout);
						D9Z01PrtNotInERC = 0;
						for(ID9Z01 =0 ; ID9Z01 < PartIndex1; ID9Z01++)
						{
							int FlagD9 =0;
							for(IERC =0 ; IERC < ERCPrtIndex; IERC++)
							{
								if(tc_strcmp(ERC_ChildsetR40[IERC],D9Z01childobjAPL[ID9Z01]) == 0)    //D9Z01 module not present in ERC [skip D9Y01]
								{
									FlagD9 = 1;
									break;
								}
							}
							if(FlagD9 == 0)
							{
								D9Z01PrtNotInERC++;
								partNotInERC[Matchindx] = D9Z01childobjAPL[ID9Z01];
								Matchindx = Matchindx + 1;
							}
						}
						for(W =0 ; W < Matchindx;W++)
						{
							printf("\n  ERC part Not present in D9Z01    %s",partNotInERC[W]);fflush(stdout);
						}

		// [check 5] : Duplicity check    (BOM under vehicle plant in APL view  +  D9Z01 bom  should not present more than once)
						// Add [Vehicle child in APL view + D9Z01 parts] in one set And compare with control objects
						//VehChildObjAPLVModAdd[VCAPLIdx]
						//D9Z01childModAddApl[PartIndex1]
									
						

						
					}
					else
					{
						printf("\n Part type is not Vehicle ");fflush(stdout);
					}
					
				//for loop vc part
				
										
																		//* Report *//																												
				printf (" \n Report Start Here.......... \n");fflush(stdout);		
	//[Check 1] :- MFG Modules not present under vehicle in APL view    [D9Z01,D9Y01,D9W01] should be present under vehicle in APL View
				fprintf(FP_Report,"\n\n\n CHECK 1 : MFG Modules not present under vehicle in APL view [D9Z01,D9Y01,D9W01 should present one quantity]");fflush(FP_Report);
				fprintf(FP_Report,"\n==============================================================================================================");fflush(FP_Report);
				if(ISD9Z01Prsnt == 1)
				{
					printf(" \n D9Z01 present \n");fflush(stdout);
					
					if(IsD9Y01Prsnt == 1)
					{
						printf(" \n D9Y01 present \n");fflush(stdout);
						if(IsD9W01Prsnt == 1)
						{
							fprintf(FP_Report,"\n NO ISSUE");fflush(FP_Report);
							printf(" \n D9W01 present \n");fflush(stdout);
						}
						else if(IsD9W01Prsnt > 1)
						{
							fprintf(FP_Report,"\n Part with Module Address D9W01 Present more than once \n");fflush(FP_Report);
							printf(" \n Part with Module Address D9W01 Present more than once \n");fflush(stdout);
							//stamptaskstatus++;
						}
						else
						{
							fprintf(FP_Report,"\n Part with Module Address D9W01 Not Present under D9Y01 \n");fflush(FP_Report);
							printf(" \n Part with Module Address D9W01 Not Present under D9Y01 \n");fflush(stdout);
							//stamptaskstatus++;
						}
					}
					else if(IsD9Y01Prsnt > 1)
					{
						//fprintf(FP_Report,"\n Part with Module Address D9Y01 Not Present under D9Z01 \n");fflush(FP_Report);
						printf(" \n Part with Module Address D9Y01  Present more than once \n");fflush(stdout);
						//stamptaskstatus++;
					}
					else
					{	
						fprintf(FP_Report,"\n Part with Module Address D9Y01 Not Present under D9Z01 \n");fflush(FP_Report);
						printf(" \n Part with Module Address D9Y01 Not Present under D9Z01 \n");fflush(stdout);
						//stamptaskstatus++;
					}
				}
				else if(ISD9Z01Prsnt > 1)     //D9Z01 >1 then  check  D9Y01??
				{
					//fprintf(FP_Report,"\n Part with Module Address D9Z01Present more than once  \n");fflush(FP_Report);
					printf(" \n Part with Module Address D9Z01 present more than once \n");fflush(stdout);
				}
				else
				{
					fprintf(FP_Report,"\n Part with Module Address D9Z01 Not Present \n");fflush(FP_Report);
					printf(" \n Part with Module Address D9Z01 Not Present under APL view \n");fflush(stdout);
					//stamptaskstatus++;
				}
				
				
	//[Check 2]    	:  ERC Modules present under vehicle in APL view.  	    [control object ---R40     should not present under APL view]	
				fprintf(FP_Report,"\n\n\n CHECK 2 : ERC Modules present under vehicle in APL view [D9Z01 Aplicable subModule]");fflush(FP_Report);
				fprintf(FP_Report,"\n==============================================================================================================");fflush(FP_Report);
				if(IsERCModuleprsnt > 0)
				{
					for(E = 0 ; E < APLIndex; E++)
					{
						printf("\n ERC Modules %s present under vehicle \n",APLVCChildsetR40[E]);fflush(stdout);
						fprintf(FP_Report,"\n %s[%s] \n",APLVCChildsetR40[E],APLVModAddsetR40[E]);fflush(FP_Report);
						//stamptaskstatus++;
					}
				}
				else
				{
					fprintf(FP_Report,"\n NO ISSUE");fflush(FP_Report);
					printf(" \n Check 2  NO ISSUE \n");fflush(stdout);
				}
	///////////////////////////////////////////////////////////////////////////////////////////////

	//[Check 3]    	:  Modules present in ERC view under vehicle but not present under D9Z01 in APL view   	
				fprintf(FP_Report,"\n\n\n CHECK 3 : Modules present in ERC view under vehicle but not present under D9Z01 in APL view.");fflush(FP_Report);
				fprintf(FP_Report,"\n==============================================================================================================");fflush(FP_Report);
				if(ErcModNtinD9Z01 > 0)
				{
					for(V =0 ; V < NotMatchindx;V++)
					{
						printf("\n Modules present in ERC view under vehicle but not present under D9Z01 in APL view %s",NotPresentinD9Z01[V]);fflush(stdout);
						fprintf(FP_Report,"\n %s\n",NotPresentinD9Z01[V]);fflush(FP_Report);
					}
					if(QntyMismatch > 0)
					{
						printf(" - quantity mismatch between ERC child and D9Z01 childs  ");fflush(stdout);
					}
				}
				else
				{
					fprintf(FP_Report,"\n NO ISSUE");fflush(FP_Report);
					printf(" \n Check 3  NO ISSUE \n");fflush(stdout);
				}

	//[Check 4]    	:  Modules present under D9Z01 but not present under vehicle in ERC view.  			
				fprintf(FP_Report,"\n\n\n CHECK 4 : Modules present under D9Z01 but not present under vehicle in ERC view.");fflush(FP_Report);
				fprintf(FP_Report,"\n==============================================================================================================");fflush(FP_Report);
				if(D9Z01PrtNotInERC > 0)
				{
					for(W =0 ; W < NotMatchindx; W++)
					{
						printf("\n Modules present under D9Z01 but not present under vehicle in ERC view. %s \n",partNotInERC[W]);fflush(stdout);
						if(tc_strstr(partNotInERC[W],"D9Y01") == NULL)
						{
							fprintf(FP_Report,"\n  %s\n",partNotInERC[W]);fflush(FP_Report);
						}
						else
						{
							fprintf(FP_Report,"\n NO ISSUE");fflush(FP_Report);
							printf(" \n Check 4  NO ISSUE \n");fflush(stdout);
						}
					}
				}
				else
				{
					
					fprintf(FP_Report,"\n NO ISSUE");fflush(FP_Report);
					printf(" \n Check 4  NO ISSUE \n");fflush(stdout);
				}
				
				
	//[Check 5]     :- Below address is duplicated under vehicle       (BOM under vehicle in APL view + D9Z01 bom     should not present more than once)
				//fprintf(FP_Report,"\n\n\n CHECK 5 : Below address is duplicated under vehicle");fflush(FP_Report);
				//fprintf(FP_Report,"\n==============================================================================================================");fflush(FP_Report);
				
		}// vc part
		
			fclose(FP_Report);
				
			//Attached Dataset
			datasetItemId=(char *) MEM_alloc(100 * sizeof(char ));
			reference_nameDS= (char *) MEM_alloc(100);
			FilePath = (char *) MEM_alloc(100);
			tc_strcpy(datasetItemId,"");
			tc_strcpy(datasetItemId,taskid);
			tc_strcat(datasetItemId,"_report");			
			printf("\n Before Adding Text Dataset");fflush(stdout);
			
			tc_strcpy(FilePath,"");
			tc_strcpy(FilePath,"//user//cvprod//TC_ROOT12//pool_manager//confs//config1//");     
			
			tc_strcat(FilePath,MBOMReportFileName);
			printf("\n File path: %s",FilePath);fflush(stdout);
			
			ITK_CALL(AE_find_datasettype2("Text",&tDataSetType));	
			printf("\n  Text DataSet found ");fflush(stdout);
			tc_strcpy(reference_nameDS,"Text");
			printf("\n DataSet Name: %s",datasetItemId);fflush(stdout);
			printf("\n reference_nameDS Name: %s",reference_nameDS);fflush(stdout);
			printf("\n  Before dataset create........");fflush(stdout);
			ITK_CALL(AE_find_dataset2(datasetItemId,&tDataSet));
			printf("\n After dataset tag found.........");fflush(stdout);
			if(tDataSet == NULLTAG)
			{
				printf("\n dataset Not available Hence Inside create.........");fflush(stdout);
				ITK_CALL(AE_create_dataset_with_id(tDataSetType,datasetItemId,"","","",&tDataSet));
				printf("\n dataset created.........");fflush(stdout);
				ITK_CALL(AE_save_myself(tDataSet));
				ITK_CALL(IMF_import_file(FilePath,NULL, SS_TEXT, &file_tag, &file_descriptor));
				AOM_save(file_tag);
				AOM_lock(tDataSet);	
				printf("\n\t after AOM_save FIRST TIME -  \n"); fflush(stdout);
				
				ITK_CALL(GRM_find_relation_type("CMReferences",&tRelation));//CMReferences   TC_Attaches
				ITK_CALL(AE_add_dataset_named_ref2(tDataSet,reference_nameDS,tagRefTypeText,file_tag));
				printf("\n\t after named reference ADD \n"); fflush(stdout);											
				AOM_save(tDataSet);
				printf("\n\t AOM_save Dataset \n"); fflush(stdout);
				AOM_unlock(tDataSet);
				//ITK_CALL(ITEM_ask_latest_rev(Task,&taskRevTag));
				ITK_CALL(GRM_create_relation(Taskrev,tDataSet,tRelation,NULLTAG,&tRlnWithDataSet));
				ITK_CALL(GRM_save_relation(tRlnWithDataSet));
				AOM_refresh(Taskrev,0);
				
				printf("\n Text file attached to task succesfully ");fflush(stdout);
				if(MBOMReportFileName) 
				MEM_free(MBOMReportFileName);			
			}
			else
			{
				ITK_CALL(IMF_import_file(FilePath,NULL, SS_TEXT, &file_tag, &file_descriptor));
				AOM_save(file_tag);
				AOM_lock(tDataSet);	
				printf("\n\t after AOM_save FIRST TIME -  \n"); fflush(stdout);
				
				//ITK_CALL(GRM_find_relation_type("CMReferences",&tRelation));//CMReferences   TC_Attaches
				ITK_CALL(AE_add_dataset_named_ref2(tDataSet,reference_nameDS,tagRefTypeText,file_tag));
				printf("\n\t after named reference ADD \n"); fflush(stdout);											
				AOM_save(tDataSet);
				printf("\n\t AOM_save Dataset \n"); fflush(stdout);
				AOM_unlock(tDataSet);
				printf("\n Text file attached to task succesfully ");fflush(stdout);
				if(FilePath) 
				MEM_free(FilePath); 
			}
				if(FilePath) 
				MEM_free(FilePath);
				
			
		  }
			else
			{
				printf("\n Part not Found in task ");fflush(stdout);
			}	
				

			
				
		}

	}
	
	return ITK_ok;
}

int ModularBOMAccChk(void *return_data)
{
	char 			*selectedTask		= 	NULL;
	int n_tags_found					=0;
    tag_t* tags_found 					= NULL;
	const char *attrs[1];
    const char *values[1];
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	attrs[0] ="item_id";
	values[0] = (char *)selectedTask;
	ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);
	ReportModCompliance(selectedTask,n_tags_found ,tags_found);
	////////////////////////////////////
	
}

extern int tm_ModularBomAccuracyChkcalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 1;
	int retValueType;
	int inputArgTypes[1] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //Selected Task

		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n tm_ModularBomAccuracyChkcalling before....ModularBOMAccChk");fflush(stdout);  
	ifail=USERSERVICE_register_method("ModularBOMAccChk",(USER_function_t)ModularBOMAccChk,nargs,inputArgTypes,retValueType);
	
	
	return ifail;
}

extern DLLAPI int tm_ModularBomCompliance_register_callbacks ()
{	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ModularBomCompliance");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_ModularBomCompliance", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ModularBomAccuracyChkcalling);
	printf("\n After registering userservice....tm_ModularBomCompliance");fflush(stdout);
	return(ITK_ok);
}