/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int EPAInValidPrtStckUpdServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	char *EPANo= NULL;
	char *detailValInValid= NULL;
	char *validRowCnt= NULL;
	char *partNoInValid= NULL;
	char *partTypeinValid= NULL;
	char *PrtNo_InValPrt= NULL;
	char *PrtSuppEndStk_InValPrt= NULL;
	char *PrtInHouseStk_InValPrt= NULL;
	char *PrtInHouseStkT_InValPrt= NULL;
	
	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t* invalid_rowsTag = NULLTAG;

	int PrtSuppEndStk_InValPrtIntV=0;
	int PrtInHouseStk_InValPrtIntV=0;
	int PrtInHouseStkT_InValPrtV=0;
	int intInvalidRowCnt=0;
	int rcnt1=0;
	int n_invalid_rows=0;
	int iInValCnt=0;
	int rcnt2=0;
	char *invalidRowData= NULL;
	char *fectinvalidRowData= NULL;


	//USERARG_get_string_argument(&countValidPart);
	USERARG_get_string_argument(&EPANo);
	USERARG_get_string_argument(&detailValInValid);
	USERARG_get_string_argument(&validRowCnt);

	
	printf("\nArgument Received(EPAInValidPrtStckUpdServiceFnc) EPANo=%s\n",EPANo);fflush(stdout);	
	printf("\nArgument Received(EPAInValidPrtStckUpdServiceFnc) validRowCnt=%s\n",validRowCnt);fflush(stdout);	
	printf("\nArgument Received(EPAInValidPrtStckUpdServiceFnc) detailValInValid=%s\n",detailValInValid);fflush(stdout);	
	if(tc_strcmp(EPANo,"")!=0)
	{
			
		qry_entries[0] ="item_id";
		qry_values[0] = EPANo;

		printf("\n Qurying the EPA");fflush(stdout);

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		if(n_tags_found>0 )
		{
			item = itemclass[0];
			
			ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
			if(epa_rev_tag!=NULLTAG)
			{
				printf("\n EPA found");fflush(stdout);

				intInvalidRowCnt = atoi(validRowCnt); // Using atoi()
				printf("\nThe value of intInvalidRowCnt : %d", intInvalidRowCnt);fflush(stdout);

				if(intInvalidRowCnt>0)
				{
				
					char *arrayInvadDt[intInvalidRowCnt];
						
					for(rcnt1=0;rcnt1<intInvalidRowCnt;rcnt1++)
					{
						if(tc_strcmp(detailValInValid,"")!=0)
						{
							
							if(rcnt1==0)
							{
								invalidRowData=tc_strtok(detailValInValid,"~");
							}
							else
							{
								invalidRowData=tc_strtok(NULL,"~");
							}

							printf("\n invalidRowData :[%s] \n",invalidRowData);fflush(stdout);

							arrayInvadDt[rcnt1]=invalidRowData;
							printf("\n arrayInvadDt[rcnt1] :[%s] \n",arrayInvadDt[rcnt1]);fflush(stdout);

						}					

					}

					for(rcnt2=0;rcnt2<intInvalidRowCnt;rcnt2++)
					{
						fectinvalidRowData=arrayInvadDt[rcnt2];
						printf("\n fectinvalidRowData :[%s] \n",fectinvalidRowData);fflush(stdout);

						PrtNo_InValPrt = tc_strtok(fectinvalidRowData,"-");
						PrtSuppEndStk_InValPrt = tc_strtok(NULL,"-");
						PrtInHouseStk_InValPrt = tc_strtok(NULL,"-");
						PrtInHouseStkT_InValPrt = tc_strtok(NULL,"-");								

						printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:\n",PrtNo_InValPrt,PrtSuppEndStk_InValPrt,PrtInHouseStk_InValPrt,PrtInHouseStkT_InValPrt);fflush(stdout);
					
						ITKCALL(AOM_ask_table_rows(epa_rev_tag,"t5_EpaCrTabInValid", &n_invalid_rows,&invalid_rowsTag));
						printf("\n no of table rows fron InValid Parts are %d \n", n_invalid_rows);fflush(stdout);
						if(n_invalid_rows>0)
						{
							for(iInValCnt=0;iInValCnt<n_invalid_rows;iInValCnt++)
							{
								ITKCALL(AOM_ask_value_string(invalid_rowsTag[iInValCnt], "t5_PartNumberInValid", &partNoInValid));
								printf("\n partNoInValid [%s]..",partNoInValid);fflush(stdout);

								ITKCALL(AOM_ask_value_string(invalid_rowsTag[iInValCnt], "t5_PartTypeInValid", &partTypeinValid));
								printf("\n partTypeinValid [%s]..",partTypeinValid);fflush(stdout);	

						
								if( (tc_strcmp(partNoInValid,PrtNo_InValPrt)==0) && (tc_strcmp(partTypeinValid,"Parent")==0))
								{
								
									 PrtSuppEndStk_InValPrtIntV=atoi(PrtSuppEndStk_InValPrt);
									 PrtInHouseStk_InValPrtIntV=atoi(PrtInHouseStk_InValPrt);
									 PrtInHouseStkT_InValPrtV=atoi(PrtInHouseStkT_InValPrt);

									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], TRUE));

									ITKCALL(AOM_set_value_int(invalid_rowsTag[iInValCnt], "t5_SupplierEndInValid", PrtSuppEndStk_InValPrtIntV));
									ITKCALL(AOM_set_value_int(invalid_rowsTag[iInValCnt], "t5_InHouseStockInValid", PrtInHouseStk_InValPrtIntV));
									ITKCALL(AOM_set_value_int(invalid_rowsTag[iInValCnt], "t5_InHousetTotalInValid", PrtInHouseStkT_InValPrtV));
									ITKCALL(AOM_save_with_extensions(invalid_rowsTag[iInValCnt]));  //API Changed
									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], FALSE));
									printf("\n\n Update of Stock and Save Success for Invalid Part Details Parents..");fflush(stdout);								
									break;
								}
					
							}							
					
						}
					}
				}
				
			}
			
			
		}
			
	}
	
	
	return ifail;
}


extern int EPAInValidPrtStckUpdRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 3;
	int retValueType;
	int validRowCntInt=0;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;

	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EPAValidPrtUpdServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("EPAInValidPrtStckUpdServiceFnc",(USER_function_t)EPAInValidPrtStckUpdServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_EPAFuncStckServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(EPAInValidPrtStckUpdRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_EPAInValidPrtStckUpdFuncs_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_EPAInValidPrtStckUpdFuncs_register_callbacks...."); 
	printf("\n Before registoring userservice EPAInValidPrtStckUpdFuncs ...."); 
	ifail=CUSTOM_register_exit ( "tm_EPAInValidPrtStckUpdFuncs", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_EPAFuncStckServiceFnc);
	printf("\n After registoring userservice tm_EPAInValidPrtStckUpdFuncs....");
	return ( ITK_ok );
}

