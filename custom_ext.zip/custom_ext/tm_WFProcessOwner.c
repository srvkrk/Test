
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
* *------------------------------------------------------------------------------
** Filename		:	tm_WFProcessOwner.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   02-02-2024
* ENVIRONMENT	:   ITK
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 02/02/2024   	 Ketan Bhut			    Base Code

*****************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <ae/dataset.h>
#include <sa/sa.h>
#include <sys/stat.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <res/reservation.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <tccore/item_msg.h>
#include <epm/cr_effectivity.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <qry/qry.h>
#include <tccore/item.h>
#include <property/propdesc.h>
#include <tccore/grmtype.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPICKD(expr)ITK_CALL_CKD(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL_CKD(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


int tm_WFProcessOwner_assign( EPM_action_message_t msg )
{

	int				error_code	= ITK_ok;
	int             ifail				= 0;		
		
	char*   type_name;
	char*	CurrentTask			= NULL;
	char*	parent_name			= NULL;
	
	int		noAttachment			= 0;
	
	tag_t   Task_rev_tag        = NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t	rootTask			= NULLTAG;
	tag_t*	attachments			= NULLTAG;
	
	tag_t	tTask = msg.task;
	
	printf("\n ************** Ketan inside tm_WFProcessOwner_assign ***************\n ");fflush(stdout);
	
	// Control Object for tm_WFProcessOwner_assign
	
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl[3] = {"WFProcessOwner","User","0"};

	char* t5_Username = NULL;
	
    tag_t qryTagCntrl				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags	= NULLTAG;

	int n_entryCntrl		  = 3;
	int control_number_found = 0;;

	CALLAPICKD(QRY_find2("Control Objects...", &qryTagCntrl));

	if (qryTagCntrl)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPICKD(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));

		printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
	}

	if(control_number_found>0)
	{
		printf("\n Inside Control Object \n");fflush(stdout);

		if(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n tm_WFProcessOwner_assign \n"); fflush(stdout);

		if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\n CurrentTask => %s\n",CurrentTask);
		if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
		if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
		
		if(noAttachment > 0)
		{
			Task_rev_tag = attachments[0];
			if(TCTYPE_ask_object_type(Task_rev_tag,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
		    printf("\n type_name changes done: for workspaceobject => %s\n", type_name);fflush(stdout);
		}

		tag_t User_obj = list_of_WSO_cntrl_tags[0];
		CALLAPICKD(AOM_ask_value_string(User_obj,"t5_Userinfo1",&t5_Username));
		
		printf("\n t5_Username => %s \n",t5_Username);fflush(stdout);
		
		tag_t usertag = NULLTAG;
		CALLAPICKD(SA_find_user2(t5_Username, &usertag));
		CALLAPICKD(EPM_assign_responsible_party(tTask, usertag ));

		printf("\n User [%s] Set Successfully to [%s] \n",t5_Username,type_name);fflush(stdout);
		
	}
	else
	{
		printf("\n Control object for tm_WFProcessOwner_assign is OFF \n");fflush(stdout);
	}

	return error_code;
}

extern int tm_WFProcessOwner_assign_register_method(int *decision, va_list args)
{
	int ifail = ITK_ok;
	
	if( ITK_ok == EPM_register_action_handler("tm_WFProcessOwner_assign", "", tm_WFProcessOwner_assign))
	{
		//printf("\t\n Registered Action Handler tm_WFProcessOwner_assign \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler tm_WFProcessOwner_assign\n");fflush(stdout);
	}

	return ifail;
	
}

extern DLLAPI int tm_WFProcessOwner_register_callbacks()

{
	int ifail    = ITK_ok;
	//printf("\n Before registoring userservice....tm_WFProcessOwner");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_WFProcessOwner", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_WFProcessOwner_assign_register_method);
	//printf("\n ***~**** registered function tm_WFProcessOwner \n");	fflush(stdout);
	
	return ( ITK_ok );
}


