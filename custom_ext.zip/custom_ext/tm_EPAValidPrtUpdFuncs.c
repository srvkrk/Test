/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int EPAValidPrtUpdServiceFnc( void *retValue)
{

	int				ifail 	= ITK_ok;
	char *countValidPart= NULL;
	char *EPANo= NULL;
	char *detailValValid= NULL;
	char *detailValInValid= NULL;
	char *validRowCnt= NULL;
	char *InvalidRowCnt= NULL;
	//char *detailVal2= NULL;
	//char *detailVal3= NULL;
	char *srno_ValPrt= NULL;
	char *PrtType_ValPrt= NULL;
	char *PrtNo_ValPrt= NULL;
	char *PrtDesc_ValPrt= NULL;
	char *PrtRevSeq_ValPrt= NULL;
	char *PrtCS_ValPrt= NULL;
	char *PrtChgeType_ValPrt= NULL;
	char *PrtOldQty_ValPrt= NULL;
	char *validRowData= NULL;
	char *invalidRowData= NULL;
	char *fectinvalidRowData= NULL;
	char *fectValidRowData= NULL;
	char *PrtRev= NULL;
	char *PrtSeq= NULL;

	char *srno_InValPrt= NULL;
	char *PrtType_InValPrt= NULL;
	char *PrtNo_InValPrt= NULL;
	char *PrtDesc_InValPrt= NULL;
	char *PrtRevSeq_InValPrt= NULL;
	char *PrtCS_InValPrt= NULL;
	char *PrtChgeType_InValPrt= NULL;
	char *PrtOldQty_InValPrt= NULL;
	char *PrtRev1= NULL;
	char *PrtSeq1= NULL;
	char *new_srno_ValPrtSt= NULL;
	char *new_srno_InValPrtSt= NULL;
	char *srNoValid= NULL;
	char *srNoInValid= NULL;
	char *partTypeInValid= NULL;
	char *partTypeValid= NULL;

	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	int intvalidRowCnt=0;
	int intInvalidRowCnt=0;
	int n_valid_rows=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t* valid_Table_rows = NULLTAG;
	tag_t* valid_rowsTag = NULLTAG;
	tag_t* invalid_rowsTag = NULLTAG;
	tag_t* invalid_Table_rows = NULLTAG;
	int rcnt=0;
	int rcnt1=0;
	int rcnt2=0;
	int rcntVal=0;
	int srNoValidInt=0;
	int srno_ValPrtInt=0;
	int iValCnt=0;
	int new_srno_ValPrtInt=0;
	int n_invalid_rows=0;
	int iInValCnt=0;
	int srNoInValidInt=0;
	int srno_InValPrtInt=0;
	int new_srno_InValPrtInt=0;

	//USERARG_get_string_argument(&countValidPart);
	USERARG_get_string_argument(&EPANo);
	USERARG_get_string_argument(&validRowCnt);
	USERARG_get_string_argument(&detailValValid);
	USERARG_get_string_argument(&InvalidRowCnt);
	USERARG_get_string_argument(&detailValInValid);
		
	printf("\nArgument Received(EPAValidPrtUpdServiceFnc) EPANo=%s\n",EPANo);fflush(stdout);	
	printf("\nArgument Received(EPAValidPrtUpdServiceFnc) validRowCnt=%s\n",validRowCnt);fflush(stdout);	
	printf("\nArgument Received(EPAValidPrtUpdServiceFnc) detailValValid=%s\n",detailValValid);fflush(stdout);	
	printf("\nArgument Received(EPAValidPrtUpdServiceFnc) InvalidRowCnt=%s\n",InvalidRowCnt);fflush(stdout);	
	printf("\nArgument Received(EPAValidPrtUpdServiceFnc) detailValInValid=%s\n",detailValInValid);fflush(stdout);	

	if(tc_strcmp(EPANo,"")!=0)
	{
			
		qry_entries[0] ="item_id";
		qry_values[0] = EPANo;

		printf("\n Qurying the EPA");fflush(stdout);

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		if(n_tags_found>0)
		{
			item = itemclass[0];
			
			ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
			if(epa_rev_tag!=NULLTAG)
			{
			
				printf("\n Qurying the EPA done and foudn the EPA Tag..");fflush(stdout);

				intvalidRowCnt = atoi(validRowCnt); // Using atoi()
				printf("\nThe value of intvalidRowCnt : %d", intvalidRowCnt);fflush(stdout);

				intInvalidRowCnt = atoi(InvalidRowCnt); // Using atoi()
				printf("\nThe value of intInvalidRowCnt : %d", intInvalidRowCnt);fflush(stdout);

				
				
				
				if((intvalidRowCnt>0)|| (intInvalidRowCnt>0))
				{
					ITKCALL(AOM_lock(epa_rev_tag));
					
					///////////////////////VALID PART UPDATION START//////////////////////////////////

					if(intvalidRowCnt>0)
					{
					
						char *arrayVadDt[intvalidRowCnt];
						
						for(rcntVal=0;rcntVal<intvalidRowCnt;rcntVal++)
						{
							if(tc_strcmp(detailValValid,"")!=0)
							{
								
								if(rcntVal==0)
								{
									validRowData=tc_strtok(detailValValid,"~");
								}
								else
								{
									validRowData=tc_strtok(NULL,"~");
								}

								printf("\n validRowData :[%s] \n",validRowData);fflush(stdout);

								arrayVadDt[rcntVal]=validRowData;
								printf("\n arrayVadDt[rcntVal] :[%s] \n",arrayVadDt[rcntVal]);fflush(stdout);					
													

							}					

						}

							
						ITKCALL(AOM_insert_table_rows(epa_rev_tag, "t5_EpaCmTabValid", 0,intvalidRowCnt, &valid_Table_rows));
						printf("\n\n Inside else of Table Rows Inserted Success\n");fflush(stdout);
						
						
						for(rcnt=0;rcnt<intvalidRowCnt;rcnt++)
						{
								
							fectValidRowData=arrayVadDt[rcnt];
							printf("\n fectValidRowData :[%s] \n",fectValidRowData);fflush(stdout);
							
							srno_ValPrt=tc_strtok(fectValidRowData,"-");
							PrtType_ValPrt = tc_strtok(NULL,"-");
							PrtNo_ValPrt = tc_strtok(NULL,"-");
							PrtDesc_ValPrt = tc_strtok(NULL,"-");
							PrtRevSeq_ValPrt = tc_strtok(NULL,"-");
							PrtCS_ValPrt = tc_strtok(NULL,"-");
							PrtChgeType_ValPrt = tc_strtok(NULL,"-");
							PrtOldQty_ValPrt = tc_strtok(NULL,"-");

							printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_ValPrt,PrtType_ValPrt,PrtNo_ValPrt,PrtDesc_ValPrt,PrtRevSeq_ValPrt,PrtCS_ValPrt
									,PrtChgeType_ValPrt,PrtOldQty_ValPrt);fflush(stdout);
							
							if(tc_strcmp(PrtRevSeq_ValPrt,"")!=0) 
							{
								PrtRev=tc_strtok(PrtRevSeq_ValPrt,";");
								PrtSeq=tc_strtok(NULL,";");
							}

							printf("\n PrtRev [%s] PrtSeq [%s]..",PrtRev,PrtSeq);fflush(stdout);

							if((tc_strcmp(srno_ValPrt,"")!=0) && (tc_strcmp(srno_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_ESrNoValid", srno_ValPrt));
							if((tc_strcmp(PrtType_ValPrt,"")!=0) && (tc_strcmp(PrtType_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PartTypeValid", PrtType_ValPrt));
							if((tc_strcmp(PrtNo_ValPrt,"")!=0) && (tc_strcmp(PrtNo_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PartNumberValid", PrtNo_ValPrt));
							if((tc_strcmp(PrtDesc_ValPrt,"")!=0) && (tc_strcmp(PrtDesc_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_NomenclatureValid", PrtDesc_ValPrt));
							if((tc_strcmp(PrtRev,"")!=0) && (tc_strcmp(PrtRev,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_RevisionValid", PrtRev));
							if((tc_strcmp(PrtSeq,"")!=0) && (tc_strcmp(PrtSeq,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_SequenceValid", PrtSeq));				
							if((tc_strcmp(PrtCS_ValPrt,"")!=0) && (tc_strcmp(PrtCS_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_PunMakeBuyIndicatorValid", PrtCS_ValPrt));
							if((tc_strcmp(PrtChgeType_ValPrt,"")!=0) && (tc_strcmp(PrtChgeType_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_changeTypeValid", PrtChgeType_ValPrt));
							if((tc_strcmp(PrtOldQty_ValPrt,"")!=0) && (tc_strcmp(PrtOldQty_ValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(valid_Table_rows[rcnt], "t5_NewQtyLValid", PrtOldQty_ValPrt));
							
							ITKCALL(AOM_save_with_extensions(valid_Table_rows[rcnt]));
							printf("\n\n Save Success");fflush(stdout);

						}

						
						ITKCALL(AOM_ask_table_rows(epa_rev_tag,"t5_EpaCmTabValid", &n_valid_rows,&valid_rowsTag));
						printf("\n no of table rows fron Valid Parts are %d \n", n_valid_rows);fflush(stdout);
						if(n_valid_rows>0)
						{
							for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
							{
								ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_ESrNoValid", &srNoValid));
								printf("\n srNoValid [%s]..",srNoValid);fflush(stdout);
								
								ITKCALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_PartTypeValid", &partTypeValid));
								printf("\n partTypeValid [%s]..",partTypeValid);fflush(stdout);	

								if((tc_strcmp(srNoValid,"")!=0)  && (tc_strcmp(partTypeValid,"Parent")==0) )
								{
									
									new_srno_ValPrtInt=new_srno_ValPrtInt+1;
									//srNoValidInt=atoi(srNoValid);
								
									//srno_ValPrtInt=atoi(srno_ValPrt);

									//new_srno_ValPrtInt=iValCnt+srNoValidInt;
									printf("\n\n new_srno_ValPrtInt %d",new_srno_ValPrtInt);fflush(stdout);

									new_srno_ValPrtSt=(char *) MEM_alloc(50);

									sprintf(new_srno_ValPrtSt, "%d", new_srno_ValPrtInt);
									ITKCALL(AOM_refresh(valid_rowsTag[iValCnt], TRUE));

									ITKCALL(AOM_set_value_string(valid_rowsTag[iValCnt], "t5_ESrNoValid", new_srno_ValPrtSt));
									ITKCALL(AOM_save_with_extensions(valid_rowsTag[iValCnt]));
									ITKCALL(AOM_refresh(valid_rowsTag[iValCnt], FALSE));
									printf("\n\n Update of SRNo and Save Success");fflush(stdout);
								}
								else if((tc_strcmp(srNoValid,"")!=0) && (tc_strcmp(partTypeValid,"Child")==0) )
								{
									new_srno_ValPrtSt=(char *) MEM_alloc(50);

									printf("\n\n inside else new_srno_ValPrtInt for child %d",new_srno_ValPrtInt);fflush(stdout);
									sprintf(new_srno_ValPrtSt, "%d", new_srno_ValPrtInt);

									ITKCALL(AOM_refresh(valid_rowsTag[iValCnt], TRUE));

									ITKCALL(AOM_set_value_string(valid_rowsTag[iValCnt], "t5_ESrNoValid", new_srno_ValPrtSt));
									ITKCALL(AOM_save_with_extensions(valid_rowsTag[iValCnt]));
									ITKCALL(AOM_refresh(valid_rowsTag[iValCnt], FALSE));
									printf("\n\n Update of SRNo and Save Success for Invalid Part Details Child..");fflush(stdout);
								
								}
								
							}
						}
					}
					///////////////////////VALID PART UPDATION END//////////////////////////////////


					
					///////////////////////INVALID PART UPDATION END//////////////////////////////////

					if(intInvalidRowCnt>0)
					{
						
						ITKCALL(AOM_insert_table_rows(epa_rev_tag, "t5_EpaCrTabInValid", 0,intInvalidRowCnt, &invalid_Table_rows));
						printf("\n\n Inside else of Table Rows Inserted Success for n_invalid_rows..\n");fflush(stdout);
						
						char *arrayInvadDt[intInvalidRowCnt];
						
						for(rcnt1=0;rcnt1<intInvalidRowCnt;rcnt1++)
						{
							if(tc_strcmp(detailValInValid,"")!=0)
							{
								
								if(rcnt1==0)
								{
									invalidRowData=tc_strtok(detailValInValid,"~");
								}
								else
								{
									invalidRowData=tc_strtok(NULL,"~");
								}

								printf("\n invalidRowData :[%s] \n",invalidRowData);fflush(stdout);

								arrayInvadDt[rcnt1]=invalidRowData;
								printf("\n arrayInvadDt[rcnt1] :[%s] \n",arrayInvadDt[rcnt1]);fflush(stdout);

							}					

						}

						for(rcnt2=0;rcnt2<intInvalidRowCnt;rcnt2++)
						{
							fectinvalidRowData=arrayInvadDt[rcnt2];
							printf("\n fectinvalidRowData :[%s] \n",fectinvalidRowData);fflush(stdout);

							srno_InValPrt=tc_strtok(fectinvalidRowData,"-");
							PrtType_InValPrt = tc_strtok(NULL,"-");
							PrtNo_InValPrt = tc_strtok(NULL,"-");
							PrtDesc_InValPrt = tc_strtok(NULL,"-");
							PrtRevSeq_InValPrt = tc_strtok(NULL,"-");
							PrtCS_InValPrt = tc_strtok(NULL,"-");
							PrtChgeType_InValPrt = tc_strtok(NULL,"-");
							PrtOldQty_InValPrt = tc_strtok(NULL,"-");

							printf("\n Printing the first value :[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]:[%s]\n",srno_InValPrt,PrtType_InValPrt,PrtNo_InValPrt,PrtDesc_InValPrt,PrtRevSeq_InValPrt,PrtCS_InValPrt
								,PrtChgeType_InValPrt,PrtOldQty_InValPrt);fflush(stdout);
							
							
							if(tc_strcmp(PrtRevSeq_InValPrt,"")!=0) 
							{
								PrtRev1=tc_strtok(PrtRevSeq_InValPrt,";");
								PrtSeq1=tc_strtok(NULL,";");
							}

							printf("\n PrtRev1 [%s] PrtSeq1 [%s]..",PrtRev1,PrtSeq1);fflush(stdout);

							if((tc_strcmp(srno_InValPrt,"")!=0) && (tc_strcmp(srno_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_ESrNoInValid", srno_InValPrt));
							if((tc_strcmp(PrtType_InValPrt,"")!=0) && (tc_strcmp(PrtType_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PartTypeInValid", PrtType_InValPrt));
							if((tc_strcmp(PrtNo_InValPrt,"")!=0) && (tc_strcmp(PrtNo_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PartNumberInValid", PrtNo_InValPrt));
							if((tc_strcmp(PrtDesc_InValPrt,"")!=0) && (tc_strcmp(PrtDesc_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_NomenclatureInValid", PrtDesc_InValPrt));
							if((tc_strcmp(PrtRev1,"")!=0) && (tc_strcmp(PrtRev1,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_RevisionInValid", PrtRev1));
							if((tc_strcmp(PrtSeq1,"")!=0) && (tc_strcmp(PrtSeq1,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_SequenceInValid", PrtSeq1));				
							if((tc_strcmp(PrtCS_InValPrt,"")!=0) && (tc_strcmp(PrtCS_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_PunMakeBuyIndicatorInVal", PrtCS_InValPrt));
							if((tc_strcmp(PrtChgeType_InValPrt,"")!=0) && (tc_strcmp(PrtChgeType_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_changeTypeInValid", PrtChgeType_InValPrt));
							if((tc_strcmp(PrtOldQty_InValPrt,"")!=0) && (tc_strcmp(PrtOldQty_InValPrt,"^")!=0)) ITKCALL(AOM_set_value_string(invalid_Table_rows[rcnt2], "t5_OldQtyLInValid", PrtOldQty_InValPrt));
							
							ITKCALL(AOM_save_with_extensions(invalid_Table_rows[rcnt2]));
							printf("\n\n Save Success");fflush(stdout);


						
						}

						ITKCALL(AOM_ask_table_rows(epa_rev_tag,"t5_EpaCrTabInValid", &n_invalid_rows,&invalid_rowsTag));
						printf("\n no of table rows fron InValid Parts are %d \n", n_invalid_rows);fflush(stdout);
						
						if(n_invalid_rows>0)
						{
							for(iInValCnt=0;iInValCnt<n_invalid_rows;iInValCnt++)
							{
								ITKCALL(AOM_ask_value_string(invalid_rowsTag[iInValCnt], "t5_ESrNoInValid", &srNoInValid));
								printf("\n srNoInValid [%s]..",srNoInValid);fflush(stdout);
								
								ITKCALL(AOM_ask_value_string(invalid_rowsTag[iInValCnt], "t5_PartTypeInValid", &partTypeInValid));
								printf("\n partTypeInValid [%s]..",partTypeInValid);fflush(stdout);	


								if((tc_strcmp(srNoInValid,"")!=0) && (tc_strcmp(partTypeInValid,"Parent")==0) ) 
								{
									
									new_srno_InValPrtInt=new_srno_InValPrtInt+1;
									//srNoValidInt=atoi(srNoValid);
								
									//srno_ValPrtInt=atoi(srno_ValPrt);

									//new_srno_ValPrtInt=iValCnt+srNoValidInt;
									printf("\n\n new_srno_InValPrtInt for Parent %d",new_srno_InValPrtInt);fflush(stdout);

									new_srno_InValPrtSt=(char *) MEM_alloc(50);

									sprintf(new_srno_InValPrtSt, "%d", new_srno_InValPrtInt);

									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], TRUE));

									ITKCALL(AOM_set_value_string(invalid_rowsTag[iInValCnt], "t5_ESrNoInValid", new_srno_InValPrtSt));
									ITKCALL(AOM_save_with_extensions(invalid_rowsTag[iInValCnt]));
									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], FALSE));
									printf("\n\n Update of SRNo and Save Success for Invalid Part Details Parents..");fflush(stdout);
								}
								else if((tc_strcmp(srNoInValid,"")!=0) && (tc_strcmp(partTypeInValid,"Child")==0) )
								{
									new_srno_InValPrtSt=(char *) MEM_alloc(50);

									printf("\n\n new_srno_InValPrtInt for child %d",new_srno_InValPrtInt);fflush(stdout);
									sprintf(new_srno_InValPrtSt, "%d", new_srno_InValPrtInt);

									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], TRUE));

									ITKCALL(AOM_set_value_string(invalid_rowsTag[iInValCnt], "t5_ESrNoInValid", new_srno_InValPrtSt));
									ITKCALL(AOM_save_with_extensions(invalid_rowsTag[iInValCnt]));
									ITKCALL(AOM_refresh(invalid_rowsTag[iInValCnt], FALSE));
									printf("\n\n Update of SRNo and Save Success for Invalid Part Details Child..");fflush(stdout);
								
								}
							}

								
						}
					}			

					///////////////////////INVALID PART UPDATION END//////////////////////////////////


					ITKCALL(AOM_unlock(epa_rev_tag));

					ITKCALL(AOM_refresh(epa_rev_tag, FALSE));
					printf("\n\n Refresh the EPA Object");fflush(stdout);
					//Printing the first value :[1]:[Parent]:[544263200113]:[REINF ASSY B PLR LH]:[NR;2]:[]:[Modified]:[]
				}
			
			}
		}
	
	
	}


	return ifail;
}


extern int EPAValidPrtUpdRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 5;
	int retValueType;
	int validRowCntInt=0;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;

	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EPAValidPrtUpdServiceFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("EPAValidPrtUpdServiceFnc",(USER_function_t)EPAValidPrtUpdServiceFnc,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}

extern int All_EPAFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(EPAValidPrtUpdRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_EPAValidPrtUpdFuncs_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_EPAValidPrtUpdFuncs_register_callbacks...."); 
	printf("\n Before registoring userservice EPAValidPrtUpdFuncs ...."); 
	ifail=CUSTOM_register_exit ( "tm_EPAValidPrtUpdFuncs", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_EPAFuncServiceFnc);
	printf("\n After registoring userservice tm_EPAValidPrtUpdFuncs....");
	return ( ITK_ok );
}

