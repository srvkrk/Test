//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the implementation for the Business Object T5_MatCde

*/

#include <T5_tm_mcnlib/T5_MatCde.hxx>
#include <T5_tm_mcnlib/T5_MatCdeImpl.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <itk/mem.h>

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_MatCdeImpl::T5_MatCdeImpl(T5_MatCde& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_MatCdeImpl::T5_MatCdeImpl( T5_MatCde& busObj )
   : T5_MatCdeGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_MatCdeImpl::~T5_MatCdeImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_MatCdeImpl::~T5_MatCdeImpl()
{
}

//----------------------------------------------------------------------------------
// T5_MatCdeImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_MatCdeImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_MatCdeGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int getNextMatCdeNumber(char **tempobj_name)
{
	int ifail = ITK_ok;
	char *qryid;
	char *clazname="T5_MatCde";
	char *item_idval = NULL;
	*tempobj_name=(char *)MEM_alloc(6);
	qryid=(char *)MEM_alloc(5);
	tc_strcpy(qryid,"6*");

	tc_strcpy(*tempobj_name,"");

		const char *obj_name={qryid};
		const char *attr="object_name";

		POM_enquiry_create("matcde_enq");

		const char *sel_attrs[1] = {"puid"};

		POM_enquiry_add_select_attrs("matcde_enq", clazname, 1, sel_attrs);
		POM_enquiry_set_string_value("matcde_enq", "value", 1, &obj_name,POM_enquiry_bind_value);
		POM_enquiry_set_attr_expr ("matcde_enq", "expression", clazname, attr, POM_enquiry_like, "value");
		POM_enquiry_set_where_expr ("matcde_enq", "expression" );

		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		POM_enquiry_add_order_attr ( "matcde_enq",clazname,"object_name",POM_enquiry_desc_order);

		POM_enquiry_execute("matcde_enq", &rows, &columns, &report);

		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of row : %d cols : %d \n",rows,columns);fflush(stdout);

			AOM_ask_value_string(objtag,"object_name",&item_idval);
			printf("\n The Mat Code number is : %s \n",item_idval);fflush(stdout);

			int		runningSrl;
			printf("\n \n Recieved Mat Code number is  :  %s \n",item_idval);fflush(stdout);
			runningSrl = atoi(item_idval);
			runningSrl = runningSrl + 1;

			printf("\n \n converted to int next mat code number will be :  %d \n",runningSrl);fflush(stdout);
			char runningSrlChar[10];
			sprintf(runningSrlChar, "%05d", runningSrl);
			tc_strcat(*tempobj_name,runningSrlChar);
		}
		else
		{
			tc_strcat(*tempobj_name,"60000");
		}
		POM_enquiry_delete("matcde_enq");
		//item_id=BscDmlA;
		printf("\n \n Final Build mat code ID will be :  %s \n",*tempobj_name);fflush(stdout);

}


/**
 * Description for the Finalize Create Input
 * @param creInput - desc for  creInput parameter
 * @return - Return desc for Initialize for Create
 */
int  T5_MatCdeImpl::finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;
    bool isNULL;
    char *tempobj_name=NULL;

    // Call the parent Implementation
    ifail = super_finalizeCreateInputBase(  creInput );

    // Your Implementation
    
    ifail=getNextMatCdeNumber(&tempobj_name);

    creInput->setString("object_name",tempobj_name,false);

    printf("\n T5_SupSpcImpl::finalizeCreateInputBase...");fflush(stdout);

    return ifail;
}
