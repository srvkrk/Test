#include "TMLLibrary_server_exits.h"




EPM_decision_t tm_COCReviewassignVali (EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int	taskflag            = 0;
	int	prtcountt           = 0;
	int	CoCcount            = 0;
	int	jk                  = 0;
	int	FlderSize           = 0;
	int	FlderObjCount       = 0;
	int	fld       = 0;
	int	count       = 0;
	int	COCReviewerFlag       = 0;
	int	CorrectCOCRevFlag       = 0;
	tag_t  roottask			= NULLTAG;
	tag_t  prtrel_type		= NULLTAG;
	char * dmlTaskNo	    = NULL;
	char * DMLtype		    = NULL;
	char * sDMLno		    = NULL;
	char * ObjTyp		    = NULL;
	char * PartMstr_no	    = NULL;
	char * Prtrev_idd	    = NULL;
	char * Prtrel_status    = NULL;
	char * des_group	    = NULL;
	char * Prt_object_type  = NULL;
	char * partdesgrpvar    = NULL;
	char * type_name        = NULL;
	char * CoCReviewr       = NULL;
	char * FldrName         = NULL;
	char * assignee         = NULL;

	tag_t  objTypTag        = NULLTAG;
	tag_t  ObjTypDmlCoC     = NULLTAG;
	tag_t  DMLRevTg         = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLTaskTag       = NULLTAG;
	tag_t  dml_CoC_rel_type = NULLTAG;
	tag_t  DmlCoCTag        = NULLTAG;
	tag_t  query        = NULLTAG;

	tag_t  *DMLRevision     = NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  *CMParts	        = NULLTAG;
	tag_t  *DmlCoC	        = NULLTAG;
	tag_t  *FolderObj_tag	= NULLTAG;
	tag_t  *contrlObjs	= NULLTAG;

	char *sDRInfo1   = NULL;
	char *sDRInfo2   = NULL;
	char *sDRInfo3   = NULL;
	char *sDRInfo4   = NULL;
	//char *CorrectCOCRevFlag   = NULL;

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));

	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	logical is_latest;

	EPM_decision_t decision = EPM_go;

	printf("\n tm_COCReviewassignVali Function started...");fflush(stdout);
	TC_write_syslog("\n tm_COCReviewassignVali Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_COCReviewassignVali:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_COCReviewassignVali:INSIDE Attachments.");fflush(stdout);
			DMLTaskTag=taskAttachments[i];

			if (DMLTaskTag != NULLTAG)
			{

				qry_entries[0] ="SYSCD";
				qry_values[0]  ="COTASKVAli";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_COCReviewassignVali Control objects : count==>%d \n",count);fflush(stdout);

				if (count>0)
				{
				
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sDRInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sDRInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sDRInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sDRInfo4));
					printf("\n tm_COCReviewassignVali L1:sDRInfo1 is : [%s]  L2:sDRInfo2 is : [%s]  L3:sDRInfo3 is : [%s] L4:sDRInfo4 is : [%s]\n",sDRInfo1,sDRInfo2,sDRInfo3,sDRInfo4);fflush(stdout);

					if(tc_strstr(sDRInfo2,"VALI1") == NULL)
					{
						taskflag=1;
						printf("\n tm_COCReviewassignVali--taskflag= %d ",taskflag);fflush(stdout);

						ITK_CALL(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
						printf("\n tm_COCReviewassignVali objtype found \n");fflush(stdout);

						ITK_CALL(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n tm_COCReviewassignVali  ObjTyp is %s\n", ObjTyp);fflush(stdout);

						if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
						{
							if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
							printf("\n tm_COCReviewassignVali--DML Task No: [%s] \n", dmlTaskNo);fflush(stdout);
							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n tm_COCReviewassignVali--DML Revision from Task for : %d",countt);fflush(stdout);


								for (j=0;j<countt ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n tm_COCReviewassignVali--is_latest  is : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n tm_COCReviewassignVali--is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];
										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										printf("\n tm_COCReviewassignVali--for sDMLno : [%s] ",sDMLno);fflush(stdout);

										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										printf(" tm_COCReviewassignVali Release Type: [%s]", DMLtype); fflush(stdout);


										if(GRM_find_relation_type("CMReferences", &prtrel_type)!=ITK_ok)PrintErrorStack();
										if (tsk_dml_rel_type!=NULLTAG)
										{
											if(GRM_list_secondary_objects_only(DMLTaskTag,prtrel_type,&prtcountt,&CMParts)!=ITK_ok)PrintErrorStack();
											printf("\n tm_COCReviewassignVali--DML Revision from Task for prtcountt : %d",prtcountt);fflush(stdout);
											if (prtcountt>0)
											{
												for (k=0; k<prtcountt; k++)
												{
													printf("\n tm_COCReviewassignVali :Design k:%d",k);fflush(stdout);
													if(AOM_ask_value_string(CMParts[k],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
													printf("\n tm_COCReviewassignVali :Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);

													/*if(strcmp(Prt_object_type,"Folder")!=0)
													{
														// put condition for design rev, to avoid other attachments.
														if(AOM_ask_value_string(CMParts[k],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(CMParts[k], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(CMParts[k], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(CMParts[k], "t5_DesignGrp", &des_group)!=ITK_ok)PrintErrorStack();
														printf("\n tm_COCReviewassignVali:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s des_group:%s", PartMstr_no,Prtrev_idd,Prtrel_status,des_group);fflush(stdout);

														partdesgrpvar = MEM_alloc(50);

														tc_strcat(partdesgrpvar,des_group);
														tc_strcat(partdesgrpvar,"_Manager");
														printf("\n tm_COCReviewassignVali partdesgrpvar is: %s \n",partdesgrpvar);fflush(stdout);

														if(GRM_find_relation_type("HasParticipant", &dml_CoC_rel_type));
														if (dml_CoC_rel_type!=NULLTAG)
														{
															printf("\n tm_COCReviewassignVali-->inside HasParticipant..");fflush(stdout);
															if(GRM_list_secondary_objects_only(DMLTaskTag,dml_CoC_rel_type,&CoCcount,&DmlCoC));
															printf("\n tm_COCReviewassignVali-->CoCcount count: %d ",CoCcount);fflush(stdout);
															for (jk=0;jk<CoCcount ;jk++ )
															{
																DmlCoCTag = DmlCoC[jk];
																if(TCTYPE_ask_object_type(DmlCoCTag,&ObjTypDmlCoC));
																if(TCTYPE_ask_name2(ObjTypDmlCoC,&type_name));
																printf("\n tm_COCReviewassignVali TASK:DML: type_name7 :: %s.", type_name);fflush(stdout);
																if (strcmp(type_name,"T5_CoCoCReview")==0)
																{
																	if(AOM_UIF_ask_value(DmlCoCTag,"fnd0AssigneeUser",&CoCReviewr));
																	printf("\n tm_COCReviewassignVali TASK: COC Reviewer: [%s]  ",CoCReviewr);fflush(stdout);

																	if (tc_strstr(CoCReviewr,partdesgrpvar)==NULL)
																	{
																		printf("\n tm_COCReviewassignVali Condition 3 found"); fflush(stdout);
																		printf("\n************************ tm_COCReviewassignVali CoC Reviewer is not present***************************** \n"); fflush(stdout);
																		printf("\n************************ tm_COCReviewassignVali EPM_NOGO***************************** \n"); fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign the CoC Reviewer to CO task for respective design group of part attached to CO task:",partdesgrpvar);
																		decision = EPM_nogo;
																		return decision;
																	}
																}
															}
														}

													}*/
													//else
													//{

														printf("\n tm_COCReviewassignVali X67: Expanssion for Folder.");fflush(stdout);
														if(AOM_ask_value_string(CMParts[k],"object_name",&FldrName)!=ITK_ok)PrintErrorStack();
														printf("\n tm_COCReviewassignVali X68:FldrName:: %s\n", FldrName);fflush(stdout);
														
														printf("\n tm_COCReviewassignVali X69: getting parts.\n");fflush(stdout);
														if(FL_ask_size(CMParts[k],&FlderSize));
														printf("\n tm_COCReviewassignVali X70:FlderSize is:   %d\n",FlderSize);fflush(stdout);
														if(FL_ask_references(CMParts[k],FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag));
														printf("\n tm_COCReviewassignVali X71:FlderObjCount is..:   %d\n",FlderObjCount);fflush(stdout);
														if(FlderObjCount>0)
														{
															fld=0;
															for (fld=0;fld<FlderObjCount;fld++)
															{
																if(AOM_ask_value_string(FolderObj_tag[fld],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																if(AOM_UIF_ask_value(FolderObj_tag[fld], "t5_DesignGrp", &des_group)!=ITK_ok)PrintErrorStack();
																printf("\n tm_COCReviewassignVali X72:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s des_group:%s", PartMstr_no,Prtrev_idd,Prtrel_status,des_group);fflush(stdout);

																partdesgrpvar = MEM_alloc(50);
																tc_strcpy(partdesgrpvar,"");
																tc_strcat(partdesgrpvar,des_group);
																tc_strcat(partdesgrpvar,"_Managers");
																printf("\n tm_COCReviewassignVali partdesgrpvar is: %s \n",partdesgrpvar);fflush(stdout);

																if(GRM_find_relation_type("HasParticipant", &dml_CoC_rel_type));
																if (dml_CoC_rel_type!=NULLTAG)
																{
																	printf("\n tm_COCReviewassignVali-->inside HasParticipant..");fflush(stdout);
																	if(GRM_list_secondary_objects_only(DMLTaskTag,dml_CoC_rel_type,&CoCcount,&DmlCoC));
																	printf("\n tm_COCReviewassignVali-->CoCcount count: %d ",CoCcount);fflush(stdout);
																	COCReviewerFlag=0;
																	CorrectCOCRevFlag=0;
																	for (jk=0;jk<CoCcount ;jk++ )
																	{
																		DmlCoCTag = DmlCoC[jk];
																		if(TCTYPE_ask_object_type(DmlCoCTag,&ObjTypDmlCoC));
																		if(TCTYPE_ask_name2(ObjTypDmlCoC,&type_name));
																		
																		printf("\n tm_COCReviewassignVali TASK:DML: type_name7 :: %s.", type_name);fflush(stdout);
																		if (strcmp(type_name,"T5_CoCoCReview")==0)
																		{
																			COCReviewerFlag=1;
																			if(AOM_UIF_ask_value(DmlCoCTag,"fnd0AssigneeUser",&CoCReviewr));
																			printf("\n tm_COCReviewassignVali TASK: COC Reviewer: [%s]  ",CoCReviewr);fflush(stdout);

																			if(AOM_UIF_ask_value(DmlCoCTag,"assignee",&assignee));
																			printf("\n tm_COCReviewassignVali TASK: COC Reviewer assignee: [%s]  ",assignee);fflush(stdout);
																			if (tc_strstr(assignee,partdesgrpvar)!=NULL)
																			{
																				CorrectCOCRevFlag=1;
																				printf("\n tm_COCReviewassignVali CorrectCOCRevFlag: %d",CorrectCOCRevFlag); fflush(stdout);
																				break;
																			}
																			/*if (tc_strstr(assignee,partdesgrpvar)==NULL)
																			{
																				printf("\n tm_COCReviewassignVali Condition 3 found"); fflush(stdout);
																				printf("\n************************ tm_COCReviewassignVali CoC Reviewer is not present***************************** \n"); fflush(stdout);
																				printf("\n************************ tm_COCReviewassignVali EPM_NOGO***************************** \n"); fflush(stdout);
																				EMH_clear_errors();
																				EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign the CoC Reviewer from respective group:",partdesgrpvar);
																				decision = EPM_nogo;
																				return decision;
																			}*/
																		}
																	}
																	if (COCReviewerFlag ==0)
																	{
																		printf("\n not single CO reviewer assigned... \n"); fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_err,"Please assign the CoC Reviewer from respective group");
																		decision = EPM_nogo;
																		return decision;
																	}
																	if (CorrectCOCRevFlag ==0)
																	{
																		printf("\n tm_COCReviewassignVali Condition 3 found"); fflush(stdout);
											
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign the CoC Reviewer from respective group:",partdesgrpvar);
																		decision = EPM_nogo;
																		return decision;
																		//ERROR
																	}
																	
																}
															}
														}
														
													//}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	/*if(sDRInfo1){MEM_free(sDRInfo1);}
	if(sDRInfo2){MEM_free(sDRInfo2);}
	if(sDRInfo3){MEM_free(sDRInfo3);}
	if(sDRInfo4){MEM_free(sDRInfo4);}
	if(dmlTaskNo){MEM_free(dmlTaskNo);}
	if(sDMLno){MEM_free(sDMLno);}
	if(DMLtype){MEM_free(DMLtype);}
	if(Prt_object_type){MEM_free(Prt_object_type);}
	if(FldrName){MEM_free(FldrName);}
	if(PartMstr_no){MEM_free(PartMstr_no);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(Prtrel_status){MEM_free(Prtrel_status);}
	if(des_group){MEM_free(des_group);}
	if(CoCReviewr){MEM_free(CoCReviewr);}
	if(assignee){MEM_free(assignee);}*/
	printf("\n tm_COCReviewassignVali Function end...");fflush(stdout);
	TC_write_syslog("\n tm_COCReviewassignVali Function end...");
	return decision;
}