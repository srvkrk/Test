/********************************************************************************************************
*  File			: action_on_dataset.c
*  Created By	: Prachi Wade
*  Created On	: 09-May-2011
*  Project		: TCUA
*  Purpose		: Custom user exit for - checkout,checkin and cancelcheckout of an item alongwith dataset
*  Arguments	:

*  Modification History :
*  S.No    Date     CR      Modified By         Modification Notes
*1             01/09/2011    Anil Gautam		setting mod desc null after checkout the design object.
*2           10/11/2012	Sharvari Karale	Handled checkin/checkout and save process for PROE datasets .
*3           04/05/2016	Deepti Meshram	Handled single release status while doing checkin/checkout of Design Revision .
*4           19/10/2016	Muktesh	Cancel Checkout and closed BOM window.
*5			 13/01/2018		Upendra Patil		Validation on checkIn for CATIA dataset attachment based on part type.
********************************************************************************************************/
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <time.h>
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define EXIT_IF_NULL(X) (check_value(#X, (X)))
//PrintErrorStack();

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static int t5UpdateLifecycleStateAD(tag_t object_tag, char* lifecycleStateName)
{
	int n_values_checkin = 0;
	int cunt1 = 0;
	int				ifail=0;

	char *class_name = NULL;

	tag_t		class_id				=     NULLTAG;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	tag_t			status_rel					= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical			retain							= 0;

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
			printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_save_instances(1,&object_tag,1));

			CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

			CALLAPI(AOM_lock(object_tag));

			CALLAPI(AOM_save(object_tag));
			CALLAPI(AOM_refresh(object_tag,1));

		}

		 CALLAPI(AOM_unlock(object_tag));
	}

	if (CR_create_release_status(lifecycleStateName,&status_rel))PrintErrorStack();
	if(EPM_add_release_status(status_rel,1,&object_tag,retain))PrintErrorStack();

	return 0;
}

//CATIA and PRO/E Specific Validation on Dataset to check whether Named Reference relationship file contains Physical File.
//Pro/E Specific Validation to
static int t5CheckForEmptyNamedRef(tag_t dataset, char* ObjectClassType, char* reference_name, tag_t namedRefTag)
{
	int				ifail=0;
	int i = 0;
	int instFlagInt = 0;
	int gen_found = 0;
	char* prevVerFileExt = NULL;
	char* prevVerFileExtDup = NULL;
	char* currentVerFileExt = NULL;
	char* currentVerFileExtDup = NULL;

	char* prevRevOrigFileNameDup = NULL;
	char* prevRevOrigFileName = NULL;
	char* CurrentRevOrigFileNameDup = NULL;
	char* CurrentRevOrigFileName = NULL;

	tag_t referenced_object = NULLTAG;
	tag_t* generic_tagS = NULLTAG;

	AE_reference_type_t my_ref_type;

	printf("\nt5CheckForEmptyNamedRef :: Inside Function\n");

	CALLAPI(AE_ask_dataset_named_ref2(dataset, reference_name, &my_ref_type, &referenced_object));

	if(referenced_object == NULLTAG)
	{
		if(tc_strcmp(ObjectClassType,"ProAsm") == 0 || tc_strcmp(ObjectClassType,"ProPrt") == 0)
		{
			CALLAPI(AOM_get_value_tags(dataset,"IPEM_master_dependency",&gen_found,&generic_tagS));
			printf("\n t5CheckForEmptyNamedRef :: Generic Count is %d",gen_found);fflush(stdout);
			if (gen_found>0)
			{
				instFlagInt = 1;
			}
		}
	}

	printf("\nValue of instFlagInt -- %d", instFlagInt);fflush(stdout);
	if(instFlagInt == 0)
	{
		if(referenced_object == NULLTAG)
		{
			printf("\n*** t5CheckForEmptyNamedRef :: WARNING :: No CAD File attached to Dataset in the Named Reference Relationship ***\n");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"No CAD File attached to Dataset in the Named Reference Relationship. \nTo Verify :: RIGHT CLICK Dataset --> NAMED REFERENCES");
			printf("\nt5CheckForEmptyNamedRef :: 1 Exiting Function\n");fflush(stdout);
			return ITK_err;
		}
		else
		{
			if(namedRefTag != NULLTAG)
			{
				if(AOM_ask_value_string(namedRefTag,"file_ext",&prevVerFileExtDup)!=ITK_ok)PrintErrorStack();
				if(prevVerFileExtDup) tc_strdup(prevVerFileExtDup, &prevVerFileExt);

				if(AOM_ask_value_string(referenced_object,"file_ext",&currentVerFileExtDup)!=ITK_ok) PrintErrorStack();
				if(currentVerFileExtDup) tc_strdup(currentVerFileExtDup, &currentVerFileExt);

				printf("\nt5CheckForEmptyNamedRef :: CurrentRev File Ext -- %s || PreviousRev File Ext -- %s\n", currentVerFileExt, prevVerFileExt);fflush(stdout);
				if(atoi(currentVerFileExt) > atoi(prevVerFileExt))
				{
					printf("\nt5CheckForEmptyNamedRef :: Allow to Checkin\n");
				}
				else
				{
					if(AOM_ask_value_string(namedRefTag,"original_file_name",&prevRevOrigFileNameDup)!=ITK_ok)PrintErrorStack();
					if(prevRevOrigFileNameDup) tc_strdup(prevRevOrigFileNameDup, &prevRevOrigFileName);

					if(AOM_ask_value_string(referenced_object,"original_file_name",&CurrentRevOrigFileNameDup)!=ITK_ok)PrintErrorStack();
					if(CurrentRevOrigFileNameDup) tc_strdup(CurrentRevOrigFileNameDup, &CurrentRevOrigFileName);

					printf("\n*** t5CheckForEmptyNamedRef :: ERROR :: The File Extension of dataset [Named References] attached to Current Design Revision [%s] should be greater than dataset [Named References] attached to Previous Design Revision [%s]  ***\n", CurrentRevOrigFileName, prevRevOrigFileName);
					EMH_store_error_s3(EMH_severity_error,ITK_err,"The File Extension of dataset [Named References] attached to Current Design Revision should be greater than dataset [Named References] attached to Previous Design Revision. \nTo Verify :: RIGHT CLICK %s Dataset --> NAMED REFERENCES",CurrentRevOrigFileName, prevRevOrigFileName);
					printf("\nt5CheckForEmptyNamedRef :: 2 Exiting Function\n");fflush(stdout);
					return ITK_err;
				}
			}
			else
			{
				printf("\n*** t5CheckForEmptyNamedRef :: WARNING :: Ignoring the Validation as previous revision Named Reference is NULL ***\n");
			}
		}
	}

	printf("\nt5CheckForEmptyNamedRef :: 3 Exiting Function\n");fflush(stdout);
	return 0;
}

//DATASET Validation on Check-In
static int t5ValDataset(tag_t object_tag)
{
	int				ifail=0;
	int cnt = 0;
	int cnt1 = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int seqInt = 0;
	char			relation_name[TCTYPE_name_size_c+1];
	char			ObjectClassType1[TCTYPE_name_size_c+1];
	char			ObjectClassType[TCTYPE_name_size_c+1];
	char		   *seqS		= NULL;
	char		   *revS		= NULL;
	char		   *RevSeq		= NULL;
	char		   *reference_name		= NULL;
	char		   *reference_name1		= NULL;
	char *revSeq = NULL;
	char *revSeqDup = NULL;
	char *item_idDup = NULL;
	char *item_id = NULL;

	tag_t  relation_type = NULLTAG;
	tag_t  objTypeTag = NULLTAG;
	tag_t  dataset = NULLTAG;
	tag_t  dataset1 = NULLTAG;
	tag_t*  attachments = NULLTAG;
	tag_t*  attachments1 = NULLTAG;
	tag_t  tagProPrt = NULLTAG;
	tag_t  tagProAsm = NULLTAG;
	tag_t  tagProDrw = NULLTAG;
	tag_t  rev_tag = NULLTAG;

	AE_reference_type_t my_ref_type;

	printf("\nt5ValDataset :: Inside Function t5ValDataset\n");

	if(AOM_ask_value_string(object_tag,"item_revision_id",&revSeqDup)!=ITK_ok) PrintErrorStack();
	if(revSeqDup) tc_strdup(revSeqDup, &revSeq);

	if(AOM_ask_value_string(object_tag,"item_id",&item_idDup)!=ITK_ok) PrintErrorStack();
	if(item_idDup) tc_strdup(item_idDup, &item_id);
	printf("\nt5ValDataset :: Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);fflush(stdout);

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
		printf("\n t5ValDataset::Relation Type Name: %s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n t5ValDataset::Attached Datasets 1: %d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
			printf("\nt5ValDataset::Dataset Loop 1\n");
			dataset = attachments[i];

			if (TCTYPE_ask_object_type(dataset,&objTypeTag)!=ITK_ok);
			if (TCTYPE_ask_name(objTypeTag,ObjectClassType)!=ITK_ok);
			printf("\nt5ValDataset::ObjectClassType 1:: %s\n", ObjectClassType);fflush(stdout);

			if(tc_strcmp(ObjectClassType,"ProAsm") == 0 || tc_strcmp(ObjectClassType,"ProPrt") == 0 || tc_strcmp(ObjectClassType,"ProDrw") == 0)
			{
				if(tc_strcmp(revSeq,"NR;1") != 0 && tc_strstr(revSeq,";") != NULL)
				{
					revS = tc_strtok ( revSeq,";") ;
					seqS = tc_strtok ( NULL,";") ;
					printf("\nt5ValDataset::Revision -- %s :: Sequenc is -- %s\n", revS, seqS);

					seqInt = atoi(seqS);
					printf("\nt5ValDataset::After Integer Conversion Sequenc of the Object is -- %d\n", seqInt);fflush(stdout);

					if(seqInt > 1)
					{
						seqInt = seqInt - 1;
						RevSeq=(char *) MEM_alloc(10);
						sprintf(RevSeq,"%s;%d", revS, seqInt);
						printf("\nt5ValDataset:: Previous RevSeq -- %s", RevSeq);fflush(stdout);

						CALLAPI(ITEM_find_rev(item_id,RevSeq,&rev_tag));
						if(rev_tag != NULLTAG)
						{
							CALLAPI(GRM_list_secondary_objects_only(rev_tag,relation_type,&cnt1,&attachments1));
							printf("\nt5ValDataset::Attached Datasets 2: %d\n",cnt);fflush(stdout);
							for(j=0;j<cnt1;j++)
							{
								dataset1 = attachments[j];
								if (TCTYPE_ask_object_type(dataset1,&objTypeTag)!=ITK_ok);
								if (TCTYPE_ask_name(objTypeTag,ObjectClassType1)!=ITK_ok);
								printf("\nt5ValDataset::ObjectClassType 2:: %s\n", ObjectClassType1);

								if(tc_strcmp(ObjectClassType1,"ProAsm") == 0)
								{
									if(tagProAsm == NULLTAG)
									{
										CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "AsmFile", &my_ref_type, &tagProAsm));
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Assembly Attached to Previous Design Revision [%s-%s]. ***\n", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Assembly Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 1 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);
										return ITK_err;
									}
								}
								else if(tc_strcmp(ObjectClassType1,"ProPrt") == 0)
								{
									if(tagProPrt == NULLTAG)
									{
										CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "PrtFile", &my_ref_type, &tagProPrt));
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Part Attached to Previous Design Revision [%s-%s]. ***\n", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Part Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 2 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);
										return ITK_err;
									}
								}
								else if(tc_strcmp(ObjectClassType1,"ProDrw") == 0)
								{
									if(tagProDrw == NULLTAG)
									{
										CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "DrwFile", &my_ref_type, &tagProDrw));
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Drawing Attached to Previous Design Revision [%s-%s]. ***\n", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Drawing Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 3 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);
										return ITK_err;
									}
								}
								else
								{
									;
								}
							}
						}
					}
					else
					{
						printf("\n*** Bypassing as the Item Revision is having Revision as NR;1 or the ; is not present in RevSeq Field. ***\n");fflush(stdout);
					}
				}
			}

			if(tc_strcmp(ObjectClassType,"ProAsm") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "AsmFile", tagProAsm));
			}
			else if(tc_strcmp(ObjectClassType,"ProPrt") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "PrtFile", tagProPrt));
			}
			else if(tc_strcmp(ObjectClassType,"ProDrw") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "DrwFile", tagProDrw));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Part") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATPart", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Product") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATProduct", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Drawing") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATDrawing", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2AuxPart") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATPart", NULLTAG));
			}
			else
			{
				;
			}
		}
	}

	if(attachments != NULLTAG) MEM_free(attachments);
	if(attachments1 != NULLTAG) MEM_free(attachments1);

	printf("\nt5ValDataset :: 4 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);
	return 0;
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextMinute(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays,Hour,Minute,nHr,nMin;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;

	struct tm *timeptr1;
	char pAccessDate[30];
	char pAccessDate1[30];
	char cMonth[30];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	strHr[20];
	char	strMin[20];

	temp = time(NULL);
	struct tm* timeptr;
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);

	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);


	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	Hour=(timeptr->tm_hour);
	Minute=(timeptr->tm_min);


	printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);

	ny= year;
	nm= month;
	nd= day;
	nHr=Hour;
	if (Minute==59)
	{
		if (Hour==23)
		{
			nHr=0;
			nMin=0;
			ndays= days( month, year );//calling days function
			if( ++nd > ndays )
			{
			   nd= 1;
			   if ( ++nm > 12 )
			   {
				 nm= 1;
				 ++ny;
				}
			}
		}
		else
		{
			nHr=Hour+1;
			nMin=0;
		}
	}
	else
	{
		nMin=Minute+1;
	}
    printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);
    printf( "Next days date is %d:%d:%d  %d:%d\n", nd, nm, ny ,nHr,nMin);

	sprintf(strDay,"%d",nd);
	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);
	sprintf(strHr,"%d",nHr);
	sprintf(strMin,"%d",nMin);

	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,strHr);
	tc_strcat(cnextAccessDate,":");
	tc_strcat(cnextAccessDate,strMin);
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

extern DLLAPI int checkin_with_dataset(METHOD_message_t *m, va_list args)
{
  	char			relation_name[TCTYPE_name_size_c+1];
	tag_t			relation_type							= NULLTAG;
	tag_t			*attachments							= NULLTAG;
	tag_t *  	primary_objects;
	tag_t			dataset									= NULLTAG;
	tag_t	 		object_tag								= va_arg (args, tag_t);
	int				ifail=0,cnt=0,i=0,j;
	int cnt1 = 0;
	logical			checkout								= 0;
	//int				BomViewCnt,iVwCnt,count1,checkout1				= 0;//Abhishek
	int				BomViewCnt,iVwCnt,count1;//Abhishek
	tag_t			*BomViewList							= NULLTAG;//Abhishek
	char			type_name[TCTYPE_name_size_c+1];//Abhishek
	tag_t			objTypeTag								= NULLTAG;//Abhishek
	GRM_relation_t *primary_list1	= NULLTAG;
	tag_t		   primary_object1	= NULLTAG;
	GRM_relation_t *primary_list	= NULLTAG;
	//tag_t                   status_rel                                      = NULLTAG;
	tag_t    tReleaseStatusList=NULLTAG;
	tag_t    process_template = NULLTAG;
	tag_t*    status_list1=NULLTAG;
	//logical retain=true;
	char		*WSO_Name=NULL ;
	tag_t*    attr_tags=NULLTAG;
	tag_t process = NULLTAG;
	int st_count1,n_values,n_values1=0;
	char*				RevisionId		= NULL;
	logical
        *is_it_null = NULL,
        *is_it_empty = NULL;
	int		attachTypes[]		= {EPM_target_attachment};
	tag_t			status_rel					= NULLTAG;

	logical			retain							= 0;
	tag_t  CurrentRoleTag = NULLTAG;
    char       roleName[SA_name_size_c+1];





	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		=0;
	int			Rel_cnt					=0;
	tag_t*		relstatus_list			=NULLTAG;
	char		*WSO_Name_RelVal		=NULL ;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	int			n_values_checkin			=0;
	int			cunt1					=	0;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	tag_t		class_id				=     NULLTAG;
	char		*class_name				=    NULL;
	char		*gov_classification		=NULL;
    char   *PlantName=NULL;

	logical		log1;
	logical		checkout1;
	int status = 0;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
		printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  printf("\nin checkin for loop\n");fflush(stdout);
		  dataset = attachments[i];
		  CALLAPI(RES_is_checked_out(dataset,&checkout));
		  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
		  if (checkout==1)
		  {
		  		CALLAPI(RES_checkin(dataset));
				printf("\n %d DataSet Checked In \n",i+1);
		  }

		}
	}

    CALLAPI(SA_ask_current_role(&CurrentRoleTag));  //DEEPTI TZ1.34
    CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName));//DEEPTI TZ1.34
	 printf("\n\n  roleName : %s\n",roleName); fflush(stdout);//DEEPTI TZ1.34
      PlantName=subString(roleName,3,4);
      printf( "PlantName:%s\n", PlantName);

	/*Added By Abhishek For Bom View Revision Checkin on Design Checkin*/
	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	printf("\nTypeName for Checkin is [%s]\n",type_name);fflush(stdout);
	if (strcmp(type_name,"Design Revision") == 0)
	{

//		printf("\nsseeInside to set Review Status for workflowee\n");fflush(stdout);
//		//CALLAPI(EPM_find_process_template("ERC Review", &process_template));
//		CALLAPI(EPM_find_process_template("ERC Review", &process_template));
//		//EXIT_IF_NULL( process_template );
//
//		 CALLAPI(WSOM_ask_object_id_string(object_tag,&RevisionId));
//
//				//ITK_CALL(WSOM_ask_name(revTag,a_nameRev));
//
//		  printf("\n RevisionId %s \n",RevisionId);fflush(stdout);
//		printf("\nEPM_find_process_template  for workflowpp\n");fflush(stdout);
//		if(process_template)
//		{
//			printf("\n inside found  for workflowwp\n");fflush(stdout);
//			//EPM_create_process("5421377", "desc", process_template, 1, &rev,      attach_types, &process) );
//			CALLAPI(EPM_create_process(RevisionId,"Test",process_template,1,&object_tag,attachTypes,&process));
//			//EXIT_IF_NULL( process_template );
//		}
		//IFERR_REPORT(EPM_create_process("WFP", "", process_template,n_items,
          //  items, attach_types, &process));
//		CALLAPI (CR_create_release_status("T5_LcsReview",&status_rel));
//
//		CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
//		printf("\nst_count1 :%d is\n",st_count1);fflush(stdout);
//		if(st_count1>0)
//		{
//			for (cnt=0;cnt< st_count1;cnt++ )
//			{
//				CALLAPI(AOM_ask_name(status_list1[cnt],&WSO_Name));
//				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
//				if (strcmp(WSO_Name,"T5_LcsReview")==0)
//				{
//					CALLAPI(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&tReleaseStatusList));fflush(stdout);
//
//					 CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList, &n_values) );
//					 printf("\n n_values is :%d\n",n_values);fflush(stdout);
//					 CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList, 0, n_values1, &attr_tags, &is_it_null, &is_it_empty ));
//					  printf("\n n_values11 is :%d\n",n_values1);fflush(stdout);
//
//					 CALLAPI(POM_remove_from_attr(1,object_tag,tReleaseStatusList,0,1));
//					   printf("\n removedd is :%d\n",n_values1);fflush(stdout);
//					 CALLAPI(POM_save_instances(1, &object_tag, true));
//
//				}
//			}
//		}
//
//		CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));
	//	  printf("\n process created is :%d\n",n_values1);fflush(stdout);

		//CALLAPI(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&tReleaseStatusList));fflush(stdout);

		if( AOM_ask_value_string(object_tag,"gov_classification",&gov_classification)!=ITK_ok)PrintErrorStack();
		printf("\ngov_classification:%s",gov_classification);fflush(stdout);

		if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)
		{
						return ITK_ok;
		}


		if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok)PrintErrorStack();
		printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

		if (BomViewCnt > 0)
		{
			printf("\nCheckin BOM Views Also .............\n");fflush(stdout);
			for(iVwCnt=0;iVwCnt<BomViewCnt;iVwCnt++)
			{
				printf("\nCheckin [%d] View\n",iVwCnt+1);fflush(stdout);
				if (RES_checkin(BomViewList[iVwCnt])!=ITK_ok)   PrintErrorStack();

			 if(tc_strstr(roleName,"APL")!=NULL)
			 {
				 if(strcmp(PlantName,"APLC")==0)
				 {
				printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsAplReview");
    			printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				 }else if(strcmp(PlantName,"APLV")==0)
				 {
				printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsAplvReview");
    			printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				 }
			  }else
				{
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsReview");
				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				}
			}
		}

	printf("\n Before ERC Review.... \n");fflush(stdout);
//	if(AOM_lock(object_tag))PrintErrorStack();

	/*********Deepti Start for removing Release Status in CHeckIN***************************************/
	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
			printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_save_instances(1,&object_tag,1));

			CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

			CALLAPI(AOM_lock(object_tag));

			CALLAPI(AOM_save(object_tag));
			CALLAPI(AOM_refresh(object_tag,1));

		}

		 CALLAPI(AOM_unlock(object_tag));
	}


		/*********Deepti End for removing Release Status in CHeckIN***************************************/
	printf("\n Inside effectivty stamping code\n");
	char*			ReleaseStatus	=NULL;
	logical stat  ;
	char cCurrentAccessDate[20]={0};
	tag_t    	    propEff_tag				    =NULLTAG;
	char*			value					=NULL;
	char cNextDate[30]={0};
	date_t test_date_1;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	char* username;
	tag_t user_tag=NULLTAG;

	POM_get_user(&username,&user_tag);

	 if(tc_strstr(roleName,"APL")!=NULL)
	 {
		printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
		//if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
		   if(strcmp(PlantName,"APLC")==0)
		    {
			if (CR_create_release_status("T5_LcsAplReview",&status_rel))PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(EPM_add_release_status(status_rel,1,&object_tag,retain))PrintErrorStack();
			}else if (strcmp(PlantName,"APLV")==0)
			{
			if (CR_create_release_status("T5_LcsAplvReview",&status_rel))PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(EPM_add_release_status(status_rel,1,&object_tag,retain))PrintErrorStack();
			}
	  }else
	  {
			//if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
			if (CR_create_release_status("T5_LcsReview",&status_rel))PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(EPM_add_release_status(status_rel,1,&object_tag,retain))PrintErrorStack();
	  }

	if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
	{
			 if(tc_strstr(roleName,"APL")!=NULL)   // APL USer STart
			 {
				if((strcmp(ReleaseStatus,"APLC Review")==0) || (strcmp(ReleaseStatus,"APL Review")==0) ||strcmp(ReleaseStatus,"T5_LcsAplReview")==0
					 || tc_strcmp(ReleaseStatus, "APLV Review") == 0  || tc_strcmp(ReleaseStatus,"T5_LcsAplvReview")==0)  // Satrt for APL code
				{
					printf("\n Inside IF effectivty stamping code\n");
					if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;
					printf("\n stat:%d\n",stat);

					if(stat != true)
					{
						printf("\n stat is not true .....\n");
					}
					else
					{
						printf("\n stat is  true .....\n");
					}

					getCurrentDateTime(cCurrentAccessDate);
					if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
					if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
					printf("\n effectivity_text is value : %s\n",value);

					//getNextDate(cNextDate);
					getNextMinute(cNextDate);
					printf("\n cNextDate:%s",cNextDate);
					//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

					if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
					{
						return ifail;
					}
					start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

					//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

					start_end_date[0] = test_date_1;
					start_end_date[1] = test_date_2;

					if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_rel)))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
					{
						return ifail;
					}

					if(ITK_ok != (ifail = AOM_save(eff_d)))
					{
						return ifail;
					}

					if(ITK_ok != (ifail = AOM_save(status_rel)))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = AOM_refresh( status_rel, 0 )))
					{
						return ifail;
					}

					if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
					if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
					printf("\n After setting effectivity_text value : %s\n",value);
					if(ITK_ok != (ifail = AOM_refresh( object_tag, 0 )))
					{
						return ifail;
					}

					/// Previous revison

					tag_t	*rev_list				= NULL;
					tag_t	*status_lst				= NULL;
					tag_t	*effectivities_tag				= NULL;
					int Item_count=0;
					int iiCnt=0;
					int count_status=0,j=0,n_effectivities=0,n_dtes=0;
					char	*rel_status				= NULL;
					char	*cPartNo				= NULL;
					char	*rev_idd				= NULL;
					char	*status_name				= NULL;
					char	*EffvalueAfter				= NULL;
					char	*old_to_date_Rel_date				= NULL;
					logical stat1  ;
					tag_t	LpropEff_tag		= NULLTAG;
					tag_t	AftpropEff_tag		= NULLTAG;
					char 	*Effvalue				= NULL;
					char	*old_to_date			= NULL;
					tag_t   propEff_tagPre				    =NULLTAG;
					tag_t   All_item_tag				    =NULLTAG;
					date_t *Rel_start_end_values	= NULL;
					date_t Rel_Date;
					WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
					logical date_is_valid  ;
					date_t Ltest_date_1;
					date_t Ltest_date_2;
					date_t *Lstart_end_date			= NULL;
					tag_t	Leff_d				= NULLTAG;
					int jj=0;



					//// Going to update effectivity of previous data
					ifail = AOM_UIF_ask_value (object_tag, "item_id", &cPartNo);
					ifail = ITEM_find_item (cPartNo, &All_item_tag);

					ifail = ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list);
					printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

					if(Item_count > 1)
					{
						iiCnt=Item_count-2;
						ifail = AOM_UIF_ask_value (rev_list[iiCnt], "release_status_list", &rel_status);
						printf("\n Eff: Release Status is:%s.", rel_status);fflush(stdout);

						ifail = AOM_UIF_ask_value (rev_list[iiCnt], "item_revision_id", &rev_idd);
						printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);
						if(tc_strcmp(rel_status, "APLC Review") == 0 || (strcmp(rel_status,"APL Review")==0) || tc_strcmp(rel_status,"T5_LcsAplReview")==0
						   || tc_strcmp(rel_status, "APLV Review") == 0  || tc_strcmp(rel_status,"T5_LcsAplvReview")==0)
						{
							ifail = WSOM_ask_release_status_list (rev_list[iiCnt], &count_status, &status_lst);
							if(count_status > 0)
							{
								for(j=0;j<count_status;j++)
								{
									ifail = AOM_ask_value_string (status_lst[j], "object_name", &status_name);
									printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
									if((tc_strcmp(status_name,"APLC Review")==0) || (strcmp(status_name,"APL Review")==0)  || tc_strcmp(status_name,"T5_LcsAplReview")==0
								    || tc_strcmp(status_name,"APLV Review")==0  || tc_strcmp(status_name,"T5_LcsAplvReview")==0)
									{
										printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
										if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
										printf("\n EFF1:stat1:%d",stat1);fflush(stdout);

										if(stat1 != true)
										{
											printf("\n EFF1:stat1 is not true .....");fflush(stdout);
										}
										else
										{
											printf("\n EFF1:stat1 is  true .....");fflush(stdout);
										}

										if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
										if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
										printf("\n EFF1:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
										if(ITK_ok != (ifail = WSOM_status_ask_date_released (status_lst[j],&Rel_Date) )) return ifail;
										if(ITK_ok != (ifail = DATE_date_to_string(Rel_Date,"%d-%b-%Y %H:%M", &old_to_date_Rel_date )))
										{
											return ifail;
										}
										printf("\n Eff:old_to_date_Rel_date:[%s] ",old_to_date_Rel_date);fflush(stdout);

										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dtes);fflush(stdout);
												if(n_dtes > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
										}
										else
										{
											if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date_Rel_date, &date_is_valid,&Ltest_date_1 )))return ifail;
											if(date_is_valid != true)
											{
												printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
											}
											else
											{
												printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
											}

										}
										//Current Date

										printf("\n Eff:cCurrentAccessDate is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
										Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
										Lstart_end_date[0] = Ltest_date_1;
										Lstart_end_date[1] = Ltest_date_2;

										printf("\n EFF:Clearing effectivities...");fflush(stdout);

										if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
										{
											return ifail;
										}
										printf("\n EFF:Creating effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
										{
											return ifail;
										}
										printf("\n EFF:Saving effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save(Leff_d)))
										{
											return ifail;
										}
										printf("\n EFF:Saving Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save(status_lst[j])))
										{
											return ifail;
										}
										printf("\n EFF:Refreshing Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
										{
											return ifail;
										}
										printf("\n EFF:Checking effectivities txt...");fflush(stdout);
										if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))	 return ifail;
										if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))	 return ifail;
										printf("\n Eff:effectivity_text EffvalueAfter : %s\n",EffvalueAfter);fflush(stdout);
										if(ITK_ok != (ifail = AOM_refresh( rev_list[iiCnt], 0 )))
										{
											return ifail;
										}
									}
									else
									{
										printf("\n Eff: Status name:%s for rev:%s\n", status_name, rev_idd); fflush(stdout);
									}
									MEM_free(status_name);
								}
							}
							else
							{
								printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
							}
						}
					}
				}  // End for APL code
			 }
		else if((strcmp(ReleaseStatus,"ERC Review")==0) ||strcmp(ReleaseStatus,"T5_LcsReview")==0) 	// Start for ERC code
		{
			printf("\n Inside IF effectivty stamping code\n");
			if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;
			printf("\n stat:%d\n",stat);

			if(stat != true)
			{
				printf("\n stat is not true .....\n");
			}
			else
			{
				printf("\n stat is  true .....\n");
			}

			getCurrentDateTime(cCurrentAccessDate);
			if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
			if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
			printf("\n effectivity_text is value : %s\n",value);

			//getNextDate(cNextDate);
			getNextMinute(cNextDate);
			printf("\n cNextDate:%s",cNextDate);
			//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

			if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
			{
				return ifail;
			}
			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_rel)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save(eff_d)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save(status_rel)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = AOM_refresh( status_rel, 0 )))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
			if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
			printf("\n After setting effectivity_text value : %s\n",value);
			if(ITK_ok != (ifail = AOM_refresh( object_tag, 0 )))
			{
				return ifail;
			}

			/// Previous revison

			tag_t	*rev_list				= NULL;
			tag_t	*status_lst				= NULL;
			tag_t	*effectivities_tag				= NULL;
			int Item_count=0;
			int iiCnt=0;
			int count_status=0,j=0,n_effectivities=0,n_dtes=0;
			char	*rel_status				= NULL;
			char	*cPartNo				= NULL;
			char	*rev_idd				= NULL;
			char	*status_name				= NULL;
			char	*EffvalueAfter				= NULL;
			char	*old_to_date_Rel_date				= NULL;
			logical stat1  ;
			tag_t	LpropEff_tag		= NULLTAG;
			tag_t	AftpropEff_tag		= NULLTAG;
			char 	*Effvalue				= NULL;
			char	*old_to_date			= NULL;
			tag_t   propEff_tagPre				    =NULLTAG;
			tag_t   All_item_tag				    =NULLTAG;
			date_t *Rel_start_end_values	= NULL;
			date_t Rel_Date;
			WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
			logical date_is_valid  ;
			date_t Ltest_date_1;
			date_t Ltest_date_2;
			date_t *Lstart_end_date			= NULL;
			tag_t	Leff_d				= NULLTAG;
			int jj=0;



			//// Going to update effectivity of previous data
			ifail = AOM_UIF_ask_value (object_tag, "item_id", &cPartNo);
			ifail = ITEM_find_item (cPartNo, &All_item_tag);

			ifail = ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list);
			printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

			if(Item_count > 1)
			{
				iiCnt=Item_count-2;
				ifail = AOM_UIF_ask_value (rev_list[iiCnt], "release_status_list", &rel_status);
				printf("\n Eff: Release Status is:%s.", rel_status);fflush(stdout);

				ifail = AOM_UIF_ask_value (rev_list[iiCnt], "item_revision_id", &rev_idd);
				printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);
				if(tc_strcmp(rel_status, "ERC Review") == 0)
				{
					ifail = WSOM_ask_release_status_list (rev_list[iiCnt], &count_status, &status_lst);
					if(count_status > 0)
					{
						for(j=0;j<count_status;j++)
						{
							ifail = AOM_ask_value_string (status_lst[j], "object_name", &status_name);
							printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
							if((tc_strcmp(status_name,"ERC Review")==0) ||tc_strcmp(status_name,"T5_LcsReview")==0)
							{
								printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
								if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
								printf("\n EFF1:stat1:%d",stat1);fflush(stdout);

								if(stat1 != true)
								{
									printf("\n EFF1:stat1 is not true .....");fflush(stdout);
								}
								else
								{
									printf("\n EFF1:stat1 is  true .....");fflush(stdout);
								}

								if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
								if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
								printf("\n EFF1:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

								if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
								if(ITK_ok != (ifail = WSOM_status_ask_date_released (status_lst[j],&Rel_Date) )) return ifail;
								if(ITK_ok != (ifail = DATE_date_to_string(Rel_Date,"%d-%b-%Y %H:%M", &old_to_date_Rel_date )))
								{
									return ifail;
								}
								printf("\n Eff:old_to_date_Rel_date:[%s] ",old_to_date_Rel_date);fflush(stdout);

								printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
								if(n_effectivities > 0)
								{
									for(jj=0;jj<n_effectivities;jj++)
									{
										if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
										printf("\n Eff:no of Rel_start_end_value:%d\n", n_dtes);fflush(stdout);
										if(n_dtes > 0)
										{
											if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
											{
												return ifail;
											}
											printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
											if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
											{
												return ifail;
											}
											printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
											if(date_is_valid != true)
											{
												printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
											}
											else
											{
												printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
											}
										}
										else
										{
											printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
										}
									}
								}
								else
								{
									if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date_Rel_date, &date_is_valid,&Ltest_date_1 )))return ifail;
									if(date_is_valid != true)
									{
										printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
									}
									else
									{
										printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									}

								}
								//Current Date

								printf("\n Eff:cCurrentAccessDate is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
								if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
								{
									return ifail;
								}
								printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
								Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								Lstart_end_date[0] = Ltest_date_1;
								Lstart_end_date[1] = Ltest_date_2;

								printf("\n EFF:Clearing effectivities...");fflush(stdout);

								if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
								{
									return ifail;
								}
								printf("\n EFF:Creating effectivities...");fflush(stdout);
								if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
								{
									return ifail;
								}
								printf("\n EFF:Saving effectivities...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_save(Leff_d)))
								{
									return ifail;
								}
								printf("\n EFF:Saving Revision...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_save(status_lst[j])))
								{
									return ifail;
								}
								printf("\n EFF:Refreshing Revision...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
								{
									return ifail;
								}
								printf("\n EFF:Checking effectivities txt...");fflush(stdout);
								if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))	 return ifail;
								if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))	 return ifail;
								printf("\n Eff:effectivity_text EffvalueAfter : %s\n",EffvalueAfter);fflush(stdout);
								if(ITK_ok != (ifail = AOM_refresh( rev_list[iiCnt], 0 )))
								{
									return ifail;
								}
							}
							else
							{
								printf("\n Eff: Status name:%s for rev:%s\n", status_name, rev_idd); fflush(stdout);
							}
							MEM_free(status_name);
						}
					}
					else
					{
						printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
					}
				}
			}
		} // End for ERC code
	}

		if(relation_type != NULLTAG)
		{
			CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==0)
			  {
				  printf("\nSetting Lifecycle State as ERC Review  For Dataset\n");
				  	 if(tc_strstr(roleName,"APL")!=NULL)
	                {
						 status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAplReview");
					}else
					  {
					  status = t5UpdateLifecycleStateAD(dataset, "T5_LcsReview");
					  }
				  printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			  }

			}
		}
		//ERROR_CALL(ITK_set_bypass(TRUE));

	////	if(AOM_refresh(object_tag,1))PrintErrorStack();
	//	if(AOM_save(object_tag))PrintErrorStack();

	//	if(AOM_unlock(object_tag));
		printf("\n After ERC Review. removed... \n");fflush(stdout);
	}

	/*	If Condition added for reason :-
			A] Pro/E Data Should be in Checked Out state on Save.
			B] On Check-In Of Dataset or Design Revision Check-In of Pro/E Dataset should not be affected.
		Also existing functionality of Check-In of Design Revision along with Pro/E Dataset is overridden .
		Added in TZ 1.27 by Anu Nair on 12/12/2017.
	*/
	if((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0) || (strcmp(type_name,"ProDrw")==0))
	{

		if(relation_type != NULLTAG)
		{
			CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_primary_objects_only(object_tag,relation_type,&cnt1,&primary_objects));
			printf("\n Primary Objects Count is :%d\n",cnt1);fflush(stdout);
			for(i=0;i<cnt1;i++)
			{
				dataset = primary_objects[i];
				CALLAPI(RES_is_checked_out(dataset,&checkout));
				printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
				if (checkout)
				{
					printf("\nInside If Condition to Check Whether Design Revision is Checked Out..\n");
					if(RES_is_checked_out(object_tag,&checkout1) !=ITK_ok);PrintErrorStack();
					if (!checkout1)
					{
						if (RES_checkout(object_tag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok);PrintErrorStack();
						printf("\nDataSet Checked Out \n");

					}
					else
					{
						printf("\nSkipping as DataSet already Checked Out\n");
					}
				}
			}
		}
		//End of Added in TZ 1.27 by Anu Nair.

//		printf("\n other than DR for skk TypeName for Checkin is [%s]\n",type_name);fflush(stdout);
//
//
//		    if(relation_type != NULLTAG)
//		    {
//			     printf("\n inside other than DR for skk relation_type for Checkin is [%s]\n",type_name);fflush(stdout);
//			     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count1,&primary_list1));
//		    }
//		if(primary_list1!=NULLTAG)
//		{
//				   printf("\n inside other than DR for skk primary_list1 for Checkin is [%s]\n",type_name);fflush(stdout);
//				printf("\n\n  primary object Attached to dataset in in checkin_with_dataset:%d\n",count1);
//
//				for(j=0;j<count1;j++)
//				{
//				   primary_object1 = primary_list1[j].primary;
//				   if(primary_object1!=NULLTAG)
//				   {
//				 	 printf("\nprimary_object 1in skk checkin :%d\n",j);
//					  CALLAPI(RES_is_checked_out(primary_object1,&checkout1));
//				//   if (checkout1==1)
//				   if (checkout1)
//				{
//						 	//PrintErrorStack();
//						  printf("\n inside DR for ProAsmmmmmmmmmmmmmmmmmm calling CALLAPI2 \n");
//						    printf("\n PrintErrorStack before  in Design revision for  PROE \n");
//						 CALLAPI(RES_checkin(primary_object1));
//						   printf("\n PrintErrorStack  calling CALLAPI2 \n");
//						  	//PrintErrorStack();
//						  printf("\n checked in Design revision for  PROE \n");
//				}
//				}
//			  }
//		 }
	}


	/*Abhishek Code ends here*/
	if ((strcmp(type_name,"T5_TMCAEModelRevision") == 0)||(strcmp(type_name,"T5_TMCAEAnalysisRevision") == 0)) //Adi new
	{
		printf("\n Inside Type Name :%s\n",type_name);fflush(stdout);
		CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type));
		if(relation_type != NULLTAG)
		{
			CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==1)
			  {
					CALLAPI(RES_checkin(dataset));
					printf("\n %d DataSet Checked In \n",i+1);
			  }

			}
		}

		if( AOM_ask_value_string(object_tag,"gov_classification",&gov_classification)!=ITK_ok)PrintErrorStack();
		printf("\ngov_classification:%s",gov_classification);fflush(stdout);
		if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)
		{
						return ITK_ok;
		}


		if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok)PrintErrorStack();
		printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

		if (BomViewCnt > 0)
		{
			printf("\nCheckin BOM Views Also .............\n");fflush(stdout);
			for(iVwCnt=0;iVwCnt<BomViewCnt;iVwCnt++)
			{
				printf("\nCheckin [%d] View\n",iVwCnt+1);fflush(stdout);
				if (RES_checkin(BomViewList[iVwCnt])!=ITK_ok)   PrintErrorStack();

				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsReview");
				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			}
		}

		printf("\n Before ERC Review.... \n");fflush(stdout);
		CALLAPI(POM_class_of_instance(object_tag,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&object_tag));
		CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
		CALLAPI(POM_is_loaded(object_tag,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
		printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		if(n_values_checkin>0)
		{
			CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
			printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));

			}
			CALLAPI(AOM_unlock(object_tag));
		}

		if (CR_create_release_status("T5_LcsReview",&status_rel))PrintErrorStack();
		if(EPM_add_release_status(status_rel,1,&object_tag,retain))PrintErrorStack();

		if(relation_type != NULLTAG)
		{
			CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==0)
			  {
				  printf("\nSetting Lifecycle State as ERC Review  For Dataset\n");
				  status = t5UpdateLifecycleStateAD(dataset, "T5_LcsReview");
				  printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			  }

			}
		}
		printf("\n After ERC Review. removed... \n");fflush(stdout);
	}
	CLEANUP:
	printf("\n Inside CLEANUP \n");fflush(stdout);
    return ifail;

}


extern DLLAPI int checkout_with_dataset(METHOD_message_t *m, va_list args)
{
	char			relation_name[TCTYPE_name_size_c+1];
	tag_t			relation_type								= NULLTAG;
	tag_t			relation_fnd								= NULLTAG;
	tag_t			relation_type_Dsn							= NULLTAG;
	tag_t			relation_dep22								= NULLTAG;
	tag_t			*attachments								= NULLTAG;
	tag_t			dataset										= NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	tag_t			object_tag									= va_arg (args, tag_t);
	tag_t			objTypeTag									= NULLTAG;
	char			type_name[TCTYPE_name_size_c+1];
	char			*desrevid									= NULL;
	char			*cp_ItemId									= NULL;//Abhishek
	tag_t			reln_type									= NULLTAG;//Abhishek
	tag_t			*secondary_objects							= NULLTAG;//Abhishek
	int				n_attchs									= 0;//Abhishek
	tag_t			t_BomLineWindow, t_Rule, t_ItemTag			= null_tag;//Abhishek
	tag_t			t_TopLine,t_Childobject						= NULLTAG;
	tag_t			t_ChildObjType								= NULLTAG;//Abhishek
	tag_t			*t_PartChildren								= NULLTAG;//Abhishek
	tag_t			t_ChildItemRev								= NULLTAG;//Abhishek
	int				i_ChildCount= 0,iChldPrts=0,iItemType=0,iItemRevId=0,iItemId=0,iChildItemTag=0;//Abhishek
	int				i_ChildSeq= 0,iItemChkdOut					= 0;//Abhishek
	logical			b_ChildChkOutValue							= 0;//Abhishek
	char			ca_ChildType_Name[TCTYPE_name_size_c+1];//Abhishek
	char			*cp_ItemType_str,*Item_id					= NULL;//Abhishek
	char			*cp_ItemID_str								= NULL;//Abhishek
	char			*cp_ItemRev_str								= NULL;//Abhishek
	char			*Ap_owner								= NULL;
	char			*dt_typ_nm								= NULL;
	char			*cp_ChildSeq,*cp_ChildChkOutValue,*Desc_obj	= NULL;//Abhishek
	int				BomViewCnt,iVwCnt							= 0;//Abhishek
	tag_t			*BomViewList								= NULLTAG;//Abhishek
	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);
	//int				ifail=0,cnt=0,i,count2,i2,checkout2=0;
	int				ifail=0,cnt=0,i,count2,count12,i2;
	logical			checkout									= 0;
	GRM_relation_t *primary_list2	= NULLTAG;
	GRM_relation_t *primary_list12	= NULLTAG;
	tag_t                   status_rel                                      = NULLTAG;
	int	   status_count,ii=0,countDep=0,ik=0,countDep11=0;
	int status;
	int main_seq;
	int jk=0,Valid_Ch_Dataset,Ap_owner_Nt_fnd;
	int catfound,proEfound,deleteRel;

	logical retain=false;
	char   *ReleaseStatus=NULL;
	char   *Id_string_val=NULL;
	char   *Id_Pro_val=NULL;
	char   *org_rev_id=NULL;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	int org_seq_id_int=0;
    char   *PlantName=NULL;

	tag_t		   primary_object2	= NULLTAG;
	tag_t* status_list = NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t		   NewRevTag	= NULLTAG;
	tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	int n_entries = 3;
	int resultCount=0;
	tag_t *rev=NULLTAG;

	logical	checkoutp1;
	logical	checkout2;

        /***************Adi  ******************/
		tag_t			relation_fnd1	= NULLTAG;
		tag_t			dataset1		= NULLTAG;
		int               ip            = 0; 
		int               cnt1            = 0; 
		logical			checkout1		= 0;
		tag_t			*attachments1	= NULLTAG;
		char			*dt_typ_nm1		= NULL;   
		char			*dt_typ_nm2		= NULL;    
		 /***************Adi ******************/
		 tag_t		relation_tag		= NULLTAG;
		 tag_t		reln_type_tag		= NULLTAG;
		 char*		DsObjNameS			= NULL;



	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	/******Deepti End ariable initialisation***********/
		/******Start Deepti TZ1.34***********/
	tag_t  CurrentRoleTag = NULLTAG;
     char       roleName[SA_name_size_c+1];
	/******End Deepti TZ1.34***********/


	char   *catiasynch=NULL; //Adi CMI
	char   *OwnUser=NULL; //Adi Alias

	char   *SealLen		= NULL; //Adi 
	char   *ArcWeld		= NULL; //Adi 
	char   *Stud		= NULL;	//Adi 
	char   *SealantType = NULL; //Adi

	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};


 	//printf("\n\nIn checkout_with_dataset orignal stamping LC %d \n",LHFlg);

//anil
	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	printf("\n type_name  = [%s]\n", type_name);fflush(stdout);
	if(!strcmp(type_name,"Design Revision"))
	{

//		status=WSOM_ask_release_status_list(object_tag,&status_count,&status_list);
//	    if(status==ITK_ok)
//		 {
//			printf("\n number of statuses: %d \n",  status_count);
//			for (ii = 0; ii < status_count; ii++)
//			{
//				AOM_ask_name(status_list[ii], &ReleaseStatus);
//				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
//			}
//		 }
//
//		 if((strcmp(ReleaseStatus,"T5ErcPublished")==0) )
//			{
//				status=EMH_store_error_s1(EMH_severity_error,ITK_err, "BaseLine Object Cannot Be Checked-out, Please Check-out The Actual Object");
//				return ITK_err;
//			}

    /***************Adi - CMI synch *************************/

	   if( AOM_ask_value_string(object_tag,"t5_IsCatSynch",&catiasynch)==ITK_ok)

	   printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

	   if(tc_strcmp(catiasynch ,"Y")==0)
		{
		   printf("\n part has been synched from catia so on checkout setting the value to N \n");fflush(stdout);

           if(AOM_lock(object_tag));
		   if(AOM_set_value_string(object_tag,"t5_IsCatSynch","N"))PrintErrorStack();
		   if(AOM_save(object_tag))PrintErrorStack();
		   if(AOM_unlock(object_tag))PrintErrorStack();

		   printf("\n VALUE set to N  \n");fflush(stdout);
		}
		else
		{
           printf("\n catiasynch value not set to Y \n");fflush(stdout);
		}
	/***************Adi - CMI synch *************************/

	/***************Adi - setting attribute values to null **************************/

	 if( AOM_ask_value_string(object_tag,"t5_ArcWeld",&ArcWeld)==ITK_ok)
	 printf("\n ArcWeld value is -------------- %s \n",ArcWeld);fflush(stdout);

	 if((tc_strcmp(ArcWeld,"")!=0))
		{
		   printf("\n ArcWeld has some value \n");fflush(stdout);

           if(AOM_lock(object_tag));
		   if(AOM_set_value_string(object_tag,"t5_ArcWeld",""))PrintErrorStack();
		   if(AOM_save(object_tag))PrintErrorStack();
		   if(AOM_unlock(object_tag))PrintErrorStack();

		   printf("\n ArcWeld value set to NULL  \n");fflush(stdout);
		}
		else
		{
           printf("\n ArcWeld value is already NULL \n");fflush(stdout);
		}


	 if( AOM_ask_value_string(object_tag,"t5_Stud",&Stud)==ITK_ok)
	 printf("\n Stud value is -------------- %s \n",Stud);fflush(stdout);

	 if((tc_strcmp(Stud,"")!=0))
		{
		   printf("\n Stud has some value \n");fflush(stdout);

           if(AOM_lock(object_tag));
		   if(AOM_set_value_string(object_tag,"t5_Stud",""))PrintErrorStack();
		   if(AOM_save(object_tag))PrintErrorStack();
		   if(AOM_unlock(object_tag))PrintErrorStack();

		   printf("\n Stud value set to NULL  \n");fflush(stdout);
		}
		else
		{
           printf("\n Stud value is already NULL \n");fflush(stdout);
		}


	 if( AOM_ask_value_string(object_tag,"t5_SealantType",&SealantType)==ITK_ok)
	 printf("\n SealantType value is -------------- %s \n",SealantType);fflush(stdout);

	 if((tc_strcmp(SealantType,"")!=0))
		{
		   printf("\n SealantType has some value \n");fflush(stdout);

           if(AOM_lock(object_tag));
		   if(AOM_set_value_string(object_tag,"t5_SealantType",""))PrintErrorStack();
		   if(AOM_save(object_tag))PrintErrorStack();
		   if(AOM_unlock(object_tag))PrintErrorStack();

		   printf("\n SealantType value set to NULL  \n");fflush(stdout);
		}
		else
		{
           printf("\n SealantType value is already NULL \n");fflush(stdout);
		}

	 if( AOM_ask_value_string(object_tag,"t5_SealLen",&SealLen)==ITK_ok)
	 printf("\n SealLen value is -------------- %s \n",SealLen);fflush(stdout);

	 if((tc_strcmp(SealLen,"")!=0))
		{
		   printf("\n SealLen has some value \n");fflush(stdout);

           if(AOM_lock(object_tag));
		   if(AOM_set_value_string(object_tag,"t5_SealLen",""))PrintErrorStack();
		   if(AOM_save(object_tag))PrintErrorStack();
		   if(AOM_unlock(object_tag))PrintErrorStack();

		   printf("\n SealLen value set to NULL  \n");fflush(stdout);
		}
		else
		{
           printf("\n SealLen value is already NULL \n");fflush(stdout);
		}

	/***************Adi - setting attribute values to null  *************************/

		 // Added to handle relation b/w ProAsm and Des Rev
				 printf("\n\n Pro2_membership relation new for JproAsm\n");
				 if(relation_dep) relation_dep=NULLTAG;
				 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));

				 if(relation_dep != NULLTAG)
				{

					   CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
					  printf("\n Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);

					  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
					  printf("\n Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);

					  CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
					  printf("\n Ckd Out Rev is -->%s\n",org_Item_id); fflush(stdout);

					  CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

					 printf("\n\nProAsm Rel with Des Rev are --->:%d\n",countDep);fflush(stdout);

//
//						if(countDep>0)
//						{
//							for(ik=0;ik<countDep;ik++)
//							{
//							   primary_object11 = primary_list_Dep[ik].primary;
//							   if(primary_object11!=NULLTAG)
//							   {
//								 printf("\nI value in loop is--->:%d\n",ik);	fflush(stdout);
//								 CALLAPI(AOM_ask_value_string(primary_object11,"object_name",&Id_string_val));
//								 printf("\n Proasm where Item Rev is used --->%s\n",Id_string_val);fflush(stdout);
//
//								 CALLAPI(AOM_ask_value_string(primary_object11,"protection",&Id_Pro_val));
//								 printf("\n Proasm unique --->%s\n",Id_Pro_val);fflush(stdout);
//
//								  CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep22));
//
//								  GRM_find_relation(primary_object11,object_tag,relation_dep22,&relation_test);
//
//								 CALLAPI(GRM_delete_relation(relation_test));
//								 CALLAPI(AOM_refresh(primary_object11,0));
//								 CALLAPI(AOM_refresh(object_tag,0));
//
//								  printf("\n Relation deleted succ\n");fflush(stdout);
//
//
//								  main_seq=org_seq_id_int-1;
//
//								  sprintf(NewSeq,"%d",main_seq);
//
//								  printf("\n main_seq char value is  -->%s\n",NewSeq); fflush(stdout);
//
//								  if(QRY_find("DesignRevision Sequence", &queryTag));
//
//									if (queryTag)
//									{
//										printf(" Uni Found Query\n"); fflush(stdout);
//									}
//									else
//									{
//										printf("Uni Not Found Query\n"); fflush(stdout);
//									}
//
//									qry_values[0] = org_rev_id ;
//									qry_values[1] = NewSeq;
//									qry_values[2] = org_Item_id;
//									if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));
//
//									printf(" Obj queried with builder are --->%d\n",resultCount); fflush(stdout);
//
//									if(resultCount>0)
//									{
//										printf(" Des Rev already exists\n"); fflush(stdout);
//
//										for (jk=0;jk<resultCount;jk++ )
//										{
//											item_tag_rev = rev[jk];
//
//											CALLAPI(GRM_create_relation(primary_object11, item_tag_rev, relation_dep22, NULL, &relation_New));
//											CALLAPI(AOM_refresh (primary_object11,0));
//											CALLAPI(AOM_refresh(relation_New,0));
//											CALLAPI(AOM_refresh(object_tag,0));
//											CALLAPI(GRM_save_relation(relation_New));
//											printf("\n GRM_save_relation created succ \n\n"); fflush(stdout);
//
//
//										}
//									}
//								}
//							  }
//						}
				}

				 CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep11,&primary_list_Dep11));

				printf("\n\n After deleting ProAsm Rel with Des Rev are --->:%d\n",countDep11);fflush(stdout);

				// Ended to handle relation b/w ProAsm and Des Rev

		if( AOM_ask_value_string(object_tag,"item_revision_id",&desrevid))PrintErrorStack();
		printf(" desrevid %s\n", desrevid);fflush(stdout);
		if(strcmp(desrevid,"NR;1")!=0)
		{
			printf("anil start");fflush(stdout);
			if(AOM_lock(object_tag));
			if( AOM_set_value_string(object_tag,"t5_DocRemarks",""))PrintErrorStack();
			if(AOM_save(object_tag))PrintErrorStack();
			if(AOM_unlock(object_tag))PrintErrorStack();
			printf("anil end");fflush(stdout);
		}

	/**************************************************************************************************************************/
/*** Check Application_owner and don't allow check out of other datasets.***/
/*** Also dont't allow check out of JT with design revision ***/
/**************************************************************************************************************************/


/**** Checkout usecases testing*/
CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
if(relation_type != NULLTAG)
{
	CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
	printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
	CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
	printf("\n APOwn rev id-->%s\n",org_rev_id); fflush(stdout);

	CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
	printf("\n  APOwn item iD-->%s\n",org_Item_id); fflush(stdout);
	CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
	printf("\n Attached Datasets:%d\n",cnt);fflush(stdout);
	CALLAPI(AOM_ask_value_string(object_tag,"t5_ApplicationOwner",&Ap_owner));

	for(i=0;i<cnt;i++)
	{
		Valid_Ch_Dataset=0;
		Ap_owner_Nt_fnd=0;
		dt_typ_nm=NULL;
		dt_typ_nm1=NULL;//Adi
		OwnUser=NULL;  //Adi
		//catfound=0;
		//proEfound=0;
		deleteRel=0;

		dataset = attachments[i];
		CALLAPI(RES_is_checked_out(dataset,&checkout));

		printf("\nValue of checkout : %d\n",checkout);fflush(stdout);
		printf("\n Value of checkout : %d\n",checkout);fflush(stdout);

		if (checkout==0)
		{			
			CALLAPI(GRM_find_relation(object_tag, dataset, relation_type, &relation_tag)); //Adi
			if (relation_tag != NULLTAG)
			{
				printf("\n inside relation_tag \n");fflush(stdout);
				if(AOM_ask_value_string(dataset,"object_name",&DsObjNameS))
				printf("\n DsObjNameS %s", DsObjNameS);fflush(stdout);
				if(strstr(DsObjNameS,".csv")!=NULL)
				{	
					printf("\n .csv Deletion \n");fflush(stdout);
					CALLAPI(GRM_delete_relation	(relation_tag));
					printf("\n .csv Deletion success \n"); fflush(stdout);
				}
			}                                                                             //Adi

			printf("\n Application owner %s", Ap_owner);fflush(stdout);
			if(Ap_owner)
			{
				CALLAPI(AOM_ask_value_string(dataset,"object_type",&dt_typ_nm));
				printf("\n Iteration [%d] for ApplicationOwner %s and DatasetTyeTpCopmpare %s",i,Ap_owner,dt_typ_nm);fflush(stdout);
				printf("\n IMAN_specification  type_name is %s",dt_typ_nm);

				if(((tc_strstr(Ap_owner,"ProE")!=NULL) || (tc_strstr(Ap_owner,"Creo")!=NULL)) &&	((tc_strstr(dt_typ_nm,"Cat")!=NULL) || (tc_strstr(dt_typ_nm,"CMI")!=NULL) || (tc_strstr(dt_typ_nm,"CAT")!=NULL)))
				{
					printf("\n Catia data found attached Application is %s and revision number %s ",Ap_owner,org_Item_id);
					deleteRel=1;

				}

				else if (((tc_strstr(Ap_owner,"Cat")!=NULL) || (tc_strstr(Ap_owner,"CMI")!=NULL)|| (tc_strstr(Ap_owner,"CAT")!=NULL)) && ((tc_strstr(dt_typ_nm,"ProAsm")!=NULL) || (tc_strstr(dt_typ_nm,"ProDrw")!=NULL) || (tc_strstr(dt_typ_nm,"ProPrt")!=NULL) || tc_strstr(dt_typ_nm,"Creo")!=NULL))
				{
					printf("\n ProE data found attached Application owner is %s and RevisionNUmber %s ",Ap_owner,org_Item_id);
					deleteRel=1;
				}

				else if ((tc_strstr(Ap_owner,"Alias")!=NULL) && ((tc_strstr(dt_typ_nm,"Cat")!=NULL) || (tc_strstr(dt_typ_nm,"CMI")!=NULL) || (tc_strstr(dt_typ_nm,"CAT")!=NULL))) //Adi for Alias
				{
					printf("\n Catia data found attached Application owner is %s and RevisionNUmber %s ",Ap_owner,org_Item_id);
					deleteRel=1;
				}

			}
			else
			{

				printf("\n setting Application owner not found flag");fflush(stdout);
				Ap_owner_Nt_fnd=1;

			}

			printf("\n catfound %d and Dataset is %s ",catfound,dt_typ_nm);fflush(stdout);
			printf("\n proEfound %d and Dataset is %s ",proEfound,dt_typ_nm);fflush(stdout);

				if (deleteRel==1)
			{
				printf("\n inside GRM_find_relation and GRM_delete_relation for %s ",dt_typ_nm);fflush(stdout);
				CALLAPI(GRM_find_relation(object_tag,dataset,relation_type,&relation_fnd));
				if(relation_fnd != NULLTAG)
				{
					printf("\n DataSet relation delete \n");
					CALLAPI(GRM_delete_relation	(relation_fnd));
					printf("\n DataSet relation delete success \n");
					continue;
				}
			}

           /**************** Adi ***********************/
			CALLAPI(AOM_ask_value_string(dataset,"object_type",&dt_typ_nm1)); 
			printf("\n dt_typ_nm1=========== %s ",dt_typ_nm1);fflush(stdout);
			if(tc_strcmp(dt_typ_nm1,"T5_Alias")==0)
			{
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt1,&attachments1));
				printf("\n Inside T5_Alias Attached Datasets ======= %d \n",cnt1);fflush(stdout);

				for(ip=0;ip<cnt1;ip++)
				{
					dataset1 = attachments1[ip];
					CALLAPI(RES_is_checked_out(dataset1,&checkout1));

					printf("\n  checkout1 ====== %d\n",checkout1);fflush(stdout);

					CALLAPI(AOM_ask_value_string(dataset1,"object_type",&dt_typ_nm2));
					printf("\n dt_typ_nm2=========== %s ",dt_typ_nm2);fflush(stdout);

					if (checkout1==0)
					{
						if(tc_strcmp(dt_typ_nm2,"CMI2Part")==0)
						{
							printf("\n  CONVERTED CMI2PART FOUND ATTACHED   ====== %d\n");fflush(stdout);
							CALLAPI(GRM_find_relation(object_tag,dataset1,relation_type,&relation_fnd1));
							if(relation_fnd1 != NULLTAG)
							{
								printf("\n DataSet relation delete CONVERTED CMI2PART \n");
								CALLAPI(GRM_delete_relation	(relation_fnd1));
								printf("\n DataSet relation delete success  CONVERTED CMI2PART\n");
								continue;
							}
						}
					}
				}
			} /**************** Adi ***********************/


			printf("\nValid_Ch_Dataset actiononDAtaset %d and Ap_owner_Nt_fnd %d actiononDAtaset \n",Valid_Ch_Dataset,Ap_owner_Nt_fnd);fflush(stdout);


				printf("\nreason:%s\n",reason);fflush(stdout);
				printf("\nchange_id:%s\n",change_id);fflush(stdout);
				printf("\ndir_name:%s\n",dir_name);fflush(stdout);
				printf("\nreservation_type:%d\n",reservation_type);fflush(stdout);
				CALLAPI(RES_checkout(dataset,reason,change_id,dir_name,reservation_type));
				printf("\n %d DataSet Checked Out \n",dataset);
			}

	}
}
else
{
	printf("IMAN_specification,&relation_type is null");

}

/**** Checkout usecases testing end */

	}
//anil end



	/**************************************************************************************************************************/
	/*** On Assembly Checkout All Child WeldSpot Part Should Checked Out Automatically...... Added By Abhishek (8-Sep-2011) ***/
	/**************************************************************************************************************************/
	if(!strcmp(type_name,"Design Revision"))
	{
		printf("\nIt is Design Part ... So check\n");fflush(stdout);
		//if( AOM_ask_value_string(object_tag,"item_id",&cp_ItemId))PrintErrorStack();
		//printf("ItemId for Checkout is [%s]\n", cp_ItemId);fflush(stdout);


		if (GRM_list_secondary_objects_only(object_tag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)
		PrintErrorStack();
		if( AOM_ask_value_string(object_tag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();
		printf("\nTotal Secondary Objects Found for Part [%s] are [%d]\n",Item_id,n_attchs);fflush(stdout);

		if (n_attchs > 0)
		{
			printf("\nThere are some Secondary Objects ... so proceed with checks\n");fflush(stdout);
			/*Getting ChildParts through BOM LINE*/
			if(BOM_create_window (&t_BomLineWindow) !=ITK_ok) PrintErrorStack();
			//printf("\nABHI 1111\n");fflush(stdout);
			if(CFM_find( "Latest Working", &t_Rule )!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 2222\n");fflush(stdout);
			if(BOM_set_window_config_rule( t_BomLineWindow, t_Rule )!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 3333\n");fflush(stdout);
			if(BOM_set_window_pack_all (t_BomLineWindow, true)!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 4444\n");fflush(stdout);
			if(BOM_set_window_top_line (t_BomLineWindow, t_ItemTag, object_tag, null_tag, &t_TopLine)!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 5555\n");fflush(stdout);
			if(BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren)!=ITK_ok) PrintErrorStack();
			printf("\nTotal Child Parts Found in BomLine are [%d]\n",i_ChildCount);fflush(stdout);

			for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
			{
				if(t_Childobject) t_Childobject=NULLTAG;
				t_Childobject=t_PartChildren[iChldPrts];
				if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok)PrintErrorStack();
				if (TCTYPE_ask_name(t_ChildObjType,ca_ChildType_Name)!=ITK_ok)PrintErrorStack();
				printf("\n[%d] ChildType is [%s]\n",iChldPrts+1,ca_ChildType_Name);fflush(stdout);

				if( BOM_line_look_up_attribute ("bl_item_object_type",&iItemType));
				if(BOM_line_ask_attribute_string(t_Childobject, iItemType, &cp_ItemType_str));
				printf("\n[%d] Child ItemType is [%s]\n",iChldPrts+1,cp_ItemType_str);

				if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
				if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
				if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
				if(BOM_line_ask_attribute_string(t_Childobject, iItemRevId, &cp_ItemRev_str));
				printf("\n[%d] ItemRevision is [%s] and ItemID is: [%s]\n",iChldPrts+1,cp_ItemRev_str,cp_ItemID_str);

				if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
				if(BOM_line_ask_attribute_tag(t_Childobject, iChildItemTag, &t_ChildItemRev));

				if(AOM_ask_value_int(t_ChildItemRev,"sequence_id",&i_ChildSeq));
				cp_ChildSeq = (char *) MEM_alloc( 5 * sizeof(char) );
				sprintf(cp_ChildSeq,"%d",i_ChildSeq);
				printf("\n[%d] ItemSequence is [%s]\n",iChldPrts+1,cp_ChildSeq);fflush(stdout);

				if(BOM_line_look_up_attribute ("bl_rev_checked_out",&iItemChkdOut));
				if(BOM_line_ask_attribute_string (t_Childobject, iItemChkdOut, &cp_ChildChkOutValue));
				printf("\n[%d] CheckedOut is [%s]\n",iChldPrts+1,cp_ChildChkOutValue);fflush(stdout);

				if (AOM_ask_value_string(t_ChildItemRev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
				printf("\n[%d] Description is [%s]\n",iChldPrts+1,Desc_obj);fflush(stdout);

				//if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && ((tc_strcmp(cp_ItemType_str,"WeldSpot")==0)||(tc_strstr(cp_ItemID_str,"_WE") != NULL)))
				if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && ((tc_strcmp(cp_ItemType_str,"WeldSpot")==0)))

				{
					printf("\nThis is WeldSpot and is Not Checked out... so auto checkout it\n");fflush(stdout);
					CALLAPI(RES_checkout(t_ChildItemRev,reason,change_id,dir_name,reservation_type));
				}
			    //if (tc_strstr(cp_ItemID_str,"_WE") != NULL)
			    if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && (tc_strstr(cp_ItemID_str,"_WE")!= NULL))
				{
					printf("\n _WE not checked out.. so auto checkout \n");fflush(stdout);
					CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTag));
					CALLAPI(AOM_refresh(t_ChildItemRev,0));
					CALLAPI(AOM_refresh(NewRevTag,0));
				}
			}
			 //Muktesh
			 printf("\n Closing Bom Window\n");fflush(stdout);
			if(BOM_close_window (t_BomLineWindow) !=ITK_ok) PrintErrorStack();
			 printf("\n After Closing Bom Window\n");fflush(stdout);
			//BOM_close_window(t_BomLineWindow);
		}
		/*Added By Abhishek For Bom View Revision Checkout on Design Checkout*/
		printf("\nTypeName for Checkout is [%s]\n",type_name);fflush(stdout);
		if (strcmp(type_name,"Design Revision") == 0)
		{
			 printf("\n going to stamp status\n");fflush(stdout);


			 /*Start  Removing Release Status Code by Deepti*/

			CALLAPI(POM_class_of_instance(object_tag,&class_id));
			CALLAPI(POM_name_of_class(class_id,&class_name));
			printf("\n class_name is :%s\n",class_name);fflush(stdout);

			CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

			CALLAPI(POM_unload_instances (1,&object_tag));
			CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
			CALLAPI(POM_is_loaded(object_tag,&log1));
			if(log1 == 1)
			{
				 printf(" Load Success\n " );
			}
			else
			printf("Load Failure\n"  );

			CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList, &n_values) );
			printf("\n n_values is :%d\n",n_values);fflush(stdout);
			if(n_values>0)
			{
				CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

				for (cunt1 =  0; cunt1 < n_values; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList,0,1));
					printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));

				}

				 CALLAPI(AOM_unlock(object_tag));
			}

			 /*End  Removing Release Status Code by Deepti*/

			  CALLAPI(SA_ask_current_role(&CurrentRoleTag));  //DEEPTI TZ1.34
			 CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName));//DEEPTI TZ1.34
			 printf("\n\n  roleName : %s\n",roleName); fflush(stdout);//DEEPTI TZ1.34
			  PlantName=subString(roleName,3,4);
			  printf( "PlantName:%s\n", PlantName);

			//UPdate Lifecycle state on Design Revision
			 //CALLAPI (CR_create_release_status("T5_LcsWorking",&status_rel));
			 //CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));

			 if(tc_strstr(roleName,"APL")!=NULL)
			 {
				  if(strcmp(PlantName,"APLC")==0)
		         {
				 CALLAPI (CR_create_release_status("T5_LcsAPLWrkg",&status_rel)); //DEEPTI TZ1.34
				CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));//DEEPTI TZ1.34
				 }else if(strcmp(PlantName,"APLV")==0)
		         {
				 CALLAPI (CR_create_release_status("T5_LcsAPLvWrkg",&status_rel)); //DEEPTI TZ1.34
				CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));//DEEPTI TZ1.34
				 }
			 }
			 else
			 {

				//UPdate Lifecycle state on Design Revision
				CALLAPI (CR_create_release_status("T5_LcsWorking",&status_rel));
				CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));
			 }

			//UPdate Lifecycle state on BOM VIew
			if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok)PrintErrorStack();
			printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

			if (BomViewCnt > 0)
			{
				printf("\nCheckout BOM Views Also .............\n");fflush(stdout);

				if(tc_strstr(roleName,"APL")!=NULL) //DEEPTI TZ1.34
			  {
				  if(strcmp(PlantName,"APLC")==0)
		         {
				printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
				status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLWrkg");
				printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
				 }else if(strcmp(PlantName,"APLV")==0)
		         {
 				printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
				status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLvWrkg");
				printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
				 }
			  }
			  else
			  {
				printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
				status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			  }

//				printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
//				status = t5UpdateLifecycleStateAD(BomViewList[0], "T5_LcsWorking");
//				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			}

			//UPdate Lifecycle state on Dataset
			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
			if(relation_type != NULLTAG)
			{
				CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
				printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
				printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
				for(i=0;i<cnt;i++)
				{
				  printf("\nin checkin for loop\n");fflush(stdout);
				  dataset = attachments[i];
				  CALLAPI(RES_is_checked_out(dataset,&checkout));
				  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
				  if (checkout==1)
				  {
					  if(tc_strstr(roleName,"APL")!=NULL) //DEEPTI TZ1.34
					  {
						 if(strcmp(PlantName,"APLC")==0)
		                {
						printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLWrkg");
						printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
						}else 	if(strcmp(PlantName,"APLV")==0)
		                {
						printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLvWrkg");
						printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
						}
					  }
					  else
					  {
						printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
						printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
					  }

					  //printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
					  //status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
					  //printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				  }

				}
			}
		}
	}
	else
	{

		if((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0) || (strcmp(type_name,"ProDrw")==0))
		{
			printf("\n other than DR for skk TypeName for checkout  is [%s]\n",type_name);fflush(stdout);
			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type_Dsn));

			    if(relation_type_Dsn != NULLTAG)
			    {
				     CALLAPI(GRM_list_primary_objects(object_tag,relation_type_Dsn,&count2,&primary_list2));
					 printf("\n No:of Des Rev Obj attached to dataset are --> [%d]\n",count2);fflush(stdout);
			    }

			    if(primary_list2!=NULLTAG)
				{
						printf("\n\nDataset Attached to Primary Object in in checkin_dataset:%d\n",count2);fflush(stdout);

						for(i2=0;i2<count2;i2++)
						{
						   //primary_object2 = primary_list2[i].primary;
						   //primary_object2 = primary_list2[i];
						   primary_object2 = primary_list2[i2].primary;
						   if(primary_object2!=NULLTAG)
						   {
							 //printf("\nprimary_object2 in skk checkin :%d\n",i);
							 printf("\nprimary_object2 in skk checkin :%d\n",i2);
							 CALLAPI(RES_is_checked_out(primary_object2,&checkout2));
							 	printf("\nValue of checkout2 for primary_object2 : %d\n",checkout2);fflush(stdout);
						//	 printf("\n\nallow_chkin1 in in disallow_checkin_dataset:%d and ObjectClassType 222 :%s and strcmp proasm :%d\n",allow_chkin,ObjectClassType,strcmp(ObjectClassType,"ProPrt"));

							//  if(strcmp(ObjectClassType,"ProPrt")==0)// && (strcmp(ObjectClassType,"ProPrt")!=0))
							//  {
								//if(checkout2==0)
								if(!checkout2)
								{
								  printf("\n inside DR for ProAsmmmmmmmmmmmmmmmmmm \n");
								  CALLAPI(RES_checkout(primary_object2,reason,change_id,dir_name,reservation_type));
								  //CALLAPI (CR_create_release_status("T5_LcsWorking",&status_rel));
								  //CALLAPI(EPM_add_release_status(status_rel,1,&primary_object2,retain));
								  printf("\n checkout  in Design revision for  PROE \n");
								 }
							//  }
							 }
					  }
			  }
		 }
	}
	/*************************************************************************************************/
	/********************************** Code End Abhishek (8-Sep-2011) *******************************/
	/*************************************************************************************************/

	return ifail;
}

extern DLLAPI int cancelcheckout_with_dataset(METHOD_message_t *m, va_list args)
{
  	char		   relation_name[TCTYPE_name_size_c+1];
	tag_t		   relation_type	= NULLTAG;
	tag_t		   *attachments		= NULLTAG;
	tag_t		   dataset			= NULLTAG;
	tag_t		   relation_dep22			= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	logical		   copy_flag		= (logical)   va_arg (args, int);
	int		       ifail=0,cnt=0,i,ij,count=0,count_asm=0;
	GRM_relation_t *primary_list	= NULLTAG;
	char		   *is_chkout		=NULL;
	char		   *is_chkout1		=NULL;
	char		   *org_rev_id		=NULL;
	char		   *org_item_cat		=NULL;
	char		   *sPartID		=NULL;
	tag_t		   primary_object	= NULLTAG;
	tag_t		   *tags	= NULLTAG;
	tag_t			objTypeTag									= NULLTAG;
	char			type_name[TCTYPE_name_size_c+1];
	char   *Id_string_val=NULL;
	char   *sAsmVer=NULL;
	char   *asm_rev=NULL;
	int main_seq=0;
	char   *Id_Pro_val=NULL;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	int org_seq_id_int=0;
	tag_t		   primary_object2	= NULLTAG;
	tag_t* status_list = NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t queryTagP = NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	int n_entries = 3;
	int n_entries2 = 2;
	int resultCountAsm = 0;
	int resultCount=0,jk=0,countDep11=0;
	tag_t *rev=NULLTAG;
	tag_t *revAsm=NULLTAG;
	WSO_search_criteria_t  	criteria;
	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};

	char *qry_entries5[2] = {"Name","Version Number"},
		 *qry_values5[2]	= {"*","*"};
	printf("\n\nIn cancel_checkout_with_dataset\n");

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	printf("\n type_name  = [%s]\n", type_name);fflush(stdout);

	// Added to handle relation b/w ProAsm and Des Rev
//				 printf("\n\n Pro2_membership relation new11\n");
//
//				 if(strcmp(type_name,"Design Revision")==0 )
//				{
//
//
//				CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//				printf("\n Final Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);
//
//				CALLAPI(AOM_ask_value_string(object_tag,"t5_ItmCategory",&org_item_cat));
//				printf("\n Item Category of Prev Seq is -->%s\n",org_item_cat); fflush(stdout);
//
//				if(strlen(org_item_cat)>0)
//				{
//					sPartID = strtok( org_item_cat, ";" );
//					sAsmVer = strtok( NULL, " " );
//
//					printf("\n sPartID -->%s\n",sPartID); fflush(stdout);
//					printf("\n sAsmVer -->%s\n",sAsmVer); fflush(stdout);
//
//					if(QRY_find("ProAsm Dataset", &queryTagP));
//
//					if (queryTagP)
//					{
//					printf(" ProAsm Found Query\n"); fflush(stdout);
//					}
//					else
//					{
//					printf("ProAsm Not Found Query\n"); fflush(stdout);
//					}
//
//					qry_values1[0] = sPartID ;
//					qry_values1[1] = sAsmVer;
//					if(QRY_execute(queryTagP, n_entries2, qry_entries5, qry_values1, &resultCountAsm, &revAsm));
//
//					printf("No:of ProAsm Found in DB are -->%d\n",resultCountAsm); fflush(stdout);
//
//
//					asm_rev = revAsm[0];
//
//					CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
//
//					CALLAPI(GRM_create_relation(asm_rev, object_tag, relation_dep, NULL, &relation_New));
//					CALLAPI(AOM_refresh (asm_rev,0));
//					CALLAPI(AOM_refresh(relation_New,0));
//					CALLAPI(AOM_refresh(object_tag,0));
//					CALLAPI(GRM_save_relation(relation_New));
//					printf("\n GRM_save_relation created succ \n\n"); fflush(stdout);
//
//				}
//
//
//
//
//				CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep11,&primary_list_Dep11));
//
//				printf("\n\n After deleting ProAsm Rel with Des Rev are --->:%d\n",countDep11);
//			}

				// Ended to handle relation b/w ProAsm and Des Rev





	if(!strcmp(type_name,"Design Revision"))
	{
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Attached Datasets rbb111:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  dataset = attachments[i];

		  if( AOM_ask_value_string(dataset,"checked_out",&is_chkout1)==ITK_ok)
			{

			   printf("\n is_chkout1 ---->%s \n",is_chkout1);

						if(strcmp(is_chkout1,"Y")==0)
						{

							  CALLAPI(RES_cancel_checkout(dataset,copy_flag));
							printf("\n %d Canceled DataSet Check Out \n",dataset);

						}
			}

		}

	}




	if(relation_type != NULLTAG)
	{
		CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
		printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Attached Datasets rbb:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  dataset = attachments[i];

		  if( AOM_ask_value_string(dataset,"checked_out",&is_chkout1)==ITK_ok)
			{

			   printf("\n is_chkout1 ---->%s \n",is_chkout1);

						if(strcmp(is_chkout1,"N")==0)
						{

							  CALLAPI(RES_cancel_checkout(dataset,copy_flag));
							printf("\n %d Canceled DataSet Check Out \n",dataset);

						}
			}

		}

//	 CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//	  printf("\n ppcancel Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);

//	  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
//	  printf("\n ppcancel Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);




		if(object_tag)
		{

		printf("\n ppcancel inside if loop  \n"); fflush(stdout);

		CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));

		if(primary_list!=NULLTAG)
		{
				printf("\n\n Des Rev Attached to Dataset rbb:%d\n",count);

				for(ij=0;ij<count;ij++)
				{
				   primary_object = primary_list[ij].primary;
				   if(primary_object!=NULLTAG)
				   {
				 	 printf("\nprimary_object:%d\n",ij);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)==ITK_ok)
					 {
						if(strcmp(is_chkout,"Y")==0)
						{

							  CALLAPI(RES_cancel_checkout(primary_object,copy_flag));
							  printf("\n\n checked-out sucess:\n");

						}
					 }

				  }
				}
		}
		}

		printf("\n Exitssssssss \n");



	}
    return ifail;
}


extern DLLAPI int disallow_checkin_dataset_only(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	int count = 0,i=0;
	char		   *is_chkout		=NULL;
 	GRM_relation_t *primary_list	= NULLTAG;

	char		   *class_name		= NULL;
	tag_t		   class_id			= NULLTAG;
	char		   *ObjectClassType		= NULL;
	int   allow_chkin = 1;
	//validation on check in
	char	*Desc_obj2	= NULL;
	char   *sObjTagMatDrw=NULL;
	char   *sObjTagDrwInd=NULL;
    char   *sPartStatus	 =NULL;
    char   *sPartType1	 =NULL;
    char   *sCatName	 =NULL;
    char   *sDesignGrp	 =NULL;
    char   *ItemDesc	 =NULL;
	logical	SpareInd1	= false;
	char   *SpareCriteria1	=NULL;
    char   *RefPartNumber1	=NULL;
    char   *MThickness		=NULL;
	char   *TempVal			=NULL;
	char   *EnvelopeDim		=NULL;
	int y		= 0;
	int counter1	= 0;
	double objWeightVal ;
	char wgtstr[100];
	int left=0;
	int right=0;
	char* username;
	tag_t user_tag=NULLTAG;

	sDesignGrp = malloc(10 * sizeof (char *) );
	TempVal=(char *) MEM_alloc(1000);
//validation on check in end

	printf("\n\ndisallow_checkin_dataset_only\n");fflush(stdout);


	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));

	printf("\n\nObject Classname:%s\n",class_name);

	POM_get_user(&username,&user_tag);

   printf("\n\n111111111111111111111111111111111 \n");

	if(strcmp(class_name,"Dataset")==0)
	{
		printf("\n\n1 222222222222222222 \n");fflush(stdout);
        CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type != NULLTAG)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }
		if(primary_list!=NULLTAG)
		{
				printf("\n\nDataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object!=NULLTAG)
				   {
				 	 printf("\nprimary_object:%d\n",i);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)==ITK_ok)

					 {
						if(strcmp(is_chkout,"Y")==0)
						{


							printf("adk validations start");fflush(stdout);
							printf("\nusername before validation: %s",username);fflush(stdout);

					//validations
						if(strcmp(username,"loader")!=0)
						{
						if (AOM_ask_value_string(primary_object,"item_revision_id",&Desc_obj2)!=ITK_ok);PrintErrorStack();
							printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
							//Vitthal start
							if( AOM_ask_value_string(primary_object,"t5_DrawingInd",&sObjTagDrwInd)!=ITK_ok);PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_Material",&sObjTagMatDrw)!=ITK_ok);PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_PartStatus",&sPartStatus)!=ITK_ok);PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
							if(	AOM_UIF_ask_value(primary_object,"t5_DesignGrp",&sDesignGrp)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"object_desc",&ItemDesc)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_logical(primary_object,"t5_SpareInd",&SpareInd1)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_SpareCriteria",&SpareCriteria1)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_RefPartNumber",&RefPartNumber1)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_MThickness",&MThickness)!=ITK_ok);PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_EnvelopeDimensions",&EnvelopeDim)!=ITK_ok);PrintErrorStack();

							printf("\n Drawing Indicator :%s \n Material In Drawing :%s \n Part Status :%s \n Part Type :%s  \n Design Group ",sObjTagDrwInd,sObjTagMatDrw,sPartStatus,sPartType1,sDesignGrp);fflush(stdout);

							if((strcmp(sObjTagDrwInd,"A")==0) || (strcmp(sObjTagDrwInd,"D")==0) )
							{
								if((tc_strcmp(sObjTagMatDrw,"")!=0))
								{
									printf("\n	Material name is present----->> :%s",sObjTagMatDrw);fflush(stdout);
								}
								else
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"If Drawing Indicator is D/A then Material is Mandatory");
									return ITK_err;
								}
							}
							if(strstr(Desc_obj2,"NR") != NULL)
							{
								if((strcmp(sPartStatus,"DR4")==0) || (strcmp(sPartStatus,"DR5")==0) ||(strcmp(sPartStatus,"AR4")==0) || (strcmp(sPartStatus,"AR5")==0) )
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"NR revision part can not be created or updated with DR-status DR4/5 or AR4/5");
									return ITK_err;

								}
							}
							if((strcmp(sPartType1,"C")==0))
							{
								if((tc_strcmp(sObjTagMatDrw,"")!=0))
								{
									printf("\n	Material while Part type comp :%s",sObjTagMatDrw);fflush(stdout);
								}
								else
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Material in drawing can not be NULL for part type Component. Please fill material in drawing");
									return ITK_err;
								}
							}

							/*** modification by Anand starts ***/

							//Material Thickness cannot be NULL for part type Component
							//Material thickness can be only Number or NA
							//DOT should not be more than one
							if((tc_strcmp(MThickness,"")==0))
							{
								printf("\n Material Thickness is NULL \n");fflush(stdout);

								if((strcmp(sPartType1,"C")==0))
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness cannot be NULL for part type Component.");
									return ITK_err;
								}

							}
							else
							{
								if(tc_strcmp(MThickness,"NA"))
								{
									TempVal =strcpy(TempVal,MThickness);

									for(y=0;y<tc_strlen(MThickness);y++)
									{
										if (TempVal[y] < 48 || TempVal[y] > 57)
										{	if (TempVal[y] == 46)
											{
												counter1++;
											}else
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness need to have only numbers or it can be NA.");
												return ITK_err;
											}
										}
									}

									if (counter1>0 && counter1<2 && tc_strlen(MThickness)>0 && tc_strlen(MThickness)<2)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness need to have only numbers or it can be NA.");
										return ITK_err;
									}

									if(counter1 >1)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DOT should not be more than one for Material Thickness");
										return ITK_err;
									}

								}

							}

							//If Part Category is BTS and Spare Indicator is True, so Party Part number is mandatory
							//if((SpareInd1==1) && tc_strcmp(SpareCriteria1,"BTS")==0 )
							if( tc_strcmp(SpareCriteria1,"BTS")==0 )
							{
								printf("\n Spare Criteria is BTS\n");fflush(stdout);

								if(tc_strcmp(RefPartNumber1,"")==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err, "Part Category is: BTS-Built To Specification, so Party Part number is mandatory");
									return ITK_err;
								}
							}
							//for spare indicator ='Y' envelope dimension should not be null
							if( SpareInd1==1 )
							{
								printf("\n Spare Indicator is True\n");fflush(stdout);

								if(tc_strcmp(EnvelopeDim,"")==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err, "Envelope Dimensions cannot be null if Spare Indicator is True");
									return ITK_err;
								}
							}

							if(tc_strstr(ItemDesc,"\n"))
							{
								printf("\n	Description of Design %s \n",ItemDesc);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"New Line charecter is not allowed in Desc field.");
								return ITK_err;
							}
							//Ashish

							//Mohan start

							if((tc_strlen(ItemDesc)>40) )
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Fill Only 40 Character In Description As Per SAP/Denis Standards.");
								return ITK_err;

							}
							//Mohan

							//amol Kale
							if( AOM_ask_value_double(primary_object,"t5_Weight",&objWeightVal)==ITK_ok)
								{
								printf("\n Action On dataset objWeightVal  = %f\n", objWeightVal);fflush(stdout);
								   if (objWeightVal > 0)
									{
										sprintf(wgtstr,"%0.3f",objWeightVal);
										printf("\n Action On dataset wgtstr  = [%s]\n", wgtstr);fflush(stdout);
										sscanf(wgtstr, "%d.%d", &left, &right);
										printf("\n adk Action On dataset left = [%d] adk right = [%d]", left,right);fflush(stdout);
										if(right>0)
										{
											while (right%10==0)
											{
												right=right/10;
											}
										}
										printf("\n adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
										if(left > 99999 || right > 999)
										{
											printf("\nAction On dataset validation to weight\n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Weight Value should have a maximum of 5 Digits before the Decimal Point and maximum of 3 digits after the Decimal Point.");
											printf("\n Action On dataset after validation to weight\n");fflush(stdout);
										   return ITK_err;


										}
									}

								}
						}
							printf("\n\n 3333333333333333333333333  \n");fflush(stdout);
							//Amol Kale
								//validations end
							allow_chkin = 0;

						}
					 }
					 printf("\n\nallow_chkin1 7777 :%d\n",allow_chkin);
				  }
				}
		}
		else
		{
			allow_chkin=0;
		}
		printf("\n\nallow_chkin2 8888 :%d\n",allow_chkin);

	    if(allow_chkin==0)
	    {
			  if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			printf("\n\n ObjectClassType in in disallow_checkin_dataset rbb:%s\n",ObjectClassType);

			if((strcmp(ObjectClassType,"ProAsm")==0) ||  (strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProDrw")==0)|| (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
			{
			   printf("\n\n Giving error for Individual checkin not allowed :%s\n",ObjectClassType);
			   EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkin of dataset is not allowed.");
			   return ITK_err;
			}
	    }

   }
    printf("\n\nallow_chkin:%d\n",allow_chkin);
	return ifail;
}

// 0 !=0  ->false
//-1 !=0 ->false
extern DLLAPI int disallow_checkout_dataset_only(METHOD_message_t *m,va_list args)
{
	int   ifail				= 0;
	int		       org_ver_id_int=0;
	int		       is_prev_seq=0;
	char		       *org_ver_id_int_prev=NULL;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   relation_type_prev	= NULLTAG;
	tag_t		   relation_depp	= NULLTAG;
	tag_t		   relation	= NULLTAG;
	tag_t		   relation_dep	= NULLTAG;
	tag_t		   relation_dep22	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t		   primary_object_prev	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t          relation_type22;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	GRM_relation_t *primary_list	= NULLTAG;
	GRM_relation_t *primary_list_prev	= NULLTAG;
	//tag_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep;
	//tag_t *primary_list_Depp	= NULLTAG;
	GRM_relation_t *primary_list_Depp;
	int count = 0,i=0 ,countDep=0,countDepp=0,ik=0,prev_ver_id=0,cmt=0,count_prev=0;
	char *is_chkout=NULL;
	char *ReleaseStatus=NULL;
	char		   *class_name		= NULL;
	//char		   *Drtype_name		= NULL;
	tag_t		    class_id		= NULLTAG;
	int				allow_chkout		= 1;
	int				status_count		= 0;
	int				status,ii,ref_count		= 0;
	tag_t* status_list = NULLTAG;
	tag_t	master	=	NULLTAG;
	//tag_t	DrObj	=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t	sequence_id_c	=	NULLTAG;
	tag_t	sequence_id_c1	=	NULLTAG;
	tag_t	DrobjTypeTag	=	NULLTAG;
	tag_t	datasettype =  NULLTAG;
	char			*Desc_obj	 = NULL;
	char			*Desc_obj1	 = NULL;
	char			*ITemRevSeq	 = NULL;
	char			*ITemRevSeq1 = NULL;
	char			*Id_string_val = NULL;
	char			*Id_Pro_val = NULL;
	char			*org_object_name = NULL;
	char			**ref_list = NULL;
	char			Drtype_name[TCTYPE_name_size_c+1];
	char   *Item_string=NULL;
	char *p;
	tag_t 	prevDataset= NULLTAG;
	//tag_t 	*ref_list= NULLTAG;

	//LH/RH Attribute declare
	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);

	char * ItemLhRhInd;
	char * ObjectClassType = NULL;
	int HasSymPrt=0;
	static int	 LHFlg	= -1;
	char *SesUsr = NULL;

	printf("\n\n In checkout_dataset_only New JProAsm \n");fflush(stdout);

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n\nObject Classname JProAsm:%s\n",class_name);

	POM_get_user_id (&SesUsr);
	printf("\n DRCHK: Session user: %s\n",SesUsr); fflush(stdout);

	if(strcmp(class_name,"Design_0_Revision_alt")==0)
	{
		tag_t	relation_Soln=NULLTAG;
		int    TskCnt=0;
		tag_t *TskSO=NULLTAG;
		char*	 taskTempLT= NULL;

		if(tc_strcmp(SesUsr,"infodba") !=0 && tc_strcmp(SesUsr,"loader") !=0)
		{
			CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_Soln));
			if(relation_Soln != NULLTAG)
			{
				CALLAPI( GRM_list_primary_objects_only(object_tag,relation_Soln,&TskCnt,&TskSO));
				printf("\n Task Count :-------------------->>>>  %d\n",TskCnt);fflush(stdout);
				if (TskCnt > 0)
				{
					printf("\n Inside validation Task not in add solutrion items \n",taskTempLT);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Design Revison is attached to ERC task. \nCheckout of Design Revison is not allowed.");
					return ITK_err;

					/*
					CALLAPI(AOM_UIF_ask_value(TskSO[0],"fnd0ActuatedInteractiveTsks",&taskTempLT));
					printf("\n primary taskTempLT is : <%s>\n",taskTempLT);fflush(stdout);

					if(tc_strcmp(taskTempLT,"") !=0)
					{
						printf("\n inside primary taskTempLT is : <%s>\n",taskTempLT);fflush(stdout);
						if(tc_strcmp(taskTempLT,"Add solution items") !=0)
						{
							printf("\n Inside validation Task not in add solutrion items \n",taskTempLT);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Design Revison is attached to ERC task.\n ERC task is currently not for 'Add solution Items' assignment.\n Checkout of Design Revison is not allowed.");
							return ITK_err;
						}
					}*/


				}
			}
	    }


		     // Added to handle relation b/w ProAsm and Des Rev
		CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));

		 if(relation_dep != NULLTAG)
		{
			 CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

			 printf("\n\n JproAsm ProAsm Rel with Des Rev are --->:%d\n",countDep);
		}

		  CALLAPI(AOM_ask_value_int(object_tag,"revision_number",&org_ver_id_int));
		printf("\n Version no org_ver_id_int is -->%d\n",org_ver_id_int); fflush(stdout);
		if (countDep <= 0)
		{

		}
		// Ended to handle relation b/w ProAsm and Des Rev

		/******************************************************************************************
								LH/RH Checked-Out start
		******************************************************************************************/
		printf("\n LHFlg : %d",LHFlg);
		HasSymPrt=0;
		tag_t  	master =	NULLTAG;
		tag_t  *master2 = NULLTAG;
		tag_t relation_type;
		tag_t relation_type2;

		int result,n_attch = 0;
		tag_t objTypeTag = NULLTAG;
		char type_name1[TCTYPE_name_size_c+1];
		logical	checkout2;
		tag_t	latestrev	=	NULLTAG;
		tag_t RevNewSeqTag = NULLTAG;

		CALLAPI(AOM_ask_value_string(object_tag,"t5_LeftRh_Comp",&ItemLhRhInd));
		printf("\n LH/RH Indicator of selected Part :: %s",ItemLhRhInd);fflush(stdout);

			if(ItemLhRhInd==NULL || tc_strcmp(ItemLhRhInd,"NA")==0)
			{
				printf("\n inside NULL/NA of LH/RH Indicator values");fflush(stdout);
				HasSymPrt=0;
			}else
			{
				if(tc_strcmp(ItemLhRhInd,"LH CATIA")==0 || tc_strcmp(ItemLhRhInd,"LH PROE")==0)
			    {
					printf("\n inside LH CATIA OR PROE");fflush(stdout);
					HasSymPrt=1;

					CALLAPI(ITEM_ask_item_of_rev(object_tag, &master));
					printf("\n ITEM_Found......");fflush(stdout);

					result = GRM_find_relation_type("T5_LRReln", &relation_type);
					printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

					if (relation_type!=NULLTAG)
					{
							CALLAPI(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
							printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

							if(n_attch>0)
							{
								CALLAPI(ITEM_ask_latest_rev(master2[0],&latestrev));
								if (latestrev!=NULLTAG)
								{
									  printf("\n master2 latest revision found\n");fflush(stdout);
									  if (TCTYPE_ask_object_type(latestrev,&objTypeTag)!=ITK_ok)PrintErrorStack();
									  if (TCTYPE_ask_name(objTypeTag,type_name1)!=ITK_ok)PrintErrorStack();
									  printf("\n type_name1 ==> %s\n", type_name1);fflush(stdout);

									  if(tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"ItemRevision")==0 )
									  {
											CALLAPI(RES_is_checked_out(latestrev,&checkout2));
											printf("\n Checked-out Status of selected Object : [%d]\n",checkout2);fflush(stdout);

											if (!checkout2)
											{
												printf("\n LHFlg : %d",LHFlg);
												LHFlg = 1;
												printf("\n LHFlg : %d",LHFlg);

												CALLAPI(ITEM_copy_rev(latestrev,NULL,&RevNewSeqTag));
												CALLAPI(AOM_refresh(latestrev,0));
												printf("\n RH Part get Checked-out.............");fflush(stdout);
											}else
											{
												printf("\n selected LH Part is already checked-out.......\n");fflush(stdout);
											}
									  }else
									  {
											printf("\n Class of LH Part is not matched.......\n");fflush(stdout);
									  }
								}
							}else
							{
								printf("\n LH/RH Part Master relation is not available\n");fflush(stdout);
							}
					}
				}else if(tc_strcmp(ItemLhRhInd,"RH CATIA")==0 || tc_strcmp(ItemLhRhInd,"RH PROE")==0)
				{
					printf("\n RHFlg : %d",LHFlg);
					printf("\n calling RH CATIA/PROE....");fflush(stdout);
					CALLAPI(ITEM_ask_item_of_rev(object_tag, &master));
					printf("\n ITEM_Found......");fflush(stdout);

					result = GRM_find_relation_type("T5_LRReln", &relation_type2);
					printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

					if (relation_type2!=NULLTAG)
                    {
						CALLAPI(GRM_list_secondary_objects_only(master,relation_type2,&n_attch,&master2));
						printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

						if(n_attch>0)
						{
							if(LHFlg<1)
							{
								printf("\n inside EMH_store_error_s2...........");fflush(stdout);
								//EMH_store_error_s2(EMH_severity_error,ITK_err,"In-Valid to Checked-Out RH Part","Pls select LH Part and Checked-Out");
								//return ITK_err;
							}else
							{
								printf("\n RH Part is checked-out........");fflush(stdout);
							}
						}
				  }
				}
			}

	}
 printf("\n\n b4 dataset.........\n");fflush(stdout);

	if(strcmp(class_name,"Dataset")==0)
	{

		tag_t	ref_relation=NULLTAG;
		tag_t	refobjTypeTag=NULLTAG;
		tag_t	primary_object_ref=NULLTAG;
		int    refcount=0;
		int    ri=0;
		int    ref_Result=0;
		tag_t *primary_ref_list=NULLTAG;
		char  reftype_name[TCTYPE_name_size_c+1];
		char   *dmlstatus=NULL;

		char* username = NULL;
	    tag_t user_tag=NULLTAG;

	   //Get Session User
 	   CALLAPI(POM_get_user(&username,&user_tag));
       printf("\n\n username :%s\n",username);fflush(stdout);
		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0)
		{
			 printf("\n\n\t\t bypass for loader & infodba ==> %s\n", username);fflush(stdout);
		}
       else
		{
			CALLAPI(GRM_find_relation_type("IMAN_reference",&ref_relation));
			//CALLAPI(GRM_find_relation_type("CMReferences",&ref_relation));
			if(ref_relation != NULLTAG)
			{
				 CALLAPI(GRM_list_primary_objects_only(object_tag,ref_relation,&refcount,&primary_ref_list));
			}
            printf("\n\n refcount--->:%d\n",refcount);fflush(stdout);
			if(refcount>0)
			{
					printf("\n\nDataset Attached to Primary Object:%d\n",refcount);

					for(ri=0;ri<refcount;ri++)
					{
						 CALLAPI(TCTYPE_ask_object_type (primary_ref_list[ri], & refobjTypeTag));
						 CALLAPI(TCTYPE_ask_name( refobjTypeTag, reftype_name));
						 printf("\n\n\t\t reftype_name ==> %s\n", reftype_name);fflush(stdout);

						 if(tc_strcmp(reftype_name,"ChangeRequestRevision")==0)
							{
								CALLAPI(AOM_UIF_ask_value(primary_ref_list[ri],"release_status_list",&dmlstatus));
								printf("\n\n\t\t dmlstatus ==> %s\n", dmlstatus);fflush(stdout);

								if(strcmp(dmlstatus,"ERC Released")==0)
									 {
									    printf("\n\n\t\t DML is in ERC Released State You cannot  modify referece dataset. ==> %s\n", dmlstatus);fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML is in Released State You cannot modify referece dataset.");
						                return ITK_err;
									 }

							}
					}


			  }

		}


		printf("\n\n In dataset loop only \n");fflush(stdout);
		if( AE_ask_dataset_prev_rev	(object_tag,&prevDataset) != ITK_ok) PrintErrorStack();

		//CALLAPI(AE_find_datasettype("ProAsm", &datasettype));
		if(prevDataset)
		{

		CALLAPI(AOM_UIF_ask_values(prevDataset, "ref_list",&ref_count, &ref_list));
//		CALLAPI(AE_ask_dataset_named_refs(prevDataset, &ref_count, &ref_list));
		printf("\n\t Got reference list--->%d",ref_count); fflush(stdout);
//
		 for (i = 0; i < ref_count; i++)
            {
                printf ("\n named reference %d is <%s>./n", i + 1, ref_list[i]);
            }
            MEM_free (ref_list);

		 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_depp));
		  if(relation_depp != NULLTAG)
			{
				 CALLAPI(GRM_list_secondary_objects(prevDataset,relation_depp,&countDepp,&primary_list_Depp));

				 printf("\n\n countDepp--->:%d\n",countDepp);fflush(stdout);
			}

			//CALLAPI(AOM_ask_value_string(prevDataset,"ref_list",&org_ver_id_int_prev));
			//printf("\n Latest Version no of Prev Dataset isss-->%s\n",org_ver_id_int_prev); fflush(stdout);

			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type_prev));
			if(relation_type_prev != NULLTAG)
			{
				 CALLAPI(GRM_list_primary_objects(prevDataset,relation_type_prev,&count_prev,&primary_list_prev));
			}

			printf("\n\n Prev Dataset Attached to Primary Object:%d\n",count_prev);

			if(primary_list_prev!=NULLTAG)
			{


					for(i=0;i<count_prev;i++)
					{
					   primary_object_prev = primary_list_prev[i].primary;
					   if(primary_object_prev!=NULLTAG)
					   {
						 printf("\n going for previous offic rev :%d\n",i);

						 if( AOM_ask_value_int(primary_object_prev,"sequence_id",&is_prev_seq)==ITK_ok)

						 printf("\n\n prev Dsn Rev Seq:%d\n",is_prev_seq);
					  }
					}
			}

		}

		CALLAPI(AOM_ask_value_int(object_tag,"revision_number",&org_ver_id_int));
		printf("\n Version no for Dataset isss-->%d\n",org_ver_id_int); fflush(stdout);






		 prev_ver_id=org_ver_id_int-1;

		 printf("\n Version no for Dataset isss-->%d\n",prev_ver_id); fflush(stdout);

		 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
		  if(relation_dep != NULLTAG)
		{
			 CALLAPI(GRM_list_secondary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

			 printf("\n\n JproAsmSecc ProAsm Rel with Des Rev are org_object_name--->:%d\n",countDep);fflush(stdout);
		}
		if (countDep >0)
		{
			for (cmt=0;cmt<countDep ;cmt++ )
			{
//				  DrObj = primary_list_Dep[cmt];
//				CALLAPI (TCTYPE_ask_object_type(DrObj,&DrobjTypeTag));
//				 printf("\n 00Drtype_namess-->%s\n",Drtype_name); fflush(stdout);
//				CALLAPI (TCTYPE_ask_name(DrobjTypeTag,Drtype_name));
//				 printf("\n Drtype_namess-->%s\n",Drtype_name); fflush(stdout);
//
//				 CALLAPI(AOM_ask_value_string(DrObj,"object_name",&org_object_name));
//				printf("\n org_object_nameee-->%s\n",org_object_name); fflush(stdout);

			}

		}


		CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type != NULLTAG)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }


		if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
		printf("\n\n disallow_checkout_dataset_only :: ObjectClassType in checkout :%s\n",ObjectClassType);

		if(primary_list!=NULLTAG)
		{
				printf("\n\n JproAsm Dataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object!=NULLTAG)
				   {
				 	 printf("\n JproAsm primary_object:%d\n",i);



					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)==ITK_ok)
					 {
						if(strcmp(is_chkout,"Y")!=0)
						{
							allow_chkout = 0;

						}
					 }
					 printf("\n\nallow_chkout1:%d\n",allow_chkout);
				  }
				}
		}
		else
		{
			//If Added to bypass newly created Pro/E Dataset, but this will bypass Pro/E Dataset checkout for those not having Design Revision
			if((strcmp(ObjectClassType,"ProAsm")==0) || (strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
			{
				allow_chkout = 1;
			}
			else
			{
				allow_chkout = 0;
			}
		}
		printf("\n\nallow_chkout2:%d\n",allow_chkout);

	    if(allow_chkout==0)
	    {
			if((strcmp(ObjectClassType,"ProAsm")==0) || (strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkout of dataset is not allowed");
				return ITK_err;
			}
		}

   }

   	if(!strcmp(class_name,"Design_0_Revision_alt"))
	{




		if (AOM_ask_value_string(object_tag,"current_revision_id",&Desc_obj1)!=ITK_ok)   PrintErrorStack();
		if(AOM_ask_value_int(object_tag,"sequence_id",&sequence_id_c1))PrintErrorStack();
		ITemRevSeq1 = (char *) MEM_alloc( 5 * sizeof(char) );
		sprintf(ITemRevSeq1,"%d",sequence_id_c1);

		if ( strcmp(Desc_obj1,"NR")==0 && strcmp(ITemRevSeq1,"1")==0)
		{
			printf("\nPart is NR,1\n");fflush(stdout);
		}




//	else
//	{
//
//		printf("\nDesin is not NR,1\n");fflush(stdout);
//		status=WSOM_ask_release_status_list(object_tag,&status_count,&status_list);
//	    if(status==ITK_ok)
//		 {
//			printf("\n number of statuses: %d \n",  status_count);
//			for (ii = 0; ii < status_count; ii++)
//			{
//				AOM_ask_name(status_list[ii], &ReleaseStatus);
//				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
//			}
//		 }
//
//		 if((strcmp(ReleaseStatus,"T5ErcPublished")==0) )
//			{
//				status=EMH_store_error_s1(EMH_severity_error,ITK_err, "BaseLine Object Cannot Be Checked-out, Please Check-out The Actual Object");
//				return ITK_err;
//			}
//
//			if(ITEM_ask_item_of_rev  ( object_tag,&master) );
//			if(ITEM_ask_latest_rev(master,&latestrev));
//
//			if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
//			if(AOM_ask_value_int(latestrev,"sequence_id",&sequence_id_c)) PrintErrorStack();
//			ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
//			sprintf(ITemRevSeq,"%d",sequence_id_c);
////
////			if (AOM_ask_value_string(object_tag,"current_revision_id",&Desc_obj1)!=ITK_ok)   PrintErrorStack();
////			if(AOM_ask_value_int(object_tag,"sequence_id",&sequence_id_c1))PrintErrorStack();
////			ITemRevSeq1 = (char *) MEM_alloc( 5 * sizeof(char) );
////			sprintf(ITemRevSeq1,"%d",sequence_id_c1);
//
//			printf("\n Value of Desc_obj :%s and Desc_obj1 : %s\n",Desc_obj,Desc_obj1);fflush(stdout);
//			printf("\n Value of ITemRevSeq :%s and ITemRevSeq1 : %s\n",ITemRevSeq,ITemRevSeq1);fflush(stdout);
//
//				p=strstr(Desc_obj,Desc_obj1);
//				if(p)
//				{
//					printf("\n Revision Matches\n");fflush(stdout);
//					if (strcmp(Desc_obj,".")==0)
//					{
//						printf("\n Desc_obj has . in it\n");fflush(stdout);
//						if ((strcmp(ITemRevSeq,ITemRevSeq1) !=0) )
//						{
//							printf("\n Part Sequence is not latest ,Checkout Failed. \n");fflush(stdout);
//							status=EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Latest Revision is allowed to Checkout,Checkout Failed.");
//							return ITK_err;
//						}
//					}
//				}
//				else
//				{
//					printf("\n Part is not latest ,Checkout Failed. \n");fflush(stdout);
//					status=EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Latest Revision is allowed to Checkout,Checkout Failed.");
//					return ITK_err;
//				}
//
//	}


	}



    printf("\n\nallow_chkout:%d\n",allow_chkout);
	LHFlg=-1;
	return ifail;
}

extern DLLAPI int disallow_cancalcheckout_dataset_only(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	GRM_relation_t *primary_list	= NULLTAG;
	int count = 0,i=0;
	char			*is_chkout		=NULL;
	char		   *class_name		= NULL;
	tag_t		    class_id		= NULLTAG;
	char		   *ObjectClassType		= NULL;
	int				allow_chkin		= 1;
		tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	int n_entries = 3;
	int resultCount=0,countDep=0,ik=0;
	tag_t *rev=NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	tag_t			relation_dep22								= NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	char   *Id_Pro_val=NULL;

	char   *org_rev_id=NULL;
	tag_t		   primary_object11	= NULLTAG;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	char   *CharVer=NULL;
	char   *Id_Obj_val=NULL;
	 int Id_string_val=0;
	char   *ProAsmDetails=NULL;
	int org_seq_id_int=0,main_seq=0,jk=0;
	tag_t		   primary_object2	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	CharVer = (char *) MEM_alloc( 20 * sizeof(char) );
	ProAsmDetails = (char *) MEM_alloc( 20 * sizeof(char) );


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};

	printf("\n\nIn disallow_cancalcheckout_dataset_only\n");

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));

	printf("\n\nObject Classname:Jproasm del comment is :%s\n",class_name);

	 // Started for Pro members

//	 if(strcmp(class_name,"Design Revision")==0 || strcmp(class_name,"Design_0_Revision_alt")==0)
//	{
//
//
//	  CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//	  printf("\n Dis Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);
//
//	  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
//	  printf("\n Dis Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);
//
//	  CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
//	  printf("\n Dis Ckd Out Rev is -->%s\n",org_Item_id); fflush(stdout);
//
//	  main_seq=org_seq_id_int-1;
//
//	  sprintf(NewSeq,"%d",main_seq);
//
//	  printf("\n Dis main_seq char value is  -->%s\n",NewSeq); fflush(stdout);
//
//	  if(QRY_find("DesignRevision Sequence", &queryTag));
//
//		if (queryTag)
//		{
//			printf(" Dis Uni Found Query\n"); fflush(stdout);
//		}
//		else
//		{
//			printf("Uni Not Found Query\n"); fflush(stdout);
//		}
//
//		qry_values[0] = org_rev_id ;
//		qry_values[1] = NewSeq;
//		qry_values[2] = org_Item_id;
//		if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));
//
//		printf(" Dis Obj queried with builder are --->%d\n",resultCount); fflush(stdout);
//
//		if(resultCount>0)
//		{
//			printf("\n Dis Des Rev already exists\n"); fflush(stdout);
//
//			for (jk=0;jk<resultCount;jk++ )
//			{
//				item_tag_rev = rev[jk];
//
//				 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
//
//
//					 CALLAPI(GRM_list_primary_objects(item_tag_rev,relation_dep,&countDep,&primary_list_Dep));
//
//					 printf("\n\n Dis ProAsm Rel with Des Rev are --->:%d\n",countDep);fflush(stdout);
//
//						if(countDep >0)
//						{
//
//							for(ik=0;ik<countDep;ik++)
//							{
//							   primary_object11 = primary_list_Dep[ik].primary;
//							   if(primary_object11!=NULLTAG)
//							   {
//								 printf("\n Dis I value in loop is--->:%d\n",ik);fflush(stdout);
////								 CALLAPI(AOM_ask_value_string(primary_object11,"object_name",&Id_string_val));
////								 printf("\n Dis Proasm where Item Rev is used --->%s\n",Id_string_val);
//
//								 CALLAPI(AOM_ask_value_int(primary_object11,"revision_number",&Id_string_val));
//								 printf("\n Dis Proasm Rev number --->%d\n",Id_string_val);
//
//								 CALLAPI(AOM_ask_value_string(primary_object11,"object_string",&Id_Obj_val));
//								 printf("\n Dis Proasm Object String --->%s\n",Id_Obj_val);fflush(stdout);
//
//								 sprintf(CharVer,"%d",Id_string_val);
//
//								  printf("\n DCharVer value is --->%s\n",CharVer);fflush(stdout);
//
//								  ProAsmDetails = strcat(Id_Obj_val,";");
//								  ProAsmDetails = strcat(ProAsmDetails,CharVer);
//
//								   printf("\n Dis ProAsmDetails --->%s\n",ProAsmDetails);fflush(stdout);
//
//								  if(AOM_lock(item_tag_rev));
//								if( AOM_set_value_string(item_tag_rev,"t5_ItmCategory",ProAsmDetails))PrintErrorStack();
//								if(AOM_save(item_tag_rev))PrintErrorStack();
//								if(AOM_unlock(item_tag_rev))PrintErrorStack();
//
//								  CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep22));
//
//								  GRM_find_relation(primary_object11,item_tag_rev,relation_dep22,&relation_test);
//
//								 CALLAPI(GRM_delete_relation(relation_test));
//								 CALLAPI(AOM_refresh(primary_object11,0));
//								 CALLAPI(AOM_refresh(item_tag_rev,0));
//
//								  printf("\n Dis Relation deleted succ\n");
//							   }
//							}
//						}
//
//
//			}
//		}
//}
		  //ended for Pro members

	if(strcmp(class_name,"Dataset")==0)
	{
        CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type != NULLTAG)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }
		if(primary_list!=NULLTAG)
		{
				printf("\n\nDataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object!=NULLTAG)
				   {
				 	 printf("\nprimary_object:%d\n",i);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)==ITK_ok)
					 {
						if(strcmp(is_chkout,"Y")==0)
						{
							allow_chkin = 0;

						}
					 }
					 printf("\n\nallow_chkin1:%d\n",allow_chkin);
				  }
				}
		}
		else
		{
			allow_chkin=0;
		}

		printf("\n\nallow_chkin2:%d\n",allow_chkin);

	    if(allow_chkin==0)
	    {
			  if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
			  printf("\n\n ObjectClassType in checkout :%s\n",ObjectClassType);

			  if((strcmp(ObjectClassType,"ProAsm")!=0) && (strcmp(ObjectClassType,"ProPrt")!=0)&& (strcmp(ObjectClassType,"ProDrw")!=0))
			  {
				   EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual cancel-checkout of dataset not allowed");
				   return ITK_err;
			  }
	    }
   }
    printf("\n\nallow_chkin:%d\n",allow_chkin);
	return ifail;
}


extern DLLAPI int CheckIn_validation(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	char		   *class_name		= NULL;
	char		   *PartType		= NULL;
	tag_t		   class_id			= NULLTAG;
	tag_t	 	   DesignRevision		= va_arg (args, tag_t);
	char *object_types;
	tag_t relationTag = NULLTAG;
	int   	count = 0, i =0 , flag = 0;
	tag_t *secondary_objects	;
	char  type_name[TCTYPE_name_size_c+1];
	//DR Validations
	char *PrtCol = NULL;
	char *Prttyp = NULL;
	char *PrtDR = NULL;
	char *PrtProj = NULL;
	char *DesGrp = NULL;
	char *PrtClass = NULL;
	char *Proj_typ	= NULL;
	tag_t  	PrtCls  = NULLTAG;
	tag_t	Project_t = NULLTAG;
	char	*info4	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	int     DRValiFlag      =  0;
	int     rsltCount      =  0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	tag_t	ObjTypProj	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	char *release_status = NULL;
	char* username = NULL;
	tag_t user_tag=NULLTAG;

	char	*info1	= NULL;
	char	*info2	= NULL;
	tag_t	TagQryContObjSite = NULLTAG, *BypCnObj = NULL;
	int		n_Input = 2,ByPasQCount = 0,CheckBypasFlag=0;
	char	*qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char	*qry_BypVal[2] = {"VALDBYPASS", "DSGPROJ"};

	printf("\nCheckIn_validation\n");fflush(stdout);

	//Get Session User
	CALLAPI(POM_get_user(&username,&user_tag));

	CALLAPI(POM_class_of_instance(DesignRevision,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n\nObject Classname:%s\n",class_name);
	CALLAPI(WSOM_ask_object_type 	(DesignRevision,type_name)) 		;
	printf("\n object Type= %s\n",type_name);
	PartType=malloc(50);
	if(tc_strcmp(type_name,"Design Revision")== 0)
	{
	if (AOM_UIF_ask_value(DesignRevision,"t5_PartType",&PartType)!=ITK_ok)   PrintErrorStack();
	printf("\n PartType is :%s\n",PartType);fflush(stdout);

	//ByPassing Mandetory Attribute Check Validations for APC Group Project Code 2956 and ST Design Group
	if(AOM_ask_value_string(DesignRevision,"t5_ProjectCode",&PrtProj)==ITK_ok) PrintErrorStack();
	if(AOM_UIF_ask_value(DesignRevision,"t5_DesignGrp",&DesGrp)==ITK_ok) PrintErrorStack();
	printf("\nRevision Project Code [%s] Design Group :[%s]",PrtProj,DesGrp);fflush(stdout);
	if(strcmp(PrtProj,"")!=0 || strcmp(DesGrp,"")!=0)
	{
		if(QRY_find2("ControlObjQry", &TagQryContObjSite));
		if(TagQryContObjSite)
		{
			 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ByPasQCount, &BypCnObj));
			 printf("\nObjects for Query VALDBYPASS == %d", ByPasQCount);fflush(stdout);
		}
		else
		{
			printf("\nContrlObj not found for SYSCD=VALDBYPASS");fflush(stdout);
		}

		if(ByPasQCount >0)
		{
			if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
			if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();//Project Code

			printf("\nBypass Project Codes List [%s]",info2); fflush(stdout);
			printf("\nBypass Design  Group List [%s]",info1); fflush(stdout);

			if(tc_strstr(info2,PrtProj)!=NULL || tc_strstr(info1,DesGrp)!=NULL)
			{
				CheckBypasFlag=1;	//If found in Control Object check-in validations will be bypassed
			}
		}
		printf("\nCheckBypasFlag : [%d]",CheckBypasFlag);fflush(stdout);
	}

	//DR Validation on CheckIn
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && CheckBypasFlag==0)
		{
			printf("\n Part Checkin validation ...\n"); fflush(stdout);
			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali";
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n CREVali:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
				printf("\n info4 is  = [%s]\n", info4);fflush(stdout);
			}
			if (AOM_ask_value_string(DesignRevision,"t5_ColourInd",&PrtCol)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(DesignRevision,"t5_PartType",&Prttyp)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(DesignRevision,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
			if (AOM_UIF_ask_value(DesignRevision,"release_status_list",&release_status)!=ITK_ok)   PrintErrorStack();
			printf("\n CheckIn:Prttyp: [%s] PrtDR: [%s] PrtCol:[%s] release_status:[%s]\n",Prttyp,PrtDR,PrtCol,release_status);fflush(stdout);
			if(POM_class_of_instance(DesignRevision,&PrtCls)!=ITK_ok) PrintErrorStack();
			if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok) PrintErrorStack();
			printf("\n CheckIn:PrtClass :%s",PrtClass); fflush(stdout);
			if (AOM_ask_value_string(DesignRevision,"t5_ProjectCode",&PrtProj)!=ITK_ok)   PrintErrorStack();
			printf("\n CheckIn:PrtProj is  = [%s]\n", PrtProj);fflush(stdout);
			DRValiFlag=0;
			if(tc_strcmp(release_status,"")!=0)
			{
				if(tc_strstr(info4,release_status) != NULL)
				{
					DRValiFlag=1;
					printf("\n CheckIn:DRValiFlag  = [%d]\n", DRValiFlag);fflush(stdout);
				}
			}
			if((tc_strcmp(PrtProj,"")!=0)&&(DRValiFlag==0))
			{
				if(ITEM_find_item(PrtProj,&Project_t)!=ITK_ok)PrintErrorStack();
				if (Project_t!=NULLTAG)
				{
					if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
					if(TCTYPE_ask_name(ObjTypProj,type_Proj));
					printf("\n CheckIn:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
					if (strcmp(type_Proj,"T5_Project")==0)
					{
						if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok)PrintErrorStack();
						printf("\n CheckIn:Proj_typ :[%s]\n",Proj_typ);   fflush(stdout);
						if((tc_strcmp(PrtDR,"")!=0) && (tc_strcmp(PrtDR,"NA")!=0))
						{
							if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
							{
								if((tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0)  && (tc_strcmp(PrtDR,"AR2")!=0) &&
								(tc_strcmp(PrtDR,"AR3")!=0) && (tc_strcmp(PrtDR,"AR4")!=0)  &&  (tc_strcmp(PrtDR,"AR5")!=0))
								{
									printf("\n CheckIn:ERROR:1.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly select AR-status from AR0/AR1/AR2/AR3/AR4/AR5.\n Part project type-Engine/GearBox/Clutch/Axles should have AR-value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
									return 1;
								}
							}
							else
							{
								if((tc_strcmp(PrtDR,"DR0")!=0) && (tc_strcmp(PrtDR,"DR1")!=0)  && (tc_strcmp(PrtDR,"DR2")!=0) &&
								(tc_strcmp(PrtDR,"DR3")!=0) && (tc_strcmp(PrtDR,"DR4")!=0)  &&  (tc_strcmp(PrtDR,"DR5")!=0))
								{
									printf("\n CheckIn:ERROR:2.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly select DR-status from DR0/DR1/DR2/DR3/DR4/DR5 instead of AR value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
									return 1;
								}
							}
						}
						else
						{
							//Check Part type..
							if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
							(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
							{
								printf("\n CheckIn:ERROR:3..\n"); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly select valid DR/AR-status from drop down list.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
								return 1;
							}
						}
					}
				}
			}
			printf("\n Inside Fun:CheckIn_validation in action_on_dataset: Part type: [%s] to check it's dataset  \n",PartType);fflush(stdout);
			/* Validations as below:
			For part Type = Assembly, CAD module, Module, GID,  Dummy assembly =  CMI2Part is invalid with Iman_Specification relation
			For part Type = Component & Dummy Component = CMI2product is invalid with Iman_Specification relation
			validation is on check in.*/
			if (GRM_find_relation_type("IMAN_specification", &relationTag))   PrintErrorStack();
			if(GRM_list_secondary_objects_only(DesignRevision, relationTag, &count, &secondary_objects)) PrintErrorStack();

			if(count > 0)
			{
				for (i=0; i<count; i++)
				{
					if (AOM_ask_value_string(secondary_objects[i],"object_type",&object_types)!=ITK_ok)   PrintErrorStack();

					printf("\n Inside Fun:CheckIn_validation in action_on_dataset: Object Type: [%s] to check it's dataset  \n",object_types);fflush(stdout);

					if((tc_strcmp(object_types,"CMI2Part") == 0) && ((tc_strcmp(PartType,"Assembly") == 0 || tc_strcmp(PartType,"CAD Module") == 0 || tc_strcmp(PartType,"Module") == 0 || tc_strcmp(PartType,"Group Id") == 0 || tc_strcmp(PartType,"Dummy Assembly") == 0)))
					{
						printf("\n Inside fun:CheckIn_validation in action_on_dataset.c file \n Error: CMI2Part is invalid for Part Type: [%s] \n",PartType);fflush(stdout);
						EMH_store_error_s3(EMH_severity_error,ITK_err,"For Part Type ",PartType,", Dataset type CMI2Part is invalid. Please change Part type to Component / Dummy Component");
						return 1;
					}
					if((tc_strcmp(object_types,"CMI2Product") == 0) && (tc_strcmp(PartType,"Component") == 0 || tc_strcmp(PartType,"Dummy Component") == 0))
					{
						printf("\n Inside fun:CheckIn_validation in action_on_dataset.c file \n Error: CMI2Product is invalid for Part Type: [%s] \n",PartType);fflush(stdout);
						EMH_store_error_s3(EMH_severity_error,ITK_err,"For Part Type ",PartType,", Dataset type CMI2Product is invalid. Please change Part type to other than Component / Dummy Component");
						return 1;
					}

				}
	}

		}
		//DR Validation on Check In end.





	if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0)
	{
		printf("\nBypass Provided as Login is %s\n", username);fflush(stdout);
	}
	else
	{
		CALLAPI(t5ValDataset(DesignRevision));
	}
	}
	return ifail;
}


extern int register_checkout_action(int *decision, va_list args)
{
	METHOD_id_t  method;
	METHOD_id_t  method_preCond;
	int	ifail = 0;

    *decision = ALL_CUSTOMIZATIONS;

   printf("\n  register_checkout_action \n");fflush(stdout);
    CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg, &method));
    if (method.id != NULLTAG)
    {
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)checkin_with_dataset,NULL));
    }

	CALLAPI(METHOD_find_method(RES_Type, RES_checkout_msg, &method));
    if (method.id != NULLTAG)
    {
        CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)checkout_with_dataset,NULL));
    }

	CALLAPI(METHOD_find_method(RES_Type, RES_cancel_checkout_msg , &method));
    if (method.id != NULLTAG)
	{
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)cancelcheckout_with_dataset,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg ,&method));
    if (method.id != NULLTAG)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_checkin_dataset_only,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_checkout_msg ,&method));
    if (method.id != NULLTAG)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_checkout_dataset_only,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_cancel_checkout_msg ,&method));
    if (method.id != NULLTAG)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_cancalcheckout_dataset_only,NULL));
	}

		CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg ,&method_preCond));
    if (method_preCond.id != NULLTAG)
	{
		CALLAPI( METHOD_add_pre_condition(method_preCond,(METHOD_function_t)CheckIn_validation,NULL));
	}
    return ifail;
}

extern DLLAPI int action_on_dataset_register_callbacks()
{
     CUSTOM_register_exit("action_on_dataset", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_checkout_action);

     printf("\nRegister Checkout Custom Exit org\n");

	 return ( ITK_ok );
}
