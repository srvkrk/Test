//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

//
//  @file
//  This file contains the implementation for the Business Object T5_BulkSorImpl
//

#include <T5_tm_bulkPPPMPrjCodelib/T5_BulkSorImpl.hxx>


#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/aom.h>
#include <tccore/releasestatus.h>
#include <tccore/workspaceobject.h>
#include <res/res_itk.h>

#include<iostream>

//#include <iostream.h>
#define ITK_err 919002
#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_BulkSorImpl::T5_BulkSorImpl(T5_BulkSor& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_BulkSorImpl::T5_BulkSorImpl( T5_BulkSor& busObj )
   : T5_BulkSorGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_BulkSorImpl::~T5_BulkSorImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_BulkSorImpl::~T5_BulkSorImpl()
{
}

//----------------------------------------------------------------------------------
// T5_BulkSorImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_BulkSorImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_BulkSorGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// desc for createPost
/// @param creInput - Description for the Create Input
/// @return - return desc for createPost
///




int PrtQuery_function(char *partno,char *Rev, char *Seq)
{
	int ifail = ITK_ok;
	int n_entries = 2;
	int resultCount = 0;
	char *RevSeq = NULL;

	RevSeq = (char *)MEM_alloc(5*sizeof(char));

	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);

	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;


	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	printf("\nQuering Part no [%s] Rev,Seq [%s]",partno,RevSeq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

		printf("\nPart Count in TCUA : [%d]",resultCount);


	}



	if (resultCount == 0)
	{
		return 1;
	}



	return ifail;

}

int PrtQuery_function_SOR (char *partno,char *Rev,char *Seq)
{
	int ifail = ITK_ok;
	int n_entries = 2;
	int resultCount = 0;
	int SORCount = 0;
	char *SOR_no = NULL;
	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;
	tag_t *SOR_Objects = NULLTAG;

	tag_t PartTag = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t SOR_Tag = NULLTAG;

	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(5*sizeof(char));

	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);

	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	printf("\nQuering Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

		printf("\nPart Count in TCUA : [%d]",resultCount);

		if ( resultCount > 0 )
		{

			PartTag = partObjs[0];
			printf("\nfind T5_PartSorRel");
			ifail =(GRM_find_relation_type("T5_PartSorRel",&relation_type));
			ifail =(GRM_list_secondary_objects_only(PartTag,relation_type,&SORCount,&SOR_Objects));

			if (SORCount > 0 )
			{

				SOR_Tag = SOR_Objects[0];
				ifail = ( AOM_ask_value_string ( SOR_Tag, "item_id", &SOR_no ) ) ;
				printf("\nSOR [%s] is Already Present For part",SOR_no);
				return 1;
			}


		}



	}



	return ifail;

}

int Get_Part_Details (tag_t Part_Tag, char *BulkPrtno,char *BulkPPPMprjcode, char *BulkPrjCode,char *partno,char *Rev,char *Seq, char *qSORPart_no, char *qSORPart_RevSeq, char *qSORPart_Rev, char *qSORPart_Seq, char *qSORPart_Desc, char *qSORPart_ClrInd, char *qSORPart_Cat)
{
	int ifail = ITK_ok;
	int n_entries = 2;
	int resultCount = 0;

	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;

	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(5*sizeof(char));

	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);


	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	printf("\nGet_Part_Details Quering Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
		printf("\nPart Count in TCUA : [%d]",resultCount);

		if ( resultCount > 0)
		{

			Part_Tag = partObjs[0];

			ifail = ( AOM_ask_value_string ( Part_Tag, "item_id", &qSORPart_no ) ) ;
			printf("\nGet_Part_Details qSORPart_no : [%s]", qSORPart_no);

			ifail = ( AOM_ask_value_string ( Part_Tag, "item_revision_id", &qSORPart_RevSeq ) ) ;
			printf("\nGet_Part_Details qSORPart_RevSeq : [%s]", qSORPart_RevSeq);

			qSORPart_Rev = strtok(qSORPart_RevSeq,";");
			qSORPart_Seq = strtok(NULL,"");

			printf("\nGet_Part_Details qSORPart_Rev : [%s]", qSORPart_Rev);
			printf("\nGet_Part_Details qSORPart_Rev : [%s]", qSORPart_Seq);

			ifail = ( AOM_ask_value_string ( Part_Tag, "object_desc", &qSORPart_Desc ) ) ;
			printf("\nGet_Part_Details qSORPart_Desc : [%s]", qSORPart_Desc);

			ifail = ( AOM_ask_value_string ( Part_Tag, "t5_ColourInd", &qSORPart_ClrInd ) ) ;
			printf("\nGet_Part_Details qSORPart_ClrInd : [%s]", qSORPart_ClrInd);

			ifail = ( AOM_ask_value_string ( Part_Tag, "t5_SpareCriteria", &qSORPart_Cat  ) ) ;
			printf("\nGet_Part_Details qSORPart_Cat : [%s]", qSORPart_Cat);


			printf("\nBulkPrtno            : [%s]",BulkPrtno);
			printf("\nBulkPPPMprjcode      : [%s]",BulkPPPMprjcode);
			printf("\nBulkPrjCode          : [%s]",BulkPrjCode);



			//qSOR_Create_function (BulkPrtno,BulkPPPMprjcode,BulkPrjCode, Part_Tag, qSORPart_no,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);
			//qSOR_Create_function (Bulkno,PPPMprjcode,PrjCode,Part_Tag,qSORPart_no,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);



		char *qSOR_no = NULL;
		qSOR_no = (char*)MEM_alloc(50*sizeof(char));

		tag_t latestqSorrev = NULLTAG;
		tag_t PrtRelationFind = NULLTAG;
		//tag_t BulkRelationFind = NULLTAG;
		tag_t PartSorRelTag = NULLTAG;
		//tag_t BulkSorRelTag = NULLTAG;

		const char *reason = "" ;
		const char *change_id = "" ;
		const char *dir_name = "" ;


		tc_strcpy(qSOR_no,"qSOR_");
		tc_strcat(qSOR_no,qSORPart_no);
		tc_strcat(qSOR_no,"_");
		tc_strcat(qSOR_no,qSORPart_Rev);


		tag_t tItemTag = NULLTAG ;
		tag_t tRevTypeTag = NULLTAG ;
		tag_t tItemTypeTag = NULLTAG ;
		tag_t tItemCreateInputTag = NULLTAG ;
		tag_t tRevCreateInputTag  = NULLTAG ;

		printf("\nqSOR_Create_function BulkPrtno        : [%s]",BulkPrtno);
		printf("\nqSOR_Create_function PPPMprjcode      : [%s]",BulkPPPMprjcode);
		printf("\nqSOR_Create_function prjcode          : [%s]",BulkPrjCode);
		printf("\nqSOR_Create_function qSORPart_Rev     : [%s]",qSORPart_Rev);
		printf("\nqSOR_Create_function qSORPart_Seq     : [%s]",qSORPart_Seq);
		printf("\nqSOR_Create_function qSORPart_Desc    : [%s]",qSORPart_Desc);
		printf("\nqSOR_Create_function qSORPart_ClrInd  : [%s]",qSORPart_ClrInd);
		printf("\nqSOR_Create_function qSORPart_Cat     : [%s]",qSORPart_Cat);



		ifail = ( TCTYPE_find_type ( "T5_quicksorRevision", "T5_quicksorRevision", &tRevTypeTag ) ) ;
		ifail = ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;

		ifail = ( TCTYPE_find_type ( "T5_quicksor", "T5_quicksor", &tItemTypeTag ) ) ;
		ifail = ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;



		ifail = ( AOM_set_value_string ( tItemCreateInputTag, "item_id", qSOR_no ) ) ;
		ifail = ( AOM_set_value_string ( tItemCreateInputTag, "object_name", qSOR_no ) ) ;
		ifail = ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;


		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartNumber", qSORPart_no ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartRevision", qSORPart_Rev ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartSeq", qSORPart_Seq ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSORPartDesc", qSORPart_Desc ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPPPMPrjCode", BulkPPPMprjcode ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPrtClrInd", qSORPart_ClrInd ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPrtCat", qSORPart_Cat ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qBarrelCode", BulkPrjCode ) ) ;


		ifail = ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
		ifail = ( AOM_save ( tItemTag ) ) ;

		ifail = ( ITEM_ask_latest_rev ( tItemTag, &latestqSorrev ) ) ;

		ifail = ( RES_checkout2 ( latestqSorrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;


		ifail = ( GRM_find_relation_type ( "T5_PartSorRel", &PrtRelationFind ) ) ;

		if (PrtRelationFind != NULLTAG)
		{
			printf("\nT5_PartSorRel PrtRelationFind found");

			if (Part_Tag != NULLTAG )
			{
				printf("\nPart_Tag found");
				ifail = ( GRM_create_relation ( Part_Tag, latestqSorrev, PrtRelationFind, NULLTAG, &PartSorRelTag ) ) ;
				ifail = ( GRM_save_relation ( PartSorRelTag ) ) ;
				ifail = ( AOM_refresh ( Part_Tag,0 ) );
				printf("\nqSOR [%s] and  part [%s] relation created successfully\n",qSOR_no, qSORPart_no );
			}

		}


	    /*int number_found;
	    tag_t* list_of_WSO_tags;
	    tag_t BulkTag;


	    WSO_search_criteria_t criteria;
	    ifail =(WSOM_clear_search_criteria(&criteria));
	    tc_strcpy(criteria.name, BulkPrtno);
	    ifail =(WSOM_search(criteria, &number_found, &list_of_WSO_tags));


	    if (number_found > 0)
	    {


	    	BulkTag = list_of_WSO_tags [0];
	    	ifail = ( GRM_find_relation_type ( "T5_Bulk_part_has_qSor", &BulkRelationFind ) ) ;

			if (BulkRelationFind != NULLTAG)
			{
				printf("\nT5_Bulk_part_has_qSor BulkRelationFind found");

				if (BulkTag !=NULLTAG)
				{

					printf("\nBulkTag found");

					ifail = ( GRM_create_relation ( BulkTag, latestqSorrev, BulkRelationFind, NULLTAG, &BulkSorRelTag ) ) ;//latest part revision and dad doc revision
					ifail = ( GRM_save_relation ( BulkSorRelTag ) ) ;
					ifail = ( AOM_refresh ( BulkTag,0 ) );
					printf("\nqSOR [%s] and  BulkSOR [%s] relation created successfully\n",qSOR_no, BulkPrtno );
				}
			}
	    }
	    else
	    {
	    	printf("\nObject not found");
	    }*/


		}


	}


	return ifail;


}

int tm_check_control_object ( char *syscd, char *subsyscd )
{

	int n_found = 0 ;
	int n_entries = 2 ;
	char    *qry_entries[] = {(char *)"SYSCD",(char *)"SUBSYSCD"};
	char    *qry_values[] = {(char *)syscd,(char *)subsyscd};
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;
	QRY_find2 ( "ControlObjQry", &query );
	QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
	return n_found ;
}


/*int qSOR_Create_function(char *BulkPrtno, char *PPPMprjcode, char *prjcode, tag_t Part_Tag, char *qSORPart_no, char *qSORPart_Rev, char *qSORPart_Seq, char *qSORPart_Desc, char *qSORPart_ClrInd, char *qSORPart_Cat)
{

	printf("\nINSIDE qSOR_Create_function ......");

	int ifail = ITK_ok;

	 char *qSOR_no = NULL;
	 qSOR_no = (char*)MEM_alloc(50*sizeof(char));

	tag_t latestqSorrev = NULLTAG;
	tag_t PrtRelationFind = NULLTAG;
	tag_t BulkRelationFind = NULLTAG;
	tag_t PartSorRelTag = NULLTAG;
	tag_t BulkSorRelTag = NULLTAG;


		tc_strcpy(qSOR_no,"qSOR_");
		tc_strcat(qSOR_no,qSORPart_no);
		tc_strcat(qSOR_no,"_");
		tc_strcat(qSOR_no,qSORPart_Rev);


		tag_t tItemTag = NULLTAG ;
		tag_t tRevTypeTag = NULLTAG ;
		tag_t tItemTypeTag = NULLTAG ;
		tag_t tItemCreateInputTag = NULLTAG ;
		tag_t tRevCreateInputTag  = NULLTAG ;

		printf("\nqSOR_Create_function BulkPrtno        : [%s]",BulkPrtno);
		printf("\nqSOR_Create_function PPPMprjcode      : [%s]",PPPMprjcode);
		printf("\nqSOR_Create_function prjcode          : [%s]",prjcode);
		printf("\nqSOR_Create_function qSORPart_Rev     : [%s]",qSORPart_Rev);
		printf("\nqSOR_Create_function qSORPart_Seq     : [%s]",qSORPart_Seq);
		printf("\nqSOR_Create_function qSORPart_Desc    : [%s]",qSORPart_Desc);
		printf("\nqSOR_Create_function qSORPart_ClrInd  : [%s]",qSORPart_ClrInd);
		printf("\nqSOR_Create_function qSORPart_Cat     : [%s]",qSORPart_Cat);



		ifail = ( TCTYPE_find_type ( "T5_quicksorRevision", "T5_quicksorRevision", &tRevTypeTag ) ) ;
		ifail = ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;

		ifail = ( TCTYPE_find_type ( "T5_quicksor", "T5_quicksor", &tItemTypeTag ) ) ;
		ifail = ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;



		ifail = ( AOM_set_value_string ( tItemCreateInputTag, "item_id", qSOR_no ) ) ;
		ifail = ( AOM_set_value_string ( tItemCreateInputTag, "object_name", qSOR_no ) ) ;
		ifail = ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;


		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartNumber", qSORPart_no ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartRevision", qSORPart_Rev ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartSeq", qSORPart_Seq ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSORPartDesc", qSORPart_Desc ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPPPMPrjCode", PPPMprjcode ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPrtClrInd", qSORPart_ClrInd ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPrtCat", qSORPart_Cat ) ) ;
		ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qBarrelCode", prjcode ) ) ;


		ifail = ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
		ifail = ( AOM_save ( tItemTag ) ) ;

		ifail = ( ITEM_ask_latest_rev ( tItemTag, &latestqSorrev ) ) ;

		ifail = ( GRM_find_relation_type ( "T5_PartSorRel", &PrtRelationFind ) ) ;

		if (PrtRelationFind != NULLTAG)
		{
			printf("\nT5_PartSorRel PrtRelationFind found");

			if (Part_Tag != NULLTAG )
			{
				printf("\nPart_Tag found");
				ifail = ( GRM_create_relation ( Part_Tag, latestqSorrev, PrtRelationFind, NULLTAG, &PartSorRelTag ) ) ;
				ifail = ( GRM_save_relation ( PartSorRelTag ) ) ;
				ifail = ( AOM_refresh ( Part_Tag,0 ) );
				printf("\nqSOR [%s] and  part [%s] relation created successfully\n",qSOR_no, qSORPart_no );
			}

		}


	    int number_found;
	    tag_t* list_of_WSO_tags;
	    tag_t BulkTag;


	    WSO_search_criteria_t criteria;
	    ifail =(WSOM_clear_search_criteria(&criteria));
	    tc_strcpy(criteria.name, BulkPrtno);
	    ifail =(WSOM_search(criteria, &number_found, &list_of_WSO_tags));


	    if (number_found > 0)
	    {


	    	BulkTag = list_of_WSO_tags [0];
	    	ifail = ( GRM_find_relation_type ( "T5_Bulk_part_has_qSor", &BulkRelationFind ) ) ;

			if (BulkRelationFind != NULLTAG)
			{
				printf("\nT5_Bulk_part_has_qSor BulkRelationFind found");

				if (BulkTag !=NULLTAG)
				{

					printf("\nBulkTag found");

					ifail = ( GRM_create_relation ( BulkTag, latestqSorrev, BulkRelationFind, NULLTAG, &BulkSorRelTag ) ) ;//latest part revision and dad doc revision
					ifail = ( GRM_save_relation ( BulkSorRelTag ) ) ;
					ifail = ( AOM_refresh ( BulkTag,0 ) );
					printf("\nqSOR [%s] and  BulkSOR [%s] relation created successfully\n",qSOR_no, BulkPrtno );
				}
			}
	    }
	    else
	    {
	    	printf("\nObject not found");
	    }

	    return ifail;

}
*/


int  T5_BulkSorImpl::createPostBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;

    // Call the parent Implementation
    ifail = super_createPostBase(  creInput );

     // In addition to the implementation in parent BusinessObject write
     // your specific Implementation

     //Add custom code here if needed.

     //use getters methods available on OperationInput/CreateInput to access the
     //values in CreateInput.
     //for example below code gets the SAPPartNumber set by the user during
     //the create CommercialItem Action on the create UI.

	std::string BulkPartno ;
	std::string PPPMprjcode ;
	std::string prjcode ;
	std::vector<std::string> obj_val;
	std::vector<int> lovnullist;

	bool isNull = false ;
	bool isNull1 = false ;

	int error_flag = 0;
	int i = 0;
	int j = 0;
	int PrtQuery_function_SOR_return = 0;
	int PrtQuery_function_return = 0;
	int PrtQuery_function_counter = 0;
	int PrtQuery_function_SOR_counter = 0;

	int n_found_bulkSOR = 0;




	char *ErrorMessage = NULL;
	char *PrtErrorMessage = NULL;
	char *infoMessage = NULL;
	char *Partno_Rev_Seq = NULL;
	char *BulkPrtno = NULL;
	char *BulkPPPMprjcode = NULL;
	char *BulkPrjCode = NULL;

	BulkPrtno = (char *)MEM_alloc(50 *sizeof(char));
	BulkPPPMprjcode = (char *)MEM_alloc(200 *sizeof(char));
	BulkPrjCode = (char *)MEM_alloc(50 *sizeof(char));
	ErrorMessage = (char *)MEM_alloc(300 *sizeof(char));
	PrtErrorMessage = (char *)MEM_alloc(300 *sizeof(char));
	infoMessage = (char *)MEM_alloc(50 *sizeof(char));


	tag_t Part_Tag = NULLTAG;;




	tc_strcpy(ErrorMessage,"");
	tc_strcpy(infoMessage,"");

	char *BulkSORcheck = NULL;
	char *BulkSORstatus = NULL;
	BulkSORcheck = (char *)MEM_alloc(50 *sizeof(char));
	BulkSORstatus = (char *)MEM_alloc(50 *sizeof(char));

	tc_strcpy(BulkSORcheck,"BulkSOR");
	tc_strcpy(BulkSORstatus,"ON");



	n_found_bulkSOR = tm_check_control_object ( BulkSORcheck, BulkSORstatus );


	if (n_found_bulkSOR > 0)
	{

		printf("\nControl Object found");

		creInput->getString("object_name",BulkPartno,isNull); //Bulk SOR number
		printf("\nBulk Part no : [%s]",BulkPartno.c_str());

		 strcpy(BulkPrtno,BulkPartno.c_str());

		creInput->getStringArray("t5_SOR_Part_Numbers", obj_val, lovnullist );//SOR part number list
		std::cout << "\nno of parts are : " << lovnullist.size() << std::endl;

		creInput->getString("t5_BulkPPPMPrjCode", PPPMprjcode, isNull1 );//Bulk SOR PPPM Project code
		printf("\nPPPM Prj Code : [%s]",PPPMprjcode.c_str());

		strcpy(BulkPPPMprjcode,PPPMprjcode.c_str());

		creInput->getString("t5_BulkPrjCode", prjcode, isNull1 );//Bulk SOR Project code
		printf("\n Prj Code : [%s]",prjcode.c_str());

		strcpy(BulkPrjCode,prjcode.c_str());


		printf("\nBulkPartno : [%s], BulkPPPMprjcode : [%s], BulkPrjCode : [%s]",BulkPrtno,BulkPPPMprjcode,BulkPrjCode);



		 if(lovnullist.size()==0)
		 {
		     error_flag++;
		     tc_strcat(ErrorMessage,"Selet SOR Part numbers");//Error message
		 }

		 else if(isNull1 == true)
		 {
			 error_flag++;
			 tc_strcat(ErrorMessage,"Select PPPM Project code");//Error message
		 }

		 if(error_flag>0)
		 {

		         EMH_clear_errors();
		         EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);//Error message
		         return(PLM_error1);
		 }
		 else
		 {
			//loop for Quering Part in TCUA
			 for (i = 0 ; i < lovnullist.size(); i++)
			 {

				 printf("\n[%d] SOR Part number from the list  : [%s]",i, obj_val[i].c_str()); //SOR part number

				 Partno_Rev_Seq = (char*)MEM_alloc(50*sizeof(char));

				 strcpy(Partno_Rev_Seq,obj_val[i].c_str());//copying qSOR part number from list
				 printf("\n[%d] Partno_Rev_Seq : [%s]",i,Partno_Rev_Seq);

					char *partno = NULL;
					char *Rev = NULL;
					char *Seq = NULL;
					partno = strtok(Partno_Rev_Seq,",");
					Rev = strtok(NULL,",");
					Seq = strtok(NULL,",");

				 PrtQuery_function_return = PrtQuery_function(partno,Rev,Seq);//Query function for qSOR part number

				 if (PrtQuery_function_return > 0)
				 {
					 PrtQuery_function_counter ++;
					 tc_strcat(PrtErrorMessage,Partno_Rev_Seq);
					 tc_strcat(PrtErrorMessage,",");

				 }

				 MEM_free(Partno_Rev_Seq);
			 }

			 if( PrtQuery_function_counter > 0 )
			 {
				 EMH_clear_errors();
		         EMH_store_error_s2(EMH_severity_error,PLM_error1,"Parts Not found in TCUA : ",PrtErrorMessage);//Error message
		         return(PLM_error1);
			 }

			 //End loop for Quering Part in TCUA


			 //loop for Quering Part with SOR in TCUA
			 for (j = 0 ; j < lovnullist.size(); j++)
			 {

				 printf("\n[%d] SOR Part number from the list  : [%s]",j, obj_val[j].c_str()); //SOR part number

				 Partno_Rev_Seq = (char*)MEM_alloc(50*sizeof(char));

				 strcpy(Partno_Rev_Seq,obj_val[j].c_str());//copying qSOR part number from list
				 printf("\n[%d] Partno_Rev_Seq : [%s]",j,Partno_Rev_Seq);

				// RevSeq = (char *)MEM_alloc(5*sizeof(char));
				 char *partno = NULL;
				 char *Rev = NULL;
				 char *Seq = NULL;
				 partno = strtok(Partno_Rev_Seq,",");
				 Rev = strtok(NULL,",");
				 Seq = strtok(NULL,",");

				 PrtQuery_function_SOR_return = PrtQuery_function_SOR(partno,Rev,Seq);//Query function for qSOR part number

				 if (PrtQuery_function_SOR_return > 0)
				 {
					 PrtQuery_function_SOR_counter ++;
					 tc_strcat(infoMessage,Partno_Rev_Seq);
					 tc_strcat(infoMessage,",");
					 continue;

				 }

				char *qSORPart_no = NULL;
				char *qSORPart_RevSeq = NULL;
				char *qSORPart_Desc = NULL;
				char *qSORPart_ClrInd = NULL;
				char *qSORPart_Cat = NULL;
				char *qSORPart_Rev = NULL;
				char *qSORPart_Seq = NULL;

				 //Get_Part_Details (Part_Tag,partno,Rev,Seq,qSORPart_no,qSORPart_RevSeq,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);
				 Get_Part_Details (Part_Tag,BulkPrtno,BulkPPPMprjcode,BulkPrjCode,partno,Rev,Seq,qSORPart_no,qSORPart_RevSeq,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);

				// printf("\npartno :[%s], Rev : [%s], Seq : [%s], qSORPart_no : [%s], qSORPart_RevSeq : [%s], qSORPart_Rev : [%s], qSORPart_Seq : [%s], qSORPart_Desc : [%s], qSORPart_ClrInd : [%s], qSORPart_Cat : [%s]",partno,Rev,Seq,qSORPart_no,qSORPart_RevSeq,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);


				 MEM_free(Partno_Rev_Seq);
			 }

			 if( PrtQuery_function_SOR_counter > 0 )
			 {
				 EMH_clear_errors();
		         EMH_store_error_s2(EMH_severity_information,ITK_err,"SOR is Already Exist for parts : ",infoMessage);
		         return(PLM_error1);
			 }

			 //End loop for Quering Part with SOR in TCUA

		 }
	}



     //Implement custom code to meet the Business Requirement


     //Add custom code here if needed.
     /*
     Custom code
     */
     // Call the super createPost to invoke parent implementation
    // ifail = T5_BulkSorImpl::super_createPostBase(pCreateInput);



    // Your Implementation

    return ifail;
}

