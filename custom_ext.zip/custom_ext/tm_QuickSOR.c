///home/uadev/devgroups/dbk/custom_exit_dbk/QuickSOR
//Header files
//#include <stdio.h>
//#include <tccore/custom.h>
//#include <tcinit/tcinit.h>
//#include <epm/epm.h>
#include <tccore/aom_prop.h>
//#include <tccore/aom.h>
//#include <res/reservation.h>
//#include <tccore/tctype.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ae/dataset.h>
//#include <tccore/grm_msg.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tccore/grm.h>
#include <tc/preferences.h>
//#include <sa/tcfile.h>
//#include <unistd.h>
//#include <tcdefs.h>

#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset_msg.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/grm_msg.h>
#include <Fnd0Participant/participant.h>
#include <time.h>

#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//dll syntax in Viual studio
//#define DLLAPI __declspec(dllexport)

#define PLM_error (EMH_USER_error_base + 100)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error(char* file, int line, char* function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails); fflush(stdout);
		for (index = 0; index < n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]); fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line); fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

//Declaring functions
int SOR_checkin_PreCond_Validation(METHOD_message_t* msg, va_list args);
int tm_QuickSOR_CUST_register_method(int* decision, va_list args);
int tm_fctn_tm_QuickSOR_action_handler(EPM_action_message_t msg);
int SOR_checkin_method_post(METHOD_message_t* msg, va_list args);
//int SOR_save_method_preact(METHOD_message_t* msg, va_list args);
//int SOR_save_PreCond_Validation(METHOD_message_t* msg, va_list args);
int removeAllReleaseStatus(tag_t objTag);

char* time_stamp()
{

	char *timestamp = (char *)malloc(sizeof(char) * 30);
	time_t ltime;
	ltime=time(NULL);
	struct tm *tm_now;
	tm_now=localtime(&ltime);
	sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now->tm_year+1900, tm_now->tm_mon, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	//sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now.tm_year+1900, tm_now.tm_mon, tm_now.tm_mday, tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
	return timestamp;
}

int tm_check_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	return n_found ;
}

int removeAllReleaseStatus(tag_t objTag)
{

	int status_count;
	tag_t* status_list;
	tag_t		tReleaseStatusList = NULLTAG;
	int			n_values = 0;
	int			cunt1 = 0;
	tag_t* attr_tags = NULLTAG;
	logical* is_it_null = NULL;
	logical* is_it_empty = NULL;
	tag_t		class_id = NULLTAG;
	char* class_name = NULL;
	logical		log1;


	printf("\ninside t5removeAllReleaseStatus : Removing all the release status"); fflush(stdout);
	TC_write_syslog("\ninside t5removeAllReleaseStatus : Removing all the release status"); fflush(stdout);

	ITK_CALL(WSOM_ask_release_status_list(objTag, &status_count, &status_list));

	printf("\n no of Status==%d\n", status_count);; fflush(stdout);
	if (status_count > 0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove..."); fflush(stdout);

		ITK_CALL(POM_class_of_instance(objTag, &class_id));
		ITK_CALL(POM_name_of_class(class_id, &class_name));
		printf("\n class_name is :%s\n", class_name); fflush(stdout);

		ITK_CALL(POM_attr_id_of_attr("release_status_list", class_name, &tReleaseStatusList)); fflush(stdout);

		ITK_CALL(POM_unload_instances(1, &objTag));
		ITK_CALL(POM_load_instances(1, &objTag, class_id, 1));
		ITK_CALL(POM_is_loaded(objTag, &log1));
		if (log1 == 1)
		{
			printf(" Load Success\n ");
		}
		else
			printf("Load Failure\n");

		ITK_CALL(POM_length_of_attr(objTag, tReleaseStatusList, &n_values));
		printf("\n n_values is :%d\n", n_values); fflush(stdout);
		if (n_values > 0)
		{
			ITK_CALL(POM_ask_attr_tags(objTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty));
			printf("\n n_values11 is :%d\n", n_values); fflush(stdout);

			for (cunt1 = 0; cunt1 < n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n", cunt1); fflush(stdout);


				ITK_CALL(POM_remove_from_attr(1, &objTag, tReleaseStatusList, 0, 1));
				printf("\n cunt1 == 0 removedd is :%d\n", cunt1); fflush(stdout);


				ITK_CALL(POM_save_instances(1, &objTag, 1));

				ITK_CALL(POM_refresh_instances(1, &objTag, class_id, 2));

				ITK_CALL(AOM_lock(objTag));

				ITK_CALL(AOM_save_without_extensions(objTag));//Replace AOM_SAVE
				ITK_CALL(AOM_refresh(objTag, 1));

			}

			ITK_CALL(AOM_unlock(objTag));
		}
		printf("\n Status removed");; fflush(stdout);
	}
	return (0);
}


int SOR_checkin_method_post(METHOD_message_t* msg, va_list args)
{

	tag_t Primary_Obj = va_arg(args, tag_t);
	tag_t Primary_Obj_Type = NULLTAG;
	char* Primary_Obj_name = NULL;
	tag_t rel_status_SOR = NULLTAG;
	logical retain_released_date_SOR = TRUE;
	char* sor_qSORnumber = NULL;

	ITK_CALL(TCTYPE_ask_object_type(Primary_Obj, &Primary_Obj_Type));
	ITK_CALL(TCTYPE_ask_name2(Primary_Obj_Type, &Primary_Obj_name));

	printf("\nSOR_checkin_method_post Primary_Obj_name:  [%s]\n", Primary_Obj_name); fflush(stdout);
	TC_write_syslog("\nSOR_checkin_method_post Primary_Obj_name :  [%s]\n", Primary_Obj_name); fflush(stdout);

	if (tc_strcmp(Primary_Obj_name, "T5_quicksorRevision") == 0)
	{

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "item_id", &sor_qSORnumber));
		printf("\nSOR_checkin_method_post sor_qSORnumber : [%s]", sor_qSORnumber);
		TC_write_syslog("\nSOR_checkin_method_post sor_qSORnumber : [%s]", sor_qSORnumber);

		removeAllReleaseStatus(Primary_Obj);
		printf("\nGoing to ERC Review  on SOR...."); fflush(stdout);
		ITK_CALL(RELSTAT_create_release_status("T5_LcsReview", &rel_status_SOR));
		ITK_CALL(RELSTAT_add_release_status(rel_status_SOR, 1, &Primary_Obj, retain_released_date_SOR));
		printf("\nERC Review stamping on SOR...."); fflush(stdout);
		TC_write_syslog("\nERC Review stamping on SOR...."); fflush(stdout);
	}


	return (ITK_ok);

}


int CompareDatasetfile(tag_t Primary_Obj, char* sor_qSorPartNumber,char *sor_qSorPartRevision,char *sor_qSorPartSeq, char* Error_MessageDataset)
{

	tag_t rel_type = NULLTAG;
	tag_t pdfdataset_tag = NULLTAG;
	tag_t* pdfdataset = NULLTAG;

	int pdfcount = 0;
	int ipdf = 0;

	int flag = 0;

	int intpdfdataset_type = 0;
	int counter = 0;
	int countername = 0;
	int counterdatasetname = 0;
	int DVP_pdfcnt = 0;
	int RFQ_pdfcnt = 0;


	char* pdfdataset_type = NULL;
	char* pdfdataset_name = NULL;
	char* pdfdatasetnames = NULL;
	pdfdatasetnames = (char*)MEM_alloc(50 * sizeof(char));

	tc_strcpy(pdfdatasetnames, "");



	char* RFQ_pdfdataset_name = NULL;
	char* DVP_pdfdataset_name = NULL;

	RFQ_pdfdataset_name = (char*)MEM_alloc(50 * sizeof(char));
	DVP_pdfdataset_name = (char*)MEM_alloc(50 * sizeof(char));

	tc_strcpy(RFQ_pdfdataset_name, "RFQ_");
	tc_strcat(RFQ_pdfdataset_name, sor_qSorPartNumber);
	tc_strcat(RFQ_pdfdataset_name, "_");
	tc_strcat(RFQ_pdfdataset_name, sor_qSorPartRevision);
	tc_strcat(RFQ_pdfdataset_name, "_");
	tc_strcat(RFQ_pdfdataset_name, sor_qSorPartSeq);

	tc_strcpy(DVP_pdfdataset_name, "DVP_");
	tc_strcat(DVP_pdfdataset_name, sor_qSorPartNumber);
	tc_strcat(DVP_pdfdataset_name, "_");
	tc_strcat(DVP_pdfdataset_name, sor_qSorPartRevision);
	tc_strcat(DVP_pdfdataset_name, "_");
	tc_strcat(DVP_pdfdataset_name, sor_qSorPartSeq);

	ITK_CALL(GRM_find_relation_type("IMAN_specification", &rel_type));
	ITK_CALL(GRM_list_secondary_objects_only(Primary_Obj, rel_type, &pdfcount, &pdfdataset));

	printf("\nSOR_checkin_PreCond_Validation pdfcount : [%d]", pdfcount); fflush(stdout);
	TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfcount : [%d]", pdfcount);

	//if (pdfcount > 0)
	if (pdfcount == 2)
	{
		int int_CompareDVP_RFQ = 0;
		for (ipdf = 0; ipdf < 2; ipdf++)
		{

			pdfdataset_tag = pdfdataset[ipdf];
			ITK_CALL(AOM_ask_value_string(pdfdataset_tag, "object_type", &pdfdataset_type));
			printf("\nSOR_checkin_PreCond_Validation pdfdataset_type : [%s]", pdfdataset_type);
			TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdataset_type : [%s]", pdfdataset_type);


			if (tc_strcmp(pdfdataset_type, "PDF") == 0)
			{

				ITK_CALL(AOM_ask_value_string(pdfdataset_tag, "object_name", &pdfdataset_name));
				printf("\nSOR_checkin_PreCond_Validation pdfdataset_name : [%s]", pdfdataset_name);
				TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdataset_name : [%s]", pdfdataset_name);

				//int_CompareDVP_RFQ = CompareDVP_RFQ(pdfdataset_name, sor_qSORnumber);

				tc_strcat(pdfdatasetnames, pdfdataset_name);
				tc_strcat(pdfdatasetnames, ",");

				//printf("\nSOR_checkin_PreCond_Validation int_CompareDVP_RFQ : [%d]", int_CompareDVP_RFQ);
				//TC_write_syslog("\nSOR_checkin_PreCond_Validation int_CompareDVP_RFQ : [%d]", int_CompareDVP_RFQ);

				printf("\nSOR_checkin_PreCond_Validation pdfdatasetnames : [%s]", pdfdatasetnames);
				TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdatasetnames : [%s]", pdfdatasetnames);

			}
			else
			{

				intpdfdataset_type++;

			}



		}

		printf("\nSOR_checkin_PreCond_Validation pdfdatasetnames : [%s]", pdfdatasetnames);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdatasetnames : [%s]", pdfdatasetnames);



		if (intpdfdataset_type > 0)
		{
			printf("\nOnly PDF Datasets are allowed to attached in specification relation in format %s and %s", RFQ_pdfdataset_name, DVP_pdfdataset_name);
			sprintf(Error_MessageDataset, "Only PDF Datasets are allowed to attached in specification relation in format %s and %s", RFQ_pdfdataset_name, DVP_pdfdataset_name);
			flag = 1;
			return flag;

		}


		if (tc_strstr(pdfdatasetnames, RFQ_pdfdataset_name) == NULL && tc_strstr(pdfdatasetnames, DVP_pdfdataset_name) == NULL)
		{

			printf("\nPlease attach %s and %s dataset in specification relation", RFQ_pdfdataset_name, DVP_pdfdataset_name);
			sprintf(Error_MessageDataset, "Please attach %s and %s dataset in specification relation", RFQ_pdfdataset_name, DVP_pdfdataset_name);
			flag = 2;
			return flag;

		}

		if (tc_strstr(pdfdatasetnames, RFQ_pdfdataset_name) == NULL && tc_strstr(pdfdatasetnames, DVP_pdfdataset_name) != NULL)
		{

			printf("\nPlease attach %s dataset in specification relation", RFQ_pdfdataset_name);
			sprintf(Error_MessageDataset, "Please attach %s dataset in specification relation", RFQ_pdfdataset_name);
			flag = 3;
			return flag;

		}

		if (tc_strstr(pdfdatasetnames, RFQ_pdfdataset_name) != NULL && tc_strstr(pdfdatasetnames, DVP_pdfdataset_name) == NULL)
		{

			printf("\nPlease attach %s dataset in specification relation", DVP_pdfdataset_name);
			sprintf(Error_MessageDataset, "Please attach %s dataset in specification relation", DVP_pdfdataset_name);
			flag = 4;
			return flag;

		}



	}

	else if (pdfcount > 2)
	{
		printf("\nOnly 2 PDF datasets are allowed to attach in specification relation");
		sprintf(Error_MessageDataset, "Only 2 PDF datasets are allowed to attach in specification relation");
		flag = 5;
		return flag;
	}
	else
	{
		printf("\nfor CAT 1, CAT 2, CAT 3 - Please attach RFQ and DVP PDF datasets in format %s , %s", RFQ_pdfdataset_name, DVP_pdfdataset_name);
		sprintf(Error_MessageDataset, "\nfor CAT 1, CAT 2, CAT 3 - Please attach RFQ and DVP PDF datasets in format %s , %s", RFQ_pdfdataset_name, DVP_pdfdataset_name);
		flag = 6;
		return flag;
	}


	return flag;
}

int CompareNamedReffile(tag_t Primary_Obj, char* sor_qSorPartNumber,char *sor_qSorPartRevision,char *sor_qSorPartSeq, char* Error_Message)
{

	tag_t rel_type = NULLTAG;
	tag_t pdfdataset_tag = NULLTAG;
	tag_t* pdfdataset = NULLTAG;

	int pdfcount = 0;
	int ipdf = 0;

	int flag = 0;

	int intpdfdataset_type = 0;
	int counter = 0;
	int countername = 0;
	int counterdatasetname = 0;
	int DVP_pdfcnt = 0;
	int RFQ_pdfcnt = 0;

	//char   orig_name[IMF_filename_size_c + 1];
	char* orig_name = NULL;
	char* pdfdataset_type = NULL;
	char* pdfdataset_name = NULL;
	char* pdfdatasetnamedrefname = NULL;
	char* pdfdatasetnamedrefnameRFQ = NULL;
	char* pdfdatasetnamedrefnameDVP = NULL;
	char* pdfdatasetnamedrefnamefile = NULL;
	char* pdfdatasetreffilename = NULL;
	char* pdfdatasetreffilename1 = NULL;
	char* RFQ_pdfdataset_namedRefPDF = NULL;
	char* DVP_pdfdataset_namedRefPDF = NULL;
	pdfdatasetnamedrefnamefile = (char*)MEM_alloc(50 * sizeof(char));
	pdfdatasetnamedrefname = (char*)MEM_alloc(50 * sizeof(char));
	pdfdatasetnamedrefnameRFQ = (char*)MEM_alloc(50 * sizeof(char));
	pdfdatasetnamedrefnameDVP = (char*)MEM_alloc(50 * sizeof(char));
	pdfdatasetreffilename = (char*)MEM_alloc(50 * sizeof(char));
	pdfdatasetreffilename1 = (char*)MEM_alloc(50 * sizeof(char));
	RFQ_pdfdataset_namedRefPDF = (char*)MEM_alloc(100 * sizeof(char));
	DVP_pdfdataset_namedRefPDF = (char*)MEM_alloc(100 * sizeof(char));

	tc_strcpy(pdfdatasetnamedrefnameRFQ, "");
	tc_strcpy(pdfdatasetnamedrefnameDVP, "");
	tc_strcpy(pdfdatasetnamedrefname, "");
	tc_strcpy(pdfdatasetnamedrefnamefile, "");
	tc_strcpy(pdfdatasetreffilename, "");
	tc_strcpy(pdfdatasetreffilename1, "");




	char* RFQ_pdfdataset_namedRef = NULL;
	char* DVP_pdfdataset_namedRef = NULL;

	RFQ_pdfdataset_namedRef = (char*)MEM_alloc(50 * sizeof(char));
	DVP_pdfdataset_namedRef = (char*)MEM_alloc(50 * sizeof(char));

	tc_strcpy(RFQ_pdfdataset_namedRef, "RFQ_");
	tc_strcat(RFQ_pdfdataset_namedRef, sor_qSorPartNumber);
	tc_strcat(RFQ_pdfdataset_namedRef, "_");
	tc_strcat(RFQ_pdfdataset_namedRef, sor_qSorPartRevision);
	tc_strcat(RFQ_pdfdataset_namedRef, "_");
	tc_strcat(RFQ_pdfdataset_namedRef, sor_qSorPartSeq);

	tc_strcpy(DVP_pdfdataset_namedRef, "DVP_");
	tc_strcat(DVP_pdfdataset_namedRef, sor_qSorPartNumber);
	tc_strcat(DVP_pdfdataset_namedRef, "_");
	tc_strcat(DVP_pdfdataset_namedRef, sor_qSorPartRevision);
	tc_strcat(DVP_pdfdataset_namedRef, "_");
	tc_strcat(DVP_pdfdataset_namedRef, sor_qSorPartSeq);

	ITK_CALL(GRM_find_relation_type("IMAN_specification", &rel_type));
	ITK_CALL(GRM_list_secondary_objects_only(Primary_Obj, rel_type, &pdfcount, &pdfdataset));

	printf("\nSOR_checkin_PreCond_Validation pdfcount : [%d]", pdfcount); fflush(stdout);
	TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfcount : [%d]", pdfcount);

	//if (pdfcount > 0)
	if (pdfcount == 2)
	{

		for (ipdf = 0; ipdf < 2; ipdf++)
		{

			pdfdataset_tag = pdfdataset[ipdf];
			ITK_CALL(AOM_ask_value_string(pdfdataset_tag, "object_type", &pdfdataset_type));
			printf("\nSOR_checkin_PreCond_Validation pdfdataset_type : [%s]", pdfdataset_type);
			TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdataset_type : [%s]", pdfdataset_type);


			if (tc_strcmp(pdfdataset_type, "PDF") == 0)
			{

				ITK_CALL(AOM_ask_value_string(pdfdataset_tag, "object_name", &pdfdataset_name));
				printf("\nSOR_checkin_PreCond_Validation pdfdataset_name : [%s]", pdfdataset_name);
				TC_write_syslog("\nSOR_checkin_PreCond_Validation pdfdataset_name : [%s]", pdfdataset_name);

				int referencenumberfound = 0;
				int ref_c = 0;
				//char refname[AE_reference_size_c + 1];
				char* refname = NULL;
				tag_t refobject = NULLTAG;
				AE_reference_type_t reftype;
				


				ITK_CALL(AE_ask_dataset_ref_count(pdfdataset_tag, &referencenumberfound));

				printf("\nSOR_checkin_PreCond_Validation referencenumberfound : [%d]\n", referencenumberfound); fflush(stdout);

				if (referencenumberfound == 1)
				{

					ITK_CALL(AE_find_dataset_named_ref2(pdfdataset_tag, 0, &refname, &reftype, &refobject));
					printf("\nSOR_checkin_PreCond_Validation refname : [%s]\n", refname); fflush(stdout);
					ITK_CALL(IMF_ask_original_file_name2(refobject, &orig_name));



					printf("\nSOR_checkin_PreCond_Validation orig_name : [%s]\n", orig_name); fflush(stdout);
					printf("\nSOR_checkin_PreCond_Validation pdfdataset_name : [%s]\n", pdfdataset_name); fflush(stdout);
					printf("\nSOR_checkin_PreCond_Validation RFQ_pdfdataset_namedRef : [%s]\n", RFQ_pdfdataset_namedRef); fflush(stdout);
					printf("\nSOR_checkin_PreCond_Validation DVP_pdfdataset_namedRef : [%s]\n", DVP_pdfdataset_namedRef); fflush(stdout);

					if (tc_strstr(orig_name, "RFQ") != NULL && tc_strcmp(pdfdataset_name, RFQ_pdfdataset_namedRef) == 0)
					{
						printf("inside..................RFQ");

						tc_strcpy(RFQ_pdfdataset_namedRefPDF, "");
						tc_strcat(RFQ_pdfdataset_namedRefPDF, RFQ_pdfdataset_namedRef);
						tc_strcat(RFQ_pdfdataset_namedRefPDF, ".pdf");

						printf("\nRFQ_pdfdataset_namedRef : [%s]\n", RFQ_pdfdataset_namedRef); fflush(stdout);

						if (tc_strcmp(RFQ_pdfdataset_namedRefPDF, orig_name) != 0)
						{
							printf("\nNamed reference file name is [%s] it should be in format [%s]", orig_name, RFQ_pdfdataset_namedRefPDF);
							tc_strcat(pdfdatasetnamedrefnameRFQ, orig_name);
							tc_strcat(pdfdatasetnamedrefnameRFQ, ",");
						}


					}
					else if (tc_strstr(orig_name, "DVP") != NULL && tc_strcmp(pdfdataset_name, DVP_pdfdataset_namedRef) == 0)
					{
						printf("inside..................DVP");
						tc_strcpy(DVP_pdfdataset_namedRefPDF, "");
						tc_strcat(DVP_pdfdataset_namedRefPDF,DVP_pdfdataset_namedRef);
						tc_strcat(DVP_pdfdataset_namedRefPDF, ".pdf");
						printf("\nDVP_pdfdataset_namedRef : [%s]\n", DVP_pdfdataset_namedRef); fflush(stdout);
						if (tc_strcmp(DVP_pdfdataset_namedRefPDF, orig_name) != 0)
						{
							printf("\nNamed reference file name is [%s] it should be in format [%s]", orig_name, DVP_pdfdataset_namedRefPDF);
							tc_strcat(pdfdatasetnamedrefnameDVP, orig_name);
							tc_strcat(pdfdatasetnamedrefnameDVP, ",");
						}


					}
					else
					{
						printf("\nNamed reference file name is incorrect for : [%s]\n", pdfdataset_name);
						tc_strcat(pdfdatasetnamedrefnamefile, pdfdataset_name);
						tc_strcat(pdfdatasetnamedrefnamefile, ",");
						//printf("\nNamed reference file name is incorrect for : [%s]\n",pdfdatasetnamedrefnamefile);

					}



				}
				else if (referencenumberfound > 1)
				{
					printf("\nOnly 1 PDF is allowed to upload in Named Reference of [%s]", pdfdataset_name);
					tc_strcat(pdfdatasetreffilename, pdfdataset_name);
					tc_strcat(pdfdatasetreffilename, ",");

				}
				else
				{
					printf("\nNo PDF in Named Reference [%s]", pdfdataset_name);
					tc_strcat(pdfdatasetreffilename1, pdfdataset_name);
					tc_strcat(pdfdatasetreffilename1, ",");

				}

			}



		}
	}

	if (tc_strlen(pdfdatasetreffilename1) > 0)
	{
		sprintf(Error_Message, "No PDF in Named Reference [%s]", pdfdatasetreffilename1);
		printf("\nNo PDF in Named Reference [%s]", pdfdatasetreffilename1);
		flag = 1;
		return flag;

	}


	if (tc_strlen(pdfdatasetreffilename) > 0)
	{
		sprintf(Error_Message, "Only 1 PDF is allowed to upload in Named Reference of [%s]", pdfdatasetreffilename);
		printf("\nOnly 1 PDF is allowed to upload in Named Reference of [%s]", pdfdatasetreffilename);
		flag = 2;
		return flag;

	}

	if (tc_strlen(pdfdatasetnamedrefnamefile) > 0)
	{
		sprintf(Error_Message, "Named reference file name is incorrect for : [%s]", pdfdatasetnamedrefnamefile);
		printf("\nNamed reference file name is incorrect for : [%s]\n", pdfdatasetnamedrefnamefile);
		flag = 3;
		return flag;

	}

	if (tc_strlen(pdfdatasetnamedrefnameRFQ) > 0 && tc_strlen(pdfdatasetnamedrefnameDVP) > 0)
	{
		sprintf(Error_Message, "Please upload Named reference file in format - [%s,%s]", RFQ_pdfdataset_namedRef, DVP_pdfdataset_namedRef);
		printf("\nPlease upload Named reference file in format - [%s,%s]", RFQ_pdfdataset_namedRef, DVP_pdfdataset_namedRef);
		flag = 4;
		return flag;

	}

	if (tc_strlen(pdfdatasetnamedrefnameRFQ) > 0)
	{
		sprintf(Error_Message, "Please upload Named reference file in format - [%s]", RFQ_pdfdataset_namedRef);
		printf("\nPlease upload Named reference file in format - [%s]\n", RFQ_pdfdataset_namedRef);
		flag = 5;
		return flag;

	}

	if (tc_strlen(pdfdatasetnamedrefnameDVP) > 0)
	{
		sprintf(Error_Message, "Please upload Named reference file in format - [%s]", DVP_pdfdataset_namedRef);
		printf("\nPlease upload Named reference file in format - [%s]\n", DVP_pdfdataset_namedRef);
		flag = 6;
		return flag;

	}

	return flag;
}

int SOR_checkin_PreCond_Validation(METHOD_message_t* msg, va_list args)
{

	tag_t Primary_Obj = va_arg(args, tag_t);
	tag_t Primary_Obj_Type = NULLTAG;
	tag_t* table_rows = NULLTAG;


	int ntablerows = 0;
	int i = 0;
	int int_CompareDatasetfile = 0;
	int int_CompareNamedReffile = 0;


	char* Primary_Obj_name = NULL;
	char* qCtrlCommodity = NULL;
	char* qsorPMXU = NULL;
	char* ReferencePartno = NULL;
	char* sor_qBarrelCode = NULL;
	char* sor_qSORnumber = NULL;
	char* sor_qSORPartDesc = NULL;
	char* sor_qSorCat = NULL;
	char* sor_qSorPrtClrInd = NULL;
	char* sor_qSorPartNumber = NULL;
	char* sor_qSorPartRevision = NULL;
	char* sor_qSorPartSeq = NULL;
	char* sor_qPPPMPrjCode = NULL;
	char* st5_qQuantity = NULL;
	char* sor_qSORRequired = NULL;


	ITK_CALL(TCTYPE_ask_object_type(Primary_Obj, &Primary_Obj_Type));
	ITK_CALL(TCTYPE_ask_name2(Primary_Obj_Type, &Primary_Obj_name));

	printf("\nSOR_checkin_PreCond_Validation Primary_Obj_name:  [%s]\n", Primary_Obj_name); fflush(stdout);
	TC_write_syslog("\nSOR_checkin_PreCond_Validation Primary_Obj_name :  [%s]\n", Primary_Obj_name); fflush(stdout);

	if (tc_strcmp(Primary_Obj_name, "T5_quicksorRevision") == 0)
	{
		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSORRequired", &sor_qSORRequired));
        printf("\nSOR_checkin_PreCond_Validation sor_qSORRequired : [%s]", sor_qSORRequired);
        TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSORRequired : [%s]", sor_qSORRequired);	
	
		if (tc_strcmp(sor_qSORRequired, "Y") == 0 || tc_strcmp(sor_qSORRequired, "") == 0)
	 {
		ITK_CALL(AOM_ask_value_string(Primary_Obj, "item_id", &sor_qSORnumber));
		printf("\nSOR_checkin_PreCond_Validation sor_qSORnumber : [%s]", sor_qSORnumber);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSORnumber : [%s]", sor_qSORnumber);

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSORPartDesc", &sor_qSORPartDesc));
		printf("\nSOR_checkin_PreCond_Validation sor_qSORPartDesc : [%s]", sor_qSORPartDesc);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSORPartDesc : [%s]", sor_qSORPartDesc);

		if (tc_strcmp(sor_qSORPartDesc, "") == 0 || tc_strlen(sor_qSORPartDesc) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill SOR Part Desc before checkin");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qCtrlSorCat", &sor_qSorCat));
		printf("\nSOR_checkin_PreCond_Validation sor_qSorCat : [%s]", sor_qSorCat);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSorCat : [%s]", sor_qSorCat);

		if (tc_strcmp(sor_qSorCat, "") == 0 || tc_strlen(sor_qSorCat) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "select valid SOR Category from dropdown list");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSorPrtClrInd", &sor_qSorPrtClrInd));
		printf("\nSOR_checkin_PreCond_Validation sor_qSorPrtClrInd : [%s]", sor_qSorPrtClrInd);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSorPrtClrInd : [%s]", sor_qSorPrtClrInd);

		if (tc_strcmp(sor_qSorPrtClrInd, "") == 0 || tc_strlen(sor_qSorPrtClrInd) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill SOR Part Colour Indicator before checkin");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSorPartNumber", &sor_qSorPartNumber));
		printf("\nSOR_checkin_PreCond_Validation sor_qSorPartNumber : [%s]", sor_qSorPartNumber);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSorPartNumber : [%s]", sor_qSorPartNumber);

		if (tc_strcmp(sor_qSorPartNumber, "") == 0 || tc_strlen(sor_qSorPartNumber) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill SOR Part Number before checkin");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSorPartRevision", &sor_qSorPartRevision));
		printf("\nSOR_checkin_PreCond_Validation sor_qSorPartRevision : [%s]", sor_qSorPartRevision);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSorPartRevision : [%s]", sor_qSorPartRevision);

		if (tc_strcmp(sor_qSorPartRevision, "") == 0 || tc_strlen(sor_qSorPartRevision) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill SOR Part Number before checkin");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qSorPartSeq", &sor_qSorPartSeq));
		printf("\nSOR_checkin_PreCond_Validation sor_qSorPartSeq : [%s]", sor_qSorPartSeq);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qSorPartSeq : [%s]", sor_qSorPartSeq);

		if (tc_strcmp(sor_qSorPartSeq, "") == 0 || tc_strlen(sor_qSorPartSeq) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill SOR Part Revision before checkin");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qPPPMPrjCode", &sor_qPPPMPrjCode));
		printf("\nSOR_checkin_PreCond_Validation sor_qPPPMPrjCode : [%s]", sor_qPPPMPrjCode);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qPPPMPrjCode : [%s]", sor_qPPPMPrjCode);

		if (tc_strcmp(sor_qPPPMPrjCode, "") == 0 || tc_strlen(sor_qPPPMPrjCode) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "select valid PPPM project code from dropdown list");
			return PLM_error;
		}

		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qBarrelCode", &sor_qBarrelCode));
		printf("\nSOR_checkin_PreCond_Validation sor_qBarrelCode : [%s]", sor_qBarrelCode);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation sor_qBarrelCode : [%s]", sor_qBarrelCode);

		if (tc_strcmp(sor_qBarrelCode, "") == 0 || tc_strlen(sor_qBarrelCode) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "fill Project Code before checkin");
			return PLM_error;
		}
		//Added by shubham on 06-Jun-2025 checkin condition handled for commodity
		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qCtrlCommodity", &qCtrlCommodity));
		printf("\nSOR_checkin_PreCond_Validation t5_qCtrlCommodity : [%s]", qCtrlCommodity);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation qCtrlCommodity : [%s]", qCtrlCommodity);

		if (tc_strcmp(qCtrlCommodity, "") == 0 || tc_strlen(qCtrlCommodity) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "Fill SOR Commodity field before checkin");
			return PLM_error;
		}
		//Ended

		//Added by shubham on 07-July-2025 checkin condition handled for PMXU Field
		ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qsorPMXU", &qsorPMXU));
		printf("\nSOR_checkin_PreCond_Validation t5_qsorPMXU : [%s]", qsorPMXU);
		TC_write_syslog("\nSOR_checkin_PreCond_Validation qsorPMXU : [%s]", qsorPMXU);

		if (tc_strcmp(qsorPMXU, "") == 0 || tc_strlen(qsorPMXU) == 0)
		{
			EMH_store_error_s1(EMH_severity_error, PLM_error, "Fill SOR PMXU field before checkin");
			return PLM_error;
		}
		else
		{
			if (tc_strcmp(qsorPMXU, "P") == 0 || tc_strcmp(qsorPMXU, "M") == 0)
			{
				ITK_CALL(AOM_ask_value_string(Primary_Obj, "t5_qReferencePartnumber", &ReferencePartno));
				printf("\nSOR_checkin_PreCond_Validation t5_qReferencePartnumber : [%s]", ReferencePartno);
				TC_write_syslog("\nSOR_checkin_PreCond_Validation ReferencePartno : [%s]", ReferencePartno);
				
				if (tc_strcmp(ReferencePartno, "") == 0 || tc_strlen(ReferencePartno) == 0)
				{
					EMH_store_error_s1(EMH_severity_error, PLM_error, "Fill ReferencePartno field before checkin");
					return PLM_error;
				}
				
			}
		}
		//Ended

		//Added by shubham on 18-Jun-2025 checkin condition handled for Quantity
		//ITK_CALL ( AOM_ask_table_rows(Primary_Obj, "t5_qSORVar", &ntablerows, &table_rows) );
        //printf("\nSOR_checkin_PreCond_Validation sor_t5_variant : [%d]",ntablerows);fflush(stdout);
		//TC_write_syslog("\nsor_t5_variant  checkin : [%d]",ntablerows);
		//int varflagPv = 0;
        //for (i=0; i<ntablerows; i++)
		//{
		//	printf("\n********************************************************");fflush(stdout);
		//	ITK_CALL ( AOM_UIF_ask_value(table_rows[i],"t5_qQuantity",&st5_qQuantity));
		//	printf("\nt5_Quantity : [%s]",st5_qQuantity);fflush(stdout);
		//
		//	if (tc_strcmp(st5_qQuantity, "") == 0 || tc_strlen(st5_qQuantity) == 0)
		//	{
		//		 printf("\nst5_Quantity : [%s]",st5_qQuantity);fflush(stdout);
		//	     TC_write_syslog("\nst5_Quantity : [%s]",st5_qQuantity);
		//		 varflagPv++;
		//	}
		//	printf("\n ntablerows : [%d]",ntablerows);fflush(stdout);
		//	printf("\n varflagPv : [%d]",varflagPv);fflush(stdout);
		//	TC_write_syslog("\n ntablerows : [%d]",ntablerows);
		//	TC_write_syslog("\n varflagPv : [%d]",varflagPv);
		//
		//	if (varflagPv > 0)
		//	{
		//		EMH_store_error_s1(EMH_severity_error,PLM_error,"Fill the details of All Variant Quantity before checkin)");
		//		printf("\nFill the details of Variant 1\n"); fflush ( stdout) ;
		//		TC_write_syslog("\nFill the details of Variant 1\n");
		//		return PLM_error;
		//	}
		//}

		//Ended


		if (tc_strstr(sor_qSorCat, "CAT 1") != NULL || tc_strstr(sor_qSorCat, "CAT 2") != NULL || tc_strstr(sor_qSorCat, "CAT 3") != NULL)
		{


			char* Error_MessageDataset = NULL;

			Error_MessageDataset = (char*)MEM_alloc(200 * sizeof(char));

			int_CompareDatasetfile = CompareDatasetfile(Primary_Obj, sor_qSorPartNumber,sor_qSorPartRevision,sor_qSorPartSeq, Error_MessageDataset);

			printf("\nint_CompareDatasetfile : [%d]", int_CompareDatasetfile);

			printf("\nError_MessageDataset : [%s]", Error_MessageDataset);

			if (int_CompareDatasetfile > 0 && int_CompareDatasetfile <= 6)
			{
				EMH_store_error_s2(EMH_severity_error, PLM_error, "\nError Message - \n", Error_MessageDataset);
				return PLM_error;
			}

			char* Error_MessageNamedref = NULL;

			Error_MessageNamedref = (char*)MEM_alloc(200 * sizeof(char));

			int_CompareNamedReffile = CompareNamedReffile(Primary_Obj, sor_qSorPartNumber,sor_qSorPartRevision,sor_qSorPartSeq, Error_MessageNamedref);

			printf("\nint_CompareNamedReffile : [%d]", int_CompareNamedReffile);

			printf("\nError_MessageNamedref : [%s]", Error_MessageNamedref);

			if (int_CompareNamedReffile > 0 && int_CompareNamedReffile <= 6)
			{
				EMH_store_error_s2(EMH_severity_error, PLM_error, "\nError Message - \n", Error_MessageNamedref);
				return PLM_error;
			}



		}
		//Shubham Added check on 13March2025
		if (tc_strstr(sor_qSorCat, "CAT 4a") != NULL || tc_strstr(sor_qSorCat, "CAT 4b") != NULL || tc_strstr(sor_qSorCat, "CAT 5") != NULL || tc_strstr(sor_qSorCat, "CAT 6") != NULL)
		{
		
			tag_t grm_rel = NULLTAG;
		
			//tag_t Primary_Obj = NULLTAG;
		
			//tag_t* pdfdataset = NULLTAG;
		
			tag_t *grm_data = NULLTAG;
		
			int n_grm_count = 0;
		
			int i = 0;
		
			int n_found_DRW_IND = 0 ;
		
			char* pdfdataset_type = NULL;
		
			char* pdfdataset_name = NULL;
		
			char *Partno = NULL;
			
			char* syscd = NULL;
			char* subsyscd = NULL;

		
			char *PartDrawingInd = NULL;

			char *info2 = NULL;
			int n_found = 0;
			int n_entries = 2;
			char* qry_entries[2] = { "SYSCD", "SUBSYSCD" };
			char* qry_values[2] = { "QSORPartDRWIND", "N" };
			tag_t query = NULLTAG;
			tag_t* cntr_objects = NULL;

			char* l_info1 = NULL;
			char* l_info2 = NULL;

			
			ITK_CALL(QRY_find2("ControlObjQry", &query));
			ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			printf("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);
			TC_write_syslog("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);

			if (n_found > 0)
			{

				info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
			
				ITK_CALL(GRM_find_relation_type("T5_PartSorRel",&grm_rel));
			
				ITK_CALL(GRM_list_primary_objects_only(Primary_Obj, grm_rel, &n_grm_count, &grm_data));
			
			
				printf("\nSOR_checkin_PreCond_Validation n_grm_count : [%d]", n_grm_count); fflush(stdout);
			
				TC_write_syslog("\nSOR_checkin_PreCond_Validation n_grm_count : [%d]", n_grm_count);
			
				for(i=0;i<n_grm_count; i++)
			
				{
			
					ITK_CALL ( AOM_ask_value_string(grm_data[i],"object_name",&Partno) );
			
					printf("\nPartno : [%s]\n",Partno); fflush(stdout);
			
					ITK_CALL ( AOM_ask_value_string(grm_data[i],"t5_DrawingInd",&PartDrawingInd) );
			
					printf("\nDrawingInd : [%s]\n",PartDrawingInd); fflush(stdout);
			
					if (tc_strcmp(PartDrawingInd,"N")==0)		
					{
										
						//if ( n_found_DRW_IND <= 0 )//drawing indicator not found in control object
						//{
					
							printf ( "\nPlease update drawing indiactor for part as D/A" ) ; fflush ( stdout) ;
					
							EMH_clear_errors();
					
							EMH_store_error_s1(EMH_severity_warning,ITK_err,"To check in QuickSOR for SOR Categories CAT 4a, CAT 4b, CAT 5, and CAT 6, The Part Drawing indicator should be D/A.");
					
							return ITK_err;
					  // }	
					}
			
				}
			}
		
		}

		//Ended

		ITK_CALL(AOM_ask_table_rows(Primary_Obj, "t5_qSORVar", &ntablerows, &table_rows));
		printf("\nsor_t5_variant  checkin : [%d]", ntablerows); fflush(stdout);
		TC_write_syslog("\nsor_t5_variant  checkin : [%d]", ntablerows);

		if (tc_strstr(sor_qSorCat, "CAT 1") != NULL || tc_strstr(sor_qSorCat, "CAT 2") != NULL || tc_strstr(sor_qSorCat, "CAT 3") != NULL || tc_strstr(sor_qSorCat, "CAT 4a") != NULL || tc_strstr(sor_qSorCat, "CAT 4b") != NULL || tc_strstr(sor_qSorCat, "CAT 5") != NULL || tc_strstr(sor_qSorCat, "CAT 6") != NULL)//Added by Shubham on 18-Jun-2025
		{	
			char *info2 = NULL;
			int n_found = 0;
			int n_entries = 2;
			char* qry_entries[2] = { "SYSCD", "SUBSYSCD" };
			char* qry_values[2] = { "QSORQUANTITY", "ON" };
			tag_t query = NULLTAG;
			tag_t* cntr_objects = NULL;

			char* l_info1 = NULL;
			char* l_info2 = NULL;
			char* syscd = NULL;
			char* subsyscd = NULL;

			
			ITK_CALL(QRY_find2("ControlObjQry", &query));
			ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			printf("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);
			TC_write_syslog("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);

			if (n_found > 0)
			{

				int varflagCv = 0;

				int hasZero = 0;     //  check if any quantity is 0
                int hasOne = 0;      // check if any quantity is 1
				for (i = 0; i < ntablerows; i++)
				{


					//ITK_CALL(AOM_ask_value_string(table_rows[i], "t5_qDom", &st5_qDom));
					//ITK_CALL(AOM_ask_value_string(table_rows[i], "t5_qIB", &st5_qIB));
					ITK_CALL(AOM_UIF_ask_value(table_rows[i], "t5_qQuantity", &st5_qQuantity));


					//printf("\nst5_qDom : [%s]", st5_qDom); fflush(stdout);
					//TC_write_syslog("\nst5_qDom : [%s]", st5_qDom);
					//printf("\nst5_qIB : [%s]", st5_qIB); fflush(stdout);
					//TC_write_syslog("\nst5_qIB : [%s]", st5_qIB);
					printf("\nt5_qQuantity : [%s]", st5_qQuantity); fflush(stdout);
					TC_write_syslog("\nt5_qQuantity : [%s]", st5_qQuantity); fflush(stdout);

					if (tc_strcmp(st5_qQuantity, "") == 0 || tc_strcmp(st5_qQuantity, NULL) == 0)
					{
						//printf("\nst5_qDom : [%s]", st5_qDom); fflush(stdout);
						//TC_write_syslog("\nst5_qDom : [%s]", st5_qDom);
						//printf("\nst5_qIB : [%s]", st5_qIB); fflush(stdout);
						//TC_write_syslog("\nst5_qIB : [%s]", st5_qIB);
						printf("\nt5_qQuantity : [%s]", st5_qQuantity); fflush(stdout);
						TC_write_syslog("\nt5_qQuantity : [%s]", st5_qQuantity); fflush(stdout);
						varflagCv++;
					}
					else  // for qty check else block
					 {
					     int val = atoi(st5_qQuantity);
						 if (val == 1)
						   hasOne = 1;
					 }
				}
				printf("\n ntablerows : [%d]", ntablerows); fflush(stdout);
				printf("\n varflagCv : [%d]", varflagCv); fflush(stdout);
				printf("\n hasZero : [%d]", hasZero); fflush(stdout);     
                printf("\n hasOne : [%d]", hasOne); fflush(stdout); 
				TC_write_syslog("\n ntablerows : [%d]", ntablerows);
				TC_write_syslog("\n varflagCv : [%d]", varflagCv);
				TC_write_syslog("\n hasZero : [%d]", hasZero);            
                TC_write_syslog("\n hasOne : [%d]", hasOne);  
 
				if (varflagCv > 0)
				{
					EMH_store_error_s1(EMH_severity_error, PLM_error, "Fill the details of All Variant and Quantity (Value of Quantity should be 1 or 0)");
					printf("\nFill the details of Variant\n"); fflush(stdout);
					TC_write_syslog("\nFill the details of Variant\n");
					return PLM_error;

				}
				
		          // check  at least one value  1
                 if (!hasOne)
                 {
                     EMH_store_error_s1(EMH_severity_error, PLM_error, "Please select at least one variant with quantity 1.");
                     printf("\nPlease select at least one variant with quantity = 1.....\n"); 
                     fflush(stdout);
                     TC_write_syslog("\nPlease select at least one variant with quantity : 1....");
                     return PLM_error;
                 }
			}
		}
	 }
	 else
        {
            
            printf("\nSOR_checkin_PreCond_Validation: SOR Required value is [%s], skipping validations\n", sor_qSORRequired);
            TC_write_syslog("\nSOR_checkin_PreCond_Validation: SOR Required is [%s], skipping validations\n", sor_qSORRequired);
        }

	}



	

	return (ITK_ok);

}


int tm_check_info_control_object(char* syscd, char* subsyscd, char* info1, char* info2)
{
	int n_found = 0;
	int n_entries = 2;
	char* qry_entries[2] = { "SYSCD", "SUBSYSCD" };
	char* qry_values[2] = { syscd, subsyscd };
	tag_t query = NULLTAG;
	tag_t* cntr_objects = NULL;

	char* l_info1 = NULL;
	char* l_info2 = NULL;

	ITK_CALL(QRY_find2("ControlObjQry", &query));
	ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);
	TC_write_syslog("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);

	if (n_found > 0)
	{
		ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo1", &l_info1));
		tc_strcpy(info1, l_info1);
		ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo2", &l_info2));
		tc_strcpy(info2, l_info2);

		TC_write_syslog("\ninfo1 : [%s] info2 : [%s]", info1, info2); fflush(stdout);
	}

	return n_found;
}


int tm_fctn_tm_QuickSOR_action_handler(EPM_action_message_t msg)
{

	tag_t rootTask = NULLTAG;
	tag_t* attachments = NULLTAG;
	int noAttachment = 0;
	int i = 0;
	char* CurrentTask = NULL;
	char* parent_name = NULL;
	char* sor_qSORnumber = NULL;
	char* sor_qSorPartNumber = NULL;
	char* sor_qSORreleasestatus = NULL;
	char* sor_qSorPartRevision = NULL;
	char* sor_qSorPartSeq = NULL;
	char* command = NULL;
	command = (char*)MEM_alloc(1000 * sizeof(char));


	ITK_CALL(EPM_ask_root_task(msg.task, &rootTask));
	printf("\nQuickSOR Action Handler started"); fflush(stdout);
	TC_write_syslog("\nQuickSOR Action Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
	printf("\nQuickSOR CurrentTask : [%s]", CurrentTask);
	TC_write_syslog("\nQuickSOR CurrentTask : [%s]", CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
	printf("\nQuickSORParent Name : [%s]", parent_name); fflush(stdout);
	TC_write_syslog("\nQuickSORParent Name : [%s]", parent_name); fflush(stdout);

	if (tc_strstr(parent_name, "QuickSORReleaseProcess") != NULL)//workflowname main Parent process
	{
		if (tc_strstr(CurrentTask, "Release") != NULL)
		{

			ITK_CALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments));
			printf("\nQuickSORTarget Attachment : [%d]", noAttachment); fflush(stdout);
			TC_write_syslog("\nQuickSORTarget Attachment : [%d]", noAttachment); fflush(stdout);

			if (noAttachment > 0)
			{
				for (i = 0; i < noAttachment; i++)
				{

					ITK_CALL(AOM_ask_value_string(attachments[i], "item_id", &sor_qSORnumber));
					printf("\ntm_fctn_tm_QuickSOR_action_handler sor_qSORnumber : [%s]", sor_qSORnumber);
					TC_write_syslog("\ntm_fctn_tm_QuickSOR_action_handler sor_qSORnumber : [%s]", sor_qSORnumber);


					ITK_CALL(AOM_UIF_ask_value(attachments[i], "release_status_list", &sor_qSORreleasestatus));
					printf("\ntm_fctn_tm_QuickSOR_action_handler sor_qSORreleasestatus : [%s]", sor_qSORreleasestatus);
					TC_write_syslog("\ntm_fctn_tm_QuickSOR_action_handler sor_qSORreleasestatus : [%s]", sor_qSORreleasestatus);

					ITK_CALL(AOM_ask_value_string(attachments[i], "t5_qSorPartNumber", &sor_qSorPartNumber));
					printf("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartNumber : [%s]", sor_qSorPartNumber);
					TC_write_syslog("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartNumber : [%s]", sor_qSorPartNumber);


					ITK_CALL(AOM_ask_value_string(attachments[i], "t5_qSorPartRevision", &sor_qSorPartRevision));
					printf("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartRevision : [%s]", sor_qSorPartRevision);
					TC_write_syslog("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartRevision : [%s]", sor_qSorPartRevision);

					ITK_CALL(AOM_ask_value_string(attachments[i], "t5_qSorPartSeq", &sor_qSorPartSeq));
					printf("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartSeq : [%s]", sor_qSorPartSeq);
					TC_write_syslog("\ntm_fctn_tm_QuickSOR_action_handler sor_qSorPartSeq : [%s]", sor_qSorPartSeq);



					if (tc_strstr(sor_qSORreleasestatus, "ERC Released") != NULL || tc_strstr(sor_qSORreleasestatus, "T5_LcsErcRlzd") != NULL)
					{
						int n_found_SOR_ProNext_info1 = 0;
						int n_found_SOR_PF_info = 0;
						char* shell_path = NULL;
						char* info2 = NULL;
						char* tcua_uname = NULL;
						char* tcua_pf_file = NULL;

						shell_path = (char*)MEM_alloc(200 * sizeof(char));
						info2 = (char*)MEM_alloc(200 * sizeof(char));
						tcua_uname = (char*)MEM_alloc(50 * sizeof(char));
						tcua_pf_file = (char*)MEM_alloc(200 * sizeof(char));

						n_found_SOR_PF_info = tm_check_info_control_object("AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file);
						if (n_found_SOR_PF_info < 0)
						{
							//TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
							return 0;
						}

						n_found_SOR_ProNext_info1 = tm_check_info_control_object("QUICKSOR_SHELL", "PRONEXT_TRNS", shell_path, info2);

						if (n_found_SOR_ProNext_info1 < 0)
						{
							TC_write_syslog("\nexecuting shell for PRONEXT_TRNS");
							return 0;
						}

						//#ifdef LINUX_OS	//Commented this line by Shubham on 20-Jan-25 to auto-transfer quick SOR after ERC released.

						if (access(shell_path, F_OK) == 0)
						{
							// file exists
							printf("\nshell_path : [%s]", shell_path);
							TC_write_syslog("\nshell_path : [%s]", shell_path);
							sprintf(command, "%s/CCPLMToProNext_EV_prod_part.sh -u=%s -pf=\"%s\" -i=%s -r=%s -s=%s", shell_path, tcua_uname, tcua_pf_file, sor_qSorPartNumber, sor_qSorPartRevision, sor_qSorPartSeq);
							system(command);
						}
						else
						 {
							// file doesn't exist

							int tmp_n_found_SOR_PF_info1 = 0;
							char* shell_path_TMP_PATH = NULL;
							char* info2_TMP_PATH = NULL;

							shell_path_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));
							info2_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));

							tmp_n_found_SOR_PF_info1 = tm_check_info_control_object("QUICKSOR_SHELL_TMP_PATH", "PRONEXT_TRNS_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH);

							if (tmp_n_found_SOR_PF_info1 < 0)
							{
								TC_write_syslog("\nexecuting shell for PRONEXT_TRNS");
								return 0;
							}

							printf("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
							TC_write_syslog("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
							sprintf(command, "%s/CCPLMToProNext_EV_prod_part.sh -u=%s -pf=\"%s\" -i=%s -r=%s -s=%s", shell_path_TMP_PATH, tcua_uname, tcua_pf_file, sor_qSorPartNumber, sor_qSorPartRevision, sor_qSorPartSeq);
							system(command);

						}
						//#endif//Commented this line by Shubham on 20-Jan-25 to auto-transfer quick SOR after ERC released.
					}
				}
			}
		}
	}
	return ITK_ok;
}



int check_qsor_participant_count ( tag_t objTag) 
{
	tag_t has_participant_type = NULLTAG ;
	int nScndry_Obj_Prticipnt_cnt = 0 ;
	tag_t *existing_Prticipnts = NULLTAG ;
	tag_t exst_prtcpnt_Tag = NULLTAG ;
	int index_Prticipnt_remove = 0 ;
	tag_t ObjTypPrtcpant = NULLTAG ;
	char *PrtcpantTypeName;
	char *AssignedUsr_1 = NULL ;
	char *AssignedUsr_2 = NULL ;
	char *ParticiapntObjType = NULL;
	ITK_CALL(GRM_find_relation_type("HasParticipant", &has_participant_type));
	if ( has_participant_type != NULLTAG )
	{
		TC_write_syslog("\nQuickSOR HasParticipant"); fflush(stdout);
		printf("\nQuickSOR HasParticipant"); fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(objTag,has_participant_type,&nScndry_Obj_Prticipnt_cnt,&existing_Prticipnts));
		TC_write_syslog("\nQuickSOR existing_Prticipnts count 1 : [%d]",nScndry_Obj_Prticipnt_cnt);fflush(stdout);	
		printf("\nQuickSOR existing_Prticipnts count 1 : [%d]",nScndry_Obj_Prticipnt_cnt);fflush(stdout);	
		for ( index_Prticipnt_remove = 0; index_Prticipnt_remove < nScndry_Obj_Prticipnt_cnt ; index_Prticipnt_remove++ )
		{	
			exst_prtcpnt_Tag = existing_Prticipnts[index_Prticipnt_remove];
			ITK_CALL(TCTYPE_ask_object_type(exst_prtcpnt_Tag,&ObjTypPrtcpant));
			ITK_CALL(TCTYPE_ask_name2(ObjTypPrtcpant,&PrtcpantTypeName));
			TC_write_syslog("\nQuickSOR PrtcpantTypeName 1 : [%s]", PrtcpantTypeName);fflush(stdout);
			printf("\nQuickSOR PrtcpantTypeName 1 : [%s]", PrtcpantTypeName);fflush(stdout);
			if (tc_strcmp(PrtcpantTypeName,"T5_SORReviewer")==0)//Partipant type
			{
				ITK_CALL(AOM_UIF_ask_value(exst_prtcpnt_Tag,"fnd0AssigneeUser",&AssignedUsr_1));
				TC_write_syslog("\nQuickSOR reviewer 1 : [%s] ",AssignedUsr_1);fflush(stdout);
				printf("\nQuickSOR reviewer 1 : [%s] ",AssignedUsr_1);fflush(stdout);
			}
			//Added by Shubham on 22-May-2025
			if (tc_strcmp(PrtcpantTypeName,"T5_SORVIGReviewer")==0)//Partipant type
			{
				ITK_CALL(AOM_UIF_ask_value(exst_prtcpnt_Tag,"fnd0AssigneeUser",&AssignedUsr_2));
				TC_write_syslog("\nnQuickSOR reviewer 2 : [%s] ",AssignedUsr_2);fflush(stdout);
				printf("\nnQuickSOR reviewer 2 : [%s] ",AssignedUsr_2);fflush(stdout);
			}
			
		}
		if ( (AssignedUsr_1 != NULL) && (AssignedUsr_2 != NULL) )
		{
			TC_write_syslog("\nBoth Reviewer assigned hence proceed");
			printf("\nBoth Reviewer assigned hence proceed");
			return 2;//Both Available
		}
		else if ( (AssignedUsr_1 == NULL) && (AssignedUsr_2 == NULL) )
		{
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'SOR Reviewer' and 'SOR VIG Reviewer' to Quick SOR");
			
			TC_write_syslog("\nAssign 'SOR Reviewer' and 'SOR VIG Reviewer' to Quick SOR");
			printf("\nAssign 'SOR Reviewer' and 'SOR VIG Reviewer' to Quick SOR");
			return -2;//both are not available
		}
		else if ( AssignedUsr_1 == NULL)
		{
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'SOR Reviewer' to Quick SOR");
			
			TC_write_syslog("\nAssign 'SOR Reviewer' to Quick SOR");
			printf("\nAssign 'SOR Reviewer' to Quick SOR");
			return -1;//SOR Reviewer are not available
		}
		else if (AssignedUsr_2 == NULL)
		{
			//T5_RFICEReviewer
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'SOR VIG Reviewer' to Quick SOR");
			TC_write_syslog("\nAssign 'SOR VIG Reviewer' to Quick SOR");
			printf("\nAssign 'SOR VIG Reviewer' to Quick SOR");
			return -1;//SOR VIG Reviewer not available
		}
	}
		
	return 0;
}

EPM_decision_t Check_QuickSOR_Review_Count_Func(EPM_rule_message_t msg)
{
	char *s_DesignGrp = NULL;
	char* CurrentTask = NULL;
	char* ObjTyp = NULL;
	char* current_release_level = NULL;
	char* parent_name = NULL;
	char* task_result = NULL;
	char* qsor_COC_Hd_roles = NULL ;
	char* qsor_ce_review_roles = NULL ;
	char* tct_item_id = NULL;
	char* username = NULL;
	
	int atch = 0 ;
	int no_attach = 0 ;
	tag_t *attachment = NULLTAG;

	tag_t job = NULLTAG;
	tag_t objTag = NULLTAG;
	tag_t root_task = NULLTAG;
	tag_t user_tag = NULLTAG;
	//tag_t objMasterTag = NULLTAG;
	EPM_decision_t decision = EPM_go;


	ITK_CALL ( POM_get_user(&username,&user_tag) ) ;
	TC_write_syslog("\nQuickSOR username:[%s]",username);
	printf("\nQuickSOR username:[%s]",username);fflush(stdout);

	ITK_CALL ( EPM_ask_root_task(msg.task,&root_task ) ) ;
	TC_write_syslog("\nQuickSOR Root task found");
	printf("\nQuickSOR Root task found");fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(msg.task,"object_name",&CurrentTask) ) ;
	TC_write_syslog("\nQuickSOR CurrentTask : [%s]",CurrentTask);//QuickSORReleaseProcess
	printf("\nQuickSOR CurrentTask : [%s]",CurrentTask);fflush(stdout);//QuickSORReleaseProcess

	ITK_CALL ( AOM_ask_value_string(msg.task,"task_result",&task_result) ) ;
	TC_write_syslog("\nQuickSOR task_result : [%s]",task_result);
	printf("\nQuickSOR task_result : [%s]",task_result);fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(root_task,"object_name",&parent_name ) ) ;
	TC_write_syslog("\nQuickSOR Parent Name : [%s]",parent_name);//QuickSORReleaseProcess
	printf("\nQuickSOR Parent Name : [%s]",parent_name);fflush(stdout);//QuickSORReleaseProcess
	
	
	ITK_CALL ( EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment) ) ;
	TC_write_syslog("\nQuickSOR No of Attachements: [%d]", no_attach);
	printf("\nQuickSOR No of Attachements: [%d]", no_attach);fflush(stdout);

	//CurrentTask:Assign Analyst and Change Review Board(COC)
	//Parent Name:QuickSORReleaseProcess
	if( no_attach > 0 )
	{
		if ( tc_strstr ( parent_name, "QuickSORReleaseProcess" ) != NULL )
		{
			//if ( tc_strcmp ( CurrentTask, "Assign Analyst and Change Review Board(COC)" ) == 0 )
			if ( tc_strstr (CurrentTask, "Assign Analyst and Change Review Board") != NULL )//added Shubham on 23-May-2025
			{
				for(atch=0;atch<no_attach;atch++)
				{
					objTag = attachment[atch];
					ITK_CALL ( AOM_ask_value_string(objTag,"object_type",&ObjTyp) ) ;
					TC_write_syslog("\nQuickSOR ObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_quicksorRevision
					printf("\nQuickSOR ObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_quicksorRevision

					if( tc_strcmp ( ObjTyp, "T5_quicksorRevision" ) == 0 )
					{
						int Participant_Count = check_qsor_participant_count( objTag);
						TC_write_syslog("\nQuickSOR Participant_Count : [%d]",Participant_Count);fflush(stdout);
						printf("\nQuickSOR Participant_Count : [%d]",Participant_Count);fflush(stdout);

						if ( Participant_Count < 2)
						{
							decision = EPM_nogo;
							return decision;
						}
						else//total more than 1 partipant of both type
						{
							decision = EPM_go;
							return decision;
						}
					}
				}
			}
		}
	}
	return decision;
}

extern int Revise_quicksor_postAct(METHOD_message_t *m, va_list args)
{
	tag_t objTypeTag = NULLTAG;
	char *type_name = NULL;
	tag_t master = NULLTAG;
	tag_t source_rev =va_arg (args, tag_t);
	char* new_rev_id = va_arg(args, char*);
	tag_t* new_rev = va_arg(args, tag_t*);
	tag_t item_rev_master_form = va_arg(args, tag_t);
	tag_t dataset_relation_type = NULLTAG;
	tag_t* DatasetList = NULLTAG;
	int dataset_cnt = 0 ;
	int iRelCntr = 0;
	int n_qsor_pdf_rel_del = 0;
	tag_t relation_tag = NULLTAG;
	char *old_rev_id = NULL;
	char *qsor_item_id = NULL;
	char *old_data_set_name = NULL;
	char *New_rev_data_set_name = NULL;

	tag_t dataset_objTypeTag = NULLTAG;
	char *dataset_typename = NULL;

	char *sor_qSorPartNumber = NULL;
	char *sor_qSorPartRevision = NULL;
	char *sor_qSorPartSeq = NULL;
	char *RFQ_pdfdataset_name = NULL;
	char *DVP_pdfdataset_name = NULL;

	char *info1 = NULL;
	char *info2 = NULL;

	info1 = ( char * ) MEM_alloc ( 100 * sizeof ( char ) ) ;
	info2 = ( char * ) MEM_alloc ( 100 * sizeof ( char ) ) ;
	

	

	ITK_CALL ( TCTYPE_ask_object_type ( *new_rev,&objTypeTag ) );
	ITK_CALL ( TCTYPE_ask_name2( objTypeTag, &type_name ) );
	ITK_CALL ( ITEM_ask_item_of_rev  ( *new_rev, &master ) );

	RFQ_pdfdataset_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;
	DVP_pdfdataset_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;

	printf("\nRevise_quicksor_postAct : type_name : [%s]",type_name); fflush(stdout);
	TC_write_syslog("\nRevise_quicksor_postAct : type_name : [%s]",type_name);

	printf("\nRevise_quicksor_postAct : new_rev_id : [%s]",new_rev_id); fflush(stdout);
	TC_write_syslog("\nRevise_quicksor_postAct : new_rev_id : [%s]",new_rev_id);

	if (strcmp(type_name,"T5_quicksorRevision") == 0)
	{
		n_qsor_pdf_rel_del = tm_check_info_control_object("QSOR_PDF_REL", "TRUE", info1, info2);
		printf ( "\nn_qsor_pdf_rel_del : [%d]", n_qsor_pdf_rel_del ) ;
		TC_write_syslog ( "\nn_qsor_pdf_rel_del : [%d]", n_qsor_pdf_rel_del ) ;
			
		if (n_qsor_pdf_rel_del > 0)
		{
			ITK_CALL ( AOM_ask_value_string ( source_rev,"item_revision_id", &old_rev_id ) ) ;
			printf ( "\nold_rev_id : [%s]", old_rev_id ) ;
			TC_write_syslog ( "\nold_rev_id : [%s]", old_rev_id ) ;

			ITK_CALL ( AOM_ask_value_string ( source_rev, "item_id", &qsor_item_id ) ) ;
			printf ( "\nqsor_item_id : [%s]", qsor_item_id ) ;
			TC_write_syslog ( "\nqsor_item_id : [%s]", qsor_item_id ) ;

			
			ITK_CALL(AOM_ask_value_string(source_rev, "t5_qSorPartNumber", &sor_qSorPartNumber));
			printf ( "\nsor_qSorPartNumber : [%s]", sor_qSorPartNumber ) ;
			TC_write_syslog ( "\nsor_qSorPartNumber : [%s]", sor_qSorPartNumber ) ;

	
			ITK_CALL(AOM_ask_value_string(source_rev, "t5_qSorPartRevision", &sor_qSorPartRevision));
			printf ( "\nsor_qSorPartRevision : [%s]", sor_qSorPartRevision ) ;
			TC_write_syslog ( "\nsor_qSorPartRevision : [%s]", sor_qSorPartRevision ) ;

	
			ITK_CALL(AOM_ask_value_string(source_rev, "t5_qSorPartSeq", &sor_qSorPartSeq));
			printf ( "\nsor_qSorPartSeq : [%s]", sor_qSorPartSeq ) ;
			TC_write_syslog ( "\nsor_qSorPartSeq : [%s]", sor_qSorPartSeq ) ;

			
			tc_strcpy(RFQ_pdfdataset_name, "RFQ_");
			tc_strcat(RFQ_pdfdataset_name, sor_qSorPartNumber);
			tc_strcat(RFQ_pdfdataset_name, "_");
			tc_strcat(RFQ_pdfdataset_name, sor_qSorPartRevision);
			tc_strcat(RFQ_pdfdataset_name, "_");
			tc_strcat(RFQ_pdfdataset_name, sor_qSorPartSeq);

			tc_strcpy(DVP_pdfdataset_name, "DVP_");
			tc_strcat(DVP_pdfdataset_name, sor_qSorPartNumber);
			tc_strcat(DVP_pdfdataset_name, "_");
			tc_strcat(DVP_pdfdataset_name, sor_qSorPartRevision);
			tc_strcat(DVP_pdfdataset_name, "_");
			tc_strcat(DVP_pdfdataset_name, sor_qSorPartSeq);
	
			
			old_data_set_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;
			sprintf ( old_data_set_name, "%s_%s",  qsor_item_id, old_rev_id ) ;

			printf ( "\nold_data_set_name : [%s]", old_data_set_name ) ;
			TC_write_syslog ( "\nold_data_set_name : [%s]", old_data_set_name ) ;
		
			ITK_CALL ( GRM_find_relation_type ( "IMAN_specification", &dataset_relation_type ) );

			ITK_CALL ( GRM_list_secondary_objects_only ( *new_rev, dataset_relation_type, &dataset_cnt, &DatasetList ) ) ;
			printf("\nRevise_quicksor_postAct : dataset_cnt : [%d]", dataset_cnt); fflush(stdout);
			TC_write_syslog("\nRevise_quicksor_postAct : dataset_cnt : [%d]", dataset_cnt);

			for ( iRelCntr = 0 ; iRelCntr < dataset_cnt; iRelCntr++ )
			{
				printf("\nRevise_quicksor_postAct : RelCounter : [%d]", iRelCntr); fflush(stdout);
				TC_write_syslog("\nRevise_quicksor_postAct : RelCounter : [%d]", iRelCntr);

				ITK_CALL ( GRM_find_relation ( *new_rev, DatasetList[iRelCntr], dataset_relation_type, &relation_tag ) );

				ITK_CALL ( TCTYPE_ask_object_type ( DatasetList[iRelCntr],&dataset_objTypeTag ) );
				ITK_CALL ( TCTYPE_ask_name2( dataset_objTypeTag, &dataset_typename ) );

				printf("\nRevise_quicksor_postAct : dataset_typename : [%s]", dataset_typename); fflush(stdout);
				TC_write_syslog("\nRevise_quicksor_postAct : dataset_typename : [%s]", dataset_typename);

				if ( tc_strcmp ( dataset_typename, "PDF" ) == 0 )//delete only PDF dataset type
				{
					if ( relation_tag )//	Breaking relation between qsor SOR and New revision
					{
						ITK_CALL ( AOM_ask_value_string ( DatasetList[iRelCntr], "object_name", &New_rev_data_set_name ) ) ;
						printf ( "\nNew_rev_data_set_name : [%s]", New_rev_data_set_name ) ;
						TC_write_syslog ( "\nNew_rev_data_set_name : [%s]", New_rev_data_set_name ) ;
		
						if ( ( tc_strcmp ( New_rev_data_set_name, RFQ_pdfdataset_name ) == 0 ) ||
							( tc_strcmp ( New_rev_data_set_name, DVP_pdfdataset_name ) == 0 )
						)
						{
							ITK_CALL ( GRM_delete_relation ( relation_tag ) ) ;
							printf("\nRevise_quicksor_postAct : after delete qsor document relation delete" ) ; fflush(stdout);
							TC_write_syslog("\nRevise_quicksor_postAct : after delete qsor document relation delete" ) ;
						}
					}
				}
			}
		}
	}
	
	return ITK_ok;
}

int tm_get_quick_sor_pppm_variant ( tag_t quicksorobjTag, char *quick_sor_project_code, char *qsor_t5_qPPPMPrjCode)
{
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *var_cmd_to_execute = NULL;
	char *command = NULL;
	//char command[512];
	FILE* file = NULL ;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	char **variant_details = NULL;
	char **variant_details_read = NULL;
	int ij = 0;
	char line[250] = { 0 };
	//char *qsor_t5_qPPPMPrjCode = NULL;
	int iIndex = 0;

	char *s_srl_no = NULL;
	char *s_volume_inf = NULL;
	char *s_var_id = NULL;
	char *s_location = NULL;
	char *s_var_name = NULL;

	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_qSORVar";
	int num_rows_to_append = 0;
	char *sAutoSOR_CC_path = NULL;
	char hostbuffer[256];

	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *shell_path = NULL;
	char *pppm_file_path = NULL;
	tag_t objTypeTag = NULLTAG;
	char *type_name = NULL;

	
	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );

	ITK_CALL ( TCTYPE_ask_object_type ( quicksorobjTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	printf ( "\ntype_name : [%s]",type_name ); fflush ( stdout) ;
	TC_write_syslog ( "\ntype_name : [%s]",type_name );

	if ( tc_strcmp(type_name,"T5_quicksorRevision" ) == 0 )
	{
		n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
		if ( n_found_SOR_PF_info < 0 )
		{
			TC_write_syslog ( "\nCreate hostname username and password file control object for host : " ) ;
			return 0;
		}

		TC_write_syslog ("\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode before : [%s]",qsor_t5_qPPPMPrjCode);

		if ( tc_strcmp ( qsor_t5_qPPPMPrjCode, "" ) == 0 )
		{
			printf ( "\ntm_get_quick_sor_pppm_variant: qsor_t5_qPPPMPrjCode is null select from drop down" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode is null select from drop down" ) ;
			return -1;
		}

		ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
		printf ( "\ntm_get_quick_sor_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;
			

		printf("\ntm_get_quick_sor_pppm_variant : Project code after strtok : [%s]",qsor_t5_qPPPMPrjCode); fflush ( stdout) ;
		TC_write_syslog ("\ntm_get_quick_sor_pppm_variant: qsor_t5_qPPPMPrjCode after strtok : [%s]",qsor_t5_qPPPMPrjCode);
		
		ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
		ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
		printf ("\ntm_get_quick_sor_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);
		TC_write_syslog ("\ntm_get_quick_sor_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);

		n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

		if ( n_found_SOR_PF_info < 0 )
		{
			TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
			return 0;
		}

		n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

		if ( n_found_SOR_PF_info1 < 0 )
		{
			TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
			return 0;
		}

		timestamp = time_stamp ( ) ;
		sprintf( fileName, "/%s/pppm_var_%s_%s_%s.txt",pppm_file_path, userid,quick_sor_project_code,timestamp );
		printf ( "\ntm_get_quick_sor_pppm_variant : fileName : [%s]", fileName ); fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : fileName : [%s]", fileName );
		command = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;


		if (access(shell_path, F_OK) == 0) 
		{
			printf ("\nshell_path : [%s]",shell_path);
			TC_write_syslog ("\nshell_path : [%s]",shell_path);
			sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, quick_sor_project_code, qsor_t5_qPPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
			system( command );
			TC_write_syslog ("\ncommand QuickSOR $$$$ 1 : [%s]",command);
		} 
		else 
		{
			// file doesn't exist
			int tmp_n_found_SOR_PF_info1 = 0;
			char *shell_path_TMP_PATH = NULL;
			char *info2_TMP_PATH = NULL;


			shell_path_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );
			info2_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );

			tmp_n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL_TMP_PATH", "PPPM_CODE_VARIANT_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH );

			if ( tmp_n_found_SOR_PF_info1 < 0 )
			{
				TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
				return 0;
			}
			printf ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
			TC_write_syslog ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
			sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path_TMP_PATH,quick_sor_project_code, qsor_t5_qPPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
			system( command );

			TC_write_syslog ("\ncommand QuickSOR $$$$ 2 : [%s]",command);
		
		}

		printf ( "\ntm_get_quick_sor_pppm_variant : var_cmd_to_execute : [%s]", command ); fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : var_cmd_to_execute : [%s]", command );

		file = fopen(fileName, "r");

		if ( !file )
		{
			printf("\ntm_get_quick_sor_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
			TC_write_syslog("\ntm_get_quick_sor_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
			return -1;
		}

		variant_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			variant_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( variant_details[ij], line ) ;
			printf("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
			TC_write_syslog("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
			ij = ij + 1;
		}
		fclose ( file ) ;

		printf("\ntm_get_quick_sor_pppm_variant : Number of variant found in file : [%d]", ij ); fflush ( stdout) ;
		TC_write_syslog("\ntm_get_quick_sor_pppm_variant : Number of variant found in file : [%d]", ij );

		
		file = fopen(fileName, "r");

		if ( !file )
		{
			printf("\ntm_get_quick_sor_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
			TC_write_syslog("\ntm_get_quick_sor_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
			return -1;
		}
		n_table_rows = 0;
		ITK_CALL ( AOM_ask_table_rows ( quicksorobjTag, "t5_qSORVar", &n_table_rows, &table_rowsTag ) ) ;
		printf ( "\ntm_get_quick_sor_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows
		fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows

		if ( n_table_rows > 0 )
		{

			TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : deleting old variant for PPPM project code selected \n" ) ;//need to delete old rows
			//ITK_CALL ( AOM_lock( quicksorobjTag ) ); //lock		//Shubham commented on 23-jan-2025
			ITK_CALL ( AOM_delete_table_rows(quicksorobjTag, "t5_qSORVar", 0, n_table_rows) );

			//ITK_CALL ( AOM_save_without_extensions ( quicksorobjTag ) ); //Shubham commented on 23-jan-2025
			//ITK_CALL ( AOM_unlock ( quicksorobjTag ) );//unlock	//Shubham commented on 23-jan-2025

			TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : deleting old variant for previous PPPM project code completed... done!!!\n" ) ;//need to delete old rows
			
		}


		printf ( "\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode : [%s] \n", qsor_t5_qPPPMPrjCode ) ;//need to delete old rows
		fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode : [%s] \n", qsor_t5_qPPPMPrjCode ) ;//need to delete old rows
		
		
		if ( tc_strcmp ( qsor_t5_qPPPMPrjCode, "" ) != 0 )//pppm project is not blank
		{
			num_rows_to_append = ij ;
			
			TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : append no of rows to table : [%d] \n", num_rows_to_append ) ;//need to delete old rows
		
			//ITK_CALL ( AOM_lock ( quicksorobjTag ) ); //lock		//Shubham commented on 23-jan-2025
			TC_write_syslog("\nquicksorobjTag locked1");
			ITK_CALL ( AOM_append_table_rows ( quicksorobjTag, table_property_name,num_rows_to_append, &NewLevel, &table_rows1Tag ) ) ;
			
			
			
			//ITK_CALL (  AOM_save_without_extensions(quicksorobjTag) ); //save	//Shubham commented on 23-jan-2025
			TC_write_syslog("\nquicksorobjTag saved1");
			//ITK_CALL ( AOM_unlock ( quicksorobjTag ) );//unlock		//Shubham commented on 23-jan-2025
			TC_write_syslog("\nquicksorobjTag unlocked1");
			
			iIndex = 0 ;
			variant_details_read = (char **)MEM_alloc (200 * sizeof(char*));//no of project
			while ( fgets ( line, sizeof ( line ), file ) )
			{
				line[tc_strlen(line)-2] = '\0';
				variant_details_read[iIndex] = (char *) MEM_alloc ( 200 );	//project desc length
				tc_strcpy ( variant_details_read[iIndex], line ) ;
				variant_details_read[iIndex] = stripBlanks ( variant_details_read[iIndex] );
				
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : variant_details_read[iIndex] : [%s]",variant_details_read[iIndex]);
					
				
				s_srl_no = tc_strtok ( variant_details_read[iIndex], "^" );
				s_volume_inf = tc_strtok ( NULL, "^" );
				s_var_id = tc_strtok (  NULL, "^" );
				s_location = tc_strtok (  NULL, "^" );
				s_var_name = tc_strtok (  NULL, "^" );
				
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : s_srl_no : [%s]",s_srl_no);
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : s_volume_inf : [%s]",s_volume_inf);
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : s_var_id : [%s]",s_var_id);
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : s_location : [%s]",s_location);
				TC_write_syslog("\ntm_get_quick_sor_pppm_variant : s_var_name : [%s]\n",s_var_name);
				
				s_var_name[ tc_strlen (s_var_name) ] = '\0';
				
				ITK_CALL ( AOM_lock ( table_rows1Tag[iIndex] ) );//lock
				TC_write_syslog("\ntable_rows1Tag[%d],locked",iIndex);
				ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_qVariantId", s_var_id ) ) ;
				ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_qVariant_Name", s_var_name ) ) ;
				ITK_CALL (  AOM_save_without_extensions ( table_rows1Tag[iIndex] ) );
				ITK_CALL ( AOM_unlock ( table_rows1Tag[iIndex] ) );//unlock
				TC_write_syslog("\ntable_rows1Tag[%d],unlocked",iIndex);
				iIndex = iIndex + 1;

			}
			
			fclose ( file ) ;
			TC_write_syslog("\nfclose ( file )");
			TC_write_syslog("\ndone");

		}
		else
		{
			printf ( "\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode is blank and no of table rows are zero" ) ;//need to delete old rows
			fflush ( stdout) ;
			TC_write_syslog ( "\ntm_get_quick_sor_pppm_variant : qsor_t5_qPPPMPrjCode is blank and no of table rows are zero " ) ;//need to delete old rows

		}
	}
	return ITK_ok;
}


extern DLLAPI int prop_QuickSorPPPPrjValChg_ChngVariant(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	char *qsor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;

	tag_t  prop = va_arg(args, tag_t );
    char*  value = va_arg(args, char* );

	
	TC_write_syslog("\nINSIDE prop_QuickSorPPPPrjValChg_ChngVariant value : [%s]\n",value);fflush(stdout);
	
	tag_t quicksorRev = msg->object_tag;

			
	ITK_CALL ( AOM_ask_value_string ( quicksorRev, "t5_qBarrelCode", &dml_project_code ) ) ;
	printf ( "\nQuickSOR prop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nQuickSOR prop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ;

	ITK_CALL ( AOM_ask_value_string ( quicksorRev, "t5_qPPPMPrjCode", &qsor_t5_PPPMPrjCode ) ) ;
	printf ( "\nQuickSOR prop_PPPProjValueChange_ChngVariant : QuickSOR _t5_PPPMPrjCode pre : [%s]", qsor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nQuickSOR prop_PPPProjValueChange_ChngVariant : QuickSOR _t5_PPPMPrjCode pre : [%s]", qsor_t5_PPPMPrjCode ) ;

	if ( tc_strcmp ( qsor_t5_PPPMPrjCode, "" ) != 0 )
	{
		tm_get_quick_sor_pppm_variant ( quicksorRev, dml_project_code, qsor_t5_PPPMPrjCode);
		return ITK_ok;
	}
	else
	{
		TC_write_syslog("\nQuickSOR prop_PPPProjValueChange_ChngVariant : Select valid PPPM Project code\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid PPPM project code from dropdown list");
		return PLM_error;
	}

	return error_code;
}


// SOR CUT STOP operation
extern DLLAPI int T5_SORcutStop(METHOD_message_t *msg, va_list args)
{     
    int ifail = ITK_ok;
    int Progobj_count = 0;
    int i = 0;
    
    va_list largs;
    va_copy(largs, args);
    
    
    tag_t relation = va_arg(largs, tag_t);
    va_end(largs);
    
    tag_t primary_object = NULLTAG;
    tag_t secondary_object = NULLTAG;
    tag_t primary_obj_Type_Tag = NULLTAG;
    tag_t secondary_Type_Tag = NULLTAG;
    tag_t relation_type = NULLTAG;
    
    char *relation_type_name = NULL;
    char *primary_type_name = NULL;
    char *secondary_type_name = NULL;
    char *username = NULL;
    char *rolename = NULL;
    char *Userinfodup = NULL;
    
    tag_t user_tag = NULLTAG;
    tag_t role_tag = NULLTAG;
    tag_t Controlbj = NULLTAG;
    tag_t* Prog_object = NULLTAG;
    
    printf("\n=== INSIDE SOR CUT STOP.....N.. ===\n");
	TC_write_syslog("\n=== INSIDE SOR CUT STOP.....N.. ===\n");
    fflush(stdout);
    
    
    ITK_CALL(GRM_ask_relation_type(relation, &relation_type));
    ITK_CALL(TCTYPE_ask_name2(relation_type, &relation_type_name));
    printf("Relation Type: %s\n", relation_type_name);
    fflush(stdout);
    
    ITK_CALL(GRM_ask_primary(relation, &primary_object));
    if (primary_object != NULLTAG)
    {
        ITK_CALL(TCTYPE_ask_object_type(primary_object, &primary_obj_Type_Tag));
        ITK_CALL(TCTYPE_ask_name2(primary_obj_Type_Tag, &primary_type_name));
        printf("Primary Type: %s\n", primary_type_name);
        fflush(stdout);
    }
    
    ITK_CALL(GRM_ask_secondary(relation, &secondary_object));
    if (secondary_object != NULLTAG)
    {
        ITK_CALL(TCTYPE_ask_object_type(secondary_object, &secondary_Type_Tag));
        ITK_CALL(TCTYPE_ask_name2(secondary_Type_Tag, &secondary_type_name));
        printf("Secondary Type: %s\n", secondary_type_name);
        fflush(stdout);
    }
    
    ITK_CALL(POM_get_user(&username, &user_tag));
    ITK_CALL(SA_ask_current_role(&role_tag));
    ITK_CALL(SA_ask_role_name2(role_tag, &rolename));
    printf("User: %s, Role: %s\n", username, rolename);
    fflush(stdout);
    
    if (relation_type_name != NULL && tc_strcmp(relation_type_name, "T5_PartSorRel") == 0)
    {
        printf("Found T5_PartSorRel relation\n");
        fflush(stdout);
        
        if (secondary_type_name != NULL && tc_strcmp(secondary_type_name, "T5_quicksorRevision") == 0)
        {
            printf("Secondary is Quick SOR Revision\n");
            fflush(stdout);
            
            QRY_find2("Control Objects...", &Controlbj);
            printf("\n Inside SOR stop:: logic\n");
            fflush(stdout);
            
            char *Progsc_entry[2] = {"SYSCD", "SUBSYSCD"};
            char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
            if (Progsc_RelVal != NULL)
            {
                Progsc_RelVal[0] = "SOR_Stop";
                Progsc_RelVal[1] = "ON";
                
                QRY_execute(Controlbj, 2, Progsc_entry, Progsc_RelVal, 
                           &Progobj_count, &Prog_object);
                printf("SOR object stop:: control object count :%d \n", Progobj_count);
                fflush(stdout);
                
                if(Progobj_count > 0)
                {
                    tag_t prog_obj = Prog_object[i];
                    AOM_ask_value_string(prog_obj, "t5_Userinfo1", &Userinfodup);
                    printf("userinfo1 SOR object stop ::[%s]\n", Userinfodup);
                    fflush(stdout);
                    
                    if(tc_strstr(Userinfodup, username) != NULL || tc_strcmp(rolename, "Support_Role") == 0)
                    {
                        printf("SOR cut stop:: bypass for user %s\n", username);
                        fflush(stdout);
                        MEM_free(Progsc_RelVal);
                        return ITK_ok;  //allow
                    }
                    else
                    {
                        printf("T5_PartSorRel--primary obj type ==> %s\n", primary_type_name);
                        fflush(stdout);
                        
                        if(tc_strcmp(primary_type_name, "Design Revision") == 0 && 
                           tc_strcmp(secondary_type_name, "T5_quicksorRevision") == 0)
                        {
                            EMH_clear_errors();
                            EMH_store_error_s1(EMH_severity_error, ITK_err, 
                                "Not allowed to cut the Quick SOR Revision from Part Has SOR folder.");
                            MEM_free(Progsc_RelVal);
                            return ITK_err;  //block
                        }
                    }
                }
                else
                {
                    printf("SOR_Stop control object NOT found - allowing\n");
                    fflush(stdout);
                }
                
                MEM_free(Progsc_RelVal);
            }
        }
    }
    
    printf("Operation allowed\n");
    fflush(stdout);
    return ITK_ok;
}

int tm_bulk_sor_zip_dataset_import( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	/**
	    @param tag_t               datasetTag     (I)
	    @param char*               referenceName  (I)
	    @param AE_reference_type_t referenceType  (I)
	    @param char*               osFullPathName (I)
	    @param char*               fileName       (I)
	    @param int                 fileTypeFlag   (I)
	*/
	tag_t  datasetTag = va_arg(args, tag_t);
	char*  referenceName = va_arg(args, char*);
	AE_reference_type_t  referenceType = va_arg(args, AE_reference_type_t);
	char*  osFullPathName = va_arg(args, char*);
	char*  fileName = va_arg(args, char*);
	char *dataset_obj_name = NULL;
	char* type = NULL;
	int priObjCount = 0;
	tag_t* priObj;
	int count = 0;
	char* priObjtype = NULL;
	int namedRefCount = 0;
	tag_t* namedReference;
	char* pdfname = NULL;
	char *pdf_no_ext = NULL;
	char *bulk_sor_object_name = NULL;
	int n_BULKSOR_IMP_ZIP = 0;

	TC_write_syslog("\n*******************welcome Bulk SOR ZIP dataset import**********************");

	n_BULKSOR_IMP_ZIP = tm_check_control_object ( "BULKSOR_ZIP_NAME_VLDTN", "TRUE" );
	if ( n_BULKSOR_IMP_ZIP > 0 )
	{
		if(datasetTag != NULLTAG)
		{
			ITK_CALL ( AOM_ask_value_string ( datasetTag, "object_name", &dataset_obj_name ) ) ;
			TC_write_syslog("\ninside tm_bulk_sor_zip_dataset_import : [%s]", dataset_obj_name);fflush(stdout);
			ITK_CALL ( WSOM_ask_object_type2(datasetTag,&type) );
			TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : DatasetType : [%s]",type);fflush(stdout);
			TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : referenceName : [%s]",referenceName);fflush(stdout);
			if(tc_strcmp(type,"Zip")==0)
			{
				ITK_CALL ( GRM_list_primary_objects_only(datasetTag,NULLTAG,&priObjCount,&priObj) );
				TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : Primary object count : [%d]", priObjCount);fflush(stdout);
				if(priObjCount>0)
				{
					for ( count = 0 ; count < priObjCount; count++ )
					{
						ITK_CALL ( WSOM_ask_object_type2(priObj[count],&priObjtype ) ) ;
						TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : Primary object type : [%s]", priObjtype);fflush(stdout);

						if(tc_strcmp(priObjtype,"T5_BulkSor")==0)//New SOR
						{
							ITK_CALL ( AOM_ask_value_string ( priObj[count], "object_name", &bulk_sor_object_name ) ) ;
					
							ITK_CALL ( AE_ask_dataset_named_refs(datasetTag,&namedRefCount,&namedReference) );
							TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : inside if of tm_bulk_sor_zip_dataset_import");fflush(stdout);
							TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : AE_ask_dataset_named_refs count : [%d]",namedRefCount);fflush(stdout);
							if ( namedRefCount > 0 )
							{
								if ( tc_strstr ( dataset_obj_name, bulk_sor_object_name ) != NULL ) // check if item id and dataset name matching
								{
									ITK_CALL ( IMF_ask_original_file_name2 ( namedReference[0], &pdfname) );
									TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : pdfname : [%s]",pdfname);fflush(stdout);
									TC_write_syslog("\ntm_bulk_sor_zip_dataset_import : dataset_obj_name : [%s]",dataset_obj_name);fflush(stdout);
									pdf_no_ext = tc_strtok ( pdfname, "." ) ;
									if ( tc_strcmp ( dataset_obj_name,pdf_no_ext ) != 0 )//Is dataset name and ZIP name matching check
									{
										char *PDFNameErr = NULL;
										PDFNameErr = MEM_alloc ( 200 ) ;
										sprintf ( PDFNameErr, "ZIP filename : [%s] not matching with Dataset name : [%s] ", pdf_no_ext, dataset_obj_name ) ;
										EMH_store_error_s1 ( EMH_severity_error, PLM_error,PDFNameErr ) ;
										TC_write_syslog ( "\ntm_bulk_sor_zip_dataset_import : Error Msg : [%s]",PDFNameErr ) ;
										return PLM_error;
									}
								}
								else
								{
									TC_write_syslog ( "\ntm_bulk_sor_zip_dataset_import : BULKSOR item_no and dataset name not maching allowing to import other pdf" ) ;
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
int tm_bulk_sor_pdf_dataset_import( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	/**
	    @param tag_t               datasetTag     (I)
	    @param char*               referenceName  (I)
	    @param AE_reference_type_t referenceType  (I)
	    @param char*               osFullPathName (I)
	    @param char*               fileName       (I)
	    @param int                 fileTypeFlag   (I)
	*/
	tag_t  datasetTag = va_arg(args, tag_t);
	char*  referenceName = va_arg(args, char*);
	AE_reference_type_t  referenceType = va_arg(args, AE_reference_type_t);
	char*  osFullPathName = va_arg(args, char*);
	char*  fileName = va_arg(args, char*);
	char *dataset_obj_name = NULL;
	char* type = NULL;
	int priObjCount = 0;
	tag_t* priObj;
	int count = 0;
	char* priObjtype = NULL;
	int namedRefCount = 0;
	tag_t* namedReference;
	char* pdfname = NULL;
	char *pdf_no_ext = NULL;
	char *bulk_sor_object_name = NULL;
	int n_BULKSOR_IMP_PDF = 0;

	TC_write_syslog("\n*******************welcome Bulk SOR pdf dataset import**********************");

	n_BULKSOR_IMP_PDF = tm_check_control_object ( "BULKSOR_PDF_NAME_VLDTN", "TRUE" );
	if ( n_BULKSOR_IMP_PDF > 0 )
	{
		if(datasetTag != NULLTAG)
		{
			ITK_CALL ( AOM_ask_value_string ( datasetTag, "object_name", &dataset_obj_name ) ) ;
			TC_write_syslog("\ninside tm_bulk_sor_pdf_dataset_import : [%s]", dataset_obj_name);fflush(stdout);
			ITK_CALL ( WSOM_ask_object_type2(datasetTag,&type) );
			TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : DatasetType : [%s]",type);fflush(stdout);
			TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : referenceName : [%s]",referenceName);fflush(stdout);
			if(tc_strcmp(type,"PDF")==0)
			{
				ITK_CALL ( GRM_list_primary_objects_only(datasetTag,NULLTAG,&priObjCount,&priObj) );
				TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : Primary object count : [%d]", priObjCount);fflush(stdout);
				if(priObjCount>0)
				{
					for ( count = 0 ; count < priObjCount; count++ )
					{
						ITK_CALL ( WSOM_ask_object_type2(priObj[count],&priObjtype ) ) ;
						TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : Primary object type : [%s]", priObjtype);fflush(stdout);

						if(tc_strcmp(priObjtype,"T5_BulkSor")==0)//New SOR
						{
							ITK_CALL ( AOM_ask_value_string ( priObj[count], "object_name", &bulk_sor_object_name ) ) ;
					
							ITK_CALL ( AE_ask_dataset_named_refs(datasetTag,&namedRefCount,&namedReference) );
							TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : inside if of tm_bulk_sor_pdf_dataset_import");fflush(stdout);
							TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : AE_ask_dataset_named_refs count : [%d]",namedRefCount);fflush(stdout);
							if ( namedRefCount > 0 )
							{
								if ( tc_strstr ( dataset_obj_name, bulk_sor_object_name ) != NULL ) // check if item id and dataset name matching
								{
									ITK_CALL ( IMF_ask_original_file_name2 ( namedReference[0], &pdfname) );
									TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : pdfname : [%s]",pdfname);fflush(stdout);
									TC_write_syslog("\ntm_bulk_sor_pdf_dataset_import : dataset_obj_name : [%s]",dataset_obj_name);fflush(stdout);
									pdf_no_ext = tc_strtok ( pdfname, "." ) ;
									if ( tc_strcmp ( dataset_obj_name,pdf_no_ext ) != 0 )//Is dataset name and pdf name matching check
									{
										char *PDFNameErr = NULL;
										PDFNameErr = MEM_alloc ( 200 ) ;
										sprintf ( PDFNameErr, "PDF filename : [%s] not matching with Dataset name : [%s] ", pdf_no_ext, dataset_obj_name ) ;
										EMH_store_error_s1 ( EMH_severity_error, PLM_error,PDFNameErr ) ;
										TC_write_syslog ( "\ntm_bulk_sor_pdf_dataset_import : Error Msg : [%s]",PDFNameErr ) ;
										return PLM_error;
									}
								}
								else
								{
									TC_write_syslog ( "\ntm_bulk_sor_pdf_dataset_import : BULKSOR item_no and dataset name not maching allowing to import other pdf" ) ;
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
//function definition
extern int tm_QuickSOR_CUST_register_method(int* decision, va_list args)
{
	METHOD_id_t  method_sor_checkin;
	METHOD_id_t  method_post_act_sor;
	METHOD_id_t  method_quicksor_revise;
	METHOD_id_t  methodQuickSORPPPProjValueChange;
	//METHOD_id_t method_save_pre_act_sor;
	//METHOD_id_t method_save_pre_con_sor;
	METHOD_id_t  bulk_sor_pdf_dataset_import;
	METHOD_id_t  bulk_sor_zip_dataset_import;
	
	//three types of decisions
	//decision  (O) Whether to execute ALL_CUSTOMIZATIONS, ONLY_CURRENT_CUSTOMIZATION or NO_CUSTOMIZATION  
	*decision = ALL_CUSTOMIZATIONS;

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_sor_checkin));
	//if (method_sor_checkin.id != NULLTAG)
	if (method_sor_checkin.id != NULL)
	{
		printf("\nSOR SOR_checkin_PreCond_Validation found\n"); fflush(stdout);
		TC_write_syslog("\nSOR SOR_checkin_PreCond_Validation found\n"); fflush(stdout);
		ITK_CALL(METHOD_add_pre_condition(method_sor_checkin, (METHOD_function_t)SOR_checkin_PreCond_Validation, NULL));
	}
	else
	{
		printf("\nSOR SOR_checkin_PreCond_Validation not found\n"); fflush(stdout);
		TC_write_syslog("\nSOR SOR_checkin_PreCond_Validation not found\n"); fflush(stdout);
	}

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_post_act_sor));
	//if (method_post_act_sor.id != NULLTAG)
	if (method_post_act_sor.id != NULL)
	{
		ITK_CALL(METHOD_add_action(method_post_act_sor, METHOD_post_action_type, (METHOD_function_t)SOR_checkin_method_post, NULL));
	}
	else
	{
		TC_write_syslog("\nQuickSOR SOR_checkin_method_post not found\n"); fflush(stdout);
	}

	//ITK_CALL(METHOD_find_method("T5_quicksorRevision", "IMAN_save", &method_save_pre_act_sor));
	//if (method_save_pre_act_sor.id != NULLTAG)
	//{
	//	ITK_CALL(METHOD_add_action(method_save_pre_act_sor, METHOD_pre_action_type, (METHOD_function_t)SOR_save_method_preact, NULL));
	//}
	//else
	//{
	//	TC_write_syslog("\nSOR method_save_pre_act_sor not found\n"); fflush(stdout);
	//}

	//ITK_CALL(METHOD_find_method("T5_quicksorRevision", "IMAN_save", &method_save_pre_con_sor));
	//if (method_save_pre_con_sor.id != NULLTAG)
	//{
	//	ITK_CALL(METHOD_add_pre_condition(method_sor_checkin, (METHOD_function_t)SOR_save_PreCond_Validation, NULL));
	//}
	//else
	//{
	//	TC_write_syslog("\nSOR method_save_pre_con_sor not found\n"); fflush(stdout);
	//}



	//EPM_register_action_handler("Handlername","Handler Description","function pointer")

		
	ITK_CALL(METHOD_find_method("T5_quicksorRevision", "ITEM_copy_rev", &method_quicksor_revise));
    //if (method_quicksor_revise.id != NULLTAG)
    if (method_quicksor_revise.id != NULL)
    {
        ITK_CALL(METHOD_add_action(method_quicksor_revise, METHOD_post_action_type,(METHOD_function_t)Revise_quicksor_postAct,NULL));
    }

	ITK_CALL ( EPM_register_action_handler("tm_ActnH_tm_QuickSOR", "", tm_fctn_tm_QuickSOR_action_handler)) ;
	
	//ITK_CALL( EPM_register_rule_handler ("QuickSOR-rule-handler","Placement: Assign Task Action of select-signoff-team task", (EPM_rule_handler_t) Check_QuickSOR_Review_Count_Func));
	ITK_CALL( EPM_register_rule_handler ("QuickSOR-rule-handler","Placement: Assign Task Action of select-signoff-team task",Check_QuickSOR_Review_Count_Func));//Added Shubham on 23-May-2025

	ITK_CALL ( METHOD_find_prop_method("T5_quicksorRevision", "t5_qPPPMPrjCode", PROP_set_value_string_msg, &methodQuickSORPPPProjValueChange) );
	//if (methodQuickSORPPPProjValueChange.id != NULLTAG)
	if (methodQuickSORPPPProjValueChange.id != NULL)
	{
		ITK_CALL ( METHOD_add_action(methodQuickSORPPPProjValueChange, METHOD_post_action_type, (METHOD_function_t) prop_QuickSorPPPPrjValChg_ChngVariant, NULL) ) ;
	}
	
	ITK_CALL(METHOD_find_method("PDF", AE_import_file_msg, &bulk_sor_pdf_dataset_import));
	if (bulk_sor_pdf_dataset_import.id != 0)
	{
			ITK_CALL(METHOD_add_action(bulk_sor_pdf_dataset_import, METHOD_post_action_type,(METHOD_function_t)tm_bulk_sor_pdf_dataset_import ,NULL));
	}

	ITK_CALL(METHOD_find_method("Zip", AE_import_file_msg, &bulk_sor_zip_dataset_import));
	if (bulk_sor_zip_dataset_import.id != 0)
	{
			ITK_CALL(METHOD_add_action(bulk_sor_zip_dataset_import, METHOD_post_action_type,(METHOD_function_t)tm_bulk_sor_zip_dataset_import ,NULL));
	}
	

	// Varaible declaration for SOR CUT STOP operation
	METHOD_id_t  methoddfq7;
	int	ifail = ITK_ok;

	// Nikhil Stop the cut action on PartHasSOR Folder

   ifail = METHOD_find_method("ImanRelation", "IMAN_delete", &methoddfq7);
   if( ifail == ITK_ok )
   {
	   
		if (methoddfq7.id != NULLTAG)
	    {
			if( METHOD_add_action(methoddfq7, METHOD_pre_action_type, (METHOD_function_t) T5_SORcutStop, NULL)!=ITK_ok) 
			{
				
			}
			//	printf("Registered as METHOD_pre_action_type for T5PartToDFQVal \n");fflush(stdout);
		}
		else
	   {
			printf("Method not found for T5_SORcutStop TC_delete_msg...\n");fflush(stdout);
	   }
   }


	// END
	return ITK_ok;
}


DLLAPI int tm_QuickSOR_register_callbacks ()
{
	int ifail=0;
	printf("\nregister_callback for tm_QuickSOR");fflush(stdout);
	TC_write_syslog("\nregister_callback for tm_QuickSOR");fflush(stdout);

	ITK_CALL ( CUSTOM_register_exit ( "tm_QuickSOR", "USER_init_module", (CUSTOM_EXIT_ftn_t)  tm_QuickSOR_CUST_register_method ) ) ;
	TC_write_syslog("\nafter register_callback for tm_QuickSOR");fflush(stdout);

	return ( ITK_ok );

}
