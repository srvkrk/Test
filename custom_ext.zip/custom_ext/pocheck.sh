. /home/uadev/.bash_profile
#/home/uadev/devgroups/mohan/ITK/POcheckatERC/po1/tm_POCheckStopAtFProg -u=ercpsup  -pf=XYT1ESA  -g=dba -taskno=$1
/user/uaprod/TC_ROOT_10/bin/tml_tools/tm_POCheckStopAtFProg -u=ercpsup  -pf=XYT1ESA  -g=dba -taskno=$1
