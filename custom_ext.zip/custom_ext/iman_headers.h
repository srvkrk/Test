#ifndef IMAN_HEADERS_H
#define IMAN_HEADERS_H

#include <iman.h>
#include <ict_userservice.h>
#include <user_exits.h>
#include <prop.h>
#include <distributionlist.h>
#include <stdlib.h>
#include <ss_const.h>
#include <cr.h>
#include <epm.h>
#include <pom.h>
#include <aom.h>
#include <aom_prop.h>
#include <grm.h>
#include <item.h>
#include <item_msg.h>
#include <ae.h>
#include <folder.h>
#include <workspaceobject.h>
#include <envelope.h>
#include <method.h>
#include <imantype.h>
#include <user.h>
#include <emh.h>
#include <emh_errors.h>
#include <bom_attr.h>
#include <bom.h>
#include <custom.h>
#include <string.h>
#include <preferences.h>
#include <imanfile.h>
#include <ps.h>
#include <cr_action_handlers.h>
#include <aliaslist.h>
#include <cr_errors.h>
#include <epm_errors.h>
#include <epm_toolkit_utils.h>
#include <epm_toolkit_iman_utils.h>
#include <pom_errors.h>
#include <sa.h>
#include <sa_errors.h>
#include <ss_errors.h>
#include <wsouif_errors.h>
#include <iman_util.h>
#include <time.h>
#include <ecm.h>
#include <ods_itk.h>
#include <dataset_msg.h>
#include <tcaehelper.h>
#include <aiws_ext.h>
#include <iman_arguments.h>
#include <dataset.h>
#include <emh_const.h>
#include <ics.h>
#include <form.h>
#include <datasettype.h>
#include <tcfile.h>
#include <ae_types.h>
#include <time.h>
#include <locale.h>
#include <grm_msg.h>
#include <vm_errors.h>
#include <cfm.h>
#include<res_itk.h>
#include <stdarg.h>


int debug_g;
int SetDecisionOnEpmNogo(tag_t tasktag);
int StoreErrorString(char *errorString,int errorno);
logical INTLZ_Is_Allowed_Disallowed_Type(tag_t ObjTag,  char *ClassName, int No_of_objects, char **Object_list);
logical INTLZ_Check_Class_And_Object_Type(tag_t ObjTag, char *ClassName, char *ObjectType);
int INTLZ_Multi_Value_String_to_Pointer_Array(char *argValue, char ***Value);
int AC_set_string_value(tag_t object, char *attributeName, char* value);
int AC_set_strings_value(tag_t object, char *attributeName, char **value,int num);
int AC_get_form_tag(tag_t objectTag,char *relationName,char *formType,tag_t* formTag);
int AC_Get_Target_Plant_Value(tag_t ObjTag,char *targetFormType, char *targetPlantAttrName, char **plantValue);
int AC_Collect_All_AttachmentsFrom_RootTask(tag_t root_Task,char *itemRevId);
tag_t GetPreviousReleasedRevision1(tag_t Item_tag, tag_t Rev_tag);
int AC_Write_Error_String(tag_t objTag, char **errorString);
logical INTLZ_Check_Object_In_Attachment(tag_t rootTask, tag_t objTag, int attachment_Type);
int INTLZ_check_status_found(tag_t bomview,char StatusType[100]);

#define print_error(context)   PRINT_ERROR (context, __FILE__, __LINE__);
void  PRINT_ERROR (char* , char* , int );

 #define ERROR_CALL(x) {               \
  int stat;                     \
  char *err_string = NULL;             \
  if( (stat = (x)) != ITK_ok)   \
  {                             \
    EMH_ask_error_text (stat, &err_string);              \
    if(err_string != NULL) {\
	printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
    printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
	TC_write_syslog("Arcelik Workflow ERROR[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
	MEM_free (err_string);\
	err_string=NULL;\
	}\
    return (stat);          \
  }                         \
 }
#define Custom_free_array(p, count) {\
    int i = 0;\
  if ( p != NULL ) {\
        for(i = 0; i < count; i++) {\
            if(p[i] != NULL) {\
                MEM_free(p[i]);\
                p[i] = NULL;\
            }\
        }\
        MEM_free(p);\
        p = NULL;\
    }\
} 
#define Custom_free(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}

/*Macro for the User Custom Error*/



#endif
