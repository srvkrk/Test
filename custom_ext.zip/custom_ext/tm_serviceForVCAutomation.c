#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ict/ict_userservice.h>
#include <tccore/aom_prop.h>
#include <tc/tc_startup.h>
#include <tccore/custom.h>
#include <tccore/aom.h>
#include <qry/qry.h>
#include <tc/emh.h>
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
int ServiceForVCAutomationMaster(void *return_data)
{
	int status;
	int	ifail =	ITK_ok;	
	char *selectedTask = NULL;
	//char *selectedVehicle = NULL;
	char command[1000];

	printf("\n I am in main program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);					
	//USERARG_get_string_argument(&selectedVehicle);	
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	//printf("\n Input selectedVehicle :: %s ",selectedVehicle);fflush(stdout);
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	char* qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char* qry_valuesCntrl1[3]= {"VC","Automation","0"};
	ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	{
		if (qryTagCntrl1)
		{
			printf("\n Control Object VC Automation Query Found \n");fflush(stdout);
			ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			printf("\n No of Control Object VC Automation  Found %d ",control_number_found1);fflush(stdout);
			if(control_number_found1>0)
		    {
				char* t5_Userinfo1 = NULL;
				char Command[200];
				tag_t obj = list_of_WSO_cntrl_tags1[0];
				ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
				printf("\n t5_Userinfo1 = %s  \n",t5_Userinfo1);fflush(stdout);
				printf("\n selectedTask = %s  \n",selectedTask);fflush(stdout);
				sprintf(Command,"%s %s",t5_Userinfo1,selectedTask);
				printf("\n Executing Command = %s  \n",Command);fflush(stdout);
				TC_write_syslog("Command = %s\n",command);
				system(Command);
				printf("\n After executing Command \n");fflush(stdout);
		    }
		    else
		    {
				printf(" \n Control Object Not Found \n");
		    }

		}
	}
	return ifail;
}
extern int AllUserServiceForVCAutomation(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	int nargs = 1;//To be recieved from RAC
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );

	inputArgTypes[0] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ;

	printf("\n AllUserServiceForVCAutomation calling before....ServiceForVCAutomationMaster");fflush(stdout);  
	ifail=USERSERVICE_register_method("ServiceForVCAutomationMaster",(USER_function_t)ServiceForVCAutomationMaster,nargs,inputArgTypes,retValueType);
	return ifail;
}

extern DLLAPI int tm_serviceForVCAutomation_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_serviceForVCAutomation");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_serviceForVCAutomation", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceForVCAutomation);
	printf("\n After registering userservice....tm_serviceForVCAutomation");fflush(stdout);
	return ( ITK_ok );
}