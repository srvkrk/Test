#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

int SuffixSelectionService(void* return_data)
{
		int		status;	
		char	*ShellPath	= NULL;
		char	*ClsShmName	= NULL;
		char	*ClsShmRevision_id	= NULL;
		char	*clsShmSequence_id	= NULL;
		char	*PartTypeS	= NULL;
		char			*output						= NULL;
		int		result=0,resultDMLNo	= 0;
		char *shellpathname = NULL;
		char    command[512];
		char *user_name_string = NULL;

		char **valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
		shellpathname=MEM_alloc(150);
		printf("\n tm_SuffixSelectionService function Starting---->\n");fflush(stdout);	
		output = "tm_SuffixSelectionService function Starting---->"; 
		ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
		ITK_auto_login( );
		ITK_set_journalling( TRUE );
		printf("\n ITK_auto_login success---->\n");fflush(stdout);
		output = "ITK_auto_login success---->"; 
		USERARG_get_string_argument(&ShellPath);
		USERARG_get_string_argument(&ClsShmName);
		USERARG_get_string_argument(&ClsShmRevision_id);
		USERARG_get_string_argument(&clsShmSequence_id);
		printf("\n ShellPath-------->  : %s",ShellPath);fflush(stdout);
		printf("\n ClsShmName-------->  : %s",ClsShmName);fflush(stdout);
		printf("\n ClsShmRevision_id-------->  : %s",ClsShmRevision_id);fflush(stdout);
		printf("\n clsShmSequence_id-------->  : %s",clsShmSequence_id);fflush(stdout);
		
		POM_get_user_id(&user_name_string);
		printf("\n Session user_name_string : %s",user_name_string);fflush(stdout);

		strcpy(shellpathname,ShellPath);
		printf("\n shellpathname-------->  : %s\n",shellpathname);fflush(stdout);
		
		printf("\n%s %s %s %s \n",shellpathname,ClsShmName,ClsShmRevision_id,clsShmSequence_id);fflush(stdout);
		sprintf(command,"%s %s %s %s",shellpathname,ClsShmName,ClsShmRevision_id,clsShmSequence_id);
		
		system(command);
		printf("\n tm_SuffixSelectionService function return successfully---->\n");fflush(stdout);	

		*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

		strcpy( *((char **) return_data), output); 
		return result;
}

extern DLLAPI int SuffixSelectionService_register_userservices()
{   
 	int nargs=4;
	int *inputArgTypes;	
	int retValueType;
        
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));	
	inputArgTypes[0]=USERARG_STRING_TYPE;
	inputArgTypes[1]=USERARG_STRING_TYPE;
	inputArgTypes[2]=USERARG_STRING_TYPE;
	inputArgTypes[3]=USERARG_STRING_TYPE;
	retValueType=USERARG_TAG_TYPE;	
	printf("\n UserService tm_SuffixSelectionService get Call....");fflush(stdout);
	USERSERVICE_register_method("SuffixSelectionService",(USER_function_t) SuffixSelectionService, nargs, inputArgTypes, retValueType);
    return ITK_ok;
}

extern int SuffixSelectionServiceFun(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	SuffixSelectionService_register_userservices();
	
	return ifail;
	
}

extern DLLAPI int tm_SuffixSelectionService_register_callbacks()
{
   printf("\n tm_SuffixSelectionService_register_callbacks...."); 
   printf("\n Before registoring userservice....");
   CUSTOM_register_exit("tm_SuffixSelectionService","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)SuffixSelectionServiceFun);
   printf("\n After registoring userservice....");
   return ITK_ok;
}
