/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       t5_UpdateRowInAmden.c
*
* Description   : > 
* Module
* Since             :   26-08-2023
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 22/11/2022     Sandeep Goyal/Abineswar Bisoi                      Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}



int AmdenUpdRowFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;

    char                    *AmdInputPart                        =       NULL;
    char                    *AmdInputPartDesc                    =       NULL;
    char                    *AmdInputPartAgency                  =       NULL;
    char                    *AmdInputPartAplicablity             =       NULL;
    char                    *AmdModBy                            =       NULL;
    char                    *AmdModFnDate                        =       NULL;
    char                    *AmdInputPlantAgency                 =       NULL;
    char                    *output                              =       NULL;    
    
    output = (char *) MEM_alloc( 100 * sizeof(char*) );
    printf("\n I am in main program");fflush(stdout);


    USERARG_get_string_argument(&AmdInputPart);
    printf("\n I am in main program");fflush(stdout);
    USERARG_get_string_argument(&AmdInputPartDesc);
    USERARG_get_string_argument(&AmdInputPartAgency);
    USERARG_get_string_argument(&AmdInputPartAplicablity);
    USERARG_get_string_argument(&AmdModBy);
    USERARG_get_string_argument(&AmdModFnDate);
    USERARG_get_string_argument(&AmdInputPlantAgency);
    
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n InputAmdInputPart :: %s ",AmdInputPart);fflush(stdout);
    printf("\n InputAmdInputPartDesc :: %s ",AmdInputPartDesc);fflush(stdout);
    printf("\n InputAmdInputPartAgency :: %s ",AmdInputPartAgency);fflush(stdout);
    printf("\n InputAmdInputPartAplicablity :: %s ",AmdInputPartAplicablity);fflush(stdout);
    printf("\n InputAmdModBy :: %s ",AmdModBy);fflush(stdout);
    printf("\n InputAmdModFnDate :: %s ",AmdModFnDate);fflush(stdout);
    printf("\n InputAmdInputPlantAgency :: %s ",AmdInputPlantAgency);fflush(stdout);
    
    tag_t   AmdanQryTag       		 =    NULLTAG;
    char    *qry_entry[2]            =    {"Name","Type"};
    char    **qry_values             =  (char **) MEM_alloc(10 * sizeof(char *));

    int     CountObject              =    0;
    tag_t   *Objects_Tag             =    NULLTAG;
    tag_t   AmdenItem                =        NULLTAG;
    tag_t   Amden_rev_tag            =    NULLTAG;
    tag_t*  valid_Table_rows         =    NULLTAG;

    if(QRY_find("General...", &AmdanQryTag));
    if (AmdanQryTag)
    {
		printf("\n Query General Found \n");fflush(stdout);
    }
    else
    {
		printf("\n Query Tag General Not Found \n");fflush(stdout);
    }
    qry_values[0] = AmdInputPlantAgency;
    qry_values[1] = "Amden Table";
    if(QRY_execute(AmdanQryTag, 1, qry_entry, qry_values, &CountObject, &Objects_Tag));
    printf("No of Object Found = %d",CountObject);fflush(stdout);

    AmdenItem = Objects_Tag[0];
    ITKCALL(AOM_lock(AmdenItem));
    ITKCALL(AOM_insert_table_rows(AmdenItem, "t5_AmdTablerow", 0,1, &valid_Table_rows));
	
    ITKCALL(AOM_set_value_string(valid_Table_rows[0], "t5_AmdPartNumber", AmdInputPart));
    ITKCALL(AOM_set_value_string(valid_Table_rows[0], "t5_AmdPartDesc", AmdInputPartDesc));
    ITKCALL(AOM_set_value_string(valid_Table_rows[0], "t5_AmdAgency", AmdInputPartAgency));
    ITKCALL(AOM_set_value_string(valid_Table_rows[0], "t5_AmdInProduction", AmdInputPartAplicablity));
    ITKCALL(AOM_set_value_string(valid_Table_rows[0], "t5_AmdModBy", AmdModBy));
	
    char                  *TempDate  =       NULL;
    TempDate =       (char *) MEM_alloc(32);
    date_t         test_date_1;
    strcpy(TempDate,AmdModFnDate);
    ITK_CALL(ITK_string_to_date(TempDate,&test_date_1 ));
    ITKCALL(AOM_set_value_date(valid_Table_rows[0], "t5_AmdModificationDate",test_date_1));
    ITKCALL(AOM_save_with_extensions(valid_Table_rows[0]));   
    ITKCALL(AOM_unlock(AmdenItem));
    ITKCALL(AOM_refresh(AmdenItem, FALSE));

   
    printf("\n Successfully Added into the Table");fflush(stdout);
    tc_strcpy(output,"1000");
	printf("\n before return data....!\n");fflush(stdout);
    *((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);
	printf("\n After return data....!\n");fflush(stdout);
    MEM_free(output);

    return ifail;
}



extern int AmdenUserServiceFnUpdateRow()
{
    int ifail = ITK_ok;
    int nargs = 7;
    int retValueType;
    int inputArgTypes[7] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //inputPart
    inputArgTypes[1] = USERARG_STRING_TYPE; //inputPartDesc
    inputArgTypes[2] = USERARG_STRING_TYPE; //inputPartAgency
    inputArgTypes[3] = USERARG_STRING_TYPE; //inputPartAplicablity
    inputArgTypes[4] = USERARG_STRING_TYPE; //SessionUser
    inputArgTypes[5] = USERARG_STRING_TYPE; //ModifiedDate
    inputArgTypes[6] = USERARG_STRING_TYPE; //PlantAgency
    

    retValueType = USERARG_STRING_TYPE ;
    printf("\n AmdenUserServiceFnUpdateRow before....AmdenUpdRowFuncsvr");fflush(stdout);
    ifail=USERSERVICE_register_method("AmdenUpdRowFuncsvr",(USER_function_t)AmdenUpdRowFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceFnAmdenUpdRowFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(AmdenUserServiceFnUpdateRow());

    return ifail;
}

extern DLLAPI int t5_UpdateRowInAmden_register_callbacks ()
{

    int ifail    = ITK_ok;
    printf("\n Before registering userservice....tm_UpdateRowInAmden");fflush(stdout);
    ifail = CUSTOM_register_exit("t5_UpdateRowInAmden", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnAmdenUpdRowFn);
    printf("\n After registering userservice....tm_UpdateRowInAmden");fflush(stdout);
    return(ITK_ok);
}

