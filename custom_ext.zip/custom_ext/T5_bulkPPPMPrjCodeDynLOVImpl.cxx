//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

//
//  @file
//  This file contains the implementation for the Business Object T5_bulkPPPMPrjCodeDynLOVImpl
//

#include <T5_tm_bulkPPPMPrjCodelib/T5_bulkPPPMPrjCodeDynLOV.hxx>
#include <T5_tm_bulkPPPMPrjCodelib/T5_bulkPPPMPrjCodeDynLOVImpl.hxx>

#include <fclasses/tc_string.h>
//#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <iostream.h>

#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_bulkPPPMPrjCodeDynLOVImpl::T5_bulkPPPMPrjCodeDynLOVImpl(T5_bulkPPPMPrjCodeDynLOV& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_bulkPPPMPrjCodeDynLOVImpl::T5_bulkPPPMPrjCodeDynLOVImpl( T5_bulkPPPMPrjCodeDynLOV& busObj )
   : T5_bulkPPPMPrjCodeDynLOVGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_bulkPPPMPrjCodeDynLOVImpl::~T5_bulkPPPMPrjCodeDynLOVImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_bulkPPPMPrjCodeDynLOVImpl::~T5_bulkPPPMPrjCodeDynLOVImpl()
{
}

//----------------------------------------------------------------------------------
// T5_bulkPPPMPrjCodeDynLOVImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_bulkPPPMPrjCodeDynLOVImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_bulkPPPMPrjCodeDynLOVGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int Get_PPPM_prjCode(const char *Project_code,int* count, tag_t** items)
{
        int ifail = ITK_ok;
        tag_t Query=NULLTAG;

                int nOne = 1;
                int nCount = 0;
                char* one_attr[1] = {(char *)"Barrel Code"};

                char    *one_values[] = {(char *)Project_code};
                tag_t *nTags = NULLTAG;

                *count = 0;
                int i=0;


        printf("\n\n Get_PPPM_prjCode::Project_code==%s \n",Project_code);fflush(stdout);


                QRY_find2("SOR_Barrel", &Query);


                if (Query)
                {


                                //one_values[0] = (char*)MEM_alloc(tc_strlen(Project_code) + 1);
                                //tc_strcpy(one_values[0], Project_code);

                                QRY_execute(Query, nOne, one_attr, one_values, &nCount, &nTags);

                                printf("\n\n Get_PPPM_prjCode::nCount==%d \n",nCount);fflush(stdout);

                                printf("\n\n Get_PPPM_prjCode::Rows555==%s %d\n",Project_code,nCount);fflush(stdout);
                                *count = nCount;


                                printf("\n\n Get_PPPM_prjCode::Rows1000 VAL= %d\n",*count);fflush(stdout);
                                (*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));

                                for(i=0;i<*count;i++)
                                        {
                                                        (*items)[i] = nTags[i];
                                        }


                }


                return ifail;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_bulkPPPMPrjCodeDynLOVImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;

        bool isNull1=false;
        //bool isNull2=false;

        char *ErrorMessage = NULL;

        std::string obj_val1;

        int error_flag = 0;
        *nResults=0;
        (*results)=NULLTAG;

        printf("\n--->>>>> T5_bulkPPPMPrjCodeDynLOVImpl::In NOT NULL 11111111");fflush(stdout);

        ErrorMessage = (char *)MEM_alloc(300);

        if( JOURNAL_is_journaling() )
        {
                //JOURNAL_routine_start( "T5_DMLReasonCodeLOVImpl::fnd0askLOVValuesBase" );
                JOURNAL_routine_start( "T5_bulkPPPMPrjCodeDynLOVImpl::fnd0askLOVValuesBase" );
           // JOURNAL_address_in( impl );
                JOURNAL_routine_call();
        }

                // Call the parent Implementation
                ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

                // Your Implementation

                printf("\n  T5_bulkPPPMPrjCodeDynLOV Starting Testing !!!>>\n");fflush(stdout);
                try
                {
                        //  list_displayable_properties_with_value(operationInputTag);
                        Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
                        (Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
                        if( refOprtnInput!=NULL )
                        {

                                        refOprtnInput->getString("t5_BulkPrjCode", obj_val1, isNull1 ); ///get properties from the object

                                        tc_strcpy(ErrorMessage,"Please select Below Required Fields\n"); ///ashwani

                                        if(isNull1==true)
                                        {
                                                error_flag++;
                                                tc_strcat(ErrorMessage,"Project Code");
                                                //EMH_clear_errors();
                                                //EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Project Code First.!!");
                                                //(*results)=NULLTAG;
                                                //*nResults=0;
                                                //return ITK_err;
                                        }

                                        printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
                                        if(error_flag>0)
                                        {
                                                //tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Reason!\n");
                                                //tc_strcat(ErrorMessage,"Project Code,Release Type,Business Unit,Vehicle Classification,DR Status,Part Status/Site change [From-To]");
                                                EMH_clear_errors();
                                                EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);
                                                (*results)=NULLTAG;
                                                *nResults=0;
                                                return(PLM_error1);
                                        }
                                        if(error_flag==0)
                                        {
                                                printf("\n Before Call T5_bulkPPPMPrjCodeDynLOV::Get_PPPM_prjCode");fflush(stdout);

                                                printf("\nGiven Project Code  -->[%s] >>\n",obj_val1.c_str());fflush(stdout);

                                                (*results)=NULLTAG;
                                                *nResults=0;
                                                (*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
                                                Get_PPPM_prjCode(obj_val1.c_str(),nResults, results);

                                        }
                        }
            else
                        {
                                printf("\n--->>>>> T5_bulkPPPMPrjCodeDynLOV::In  NULL refinputtag");fflush(stdout);
                        }

                }

                catch( const IFail& ex )
                {
                   ifail = ex.ifail();
                }

    return ifail;
}
