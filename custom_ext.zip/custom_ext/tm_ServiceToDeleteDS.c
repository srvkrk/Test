#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)


#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

// /*
int tm_serviceToDeleteDesignMaster(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	int n_entryCntrl1=3;
	tag_t rev = NULLTAG;

	char *id	= NULL;
	char *revision = NULL;
	char *sequence	= NULL;
	
	USERARG_get_string_argument(&id);					
	USERARG_get_string_argument(&revision);					
	USERARG_get_string_argument(&sequence);		

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char     *qry_valuesCntrl1[3]= {"DeleteDesignMaster","DeleteDesign_Master","0"};

    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;
	printf("\n New Changes");fflush(stdout);
	printf("\n id %s", id);fflush(stdout);
	printf("\n revision %s", revision);fflush(stdout);
	printf("\n Seq %s", sequence);fflush(stdout);


    ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
       if (qryTagCntrl1)
       {
            printf("\n Design Master Delete Code11112233 \n");fflush(stdout);
		    printf("\n Control Object DeleteDesignMaster Query Found \n");fflush(stdout);
			
			ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		    printf("\n No of Control Object DeleteDesignMaster  Found %d ",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
		    {
				char* t5_Userinfo1 = NULL;
				char cmd[200];
				tag_t obj = list_of_WSO_cntrl_tags1[0];
				ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	

				sprintf(cmd,"%s  %s %s %s",t5_Userinfo1,id,revision,sequence);
				printf("Excuting Command = %s",cmd);fflush(stdout);
				system(cmd);
				printf("After executing Command");fflush(stdout);
		    }
		    else
		    {
				printf(" \n Control Object Not Found \n");
		    }
	   }


	return ifail;

}



extern int AllUserServiceDeleteDS(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
	int nargs = 3;
	int retValueType;
	int inputArgTypes[3] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes[0] = USERARG_STRING_TYPE;     // taskID
	inputArgTypes[1] = USERARG_STRING_TYPE;  // grp98Type
	inputArgTypes[2] = USERARG_STRING_TYPE;  // SESSION USER
	//inputArgTypes[3] = USERARG_STRING_TYPE;  // Group
	//inputArgTypes[4] = USERARG_STRING_TYPE;  // SESSION ROLE
	

	retValueType = USERARG_STRING_TYPE ; 
	printf("\n AllUserServiceDeleteDS before....tm_ServiceToDeleteDS");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_serviceToDeleteDesignMaster",(USER_function_t)tm_serviceToDeleteDesignMaster,nargs,inputArgTypes,retValueType);
	
	
	
 
 return ifail;
 
}

extern DLLAPI int tm_ServiceToDeleteDS_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_ServiceToDeleteDS");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ServiceToDeleteDS", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceDeleteDS);
	printf("\n After registoring userservice....tm_ServiceToDeleteDS");fflush(stdout);
	return ( ITK_ok );
}


