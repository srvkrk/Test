/**********************************************************************************************************************************************************
** SOURCE FILE NAME: tm_GateMaturationUpd.c
**
**
**	Date		Author				Modification
**	02-04-2019	Mohan Tayade		Code creation
**	06-05-2019	Mohan Tayade		Handle DR3P/AR3P.
**	22-01-2020	Mohan Tayade		Handle system attached parts for updation in new folder.
**	09-11-2022	Mohan Tayade		changes for MS status.
**	19-04-2023	Mohan Tayade		Handle MS status upadtion on part for MS live project part...
**	29-09-2023	Prasad Sagare		Handle Colour DR status upadtion on part Having Colour Indicator C
** command to run:
GateMaturationUpd -u=hpp05653 -pf=hpp05653 -g=dba -file=input.txt
GateMaturationUpd -u=ercpsup  -pf=XYT1ESA  -g=dba -file=input.txt
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int GateMaturationUpd(char* item_id);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);

	 ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	/*output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/

		//ifail = read_value_from_file(Filename);
		ifail = GateMaturationUpd(dmlnob);
		CHECK_FAIL;

	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*design_group			= NULL;
	char 			*dr_status				= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s",itemid);


		//ifail = tm_DesignRevBOM(itemid,"13PP254028","DR2");
				//ifail = GateMaturationUpd(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}
// Check Milestone Live Project
int CheckMilestoneLive(char* sProject)
{
	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t	*MilstonCntrlObjectTag		= NULLTAG;
	tag_t	MilestoneqryTag		= NULLTAG;
	char    *Milston_qry_entry[1]  = {"SYSCD"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*	 Milstoninfo1 = NULL;
	char*	 Milstoninfo2 = NULL;

	printf("\n Y15: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n Y16:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n Y17:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = "Milston";
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n Y18:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n Y19:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n Y20:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

		if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		{
			printf("\n Y21: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n Y22:It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 0;
		}
	}

	return 0;
}

int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n Y13: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n Y14: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;
}

int GateMaturationUpd(char* item_id)
{
	int		ifail 		= ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	int      no_attach      =  0;
	char	*PlntToPlnt1		=  NULL;
	char	*PlntToPlnt		=  NULL;
	char	*class_name1	=  NULL;
	char	*TaskProj		=  NULL;
	char	*PartMstr_no	=  NULL;
	char	*sPartMilstone		=  NULL;
	char	*DMLProj		=  NULL;
	char	*DMLDRR			=  NULL;
	char	*TskNm			=  NULL;
	char	*TaskDesg		=  NULL;
	char	*DMLNo			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*Partno		=  NULL;
	char	*Toplnt		=  NULL;
	char	*PrtDRst		=  NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   *ObjTyp = NULL;
	int     count,j		=  0;
	int	rel_status_cunt	=  0;
	int	crr	=  0;
	int	ii	=  0;
	int	UpdateAllow	= 0;
	int	Tskcnt	= 0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	CMRefcount	= 0;
	char*	 Chld_Rel_Stus = NULL;
	tag_t DMLRevTag = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	PartTag	= NULLTAG;
	tag_t	AssyMstrtag	= NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t*	rel_status_lst	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *GMinfo5 =NULL;
	char   *GMinfo7 =NULL;
	char   *GMinfo4 =NULL;
	char   *PartClassAllw =NULL;
	char   *Prtrel_status =NULL;
	char   *sSystPrtName =NULL;
	char   *FldrName =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;
	char   *PartProj =NULL;
	char   *relation_name =NULL;
	char   *ProjDesc =NULL;
	char   *Proj_typ =NULL;
	char   *ClrIndi =NULL;
	char   *PartDesg =NULL;
	char   *ClrDRstatus =NULL;
	logical is_latest;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	char   *type_Proj =NULL;
	char   *sPartObjyp= NULL;
	int     DR_n_entry    = 1;
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	//int     FrmValueIntg      =  0;
	int     RelRevFlag      =  0;
	int     DR_rsltCount      =  0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char *sUNMSvalue = NULL;
	sUNMSvalue =(char *) MEM_alloc(20 * sizeof(char *));
	char *sUPMSvalue = NULL;
	sUPMSvalue =(char *) MEM_alloc(20 * sizeof(char *));
	char *DMLDRStrng = NULL;
	DMLDRStrng =(char *) MEM_alloc(20 * sizeof(char *));
	char *DRStrng = NULL;
	DRStrng =(char *) MEM_alloc(20 * sizeof(char *));
	char *MSStrng = NULL;
	MSStrng =(char *) MEM_alloc(20 * sizeof(char *));
	char *TOMileStone = NULL;
	TOMileStone =(char *) MEM_alloc(20 * sizeof(char *));
		
	item_id=subString(item_id,0,10);
	printf("\n##....Inside Gate Maturation DML... %s\n",item_id);fflush(stdout);
	if(ITEM_find_item (item_id, &item_tag)!=ITK_ok)PrintErrorStack();
	//item_tag= t5GetItemRevison(item_id);
	if(item_tag==NULLTAG)
	{
		printf("\n X1:item_tag is NULL.\n");fflush(stdout);
		return 0;
	}
	else
	{
		printf("\n X2:item_tag found.\n");fflush(stdout);
		if(ITEM_ask_latest_rev (item_tag, &DMLTag)!=ITK_ok)PrintErrorStack();
		if(DMLTag==NULLTAG)
		{
			printf("\n X3:Object not found in Teamcenter...!!\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n Object Found...!!");fflush(stdout);
			if(TCTYPE_ask_object_type(DMLTag,&objTypTag)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n X4: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//DML Details:
				if(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
				printf("\n X5: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);

				if(tc_strcmp(DMLtype,"TODR")==0)
				{
					if(QRY_find2("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n X9:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n X10:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "CREVali";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n X11:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&GMinfo4)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&GMinfo5)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&GMinfo7)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo8",&PartClassAllw)!=ITK_ok)   PrintErrorStack();
						printf("\n X12:GMinfo4 is  = [%s]\n", GMinfo4);fflush(stdout);
						printf("\n X12:GMinfo5 is  = [%s]\n", GMinfo5);fflush(stdout);
						printf("\n X12:GMinfo7 is  = [%s]\n", GMinfo7);fflush(stdout);
						printf("\n X12:PartClassAllw is  = [%s]\n", PartClassAllw);fflush(stdout);
					}

					if(PlntToPlnt!=NULL)
					{
						//Check Milestone DML
						/*IsMilestoneLiveFlag=0;
						IsMilestoneLiveFlag = CheckMilestoneLive(DMLProj);
						printf("\n X6:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);
						if (IsMilestoneLiveFlag >0)
						{
							printf("\n X7:IsMilestoneLiveFlag project..");fflush(stdout);
							//if(AOM_ask_value_string(DMLTag,"t5_MilestoneStatus",&DML_Milestone)!=ITK_ok)PrintErrorStack();
							//printf("\n 8:DML_Milestone:%s", DML_Milestone); fflush(stdout);
						}*/
						//Check AR or DR
						if(ITEM_find_item(DMLProj,&Project_t)!=ITK_ok)PrintErrorStack();
						if (Project_t!=NULLTAG)
						{
							if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
							if(TCTYPE_ask_name2(ObjTypProj,&type_Proj));
							printf("\n P2:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
							if (tc_strcmp(type_Proj,"T5_Project")==0)
							{
								if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok)PrintErrorStack();
								printf("\n P2: ProjDesc : %s Proj_typ :[%s]\n",ProjDesc,Proj_typ);   fflush(stdout);
							}
							else
							{
								printf("\n P2: It is invalid project: %s \n", DMLProj);fflush(stdout);
							}
						}
						//AR0 to AR1
						if((tc_strstr(GMinfo5,PlntToPlnt) != NULL)||(tc_strstr(GMinfo7,PlntToPlnt) != NULL))
						{
							tc_strcpy(DMLDRStrng,"");
							printf("\n X12:PlntToPlnt: [%s] Proj_typ: [%s]\n", PlntToPlnt,Proj_typ);fflush(stdout);
							if((tc_strstr(PlntToPlnt,"DR")!=NULL)||(tc_strstr(PlntToPlnt,"AR")!=NULL))
							{
								if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0))
								{
									//DR3P to DR4
									printf("X13:P2:Plant to plant:%s",PlntToPlnt);fflush(stdout);
									FromPlnt=subString(PlntToPlnt, 0, 4);
									Toplnt=subString(PlntToPlnt, 8, 3);
									printf("\n X14: FromPlnt: %s, Toplnt: %s",FromPlnt,Toplnt);fflush(stdout);
								}
								else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
								{
									//AR3 to AR3P
									printf("\n X15:Plant to plant:%s",PlntToPlnt);fflush(stdout);
									FromPlnt=subString(PlntToPlnt, 0, 3);
									Toplnt=subString(PlntToPlnt, 7, 4);
									printf("\n X16: FromPlnt: %s, Toplnt: %s",FromPlnt,Toplnt);fflush(stdout);
								}
								else
								{
									//DR3 to DR4
									FromPlnt=subString(PlntToPlnt, 0, 3);
									Toplnt=subString(PlntToPlnt, 7, 3);
									printf("\n X17: FromPlnt:[%s] FromPlnt:[%s]\n", FromPlnt,Toplnt);fflush(stdout);
								}
								printf("\n X20:Before part updation DML DR-status:[%s] need to updated to:[%s].",DMLDR,Toplnt);fflush(stdout);
								if(AOM_refresh (DMLTag, 1)!=ITK_ok)PrintErrorStack();
								if(AOM_lock( DMLTag)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_set_value (DMLTag, "t5_cDRstatus", Toplnt)!=ITK_ok)PrintErrorStack();
								if(AOM_save_without_extensions (DMLTag)!=ITK_ok)PrintErrorStack();
								if(AOM_unlock(DMLTag)!=ITK_ok)PrintErrorStack();
								if(AOM_refresh (DMLTag, 0)!=ITK_ok)PrintErrorStack();

								if(AOM_ask_value_string(DMLTag,"t5_cDRstatus",&DMLDRR)!=ITK_ok)PrintErrorStack();
								printf("\n X21:After updation DML DR-status:%s",DMLDRR);fflush(stdout);

								Tskcnt=0;
								if(AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
								printf("\n X22:Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
								if (Tskcnt>0)
								{
									for (tsk=0;tsk<Tskcnt ;tsk++ )
									{
										if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
										printf("\n X23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

										if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
										{
											if(TaskDsgGrp) TaskDsgGrp=NULL;
											if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
											TaskDsgGrp=subString(TskNm,11,2);
											printf("\n X24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);

											if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
											if (tsk_CMRef_type!=NULLTAG)
											{
												CMRefcount=0;
												if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
												printf("\n X25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
												if(CMRefcount > 0)
												{
													Mstr=0;
													for (Mstr=0;Mstr<CMRefcount ;Mstr++)
													{
														printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
														if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
														printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
														if(strcmp(Prt_object_type,"Folder")!=0)
														{
															// put condition for design rev, to avoid other attachments.
															if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
															if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
															if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
															printf("\n X28:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

															Item_count=0;
															All_item_tag= t5GetItemRevison(PartMstr_no);
															if(All_item_tag==NULLTAG)
															{
																printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																//return 0;
															}
															else
															{
																if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																if(Item_count > 0)
																{
																	ii=0;
																	for(ii=Item_count-1;ii>=0;ii--)
																	{
																		rel_status_cunt=0;
																		if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(rev_list[ii], "t5_ProjectCode", &PartProj)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																		if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																		if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																		printf("\n X31:Part %s rev:%s PartProj:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartProj,rel_status,sPartObjyp);fflush(stdout);
																		//Release status.
																		if(WSOM_ask_release_status_list (rev_list[ii], &rel_status_cunt, &rel_status_lst)!=ITK_ok)PrintErrorStack();
																		printf("\n X32:rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);
																		if(rel_status_cunt > 0)
																		{
																			crr=0;
																			RelRevFlag=0;
																			for(crr=0;crr<rel_status_cunt;crr++)
																			{
																				if(AOM_ask_value_string (rel_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
																				printf("\n X33: Chld_Rel_Stus:%s rel_status:%s", Chld_Rel_Stus,rel_status);fflush(stdout);
																				if((tc_strstr(rel_status,"ERC Released")!=NULL) ||(tc_strstr(rel_status,"Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
																				{
																					if (tc_strcmp(Prtrev_idd,rev_idd)==0)
																					{
																						UPdaFlag=0;
																						RelRevFlag=1;
																						PrtDRst=NULL;
																						if(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&PrtDRst)!=ITK_ok)PrintErrorStack();
																						if(AOM_ask_value_string(rev_list[ii],"t5_ColourInd",&ClrIndi)!=ITK_ok)PrintErrorStack();
																						if(AOM_UIF_ask_value(rev_list[ii], "t5_DesignGrp", &PartDesg)!=ITK_ok)PrintErrorStack();
																						//if(AOM_ask_value_string(rev_list[ii],"t5_DRStatus",&ClrDRstatus)!=ITK_ok)PrintErrorStack();
																						printf("\n X34: Partno:%s rev_idd:%s PrtDRst:%s Toplnt:%s ClrIndi:%s PartDesg:%s", Partno,rev_idd,PrtDRst,Toplnt,ClrIndi,PartDesg);fflush(stdout);
																						if(tc_strcmp(ClrIndi,"C")==0)
																						{
																							if(AOM_ask_value_string(rev_list[ii],"t5_DRStatus",&ClrDRstatus)!=ITK_ok)PrintErrorStack();
																							printf("\n X32:ClrDRstatus is:%s.", ClrDRstatus);fflush(stdout);
																						}
																						IsPartMilestoneLiveFlag=0;
																						IsPartMilestoneLiveFlag = CheckMilestoneLive(PartProj);
																						printf("\n X34:IsPartMilestoneLiveFlag: %d",IsPartMilestoneLiveFlag);fflush(stdout);
																						if(IsPartMilestoneLiveFlag >0)
																						{
																							//printf("\n X34:DML_Milestone:%s", DML_Milestone); fflush(stdout);
																							if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																							if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																							printf("\n X34:Part class::%s\n",sPartObjyp);fflush(stdout);
																							if(tc_strstr(PartClassAllw,sPartObjyp) != NULL)
																							{
																								if (tc_strcmp(sPartObjyp,"Design Revision") == 0)
																								{
																									if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																									printf(" and t5_DesignMilestoneStatus1:[%s]..",sPartMilstone);fflush(stdout);
																								}
																								else if (tc_strcmp(sPartObjyp,"T5_EE_PartRevision") == 0)
																								{
																									if(tc_strstr(GMinfo4,"May2022E") == NULL)
																									{
																										if(AOM_ask_value_string(rev_list[ii],"t5_EEPartMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																										printf(" and t5_EEPartMilestoneStatus:[%s]..",sPartMilstone);fflush(stdout);
																									}
																									else
																									{
																										if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																										printf(" and t5_DesignMilestoneStatus2:[%s]..",sPartMilstone);fflush(stdout);
																									}
																								}
																								else if (tc_strcmp(sPartObjyp,"T5_ClrPartRevision") == 0)
																								{
																									if(tc_strstr(GMinfo4,"May2022F") == NULL)
																									{
																										if(AOM_ask_value_string(rev_list[ii],"t5_ClrMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																										printf(" and t5_DesignMilestoneStatus3:[%s]..",sPartMilstone);fflush(stdout);
																									}
																									else
																									{
																										if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																										printf(" and t5_DesignMilestoneStatus4::[%s]..",sPartMilstone);fflush(stdout);
																									}
																								}
																								else
																								{
																									if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																									printf(" and t5_DesignMilestoneStatus4:[%s]..",sPartMilstone);fflush(stdout);
																								}
																							}
																							//Milestone status upadtion logic
																							printf("\n X78:Milestone status upadtion logic...Partno:[%s]",Partno);fflush(stdout);
																							if(tc_strstr(GMinfo4,"MSValiON") == NULL)
																							{
																								if ((tc_strcmp(PlntToPlnt,"AR0 to AR1")==0)|| (tc_strcmp(PlntToPlnt,"DR0 to DR1")==0))
																								{
																									printf("\n X33: Partno:%s updated... ", Partno);fflush(stdout);																											
																									//if (tc_strcmp(sPartMilstone,"")==0)
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV1");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV2");
																										}
																										printf("\n X80::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV1") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV2");
																										printf("\n X80::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV0") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV1");
																										printf("\n X80::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV1");
																										printf("\n X80::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else if ((tc_strcmp(PlntToPlnt,"AR1 to AR2")==0)|| (tc_strcmp(PlntToPlnt,"DR1 to DR2")==0))
																								{
																									printf("\n X90: Partno:%s updated... ", Partno);fflush(stdout);																											
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV3");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV3");
																										}
																										printf("\n X90::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV3");
																										printf("\n X90::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV3");
																										printf("\n X90::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV3");
																										printf("\n X90::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else if ((tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
																								{
																									printf("\n X91: Partno:%s updated... ", Partno);fflush(stdout);																											
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV3");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV3");
																										}
																										printf("\n X91::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV3");
																										printf("\n X91::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV3");
																										printf("\n X91::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV3");
																										printf("\n X91::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
																								{
																									printf("\n X92: Partno:%s updated... ", Partno);fflush(stdout);																											
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV3");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV3");
																										}
																										printf("\n X92::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV3");
																										printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV3");
																										printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV3");
																										printf("\n X92::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR4")==0))
																								{
																									printf("\n X92: Partno:%s updated... ", Partno);fflush(stdout);																											
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV3");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV3");
																										}
																										printf("\n X92::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV3");
																										printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV3");
																										printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV3");
																										printf("\n X92::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else if ((tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)|| (tc_strcmp(PlntToPlnt,"DR4 to DR5")==0))
																								{
																									printf("\n X93: Partno:%s updated... ", Partno);fflush(stdout);																											
																									if(tc_strlen(sPartMilstone) == 0)
																									{
																										//ZZZZZZZZZZZZZZZZZ
																										if(tc_strstr(GMinfo4,PartDesg) != NULL)
																										{
																											tc_strcpy(MSStrng,"UPV3");
																										}
																										else
																										{
																											tc_strcpy(MSStrng,"UNV3");
																										}
																										printf("\n X93::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UNV3");
																										printf("\n X93::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																									{
																										tc_strcpy(MSStrng,"UPV3");
																										printf("\n X93::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																									}
																									else
																									{
																										//tc_strcpy(MSStrng,"UPV3");
																										printf("\n X93::V8:NO MS status...\n");fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n Y8:Part not allow for updation:%s\n",Partno);fflush(stdout);
																								}
																							
																								printf("\n Final:part MS status for updation:%s \n",MSStrng);fflush(stdout);
																								if (tc_strcmp(MSStrng,"") == 0)
																								{
																									printf("\n .......................NO MS updationnnnnnn.\n");fflush(stdout);
																								}
																								else
																								{
																									printf("\n going for MS status for updation:%s \n",MSStrng);fflush(stdout);
																									if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																									if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																									if(tc_strstr(PartClassAllw,sPartObjyp) != NULL)
																									{
																										if (tc_strcmp(sPartObjyp,"Design Revision") == 0)
																										{
																											if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																										}
																										else if (tc_strcmp(sPartObjyp,"T5_EE_PartRevision") == 0)
																										{
																											if(tc_strstr(GMinfo4,"May2022E") == NULL)
																											{
																												if(AOM_UIF_set_value (rev_list[ii], "t5_EEPartMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																												printf("\n Y10:F:MSStrng:%s \n",MSStrng);fflush(stdout);
																											}
																											else
																											{
																												if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																												printf("\n Y10:D::MSStrng:%s \n",MSStrng);fflush(stdout);
																											}
																										}
																										else if (tc_strcmp(sPartObjyp,"T5_ClrPartRevision") == 0)
																										{
																											if(tc_strstr(GMinfo4,"May2022F") == NULL)
																											{
																												if(AOM_UIF_set_value (rev_list[ii], "t5_ClrMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																												printf("\n Y10:A:MSStrng:%s \n",MSStrng);fflush(stdout);
																											}
																											else
																											{
																												if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																												printf("\n Y10:C:MSStrng:%s \n",MSStrng);fflush(stdout);
																											}
																										}
																										else
																										{
																											if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																											printf("\n Y10:B:MSStrng:%s \n",MSStrng);fflush(stdout);
																										}
																									}
																									if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																									if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																									if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																									printf("\n Y10:MSStrng:%s part:%s\n",MSStrng,Partno);fflush(stdout);
																									printf("\n  ............................MS successfully updated.\n");fflush(stdout);
																								}
																							}
																						}
																						printf("\n Folder Hereeeeee sPartMilstone:[%s]",sPartMilstone);fflush(stdout);
																						if((tc_strcmp(PrtDRst,"")==0) || (PrtDRst==NULL) || (tc_strlen(PrtDRst) == 0) || (tc_strcmp(PrtDRst,"NA")==0))
																						{
																							printf("\n X78:NA Part updation...");fflush(stdout);
																							if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																							if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																							if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																							printf(" done for part:%s\n",Partno);fflush(stdout);
																							//need to handle to MS live parts...this is kept OFF
																							
																						}
																						else
																						{
																							if ((tc_strcmp(PlntToPlnt,"AR0 to AR1")==0)|| (tc_strcmp(PlntToPlnt,"DR0 to DR1")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR1");
																										printf("\n X79:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR1");
																										printf("\n X80:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X81:Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else if ((tc_strcmp(PlntToPlnt,"AR1 to AR2")==0)|| (tc_strcmp(PlntToPlnt,"DR1 to DR2")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR2");
																										printf("\n X82:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR2");
																										printf("\n X83:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X84:Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else if ((tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR3");
																										printf("\n X85:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR3");
																										printf("\n X86:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X87:Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR3P");
																										printf("\n X88:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR3P");
																										printf("\n X89:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X90::Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR4")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0)||(tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR4");
																										printf("\n X91:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR4");
																										printf("\n X92:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X93:Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else if ((tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)|| (tc_strcmp(PlntToPlnt,"DR4 to DR5")==0))
																							{
																								if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0)||(tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0)||(tc_strcmp(PrtDRst,"AR4")==0)|| (tc_strcmp(PrtDRst,"DR4")==0))
																								{
																									UPdaFlag=1;
																									tc_strcpy(DRStrng,"");
																									if(tc_strstr(PrtDRst,"DR") != NULL)
																									{
																										tc_strcpy(DRStrng,"DR5");
																										printf("\n X94:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																									else
																									{
																										tc_strcpy(DRStrng,"AR5");
																										printf("\n X95:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																									}
																								}
																								else
																								{
																									printf("\n X96:Other DR-status part:%s\n",Partno);fflush(stdout);
																								}
																							}
																							else
																							{
																								printf("\n Y8:Part not allow for updation:%s\n",Partno);fflush(stdout);
																							}
																							printf("\n Y9:Part allow for updation:%s:%s  and IsPartMilestoneLiveFlag:%d MSStrng:%s\n",Partno,DRStrng,IsPartMilestoneLiveFlag,MSStrng);fflush(stdout);
																							if(UPdaFlag >0)
																							{
																								if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																								if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																								if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																								printf("\n Y10:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																							}
																						}
																						//Prasad
																						printf("\n To Update t5_DRStatus of part: %s, Colour indicator :%s to update t5_DRStatus:%s\n",Partno,ClrIndi,Toplnt);fflush(stdout);
																						if((tc_strcmp(ClrIndi,"C")==0) && (tc_strcmp(ClrDRstatus,Toplnt)!=0))
																						{
																							printf("\n Colour indicator C found And update t5_DRStatus to:%s\n",Toplnt);fflush(stdout);
																							if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																							if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_UIF_set_value (rev_list[ii], "t5_DRStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																							if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																							if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																							printf("\n Y112:t5_DRStatus:%s part:%s\n",Toplnt,Partno);fflush(stdout);
																						}
																						break;
																					}
																				}
																			}
																			if (RelRevFlag >0)
																			{
																				break;
																			}
																		}
																	}
																}
															}
														}
														else
														{
															printf("\n X67: Expanssion for Folder.");fflush(stdout);
															if(AOM_ask_value_string(TaskCMRef[Mstr],"object_name",&FldrName)!=ITK_ok)PrintErrorStack();
															printf("\n X68:FldrName:: %s\n", FldrName);fflush(stdout);
															if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
															{
																printf("\n X69: getting parts.\n");fflush(stdout);
																if(FL_ask_size(TaskCMRef[Mstr],&FlderSize));
																printf("\n X70:FlderSize is:   %d\n",FlderSize);fflush(stdout);
																if(FL_ask_references(TaskCMRef[Mstr],FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag));
																printf("\n X71:FlderObjCount is..:   %d\n",FlderObjCount);fflush(stdout);
																if(FlderObjCount>0)
																{
																	fld=0;
																	for (fld=0;fld<FlderObjCount;fld++)
																	{
																		if(AOM_ask_value_string(FolderObj_tag[fld],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(FolderObj_tag[fld], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																		if(AOM_UIF_ask_value(FolderObj_tag[fld], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																		printf("\n X72:PartMstr_no %s Prtrev_idd:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																		Item_count=0;
																		All_item_tag= t5GetItemRevison(PartMstr_no);
																		if(All_item_tag==NULLTAG)
																		{
																			printf("\n X29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																			//return 0;
																		}
																		else
																		{
																			if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																			printf("\n X30:Total rev found: %d.", Item_count);fflush(stdout);
																			if(Item_count > 0)
																			{
																				ii=0;
																				for(ii=Item_count-1;ii>=0;ii--)
																				{
																					rel_status_cunt=0;
																					if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(rev_list[ii], "t5_ProjectCode", &PartProj)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(rev_list[ii],"t5_ColourInd",&ClrIndi)!=ITK_ok)PrintErrorStack();
																					if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																					if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																					printf("\n X31:Part %s rev:%s PartProj:%s Rel Status:%s sPartObjyp:%s ClrIndi:%s", Partno,rev_idd,PartProj,rel_status,sPartObjyp,ClrIndi);fflush(stdout);
																					if(tc_strcmp(ClrIndi,"C")==0)
																					{
																						if(AOM_ask_value_string(rev_list[ii],"t5_DRStatus",&ClrDRstatus)!=ITK_ok)PrintErrorStack();
																						printf("\n X32:ClrDRstatus is:%s.", ClrDRstatus);fflush(stdout);
																					}
																					//Release status.
																					if(WSOM_ask_release_status_list (rev_list[ii], &rel_status_cunt, &rel_status_lst)!=ITK_ok)PrintErrorStack();
																					printf("\n X32:rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);
																					if(rel_status_cunt > 0)
																					{
																						crr=0;
																						RelRevFlag=0;
																						for(crr=0;crr<rel_status_cunt;crr++)
																						{
																							if(AOM_ask_value_string (rel_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
																							printf("\n X33: Chld_Rel_Stus:%s rel_status:%s", Chld_Rel_Stus,rel_status);fflush(stdout);
																							if((tc_strstr(rel_status,"ERC Released")!=NULL) ||(tc_strstr(rel_status,"Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
																							{
																								if (tc_strcmp(Prtrev_idd,rev_idd)==0)
																								{
																									UPdaFlag=0;
																									RelRevFlag=1;
																									PrtDRst=NULL;
																									if(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&PrtDRst)!=ITK_ok)PrintErrorStack();
																									printf("\n X34: Partno:%s rev_idd:%s PrtDRst:%s Toplnt:%s", Partno,rev_idd,PrtDRst,Toplnt);fflush(stdout);
																									IsPartMilestoneLiveFlag=0;
																									IsPartMilestoneLiveFlag = CheckMilestoneLive(PartProj);
																									printf("\n X34:IsPartMilestoneLiveFlag: %d",IsPartMilestoneLiveFlag);fflush(stdout);
																									if(IsPartMilestoneLiveFlag >0)
																									{
																										//printf("\n X34:DML_Milestone:%s", DML_Milestone); fflush(stdout);
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																										printf("\n X34:Part class::%s\n",sPartObjyp);fflush(stdout);
																										if(tc_strstr(PartClassAllw,sPartObjyp) != NULL)
																										{
																											if (tc_strcmp(sPartObjyp,"Design Revision") == 0)
																											{
																												if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																												printf(" and t5_DesignMilestoneStatus1:[%s]..",sPartMilstone);fflush(stdout);
																											}
																											else if (tc_strcmp(sPartObjyp,"T5_EE_PartRevision") == 0)
																											{
																												if(tc_strstr(GMinfo4,"May2022E") == NULL)
																												{
																													if(AOM_ask_value_string(rev_list[ii],"t5_EEPartMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																													printf(" and t5_EEPartMilestoneStatus:[%s]..",sPartMilstone);fflush(stdout);
																												}
																												else
																												{
																													if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																													printf(" and t5_DesignMilestoneStatus2:[%s]..",sPartMilstone);fflush(stdout);
																												}
																											}
																											else if (tc_strcmp(sPartObjyp,"T5_ClrPartRevision") == 0)
																											{
																												if(tc_strstr(GMinfo4,"May2022F") == NULL)
																												{
																													if(AOM_ask_value_string(rev_list[ii],"t5_ClrMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																													printf(" and t5_DesignMilestoneStatus3:[%s]..",sPartMilstone);fflush(stdout);
																												}
																												else
																												{
																													if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																													printf(" and t5_DesignMilestoneStatus4::[%s]..",sPartMilstone);fflush(stdout);
																												}
																											}
																											else
																											{
																												if(AOM_ask_value_string(rev_list[ii],"t5_DesignMilestoneStatus",&sPartMilstone)!=ITK_ok)PrintErrorStack();
																												printf(" and t5_DesignMilestoneStatus4:[%s]..",sPartMilstone);fflush(stdout);
																											}
																										}
																										//Milestone status upadtion logic
																										printf("\n X78:Milestone status upadtion logic...Partno:[%s]",Partno);fflush(stdout);
																										if(tc_strstr(GMinfo4,"MSValiON") == NULL)
																										{
																											if ((tc_strcmp(PlntToPlnt,"AR0 to AR1")==0)|| (tc_strcmp(PlntToPlnt,"DR0 to DR1")==0))
																											{
																												printf("\n X33: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV2");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV1");
																													}
																													printf("\n X80::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV1") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV2");
																													printf("\n X80::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV0") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV1");
																													printf("\n X80::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV1");
																													printf("\n X80::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else if ((tc_strcmp(PlntToPlnt,"AR1 to AR2")==0)|| (tc_strcmp(PlntToPlnt,"DR1 to DR2")==0))
																											{
																												printf("\n X90: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV3");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV3");
																													}
																													printf("\n X90::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV3");
																													printf("\n X90::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV3");
																													printf("\n X90::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV3");
																													printf("\n X90::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else if ((tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
																											{
																												printf("\n X91: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV3");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV3");
																													}
																													printf("\n X91::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV3");
																													printf("\n X91::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV3");
																													printf("\n X91::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV3");
																													printf("\n X91::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
																											{
																												printf("\n X92: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV3");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV3");
																													}
																													printf("\n X92::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV3");
																													printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV3");
																													printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV3");
																													printf("\n X92::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR4")==0))
																											{
																												printf("\n X92: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV3");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV3");
																													}
																													printf("\n X92::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV3");
																													printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV3");
																													printf("\n X92::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV3");
																													printf("\n X92::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else if ((tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)|| (tc_strcmp(PlntToPlnt,"DR4 to DR5")==0))
																											{
																												printf("\n X93: Partno:%s updated... ", Partno);fflush(stdout);																											
																												if(tc_strlen(sPartMilstone) == 0)
																												{
																													//ZZZZZZZZZZ
																													if(tc_strstr(GMinfo4,PartDesg) != NULL)
																													{
																														tc_strcpy(MSStrng,"UPV3");
																													}
																													else
																													{
																														tc_strcpy(MSStrng,"UNV3");
																													}
																													printf("\n X93::V8:NULL:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UNV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UNV3");
																													printf("\n X93::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else if(tc_strstr(sPartMilstone,"UPV") != NULL)
																												{
																													tc_strcpy(MSStrng,"UPV3");
																													printf("\n X93::V8:DR1:DML MS status for updation:%s\n",MSStrng);fflush(stdout);
																												}
																												else
																												{
																													//tc_strcpy(MSStrng,"UPV3");
																													printf("\n X93::V8:NO MS status...\n");fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n Y8:Part not allow for updation:%s\n",Partno);fflush(stdout);
																											}
																										
																											printf("\n Final:part MS status for updation:%s \n",MSStrng);fflush(stdout);
																											if (tc_strcmp(MSStrng,"") == 0)
																											{
																												printf("\n .......................NO MS updationnnnnnn.\n");fflush(stdout);
																											}
																											else
																											{
																												printf("\n going for MS status for updation:%s \n",MSStrng);fflush(stdout);
																												if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																												if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																												if(tc_strstr(PartClassAllw,sPartObjyp) != NULL)
																												{
																													if (tc_strcmp(sPartObjyp,"Design Revision") == 0)
																													{
																														if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																													}
																													else if (tc_strcmp(sPartObjyp,"T5_EE_PartRevision") == 0)
																													{
																														if(tc_strstr(GMinfo4,"May2022E") == NULL)
																														{
																															if(AOM_UIF_set_value (rev_list[ii], "t5_EEPartMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																															printf("\n Y10:F:MSStrng:%s \n",MSStrng);fflush(stdout);
																														}
																														else
																														{
																															if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																															printf("\n Y10:D::MSStrng:%s \n",MSStrng);fflush(stdout);
																														}
																													}
																													else if (tc_strcmp(sPartObjyp,"T5_ClrPartRevision") == 0)
																													{
																														if(tc_strstr(GMinfo4,"May2022F") == NULL)
																														{
																															if(AOM_UIF_set_value (rev_list[ii], "t5_ClrMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																															printf("\n Y10:A:MSStrng:%s \n",MSStrng);fflush(stdout);
																														}
																														else
																														{
																															if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																															printf("\n Y10:C:MSStrng:%s \n",MSStrng);fflush(stdout);
																														}
																													}
																													else
																													{
																														if(AOM_UIF_set_value (rev_list[ii], "t5_DesignMilestoneStatus", MSStrng)!=ITK_ok)PrintErrorStack();
																														printf("\n Y10:B:MSStrng:%s \n",MSStrng);fflush(stdout);
																													}
																												}
																												if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																												if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																												if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																												printf("\n Y10:MSStrng:%s part:%s\n",MSStrng,Partno);fflush(stdout);
																												printf("\n  ............................MS successfully updated.\n");fflush(stdout);
																											}
																										}
																									}
																									printf("\n Folder Hereeeeee sPartMilstone:[%s]",sPartMilstone);fflush(stdout);
																									if((tc_strcmp(PrtDRst,"")==0) || (PrtDRst==NULL) || (tc_strlen(PrtDRst) == 0) || (tc_strcmp(PrtDRst,"NA")==0))
																									{
																										printf("\n X78:NA Part updation...");fflush(stdout);
																										if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																										if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																										if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																										printf(" done for part:%s\n",Partno);fflush(stdout);
																										//need to handle to MS live parts...this is kept OFF
																										
																									}
																									else
																									{
																										if ((tc_strcmp(PlntToPlnt,"AR0 to AR1")==0)|| (tc_strcmp(PlntToPlnt,"DR0 to DR1")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR1");
																													printf("\n X79:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR1");
																													printf("\n X80:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X81:Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else if ((tc_strcmp(PlntToPlnt,"AR1 to AR2")==0)|| (tc_strcmp(PlntToPlnt,"DR1 to DR2")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR2");
																													printf("\n X82:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR2");
																													printf("\n X83:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X84:Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else if ((tc_strcmp(PlntToPlnt,"AR2 to AR3")==0)|| (tc_strcmp(PlntToPlnt,"DR2 to DR3")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR3");
																													printf("\n X85:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR3");
																													printf("\n X86:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X87:Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else if ((tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR3P");
																													printf("\n X88:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR3P");
																													printf("\n X89:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X90::Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else if ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR4")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0)||(tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR4");
																													printf("\n X91:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR4");
																													printf("\n X92:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X93:Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else if ((tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)|| (tc_strcmp(PlntToPlnt,"DR4 to DR5")==0))
																										{
																											if ((tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)||(tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)||(tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)||(tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR3")==0)||(tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0)||(tc_strcmp(PrtDRst,"AR4")==0)|| (tc_strcmp(PrtDRst,"DR4")==0))
																											{
																												UPdaFlag=1;
																												tc_strcpy(DRStrng,"");
																												if(tc_strstr(PrtDRst,"DR") != NULL)
																												{
																													tc_strcpy(DRStrng,"DR5");
																													printf("\n X94:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																												else
																												{
																													tc_strcpy(DRStrng,"AR5");
																													printf("\n X95:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																												}
																											}
																											else
																											{
																												printf("\n X96:Other DR-status part:%s\n",Partno);fflush(stdout);
																											}
																										}
																										else
																										{
																											printf("\n Y8:Part not allow for updation:%s\n",Partno);fflush(stdout);
																										}
																										printf("\n Y9:Part allow for updation:%s:%s  and IsPartMilestoneLiveFlag:%d MSStrng:%s\n",Partno,DRStrng,IsPartMilestoneLiveFlag,MSStrng);fflush(stdout);
																										if(UPdaFlag >0)
																										{
																											if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																											if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																											if(AOM_UIF_set_value (rev_list[ii], "t5_PartStatus", DRStrng)!=ITK_ok)PrintErrorStack();
																											if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																											if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																											if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																											printf("\n Y10:DRStrng:%s part:%s\n",DRStrng,Partno);fflush(stdout);
																										}
																									}
																									//Prasad
																									printf("\n FOlder parts: To Update t5_DRStatus of part: %s, Colour indicator :%s to update t5_DRStatus:%s\n",Partno,ClrIndi,Toplnt);fflush(stdout);
																									if((tc_strcmp(ClrIndi,"C")==0) && (tc_strcmp(ClrDRstatus,Toplnt)!=0))
																									{
																										printf("\n FOlder parts:Colour indicator C found And update t5_DRStatus to:%s\n",Toplnt);fflush(stdout);
																										if(AOM_refresh (rev_list[ii], 1)!=ITK_ok)PrintErrorStack();
																										if(AOM_lock( rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_set_value (rev_list[ii], "t5_DRStatus", Toplnt)!=ITK_ok)PrintErrorStack();
																										if(AOM_save_without_extensions (rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_unlock(rev_list[ii])!=ITK_ok)PrintErrorStack();
																										if(AOM_refresh (rev_list[ii], 0)!=ITK_ok)PrintErrorStack();
																										printf("\nFOlder parts:Y122:t5_DRStatus:%s part:%s\n",Toplnt,Partno);fflush(stdout);
																									}
																									break;
																								}
																							}
																						}
																						if (RelRevFlag >0)
																						{
																							break;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
							else
							{
								printf("\n X18:other value case.......");fflush(stdout);
							}
						}
					}
					else
					{
						//Blank value
						printf("\n Y11: Blank value..");fflush(stdout);
					}
					if(TaskCMRef) MEM_free(TaskCMRef);
					if(rev_list) MEM_free(rev_list);
				}
				printf("\n Y12: ......Updation Function end for GM DML.");fflush(stdout);
				//break;
			}
		}
	}

	return ifail;
}
