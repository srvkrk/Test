/*****************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   DML release letter in DML WF..
*  Code                 :   tm_DML_Mail_WF_AH_Func.c
*  Created on			:   26/03/2023
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		26/03/2023				Mohan Tayade		DML release letter in DML WF..
*	2.		26/04/2023				Mohan Tayade		DML mails to Manager and Group.
*******************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_DML_Mail_WF_AH_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *taskAttachments     =  NULLTAG;
	int i=0;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLNo			=  NULL;
	tag_t	user		= NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp = NULL;
	int error_code = ITK_ok;
	char*	DMLReason		= NULL;
	char*	DML_BU			= NULL;
	char*	DMLType			= NULL;
	char*	ProjectID		= NULL;
	char*	sDMLrlstype		= NULL;
	char*	DMLcommand		= NULL;
	char *person_namee			= NULL;
	char*	DMLprintInfo7		= NULL;
	char*	DMLprintInfo6		= NULL;
	char*	DMLprintInfo5		= NULL;
	char*	DMLprintInfo4		= NULL;
	char*	DMLprintInfo3		= NULL;
	char*	DMLprintInfo2		= NULL;
	char*	DMLprintInfo1		= NULL;
	char*	ReqUserId		= NULL;
	tag_t	person_tagg			= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		person_tag			= NULLTAG;
	char*		person_name			= NULL;
	char*		sCCmails			= NULL;
	char*		sTOmails			= NULL;
	char		*emailID					=NULL;
	int     DR_n_entry    = 1;
	int     n_entry    = 1;
	int     DR_rsltCount      =  0;
	int     rsltCount      =  0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(100 * sizeof(char *));
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	int jk=0;
	int CRBcount=0;
	tag_t dml_CRB_rel_type = NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t ObjTypDmlCRB = NULLTAG;
	char* DMLReviewGrp = NULL;
	char* RevemailID = NULL;
	char* DMUReviewr = NULL;
	char* DMUReviewGrp = NULL;
	char* DMLReviewr = NULL;
	tag_t DmlCRBTag = NULLTAG;
	char* type_name7 = NULL;
	int ik =0;
	int member_Cunt =0;
	char	*DMLRevir	=  NULL;
	char	*DMLRevirr	=  NULL;
	//char	*TOemailID	=  NULL;
	char	*TOemailID	=  NULL;
	char *DMLperson_namee			= NULL;
	char	*username	=  NULL;
	char	*DMLRELMAIL_Role	=  NULL;
	char	*groupName		=  NULL;
	tag_t   DMLRELMAIL_Role_tag		= NULLTAG;
	tag_t   DMLRELMAIL_Grp_tag		= NULLTAG;
	tag_t	DMLperson_tagg			= NULLTAG;
	tag_t   *member_tags     = NULLTAG;
	tag_t user_tag= NULLTAG;
	tag_t DMLRevuser	= NULLTAG;
	
	printf("\n tm_DML_Mail_WF_AH_Func Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DML_Mail_WF_AH_Func Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n POCHCK:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n POCHCK:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "DMLMAILD";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n POCHCK:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//ONOFF
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&DMLprintInfo1)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo1 is :[%s]\n", DMLprintInfo1);fflush(stdout);
					//DML Types considered
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&DMLprintInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo2 is :[%s]\n", DMLprintInfo2);fflush(stdout);
					//Path to call shells tm_DML_Mail.sh
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&DMLprintInfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo3 is :[%s]\n", DMLprintInfo3);fflush(stdout);
					//TO mail id
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&DMLprintInfo4)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo4 is :[%s]\n", DMLprintInfo4);fflush(stdout);
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&DMLprintInfo5)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo5 is :[%s]\n", DMLprintInfo5);fflush(stdout);
					sTOmails=(char *)MEM_alloc(500);
					tc_strcpy(sTOmails,"");
					if(DMLprintInfo4 !=NULL)
					{
						tc_strcpy(sTOmails,DMLprintInfo4);
					}
					if(DMLprintInfo5 !=NULL)
					{
						tc_strcat(sTOmails,DMLprintInfo5);
					}
					printf("\n CV:17:sTOmails: [%s]",sTOmails);fflush(stdout);

					//CC mail id
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&DMLprintInfo6)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo6 is :[%s]\n", DMLprintInfo6);fflush(stdout);
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&DMLprintInfo7)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLprintInfo7 is :[%s]\n", DMLprintInfo7);fflush(stdout);
					sCCmails=(char *)MEM_alloc(500);
					tc_strcpy(sCCmails,"");
					if(DMLprintInfo6 !=NULL)
					{
						tc_strcpy(sCCmails,DMLprintInfo6);
					}
					if(DMLprintInfo7 !=NULL)
					{
						tc_strcat(sCCmails,DMLprintInfo7);
					}
					printf("\n CV:17:sCCmails: [%s]",sCCmails);fflush(stdout);

					if(strstr(DMLprintInfo1,"PRNT001")==NULL)
					{
						sDMLrlstype=(char *)MEM_alloc(20);
						DMLType=(char *)MEM_alloc(20);
						DML_BU=(char *)MEM_alloc(30);
						ProjectID=(char *)MEM_alloc(20);
						if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(taskAttachments[i],"requestor_user_id",&ReqUserId)!=ITK_ok)PrintErrorStack();
						printf("\n CV:15:DML Number: [%s] DMLType: [%s] DML_BU:[%s] ProjectID :[%s]",DMLNo,DMLType,DML_BU,ProjectID);fflush(stdout);
						printf("\n requestor_user_id Name %s",ReqUserId);fflush(stdout);
						if(strstr(DMLprintInfo1,"PRNT006")==NULL)
						{
							//if(SA_find_user2("nkp06368", &user)!=ITK_ok)PrintErrorStack();
							printf("\n quering req id...\n");fflush(stdout);
							if(SA_find_user2(ReqUserId, &user)!=ITK_ok)PrintErrorStack();
							if(AOM_load(user)!=ITK_ok)PrintErrorStack();
							if(SA_ask_user_person_name2(user, &person_namee)!=ITK_ok)PrintErrorStack();
							if(SA_find_person2 ( person_namee, &person_tagg)!=ITK_ok)PrintErrorStack();
							if(SA_ask_person_email_address ( person_tagg, &emailID )!=ITK_ok)PrintErrorStack(); 
						}
						else
						{
							if(AOM_ask_owner(taskAttachments[i],&object_owner)!=ITK_ok)PrintErrorStack();
							if(SA_ask_user_person(object_owner,&person_tag)!=ITK_ok)PrintErrorStack();
							if(SA_ask_person_name2(person_tag,&person_name)!=ITK_ok)PrintErrorStack();
							printf("\nCreator Name %s",person_name);fflush(stdout);
							if(SA_find_user2(person_name, &user)!=ITK_ok)PrintErrorStack();
							//if(AOM_load(user)!=ITK_ok)PrintErrorStack();
							if(SA_ask_user_person_name2(user, &person_namee)!=ITK_ok)PrintErrorStack();
							if(SA_find_person2 ( person_namee, &person_tagg)!=ITK_ok)PrintErrorStack();
							if(SA_ask_person_email_address ( person_tagg, &emailID )!=ITK_ok)PrintErrorStack(); 
							//if(AOM_ask_value_string(person_tag,"fnd0AssigneeEmail",&emailID)!=ITK_ok)PrintErrorStack();
						}
						printf("\nMail ID of Manager:::: %s\n",emailID);fflush(stdout);
						tc_strcpy(sDMLrlstype,"");
						tc_strcpy(sDMLrlstype,",");
						tc_strcat(sDMLrlstype,DMLType);
						tc_strcat(sDMLrlstype,",");
						printf("\n CV:17:sDMLrlstype: [%s]",sDMLrlstype);fflush(stdout);
						if(tc_strstr(DMLprintInfo2,sDMLrlstype) != NULL)
						{
							DMLcommand = (char	*)MEM_alloc(500);
							//START
							if(strstr(DMLprintInfo1,"PRNT007")==NULL)
							{
								///user/uaprod/TC_ROOT12/bin/tml_tools/tm_DML_Mail.sh
								//1: DMLno 2:Creator 3: TOmailIds 4:subject 5: CCmail
								tc_strcpy(DMLcommand,"");
								tc_strcpy(DMLcommand,DMLprintInfo3);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								if(emailID !=NULL)
								{
									tc_strcat(DMLcommand,emailID);
									printf("\n  User mail updated.\n");fflush(stdout);
								}
								else
								{
									tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
									printf("\n NO User mail updated.\n");fflush(stdout);
								}
								//checking for TO mail ids
								
								//Group
								groupName = (char	*)MEM_alloc(100);
								tc_strcpy(groupName,"DML_Mail_Group");
								printf("\nP1:Group Name:%s\n", groupName);   fflush(stdout);
								if(SA_find_group(groupName, &DMLRELMAIL_Grp_tag)!=ITK_ok)PrintErrorStack();
								//Role
								DMLRELMAIL_Role = (char	*)MEM_alloc(100);
								//tc_strcpy(DMLRELMAIL_Role,"CoC_Brakes_Controls_Peer_PVBU");
								tc_strcpy(DMLRELMAIL_Role,ProjectID);
								tc_strcat(DMLRELMAIL_Role,"_DMLRELMAIL");
								printf("\n P2:DMLRELMAIL_Role:[%s].\n",DMLRELMAIL_Role);fflush(stdout);
								if(SA_find_role2(DMLRELMAIL_Role,&DMLRELMAIL_Role_tag)!=ITK_ok)PrintErrorStack();
								if(DMLRELMAIL_Role_tag!=NULLTAG && DMLRELMAIL_Grp_tag!=NULLTAG)
								{
									printf("\n P3:Getting role..");fflush(stdout);
									if(SA_find_groupmember_by_role(DMLRELMAIL_Role_tag,DMLRELMAIL_Grp_tag,&member_Cunt,&member_tags)!=ITK_ok)PrintErrorStack();
									printf("\n P4:No of member in role:member_Cunt  :[%d]",member_Cunt);fflush(stdout);
									if(member_Cunt>0)
									{
										for(ik=0;ik<member_Cunt;ik++)
										{	
											if(TOemailID) TOemailID=NULL;
											printf("\n P5:Reviewer no: [%d]",ik);fflush(stdout);
											if(SA_ask_groupmember_user(member_tags[ik],&user_tag)!=ITK_ok)PrintErrorStack();
								
											if(SA_ask_user_person_name2(user_tag,&username)!=ITK_ok)PrintErrorStack();
											printf("\n P6:Personname = [%s]",username);fflush(stdout);
											if(SA_find_person2 ( username, &person_tagg)!=ITK_ok)PrintErrorStack();
											if(SA_ask_person_email_address ( person_tagg, &TOemailID )!=ITK_ok)PrintErrorStack();
											printf("\n P7:TOemailID = [%s]",TOemailID);fflush(stdout);
											if (ik ==0)
											{
												printf("..First..");fflush(stdout);
												tc_strcat(DMLcommand," ");
												tc_strcat(DMLcommand,sTOmails);
												if(TOemailID !=NULL)
												{
													tc_strcat(DMLcommand,",");
													tc_strcat(DMLcommand,TOemailID);
												}
											}
											else
											{
												printf("\n P8:TOemailID = [%s]",TOemailID);fflush(stdout);
												if(TOemailID !=NULL)
												{
													tc_strcat(DMLcommand,",");
													tc_strcat(DMLcommand,TOemailID);
												}
											}
										}
									}
									else
									{
										printf("\n P9:sTOmails = [%s]",sTOmails);fflush(stdout);
										tc_strcat(DMLcommand," ");
										tc_strcat(DMLcommand,sTOmails);
									}
								}
								else
								{
									printf("\n P10:sTOmails = [%s]",sTOmails);fflush(stdout);
									tc_strcat(DMLcommand," ");
									tc_strcat(DMLcommand,sTOmails);
								}
								//tc_strcat(DMLcommand," ");
								//tc_strcat(DMLcommand,sTOmails);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,sCCmails);
								//For CC managers.
								if(strstr(DMLprintInfo1,"PRNT008")==NULL)
								{
									if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
									if (dml_CRB_rel_type!=NULLTAG)
									{
										printf("\n P11:inside HasParticipant.. \n");fflush(stdout);
										if(GRM_list_secondary_objects_only(taskAttachments[i],dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
										printf("\n P12: DmlCRB count: %d",CRBcount);fflush(stdout);
										for (jk=0;jk<CRBcount ;jk++ )
										{
											//printf("\n TASK:jk: %d.\n",jk);fflush(stdout);
											DmlCRBTag = DmlCRB[jk];
											if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
											if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
											//printf("\n TASK:DML: type_name7 :: %s.", type_name7);fflush(stdout);
											if (strcmp(type_name7,"ChangeReviewBoard")==0)
											{
												if(RevemailID) RevemailID=NULL;
												if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
												if(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMLReviewGrp)!=ITK_ok)PrintErrorStack();
												printf("\n P13: DML Reviewer: [%s] Group: [%s] ",DMLReviewr,DMLReviewGrp);fflush(stdout);
												DMLRevir = strtok( DMLReviewr, "(" );
												printf("\n P14:DML Rev id.: %s\n",DMLRevir);fflush(stdout);
												DMLRevirr	  = strtok ( NULL, ")" );
												printf("\n DML Rev id.: %s\n",DMLRevirr);fflush(stdout);
												if(SA_find_user2(DMLRevirr, &DMLRevuser)!=ITK_ok)PrintErrorStack();
												if(AOM_load(DMLRevuser)!=ITK_ok)PrintErrorStack();
												if(SA_ask_user_person_name2(DMLRevuser, &DMLperson_namee)!=ITK_ok)PrintErrorStack();
												if(SA_find_person2 ( DMLperson_namee, &DMLperson_tagg)!=ITK_ok)PrintErrorStack();
												if(SA_ask_person_email_address ( DMLperson_tagg, &RevemailID )!=ITK_ok)PrintErrorStack(); 
												printf("\n DML Rev EmailID id.: %s\n",RevemailID);fflush(stdout);
												if(RevemailID !=NULL)
												{
													tc_strcat(DMLcommand,",");
													tc_strcat(DMLcommand,RevemailID);
												}
											}
											/*if (strcmp(type_name7,"T5_DMUReviewer")==0)
											{
												if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMUReviewr)!=ITK_ok)PrintErrorStack();
												if(AOM_UIF_ask_value(DmlCRBTag,"assignee",&DMUReviewGrp)!=ITK_ok)PrintErrorStack();
												printf("\n P14: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
											}*/
										}
									}
								}
								//printf("\n P15: DMLReviewr: [%s]	DMUReviewr: [%s]  \n", DMLReviewr,DMUReviewr);fflush(stdout);
								//tc_strcat(DMLcommand," ");
								//tc_strcat(DMLcommand,sCCmails);
								if(emailID !=NULL)
								{
									tc_strcat(DMLcommand,",");
									tc_strcat(DMLcommand,emailID);
									printf("\n  User CC mail updated.\n");fflush(stdout);
								}
								printf("\n ASSIGN::DMLcommand: %s",DMLcommand);fflush(stdout);
								TC_write_syslog("DMLcommand = %s\n",DMLcommand);
								system(DMLcommand);
								printf("\n ASSIGN:A:Reviewers set successfully.. \n");fflush(stdout);
							}
							//END
							else if(strstr(DMLprintInfo1,"PRNT005")==NULL)
							{
								///user/uaprod/TC_ROOT12/bin/tml_tools/tm_DML_Mail.sh
								//1: DMLno 2:Creator 3: TOmailIds 4:subject 5: CCmail
								tc_strcpy(DMLcommand,"");
								tc_strcpy(DMLcommand,DMLprintInfo3);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								if(emailID !=NULL)
								{
									tc_strcat(DMLcommand,emailID);
									printf("\n  User mail updated.\n");fflush(stdout);
								}
								else
								{
									tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
									printf("\n NO User mail updated.\n");fflush(stdout);
								}
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,sTOmails);
								//START
								if(emailID !=NULL)
								{
									tc_strcat(DMLcommand,",");
									tc_strcat(DMLcommand,emailID);
									printf("\n  User mail updated.\n");fflush(stdout);
								}
								//END
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,sCCmails);
								printf("\n ASSIGN::DMLcommand: %s",DMLcommand);fflush(stdout);
								/*tc_strcpy(DMLcommand,"");
								tc_strcpy(DMLcommand,"/user/testcmi/Dev/devgroups/mohan/Report/tm_DML_MailD/tm_DML_MailSH.sh");
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,"mohant.ttl@tatamotors.com");
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,DMLNo);
								tc_strcat(DMLcommand," ");
								tc_strcat(DMLcommand,"as925914.ttl@tatamotors.com");
								printf("\n ASSIGN::DMLcommand: %s",DMLcommand);fflush(stdout);*/
								//sprintf(DMLcommand,"/user/uaprod/shells/DMLWF/tm_DML_Mail.sh %s ",DMLNo);
								TC_write_syslog("DMLcommand = %s\n",DMLcommand);
								system(DMLcommand);
								printf("\n ASSIGN:A:Reviewers set successfully.. \n");fflush(stdout);
							}
							else if(strstr(DMLprintInfo1,"PRNT002")==NULL)
							{
								sprintf(DMLcommand,"/user/uaprod/TC_ROOT12/bin/tml_tools/tm_DML_Mail.sh %s ",DMLNo);
								TC_write_syslog("Command = %s\n",DMLcommand);
								system(DMLcommand);

							}
							else if(strstr(DMLprintInfo1,"PRNT003")==NULL)
							{
								sprintf(DMLcommand,"/user/testcmi/Dev/devgroups/mohan/Report/tm_DML_Mail_AH/tm_DML_Mail.sh %s ",DMLNo);
								TC_write_syslog("Command = %s\n",DMLcommand);
								system(DMLcommand);
							}
							else if(strstr(DMLprintInfo1,"PRNT004")==NULL)
							{
								sprintf(DMLcommand,"/home/uadev/devgroups/mohan/test/tm_DML_Mail.sh %s ",DMLNo);
								TC_write_syslog("Command = %s\n",DMLcommand);
								system(DMLcommand);
							}
							else
							{
								printf("\n POCHCK:Other client.. \n");fflush(stdout);
							}
						}
					}
				}
			}
		}
	}
    printf("\n tm_DML_Mail_WF_AH_Func Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DML_Mail_WF_AH_Func Function started...");
	//return error_code;
	return 0;
}