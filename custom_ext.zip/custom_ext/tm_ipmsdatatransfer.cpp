#include <iostream>
#include <tcinit/tcinit.h>
//#include <base_utils/IFail.hxx>
//#include <base_utils/TcResultStatus.hxx>
//#include <base_utils/ScopedSmPtr.hxx>
//#include <Error_Exception.hxx>
#include <tccore/aom.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <epm/epm_task_template_itk.h>
#include <iostream>
#include <sstream>
#include <fstream>  
#include <vector>
#include <map>
#include <string>
#include <typeinfo>
#include <unistd.h>
using namespace std;
#define ITK_err 919006
#define ITK_errStore1 (EMH_USER_error_base + 7)
#include <iostream>
#include <string>
#include "MppFunctionFile.cpp"
struct partSapDetails
{

    string line;
    string station;
    string opid;
    string opdescription;
    string partNumber;
    string designrevid;
    string designdesc;
    string traceanddtrake;
    string barrcode;
    string criticalemisionnd;
    string quantity;
    string cs;
};
vector<partSapDetails> lineExpandMap(string IstemID , char *types,char *attributename)
{

    vector<partSapDetails> childpartlist;
    //multimap<string,string> StationPartMap;
    cout << "Inside Plant BOP Vector................ "  << "\n";

    tag_t lineBOM=NULLTAG;
    tag_t stationBOM=NULLTAG;
    tag_t operationBOM=NULLTAG;
    int stationcount=0;
    int operationcount=0;
    int childpartcount=0;
    tag_t  *stationstag=NULLTAG;
    tag_t  *operationtag=NULLTAG;
    tag_t  *childparttag=NULLTAG;
    char *StationID=NULL;
    char *operationID=NULL;
    char *designRevisionID=NULL;
    char *Stationtype=NULL;
    char *operationtype=NULL;

    lineBOM = GetBomLine(IstemID,types);
    BOM_line_ask_child_lines(lineBOM, &stationcount, &stationstag);
    if(stationcount>0)
    {
        for (int c=0;c<stationcount;c++)
        {
            AOM_ask_value_string(stationstag[c],"bl_rev_awp0Item_item_id",& StationID);
            cout << "Station Item ID:-" << StationID<<endl;
            //AOM_ask_value_string(stationstag[c],"bl_item_object_type",& Stationtype);
            //cout << "Child Item ID:-" << Stationtype<<endl;
            //StationList.push_back(StationID);
            string stringstationID =StationID;

            Stationtype ="Mfg0MEProcStatnRevision";

            stationBOM = GetBomLine(stringstationID,Stationtype); 
            BOM_line_ask_child_lines(stationBOM, &operationcount, &operationtag);
            if(operationcount>0)
            {
                for(int d=0;d<operationcount;d++)
                {
                    AOM_ask_value_string(operationtag[d],"bl_rev_awp0Item_item_id",& operationID);
                    cout << "Operation ID...:-" << operationID<<endl;
                    //AOM_ask_value_string(operationtag[d],"bl_item_object_type",& operationtype);
                    //cout << "Child Item ID:-" << operationtype<<endl;
                    string stringoprationID =operationID;
                    //operationlist.push_back(operationID);
                    operationtype ="MEOPRevision";

                    operationBOM = GetBomLine(stringoprationID,operationtype); 
                    BOM_line_ask_child_lines(operationBOM, &childpartcount, &childparttag);
                    if(childpartcount>0)
                    {
                        for(int childpartIteratior=0;childpartIteratior<childpartcount;childpartIteratior++)
                        {
                            char* Qty = NULL;
                            char* plantcs =NULL;
                            AOM_ask_value_string(childparttag[childpartIteratior],"bl_rev_awp0Item_item_id",& designRevisionID);
                            cout << "Part ID under opertaions ...:-" << designRevisionID<<endl;
                            AOM_ask_value_string(childparttag[childpartIteratior],"bl_quantity",&Qty);
                            cout << "Part qty under opertaions ...:-" << Qty<<endl;
                            AOM_ask_value_string(childparttag[childpartIteratior],attributename,&plantcs);
                            cout << "Part qty under opertaions ...:-" << Qty<<endl;
                            string stringQty = Qty;
                            string stringPartId = designRevisionID;
                            string stringCs =plantcs;
                            //designrevisionlist.push_back(designRevisionID);
                            cout << "Printing in Map "<< endl;
                            cout << "stringstationID : " << stringstationID << " stringPartId : " << stringPartId << endl;
                            //StationPartMap.insert({stringstationID,stringPartId});
                            childpartlist.push_back(
                                {
                                    IstemID,
                                    stringstationID,
                                    designRevisionID,
                                    stringQty,
                                    stringCs
                                }
                            );
                        }
                        
                    }

                }
            
            }
        }
    }
    
    
    return childpartlist;

}
extern int IPMSDatatransferservice(void *return_data)
{

    int ifail =0;
    char 			*bookabledesignrev	=	NULL;
    char 			*lindeID	=	NULL;
    tag_t QueryTag = NULLTAG;
    vector<string> bookablepartlist; //Bookable BOM List
    multimap<string,string> StationPartMapreturn;
    USERARG_get_string_argument(&bookabledesignrev);
    USERARG_get_string_argument(&lindeID);
    string stringBookableId;


    cout << "Bookable Design Rev is : " << bookabledesignrev << endl; //Bookable Design Rev is : 29006300M10130_SE10001_56506005928/B;2/29006300M10130_SE
    cout << "Line ID is : " << lindeID << endl; //Line ID is : 1001CHA01Line/A;1

    QRY_find2("Control Objects...",&QueryTag);
    if(QueryTag!=NULL)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="mpptoipms";
        Valuesp[1]="mpptoipms";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;

        QRY_execute(QueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp>0)
        {
            char *shelfilelocation=NULL;
            //string Command[200];
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo3",&shelfilelocation);
            cout << "Value of control object 3:- ..........." <<shelfilelocation<< endl;
            string info3 =shelfilelocation;
            string strbookable =bookabledesignrev;
            string s1 =strbookable ;
              
            string stringline=lindeID;
            string s2 = stringline;
            string s3 = " \"" + s1 +" " + s2 + "\"";
            
           // string command =info3 +" """+strbookable+"\" \""+stringline +"\"";
            string command =info3 +s3;
            cout << "Command:- ..........." <<command<< endl;
            int returnCode = system(command.c_str());
            if (returnCode == -1)
            {
                cout << "Command not execuated:- ..........." <<command<< endl;
                    
            } else
            {
                 
                cout << "Command returned: " << returnCode << "\n";
            }

            return 0;



        }
     
        else
        {
             cout << "No control object found for IPMS Data Trnasfer..........." << endl;

        }
    }
    
    return ifail;
}
extern int tm_ipmsdatatransfer_register_method(int *decision, va_list args)
{
     cout << "Welcome to IPMS Data Transfer...."<< endl;
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    int nargs = 2;
    int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
    inputArgTypes[0] = USERARG_STRING_TYPE; //Bookabledesignrev
	inputArgTypes[1] = USERARG_STRING_TYPE; //LineID
    int retValueType;
    retValueType = USERARG_STRING_TYPE ; 
    cout << "Before service call IPMSDatatransferservice"<< endl;
    ifail= USERSERVICE_register_method("IPMSDatatransferservice",(USER_function_t)IPMSDatatransferservice,nargs,inputArgTypes,retValueType);
 
    return 0;
}

extern "C" DLLAPI int tm_ipmsdatatransfer_register_callbacks()
{
    cout << "Before registered ipmstransfer function in MPP"<< endl;
    CUSTOM_register_exit("tm_ipmsdatatransfer", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t) tm_ipmsdatatransfer_register_method);
    cout << "registered function tm_MPP_assign"<< endl;
    return 0;
}