//@<COPYRIGHT>@
//==================================================
//Copyright $2024.

//Siemens Product Lifecycle Management Software Inc.

//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_RFIPPPMPrjCodeLovBOImpl
//

#include <T5_RFISORCODEFL/T5_RFIPPPMPrjCodeLovBOImpl.hxx>

#include <fclasses/tc_string.h>
//#include <tc/tc.h>
//-----
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <cstring>
#include <iostream>
//---
using namespace std;
using namespace TRL001;

#define PLM_error1 (EMH_USER_error_base+26)

//----------------------------------------------------------------------------------
// T5_RFIPPPMPrjCodeLovBOImpl::T5_RFIPPPMPrjCodeLovBOImpl(T5_RFIPPPMPrjCodeLovBO& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_RFIPPPMPrjCodeLovBOImpl::T5_RFIPPPMPrjCodeLovBOImpl( T5_RFIPPPMPrjCodeLovBO& busObj )
   : T5_RFIPPPMPrjCodeLovBOGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_RFIPPPMPrjCodeLovBOImpl::~T5_RFIPPPMPrjCodeLovBOImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_RFIPPPMPrjCodeLovBOImpl::~T5_RFIPPPMPrjCodeLovBOImpl()
{
}

//----------------------------------------------------------------------------------
// T5_RFIPPPMPrjCodeLovBOImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_RFIPPPMPrjCodeLovBOImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_RFIPPPMPrjCodeLovBOGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

//----------------------------------------------------------------------------------
//this function is used to list pppm for selected vertical only
//----------------------------------------------------------------------------------
int Get_RFISor_PPPM_prjCode(const char *Vertical,int* count, tag_t** items)
{
	int ifail = ITK_ok;
	tag_t Query=NULLTAG;

	int nOne = 1;
	int nCount = 0;
	char* one_attr[1] = {(char *)"Vertical"};//t5_Brletc1
	char    *one_values[] = {(char *)Vertical};
	tag_t *nTags = NULLTAG;
	*count = 0;
	int i=0;

	TC_write_syslog("\n\nGet_DummySor_PPPM_prjCode::Vertical : [%s]\n",Vertical);
	printf("\n\nGet_DummySor_PPPM_prjCode::Vertical : [%s]\n",Vertical);

	QRY_find2("SOR_Vertical", &Query);

	if (Query)
	{
			QRY_execute(Query, nOne, one_attr, one_values, &nCount, &nTags);
			TC_write_syslog("\n\nGet_DummySor_PPPM_prjCode::nCount : [%d] \n",nCount);
			printf("\n\nGet_DummySor_PPPM_prjCode::nCount : [%d] \n",nCount);
			TC_write_syslog("\n\nGet_DummySor_PPPM_prjCode::Rows : [%s] [%d]\n",Vertical,nCount);
			printf("\n\nGet_DummySor_PPPM_prjCode::Rows : [%s] [%d]\n",Vertical,nCount);

			*count = nCount;

			TC_write_syslog("\n\nGet_DummySor_PPPM_prjCode::Rows VAL : [%d]\n",*count);
			printf("\n\nGet_DummySor_PPPM_prjCode::Rows VAL : [%d]\n",*count);

			(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
			for(i=0;i<*count;i++)
			{
					(*items)[i] = nTags[i];
			}
	}


	return ifail;
}

///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_RFIPPPMPrjCodeLovBOImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
	int ifail = ITK_ok;
	std::string VerticalRetValue;
	bool isNull1 = false ;
	int error_flag = 0;
	char *ErrorMessage = NULL;

	TC_write_syslog("\nRFIPPPMPrjCode askLOV");
	printf("\nRFIPPPMPrjCode askLOV");

	ErrorMessage = (char *) MEM_alloc ( 300 ) ;
	if ( JOURNAL_is_journaling() )
	{
		JOURNAL_routine_start ( "T5_DummyPPPMPrjCodeLovBOImpl::fnd0askLOVValuesBase" ) ;
		JOURNAL_routine_call ( ) ;
	}


    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation
    try{

		Teamcenter::OperationInput* refOpnInput = dynamic_cast < Teamcenter::OperationInput *> (Teamcenter::BusinessObjectRegistry::instance().getObject(operationInputTag));
		if (refOpnInput != NULL )
		{
			refOpnInput->getString("t5_RfiVerticle", VerticalRetValue, isNull1);
			tc_strcpy(ErrorMessage,"Please select Required Field from drop down ");

			cout<< "\nVerticalRetValue : " << VerticalRetValue;
			TC_write_syslog("\nVerticalRetValue : [%s]",VerticalRetValue.c_str());
			if (isNull1 == true )
			{
				error_flag++;
				tc_strcat(ErrorMessage," - Vertical (ProductLine)");
			}
			TC_write_syslog("\nerror_flag : [%d] [%s]\n",error_flag,ErrorMessage);
			printf("\nerror_flag : [%d] [%s]\n",error_flag,ErrorMessage);

			if ( error_flag > 0 )
			{
				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message : ",ErrorMessage);
				(*results) = NULLTAG ;
				*nResults = 0 ;
				return(PLM_error1);
			}
			if ( error_flag == 0 )
			{
				TC_write_syslog("\nlist Vertical : [%s] >>\n",VerticalRetValue.c_str());
				printf("\nlist Vertical : [%s] >>\n",VerticalRetValue.c_str());
				(*results) = NULLTAG;
				*nResults = 0;
				(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
				Get_RFISor_PPPM_prjCode(VerticalRetValue.c_str(),nResults, results);

			}
		}

	}
	catch (IFail& ex )
	{
		ifail = ex.ifail();
	}
    return ifail;
}
