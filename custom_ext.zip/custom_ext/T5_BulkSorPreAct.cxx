//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension T5_BulkSorPreAct
 *
 */
#include <T5_tm_bulkPPPMPrjCodelib/T5_BulkSorPreAct.hxx>
//#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
//#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <tccore/releasestatus.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include<iostream>
#include <res/res_itk.h>
#include <tccore/aom.h>

#define ITK_err 919002
#define PLM_error1 (EMH_USER_error_base+26)
using namespace Teamcenter;

int tm_check_info_control_object_BulkSorPreAct ( char *syscd, char *subsyscd)
{
	int ifail = ITK_ok;
	int n_found = 0 ;
	int n_entries = 2 ;
	char  *qry_entries[] = {(char *)"SYSCD",(char *)"SUBSYSCD"};
	char  *qry_values[] = {(char *)syscd,(char *)subsyscd};
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	//char *l_info1 = NULL ;
	//char *l_info2 = NULL ;

	ifail =  ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ifail =  ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\ntm_check_info_control_object [%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	//if ( n_found > 0 )
	//{
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
	//	tc_strcpy( info1, l_info1 );
	//	ifail =  ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
	//	tc_strcpy( info2, l_info2 );
	//
	//	printf ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//	TC_write_syslog ( "\ntm_check_info_control_object info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	//}

	return n_found ;
}


int removeAllReleaseStatus(tag_t objTag)
{

	int status_count;
	tag_t* status_list;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	printf ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;
	TC_write_syslog ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;

	ifail = (WSOM_ask_release_status_list(objTag,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		ifail =(POM_class_of_instance(objTag,&class_id));
		ifail =(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		ifail =(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		ifail =(POM_unload_instances (1,&objTag));
		ifail =(POM_load_instances(1,&objTag,class_id,1));
		ifail =(POM_is_loaded(objTag,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		ifail =( POM_length_of_attr(objTag, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			ifail =( POM_ask_attr_tags(objTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				ifail =(POM_remove_from_attr(1,&objTag,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				ifail =(POM_save_instances(1,&objTag,1));

				ifail =(POM_refresh_instances(1,&objTag,class_id,2));

				//ifail =(AOM_lock(objTag));
				ifail =(AOM_refresh(objTag,TRUE));

				ifail =(AOM_save_without_extensions(objTag));
				ifail =(AOM_refresh(objTag,FALSE));

			}

			//ifail =(AOM_unlock(objTag));
		}
		printf("\n Status removed");;fflush(stdout);
	}
	return (ifail);
}


int qSOR_create_Funct (tag_t Part_Tag,const char *Bulkprjcode,const char *BulkPPPMprjcode,char *qSORPart_no, char *qSORPart_Rev, char *qSORPart_Seq, char *qSORPart_Desc, char *qSORPart_ClrInd, char *qSORPart_Cat)
{

	printf("\n....Inside qSOR_create_Funct qSOR_no....");
	TC_write_syslog("\n....Inside qSOR_create_Funct qSOR_no....");

	int ifail = ITK_ok;

	char *qSOR_no = NULL;
	qSOR_no = (char*)MEM_alloc(50*sizeof(char));
	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	tag_t rel_status_SOR		   = NULLTAG;
	logical retain_released_date_SOR = TRUE;
	tag_t latestqSorrev = NULLTAG;
	tag_t PrtRelationFind = NULLTAG;
	tag_t PartSorRelTag = NULLTAG;
	int n_found_qSORNAME = 0;

	tag_t queryTag = NULLTAG;
	char *qry_entries[] = {(char *)"Item ID",(char *)"Type"};
	int n_entries = 2;
	int resultCount = 0;
	tag_t *QSORObjs = NULLTAG;

	n_found_qSORNAME = tm_check_info_control_object_BulkSorPreAct ( (char *) "qSORNAME",(char *) "ON");
	if ( n_found_qSORNAME > 0 )
	{
		tc_strcpy(qSOR_no,"qSOR_");
	}
	else
	{
		tc_strcpy(qSOR_no,"SOR_");
	}
	tc_strcat(qSOR_no,qSORPart_no);
	tc_strcat(qSOR_no,"_");
	tc_strcat(qSOR_no,qSORPart_Rev);


	tag_t tItemTag = NULLTAG ;
	tag_t tRevTypeTag = NULLTAG ;
	tag_t tItemTypeTag = NULLTAG ;
	tag_t tItemCreateInputTag = NULLTAG ;
	tag_t tRevCreateInputTag  = NULLTAG ;

	char *qry_values[] = {(char *)qSOR_no,(char *)"T5_quicksorRevision"};
	ifail =(QRY_find2("Item Revision...", &queryTag));

	if (queryTag)
	{
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &QSORObjs));
		printf("\nQuick SOR count : [%d]",resultCount);
		TC_write_syslog("\nQuick SOR count : [%d]",resultCount);

		if ( resultCount <= 0 )
		{
			printf("\nqSOR_create_Funct qSOR_no : [%s]",qSOR_no);
			TC_write_syslog("\nqSOR_create_Funct qSOR_no : [%s]",qSOR_no);
			printf("\nqSOR_create_Funct qSORPart_no : [%s]",qSORPart_no);
			TC_write_syslog("\nqSOR_create_Funct qSORPart_no : [%s]",qSORPart_no);
			printf("\nqSOR_create_Funct qSORPart_Seq : [%s]",qSORPart_Seq);
			TC_write_syslog("\nqSOR_create_Funct qSORPart_Seq : [%s]",qSORPart_Seq);
			printf("\nqSOR_create_Funct qSORPart_Desc : [%s]",qSORPart_Desc);
			TC_write_syslog("\nqSOR_create_Funct qSORPart_Desc : [%s]",qSORPart_Desc);
			printf("\nqSOR_create_Funct Bulkprjcode : [%s]",Bulkprjcode);
			TC_write_syslog("\nqSOR_create_Funct Bulkprjcode : [%s]",Bulkprjcode);
			printf("\nqSOR_create_Funct BulkPPPMprjcode : [%s]",BulkPPPMprjcode);
			TC_write_syslog("\nqSOR_create_Funct BulkPPPMprjcode : [%s]",BulkPPPMprjcode);
			printf("\nqSOR_create_Funct qSORPart_ClrInd : [%s]",qSORPart_ClrInd);
			TC_write_syslog("\nqSOR_create_Funct qSORPart_ClrInd : [%s]",qSORPart_ClrInd);
			printf("\nqSOR_create_Funct qSORPart_Cat : [%s]",qSORPart_Cat);
			TC_write_syslog("\nqSOR_create_Funct qSORPart_Cat : [%s]",qSORPart_Cat);

			ifail = ( TCTYPE_find_type ( "T5_quicksorRevision", "T5_quicksorRevision", &tRevTypeTag ) ) ;
			ifail = ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;

			ifail = ( TCTYPE_find_type ( "T5_quicksor", "T5_quicksor", &tItemTypeTag ) ) ;
			ifail = ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;

			ifail = ( AOM_set_value_string ( tItemCreateInputTag, "item_id", qSOR_no ) ) ;
			ifail = ( AOM_set_value_string ( tItemCreateInputTag, "object_name", qSOR_no ) ) ;
			ifail = ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;

			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartNumber", qSORPart_no ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartRevision", qSORPart_Rev ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartSeq", qSORPart_Seq ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSORPartDesc", qSORPart_Desc ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qBarrelCode", Bulkprjcode ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPPPMPrjCode", BulkPPPMprjcode ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPrtClrInd", qSORPart_ClrInd ) ) ;
			ifail = ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPrtCat", qSORPart_Cat ) ) ;

			ifail = ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
			ifail = ( AOM_refresh ( tItemTag, TRUE ) ) ;
			ifail = ( AOM_save_without_extensions ( tItemTag ) ) ;
			ifail = ( AOM_refresh ( tItemTag, FALSE ) ) ;

			ifail = ( ITEM_ask_latest_rev ( tItemTag, &latestqSorrev ) ) ;

			ifail = ( RES_checkout2 ( latestqSorrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//check-out qSOR


			removeAllReleaseStatus(latestqSorrev);
			printf("\nGoing to ERC Working  on SOR....");fflush(stdout);
			ifail = (RELSTAT_create_release_status ("T5_LcsWorking",&rel_status_SOR));
			ifail = (RELSTAT_add_release_status(rel_status_SOR,1,&latestqSorrev ,retain_released_date_SOR));
			printf("\nERC Working stamping on SOR....");fflush(stdout);
			TC_write_syslog("\nERC Working stamping on SOR....");fflush(stdout);


			ifail = ( GRM_find_relation_type ( "T5_PartSorRel", &PrtRelationFind ) ) ;

			if (PrtRelationFind != NULLTAG)
			{
				printf("\nqSOR_create_Funct T5_PartSorRel PrtRelationFind found");fflush(stdout);
				TC_write_syslog("\nqSOR_create_Funct T5_PartSorRel PrtRelationFind found");

				if (Part_Tag != NULLTAG )
				{
					printf("\nqSOR_create_Funct Part_Tag found");fflush(stdout);
					TC_write_syslog("\nqSOR_create_Funct Part_Tag found");
					ifail = ( GRM_create_relation ( Part_Tag, latestqSorrev, PrtRelationFind, NULLTAG, &PartSorRelTag ) ) ;
					ifail = ( GRM_save_relation ( PartSorRelTag ) ) ;
					ifail = ( AOM_refresh ( Part_Tag,0 ) );
					printf("\nqSOR_create_Funct qSOR [%s] and  part [%s] relation created successfully\n",qSOR_no, qSORPart_no );fflush(stdout);
					TC_write_syslog("\nqSOR_create_Funct qSOR [%s] and  part [%s] relation created successfully\n",qSOR_no, qSORPart_no );
				}

			}
		}
		else
		{
			printf("\nQuick SOR already exist : [%s]",qSOR_no);
			TC_write_syslog("\nQuick SOR already exist : [%s]",qSOR_no);
		}
	}
	else
	{
		printf("\nQuery not found Item Revision...");
		TC_write_syslog("\nQuery not found Item Revision...");
	}

	return ifail;

}



int Get_Part_Details(const char *Bulkprjcode,const char *BulkPPPMprjcode,char *partno,char *Rev,char *Seq)
{

	printf("\n....Inside Get_Part_Details....");
	TC_write_syslog("\n....Inside Get_Part_Details....");

	int ifail = ITK_ok;
	int n_entries = 2;
	int resultCount = 0;
	int n_found_DRW_IND = 0 ;

	char *qSORPart_no = NULL;
	char *qSORPart_RevSeq = NULL;
	char *qSORPart_Desc = NULL;
	char *qSORPart_ClrInd = NULL;
	char *qSORPart_Drwind = NULL;
	char *qSORPart_Cat = NULL;
	char *qSORPart_Rev = NULL;
	char *qSORPart_Seq = NULL;
	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};
	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(5*sizeof(char));
	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);
	char *qry_values[] = {(char *)partno,(char *)RevSeq};
	char *PrtErrorMessage = NULL;

	PrtErrorMessage = (char *)MEM_alloc(200*sizeof(char));


	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;
	tag_t Part_Tag = NULLTAG;


	printf("\nGet_Part_Details Quering Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);
	TC_write_syslog("\nGet_Part_Details Quering Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{

		printf("\nGet_Part_Details Unique RevSeq Query found");
		TC_write_syslog("\n Get_Part_Details Unique RevSeq Query found");
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
		printf("\nGet_Part_Details Part Count in TCUA : [%d]",resultCount);
		TC_write_syslog("\nGet_Part_Details Part Count in TCUA : [%d]",resultCount);

		if ( resultCount > 0)
		{

			Part_Tag = partObjs[0];

			ifail = ( AOM_ask_value_string ( Part_Tag, "item_id", &qSORPart_no ) ) ;
			printf("\nGet_Part_Details qSORPart_no : [%s]", qSORPart_no);
			TC_write_syslog("\nGet_Part_Details qSORPart_no : [%s]", qSORPart_no);

			ifail = ( AOM_ask_value_string ( Part_Tag, "item_revision_id", &qSORPart_RevSeq ) ) ;
			printf("\nGet_Part_Details qSORPart_RevSeq : [%s]", qSORPart_RevSeq);
			TC_write_syslog("\nGet_Part_Details qSORPart_RevSeq : [%s]", qSORPart_RevSeq);

			qSORPart_Rev = strtok(qSORPart_RevSeq,";");
			qSORPart_Seq = strtok(NULL,"");

			printf("\nGet_Part_Details qSORPart_Rev : [%s]", qSORPart_Rev);
			TC_write_syslog("\nGet_Part_Details qSORPart_Rev : [%s]", qSORPart_Rev);

			printf("\nGet_Part_Details qSORPart_Seq : [%s]", qSORPart_Seq);
			TC_write_syslog("\nGet_Part_Details qSORPart_Seq : [%s]", qSORPart_Seq);

			ifail = ( AOM_ask_value_string ( Part_Tag, "object_desc", &qSORPart_Desc ) ) ;
			printf("\nGet_Part_Details qSORPart_Desc : [%s]", qSORPart_Desc);
			TC_write_syslog("\nGet_Part_Details qSORPart_Desc : [%s]", qSORPart_Desc);

			ifail = ( AOM_ask_value_string ( Part_Tag, "t5_ColourInd", &qSORPart_ClrInd ) ) ;
			printf("\nGet_Part_Details qSORPart_ClrInd : [%s]", qSORPart_ClrInd);
			TC_write_syslog("\nGet_Part_Details qSORPart_ClrInd : [%s]", qSORPart_ClrInd);

			ifail = ( AOM_ask_value_string ( Part_Tag, "t5_SpareCriteria", &qSORPart_Cat  ) ) ;
			printf("\nGet_Part_Details qSORPart_Cat : [%s]", qSORPart_Cat);
			TC_write_syslog("\nGet_Part_Details qSORPart_Cat : [%s]", qSORPart_Cat);
			
			//Shubham Added below check regarding Drawing indcator D or A on 29-Jan-2025 
			ifail = ( AOM_ask_value_string ( Part_Tag, "t5_DrawingInd", &qSORPart_Drwind  ) ) ;
			printf("\nGet_Part_Details qSORPart_Drwind : [%s]", qSORPart_Drwind);
			TC_write_syslog("\nGet_Part_Details qSORPart_Drwind : [%s]", qSORPart_Drwind);

			//n_found_DRW_IND = tm_check_info_control_object_BulkSorPreAct ( "QSORDRWIND", qSORPart_Drwind );//valid drawing ind
			n_found_DRW_IND = tm_check_info_control_object_BulkSorPreAct ( (char *) "QSORDRWIND",qSORPart_Drwind);//valid drawing ind
			if ( n_found_DRW_IND <= 0 )//drawing indicator not found in control object
			{
//				if (Part_Tag > 0)
//				{
//
//					Part_Tag ++;
//					tc_strcat(PrtErrorMessage,qSORPart_no);
//					tc_strcat(PrtErrorMessage,",");
//
//				}	
//				//MEM_free(qSORPart_RevSeq);
				printf ( "\thence skipping QSOR creation drawing indicator" ) ; fflush ( stdout) ;
				TC_write_syslog ( "\thence skipping QSOR creation drawing indicator" ) ;
//				EMH_clear_errors();
//				EMH_store_error_s2(EMH_severity_warning,ITK_err,"For QuickSOR Creation Drawing indicator should be D or A for part : ",PrtErrorMessage);
//				return ITK_err;
				return 1;
			}
			else
			{
				printf("\nGet_Part_Details qSOR_create_Funct......");
				TC_write_syslog("\nGet_Part_Details qSOR_create_Funct");
				
				qSOR_create_Funct(Part_Tag,Bulkprjcode,BulkPPPMprjcode,qSORPart_no,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);
				return 0;
			}
			//end 
			//printf("\nGet_Part_Details qSOR_create_Funct......");
			//TC_write_syslog("\nGet_Part_Details qSOR_create_Funct");
			//qSOR_create_Funct(Part_Tag,Bulkprjcode,BulkPPPMprjcode,qSORPart_no,qSORPart_Rev,qSORPart_Seq,qSORPart_Desc,qSORPart_ClrInd,qSORPart_Cat);


		}

	}

	return 0;

}

int BulkSorPreAct_PrtQuery_function_SOR (char *partno,char *Rev,char *Seq)
{
	printf("\n....Inside BulkSorPreAct_PrtQuery_function_SOR....");
	TC_write_syslog("\n....Inside BulkSorPreAct_PrtQuery_function_SOR....");

	int ifail = ITK_ok;
	int n_entries = 2;
	int i = 0;
	int resultCount = 0;
	int SORCount = 0;
	int SORflag = 0;

	char *SOR_object_type = NULL;
	char *SOR_no = NULL;
	char *qry_entries[] = {(char *)"Item ID",(char *)"Revision"};
	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(5*sizeof(char));
	tc_strcpy(RevSeq,Rev);
	tc_strcat(RevSeq,"*");
	tc_strcat(RevSeq,Seq);
	char  *qry_values[] = {(char *)partno,(char *)RevSeq};

	tag_t queryTag = NULLTAG;
	tag_t *partObjs = NULLTAG;
	tag_t *SOR_Objects = NULLTAG;
	tag_t PartTag = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t SOR_Tag = NULLTAG;

	printf("\nBulkSorPreAct_PrtQuery_function_SOR Querying Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);
	TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR Querying Part no [%s] Rev [%s] Seq [%s]",partno,Rev,Seq);

	ifail =(QRY_find2("Unique RevSeq", &queryTag));

	if (queryTag)
	{
		printf("\nBulkSorPreAct_PrtQuery_function_SOR Unique RevSeq Query found");
		TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR Unique RevSeq Query found");
		ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));

		printf("\nBulkSorPreAct_PrtQuery_function_SOR Part Count in TCUA : [%d]",resultCount);
		TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR Part Count in TCUA : [%d]",resultCount);

		if ( resultCount > 0 )
		{

			PartTag = partObjs[0];
			printf("\nnBulkSorPreAct_PrtQuery_function_SOR find T5_PartSorRel");
			TC_write_syslog("\nnBulkSorPreAct_PrtQuery_function_SOR find T5_PartSorRel");
			ifail =(GRM_find_relation_type("T5_PartSorRel",&relation_type));
			ifail =(GRM_list_secondary_objects_only(PartTag,relation_type,&SORCount,&SOR_Objects));

			printf("\nBulkSorPreAct_PrtQuery_function_SOR SORCount : [%d]",SORCount);
			TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR SORCount : [%d]",SORCount);

			if (SORCount > 0 )
			{

				for(i = 0 ; i < SORCount ; i++ )
				{

					SOR_Tag = SOR_Objects[i];
					ifail = ( AOM_ask_value_string ( SOR_Tag, "object_name", &SOR_no ) ) ;
					ifail = ( AOM_ask_value_string ( SOR_Tag, "object_type", &SOR_object_type ) ) ;

					printf("\nBulkSorPreAct_PrtQuery_function_SOR SOR_no : [%s]",SOR_no);
					TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR SOR_no : [%s]",SOR_no);
					printf("\nBulkSorPreAct_PrtQuery_function_SOR SOR_object_type : [%s]",SOR_object_type);
					TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR SOR_object_type : [%s]",SOR_object_type);

					if (tc_strcmp(SOR_object_type,"T5_quicksorRevision")==0)
					{
						printf("\nBulkSorPreAct_PrtQuery_function_SOR SOR [%s] is Already Present For part",SOR_no);
						TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR SOR [%s] is Already Present For part",SOR_no);
						SORflag++;
					}
				}

				if (SORflag > 0)
				{
					return 1;
				}
			}


		}

	}

	return ifail;

}


void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}
	}
}

void getCurrentYear(char cCurrentAccessYear[20])
{
        int ch;
        time_t temp;
        struct tm *timeptr;
        char pAccessDate[20];
        printf("getCurrentYear calling..........\n");
        TC_write_syslog("getCurrentYear calling..........\n");
        temp = time(NULL);
        tc_strcpy(pAccessDate,"");
        timeptr = (struct tm *)localtime(&temp);
        ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%Y",timeptr);
        tc_strcpy(cCurrentAccessYear,pAccessDate);
        printf("\ngetCurrentYear cCurrentAccessYear:%s\n",cCurrentAccessYear);
        TC_write_syslog("\ngetCurrentYear cCurrentAccessYear:%s\n",cCurrentAccessYear);
        printf("\ngetCurrentYear Year:%d\n",(timeptr->tm_year+1900));
        TC_write_syslog("\ngetCurrentYear Year:%d\n",(timeptr->tm_year+1900));

}

void getBulkSORname(char BulkSOR_id[30], char *BulkSOR_Vertical)
{
	int ifail = ITK_ok;
	int p = 1;
	int i = 0;
	int number_found;

	char cCurrentAccessYear[20];
	char str[7];
	char *BulkSOR_name = NULL;

	BulkSOR_name = (char *)MEM_alloc(30*sizeof(char));

	tag_t* list_of_WSO_tags;

	getCurrentYear(cCurrentAccessYear);
	printf("getBulkSORname cCurrentAccessYear:%s\n",cCurrentAccessYear);
	TC_write_syslog("getBulkSORname cCurrentAccessYear:%s\n",cCurrentAccessYear);

	printf("getBulkSORname BulkSOR_Vertical:[%s]\n",BulkSOR_Vertical);
	TC_write_syslog("getBulkSORname BulkSOR_Vertical:[%s]\n",BulkSOR_Vertical);

	trimString (BulkSOR_Vertical);


	for(i = 0 ; i < 999999 ; i++)
	{

		sprintf(str,"%06d",p);
		strcpy(BulkSOR_name,"NEWSOR_");
		strcat(BulkSOR_name,BulkSOR_Vertical);
		strcat(BulkSOR_name,"_");
		strcat(BulkSOR_name,cCurrentAccessYear);
		strcat(BulkSOR_name,"_");
		strcat(BulkSOR_name,str);

		trimString (BulkSOR_name);

		printf("\ngetBulkSORname BulkSOR_name : [%s]",BulkSOR_name);
		TC_write_syslog("\ngetBulkSORname BulkSOR_name : [%s]",BulkSOR_name);

		WSO_search_criteria_t criteria;
		ifail =(WSOM_clear_search_criteria(&criteria));
		tc_strcpy(criteria.name, BulkSOR_name);

		ifail =(WSOM_search(criteria, &number_found, &list_of_WSO_tags));

		printf("\ngetBulkSORname number_found : [%d]",number_found);
		TC_write_syslog("\ngetBulkSORname number_found : [%d]",number_found);

		if (number_found == 0)
		{

			strcpy(BulkSOR_id,BulkSOR_name);
			trimString (BulkSOR_id);
			printf("\ngetBulkSORname BulkSOR_id : [%s]",BulkSOR_id);
			TC_write_syslog("\ngetBulkSORname BulkSOR_id : [%s]",BulkSOR_id);
			break;

		}

		p++;
	}

}



int T5_BulkSorPreAct( METHOD_message_t *, va_list args )
{

	printf("\nT5_BulkSorPreAct...............");
	TC_write_syslog("\nT5_BulkSorPreAct...............");

	int ifail = ITK_ok;
	int i = 0;
	int BulkSorPreAct_PrtQuery_function_SOR_return = 0;
	int n_found_BulkSorPreAct = 0;

	std::string Bulkprjcode ;
	std::string BulkPPPMprjcode ;
	std::string BulkSOR_name ;
	std::string BulkSOR_Vertical;
	std::vector<std::string> SOR_Part_Numbers;
	std::vector<int> lovnullist;


	bool isNull1;
	bool isNull2;
	bool isNull3;
	bool isNull4;

	char BulkSOR_id[30];
	char *BulkSOR_Ver;
	int DrwIndStat = 0;
	int InVal_DrwIndPartCnt = 0;
	char *List_Part_Drw_Ind = NULL;

	va_list local_args;
	va_copy( local_args, args);

	char *BulkSorPreActcheck = NULL;
	char *BulkSorPreActstatus = NULL;
	BulkSorPreActcheck = (char *)MEM_alloc(50 *sizeof(char));
	BulkSorPreActstatus = (char *)MEM_alloc(50 *sizeof(char));
	BulkSOR_Ver = (char *)MEM_alloc(30 *sizeof(char));
	List_Part_Drw_Ind = (char *)MEM_alloc(500 *sizeof(char));
	
	tc_strcpy ( List_Part_Drw_Ind, "");

	tc_strcpy(BulkSorPreActcheck,"BulkSorPreAct");
	tc_strcpy(BulkSorPreActstatus,"ON");


	CreateInput *CreInput = va_arg(local_args, CreateInput*);

	n_found_BulkSorPreAct = tm_check_info_control_object_BulkSorPreAct ( BulkSorPreActcheck,BulkSorPreActstatus);

	printf("\nBulkSorPreAct n_found_BulkSorPreAct : [%d]",n_found_BulkSorPreAct);
	TC_write_syslog("\nBulkSorPreAct n_found_BulkSorPreAct : [%d]",n_found_BulkSorPreAct);


	if ( n_found_BulkSorPreAct > 0 )
	{

		CreInput->getString("object_name", BulkSOR_name, isNull1 );
		printf("\nnT5_BulkSorPreAct BulkSOR_name : [%s]",BulkSOR_name.c_str());
		TC_write_syslog("\nnT5_BulkSorPreAct BulkSOR_name : [%s]",BulkSOR_name.c_str());

		CreInput->getString("t5_BulkVertical", BulkSOR_Vertical, isNull4 );
		printf("\nnT5_BulkSorPreAct BulkSOR_Vertical : [%s]",BulkSOR_Vertical.c_str());
		TC_write_syslog("\nnT5_BulkSorPreAct BulkSOR_Vertical : [%s]",BulkSOR_Vertical.c_str());

		tc_strcpy(BulkSOR_Ver,BulkSOR_Vertical.c_str());



		if(isNull1 == true)
		{

			getBulkSORname(BulkSOR_id,BulkSOR_Ver);//Get Bulk SOR name

			printf("\nSetting BULK SOR Name : [%s]",BulkSOR_id);
			TC_write_syslog("\nSetting BULK SOR Name : [%s]",BulkSOR_id);

			std::string BulkSOR_name = BulkSOR_id;

			CreInput->setString("object_name", BulkSOR_name, false);

			printf("\nnT5_BulkSorPreAct After setting BulkSOR_name : [%s]",BulkSOR_name.c_str());
			TC_write_syslog("\nnT5_BulkSorPreAct After setting BulkSOR_name : [%s]",BulkSOR_name.c_str());

		}


		CreInput->getString("t5_BulkPrjCode", Bulkprjcode, isNull2 );//Bulk SOR Project code
		printf("\nnT5_BulkSorPreAct Bulkprjcode : [%s]",Bulkprjcode.c_str());
		TC_write_syslog("\nnT5_BulkSorPreAct Bulkprjcode : [%s]",Bulkprjcode.c_str());


		CreInput->getString("t5_BulkPPPMPrjCode", BulkPPPMprjcode, isNull3 );//Bulk SOR PPPM Project code
		printf("\nnT5_BulkSorPreAct BulkPPPMprjcode : [%s]",BulkPPPMprjcode.c_str());
		TC_write_syslog("\nnT5_BulkSorPreAct BulkPPPMprjcode : [%s]",BulkPPPMprjcode.c_str());


		CreInput->getStringArray("t5_SOR_Part_Numbers", SOR_Part_Numbers, lovnullist );//SOR part number list
		std::cout << "\nnT5_BulkSorPreAct no of SOR_Part_Numbers : " << lovnullist.size() << std::endl;



		for (i = 0 ; i < lovnullist.size(); i++)
		{

			printf("\nT5_BulkSorPreActSOR Part number from the list : [%d]\t[%s]",i, SOR_Part_Numbers[i].c_str()); //SOR part number
			TC_write_syslog("\nT5_BulkSorPreAct SOR Part number from the list : [%d]\t[%s]",i, SOR_Part_Numbers[i].c_str()); //SOR part number

			char *Partno_Rev_Seq = NULL;
			Partno_Rev_Seq = (char*)MEM_alloc(50*sizeof(char));

			strcpy(Partno_Rev_Seq,SOR_Part_Numbers[i].c_str());//copying SOR part number from list
			printf("\nT5_BulkSorPreAct Partno_Rev_Seq : [%d]\t[%s]",i,Partno_Rev_Seq);
			TC_write_syslog("\nT5_BulkSorPreAct Partno_Rev_Seq : [%d]\t[%s]",i,Partno_Rev_Seq);

			char *partno = NULL;
			char *Rev = NULL;
			char *Seq = NULL;
			partno = strtok(Partno_Rev_Seq,",");
			Rev = strtok(NULL,",");
			Seq = strtok(NULL,",");

			BulkSorPreAct_PrtQuery_function_SOR_return = BulkSorPreAct_PrtQuery_function_SOR(partno,Rev,Seq);//Query function for qSOR part number

			printf("\nBulkSorPreAct_PrtQuery_function_SOR_return : [%d]",BulkSorPreAct_PrtQuery_function_SOR_return);
			TC_write_syslog("\nBulkSorPreAct_PrtQuery_function_SOR_return : [%d]",BulkSorPreAct_PrtQuery_function_SOR_return);


			if (BulkSorPreAct_PrtQuery_function_SOR_return > 0)
			{

				printf("\nT5_BulkSorPreActSOR Skipping qSOR Creation");
				TC_write_syslog("\nT5_BulkSorPreActSOR Skipping qSOR Creation");

			}
			else
			{
				DrwIndStat = 0 ; // valid drawing ind part	1== invalid drw ind for sor creation
				DrwIndStat = Get_Part_Details(Bulkprjcode.c_str(),BulkPPPMprjcode.c_str(),partno,Rev,Seq);
				if ( DrwIndStat == 1)
				{
					tc_strcat ( List_Part_Drw_Ind, partno);
					tc_strcat ( List_Part_Drw_Ind, ",");
					InVal_DrwIndPartCnt = InVal_DrwIndPartCnt + 1;
				}
			}

			MEM_free(Partno_Rev_Seq);

		}
		if ( InVal_DrwIndPartCnt > 0 )
		{
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_warning,ITK_err,"For QuickSOR Creation Drawing indicator should be D or A for part : ",List_Part_Drw_Ind);
		}
	}

	MEM_free(BulkSorPreActcheck);
	MEM_free(BulkSorPreActstatus);

    return ifail;

}
