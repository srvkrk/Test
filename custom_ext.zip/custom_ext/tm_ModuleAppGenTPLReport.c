
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_ModuleAppGenTPLReport.c
*
* Description		: > This contains custom user service for Module Applicability Gen TPL report
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 23/04/2024   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tccore/iman_msg.h>
#include <tc/envelope.h>


#define MAX_LINE_LEN 10024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


char *trimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


/* Function to add string into a set of string */


int getProjectTag(char *projNo, tag_t *projTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\nModuleApp:\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = "T5_Project";
	qry_values[1] = projNo;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\nModuleApp: SAN:getProjectTag: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*projTag = itemObj[count-1];
	}
	
	return ifail;
}



void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\nModuleApp: ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\nModuleApp: ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\nModuleApp: setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\nModuleApp: setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\nModuleApp:[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\nModuleApp: ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\nModuleApp: **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\nModuleApp:[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}



void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}




void  getcurentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int tdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void NextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= tdays( month, year );//calling tdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getcurentMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\nModuleApp: cnextAccessDate:%s\n",cnextAccessDate);
}

void CurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	//printf("\nModuleApp: CurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	//printf("\nModuleApp: cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	//printf("Date:%d\n",(timeptr->tm_mday));
	//printf("Month:%d\n",(timeptr->tm_mon)+1);
	//printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}



int cmpstr(const void* a, const void* b)
{
    const char* aa = *(const char**)a;
    const char* bb = *(const char**)b;
    return tc_strcmp(aa,bb);
}
//End San



int tm_Compare(const void* a, const void* b)
{
 
    // setting up rules for comparison
    return strcmp(*(const char**)a, *(const char**)b);
}

// Function to sort the array
void tm_sort(char* arr[], int n)
{
    // calling qsort function to sort the array
    // with the help of Comparator
    qsort(arr, n, sizeof(const char*), tm_Compare);
}




int getlatestReleasedItem(char *partNumber, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	tag_t itemMaster = NULLTAG;
	
	qry_entries[0] = "Item ID";
	
	qry_values[0] = partNumber;
	
		
	CALLAPI(QRY_find2("Item...", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	//printf("\nModuleApp: Item Master count==>%d", count);fflush(stdout);

	if(count>0)
	{
		itemMaster = itemObjs[0];
		int Item_count = 0;
		tag_t* rev_list = NULLTAG;
		int k = 0;
		char* rel_status = NULL;
		char* partNo = NULL;
		char* partRev = NULL;
		char* creDate = NULL;
		char* lastModDate = NULL;			
		
		ifail = ITEM_list_all_revs(itemMaster, &Item_count, &rev_list);
		//printf("\nModuleApp: Item Revisions count==>%d", count);fflush(stdout);
		for(k=Item_count-1;k>=0;k--)
		{
			
			date_t creation_dt = NULLDATE;
			CALLAPI(AOM_ask_value_string(rev_list[k], "item_id", &partNo))
			CALLAPI(AOM_ask_value_string(rev_list[k], "item_revision_id", &partRev))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "creation_date", &creDate))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "last_mod_date", &lastModDate))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "release_status_list", &rel_status))
			//printf("\nModuleApp: [%d]. Part No:[%s;%s], Creation Date:[%s],Last Modified Date: [%s], release_status_list:[%s]", k+1, partNo, partRev,creDate,lastModDate,rel_status);fflush(stdout);
			
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				*tcPart = rev_list[k];
				break;
			}
			
			
		}

		if(*tcPart!=NULLTAG)
		{
			char* partNo = NULL;
			char* partRev = NULL;
			CALLAPI(AOM_ask_value_string(*tcPart, "item_id", &partNo))
			CALLAPI(AOM_ask_value_string(*tcPart, "item_revision_id", &partRev))
			//printf("\nModuleApp: Latest Released Part [%s;%s]\n", partNo, partRev);fflush(stdout);
		}
		else
		{
			//printf("\nModuleApp: No Released Part Found with id [%s]\n",partNumber);fflush(stdout);
		}		
		
		
	}
	
	
	
	
	return ifail;
}

char* subStringMR(char* mainStringf,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}




void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}



int getLatestERCReleasedPart(char* partNo, tag_t* vcRevTag)
{
	int ifail = ITK_ok;
	tag_t partMstrTag = NULLTAG;
	//printf("\nModuleApp:Get Latest ERC Released Part of [%s]\n", partNo);fflush(stdout);
	
	ifail = ITEM_find_item(partNo,&partMstrTag);
	
	if(partMstrTag!=NULLTAG)
	{
		char* type = NULL;
		ifail = AOM_ask_value_string(partMstrTag,"object_type",&type);
		
		//printf("\nModuleApp:Type of the Part = %s\n",type);fflush(stdout);
		
		if(tc_strcmp(type,"Design")==0)
		{
			int partRevCnt = 0;
			tag_t* partRevTagObjs = NULLTAG;
			tag_t partRevTag = NULLTAG;
			ifail = ITEM_list_all_revs (partMstrTag, &partRevCnt, &partRevTagObjs);
			//printf("\nModuleApp: Part Revision counts :%d\n",partRevCnt);fflush(stdout);
			
			int i = 0;
			for(i=partRevCnt-1;i>=0;i--)
			{
				char* rel_status = NULL;
				partRevTag = partRevTagObjs[i];
				
				ifail = AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status);
				
				if(tc_strstr(rel_status,"ERC Released")!=NULL)
				{
					*vcRevTag = partRevTag;
					break;
				}
			}
			
		}
		
	}
	else
	{
		printf(" Part[%s] Not found in PLM database\n",partNo);fflush(stdout);
	}
	
	//printf("\nModuleApp:END of  getLatestERCReleasedPart...\n");fflush(stdout);
	return ifail;
}


typedef struct vehModuleMap_
{
	char vehicleNo[50];
	char** moduleNumList;
	int moduleCnt;
}vehModuleMap;

void setAddVehModuleMap(int *count,vehModuleMap **objlist,vehModuleMap obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (vehModuleMap *)malloc((*count ) * sizeof(vehModuleMap ));
	}
	else
	{
		(*objlist) = (vehModuleMap *)realloc((*objlist),(*count) * sizeof(vehModuleMap ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindVehNodeInVehModuleMap(vehModuleMap *vehnode_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\nModuleApp:[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(vehnode_list[k].vehicleNo,str)==0)
		{
			*found=1;
			break;
		}

	}
}


int getPartObjFromRevStr(char* partNo,char* revStr, tag_t* partRev)
{
	int ifail = ITK_ok;
	tag_t partMstrTag = NULLTAG;
	ifail = ITEM_find_item(partNo,&partMstrTag);
	
	if(partMstrTag!=NULLTAG)
	{
		char* type = NULL;
		ifail = AOM_ask_value_string(partMstrTag,"object_type",&type);
		
		//printf("\nModuleApp:Type of the Part = %s\n",type);fflush(stdout);
		
		if(tc_strcmp(type,"Design")==0)
		{
			int partRevCnt = 0;
			tag_t* partRevTagObjs = NULLTAG;
			tag_t partRevTag = NULLTAG;
			ifail = ITEM_list_all_revs (partMstrTag, &partRevCnt, &partRevTagObjs);
			//printf("\nModuleApp: Part Revision counts :%d\n",partRevCnt);fflush(stdout);
			
			int i = 0;
			for(i=partRevCnt-1;i>=0;i--)
			{
				char* revS = NULL;
				partRevTag = partRevTagObjs[i];
				
				ifail = AOM_ask_value_string(partRevTag,"item_revision_id",&revS);
				if(revS==NULL) continue;
				char* revStr1 = NULL;
				char* revStr2 = NULL;
				revStr1 = ltrimString(revStr);
				revStr2 = rtrimString(revStr1);	
				if(tc_strcmp(revS,revStr2)== 0)
				{
					*partRev = partRevTag;
					break;
				}
			}
			
		}
		
	}
	else
	{
		//Not found
	}
	
	//printf("\nModuleApp:END of  getLatestERCReleasedPart...\n");fflush(stdout);
	return ifail;
}


void t5BomExpansionMulLevel(tag_t line, int depth, int reqlevel, tag_t** bomLineList, int *bomLineListCnt,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* inp_Plant)
{
	int ifail;
	char *name, *sequence_no;
	int i, n;
	tag_t *children;
	depth ++;
	if(depth > reqlevel) return;
	ifail = AOM_ask_value_string (line, "bl_item_item_id", &name);
	
	ifail = AOM_ask_value_string (line, "bl_rev_item_revision_id", &sequence_no);

	t5AddTagObjToSet(bomLineListCnt,bomLineList,line);

	ifail = BOM_line_ask_child_lines (line, &n, &children);
	
	for (i = 0; i < n; i++)
	{
		char* partStr = NULL;
		char* line_quantity = NULL;
		ifail = AOM_ask_value_string (children[i], "bl_item_item_id", &partStr);
			
		//remove underscore part
		if(remove_underscorePart)
		{
			if (tc_strstr(partStr,"_")!=NULL)
			{
				//printf("\nModuleApp: Got underscorepart :%s \n",partStr);fflush(stdout);
				continue;
			}
		}
		ifail = AOM_UIF_ask_value(children[i],"bl_quantity",&line_quantity);
		//printf("\n skipzeroQty => %d\n",skipzeroQty);fflush(stdout);
		if(skipzeroQty)
		{
			if(atoi(line_quantity) == 0)
			{
				//printf("\nModuleApp:Skipping 0 Qty => %s \n",partStr);fflush(stdout);	
				continue;
			} 
		}
		
		if(stopAtF)
		{
			
			char* line_PlantCS = NULL;
			//printf("\nModuleApp: top_line_input Plant ==>  %s \n",inp_Plant);fflush(stdout);
			
			if(strcmp(inp_Plant,"DHARWAD")==0)
			{
			  //printf("\nModuleApp: Inside DWD \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_DwdMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"CVBU Pune")==0)
			{
			  //printf("\nModuleApp: Inside CVBU Pune \n");fflush(stdout);
			  ifail  = AOM_ask_value_string(children[i],"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"PUVBU")==0)
			{
			  //printf("\nModuleApp: Inside PUVBU \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_PunUVMakeBuyIndicator",&line_PlantCS);
			} 
			else  if(strcmp(inp_Plant,"CAR")==0)
			{
			  //printf("\nModuleApp: Inside CAR \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_CarMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"CVBU JSR")==0)
			{
			 // printf("\nModuleApp: Inside CVBU JSR \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_JsrMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"CVBU LKO")==0)
			{
			 // printf("\nModuleApp: Inside CVBU LKO \n");fflush(stdout);
			  ifail  = AOM_ask_value_string(children[i],"bl_Design Revision_t5_LkoMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"SMALLCAR AHD")==0)
			{
			  //printf("\nModuleApp: Inside SMALLCAR AHD \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_AhdMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"CVBU PNR")==0)
			{
			  //printf("\nModuleApp: Inside CVBU PNR \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_PnrMakeBuyIndicator",&line_PlantCS);
			}
			else  if(strcmp(inp_Plant,"TMLDL JSR")==0)
			{
			  //printf("\nModuleApp: Inside TMLDL JSR \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_JdlMakeBuyIndicator",&line_PlantCS);
			}
			else
			{
			  //printf("\nModuleApp: Inside other \n");fflush(stdout);
			  ifail = AOM_ask_value_string(children[i],"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			}			
			
			if (tc_strstr(line_PlantCS,"F")!=NULL)
			{
				//printf("\nModuleApp:skip F CS \n");fflush(stdout);
				continue;
			}
		}
	
		
		
		t5BomExpansionMulLevel(children[i], depth, reqlevel,bomLineList,bomLineListCnt,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,inp_Plant);
	}
	
}


int multiLevelBomExplosion(tag_t partRevObj, int reqlevel, vehModuleMap * vehModuleRelList, int vehModuleRelListCnt,char** vcArray, int size, tag_t closureRule, tag_t RevRule,char*** bufferedXmlStrOut, int* buff_cnt,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* inp_Plant)
{
	int ifail = ITK_ok;
	
	

	tag_t partItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(partRevObj, &partItemTag);
	ifail = ITEM_list_bom_views(partItemTag, &bv_count, &bvs );
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		printf("\nModuleApp: No BV... exit....\n");fflush(stdout);
		return ifail;
	}
	
	ifail = ITEM_rev_list_bom_view_revs(partRevObj,&bvr_count, &bvrs);
	
	if(bvr_count)
	{	
		bvr = bvrs[0];
		MEM_free(bvrs);		
	}
	else
	{
		printf("\nModuleApp: No BVR ..exit....\n");fflush(stdout);
		return ifail;
	}
	
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
		
	if(bvr != NULLTAG)
	{
		tag_t window = NULLTAG;
		tag_t top_line = NULLTAG;
		char **rulename = NULL;
		char **rulevalue = NULL;
		tag_t* bomLineList;
		int bomLineListCnt = 0;
		ifail = BOM_create_window (&window);
		ifail = BOM_set_window_config_rule( window, RevRule );
		ifail = BOM_window_set_closure_rule( window,closureRule, 0, rulename,rulevalue );
		ifail = BOM_set_window_pack_all (window, true);
		ifail = BOM_set_window_top_line (window, NULLTAG,partRevObj, NULLTAG, &top_line);
		
		ifail =	BOM_window_hide_unconfigured( window );
		if(showSuppressed)
		{
			ifail = BOM_window_show_suppressed( window );
		}
		else
		{
			ifail = BOM_window_hide_suppressed( window );
		}
		
		
		if(top_line != NULLTAG)
		{
			t5BomExpansionMulLevel (top_line, 0, reqlevel, &bomLineList,&bomLineListCnt,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,inp_Plant);
		}
		
		printf("\nModuleApp:Size of bomLineList:[%d]",bomLineListCnt);fflush(stdout);
		
		
		int i =0;
		for(i=0; i< bomLineListCnt; i++)
		{
			tag_t line = NULLTAG;
			//int itemid, itemrev;
			char* partStr = NULL;
			char* partRev = NULL;
			char* line_level = NULL;
			char* line_Description = NULL;
			//char* line_Description1 = NULL;
			//char* line_Description2 = NULL;
			char* line_Coated = NULL;
			char* line_ColourInd = NULL;
			char* line_Comp_Code = NULL;
			char* line_Colour_ID = NULL;
			char* line_Unit = NULL;
			char* line_quantity = NULL;
			//char* line_ModDescription1 = NULL;
			char* line_ModDescription = NULL;
			//char* line_ModDescription2 = NULL;
			
			//char* line_AddOn_Description1 = NULL;
			char* line_AddOn_Description = NULL;
			//char* line_AddOn_Description2 = NULL;			
			
			//char* line_KeyWord_Description1 = NULL;
			char* line_Keyword_Description = NULL;
			//char* line_KeyWord_Description2 = NULL;
			
			char* line_ProjectCode = NULL;
			char* line_DesignGrp = NULL;
			
			char* line_OwnerDesignUnit = NULL;
			char* line_PartType = NULL;
			char* line_PartCode = NULL;
			
			//char* line_Part_Category1 = NULL;
			//char* line_Part_Category2 = NULL;
			char* line_Part_Category = NULL;
			
			char* line_PartStatus = NULL;
			char* line_DrawingInd = NULL;
			char* line_DrawingNo = NULL;
			
			//char* line_PartMaterial1 = NULL;
			//char* line_PartMaterial2 = NULL;
			char* line_PartMaterial = NULL;
			
			char* line_Weight = NULL;
			char* line_RolledupWt = NULL;
			char* line_Mat_Thickness = NULL;
			//char* line_MatlClass1 = NULL;
			//char* line_MatlClass2 = NULL;
			char* line_MatlClass = NULL;
			
			char* line_EnvelopeDimensions = NULL;
			char* line_ApplicationOwner = NULL;
			char* line_Samples_to_be_Approved = NULL;
			char* line_Validation_Status = NULL;
			char* line_Spare_Part = NULL;
			char* line_Spare_Indicator = NULL;
			char* line_Homologation_Reqd = NULL;
			char* line_CMVR_Cert_Reqd = NULL;
			char* line_owner = NULL;
			char* line_last_mod_user = NULL;
			//char* line_Release_Status1 = NULL;
			//char* line_Release_Status2 = NULL;
			char* line_Release_Status = NULL;
			
			
			
			
			//int line_attr = 0;
			tag_t line_bl_rev = NULLTAG;
			char* line_creation_date = NULL;
			char* line_LastModifiedDate = NULL;
			
		
			line = bomLineList[i];
			
			ifail = AOM_ask_value_string (line, "bl_item_item_id", &partStr);
			
			//remove underscore part
			if(remove_underscorePart)
			{
				if (tc_strstr(partStr,"_")!=NULL)
				{
					//printf("\nModuleApp: Got underscorepart :%s \n",partStr);fflush(stdout);
					continue;
				}
			}
			
			ifail = AOM_ask_value_string (line, "bl_rev_item_revision_id", &partRev);
			
			ifail = AOM_UIF_ask_value(line,"bl_level_starting_1",&line_level);
			ifail = AOM_UIF_ask_value(line,"bl_rev_object_desc",&line_Description);
			
			if(line_Description !=NULL)
			{
				STRNG_replace_str(line_Description,"&","&amp;",&line_Description);
				STRNG_replace_str(line_Description,"<","&lt;",&line_Description);
				STRNG_replace_str(line_Description,">","&gt;",&line_Description);
			}			
			
			
			

			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Coated",&line_Coated);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ColourInd",&line_ColourInd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PrtCatCode",&line_Comp_Code);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ColourID",&line_Colour_ID);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_uom",&line_Unit);
			ifail = AOM_UIF_ask_value(line,"bl_quantity",&line_quantity);
			
			//printf("\nModuleApp:11 -skipzeroQty => %d\n",skipzeroQty);fflush(stdout);
			if(skipzeroQty)
			{
				if(atoi(line_quantity) == 0)
				{
					//printf("\nModuleApp:11 Skipping 0 Qty => %s \n",partStr);fflush(stdout);	
					continue;
				} 
			}
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DocRemarks",&line_ModDescription);
			
			if(line_ModDescription !=NULL)
			{
				STRNG_replace_str(line_ModDescription,"&","&amp;",&line_ModDescription);
				STRNG_replace_str(line_ModDescription,"<","&lt;",&line_ModDescription);
				STRNG_replace_str(line_ModDescription,">","&gt;",&line_ModDescription);
			}
			
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SimVal",&line_AddOn_Description);
			
			if(line_AddOn_Description !=NULL)
			{
				STRNG_replace_str(line_AddOn_Description,"&","&amp;",&line_AddOn_Description);
				STRNG_replace_str(line_AddOn_Description,"<","&lt;",&line_AddOn_Description);
				STRNG_replace_str(line_AddOn_Description,">","&gt;",&line_AddOn_Description);
			}			
			
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_CategoryName",&line_Keyword_Description);
			
			if(line_Keyword_Description !=NULL)
			{
				STRNG_replace_str(line_Keyword_Description,"&","&amp;",&line_Keyword_Description);
				STRNG_replace_str(line_Keyword_Description,"<","&lt;",&line_Keyword_Description);
				STRNG_replace_str(line_Keyword_Description,">","&gt;",&line_Keyword_Description);
			}
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ProjectCode",&line_ProjectCode);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DesignGrp",&line_DesignGrp);
			
			//new attr
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DsgnOwn",&line_OwnerDesignUnit);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartType",&line_PartType);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartCode",&line_PartCode);
			

			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SpareCriteria",&line_Part_Category);
			if(line_Part_Category !=NULL)
			{
				STRNG_replace_str(line_Part_Category,"&","&amp;",&line_Part_Category);
				STRNG_replace_str(line_Part_Category,"<","&lt;",&line_Part_Category);
				STRNG_replace_str(line_Part_Category,">","&gt;",&line_Part_Category);
			}			

			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartStatus",&line_PartStatus);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DrawingInd",&line_DrawingInd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DrawingNo",&line_DrawingNo);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Material",&line_PartMaterial);
			if(line_PartMaterial !=NULL)
			{
				STRNG_replace_str(line_PartMaterial,"&","&amp;",&line_PartMaterial);
				STRNG_replace_str(line_PartMaterial,"<","&lt;",&line_PartMaterial);
				STRNG_replace_str(line_PartMaterial,">","&gt;",&line_PartMaterial);
			}				


			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Weight",&line_Weight);
			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_RolledupWt",&line_RolledupWt);
			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_MThickness",&line_Mat_Thickness);

			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_MatlClass",&line_MatlClass);
			if(line_MatlClass !=NULL)
			{
				STRNG_replace_str(line_MatlClass,"&","&amp;",&line_MatlClass);
				STRNG_replace_str(line_MatlClass,"<","&lt;",&line_MatlClass);
				STRNG_replace_str(line_MatlClass,">","&gt;",&line_MatlClass);
			}	

			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_EnvelopeDimensions",&line_EnvelopeDimensions);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ApplicationOwner",&line_ApplicationOwner);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SamplesToAppr",&line_Samples_to_be_Approved);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PrtValiStatus",&line_Validation_Status);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SPDisposalInstr",&line_Spare_Part);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SpareInd",&line_Spare_Indicator);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_HomologationReqd",&line_Homologation_Reqd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_CMVRCertificationReqd",&line_CMVR_Cert_Reqd);
			ifail = AOM_UIF_ask_value(line,"awb0RevisionOwningUser",&line_owner);
			
			//ifail = BOM_line_look_up_attribute("bl_revision",&line_attr);
			ifail = AOM_ask_value_tag(line,"bl_revision",&line_bl_rev);

			ifail = AOM_UIF_ask_value(line_bl_rev,"creation_date",&line_creation_date);
			ifail = AOM_UIF_ask_value(line_bl_rev,"last_mod_date",&line_LastModifiedDate);
			
			ifail = AOM_UIF_ask_value(line,"awb0RevisionLastModifiedUser",&line_last_mod_user);
			ifail = AOM_UIF_ask_value(line,"bl_rev_release_status_list",&line_Release_Status);
			
			if(line_Release_Status !=NULL)
			{
				STRNG_replace_str(line_Release_Status,"&","&amp;",&line_Release_Status);
				STRNG_replace_str(line_Release_Status,"<","&lt;",&line_Release_Status);
				STRNG_replace_str(line_Release_Status,">","&gt;",&line_Release_Status);
			}			
					
			
			//Get DML info - To do
			
			
			//Get CS
			// Getting Plant CS for line
			//char* inp_Plant = NULL;
			char* line_PlantCS = NULL;
			//inp_Plant = "CAR";
			//printf("\nModuleApp: 11top_line_input Plant ==>  %s \n",inp_Plant);fflush(stdout);
			
			if(strcmp(inp_Plant,"DHARWAD")==0)
			 {
				  //printf("\nModuleApp: Inside DWD \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_DwdMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU Pune")==0)
			 {
				  //printf("\nModuleApp: Inside CVBU Pune \n");fflush(stdout);
				  ifail  = AOM_ask_value_string(line,"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"PUVBU")==0)
			 {
				  //printf("\nModuleApp: Inside PUVBU \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PunUVMakeBuyIndicator",&line_PlantCS);
			 } 
			 else  if(strcmp(inp_Plant,"CAR")==0)
			 {
				  //printf("\nModuleApp: Inside CAR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_CarMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU JSR")==0)
			 {
				 // printf("\nModuleApp: Inside CVBU JSR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_JsrMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU LKO")==0)
			 {
				 // printf("\nModuleApp: Inside CVBU LKO \n");fflush(stdout);
				  ifail  = AOM_ask_value_string(line,"bl_Design Revision_t5_LkoMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"SMALLCAR AHD")==0)
			 {
				  //printf("\nModuleApp: Inside SMALLCAR AHD \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_AhdMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU PNR")==0)
			 {
				  //printf("\nModuleApp: Inside CVBU PNR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PnrMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"TMLDL JSR")==0)
			 {
				  //printf("\nModuleApp: Inside TMLDL JSR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_JdlMakeBuyIndicator",&line_PlantCS);
			 }
			 else
			 {
				  //printf("\nModuleApp: Inside other \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			 }	

			
			
			
	
			//fprintf(vcMdlRep,"\n%s,%s,%s,%s,",line_level,partStr,partRev,line_Description);fflush(vcMdlRep);
			
			/*tc_strdup(line_level,&line_levelBuf);
			tc_strdup(partStr,&partStrBuf);
			tc_strdup(partRev,&partRevBuf);
			tc_strdup(line_Description,&line_DescriptionBuf);*/
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartDetail>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Level>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_level);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Level>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Component>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,partStr);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Component>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Revision>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,partRev);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Revision>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Description>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Description);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Description>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ModuleInVC>");
			if(tc_strcmp(line_level,"1")==0)
			{
				
				char* moduleNoS = (char*)MEM_alloc(tc_strlen(partStr) + tc_strlen(partRev) + 5);
				
				tc_strcpy(moduleNoS,partStr);
				tc_strcat(moduleNoS,"/");
				tc_strcat(moduleNoS,partRev);
				
				int k = 0;
				for(k=0;k<size;k++)
				{

					int j = 0;
					for (j=0;j<vehModuleRelListCnt;j++)
					{
						char* vcNoS = NULL;
						vcNoS = vehModuleRelList[j].vehicleNo;
						if(tc_strcmp(vcArray[k],vcNoS) == 0)
						{
							char* fndStr = (char*)MEM_alloc(10);
							tc_strcpy(fndStr,"NO");
							char** moduleList = NULL;
							int moduleCnt = 0;
							
							moduleList = vehModuleRelList[j].moduleNumList;
							moduleCnt = vehModuleRelList[j].moduleCnt;
							
							int found = 0;
							int n = 0;
							for (n = 0; n<moduleCnt; n++)
							{
								if(tc_strcmp(moduleNoS,moduleList[n])==0)
								{
									//cout<<"Found\n";
									found++;
									tc_strcpy(fndStr,"YES");
									break;
								}
							}
							t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ModuleAvlInVC>");
							t5AddStrToSet(buff_cnt,bufferedXmlStrOut,fndStr);
							t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ModuleAvlInVC>");
							//fprintf(vcMdlRep,"%s,",fndStr);fflush(vcMdlRep);
							
							MEM_free(fndStr);
							
							
						}
					}
					
				}
							
				
				MEM_free(moduleNoS);
			
			}
			else
			{
				int m = 0;
				for(m=0;m<size;m++)
				{
					//fprintf(vcMdlRep,"%s",",");fflush(vcMdlRep);
					t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ModuleAvlInVC>");
					//t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"-");
					t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ModuleAvlInVC>");
				}
				
			}
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ModuleInVC>");
			
			//fprintf(vcMdlRep,"%s,%s,%s,%s,%s,%s,,%s,%s,%s,%s,%s,",line_Coated,line_ColourInd,line_Comp_Code,line_Colour_ID,line_Unit,line_quantity,line_ModDescription,line_AddOn_Description,line_Keyword_Description,line_ProjectCode,line_DesignGrp);fflush(vcMdlRep);
			
			
			
			//fprintf(vcMdlRep,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",line_Coated,line_ColourInd,line_Comp_Code,line_Colour_ID,line_Unit,line_quantity,line_PlantCS,line_ModDescription,line_AddOn_Description,line_Keyword_Description,line_ProjectCode,line_DesignGrp,line_OwnerDesignUnit,line_PartType,line_PartCode,line_Part_Category,line_PartStatus,line_DrawingInd,line_DrawingNo,line_PartMaterial,line_Weight,line_RolledupWt,line_Mat_Thickness,line_MatlClass,line_EnvelopeDimensions,line_ApplicationOwner,line_Samples_to_be_Approved,line_Validation_Status,line_Spare_Part,line_Spare_Indicator,line_Homologation_Reqd,line_CMVR_Cert_Reqd,line_owner,line_creation_date,line_last_mod_user,line_LastModifiedDate,line_Release_Status);fflush(vcMdlRep);	

		
						

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Coated>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Coated);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Coated>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ColourIndicator>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_ColourInd);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ColourIndicator>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<CompCode>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Comp_Code);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</CompCode>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ColourID>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Colour_ID);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ColourID>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Unit>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Unit);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Unit>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Quantity>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_quantity);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Quantity>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<CS>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_PlantCS);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</CS>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ModificationDescription>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_ModDescription);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ModificationDescription>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<AddOnDescription>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_AddOn_Description);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</AddOnDescription>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<KeywordDescription>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Keyword_Description);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</KeywordDescription>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ProjectCode>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_ProjectCode);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ProjectCode>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<DesignGroup>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_DesignGrp);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</DesignGroup>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<OwnerDesignUnit>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_OwnerDesignUnit);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</OwnerDesignUnit>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartType>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_PartType);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartType>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartCode>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_PartCode);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartCode>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartCategory>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Part_Category);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartCategory>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartDRStatus>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_PartStatus);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartDRStatus>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<DrawingIndicator>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_DrawingInd);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</DrawingIndicator>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<DrawingNo>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_DrawingNo);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</DrawingNo>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<PartMaterial>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_PartMaterial);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartMaterial>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Weight>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Weight);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Weight>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<RolledUpWeight>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_RolledupWt);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</RolledUpWeight>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<MaterialThickness>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Mat_Thickness);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</MaterialThickness>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<MaterialClass>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_MatlClass);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</MaterialClass>");
			
	
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<EnvelopeDimensions>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_EnvelopeDimensions);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</EnvelopeDimensions>");
						
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ApplicationOwner>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_ApplicationOwner);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ApplicationOwner>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<SamplesToBeApproved>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Samples_to_be_Approved);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</SamplesToBeApproved>");			
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ValidationStatus>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Validation_Status);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ValidationStatus>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<SparePart>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Spare_Part);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</SparePart>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<SpareIndicator>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Spare_Indicator);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</SpareIndicator>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<HomologationReqd>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Homologation_Reqd);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</HomologationReqd>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<CMVRCertReqd>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_CMVR_Cert_Reqd);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</CMVRCertReqd>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Owner>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_owner);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Owner>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<CreationDate>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_creation_date);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</CreationDate>");

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<LastModifyingUser>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_last_mod_user);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</LastModifyingUser>");
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<LastModifiedDate>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_LastModifiedDate);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</LastModifiedDate>");			

			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ReleaseStatus>");
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,line_Release_Status);
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ReleaseStatus>");		
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</PartDetail>");
		
		}
		
		
		
		ifail = BOM_close_window(window);
	}
	
	
	
	
	
	
	return ifail;
}


int generateModuleApplReport(char* moduleNumStr, vehModuleMap * vehModuleRelList, int vehModuleRelListCnt, tag_t closureRule, tag_t RevRule,char** vcArray, int size,char*** bufferedXmlStrOut, int *buff_cnt,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* levelStr, char* plantStr)
{
	int ifail = ITK_ok;
	char* moduleNum = NULL;
	char* moduleId = NULL;
	char* revStr = NULL;
	tag_t moduleRevTag = NULLTAG;
	moduleNum = (char*)MEM_alloc(tc_strlen(moduleNumStr) + 1);
	
	tc_strcpy(moduleNum,moduleNumStr);
	
	//cout<<"Module No"<<moduleNum<<endl;
	
	if(tc_strstr(moduleNum,"/") != NULL)
	{
		moduleId = tc_strtok(moduleNum,"/");
		revStr = tc_strtok(NULL,"/");
	}
	 

	
	//Get Module Rev Tag
	ifail = getPartObjFromRevStr(moduleId,revStr, &moduleRevTag);
	if(moduleRevTag != NULLTAG)
	{
		
		printf("\nModuleApp:Found Tag Module No:[%s/%s]",moduleId,revStr);fflush(stdout);
		
		//level
		int lvl = 0;
		
		lvl=atoi(levelStr);
		
		ifail = multiLevelBomExplosion(moduleRevTag, lvl, vehModuleRelList,vehModuleRelListCnt,vcArray,size,closureRule, RevRule,bufferedXmlStrOut,buff_cnt,dmlInfo,drawingInfo,remove_underscorePart, skipzeroQty,stopAtF,showSuppressed,plantStr);
		
	}
	else
	{
		printf("\nModuleApp:Not Found Tag Module No:[%s/%s]",moduleId,revStr);fflush(stdout);
	}
	
	
	if(moduleNum != NULL) MEM_free(moduleNum);
	
	return ifail;
}


int executeModuleAppGenTPLReportLogic(int no_of_Vehicles,char** vehicleSelected,char* viewStr,char* plantStr,char* closureRuleStr,char* revRuleStr,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* levelStr,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	
	printf("\nModuleApp:Input parameters:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
	
	
	tag_t rule = NULLTAG;
	int rulefound = 0;
	tag_t* ClosureRuleTags = NULLTAG;
	tag_t ClosureRuleTag = NULLTAG;

	//ifail = CFM_find("ERC release and above", &rule );
	
	ifail = CFM_find(revRuleStr, &rule );
	if(rule == NULLTAG)
	{
		printf("\n Revision Rule- [%s] Not found, Applying Default Rule\n",revRuleStr);fflush(stdout);
		ifail = CFM_find("Latest Working", &rule );
	}
	else
	{
		printf("\n Revision Rule - [%s] found\n",revRuleStr);fflush(stdout);
	}

	//ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
	ifail = PIE_find_closure_rules2(closureRuleStr,PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
	//ifail = PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);


	printf ("\nClosure Rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		ClosureRuleTag = ClosureRuleTags[0];
		printf ("\nClosure rule found \n");fflush(stdout);

	}

	//End of closure and rev rule
	
	//Loop through the vehicle
	int k = 0;
	vehModuleMap * vehModuleRelList = NULL;
	int vehModuleRelListCnt = 0;
	
	char** unqModuleNumList = NULL;
	int unqModuleNumListCnt = 0;
	
	
	for(k=0;k<no_of_Vehicles;k++)
	{
		//printf("\nModuleApp:[%d] - [%s]", k+1, vehicleSelected[k]);fflush(stdout);
		tag_t vcRevTag = NULLTAG;
		char* partNo = NULL;
		char* revStr = NULL;
		char* vcNumb = NULL;
		vcNumb = (char*)MEM_alloc(tc_strlen(vehicleSelected[k]) + 1);
		tc_strcpy(vcNumb,vehicleSelected[k]);
		
		printf("\nModuleApp:[%d] - [%s], [%s]", k+1, vehicleSelected[k], vcNumb);fflush(stdout);
		//Get Vehicle No, Rev and sequence
		if(tc_strstr(vcNumb,"/") != NULL)
		{
			partNo = tc_strtok(vcNumb,"/");
			revStr = tc_strtok(NULL,"/");
		}
		
		if(partNo == NULL)
		{
			continue;
		}
		else if(revStr == NULL)
		{
			ifail = getLatestERCReleasedPart(partNo,&vcRevTag);
		}
		else
		{
			ifail = getPartObjFromRevStr(partNo,revStr, &vcRevTag);
			
			if(vcRevTag == NULLTAG)
			{
				printf("\nModuleApp:Wrong Revision format:Get the latest released part");fflush(stdout);
				ifail = getLatestERCReleasedPart(partNo,&vcRevTag);
			}
		}
		
		if(vcRevTag != NULLTAG)
		{
			char* vcNum = NULL;
			char* vcRev = NULL;
			ifail = AOM_ask_value_string(vcRevTag,"item_id",&vcNum);
			ifail = AOM_ask_value_string(vcRevTag,"item_revision_id",&vcRev);
			printf("\nModuleAppSelected Part:[%s/%s]",vcNum,vcRev);fflush(stdout);
			
			//Expansion of Vehicle
			
			tag_t vcItemTag = NULLTAG;
			tag_t* bvs = NULLTAG;
			int bv_count = 0;
			tag_t* bvrs = NULLTAG;
			int bvr_count = 0;
			tag_t bv = NULLTAG;
			tag_t bvr = NULLTAG;
			
			ifail = ITEM_ask_item_of_rev(vcRevTag, &vcItemTag);
			ifail = ITEM_list_bom_views(vcItemTag, &bv_count, &bvs );
			
			if(bv_count)
			{
				bv = bvs[0];
				MEM_free(bvs);
			}
			else
			{
				printf("\nModuleApp: No BV... exit....\n");fflush(stdout);
				continue;
			}
			
			ifail = ITEM_rev_list_bom_view_revs(vcRevTag,&bvr_count, &bvrs);
			
			if(bvr_count)
			{	
				bvr = bvrs[0];
				MEM_free(bvrs);		
			}
			else
			{
				printf("\nModuleApp: No BVR ..exit....\n");fflush(stdout);
				continue;
			}
			
			
			if ( bv != NULLTAG )
			{
				ifail = AOM_unload( bv );					
					
			}
			
			if(bvr != NULLTAG)
			{
				tag_t window = NULLTAG;

				tag_t top_line = NULLTAG;
				char **rulename = NULL;
				char **rulevalue = NULL;
				
				ifail = BOM_create_window (&window);
				ifail = BOM_set_window_config_rule( window, rule );
				ifail = BOM_window_set_closure_rule( window,ClosureRuleTag, 0, rulename,rulevalue );
				ifail = BOM_set_window_pack_all (window, false);
				ifail = BOM_set_window_top_line (window, NULLTAG,vcRevTag, NULLTAG, &top_line);
				
				if(top_line != NULLTAG)
				{
					tag_t* child_lines = NULLTAG;
					int nChld = 0;
					int j = 0;
					//int childId = 0;
					//int childRevSeq = 0;
					char* child_id = NULL;
					char* child_rev_seq = NULL;
					//int occuid = 0;
					char* ChildUID = NULL;
					//int ruleConfigByID 	 =0;
					char* rules_configured_by = NULL;
					
					//int relStatID = 0;
					char* releaseStatusStr = NULL;
					
					char** ModuleNumList = NULL;
					int ModuleNumListCnt = 0;
					vehModuleMap vehModRDet;
					
					ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
					printf("\nModuleApp:No of child objects of Vehicle Rev are : %d\n",nChld);fflush(stdout);
					
					
					for(j=0;j<nChld;j++)
					{
						char* partnum = (char*)MEM_alloc(50* sizeof(char*));
						
						ifail = AOM_ask_value_string(child_lines[j],"bl_item_item_id",&child_id);
						ifail = AOM_ask_value_string(child_lines[j],"bl_rev_item_revision_id",&child_rev_seq);
						ifail = AOM_ask_value_string(child_lines[j], "bl_occurrence_uid", &ChildUID);
						
						ifail = AOM_ask_value_string(child_lines[j], "bl_config_string", &rules_configured_by);
						
						if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
						{
							//skip the unconigured child part.
							continue;
						}
						
						//Skip Non ERC Released Part.
						ifail = AOM_ask_value_string(child_lines[j], "bl_rev_release_status_list", &releaseStatusStr);
						
						if(tc_strcmp(revRuleStr,"ERC release and above")==0)
						{
							//printf("\nModuleApp: releaseStatusStr: [%s]",releaseStatusStr);fflush(stdout);
							if(tc_strstr(releaseStatusStr,"ERC Released")!= NULL || tc_strstr(releaseStatusStr,"T5_LcsErcRlzd")!= NULL)
							{
								//ok part to be considered for expansion.
							}
							else
							{
								
								printf("\nModuleApp: Skip APL part:%s/%s\n",child_id,child_rev_seq);fflush(stdout);
								continue;
							}								
							
						}
						
						
						tc_strcpy(partnum,child_id);
						tc_strcat(partnum,"/");
						tc_strcat(partnum,child_rev_seq);
						
						t5AddStrToSet(&ModuleNumListCnt,&ModuleNumList,partnum);
						
						int found = 0;
						t5FindStrInSet(unqModuleNumList,unqModuleNumListCnt,partnum,&found);
						if(found == 0)
						{
							t5AddStrToSet(&unqModuleNumListCnt,&unqModuleNumList,partnum);
						}
						
						
						MEM_free(partnum);
					}
					
					tc_strcpy(vehModRDet.vehicleNo,vehicleSelected[k]);
					vehModRDet.moduleNumList = ModuleNumList;
					vehModRDet.moduleCnt = ModuleNumListCnt;
					
					setAddVehModuleMap(&vehModuleRelListCnt, &vehModuleRelList,vehModRDet);
					
				}
				
				
				
				ifail = BOM_close_window(window);
			}
				
		}//End of loop of Vehicle.
		
		
		MEM_free(vcNumb);
	
	}//End of loop of Vehicle.
	
	printf("\nModuleApp:vehModuleRelListCnt[%d], Unique Module List Count[%d]",vehModuleRelListCnt, unqModuleNumListCnt);fflush(stdout);
		
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ModuleAppGenTplReport>");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ReportData>");
	
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<VehicleData>");
	for(k=0;k<no_of_Vehicles;k++)
	{
		printf("%s ", vehicleSelected[k]);fflush(stdout);
		//fprintf(vcMdlRep,"%s,",vehicleSelected[k]);fflush(vcMdlRep);
		t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<VehicleNo>");
		t5AddStrToSet(buff_cnt,bufferedXmlStrOut,vehicleSelected[k]);
		t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</VehicleNo>");
		
	}
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</VehicleData>");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<View>");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,viewStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</View>");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<Plant>");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,plantStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</Plant>");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<RevisionRule>");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,revRuleStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</RevisionRule>");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"<ClosureRule>");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,closureRuleStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ClosureRule>");
		
	
	
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ReportData>");
	
	
	
	for(k = 0; k < unqModuleNumListCnt ; k ++)
	{		
		ifail = generateModuleApplReport(unqModuleNumList[k], vehModuleRelList,vehModuleRelListCnt, ClosureRuleTag, rule,vehicleSelected,no_of_Vehicles,bufferedXmlStrOut,buff_cnt,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr,plantStr);
	}
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"</ModuleAppGenTplReport>");
	
	
	
	
	return ifail;
}


int tm_ModuleAppGenTPLReportServ(void *retValue)
{
	const char	*prog_name 	="tm_ModuleAppGenTPLReportServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nModuleApp: Start----tm_ModuleAppGenTPLReportServ....\n");fflush(stdout);
		
	char** vehicleSelected = NULL;
	int no_of_Vehicles = 0;
	char* viewStr = NULL;
	char* plantStr = NULL;
	char* closureRuleStr = NULL;
	char* revRuleStr = NULL;
	char* levelStr = NULL;
	logical dmlInfo = FALSE;
	logical drawingInfo = FALSE;
	logical remove_underscorePart = FALSE;
	logical skipzeroQty = FALSE;
	logical stopAtF = FALSE;
	logical showSuppressed = FALSE;
	
		
	//print input parameters
	USERARG_get_string_array_argument(&no_of_Vehicles,&vehicleSelected);
	USERARG_get_string_argument(&viewStr);
	USERARG_get_string_argument(&plantStr);
	USERARG_get_string_argument(&closureRuleStr);
	USERARG_get_string_argument(&revRuleStr);
	USERARG_get_logical_argument(&dmlInfo);
	USERARG_get_logical_argument(&drawingInfo);
	USERARG_get_logical_argument(&remove_underscorePart);
	USERARG_get_logical_argument(&skipzeroQty);
	USERARG_get_logical_argument(&stopAtF);
	USERARG_get_logical_argument(&showSuppressed);
	USERARG_get_string_argument(&levelStr);
		
	//printf("\nModuleApp:Input parameters:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
		
	ifail = executeModuleAppGenTPLReportLogic(no_of_Vehicles,vehicleSelected,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr,&bufferedXmlStrOut, &buff_cnt);
	
	int m =0;
	//printf("\nModuleApp:ESO Report Buff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nModuleApp:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	//printf("\nModuleApp:Before returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nModuleApp: End----tm_ModuleAppGenTPLReportServ....\n");fflush(stdout);
	return ifail;
}


/**************************CSV Logic****************************************/

int multiLevelBomExplosionCSV(tag_t partRevObj, int reqlevel, vehModuleMap * vehModuleRelList, int vehModuleRelListCnt,char** vcArray, int size, tag_t closureRule, tag_t RevRule,char*** bufferedXmlStrOut, int* buff_cnt,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* inp_Plant)
{
	int ifail = ITK_ok;
	
	

	tag_t partItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;
	
	ifail = ITEM_ask_item_of_rev(partRevObj, &partItemTag);
	ifail = ITEM_list_bom_views(partItemTag, &bv_count, &bvs );
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	else
	{
		printf("\nModuleApp: No BV... exit....\n");fflush(stdout);
		return ifail;
	}
	
	ifail = ITEM_rev_list_bom_view_revs(partRevObj,&bvr_count, &bvrs);
	
	if(bvr_count)
	{	
		bvr = bvrs[0];
		MEM_free(bvrs);		
	}
	else
	{
		printf("\nModuleApp: No BVR ..exit....\n");fflush(stdout);
		return ifail;
	}
	
	
	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}
		
	if(bvr != NULLTAG)
	{
		tag_t window = NULLTAG;
		tag_t top_line = NULLTAG;
		char **rulename = NULL;
		char **rulevalue = NULL;
		tag_t* bomLineList;
		int bomLineListCnt = 0;
		ifail = BOM_create_window (&window);
		ifail = BOM_set_window_config_rule( window, RevRule );
		ifail = BOM_window_set_closure_rule( window,closureRule, 0, rulename,rulevalue );
		ifail = BOM_set_window_pack_all (window, true);
		ifail = BOM_set_window_top_line (window, NULLTAG,partRevObj, NULLTAG, &top_line);
		
		ifail =	BOM_window_hide_unconfigured( window );
		if(showSuppressed)
		{
			ifail = BOM_window_show_suppressed( window );
		}
		else
		{
			ifail = BOM_window_hide_suppressed( window );
		}
		
		
		if(top_line != NULLTAG)
		{
			t5BomExpansionMulLevel (top_line, 0, reqlevel, &bomLineList,&bomLineListCnt,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,inp_Plant);
		}
		
		printf("\nModuleApp:Size of bomLineList:[%d]",bomLineListCnt);fflush(stdout);
		
		
		int i =0;
		for(i=0; i< bomLineListCnt; i++)
		{
			tag_t line = NULLTAG;
			//int itemid, itemrev;
			char* partStr = NULL;
			char* partRev = NULL;
			char* line_level = NULL;
			char* line_Description = NULL;
			//char* line_Description1 = NULL;
			//char* line_Description2 = NULL;
			char* line_Coated = NULL;
			char* line_ColourInd = NULL;
			char* line_Comp_Code = NULL;
			char* line_Colour_ID = NULL;
			char* line_Unit = NULL;
			char* line_quantity = NULL;
			//char* line_ModDescription1 = NULL;
			char* line_ModDescription = NULL;
			//char* line_ModDescription2 = NULL;
			
			//char* line_AddOn_Description1 = NULL;
			char* line_AddOn_Description = NULL;
			//char* line_AddOn_Description2 = NULL;			
			
			//char* line_KeyWord_Description1 = NULL;
			char* line_Keyword_Description = NULL;
			//char* line_KeyWord_Description2 = NULL;
			
			char* line_ProjectCode = NULL;
			char* line_DesignGrp = NULL;
			
			char* line_OwnerDesignUnit = NULL;
			char* line_PartType = NULL;
			char* line_PartCode = NULL;
			
			//char* line_Part_Category1 = NULL;
			//char* line_Part_Category2 = NULL;
			char* line_Part_Category = NULL;
			
			char* line_PartStatus = NULL;
			char* line_DrawingInd = NULL;
			char* line_DrawingNo = NULL;
			
			//char* line_PartMaterial1 = NULL;
			//char* line_PartMaterial2 = NULL;
			char* line_PartMaterial = NULL;
			
			char* line_Weight = NULL;
			char* line_RolledupWt = NULL;
			char* line_Mat_Thickness = NULL;
			//char* line_MatlClass1 = NULL;
			//char* line_MatlClass2 = NULL;
			char* line_MatlClass = NULL;
			
			char* line_EnvelopeDimensions = NULL;
			char* line_ApplicationOwner = NULL;
			char* line_Samples_to_be_Approved = NULL;
			char* line_Validation_Status = NULL;
			char* line_Spare_Part = NULL;
			char* line_Spare_Indicator = NULL;
			char* line_Homologation_Reqd = NULL;
			char* line_CMVR_Cert_Reqd = NULL;
			char* line_owner = NULL;
			char* line_last_mod_user = NULL;
			//char* line_Release_Status1 = NULL;
			//char* line_Release_Status2 = NULL;
			char* line_Release_Status = NULL;
			
			
			
			
			//int line_attr = 0;
			tag_t line_bl_rev = NULLTAG;
			char* line_creation_date = NULL;
			char* line_LastModifiedDate = NULL;
			
		
			line = bomLineList[i];
			
			ifail = AOM_ask_value_string (line, "bl_item_item_id", &partStr);
			
			//remove underscore part
			if(remove_underscorePart)
			{
				if (tc_strstr(partStr,"_")!=NULL)
				{
					printf("\nModuleApp: Got underscorepart :%s \n",partStr);fflush(stdout);
					continue;
				}
			}
			
			ifail = AOM_ask_value_string (line, "bl_rev_item_revision_id", &partRev);
			
			ifail = AOM_UIF_ask_value(line,"bl_level_starting_1",&line_level);
			ifail = AOM_UIF_ask_value(line,"bl_rev_object_desc",&line_Description);
			
			if(line_Description !=NULL)
			{
				STRNG_replace_str(line_Description,","," ",&line_Description);
				STRNG_replace_str(line_Description,"\n"," ",&line_Description);
			}			
			
			
			

			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Coated",&line_Coated);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ColourInd",&line_ColourInd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PrtCatCode",&line_Comp_Code);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ColourID",&line_Colour_ID);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_uom",&line_Unit);
			ifail = AOM_UIF_ask_value(line,"bl_quantity",&line_quantity);
			
			//printf("\nModuleApp:11 -skipzeroQty => %d\n",skipzeroQty);fflush(stdout);
			if(skipzeroQty)
			{
				if(atoi(line_quantity) == 0)
				{
					printf("\nModuleApp:11 Skipping 0 Qty => %s \n",partStr);fflush(stdout);	
					continue;
				} 
			}
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DocRemarks",&line_ModDescription);
			
			if(line_ModDescription !=NULL)
			{
				STRNG_replace_str(line_ModDescription,","," ",&line_ModDescription);
				STRNG_replace_str(line_ModDescription,"\n"," ",&line_ModDescription);
			}
			
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SimVal",&line_AddOn_Description);
			
			if(line_AddOn_Description !=NULL)
			{
				STRNG_replace_str(line_AddOn_Description,","," ",&line_AddOn_Description);
				STRNG_replace_str(line_AddOn_Description,"\n"," ",&line_AddOn_Description);
			}			
			
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_CategoryName",&line_Keyword_Description);
			
			if(line_Keyword_Description !=NULL)
			{
				STRNG_replace_str(line_Keyword_Description,","," ",&line_Keyword_Description);
				STRNG_replace_str(line_Keyword_Description,"\n"," ",&line_Keyword_Description);
			}
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ProjectCode",&line_ProjectCode);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DesignGrp",&line_DesignGrp);
			
			//new attr
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DsgnOwn",&line_OwnerDesignUnit);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartType",&line_PartType);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartCode",&line_PartCode);
			

			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SpareCriteria",&line_Part_Category);
			if(line_Part_Category !=NULL)
			{
				STRNG_replace_str(line_Part_Category,","," ",&line_Part_Category);
				STRNG_replace_str(line_Part_Category,"\n"," ",&line_Part_Category);
			}			

			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PartStatus",&line_PartStatus);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DrawingInd",&line_DrawingInd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_DrawingNo",&line_DrawingNo);
			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Material",&line_PartMaterial);
			if(line_PartMaterial !=NULL)
			{
				STRNG_replace_str(line_PartMaterial,","," ",&line_PartMaterial);
				STRNG_replace_str(line_PartMaterial,"\n"," ",&line_PartMaterial);
			}				


			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_Weight",&line_Weight);
			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_RolledupWt",&line_RolledupWt);
			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_MThickness",&line_Mat_Thickness);

			ifail  = AOM_UIF_ask_value(line,"bl_Design Revision_t5_MatlClass",&line_MatlClass);
			if(line_MatlClass !=NULL)
			{
				STRNG_replace_str(line_MatlClass,","," ",&line_MatlClass);
				STRNG_replace_str(line_MatlClass,"\n"," ",&line_MatlClass);
			}	

			
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_EnvelopeDimensions",&line_EnvelopeDimensions);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_ApplicationOwner",&line_ApplicationOwner);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SamplesToAppr",&line_Samples_to_be_Approved);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_PrtValiStatus",&line_Validation_Status);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SPDisposalInstr",&line_Spare_Part);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_SpareInd",&line_Spare_Indicator);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_HomologationReqd",&line_Homologation_Reqd);
			ifail = AOM_UIF_ask_value(line,"bl_Design Revision_t5_CMVRCertificationReqd",&line_CMVR_Cert_Reqd);
			ifail = AOM_UIF_ask_value(line,"awb0RevisionOwningUser",&line_owner);
			
			//ifail = BOM_line_look_up_attribute("bl_revision",&line_attr);
			ifail = AOM_ask_value_tag(line,"bl_revision",&line_bl_rev);

			ifail = AOM_UIF_ask_value(line_bl_rev,"creation_date",&line_creation_date);
			ifail = AOM_UIF_ask_value(line_bl_rev,"last_mod_date",&line_LastModifiedDate);
			
			ifail = AOM_UIF_ask_value(line,"awb0RevisionLastModifiedUser",&line_last_mod_user);
			ifail = AOM_UIF_ask_value(line,"bl_rev_release_status_list",&line_Release_Status);
			
			if(line_Release_Status !=NULL)
			{
				STRNG_replace_str(line_Release_Status,","," ",&line_Release_Status);
				STRNG_replace_str(line_Release_Status,"\n"," ",&line_Release_Status);
			}			
					
			
			//Get DML info - To do
			
			
			//Get CS
			// Getting Plant CS for line
			//char* inp_Plant = NULL;
			char* line_PlantCS = NULL;
			//inp_Plant = "CAR";
			//printf("\nModuleApp: 11top_line_input Plant ==>  %s \n",inp_Plant);fflush(stdout);
			
			if(strcmp(inp_Plant,"DHARWAD")==0)
			 {
				  //printf("\nModuleApp: Inside DWD \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_DwdMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU Pune")==0)
			 {
				  //printf("\nModuleApp: Inside CVBU Pune \n");fflush(stdout);
				  ifail  = AOM_ask_value_string(line,"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"PUVBU")==0)
			 {
				  //printf("\nModuleApp: Inside PUVBU \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PunUVMakeBuyIndicator",&line_PlantCS);
			 } 
			 else  if(strcmp(inp_Plant,"CAR")==0)
			 {
				  //printf("\nModuleApp: Inside CAR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_CarMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU JSR")==0)
			 {
				 // printf("\nModuleApp: Inside CVBU JSR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_JsrMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU LKO")==0)
			 {
				 // printf("\nModuleApp: Inside CVBU LKO \n");fflush(stdout);
				  ifail  = AOM_ask_value_string(line,"bl_Design Revision_t5_LkoMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"SMALLCAR AHD")==0)
			 {
				  //printf("\nModuleApp: Inside SMALLCAR AHD \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_AhdMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"CVBU PNR")==0)
			 {
				  //printf("\nModuleApp: Inside CVBU PNR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PnrMakeBuyIndicator",&line_PlantCS);
			 }
			 else  if(strcmp(inp_Plant,"TMLDL JSR")==0)
			 {
				  //printf("\nModuleApp: Inside TMLDL JSR \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_JdlMakeBuyIndicator",&line_PlantCS);
			 }
			 else
			 {
				  //printf("\nModuleApp: Inside other \n");fflush(stdout);
				  ifail = AOM_ask_value_string(line,"bl_Design Revision_t5_PunMakeBuyIndicator",&line_PlantCS);
			 }	

			
			char* buffStr = (char*)MEM_alloc(8000*sizeof(char*));
			tc_strcpy(buffStr,"");

			//fprintf(vcMdlRep,"\n%s,%s,%s,%s,",line_level,partStr,partRev,line_Description);fflush(vcMdlRep);
			
			char* tempStr = (char*)MEM_alloc(1000*sizeof(char*));
	
			sprintf(tempStr,"%s,%s,%s,%s,",line_level,partStr,partRev,line_Description);
			tc_strcat(buffStr,tempStr);
			if(tempStr!=NULL) MEM_free(tempStr);
			
			if(tc_strcmp(line_level,"1")==0)
			{
				
				char* moduleNoS = (char*)MEM_alloc(tc_strlen(partStr) + tc_strlen(partRev) + 5);
				
				tc_strcpy(moduleNoS,partStr);
				tc_strcat(moduleNoS,"/");
				tc_strcat(moduleNoS,partRev);
				
				int k = 0;
				for(k=0;k<size;k++)
				{

					int j = 0;
					for (j=0;j<vehModuleRelListCnt;j++)
					{
						char* vcNoS = NULL;
						vcNoS = vehModuleRelList[j].vehicleNo;
						if(tc_strcmp(vcArray[k],vcNoS) == 0)
						{
							char* fndStr = (char*)MEM_alloc(10);
							tc_strcpy(fndStr,"NO");
							char** moduleList = NULL;
							int moduleCnt = 0;
							
							moduleList = vehModuleRelList[j].moduleNumList;
							moduleCnt = vehModuleRelList[j].moduleCnt;
							
							int found = 0;
							int n = 0;
							for (n = 0; n<moduleCnt; n++)
							{
								if(tc_strcmp(moduleNoS,moduleList[n])==0)
								{
									//cout<<"Found\n";
									found++;
									tc_strcpy(fndStr,"YES");
									break;
								}
							}
							
							//fprintf(vcMdlRep,"%s,",fndStr);fflush(vcMdlRep);
							tc_strcat(buffStr,fndStr);
							tc_strcat(buffStr,",");
							
							MEM_free(fndStr);
							
							
						}
					}
					
				}
							
				
				MEM_free(moduleNoS);
			
			}
			else
			{
				int m = 0;
				for(m=0;m<size;m++)
				{
					tc_strcat(buffStr,",");
					
				}
				
			}
			
			
						
			
			//fprintf(vcMdlRep,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",line_Coated,line_ColourInd,line_Comp_Code,line_Colour_ID,line_Unit,line_quantity,line_PlantCS,line_ModDescription,line_AddOn_Description,line_Keyword_Description,line_ProjectCode,line_DesignGrp,line_OwnerDesignUnit,line_PartType,line_PartCode,line_Part_Category,line_PartStatus,line_DrawingInd,line_DrawingNo,line_PartMaterial,line_Weight,line_RolledupWt,line_Mat_Thickness,line_MatlClass,line_EnvelopeDimensions,line_ApplicationOwner,line_Samples_to_be_Approved,line_Validation_Status,line_Spare_Part,line_Spare_Indicator,line_Homologation_Reqd,line_CMVR_Cert_Reqd,line_owner,line_creation_date,line_last_mod_user,line_LastModifiedDate,line_Release_Status);fflush(vcMdlRep);	

			char* tempStr1 = (char*)MEM_alloc(7000*sizeof(char*));
			
			sprintf(tempStr1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",line_Coated,line_ColourInd,line_Comp_Code,line_Colour_ID,line_Unit,line_quantity,line_PlantCS,line_ModDescription,line_AddOn_Description,line_Keyword_Description,line_ProjectCode,line_DesignGrp,line_OwnerDesignUnit,line_PartType,line_PartCode,line_Part_Category,line_PartStatus,line_DrawingInd,line_DrawingNo,line_PartMaterial,line_Weight,line_RolledupWt,line_Mat_Thickness,line_MatlClass,line_EnvelopeDimensions,line_ApplicationOwner,line_Samples_to_be_Approved,line_Validation_Status,line_Spare_Part,line_Spare_Indicator,line_Homologation_Reqd,line_CMVR_Cert_Reqd,line_owner,line_creation_date,line_last_mod_user,line_LastModifiedDate,line_Release_Status);
			
			tc_strcat(buffStr,tempStr1);
			
			if(tempStr1!=NULL) MEM_free(tempStr1);
			
			t5AddStrToSet(buff_cnt,bufferedXmlStrOut,buffStr);
						

			if(buffStr!=NULL) MEM_free(buffStr);
			
		
		}
		
		
		
		ifail = BOM_close_window(window);
	}
	
	
	
	
	
	
	return ifail;
}


int generateModuleApplReportCSV(char* moduleNumStr, vehModuleMap * vehModuleRelList, int vehModuleRelListCnt, tag_t closureRule, tag_t RevRule,char** vcArray, int size,char*** bufferedXmlStrOut, int *buff_cnt,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* levelStr, char* plantStr)
{
	int ifail = ITK_ok;
	char* moduleNum = NULL;
	char* moduleId = NULL;
	char* revStr = NULL;
	tag_t moduleRevTag = NULLTAG;
	moduleNum = (char*)MEM_alloc(tc_strlen(moduleNumStr) + 1);
	
	tc_strcpy(moduleNum,moduleNumStr);
	
	//cout<<"Module No"<<moduleNum<<endl;
	
	if(tc_strstr(moduleNum,"/") != NULL)
	{
		moduleId = tc_strtok(moduleNum,"/");
		revStr = tc_strtok(NULL,"/");
	}
	 

	
	//Get Module Rev Tag
	ifail = getPartObjFromRevStr(moduleId,revStr, &moduleRevTag);
	if(moduleRevTag != NULLTAG)
	{
		
		printf("\nModuleApp:Found Tag Module No:[%s/%s]",moduleId,revStr);fflush(stdout);
		
		//level
		int lvl = 0;
		
		lvl=atoi(levelStr);
		
		ifail = multiLevelBomExplosionCSV(moduleRevTag, lvl, vehModuleRelList,vehModuleRelListCnt,vcArray,size,closureRule, RevRule,bufferedXmlStrOut,buff_cnt,dmlInfo,drawingInfo,remove_underscorePart, skipzeroQty,stopAtF,showSuppressed,plantStr);
		
	}
	else
	{
		printf("\nModuleApp:Not Found Tag Module No:[%s/%s]",moduleId,revStr);fflush(stdout);
	}
	
	
	if(moduleNum != NULL) MEM_free(moduleNum);
	
	return ifail;
}


int executeModuleAppGenTPLReportLogicCSV(int no_of_Vehicles,char** vehicleSelected,char* viewStr,char* plantStr,char* closureRuleStr,char* revRuleStr,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* levelStr,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	
	printf("\nModuleApp:Input parameters:executeModuleAppGenTPLReportLogicCSV:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
	
	
	tag_t rule = NULLTAG;
	int rulefound = 0;
	tag_t* ClosureRuleTags = NULLTAG;
	tag_t ClosureRuleTag = NULLTAG;

	//ifail = CFM_find("ERC release and above", &rule );
	
	ifail = CFM_find(revRuleStr, &rule );
	if(rule == NULLTAG)
	{
		printf("\n Revision Rule- [%s] Not found, Applying Default Rule\n",revRuleStr);fflush(stdout);
		ifail = CFM_find("Latest Working", &rule );
	}
	else
	{
		printf("\n Revision Rule - [%s] found\n",revRuleStr);fflush(stdout);
	}
	if(closureRuleStr == NULL) closureRuleStr="BOMViewClosureRuleERC";
	//ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
	ifail = PIE_find_closure_rules2(closureRuleStr,PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
	//ifail = PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);


	printf ("\nClosure Rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		ClosureRuleTag = ClosureRuleTags[0];
		printf ("\nClosure rule found \n");fflush(stdout);

	}

	//End of closure and rev rule
	
	//Loop through the vehicle
	int k = 0;
	vehModuleMap * vehModuleRelList = NULL;
	int vehModuleRelListCnt = 0;
	
	char** unqModuleNumList = NULL;
	int unqModuleNumListCnt = 0;
	
	
	for(k=0;k<no_of_Vehicles;k++)
	{
		//printf("\nModuleApp:[%d] - [%s]", k+1, vehicleSelected[k]);fflush(stdout);
		tag_t vcRevTag = NULLTAG;
		char* partNo = NULL;
		char* revStr = NULL;
		char* vcNumb = NULL;
		vcNumb = (char*)MEM_alloc(tc_strlen(vehicleSelected[k]) + 1);
		tc_strcpy(vcNumb,vehicleSelected[k]);
		
		printf("\nModuleApp:[%d] - [%s], [%s]", k+1, vehicleSelected[k], vcNumb);fflush(stdout);
		//Get Vehicle No, Rev and sequence
		if(tc_strstr(vcNumb,"/") != NULL)
		{
			partNo = tc_strtok(vcNumb,"/");
			revStr = tc_strtok(NULL,"/");
		}
		
		if(partNo == NULL)
		{
			continue;
		}
		else if(revStr == NULL)
		{
			ifail = getLatestERCReleasedPart(partNo,&vcRevTag);
		}
		else
		{
			ifail = getPartObjFromRevStr(partNo,revStr, &vcRevTag);
			
			if(vcRevTag == NULLTAG)
			{
				printf("\nModuleApp:Wrong Revision format:Get the latest released part");fflush(stdout);
				ifail = getLatestERCReleasedPart(partNo,&vcRevTag);
			}
		}
		
		if(vcRevTag != NULLTAG)
		{
			char* vcNum = NULL;
			char* vcRev = NULL;
			ifail = AOM_ask_value_string(vcRevTag,"item_id",&vcNum);
			ifail = AOM_ask_value_string(vcRevTag,"item_revision_id",&vcRev);
			printf("\nModuleAppSelected Part:[%s/%s]",vcNum,vcRev);fflush(stdout);
			
			//Expansion of Vehicle
			
			tag_t vcItemTag = NULLTAG;
			tag_t* bvs = NULLTAG;
			int bv_count = 0;
			tag_t* bvrs = NULLTAG;
			int bvr_count = 0;
			tag_t bv = NULLTAG;
			tag_t bvr = NULLTAG;
			
			ifail = ITEM_ask_item_of_rev(vcRevTag, &vcItemTag);
			ifail = ITEM_list_bom_views(vcItemTag, &bv_count, &bvs );
			
			if(bv_count)
			{
				bv = bvs[0];
				MEM_free(bvs);
			}
			else
			{
				printf("\nModuleApp: No BV... exit....\n");fflush(stdout);
				continue;
			}
			
			ifail = ITEM_rev_list_bom_view_revs(vcRevTag,&bvr_count, &bvrs);
			
			if(bvr_count)
			{	
				bvr = bvrs[0];
				MEM_free(bvrs);		
			}
			else
			{
				printf("\nModuleApp: No BVR ..exit....\n");fflush(stdout);
				continue;
			}
			
			
			if ( bv != NULLTAG )
			{
				ifail = AOM_unload( bv );					
					
			}
			
			if(bvr != NULLTAG)
			{
				tag_t window = NULLTAG;

				tag_t top_line = NULLTAG;
				char **rulename = NULL;
				char **rulevalue = NULL;
				
				ifail = BOM_create_window (&window);
				ifail = BOM_set_window_config_rule( window, rule );
				ifail = BOM_window_set_closure_rule( window,ClosureRuleTag, 0, rulename,rulevalue );
				ifail = BOM_set_window_pack_all (window, false);
				ifail = BOM_set_window_top_line (window, NULLTAG,vcRevTag, NULLTAG, &top_line);
				
				if(top_line != NULLTAG)
				{
					tag_t* child_lines = NULLTAG;
					int nChld = 0;
					int j = 0;
					//int childId = 0;
					//int childRevSeq = 0;
					char* child_id = NULL;
					char* child_rev_seq = NULL;
					//int occuid = 0;
					char* ChildUID = NULL;
					//int ruleConfigByID 	 =0;
					char* rules_configured_by = NULL;
					
					//int relStatID = 0;
					char* releaseStatusStr = NULL;
					
					char** ModuleNumList = NULL;
					int ModuleNumListCnt = 0;
					vehModuleMap vehModRDet;
					
					ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
					printf("\nModuleApp:No of child objects of Vehicle Rev are : %d\n",nChld);fflush(stdout);
					
					
					for(j=0;j<nChld;j++)
					{
						char* partnum = (char*)MEM_alloc(50* sizeof(char*));
						
						ifail = AOM_ask_value_string(child_lines[j],"bl_item_item_id",&child_id);
						ifail = AOM_ask_value_string(child_lines[j],"bl_rev_item_revision_id",&child_rev_seq);
						ifail = AOM_ask_value_string(child_lines[j], "bl_occurrence_uid", &ChildUID);
						
						ifail = AOM_ask_value_string(child_lines[j], "bl_config_string", &rules_configured_by);
						
						if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
						{
							//skip the unconigured child part.
							continue;
						}
						
						//Skip Non ERC Released Part.
						ifail = AOM_ask_value_string(child_lines[j], "bl_rev_release_status_list", &releaseStatusStr);
						
						if(tc_strcmp(revRuleStr,"ERC release and above")==0)
						{
							//printf("\nModuleApp: releaseStatusStr: [%s]",releaseStatusStr);fflush(stdout);
							if(tc_strstr(releaseStatusStr,"ERC Released")!= NULL || tc_strstr(releaseStatusStr,"T5_LcsErcRlzd")!= NULL)
							{
								//ok part to be considered for expansion.
							}
							else
							{
								
								//printf("\nModuleApp: Skip APL part:%s/%s\n",child_id,child_rev_seq);fflush(stdout);
								continue;
							}								
							
						}
						
						
						tc_strcpy(partnum,child_id);
						tc_strcat(partnum,"/");
						tc_strcat(partnum,child_rev_seq);
						
						t5AddStrToSet(&ModuleNumListCnt,&ModuleNumList,partnum);
						
						int found = 0;
						t5FindStrInSet(unqModuleNumList,unqModuleNumListCnt,partnum,&found);
						if(found == 0)
						{
							t5AddStrToSet(&unqModuleNumListCnt,&unqModuleNumList,partnum);
						}
						
						
						MEM_free(partnum);
					}
					
					tc_strcpy(vehModRDet.vehicleNo,vehicleSelected[k]);
					vehModRDet.moduleNumList = ModuleNumList;
					vehModRDet.moduleCnt = ModuleNumListCnt;
					
					setAddVehModuleMap(&vehModuleRelListCnt, &vehModuleRelList,vehModRDet);
					
				}
				
				
				
				ifail = BOM_close_window(window);
			}
				
		}//End of loop of Vehicle.
		
		
		MEM_free(vcNumb);
	
	}//End of loop of Vehicle.
	
	printf("\nModuleApp:vehModuleRelListCnt[%d], Unique Module List Count[%d]",vehModuleRelListCnt, unqModuleNumListCnt);fflush(stdout);
	
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,",,,,*******************Module Applicability GenTPL Report*********************,,,,,,,,,,,,,,,");
	
	char* tempS= (char*)MEM_alloc(no_of_Vehicles*100*sizeof(char*)+20);
	tc_strcpy(tempS,",Selected Vehicles,");
	for(k=0;k<no_of_Vehicles;k++)
	{
		tc_strcat(tempS,vehicleSelected[k]);
		tc_strcat(tempS,"  ");
		
	}
	tc_strcat(tempS,",");
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS);
	MEM_free(tempS);
	
	char* tempS1= (char*)MEM_alloc(100*sizeof(char*));
	tc_strcpy(tempS1,",View,");
	tc_strcat(tempS1,viewStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS1);
	MEM_free(tempS1);
	
	char* tempS2= (char*)MEM_alloc(100*sizeof(char*));
	tc_strcpy(tempS2,",Plant,");
	tc_strcat(tempS2,plantStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS2);
	MEM_free(tempS2);
	
	char* tempS3= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS3,",Revision Rule,");
	tc_strcat(tempS3,revRuleStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS3);
	MEM_free(tempS3);

	char* tempS4= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS4,",Closure Rule,");
	tc_strcat(tempS4,closureRuleStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS4);
	MEM_free(tempS4);
	
	char* tempS5= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS5,",DML Info,");
	if(dmlInfo)
	{
		tc_strcat(tempS5,"YES");
	}
	else
	{
		tc_strcat(tempS5,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS5);
	MEM_free(tempS5);
	
	char* tempS6= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS6,",Drawing Info,");
	if(drawingInfo)
	{
		tc_strcat(tempS6,"YES");
	}
	else
	{
		tc_strcat(tempS6,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS6);
	MEM_free(tempS6);
	
	char* tempS7= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS7,",Remove Underscore Part,");
	if(remove_underscorePart)
	{
		tc_strcat(tempS7,"YES");
	}
	else
	{
		tc_strcat(tempS7,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS7);
	MEM_free(tempS7);
	
	char* tempS8= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS8,",SKIP Zero Quantity,");
	if(skipzeroQty)
	{
		tc_strcat(tempS8,"YES");
	}
	else
	{
		tc_strcat(tempS8,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS8);
	MEM_free(tempS8);
	
	char* tempS9= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS9,",STOP at F,");
	if(stopAtF)
	{
		tc_strcat(tempS9,"YES");
	}
	else
	{
		tc_strcat(tempS9,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS9);
	MEM_free(tempS9);

	char* tempS10= (char*)MEM_alloc(150*sizeof(char*));
	tc_strcpy(tempS10,",Show Suppressed,");
	if(stopAtF)
	{
		tc_strcat(tempS10,"YES");
	}
	else
	{
		tc_strcat(tempS10,"NO");
	}	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS10);
	MEM_free(tempS10);
	
	char* tempS11= (char*)MEM_alloc(50*sizeof(char*));
	tc_strcpy(tempS11,",Level,");
	tc_strcat(tempS11,levelStr);
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,tempS11);
	MEM_free(tempS11);	
		
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"\n");
	
	printf("\nModuleApp:Input parameters:executeModuleAppGenTPLReportLogicCSV:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
	
	char* buffStr= (char*)MEM_alloc(3000*sizeof(char*));
	
	tc_strcpy(buffStr,"");
	tc_strcat(buffStr,"Level,Component,Revision,Description,");
	for(k=0;k<no_of_Vehicles;k++)
	{
		printf("%s ", vehicleSelected[k]);fflush(stdout);
		//fprintf(vcMdlRep,"%s,",vehicleSelected[k]);fflush(vcMdlRep);
		tc_strcat(buffStr,vehicleSelected[k]);
		tc_strcat(buffStr,",");
	}
	
	tc_strcat(buffStr,"Coated,Colour Indicator,Comp Code,Colour ID,Unit,Quantity,CS,Modification Description,AddOn Description,Keyword Description,Project Code,Design Group,Owner Design Unit,Part Type,Part Code,Part Category,Part DR Status,Drawing Indicator,Drawing No,Part Material,Weight,Rolled Up Weight,Material Thickness,Material Class,Envelope Dimensions,Application Owner,Samples to be Approved,Validation Status,Spare Part,Spare Indicator,Homologation Reqd,CMVR Cert Reqd,Owner,Creation Date,Last Modifying User,Last Modified Date,Release Status");
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,buffStr);
	
	if(buffStr!=NULL) MEM_free(buffStr);
	
	
	
	for(k = 0; k < unqModuleNumListCnt ; k ++)
	{		
		ifail = generateModuleApplReportCSV(unqModuleNumList[k], vehModuleRelList,vehModuleRelListCnt, ClosureRuleTag, rule,vehicleSelected,no_of_Vehicles,bufferedXmlStrOut,buff_cnt,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr,plantStr);
	}
	
	t5AddStrToSet(buff_cnt,bufferedXmlStrOut,"\n,,,,,,,******************End of Report*******************,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	
	
	
	
	return ifail;
}




int tm_ModuleAppGenTPLReportCSVServ(void *retValue)
{
	const char	*prog_name 	="tm_ModuleAppGenTPLReportCSVServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nModuleApp: Start----tm_ModuleAppGenTPLReportCSVServ....\n");fflush(stdout);
		
	char** vehicleSelected = NULL;
	int no_of_Vehicles = 0;
	char* viewStr = NULL;
	char* plantStr = NULL;
	char* closureRuleStr = NULL;
	char* revRuleStr = NULL;
	char* levelStr = NULL;
	logical dmlInfo = FALSE;
	logical drawingInfo = FALSE;
	logical remove_underscorePart = FALSE;
	logical skipzeroQty = FALSE;
	logical stopAtF = FALSE;
	logical showSuppressed = FALSE;
	
		
	//print input parameters
	USERARG_get_string_array_argument(&no_of_Vehicles,&vehicleSelected);
	USERARG_get_string_argument(&viewStr);
	USERARG_get_string_argument(&plantStr);
	USERARG_get_string_argument(&closureRuleStr);
	USERARG_get_string_argument(&revRuleStr);
	USERARG_get_logical_argument(&dmlInfo);
	USERARG_get_logical_argument(&drawingInfo);
	USERARG_get_logical_argument(&remove_underscorePart);
	USERARG_get_logical_argument(&skipzeroQty);
	USERARG_get_logical_argument(&stopAtF);
	USERARG_get_logical_argument(&showSuppressed);
	USERARG_get_string_argument(&levelStr);
		
	//printf("\nModuleApp:Input parameters:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
		
	ifail = executeModuleAppGenTPLReportLogicCSV(no_of_Vehicles,vehicleSelected,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr,&bufferedXmlStrOut, &buff_cnt);
	
	int m =0;
	//printf("\nModuleApp:ESO Report Buff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nModuleApp:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	//printf("\nModuleApp:Before returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nModuleApp: End----tm_ModuleAppGenTPLReportCSVServ....\n");fflush(stdout);
	return ifail;
}

/*****************************Client logic *********************************/

int isLiveModuleAppGenTPLClient(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *contrlObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "MODULEAPPRPT";
	qry_values[1] = "REPORTLOGIC";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nModuleApp:Control objects MODULEAPPRPT-REPORTLOGIC: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{					
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}


int executeModuleAppGenTPLReportLogicITK(int no_of_Vehicles,char** vehicleSelected,char* viewStr,char* plantStr,char* closureRuleStr,char* revRuleStr,logical dmlInfo,logical drawingInfo,logical remove_underscorePart,logical skipzeroQty,logical stopAtF,logical showSuppressed,char* levelStr,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	
	printf("\nModuleApp:Input parameters:executeModuleAppGenTPLReportLogicITK:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
	
	tag_t cntrlObj = NULLTAG;
	ifail = isLiveModuleAppGenTPLClient(&cntrlObj);
	
	char* vehNoS = (char*)MEM_alloc(no_of_Vehicles*50*sizeof(char*));
	
	int i = 0;
	tc_strcpy(vehNoS,"\"");
	for(i=0;i<no_of_Vehicles;i++)
	{
		tc_strcat(vehNoS,vehicleSelected[i]);
		tc_strcat(vehNoS,",");
	}
	tc_strcat(vehNoS,"\"");
	
	
	if(cntrlObj != NULLTAG)
	{		
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;
				
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//shell path
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//live flag
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
		
		
		
		printf("\nModuleApp:MODULEAPPRPT-REPORTLOGIC Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
		
		if(tc_strcmp(userInfo4,"LIVECLIENT")==0)
		{
			char* username = NULL;
			char* person_name = NULL;
			char* emailID = NULL;
			tag_t user_tag = NULLTAG;
			tag_t person_tag = NULLTAG;
			ifail = POM_get_user(&username,&user_tag);
			printf("\nModuleApp:Session User Name[%s]\n",username);fflush(stdout);
			if(user_tag!= NULLTAG)
			{
				ifail = SA_ask_user_person_name2(user_tag, &person_name);
				ifail = SA_find_person2( person_name, &person_tag);
				if(person_tag != NULLTAG)
					ifail = SA_ask_person_email_address( person_tag, &emailID );	
			}
					
			
			char* sysCmnd = NULL;
			//execute client logic.
			printf("\nCLIENT LOGIC ModuleAppGenTplReport..\n");fflush(stdout);
			sysCmnd=(char *) MEM_alloc(2000);
			tc_strcpy(sysCmnd,userInfo3);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,vehNoS);
			tc_strcat(sysCmnd," \"");
			tc_strcat(sysCmnd,viewStr);
			tc_strcat(sysCmnd,"\" \"");
			tc_strcat(sysCmnd,plantStr);
			tc_strcat(sysCmnd,"\" \"");
			tc_strcat(sysCmnd,revRuleStr);
			tc_strcat(sysCmnd,"\" \"");
			tc_strcat(sysCmnd,closureRuleStr);
			tc_strcat(sysCmnd,"\" ");
			if(dmlInfo)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");
			tc_strcat(sysCmnd," ");
			if(drawingInfo)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");
			tc_strcat(sysCmnd," ");
			//tc_strcat(sysCmnd,remove_underscorePart);
			if(remove_underscorePart)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");			
			tc_strcat(sysCmnd," ");
			//tc_strcat(sysCmnd,skipzeroQty);
			if(skipzeroQty)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");			
			tc_strcat(sysCmnd," ");
			//tc_strcat(sysCmnd,stopAtF);
			if(stopAtF)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");			
			tc_strcat(sysCmnd," ");
			//tc_strcat(sysCmnd,showSuppressed);
			if(showSuppressed)
				tc_strcat(sysCmnd,"+");
			else
				tc_strcat(sysCmnd,"-");			
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,levelStr);
			
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,emailID);			


			printf("\nModuleApp:Start-- Calling shell file tm_GenTPLModuleAppReport.sh using client system command: %s\n",sysCmnd);fflush(stdout);
			system(sysCmnd);

			printf("\nModuleApp: End --- Calling shell file tm_GenTPLModuleAppReport.sh using client system command: %s\n",sysCmnd);fflush(stdout);

			MEM_free(sysCmnd);			
			
		}
		else
		{
			printf("\nModuleApp:Not Live for client execution....info4 should be LIVECLIENT\n");fflush(stdout);
		}
		
	}
	
	
	
	
	
	
	
	
	return ifail;
}



int tm_ModuleAppGenTPLReportClientServ(void *retValue)
{
	const char	*prog_name 	="tm_ModuleAppGenTPLReportClientServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nModuleApp: Start----tm_ModuleAppGenTPLReportClientServ....\n");fflush(stdout);
		
	char** vehicleSelected = NULL;
	int no_of_Vehicles = 0;
	char* viewStr = NULL;
	char* plantStr = NULL;
	char* closureRuleStr = NULL;
	char* revRuleStr = NULL;
	char* levelStr = NULL;
	logical dmlInfo = FALSE;
	logical drawingInfo = FALSE;
	logical remove_underscorePart = FALSE;
	logical skipzeroQty = FALSE;
	logical stopAtF = FALSE;
	logical showSuppressed = FALSE;
	
		
	//print input parameters
	USERARG_get_string_array_argument(&no_of_Vehicles,&vehicleSelected);
	USERARG_get_string_argument(&viewStr);
	USERARG_get_string_argument(&plantStr);
	USERARG_get_string_argument(&closureRuleStr);
	USERARG_get_string_argument(&revRuleStr);
	USERARG_get_logical_argument(&dmlInfo);
	USERARG_get_logical_argument(&drawingInfo);
	USERARG_get_logical_argument(&remove_underscorePart);
	USERARG_get_logical_argument(&skipzeroQty);
	USERARG_get_logical_argument(&stopAtF);
	USERARG_get_logical_argument(&showSuppressed);
	USERARG_get_string_argument(&levelStr);
		
	//printf("\nModuleApp:Input parameters:no_of_Vehicles:[%d],viewStr:[%s],plantStr[%s],closureRuleStr:[%s],revRuleStr:[%s],dmlInfo:[%d],drawingInfo:[%d], remove_underscorePart:[%d], skipzeroQty:[%d], stopAtF:[%d], showSuppressed:[%d],levelStr:[%s]\n",no_of_Vehicles,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr);fflush(stdout);
		
	ifail = executeModuleAppGenTPLReportLogicITK(no_of_Vehicles,vehicleSelected,viewStr,plantStr,closureRuleStr,revRuleStr,dmlInfo,drawingInfo,remove_underscorePart,skipzeroQty,stopAtF,showSuppressed,levelStr,&bufferedXmlStrOut, &buff_cnt);
	
	int m =0;
	//printf("\nModuleApp:ESO Report Buff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nModuleApp:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	//printf("\nModuleApp:Before returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nModuleApp: End----tm_ModuleAppGenTPLReportClientServ....\n");fflush(stdout);
	return ifail;
}




extern int tm_ModuleAppGenTPLReportFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
		
	int n_args = 12;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//Selected Vehicles
	input_arg_type[1]=USERARG_STRING_TYPE;//View
	input_arg_type[2]=USERARG_STRING_TYPE;//Plant 
	input_arg_type[3]=USERARG_STRING_TYPE;//Closure Rule 
	input_arg_type[4]=USERARG_STRING_TYPE;//Revision Rule 
	input_arg_type[5]=USERARG_LOGICAL_TYPE;//DML Info
	input_arg_type[6]=USERARG_LOGICAL_TYPE;//Drawing Info
	input_arg_type[7]=USERARG_LOGICAL_TYPE;//Remove Underscore Part
	input_arg_type[8]=USERARG_LOGICAL_TYPE;//Skip Zero Qty
	input_arg_type[9]=USERARG_LOGICAL_TYPE;//stop at F 
	input_arg_type[10]=USERARG_LOGICAL_TYPE;//show suppressed occurence 
	input_arg_type[11]=USERARG_STRING_TYPE;//Level 
	
	ret_value_type = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	//printf("\nModuleApp: Status creation services start: Before registering tm_ModuleAppGenTPLReportServ userservice...");  
	ifail=USERSERVICE_register_method("tm_ModuleAppGenTPLReportServ",(USER_function_t)tm_ModuleAppGenTPLReportServ,n_args,input_arg_type,ret_value_type);
	
	
	int n_args1 = 12;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type1[0]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//Selected Vehicles
	input_arg_type1[1]=USERARG_STRING_TYPE;//View
	input_arg_type1[2]=USERARG_STRING_TYPE;//Plant 
	input_arg_type1[3]=USERARG_STRING_TYPE;//Closure Rule 
	input_arg_type1[4]=USERARG_STRING_TYPE;//Revision Rule 
	input_arg_type1[5]=USERARG_LOGICAL_TYPE;//DML Info
	input_arg_type1[6]=USERARG_LOGICAL_TYPE;//Drawing Info
	input_arg_type1[7]=USERARG_LOGICAL_TYPE;//Remove Underscore Part
	input_arg_type1[8]=USERARG_LOGICAL_TYPE;//Skip Zero Qty
	input_arg_type1[9]=USERARG_LOGICAL_TYPE;//stop at F 
	input_arg_type1[10]=USERARG_LOGICAL_TYPE;//show suppressed occurence 
	input_arg_type1[11]=USERARG_STRING_TYPE;//Level 
	
	ret_value_type1 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	//printf("\nModuleApp: Status creation services start: Before registering tm_ModuleAppGenTPLReportCSVServ userservice...");  
	ifail=USERSERVICE_register_method("tm_ModuleAppGenTPLReportCSVServ",(USER_function_t)tm_ModuleAppGenTPLReportCSVServ,n_args1,input_arg_type1,ret_value_type1);
	
	
	int n_args2 = 12;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type2[0]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//Selected Vehicles
	input_arg_type2[1]=USERARG_STRING_TYPE;//View
	input_arg_type2[2]=USERARG_STRING_TYPE;//Plant 
	input_arg_type2[3]=USERARG_STRING_TYPE;//Closure Rule 
	input_arg_type2[4]=USERARG_STRING_TYPE;//Revision Rule 
	input_arg_type2[5]=USERARG_LOGICAL_TYPE;//DML Info
	input_arg_type2[6]=USERARG_LOGICAL_TYPE;//Drawing Info
	input_arg_type2[7]=USERARG_LOGICAL_TYPE;//Remove Underscore Part
	input_arg_type2[8]=USERARG_LOGICAL_TYPE;//Skip Zero Qty
	input_arg_type2[9]=USERARG_LOGICAL_TYPE;//stop at F 
	input_arg_type2[10]=USERARG_LOGICAL_TYPE;//show suppressed occurence 
	input_arg_type2[11]=USERARG_STRING_TYPE;//Level 
	
	ret_value_type2 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	//printf("\nModuleApp: Status creation services start: Before registering tm_ModuleAppGenTPLReportCSVServ userservice...");  
	ifail=USERSERVICE_register_method("tm_ModuleAppGenTPLReportClientServ",(USER_function_t)tm_ModuleAppGenTPLReportClientServ,n_args2,input_arg_type2,ret_value_type2);
		
	
	return ifail;
}



extern DLLAPI int tm_ModuleAppGenTPLReport_register_callbacks ()
{	
    int ifail    = ITK_ok;
		
	ifail=CUSTOM_register_exit ( "tm_ModuleAppGenTPLReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_ModuleAppGenTPLReportFn);
	
  return ( ITK_ok );
}

