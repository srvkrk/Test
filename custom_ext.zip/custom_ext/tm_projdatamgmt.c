/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2020 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_projdatamgmt.c
*
* Description	: > Server side code for Chassis Barrel
*				  > 
* Module  		:	Project Data Management
* Since		    :   10-05-2020
* ENVIRONMENT	:   ITK
*
* History
*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 10-04-2020   	 Rajesh Raman Basak			    Server code for Chassis Barrel

* -----------------------------------------------------------------------------
*
*****************************************************************************/


	#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <fclasses/tc_time.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <ps/ps_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_basic.h>
#include<ics/ics.h>
#include<ics/ics2.h>
#include<ics/ics_defines.h>
#include<ics/ics_errors.h>
#include <bom/bom_errors.h>
#include <bom/bom_msg.h>
#include <bom/bomlines.h>
#include <common/tc_deprecation_macros.h>
	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}

	#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
	#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
	static int report_error(char *file, int line, char *call, int status,
	    logical exit_on_error)
	{
	    if (status != ITK_ok)
	    {
		/*int
		    n_errors = 0,
		    *severities = NULL,
		    *statuses = NULL;
			*/
			int n_errors = 0;
			const int 
				*severities=NULL,
				*statuses=NULL;
		const char
		    **messages;
			


		EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
		if (n_errors > 0)
		{
		    ECHO("\n%s\n", messages[n_errors-1]);
		    EMH_clear_errors();
		}
		else
		{
		    char *error_message_string;
		   // EMH_get_error_string (NULLTAG, status, &error_message_string);
		   EMH_ask_error_text(status,&error_message_string);
		    ECHO("\n%s\n", error_message_string);
		}

		ECHO("error %d at line %d in %s\n", status, line, file);
		ECHO("%s\n", call);

		if (exit_on_error)
		{
		    ECHO("Exiting program!\n");
		    exit (status);
		}
	    }

	    return status;
	}

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text(stat,&err_string);				\
		printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/*C substring function: It returns a pointer to the substring */
 
char *substring(char *string, int position, int length)
{
   char *pointer;
   int c;
 
   pointer = malloc(length+1);
   
   if (pointer == NULL)
   {
      printf("Unable to allocate memory.\n");
      exit(1);
   }
 
   for (c = 0 ; c < length ; c++)
   {
      *(pointer+c) = *(string+position-1);      
      string++;  
   }
 
   *(pointer+c) = '\0';
 
   return pointer;
}
//funtion to remove trailing space
void trimleadingandTrailing(char *s)
{
	int  i,j;
 
	for(i=0;s[i]==' '||s[i]=='\t';i++);
		
	for(j=0;s[i];i++)
	{
		s[j++]=s[i];
	}
	s[j]='\0';
	for(i=0;s[i]!='\0';i++)
	{
		if(s[i]!=' '&& s[i]!='\t')
				j=i;
	}
	s[j+1]='\0';
}	
int printObject(tag_t objtag)
{

               int                prop_count=0;
               char**             prop_names=NULL;
               int        num_values=0;
               char**     values =NULL;
               tag_t                   class_tag=NULLTAG;
               char                     *class_name=NULL;
               int j=0,k=0;

               logical propConstReqBool=false;

               int ifail=ITK_ok;

               printf("\n printObject()->");fflush(stdout);

     if(objtag==NULLTAG)
     {
                printf("\nNULLTAG");fflush(stdout);
                return ifail;
     }
               /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
               ITK_CALL(POM_name_of_class(class_tag, &class_name) );

*/
     char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

     ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



               ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
               printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
               // printf("\n printObject2 %d",prop_count);fflush(stdout);

               for (k=0;k<prop_count;k++)
               {
               //ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values)); //hashed for Teamcenter14 recommendation
			   ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values)); //similar new API for Teamcenter14
               tag_t prop_tag = NULLTAG;
               ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
               printf("\n %s:{,[",prop_names[k]);fflush(stdout);

               propConstReqBool=false;
               char *prop_dispay_name=NULL;
               PROP_value_type_t valtype;
               char *valtypeName=NULL;
               ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

                                                                           printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
                                                                           printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
                                                                           printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
                                                                           printf("\n]\n");fflush(stdout);

               for(j=0;j<num_values;j++)
               {
               printf("\n\t%s,",values[j]);fflush(stdout);
               }

               printf("\n },");fflush(stdout);

               }
               printf("\n]");fflush(stdout);
return ifail;
}

void setFindStr(char **view_list,int count,char *str,int *found)
{


	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

void setFindStrFrom(char **view_list,int count,char *str,int start,int *found)
{


	int k=0;
	*found=0;
	for(k=start;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

		

//Funtion to Create Chassis Barrel
int tm_ChBarrelCreFunc( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	//tag_t new_item         = NULLTAG;
	tag_t status_rel		 = NULLTAG;
	tag_t		*ChBarrel_obj	= NULLTAG;
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	logical isnew              = 0;
	int ChBarrelFlag		   = 0;
	logical 	retain;
	//Signature for iman_save
	
	   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t new_item = va_arg(largs, tag_t);
   tag_t new_rev = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	char *type_name = va_arg(largs, char *);
	va_end( largs );
	//End iman_save signature
	
	
	//signature for item create
	
	// char* item_id  = va_arg(args, char*);
    // const char* item_name = va_arg(args, char*);
    // const char* type_name = va_arg(args, char*);
    // const char* rev_id = va_arg(args, char*);
    // tag_t*      new_item = va_arg(args, tag_t*);
    // tag_t*      new_rev = va_arg(args, tag_t*);
    // tag_t       item_master_form = va_arg(args, tag_t);
    // tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	
	
	//new_item               = va_arg(args, tag_t);
	//isnew                  = va_arg(args, int);
	printf("\n inside ChBarrel creation func !! ");fflush(stdout);
	printf("\n Is ChBarrel New %d ",isnew);fflush(stdout);
	time_t 	now;
	struct 	tm	when;
	char 	CurrYear[6]		= "";
	char* from2 = CurrYear;  
	char *YearCode = MEM_alloc(10);
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);	
	strncpy(YearCode, from2+2,2);
	printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
	printf("\n--->>>>> ChBarrel Current Year >> %s  new_item=%u",CurrYear,new_item);fflush(stdout);
	
	//char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     //ITK_CALL(TCTYPE_ask_object_type(new_item,&type_tag));

     //ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));

	 //printf("\n object type_name :  %s \n",type_name);fflush(stdout);	
	 printf("\n type_name changed by Muktesh\n");fflush(stdout);	
	
	//if(new_item != NULLTAG && isnew >1)
	
		char *loc 	   = NULL;
		char *ProjCode 	   = NULL;
		char **DesignGroupList = NULL;
		char **DMLMdAddList = NULL;
		char *SrlNo   = NULL;
		
		char *locDup 	   = NULL;
		char *ProjCodeDup 	   = NULL;
		
		char *ChType1stBarrel 	   = NULL;
		char *ChType1stBarrelDup 	   = NULL;
		char *ChIndexType 	   = NULL;
		char *ChIndexTypeDup 	   = NULL;
		char *ChVehModel 	   = NULL;
		char *ChVehModelDup 	   = NULL;
		char *ToBeNewChBarrelNo 	   = NULL;
		char *ToBeNewChBarrelNoDup 	   = NULL;
		char *ChBarrelVehModNum 	   = NULL;
		char *ChBarrelVehModNumDup 	   = NULL;
		char *comma 	   = NULL;
		//char *ChBarrelVehModNumDup 	   = NULL;
		char *NOx 	   = NULL;
		char *SrlNoDup 	   = NULL;
		char *ChBarrelIntentNum 	   = NULL;
		char *ChBarrelIntentNumDup 	   = NULL;
		char *ExChBarrelNo 	   = NULL;
		char *ExChBarrelNoDup 	   = NULL;
		char *IntentNoToBe 	   = NULL;
		//char *ChType1stBarrelDup 	   = NULL;
		char *ChBarrelDesc		= NULL;
		char *ChBarrelDescDup		= NULL;
		char *subStrr		= NULL;
		int	 num,mad,i	   = 0;
		int Flag		   = 0;
		int		status;	
		printf("\n inside class ChBarrel CRE......\n");fflush(stdout);
		if(new_item)
		{
		//printObject(new_item);	
		
		
		AOM_ask_value_string( new_item, "t5_ChassisType1", &ChType1stBarrel);
		AOM_ask_value_string( new_item, "t5_IndexType1", &ChIndexType);
		AOM_ask_value_string( new_item, "object_desc", &ChBarrelDesc);
		AOM_ask_value_string( new_item, "t5_VehicleModel1", &ChVehModel);  
		}
	
		printf("\n ChType1stBarrel : %s\n",ChType1stBarrel);fflush(stdout);
		printf("\n ChIndexType : %s\n",ChIndexType);fflush(stdout);
		printf("\n ChVehModel : %s\n",ChVehModel);fflush(stdout);
		printf("\n ChBarrelDesc : %s\n",ChBarrelDesc);fflush(stdout);
		if(ChType1stBarrel)
		{
			tc_strdup(ChType1stBarrel,&ChType1stBarrelDup);
		}
		if(ChIndexType)
		{
			tc_strdup(ChIndexType,&ChIndexTypeDup);
		}
		if(ChVehModel)
		{
			tc_strdup(ChVehModel,&ChVehModelDup);
		}
		if(ChBarrelDesc)
		{
			tc_strdup(ChBarrelDesc,&ChBarrelDescDup);
		}
		printf("\n ChType1stBarrelDup : %s  ChIndexTypeDup : %s ChVehModelDup : %s  ChBarrelDescDup :%s\n",ChType1stBarrelDup,ChIndexTypeDup,ChVehModelDup,ChBarrelDescDup);fflush(stdout);
		//Attr Values which will decide to create ChBarrel Intent approval object
		
		
		if(tc_strlen(ChType1stBarrelDup)<=0)
		{
			printf("\n 1Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Chassis_Type_No_First_Barrel can not be NULL:- \n ",ChType1stBarrelDup);
			printf("\n 2Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
			return ITK_err;
		}
		if(tc_strlen(ChIndexTypeDup)<=0)
		{
			printf("\n 1Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Index Number can not be NULL:- \n ",ChIndexTypeDup);
			printf("\n 2Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
			return ITK_err;
		}
		if(tc_strlen(ChVehModelDup)<=0)
		{
			printf("\n 1Inside Err ChVehModelDup :: %s\n",ChVehModelDup);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Vehicle Model Name can not be NULL:- \n ",ChVehModelDup);
			printf("\n 2Inside Err ChVehModelDup :: %s\n",ChVehModelDup);fflush(stdout);
			return ITK_err;
		}
		if(tc_strlen(ChIndexTypeDup)>1) 
		{
			tc_strdup(",",&comma);
			subStrr=(char *)substring(ChIndexTypeDup,0,3);
			printf("\n subStrr :%s comma=%s\n",subStrr,comma);fflush(stdout);
			/* if (tc_strstr(subStrr,comma)==NULL )
			{
				Flag=1;
			}
			else
			{
				subStrr=substring(ChIndexTypeDup,0,2);
				if (tc_strstr(subStrr,comma)==NULL )
				{
					Flag=1;
				}
			} */
			printf("\n 11subStrr :%s comma=%s\n",subStrr,comma);fflush(stdout);
			printf("\n Flag :%d\n",Flag);fflush(stdout);
			
			if( tc_strlen(ChType1stBarrelDup) >3 )
			{
			printf("\n Given Chassis Barrel is not valid value,Chassis Barrel must be of THREE digits Barrel already available with input value:-%s !!! \n",ChType1stBarrelDup);fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s2(EMH_severity_error,ITK_err,"Given Chassis Barrel is not valid value,Chassis Barrel must be of THREE digits Barrel already available with input value:- \n ",ChType1stBarrelDup);
			//decision = EPM_nogo;
			return ITK_err;
				
			}
			
			//Need to use Query Builder to get ChBarrel Object to decide for new creation.....
			char *qry_entries3[] = {"Chassis_Type_No_First_Barrel","Index Number"};
			char *qry_values3[] = {ChType1stBarrelDup,ChIndexTypeDup};
			//CALLAPI(QRY_find("CHBarrel", &query)); //hashed for Teamcenter14 recommendation
			CALLAPI(QRY_find2("CHBarrel", &query)); //similar new API for Teamcenter14
			CALLAPI(QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &ChBarrel_obj));
			printf("\n \n number of ChBarrel objs : %d \n",n_found);fflush(stdout);			
			if (n_found != 0)
			{
				tag_t 		ChBarrel_tag = 	NULLTAG;
				tag_t *QryChBarrelobjset                        		= NULLTAG;
				char *NewChBarrelNo=NULL;
				char *IntNumStr=NULL;
				char *tmpStr= NULL;
				char *FuelType=NULL;
				char *QryChIndexType = NULL;
				char *QryChIndexTypeDup = NULL;
				char *QryChType1stBarrel = NULL;
				char *QryChType1stBarrelDup = NULL;
				tag_t status_rel		 = NULLTAG;
				
				int ChBarrelcnt=0;
				NewChBarrelNo = (char *) MEM_alloc( 50 * sizeof(char) );
				IntNumStr = (char *) MEM_alloc( 50 * sizeof(char) );
				
				printf("\n \n inside cond number of ChBarrel objs : %d \n",n_found);fflush(stdout);
				for(i=0;i<n_found;i++)
				{
				
					ChBarrel_tag = ChBarrel_obj[i];			
				
					if(ChBarrel_tag)
					{
						AOM_ask_value_string( ChBarrel_tag, "t5_VehicleModel1", &ChBarrelVehModNum);
						printf( "ChBarrelVehModNum:%s\n", ChBarrelVehModNum);fflush(stdout);
						AOM_ask_value_string( ChBarrel_tag, "t5_ChassisType1", &QryChType1stBarrel);
						AOM_ask_value_string( ChBarrel_tag, "t5_IndexType1", &QryChIndexType);
						if(ChBarrelVehModNum)
						{
							 tc_strdup(ChBarrelVehModNum,&ChBarrelVehModNumDup);	
							printf( "ChBarrelVehModNumDup:%s\n", ChBarrelVehModNumDup);fflush(stdout);
						}
						if(QryChType1stBarrel)
						{
							 tc_strdup(QryChType1stBarrel,&QryChType1stBarrelDup);	
							printf( "QryChType1stBarrelDup:%s\n", QryChType1stBarrelDup);fflush(stdout);
						}
						if(QryChIndexType)
						{
							 tc_strdup(QryChIndexType,&QryChIndexTypeDup);	
							printf( "QryChIndexTypeDup:%s\n", QryChIndexTypeDup);fflush(stdout);
						}
						
						printf("\ninput ChType1stBarrelDup [%s], Existing QryChType1stBarrelDup[%s]  \n",ChType1stBarrelDup,QryChType1stBarrelDup);fflush(stdout);
						if(tc_strcmp(ChType1stBarrelDup,QryChType1stBarrelDup)==0)
						{
							EMH_clear_errors();
							status=EMH_store_error_s2(EMH_severity_error,ITK_err,"This Chassis Barrel Type already exists..Pls enter unique Chassis Barrel Type No:- \n ",ChType1stBarrelDup);
							printf("\nInside Err QryChType1stBarrelDup :: %s\n",QryChType1stBarrelDup);fflush(stdout);
							return ITK_err;
						}
						
						
						printf("\ninput Index number [%s], Existing Index number[%s] is \n",ChIndexTypeDup,QryChIndexTypeDup);fflush(stdout);
						if(tc_strcmp(ChIndexTypeDup,QryChIndexTypeDup)==0)
						{
							EMH_clear_errors();
							status=EMH_store_error_s2(EMH_severity_error,ITK_err,"This Index No  already exists.Pls enter unique Index No:- \n ",ChIndexTypeDup);
							printf("\nInside Err QryChIndexTypeDup :: %s\n",QryChIndexTypeDup);fflush(stdout);
							return ITK_err;
						}
						
						
							
							
					}
				}

			}
			//else
			//{
					//Here need to build the auto Intent Number logic
					// printf("\nGoing to set Chassis Barrel no in Item_id :: %s Flag=%d subStrr=%s\n",ChType1stBarrelDup,Flag,subStrr);fflush(stdout);
						// printf("\n b4 set ChType1stBarrelDup = %s ToBeNewChBarrelNoDup = %s  for create ChBarrel object !!\n",ChType1stBarrelDup,ChIndexTypeDup);fflush(stdout);
						// CALLAPI(AOM_lock(new_item));
						// if(Flag==1)
						// {
							//AOM_set_value_string(new_item,"t5_IndexType1", subStrr);
							// AOM_set_value_string(new_item,"t5_IndexType1", ChIndexTypeDup);
						// }
						//AOM_set_value_string(new_item,"item_id", ChType1stBarrelDup);
						//AOM_set_value_string(new_item,"t5_ChBarrelNo", ToBeNewChBarrelNoDup);
						//AOM_set_value_string(new_item,"t5_Intent_4", runningSrlChar);
						//AOM_set_value_string(new_item,"object_name", ChBarrelDescDup);
						// CALLAPI(AOM_save_with_extensions(new_item));						
						// CALLAPI(AOM_unlock(new_item));
						//CALLAPI(AOM_lock(new_rev));
						//AOM_set_value_string(new_rev,"object_name", ChBarrelDescDup);
						//CALLAPI(AOM_save_with_extensions(new_rev));						
						//CALLAPI(AOM_unlock(new_rev));
						// printf("\nB4 Release status T5_LcsReview added to ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
						// CALLAPI(CR_create_release_status("T5_LcsReview",&status_rel)); 
						// if(status_rel)
						// CALLAPI(RELSTAT_add_release_status(status_rel,1,&new_item,retain));  
						// printf("\nAfter Release status T5_LcsReview added to ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
						/*CALLAPI(AOM_lock(item_master_form));
						printf("\nB4 set ChType1stBarrelDup :: %s in object_name with val[%s]\n",ChType1stBarrelDup,ChBarrelDescDup);fflush(stdout);
						printObject(item_master_form);	
						AOM_set_value_string(item_master_form,"object_name", ChType1stBarrelDup);
						CALLAPI(AOM_save_with_extensions(item_master_form));						
						CALLAPI(AOM_unlock(item_master_form));
						printf("\nAfter set ChType1stBarrelDup :: %s in object_name for item_master_form\n",ChType1stBarrelDup);fflush(stdout);
						printObject(item_master_form);
						char *rev_master_form_id=NULL;
						rev_master_form_id=MEM_alloc(30);
						tc_strcpy(rev_master_form_id,ChType1stBarrelDup); 
						tc_strcat(rev_master_form_id,"/"); 
						tc_strcat(rev_master_form_id,rev_id); 
						printf("\nB4 set ChType1stBarrelDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
						CALLAPI(AOM_lock(item_rev_master_form));
						CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
						CALLAPI(AOM_save_with_extensions(item_rev_master_form));
						CALLAPI(AOM_unlock(item_rev_master_form));
						printf("\nAfter set ChType1stBarrelDup :: %s in object_name for item_rev_master_form\n",rev_master_form_id);fflush(stdout);
						*/
					
					
				
					
				
				
				
			//}
			printf("\nChBarrel object created with ChType1stBarrelDup :: %s ToBeNewChBarrelNoDup = %s \n",ChType1stBarrelDup,ToBeNewChBarrelNoDup);fflush(stdout);
		}
		
			
	MEM_free(ChBarrel_obj);
	
	return 0;
}


//Funtion to Create Chassis Type Number by overriding iman_save
int tm_ChTypeNumberCreFunc( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	//tag_t new_item         = NULLTAG;
	tag_t status_rel		 = NULLTAG;
	//tag_t		*tm_ChTypeNumberCreFunc_obj	= NULLTAG;
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	logical isnew              = 0;
	int tm_ChTypeNumberCreFuncFlag		   = 0;
	logical 	retain;
	//Signature for iman_save
	
	   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t new_item = va_arg(largs, tag_t);
   tag_t new_rev = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	char *type_name = va_arg(largs, char *);
	va_end( largs );
	//End iman_save signature
	
	
	//signature for item create
	
	// char* item_id  = va_arg(args, char*);
    // const char* item_name = va_arg(args, char*);
    // const char* type_name = va_arg(args, char*);
    // const char* rev_id = va_arg(args, char*);
    // tag_t*      new_item = va_arg(args, tag_t*);
    // tag_t*      new_rev = va_arg(args, tag_t*);
    // tag_t       item_master_form = va_arg(args, tag_t);
    // tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	
	
	//new_item               = va_arg(args, tag_t);
	//isnew                  = va_arg(args, int);
	printf("\n inside tm_ChTypeNumberCreFunc creation func !! ");fflush(stdout);
	printf("\n Is tm_ChTypeNumberCreFunc New %d ",isnew);fflush(stdout);
	time_t 	now;
	struct 	tm	when;
	char 	CurrYear[6]		= "";
	char* from2 = CurrYear;  
	char *YearCode = MEM_alloc(10);
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);	
	strncpy(YearCode, from2+2,2);
	printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
	printf("\n--->>>>> tm_ChTypeNumberCreFunc Current Year >> %s  new_item=%u",CurrYear,new_item);fflush(stdout);
	
	//char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     //ITK_CALL(TCTYPE_ask_object_type(new_item,&type_tag));

     //ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));

	 //printf("\n object type_name :  %s \n",type_name);fflush(stdout);	
	printf("\n Changed by Muktesh\n");fflush(stdout);	
	//if(new_item != NULLTAG && isnew >1)
	
		char *loc 	   = NULL;
		char *ProjCode 	   = NULL;
		char **DesignGroupList = NULL;
		char **DMLMdAddList = NULL;
		char *SrlNo   = NULL;
		
		char *locDup 	   = NULL;
		char *ProjCodeDup 	   = NULL;
		
		char *ChType1stBarrel 	   = NULL;
		char *ChType1stBarrelDup 	   = NULL;
		char *ChIndexType 	   = NULL;
		char *ChIndexTypeDup 	   = NULL;
		char *ChVehModel 	   = NULL;
		char *ChVehModelDup 	   = NULL;
		char *ToBeNewtm_ChTypeNumberCreFuncNo 	   = NULL;
		char *ToBeNewtm_ChTypeNumberCreFuncNoDup 	   = NULL;
		char *tm_ChTypeNumberCreFuncVehModNum 	   = NULL;
		char *tm_ChTypeNumberCreFuncVehModNumDup 	   = NULL;
		char *comma 	   = NULL;
		//char *tm_ChTypeNumberCreFuncVehModNumDup 	   = NULL;
		char *NOx 	   = NULL;
		char *SrlNoDup 	   = NULL;
		char *tm_ChTypeNumberCreFuncIntentNum 	   = NULL;
		char *tm_ChTypeNumberCreFuncIntentNumDup 	   = NULL;
		char *Extm_ChTypeNumberCreFuncNo 	   = NULL;
		char *Extm_ChTypeNumberCreFuncNoDup 	   = NULL;
		char *IntentNoToBe 	   = NULL;
		//char *ChType1stBarrelDup 	   = NULL;
		char *tm_ChTypeNumberCreFuncDesc		= NULL;
		char *tm_ChTypeNumberCreFuncDescDup		= NULL;
		char *subStrr		= NULL;
		char *ChTypeNum = NULL;
		int	 num,mad,i	   = 0;
		int Flag		   = 0;
		int		status;	
		printf("\n inside class tm_ChTypeNumberCreFunc CRE......\n");fflush(stdout);
		if(new_item)
		{
		//printObject(new_item);	
		
		ChTypeNum=MEM_alloc(30);
		AOM_ask_value_string( new_item, "t5_ChassisTypeNo", &ChType1stBarrel);
		AOM_ask_value_string( new_item, "t5_IndexType1", &ChIndexType);
		//AOM_ask_value_string( new_item, "object_desc", &tm_ChTypeNumberCreFuncDesc);
		//AOM_ask_value_string( new_item, "t5_VehicleModel1", &ChVehModel);  
		}
	
		printf("\n ChType1stBarrel : %s\n",ChType1stBarrel);fflush(stdout);
		printf("\n ChIndexType : %s\n",ChIndexType);fflush(stdout);
		//printf("\n ChVehModel : %s\n",ChVehModel);fflush(stdout);
		//printf("\n tm_ChTypeNumberCreFuncDesc : %s\n",tm_ChTypeNumberCreFuncDesc);fflush(stdout);
		if(ChType1stBarrel)
		{
			tc_strdup(ChType1stBarrel,&ChType1stBarrelDup);
			
		}
		if(ChIndexType)
		{
			tc_strdup(ChIndexType,&ChIndexTypeDup);
			
		}
		// if(ChVehModel)
		// {
			// tc_strdup(ChVehModel,&ChVehModelDup);
		// }
		// if(tm_ChTypeNumberCreFuncDesc)
		// {
			// tc_strdup(tm_ChTypeNumberCreFuncDesc,&tm_ChTypeNumberCreFuncDescDup);
		// }
		printf("\n ChType1stBarrelDup : %s  ChIndexTypeDup : %s tc_strlen(ChType1stBarrelDup):-%d\n",ChType1stBarrelDup,ChIndexTypeDup,tc_strlen(ChType1stBarrelDup));fflush(stdout);
		//Attr Values which will decide to create tm_ChTypeNumberCreFunc Intent approval object
				
		
		if(tc_strlen(ChType1stBarrelDup)<6)
		{
			//tc_strcpy(ChTypeNum,ChIndexTypeDup);
			//tc_strcat(ChTypeNum,projcode);
			printf("\n 1Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Chassis Type Number Should not be less than six : \n ",ChType1stBarrelDup);
			printf("\n 2Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
			return ITK_err;
		}
		
		
		if(tc_strlen(ChIndexTypeDup)<=0)
		{
			//tc_strcpy(ChTypeNum,ChIndexTypeDup);
			//tc_strcat(ChTypeNum,projcode);
			printf("\n 1Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Index Number can not be NULL : \n ",ChIndexTypeDup);
			printf("\n 2Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
			return ITK_err;
		}
			
	//MEM_free(tm_ChTypeNumberCreFunc_obj);
	
	return 0;
}


//Funtion to validation in Chassis Type Number by overrriding item_create 
int tm_ChTypeNumItemCreFunc( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	//tag_t new_item         = NULLTAG;
	tag_t status_rel		 = NULLTAG;
	tag_t		*ChBarrel_obj	= NULLTAG;
	tag_t        query           = NULLTAG;
	tag_t        *t_item1           = NULLTAG;
	int          n_found         = 0;
	logical isnew              = 0;
	int tm_ChTypeNumberCreFuncFlag		   = 0;
	logical 	retain;
	char *ChTypeNum =NULL;
	//Signature for iman_save
	
	   /* va_list for BOMLine_add_msg */
   // va_list largs;
   // va_copy( largs, args );               
   // tag_t new_item = va_arg(largs, tag_t);
   // tag_t new_rev = va_arg(largs, tag_t);
   // logical  isNew = va_arg(args, int);
	// char *type_name = va_arg(largs, char *);
	// va_end( largs );
	//End iman_save signature
	
	
	//signature for item create
	
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	
	
	//new_item               = va_arg(args, tag_t);
	//isnew                  = va_arg(args, int);
	printf("\n inside tm_ChTypeNumItemCreFunc creation func !! ");fflush(stdout);
	//printf("\n Is tm_ChTypeNumItemCreFunc New %d ",isnew);fflush(stdout);
	time_t 	now;
	struct 	tm	when;
	char 	CurrYear[6]		= "";
	char* from2 = CurrYear;  
	char *YearCode = MEM_alloc(10);
	time(&now);
	when = *localtime(&now);
	char *basepart=MEM_alloc(10);
	//ChTypeNum=MEM_alloc(30);
	const char *select_attrs[]={"t5_ChassisTypeNo"};
	int n_rows;
	int n_cols;
	int row;
	int column;
	void ***report;
	char vals[6];
	char FinalItemId[10];
	char TobeCHTypeNum[10];
	char *subStrr		= NULL;
	int	 num,mad,i	   = 0;
	int Flag		   = 0;
	int		status;	
	char *ChType1stBarrel 	   = NULL;
	char *ChType1stBarrelDup 	   = NULL;
	char *ChIndexType 	   = NULL;
	char *ChIndexTypeDup 	   = NULL;
	strftime(CurrYear,100,"%y",&when);	
	strncpy(YearCode, from2+2,2);
	printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout);	
	printf("\n--->>>>> tm_ChTypeNumItemCreFunc Current Year >> %s  new_item=%u",CurrYear,new_item);fflush(stdout);
	
	
     tag_t type_tag = NULLTAG;
 	 //printf("\n object type_name :  %s \n",type_name);fflush(stdout);	
		
		printf("\n inside class tm_ChTypeNumItemCreFunc CRE......\n");fflush(stdout);
		// if(new_item)
		// {
		// printObject(*new_item);	
		// }
		
		AOM_ask_value_string( *new_item, "t5_ChassisTypeNo", &ChType1stBarrel);
		AOM_ask_value_string( *new_item, "t5_IndexType1", &ChIndexType);
		//AOM_ask_value_string( new_item, "object_desc", &tm_ChTypeNumberCreFuncDesc);
		//AOM_ask_value_string( new_item, "t5_VehicleModel1", &ChVehModel);  
		
	
		printf("\ninside tm_ChTypeNumItemCreFunc ChType1stBarrel : %s\n",ChType1stBarrel);fflush(stdout);
		printf("\ninside tm_ChTypeNumItemCreFunc ChIndexType : %s\n",ChIndexType);fflush(stdout);
		//printf("\n ChVehModel : %s\n",ChVehModel);fflush(stdout);
		//printf("\n tm_ChTypeNumberCreFuncDesc : %s\n",tm_ChTypeNumberCreFuncDesc);fflush(stdout);
		if(ChType1stBarrel)
		{
			tc_strdup(ChType1stBarrel,&ChType1stBarrelDup);
			trimleadingandTrailing(ChType1stBarrel);
			printf("\niafter trimleadingandTrailing ChType1stBarrel : %s\n",ChType1stBarrel);fflush(stdout);
			ChTypeNum=substring(ChType1stBarrel,1,3);
			
			printf("\n \n after substring ChTypeNum : %s \n",ChTypeNum);fflush(stdout);
			//Need to use Query Builder to get ChBarrel Object to decide whether input index number is valid or not.....
			char *qry_entries3[] = {"Chassis_Type_No_First_Barrel","Index Number"};
			char *qry_values3[] = {ChTypeNum,""};
			//CALLAPI(QRY_find("CHBarrel", &query)); //hashed for Teamcenter14 recommendation
			CALLAPI(QRY_find2("CHBarrel", &query)); //similar new API for Teamcenter14
			CALLAPI(QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &ChBarrel_obj));
			printf("\n \n tm_ChTypeNumItemCreFunc number of ChBarrel objs : %d \n",n_found);fflush(stdout);			
			if (n_found <= 0)
			{
				printf("\n tm_ChTypeNumItemCreFunc 1Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Chassis Type No can not be created as Chassis Barrel is not present in  system,First three digit of chassis type no and chassis barrel should be same. \n ",ChTypeNum);
				printf("\n tm_ChTypeNumItemCreFunc 2Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
				return ITK_err;
			}
		}
		if(ChIndexType)
		{
			tc_strdup(ChIndexType,&ChIndexTypeDup);
			
			//Need to use Query Builder to get ChBarrel Object to decide whether input index number is valid or not.....
			char *qry_entries3[] = {"Chassis_Type_No_First_Barrel","Index Number"};
			char *qry_values3[] = {"",ChIndexTypeDup};
			//CALLAPI(QRY_find("CHBarrel", &query)); //hashed for Teamcenter14 recommendation
			CALLAPI(QRY_find2("CHBarrel", &query)); //similar new API for Teamcenter14
			CALLAPI(QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &ChBarrel_obj));
			printf("\n \n tm_ChTypeNumItemCreFunc number of ChBarrel objs : %d \n",n_found);fflush(stdout);			
			if (n_found <= 0)
			{
				printf("\n tm_ChTypeNumItemCreFunc 1Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s2(EMH_severity_error,ITK_err,"input Index Number is not matching with any Chassis Barrel's Index Number ,Enter the valid Index Number : \n ",ChIndexTypeDup);
				printf("\n tm_ChTypeNumItemCreFunc 2Inside Err ChIndexTypeDup :: %s\n",ChIndexTypeDup);fflush(stdout);
				return ITK_err;
			}
			
		}
		
		printf("\nInside tm_ChTypeNumItemCreFunc ChType1stBarrelDup : %s  ChTypeNum : %s \n",ChType1stBarrelDup,ChTypeNum);fflush(stdout);
		//Attr Values which will decide to create tm_ChTypeNumberCreFunc Intent approval object
		
				
				/*tc_strcpy(FinalItemId,ChTypeNum);
				tc_strcat(FinalItemId,"*");
				tc_strcpy(TobeCHTypeNum,ChTypeNum);
				*/
				tc_strcpy(FinalItemId,ChType1stBarrelDup);
				tc_strcat(FinalItemId,"*");
				const char *str_list[10]={FinalItemId};
				printf("\nstr_list[0]=%s",str_list[0]);
				//Create Start
				
				      printf("\nB4 query Build FinalItemId=%s TobeCHTypeNum=%s",FinalItemId,TobeCHTypeNum);
					CALLAPI(POM_enquiry_create ("find_ChTypeNum_by_type"));
					CALLAPI(POM_enquiry_add_select_attrs ("find_ChTypeNum_by_type","T5_ChnDlg", 1, select_attrs));
					CALLAPI(POM_enquiry_set_string_value ("find_ChTypeNum_by_type","attrval",1,str_list,POM_enquiry_bind_value));
					CALLAPI(POM_enquiry_set_attr_expr ("find_ChTypeNum_by_type","expr1", "T5_ChnDlg","t5_IndexType1",POM_enquiry_like, "attrval"));
					CALLAPI(POM_enquiry_set_where_expr ("find_ChTypeNum_by_type","expr1"));
					CALLAPI(POM_enquiry_add_order_attr( "find_ChTypeNum_by_type", "T5_ChnDlg", "t5_IndexType1", POM_enquiry_desc_order ));
					CALLAPI(POM_enquiry_execute("find_ChTypeNum_by_type", &n_rows, &n_cols, &report));
					CALLAPI(POM_enquiry_delete("find_ChTypeNum_by_type")); 
					
							printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",FinalItemId,n_rows,n_cols,report);
						for (row = 0; row < n_rows; row++)
						{
						for (column = 0; column < n_cols; column++)
						printf("\n Query return=%s\t", report[row][column]);
					
						}
						printf("\n Row =%d Column =%d\t", n_rows,n_cols);
						if(n_rows==0 )
						{
						printf("\nInside start Base part of chassis type number=%s",basepart);
						
						
						
						//tc_strcpy(basepart,"001");
						}
						else
						{
							/* printf("\nInside Base part of chassis type number increment condition=%s ",basepart);
							char *tmpStr=report[0][0];
							printf("\ntmpStr=%s",tmpStr);
							//char *str=substring(tmpStr,9,tc_strlen(tmpStr));
							int last3dig=atoi(substring(tmpStr,4,tc_strlen(tmpStr)));
							last3dig=last3dig+1;
							printf("\n str=%d",last3dig);
							sprintf(vals,"%.3d",last3dig);
							printf("\nInside vals=%s",vals);
					     	strcpy(basepart,vals); */
							
							printf("\n Input Chassis Type Number is already exist in system 1Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s2(EMH_severity_error,ITK_err,"Input Chassis Type Number is already exist in system , Enter valid Chassis Type Number\n ",ChTypeNum);
							printf("\n tm_ChTypeNumItemCreFunc3Inside Err ChType1stBarrelDup :: %s\n",ChType1stBarrelDup);fflush(stdout);
							return ITK_err;
						} 
				//printf("\nTo be create Chassis Type Number=%s",basepart);
				
						
		
		/* if(tc_strlen(ChIndexTypeDup)>1) 
		{
			printf("\n \n Inside to be set Chassis Type Number  : %s  TobeCHTypeNum=%s\n",basepart,TobeCHTypeNum);fflush(stdout);
			tc_strcat(TobeCHTypeNum,basepart);
			CALLAPI(AOM_lock(*new_item));
			printf("\nTo be create Chassis Type Number=%s with TobeCHTypeNum=%s",basepart,TobeCHTypeNum);
				CALLAPI( AOM_set_value_string(*new_item, "t5_ChassisTypeNo", TobeCHTypeNum));
				printf("\nAfter Chassis Type Number=%s set",TobeCHTypeNum);
				CALLAPI(AOM_save_with_extensions(*new_item));
				printf("\nAfter Chassis Type Number AOM_save_with_extensions call");
				CALLAPI(AOM_unlock(*new_item));
				printf("\nAfter Chassis Type Number AOM_unlock call");
				
			

			
			
			printf("\ntm_ChTypeNumItemCreFunc object created with ChType1stBarrelDup :: %s \n",basepart);fflush(stdout);
		} */
		printf("\n End of tm_ChTypeNumItemCreFunc object created with ChType1stBarrelDup :: %s \n",ChType1stBarrelDup);fflush(stdout);
			
	//MEM_free(tm_ChTypeNumberCreFunc_obj);
	
	return 0;
}

// Func to getting Vehicle from Tech Spec ObjectChassisTypeNum 
extern DLLAPI int getVehfrmChassisTypeNum(tag_t ChassisTypeNumObj,tag_t* VehFrmTS)
{

	 printf("\n Start func getVehfrmChassisTypeNum\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;


	ITK_CALL(GRM_find_relation_type("T5_HasChassisTypeNo", &relType));

	printf("\n ChassisTypeNumObj=%u relType=%u\n",ChassisTypeNumObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(ChassisTypeNumObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{

		*VehFrmTS = primary_objects[0];
		}

	}
	return ifail;	

	printf("\n End func getVehfrmChassisTypeNum\n");fflush(stdout);

}
//Get Vehicle from chassis Type Number object
//t5_ChassisTypeforAssm
	extern DLLAPI int getVehRelationFrmCHTypeNum(METHOD_message_t * message, va_list args )
	{

	printf("\n Start func getVehRelationFrmCHTypeNum\n");fflush(stdout);
    int ifail = ITK_ok;
	tag_t *VehTag=NULLTAG;
	

        tag_t CHTypeNumTag= message->object_tag;

        va_list largs;

        va_copy( largs, args);
        va_arg( largs, tag_t );
        VehTag = va_arg( largs, tag_t*);
        va_end( largs );

		

			printf("\n Calling func getVehfrmChassisTypeNum\n");fflush(stdout);
			ITK_CALL(getVehfrmChassisTypeNum(CHTypeNumTag,VehTag));

			printf("\n After func call getVehfrmChassisTypeNum VehTag=%u\n",VehTag);fflush(stdout);
			
				
			
			return ifail;	

		
			
	}
	
	
//Validation to create relation between Vehicle & ChassisTypeNumber
extern DLLAPI int  Has_ChassisType_validation(METHOD_message_t *msg, va_list args)
{
	tag_t	primary_object				=	va_arg(args, tag_t);
	tag_t	secondary_object			=	va_arg(args, tag_t);
	tag_t	relation_type				=	va_arg(args, tag_t);

	tag_t	RelobjTypeTag				=	NULLTAG;
	tag_t	priObjTypeTag				=	NULLTAG;
	tag_t	secObjTypeTag				=	NULLTAG;
	tag_t	*DatasetList					=	NULLTAG;
	tag_t	DatasetTypeTag					=	NULLTAG;
	tag_t	RelType					=	NULLTAG;

	int		DatasetCnt					=0;
	int		i						=0;

	//char   Reltype_name[TCTYPE_name_size_c+1];
	char * Reltype_name =NULL;
	//char   type_name1[TCTYPE_name_size_c+1];
	char   * type_name1=NULL;
	char   *type_name2=NULL;
	char   *D_typeName=NULL;

	char			*user_id				= NULL;
	char			*Part_Type				= NULL;
	char			*D_ObjName				= NULL;
	char			*Sec_ObjNmae				= NULL;
	char			*Pri_ObjNmae				= NULL;
	tag_t	LatestRev				=	NULLTAG;
		char			*PartType				= NULL;


tag_t groupTag = NULLTAG;
			char* groupname = NULL;
	if (POM_get_user_id(&user_id)!=ITK_ok);
	POM_ask_group(&groupname, &groupTag);
	printf("\n Inside Has_ChassisType_validation curent login user is ==> [ %s ] groupname[%s]\n",user_id,groupname);fflush(stdout);

	if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0)
	{
		if (TCTYPE_ask_name2(relation_type,&Reltype_name)!=ITK_ok);
		printf("\n\t Has_ChassisType_validation RelType name is :%s\n", Reltype_name);fflush(stdout);
		
		if (TCTYPE_ask_object_type(primary_object,&priObjTypeTag)!=ITK_ok);
		if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
		printf("\n\t Has_ChassisType_validation Pri obj type name is :%s  \n", type_name1);fflush(stdout);
		// if(tc_strcmp(type_name1,"T5_ChnDlg")==0 )
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Chassis Type should be drop on part type Vehilce/CCV/VC ");
									// printf("\n\n\t ******* Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
									// return(ITK_err);
		// }
		
		// if(tc_strlen(Reltype_name)<=0 && tc_strcmp(type_name1,"T5_ChnDlg")==0)
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Unknown relation Type , Chassis Type should be drop on part type Vehilce/CCV/VC ");
								// printf("\n\n\t *******Unknown relation Type ,Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
								// return(ITK_err);
		// }
		
		
		
		if (TCTYPE_ask_object_type(secondary_object,&secObjTypeTag)!=ITK_ok);
			if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
		printf("\n\t Has_ChassisType_validation Secondary obj type name is :%s  \n", type_name2);fflush(stdout);
	
		// if(tc_strcmp(type_name1,"T5_ChnDlg")==0 )
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Chassis Type should be drop on part type Vehilce/CCV/VC ");
									// printf("\n\n\t ******* Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
									// return(ITK_err);
		// }
		if(tc_strcmp(type_name2,"T5_ChnDlg")==0)
		{
			if(tc_strcmp(type_name1,"Design")==0)
			{
				if(primary_object)
				{
					if(ITEM_ask_latest_rev(primary_object,&LatestRev));
					if( AOM_ask_value_string(LatestRev,"t5_PartType",&PartType)==ITK_ok) 
					printf("\n Primary object's PartType--------------%s \n",PartType);fflush(stdout);
					if(tc_strstr(PartType,"V")!=NULL)
					{
						printf("\n allow to create relation between Vehilce/CCV/VC and Chassis Type --------------%s \n",PartType);fflush(stdout);
					}
					else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Primary object's part type should be Vehilce/CCV/VC ");
								printf("\n\n\t ******* Primary object's part type should be Vehilce/CCV/VC*****\n");fflush(stdout);
								return(ITK_err);
					}
				
				}
			}
			else
			{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Primary object's part type should be Vehilce/CCV/VC ");
						printf("\n\n\t ******* Primary object's part type should be Vehilce/CCV/VC*****\n");fflush(stdout);
						return(ITK_err);
			}
		}
	
		

			
				
	}		

	return 0;
	
}

//End 
int getClsValueFrmClsTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   *Ptype_name=NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char   *VCNum  = NULL;
	char   *CCVNo  = NULL;
	char   *CCVNoDup  = NULL;
	char   *VcPartType  = NULL;
	char   *VcPartTypeDup  = NULL;
	char   *ChassisTypeNoWFStepName  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	char *TaskAnlyst = NULL;
	//char *TaskAnlyst = NULL;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	tag_t	ccvMstrTag = NULLTAG;
	

	ITKCALL(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//ITKCALL(TCTYPE_ask_name(objTypeTag,&Ptype_name));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	printf("\n getClsValueFrmClsTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
                tag_t* partRevTagObjs = NULLTAG;
                tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int i;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//CALLAPI(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			CALLAPI(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue))
			
			printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
			if(AttrKeyValue)
			{
			
			CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(tc_strcmp(AttrKeyValue,lov_keys[i])==0)
					{
						printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
						
						if(lov_values[i])
						{
							tc_strdup(lov_values[i],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}
					//if(tc_strcmp(lov_values[i],"AAMN0001")==0)
					
					
				}
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}						
			printf("\n RetAttrVal=%s ",RetAttrVal); fflush(stdout);
			

	return ITK_ok;

}





//Start iman_save to create relation between Vehicle & ChassisTypeNumber
extern DLLAPI int  setValueInChassisTypeRelCre(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t	primary_object				=	NULLTAG;
	tag_t	secondary_object			=	NULLTAG;
	tag_t	HasChassisTypeRelTag				=	va_arg(args, tag_t);
	tag_t	objTypeTag				=	NULLTAG;
	//tag_t	objTag					=	va_arg(args, tag_t);
	tag_t	RelobjTypeTag				=	NULLTAG;
	tag_t	priObjTypeTag				=	NULLTAG;
	tag_t	secObjTypeTag				=	NULLTAG;
	tag_t	*DatasetList					=	NULLTAG;
	tag_t	*techspec_objects					=	NULLTAG;
	tag_t	DatasetTypeTag					=	NULLTAG;
	tag_t	RelType					=	NULLTAG;
	tag_t	relation_type_tag					=	NULLTAG;
	//char			*SessionUser_id				= NULL;
	int		DatasetCnt					=0;
	int		i						=0;
	int		cnt						=0;
	int 	tscount					=0;
	int 	n_found					=0;
	int 	l  =0;
	int		status;	
	//char   Reltype_name[TCTYPE_name_size_c+1];
	char   *Reltype_name= NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name= NULL;
	//char   type_name1[TCTYPE_name_size_c+1];
	char   *type_name1= NULL;
	//char   type_name2[TCTYPE_name_size_c+1];
	char   *type_name2= NULL;
	//char   D_typeName[TCTYPE_name_size_c+1];
	char   *D_typeName= NULL;
	char TsAttrIdList[200];
	char			*user_id				= NULL;
	char			*Part_Type				= NULL;
	char			*D_ObjName				= NULL;
	char			*Sec_ObjNmae				= NULL;
	char			*Pri_ObjNmae				= NULL;
	char 			*ctrObjAttrid			=NULL;
	char 			*TechSpecNum			=NULL;
	char 			*busUnitDup			=NULL;
	//char 			*TechSpecNum			=NULL;
	char 			ctrObjkeylovid[10]	;
	char 			t5Remarks[200]	;
	
	char 			*userinfo1			=NULL;
	char 			*userinfo2			=NULL;
	char 			*userinfo3			=NULL;
	//int i=0;
	//char 			*TechSpecNum			=NULL;
	//char 			*busUnitDup			=NULL;
	tag_t	LatestRev				=	NULLTAG;
	tag_t   PartRev					= NULLTAG;
	tag_t *ClsObjTag = NULLTAG;
	tag_t  	TSItemRev= NULLTAG;
	tag_t		query_tag		= NULLTAG;
	tag_t		query			=NULLTAG;
	tag_t		*ChBarrel_Ctrlobj	= NULLTAG;
	int Task_C1, Task_C2, DML_C, DML_C2, ij, CmpFlag, CmpFlag_1;

	tag_t			SolItemR			=	NULLTAG;
	tag_t			DMLTaskR			=	NULLTAG;
	tag_t			*Task_Obj			=	NULLTAG; 
	tag_t			*Task_Obj2			=	NULLTAG;
	tag_t			*DML_Obj1			=	NULLTAG;
	tag_t			*DML_Obj2			=	NULLTAG;
	tag_t			DML_Task1			=	NULLTAG;
	tag_t			DML_Task2			=	NULLTAG;
	tag_t			DML1				=	NULLTAG;
	tag_t			DML2				=	NULLTAG;
	tag_t			DmlItemsRelation_t	=   NULLTAG;
	char			*Task_no1				= NULL;
	char			*DML_no2				= NULL;	
	
	
		char			*PartType				= NULL;
char			*CCVNo				= NULL;
char			*CCVNoDup				= NULL;
char *item_ids=NULL;
char   *LeftObjWFStepName  = NULL;
char   *PartMstrObjWFStepName  = NULL;
char   *TaskObjWFStepName  = NULL;
char   *DmlObjWFStepName  = NULL;
char   *PartMstrObjWFStepNameDup  = NULL;
char   *TaskObjWFStepNameDup  = NULL;
char   *DmlObjWFStepNameDup  = NULL;
char   *username  = NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *busUnit=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	char *SalesDesignation =NULL;
	char *SalesDesignationDup =NULL;
	char *Remarks =NULL;
	char *RemarksDup =NULL;
	char *TsAttrRetVal =NULL;
	tag_t groupTag = NULLTAG;
			char* groupname = NULL;
	if (POM_get_user_id(&user_id)!=ITK_ok);

	POM_ask_group(&groupname, &groupTag);
	printf("\n Inside setValinChassisTypeRelCre curent login user is ==> [ %s ] groupname[%s] \n",user_id,groupname);fflush(stdout);

//	if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
//	{
		
		if (TCTYPE_ask_object_type(HasChassisTypeRelTag,&objTypeTag)!=ITK_ok);
			//if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok); //hashed for Teamcenter14 recommendation
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok); //similar new API for Teamcenter14
			printf("\n RRB::type_name :%s\n", type_name);fflush(stdout);

			if (GRM_ask_primary (HasChassisTypeRelTag,&primary_object)!=ITK_ok);
			//if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
			//if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
			//printf("\n RRB::pri_type_name :%s  \n", type_name1);fflush(stdout);

			if (GRM_ask_secondary (HasChassisTypeRelTag,&secondary_object)!=ITK_ok);
			if (TCTYPE_ask_object_type(secondary_object,&secObjTypeTag)!=ITK_ok);
			//if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
			if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
			printf("\n RRB::sec_type_name :%s\n", type_name2);fflush(stdout);
		
		//if (TCTYPE_ask_name(relation_type,Reltype_name)!=ITK_ok);
		//printf("\n\t setValinChassisTypeRelCre RelType name is :%s\n", Reltype_name);fflush(stdout);
		
		if (TCTYPE_ask_object_type(primary_object,&priObjTypeTag)!=ITK_ok);
		//if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
		if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
		if(primary_object!=NULLTAG)
		{
		AOM_ask_value_string( primary_object, "item_id", &CCVNo);	
		if(CCVNo)
		{
			tc_strdup(CCVNo,&CCVNoDup);
		}
		}
		
		printf("\n\n\t\t CCVNo :%s",CCVNoDup);	fflush(stdout);
		printf("\n\t setValinChassisTypeRelCre Pri obj type name is :%s CCVNo=%s \n", type_name1,CCVNo);fflush(stdout);
		
		//printObject(LatestRev);
		CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&PartMstrObjWFStepName)); //AOM_UIF_ask_value is not deprecated , AOM_UIF_ask_values is deprecated hashed for Teamcenter14 recommendation
		//CALLAPI(AOM_UIF_ask_value(primary_object,"fnd0ActuatedInteractiveTsks",&PartMstrObjWFStepName)); //similar new API for Teamcenter14
		printf("\n primary PartMstrObjWFStepName is :- %s\n",PartMstrObjWFStepName);fflush(stdout);
		if(PartMstrObjWFStepName)
		{
			tc_strdup(PartMstrObjWFStepName,&PartMstrObjWFStepNameDup);
		}
		
		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		if (GRM_find_relation_type("T5_DMLTaskRelation", &DMLTaskR)!=ITK_ok);
		
		CALLAPI(ITEM_ask_latest_rev(primary_object,&PartRev));
		
		if (GRM_list_primary_objects_only(PartRev,DmlItemsRelation_t,&Task_C2,&Task_Obj2)!=ITK_ok);

		
		printf("\n setValinChassisTypeRelCre Object Task Count %d \n",Task_C2);fflush(stdout);

			if (Task_C2>=1)
			{
				printf("\n setValinChassisTypeRelCre Only one Secondary Object Task found\n");fflush(stdout);
				for(i=0;i<Task_C2;i++)
				{
					DML_Task2 = Task_Obj2[i];
					if(DML_Task2)					
					{
						if (AOM_UIF_ask_value(DML_Task2,"item_id",&Task_no1) !=ITK_ok); //hashed for Teamcenter14 recommendation
						//if (AOM_ask_displayable_values(DML_Task2,"item_id",&Task_no1) !=ITK_ok); //similar new API for Teamcenter14
						if(tc_strstr(Task_no1,"APL")==NULL)
						{
						printf("\n setValinChassisTypeRelCre Task of Secondary Object is : [%s]\n", Task_no1);fflush(stdout);
						CALLAPI(AOM_UIF_ask_value(DML_Task2,"fnd0ActuatedInteractiveTsks",&TaskObjWFStepName)); //hashed for Teamcenter14 recommendation
						//CALLAPI(AOM_ask_displayable_values(DML_Task2,"fnd0ActuatedInteractiveTsks",&TaskObjWFStepName)); //similar new API for Teamcenter14
						printf("\n setValinChassisTypeRelCre primary TaskObjWFStepName is :- %s\n",TaskObjWFStepName);fflush(stdout);
						if (tc_strstr(TaskObjWFStepName,"Add Chassis Details")!=NULL)
						{
							if(TaskObjWFStepName)
							{
								tc_strdup(TaskObjWFStepName,&TaskObjWFStepNameDup);
							}
							break;
						}
						
						
						if (GRM_list_primary_objects_only(DML_Task2,DMLTaskR,&DML_C2,&DML_Obj2)!=ITK_ok);
						printf("\n setValinChassisTypeRelCre Object DML_C2 Count %d \n",DML_C2);fflush(stdout);
						DML2 = DML_Obj2[0];
						if(DML2)					
						{
							CALLAPI(AOM_UIF_ask_value(DML2,"fnd0ActuatedInteractiveTsks",&DmlObjWFStepName)); //hashed for Teamcenter14 recommendation
							//CALLAPI(AOM_ask_displayable_values(DML2,"fnd0ActuatedInteractiveTsks",&DmlObjWFStepName)); //similar new API for Teamcenter14
							printf("\n setValinChassisTypeRelCre primary DmlObjWFStepName is :- %s\n",DmlObjWFStepName);fflush(stdout);
						
							//CALLAPI(AOM_UIF_ask_value(DML2,"T5_ChassisReviewer",&TaskAnlyst));
							//printf("\n setValinChassisTypeRelCre primary TaskAnlyst is :- %s\n",TaskAnlyst);fflush(stdout);
						}
						if (tc_strstr(DmlObjWFStepName,"Add Chassis Details")!=NULL)
						{
							if(DmlObjWFStepName)
							{
								tc_strdup(DmlObjWFStepName,&DmlObjWFStepNameDup);
							}
							break;
						}
						
						if (AOM_UIF_ask_value(DML2,"item_id",&DML_no2) !=ITK_ok); //hashed for Teamcenter14 recommendation
						//if (AOM_ask_displayable_values(DML2,"item_id",&DML_no2) !=ITK_ok); //similar new API for Teamcenter14
						printf("\n setValinChassisTypeRelCre DML of Secondary Object is : [%s]\n", DML_no2);fflush(stdout);
						}
					}
				}
				

				
			}
		
		
		
		
		// if(tc_strcmp(type_name1,"T5_ChnDlg")==0 )
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Chassis Type should be drop on part type Vehilce/CCV/VC ");
									// printf("\n\n\t ******* Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
									// return(ITK_err);
		// }
		
		// if(tc_strlen(Reltype_name)<=0 && tc_strcmp(type_name1,"T5_ChnDlg")==0)
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Unknown relation Type , Chassis Type should be drop on part type Vehilce/CCV/VC ");
								// printf("\n\n\t *******Unknown relation Type ,Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
								// return(ITK_err);
		// }
		
		
		
		if (TCTYPE_ask_object_type(secondary_object,&secObjTypeTag)!=ITK_ok);
			//if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
			if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
		printf("\n\t setValinChassisTypeRelCre Secondary obj type name is :%s  \n", type_name2);fflush(stdout);
	
		// if(tc_strcmp(type_name1,"T5_ChnDlg")==0 )
		// {
			// EMH_store_error_s1(EMH_severity_error,ITK_err,"Chassis Type should be drop on part type Vehilce/CCV/VC ");
									// printf("\n\n\t ******* Chassis Type should be drop on part type Vehilce/CCV/VC*****\n");fflush(stdout);
									// return(ITK_err);
		// }
		if(tc_strcmp(type_name2,"T5_ChnDlg")==0)
		{
			if(tc_strcmp(type_name1,"Design")==0)
			{
				if(primary_object)
				{
					if(ITEM_ask_latest_rev(primary_object,&LatestRev));
					if( AOM_ask_value_string(LatestRev,"t5_PartType",&PartType)==ITK_ok) 
					printf("\n Primary object's PartType--------------%s \n",PartType);fflush(stdout);
					if(tc_strcmp(PartType,"VC")!=0) //skip VC for altroz
					{
					if(tc_strstr(PartType,"V")!=NULL)
					{
						printf("\n allow to create relation between Vehilce/CCV/VC and Chassis Type --------------%s \n",PartType);fflush(stdout);
						
						ITKCALL(POM_get_user_id (&username));
						printf("\n\n  Chassis assignmentToVcRelPostMsg Session login User1 : %s\n",username); fflush(stdout);
					if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0)
					{
						//printObject(LatestRev);
						CALLAPI(AOM_UIF_ask_value(LatestRev,"fnd0ActuatedInteractiveTsks",&LeftObjWFStepName)); //hashed for Teamcenter14 recommendation
						//CALLAPI(AOM_ask_displayable_values(LatestRev,"fnd0ActuatedInteractiveTsks",&LeftObjWFStepName)); //similar new API for Teamcenter14
						printf("\n primary Part Rev's assisgnment Step[%s] DML's assisgnment Step[%s] Task's assisgnment Step[%s] Part Master's assisgnment Step[%s]\n",LeftObjWFStepName,DmlObjWFStepNameDup,TaskObjWFStepNameDup,PartMstrObjWFStepNameDup);fflush(stdout);
						//if(LeftObjWFStepName == NULL||DmlObjWFStepNameDup == NULL||TaskObjWFStepNameDup == NULL||PartMstrObjWFStepNameDup == NULL)	
						if(LeftObjWFStepName == NULL && DmlObjWFStepNameDup == NULL && TaskObjWFStepNameDup == NULL && PartMstrObjWFStepNameDup == NULL)	
						{
						printf("\n CCV/VC/V must be active in SVR Cluster/CCV release Workflow to !!! \n");fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_err,"VC/V/CCV must be active in Workflow & Assignment must be with <Add Chassis Details> !!! ");
						//decision = EPM_nogo;
						return ITK_err;
						}
						else if (tc_strstr(LeftObjWFStepName,"Add Chassis Details")!=NULL || tc_strstr(DmlObjWFStepNameDup,"Add Chassis Details")!=NULL || tc_strstr(TaskObjWFStepNameDup,"Add Chassis Details")!=NULL || tc_strstr(PartMstrObjWFStepNameDup,"Add Chassis Details")!=NULL	)
							{
						//CALLAPI(POM_get_user_id (&username));
						printf("\n\n  Session login User1 for Chassis assignment : %s\n",username); fflush(stdout);

						printf("\n\n  Allow to attach Chassis into Vehicle : %s\n",username); fflush(stdout);

							//Check Analyst
							// CALLAPI(AOM_UIF_ask_value(LatestRev,"T5_ChassisReviewer",&TaskAnlyst));
							// printf("\n\n  T5_ChassisReviewer for Chassis assignment : %s\n",TaskAnlyst); fflush(stdout);
							// if(tc_strcmp(username,TaskAnlyst) !=0)
							// {
								// printf("\n Session User is Not Chassis assignment Initor..Only Chassis assignment Initiator can make relation between Chassis assignment & VC:%s",TaskAnlyst); fflush(stdout);
								// EMH_store_error_s2(EMH_severity_warning,ITK_err,"Session User is Not Chassis assignment Initor..Only Chassis assignment Initiator can make relation between Chassis assignment & VC:",TaskAnlyst);
								// return ITK_err;
							// }
							// else
							// {
								// printf("\n allow to process the Chassis assignment & VC relation coz Chassis assignment active in WF with assignment  %s\n",LeftObjWFStepName);fflush(stdout);		
							// }


							

						}
						else
						{	
						printf("\n 2 VC/V/CCV must be active in Workflow & Assignment must be with <Add Chassis Details> !!! \n");fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_err,"VC/V/CCV must be active in Workflow & Assignment must be with <Add Chassis Details> !! ");
						//decision = EPM_nogo;
						return ITK_err;
						}

					}

						
						CALLAPI(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
					CALLAPI(GRM_list_secondary_objects_only(LatestRev,relation_type_tag,&tscount,&techspec_objects ));
					printf("\n tscount[%d] for CCV[%s] !!",tscount,CCVNo); fflush(stdout);
						if(tscount>0)
						{
							ITK_CALL( AOM_ask_value_string(techspec_objects[0], "item_id",&item_ids));
							if(item_ids)
							{
								tc_strdup(item_ids,&TechSpecNum);
							}
							printf("\n TechSpecNum[%s] !!",TechSpecNum); fflush(stdout);
							ITK_CALL( AOM_ask_value_string(techspec_objects[0], "object_name",&Desc));
							printf("\n Desc[%s] !!",Desc); fflush(stdout);
							//ITK_CALL( AOM_ask_value_string(techspec_objects[0], "t5_ProjectCode",&ProjName));
							//ITEM_ask_latest_rev(techspec_objects[0],&TSItemRev);
							//ITK_CALL( AOM_ask_value_string(TSItemRev, "item_revision_id",&Itemrevid));
							printf("\n b4 busUnit[%s] !!",busUnit); fflush(stdout);
							//printObject(techspec_objects[0]);
							if(techspec_objects[0]!=NULLTAG)
							{
								//printObject(TSItemRev);
								ITK_CALL( AOM_ask_value_string(techspec_objects[0], "t5_VCClassName",&busUnit));
							}
							
							printf("\n After busUnit[%s] !!",busUnit); fflush(stdout);
							if(busUnit)
							{
								tc_strdup(busUnit,&busUnitDup);
							}
							printf("\n  busUnitDup[%s] !!",busUnitDup); fflush(stdout);
							//CALLAPI(AOM_ask_value_string(techspec_objects[0],"t5_VehicleClass",&ProjectClass));
							CALLAPI(AOM_ask_value_tags(primary_object,"IMAN_classification",&cnt,&ClsObjTag));
								printf("\n classified object count[%d] for CCV[%s] !!",cnt,CCVNo); fflush(stdout);
								if(cnt>0)
								{
									
									//Need to use Query Builder to get Control Objects... Object to set the value of TechSpec in T5_HasChassisType class.....
									char *qry_entries3[] = {"SYSCD","SUBSYSCD"};
									char *qry_values3[] = {"CHASSIS",busUnit};
									//CALLAPI(QRY_find("Control Objects...", &query)); //hashed for Teamcenter14 recommendation
									CALLAPI(QRY_find2("Control Objects...", &query)); //similar new API for Teamcenter14
									CALLAPI(QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &ChBarrel_Ctrlobj));
									printf("\n \n setValueInChassisTypeRelCre number of ChBarrel objs : %d \n",n_found);fflush(stdout);			
									if (n_found <= 0)
									{
										printf("\n setValueInChassisTypeRelCre 1Inside Err no control object found for CHASSIS & Business Unit[%s] :: \n",busUnit);fflush(stdout);
										EMH_clear_errors();
										status=EMH_store_error_s2(EMH_severity_error,ITK_err,"no control object found for Syscd[CHASSIS] & Business Unit : \n ",busUnit);
										printf("\n setValueInChassisTypeRelCre 2Inside Err busUnit :: %s\n",busUnit);fflush(stdout);
										return ITK_err;
									}
									else
									{
										tc_strcpy(t5Remarks,"");
										tc_strcat(t5Remarks,busUnitDup);
										tc_strcat(t5Remarks,",");
										tc_strcat(t5Remarks,CCVNoDup);
										tc_strcat(t5Remarks,",");
										AOM_ask_value_string(ChBarrel_Ctrlobj[0],"t5_Userinfo1",&userinfo1);
										AOM_ask_value_string(ChBarrel_Ctrlobj[0],"t5_Userinfo2",&userinfo2);
										AOM_ask_value_string(ChBarrel_Ctrlobj[0],"t5_Userinfo3",&userinfo3);
										printf("\n  User Info1 [%s ] and info2[%s] info3[%s] of Chassis Control Object \n",userinfo1,userinfo2,userinfo3);fflush(stdout);
										
										tc_strcpy(TsAttrIdList,userinfo1);
										tc_strcat(TsAttrIdList,userinfo2);
										printf("\n userinfo1[%s] userinfo2[%s] TsAttrIdList[%s]",userinfo1,userinfo2,TsAttrIdList);fflush(stdout);
										ctrObjAttrid=strtok(TsAttrIdList,";");
										l=0;
										printf("\n b4 call func getClsValueFrmClsTag for Sales Designation ");fflush(stdout);
										SalesDesignation=NULL;
										if(userinfo3)
										{
											CALLAPI(getClsValueFrmClsTag(*ClsObjTag,userinfo3,&SalesDesignation));
										}
										else
										{
											CALLAPI(getClsValueFrmClsTag(*ClsObjTag,"8066",&SalesDesignation));
										}
										
										printf("\n After call func getClsValueFrmClsTag with return SalesDesignation[%s] for Sales Designation",SalesDesignation);fflush(stdout);
										while( ctrObjAttrid != NULL )
										{										
										
										TC_write_syslog("\nt5Remarks for Chassis Type allocation by func setValueInChassisTypeRelCre= %s\n",t5Remarks);
										printf("\n t5Remarks for Chassis Type allocation by func setValueInChassisTypeRelCre= %s ",t5Remarks);fflush(stdout);
										
										//printf("\n b4 call func getClsValueFrmClsTag for Sales Designation ctrObjAttrid[%s] ",ctrObjAttrid);fflush(stdout);
										
										// tc_strcpy(ctrObjkeylovid,"");
										// tc_strcat(ctrObjkeylovid,"-");
										// tc_strcat(ctrObjkeylovid,ctrObjAttrid);
										printf("\n b4 call func getClsValueFrmClsTag for Sales Designation with input ctrObjkeylovid[%s] ",ctrObjkeylovid);fflush(stdout);
										TsAttrRetVal=NULL;
										CALLAPI(getClsValueFrmClsTag(*ClsObjTag,ctrObjAttrid,&TsAttrRetVal));
										printf("\n After call func getClsValueFrmClsTag with return TsAttrRetVal[%s] for Remarks[%s]",TsAttrRetVal,t5Remarks);fflush(stdout);
										
										if(TsAttrRetVal)
										{
											tc_strcat(t5Remarks,TsAttrRetVal);
											tc_strcat(t5Remarks,",");
										}
										// else
										// {
										// l++;	//skip not found Attribute id in classisfication
										// }
										ctrObjAttrid = strtok( NULL, ";" );
										printf("\n After Tok NULL ctrObjAttrid[%s] ",ctrObjAttrid);fflush(stdout);
										
										l++;
										
										}
										
										printf("\n Final t5Remarks[%s] for t5_ChassisDescription ,SalesDesignation[%s] TechSpecNum[%s]",t5Remarks,SalesDesignation,TechSpecNum);fflush(stdout);
										
										CALLAPI(AOM_lock(HasChassisTypeRelTag));									
										CALLAPI( AOM_set_value_string(HasChassisTypeRelTag,"t5_SalesDesignation",SalesDesignation));   
										printf("\n in SalesDesignation AOM_set_value_string for HasChassisTypeRelTag \n");fflush(stdout);
	
										CALLAPI( AOM_set_value_string(HasChassisTypeRelTag,"t5_ChassisDescription",t5Remarks));   
										printf("\n in t5Remarks AOM_set_value_string for HasChassisTypeRelTag \n");fflush(stdout);
										
										CALLAPI( AOM_set_value_string(HasChassisTypeRelTag,"t5_VehSpecNo",TechSpecNum));   
										printf("\n in techSpecid AOM_set_value_string for HasChassisTypeRelTag \n");fflush(stdout);
										CALLAPI(AOM_save_without_extensions(HasChassisTypeRelTag));
										printf("\n in HasChassisTypeRelTag save..\n");fflush(stdout);

										CALLAPI(AOM_unlock(HasChassisTypeRelTag));
										printf("\n in HasChassisTypeRelTag unlock..\n");fflush(stdout);
										
										CALLAPI(AOM_refresh(HasChassisTypeRelTag,TRUE));
										printf("\n in HasChassisTypeRelTag refresh..\n");fflush(stdout);
										
									}
								}
								else
								{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Tech Spec must be updated & classified values prior to make relation with Chassis Type");
								printf("\n\n\t ******* Tech Spec must be updated & classified values prior to make relation with Chassis Type *****\n");fflush(stdout);
								return(ITK_err);
								}
							
							
						}
						else
						{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"No Tech Spec attached to this Vehicle/VC/CCV ,Tech Spec must attached then only chassis type will allow to make relation!!  ");
						printf("\n\n\t ******* No Tech Spec attached to this Vehicle/VC/CCV ,Tech Spec must attached then only chassis type will allow to make relation!! *****\n");fflush(stdout);
						return(ITK_err);
						}
						
						
					}
					else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Primary object's part type should be Vehilce/CCV/VC ");
								printf("\n\n\t ******* Primary object's part type should be Vehilce/CCV/VC*****\n");fflush(stdout);
								return(ITK_err);
					}
				}
				else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type <VC> is not applicable for assigning Chassis Type for ALTROZ,assign Chassis Type to 9 digit Vehicle");
								printf("\n\n\t ******* Part Type VC is not applicable for assigning Chassis Type for ALTROZ,assign Chassis Type to 9 digit Vehicle*****\n");fflush(stdout);
								return(ITK_err);
					}				
				}
			}
			else
			{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Primary object's part type should be Vehilce/CCV/VC ");
						printf("\n\n\t ******* Primary object's part type should be Vehilce/CCV/VC*****\n");fflush(stdout);
						return(ITK_err);
			}
		}
	
		

			
				
	//}		

	return 0;
	
}

//End iman_save to create relation between Vehicle & ChassisTypeNumber
extern int tm_projdatamgmt_register_methods(int *decision, va_list args)
{
                            

         printf("\n Start  *****ChBarrel_register_methods\n");fflush(stdout);       
                 int ifail = ITK_ok;
                 METHOD_id_t  method1;
				METHOD_id_t  method2;
                 METHOD_id_t  method3;
                  METHOD_id_t  method4;
				  METHOD_id_t  method5;
				   METHOD_id_t  method6;
                 *decision = ALL_CUSTOMIZATIONS;

				 
				 
				 //Start Method registering 
			  ERROR_CHECK(METHOD_find_method("T5_InxDlg", "IMAN_save", &method1));
              ERROR_CHECK(METHOD_find_method("T5_ChnDlg", "ITEM_create", &method2));
			  ERROR_CHECK(METHOD_find_method("T5_ChnDlg", "IMAN_save", &method3));
			// ERROR_CHECK( METHOD_find_method("T5_HasChassisTypeNo", IMAN_save_msg, &method6));
			  ERROR_CHECK( METHOD_find_method("T5_HasChassisTypeNo", TC_save_msg, &method6));
			   printf("\n  *****METHOD_find_method\n");fflush(stdout);    

			   printf("\n TMML.c: MyType:method - ");fflush(stdout);			   
				if (method1.id != 0)
				{			
					TC_write_syslog("\n  *****b4 METHOD_add_Post_action of Chassis Barrel T5_InxDlg\n");    
					ERROR_CHECK( METHOD_add_action(method1, METHOD_pre_action_type,(METHOD_function_t) tm_ChBarrelCreFunc, NULL));
					TC_write_syslog("\n  *****After T5ChBarrelCre_Validation_post METHOD_add_action\n"); 		  

				}
				
				
				if (method2.id != 0)
				{
					TC_write_syslog("\n  *****b4 METHOD_add_Post_action of Chassis Type Number T5_ChnDlg\n");    
					ERROR_CHECK( METHOD_add_action(method2, METHOD_post_action_type,(METHOD_function_t) tm_ChTypeNumItemCreFunc, NULL));
					TC_write_syslog("\n  *****After Chassis Type Number T5_ChnDlg_Validation_post METHOD_add_action\n"); 		  
					
				}

				if (method3.id != 0)
				{
					
					TC_write_syslog("\n  *****b4 METHOD_add_Post_action of Chassis Type Number T5_ChnDlg\n");   
					ERROR_CHECK( METHOD_add_action(method3, METHOD_pre_action_type,(METHOD_function_t) tm_ChTypeNumberCreFunc, NULL));
					TC_write_syslog("\n  *****After Chassis Type Number T5_ChnDlg_Validation_post METHOD_add_action\n"); 		  

				}
				
					printf("\n  *****b4 METHOD_add_Post_action:getVehRelationFrmCHTypeNum\n");fflush(stdout);   
					ifail = (METHOD_find_method("T5_HasChassisTypeNo", "GRM_create", &method4));
					if (method4.id != 0)
					{
						TC_write_syslog("\n  b4 METHOD_register_prop_method register for getVehRelationFrmCHTypeNum\n"); 		
						ERROR_CHECK(METHOD_register_prop_method("T5_ChnDlg", "t5_ChassisTypeforAssm",  PROP_ask_value_tag_msg, getVehRelationFrmCHTypeNum, 0,  &method4 ));
						TC_write_syslog("\n  After METHOD_register_prop_method for getVehRelationFrmCHTypeNum register\n");
					}
				if ( METHOD_find_method("T5_HasChassisTypeNo", GRM_create_msg, &method5) !=ITK_ok);
					
				if (method5.id != 0)
				{
					TC_write_syslog("\n  *****b4 METHOD_add_Post_action of Chassis Type Number T5_ChnDlg & Vehicle relation\n");    
					CALLAPI( METHOD_add_action(method5, METHOD_post_action_type, (METHOD_function_t) Has_ChassisType_validation, NULL));
					//if( METHOD_add_pre_condition(method5,(METHOD_function_t)Has_ChassisType_validation,NULL)!=ITK_ok)
						TC_write_syslog("\n  *****After METHOD_add_Post_action Chassis Type Number T5_ChnDlg_Validation_pre for relation create METHOD_add_action\n"); 		  
					PrintErrorStack();
					
				}
				else
				{
					printf("method5 not found for Has_ChassisType_validation\n");fflush(stdout);
				}
				
				if (method6.id != 0)
				{
					TC_write_syslog("\n  *****b4 METHOD_add_Post_action for iman_save of Chassis Type Number T5_ChnDlg & Vehicle relation\n");    
					CALLAPI( METHOD_add_action(method6, METHOD_post_action_type, (METHOD_function_t) setValueInChassisTypeRelCre, NULL));
					//if( METHOD_add_pre_condition(method5,(METHOD_function_t)Has_ChassisType_validation,NULL)!=ITK_ok)
						TC_write_syslog("\n  *****After METHOD_add_Post_action for iman_save Chassis Type Number T5_ChnDlg_Validation_pre for relation create METHOD_add_action\n");
					PrintErrorStack();
					
				}
				else
				{
					printf("method6 not found for setValueInChassisTypeRelCre for iman_save\n");fflush(stdout);
				}
				
				
				
return ifail;
}

//End

extern DLLAPI int tm_projdatamgmt_register_callbacks ()
{
    ECHO("ChBarrel_register_callbacks\n");

	TC_write_syslog("\nChBarrel_register_callbacks");

	ERROR_CHECK(CUSTOM_register_exit ( "tm_projdatamgmt", "USER_init_module",(CUSTOM_EXIT_ftn_t) tm_projdatamgmt_register_methods ));
	//ERROR_CHECK(CUSTOM_register_exit ( "tm_projdatamgmt", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  IcsLovUpdateServiceFunc));
	TC_write_syslog("\nAfter ChBarrel_register_callbacks");
    return ITK_ok;
}

