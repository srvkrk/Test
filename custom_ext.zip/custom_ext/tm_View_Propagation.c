#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <bom/bom_msg.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tccore/aom_prop.h>
//#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*Depricated API BOM_line_ask_attribute_string replaced with  AOM_ask_displayable_values
*Depricated API BOM_line_look_up_attribute replaced with   TCTYPE_ask_property_by_name
*Depricated API BOM_line_set_attribute_string replaced with    AOM_UIF_set_value
*/

{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void  getPlantDetailsAttr_View( char * RoleName ,char  getUserAgency[40])
{
     char   *PlantName=NULL;
     char   *dsgModAddressVal=NULL; //MBOM implementation for CV TZ-1.69
	  printf( "RoleName:%s\n", RoleName);fflush(stdout);

	  if( tc_strstr(RoleName,"MBOM")!=NULL) //MBOM implementation for CV TZ-1.69
	  {
		dsgModAddressVal = strtok (RoleName,"_");	//MBOM implementation for CV TZ-1.69
		PlantName = strtok (NULL,"_");
		printf( "dsgModAddressVal:%s\n", dsgModAddressVal); fflush(stdout);
		printf( "PlantName:%s\n", PlantName); fflush(stdout); //MBOM implementation for CV TZ-1.69
	  }
	  else
	  {
       PlantName=subString(RoleName,3,4); //MBOM implementation for CV TZ-1.69
	  }
      printf( "PlantName:%s\n", PlantName);fflush(stdout);
	 /// APL Logic
	  if(strcmp(PlantName,"APLD")==0)
	  {
		tc_strcpy(getUserAgency,"PDWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getUserAgency,"PPUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getUserAgency,"PCAR");
	  }else  if(strcmp(PlantName,"APLJ")==0)
	  {
		tc_strcpy(getUserAgency,"PJSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getUserAgency,"PLKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getUserAgency,"PAHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getUserAgency,"PUTK");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getUserAgency,"PJDL");
	  }else  if(strcmp(PlantName,"APLV")==0)
	  {
		tc_strcpy(getUserAgency,"PPUV");
	  }
	  if(strcmp(PlantName,"MBOM")==0)	//MBOM implementation for CV TZ-1.69
	  {
		tc_strcpy(getUserAgency,"MBOM");//MBOM implementation for CV TZ-1.69
	  }
	 /// STD Logic
	  if(strcmp(PlantName,"STDD")==0)
	  {
		tc_strcpy(getUserAgency,"SDWD");
	  }else  if(strcmp(PlantName,"STDP")==0)
	  {
		tc_strcpy(getUserAgency,"SPUN");
	  }else  if(strcmp(PlantName,"STDC")==0)
	  {
		tc_strcpy(getUserAgency,"SCAR");
	  }else  if(strcmp(PlantName,"STDJ")==0)
	  {
		tc_strcpy(getUserAgency,"SJSR");
	  }else  if(strcmp(PlantName,"STDL")==0)
	  {
		tc_strcpy(getUserAgency,"SLKO");
	  }else  if(strcmp(PlantName,"STDA")==0)
	  {
		tc_strcpy(getUserAgency,"SAHD");
	  }else  if(strcmp(PlantName,"STDU")==0)
	  {
		tc_strcpy(getUserAgency,"SPNR");
	  }else  if(strcmp(PlantName,"STDS")==0)
	  {
		tc_strcpy(getUserAgency,"SJDL");
	  }else  if(strcmp(PlantName,"STDV")==0)
	  {
		tc_strcpy(getUserAgency,"SPUV");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
extern DLLAPI int  save_method_BOMLineAdd(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t  item_tag		= va_arg(args, tag_t);
	tag_t  itemRev_tag		= va_arg(args, tag_t);
	tag_t  bv_tag		= va_arg(args, tag_t);
	const char *occType		= va_arg(args, const 	char* );
    tag_t *newBomline_tag 	= va_arg(args, tag_t*);

	//logical flag = va_arg(args, logical);
	tag_t objTypeTag = NULLTAG;
	tag_t Bomline_tag = NULLTAG;
	char   *type_name=NULL;
	int checked_out_user = 0;
	//logical	checkoutp				= 0;
	char *username;
	char *cp_ChildChkOutValue = NULL;
	char *Item_ID_str = NULL;
	char *Item_ID_Rev_str = NULL;
	char *APLP_CurrentView_Mask = NULL;
	int   Item_ID,Item_Revision = 0;
	int   APLPCurrentView = 0;
	tag_t user_tag=NULLTAG;
	tag_t rev_tag=NULLTAG;
	char *objecttype = NULL;
	char *PartType = NULL;
	char *t5_DesignGrp = NULL;
	char *ChildPartType = NULL;

	tag_t     CurrentRoleTag = NULLTAG;
	char       *roleName=NULL  ;
	char UserAgency[40];

	//end

	int   Item_PartType = 0; //TZ1.43 Added by Deepti
	char *Item_Rev_PartType= NULL; //TZ1.43 Added by Deepti
	char *Item_ID_str_Cpy= NULL; //TZ1.43 Added by Deepti
	char *Item_ID_Check= NULL; //TZ1.43 Added by Deepti
	int t5_APLCarCurrentView=0; //TZ1.43 Added by Deepti
	WSO_search_criteria_t  	criteria_ANSup;//TZ1.43 Added by Deepti
	int control_number_found=0;//TZ1.43 Added by Deepti
	int iCntl=0;//TZ1.43 Added by Deepti
	char*		SubSyscd 			=	NULL;//TZ1.43 Added by Deepti
	logical		deleInd 			;//TZ1.43 Added by Deepti
	char*		biwERCModInfo1 		=	NULL;//TZ1.43 Added by Deepti
	char*		biwERCModInfo2 		=	NULL;//TZ1.43 Added by Deepti
	int			status			=	0;//TZ1.43 Added by Deepti
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;//TZ1.43 Added by Deepti


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);

	printf("\n!!!!!!!!!!!!!!!!! save_method_BOMLine:::::::::type_name[%s]\n",type_name);fflush(stdout);
	printf("\n  Printf added for testing [%s]\n",type_name);fflush(stdout);

	if(SA_ask_current_role(&CurrentRoleTag));PrintErrorStack();
	if(SA_ask_role_name2(CurrentRoleTag,&roleName));PrintErrorStack();
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	getPlantDetailsAttr_View(roleName,UserAgency);
	printf("\n UserAgency %s \n",UserAgency);

	if(strcmp(type_name,"BOMLine")==0)
	{
		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		// if(RES_is_checked_out(objTag,&checkoutp))PrintErrorStack();

		//if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user))PrintErrorStack();
		//if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue))PrintErrorStack();

		AOM_UIF_ask_value(objTag, "bl_rev_checked_out", &cp_ChildChkOutValue);
		printf("\n Item_ID_str-----------------------------------------------------=%s\n",cp_ChildChkOutValue);fflush(stdout);


		//if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision))PrintErrorStack();
		//if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str))PrintErrorStack();
	    //if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID))PrintErrorStack();
		//if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str))PrintErrorStack();
		
		//printf("\n ItemRevision is [%s] and ItemID is: [%s] \n",Item_ID_Rev_str,Item_ID_str);


		AOM_UIF_ask_value(objTag, "bl_rev_item_revision_id", &Item_ID_Rev_str);
		printf("\n Item_ID_Rev_str----------------------------- =%s\n",Item_ID_Rev_str);fflush(stdout);


		AOM_UIF_ask_value(objTag, "bl_item_item_id", &Item_ID_str);
		printf("\n Item_ID_str -------------------------------=%s\n",Item_ID_str);fflush(stdout);

		/////////APL Logic Stamping

		 if(strcmp(UserAgency,"PDWD")==0)
		{
	 		 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskD",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			  AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskD","-12");
	    }else if(strcmp(UserAgency,"PPUN")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskP",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskP","-12");
			 printf("\n \n \t -------------Depricated API has been chnaged---------------");fflush(stdout);
		}else if(strcmp(UserAgency,"PCAR")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskC",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskC","-12");
		}else if(strcmp(UserAgency,"PJSR")==0)
		{
			// if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskJ",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			  AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskJ","-12");
		}else if(strcmp(UserAgency,"PLKO")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskL",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			// if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
				AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskL","-12");
		}else if(strcmp(UserAgency,"PAHD")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskA",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskA","-12");
		}else if(strcmp(UserAgency,"PUTK")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskU",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskU","-12");
		}else if(strcmp(UserAgency,"PJDL")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskS",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			// if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskS","-12");
		}else if(strcmp(UserAgency,"PPUV")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskV",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskV","-12");
		}
		else if(strcmp(UserAgency,"MBOM")==0)		//MBOM implementation for CV TZ-1.69
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskM",&APLPCurrentView))PrintErrorStack(); //MBOM implementation for CV TZ-1.69
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "1"))PrintErrorStack();
			//if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "-12"))PrintErrorStack(); //MBOM implementation for CV TZ-1.69

			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskM","-12");
		}
		/////////STD Logic Stamping
		if(strcmp(UserAgency,"SDWD")==0)
		{
	 		 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskD",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskD","--2");
	    }else if(strcmp(UserAgency,"SPUN")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskP",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskP","--2");
		}else if(strcmp(UserAgency,"SCAR")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskC",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskC","--2");
		}else if(strcmp(UserAgency,"SJSR")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskJ",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskJ","--2");
		}else if(strcmp(UserAgency,"SLKO")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskL",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskL","--2");
		}else if(strcmp(UserAgency,"SAHD")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskA",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			// if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskA","--2");
		}else if(strcmp(UserAgency,"SUTK")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskU",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			// if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskU","--2");
		}else if(strcmp(UserAgency,"SJDL")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskS",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			// if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskS","--2");
		}else if(strcmp(UserAgency,"SPUV")==0)
		{
			 //if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskV",&APLPCurrentView))PrintErrorStack();
			 Bomline_tag = newBomline_tag[0];
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "2"))PrintErrorStack();
			 //if(BOM_line_set_attribute_string(Bomline_tag, APLPCurrentView, "--2"))PrintErrorStack();
			 AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskV","--2");
		}
		else 
		{
			//ADDED BY DEEPTI TZ1.43 for BIW Supress
			if(tc_strstr(roleName,"Designers")!=NULL)
			{
				printf("\n Inside ERC Designers...");fflush(stdout);

				//if(BOM_line_look_up_attribute ("bl_item_object_type",&Item_PartType))PrintErrorStack();	
				//if(BOM_line_ask_attribute_string(objTag, Item_PartType, &Item_Rev_PartType))PrintErrorStack();

				AOM_UIF_ask_value(objTag, "bl_item_object_type", &Item_Rev_PartType);
				

				printf("\n Item_Rev_PartType %s",Item_Rev_PartType);fflush(stdout);

				if(tc_strcmp(Item_Rev_PartType,"Architecture Module")==0)
				{
					printf("\n Inside Architecture Module ...");fflush(stdout);

					Item_ID_str_Cpy=subString(Item_ID_str,0,2);
					Item_ID_Check=subString(Item_ID_str,2,6);

					printf("\n Inside Item_ID_str_Cpy ...%s:%s",Item_ID_str_Cpy,Item_ID_Check);fflush(stdout);
					WSOM_clear_search_criteria(&criteria_ANSup);
					tc_strcpy(criteria_ANSup.name,"BIW_ERC_APL_SUPRESS");
					tc_strcpy(criteria_ANSup.class_name,"T5_ControlObject");
					status	= WSOM_search(criteria_ANSup, &control_number_found, &list_of_WSO_cntrl_tags);
					printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
					if(control_number_found>0)
					{
						for (iCntl=0;iCntl<control_number_found;iCntl++ )
						{
							AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
							printf("\n\n DML Project from control: %s",SubSyscd);fflush(stdout);

							AOM_ask_value_logical( list_of_WSO_cntrl_tags[iCntl], "t5_DelInd", &deleInd);
							
							if ((tc_strcmp(SubSyscd,Item_ID_str_Cpy)==0) )
							{
								if (deleInd == false )
								{
									AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_Userinfo1", &biwERCModInfo1);
									printf("\n\n biwERCModInfo1: %s",biwERCModInfo1);fflush(stdout);

									AOM_ask_value_string(list_of_WSO_cntrl_tags[iCntl], "t5_Userinfo2", &biwERCModInfo2);
									printf("\n\n biwERCModInfo2: %s",biwERCModInfo2);fflush(stdout);

									if((tc_strstr(biwERCModInfo1,Item_ID_Check)!=NULL)|| (tc_strstr(biwERCModInfo2,Item_ID_Check)!=NULL))
									{
										printf("\n 11Inside ERC BIW Flag set to 0 ...");fflush(stdout);
										//if(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskC",&t5_APLCarCurrentView))PrintErrorStack();
										Bomline_tag = newBomline_tag[0];
										//if(BOM_line_set_attribute_string(Bomline_tag, t5_APLCarCurrentView, "0"))PrintErrorStack();									
										//if(BOM_line_set_attribute_string(Bomline_tag, t5_APLCarCurrentView, "0--"))PrintErrorStack();	
										AOM_UIF_set_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskC","0--");
									
									}
									else
									{
										printf("\n 11Inside ERC BIW not found ...");fflush(stdout);	
									}
								
								}
								else
								{
									printf("\n\n Delete ind is true...hence not setting the flag..");fflush(stdout);
								}
								break;
							}
						}
					
					}
				}
			}
			
		}
		
	printf("\n Stamping Completed for Addition  \n");fflush(stdout);

	}

	return error_code;
}
// End of function

extern int tm_View_Propagation_register_method(int *decision, va_list args)
{
    METHOD_id_t  methodBOMLine;
    METHOD_id_t  methodBOMLineC;
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

	if ( METHOD_find_method("BOMLine",BOMLine_add_msg,&methodBOMLine) !=ITK_ok);PrintErrorStack();//uppp

		if (methodBOMLine.id != NULL)///upp
		{
			printf("\nInside methodBOMLine\n");
			if( METHOD_add_action(methodBOMLine, METHOD_post_action_type, (METHOD_function_t) save_method_BOMLineAdd, NULL)!=ITK_ok) PrintErrorStack();

			if( ifail != ITK_ok )
			{
					EMH_store_error( EMH_severity_error, ifail );
			}
		}
		else
		{
			printf("\n methodBOMLine not found\n");
		}

    return ITK_ok;
}

extern DLLAPI int tm_View_Propagation_register_callbacks()
{
	 CUSTOM_register_exit("tm_View_Propagation", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_View_Propagation_register_method);

 

	 return ( ITK_ok );
}
