
#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <map>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedPtr.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
// #include <tc/iman.h>
// #include <tccore/imantype.h>
// #include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
// #include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h> /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h> /* for dataset id and rev */
#include <ae/ae_types.h>  /* for dataset id and rev */
#include <unidefs.h>
#include <tccore/tctype.h>

#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
// #include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
// #include <tc/emh_const.h>
#include <sa/groupmember.h>
// #include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
// #include <tc/tc.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>

#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>

#include <tccore/tctype.h>
//#include "sapitab.h"
// #include "wmhelpe.h"
// #include "wmapi2.h"
//#include "wmconste.h"
//#include "bapi.h"
//#include "t.h"
//#include "ppe.h"
#include <time.h>

// #include <metaframework/BusinessObjectRef.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedSmPtr.hxx>
// #include <mld/logging/TcMainLogger.hxx>

using namespace std;
using namespace Teamcenter;
// using Teamcenter::Main::logger;

#define ITK_CALL(x)                                                                 \
    {                                                                               \
        int stat;                                                                   \
        char *err_string;                                                           \
        if ((stat = (x)) != ITK_ok)                                                 \
        {                                                                           \
            EMH_ask_error_text(stat, &err_string);                                  \
            printf("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
            printf("\n FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
            if (err_string)                                                         \
                MEM_free(err_string);                                               \
            exit(EXIT_FAILURE);                                                     \
        }                                                                           \
    }

int tm_getTaskBOM_Call(void *return_data)
{

    int ifail = ITK_ok;
    char *revision_rule;
    char *svr_closure_rule;
    char *dml_id;
    char *plant;
    char *mail;
    tag_t qryCOTag = NULLTAG;
    int cocnt;
    tag_t *cores = NULLTAG;
    char *plantcode;
    char *closure_rule;
    char *plantname;

    	// 	objects[0] = "\"" + DMLNumber + "\"";
		// objects[1] = "\"" + ruleSelected + "\"";
		// objects[2] = finalCloseRule == null ? "" : "\"" + finalCloseRule + "\"";
		// objects[3] = "\"" + cmbPlantData + "\"";
		// objects[4] = "\"" + mailLOV + "\"";

    USERARG_get_string_argument(&dml_id);
    USERARG_get_string_argument(&revision_rule);
    USERARG_get_string_argument(&svr_closure_rule);
    USERARG_get_string_argument(&plant);
    USERARG_get_string_argument(&mail);

    char *qryCOEntries[4] = {"SYSCD", "SUBSYSCD", "Information-1", "Delete Indicator"};
    char *qryCOValues[4] = {"TaskBOMComp", "ClosureRule", plant, "0"};

    ITK_CALL(QRY_find2("Control Objects...", &qryCOTag));
    printf("before qryCOTag\n");
    if (qryCOTag)
    {
        printf("under qryCOTag\n");

        ITK_CALL(QRY_execute(qryCOTag, 4, qryCOEntries, qryCOValues, &cocnt, &cores));
        printf("cocnt: %d\n ", cocnt);
        if (cocnt > 0)
        {
            printf("under cocnt\n ");
            ITK_CALL(AOM_ask_value_string(cores[0], "t5_Userinfo2", &plantcode));
            printf("\n plantcode - %s \n", plantcode);

            ITK_CALL(AOM_ask_value_string(cores[0], "t5_Userinfo3", &closure_rule));
            printf("\n closure_rule - %s \n", closure_rule);

            ITK_CALL(AOM_ask_value_string(cores[0], "t5_Userinfo4", &plantname));
            printf("\n closure_rule - %s \n", plantname);
        }
    }
    else{
        printf("not found qryCOTag");
    }
    printf("upppp\n");

    printf("Under ITK call dml_id %s\n", dml_id);
    printf("Under ITK call revision_rule %s\n", revision_rule);
    printf("Under ITK call svr_closure_rule %s\n", svr_closure_rule);
    printf("Under ITK call plant %s\n",plantname);
    printf("Under ITK call mail %s\n", mail);
    printf("Under ITK call plantcode %s\n", plantcode);
    printf("Under ITK call closure_rule %s\n", closure_rule);

    // Control Object for EXE
    char *qry_entries1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qry_values1[3] = {"TaskBOMComp", "TaskBOMCompPATH", "0"};

    tag_t qryTag = NULLTAG;
    int query_count;
    tag_t *query_result = NULLTAG;

    ITK_CALL(QRY_find2("Control Objects...", &qryTag));

    if (qryTag)
    {
        printf("\n Control Object Query Found \n");
        fflush(stdout);

        ITK_CALL(QRY_execute(qryTag, 3, qry_entries1, qry_values1, &query_count, &query_result));

        printf("\n query_count is : %d\n", query_count);
        fflush(stdout);

        if (query_count > 0)
        {
            char *t5_Userinfo1 = NULL;
            char cmd[500];
            tag_t obj = query_result[0];
            ITK_CALL(AOM_ask_value_string(obj, "t5_Userinfo1", &t5_Userinfo1));
            sprintf(cmd, "%s/EXE_TaskBOMComp.sh %s %s %s %s %s %s %s&", t5_Userinfo1, dml_id, revision_rule, svr_closure_rule, closure_rule, plantcode, plantname, mail);//EXE_TaskBOMComp.sh
            printf("Excuting Command = %s", cmd);
            fflush(stdout);
            system(cmd);
            printf("After executing Command");
            fflush(stdout);
        }
    }

    return ifail;
}

extern int AllUserServiceFntm_TaskBomComparsionFtn(int *decision, va_list args)
{
    int ifail = ITK_ok;

    *decision = ALL_CUSTOMIZATIONS;

    int nargs = 5;
    int retValueType;
    int inputArgTypes[5] = {0};
		// objects[0] = "\"" + DMLNumber + "\"";
		// objects[1] = "\"" + ruleSelected + "\"";
		// objects[2] = finalCloseRule == null ? "" : "\"" + finalCloseRule + "\"";
		// objects[3] = "\"" + cmbPlantData + "\"";
		// objects[4] = "\"" + mailLOV + "\"";

    inputArgTypes[0] = USERARG_STRING_TYPE;//Task
    inputArgTypes[1] = USERARG_STRING_TYPE;//Rev Rule
    inputArgTypes[2] = USERARG_STRING_TYPE;//Closure Rule
    inputArgTypes[3] = USERARG_STRING_TYPE;//Plant
    inputArgTypes[4] = USERARG_STRING_TYPE;//Mail

    retValueType = USERARG_STRING_TYPE;

    printf("\n AllUserServiceFntm_TaskBomComparsionFtn before....tm_TaskBomComparsionFtnFtn");
    fflush(stdout);
    ifail = USERSERVICE_register_method("tm_getTaskBOM_Call", (USER_function_t)tm_getTaskBOM_Call, nargs, inputArgTypes, retValueType);

    return ifail;
}

extern "C" DLLAPI int tm_TaskBomComparsion_register_callbacks()
{
    int ifail = ITK_ok;
    printf("\n Before registoring userservice....tm_TaskBomComparsion");
    fflush(stdout);
    ifail = CUSTOM_register_exit("tm_TaskBomComparsion", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFntm_TaskBomComparsionFtn);
    printf("\n After registoring userservice....tm_TaskBomComparsion");
    fflush(stdout);
    return (ITK_ok);
}

