/******************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :  Shubham Ghuge
*  Module               :   
*  Code                 :   
*  Created on			:   26-07-2023
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*********************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

#define ECU_err 919002

EPM_decision_t tm_ECUChk(EPM_rule_message_t msg)
{
	tag_t *Dml_tasksss= NULLTAG;
	tag_t *Dml_taskss= NULLTAG;
	char  *SubSubTaskNm1= NULL;
	char  *SubTaskNm1= NULL;
	int no_attach	=  0;
	int AddSolutionFound	=  0;
	int Tskcntt	=  0;
	int Tskcnttt	=  0;
	int	kkk	=  0;
	int	kk	=  0;
	int	i	=  0;
	tag_t	roottask        =  NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char	*SubSubtaskType		=  NULL;
	int	ii	=  0;
	int	VCChildCunt	= 0;
	int	tsk	= 0;
	int	CMRefcount	= 0;
	int	Tskcnt	= 0;
	int MDLrulefound =0;
	int DR_n_entry    = 1;
	int iChild   =  0;
	int DR_rsltCount   =  0;
	int FiftyFlag      =  0;
	int TwentyOneFlag   =  0;
	int TwentySixFlag   =  0;
	int ThirtyFiveFlag   =  0;
	int ZeroTaskFlag    =  0;
	int ECUMdlFlag     =  0;
	int j =0;
	int countt =0;
	char*	CurrentTask		= NULL;
	char	*PlntToPlnt		= NULL;
	char	*TskNm			= NULL;
	char	*rev_idd		= NULL;
	char	*DMLtype		= NULL;
	char	*TaskDsgGrp		= NULL;
	char	*Partno		= NULL;
	char	*PartMstr_no		= NULL;
	char*   ObjTyp= NULL;
	char   *InputTaskDsgGrp=NULL;
	char **MDLrulevalueXO = NULL;
	char **MDLrulenameXO = NULL;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *Prtrev_idd =NULL;
	char   *DMLDR =NULL;
	char   *p_child_item_id=NULL;
	char   *rel_sstats=NULL;
	char   *rev_iidd=NULL;
	char   *PrtDegGrp=NULL;
	char   *PrtProjj=NULL;
	char   *ECUmoduleNo=NULL;
	int	VehAttached=0;
	int	Mstr=0;
	int	TskSignoffFlag=0;
	int	ECUMdlcount=0;
	char   *DMLProj =NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*TaskPerfInfo2		=  NULL;
	char	*TaskPerfInfo1		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char	*TaskPerfInfo3		=  NULL;
	char	*DMLBUnit		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t ECUMdlTagg = NULLTAG;
	tag_t ECUMdlTag = NULLTAG;
	tag_t*	ECUMdlTags	= NULLTAG;
	tag_t CCVCrel_type = NULLTAG;
	tag_t *MDLclosureruleee = NULLTAG;
	tag_t	p_window 	= NULLTAG;
	tag_t	MDLClosureTag 	= NULLTAG;
	tag_t	MDL_rule 	= NULLTAG;
	tag_t	p_top_line 	= NULLTAG;
	tag_t *VCChildobject=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	DMLTagg 		= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	char  *tasknameofroot= NULL;
	int drrtaskcount=0;
	tag_t  	taskjob=NULLTAG;
	tag_t  	taskroottask=NULLTAG;
	tag_t  	task_job_type=NULLTAG;
	tag_t   *subtasks=NULLTAG;
	tag_t   *dmltasks=NULLTAG;
	char *roottask_Objtype = NULL;
	char *status_root_task = NULL;
	logical is_latest;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_ECUChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ECUChk Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n PO:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n Veh:P6: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
			//////////////Start adding in handler but ensure initial tag//////////
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Veh:P7:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Veh:P8:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "TSKPERFM";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Veh:P9:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF for CV Veh DML
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&TaskPerfInfo1)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo1:[%s]:",TaskPerfInfo1); fflush(stdout);
				//DML project which skipped for validation.
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&TaskPerfInfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo2:[%s]:",TaskPerfInfo2); fflush(stdout);
				//sign off status which need to check fr task sign off status : Completed
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&TaskPerfInfo3)!=ITK_ok)   PrintErrorStack();
				printf(" \n Veh:P9:TaskPerfInfo3:[%s]:",TaskPerfInfo3); fflush(stdout);
				if(tc_strstr(TaskPerfInfo1,"A1") == NULL)
				{
					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
					{
						printf("\n Veh:P12:inside T5_ChangeTaskRevision .....\n");fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						if(InputTaskDsgGrp) InputTaskDsgGrp=NULL;
						InputTaskDsgGrp=subString(sDMLtaskno,11,2);
						printf("\n veh:P13:sDMLtaskno:[%s]  InputTaskDsgGrp:[%s].",sDMLtaskno,InputTaskDsgGrp);fflush(stdout);
						if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
						if (tsk_dml_rel_type!=NULLTAG)
						{
							if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							printf("\n Veh:P14:DML Revision from Task for MR : %d",countt);fflush(stdout);
							for (j=0;j<countt ;j++ )
							{
								if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
								printf("\n Veh:P15: is_latest MR is : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n veh:P16:is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									DMLRevTg = DMLRevision[j];
									if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
									printf("\n Veh:P17:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);

									if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
									if(item_tag==NULLTAG)
									{
										printf("\n Veh:P18:item_tag is NULL.\n");fflush(stdout);
										return decision;
									}
									else
									{
										printf("\n Veh:P19:item_tag found.\n");fflush(stdout);
										if(ITEM_ask_latest_rev (item_tag, &DMLTagg)!=ITK_ok)PrintErrorStack();
										if(DMLTagg==NULLTAG)
										{
											printf("\n Veh:P20:Object not found in Teamcenter...!!\n");fflush(stdout);
											return decision;
										}
										else
										{
											DMLBUnit     =  (char *) MEM_alloc(10 * sizeof(char));
											//DML Details:
											if(AOM_ask_value_string(DMLTagg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
											printf("\n Veh:P21: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s] DMLBUnit:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR,DMLBUnit);fflush(stdout);
											if(strcmp(DMLtype,"Veh")==0)
											{
												if(strcmp(DMLBUnit,"")==0)
												{
													//DML BU is NULL.
													printf("\n Veh:P20:ERROR:DML BU is NULL:[%s]\n",sDMLno);fflush(stdout);
													if(tc_strstr(TaskPerfInfo1,"A9") == NULL)
													{
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML business unit is null.\nPlease update it and process. ",sDMLno);
														decision = EPM_nogo;
														return decision;
													}
												}
												else
												{
													if(strcmp(DMLBUnit,"CVBU")==0)
													{
														if(tc_strstr(TaskPerfInfo2,DMLProj) == NULL)
														{
															printf("\n Veh:P20:Checking for DML:[%s]\n",sDMLno);fflush(stdout);
															// Get 00 task and then vehicle and expand vehicle to BOM.
															Tskcnt=0;
															if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
															printf("\n Veh:V:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
															if (Tskcnt>0)
															{
																if(tc_strstr(TaskPerfInfo1,"B1") == NULL)
																{
																	for (tsk=0;tsk<Tskcnt ;tsk++ )
																	{
																		if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																		printf("\n Veh:V:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																		if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																		{
																			if(TaskDsgGrp) TaskDsgGrp=NULL;
																			if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																			TaskDsgGrp=subString(TskNm,11,2);
																			printf("\n Veh:V:P24: Task: [%s] TaskDsgGrp:[%s] \n",TskNm,TaskDsgGrp);fflush(stdout);
																			if(strcmp(TaskDsgGrp,"00")==0)
																			{
																				printf("\n MDL:V:P26:Vehicle 00 tasks:[%s]",TskNm);fflush(stdout);
																				if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																				if (tsk_CMRef_type!=NULLTAG)
																				{
																					//Getting parts from CMHasSolutionItem
																					CMRefcount=0;
																					if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																					printf("\n Veh:V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																					if(CMRefcount > 0)
																					{
																						Mstr=0;
																						VehAttached =0;
																						for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																						{
																							printf("\n Veh:V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																							if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																							printf("\n Veh:V:P27:Prt_object_type is :[%s]\n",Prt_object_type);fflush(stdout);
																							if(strcmp(Prt_object_type,"Design Revision")==0)
																							{
																								// Put condition for desi rev , to avoid other attachments.
																								if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(TaskCMRef[Mstr], "t5_PartType", &sPartTyp)!=ITK_ok)PrintErrorStack();
																								printf("\n Veh:V:P28:PartMstr_no:[%s] attach part revision:[%s] and sPartTyp:[%s]", PartMstr_no,Prtrev_idd,sPartTyp);fflush(stdout);
																								//check task design group wise module availability.
																								if(strcmp(sPartTyp,"V")==0)
																								{
																									VehAttached =1;
																									printf("\n Veh:V:P26:Chcking for part no:[%s]",PartMstr_no);fflush(stdout);
																									//Expand Vehicle to check ECU module
																									ECUMdlFlag =0;
																									if(GRM_find_relation_type("T5_CCVCHasECUModule", &CCVCrel_type)!=ITK_ok)PrintErrorStack();
																									if (CCVCrel_type!=NULLTAG)
																									{
																										printf("\n Veh:getting CCVCrel_type.");fflush(stdout);
																										ECUMdlcount=0;
																										if(GRM_list_secondary_objects_only(TaskCMRef[Mstr],CCVCrel_type,&ECUMdlcount,&ECUMdlTags)!=ITK_ok)PrintErrorStack();
																										printf("\n Veh:ECUMdlcount: %d",ECUMdlcount);fflush(stdout);
																										if(ECUMdlcount > 0)
																										{
																											ECUMdlFlag=1;
																											ECUMdlTag = ECUMdlTags[0];
																											//check ECU module having at least one released revision to equal or above.
																											if(ITEM_ask_latest_rev(ECUMdlTag, &ECUMdlTagg)!=ITK_ok)PrintErrorStack();
																											printf("\n Veh:Checking ECU module DR status.");fflush(stdout);
																											if(AOM_ask_value_string(ECUMdlTagg,"item_id",&ECUmoduleNo)!=ITK_ok)PrintErrorStack();
																											printf("\n Veh:Checking ECU module no:%s",ECUmoduleNo);fflush(stdout);
																										}
																										else
																										{
																											printf("\nError: need to attach ECU module\n");fflush(stdout);
																											EMH_clear_errors();
																											EMH_store_error_s1(EMH_severity_error,ECU_err,"ECU Module master is not attached under �Has ECU Calibration Module� to Vehicle/CCV, Please attach it.");
																											decision = EPM_nogo;
																											return decision;
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_ECUChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ECUChk Function end...");
	return decision;
}