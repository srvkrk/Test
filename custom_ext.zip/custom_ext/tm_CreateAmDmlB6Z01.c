#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/aom_prop.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define EMH_severity_information 1
#define EMH_severity_warning      2
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
char	*ClrSchmToVf	= NULL;
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;



static void ECHO(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}


int tm_updateObjRevMasterFormName(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nInside tm_updateObjRevMasterFormName ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_APLDMLRevisionMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_with_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
		}
	}
	return 0;
}

int tm_updateObjMasterFormName(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;
	
	printf("\nInside tm_updateMasterFormName");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\nItem ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;
	if(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
	if(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;

			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_APLDMLMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				ITKCALL(AOM_save_with_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
		}
	}
	return 0;
}



int	FunctionToReadDMLNumber(tag_t controlobject, char	*PlantName, char	*Proj_ID,char	*DesignGroup,char	*ecntypeVal,char	**DMLNumber)
{
	int status;

	//Query control object
	char    *qry_entryCntrl[3]  =	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl	=	(char **) MEM_alloc(5 * sizeof(char *));
	int		n_entryT			=	3;
	int		ValCntT				=	0;

	char	*syscommand			=	NULL;
	char	*ExePath			=	NULL;
	char	*UsrP				=	NULL;
	char	*PwdP				=	NULL;
	char	*roleP				=	NULL;

	tag_t*	ValCntrlObjectTagT	=	NULLTAG;
	tag_t	qryTagT				=	NULLTAG;
	tag_t	controlobj			=	NULLTAG;
	
	*DMLNumber	=	NULL;
	*DMLNumber	=	(char *) MEM_alloc(150 * sizeof(char *));

	printf("\nPlant Name : %s, Project : %s, Design group : %s, ECN Type : %s",PlantName,Proj_ID,DesignGroup,ecntypeVal);fflush(stdout);
	
	{
		if (controlobject!=NULLTAG)
		{
			//controlobj	=	ValCntrlObjectTagT[0];
			
			printf("\n consuming web service start: \n"); fflush(stdout);
			if (AOM_ask_value_string(controlobject,"t5_Userinfo1",&ExePath)!=ITK_ok)   PrintErrorStack();
			printf("\n consuming web service start:%s \n",ExePath); fflush(stdout);

			syscommand=(char *) MEM_alloc(500);

			tc_strcpy(syscommand,ExePath);
			tc_strcat(syscommand," ");
			tc_strcat(syscommand,Proj_ID);
			tc_strcat(syscommand," ");
			tc_strcat(syscommand,PlantName);
			tc_strcat(syscommand," ");
			tc_strcat(syscommand,DesignGroup);
			tc_strcat(syscommand," ");
			tc_strcat(syscommand,ecntypeVal);

			printf("\ncommand : %s",syscommand);fflush(stdout);

			int rc;
			FILE *pipe = NULL;
			int i;
			char buffer[3000];


			sprintf(buffer, "%s",syscommand);
			if ((pipe = popen(buffer, "r")) == NULL) {
			perror("popen");
			return 1;
			}
			while (fgets(buffer, 3000, pipe) != NULL)

			printf("buffer: %s",  buffer);

			if (pclose(pipe) == -1) {
			perror("pclose");
			return 1;
			}

			printf("\n consuming web service end \n"); fflush(stdout);

			if(strstr(buffer,"NODMLCREATED")!=NULL)
			{
				printf("\n Checked in TCE, part is not present in TCE  : %s\n",buffer); fflush(stdout);
				tc_strcpy(*DMLNumber,"NODMLCREATED");
			}
			else
			{
				printf("\n Checked in TCE, part is present in TCE : %s\n",buffer); fflush(stdout);
				tc_strcpy(*DMLNumber,buffer);
			}
		}
		else
		{
			tc_strcpy(*DMLNumber,"NODMLCREATED");
		}
	}

	return status;
}
 //extern int AMDMLCreateFuncB6Z01(char  *project,char *dsgnGrp,char *PlantName,tag_t *AMDmlObj,void *retValue)
 extern int AMDMLCreateFuncB6Z01(void *retValue)
 {
	tag_t		APLDTypeTag			=  NULLTAG;
	tag_t		APLDRevTypeTag		=  NULLTAG;
	tag_t		APLDCreInTag		=  NULLTAG;
	tag_t		APLDRevCreInTag		=  NULLTAG;

	//tag_t			APLDTypeTag			= NULLTAG;
	tag_t		TaskRevTag			= NULLTAG;
	tag_t 		APLDMLRevTag		= NULLTAG;
	tag_t		APLTTypeTag			= NULLTAG;
	tag_t		APLTCreInTag		= NULLTAG;
	tag_t		APLTRevTypeTag		= NULLTAG;
	tag_t		APLTRevCreInTag		= NULLTAG;

	tag_t	    Dml_tag		    	= NULLTAG;
	tag_t		APLDMLTag			= NULLTAG;
	tag_t		TaskTagrev		    = NULLTAG;
	tag_t		APLTaskTag			= NULLTAG;
	tag_t 		APLTaskRevTag	    = NULLTAG;
	tag_t 		DmlEcnRlzTypeAttrID = NULLTAG;
	tag_t       *results			=  NULLTAG;
	tag_t		*AmRevObjSet 		=  NULLTAG;

	tag_t       relation_type        = NULLTAG;
	tag_t		apltaskrelation      = NULLTAG;
	tag_t		NewDMLAttrId = NULLTAG;
	tag_t		NewDMLRevAttrId = NULLTAG;
	


	char		*tempString			= NULL;

	char		*DmlNoRule			= NULL;
	char 		*apldmlno			= NULL;
	char 		*aplTaskno			= NULL;
	char		*Year                = NULL;

	char        *Proj_ID=NULL;
	char		*DMLAPL				= NULL;
	char		*Suffix				= NULL;
	char		*item_id 	   		= NULL;
	char 		*DML_no 			= NULL;
	char		**DesignGroupList	= NULL;
	int			max_char_size 					= 100;

	char cCurrentAccessDate[20]		={0};
	WSO_search_criteria_t  	APLTaskCriteria;
	WSO_search_criteria_t  	APLDMLCriteria;


	char *Dml_Name 	  				=	NULL;
	char *DMLSerial					=	NULL;
	char *DMLitem_id				=	NULL;
	char *DmlLastSerial				=	(char *)MEM_alloc(max_char_size * sizeof(char));

	//Integer declaration
	int apl_dml_found=0,apl_task_number_found=0,index=0,n_entries=0,n_found=0;
	int  DMLSerialInt;
	int				l_strings			= 500;
	int FlagPR=0;
	int status=0;
 	int				ifail 	= ITK_ok;
	tag_t 		    AmDmlFindquery		= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	char*			tempStringt			= NULL;
	char **string_array 	= NULL;

	char *item_id_apl_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_apl_dml_str = (char *)MEM_alloc(max_char_size * sizeof(char));

	char *item_id_apl_task = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	//	char *item_id_dml_Str = (char *)MEM_alloc(max_char_size * sizeof(char));

	tag_t *list_of_WSO_tags			= NULLTAG;
	tag_t  NewTaskAttrId 				= NULLTAG;

	int n_strings=1;

	int      num_to_sort  = 1;
	char    *keys[1]      = {"creation_date"};
	int  	 orders[1]     = {2};

	//Webservice changes start
	char	*Response		=	NULL;
	char	*amdmltce		=	NULL;
	char	*dsgnGrp		=	NULL;
	char	*PlantName		=	NULL;
	char	*project		=	NULL;
	char *ECNTyep="APLSTR";
	//Webservice changes ends


USERARG_get_string_argument(&project);	
USERARG_get_string_argument(&dsgnGrp);	
USERARG_get_string_argument(&PlantName);	
//USERARG_get_string_argument(&project);	
	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}
	printf("\n Inside the AMDML Creation for Template Revise"); fflush(stdout);

	printf("\n Inside the AMDML Creation Function  Plan Name : %s",PlantName); fflush(stdout);

		   // printf("2.Found Query \n");fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n cCurrentAccessDate:%s ",cCurrentAccessDate);
	Year=subString(cCurrentAccessDate,9,2);

	if(strcmp(PlantName,"APLJ")==0)
	{
		strcpy(item_id_apl_dml,Year);
		strcat (item_id_apl_dml,"AM80");
		strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM80");
	}
	else if(strcmp(PlantName,"APLL")==0)
	{
		tc_strcpy(item_id_apl_dml,Year);
		tc_strcat (item_id_apl_dml,"AM70");
		tc_strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM70");
	}
	else
	{
		tc_strcpy(item_id_apl_dml,Year);
		tc_strcat (item_id_apl_dml,"AM90");
		tc_strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM90");
	}
			//Qry Find to Get Latest AMDML Created

	CALLAPI(QRY_find2("APLDMLQuery", &AmDmlFindquery));
	n_entries=1;
	char
		 *qry_entries[1] = {"ID"},
		 *qry_values[1] =  {item_id_apl_dml};
	printf(" Print  User  values: %s\n",qry_values[0]);fflush(stdout);
			//printf(" Print entries and values: %s\n",qry_entries[1]);fflush(stdout);


	if(AmDmlFindquery!=NULLTAG)
	{
		  QRY_execute_with_sort(AmDmlFindquery, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &n_found, &results);
	}
	printf("\n Total AMDML Found in DB %d",n_found); fflush(stdout);

			//QRY_execute(AmDmlFindquery, n_entries, qry_entries, qry_values, &n_found, &AmRevObjSet);

	if(n_found>0)
	{
		Dml_tag = results[0];
		AOM_ask_value_string( Dml_tag, "item_id", &Dml_Name);
		printf("\n Dml_Name : %s\n",Dml_Name);fflush(stdout);
		DMLSerial=subString(Dml_Name,6,4);
		printf("\n DMLSerial : %s\n",DMLSerial);fflush(stdout);
		DMLSerialInt =atoi(DMLSerial);
		DMLSerialInt = DMLSerialInt + 1 ;
		printf("\n DMLSerialInt :%d\n",DMLSerialInt);fflush(stdout);
		sprintf(DmlLastSerial,"%d",DMLSerialInt);
		printf("\n DmlLastSerial : %s\n",DmlLastSerial);fflush(stdout);
		tc_strcat (item_id_apl_dml_str,DmlLastSerial);
		tc_strcat (item_id_apl_dml_str,"_");
		tc_strcat (item_id_apl_dml_str,PlantName);
		printf("\n item_id_apl_dml_str:%s",item_id_apl_dml_str);
	}
	else
	{
		tc_strcat (item_id_apl_dml_str,"1001");
		tc_strcat (item_id_apl_dml_str,"_");
		tc_strcat (item_id_apl_dml_str,PlantName);
	}

	char	*cUserInfo2		=	NULL;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t*	ValCntrlObjectTagT	=	NULLTAG;
	tag_t	qryTagCntrl1				=	NULLTAG;
	tag_t	controlobj			=	NULLTAG;

	int     n_entryCntrl1    = 3;

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found webservice\n");fflush(stdout);
		qry_valuesCntrl1[0]="CreateDMLINTCE";
		qry_valuesCntrl1[1]="CreateDMLINTCE";
		qry_valuesCntrl1[2]="0";
							
		printf("\nBefore Control Object Query Found webservice\n");fflush(stdout);

		int	control_number_found1	=	0;
		tag_t	*list_of_WSO_cntrl_tags1	=	NULLTAG;
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found :%d",control_number_found1);fflush(stdout);

		if (control_number_found1>0)
		{						char	*DMLNumber	=	NULL;
						DMLNumber	=	(char *)MEM_alloc (50 * sizeof(char));

						char	*cUserInfo2		=	NULL;
						//DMLNumber	=	strtok(Response,"_");
						//tc_strcat(DMLNumber,"_");
						//tc_strcat(DMLNumber,PlantName);
						//printf("\nNew DML Number as per  TCE : %s",DMLNumber);fflush(stdout);
						
						//calling function to read output from console
						char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
						char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

						tag_t*	ValCntrlObjectTagT	=	NULLTAG;
						tag_t	qryTagCntrl1				=	NULLTAG;
						tag_t	controlobj			=	NULLTAG;

						int     n_entryCntrl1    = 3;
						
						if(QRY_find2("Control Objects...", &qryTagCntrl1));
						if (qryTagCntrl1!=NULLTAG)
						{
							printf("\n Control Object Query Found webservice\n");fflush(stdout);
							qry_valuesCntrl1[0]="CreateDMLINTCE";
							qry_valuesCntrl1[1]="CreateDMLINTCE";
							qry_valuesCntrl1[2]="0";
							
							printf("\nBefore Control Object Query Found webservice\n");fflush(stdout);
							//if(QRY_execute(qryTagT, n_entryT, qry_entryCntrl, qry_valuesCntrl, &ValCntT, &ValCntrlObjectTagT));
							int	control_number_found1	=	0;
							tag_t	*list_of_WSO_cntrl_tags1	=	NULLTAG;
							if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
							printf("\nNumber of control object found :%d",control_number_found1);fflush(stdout);
							
							if (control_number_found1>0)
							{
								AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &cUserInfo2);
								printf("\n cUserInfo2: %s\n",cUserInfo2);fflush(stdout);

								if (tc_strstr(cUserInfo2,ECNTyep)!=NULL)
								{
									printf("\nEcntype %s found under control object ");fflush(stdout);
								}
								else
								{
									//FunctionToReadDMLNumber(list_of_WSO_cntrl_tags1[0],"APLCAR",Proj_ID,DesignGroupList[0],ecntypeVal,&DMLNumber);//Need Dynamic
									FunctionToReadDMLNumber(list_of_WSO_cntrl_tags1[0],PlantName,Proj_ID,DesignGroupList[0],ECNTyep,&DMLNumber);//Need Dynamic
								}
							}
							else
							{
								printf("\nControl object not found...");fflush(stdout);
							}

							printf("\nNew DML Number : %s, ecn type : %s ",DMLNumber,ECNTyep);fflush(stdout);
						}
		


		//	Response	=	creAMDMLInTCE(PlantName,project,"SYSTEM GENERATED APL DML FOR TCUA", dsgnGrp, "AMDML");
			
			amdmltce	=	strtok(DMLNumber,"_");
			tc_strcat(amdmltce,"_");
			tc_strcat(amdmltce,PlantName);
			
			printf("\nAM DML IN TCE : %s",amdmltce);fflush(stdout);
			if (tc_strstr(amdmltce,PlantName)!=NULL  && tc_strstr(amdmltce,"AM")!=NULL)
			{
				//WSOM_clear_search_criteria(&APLDMLCriteria);
				//tc_strcpy(APLDMLCriteria.name,amdmltce);
				//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
				//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
				//printf("\n apl_dml_found as per tce :%d",apl_dml_found);
				printf("\nSearch AMDML as per TCE, so item_is_apl_dml  rename : %s",amdmltce);fflush(stdout);
				item_id_apl_dml_str	=	NULL;
				item_id_apl_dml_str	=	(char *)MEM_alloc(tc_strlen(amdmltce)+25);
				tc_strcpy(item_id_apl_dml_str,amdmltce);
				printf("\nItem Id as per TCE : %s",item_id_apl_dml_str);fflush(stdout);

			}
			else
			 {
				//WSOM_clear_search_criteria(&APLDMLCriteria);
				//tc_strcpy(APLDMLCriteria.name,item_id_apl_dml_str);
				//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
				//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
				//printf("\n apl_dml_found as per tcua :%d",apl_dml_found);
				printf("\nSearch AM DML as per TCUA");fflush(stdout);
			 }
		}
		else
		{
			printf("\nCreateDMLINTCE cntrl not found");fflush(stdout);
		}

	}

	//Webservice changes start
//	Response	=	creAMDMLInTCE(PlantName,project,"SYSTEM GENERATED APL DML FOR TCUA", dsgnGrp, "AMDML");
//	
//	amdmltce	=	strtok(Response,"_");
//	tc_strcat(amdmltce,"_");
//	tc_strcat(amdmltce,PlantName);
//	
//	printf("\nAM DML IN TCE : %s",amdmltce);fflush(stdout);
//	if (tc_strstr(amdmltce,PlantName)!=NULL  && tc_strstr(amdmltce,"AM")!=NULL)
//	{
//		//WSOM_clear_search_criteria(&APLDMLCriteria);
//		//tc_strcpy(APLDMLCriteria.name,amdmltce);
//		//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
//		//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
//		//printf("\n apl_dml_found as per tce :%d",apl_dml_found);
//		printf("\nSearch AMDML as per TCE, so item_is_apl_dml  rename : %s",amdmltce);fflush(stdout);
//		item_id_apl_dml_str	=	NULL;
//		item_id_apl_dml_str	=	(char *)MEM_alloc(tc_strlen(amdmltce)+25);
//		tc_strcpy(item_id_apl_dml_str,amdmltce);
//		printf("\nItem Id as per TCE : %s",item_id_apl_dml_str);fflush(stdout);
//
//	}
//	else
//	 {
//		//WSOM_clear_search_criteria(&APLDMLCriteria);
//		//tc_strcpy(APLDMLCriteria.name,item_id_apl_dml_str);
//		//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
//		//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
//		//printf("\n apl_dml_found as per tcua :%d",apl_dml_found);
//		printf("\nSearch AM DML as per TCUA");fflush(stdout);
//	 }
	//Webservice changes ends
		//Search Formed String of  AM DML in Db
		
	WSOM_clear_search_criteria(&APLDMLCriteria);
	tc_strcpy(APLDMLCriteria.name,item_id_apl_dml_str);
	tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
	status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
	printf("\n apl_dml_found:%d",apl_dml_found);
		//CALLAPI(AOM_ask_value_string(latestAMDMLtag,"item_revision_id",&partRevisionID));

	if(apl_dml_found==0)
	{

		CALLAPI( TCTYPE_find_type("T5_APLDML", NULL, &APLDTypeTag) );
		CALLAPI( TCTYPE_construct_create_input(APLDTypeTag, &APLDCreInTag) );
		CALLAPI( TCTYPE_find_type("T5_APLDMLRevision", NULL, &APLDRevTypeTag) );
		CALLAPI( TCTYPE_construct_create_input(APLDRevTypeTag, &APLDRevCreInTag) );


		printf("\n 11APLDML is : %s\n",item_id_apl_dml_str);fflush(stdout);

		//		tc_strcpy( stringArrayAPLD[0], item_id_apl_dml_str);
		//tc_strcpy( stringArrayAPLD[0], "18AM905501_APLC");
		tc_strcpy( stringArrayAPLD[0], "18AM905502_APLC");
		CALLAPI( TCTYPE_set_create_display_value(APLDCreInTag, "item_id", 1,(const char**)stringArrayAPLD) );

		tc_strcpy( stringArrayAPLD[0], "APL Restructuring DML for Template Revise");
		printf("\n 11APLDML Name  is :\n");fflush(stdout);
		CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "object_name", 1, (const char**)stringArrayAPLD) );
		tc_strcpy( stringArrayAPLD[0], " APL Restructuring DML for Template Revise");
		printf("\n 11APLDML desc is : \n");fflush(stdout);
		CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "object_desc", 1, (const char**)stringArrayAPLD) );
		CALLAPI( AOM_tag_to_string(APLDRevCreInTag, &tempString) );
		tc_strcpy( stringArrayAPLD[0], tempString);
		printf("\nTest0.D1..[%s]\n",stringArrayAPLD[0]);fflush(stdout);
		CALLAPI( TCTYPE_set_create_display_value( APLDCreInTag, "revision", 1,(const char**)stringArrayAPLD) );

		tc_strcpy( stringArrayAPLD[0], "A");
		CALLAPI( TCTYPE_set_create_display_value( APLDRevCreInTag, "item_revision_id", 1, (const char**)stringArrayAPLD) );

		tc_strcpy( stringArrayAPLD[0], project);
		CALLAPI( TCTYPE_set_create_display_value( APLDRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLD) );

		printf("\nTest1..\n");fflush(stdout);

		CALLAPI( TCTYPE_create_object(APLDCreInTag, &APLDMLTag) );

		printf("\nTest2..\n");fflush(stdout);
		printf("\nAPL DML Object created");
		AOM_save_with_extensions(APLDMLTag);
		CALLAPI(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));
		if (APLDMLRevTag!=NULLTAG)
		{
			printf("\nAPLDMLRevTag is not NULLTAG");
		}
		else
		{
			printf("\nAPLDMLRevTag is NULLTAG");
		}

		if (APLDMLTag!=NULLTAG)
		{
			printf("\nAPLDMLTag is not nulltag");
		}
		else
		{
			printf("\nAPLDMLTag is nulltag");
		}

		if (APLDMLTag != NULLTAG)
		{
			printf("\nForm APLDMLTag is not null");
			if(POM_attr_id_of_attr("item_id","T5_APLDML",&NewDMLAttrId));
			if(AOM_refresh(APLDMLTag,TRUE));
			if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			if(POM_set_attr_string(1,&APLDMLTag,NewDMLAttrId,item_id_apl_dml_str));
			if(AOM_save_with_extensions(APLDMLTag));
			if(AOM_refresh(APLDMLTag,TRUE));
			ITKCALL(tm_updateObjMasterFormName(APLDMLTag, item_id_apl_dml_str));//Update MASTER
			

		}

		if (APLDMLRevTag != NULLTAG)
		{
			printf("\n form APLDMLRevTag is not null tag");fflush(stdout);
			ITKCALL(tm_updateObjRevMasterFormName(APLDMLRevTag, item_id_apl_dml_str));
			if(POM_attr_id_of_attr("item_id","T5_APLDMLRevision",&NewDMLRevAttrId));
			if(AOM_refresh(APLDMLRevTag,TRUE));
			if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			if(POM_set_attr_string(1,&APLDMLRevTag,NewDMLRevAttrId,item_id_apl_dml_str));
			if(AOM_save_with_extensions(APLDMLRevTag));
			if(AOM_refresh(APLDMLRevTag,TRUE));

			
			printf("Stamping ECN Type to TOODMLR"); fflush(stdout);
			//CALLAPI(AOM_set_value_string(APLDMLRevTag,"t5_EcnType",ECNTyep));

			CALLAPI(POM_attr_id_of_attr("t5_EcnType","T5_APLDMLRevision",&DmlEcnRlzTypeAttrID));
			CALLAPI(AOM_refresh(APLDMLRevTag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_string(1,&APLDMLRevTag,DmlEcnRlzTypeAttrID,ECNTyep));
			CALLAPI(AOM_save_with_extensions(APLDMLRevTag));
			CALLAPI(AOM_refresh(APLDMLRevTag,TRUE));
			/*

			CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
			CALLAPI(AOM_refresh(APLDMLRevTag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&APLDMLRevTag,TaskClosureDtAttrId,Task_Release_date));
			*/
			CALLAPI(AOM_lock(APLDMLRevTag));

			printf("\n Set Project on AMDML %s and Design Grp : %s ",project,dsgnGrp); fflush(stdout);

			//commented for testing
			//CALLAPI(AOM_set_value_string(APLDMLRevTag,"t5_cprojectcode",project));
			CALLAPI(AOM_set_value_string(APLDMLRevTag,"t5_rlstype","TPL"));

			if(AOM_save_with_extensions(APLDMLRevTag));//Added by Hemal
			CALLAPI( AOM_unlock(APLDMLRevTag) );//Added by Hemal
			if(AOM_refresh(APLDMLRevTag,TRUE));//Added by Hemal
			if(FlagPR==1)
			{
				char **prDesignGrp=NULL;
				NewDMLRevAttrId= NULLTAG;
				n_strings=2;

				prDesignGrp=(char **)malloc(n_strings * sizeof *prDesignGrp);

				for( index=0; index<n_strings; index++ )
				{
					prDesignGrp[index] = (char*)malloc( l_strings + 1 );
				}
				prDesignGrp[0]=dsgnGrp;
				prDesignGrp[1]="PR";
				CALLAPI(AOM_lock(APLDMLRevTag));//Added by Hemal
				if(POM_attr_id_of_attr("t5_crdesigngroup","T5_APLDMLRevision",&NewDMLRevAttrId));
				if(AOM_refresh(APLDMLRevTag,TRUE));
				if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
				//if(POM_set_attr_strings(1,&APLDMLRevTag,NewDMLRevAttrId,"PR"));
				//CALLAPI ( AOM_set_value_string_at(APLDMLRevTag,"t5_crdesigngroup",1,prDesignGrp));
				if(POM_set_attr_strings(1,&APLDMLRevTag,NewDMLRevAttrId,0,2,prDesignGrp));
				if(AOM_save_with_extensions(APLDMLRevTag));//Added by Hemal
				CALLAPI( AOM_unlock(APLDMLRevTag) );//Added by Hemal
				if(AOM_refresh(APLDMLRevTag,TRUE));//Added by Hemal
			}
			else
			{
				CALLAPI(AOM_lock(APLDMLRevTag));//Added by Hemal
				CALLAPI ( AOM_set_value_string_at(APLDMLRevTag,"t5_crdesigngroup",0,dsgnGrp));
				if(AOM_save_with_extensions(APLDMLRevTag));//Added by Hemal
				CALLAPI( AOM_unlock(APLDMLRevTag) );
				if(AOM_refresh(APLDMLRevTag,TRUE));//Added by Hemal
			}

			if(tc_strstr(item_id_apl_dml_str,"AM")!=NULL)
			{
				/*
				if(tc_strcmp(aplAMLastUpDtDup,"-")==0)
				{
				printf("\n Inside if date conversion..");fflush(stdout);
				}
				else
				{
				printf("\n Inside else date conversion..");fflush(stdout);
				getNextDate(aplAMLastUpDtDup,ChangeaplAMLastUpDtDup);

				CALLAPI(ITK_string_to_date(ChangeaplAMLastUpDtDup, &apl_last_md_dt ));

				apl_last_md_dt_cpy = (date_t *)MEM_alloc(sizeof(date_t)*2);
				apl_last_md_dt_cpy[0] = apl_last_md_dt;
				CALLAPI(AOM_set_value_date(APLDMLRevTag,"last_mod_date",apl_last_md_dt_cpy));
				}
				*/

				printf("\n Inside AMDML data updated\n");fflush(stdout);
				//if(dvrNum!=NULL)
				{
					CALLAPI( AOM_lock(APLDMLRevTag) );	//Added by Hemal	
					CALLAPI(AOM_set_value_string(APLDMLRevTag,"t5_DriverVC","54426724R"));
					if(AOM_save_with_extensions(APLDMLRevTag));//Added by Hemal
					CALLAPI( AOM_unlock(APLDMLRevTag) );//Added by Hemal
					if(AOM_refresh(APLDMLRevTag,TRUE));//Added by Hemal
				}
			}
			//CALLAPI( AOM_save_with_extensions(APLDMLRevTag) );
			//CALLAPI( AOM_unlock(APLDMLRevTag) );
		}
		else
		{
			printf("\n AMDML Tag Not Found . EXIT From Functn"); fflush(stdout);
			return status;
		}
		//Create Task & Create Relation Inbetween DML & Task
		int num=0;

		//if(ITEM_ask_latest_rev(APLDMLRevTag,&TaskTagrev));
		printf("\n inside class T5_APLDML......\n");fflush(stdout);
		AOM_ask_value_string(APLDMLRevTag, "item_id", &item_id);

		AOM_ask_value_strings(APLDMLRevTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string(APLDMLRevTag, "t5_cprojectcode", &Proj_ID);

		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n Design Grp Count is : %d\n",num);fflush(stdout);


		int j=0;
		for(j=0;j<num;j++)
		{
			DMLAPL= NULL;
			DML_no= NULL;
			tc_strcpy(item_id_apl_task,"");
			AOM_ask_value_string(APLDMLRevTag, "current_id", &DML_no);
			DMLAPL = strtok (DML_no,"_");
			Suffix = strtok (NULL,"_");
			printf("\n DMLAPL is : %s\n",DMLAPL);fflush(stdout);
			printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

			tc_strcpy(item_id_apl_task,DMLAPL);
			tc_strcat (item_id_apl_task,"_");

			if(DesignGroupList!=NULL)
			{
				printf("\n Design Grp is %s",DesignGroupList[j]);
				if(tc_strcmp(DesignGroupList[j],"")!=0)
				{
					tc_strcat (item_id_apl_task,DesignGroupList[j]);
				}
				else
				{
					printf("\n Design Grp Not Found On APL DML revision "); fflush(stdout);
					status=0;
					return status;
				}
			}
			else
			{
				printf("\n DesignGroupList Tag Null"); fflush(stdout);
				status=0;
				return status;
			}

			tc_strcat (item_id_apl_task,"_");
			tc_strcat(item_id_apl_task,Suffix);

			printf("\n item_id_apl_task to Create :%s\n",item_id_apl_task);fflush(stdout);
			// Serch AM Task Exist in DB or Not
			WSOM_clear_search_criteria(&APLTaskCriteria);
			strcpy(APLTaskCriteria.name,item_id_apl_task);
			strcpy(APLTaskCriteria.class_name,"T5_APLTaskRevision");
			status	= WSOM_search(APLTaskCriteria, &apl_task_number_found, &list_of_WSO_tags);

			printf("\n apl_task_number_found %d\n",apl_task_number_found);fflush(stdout);

			if(apl_task_number_found==0)
			{
				CALLAPI( TCTYPE_find_type( "T5_APLTask", NULL, &APLTTypeTag) );
				CALLAPI( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

				CALLAPI( TCTYPE_find_type( "T5_APLTaskRevision", NULL, &APLTRevTypeTag) );
				CALLAPI( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );

				tc_strcpy( stringArrayAPLT[0], item_id_apl_task);
				CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );

				tc_strcpy( stringArrayAPLT[0], " APL Restructuring DML for Template Revise");

				CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );

				tc_strcpy( stringArrayAPLT[0], " APL Restructuring DML for Template Revise");
				CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "object_desc", 1,(const char**)stringArrayAPLT) );

				CALLAPI( AOM_tag_to_string(APLTRevCreInTag, &tempStringt) );
				tc_strcpy( stringArrayAPLT[0], tempStringt);
				printf("\nTest0.4..[%s]\n",stringArrayAPLT[0]);fflush(stdout);
				CALLAPI( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
				tc_strcpy( stringArrayAPLT[0], "A");
				CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
				tc_strcpy( stringArrayAPLT[0], dsgnGrp);
				CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
				tc_strcpy( stringArrayAPLT[0], project);
				CALLAPI( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );

				printf("\n Value to set in apl_task_number %s:%s:%s:%s:%s:\n",item_id_apl_task,item_id_apl_dml_str,tempStringt,dsgnGrp,project);fflush(stdout);

				CALLAPI( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
				CALLAPI( AOM_save_with_extensions(APLTaskTag) );

				CALLAPI(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));

				if (APLTaskRevTag != NULLTAG)
				{
					printf("\n Calling APLDMLLCSDateStamp for stamping the task...\n");fflush(stdout);
					//CALLAPI(APLDMLLCSDateStamp(APLTaskRevTag,dmlNoLCS,dmlAPLRlzdDt,dmlSTDSIRlzdDt,fperror));

					//tag_t		 TaskClosureDtAttrId=NULLTAG;
					//date_t		 Task_Release_date =NULLDATE;

					/*
					CALLAPI(AOM_lock(APLTaskRevTag));

					CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
					CALLAPI(AOM_refresh(APLTaskRevTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&APLTaskRevTag,TaskClosureDtAttrId,Task_Release_date));
					CALLAPI(AOM_save_with_extensions(APLTaskRevTag));
					CALLAPI(AOM_unlock(APLTaskRevTag));

					CALLAPI(APLDMLLCSDateStamp(APLTaskRevTag,dmlTaskLCS,dmlTaskAPLRlzdDt,dmlTaskSTDRlzdDt,fperror));

					*/
				}

				if ((APLDMLRevTag != NULLTAG) && (APLTaskRevTag != NULLTAG))
				{
					int FndDMLTaskrelation=0;
					printf("\n CREATING REL OF APL DML & TASK...\n");fflush(stdout);

					CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
					CALLAPI(GRM_find_relation(APLDMLRevTag, APLTaskRevTag, relation_type ,&FndDMLTaskrelation));
					if(FndDMLTaskrelation)
					{
						printf("\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",item_id_apl_dml_str,item_id_apl_task);fflush(stdout);
						//fprintf(fpexception,"\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",apldmlno,aplTaskno);
					}
					else
					{
						CALLAPI(GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation));
						CALLAPI(GRM_save_relation(apltaskrelation));
					}
				}
				else
				{
					printf("\n Unable to CREATING REL OF APL DML & TASK...\n");fflush(stdout);
				}
			}
		}
	}
										tag_t template_tag = NULLTAG;
									tag_t test_job_a = NULLTAG;
									int attachment_types = 1;
									if(AOM_refresh(APLDMLRevTag,TRUE));
CALLAPI(EPM_find_template2("ECN APL Workflow",0,&template_tag));

										if (template_tag!=NULLTAG)
										{
											printf("\n Submit APL DML in to workflow\n");fflush(stdout);
											CALLAPI(EPM_create_process("APL DML Process","",template_tag,1, &APLDMLRevTag,&attachment_types,&test_job_a));
											printf("\n Submit APL DML in to workflow process complete\n");fflush(stdout);
										}
	if(AOM_refresh(APLDMLRevTag,TRUE));

	if(list_of_WSO_tags[0]!=NULLTAG)
	{
		MEM_free(list_of_WSO_tags);
	}
	// APL AMDML Tag
	//*AMDmlObj=APLDMLRevTag;
//	status=1;

	if (APLTaskRevTag != NULLTAG)
	{
			tag_t * docn_best = (tag_t *) MEM_alloc (1 * sizeof (tag_t));
		int n_docn_best = 1;
		USERSERVICE_array_t arrayStruct;
		docn_best=&APLTaskRevTag;

		ifail = USERSERVICE_return_tag_array(docn_best, n_docn_best, &arrayStruct);
		printf("\nAfter returning Value=%d",arrayStruct.length);fflush(stdout);

		if (arrayStruct.length != 0)
		*((USERSERVICE_array_t*) retValue) = arrayStruct;	

		printf("\nAfter returning Value*******");fflush(stdout);
	
	}

	return ifail;
}

extern int AMDMlCreationRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 3;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	//inputArgTypes[3] = USERARG_STRING_TYPE;
	//inputArgTypes[4] = USERARG_STRING_TYPE;

	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n CreateAmDmlGmDmlFnc before....CreateAmDmlGmDmlFncCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("AMDMLCreateFuncB6Z01",(USER_function_t)AMDMLCreateFuncB6Z01,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}


extern int APLDMLCreateFuncServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	//CALLAPI(EBOMMBOMReportRegisterServiceFnc());
	
	AMDMlCreationRegisterServiceFnc();
	
	return ifail;
	
}

extern DLLAPI int tm_CreateAmDmlB6Z01_register_callbacks ()
{
	int ifail    = ITK_ok;

	ifail=CUSTOM_register_exit ( "tm_CreateAmDmlB6Z01", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)APLDMLCreateFuncServiceFnc);

	return ( ITK_ok );
}
