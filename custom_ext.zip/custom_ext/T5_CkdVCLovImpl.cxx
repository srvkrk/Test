//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the implementation for the Business Object T5_CkdVCLov

*/

#include <T5_tm_ckdlib/T5_CkdVCLov.hxx>
#include <T5_tm_ckdlib/T5_CkdVCLovImpl.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tccore/item.h>



#include <fclasses/tc_string.h>
#include <tc/tc.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>


#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>

#include <tccore/grm.h>
#include <tccore/grmtype.h>


using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_CkdVCLovImpl::T5_CkdVCLovImpl(T5_CkdVCLov& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_CkdVCLovImpl::T5_CkdVCLovImpl( T5_CkdVCLov& busObj )
   : T5_CkdVCLovGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_CkdVCLovImpl::~T5_CkdVCLovImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_CkdVCLovImpl::~T5_CkdVCLovImpl()
{
}

//----------------------------------------------------------------------------------
// T5_CkdVCLovImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_CkdVCLovImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_CkdVCLovGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int getESHasVc(const char *val, int* count, tag_t** items)
{
	int ifail = ITK_ok;
	tag_t imanren_reltag=NULLTAG;

	*count = 0;
	tag_t* itemsRev =NULLTAG;

	int* count1=0;
	tag_t* items1=NULLTAG;

	char *item_id = NULL;





	printf("\n\n Rows==%s \n",val);fflush(stdout);

	tag_t  query	= NULLTAG;
	tag_t  *t_item1	= NULLTAG;

	int		n_found	= 0;

	char
	*qry_entries3[] 	= {(char *)"Item ID"},
	*qry_values3[]      = {(char *)val};

	printf("\n\n Rows333==%s \n",val);fflush(stdout);
	QRY_find("Item ID", &query);
	printf("\n\n Rows444==%s \n",val);fflush(stdout);

	QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1);
	printf("\n\n Rows555==%s %d\n",val,n_found);fflush(stdout);

	AOM_ask_value_string(t_item1[0], "item_id",&item_id);
	//printf("\n\n Rows666 VAL1= %s\n",item_id);fflush(stdout);




	//printf("\n\n Rows777 VAL= %s\n",item_id);fflush(stdout);
	GRM_find_relation_type("T5_EpsVhR",&imanren_reltag);
	printf("\n\n Rows888 VAL= \n");fflush(stdout);

	tag_t latestrev=NULLTAG;
	ITEM_ask_latest_rev(t_item1[0],&latestrev);

	printf("\n\n Rows899 VAL= \n");fflush(stdout);
	//printf("\n\n Rows888 VAL= %s\n",object_string);fflush(stdout);

	GRM_list_secondary_objects_only(latestrev, imanren_reltag,  count,&itemsRev);
	printf("\n\n Rows1000 VAL= %d\n",*count);fflush(stdout);
	(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
	int i=0;
	for(i=0;i<*count;i++)
	{
		tag_t VehMaster = NULLTAG;
		ITEM_ask_item_of_rev(itemsRev[i], &VehMaster);
		(*items)[i] = VehMaster;
	}

	return ifail;
}

/**
 * Returns List Of Values based on Dynamic LOV definition and user search criteria.
 * @param operationInputTag - Operation Input containing the modified values.
 * @param propertyName - Name of the selected property.
 * @param searchString - User entered search string.
 * @param sortByProp - Property to use for sorting.
 * @param sortOrder - order for sorting (0=Ascending, 1=Descending).
 * @param nResults - Number of returned results.
 * @param results - Returned Values for LOV.
 * @return - Zero (0) if everything is alright otherwise the error code.
 */
int  T5_CkdVCLovImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
	 int ifail = ITK_ok;
	    bool isNull=false;
	    std::string obj_val;
	    *nResults=0;
	    (*results)=NULLTAG;
	    (*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));

	    // Call the parent Implementation
	    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

	    // Your Implementation
	    try
		{
			Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
			(Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
			if( refOprtnInput!=NULL )
			{
				refOprtnInput->getString("t5_ErcEsNo", obj_val, isNull ); ///get properties from the object

				if(isNull==false)
				{
				printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val.c_str());fflush(stdout);
				getESHasVc(obj_val.c_str(),nResults, results );
				}

				else
				{
					printf("\n--->>>>> In  NULL 11111111");fflush(stdout);
					//*nResults=0;
				}
			}
			else
			{
				printf("\n--->>>>> In  NULL refinputtag");fflush(stdout);
			}

		}
		catch( const IFail& ex )
		{
		   ifail = ex.ifail();
		}

	    return ifail;
}
