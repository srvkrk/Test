/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   :
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"
#define NULLDATE   (POM_null_date())
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

extern int tm_AdmrRprtAWCTCEUpdServiceFnc( void *retValue)
{
	int	  ifail 	= ITK_ok;
	char  command[512];
	char *ERCDMLNo= NULL;
	USERARG_get_string_argument(&ERCDMLNo);
	printf("\n Argument Received(ConsmbltbleUpdServiceFnc) Consumabletemp=%s\n",ERCDMLNo);fflush(stdout);
	if(tc_strcmp(ERCDMLNo,"")!=0)
	{
		printf("\n UAPROD:Task name: %s ", ERCDMLNo);fflush(stdout);
		sprintf(command,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/ADMAWCreport/ADMreportAWCTCUA.sh %s ",ERCDMLNo);
		TC_write_syslog("Command = %s\n",command);
		system(command);
	}
	return ifail;
}
extern int tm_AdmrRprtAWCTCEUpdRegisterServiceFnc()
{
	int ifail = ITK_ok;
	int nargs = 1;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
	inputArgTypes[0] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n tm_AdmrRprtAWCTCEUpdServiceFnc before...");fflush(stdout);
	ifail=USERSERVICE_register_method("tm_AdmrRprtAWCTCEUpdServiceFnc",(USER_function_t)tm_AdmrRprtAWCTCEUpdServiceFnc,nargs,inputArgTypes,retValueType);
	return ifail;
}
extern int All_tm_AdmrRprtAWCTCE(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	ITKCALL(tm_AdmrRprtAWCTCEUpdRegisterServiceFnc());
	return ifail;
}
extern DLLAPI int tm_AdmrRprtAWCTCE_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n tm_AdmrRprtAWCTCE....");
	printf("\n Before registoring userservice tm_ConsmblTbleUpdFuncs ....");
	ifail=CUSTOM_register_exit ( "tm_AdmrRprtAWCTCE", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)All_tm_AdmrRprtAWCTCE);
	printf("\n After registoring userservice tm_AdmrRprtAWCTCE....");
	return ( ITK_ok );
}