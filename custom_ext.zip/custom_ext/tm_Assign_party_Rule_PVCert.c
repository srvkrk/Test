#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_Assign_party_Rule_PVCert(EPM_rule_message_t msg)
{
	int		ifail 		= ITK_ok;
	logical hasbypass =true;
	//PVBU PEER REVIEWER...
	const char*   Axle_Peer_role = "Peer_AXLE_W_T_Reviewers_PV";
	const char*   CAB_Peer_role = "Peer_CAB_Reviewers_PV";
	const char*   Chassis_Peer_role = "Peer_Chassis_Design_PV";
	const char*   E_and_E_Peer_role = "Peer_E_and_E_Reviewers_PV";
	const char*   Engine_Peer_role = "Peer_Review_Engine_PV";
	const char*   Brakes_Peer_role = "Peer_Brake_Reviewers_PV";
	const char*   PTrain_Peer_role = "Peer_Power_TrainInt_Reviewers_PV";
	const char*   Steering_System_Peer_role = "Peer_St_Sys_Cntrl_Reviewers";
	const char*   Suspenssion_Peer_role = "Peer_Suspension_Reviewers_PV";
	const char*   Gearbox_Peer_role = "Peer_Aux_GearBox_Reviewers_PV";
	const char*   Peer_Prpller_shft = "Peer_Prpller_shft";
	EPM_decision_t decision = EPM_go;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	roottask		= NULLTAG;
	int     CRBcunt		=  0;
	int     Tskcout		=  0;
	int     no_attach		=  0;
	int     CertFlag		=  0;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t   *attachment= NULLTAG;
	logical is_Tsklatst;
	logical is_Tskletst;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t	TskCRBTag	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* primaryobjs = NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	char   *ObjTyp= NULL;
	char *sDMLrlstype = NULL;
	char	*Task_name		= NULL;
	char *DMLtype = NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t	TechSpecObjTag   = NULLTAG;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass = NULL;
	char*	ProjDesc = NULL;
	char*	TechSpecNum = NULL;
	char*	VCBusUnit = NULL;
	char*	Proj_PltFrm = NULL;
	char*	VCBusUnitDup = NULL;
	tag_t	item_tag		= NULLTAG;
	int t =0;
	int b =0;
	int jtsk =0;
	int ii =0;
	int jkk =0;
	int TScount =0;
	int DsgGrpcount =0;
	tag_t   PRDqryTag     = NULLTAG;
	tag_t   DMLqryTag     = NULLTAG;
	int     DsgGrup = 0;
	char	*DsgGrp			= NULL;
	char	*Tsk_class		= NULL;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	objTag		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	char	*DMLNo		= NULL;
	char	*TskReviewr		= NULL;
	char	*DML_info1		= NULL;
	char	*DML_info2		= NULL;
	char	*DML_info3	= NULL;
	char	*DML_info4	= NULL;
	char	*DML_info6	= NULL;
	char	*DML_info7	= NULL;
	char	*DML_info8	= NULL;
	char	*DML_info9	= NULL;
	char	*sPlntToPlnt	= NULL;
	char   type_name8[TCTYPE_name_size_c+1];
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t*  DRAna			= NULLTAG;
	tag_t*  DRAna1			= NULLTAG;
	tag_t*  DRAna2			= NULLTAG;
	tag_t*  DRAna3			= NULLTAG;
	tag_t*  CertiAna			= NULLTAG;
	tag_t*  CEAna			= NULLTAG;
	tag_t	DRAna_Patri_Type	= NULLTAG;
	tag_t	CertiAna_Patri_Type	= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	tag_t	DRAna_Party		= NULLTAG;
	tag_t	CertiAna_Party		= NULLTAG;
	tag_t   NPIparty	        = NULLTAG;
	tag_t   NPIpartytag	        = NULLTAG;
	tag_t   role_tag	        = NULLTAG;
	char*	DMLType = NULL;
	char*	DML_BU = NULL;
	char*	ProjectID = NULL;
	char*	DMLDrStat = NULL;
	char*	DMLVertical = NULL;
	char*	DMLDesignGrp = NULL;
	char **DesignGroupList;
	char*	DMLReason = NULL;
	char*	DML_CE_Group = NULL;
	char*	Proj_BU = NULL;
	char*   groupName			    = NULL;
	char*   item_id				    = NULL;
	char	*DR_Gateway_Role		= NULL;
	char	*CertiFication_Role		= NULL;
	char	*DRgroupNameCV		= NULL;
	char	*groupNamePV		= NULL;
	char	*Part_prj		= NULL;
	char	*DesgTyp		= NULL;
	char	*Part_no		= NULL;
	char	*PartTyp		= NULL;
	char	*PRD_info4		= NULL;
	char	*PRD_info3		= NULL;
	char	*PRD_info2		= NULL;
	char	*PRD_info1		= NULL;
	char	*sPrtColInd		= NULL;
	char	*rel_status		= NULL;
	char	*rev_idd		= NULL;
	char	*Partno		= NULL;
	char	*Prtrev_idd		= NULL;
	char	*DML_info10		= NULL;
	char	*DMLReviewr		= NULL;
	char	*relation_name		= NULL;
	tag_t	PartypObj		= NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t   *reviewertag	= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	int     No_Peer = 0;
	int CRBcount = 0;
	int     CertiFlag = 0;
	int     kk = 0;
	int     ik = 0;
	int     jk = 0;
	int     Taskcout = 0;
	int     prt = 0;
	int     PltFrmPartFlg = 0;
	int     No_CertiAna = 0;
	int     No_DRAna = 0;
	int     No_DRAna1 = 0;
	int     No_DRAna2 = 0;
	int     No_DRAna3 = 0;
	int     No_CEAna = 0;
	int		partcnt = 0;
	int		resultCount = 0;
	int		FirstTimeVehFlag = 0;
	int		FourthCodition = 0;
	int		SixthCondition = 0;
	int		PassFlag = 0;
	int		DRPassFlag = 0;
	int		fivethCondition = 0;
	int		DRGateWayVehFalg = 0;
	int		DRGateWayFalg = 0;
	int		Item_count = 0;
	int		DsgN = 0;
	int		FirstTimeFlag = 0;
	int     cnt_ccvcls      =  0;
	int     noOfreviewer    =  0;
	tag_t *ClsObjTag= NULLTAG;
	tag_t  	master =	NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t ObjTypDmlCRB = NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	logical is_Tskltst;
	tag_t   DRGrp_tag			= NULLTAG;
	tag_t   CertiGrp_tag			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   DMLTag		= NULLTAG;
	tag_t   DRAnalyst_tag		= NULLTAG;
	tag_t   relation_type_tag		= NULLTAG;
	tag_t   CertiAnalyst_tag		= NULLTAG;
	tag_t   group_tag		= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t participant_type = NULLTAG;
	char   *sPartObjyp=NULL;
	char   *type_name7=NULL;
	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	tag_t   *PRD_CntrlObjectTag      = NULLTAG;
	char   *Tsk_Typ=NULL;
	int     FirstTimeTPLFlag =  0; 
	int     iESOAppliFlag =  0; 
	int     iESOAppliValue =  0; 
	int     DML_rsltCount      =  0;
	int     PRD_rsltCount      =  0;
	int     DML_n_entry    = 1;
	int     PRD_n_entry    = 1;
	char*	 Prtobj_type = NULL;
	char*	 Prtobj_typee = NULL;
	char    *DML_qry_entry[1]  = {"SYSCD"};
	char    *PRD_qry_entry[1]  = {"SYSCD"};
	char    **DML_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **PRD_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	//logical hasbypass =true;
	sDMLrlstype=(char *)MEM_alloc(20);
	DML_CE_Group = (char	*)MEM_alloc(100);
	char cCurrentAccessDate[20]={0};
	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group_CV");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);
	//tag_t   *IndeNum_objects		= NULLTAG;
	//tag_t   TagQryIndeNum		= NULLTAG;
	//int	n_entriesInd = 1;

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML/Task Number: [%s].", DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
			printf("\n ASSIGN:P9:.Control Table for Assign dynamic party....\n"); fflush(stdout);
			if(QRY_find2("ControlObjects", &DMLqryTag));//14.3
			if (DMLqryTag)
			{
				printf("\n ASSIGN:P10:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n ASSIGN:P11:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DML_qry_values2[0] = "PVPartyRule";
			if(QRY_execute(DMLqryTag, DML_n_entry, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
			printf(" \n ASSIGN:P12:DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
			if(DML_rsltCount > 0)
			{
				//PV ONOFF
				if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo1",&DML_info1)!=ITK_ok)   PrintErrorStack();
				printf("\n ASSIGN:DML_info1 is.:[%s]\n", DML_info1);fflush(stdout);
				//PV All eligible DML Types: ,TSKR,MR,TODR,EP,RBQU,Veh,
				if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo2",&DML_info2)!=ITK_ok)   PrintErrorStack();
				printf("\n ASSIGN:DML_info2 is.:[%s]\n", DML_info2);fflush(stdout);
				//PV DML All BU: ,PVBU,PV-PSE,
				if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo3",&DML_info3)!=ITK_ok)   PrintErrorStack();
				printf("\n ASSIGN:DML_info3 is.:[%s]\n", DML_info3);fflush(stdout);
				
				if(tc_strstr(DML_info1,"PVDMLA01")==NULL)
				{
					groupNamePV = (char	*)MEM_alloc(100);
					tc_strcpy(groupNamePV,"ECert_Approver");
					
					DMLType=(char *)MEM_alloc(20);
					DML_BU=(char *)MEM_alloc(30);
					ProjectID=(char *)MEM_alloc(20);
					if(AOM_ask_value_string(objTag,"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
					printf("\n ASSIGN:P13:DML Number: [%s] DMLType: [%s] DML_BU:[%s] ProjectID :[%s]",DMLNo,DMLType,DML_BU,ProjectID);fflush(stdout);
						
					printf("\n ASSIGN:P14::%s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
					tc_strcpy(sDMLrlstype,"");
					tc_strcpy(sDMLrlstype,",");
					tc_strcat(sDMLrlstype,DMLType);
					tc_strcat(sDMLrlstype,",");
					printf("\n ASSIGN:P15:sDMLrlstype: %s",sDMLrlstype);fflush(stdout);
					if(tc_strstr(DML_info1,"DMLASGA01") == NULL)
					{
						if((tc_strcmp(DMLType,"")==0) ||(tc_strcmp(ProjectID,"")==0)||(tc_strcmp(DML_BU,"")==0))
						{
							printf("\n ASSIGN:P16:%s:ERROR:DML type/DMLBU/DML Project is NULL..................",DMLNo);fflush(stdout);
						}
					}
					if(tc_strstr(DML_info1,"DMLASGA02") == NULL)
					{
						printf("\n ASSIGN:P17::%s:Check for DML BU:[%s].",DMLNo,DML_BU);fflush(stdout);
						if(ProjectID)
						{
							if(QRY_find2("Qury_Project", &queryTag));//14.3
							printf("\n ASSIGN:P17:After Prd_Project: QRY_find");fflush(stdout);
							if (queryTag)
							{
								printf("\n ASSIGN:P18:Found Query");fflush(stdout);
							}
							else
							{
								printf("\n ASSIGN:P19:Not Found Query");fflush(stdout);
							}
							qry_values[0] = ProjectID;
							if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
							printf("\n ASSIGN:P20: resultCount : %d\n", resultCount); fflush(stdout);
							if(resultCount > 0)
							{
								printf("\n ASSIGN:P21:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
								Project_t = t5_Project[0];
								if (Project_t!=NULLTAG)
								{
									ProjectClass=(char *)MEM_alloc(20);
									ProjDesc=(char *)MEM_alloc(200);
									Proj_PltFrm=(char *)MEM_alloc(20);
									Proj_BU=(char *)MEM_alloc(20);
									if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
									printf("\n ASSIGN:P22: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
									if(tc_strstr(DML_info1,"DMLASGA03") == NULL)
									{
										if((tc_strcmp(Proj_PltFrm,"")==0) ||(tc_strcmp(Proj_BU,"")==0)||(tc_strcmp(ProjectClass,"")==0))
										{
											printf("\n ASSIGN:P23:%s:ERROR:Project platform/proj BU/Proj Class is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
										}
									}
								}
							}
						}
						//For PVBU DML BU
						if(tc_strstr(DML_info3,DML_BU) != NULL)
						{
							printf("\n ASSIGN:PV:P24:%s:It is for PV DML Type.",DMLNo);fflush(stdout);
							if(tc_strstr(DML_info2,sDMLrlstype) != NULL)
							{
								//CE Reviewer not for PVBU.
								DMLVertical=(char *)MEM_alloc(50);
								printf("\n ASSIGN:PV:P25: Setting CE Reviewer...");fflush(stdout);
								if(AOM_ask_value_string(objTag,"t5_cDRstatus",&DMLDrStat)!=ITK_ok)PrintErrorStack();
								//if(AOM_ask_value_string(objTag,"t5_reason",&DMLReason)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_ask_value(objTag, "t5_reason", &DMLReason)!=ITK_ok)PrintErrorStack();
								//if(AOM_ask_value_string_at(objTag,"t5_crdesigngroup",DsgGrpcount,&DMLDesignGrp)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_strings( objTag,"t5_crdesigngroup",&DsgGrpcount,&DesignGroupList)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(objTag,"t5_ProductLine",&DMLVertical)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(objTag,"t5_PlntToPlnt",&sPlntToPlnt)!=ITK_ok)PrintErrorStack();

								printf("\n ASSIGN:PV:P26:DML DR STATUS: [%s] DMLType: [%s] DMLReason: [%s] DsgGrpcount: [%d] DMLVertical: [%s] sPlntToPlnt:[%s]", DMLDrStat,DMLType,DMLReason,DsgGrpcount,DMLVertical,sPlntToPlnt);fflush(stdout);

								printf("\n ASSIGN:PV:P27:%s:REMOVE CE REVIEWER and Certification Reviewer START.. \n",DMLNo);fflush(stdout);
								
								
								// START: CERTIFICATION REVIEWER : T5_CertificatnReviewer ---------------------------------------------------------
								printf("\n PV_CERT:P1:START:CE REVIEWER: T5_CertificatnReviewer....................................");fflush(stdout);
								if(tc_strstr(DML_info1,"DMLASGB03") == NULL)
								{
									printf("\n PV_CERT:P2:Going for certification reviewer only for vehicle DML and veh GMD......\n");fflush(stdout);
									//if((tc_strcmp(DML_BU,"PCBU")==0)||(tc_strcmp(DML_BU,"PVBU")==0)||(tc_strcmp(DML_BU,"CVBU")==0))
									if(tc_strcmp(DML_BU,"PVBU")==0)
									{
										//DMLType
										if((tc_strcmp(DMLType,"Veh")==0)&&((tc_strcmp(DMLDrStat,"DR3")==0)||(tc_strcmp(DMLDrStat,"DR3P")==0)||(tc_strcmp(DMLDrStat,"DR4")==0)||(tc_strcmp(DMLDrStat,"DR5")==0)||(tc_strcmp(DMLDrStat,"AR3")==0)||(tc_strcmp(DMLDrStat,"AR3P")==0)||(tc_strcmp(DMLDrStat,"AR4")==0)||(tc_strcmp(DMLDrStat,"AR5")==0)))
										{
											if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
											if (DmlTsk_tag!=NULLTAG)
											{		
												if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
												printf("\n PV_CERT:P3:Veh: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
												for (kk=0;kk<Taskcout ;kk++ )
												{
													if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
													if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));//14.3
													printf("\n PV_CERT:P4:Veh: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
													if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
													{
														if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
														if(is_Tskltst != true)
														{
															printf("\n PV_CERT:P5:Veh:is_Tskltst is not true .....\n");fflush(stdout);
														}
														else
														{
															if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
															printf("\n PV_CERT:P6:Veh: partcnt.:%d\n",partcnt);fflush(stdout);
															if (partcnt>0)
															{
																prt=0;
																PltFrmPartFlg=0;
																for (prt=0;prt<partcnt ;prt++ )
																{							
																	AssyTag=PartsTag[prt];
																	if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																	printf("\n PV_CERT:P7:Veh:.Part_no:%s ...",Part_no);	fflush(stdout);
																	if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																	printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																	if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																	printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																	if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																	{
																		CertiFlag ++;
																		printf("\n PV_CERT:P8:Veh:more modification needed for certification review:%d",CertiFlag);fflush(stdout);
																	}
																}
															}
														}
													}
												}
											}
										}
										else if((tc_strcmp(DMLType,"TODR")==0)&&((tc_strcmp(sPlntToPlnt,"DR2 to DR3")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR3P")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR4 to DR5")==0)))
										{
											if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
											if (DmlTsk_tag!=NULLTAG)
											{		
												if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
												printf("\n PV_CERT:P9:GM:: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
												for (kk=0;kk<Taskcout ;kk++ )
												{
													if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
													if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));//14.3
													printf("\n PV_CERT:P10:GM:: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
													if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
													{
														if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
														if(is_Tskltst != true)
														{
															printf("\n PV_CERT:P11:GM::is_Tskltst is not true .....\n");fflush(stdout);
														}
														else
														{
															if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
															printf("\n PV_CERT:P12:GM:: partcnt.:%d\n",partcnt);fflush(stdout);
															if (partcnt>0)
															{
																prt=0;
																PltFrmPartFlg=0;
																for (prt=0;prt<partcnt ;prt++ )
																{							
																	AssyTag=PartsTag[prt];
																	if(AOM_UIF_ask_value(AssyTag, "object_type", &Prtobj_typee)!=ITK_ok)   PrintErrorStack();
																	printf("\n PV_CE: Object Type is : %s",Prtobj_typee);	fflush(stdout);	
																	if(tc_strcmp(Prtobj_typee,"Folder")!=0)
																	{
																		if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																		printf("\n PV_CERT:P12:GM::.Part_no:%s ...",Part_no);	fflush(stdout);
																		if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																		printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																		if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																		printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																		if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																		{
																			CertiFlag ++;
																			printf("\n PV_CERT:P13:GM:more modification needed for certification review:%d",CertiFlag);fflush(stdout);
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										else
										{
											printf("\n PV_CERT:P14:This DML type is not applicable for certification review.");fflush(stdout);
										}
										if (CertiFlag >0)
										{
											if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
											if (dml_CRB_rel_type!=NULLTAG)
											{
												printf("\n ASSIGN:P28:inside participant removal. \n");fflush(stdout);
												if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
												printf("\n ASSIGN:PV:P29: DmlCRB count: %d",CRBcount);fflush(stdout);	
												for (jk=0;jk<CRBcount ;jk++ )
												{	
													//printf("\n ASSIGN::jk: %d.\n",jk);fflush(stdout);
													DmlCRBTag = DmlCRB[jk];
													if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
													if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));//14.3
													printf("\n ASSIGN:PV:P30:DML: Participants Name: %s", type_name7);fflush(stdout);
													//VI Reviewer will be work as Certification reviewer
													if (tc_strcmp(type_name7,"T5_CertificatnReviewer")==0)
													{
														CertFlag++;
													}
												}
												if (CertFlag>0)
												{
													printf("\n CErtification Reviewer is present");fflush(stdout);
												}
												else
												{
													printf("\n CErtification Reviewer is present");fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,PO_BASIC_VALI,"ERROR::DML is eligible for Certification reviewer, but no Certification reviewer is assigned.\nPlease get it assigned from DML support team.");	
													decision = EPM_nogo;
													return decision;
												}
											}
										}
									}
								}	
							}
						}
					}
				}
				else
				{
					printf("\n ASSIGN:function tm_Assign_Dynamic_party_PV is OFF...");fflush(stdout);
				}
			}
	}
	return decision;
}