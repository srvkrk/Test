/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_VMLTReviewerForTaskFun.c
**
**
**	Date							Author					Modification
**	02-06-2021						Mohan Tayade			Code creation
**
** command to run:
GateMaturationUpd -u=hpp05653 -pf=hpp05653 -g=dba -file=input.txt
./tm_VMLTReviewerForTaskFun -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=16PP251772
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int GateMaturationUpd(char* item_id);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);

	 ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	/*output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/

		//ifail = read_value_from_file(Filename);
		ifail = tm_VMLTReviewerForTaskFun(dmlnob);
		CHECK_FAIL;

	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*design_group			= NULL;
	char 			*dr_status				= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s",itemid);


		//ifail = tm_DesignRevBOM(itemid,"13PP254028","DR2");
				//ifail = GateMaturationUpd(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}
// Check Milestone Live Project
int CheckMilestoneLive(char* sProject)
{
	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t	*MilstonCntrlObjectTag		= NULLTAG;
	tag_t	MilestoneqryTag		= NULLTAG;
	char    *Milston_qry_entry[1]  = {"SYSCD"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*	 Milstoninfo1 = NULL;
	char*	 Milstoninfo2 = NULL;

	printf("\n Y15: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n Y16:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n Y17:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = "Milston";
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n Y18:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n Y19:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n Y20:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

		if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		{
			printf("\n Y21: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n Y22:It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 0;
		}
	}

	return 0;
}

int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n Y13: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n Y14: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;
}

int tm_VMLTReviewerForTaskFun(char* item_id)
{
	int		ifail 		= ITK_ok;
	//Variable Declaration
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	char*	 sUserId = NULL;
	char*	 GrpMembName = NULL;
	tag_t	GrpTag = NULLTAG;
	int	AccesFound=0;
	int	jkl=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	int     DR_rsltCount      =  0;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	const char*   Test_VMTL_role = "BIW_COC_Reviewer";
	const char*   Brake_VMTL_role = "Brakes_Controls_VMTL_DML_PVBU";
	const char*   BIW_VMTL_role = "CAB_BIW_VMTL_DML_PVBU";
	const char*   Door_VMTL_role = "CAB_Door_VMTL_DML_PVBU";
	const char*   ExtTrims_VMTL_role = "CAB_Ext_Trims_VMTL_DML_PVBU";
	const char*   Fit_VMTL_role = "CAB_Int_Fittings_VMTL_DML_PVBU";
	const char*   IntTrims_VMTL_role = "CAB_Int_Trims_VMTL_DML_PVBU";
	const char*   Mascots_VMTL_role = "CAB_Mascots_VMTL_DML_PVBU";
	const char*   Seat_VMTL_role = "CAB_Seats_VMTL_DML_PVBU";
	const char*   EE_VMTL_role = "E&E_VMTL_DML_PVBU";
	const char*   Exhaust_VMTL_role = "Exhaust_VMTL_DML_PVBU";
	const char*   Frame_VMTL_role = "Frames_VMTL_DML_PVBU";
	const char*   Fuel_VMTL_role = "Fuel_System_VMTL_DML_PVBU";
	const char*   HVAC_VMTL_role = "HVAC_VMTL_DML_PVBU";
	const char*   Mounts_VMTL_role = "Mounts_VMTL_DML_PVBU";
	const char*   Restrn_VMTL_role = "Restraints_VMTL_DML_PVBU";
	const char*   Steering_VMTL_role = "Steering_VMTL_DML_PVBU";
	const char*   Suspension_VMTL_role = "Suspension_VMTL_DML_PVBU";
	const char*   Tools_VMTL_role = "Tools_Acessories_VMTL_DML_PVBU";
	tag_t	DmlTask_tag		= NULLTAG;
	int     CRBcunt		=  0;
	int     Tskcout		=  0;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	logical is_Tsklatst;
	logical is_Tskletst;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t	TskCRBTag	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	int     im = 0;
	int     No_DMU = 0;
	tag_t   DMUGrp_tag		= NULLTAG;
	tag_t   DMU_Rev			= NULLTAG;
	tag_t   DMU_tag		= NULLTAG;
	tag_t	DMU_Patri_Type	= NULLTAG;
	tag_t*  DMU_t			= NULLTAG;
	tag_t	DMU_Party		= NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char *sDMLrlstype = NULL;
	char	*Task_name		= NULL;
	char *DMLtype = NULL;
	char *VMLTinfo2 = NULL;
	char *VMLTinfo1 = NULL;
	char *DMLProj = NULL;
	char *PlntToPlnt = NULL;
	char *DMLDR = NULL;
	tag_t	queryTag   = NULLTAG;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass = NULL;
	char*	ProjDesc = NULL;
	char*	Proj_PltFrm = NULL;
	tag_t	item_tag		= NULLTAG;
	tag_t	tUserTag		= NULLTAG;
	int b =0;
	int t =0;
	int jtsk =0;
	int jkk =0;
	int     DsgGrup = 0;
	char	*DsgGrp			= NULL;
	char	*VMLTinfo3		= NULL;
	char	*Tsk_class		= NULL;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	objTag		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	char	*TskReviewr		= NULL;
	char   type_name8[TCTYPE_name_size_c+1];
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	projTag		= NULLTAG;
	int     DR_n_entry    = 1;

	char	*groupName		= NULL;
	char*	Proj_BU = NULL;
	int		resultCount = 0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	sDMLrlstype=(char *)MEM_alloc(20);

	printf("\n VMTL:....Inside tm_VMLTReviewerForTaskFun......\n",item_id);fflush(stdout);
	if(ITEM_find_item (item_id, &item_tag)!=ITK_ok)PrintErrorStack();
	//item_tag= t5GetItemRevison(item_id);
	if(item_tag==NULLTAG)
	{
		printf("\n VMTL::item_tag is NULL.\n");fflush(stdout);
		return 0;
	}
	else
	{
		printf("\n VMTL::item_tag found.\n");fflush(stdout);
		if(ITEM_ask_latest_rev (item_tag, &objTag)!=ITK_ok)PrintErrorStack();
		if(objTag==NULLTAG)
		{
			printf("\n VMTL::Object not found in Teamcenter...!!\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n VMTL:Object Found...!!");fflush(stdout);
			if(TCTYPE_ask_object_type(objTag,&objTypTag)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name(objTypTag,ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n VMTL:: Workfow obj type: [%s]", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(QRY_find("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n VMTL::Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n VMTL::Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "VMTLTB";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n VMTL::DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//DML released type to live.
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&VMLTinfo1)!=ITK_ok)   PrintErrorStack();
					//ON OFF set reviewer
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&VMLTinfo2)!=ITK_ok)   PrintErrorStack();
					//Business unit live for
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&VMLTinfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n VMTL::VMLTinfo1: [%s]  VMLTinfo2: [%s] VMLTinfo3:[%s]\n", VMLTinfo1,VMLTinfo2,VMLTinfo3);fflush(stdout);
				}
				if(tc_strstr(VMLTinfo2,"VMTLOFF")==NULL)
				{
					//DML Details:
					if(AOM_ask_value_string(objTag,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_ERCBusiUt",&Proj_BU)!=ITK_ok)PrintErrorStack();
					printf("\n VMTL:: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]  Proj_BU:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR,Proj_BU);fflush(stdout);
					tc_strcpy(sDMLrlstype,"");
					tc_strcpy(sDMLrlstype,",");
					tc_strcat(sDMLrlstype,DMLtype);
					tc_strcat(sDMLrlstype,",");
					printf("\n VMTL:sDMLrlstype: %s",sDMLrlstype);fflush(stdout);
					//Check Point for DML type and Business unit
					if(tc_strstr(VMLTinfo3,Proj_BU) != NULL)
					{
						if(tc_strstr(VMLTinfo1,sDMLrlstype) != NULL)
						{
							if(DMLProj)
							{
								if(QRY_find("Qury_Project", &queryTag));
								printf("\n VMTL::After Prd_Project: QRY_find");fflush(stdout);
								if (queryTag)
								{
									printf("\n VMTL::Found Query");fflush(stdout);
								}
								else
								{
									printf("\n VMTL::Not Found Query");fflush(stdout);
								}

								qry_values[0] = DMLProj;

								if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
								printf("\n VMTL:: resultCount : %d\n", resultCount); fflush(stdout);

								if(resultCount > 0)
								{
									printf("\n VMTL::t5_Project = [%s] found in DB\n",DMLProj);fflush(stdout);
									Project_t = t5_Project[0];
									if (Project_t!=NULLTAG)
									{
										if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
										printf("\n VMTL:: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
										//VMTL group for VMTL logic
										groupName = (char	*)MEM_alloc(100);
										tc_strcpy(groupName,"VMTL_Participants_Group");
										//tc_strcpy(groupName,"DML_Participants_Group");
										printf("\n VMTL:: groupName  --> %s\n",groupName);   fflush(stdout);

										if (PROJ_find(DMLProj,&projTag) !=ITK_ok)PrintErrorStack();
										if(projTag !=NULLTAG)
										{
											Gmcnt1=0;
											Gmcnt2=0;
											Gmcnt3=0;
											GmFound1 =NULLTAG;
											GmFound2 =NULLTAG;
											GmFound3 =NULLTAG;
											printf("\n VMTL::Getting Project Team...\n");fflush(stdout);
											if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
											printf("\n VMTL::Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
										}

										//################# REVIEWERS FOR TASK START #####################/
										printf("\n VMTL::PVBU:TASK:REMOVING VMTL REVIEWERS FOR TASK START......\n");fflush(stdout);
										if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
										if (DmlTask_tag!=NULLTAG)
										{
											if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
											printf("\n VMTL::TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
											for (jkk=0;jkk<Tskcout ;jkk++ )
											{
												if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
												//printf("\n VMTL::.is_Tskletst. %d",is_Tskletst);fflush(stdout);
												if(is_Tskletst != true)
												{
													printf("\n VMTL::TASK:is_Tskletst is not true .....\n");fflush(stdout);
												}
												else
												{
													TskRev_tg = TskRev_tag[jkk];
													if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
													if (Tsk_CRB_rel_type!=NULLTAG)
													{
														if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
														printf("\n VMTL::TASK: count: %d",CRBcunt);fflush(stdout);
														for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
														{
															TskCRBTag = TskCRB[jtsk];
															if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
															if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
															printf("\n VMTL::TASK: Participant Name: %s\n", type_name8);fflush(stdout);

															if (tc_strcmp(type_name8,"ProposedReviewer")==0)
															{
																printf("\n VMTL::TASK: Removing VMTL reviewer:%d",jtsk); fflush(stdout);
																if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
																printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
																AOM_lock(TskRev_tg);
																if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
																AOM_save(TskRev_tg);
																AOM_unlock(TskRev_tg);
															}
														}
													}
												}
											}
											printf("\n VMTL::PVBU:ADDING VMTL REVIEWERS FOR TASK START......\n");fflush(stdout);

											for (t=0;t<Tskcout ;t++ )
											{
												No_DMU=0;
												if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
												//printf("\n VMTL::is_Tsklatst %d",is_Tsklatst);fflush(stdout);

												if(is_Tsklatst != true)
												{
													printf("\n VMTL::is_Tsklatst is not true .....\n");fflush(stdout);
												}
												else
												{
													TskRev_t = TskRev_tag[t];
													if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
													if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
													printf("\n VMTL:: Task class..:%s",Tsk_class); fflush(stdout);
													if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
													{
														//Setting VMTL Reviewers.
														if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
														printf("\n VMTL:: Task Name :[%s]",Task_name);fflush(stdout);
														DsgGrp=subString(Task_name,11,2);
														DsgGrup=(int) atoi(DsgGrp);
														printf(" and design group: [%s]\n",DsgGrp);fflush(stdout);
														//VMTL Reviewer
														printf("\n VMTL::SETTING COC VMTL Reviewer.....: ");fflush(stdout);
														if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
														if(DsgGrup ==1111)
														{
															printf("Test_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Test_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Test_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON1")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"BIW_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL::Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Test_VMTL_role access avail.....\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					//if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					printf("\n VMTL:Test_VMTL_role..1\n");fflush(stdout);
																					//if(EPM_get_participanttype ("T5_BIWReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Test_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																		printf("\n VMTL:Test_VMTL_role set done..\n");fflush(stdout);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
														{
															printf("Brake_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Brake_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Brake_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON2")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Brakes_Controls_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Brake_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Brake_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if ((DsgGrup >=60) && (DsgGrup <=66))
														{
															printf("BIW_VMTL_role.. "); fflush(stdout);
															if(SA_find_role2(BIW_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															printf(" No_DMU:%d \n",No_DMU); fflush(stdout);
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: BIW_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON3")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_BIW_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:BIW_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:BIW_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if ((DsgGrup >=70) && (DsgGrup <=80))
														{
															printf("Door_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Door_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															printf(" No_DMU:%d \n",No_DMU); fflush(stdout);
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Door_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON4")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Door_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Door_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Door_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==88)
														{
															printf("ExtTrims_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(ExtTrims_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: ExtTrims_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON5")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Ext_Trims_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:ExtTrims_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:ExtTrims_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==81)
														{
															printf("Fit_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Fit_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Fit_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON6")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Int_Fittings_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Fit_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Fit_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if ((DsgGrup >=67) && (DsgGrup <=69))
														{
															printf("IntTrims_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(IntTrims_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: IntTrims_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON7")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Int_Trims_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:IntTrims_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:IntTrims_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==55)
														{
															printf("Mascots_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Mascots_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: VMTL:Mascots_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON8")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Mascots_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Mascots_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Mascots_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if ((DsgGrup >=91) && (DsgGrup <=96))
														{
															printf("Seat_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Seat_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Seat_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLON9")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"CAB_Seats_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Seat_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Seat_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==83)
														{
															printf("HVAC_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(HVAC_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: HVAC_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA1")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"HVAC_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:HVAC_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:HVAC_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
														{
															printf("EE_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(EE_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: EE_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA2")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"E&E_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:EE_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:EE_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==49)
														{
															printf("Exhaust_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Exhaust_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Exhaust_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA3")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Exhaust_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Exhaust_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Exhaust_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==31)
														{
															printf("Frame_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Frame_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Frame_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA4")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Frames_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Frame_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Frame_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==47)
														{
															printf("Fuel_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Fuel_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Fuel_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA5")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Fuel_System_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Fuel_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Fuel_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==24)
														{
															printf("Mounts_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Mounts_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Mounts_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA6")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Mounts_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL: Mounts_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Mounts_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==97)
														{
															printf("Restrn_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Restrn_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Restrn_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA7")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Restraints_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Restrn_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Restrn_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==46)
														{
															printf("Steering_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Steering_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Steering_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA8")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Steering_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Steering_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Steering_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if ((DsgGrup ==32)||(DsgGrup ==33)||(DsgGrup ==35)||(DsgGrup ==40)|| (DsgGrup ==41))
														{
															printf("Suspension_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Suspension_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Suspension_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONA9")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Suspension_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Suspension_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Suspension_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else if(DsgGrup ==58)
														{
															printf("Tools_VMTL_role.. \n"); fflush(stdout);
															if(SA_find_role2(Tools_VMTL_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															if(No_DMU>0)
															{
																for(b=0;b<No_DMU;b++)
																{
																	printf("\n VMTL:: Tools_VMTL_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(VMLTinfo2,"VMTLONB1")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(DMU_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n VMTL:: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Tools_Acessories_VMTL_DML_PVBU")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n VMTL:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n VMTL:Tools_VMTL_role access avail...\n");fflush(stdout);
																					if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																					if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_lock(TskRev_t);
																					if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																					AOM_save(TskRev_t);
																					AOM_unlock(TskRev_t);
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n VMTL:Tools_VMTL_role access avail...\n");fflush(stdout);
																		if(EPM_get_participanttype ("ProposedReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(DMU_t[b],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);
																		if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();
																		AOM_save(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
														}
														else
														{
															printf("\n VMTL:::ELSE Other design group.. \n"); fflush(stdout);
														}
													}
												}
											}
										}
									}
								}
							}
							else
							{
								printf("\n VMTL:This DML project is NULL.......");fflush(stdout);
							}
						}
						else
						{
							printf("\n VMTL:This DML type is not live for VMTL review: %s",sDMLrlstype);fflush(stdout);
						}
					}
					else
					{
						printf("\n VMTL:Proj_BU is not live for VMTL review: %s",Proj_BU);fflush(stdout);
					}
				}
				else
				{
					printf("\n VMTL:function tm_VMLTReviewerForTaskFun is OFF.");fflush(stdout);
				}
			}
		}
	}

	printf("\n VMTL:End of function tm_VMLTReviewerForTaskFun.......");fflush(stdout);
	return ifail;
}
;