/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Anup
*  Module               :   Workflow Action Handler For Information.
*  Code                 :   tm_DMLPrintRpt.c
*  Created on			:   23/57/2020
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_dmlinforpt(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int j      =  0;
	int countt	=  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *PrintDMLInfo1		= NULL;
	char *PrintDMLInfo2		= NULL;
	char *command		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t  DMLRevTg = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  *DMLRevision = NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	logical is_latest;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	command=(char *)MEM_alloc(600);
	
	printf("\n tm_dmlinforpt Function started...");fflush(stdout);
	TC_write_syslog("\n tm_dmlinforpt Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_dmlinforpt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n tm_dmlinforpt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if((tc_strcmp(ObjTyp,"ChangeRequestRevision")==0) ||(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0))
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n tm_dmlinforpt:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n tm_dmlinforpt:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "DMLINFO";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n tm_dmlinforpt:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//Path:
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&PrintDMLInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n tm_dmlinforpt:PrintDMLInfo2 is :[%s]\n", PrintDMLInfo2);fflush(stdout);
					if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{					
						if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_dmlinforpt:UAPROD:DML no : %s ", DMlid);fflush(stdout);
						tc_strcpy(command,"");
						tc_strcpy(command,PrintDMLInfo2);
						tc_strcat(command," ");
						tc_strcat(command,DMlid);
						printf("\n tm_dmlinforpt::command: %s",command);fflush(stdout);
						//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
						//sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
						TC_write_syslog("Command = %s\n",command);
						system(command);
					}
					else
					{
						if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
						if (tsk_dml_rel_type!=NULLTAG)
						{
							if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							printf("\n tm_dmlinforpt:DML Revision from Task for : [%d]",countt);fflush(stdout);
							for (j=0;j<countt ;j++ )
							{
								if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
								printf("\n tm_dmlinforpt::is_latest  is : [%d]",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n tm_dmlinforpt::is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									DMLRevTg = DMLRevision[j];
									if(AOM_ask_value_string(DMLRevTg,"item_id",&DMlid)!=ITK_ok)PrintErrorStack();
									printf("\n tm_dmlinforpt::: for DMlid : [%s] ",DMlid);fflush(stdout);
									tc_strcpy(command,"");
									tc_strcpy(command,PrintDMLInfo2);
									tc_strcat(command," ");
									tc_strcat(command,DMlid);
									printf("\n tm_dmlinforpt:::command: %s",command);fflush(stdout);
									//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
									//sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/dmlprintprt.sh %s ",DMlid);
									TC_write_syslog("Command : %s\n",command);
									system(command);
								}
							}
						}
					}
				}
				break;
			}
		}
	}
	printf("\n tm_dmlinforpt Function end...");fflush(stdout);
	TC_write_syslog("\n tm_dmlinforpt Function end...");
	//return error_code;
	return 0;
}