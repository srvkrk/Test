//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_AutoPPPMPrjCodeLovBOImpl
//

#ifndef TRL001__T5_AUTOPPPMPRJCODELOVBOIMPL_HXX
#define TRL001__T5_AUTOPPPMPRJCODELOVBOIMPL_HXX

#include <T5_RFISORCODEFL/T5_AutoPPPMPrjCodeLovBOGenImpl.hxx>
#include <common/tc_deprecation_macros.h>

#include <T5_RFISORCODEFL/libt5_rfisorcodefl_exports.h>


namespace TRL001
{
    class T5_AutoPPPMPrjCodeLovBOImpl; 
    class T5_AutoPPPMPrjCodeLovBODelegate;
}

class  T5_RFISORCODEFL_API TRL001::T5_AutoPPPMPrjCodeLovBOImpl
    : public TRL001::T5_AutoPPPMPrjCodeLovBOGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @version Teamcenter 10
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_AutoPPPMPrjCodeLovBO
    explicit T5_AutoPPPMPrjCodeLovBOImpl( T5_AutoPPPMPrjCodeLovBO& busObj );

    ///
    /// Destructor
    virtual ~T5_AutoPPPMPrjCodeLovBOImpl();

private:
    ///
    /// Default Constructor for the class
    T5_AutoPPPMPrjCodeLovBOImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_AutoPPPMPrjCodeLovBOImpl( const T5_AutoPPPMPrjCodeLovBOImpl& );

    ///
    /// Copy constructor
    T5_AutoPPPMPrjCodeLovBOImpl& operator=( const T5_AutoPPPMPrjCodeLovBOImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_AutoPPPMPrjCodeLovBODelegate;

};

#include <T5_RFISORCODEFL/libt5_rfisorcodefl_undef.h>
#endif // TRL001__T5_AUTOPPPMPRJCODELOVBOIMPL_HXX
