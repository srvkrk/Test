/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler PO Check and attach NOPO report to DML as xls.
*  Code                 :   tm_POChkStopAtF.c
*  Created on			:   12/04/2019
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		12/04/2019				Mohan Tayade		Workflow Action Handler PO Check and attach NOPO report to DML as xls.
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_POChkStopAtF(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int iii    =  0;
	int i      =  0;
	int task_count	=  0;
	int Col1_count	=  0;
	int part_count	=  0;
	int Item_count	=  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *task_id		= NULL;
	char *GMDPOcommand		= NULL;
	char *PathInfo7		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp	= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t window =NULLTAG;
	tag_t window_prev =NULLTAG;
	tag_t dml_task_rel	= NULLTAG;
	tag_t *task_tag = NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	GMDPOcommand=(char *)MEM_alloc(600);
	printf("\n tm_POChkStopAtF Function started...");fflush(stdout);
	TC_write_syslog("\n tm_POChkStopAtF Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n POCHCK:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n POCHCK:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "POCHCK";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n POCHCK:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&PathInfo7)!=ITK_ok)   PrintErrorStack();
					printf("\n PathInfo7 is :[%s]\n", PathInfo7);fflush(stdout);
					if(strstr(POinfo3,"MAINPOCHECKOFF")==NULL)
					{
						if(strstr(POinfo3,"MAINPOCHECKUAPROD")==NULL)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel)!=ITK_ok)PrintErrorStack();
							if(GRM_list_secondary_objects_only(taskAttachments[i], dml_task_rel, &task_count, &task_tag)!=ITK_ok)PrintErrorStack();
							for(iii=0;iii<task_count;iii++)
							{
								if(AOM_UIF_ask_value(task_tag[0], "item_id", &task_id));
								printf("\n UAPROD:Task name: %s ", task_id);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/pocheck.sh %s ",task_id);
								sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/pocheck.sh %s ",task_id);
								TC_write_syslog("Command = %s\n",command);
								system(command);
								break;
							}
						}
						else if(strstr(POinfo3,"MAINPOCHECKCVPROD")==NULL)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel)!=ITK_ok)PrintErrorStack();
							if(GRM_list_secondary_objects_only(taskAttachments[i], dml_task_rel, &task_count, &task_tag)!=ITK_ok)PrintErrorStack();
							for(iii=0;iii<task_count;iii++)
							{
								if(AOM_UIF_ask_value(task_tag[0], "item_id", &task_id));
								printf("\n CVPROD:Task name: %s ", task_id);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/pocheck.sh %s ",task_id);
								sprintf(command,"/user/cvprod/shells/DML_DCR/pocheck.sh %s ",task_id);
								TC_write_syslog("Command = %s\n",command);
								system(command);
								break;
							}
						}
						else if(strstr(POinfo3,"MAINPOCHECKCMITEST")==NULL)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel)!=ITK_ok)PrintErrorStack();
							if(GRM_list_secondary_objects_only(taskAttachments[i], dml_task_rel, &task_count, &task_tag)!=ITK_ok)PrintErrorStack();
							for(iii=0;iii<task_count;iii++)
							{
								if(AOM_UIF_ask_value(task_tag[0], "item_id", &task_id));
								printf("\n CMITEST: Task name: %s ", task_id);fflush(stdout);
								sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/pocheck.sh %s ",task_id);
								TC_write_syslog("Command = %s\n",command);
								system(command);
								break;
							}
						}
						else if(strstr(POinfo3,"MAINPOCHECKUADEV")==NULL)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel)!=ITK_ok)PrintErrorStack();
							if(GRM_list_secondary_objects_only(taskAttachments[i], dml_task_rel, &task_count, &task_tag)!=ITK_ok)PrintErrorStack();
							for(iii=0;iii<task_count;iii++)
							{
								if(AOM_UIF_ask_value(task_tag[0], "item_id", &task_id));
								printf("\n UADEV:Task name: %s ", task_id);fflush(stdout);
								sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/pocheck.sh %s ",task_id);
								TC_write_syslog("Command = %s\n",command);
								system(command);
								break;
							}
						}
						else
						{
							printf("\n POCHCK:Other client.. \n");fflush(stdout);
						}
					}
					else if(strstr(POinfo3,"GMDPOPATH")==NULL)
					{
						if(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(taskAttachments[i], dml_task_rel, &task_count, &task_tag)!=ITK_ok)PrintErrorStack();
						for(iii=0;iii<task_count;iii++)
						{
							if(AOM_UIF_ask_value(task_tag[0], "item_id", &task_id));
							printf("\n UADEV:Task name: %s ", task_id);fflush(stdout);
							tc_strcpy(GMDPOcommand,"");
							tc_strcpy(GMDPOcommand,PathInfo7);
							tc_strcat(GMDPOcommand," ");
							tc_strcat(GMDPOcommand,task_id);
							printf("\n GMD EXP::GMDPOcommand: %s",GMDPOcommand);fflush(stdout);
							TC_write_syslog("GMDPOcommand = %s\n",GMDPOcommand);
							system(GMDPOcommand);
							break;
						}
					}
				}
			}
		}
	}
    printf("\n tm_POChkStopAtF Function end...");fflush(stdout);
	TC_write_syslog("\n tm_POChkStopAtF Function end...");
	//return error_code;
	return 0;
}