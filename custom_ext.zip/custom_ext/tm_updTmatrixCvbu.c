
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_updTmatrixCvbu.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for update Tmatrix logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 23/03/2023   	Sanjoy Mondal			    Initial Code
* 26/02/2025   	Sanjoy Mondal			    change as per Teamcenter 14.3
* 28/03/2025	Sanjoy Mondal				Implement CR-FY25-0122-T-matrix upd for Engine module.
* -----------------------------------------------------------------------------
*
*****************************************************************************/				

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128


#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <property/idgeneration.h>
#include <Fnd0Participant/participant.h>
#include <tccore/item_msg.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 402)
#define T5_WorkFlowHandlerErr2 (EMH_USER_error_base + 403)
#define T5_WorkFlowHandlerESOErr (EMH_USER_error_base + 701)
#define T5_WorkFlowHandlerAnxErr (EMH_USER_error_base + 702)
#define MAX_LINE_LEN 10024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

/*******************************************START OF UTILITY FUNCTIONS**************************************************/

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int getItemRevObjectTmatrix(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	//printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	if(QRY_find2("Item Revision...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}





/*********************************End of Utility function ***********************************/



int isLiveForTmatrixUpdation(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatrixUpd";
	qry_values[1] = "TmatrixUpd";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nTmatrix:Control objects TmatrixUpd: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{			
			//printf("\nTmatrix: Live for TmatrixUpd\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}

int isLiveForTmatrixUpdDigView(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TMatUpdDigVw";
	qry_values[1] = "TMatUpdDigVw";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nTmatrix:Control objects TmatrixUpd: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{			
			//printf("\nTmatrix: Live for TmatrixUpd\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}


int getTmatrixGenericControlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatGenCtrlForCC";
	qry_values[1] = "TmatGenCtrlForCC";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nTmatrix:Control objects TmatrixUpd: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		if(cntrlObj!=NULLTAG)
		{			
		
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}

typedef struct ArchNodeDet_
{
	char archNodeID[50];
	char** moduleIDList;
	int moduleCnt;
	char** tMatrixList;
}ArchNodeDet;

void setAddArchNodeDet(int *count,ArchNodeDet **objlist,ArchNodeDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (ArchNodeDet *)malloc((*count ) * sizeof(ArchNodeDet ));
	}
	else
	{
		(*objlist) = (ArchNodeDet *)realloc((*objlist),(*count) * sizeof(ArchNodeDet ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindArchNodeInArchNodeSet(ArchNodeDet *archnode_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(archnode_list[k].archNodeID,str)==0)
		{
			*found=1;
			break;
		}

	}
}



int updateTranMatrixNew(tag_t arcModRevTag, ArchNodeDet archNodeDetail,int *arcNodeListCnt,ArchNodeDet **arcNodeList)
{
	int ifail = ITK_ok;
	tag_t archModuleItemTag = NULLTAG;
	int bv_count = 0;
	tag_t* bvs = NULL;
	tag_t bv = NULLTAG;
	int bvr_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	char* arch_modl_id = NULL;
	
	
	
	printf("\nupdateTranMatrixNew:Start of ...... update T Matrix.................\n");fflush(stdout);
	
	if(AOM_ask_value_string(arcModRevTag, "item_id", &arch_modl_id));
	if(ITEM_ask_item_of_rev(arcModRevTag, &archModuleItemTag));
	if(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	//printf("\nupdateTranMatrixNew: [%s] BV Count: %d\n",arch_modl_id, bv_count);fflush(stdout);
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}	
	if(ITEM_rev_list_bom_view_revs(arcModRevTag,&bvr_count, &bvrs));	
	//printf("\nupdateTranMatrixNew: [%s] BVR Count: %d\n",arch_modl_id,bvr_count);fflush(stdout);				
	if(bvr_count)
	{
		bvr = bvrs[0];
		MEM_free(bvrs);
			
	}
	else
	{
		//printf("\nupdateTranMatrixNew No BVR Found.. Exiting....\n");
		return ifail;
	}	

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}		
	if(bvr==NULLTAG)
	{
		return ifail;
	}
	
	/**************Expand Arch Node Rev to get the child *************************/
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t line = NULLTAG;	
	int count =0;
	tag_t* child = NULL;
	int i = 0;
	int flag = 0;
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window(&window));
	if(CFM_find( "Latest Working", &rule ));
	if(BOM_set_window_config_rule(window,rule ));
	if(BOM_set_window_pack_all(window, false));
	if(BOM_set_window_top_line(window, NULLTAG,arcModRevTag,NULLTAG, &line));
	if(BOM_set_window_top_line_bvr(window,bvr,&line));		
	if(BOM_line_ask_all_child_lines(line,&count,&child));
	//printf("\nupdateTranMatrixNew: Child count::::::::>>>>>>>> %d\n",count);
	
	int ChildUIDListCnt = 0;
	char** ChildUIDList = NULL;
	
	int updtedChildListCnt = 0;
	char** updtedChildList = NULL;


	int n =0;
	
	for(n=0; n<archNodeDetail.moduleCnt;n++)
	{
		//int xform_matrixId = 0;
		char*xform_matrix_str = NULL;
		char * moduleid = NULL;
				
		//printf(" Arch Node:[%s], Module ID[%s], T-Matrix [%s]\n",archNodeDetail.archNodeID, archNodeDetail.moduleIDList[n], archNodeDetail.tMatrixList[n]);fflush(stdout);
		
		moduleid = archNodeDetail.moduleIDList[n];
		
		for (i = 0; i<count; i++)
		{
			tag_t child_line = NULLTAG;
			//int uidType = 0;
			char* ChildUID = NULL;
			char* chldid = NULL;
			char* chldrevid = NULL;


			child_line = child[i];

			ifail = AOM_ask_value_string(child_line, "bl_item_item_id", &chldid);
			ifail = AOM_ask_value_string(child_line, "bl_rev_item_revision_id", &chldrevid);		

			//ifail =  BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType);
			//ifail = BOM_line_ask_attribute_string(child_line, uidType, &ChildUID);
			ifail = AOM_ask_value_string(child_line,"bl_occurrence_uid",&ChildUID);
			//printf("\n Child Module: [%s;%s], ChildUID[%s] ",chldid,chldrevid,ChildUID);fflush(stdout);	
			
			if(tc_strcmp(chldid,moduleid)==0)				
			{
				//printf("Going to update T Matrix of this module[%s]\n", archNodeDetail.moduleIDList[n]);fflush(stdout);
				int found =0;
				t5FindStrInSet(ChildUIDList,ChildUIDListCnt,ChildUID,&found);
				//printf("\nAlready updated?.  %s found in the list [%d]\n",ChildUID,found);fflush(stdout);
				if(found ==0)
				{
					//if ( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrixId));
					//printf("\n***********xform_matrixId:%d\n",xform_matrixId);
					//if(BOM_line_ask_attribute_string(child_line, xform_matrixId, &xform_matrix_str));
					ifail = AOM_ask_value_string(child_line,"bl_plmxml_abs_xform",&xform_matrix_str);
					//printf( " child xform_matrix_str--------------> %s\n",xform_matrix_str);fflush(stdout);	

					if(xform_matrix_str == NULL) xform_matrix_str ="";

						
					//if(BOM_line_set_attribute_string(child_line,xform_matrixId,archNodeDetail.tMatrixList[n]));
					ifail = AOM_set_value_string(child_line,"bl_plmxml_abs_xform",archNodeDetail.tMatrixList[n]);
					t5AddStrToSet(&ChildUIDListCnt, &ChildUIDList,ChildUID);
					t5AddStrToSet(&updtedChildListCnt, &updtedChildList,moduleid);

					flag++;
					break;
					
				}
				
	
				
				
			}
			
			
		}
		

	}
	
	

	
	printf("\n ChildUIDListCnt:[%d], updtedChildListCnt[%d]\n",ChildUIDListCnt,updtedChildListCnt);fflush(stdout);
	
	int m =0;
	char* partId = NULL;
	char* partTmatrix = NULL;
	int found1 = 0;
	int modIDListCnt = 0;
	char** modIDList = NULL;
	int modtMatrixListCnt = 0;
	char** modtMatrixList = NULL;
	for(m=0;m<archNodeDetail.moduleCnt;m++)
	{
		found1 =0;
		partId = archNodeDetail.moduleIDList[m];
		partTmatrix = archNodeDetail.tMatrixList[m];
		
		t5FindStrInSet(updtedChildList,updtedChildListCnt,partId,&found1);
		
		if(found1 ==0)
		{
			//printf("\n The part[%s] is not updated \n",partId);fflush(stdout);
			t5AddStrToSet(&modIDListCnt, &modIDList,partId);
			t5AddStrToSet(&modtMatrixListCnt, &modtMatrixList,partTmatrix);
			
			
		}
		
		
	}
	
	ArchNodeDet archDet;
	tc_strcpy(archDet.archNodeID,arch_modl_id);
	archDet.moduleIDList = modIDList;
	archDet.moduleCnt = modIDListCnt;
	archDet.tMatrixList = modtMatrixList;

	setAddArchNodeDet(arcNodeListCnt, arcNodeList,archDet);	
	
	
	if(flag> 0) if(BOM_save_window(window));
	if(BOM_close_window(window));
	printf("\nupdateTranMatrixNew:End of ...... update T Matrix.................\n");fflush(stdout);
	return ifail;
}


int getScaledValue(char *inpStr, char **outStr)
{
	int ifail = ITK_ok;
	
	char* tMatrixStr = (char*)MEM_alloc(100*sizeof(char));
	char* tMatrixStrDup = NULL;//(char*)MEM_alloc(100*sizeof(char));
	
	char* tmat1 = (char*)MEM_alloc(50*sizeof(char));
	*outStr = (char*)MEM_alloc(300*sizeof(char));
	char* tok1 = NULL;
	char* tok2 = NULL;
	int len1 = 0;
	
	tc_strcpy(tMatrixStr,inpStr);
	
	//printf("\n tMatrixStr:[%s]\n",tMatrixStr);fflush(stdout);
	
	tc_strdup(tMatrixStr, &tMatrixStrDup);
	
	
	len1 = tc_strlen(tMatrixStr);
	//printf("\n Length of the input T Matrix value : [%d]\n", len1);fflush(stdout);
	
	/*If first character is .*/
	int flag1 = 0;
	char ch = '\0';
	ch = tMatrixStr[0];
	
	if(ch == '.')
	{
		flag1++;
	}
	
	/* Get the tokens */
	tok1 = tc_strtok(tMatrixStr,".");
	tok2 = tc_strtok(NULL,".");
	//printf("\n tok1[%s], tok2[%s]\n",tok1,tok2);fflush(stdout);
	
	

	//printf("\n flag1 ==> %d\n", flag1);fflush(stdout);
	if(flag1 > 0)
	{
		tc_strcpy(tmat1,"0.000");
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
		
		//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
		if(tMatrixStr!=NULL) MEM_free(tMatrixStr);
		if(tMatrixStrDup!=NULL)free(tMatrixStrDup);
		if(tMatrixStr!=NULL)MEM_free(tmat1);
		return ifail;
	}
	
	/*If first character is -.*/
	int flag2 = 0;
	char ch1 = '\0';
	
	//printf("\n 111Length of the input T Matrix value : [%d]\n", tc_strlen(tMatrixStrDup));fflush(stdout);
	if(tc_strlen(tMatrixStrDup) >=2)
	{
		ch  = tMatrixStrDup[0];
		ch1 = tMatrixStrDup[1];
		
		if(ch == '-' && ch1 =='.')
		{
			flag2 ++;
		}
		
	}
	
	//printf("\n flag2 ==> %d\n", flag2);fflush(stdout);
	if(flag2 > 0)
	{
		tc_strcpy(tmat1,"-0.000");
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
		
		//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
		if(tMatrixStr!=NULL) MEM_free(tMatrixStr);
		if(tMatrixStrDup!=NULL)free(tMatrixStrDup);
		if(tMatrixStr!=NULL)MEM_free(tmat1);
		return ifail;
	}
	
	
	/********************Other Logic **************************/
	
	int flag = 0;
	int len = 0;
	int k = 0;
	int j = 0;
	int cnt = 0;
	char * tok1Dup = NULL;
	
	//tok1Dup = (char*)MEM_alloc(50*sizeof(char));
	tc_strdup(tok1,&tok1Dup);
	
	if(tok1[0] == '-')
	{
		//printf("\n -ve number \n");fflush(stdout);
		flag++;
			
	}
	
	//printf("\ntok1Dup ==. [%s]\n",tok1Dup);fflush(stdout);
	
	//replace the -ve from tok1
	if(flag > 0 )
	{
		int len1 = 0;
		len1 = tc_strlen(tok1Dup);
		
		ifail = STRNG_replace_str(tok1Dup,"-","",&tok1);
		//printf("\n tok1 ==> [%s]",tok1);fflush(stdout);
	}
	
	len = tc_strlen(tok1);
	//printf("\nLength of first token: [%d]\n",len);fflush(stdout);
	
	if(len > 3)
	{
		k = len;
	}
	else if(len ==3)
	{
		k = len + 1;
	}
	else if(len == 2)
	{
		k = len + 2;
	}
	else if(len == 1)
	{
		k = len + 3;
	}
	
	
	
	//printf("\n Initial k ==> [%d]\n",k);fflush(stdout);
	
	//76543
	for(j=len-1;j>=0;j--)
	{

		if(len > 3)
		{
			if(cnt==3)
			{
				*(tmat1 + k)= '.';
				j++;
			}
			else
			{
				*(tmat1 + k) = tok1[j];
			}
			k--;
			cnt++;
		}
		else
		{

			*(tmat1 + k ) = tok1[j];
			k--;
		}
	
	
	}
	

	if(len == 3)
	{
		*(tmat1 + k) = '.';
		*(tmat1 + k - 1) = '0';
		*(tmat1 + len + 2)='\0';
	}
	else if(len == 2)
	{
		*(tmat1 + k) = '0';
		*(tmat1 + k - 1) = '.';
		*(tmat1 + k - 2) = '0';
		*(tmat1 + len + 3)='\0';					
	}
	else if(len == 1)
	{
		*(tmat1 + k) = '0';
		*(tmat1 + k - 1) = '0';
		*(tmat1 + k - 2) = '.';
		*(tmat1 + k - 3) = '0';
		*(tmat1 + len + 4)='\0';			
	}
	
	//printf("\ntmat1[%s]\n",tmat1);fflush(stdout);
	if(flag == 0)
	{		
		tc_strcpy(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
	}
	else
	{
		tc_strcpy(*outStr,"-");
		tc_strcat(*outStr,tmat1);
		tc_strcat(*outStr,tok2);
	}

		
	//printf("\n outStr : [%s]\n",*outStr);fflush(stdout);
		
	if(tok1Dup!=NULL) free(tok1Dup);
	if(tMatrixStrDup!=NULL) free(tMatrixStrDup);
	if(tMatrixStr!=NULL)MEM_free(tMatrixStr);	
	if(tmat1!=NULL)MEM_free(tmat1);
	
	return ifail;

}

int getAbbvrPlatformNo(char* platformID, char** abvrPlatID)
{
	int ifail = ITK_ok;
	
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	*abvrPlatID = platformID;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatrixPlatformID";
	qry_values[1] = platformID;
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nTmatrix:Control objects TmatrixPlatformID: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* userInfo1 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{			
			ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
			
			//printf("\nplatformID - userInfo1[%s] - [%s]\n",platformID, userInfo1);fflush(stdout);
			*abvrPlatID = userInfo1;					
		}
		
	}	
	
	
	return ifail;
}


int tmUpdateTmatrixFromCSVServ(void *retValue)
{
	printf("\nT-matrix:Update T-Matrux Service:Start----tmUpdateTmatrixFromCSVServ....\n");fflush(stdout);
	const char	*prog_name 	="tmUpdateTmatrixFromCSVServ";	
	int ifail = ITK_ok;
	tag_t inpFileDS = NULLTAG;
	char* platformID = NULL;
	char* platformID1 = NULL;
	char* dsName = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&inpFileDS);
	USERARG_get_string_argument(&dsName);
	USERARG_get_string_argument(&platformID1);
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	ifail = getAbbvrPlatformNo(platformID1, &platformID);
	printf("\nPlatform:[%s - %s], dataset_name[%s]\n",platformID1, platformID,dsName);fflush(stdout);
	if(inpFileDS !=NULLTAG && tc_strlen(dsName)> 0 && tc_strlen(platformID)> 0)
	{
		
		//printf("\nGot the Dataset.... Platform:[%s], dataset_name[%s]\n",platformID,dsName);fflush(stdout);
		
		isLiveForTmatrixUpdation(&cntrlObj,&liveFlag);
		if(liveFlag && cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			//printf("\n TmatrixUpd-TmatrixUpd Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
			{
				char* sysCmnd = NULL;
				//execute client logic.
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,userInfo2);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,platformID);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,dsName);				
				printf("\n Start-- Calling shell file tm_UpdateTmatrixCvbuFromCSV.sh using client system command: %s\n",sysCmnd);fflush(stdout);
				system(sysCmnd);

				printf("\n End --- Calling shell file tm_UpdateTmatrixCvbuFromCSV.sh using client system command: %s\n",sysCmnd);fflush(stdout);

				MEM_free(sysCmnd);
				tc_strcpy(resultStr,"LIVECLIENT");
			}
			else
			{
				//implement in ITK code.
				printf("\nImplement in ITK...\n");fflush(stdout);
				
				char* ds_object_type = NULL;
				char  *refname = NULL;
				AE_reference_type_t     reftype;
				tag_t	refobject = NULLTAG;
				char* orig_name = NULL;
				char *fileLoc = NULL;
				
				//Read the DataSet object and copy the file in /tmp folder.
				ifail = AOM_ask_value_string(inpFileDS,"object_type",&ds_object_type);
				printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
				
				if(tc_strcmp(ds_object_type,"Text")==0)
				{
					ifail = AE_find_dataset_named_ref2(inpFileDS,0,&refname, &reftype,&refobject);
					if(refobject != NULLTAG)
					{
						ifail = IMF_ask_original_file_name2(refobject , &orig_name);
						
						fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
						tc_strcpy(fileLoc,"/tmp/");
						tc_strcat(fileLoc,orig_name);
						printf("\n FileLoc: %s", fileLoc);fflush(stdout);
						remove( fileLoc );
						
						ifail = IMF_export_file( refobject , fileLoc );
						FILE * fp=NULL;
											 
						fp = fopen(fileLoc, "r");
						
						int x =0;
						char buffer[MAX_LINE_LEN] ="";
						char* moduleId = NULL;
						
						char* vcNo = NULL;
						char* vcRev = NULL;
						char* vcSeq = NULL;
						char* tmp = NULL;
						char* tMatrixStr = NULL;						
						char* tMatrixStr1 = NULL;
						char* tMatrixStr2 = NULL;
						char* tMatrixStr3 = NULL;
						char* tMatrixStr4 = NULL;
						char* tMatrixStr5 = NULL;
						char* tMatrixStr6 = NULL;
						char* tMatrixStr7 = NULL;
						char* tMatrixStr8 = NULL;
						char* tMatrixStr9 = NULL;
						char* tMatrixStr10 = NULL;
						char* tMatrixStr11 = NULL;
						char* tMatrixStr12 = NULL;
						char* tMatrixStr13 = NULL;
						char* tMatrixStr14 = NULL;
						char* tMatrixStr15 = NULL;
						char* tMatrixStr16 = NULL;
						
						char* tMatrixStr13s = NULL;
						char* tMatrixStr14s = NULL;
						char* tMatrixStr15s = NULL;						

						char** archModuleList = NULL;
						int archModuleCnt = 0;						
						char** moduleIdList = NULL;
						int moduleIdCnt = 0;						
						char** moduleTrnList = NULL;
						int moduleTrnCnt = 0;
						
						char * archModuleID = NULL;
						char * moduleAddr = NULL;
						while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
						{
							vcNo = strtok(buffer,",");
							vcRev = strtok(NULL,",");
							vcSeq = strtok(NULL,",");
							moduleId = strtok(NULL,",");
							archModuleID = (char*)MEM_alloc(50*sizeof(char));
							if(tc_strlen(moduleId)==14)
							{
								
								moduleAddr = subString(moduleId,4,5);
								tc_strcpy(archModuleID,"");
								tc_strcat(archModuleID,platformID);
								tc_strcat(archModuleID,"M");
								tc_strcat(archModuleID,moduleAddr);
								
								
							}
							else
							{
								//printf("\nInvalid Module ID [%s]. Skip\n",moduleId);fflush(stdout);
								MEM_free(archModuleID);
								continue;
							}
							
							
							//printf("\nModule ID[%s], Architecture Module ID : [%s]",moduleId,archModuleID);fflush(stdout);
							
							tmp = strtok(NULL,",");
							tmp = strtok(NULL,",");
							tmp = strtok(NULL,",");
							tMatrixStr1 = strtok(NULL,",");
							tMatrixStr2 = strtok(NULL,",");
							tMatrixStr3 = strtok(NULL,",");
							tMatrixStr4 = strtok(NULL,",");
							tMatrixStr5 = strtok(NULL,",");
							tMatrixStr6 = strtok(NULL,",");
							tMatrixStr7 = strtok(NULL,",");
							tMatrixStr8 = strtok(NULL,",");
							tMatrixStr9 = strtok(NULL,",");
							tMatrixStr10 = strtok(NULL,",");
							tMatrixStr11 = strtok(NULL,",");
							tMatrixStr12 = strtok(NULL,",");
							tMatrixStr13 = strtok(NULL,",");
							tMatrixStr14 = strtok(NULL,",");
							tMatrixStr15 = strtok(NULL,",");
							

							ifail = getScaledValue(tMatrixStr13, &tMatrixStr13s);
							ifail = getScaledValue(tMatrixStr14, &tMatrixStr14s);
							ifail = getScaledValue(tMatrixStr15, &tMatrixStr15s);
							

							
							printf("\n tMatrixStr13: [%s],  tMatrixStr13s: [%s]",tMatrixStr13,tMatrixStr13s);fflush(stdout);
							printf("\n tMatrixStr14: [%s],  tMatrixStr14s: [%s]",tMatrixStr14,tMatrixStr14s);fflush(stdout);
							printf("\n tMatrixStr15: [%s],  tMatrixStr15s: [%s]",tMatrixStr15,tMatrixStr15s);fflush(stdout);							
							
							tMatrixStr16 = strtok(NULL,",");
							
							
							
							tMatrixStr = (char*) MEM_alloc(1000*sizeof(char));
							
							tc_strcpy(tMatrixStr,"");
							tc_strcat(tMatrixStr,tMatrixStr1);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr2);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr3);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr4);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr5);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr6);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr7);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr8);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr9);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr10);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr11);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr12);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr13s);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr14s);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr15s);
							tc_strcat(tMatrixStr," ");
							tc_strcat(tMatrixStr,tMatrixStr16);
							
							MEM_free(tMatrixStr13s);
							MEM_free(tMatrixStr14s);
							MEM_free(tMatrixStr15s);
							//printf("\n[%d]. Architecture Node[%s], Module No[%s], TMatrix[%s]", ++x, archModuleID,moduleId, tMatrixStr);fflush(stdout);
							
							t5AddStrToSet(&archModuleCnt, &archModuleList,archModuleID);
							t5AddStrToSet(&moduleIdCnt, &moduleIdList,moduleId);
							t5AddStrToSet(&moduleTrnCnt, &moduleTrnList,tMatrixStr);
								
														
							MEM_free(tMatrixStr);
							MEM_free(archModuleID);
							

							
						}
						
						if(fp!=NULL)
						{
							fclose(fp); 
						}						
						
						 MEM_free(fileLoc);
						 
						 
						 //Update the T-Matrix logic
						 printf("\n archModuleCnt[%d] moduleIdCnt[%d] moduleTrnCnt[%d]\n",archModuleCnt,moduleIdCnt,moduleTrnCnt);fflush(stdout);
						 

						//Build the Data structure.
						int i = 0;
						int j = 0;
						int found = 0;
						char** archNodeIDList = NULL;
						int archNodeIDListCnt = 0;

						ArchNodeDet * arcNodeList;
						int arcNodeListCnt =0;						
						
						for(i=0;i<archModuleCnt;i++)
						{
							char* archId = NULL;
							char** modIDList = NULL;
							int modIDListCnt = 0;
							char** modtMatrixList = NULL;
							int modtMatrixListCnt = 0;							
							
							archId = archModuleList[i];
							found = 0;
							
							t5FindStrInSet(archNodeIDList,archNodeIDListCnt,archId,&found);
							
							if(found == 0)
							{
								ArchNodeDet archDet;
								
								for(j=0;j<archModuleCnt;j++)
								{
									if(tc_strcmp(archId,archModuleList[j])==0)
									{
										t5AddStrToSet(&modIDListCnt, &modIDList,moduleIdList[j]);
										t5AddStrToSet(&modtMatrixListCnt, &modtMatrixList,moduleTrnList[j]);
									}
								}
								
								tc_strcpy(archDet.archNodeID,archId);
								archDet.moduleIDList = modIDList;
								archDet.moduleCnt = modIDListCnt;
								archDet.tMatrixList = modtMatrixList;
								
								setAddArchNodeDet(&arcNodeListCnt, &arcNodeList,archDet);
								//printf("\n modIDListCnt ==> %d\n",modIDListCnt);fflush(stdout);	
								
							}
							t5AddStrToSet(&archNodeIDListCnt, &archNodeIDList,archId);
							
						}
						
						printf("\n arcNodeListCnt ==> %d\n", arcNodeListCnt);fflush(stdout);
						
						int m =0;
						int n = 0;
						ArchNodeDet* ExcpArchNodeDetailList;
						int ExcpArchNodeDetailListCnt = 0;						
						for(m =0; m< arcNodeListCnt; m++)
						{
							ArchNodeDet archNodeDetail;
							tag_t ArchNodeRevTag = NULLTAG;
							
							archNodeDetail = arcNodeList[m];
							
							//printf("\n%d. [%s]", m+1, archNodeDetail.archNodeID);fflush(stdout);
							
							for(n =0; n < archNodeDetail.moduleCnt ;n++)
							{
								//printf("\n Module ID[%s;], TMatrix [%s]",archNodeDetail.moduleIDList[n], archNodeDetail.tMatrixList[n]);fflush(stdout);
								
								
							}
							
							ifail = getItemRevObjectTmatrix(archNodeDetail.archNodeID, "T5_ArchModuleRevision", &ArchNodeRevTag);
							
							if(ArchNodeRevTag != NULLTAG && archNodeDetail.moduleCnt >0)
							{
								//ifail = updateTranMatrix(ArchNodeRevTag,archNodeDetail);
								
								ifail = updateTranMatrixNew(ArchNodeRevTag,archNodeDetail,&ExcpArchNodeDetailListCnt, &ExcpArchNodeDetailList);
								
							}
							else
							{
								setAddArchNodeDet(&ExcpArchNodeDetailListCnt, &ExcpArchNodeDetailList,archNodeDetail);
							}
														

							
						}
						
						
						printf("\n For Below Architecture Module, T Matrix Not updated....[%d]\n",ExcpArchNodeDetailListCnt);fflush(stdout);
						int k = 0;
						int l =0;
						for(k=0;k<ExcpArchNodeDetailListCnt;k++)
						{
							for(l =0; l < ExcpArchNodeDetailList[k].moduleCnt ;l++)
							{
								printf("%s,%s,%s,\n",ExcpArchNodeDetailList[k].archNodeID,ExcpArchNodeDetailList[k].moduleIDList[l],ExcpArchNodeDetailList[k].tMatrixList[l]);fflush(stdout);
							}
							
						}
						
						if(arcNodeListCnt == 0)
						{
							tc_strcpy(resultStr,"INVALID");
						}
						
						
						 
					}//End of ITK logic
					else
					{
						printf("\n NULLTAG refobject...\n");fflush(stdout);
						tc_strcpy(resultStr,"INVALID");
					}
				}
				else
				{
					printf("\nDataset Object Type is not Text. Please check...\n");fflush(stdout);
					tc_strcpy(resultStr,"INVALID");
				}
				
				
			}

			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nTmatrix: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nT-Matrux - After returning Value\n");fflush(stdout);	

	printf("\nT-matrix:Update T-Matrux Service:End----tmUpdateTmatrixFromCSVServ....\n");fflush(stdout);
	return ifail;	
	
}



//For Stand Alone vehicle
int updateTMatrixOfVeh(tag_t vehRevTag, int moduleIdCnt, char** moduleIDList, int moduleTrnCnt, char** tMatrixList)
{
	int ifail = ITK_ok;
	tag_t vehItemTag = NULLTAG;
	int bv_count = 0;
	tag_t* bvs = NULL;
	tag_t bv = NULLTAG;
	int bvr_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	char* veh_id = NULL;
	
	
	
	printf("\nupdateTMatrixOfVeh:Start of ...... update T Matrix.................\n");fflush(stdout);
	
	if(AOM_ask_value_string(vehRevTag, "item_id", &veh_id));
	if(ITEM_ask_item_of_rev(vehRevTag, &vehItemTag));
	if(ITEM_list_bom_views(vehItemTag, &bv_count, &bvs ));
	printf("\nupdateTMatrixOfVeh: [%s] BV Count: %d\n",veh_id, bv_count);fflush(stdout);
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}	
	if(ITEM_rev_list_bom_view_revs(vehRevTag,&bvr_count, &bvrs));	
	printf("\nupdateTMatrixOfVeh: [%s] BVR Count: %d\n",veh_id,bvr_count);fflush(stdout);				
	if(bvr_count)
	{
		bvr = bvrs[0];
		MEM_free(bvrs);
			
	}
	else
	{
		printf("\nupdateTMatrixOfVeh No BVR Found.. Exiting....\n");
		return ifail;
	}	

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}		
	if(bvr==NULLTAG)
	{
		return ifail;
	}
	
	/**************Expand Vehicle Rev to get the child *************************/
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t line = NULLTAG;	
	int count =0;
	tag_t* child = NULL;
	int i = 0;
	int flag = 0;
	char** updatedModuleIDList = NULL;
	int updatedModuleIDListCnt = 0;
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window(&window));
	if(CFM_find( "Latest Working", &rule ));
	if(BOM_set_window_config_rule(window,rule ));
	if(BOM_set_window_pack_all(window, false));
	if(BOM_set_window_top_line(window, NULLTAG,vehRevTag,NULLTAG, &line));
	if(BOM_set_window_top_line_bvr(window,bvr,&line));		
	if(BOM_line_ask_all_child_lines(line,&count,&child));
	printf("\nupdateTMatrixOfVeh: Child count::::::::>>>>>>>> %d\n",count);
	int n =0;
	for(n=0;n<moduleIdCnt;n++)
	{
		char * moduleid = NULL;
		moduleid = moduleIDList[n];
		
		printf("\n[%d] - Module ID :[%s]\n", n+1,moduleid);fflush(stdout);
		
		for (i = 0; i<count; i++)
		{
			tag_t child_line = NULLTAG;
			//int uidType = 0;
			char* ChildUID = NULL;
			char* chldid = NULL;
			char* chldrevid = NULL;
			
			
			child_line = child[i];
			
			ifail = AOM_ask_value_string(child_line, "bl_item_item_id", &chldid);
			ifail = AOM_ask_value_string(child_line, "bl_rev_item_revision_id", &chldrevid);		

			//ifail =  BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType);
			//ifail = BOM_line_ask_attribute_string(child_line, uidType, &ChildUID);
			ifail = AOM_ask_value_string(child_line,"bl_occurrence_uid",&ChildUID);
			printf("\n Child Module: [%s;%s], ChildUID[%s] ",chldid,chldrevid,ChildUID);fflush(stdout);
			
			
			int found = 0;
			t5FindStrInSet(updatedModuleIDList,updatedModuleIDListCnt,ChildUID,&found);
			//check whether already updated if same module id...
			if(found == 0)
			{
				
				//int xform_matrixId = 0;
				char*xform_matrix_str = NULL;
				
				if(tc_strcmp(chldid,moduleid)==0)				
				{
					printf("Going to update T Matrix of this module[%s]\n", moduleIDList[n]);fflush(stdout);
					
					//if ( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrixId));
					//printf("\n***********xform_matrixId:%d\n",xform_matrixId);
					//if(BOM_line_ask_attribute_string(child_line, xform_matrixId, &xform_matrix_str));
					ifail = AOM_ask_value_string(child_line,"bl_plmxml_abs_xform",&xform_matrix_str);
					printf( " child xform_matrix_str--------------> %s\n",xform_matrix_str);fflush(stdout);	
				
					if(xform_matrix_str == NULL) xform_matrix_str ="";
					

					
					//if(BOM_line_set_attribute_string(child_line,xform_matrixId,tMatrixList[n]));
					ifail = AOM_set_value_string(child_line,"bl_plmxml_abs_xform",tMatrixList[n]);
					t5AddStrToSet(&updatedModuleIDListCnt,&updatedModuleIDList,ChildUID);
					flag++;	
					break;
						
				}
				
							
				
			}
			

			

		}		
		
	}

	
	if(flag> 0) if(BOM_save_window(window));
	if(BOM_close_window(window));
	printf("\nupdateTMatrixOfVeh:End of ...... update T Matrix.................\n");fflush(stdout);
	return ifail;
}



int tmUpdateTmatrixFromCSVStandAloneVehServ(void *retValue)
{
	printf("\nT-matrix:Update T-Matrux Service:Start----tmUpdateTmatrixFromCSVStandAloneVehServ....\n");fflush(stdout);
	const char	*prog_name 	="tmUpdateTmatrixFromCSVStandAloneVehServ";	
	int ifail = ITK_ok;
	tag_t inpFileDS = NULLTAG;
	//char* platformID = NULL;
	tag_t vehRevTag = NULLTAG;
	char* dsName = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&inpFileDS);
	USERARG_get_string_argument(&dsName);
	USERARG_get_tag_argument(&vehRevTag);
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	char* vehNo = NULL;
	char* vehRevS = NULL;
	ifail = AOM_ask_value_string(vehRevTag,"item_id",&vehNo);
	ifail = AOM_ask_value_string(vehRevTag,"item_revision_id",&vehRevS);
	
	printf("\nVehicle No:[%s/%s], dataset_name[%s]\n",vehNo, vehRevS,dsName);fflush(stdout);
	if(inpFileDS !=NULLTAG && tc_strlen(dsName)> 0 && vehRevTag != NULLTAG)
	{
		
		//printf("\nGot the Dataset.... Platform:[%s], dataset_name[%s]\n",platformID,dsName);fflush(stdout);
		
		isLiveForTmatrixUpdation(&cntrlObj,&liveFlag);
		if(liveFlag && cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//user group name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//session user name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));//shell path for stand alone
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));//user group name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));//session user name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			printf("\n TmatrixUpd-TmatrixUpd Control object information - stand alone Vehicle :\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			if(userInfo8 == NULL) userInfo8="";
			if(userInfo9 == NULL) userInfo9="";
			if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
			{
				char* sysCmnd = NULL;
				//execute client logic.
				printf("\nCLIENT LOGIC Tmatrix..\n");fflush(stdout);
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,userInfo5);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,vehNo);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,vehRevS);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,dsName);				
				printf("\n Start-- Calling shell file tm_UpdateTmatrixCvbuFromCSVStandAlone.sh using client system command: %s\n",sysCmnd);fflush(stdout);
				//system(sysCmnd);

				printf("\n End --- Calling shell file tm_UpdateTmatrixCvbuFromCSVStandAlone.sh using client system command: %s\n",sysCmnd);fflush(stdout);

				MEM_free(sysCmnd);
				tc_strcpy(resultStr,"LIVECLIENT");
			}
			else if(tc_strstr(userInfo8,",DIGIVIEW,")!= NULL)
			{
				//implement in ITK code.
				//printf("\nImplement in ITK...\n");fflush(stdout);
				printf("\nDIGIVIEW Tmatrix..\n");fflush(stdout);
				char* ds_object_type = NULL;
				char  *refname = NULL;
				AE_reference_type_t     reftype;
				tag_t	refobject = NULLTAG;
				char* orig_name = NULL;
				char *fileLoc = NULL;
				
				//Read the DataSet object and copy the file in /tmp folder.
				ifail = AOM_ask_value_string(inpFileDS,"object_type",&ds_object_type);
				//printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
				
				if(tc_strcmp(ds_object_type,"Text")==0)
				{
					ifail = AE_find_dataset_named_ref2(inpFileDS,0,&refname, &reftype,&refobject);
					if(refobject != NULLTAG)
					{
						ifail = IMF_ask_original_file_name2(refobject , &orig_name);
						
						fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
						tc_strcpy(fileLoc,"/tmp/");
						tc_strcat(fileLoc,orig_name);
						//printf("\n FileLoc: %s", fileLoc);fflush(stdout);
						remove( fileLoc );
						
						ifail = IMF_export_file( refobject , fileLoc );
						FILE * fp=NULL;
											 
						fp = fopen(fileLoc, "r");
						if(fp==NULL)
						{
							printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
						}
						else
						{
							char buffer[MAX_LINE_LEN] ="";
							char* moduleId = NULL;
							int x =0;
							char* vcNo = NULL;
							
							char* tMatrixStr = NULL;						
							char* tMatrixStr1 = NULL;
							char* tMatrixStr2 = NULL;
							char* tMatrixStr3 = NULL;
							char* tMatrixStr4 = NULL;
							char* tMatrixStr5 = NULL;
							char* tMatrixStr6 = NULL;
							char* tMatrixStr7 = NULL;
							char* tMatrixStr8 = NULL;
							char* tMatrixStr9 = NULL;
							char* tMatrixStr10 = NULL;
							char* tMatrixStr11 = NULL;
							char* tMatrixStr12 = NULL;
							char* tMatrixStr13 = NULL;
							char* tMatrixStr14 = NULL;
							char* tMatrixStr15 = NULL;
							char* tMatrixStr16 = NULL;
							
							char** moduleIdList = NULL;
							int moduleIdCnt = 0;						
							char** moduleTrnList = NULL;
							int moduleTrnCnt = 0;				
							
							while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
							{
								vcNo = strtok(buffer,"~");
								moduleId = strtok(NULL,"~");
								
								printf("\n vehNo: [%s] vcNo:[%s]\n",vehNo,vcNo);fflush(stdout);
								
								char* vcNoDup = (char*)MEM_alloc(50);
								tc_strcpy(vcNoDup,vcNo);
								
								if(!(tc_strcmp(vcNoDup,vehNo) ==0))
								{
									printf("\n Invalid Vehicle:[%s]\n",vcNoDup);fflush(stdout);
									continue;
								}
								
								if(tc_strlen(moduleId)==14)
								{
									
								}
								else
								{
									printf("\nInvalid Module ID [%s]. Skip\n",moduleId);fflush(stdout);
									continue;
								}
	
								tMatrixStr1 = strtok(NULL,"~");
								tMatrixStr2 = strtok(NULL,"~");
								tMatrixStr3 = strtok(NULL,"~");
								tMatrixStr4 = strtok(NULL,"~");
								tMatrixStr5 = strtok(NULL,"~");
								tMatrixStr6 = strtok(NULL,"~");
								tMatrixStr7 = strtok(NULL,"~");
								tMatrixStr8 = strtok(NULL,"~");
								tMatrixStr9 = strtok(NULL,"~");
								tMatrixStr10 = strtok(NULL,"~");
								tMatrixStr11 = strtok(NULL,"~");
								tMatrixStr12 = strtok(NULL,"~");
								tMatrixStr13 = strtok(NULL,"~");
								tMatrixStr14 = strtok(NULL,"~");
								tMatrixStr15 = strtok(NULL,"~");
								tMatrixStr16 = strtok(NULL,"~");

								
								tMatrixStr = (char*) MEM_alloc(1000*sizeof(char));
								
								tc_strcpy(tMatrixStr,"");
								tc_strcat(tMatrixStr,tMatrixStr1);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr2);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr3);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr4);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr5);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr6);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr7);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr8);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr9);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr10);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr11);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr12);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr13);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr14);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr15);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr16);
								

								printf("\n[%d]. Vehicle Node[%s], Module No[%s], TMatrix[%s]", ++x, vcNo,moduleId, tMatrixStr);fflush(stdout);
									
								t5AddStrToSet(&moduleIdCnt, &moduleIdList,moduleId);
								t5AddStrToSet(&moduleTrnCnt, &moduleTrnList,tMatrixStr);
									
															
								MEM_free(tMatrixStr);				
							}
							
							
							if(fp!=NULL)
							{
								fclose(fp); 
							}						
								
							//Update the T-Matrix logic
							printf("\n moduleIdCnt[%d] moduleTrnCnt[%d]\n",moduleIdCnt,moduleTrnCnt);fflush(stdout);
							
							ifail = updateTMatrixOfVeh(vehRevTag,moduleIdCnt,moduleIdList,moduleTrnCnt,moduleTrnList);
							
						}
							
						 
					}//End of ITK logic
					else
					{
						printf("\n NULLTAG refobject...\n");fflush(stdout);
						tc_strcpy(resultStr,"INVALID");
					}
				}
				else
				{
					printf("\nDataset Object Type is not Text. Please check...\n");fflush(stdout);
					tc_strcpy(resultStr,"INVALID");
				}
				
			}
			else if(tc_strstr(userInfo9,",SCALEDLOGIC,")!= NULL)
			{
				//implement in ITK code.
				printf("\nSCALEDLOGIC Tmatrix..\n");fflush(stdout);
				
				char* ds_object_type = NULL;
				char  *refname = NULL;
				AE_reference_type_t     reftype;
				tag_t	refobject = NULLTAG;
				char* orig_name = NULL;
				char *fileLoc = NULL;
				
				//Read the DataSet object and copy the file in /tmp folder.
				ifail = AOM_ask_value_string(inpFileDS,"object_type",&ds_object_type);
				//printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
				
				if(tc_strcmp(ds_object_type,"Text")==0)
				{
					ifail = AE_find_dataset_named_ref2(inpFileDS,0,&refname, &reftype,&refobject);
					if(refobject != NULLTAG)
					{
						ifail = IMF_ask_original_file_name2(refobject , &orig_name);
						
						fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
						tc_strcpy(fileLoc,"/tmp/");
						tc_strcat(fileLoc,orig_name);
						//printf("\n FileLoc: %s", fileLoc);fflush(stdout);
						remove( fileLoc );
						
						ifail = IMF_export_file( refobject , fileLoc );
						FILE * fp=NULL;
											 
						fp = fopen(fileLoc, "r");
						if(fp==NULL)
						{
							printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
						}
						else
						{
							char buffer[MAX_LINE_LEN] ="";
							char* moduleId = NULL;
							int x =0;
							char* vcNo = NULL;
							char* vcRev = NULL;
							char* vcSeq = NULL;
							char* tmp = NULL;
							char* tMatrixStr = NULL;						
							char* tMatrixStr1 = NULL;
							char* tMatrixStr2 = NULL;
							char* tMatrixStr3 = NULL;
							char* tMatrixStr4 = NULL;
							char* tMatrixStr5 = NULL;
							char* tMatrixStr6 = NULL;
							char* tMatrixStr7 = NULL;
							char* tMatrixStr8 = NULL;
							char* tMatrixStr9 = NULL;
							char* tMatrixStr10 = NULL;
							char* tMatrixStr11 = NULL;
							char* tMatrixStr12 = NULL;
							char* tMatrixStr13 = NULL;
							char* tMatrixStr14 = NULL;
							char* tMatrixStr15 = NULL;
							char* tMatrixStr16 = NULL;
							
							char* tMatrixStr13s = NULL;
							char* tMatrixStr14s = NULL;
							char* tMatrixStr15s = NULL;
							char** moduleIdList = NULL;
							int moduleIdCnt = 0;						
							char** moduleTrnList = NULL;
							int moduleTrnCnt = 0;				
							
							while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
							{
								vcNo = strtok(buffer,",");
								vcRev = strtok(NULL,",");
								vcSeq = strtok(NULL,",");
								moduleId = strtok(NULL,",");
								char * vcRevS = NULL;
								vcRevS = (char *) MEM_alloc( 100 * sizeof(char) );
								
								tc_strcpy(vcRevS,"");
								tc_strcat(vcRevS,vcRev);
								tc_strcat(vcRevS,";");
								tc_strcat(vcRevS,vcSeq);
								
								printf("\n vcRevS:[%s]\n",vcRevS);fflush(stdout);
								printf("\n vehRevS:[%s]\n",vehRevS);fflush(stdout);
								
								printf("\n vcNo:[%s]\n",vcNo);fflush(stdout);
								printf("\n vehNo:[%s]\n",vehNo);fflush(stdout);
								
								if(tc_strcmp(vcNo,vehNo)==0 && tc_strcmp(vcRevS,vehRevS)==0)
								{
									if(vcRevS) MEM_free(vcRevS);
								}
								else
								{
									printf("\nInvalid Vehicle ID [%s/%s]. Skip\n",vcNo,vcRevS);fflush(stdout);
									if(vcRevS) MEM_free(vcRevS);
									continue;
									
								}
								
								if(tc_strlen(moduleId)==14)
								{
									
								}
								else
								{
									printf("\nInvalid Module ID [%s]. Skip\n",moduleId);fflush(stdout);
									continue;
								}
								tmp = strtok(NULL,",");
								tmp = strtok(NULL,",");
								tmp = strtok(NULL,",");
								tMatrixStr1 = strtok(NULL,",");
								tMatrixStr2 = strtok(NULL,",");
								tMatrixStr3 = strtok(NULL,",");
								tMatrixStr4 = strtok(NULL,",");
								tMatrixStr5 = strtok(NULL,",");
								tMatrixStr6 = strtok(NULL,",");
								tMatrixStr7 = strtok(NULL,",");
								tMatrixStr8 = strtok(NULL,",");
								tMatrixStr9 = strtok(NULL,",");
								tMatrixStr10 = strtok(NULL,",");
								tMatrixStr11 = strtok(NULL,",");
								tMatrixStr12 = strtok(NULL,",");
								tMatrixStr13 = strtok(NULL,",");
								tMatrixStr14 = strtok(NULL,",");
								tMatrixStr15 = strtok(NULL,",");
								

								ifail = getScaledValue(tMatrixStr13, &tMatrixStr13s);
								ifail = getScaledValue(tMatrixStr14, &tMatrixStr14s);
								ifail = getScaledValue(tMatrixStr15, &tMatrixStr15s);
								

								
								//printf("\n tMatrixStr13: [%s],  tMatrixStr13s: [%s]",tMatrixStr13,tMatrixStr13s);fflush(stdout);
								//printf("\n tMatrixStr14: [%s],  tMatrixStr14s: [%s]",tMatrixStr14,tMatrixStr14s);fflush(stdout);
								//printf("\n tMatrixStr15: [%s],  tMatrixStr15s: [%s]",tMatrixStr15,tMatrixStr15s);fflush(stdout);							
								
								tMatrixStr16 = strtok(NULL,",");
								
								
								
								tMatrixStr = (char*) MEM_alloc(1000*sizeof(char));
								
								tc_strcpy(tMatrixStr,"");
								tc_strcat(tMatrixStr,tMatrixStr1);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr2);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr3);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr4);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr5);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr6);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr7);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr8);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr9);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr10);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr11);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr12);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr13s);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr14s);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr15s);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr16);
								
								MEM_free(tMatrixStr13s);
								MEM_free(tMatrixStr14s);
								MEM_free(tMatrixStr15s);

								printf("\n[%d]. Vehicle Node[%s], Module No[%s], TMatrix[%s]", ++x, vcNo,moduleId, tMatrixStr);fflush(stdout);
									
								t5AddStrToSet(&moduleIdCnt, &moduleIdList,moduleId);
								t5AddStrToSet(&moduleTrnCnt, &moduleTrnList,tMatrixStr);
									
															
								MEM_free(tMatrixStr);				
							}
							
							
							if(fp!=NULL)
							{
								fclose(fp); 
							}						
								
							//Update the T-Matrix logic
							printf("\n moduleIdCnt[%d] moduleTrnCnt[%d]\n",moduleIdCnt,moduleTrnCnt);fflush(stdout);
							
							ifail = updateTMatrixOfVeh(vehRevTag,moduleIdCnt,moduleIdList,moduleTrnCnt,moduleTrnList);
							
						}
							
						 
					}//End of ITK logic
					else
					{
						printf("\n NULLTAG refobject...\n");fflush(stdout);
						tc_strcpy(resultStr,"INVALID");
					}
				}
				else
				{
					printf("\nDataset Object Type is not Text. Please check...\n");fflush(stdout);
					tc_strcpy(resultStr,"INVALID");
				}
				
							
			}
			else
			{
				//implement in ITK code.
				//printf("\nImplement in ITK...\n");fflush(stdout);
				
				char* ds_object_type = NULL;
				char  *refname = NULL;
				AE_reference_type_t     reftype;
				tag_t	refobject = NULLTAG;
				char* orig_name = NULL;
				char *fileLoc = NULL;
				
				//Read the DataSet object and copy the file in /tmp folder.
				ifail = AOM_ask_value_string(inpFileDS,"object_type",&ds_object_type);
				//printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
				
				if(tc_strcmp(ds_object_type,"Text")==0)
				{
					ifail = AE_find_dataset_named_ref2(inpFileDS,0,&refname, &reftype,&refobject);
					if(refobject != NULLTAG)
					{
						ifail = IMF_ask_original_file_name2(refobject , &orig_name);
						
						fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
						tc_strcpy(fileLoc,"/tmp/");
						tc_strcat(fileLoc,orig_name);
						//printf("\n FileLoc: %s", fileLoc);fflush(stdout);
						remove( fileLoc );
						
						ifail = IMF_export_file( refobject , fileLoc );
						FILE * fp=NULL;
											 
						fp = fopen(fileLoc, "r");
						if(fp==NULL)
						{
							printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
						}
						else
						{
							char buffer[MAX_LINE_LEN] ="";
							char* moduleId = NULL;
							int x =0;
							char* vcNo = NULL;
							char* vcRev = NULL;
							char* vcSeq = NULL;
							char* tmp = NULL;
							char* tMatrixStr = NULL;						
							char* tMatrixStr1 = NULL;
							char* tMatrixStr2 = NULL;
							char* tMatrixStr3 = NULL;
							char* tMatrixStr4 = NULL;
							char* tMatrixStr5 = NULL;
							char* tMatrixStr6 = NULL;
							char* tMatrixStr7 = NULL;
							char* tMatrixStr8 = NULL;
							char* tMatrixStr9 = NULL;
							char* tMatrixStr10 = NULL;
							char* tMatrixStr11 = NULL;
							char* tMatrixStr12 = NULL;
							char* tMatrixStr13 = NULL;
							char* tMatrixStr14 = NULL;
							char* tMatrixStr15 = NULL;
							char* tMatrixStr16 = NULL;
							
							char** moduleIdList = NULL;
							int moduleIdCnt = 0;						
							char** moduleTrnList = NULL;
							int moduleTrnCnt = 0;				
							
							while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
							{
								vcNo = strtok(buffer,",");
								vcRev = strtok(NULL,",");
								vcSeq = strtok(NULL,",");
								moduleId = strtok(NULL,",");
								char * vcRevS = NULL;
								vcRevS = (char *) MEM_alloc( 100 * sizeof(char) );
								
								tc_strcpy(vcRevS,"");
								tc_strcat(vcRevS,vcRev);
								tc_strcat(vcRevS,";");
								tc_strcat(vcRevS,vcSeq);
								
								printf("\n vcRevS:[%s]\n",vcRevS);fflush(stdout);
								printf("\n vehRevS:[%s]\n",vehRevS);fflush(stdout);
								
								printf("\n vcNo:[%s]\n",vcNo);fflush(stdout);
								printf("\n vehNo:[%s]\n",vehNo);fflush(stdout);
								
								if(tc_strcmp(vcNo,vehNo)==0 && tc_strcmp(vcRevS,vehRevS)==0)
								{
									if(vcRevS) MEM_free(vcRevS);
								}
								else
								{
									printf("\nInvalid Vehicle ID [%s/%s]. Skip\n",vcNo,vcRevS);fflush(stdout);
									if(vcRevS) MEM_free(vcRevS);
									continue;
									
								}
								
								if(tc_strlen(moduleId)==14)
								{
									
								}
								else
								{
									printf("\nInvalid Module ID [%s]. Skip\n",moduleId);fflush(stdout);
									continue;
								}
								tmp = strtok(NULL,",");
								tmp = strtok(NULL,",");
								tmp = strtok(NULL,",");
								tMatrixStr1 = strtok(NULL,",");
								tMatrixStr2 = strtok(NULL,",");
								tMatrixStr3 = strtok(NULL,",");
								tMatrixStr4 = strtok(NULL,",");
								tMatrixStr5 = strtok(NULL,",");
								tMatrixStr6 = strtok(NULL,",");
								tMatrixStr7 = strtok(NULL,",");
								tMatrixStr8 = strtok(NULL,",");
								tMatrixStr9 = strtok(NULL,",");
								tMatrixStr10 = strtok(NULL,",");
								tMatrixStr11 = strtok(NULL,",");
								tMatrixStr12 = strtok(NULL,",");
								tMatrixStr13 = strtok(NULL,",");
								tMatrixStr14 = strtok(NULL,",");
								tMatrixStr15 = strtok(NULL,",");								
								tMatrixStr16 = strtok(NULL,",");
								
								
								
								tMatrixStr = (char*) MEM_alloc(1000*sizeof(char));
								
								tc_strcpy(tMatrixStr,"");
								tc_strcat(tMatrixStr,tMatrixStr1);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr2);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr3);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr4);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr5);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr6);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr7);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr8);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr9);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr10);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr11);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr12);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr13);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr14);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr15);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr16);
								

								printf("\n[%d]. Vehicle Node[%s], Module No[%s], TMatrix[%s]", ++x, vcNo,moduleId, tMatrixStr);fflush(stdout);
									
								t5AddStrToSet(&moduleIdCnt, &moduleIdList,moduleId);
								t5AddStrToSet(&moduleTrnCnt, &moduleTrnList,tMatrixStr);
									
															
								MEM_free(tMatrixStr);				
							}
							
							
							if(fp!=NULL)
							{
								fclose(fp); 
							}						
								
							//Update the T-Matrix logic
							printf("\n moduleIdCnt[%d] moduleTrnCnt[%d]\n",moduleIdCnt,moduleTrnCnt);fflush(stdout);
							
							ifail = updateTMatrixOfVeh(vehRevTag,moduleIdCnt,moduleIdList,moduleTrnCnt,moduleTrnList);
							
						}
							
						 
					}//End of ITK logic
					else
					{
						printf("\n NULLTAG refobject...\n");fflush(stdout);
						tc_strcpy(resultStr,"INVALID");
					}
				}
				else
				{
					printf("\nDataset Object Type is not Text. Please check...\n");fflush(stdout);
					tc_strcpy(resultStr,"INVALID");
				}
				
				
			}

			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nTmatrix: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nT-Matrux - After returning Value\n");fflush(stdout);	

	printf("\nT-matrix:Update T-Matrux Service:End----tmUpdateTmatrixFromCSVStandAloneVehServ....\n");fflush(stdout);
	return ifail;	
	
}


int tmUpdateTmatrixOfVehUsingDigiViewFile(void *retValue)
{
	printf("\nT-matrix:Update T-Matrux Service:Start----tmUpdateTmatrixOfVehUsingDigiViewFile....\n");fflush(stdout);
	const char	*prog_name 	="tmUpdateTmatrixOfVehUsingDigiViewFile";	
	int ifail = ITK_ok;
	tag_t inpFileDS = NULLTAG;
	//char* platformID = NULL;
	tag_t vehRevTag = NULLTAG;
	char* dsName = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&inpFileDS);
	USERARG_get_string_argument(&dsName);
	USERARG_get_tag_argument(&vehRevTag);
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(resultStr,"");
	char* vehNo = NULL;
	char* vehRevS = NULL;
	ifail = AOM_ask_value_string(vehRevTag,"item_id",&vehNo);
	ifail = AOM_ask_value_string(vehRevTag,"item_revision_id",&vehRevS);
	
	printf("\nVehicle No:[%s/%s], dataset_name[%s]\n",vehNo, vehRevS,dsName);fflush(stdout);
	if(inpFileDS !=NULLTAG && tc_strlen(dsName)> 0 && vehRevTag != NULLTAG)
	{
		
		//printf("\nGot the Dataset.... Platform:[%s], dataset_name[%s]\n",platformID,dsName);fflush(stdout);
		
		isLiveForTmatrixUpdDigView(&cntrlObj,&liveFlag);
		if(liveFlag && cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path for digiview upd tmat
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//user group name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//session user name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));//user group name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));//session user name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			printf("\n TMatUpdDigVw-TMatUpdDigVw Control object information - stand alone Vehicle :\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			if(userInfo8 == NULL) userInfo8="";
			if(userInfo9 == NULL) userInfo9="";
			if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
			{
				char* sysCmnd = NULL;
				//execute client logic.
				printf("\nCLIENT LOGIC Tmatrix Digi View..\n");fflush(stdout);
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,userInfo2);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,vehNo);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,vehRevS);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,dsName);				
				printf("\n Start-- Calling shell file tm_UpdateTmatOfVehFromDigView.sh.sh using client system command: %s\n",sysCmnd);fflush(stdout);
				system(sysCmnd);

				printf("\n End --- Calling shell file tm_UpdateTmatOfVehFromDigView.sh using client system command: %s\n",sysCmnd);fflush(stdout);

				MEM_free(sysCmnd);
				tc_strcpy(resultStr,"LIVECLIENT");
			}
			else
			{
				//implement in ITK code.
				//printf("\nImplement in ITK...\n");fflush(stdout);
				printf("\nDIGIVIEW Tmatrix..\n");fflush(stdout);
				char* ds_object_type = NULL;
				char  *refname = NULL;
				AE_reference_type_t     reftype;
				tag_t	refobject = NULLTAG;
				char* orig_name = NULL;
				char *fileLoc = NULL;
				
				//Read the DataSet object and copy the file in /tmp folder.
				ifail = AOM_ask_value_string(inpFileDS,"object_type",&ds_object_type);
				//printf("\n dataset object_type is :%s\n",ds_object_type);fflush(stdout);
				
				if(tc_strcmp(ds_object_type,"Text")==0)
				{
					ifail = AE_find_dataset_named_ref2(inpFileDS,0,&refname, &reftype,&refobject);
					if(refobject != NULLTAG)
					{
						ifail = IMF_ask_original_file_name2(refobject , &orig_name);
						
						fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
						tc_strcpy(fileLoc,"/tmp/");
						tc_strcat(fileLoc,orig_name);
						//printf("\n FileLoc: %s", fileLoc);fflush(stdout);
						remove( fileLoc );
						
						ifail = IMF_export_file( refobject , fileLoc );
						FILE * fp=NULL;
											 
						fp = fopen(fileLoc, "r");
						if(fp==NULL)
						{
							printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
							tc_strcpy(resultStr,"FILEERROR");
						}
						else
						{
							char buffer[MAX_LINE_LEN] ="";
							char* moduleId = NULL;
							int x =0;
							char* vcNo = NULL;
							
							char* tMatrixStr = NULL;						
							char* tMatrixStr1 = NULL;
							char* tMatrixStr2 = NULL;
							char* tMatrixStr3 = NULL;
							char* tMatrixStr4 = NULL;
							char* tMatrixStr5 = NULL;
							char* tMatrixStr6 = NULL;
							char* tMatrixStr7 = NULL;
							char* tMatrixStr8 = NULL;
							char* tMatrixStr9 = NULL;
							char* tMatrixStr10 = NULL;
							char* tMatrixStr11 = NULL;
							char* tMatrixStr12 = NULL;
							char* tMatrixStr13 = NULL;
							char* tMatrixStr14 = NULL;
							char* tMatrixStr15 = NULL;
							char* tMatrixStr16 = NULL;
							
							char** moduleIdList = NULL;
							int moduleIdCnt = 0;						
							char** moduleTrnList = NULL;
							int moduleTrnCnt = 0;				
							
							while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
							{
								vcNo = tc_strtok(buffer,"~");
								moduleId = tc_strtok(NULL,"~");
								
								printf("\n vehNo: [%s] vcNo:[%s]-->[%d]\n",vehNo,vcNo,tc_strlen(vcNo));fflush(stdout);
								
								char* vcNoDup = NULL;
								tc_strdup(vcNo,&vcNoDup);
								
								printf("\n vcNoDup: [%s]-->[%d] vehNo:[%s] -->[%d]\n",vcNoDup,tc_strlen(vcNoDup),vehNo,tc_strlen(vehNo));fflush(stdout);
																
								if(!(tc_strcmp(vcNoDup,vehNo) ==0))
								{
									printf("\n Invalid Vehicle:[%s]\n",vcNoDup);fflush(stdout);
									continue;
								}
								
								if(tc_strlen(moduleId)==14)
								{
									
								}
								else
								{
									printf("\nInvalid Module ID [%s]. Skip\n",moduleId);fflush(stdout);
									continue;
								}
	
								tMatrixStr1 = tc_strtok(NULL,"~");
								tMatrixStr2 = tc_strtok(NULL,"~");
								tMatrixStr3 = tc_strtok(NULL,"~");
								tMatrixStr4 = tc_strtok(NULL,"~");
								tMatrixStr5 = tc_strtok(NULL,"~");
								tMatrixStr6 = tc_strtok(NULL,"~");
								tMatrixStr7 = tc_strtok(NULL,"~");
								tMatrixStr8 = tc_strtok(NULL,"~");
								tMatrixStr9 = tc_strtok(NULL,"~");
								tMatrixStr10 = tc_strtok(NULL,"~");
								tMatrixStr11 = tc_strtok(NULL,"~");
								tMatrixStr12 = tc_strtok(NULL,"~");
								tMatrixStr13 = tc_strtok(NULL,"~");
								tMatrixStr14 = tc_strtok(NULL,"~");
								tMatrixStr15 = tc_strtok(NULL,"~");
								tMatrixStr16 = tc_strtok(NULL,"~");

								
								tMatrixStr = (char*) MEM_alloc(10000*sizeof(char));
								
								tc_strcpy(tMatrixStr,"");
								tc_strcat(tMatrixStr,tMatrixStr1);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr2);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr3);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr4);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr5);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr6);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr7);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr8);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr9);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr10);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr11);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr12);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr13);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr14);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr15);
								tc_strcat(tMatrixStr," ");
								tc_strcat(tMatrixStr,tMatrixStr16);
								

								printf("\n[%d]. Vehicle Node[%s], Module No[%s], TMatrix[%s]", ++x, vcNo,moduleId, tMatrixStr);fflush(stdout);
									
								t5AddStrToSet(&moduleIdCnt, &moduleIdList,moduleId);
								t5AddStrToSet(&moduleTrnCnt, &moduleTrnList,tMatrixStr);
									
															
								MEM_free(tMatrixStr);				
							}
							
							
							if(fp!=NULL)
							{
								fclose(fp); 
							}						
								
							//Update the T-Matrix logic
							printf("\n moduleIdCnt[%d] moduleTrnCnt[%d]\n",moduleIdCnt,moduleTrnCnt);fflush(stdout);
							
							ifail = updateTMatrixOfVeh(vehRevTag,moduleIdCnt,moduleIdList,moduleTrnCnt,moduleTrnList);
							
						}
							
						 
					}//End of ITK logic
					else
					{
						printf("\n NULLTAG refobject...\n");fflush(stdout);
						tc_strcpy(resultStr,"NONAMEREF");
					}
				}
				else
				{
					printf("\nDataset Object Type is not Text. Please check...\n");fflush(stdout);
					tc_strcpy(resultStr,"INVALIDFILEFORMAT");
				}
				
			}
			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nTmatrix: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nT-Matrux - After returning Value\n");fflush(stdout);	

	printf("\nT-matrix:Update T-Matrux Service:End----tmUpdateTmatrixOfVehUsingDigiViewFile....\n");fflush(stdout);
	return ifail;	
	
}





int tmUpdTmatrixCCServFn(void *retValue)
{
	printf("\nTmatrix: Start---tmUpdTmatrixCCServFn\n");fflush(stdout);
	const char	*prog_name 	="tmUpdTmatrixCCServFn";	
	int ifail = ITK_ok;
	char* partNumber = NULL;
	
	USERARG_get_string_argument(&partNumber);
	
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	

	tag_t cntrlObj = NULLTAG;
	
	
	printf("\nTmatrix: Input Argument:[%s]",partNumber);fflush(stdout);
	
	ifail = getTmatrixGenericControlTag(&cntrlObj);
	
	if(cntrlObj != NULLTAG)
	{
		
		char* userInfo1	=	NULL;
		
		ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);//shell path of the client code
		
		
		printf("\nTmatrix: t5_Userinfo1:[%s]\n",userInfo1);fflush(stdout);
		
		char* sysCmnd = NULL;
		//execute client logic.
		printf("\nTmatrix: Call generic shell program.\n");fflush(stdout);
		sysCmnd=(char *) MEM_alloc(400);
		tc_strcpy(sysCmnd,userInfo1);
		tc_strcat(sysCmnd," \"");
		tc_strcat(sysCmnd,partNumber);
		tc_strcat(sysCmnd,"\"");
		
		printf("\n Start-- Calling shell file Generic client through user service: client system command:[%s]\n",sysCmnd);fflush(stdout);
		system(sysCmnd);

		printf("\n End --- Calling generic shell file  using client system command: %s\n",sysCmnd);fflush(stdout);

		MEM_free(sysCmnd);
		
		
		tc_strcpy(resultStr,"PASS");
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	

	
	
	
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nTmatrix: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nTmatrix: - After returning Value\n");fflush(stdout);	

	printf("\nTmatrix: End----of user service tmUpdTmatrixCCServFn....\n");fflush(stdout);
	return ifail;	
	
}

/*****************************************************************************/

int getEngineModuleTmatUpdCtrlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatEngnMdl";
	qry_values[1] = "TmatEngnMdl";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nTmatrix:Control objects TmatEngnMdl: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		if(cntrlObj!=NULLTAG)
		{			
		
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}

int getAddOptionValueToCtxtCtrlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatAddCC";
	qry_values[1] = "TmatAddCC";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nProdCfg:Control objects TmatAddCC: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		if(cntrlObj!=NULLTAG)
		{			
		
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}


int getAutoStampCHSDrgCtrlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nESO: Check for control object TmatrixUpd....\n");fflush(stdout);
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "TmatAutoCHS";
	qry_values[1] = "TmatAutoCHS";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nCHS:Control objects TmatAutoCHS: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		if(cntrlObj!=NULLTAG)
		{			
		
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}



int tmUpdateTmatrixFromCSVStandAloneEngineVehServ(void *retValue)
{
	printf("\nT-matrix:Update T-Matrux Service:Start----tmUpdateTmatrixFromCSVStandAloneEngineVehServ....\n");fflush(stdout);
	const char	*prog_name 	="tmUpdateTmatrixFromCSVStandAloneEngineVehServ";	
	int ifail = ITK_ok;
	tag_t inpFileDS = NULLTAG;
	//char* platformID = NULL;
	tag_t vehRevTag = NULLTAG;
	char* dsName = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&inpFileDS);
	USERARG_get_string_argument(&dsName);
	USERARG_get_tag_argument(&vehRevTag);
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	char* vehNo = NULL;
	char* vehRevS = NULL;
	ifail = AOM_ask_value_string(vehRevTag,"item_id",&vehNo);
	ifail = AOM_ask_value_string(vehRevTag,"item_revision_id",&vehRevS);
	
	printf("\nVehicle No:[%s/%s], dataset_name[%s]\n",vehNo, vehRevS,dsName);fflush(stdout);
	if(inpFileDS !=NULLTAG && tc_strlen(dsName)> 0 && vehRevTag != NULLTAG)
	{
		
		//printf("\nGot the Dataset.... Platform:[%s], dataset_name[%s]\n",platformID,dsName);fflush(stdout);
		
		ifail = getEngineModuleTmatUpdCtrlTag(&cntrlObj);
		if(cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path of script
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));//session user group name
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//session user group role
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));//session user id
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			printf("\n TmatEngnMdl-TmatEngnMdl Control object information - stand alone Vehicle :\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			if(userInfo8 == NULL) userInfo8="";
			if(userInfo9 == NULL) userInfo9="";
			if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
			{
				char* sysCmnd = NULL;
				//execute client logic.
				printf("\nCLIENT LOGIC Tmatrix..\n");fflush(stdout);
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,userInfo2);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,vehNo);
				tc_strcat(sysCmnd," \"");
				tc_strcat(sysCmnd,vehRevS);
				tc_strcat(sysCmnd,"\" \"");
				tc_strcat(sysCmnd,dsName);
				tc_strcat(sysCmnd,"\"");
				printf("\n Start-- Calling shell file tm_UpdTmatCvbuFromCSVEngineModule.sh using client system command: %s\n",sysCmnd);fflush(stdout);
				system(sysCmnd);

				printf("\n End --- Calling shell file tm_UpdTmatCvbuFromCSVEngineModule.sh using client system command: %s\n",sysCmnd);fflush(stdout);

				MEM_free(sysCmnd);
				tc_strcpy(resultStr,"LIVECLIENT");
			}
			else
			{
				tc_strcpy(resultStr,"NOTLIVE");
			}
			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nTmatrix: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nT-Matrux - After returning Value\n");fflush(stdout);	

	printf("\nT-matrix:Update T-Matrux Service:End----tmUpdateTmatrixFromCSVStandAloneEngineVehServ....\n");fflush(stdout);
	return ifail;	
	
}


int tmAssignOptionValueToCCServ(void *retValue)
{
	printf("\nProdCfg:Start----tmAssignOptionValueToCCServ....\n");fflush(stdout);
	const char	*prog_name 	="tmAssignOptionValueToCCServ";	
	int ifail = ITK_ok;
	tag_t inpFileDS = NULLTAG;
	char* dsName = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&inpFileDS);
	USERARG_get_string_argument(&dsName);
		
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	

	printf("\nProdCfg:dataset_name[%s]\n",dsName);fflush(stdout);
	if(inpFileDS !=NULLTAG && tc_strlen(dsName)> 0)
	{
		
		//printf("\nGot the Dataset.... Platform:[%s], dataset_name[%s]\n",platformID,dsName);fflush(stdout);
		
		ifail = getAddOptionValueToCtxtCtrlTag(&cntrlObj);
		if(cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path of script
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//session user group role
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));//session user id
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			printf("\n TmatAddCC-TmatAddCC Control object information - stand alone Vehicle :\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			if(userInfo8 == NULL) userInfo8="";
			if(userInfo9 == NULL) userInfo9="";
			if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
			{
				char* sysCmnd = NULL;
				//execute client logic.
				printf("\nCLIENT LOGIC Tmatrix..\n");fflush(stdout);
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,userInfo2);
				tc_strcat(sysCmnd," \"");
				tc_strcat(sysCmnd,dsName);
				tc_strcat(sysCmnd,"\"");
				printf("\n Start-- Calling shell file tm_AddOptionValueToCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
				system(sysCmnd);

				printf("\n End --- Calling shell file tm_AddOptionValueToCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);

				MEM_free(sysCmnd);
				tc_strcpy(resultStr,"LIVECLIENT");
			}
			else
			{
				tc_strcpy(resultStr,"NOTLIVE");
			}
			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nProdCfg: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nProdCfg:- After returning Value\n");fflush(stdout);	

	printf("\nProdCfg:End----tmAssignOptionValueToCCServ....\n");fflush(stdout);
	return ifail;	
	
}


int tmAutoStampCHSDrgServ(void *retValue)
{
	printf("\nCHS:Start----tmAutoStampCHSDrgServ....\n");fflush(stdout);
	const char	*prog_name 	="tmAutoStampCHSDrgServ";	
	int ifail = ITK_ok;
	//tag_t inpFileDS = NULLTAG;
	char* partno = NULL;
	char* partrev = NULL;
	char* partseq = NULL;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_string_argument(&partno);
	USERARG_get_string_argument(&partrev);
	USERARG_get_string_argument(&partseq);
		
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	

	printf("\nCHS:Input part:[%s/%s;%s]\n",partno,partrev,partseq);fflush(stdout);
	
	ifail = getAutoStampCHSDrgCtrlTag(&cntrlObj);
	if(cntrlObj != NULLTAG)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;
		
		
		
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//flag for client
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//shell path of script
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));//session user group role
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));//session user id
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
		
		
		
		printf("\nTmatAutoCHS-TmatAutoCHS Control object information - stand alone Vehicle :\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
		if(tc_strstr(userInfo1,",CLIENT,")!= NULL)
		{
			char* sysCmnd = NULL;
			//execute client logic.
			printf("\nCLIENT LOGIC TmatAutoCHS..\n");fflush(stdout);
			sysCmnd=(char *) MEM_alloc(400);
			tc_strcpy(sysCmnd,userInfo2);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,partno);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,partrev);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,partseq);
			//tc_strcat(sysCmnd," ");				
			printf("\n Start-- Calling shell file tm_AutoStampCHSDrawing.sh using client system command: %s\n",sysCmnd);fflush(stdout);
			system(sysCmnd);

			printf("\n End --- Calling shell file tm_AutoStampCHSDrawing.sh using client system command: %s\n",sysCmnd);fflush(stdout);

			MEM_free(sysCmnd);
			tc_strcpy(resultStr,"LIVECLIENT");
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
	}
	else
	{
		tc_strcpy(resultStr,"NOTLIVE");
	}

	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nProdCfg: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nProdCfg:- After returning Value\n");fflush(stdout);	

	printf("\nProdCfg:End----tmAutoStampCHSDrgServ....\n");fflush(stdout);
	return ifail;	
	
}


extern int UpdateTmatrixFromCSVFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 3;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//DataSet Object
	input_arg_type[1]=USERARG_STRING_TYPE;//dataset name
	input_arg_type[2]=USERARG_STRING_TYPE;//Platform
	ret_value_type = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tmUpdateTmatrixFromCSVServ",(USER_function_t)tmUpdateTmatrixFromCSVServ,n_args,input_arg_type,ret_value_type);
	
	
	int n_args1 = 3;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args1 * sizeof(int));
	
	input_arg_type1[0]=USERARG_TAG_TYPE;//DataSet Object
	input_arg_type1[1]=USERARG_STRING_TYPE;//dataset name
	input_arg_type1[2]=USERARG_TAG_TYPE;//StandAlone Vehicle Tag
	ret_value_type1 = USERARG_STRING_TYPE;
 	
	//printf("\nTmatrix services registered...\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tmUpdateTmatrixFromCSVStandAloneVehServ",(USER_function_t)tmUpdateTmatrixFromCSVStandAloneVehServ,n_args1,input_arg_type1,ret_value_type1);
	//printf("\n finished ..Tmatrix services registered...\n");fflush(stdout);
	
	
	
	int n_args2 = 3;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args2 * sizeof(int));
	
	input_arg_type2[0]=USERARG_TAG_TYPE;//DataSet Object
	input_arg_type2[1]=USERARG_STRING_TYPE;//dataset name
	input_arg_type2[2]=USERARG_TAG_TYPE;//StandAlone Vehicle Tag
	ret_value_type2 = USERARG_STRING_TYPE;
 	
	//printf("\nTmatrix services registered ...\n");fflush(stdout);
	ifail=USERSERVICE_register_method("tmUpdateTmatrixOfVehUsingDigiViewFile",(USER_function_t)tmUpdateTmatrixOfVehUsingDigiViewFile,n_args2,input_arg_type2,ret_value_type2);
	//printf("\n finished ..Tmatrix services registered...\n");fflush(stdout);
	
	
	/* Test*/
	
	int n_args3 = 1;
	int ret_value_type3;
	int *input_arg_type3;
	input_arg_type3=(int *)MEM_alloc(n_args3 * sizeof(int));
	
	input_arg_type3[0]=USERARG_STRING_TYPE;//Part Number
	
	ret_value_type3 = USERARG_STRING_TYPE;
	
	ifail=USERSERVICE_register_method("tmUpdTmatrixCCServ",(USER_function_t)tmUpdTmatrixCCServFn,n_args3,input_arg_type3,ret_value_type3);
	
	
	
	/********CR-FY25-0122 ******************/
	
	int n_args4 = 3;
	int ret_value_type4;
	int *input_arg_type4;
	input_arg_type4=(int *)MEM_alloc(n_args4 * sizeof(int));
	
	input_arg_type4[0]=USERARG_TAG_TYPE;//DataSet Object
	input_arg_type4[1]=USERARG_STRING_TYPE;//dataset name
	input_arg_type4[2]=USERARG_TAG_TYPE;//StandAlone Vehicle Tag
	ret_value_type4 = USERARG_STRING_TYPE;
 	
	ifail=USERSERVICE_register_method("tmUpdateTmatrixFromCSVStandAloneEngineVehServ",(USER_function_t)tmUpdateTmatrixFromCSVStandAloneEngineVehServ,n_args4,input_arg_type4,ret_value_type4);
	
		
	
	/**********End CR-FY25-0122 ***************/
	
	/*****************Start CR-FY25-0151 ***********************/
	
	int n_args5 = 2;
	int ret_value_type5;
	int *input_arg_type5;
	input_arg_type5=(int *)MEM_alloc(n_args5 * sizeof(int));
	
	input_arg_type5[0]=USERARG_TAG_TYPE;//DataSet Object
	input_arg_type5[1]=USERARG_STRING_TYPE;//dataset name
	ret_value_type5 = USERARG_STRING_TYPE;
 	
	ifail=USERSERVICE_register_method("tmAssignOptionValueToCCServ",(USER_function_t)tmAssignOptionValueToCCServ,n_args5,input_arg_type5,ret_value_type5);
	
	/***************End CR-FY25-0151 *****************************/
	
	
	/*****************Start CHS logic ***********************/
	
	int n_args6 = 3;
	int ret_value_type6;
	int *input_arg_type6;
	input_arg_type6=(int *)MEM_alloc(n_args6 * sizeof(int));
	
	input_arg_type6[0]=USERARG_STRING_TYPE;//Part No
	input_arg_type6[1]=USERARG_STRING_TYPE;//Rev
	input_arg_type6[2]=USERARG_STRING_TYPE;//Seq
	ret_value_type6 = USERARG_STRING_TYPE;
 	
	ifail=USERSERVICE_register_method("tmAutoStampCHSDrgServ",(USER_function_t)tmAutoStampCHSDrgServ,n_args6,input_arg_type6,ret_value_type6);
	
	/***************End CHS logic *****************************/
	
	
	return ifail;
}



extern DLLAPI int tm_updTmatrixCvbu_register_callbacks ()
{	
    int ifail    = ITK_ok;
	
	ifail=CUSTOM_register_exit ( "tm_updTmatrixCvbu", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)UpdateTmatrixFromCSVFn);//user service not use
	
  return ( ITK_ok );
}

