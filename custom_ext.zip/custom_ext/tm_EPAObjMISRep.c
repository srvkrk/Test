#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
//#include <tc/emh.h>
//#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

int EpaObjMisRptFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;

    char                    *EPAMISFromDate                         =       NULL;
    char                    *EPAMISToDate                           =       NULL;
	char                    *EPAMISPlant                          	=       NULL;
    char                    *EPAMISCreator                          =       NULL;
   
   
	char*                   LineItem                                =       NULL;
	int                     SysReturn                               =       0;
	
    
    printf("\n I am in main program");fflush(stdout);


    USERARG_get_string_argument(&EPAMISFromDate);
    USERARG_get_string_argument(&EPAMISToDate);
    USERARG_get_string_argument(&EPAMISPlant);
	USERARG_get_string_argument(&EPAMISCreator);
    
	
	LineItem	             =(char *) MEM_alloc(1000);
	strcpy(LineItem,"/user/cvprod/shells/STD/EpaObjMisRptProd.sh");
	strcat(LineItem," ");
	strcat(LineItem,EPAMISFromDate);
	strcat(LineItem," ");
	strcat(LineItem,EPAMISToDate);
	strcat(LineItem," ");
	strcat(LineItem,EPAMISPlant);
	strcat(LineItem," ");
	strcat(LineItem,EPAMISCreator);
	
	printf("\n LineItem = %s",LineItem);fflush(stdout);
	system(LineItem);
	
    return ifail;
}



extern int EpaObjMISUserServiceFncnfEPAMISRptFn()
{
    int ifail = ITK_ok;
    int nargs = 4;
    int retValueType;
    int inputArgTypes[4] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //From date
    inputArgTypes[1] = USERARG_STRING_TYPE; //To date
    inputArgTypes[2] = USERARG_STRING_TYPE; //User id
    inputArgTypes[3] = USERARG_STRING_TYPE; //User id
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("EpaObjMisRptFuncsvr",(USER_function_t)EpaObjMisRptFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceFnCnfEPAMISRpt(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(EpaObjMISUserServiceFncnfEPAMISRptFn());

    return ifail;
}

extern DLLAPI int tm_EPAObjMISRep_register_callbacks ()
{

    int ifail    = ITK_ok;
    ifail = CUSTOM_register_exit("tm_EPAObjMISRep", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnCnfEPAMISRpt);
    return(ITK_ok);

}