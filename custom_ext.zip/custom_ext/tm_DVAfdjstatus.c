/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_DVAfdjstatus.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for WCQ Result 7 Report.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Anvesh Bujule						    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>


int FDJcount=0;
int GCIcount=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}



//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* FDJCalulate()
{
	char* ptr = NULL;
	float WCQresult;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);

	printf("\n FDJcount [%d],GCIcount[%d]",FDJcount,GCIcount); fflush(stdout);

	WCQresult = (float)(GCIcount) / FDJcount * 100.0;

	printf("\n  after calculation: WCQresult = %.2f%%", WCQresult); fflush(stdout);
	sprintf(ptr,"%10lf",WCQresult);
	printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

	return ptr;
	
	
}

extern int DVAfdjstatus(void *retValue)
{

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	 //char *output	 = NULL;

	 int status				= ITK_ok;
	//char *fromdate			= NULL;
	//char *todate			= NULL;
	char *type				= NULL;
	int i = 0;
	int n_entries;
	int n_entries1;

	tag_t queryTag1			= NULLTAG;
	tag_t queryTag			= NULLTAG;
	tag_t VehicleTag1		= NULLTAG;
	int resultCount			= 0;
	int resultCount11		= 0;
	tag_t *VehicleTags		= NULLTAG;
	tag_t *ERCDMLTags1		= NULLTAG;
	tag_t ERCDMLTag			= NULLTAG;
	tag_t ERCDMLTag1		= NULLTAG;
	tag_t objTypeTag		= NULLTAG;
	tag_t VCMain			= NULLTAG;
	tag_t DMLtag			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	//tag_t VCMainchld1		= NULLTAG;
	//char  type_name[TCTYPE_name_size_c+1];
	char*  type_name = NULL;

	char *DmlId			= NULL;
	char *DmlIdDup		= NULL;
	char *DmlRelType	= NULL;
	char *DmlRelTypeDup = NULL;
	char *DmlRelStat	= NULL;
	char *DmlRelStatDup = NULL;
	char *PartNum		= NULL;
	char *PartRev		= NULL;
	char *VCtargetid	= NULL;
	char *VCtargetrevid = NULL;
	char *VCtestid		= NULL;
	char *VCtestrevid	= NULL;
	char *VCtestDescp	= NULL;
	//int VCtestPlatform	= 0;
	char *VCtestProgScale = NULL;
	char *VCtestDateRel = NULL;
	char *WCQfinal		= NULL;
	char *DMLno			= NULL;
	char *DMLRevno		= NULL;
	char *DMLRelType	= NULL;
	char *VCtestPlatform = NULL;
	double GCIValue;
	double TestGCIValue;
	double TestDVAValue;
	int TestDMUscore;


	tag_t* TechSPecObjSet	= NULLTAG;
	int TechSpecCount		= 0;
	tag_t TechSPecObj		= NULLTAG;
	char *descDup			= NULL;
	tag_t FDJRelationFind	= NULLTAG;
	tag_t GCIRelationFind	= NULLTAG;
	tag_t snapshotObj		= NULLTAG;
	tag_t VCRevTag			= NULLTAG;
	tag_t lov_tag			= NULLTAG;
	int snapshotCount		= 0;
	tag_t* snapshotObjSet	= NULLTAG;
	tag_t* VCMainchld		= NULLTAG;
	//tag_t* VCMainchld1		= NULLTAG;
	tag_t* FDJObjectTag		= NULLTAG;
	tag_t* GCIObjectTag		= NULLTAG;
	tag_t GCIObject			= NULLTAG;
	char snapshotObjtype_name[TCTYPE_name_size_c+1];
	tag_t snapshotObjTypeTag= NULLTAG;
	tag_t FDJObject			= NULLTAG;
	char* snapshot_itemid	= NULL;
	char* SSTopLineRev		= NULL;
	char* VCDRstatus		= NULL;
	char* VCColInd			= NULL;
	char* VCid				= NULL;
	char* VCrevid			= NULL;
	char* FDJStatus			= NULL;
	int EligibleVCatDR3     =0;
	int j                   =0;
	int DR3count            =0;
	int FDJapprove          =0;
 
	char** bufferedXmlStrOut;
	int buff_cnt                =0;
	int VCchldcount             =0;
	int FDJ_count               =0;
	int GCI_count               =0;
	int gci                     =0;
	int fdj                     =0;
    int refcount                =0;
	int flag                    =0;
	tag_t reflist2 = NULLTAG;
	tag_t DMLitemtag = NULLTAG;
	tag_t *reflist = NULLTAG;
	tag_t *ERCDMLTags = NULLTAG;
	tag_t dad_tag=NULLTAG;

	int DVAreportflag1 =0;
    tag_t DVAfoldertypetag          = NULLTAG;
    tag_t DMLitemRevtag          = NULLTAG;
    char* username                  = NULL;
    char* taskdmlno                  = NULL;
    char* documentName              = NULL;
    tag_t user_tag                  =NULLTAG;
    tag_t statustag1                  =NULLTAG;
    tag_t homefoldertag             = NULLTAG;
    FL_sort_criteria_t flcriteria;
	tag_t DatasetType               =NULLTAG;
	tag_t DVAfoldertag              = NULLTAG;
	tag_t object_create_input_tag3  = NULLTAG;
	char*	foldername	            =NULL;
	char*	date					=NULL;
	char*	year					=NULL;
	char*	to						=NULL;
	char*	m						=NULL;
	char*	cMonth					=NULL;
	char*	fromdatevalue			=NULL;
	char*	toyear					=NULL;
	char*	toMonth					=NULL;
	char*	todatevalue				=NULL;
	char*	Releasestatus			=NULL;
	char*	objecttype1			=NULL;
	char*	DRstatusdml			=NULL;
	int f =0;
	int l =0;

   char*	VCtestDateRel2			=NULL;
   char*	DMLRelType2			=NULL;
   char*	DMLRelType1			=NULL;
   char*	DMLno1			=NULL;
   char*	VCColInd1			=NULL;
   char*	Releasestatus1			=NULL;
   char*	VCtestProgScale1			=NULL;
   char*	VCtestPlatform1			=NULL;
   char*	VCtestDescp1			=NULL;
   char*	VCtestrevid1			=NULL;
   char*	VCtestid1			=NULL;
   char*	VCtargetrevid1			=NULL;
   char*	VCtargetid1			=NULL;
   char*	Releasestatuspt1			=NULL;
   char*	VCDRstatus1			=NULL;
   char*	PartNum1			=NULL;
   char*	VCtestDateRel1			=NULL;

   tag_t DMLRevTag2                  =NULLTAG;
   tag_t VCRevTag1                  =NULLTAG;
   tag_t DMLtag2                  =NULLTAG;
   tag_t DMLtag1                  =NULLTAG;
   tag_t DMLRevTag1                  =NULLTAG;
  
   tag_t GCIRelationFind1                  =NULLTAG;
   tag_t DMLitemRevtag1                  =NULLTAG;
   tag_t DMLitemtag1                  =NULLTAG;
   tag_t* VCMainchld1                  =NULLTAG;

   tag_t* GCIObjectTag1                  =NULLTAG;


    int TestDMUscore1;
    int VCchldcount1= 0;
    int GCI_count1= 0;
	double TestDVAValue1;
	double TestGCIValue1;
	double GCIValue1;

	tag_t* FDJObjectTag1                  =NULLTAG;
	tag_t* VehicleTags2                  =NULLTAG;
	tag_t FDJRelationFind1                  =NULLTAG;
	tag_t VehicleTag2                  =NULLTAG;
	tag_t FDJObject1                  =NULLTAG;
	tag_t GCIObject1                  =NULLTAG;
	tag_t VCMain1                  =NULLTAG;
	tag_t DMLRevTag4                  =NULLTAG;
	tag_t DMLtag4                  =NULLTAG;
	char*	objecttype2			=NULL;
	char*	FDJStatus1			=NULL;
	int FDJ_count1=0;


	


	//int GCIcount=0;
	//int FDJcount=0;
	FILE* file=NULL;
	char fsuccess_nam[500];
	char *Csvpath=NULL;
	Csvpath = (char *)MEM_alloc(500);

    fromdatevalue = (char *)MEM_alloc(500);
    todatevalue = (char *)MEM_alloc(500);
	toMonth = (char *)malloc(500 * sizeof(char));
	cMonth = (char *)malloc(500 * sizeof(char));
	char *GCIDocPath=NULL;
	GCIDocPath = (char *)MEM_alloc(500);

	int vcattr =0;
	int sec_result_count =0;
	tag_t *statustags = NULLTAG;
	descDup = (char *)malloc(500 * sizeof(char));

	 char		*fromdate 		= NULL;
	 char		*Releasestatuspt 		= NULL;
	 char		*releasedate 		= NULL;
	 char		*statusname 		= NULL;
	 char		*todate 		= NULL;
     USERARG_get_string_argument(&fromdate);
	 USERARG_get_string_argument(&todate);

	 printf("\n Value of from date [%s]\n",fromdate); fflush(stdout);
	 printf("\n Value of to date [%s]\n",todate); fflush(stdout);


      tc_strtok(fromdate,"{");     ///[DateTime {8/5/2020}]
      m=tc_strtok(NULL,"/");


	  printf("\n value of m is ************** [%s]\n",m); fflush(stdout);
      date=tc_strtok(NULL,"/");

	  printf("\n value of date is ************** [%s]\n",date); fflush(stdout);
      year=tc_strtok(NULL,"}");

	   printf("\n value of year is ************** [%s]\n",year); fflush(stdout);



      if(tc_strcmp(m,"1")==0)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(tc_strcmp(m,"2")==0)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(tc_strcmp(m,"3")==0)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(tc_strcmp(m,"4")==0)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(tc_strcmp(m,"5")==0)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(tc_strcmp(m,"6")==0)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(tc_strcmp(m,"7")==0)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(tc_strcmp(m,"8")==0)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(tc_strcmp(m,"9")==0)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(tc_strcmp(m,"10")==0)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(tc_strcmp(m,"11")==0)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(tc_strcmp(m,"12")==0)
	  {
		tc_strcpy(cMonth,"Dec");
	  }



     tc_strcpy(fromdatevalue,"");
     tc_strcat(fromdatevalue,date);
     tc_strcat(fromdatevalue,"-");
     tc_strcat(fromdatevalue,cMonth);
     tc_strcat(fromdatevalue,"-");
     tc_strcat(fromdatevalue,year);

     printf("\n value of from date is ************** [%s]\n",fromdatevalue); fflush(stdout);


      tc_strtok(todate,"{");     ///[DateTime {8/5/2020}]
      to=tc_strtok(NULL,"/");

	  printf("\n value of to is ************** [%s]\n",to); fflush(stdout);
      todate=tc_strtok(NULL,"/");

	  printf("\n value of todate is ************** [%s]\n",todate); fflush(stdout);
      toyear=tc_strtok(NULL,"}");

	  printf("\n value of toyear is ************** [%s]\n",toyear); fflush(stdout);



      if(tc_strcmp(to,"1")==0)
	  {
		tc_strcpy(toMonth,"Jan");
	  }
	  else if(tc_strcmp(to,"2")==0)
	  {
		tc_strcpy(toMonth,"Feb");
	  }
	  else if(tc_strcmp(to,"3")==0)
	  {
		tc_strcpy(toMonth,"Mar");
	  }
	  else if(tc_strcmp(to,"4")==0)
	  {
		tc_strcpy(toMonth,"Apr");
	  }
	  else if(tc_strcmp(to,"5")==0)
	  {
		tc_strcpy(toMonth,"May");
	  }
	  else if(tc_strcmp(to,"6")==0)
	  {
		tc_strcpy(toMonth,"Jun");
	  }
	  else if(tc_strcmp(to,"7")==0)
	  {
		tc_strcpy(toMonth,"Jul");
	  }
	  else if(tc_strcmp(to,"8")==0)
	  {
		tc_strcpy(toMonth,"Aug");
	  }
	  else if(tc_strcmp(to,"9")==0)
	  {
		tc_strcpy(toMonth,"Sep");
	  }
	  else if(tc_strcmp(to,"10")==0)
	  {
		tc_strcpy(toMonth,"Oct");
	  }
	  else if(tc_strcmp(to,"11")==0)
	  {
		tc_strcpy(toMonth,"Nov");
	  }
	  else if(tc_strcmp(to,"12")==0)
	  {
		tc_strcpy(toMonth,"Dec");
	  }

     tc_strcpy(todatevalue,"");
     tc_strcat(todatevalue,todate);
     tc_strcat(todatevalue,"-");
     tc_strcat(todatevalue,toMonth);
     tc_strcat(todatevalue,"-");
     tc_strcat(todatevalue,toyear);


    printf("\n value of To date date is11 ************** [%s]\n",todatevalue); fflush(stdout);

	/*n_entries = 5;

	char *qry_entries[5] = {"Part Type","AR/DR Status","CCVC No","From date","To Date"};
	char **qry_values = (char **) MEM_alloc(60 * sizeof(char *));

	qry_values[0] = "Vehicle";
	qry_values[1] = "DR3";
	qry_values[2] = "Configurable VC";
	qry_values[3] = fromdatevalue;
	qry_values[4] = todatevalue;*/
	
	n_entries = 3;
	char *qry_entries[3] = {"Name","date_released_after","date_released_before"};
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	qry_values[0] = "T5_LcsErcRlzd";
	qry_values[1] = fromdatevalue;
	qry_values[2] = todatevalue;
	

	/*qry_values[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
	strcpy(qry_values[0], "T5_LcsErcRlzd" );

	//qry_values[1] = (char *)MEM_alloc( strlen( "01-Mar-2021 00:00" ) + 1);
	qry_values[1] = (char *)MEM_alloc( strlen( fromdate ) + 1);
	//strcpy(qry_values[1], "01-Mar-2021 00:00"  );
	strcpy(qry_values[1], fromdate  );

	//qry_values[2] = (char *)MEM_alloc( strlen( "04-Mar-2021 00:00" ) + 1);
	qry_values[2] = (char *)MEM_alloc( strlen( todate ) + 1);
	//strcpy(qry_values[2], "04-Mar-2021 00:00"  );
	strcpy(qry_values[2], todate  );*/


	ITK_CALL(POM_get_user(&username,&user_tag));
	printf("\n\n username :%s\n",username);fflush(stdout);

	ITK_CALL(SA_ask_user_home_folder(user_tag,&homefoldertag));

    ITK_CALL(FL_ask_sort_criteria(homefoldertag,&flcriteria));
			documentName = NULL;
			documentName = (char *)MEM_alloc(100);

			//tc_strcpy(documentName, "");
			tc_strcpy(documentName, "");
			tc_strcat(documentName, "WCQ Result 7 Report");
			tc_strcat(documentName, "_");
			tc_strcat(documentName, "From_");
			tc_strcat(documentName, fromdatevalue);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, "TO");
			tc_strcat(documentName, "_");
			tc_strcat(documentName, todatevalue);

			ITK_CALL(FL_ask_references(homefoldertag,flcriteria,&refcount,&reflist));
			printf("\n the refrence count is*** :[%d]\n",refcount);   fflush(stdout);

		     int DVAreportflag = 0;

			for(f=0;f<refcount;f++)
			{
				reflist2=reflist[f];

				ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

				if(tc_strcmp(foldername,"WCQ Result 7 Report")==0)
				{

					printf("\n\n Folder is already available\n");fflush(stdout);

				   /*ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
				   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
				   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
				   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
				   ITK_CALL(AOM_save_with_extensions(dad_tag));

				   ITK_CALL(AOM_lock(dad_tag));


				   ITK_CALL(FL_insert(reflist2,dad_tag,000));
				   ITK_CALL(AOM_save_with_extensions(reflist2));


				   ITK_CALL(AOM_refresh(dad_tag, TRUE));

				   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

				   ITK_CALL(AE_save_myself(dad_tag));*/

				   DVAreportflag++;


				  //ITK_CALL(FL_insert(reflist2,file_tag,999));

				}
				else
				{
					//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

				}

			}

		
	         //printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);

  
	  if(DVAreportflag==0)
	  {
		  printf("\n\n INside folder creation condition :%s\n");fflush(stdout);

		ITK_CALL(TCTYPE_find_type( "Folder",NULL, &DVAfoldertypetag));
		ITK_CALL(TCTYPE_construct_create_input(DVAfoldertypetag, &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name","WCQ Result 7 Report"));

		ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&DVAfoldertag));

		ITK_CALL(AOM_save_with_extensions(DVAfoldertag));

		ITK_CALL(FL_insert(homefoldertag,DVAfoldertag,999));
		ITK_CALL(AOM_save_with_extensions(homefoldertag));

		  //(FL_insert(reflist2,file_tag,999))
	  }


    /*if(QRY_find2("Vehicle DR3", &queryTag1));
	printf("\n After DR3 Vehicle : QRY_find2 \n");fflush(stdout);
	if (queryTag1)
	{
		printf("\n Found Query DR3 Vehicle  \n");fflush(stdout);
	}
	else
	{
		printf("\n NotFound Query DR3 Vehicle");fflush(stdout);
		//goto CLEANUP;
	}*/

	//if(QRY_execute(queryTag1, n_entries, qry_entries, qry_values, &resultCount, &VehicleTags));

   //  printf("\t resultCount :%d:\n", resultCount);fflush(stdout);

    

		
	n_entries1 = 3;
	char *qry_entries1[3] = {"Name","date_released_after","date_released_before"};
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	qry_values1[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
	strcpy(qry_values1[0], "T5_LcsErcRlzd" );

	//qry_values[1] = (char *)MEM_alloc( strlen( "01-Mar-2021 00:00" ) + 1);
	qry_values1[1] = (char *)MEM_alloc( strlen( fromdate ) + 1);
	//strcpy(qry_values[1], "01-Mar-2021 00:00"  );
	strcpy(qry_values1[1], fromdate  );

	//qry_values[2] = (char *)MEM_alloc( strlen( "04-Mar-2021 00:00" ) + 1);
	qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
	//strcpy(qry_values[2], "04-Mar-2021 00:00"  );
	strcpy(qry_values1[2], todate  );

   


	if(QRY_find2("ERCDMLReleased", &queryTag));
	printf("\n After ERCDMLReleased : QRY_find2 \n");fflush(stdout);
	if (queryTag)
	{
		printf("\n Found Query ERCDMLReleased  \n");fflush(stdout);
	}
	else
	{
		printf("\n NotFound Query ERCDMLReleased");fflush(stdout);
		//goto CLEANUP;
	}

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ERCDMLTags));

	

    printf("\t resultCount :%d:\n", resultCount);fflush(stdout);
    printf("\t resultCount1 :%d:\n", resultCount11);fflush(stdout);


    ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path",0,&GCIDocPath));
	printf("\n GCIDocPath :[%s]\n",GCIDocPath); fflush(stdout);
	tc_strcpy(Csvpath,"");
   // tc_strcpy(Csvpath,"/user/uaprodtrl/4D_updation_shell/");
    tc_strcpy(Csvpath,GCIDocPath);
	sprintf(fsuccess_nam,"WCQ_Result_7_Report_From_%s_To_%s.csv",fromdatevalue,todatevalue);
	tc_strcat(Csvpath,fsuccess_nam);
	printf("\n file path is*** :[%s]\n",Csvpath); fflush(stdout);
	file = fopen(Csvpath,"w");

	if(file!=NULL)
	{
		printf("\n file is opening\n");   fflush(stdout);	
	}
	else
	{
		printf("\n file is not opening\n");   fflush(stdout);	
	}

	fprintf(file,"VC No.(released* & WIP),VC description,Rev Seq.,Platform,Program Scale,Release Date,DML No.,DML Type,DVA index(D),DMU Demerit Score(S),GCI(A)\n");

if (resultCount>0)
	{

		for(i=0;i<resultCount;i++)
		{

				ERCDMLTag = ERCDMLTags[i];

				if(TCTYPE_ask_object_type(ERCDMLTag,&objTypeTag));
			    if(TCTYPE_ask_name2 (objTypeTag,&type_name));
				//if(strcmp(type_name,"ChangeRequestRevision")==0)
	       
            if(tc_strcmp(type_name,"ChangeRequestRevision")==0)
	       {


				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"item_id",&DmlId));

                printf("\nDML Numbers *****: %s\n",DmlId);fflush(stdout);
				tc_strdup(DmlId,&DmlIdDup);
				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_rlstype",&DmlRelType));
				tc_strdup(DmlRelType,&DmlRelTypeDup);
				ITK_CALL(AOM_UIF_ask_value(ERCDMLTag,"release_status_list",&DmlRelStat));
				ITK_CALL(AOM_UIF_ask_value(ERCDMLTag,"t5_cDRstatus",&DRstatusdml));
				printf("\n DML DR status is  %s\n", DRstatusdml);fflush(stdout);
				tc_strdup(DmlRelStat,&DmlRelStatDup);
				
				if(tc_strcmp(DRstatusdml,"DR3")==0)
			   {
				if(tc_strcmp(DmlRelTypeDup,"Veh")==0)
				{

					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count: %d\n",tskcnt);fflush(stdout);

			   if (tskcnt>0)
		       {

				   

			    for(t=0;t<tskcnt;t++)
			   {

			    taskdmlno=NULL;
				ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
				printf("\nDML Task [%s]",TaskId);fflush(stdout);

				if (tc_strstr(TaskId,"_00")==NULL)
				{
					printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					continue;
				}

				AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&VehicleTags);
				printf("\nNo of Design Rev=%d\n",partCnt);
				printf("\nDML Task [%s]",TaskId);fflush(stdout);

				taskdmlno=tc_strtok(TaskId,"_");
				 ITK_CALL(ITEM_find_item (taskdmlno,&DMLitemtag));
				 
				ITK_CALL(ITEM_ask_latest_rev(DMLitemtag,&DMLitemRevtag));
				ITK_CALL(AOM_UIF_ask_value(DMLitemRevtag,"date_released",&VCtestDateRel));

		    if (partCnt>0)
			{
			    for(p=0;p<partCnt;p++)
				{

			   VehicleTag1 = VehicleTags[p];

				ITK_CALL(AOM_ask_value_string(VehicleTag1,"item_id",&PartNum));
										
				ITK_CALL(AOM_ask_value_string(VehicleTag1,"item_revision_id",&PartRev));
				


				ITK_CALL(ITEM_find_item (PartNum,&VCMain));
				printf("\n Vehicle No -------->[%s]",PartNum); fflush(stdout);

				ITK_CALL(ITEM_list_all_revs(VCMain,&VCchldcount,&VCMainchld));

				if (VCchldcount>0)
				{
					DR3count=0;
					for(j=0;j<VCchldcount;j++)
					{

						ITK_CALL(AOM_ask_value_string(VCMainchld[j],"t5_PartStatus",&VCDRstatus));
						printf("\n vehicle DR status is [%s]\n",VCDRstatus); fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(VCMainchld[j],"release_status_list",&Releasestatuspt));
						printf("\n vehicle Release status [%s]\n",Releasestatuspt); fflush(stdout);

						if (tc_strcmp(VCDRstatus,"DR3")==0)
						{
							if(tc_strstr(Releasestatuspt,"ERC Released")!=NULL)
							{
								DR3count++;

								ITK_CALL(AOM_ask_value_string(VCMainchld[j],"item_id",&VCtargetid));
								ITK_CALL(AOM_ask_value_string(VCMainchld[j],"item_revision_id",&VCtargetrevid));

							}

						}
						
					}

					if(DR3count==1)
					{

						printf("\n DR3 count is equal to 1........\n"); fflush(stdout);
						printf("\n vehicle to be checked for further process......................... [%s][%s]\n",VCtargetid,VCtargetrevid); fflush(stdout);

						ITK_CALL(ITEM_find_rev(VCtargetid,VCtargetrevid,&VCRevTag));

						ITK_CALL(AOM_ask_value_string(VCRevTag,"item_id",&VCtestid));	
						ITK_CALL(AOM_ask_value_string(VCRevTag,"item_revision_id",&VCtestrevid));
						ITK_CALL(AOM_ask_value_string(VCRevTag,"object_desc",&VCtestDescp));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"t5_Platform",&VCtestPlatform));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"t5_ProgramScale",&VCtestProgScale));
						//ITK_CALL(AOM_UIF_ask_value(VCRevTag,"date_released",&VCtestDateRel));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"release_status_list",&Releasestatus));
						if(AOM_ask_value_string(VCRevTag,"t5_ColourInd",&VCColInd));

						printf("colour ind is :%s\n",VCColInd);fflush(stdout);
						printf("\n testing......................... [%s],[%s]\n",VCtestid,VCtestrevid); fflush(stdout);


					 if(tc_strstr(Releasestatus,"ERC Released")!=NULL)
					 {
						 tc_strcat(VCtestid,"*");

					 }

					flag=0;

				 /*  if(tc_strstr(Releasestatus,"APLC Released")!=NULL || tc_strstr(Releasestatus,"STDSIC Released")!=NULL || tc_strstr(Releasestatus,"APLC Working")!=NULL || tc_strstr(Releasestatus,"APLJ Working")!=NULL)	
				   {

					  flag=1;
					  printf("\n Inside APLC Released and STDSIC Released \n");fflush(stdout);
				   }*/

						

                  if(flag==0)	
				  {
						if (tc_strcmp(VCColInd,"C")!=0)
						{
							ITK_CALL(GRM_find_relation_type("T5_AssmhasFDJ", &FDJRelationFind));   
							if (FDJRelationFind!=NULLTAG)
							{

								ITK_CALL(GRM_list_secondary_objects_only(VCRevTag, FDJRelationFind, &FDJ_count, &FDJObjectTag));
								printf("\n FDJ_count********** [%d]\n",FDJ_count); fflush(stdout);

								if(FDJ_count>0)
								{

										for(fdj=0;fdj<FDJ_count;fdj++)
										{

											FDJObject=FDJObjectTag[fdj];

											ITK_CALL(AOM_ask_value_string(FDJObject,"t5_FDJStatus",&FDJStatus));
											printf("\n FDJStatus [%s]\n",FDJStatus); fflush(stdout);


											FDJapprove=0;
											if(tc_strcmp(FDJStatus,"FDJ Approved")==0)
											{

												FDJcount++;
											 
												printf("\n ***FDJ is Approved***\n"); fflush(stdout);

												FDJapprove=1;


											}

											if(FDJapprove>0)
											{

												ITK_CALL(GRM_find_relation_type("T5_GCI_relation", &GCIRelationFind));

												ITK_CALL(GRM_list_secondary_objects_only(VCRevTag, GCIRelationFind, &GCI_count, &GCIObjectTag));
												printf("\n GCI_count********** [%d]\n",GCI_count); fflush(stdout);

 
												for(gci=0;gci<GCI_count;gci++)
												{

													GCIObject=GCIObjectTag[gci];

													ITK_CALL(AOM_ask_value_string(GCIObject,"object_type",&objecttype1));
													printf("\n object type of Document is [%s]\n",objecttype1); fflush(stdout);

													if((tc_strcmp(objecttype1,"T5_GCI_Document")==0 || tc_strcmp(objecttype1,"GCI Document")==0 ))
													{

													ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&GCIValue));
													printf("\n GCIValue [%f]\n",GCIValue); fflush(stdout);

													if (GCIValue>90)
													{
														GCIcount++;
														printf("\n ***************GCI value is greater than 90*********************** \n"); fflush(stdout);

													}

														ITK_CALL(AOM_ask_value_string(GCIObject,"t5_DVLODmlNo1",&DMLno));
														printf("\n DMLno [%s]\n",DMLno); fflush(stdout);

														if(taskdmlno!=NULL)
														{

															ITK_CALL(ITEM_find_item (taskdmlno,&DMLtag));
															ITK_CALL(ITEM_ask_latest_rev(DMLtag, &DMLRevTag));
															//ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"CMClosureDate",&VCtestDateRel));
															ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLRelType));
															//printf("\n DMLRelType [%s] CMClosureDate [%s] taskdmlno [%s]\n",DMLRelType,VCtestDateRel,taskdmlno); fflush(stdout);


														}

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&TestGCIValue));
								
														printf("\n GCIValue [%f]\n",TestGCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_DVA_value_d1",&TestDVAValue));
								
														printf("\n TestDVAValue [%f]\n",TestDVAValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCIObject,"t5_demerit_score_rating_S1",&TestDMUscore));
								
														printf("\n TestDMUscore [%d]\n",TestDMUscore); fflush(stdout);

														

														printf("\n VCtestid [%s] VCtestDescp [%s] VCtestrevid [%s]  VCtestPlatform [%s] VCtestProgScale [%s] VCtestDateRel [%s] taskdmlno[%s] DMLRelType[%s] TestDVAValue[%f] TestDMUscore[%d] TestGCIValue[%f]\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,taskdmlno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);fflush(stdout);
														fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,taskdmlno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);



													}
													/*else
													{

													    ITK_CALL(AOM_ask_value_string(GCIObject,"t5_DVLODmlNo1",&DMLno));
														printf("\n DMLno [%s]\n",DMLno); fflush(stdout);

														if(DMLno!=NULL)
														{

															ITK_CALL(ITEM_find_item (DMLno,&DMLtag));
															ITK_CALL(ITEM_ask_latest_rev(DMLtag, &DMLRevTag));
															ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLRelType));
															printf("\n DMLRelType [%s]\n",DMLRelType); fflush(stdout);


														}

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&TestGCIValue));
								
														printf("\n GCIValue 1 [%f]\n",GCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_DVA_value_d1",&TestDVAValue));
								
														printf("\n TestDVAValue 1 [%f]\n",GCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCIObject,"t5_demerit_score_rating_S1",&TestDMUscore));
								
														printf("\n TestDVAValue 1 [%d]\n",TestDMUscore); fflush(stdout);

														//GCIcount++;
														printf("\n ***************GCI value is Less than 85***********************\n"); fflush(stdout);

													  
                                                       printf("\n VCtestid [%s] VCtestDescp [%s] VCtestrevid [%s]  VCtestPlatform [%d] VCtestProgScale [%s] VCtestDateRel [%s] DMLno[%s] DMLRelType[%s] TestDVAValue[%f] TestDMUscore[%d] TestGCIValue[%f] \n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);fflush(stdout);
													  fprintf(file,"%s,%s,%s,%d,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);
													}*/
												   
												}
												if(GCI_count==0)
												{
													ITK_CALL(ITEM_find_item (taskdmlno,&DMLtag4));
													ITK_CALL(ITEM_ask_latest_rev(DMLtag4, &DMLRevTag4));
													ITK_CALL(AOM_UIF_ask_value(DMLRevTag4,"date_released",&VCtestDateRel));
													printf("\n GCI_count Release Date is[%s]\n",VCtestDateRel);fflush(stdout);
													
													printf("\n CMClosureDate [%s] taskdmlno [%s]\n",VCtestDateRel,taskdmlno); fflush(stdout);
													printf("\n ***************GCI Object Not found Condition***********************\n"); fflush(stdout);												
												    //fprintf(file,"%s,%s,%s,%d,%s,%s\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,DMLRelType);
													fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,taskdmlno,DMLRelType);											
												
												}


											}
														
										
										  }								
								
								}
							
							}


						}
				}
				else
				{
					printf("\n Part Status is not ERC release or ERC review"); fflush(stdout);
				}
			}
			else
			{
							printf("\n DR3 count is more than one........"); fflush(stdout);

			}

				}
			}
				}
		}
				}
			   }
			   else if(tc_strcmp(DmlRelTypeDup,"TODR")==0)
				{

				   printf("\n Inside TODR     >>>>>>>>>\n");fflush(stdout);

					int tskcnt =0,t=0,p=0,j=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					char *object_type=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count TODRRR: %d\n",tskcnt);fflush(stdout);

					

					

			   if (tskcnt>0)
		       {
				   printf("\n inside TODR \n");fflush(stdout);

			    for(t=0;t<tskcnt;t++)
			   {
					printf("\n Inside loop TODR\n");fflush(stdout);

			    taskdmlno=NULL;
				ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
				printf("\nDML Task54545 [%s]",TaskId);fflush(stdout);

				if (tc_strstr(TaskId,"_00")==NULL)
				{
					printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					continue;
				}

				AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMReferences",&partCnt,&VehicleTags2);
				printf("\nNo of Design Rev555=%d\n",partCnt);
				printf("\nDML Task [%s]",TaskId);fflush(stdout);

				taskdmlno=tc_strtok(TaskId,"_");
				 ITK_CALL(ITEM_find_item (taskdmlno,&DMLitemtag1));
				 
				ITK_CALL(ITEM_ask_latest_rev(DMLitemtag1,&DMLitemRevtag1));
				ITK_CALL(AOM_UIF_ask_value(DMLitemRevtag1,"date_released",&VCtestDateRel1));
				printf("\n VCtestDateRel1 TODR date_released [%s]",VCtestDateRel1);fflush(stdout);

		    if (partCnt>0)
			{
			    for(p=0;p<partCnt;p++)
				{
					printf("\n inside loop partCnt \n");fflush(stdout);

			   VehicleTag2 = VehicleTags2[p];


			   ITK_CALL(AOM_ask_value_string(VehicleTag2,"object_type",&object_type));
				printf("\n VC TODR object_type  [%s]",object_type);fflush(stdout);


				if(tc_strcmp(object_type,"Design Revision")==0)
				{

				ITK_CALL(AOM_ask_value_string(VehicleTag2,"item_id",&PartNum1));
				printf("\n VC TODR item id  [%s]",PartNum1);fflush(stdout);
										
				ITK_CALL(AOM_ask_value_string(VehicleTag2,"item_revision_id",&PartRev));
				printf("\n Vehicle PartRev -->[%s]",PartRev); fflush(stdout);

				ITK_CALL(ITEM_find_item (PartNum1,&VCMain1));
				printf("\n Vehicle No -----oooo--->[%s]",PartNum1); fflush(stdout);

				ITK_CALL(ITEM_list_all_revs(VCMain1,&VCchldcount1,&VCMainchld1));

				if (VCchldcount1>0)
				{
					DR3count=0;
					for(j=0;j<VCchldcount1;j++)
					{
						printf("\n inside loop VCchldcount1 \n");fflush(stdout);

						ITK_CALL(AOM_ask_value_string(VCMainchld1[j],"t5_PartStatus",&VCDRstatus1));
						printf("\n vehicle DR VCDRstatus1 is ------> [%s]\n",VCDRstatus1); fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(VCMainchld1[j],"release_status_list",&Releasestatuspt1));
						printf("\n vehicle Release Releasestatuspt1 ------> [%s]\n",Releasestatuspt1); fflush(stdout);
			

						if (tc_strcmp(VCDRstatus1,"DR3")==0)
						{
							if(tc_strstr(Releasestatuspt1,"ERC Released")!=NULL)
							{
								printf("\n inside loop Releasestatuspt1 \n");fflush(stdout);

							DR3count++;

							ITK_CALL(AOM_ask_value_string(VCMainchld1[j],"item_id",&VCtargetid1));
							printf("\n vehicle DR VCtargetid1 is ------> [%s]\n",VCtargetid1); fflush(stdout);
							ITK_CALL(AOM_ask_value_string(VCMainchld1[j],"item_revision_id",&VCtargetrevid1));
							printf("\n vehicle DR VCtargetrevid1 is ------> [%s]\n",VCtargetrevid1); fflush(stdout);

							}

						}
						
					}

					if(DR3count==1)
					{

						printf("\n DR3 count is equal to 1........\n"); fflush(stdout);
						printf("\n vehicle to be checked for further process......................... [%s][%s]\n",VCtargetid,VCtargetrevid); fflush(stdout);

						ITK_CALL(ITEM_find_rev(VCtargetid1,VCtargetrevid1,&VCRevTag1));

						ITK_CALL(AOM_ask_value_string(VCRevTag1,"item_id",&VCtestid1));
						printf("\n VCtestid1 is :%s\n",VCtestid1);fflush(stdout);

						ITK_CALL(AOM_ask_value_string(VCRevTag1,"item_revision_id",&VCtestrevid1));
						printf("\n VCtestrevid1 is :%s\n",VCtestrevid1);fflush(stdout);

						ITK_CALL(AOM_ask_value_string(VCRevTag1,"object_desc",&VCtestDescp1));
						printf("\n VCtestDescp1 is :%s\n",VCtestDescp1);fflush(stdout);

						ITK_CALL(AOM_UIF_ask_value(VCRevTag1,"t5_Platform",&VCtestPlatform1));
						printf("\n VCtestPlatform1 is :%s\n",VCtestPlatform1);fflush(stdout);

						ITK_CALL(AOM_UIF_ask_value(VCRevTag1,"t5_ProgramScale",&VCtestProgScale1));
						printf("\n VCtestProgScale1 is :%s\n",VCtestProgScale1);fflush(stdout);

						//ITK_CALL(AOM_UIF_ask_value(VCRevTag,"date_released",&VCtestDateRel));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag1,"release_status_list",&Releasestatus1));
						printf("\n Releasestatus1 is :%s\n",Releasestatus1);fflush(stdout);

						if(AOM_ask_value_string(VCRevTag1,"t5_ColourInd",&VCColInd1));
						printf("\n colour VCColInd1 is :%s\n",VCColInd1);fflush(stdout);
						


					 if(tc_strstr(Releasestatus1,"ERC Released")!=NULL)
					 {
						 tc_strcat(VCtestid1,"*");

					 }

					flag=0;

				 /*  if(tc_strstr(Releasestatus,"APLC Released")!=NULL || tc_strstr(Releasestatus,"STDSIC Released")!=NULL || tc_strstr(Releasestatus,"APLC Working")!=NULL || tc_strstr(Releasestatus,"APLJ Working")!=NULL)	
				   {

					  flag=1;
					  printf("\n Inside APLC Released and STDSIC Released \n");fflush(stdout);
				   }*/

						

                  if(flag==0)	
				  {
						if (tc_strcmp(VCColInd1,"C")!=0)
						{
							ITK_CALL(GRM_find_relation_type("T5_AssmhasFDJ", &FDJRelationFind1));   
							if (FDJRelationFind1!=NULLTAG)
							{

								ITK_CALL(GRM_list_secondary_objects_only(VCRevTag1, FDJRelationFind1, &FDJ_count1, &FDJObjectTag1));
								printf("\n FDJ_count1********** [%d]\n",FDJ_count1); fflush(stdout);

								if(FDJ_count1>0)
								{

										for(fdj=0;fdj<FDJ_count1;fdj++)
										{

											FDJObject1=FDJObjectTag1[fdj];

											ITK_CALL(AOM_ask_value_string(FDJObject1,"t5_FDJStatus",&FDJStatus1));
											printf("\n FDJStatus [%s]\n",FDJStatus1); fflush(stdout);


											FDJapprove=0;
											if(tc_strcmp(FDJStatus1,"FDJ Approved")==0)
											{

												FDJcount++;
											 
												printf("\n ***FDJ is Approved***\n"); fflush(stdout);

												FDJapprove=1;


											}

											if(FDJapprove>0)
											{

												ITK_CALL(GRM_find_relation_type("T5_GCI_relation", &GCIRelationFind1));

												ITK_CALL(GRM_list_secondary_objects_only(VCRevTag1, GCIRelationFind1, &GCI_count1, &GCIObjectTag1));
												printf("\n GCI_count1********** [%d]\n",GCI_count1); fflush(stdout);

 
												for(gci=0;gci<GCI_count1;gci++)
												{

													GCIObject1=GCIObjectTag1[gci];

													ITK_CALL(AOM_ask_value_string(GCIObject1,"object_type",&objecttype2));
													printf("\n objecttype2 type of Document is [%s]\n",objecttype2); fflush(stdout);

													if((tc_strcmp(objecttype2,"T5_GCI_Document")==0 || tc_strcmp(objecttype2,"GCI Document")==0 ))
													{

													ITK_CALL(AOM_ask_value_double(GCIObject1,"t5_geometry_conf_index_a1",&GCIValue1));
													printf("\n GCIValue1 [%f]\n",GCIValue1); fflush(stdout);

													if (GCIValue1>90)
													{
														GCIcount++;
														printf("\n ***************GCI value is greater than 90*********************** \n"); fflush(stdout);

													}

														ITK_CALL(AOM_ask_value_string(GCIObject1,"t5_DVLODmlNo1",&DMLno1));
														printf("\n DMLno1 [%s]\n",DMLno1); fflush(stdout);

														if(taskdmlno!=NULL)
														{

															ITK_CALL(ITEM_find_item (taskdmlno,&DMLtag1));
															ITK_CALL(ITEM_ask_latest_rev(DMLtag1, &DMLRevTag1));
															ITK_CALL(AOM_ask_value_string(DMLRevTag1,"t5_rlstype",&DMLRelType1));
															printf("\n DML DMLRelType1  [%s]\n",DMLRelType1); fflush(stdout);
															/*ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"CMClosureDate",&VCtestDateRel));
				                                            printf("\nVCtestDateRel TODR [%s],[%s]",VCtestDateRel,taskdmlno);fflush(stdout);
															printf("\n DMLRelType [%s]\n",DMLRelType); fflush(stdout);*/


														}

														ITK_CALL(AOM_ask_value_double(GCIObject1,"t5_geometry_conf_index_a1",&TestGCIValue1));
								
														printf("\n TestGCIValue1 [%f]\n",TestGCIValue1); fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIObject1,"t5_DVA_value_d1",&TestDVAValue1));
								
														printf("\n TestDVAValue1 [%f]\n",TestDVAValue1); fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCIObject1,"t5_demerit_score_rating_S1",&TestDMUscore1));
								
														printf("\n TestDMUscore1 [%d]\n",TestDMUscore1); fflush(stdout);

														

														printf("\n VCtestid1 [%s] VCtestDescp1 [%s] VCtestrevid1 [%s]  VCtestPlatform1 [%s] VCtestProgScale1 [%s] VCtestDateRel1 [%s] taskdmlno[%s] DMLRelType1[%s] TestDVAValue1[%f] TestDMUscore1[%d] TestGCIValue1[%f]\n",VCtestid1,VCtestDescp1,VCtestrevid1,VCtestPlatform1,VCtestProgScale1,VCtestDateRel1,taskdmlno,DMLRelType1,TestDVAValue1,TestDMUscore1,TestGCIValue1);fflush(stdout);
														//fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid,VCtestDescp,VCtestrevid1,VCtestPlatform1,VCtestProgScale1,VCtestDateRel1,DMLno,DMLRelType1,TestDVAValue1,TestDMUscore1,TestGCIValue1);
                                                        fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid1,VCtestDescp1,VCtestrevid1,VCtestPlatform1,VCtestProgScale1,VCtestDateRel1,taskdmlno,DMLRelType1,TestDVAValue1,TestDMUscore1,TestGCIValue1);


													}
													/*else
													{

													    ITK_CALL(AOM_ask_value_string(GCIObject,"t5_DVLODmlNo1",&DMLno));
														printf("\n DMLno [%s]\n",DMLno); fflush(stdout);

														if(DMLno!=NULL)
														{

															ITK_CALL(ITEM_find_item (DMLno,&DMLtag));
															ITK_CALL(ITEM_ask_latest_rev(DMLtag, &DMLRevTag));
															ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLRelType));
															printf("\n DMLRelType [%s]\n",DMLRelType); fflush(stdout);


														}

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&TestGCIValue));
								
														printf("\n GCIValue 1 [%f]\n",GCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_DVA_value_d1",&TestDVAValue));
								
														printf("\n TestDVAValue 1 [%f]\n",GCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCIObject,"t5_demerit_score_rating_S1",&TestDMUscore));
								
														printf("\n TestDVAValue 1 [%d]\n",TestDMUscore); fflush(stdout);

														//GCIcount++;
														printf("\n ***************GCI value is Less than 85***********************\n"); fflush(stdout);

													  
                                                       printf("\n VCtestid [%s] VCtestDescp [%s] VCtestrevid [%s]  VCtestPlatform [%d] VCtestProgScale [%s] VCtestDateRel [%s] DMLno[%s] DMLRelType[%s] TestDVAValue[%f] TestDMUscore[%d] TestGCIValue[%f] \n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);fflush(stdout);
													  fprintf(file,"%s,%s,%s,%d,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);
													}*/
												   
												}
												if(GCI_count1==0)
												{
													ITK_CALL(ITEM_find_item (taskdmlno,&DMLtag2));
												    ITK_CALL(ITEM_ask_latest_rev(DMLtag2, &DMLRevTag2));
												    ITK_CALL(AOM_ask_value_string(DMLRevTag2,"t5_rlstype",&DMLRelType2));
												    ITK_CALL(AOM_UIF_ask_value(DMLRevTag2,"date_released",&VCtestDateRel2));
													//printf("\n GCI_count date_released 8i is[%d]\n",VCtestDateRel2);fflush(stdout);
				                                    printf("\nVCtestDateRel TODR [%s],date_released[%s]",VCtestDateRel2,taskdmlno);fflush(stdout);
													printf("\n ***************GCI Object Not found Condition***********************\n"); fflush(stdout);												
												   // fprintf(file,"%s,%s,%s,%d,%s,%s\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel);
													fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s\n",VCtestid1,VCtestDescp1,VCtestrevid1,VCtestPlatform1,VCtestProgScale1,VCtestDateRel2,taskdmlno,DMLRelType2);											
												
												}


											}
														
										
										  }								
								
								}
							
							}


						}
				}
				else
				{
					printf("\n Part Status is not ERC release or ERC review"); fflush(stdout);
				}
			}
			else
			{
							printf("\n DR3 count is more than one........"); fflush(stdout);

			}

				}
				}
			}
				}
		}
				}

				}



		   }
							
	}
}
	}


	printf("\n The value of count%d\n",EligibleVCatDR3);fflush(stdout);
	printf("\n FDJcount [%d]",FDJcount); fflush(stdout);
	printf("\n GCIcount [%d]",GCIcount); fflush(stdout);

	WCQfinal=FDJCalulate();
	printf("\n WCQfinal [%s]..................................................................",WCQfinal); fflush(stdout);
    fprintf(file,"\n\n\n\n\n\n (WCQ Result 7 = No. of Eligible VCs at DR3 with GCI > 90%) / (No. of Eligible VCs at DR3 for WCQ Result 7) * 100\n");
	fprintf(file,"\nNo. of Eligible VCs at DR3 with GCI > 90= %d\nNo. of Eligible VCs at DR3 for WCQ Result 7 = %d\n",GCIcount,FDJcount);
	fprintf(file,"WCQ RESULT 7 = %s\n",WCQfinal);

	fclose(file);



	   for(f=0;f<refcount;f++)
		{
			reflist2=reflist[f];

			ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

			if(tc_strcmp(foldername,"WCQ Result 7 Report")==0)
			{

				printf("\n\n Folder is already created condition\n");fflush(stdout);

			   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
			   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
			   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
			   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
			   ITK_CALL(AOM_save_with_extensions(dad_tag));

			   //ITK_CALL(AOM_lock(dad_tag));
			   
               printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);
			   ITK_CALL(AOM_refresh(dad_tag, TRUE));

			   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

			   printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);

			   ITK_CALL(AE_save_myself(dad_tag));

			   printf("\n\n inside DVA Reports condition5454545454545488888888 :\n");fflush(stdout);

			   ITK_CALL(FL_insert(reflist2,dad_tag,000));
			   ITK_CALL(AOM_save_with_extensions(reflist2));
			   printf("\n\n inside DVA Reports condition545454545454545566 :\n");fflush(stdout);

			    DVAreportflag1 =1;


			  //ITK_CALL(FL_insert(reflist2,file_tag,999));

			}
			else
			{
				//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

			}

		}

	  if(DVAreportflag1 == 0)
	  {
		   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
		   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
		   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
		   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
		   ITK_CALL(AOM_save_with_extensions(dad_tag));

		   //ITK_CALL(AOM_lock(dad_tag));
		   //ITK_CALL(FL_insert(homefoldertag,dad_tag,000));
		    printf("\n\n inside dataset attach condition 2222222222222:\n");fflush(stdout);



		   ITK_CALL(AOM_refresh(dad_tag, TRUE));

		   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

		  // ITK_CALL(AE_save_myself(dad_tag)); 
		   ITK_CALL(AOM_save_with_extensions(dad_tag)); 

		   printf("\n\n inside dataset attach condition54545454545454 :\n");fflush(stdout);

		   ITK_CALL(FL_insert(DVAfoldertag,dad_tag,000));
		   ITK_CALL(AOM_save_with_extensions(DVAfoldertag));

		   printf("\n\n inside dataset attach condition :\n");fflush(stdout);

		   
       }

	   FDJcount=0;
       GCIcount=0;
	   printf("\n FDJcount  222222 [%d]",FDJcount); fflush(stdout);
	   printf("\n GCIcount  222222 [%d]",GCIcount); fflush(stdout);
		 
	    printf("\n\n END of FDJ Code 4444\n");fflush(stdout);

	  /**((char **) retValue) = (char *) MEM_alloc( (strlen(strDVA) + 1) * sizeof(char));
      strcpy( *((char **) retValue), strDVA);*/


	
	
	return 0;
}


int tm_DVAfdjstatus1()
{
	/*int ifail = ITK_ok;
    char*Vehicleid =NULL;
    char*VCTname =NULL;

	USERARG_get_string_argument(&Vehicleid);
    DVAcalculations1(Vehicleid,&VCTname);

	printf("VCTname:%s........\n",VCTname);
	*((char **) return_data) = (char *) MEM_alloc( (strlen(VCTname) + 1) * sizeof(char));
    strcpy( *((char **) return_data), VCTname);

	  printf("VCTname* :: %s\n",VCTname);fflush(stdout);

	printf("\n Inside the DVA fun111111111...............");fflush(stdout);
	return ifail;*/




	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS;

	//int inputArgTypes[] = {0};
	int retValueType;
	int nargs = 2;

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	

      
    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("DVAfdjstatus",(USER_function_t)DVAfdjstatus,nargs,inputArgTypes,retValueType);


return ifail;

}

extern int tm_DVAfdjstatuscalling(int *decision, va_list args)
{
	/*int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	int inputArgTypes[1] = {0};
	int retValueType;
	inputArgTypes[0] = USERARG_STRING_TYPE;
	int nargs = 1;
    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("DVAcalculations",(USER_function_t)DVAcalculations,nargs,inputArgTypes,retValueType);*/

	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	tm_DVAfdjstatus1();

	return ifail;


}


extern DLLAPI int tm_DVAfdjstatus_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_fdjstatus");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_DVAfdjstatus", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_DVAfdjstatuscalling);
	printf("\n After registering userservice....tm_fdjstatus");fflush(stdout);
	return(ITK_ok);
}


