/****************************************************************************************************
*  File	           :   tm_epa_mbpa_assign.c ( File name )
*  Project         :   PLM TCUA Project-STDS1.		     
*  Modification History :
*  Date			Modified By			TZ			Modification Notes
*  20/06/18		Deepti Meshram			1.53		EPA-MBPA signoff Validation-1. Previous revision not released check
																		   2. Child part not released
																		   3. AMDML validations bypass
																		   4. Two revision can not be released on same day
																		   5. Next revision of part exists with DR>DR3
																		   6. PP/PM DML for part released error
*******************************************************************************************************/
#include <Fnd0Participant/participant.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include "tm_apl_std_common_function.c"
//#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define NULLDATE   (POM_null_date()) 

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

int cnt = 0;
int cntFlag = 0;
int epacnt = 0;
int cntEPAFlag = 0;
int ifail=0;

//#define ITK_CALL 	 \
//status=X; 	 \
//if (status != ITK_ok)  	 \
//{	 \
//int	 index = 0;	 \
//int	 n_ifails = 0;	 \
//const int*	 severities = 0;	 \
//const int*	 ifails = 0;	 \
//const char**	texts = NULL;	 \
//\
//EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
//printf("%3d error with #X\n", n_ifails);	 \
//for( index=0; index<n_ifails; index++)	 \
//{	 \
//printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//}	 \
//return status;	 \
//}	 \
//;


void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By deepak
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}
void assign_mbpa_user_cv(tag_t role_tag, tag_t group_tag, tag_t EPATag) //sanket
{
	int		num_of_members		= 0;
	tag_t*	member_tags			= NULLTAG;
	tag_t	user_tag			= NULLTAG;
	char	*userid             = NULL;
	tag_t   participant_type	= NULLTAG;
	

	printf("\n **************inside assign_mbpa_user_cv***************\n ");fflush(stdout);

	ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
	printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
	if(num_of_members>0)
	{
	tag_t*	ptypes		= NULLTAG;
	tag_t*	ptypes2		= NULLTAG;
	int p1=0;
	int p2=0;	
	int j=0;
																																		
		for (j=0;j<num_of_members ;j++  )
		{
			ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
			ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
			printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
											
			TCTYPE_find_type("Analyst", "Analyst", &participant_type);
			printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
			setAddTAG_EPA(&p1,&ptypes,participant_type);
			printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
			setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
			printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
			printf("\n VCG  Assigned..to : [%s]\n",userid);fflush(stdout);

		}

	tag_t* participant_list = NULLTAG;									
	logical bypass_assignable_check =true;
	int k = 0;

	tag_t   type1TypeTag			= NULLTAG;

	char*    type1type_name;
	printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
	for(k=0;k<p2;k++)
	{
		tag_t type1 = ptypes[k];
		if(type1 != NULLTAG )
		{
			if(TCTYPE_ask_object_type(type1,&type1TypeTag));
			if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
			printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
		}
		else
		{
			printf("\n type is NULL \n");fflush(stdout);
		}
	}

	ITKCALL(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

	printf("\n  AQ Assigned..to : [%s]\n",userid);fflush(stdout);	

	}
}

int epa_mbpa_validCS_Check_Func(EPM_action_message_t msg )
{

	int	  noAttachment=0,t=0;
	char *TaskName=NULL;
	tag_t	relation_type						= NULLTAG;
	int count=0;
	tag_t*	InvalidPartkRevision						= NULLTAG;
	tag_t	EPAInValidPrtRevTag						= NULLTAG;
	int TaskCnt=0;
	char	*partCs								= NULL;
	int		aqflagActive=0;

	char	*object_type						= NULL;
	char*			username				=NULL;
	char*			parent_name				=NULL;
	char*			CurrentTask				=NULL;

	tag_t			user_tag				=NULLTAG;
	tag_t			*attachments			=NULLTAG;

	tag_t			rootTask				=NULLTAG;
	tag_t EPATag = NULLTAG;
	tag_t	CurrentRoleTag						= NULLTAG;
	char    *RoleName=NULL;
	char	PlantCS[40];
	char	PlantOptCS[40];
	char	PlantIA[40];
	char	PlantStore[40];
	char	UserAgency[40];
	char	RevisionRule[40];
	char	ClosureRule[40];
	char	STDDmlPlnt[40];
	char	BVR[40];
	char	APLDmlPlnt[40];
		char	*PlantName							= NULL;

	printf("\n Inside 1 epa_mbpa_validCS_Check_Func check ...");

	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n tm_std_dml_assign \n"); fflush(stdout);
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		for(t=0;t<noAttachment;t++)
		{
			EPATag = attachments[t];
			AOM_ask_value_string(EPATag,"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);
			if(strcmp(object_type,"T5_EPARevision")==0)
			{
				ITKCALL(AOM_ask_value_string(EPATag, "item_id",&TaskName));
				printf("\n TaskName %s.....\n",TaskName);

				ITKCALL(GRM_find_relation_type("T5_EPAHasValidPart",&relation_type));
				ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&count,&InvalidPartkRevision));

				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName))
				printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);

				PlantName=subString(RoleName,3,4);
				printf( "PlantName:%s\n", PlantName);fflush(stdout);

				getPlantDetailsAttr_Std(RoleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);
				
				printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
				if(count>0)
				{
					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						EPAInValidPrtRevTag = InvalidPartkRevision[TaskCnt];
						ITKCALL(AOM_ask_value_string(EPAInValidPrtRevTag,"object_type",&object_type));
						printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

						ITKCALL(AOM_ask_value_string(EPAInValidPrtRevTag,PlantCS,&partCs));
						printf("\n\n\t\t partCs is :%s",partCs);fflush(stdout);
						
						if( (tc_strcmp(partCs,"E50")==0) || (tc_strcmp(partCs,"F30")==0) || (tc_strcmp(partCs,"E99")==0))
						{
							aqflagActive++;
						
						}						
						
					}

				}
				else
				{
					printf("\n NO EPA TASK FOUND.. ");fflush(stdout);
				
				}	
			
			}
		}
	}
		
	if(aqflagActive>0)
	{
		return ITK_ok;

	}
	else
	{
		return ITK_errStore;	
	}
	

}



int is_MBPA_Req_CV(EPM_action_message_t msg )
{
	tag_t qryTag = NULLTAG;
	int n_entry = 3;
	char *qry_entry[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_values = (char **)MEM_alloc(5 * sizeof(char *));
	int control_found = 0;
	tag_t *list_of_controbj_tags = NULLTAG;
	
	printf("\n Inside is_MBPA_Req_CV ...");fflush(stdout);

	ITKCALL(QRY_find2("Control Objects...", &qryTag));
    if(qryTag != NULLTAG)
    {
        printf("\n Control Object Query Found \n");fflush(stdout);
        
        qry_values[0] = "MBPA";
        qry_values[1] = "MBPA_Req_CV";
        qry_values[2] = "0";

        ITKCALL(QRY_execute(qryTag, n_entry, qry_entry, qry_values, &control_found, &list_of_controbj_tags));
		printf("\n  No of control_found  %d", control_found);fflush(stdout);
    }

	if(control_found>0)
	{
	   
       return ITK_ok;
	}

	else
	{
		return ITK_errStore;
	}
	
}

int epa_mbpa_validate_MFG_QA_OK(EPM_action_message_t msg )
{

	int		noAttachment=0,t=0;
	char	*TaskName=NULL;
	char	*t5_Mfg_Result1								= NULL;
	char	*t5_Mfg_Result2								= NULL;
	char	*t5_Mfg_Result3								= NULL;
	char	*t5_Mfg_Result4								= NULL;
	char	*t5_Mfg_Result5								= NULL;
	int		mfgNotOKFlag=0;

	char	*object_type						=	NULL;
	char*	username							=	NULL;
	char*	parent_name							=	NULL;
	char*	CurrentTask							=	NULL;

	tag_t			user_tag				=NULLTAG;
	tag_t			*attachments			=NULLTAG;

	tag_t			rootTask				=NULLTAG;
	tag_t EPATag = NULLTAG;
	
	printf("\n Inside epa_mbpa_validate_MFG_QA_OK check ...");

	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n tm_std_dml_assign \n"); fflush(stdout);
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		for(t=0;t<noAttachment;t++)
		{
			EPATag = attachments[t];
			AOM_ask_value_string(EPATag,"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);
			if(strcmp(object_type,"T5_EPARevision")==0)
			{
				ITKCALL(AOM_ask_value_string(EPATag, "item_id",&TaskName));
				printf("\n TaskName %s.....\n",TaskName);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result1",&t5_Mfg_Result1));
				printf("\n t5_Mfg_Result1 %s.....\n",t5_Mfg_Result1);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result2",&t5_Mfg_Result2));
				printf("\n t5_Mfg_Result2 %s.....\n",t5_Mfg_Result2);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result3",&t5_Mfg_Result3));
				printf("\n t5_Mfg_Result3 %s.....\n",t5_Mfg_Result3);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result4",&t5_Mfg_Result4));
				printf("\n t5_Mfg_Result4 %s.....\n",t5_Mfg_Result4);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result5",&t5_Mfg_Result5));
				printf("\n t5_Mfg_Result5 %s.....\n",t5_Mfg_Result5);

				if((tc_strcmp(t5_Mfg_Result1,"Not OK")==0))
				{
					mfgNotOKFlag++;
				}					
			
			}
		}
	}
		
	if(mfgNotOKFlag>0)
	{
		return ITK_errStore;
	}
	else
	{
		return ITK_ok;		
	}
	

}

int epa_mbpa_validate_MFG_QA_OK_Check(EPM_action_message_t msg )
{

	int		noAttachment=0,t=0;
	char	*TaskName=NULL;
	char	*t5_Mfg_Result1								= NULL;
	char	*t5_Mfg_Result2								= NULL;
	char	*t5_Mfg_Result3								= NULL;
	char	*t5_Mfg_Result4								= NULL;
	char	*t5_Mfg_Result5								= NULL;
	char	*t5_QA_Result1								= NULL;
	char	*t5_QA_Result2								= NULL;
	char	*t5_QA_Result3								= NULL;
	char	*t5_QA_Result4								= NULL;
	char	*t5_QA_Result5								= NULL;
	
	int		mfgNotOKFlag=0;
	int		QaNotOKFlag=0;

	char	*object_type						=	NULL;
	char*	username							=	NULL;
	char*	parent_name							=	NULL;
	char*	CurrentTask							=	NULL;

	tag_t			user_tag				=NULLTAG;
	tag_t			*attachments			=NULLTAG;

	tag_t			rootTask				=NULLTAG;
	tag_t EPATag = NULLTAG;
	
	printf("\n Inside epa_mbpa_validate_MFG_QA_OK_Check check ...");

	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n tm_std_dml_assign \n"); fflush(stdout);
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		for(t=0;t<noAttachment;t++)
		{
			EPATag = attachments[t];
			AOM_ask_value_string(EPATag,"object_type",&object_type);
			printf("\n object_type is :%s\n",object_type);fflush(stdout);
			if(strcmp(object_type,"T5_EPARevision")==0)
			{
				ITKCALL(AOM_ask_value_string(EPATag, "item_id",&TaskName));
				printf("\n TaskName %s.....\n",TaskName);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result1",&t5_Mfg_Result1));
				printf("\n t5_Mfg_Result1 %s.....\n",t5_Mfg_Result1);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result2",&t5_Mfg_Result2));
				printf("\n t5_Mfg_Result2 %s.....\n",t5_Mfg_Result2);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result3",&t5_Mfg_Result3));
				printf("\n t5_Mfg_Result3 %s.....\n",t5_Mfg_Result3);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result4",&t5_Mfg_Result4));
				printf("\n t5_Mfg_Result4 %s.....\n",t5_Mfg_Result4);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_Mfg_Result5",&t5_Mfg_Result5));
				printf("\n t5_Mfg_Result5 %s.....\n",t5_Mfg_Result5);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_QA_Result1",&t5_QA_Result1));
				printf("\n t5_QA_Result1 %s.....\n",t5_QA_Result1);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_QA_Result2",&t5_QA_Result2));
				printf("\n t5_QA_Result2 %s.....\n",t5_QA_Result2);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_QA_Result3",&t5_QA_Result3));
				printf("\n t5_QA_Result3 %s.....\n",t5_QA_Result3);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_QA_Result4",&t5_QA_Result4));
				printf("\n t5_QA_Result4 %s.....\n",t5_QA_Result4);fflush(stdout);

				ITKCALL(AOM_ask_value_string(EPATag, "t5_Tryout_QA_Result5",&t5_QA_Result5));
				printf("\n t5_QA_Result5 %s.....\n",t5_QA_Result5);fflush(stdout);

				if(tc_strcmp(t5_Mfg_Result1,"")==0)
				{
					printf("\n t5_Mfg_Result1 is null..");fflush(stdout);	
				}
				else
				{
					if((tc_strcmp(t5_Mfg_Result1,"Not OK")==0))
					{
						mfgNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_Mfg_Result2,"")==0)
				{
					printf("\n t5_Mfg_Result2 is null..");fflush(stdout);	
				}
				else
				{
					if((tc_strcmp(t5_Mfg_Result2,"Not OK")==0))
					{
						mfgNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_Mfg_Result3,"")==0)
				{
					printf("\n t5_Mfg_Result3 is null..");fflush(stdout);		
				}
				else
				{
					if((tc_strcmp(t5_Mfg_Result3,"Not OK")==0))
					{
						mfgNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_Mfg_Result4,"")==0)
				{
					printf("\n t5_Mfg_Result4 is null..");fflush(stdout);	
				}
				else
				{
					if((tc_strcmp(t5_Mfg_Result4,"Not OK")==0))
					{
						mfgNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_Mfg_Result5,"")==0)
				{
					printf("\n t5_Mfg_Result5 is null..");fflush(stdout);	
				}
				else
				{
					if((tc_strcmp(t5_Mfg_Result5,"Not OK")==0))
					{
						mfgNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_QA_Result1,"")==0)
				{
					printf("\n t5_QA_Result1 is null..");fflush(stdout);
				}
				else
				{
					if((tc_strcmp(t5_QA_Result1,"Not OK")==0))
					{
						QaNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_QA_Result2,"")==0)
				{
						printf("\n t5_QA_Result2 is null..");fflush(stdout);
				}
				else
				{
					if((tc_strcmp(t5_QA_Result2,"Not OK")==0))
					{
						QaNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_QA_Result3,"")==0)
				{
						printf("\n t5_QA_Result3 is null..");fflush(stdout);
				}
				else
				{
					if((tc_strcmp(t5_QA_Result3,"Not OK")==0))
					{
						QaNotOKFlag++;
					}
				}

				if(tc_strcmp(t5_QA_Result4,"")==0)
				{
						printf("\n t5_QA_Result4 is null..");fflush(stdout);
				}
				else
				{
					if((tc_strcmp(t5_QA_Result4,"Not OK")==0))
					{
						QaNotOKFlag++;
					}
				}
				if(tc_strcmp(t5_QA_Result5,"")==0)
				{
						printf("\n t5_QA_Result5 is null..");fflush(stdout);	
				}
				else
				{
					if((tc_strcmp(t5_QA_Result5,"Not OK")==0))
					{
						QaNotOKFlag++;
					}
				}
							
			}
		}
	}
		
	if(mfgNotOKFlag>0)
	{
		return ITK_errStore;
	}
	else if(QaNotOKFlag>0)
	{
		return ITK_errStore;		
	}
	else
	{
		return ITK_ok;	
	}
	

}


int epa_mbpa_assign_AQ_mapping(EPM_action_message_t msg )
{



	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*AQGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_assign_AQ***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_assign_AQ \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
		//ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
		//printf("\n AQ EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n AQ EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
				
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &AQGrpName));
			printf("\n AQGrpName: %s\n",AQGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(AQGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"AQ")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"AQ")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))			// COMMENT DEEPAK

					if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(AQGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;	
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n VCG  Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;									// Added ByDepak
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak AQ Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}
				else if(tc_strstr(AQGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"AQ_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"AQ_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"AQ_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"AQ_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"AQ_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}

int epa_mbpa_assign_Mfg_mapping(EPM_action_message_t msg )
{



	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*MfgGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	
	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_Mfg_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_Mfg_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
		printf("\n  EPA NO.:  %s\n", item_id);fflush(stdout);
		//ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
		//printf("\n MFG EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n deepak MFG EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		printf("\n  EPA Plant_name :  %s\n", plantEPA);fflush(stdout);

		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &MfgGrpName));
			printf("\n MfgGrpName: %s\n",MfgGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(MfgGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"MFG")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"MFG")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))		
				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(MfgGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n VCG  Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;																// Added ByDepak
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak Mfg Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}
				else if(tc_strstr(MfgGrpName,"STDCV_")!=NULL)
				{
				    if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"MFG_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"MFG_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"MFG_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"MFG_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"MFG_CVDWD")==0))
					  )
					{
					 assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					 break;
					}

				}
				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}

int epa_mbpa_assign_VCG_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*VCGGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;


	printf("\n **************inside epa_mbpa_assign_VCG_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_VCG_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
		//ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n VCG EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &VCGGrpName));
			printf("\n VCGGrpName: %s\n",VCGGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(VCGGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol 1 Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"VCG")) && (strstr(rolename,aggregateList) ) ) VCG Trims
				//if((tc_strstr(rolename,"VCG")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))
				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(VCGGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n VCG  Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;											// Added ByDepak
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak VCG  Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}
				else if(tc_strstr(VCGGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"QA_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"QA_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"QA_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"QA_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"QA_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
				printf("\n type 2221 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}
		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;

}

int epa_mbpa_assign_SCM_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*SCMGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_SCM_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_SCM_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
		//ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
		//printf("\n  SCM EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n SCM EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &SCMGrpName));
			printf("\n SCMGrpName: %s\n",SCMGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(SCMGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name.. :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"SCM")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"SCM")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))
				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(SCMGrpName,"STDCAR_")!=NULL))
				{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n SCM  Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;											// Added ByDepak																																			
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak SCM  Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					
				}
				else if(tc_strstr(SCMGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"SCM_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"SCM_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"SCM_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"SCM_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"SCM_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
			}
		
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}

int epa_mbpa_assign_ECM_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*SCMGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	
	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_ECM_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_ECM_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
//		ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
//		printf("\n ECM EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n ECM EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &SCMGrpName));
			printf("\n SCMGrpName: %s\n",SCMGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(SCMGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"ECM")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"ECM")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))
				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(SCMGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;	
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n deepak ECM Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;														// Added ByDepak														
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak ECM Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}
				else if(tc_strstr(SCMGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"ECM_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"ECM_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"ECM_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"ECM_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"ECM_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}

int epa_mbpa_assign_VCGCQ_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*SCMGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_VCGCQ_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_VCGCQ_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
//		ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
//		printf("\n  VCGCQ EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n VCGCQ EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}

		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &SCMGrpName));
			printf("\n SCMGrpName: %s\n",SCMGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(SCMGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"CQ")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"CQ")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))

				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(SCMGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n deepak VCGCQ  Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;											// Added By deepak 																									
						logical bypass_assignable_check =true;					
						int k = 0;																					

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak VCGCQ Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);

				}
			

			//printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);

				else if(tc_strstr(SCMGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"STDCV_AQ_ Ready_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"STDCV_AQ_ Ready_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"STDCV_AQ_ Ready_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"STDCV_AQ_ Ready_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"STDCV_AQ_ Ready_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}


int epa_mbpa_assign_QA_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*SCMGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;


	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_QA_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_QA_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
//		ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
//		printf("\n  QA EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
		if(AggrCount>0)
		{
			printf("\n QA EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
		    aggregateListNew = aggregateList[0];
		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &SCMGrpName));
			printf("\n SCMGrpName: %s\n",SCMGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(SCMGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"QA")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"QA")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))
				if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(SCMGrpName,"STDCAR_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;	
						j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n QA Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							}

						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						printf("\n deepak QA Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}

				//printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				else if(tc_strstr(SCMGrpName,"STDCV_")!=NULL)
				{
					if(((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"QA_MBPA_CVPUNE")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU LKO")==0)&&(tc_strcmp(rolename,"QA_MBPA_CVLKO")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU JSR")==0)&&(tc_strcmp(rolename,"QA_MBPA_CVJSR")==0)) ||
					   ((tc_strcmp(plantEPA,"CVBU PNR")==0)&&(tc_strcmp(rolename,"QA_MBPA_CVUTK")==0)) ||
					   ((tc_strcmp(plantEPA,"DHARWAD")==0)&&(tc_strcmp(rolename,"QA_MBPA_CVDWD")==0))
					  )
					{
					assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
					break;
					}

				}
				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}


//sunny start

int epa_mbpa_assign_STDCV_SPD_ECAT_mapping(EPM_action_message_t msg )
{


	tag_t			rootTask				=	NULLTAG;
	char			*CurrentTask			=   NULL;
	char       		*parent_name			=	NULL;
	char       		*item_id				=	NULL;
	char       		*plantEPA				=	NULL;
	//char       		*aggregateList			=	NULL;
	char       		*SCMGrpName				=	NULL;
	
	int	  			noAttachment		 	= 0;
	int				oldusrcount				= 0,extUsrCnt=0;
	int     		n_entryCntrl1    		= 3;
	int  			control_number_found1	= 0;
	int				num_of_roles			= 0,i=0;
	int				num_of_members			= 0,j=0;
	tag_t 			EPATag 					= NULLTAG;
	tag_t			objTypeTag				= NULLTAG;
	tag_t			relation_type			= NULLTAG;
	tag_t			relation_type_participant= NULLTAG;
	tag_t			*OldParticipantRel		= NULLTAG;
	tag_t			OldParticipantRelTag	= NULLTAG;
	tag_t			OldObjTypTask			= NULLTAG;
	tag_t   		qryTagCntrl1     		= NULLTAG;
	tag_t 			*list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t			group_tag				= NULLTAG;
	tag_t			role_tag				= NULLTAG;
	tag_t			user_tag				= NULLTAG;
	tag_t			participant_type		= NULLTAG;
	tag_t			participant_tag			= NULLTAG;
	tag_t			relation				= NULLTAG;
	char			*Oldtype_namee_task=NULL;	
	char   			*type_name=NULL;
	char			*rolename=NULL;
	char			*userid=NULL;
	char    		*qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char			**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t			*attachments	= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;


	char **aggregateList;
	int AggrCount=0;
	char*  aggregateListNew = NULL;

	printf("\n **************inside epa_mbpa_assign_STDCV_SPD_ECAT_mapping***************\n ");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside epa_mbpa_assign_STDCV_SPD_ECAT_mapping \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		ITKCALL(AOM_ask_value_string( EPATag, "item_id", &item_id));
//		ITKCALL(AOM_ask_value_string( EPATag, "t5_Aggregate_List", &aggregateList));
//		printf("\n  QA EPA Aggregate_name :  %s\n",aggregateList);fflush(stdout);

//		ITKCALL(AOM_ask_value_strings(EPATag,"t5_Aggregate_List",&AggrCount,&aggregateList));
//		if(AggrCount>0)
//		{
//			printf("\n SPD_ECAT EPA Aggregate_name :  %s\n",aggregateList[0]);fflush(stdout);
//		    aggregateListNew = aggregateList[0];
//		}
		
		ITKCALL(AOM_ask_value_string( EPATag, "t5_EpaPlantA", &plantEPA));
		
		ITKCALL(GRM_list_secondary_objects_only(EPATag,relation_type,&oldusrcount,&OldParticipantRel));
		printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
		for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
		{
			printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
			OldParticipantRelTag = OldParticipantRel[extUsrCnt];
							
			printf("\n 11 Inside remving the relation from EPA...");fflush(stdout);

			if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
			if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
			printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

			if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
			{
				printf("\n Removing the user..");fflush(stdout);

				AOM_lock(EPATag);
				ITKCALL(PARTICIPANT_remove_participant (EPATag,OldParticipantRelTag)!=ITK_ok);
				AOM_save_with_extensions(EPATag);
				ITKCALL(AOM_refresh(EPATag,1));
				AOM_unlock(EPATag);
			}
			
		}

		 printf("\n  EPA plantEPA----------- %s\n", plantEPA);fflush(stdout);
		
		
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		 printf("\n  1----------- \n" );fflush(stdout);
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="EPAMBPAInf";
			qry_valuesCntrl1[1]=plantEPA;
			qry_valuesCntrl1[2]="0";
			printf("\n  2----------- \n" );fflush(stdout);
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
		}	
		
		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &SCMGrpName));
			printf("\n SCMGrpName: %s\n",SCMGrpName);fflush(stdout);
		
		}
		
		ITKCALL(SA_find_group(SCMGrpName,&group_tag));
		if (group_tag != NULLTAG)
		{
			ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		}
		
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				ITKCALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				
				//if((strstr(rolename,"QA")) && (strstr(rolename,aggregateList) ) )
				//if((tc_strstr(rolename,"QA")!=NULL) && (tc_strstr(rolename,aggregateList)!=NULL))

				//if ((tc_strstr(rolename,aggregateListNew)!=NULL) && (tc_strstr(SCMGrpName,"STDCV_")!=NULL)) // Need to remove testing123

                if ((tc_strstr(SCMGrpName,"STDCV_")!=NULL))
					{
						printf("\nMatch Found\n");fflush(stdout);
						role_tag = role_tags[i];
						ITKCALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
						if(num_of_members>0)
						{
							tag_t*	ptypes		= NULLTAG;
							tag_t*	ptypes2		= NULLTAG;
							int p1=0;
							int p2=0;	
							j=0;
																																							
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
								ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
																
								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n EPA Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_EPA(&p1,&ptypes,participant_type);
							    printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							    setAddTAG_EPA(&p2,&ptypes2,member_tags[j]);
							    printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
								
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								//void setAddTAG_EPA(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
//								GRM_find_relation_type("HasParticipant", &relation_type_participant);
//								GRM_create_relation(EPATag, participant_tag, relation_type_participant,  NULLTAG, &relation);
//								GRM_save_relation(relation);
								printf("\n QA Assigned..to : [%s]\n",userid);fflush(stdout);

								/*TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);*/

							 }

								tag_t* participant_list = NULLTAG;
								logical bypass_assignable_check =true;
								int k = 0;

								tag_t   type1TypeTag			= NULLTAG;

								char*    type1type_name;
								printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
								for(k=0;k<p2;k++)
								{
									tag_t type1 = ptypes[k];
									if(type1 != NULLTAG )
									{
										if(TCTYPE_ask_object_type(type1,&type1TypeTag));
										if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
										printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
									}
									else
									{
										printf("\n type is NULL \n");fflush(stdout);
									}
								 }

							 CALLAPI(PARTICIPANT_add_participants(EPATag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

							 printf("\n deepak SPD_ECAT Assigned..to : [%s]\n",userid);fflush(stdout);	

						}
					
					printf("\n type 111 \n");fflush(stdout);
				}

			//	printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				else if(tc_strstr(SCMGrpName,"STDCV_")!=NULL)
				{

                    printf("\n testtttttt \n");fflush(stdout);
					if((tc_strcmp(plantEPA,"CVBU PUNE")==0)&&(tc_strcmp(rolename,"SPD_ECAT_CVPUNE")==0))
					{
						assign_mbpa_user_cv(role_tags[i],group_tag,EPATag);
						break;
					}

				}

				else
				{
					printf("\n inside else condition \n");fflush(stdout); /// added new

				}

				printf("\n type 222 \n");fflush(stdout);

			}
			printf("\n type 222 \n");fflush(stdout);	
		
		}

		printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
		
	}
	
	return ITK_ok;


}

//Suuny END




extern EPM_decision_t DLLAPI epa_mbpa_signoff_checks_Func(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t		 rootTask			= NULLTAG;
	char		*CurrentTask		= NULL;
	char        *parent_name		= NULL;
	char        *epaitemid			= NULL;
	int			iNumAttch = 0;
	int			i = 0;
	tag_t		* pTagAttch;
	char		*type_name=NULL;
	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	int PartCnt=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t	ItemTypeTag							= NULLTAG;
	tag_t*	EPATaskRevision						= NULLTAG;
	tag_t	EPATaskRevTag						= NULLTAG;
	char	*SetChildRelErr						= NULL;
	char	*EpaFinInf							= NULL;
	char	*epa_plant							= NULL;
	char	*epaTaskNo							= NULL;
	char	*lcsToset							= NULL;
	char	*PlantName							= NULL;
	tag_t*	PartTags							= NULLTAG;
	tag_t	CurrentRoleTag						= NULLTAG;
	char	*epa_po_check						= NULL;
	char	*PrtAvalDateTrail					= NULL;
	char	*PPAPVal							= NULL;
	char	*t5_PartIntrodClearance				= NULL;
	char	*t5TentativeDtOfIntro				= NULL;
	char	*t5SAPUpdComplete					= NULL;
	//muskan
	char    *t5Breakpointstatus					= NULL;
	char	*t5EPARelComplete					= NULL;
	char	*t5BrkPntAggr						= NULL;
	char	*t5QAggregateDate					= NULL;
	char	*t5BrkPntVIN						= NULL;
	char	*t5VINDate							= NULL;
	char	*t5CertifyBP						= NULL;
	char	*t5MBPAReleaseComplete				= NULL;
	char	*t5_TryoutAQLineLoc					= NULL;
	char	*t5_TryoutAQAuppName				= NULL;
	

	char    *RoleName=NULL;
	char	PlantCS[40];
	char	PlantOptCS[40];
	char	PlantIA[40];
	char	PlantStore[40];
	char	UserAgency[40];
	char	RevisionRule[40];
	char	ClosureRule[40];
	char	STDDmlPlnt[40];
	char	BVR[40];
	char	APLDmlPlnt[40];
	int		status=0;
	int		errCnt=0;
	int cntEPAFlag=0;
	int MakeBuyFlag=0;
	int epacnt=0;
	logical	t5_TryoutBatch1Introduction;
	char *group_name = NULL;
    tag_t group_tag = NULLTAG;

	printf("\n Calling epa_mbpa_signoff_checks_Func .....\n");fflush(stdout);
	
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n epa_mbpa_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );
	ITKCALL(POM_ask_group(&group_name, &group_tag));
    printf("\n\n  group_name : %s\n", group_name);fflush(stdout);
        
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName))
	printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);

	PlantName=subString(RoleName,3,4);
    printf( "PlantName:%s\n", PlantName);fflush(stdout);
	
	
		ITKCALL( TCTYPE_find_type("T5_EPARevision", NULL, &ItemTypeTag));
		for (i=0; i < iNumAttch; i++)
		{
				tag_t		objTypeTag = NULLTAG;

				ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&epaitemid));
				printf("\n epa itemid %s.....\n",epaitemid);fflush(stdout);

				qry_entries[0] ="item_id";
				qry_values[0] = epaitemid;

				ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
				item = itemclass[0];
				if(item != NULLTAG )
				ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
				
				ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
				ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
				printf("\t  epa type_name ...%s\n", type_name);fflush(stdout);
					
				if(tc_strcmp(CurrentTask,"Finalize the EPA")==0)
				{
					printf("\n\t Finalize the EPA");fflush(stdout);
					getPlantDetailsAttr_Std(RoleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41

				if( objTypeTag == ItemTypeTag )
				{
					ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_EpaPlantA", &epa_plant));

					if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
					{
						if(tc_strstr(RoleName,"STDP")!=NULL)
						{
							printf("\t SignoffP EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}
					else if(tc_strcmp(epa_plant,"DHARWAD")==0)
					{
						if(tc_strstr(RoleName,"STDD")!=NULL)
						{
							printf("\t SignoffD EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}
					else if((tc_strcmp(epa_plant,"CAR")==0) || (tc_strcmp(epa_plant,"PlantName1")==0))
					{
						if(tc_strstr(RoleName,"STDC")!=NULL)
						{
							printf("\t SignoffC EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
						
					}
					else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
					{
						if(tc_strstr(RoleName,"STDJ")!=NULL)
						{
							printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}
					else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
					{
						if(tc_strstr(RoleName,"STDL")!=NULL)
						{
							printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}
					else if(tc_strcmp(epa_plant,"AHD")==0)										//  Plant corrected from AMALLCAR AHD TO AHD by deepak																											
					{
						if(tc_strstr(RoleName,"STDA")!=NULL)
						{
							printf("\t SignoffA EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}


					else if(tc_strcmp(epa_plant,"SANAND")==0)										//  Plant added by deepak																											
					{
						if(tc_strstr(RoleName,"STDS")!=NULL)
						{
							printf("\t SignoffA EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}


					else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"SMALLCAR PNR")==0))
					{
						if(tc_strstr(RoleName,"STDU")!=NULL)
						{
							printf("\t SignoffU EPA of as per user location ");fflush(stdout);	
						}
						else
						{
							errCnt++;		
						}
					}

					if(errCnt>0)
					{
						printf("\n Showing error of group & role");fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please select proper Group and Role before finalizing the EPA.");
						decision = EPM_nogo;
						return ITK_errStore;
					}
					
				}
			}
		}

		if((tc_strcmp(CurrentTask,"AQ to Declare Sample Development date")==0) || (tc_strcmp(CurrentTask,"AQ to Declare Sample Development date CV")==0))
		{
			 ITKCALL(AOM_UIF_ask_value(epa_rev_tag,"t5_AQSt1PrtAvalDateForTrail",&PrtAvalDateTrail));
			 printf("\n\t PrtAvalDateTrail is :%s",PrtAvalDateTrail);fflush(stdout);

			  ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_AQSt1PPAP",&PPAPVal));
			  printf("\n\t PPAPVal is :%s",PPAPVal);fflush(stdout);

			  if(tc_strlen(PrtAvalDateTrail)==0)
			  {
				printf("\n Showing error of PrtAvalDateTrail is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Part availability Dates for Trials' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> AQ Stage-1");
				decision = EPM_nogo;
				return ITK_errStore;			  
			  
			  }

              if(tc_strstr(group_name,"STDCV_")==NULL)
			  {
			  if(tc_strlen(PPAPVal)==0)
			  {
				printf("\n Showing error of PPAPVal is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'PPAP' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> AQ Stage-1");
				decision = EPM_nogo;
				return ITK_errStore;			  
			  
			  }
			  if((tc_strlen(PPAPVal)>0) && (tc_strcmp(PPAPVal,"N")==0))
			  {
				printf("\n Showing error of PPAPVal is N...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'PPAP' cannot have the value N.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> AQ Stage-1");
				decision = EPM_nogo;
				return ITK_errStore;	  
				  
			  }
			  }
		
		
		}

		if((tc_strcmp(CurrentTask,"TryOut Initiations")==0) || (tc_strcmp(CurrentTask,"TryOut Initiations CV")==0))
		{
			
			  ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_Tryout_AQ_Line_Location",&t5_TryoutAQLineLoc));
			  printf("\n\t t5_TryoutAQLineLoc is :%s",t5_TryoutAQLineLoc);fflush(stdout);

			  ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_Tryout_AQ_Supplier_Name",&t5_TryoutAQAuppName));
			  printf("\n\t t5_TryoutAQAuppName is :%s",t5_TryoutAQAuppName);fflush(stdout);
			  
			  if(tc_strlen(t5_TryoutAQLineLoc)==0)
			  {
				printf("\n Showing error of t5_TryoutAQLineLoc is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'AQ Line Location' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> AQ Stage-2");
				decision = EPM_nogo;
				return ITK_errStore;			  
			  
			  }

			  if(tc_strlen(t5_TryoutAQAuppName)==0)
			  {
				printf("\n Showing error of t5_TryoutAQAuppName is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'AQ Supplier Name' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> AQ Stage-2");
				decision = EPM_nogo;
				return ITK_errStore;			  
			  
			  }
		}
		
		if(tc_strcmp(CurrentTask,"Certify Tryout")==0)
		{
			  printf("\n\t Inside cerify tryout");fflush(stdout);
			  ITKCALL(AOM_ask_value_logical(epa_rev_tag,"t5_Tryout_100Introduction",&t5_TryoutBatch1Introduction));
			  printf("\n\t t5_TryoutBatch1Introduction is :%d",t5_TryoutBatch1Introduction);fflush(stdout);
			  
			  if((t5_TryoutBatch1Introduction==0))
			  {
				printf("\n Showing error of t5_TryoutBatch1Introduction is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'100 % Introduction' not selected.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> Manufacturing & QA");
				decision = EPM_nogo;
				return ITK_errStore;			  
			  
			  }
		}
		if(tc_strcmp(CurrentTask,"Part Introduction Clearance")==0)
		{
			
			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_AQSt3PrtIntroClearance",&t5_PartIntrodClearance));
			printf("\n\t t5_PartIntrodClearance is :%s",t5_PartIntrodClearance);fflush(stdout);

			if(tc_strlen(t5_PartIntrodClearance)==0)
			{
				printf("\n Showing error of t5_PartIntrodClearance is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Part Introduction Clearance' should not be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> Part Introduction Clearance");
				decision = EPM_nogo;
				return ITK_errStore;			  

			}
			
			if((tc_strlen("t5_PartIntrodClearance")>0)&& (tc_strcmp(t5_PartIntrodClearance,"N")==0))
			{
				printf("\n Showing error of t5_PartIntrodClearance is null...");fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Part Introduction Clearance' should be 'Y'.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> Part Introduction Clearance");
				decision = EPM_nogo;
				return ITK_errStore;			  

			}
			
		}
		if(tc_strcmp(CurrentTask,"Stock Control and Schedule")==0)
		{
			
			ITKCALL(AOM_UIF_ask_value(epa_rev_tag,"t5_SCMSt2TentativeDtOfIntro",&t5TentativeDtOfIntro));
			printf("\n\t t5TentativeDtOfIntro is :%s",t5TentativeDtOfIntro);fflush(stdout);
			 if(tc_strlen(t5TentativeDtOfIntro)==0)
			 {
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Tentative date of Introduction' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> Stock Control and Schdule");
				decision = EPM_nogo;
				return ITK_errStore;	
			
			} 			
			
		}
    //CVBU  JSR , CVBU LKO, CVBU PNR, CVBU PUNE,DHARWAD - CV PLANTS 
    //CAR, AHD,SANAND -- PV
    //muskan 
	        if(tc_strcmp(CurrentTask,"ECM to Trigger Implementation")==0)
		    {

			printf("\t  epa type_name muskan...%s\n", type_name);fflush(stdout);
            ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_EpaPlantA", &epa_plant));
			   ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_ECMBreakReleaseStatus",&t5Breakpointstatus));
			printf("\n\t t5Breakpointstatus is :%s",t5Breakpointstatus);fflush(stdout);

			if((tc_strcmp(epa_plant,"SANAND")==0) || (tc_strcmp(epa_plant,"AHD")==0) || (tc_strcmp(epa_plant,"CAR")==0) )
			{
			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_EcmEPARelComplete",&t5EPARelComplete));
			printf("\n\t t5EPARelComplete is :%s",t5EPARelComplete);fflush(stdout);

			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_EcmSAPUpdComplete",&t5SAPUpdComplete));
			printf("\n\t t5SAPUpdComplete is :%s",t5SAPUpdComplete);fflush(stdout);
         

			if(tc_strlen(t5EPARelComplete)==0)
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'EPA Release Complete' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;	
			
			} 
			
			if((tc_strlen(t5EPARelComplete)>0)&& (tc_strcmp(t5EPARelComplete,"N")==0))
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'EPA Release Complete' cannot be 'N'.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;			
			
			}

			if(tc_strlen(t5SAPUpdComplete)==0)
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'SAP Updation Complete' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details -->ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;	
			
			} 
			
			if((tc_strlen(t5SAPUpdComplete)>0)&& (tc_strcmp(t5SAPUpdComplete,"N")==0))
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'SAP Updation Complete' cannot be 'N'.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details -->ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;			
			
			}
			
			}

		if((tc_strcmp(epa_plant,"CVBU JSR")==0) || (tc_strcmp(epa_plant,"CVBU LKO")==0) || (tc_strcmp(epa_plant,"CVBU PNR")==0)|| (tc_strcmp(epa_plant,"CVBU PUNE")==0) || (tc_strcmp(epa_plant,"DHARWAD")==0))
			{ 

           if(tc_strlen(t5Breakpointstatus)==0)
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Break point release status' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details -->ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;	
			
			} 
			
			if((tc_strlen(t5Breakpointstatus)>0)&& (tc_strcmp(t5Breakpointstatus,"N")==0))
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Break point release status' cannot be 'N'.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details -->ECM Trigger Implementation");
				decision = EPM_nogo;
				return ITK_errStore;			
			
			}


			}}

		if(tc_strcmp(CurrentTask,"Mfg for SOP confirmation")==0)
		{
			
			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_MfgQBrkPntVIN",&t5BrkPntVIN));
			printf("\n\t t5BrkPntVIN is :%s",t5BrkPntVIN);fflush(stdout);

			ITKCALL(AOM_UIF_ask_value(epa_rev_tag,"t5_MfgQVINDate",&t5VINDate));
			printf("\n\t t5VINDate is :%s",t5VINDate);fflush(stdout);

			if((tc_strcmp(t5BrkPntVIN,"")==0) || (tc_strcmp(t5VINDate,"")==0))
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Break Point - VIN' OR 'VIN Date' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> Mfg SOP confirmation");
				decision = EPM_nogo;
				return ITK_errStore;
			
			}
		}

		if(tc_strcmp(CurrentTask,"VCG-CQ for SOP confirmation")==0)
		{
			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_CQConfandCertifyBP",&t5CertifyBP));
			printf("\n\t t5CertifyBP is :%s",t5CertifyBP);fflush(stdout);
			
			
			if(tc_strcmp(t5CertifyBP,"")==0) 
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'Confirm and Certify BP' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details -->VCG-QA SOP confirmation");
				decision = EPM_nogo;
				return ITK_errStore;
			
			}
		}

		if(tc_strcmp(CurrentTask,"MBPA Creation")==0)
		{
			ITKCALL(AOM_ask_value_string(epa_rev_tag,"t5_QAMBPAReleaseComplete",&t5MBPAReleaseComplete));
			printf("\n\t t5MBPAReleaseComplete is :%s",t5MBPAReleaseComplete);fflush(stdout);
			
			
			if(tc_strcmp(t5MBPAReleaseComplete,"")==0) 
			{
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"'MBPA Release Complete' cannot be blank.\n For updating the value Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->EPA --> Update EPA details --> QA MBPA Release");
				decision = EPM_nogo;
				return ITK_errStore;
			
			}
		}
		
	decision = EPM_go;
	return decision;

}

extern int epa_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
	METHOD_id_t  method;
	METHOD_id_t  method4;
    
    int ifail=0;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_rule_handler("epa_mbpa_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)epa_mbpa_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler epa_mbpa_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler epa_mbpa_signoff_checks_Func\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("epa_mbpa_validCS_Check_Func", "", epa_mbpa_validCS_Check_Func))
   {
		printf("\t\n Registered Action Handler epa_mbpa_validCS_Check_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_validCS_Check_Func\n");fflush(stdout);
   }

	if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_AQ_mapping", "", epa_mbpa_assign_AQ_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_AQ_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_AQ_mapping\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_Mfg_mapping", "", epa_mbpa_assign_Mfg_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_Mfg_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_Mfg_mapping\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_VCG_mapping", "", epa_mbpa_assign_VCG_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_VCG_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_VCG_mapping\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_SCM_mapping", "", epa_mbpa_assign_SCM_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_SCM_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_SCM_mapping\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_ECM_mapping", "", epa_mbpa_assign_ECM_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_ECM_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_ECM_mapping\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_VCGCQ_mapping", "", epa_mbpa_assign_VCGCQ_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_VCGCQ_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_VCGCQ_mapping\n");fflush(stdout);
   }
	//sunny
    if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_STDCV_SPD_ECAT_mapping", "", epa_mbpa_assign_STDCV_SPD_ECAT_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_STDCV_SPD_ECAT_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_STDCV_SPD_ECAT_mapping\n");fflush(stdout);
   }
   //sunny end

    if( ITK_ok == EPM_register_action_handler("epa_mbpa_assign_QA_mapping", "", epa_mbpa_assign_QA_mapping))
   {
		printf("\t\n Registered Action Handler epa_mbpa_assign_QA_mapping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_assign_QA_mapping\n");fflush(stdout);
   }
   
   if( ITK_ok == EPM_register_action_handler("epa_mbpa_validate_MFG_QA_OK", "", epa_mbpa_validate_MFG_QA_OK))
   {
		printf("\t\n Registered Action Handler epa_mbpa_validate_MFG_QA_OK\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_validate_MFG_QA_OK\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("epa_mbpa_validate_MFG_QA_OK_Check", "", epa_mbpa_validate_MFG_QA_OK_Check))
   {
		printf("\t\n Registered Action Handler epa_mbpa_validate_MFG_QA_OK_Check\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler epa_mbpa_validate_MFG_QA_OK_Check\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("is_MBPA_Req_CV", "", is_MBPA_Req_CV))
   {
		printf("\t\n Registered Action Handler is_MBPA_Req_CV\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler is_MBPA_Req_CV\n");fflush(stdout);
   }

   return ITK_ok;
}

extern DLLAPI int tm_epa_mbpa_assign_register_callbacks()
{
	 CUSTOM_register_exit("tm_epa_mbpa_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)epa_user_assign_register_method);

     printf("\n registered function tm_epa_mbpa_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}


