#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 919006
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

#define ERROR_CALL(x){               \
                                                int stat;                     \
                                                char *err_string = NULL;             \
                                                if( (stat = (x)) != ITK_ok)   \
                                                {                             \
                                                EMH_ask_error_text (stat, &err_string);              \
                                                if(err_string != NULL) {\
                                                printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string);        \
                                                printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__);             \
                                                TC_write_syslog("FORM Property Migiration[%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
                                                MEM_free (err_string);\
                                                err_string=NULL;\
                                                }\
                                                return (stat);          \
                                                }                         \
                                        }

static int report_error( char *file, int line, char *function, int return_code)
{
        if (return_code != ITK_ok)
        {
                int                             index = 0;
                int                             n_ifails = 0;
                const int*              severities = 0;
                const int*              ifails = 0;
                const char**    texts = NULL;

                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                printf("%3d error(s)\n", n_ifails);
                for( index=0; index<n_ifails; index++)
                {
                        printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                        TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                }
                EMH_clear_errors();

        }
        return return_code;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) malloc(3);
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
        //fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
                fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

t5removeAllReleaseStatus(tag_t rev)
{
        int status_count;
        tag_t* status_list;
        int                     st_relList_count                = 0;
        int                     Rel_cnt                                 = 0;
        tag_t*          relstatus_list                  = NULLTAG;
        char            *WSO_Name_RelVal                = NULL ;
        tag_t           tReleaseStatusList              = NULLTAG;
        int                     n_values                                = 0;
        int                     cunt1                                   = 0;
        tag_t*          attr_tags                               = NULLTAG;
        logical         *is_it_null                             = NULL;
        logical         *is_it_empty                    = NULL;
        tag_t           class_id                                = NULLTAG;
        char            *class_name                             = NULL;
        logical         log1;
        int     ifail = 0;

        ERROR_CALL (WSOM_ask_release_status_list(rev,&status_count,&status_list));
        printf("\n no of Status==%d\n",status_count);;fflush(stdout);

        if(status_count>0)
        {
                printf("\n For Status remove...");fflush(stdout);
                CALLAPI(POM_class_of_instance(rev,&class_id));
                CALLAPI(POM_name_of_class(class_id,&class_name));
                printf("\n class_name is :%s\n",class_name);fflush(stdout);

                CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);
                CALLAPI(POM_unload_instances (1,&rev));
                CALLAPI(POM_load_instances(1,&rev,class_id,1));
                CALLAPI(POM_is_loaded(rev,&log1));
                if(log1 == 1)
                {
                         printf(" Load Success\n " );
                }
                else
                printf("Load Failure\n"  );

                CALLAPI( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
                printf("\n n_values is :%d\n",n_values);fflush(stdout);
                if(n_values>0)
                {
                        CALLAPI( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
                        printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

                        for (cunt1 =  0; cunt1 <n_values; cunt1++)
                        {
                                printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
                                CALLAPI(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
                                printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
                                CALLAPI(POM_save_instances(1,&rev,1));
                                CALLAPI(POM_refresh_instances(1,&rev,class_id,2));
                                CALLAPI(AOM_lock(rev));
                                CALLAPI(AOM_save_without_extensions(rev));
                                CALLAPI(AOM_refresh(rev,1));
                        }
                         CALLAPI(AOM_unlock(rev));
                }
                printf("\n Status removed");;fflush(stdout);
        }
                ERROR_CALL(AOM_unlock(rev));
}

extern DLLAPI int ClRevMstCreValidation(METHOD_message_t *msg, va_list args)
{
        int error_code = ITK_ok;
        tag_t objTag = va_arg(args, tag_t);
        char   *type_name=NULL;
        tag_t   objTypeTag                              = NULLTAG;
        char   *desid                                   = NULL;
        char   *DesRevDesc                              = NULL;
        char   *ReplacedDesRevDesc              = NULL;
        char   *NewReplacedDescription  = NULL;
        char   *ItemMaterial                    = NULL;

        int desclength= 0;
        int revdesccnt= 0;
        EPM_decision_t decision=EPM_go;

        if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
        if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);PrintErrorStack();
        printf("\nClRevMstCreValidation :: objTypeTag Type [%s] \n",type_name);fflush(stdout);

        if(strcmp(type_name,"T5_ClrPart")==0)
        {
                if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
                if( AOM_ask_value_string(objTag,"object_desc",&DesRevDesc)!=ITK_ok);PrintErrorStack();
                printf("\nPE Part Master ID : [%s]      Desc : [%s]\n",desid,DesRevDesc);fflush(stdout);

                if(strcmp(DesRevDesc,"")!=0)
                {
                        desclength = strlen(DesRevDesc);
                        for(revdesccnt=0;revdesccnt<desclength;revdesccnt++)
                        {
                                if(DesRevDesc[revdesccnt]=='\n')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='`')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='~')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='|')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='$')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='#')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='@')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='^')
                                DesRevDesc[revdesccnt] =' ';

                                if(DesRevDesc[revdesccnt]=='!')
                                DesRevDesc[revdesccnt] =' ';
                                printf("\n [%c]\n",DesRevDesc[revdesccnt]);fflush(stdout);
                        }

                        ReplacedDesRevDesc = (char *)MEM_alloc (desclength * sizeof(char));
                        strcpy(ReplacedDesRevDesc,DesRevDesc);
                        printf("\n AFTER ClRevMstCreValidation ::ReplacedDesRevDesc=====>[%s]\n",ReplacedDesRevDesc);fflush(stdout);

                        if(ReplacedDesRevDesc)
                        {
                                if(AOM_set_value_string(objTag,"object_desc",ReplacedDesRevDesc)!=ITK_ok) PrintErrorStack();
                                if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
                                if(AOM_ask_value_string(objTag,"object_desc",&NewReplacedDescription)!=ITK_ok) PrintErrorStack();
                                printf("\n AFTER SET ClRevMstCreValidation :: NewReplacedDescription==>[%s]\n", NewReplacedDescription);fflush(stdout);
                        }
                }
      }
      return error_code;
}

extern DLLAPI int ClRevCreValidation(METHOD_message_t *msg, va_list args)
{
        int error_code = ITK_ok;
        tag_t objTag = va_arg(args, tag_t);
        tag_t objTypeTag,item_tag = NULLTAG;
        char    *type_name=NULL;
        char    *desid                  = NULL;
        char    *Desc                   = NULL;
        char    *NewDesc                = NULL;
        char    *DerRoleNme             = NULL;
        char    *DerRoleNme1    = NULL;
        char    *NewDescription = NULL;
        char    *objname                = NULL;
        tag_t   rev                     = NULLTAG;
        tag_t*  resultTags      = NULLTAG;
        char *DrwName           = NULL;
        char *DrwName1          = NULL;
        char *parent_name       = NULL;
        char *group_name        = NULL;
        char *Role_name         = NULL;
        char *Grp_name          = NULL;
        char *Desc_obj2         = NULL;
        char *item_rev_id       = NULL;
        char *currpro           = NULL;
        tag_t   attr_id ;
        tag_t   *attachments    = NULLTAG;
        int             cnt=0;
        int             ij=0;
        int             jk=0;
        int             jkl=0;
        int             Rolflag=0;
        int             dsflag=0;
        char    *qry_entries[2] = {"Name","Type"},      *qry_values[2]  = {"*","CMI2Drawing"};
        int     index,resultCount=0,j=0;
        char    *ObjectClassType        = NULL;
        char    *ObjectName             = NULL;
        char    *desi_grp               = NULL;
        char*   oojname                 = NULL;
        tag_t   form_attr_id ;
        tag_t   relation_type   = NULLTAG;
        tag_t   DesRolTag               = NULLTAG;
        tag_t   Currproj                = NULLTAG;
        tag_t   GroupMem                = NULLTAG;
        tag_t   Roletag                 = NULLTAG;
        tag_t   grptag                  = NULLTAG;
        tag_t   projobj;
        tag_t   dataset                 = NULLTAG;
        tag_t   ActGm                   = NULLTAG;
        tag_t   ActGm1                  = NULLTAG;
        tag_t   status_rel              = NULLTAG;
        tag_t   projid                  = NULLTAG;
        tag_t   tagItem                 = NULLTAG;
        logical checkout                = 0;
        logical checkoutp               = 0;
        logical retain                  = 0;
        logical promem                  = 0;
        tag_t   reln_type                       = NULLTAG;
        tag_t*  secondary_objects       = NULLTAG;
    tag_t       user_tag                        = NULLTAG;
        char* username;
        const char              *reason         = "";
        const char              *change_id      = "";
        const char              *dir_name       = "";
        char type_name2[TCTYPE_name_size_c+1];
        double objWeightVal ;
        double roundedWtVal ;
        char wgtstr[100];
        tag_t   qryTag     = NULLTAG;
        int     n_entry    = 1;
        char    *qry_entry[1]  = {"SYSCD"};
        char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
        int     rsltCount      =  0;
        tag_t   *CntrlObjectTag      = NULLTAG;
        char    *DesgTyp        = NULL;
        char    *info1  = NULL;
        char    *MPart_Desg     = NULL;
        char    *Part_DegGrp    = NULL;
        char    *Part_prj       = NULL;
        char    *DesgNo = NULL;
        char    *sDesgNoG       = NULL;
        char    *sDesgNoT       = NULL;
        char    *sDesgNoVC      = NULL;
        char    *sDesgNoV       = NULL;
        char    *sDesgNoVCCR    = NULL;
        char    *PrtProj        = NULL;
        char    *info2  = NULL;
        char    *PrtDR  = NULL;
        char    *sDesgNoD       = NULL;
        char    *Part_Desg      = NULL;
        char    *Part_Proj      = NULL;
        char    *Proj_typ               = NULL;
        tag_t   Project_t               = NULLTAG;
        tag_t   ObjTypProj      = NULLTAG;
        char    type_Proj[TCTYPE_name_size_c+1];
        tag_t   TagQryContObjSite       = NULLTAG;
        char   *desidForTRL                     = NULL;
        char   *sLastThreeChar          = NULL;
        char   *NewIDTRL                        = NULL;

        int CntrCount = 0;
        int     n_Input = 2;

        char    *gov_class              = NULL;
        char    *RepalcedID             = NULL;
        char    *DesgTypTRL             = NULL;
        char    *projcodeList   = NULL;
        char    *projcode               = NULL;
        char    *ClrIndicator   = NULL;
        tag_t   projobj1;
        int iTemp=0;
        int desclength = 0,index1=0;
        int desccnt = 0,n_entries=2;
        int c_attchs = 0,p=0;
        tag_t           primary                 = NULLTAG;
        tag_t query = NULLTAG, *cntr_objects = NULL;

        if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)  PrintErrorStack();
        if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)               PrintErrorStack();

        POM_get_user(&username,&user_tag);
        printf("\nInside tm_ClrPartValidation : ClRevCreValidation Session user %s\n",username);fflush(stdout);
        printf("\ntm_ClrPartValidation : ClRevCreValidation objTypeTag [%s]\n",type_name);fflush(stdout);

        if(strcmp(type_name,"T5_ClrPartRevision")==0)
        {
                if( AOM_ask_value_string(objTag,"t5_ColourInd",&ClrIndicator)!=ITK_ok) PrintErrorStack();
                if((tc_strcmp(ClrIndicator,"Y") == 0)|| (tc_strcmp(ClrIndicator,"N") == 0))
                {
                        EMH_store_error_s1(EMH_severity_error,ITK_err,"Color Indicator should be 'C' for Color Part.");
                        return ITK_err;
                }
        }

        if(strcmp(type_name,"T5_ClrPartRevision")==0)
        {
                if (AOM_ask_value_string(objTag,"project_ids",&projcodeList)!=ITK_ok)   PrintErrorStack();
                printf("\n tm_ClrPartValidation projcodeList is => %s\n",projcodeList);fflush(stdout);
                printf("\n tm_ClrPartValidation strlen(projcodeList) is => %d\n",strlen(projcodeList));fflush(stdout);

                if (AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)!=ITK_ok)   PrintErrorStack();
                printf("\n tm_ClrPartValidation projcode is => %s\n",projcode);fflush(stdout);

                if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4)
                {
                        if(strcmp(projcode,"")==0)
                        {
                                printf("\ntm_ClrPartValidation Project is  NULL \n");fflush(stdout);
                        }else
                        {
                                if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();
                                if(projobj1 != NULLTAG)
                                {
                                        if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok)PrintErrorStack();
                                        printf("\nColor Part Assigned to Project [%s]\n",projcode);fflush(stdout);
                                }
                        }
                }

                if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
                printf("\nDesc_obj1  = [%s]\n", Desc_obj2);fflush(stdout);
                if(POM_attr_id_of_attr("item_revision_id","T5_ClrPartRevision",&attr_id))       PrintErrorStack();

                if(strcmp(Desc_obj2,"NR")==0 )
                {
                        printf("\nInside Clr Part NR check...\n");fflush(stdout);
                        if(AOM_lock(objTag))PrintErrorStack();
                        if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
                        if(AOM_save_without_extensions(objTag))PrintErrorStack();
                        if(AOM_unlock(objTag))PrintErrorStack();
                        if(AOM_refresh(objTag,1))PrintErrorStack();
                        printf("\nNR;1 updated\n");fflush(stdout);
                }

                if(AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
                if(AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok) PrintErrorStack();
                printf("\nDesc  = [%s]\n", Desc);fflush(stdout);

                if(strcmp(Desc,"")!=0)
                {
                        desclength = strlen(Desc);
                        for(desccnt=0;desccnt<desclength;desccnt++)
                        {
                                if(Desc[desccnt]=='\n')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='`')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='~')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='|')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='$')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='#')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='@')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='^')
                                        Desc[desccnt] =' ';

                                if(Desc[desccnt]=='!')
                                        Desc[desccnt] =' ';
                        }

                        NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
                        strcpy(NewDesc,Desc);
                        printf("\nClRevCreVal : NewDesc[%s]\n",NewDesc);fflush(stdout);

                        if(NewDesc)
                        {
                                AOM_lock(objTag);
                                if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok) PrintErrorStack();
                                if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
                                if(AOM_unlock(objTag))PrintErrorStack();
                                if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
                                if(AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok) PrintErrorStack();
                                printf("\nClrRevCreVal : NewDescription[%s]\n", NewDescription);fflush(stdout);
                        }
                }
        }
		printf("\n\n Name of Revision --------------0000000:\n");fflush(stdout);
 return error_code;
}


extern DLLAPI int ClRevCreValidationPost(METHOD_message_t *msg, va_list args)
{
        int error_code = ITK_ok;
        tag_t objTag = va_arg(args, tag_t);
        tag_t objTypeTag,item_tag = NULLTAG;
        char    *type_name=NULL;
        char    *desid                  = NULL;
        char    *Desc                   = NULL;
        char    *NewDesc                = NULL;
        char    *DerRoleNme             = NULL;
        char    *DerRoleNme1    = NULL;
        char    *NewDescription = NULL;
        char    *objname                = NULL;
        tag_t   rev                     = NULLTAG;
        tag_t*  resultTags      = NULLTAG;
        char *DrwName           = NULL;
        char *DrwName1          = NULL;
        char *parent_name       = NULL;
        char *group_name        = NULL;
        char *Role_name         = NULL;
        char *Grp_name          = NULL;
        char *Desc_obj2         = NULL;
        char *item_rev_id       = NULL;
        char *currpro           = NULL;
        tag_t   attr_id ;
        tag_t   *attachments    = NULLTAG;
        int             cnt=0;
        int             ij=0;
        int             jk=0;
        int             jkl=0;
        int             Rolflag=0;
        int             dsflag=0;
        char    *qry_entries[2] = {"Name","Type"},      *qry_values[2]  = {"*","CMI2Drawing"};
        int     index,resultCount=0,j=0;
        char    *ObjectClassType        = NULL;
        char    *ObjectName             = NULL;
        char    *desi_grp               = NULL;
        char*   oojname                 = NULL;

        tag_t   form_attr_id ;
        tag_t   relation_type   = NULLTAG;
        tag_t   DesRolTag               = NULLTAG;
        tag_t   Currproj                = NULLTAG;
        tag_t   GroupMem                = NULLTAG;
        tag_t   Roletag                 = NULLTAG;
        tag_t   grptag                  = NULLTAG;
        tag_t   projobj;
        tag_t   dataset                 = NULLTAG;
        tag_t   ActGm                   = NULLTAG;
        tag_t   ActGm1                  = NULLTAG;
        tag_t   status_rel              = NULLTAG;
        tag_t   projid                  = NULLTAG;
        tag_t   tagItem                 = NULLTAG;
        logical checkout                = 0;
        logical checkoutp               = 0;
        logical retain                  = 0;
        logical promem                  = 0;
        tag_t   reln_type                       = NULLTAG;
        tag_t*  secondary_objects       = NULLTAG;
    tag_t       user_tag                        = NULLTAG;
        char* username;
        const char              *reason         = "";
        const char              *change_id      = "";
        const char              *dir_name       = "";
        char type_name2[TCTYPE_name_size_c+1];
        double objWeightVal ;
        double roundedWtVal ;
        char wgtstr[100];
        tag_t   qryTag     = NULLTAG;
        int     n_entry    = 1;
        char    *qry_entry[1]  = {"SYSCD"};
        char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
        int     rsltCount      =  0;
        tag_t   *CntrlObjectTag      = NULLTAG;
        char    *DesgTyp        = NULL;
        char    *info1  = NULL;
        char    *MPart_Desg     = NULL;
        char    *Part_DegGrp    = NULL;
        char    *Part_prj       = NULL;
        char    *DesgNo = NULL;
        char    *sDesgNoG       = NULL;
        char    *sDesgNoT       = NULL;
        char    *sDesgNoVC      = NULL;
        char    *sDesgNoV       = NULL;
        char    *sDesgNoVCCR    = NULL;
        char    *PrtProj        = NULL;
        char    *info2  = NULL;
        char    *PrtDR  = NULL;
        char    *sDesgNoD       = NULL;
        char    *Part_Desg      = NULL;
        char    *Part_Proj      = NULL;
        char    *Proj_typ               = NULL;
        tag_t   Project_t               = NULLTAG;
        tag_t   ObjTypProj      = NULLTAG;
        char    type_Proj[TCTYPE_name_size_c+1];
        tag_t   TagQryContObjSite       = NULLTAG;
        char   *desidForTRL                     = NULL;
        char   *sLastThreeChar          = NULL;
        char   *NewIDTRL                        = NULL;
        int CntrCount = 0;
        int     n_Input = 2;
        char    *gov_class              = NULL;
        char    *RepalcedID             = NULL;
        char    *DesgTypTRL             = NULL;
        char    *projcodeList   = NULL;
        char    *projcode               = NULL;
        tag_t   projobj1;
        int iTemp=0;
        int desclength = 0,index1=0;
        int desccnt = 0,n_entries=2;
        int c_attchs = 0,p=0;
        tag_t           primary         = NULLTAG;
        char* ReviewStatus=NULL;
        tag_t   release_status =NULLTAG;
        char   *ReleaseStatus=NULL;
        logical  retain_released_date =false;
       printf("\n\n Name of Revision --------------0:\n");fflush(stdout);
        ReviewStatus =(char *) MEM_alloc(20 * sizeof(char *));
        tc_strcpy(ReviewStatus,"T5_LcsReview");
        printf("\n ReviewStatus --> %s\n",ReviewStatus);

        if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)  PrintErrorStack();
        if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)               PrintErrorStack();
        printf("\n tm_ClrPartValidation : type_name is = [%s]\n",type_name);fflush(stdout);

        if(strcmp(type_name,"T5_ClrPartRevision")==0)
        {
                if(AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
                printf("\nObj_Revision Post  = [%s]\n", Desc_obj2);fflush(stdout);
                if(strcmp(Desc_obj2,"NR;1")==0)
                {
                        printf("\n Colour Part having Revision----->[%s]\n",Desc_obj2);fflush(stdout);
                        if(GRM_list_secondary_objects_only(objTag,NULLTAG,&cnt,&attachments)!=ITK_ok)   PrintErrorStack();
                        printf("\nAttached secondary_objects1 : %d\n",cnt); fflush(stdout);

                        for(ij=0;ij<cnt;ij++)
                        {
                                dataset = attachments[ij];
                                if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
                                printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

                                if (strcmp(ObjectClassType,"T5_ClrPartRevisionMaster")==0)
                                {
                                        if(AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
                                        printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
                                        oojname=strtok(ObjectName,"/");
                                        strcat(oojname,"/");
                                        strcat(oojname,"NR;1");
                                        printf("\nName of Revision Master:%s\n",oojname);fflush(stdout);
                                        if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

                                        if(AOM_lock(dataset));
                                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
                                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                                        if(AOM_unlock(dataset))PrintErrorStack();
                                        if(AOM_refresh(dataset,1))PrintErrorStack();
                                        break;
                                }
                        }
                }

                //if(CR_create_release_status2(ReviewStatus,&release_status)!=ITK_ok)PrintErrorStack();
                //if(AOM_ask_name(release_status, &ReleaseStatus)!=ITK_ok)PrintErrorStack();
                //if( RELSTAT_add_release_status(release_status,1,&objTag,retain_released_date)!=ITK_ok)PrintErrorStack();
                //printf("\n Release Status %s on Color Part is updated\n",ReleaseStatus);fflush(stdout);

        }
        return error_code;
}

extern  DLLAPI int Cl_Revise_properties_Pre(METHOD_message_t *msg, va_list args)
{
        int error_code = ITK_ok;
        tag_t objTag = va_arg(args, tag_t);
        tag_t objTypeTag,item_tag = NULLTAG;
        char            *type_name=NULL;
        char            *PartRevSeq             = NULL;
        logical         checkout                = 0;
        int status;
        int        status_count,ii=0;
        tag_t* status_list = NULLTAG;
        char   *ReleaseStatus=NULL;
        int        clrRlzStatus=0;
        tag_t tRelationFind;
        tag_t tRelationExist = NULLTAG;
        int n_attchs,l =0;
        tag_t*  secondary_objects       = NULLTAG;
        char    *prtowning_group        =       NULL;//Added by Hemal

        printf("\nInside Cl_Revise_properties_Pre Function....\n");fflush(stdout);
        if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
        if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
        printf("\n type_name---------->%s\n",type_name);fflush(stdout);

        if(strcmp(type_name,"T5_ClrPartRevision")==0)
        {
                if(AOM_ask_value_string(objTag,"object_string",&PartRevSeq)!=ITK_ok) PrintErrorStack();
                if(RES_is_checked_out(objTag,&checkout)) PrintErrorStack();

                ITKCALL(AOM_UIF_ask_value(objTag,"owning_group",&prtowning_group));//Added by Hemal
                printf("\n  prtowning_group:%s ..............",prtowning_group);fflush(stdout); //Added by Hemal

                if(checkout>=1)
                {
                        printf("\nPE Part %s Already Checked Out..!!!\n",PartRevSeq);fflush(stdout);
                        EMH_store_error_s1(EMH_severity_error,ITK_err,"Colour Part Already Checked Out..!!!");
                        return ITK_err;
                }

                status=WSOM_ask_release_status_list(objTag,&status_count,&status_list);
            if(status==ITK_ok)
                {
                        printf("\n number of statuses: %d \n",  status_count);
                        for (ii = 0; ii < status_count; ii++)
                        {
                                AOM_ask_name(status_list[ii], &ReleaseStatus);
                                printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
                                //Added by Hemal start
                                if (tc_strstr(prtowning_group,"APL")!=NULL)
                                {
                                        printf("\nAPL User revise...");fflush(stdout);
                                        if(strcmp(ReleaseStatus,"T5_LcsAplRlzd")==0)
                                        {
                                                clrRlzStatus=1;
                                        }
                                }
                                //Added by Hemal ends
                                else
                                {
                                        if(strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
                                        {
                                                clrRlzStatus=1;
                                        }
                                }
                        }
                }

                printf("\n clrRlzStatus---------->%d\n",clrRlzStatus);fflush(stdout);
                if(clrRlzStatus==0)
                {
                        if (tc_strstr(prtowning_group,"APL")!=NULL)//Added by Hemal
                        {
                                status=EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Only APL Released Revision is allowed to Revise.");
                                return ITK_errStore;
                        }

                        /*
                        else
                        {
                                status=EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Only ERC Released Revision is allowed to Revise.");
                                return ITK_errStore;
                        }
                        */
                }
        }
        return error_code;
}

extern  DLLAPI int Cl_Revise_properties_Post(METHOD_message_t *m, va_list args)
{
        char   *ReleaseStatus=NULL;
        char   *type_name=NULL;
        tag_t  source_rev_Type_Tag = NULLTAG;
        tag_t* status_list = NULLTAG;
        int        ifail        =0;
        int        ii=0;
        char   *text    =NULL;
        int        status_count=0;
        char   *Item_string=NULL;
        logical                 retain          = 0;
        int status;
        int Desc_seq=0;
        int Desc_seq9=0;
        int Desc_seq1=0;
        int Desc_seq2=0;
        char                    *Desc_obj       = NULL;
        char                    *Desc_obj9      = NULL;
        char                    *Desc_obj2      = NULL;
        char                    Desc_seq3[10];
        tag_t                   objTypeTag      = NULLTAG;
        tag_t                   status_rel      = NULLTAG;
        tag_t rev=NULLTAG;
        tag_t rev1=NULLTAG;
        tag_t master=NULLTAG;
        logical      bypass                  = FALSE;
        tag_t   source_rev               =va_arg (args, tag_t);
        char*   rev_id                   = va_arg(args, char*);
        tag_t*  new_rev                  = va_arg(args, tag_t*);
        tag_t   item_rev_master_form     = va_arg(args, tag_t);

        char    *ReplacedRevision=NULL;
        char    *ObjectClassType= NULL;
        char    *ObjectName             = NULL;
        char    *t5NcPart               = NULL;
        tag_t   dataset                 = NULLTAG;
        tag_t   *attachments    = NULLTAG;
        int revlength= 0;
        tag_t *revisions;
        int revision_count=0;
        tag_t attr_id ;
        tag_t form_attr_id ;
        tag_t                   relation_type                           = NULLTAG;
        char                    relation_name[TCTYPE_name_size_c+1];

        const char         reason;
        const char     change_id;
        const char     dir_name;
        const char         reason1;
        const char     change_id1;
        const char     dir_name1;
        char* revi=NULL;
        char* oojname=NULL;
         char   revi1[20];
        int                             cnt=0;
        int                             i=0;
        logical                 checkout                        = 0;
        int                     st_relList_count                = 0;
        int                     Rel_cnt                                 = 0;
        tag_t*          relstatus_list                  = NULLTAG;
        char            *WSO_Name_RelVal                = NULL ;
        tag_t           tReleaseStatusList              = NULLTAG;
        int                     n_values                                = 0;
        int                     cunt1                                   = 0;
        tag_t*          attr_tags                               = NULLTAG;
        logical         *is_it_null                             = NULL;
        logical         *is_it_empty                    = NULL;
        tag_t           class_id                                = NULLTAG;
        char            *class_name                             = NULL;
        logical         log1;
        tag_t tRelationFind;
        tag_t tRelationExist = NULLTAG;
        tag_t UseMaster      = NULLTAG;
        tag_t Nrev           = NULLTAG;
        tag_t Rel_task  = NULLTAG;

        int ncItem_count,ik=0;
        tag_t *ncRev_list = NULLTAG;
        char *ncRel_status=NULL;
        tag_t NonClrPrevRlzRevTag = NULLTAG;

        char    *prtowning_group        =       NULL;

        int n_entryCntrl=2 , n_found=0;
        char *qry_entryCntrl[2]  = {"SYSCD","SUBSYSCD"};
        char **qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
        tag_t qryTagCntrl = NULLTAG;
        tag_t *cntrl_tags = NULLTAG;


        printf("\nInside Cl_Revise_properties_Post Function....\n");fflush(stdout);
        if (TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok);
        if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);

        if(ITEM_ask_item_of_rev(source_rev,&master));
        if(ITEM_ask_latest_rev(master,&rev));

        if(ITEM_list_all_revs(master, &revision_count, &revisions));
        printf("\nNumber of revision : %d\n",revision_count); fflush(stdout);

        if(WSOM_ask_release_status_list(revisions[revision_count-2],&status_count,&status_list)) PrintErrorStack();
        printf("\nNumber of statuses: %d \n",  status_count);fflush(stdout);

        //Added by Hemal
        ITKCALL(AOM_UIF_ask_value(revisions[revision_count-2],"owning_group",&prtowning_group));//Added by Hemal
        printf("\n  prtowning_group:%s ..............",prtowning_group);fflush(stdout); //Added by Hemal

        int flatERCRlz=0;
        int flatERCReview=0;
        int     flatAPLRlz      =       0;
        for (ii = 0; ii < status_count; ii++)
        {
                AOM_ask_name(status_list[ii], &ReleaseStatus);
                printf("\nReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
                if (tc_strstr(prtowning_group,"APL")!=NULL)
                {
                        flatAPLRlz      =       1;
                }
                else
                {
                        if(strcmp(ReleaseStatus,"T5_LcsReview")==0)
                        {
                                flatERCReview=1;
                        }
                        else if(strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
                        {
                                flatERCRlz=1;
                                flatERCReview=0;
                                break;
                        }
                }
        }
        printf("\nflatAPLRlz: %d \n", flatAPLRlz);fflush(stdout);
        if (AOM_ask_value_string(revisions[revision_count-2],"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
        printf("\nDesc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);

        if (AOM_ask_value_int(revisions[revision_count-2],"sequence_id",&Desc_seq2)!=ITK_ok)   PrintErrorStack();
        printf("\nDesc_seq2  = [%d]\n", Desc_seq2);fflush(stdout);

        printf("\n A--flatERCReview=> %d & flatERCRlz= %d ", flatERCReview,flatERCRlz);fflush(stdout);
        if((flatERCReview==1) && (flatERCRlz==0))
        {
                if(QRY_find2("Control Objects...", &qryTagCntrl));
                if(qryTagCntrl>0)
                {
                        //printf("\n Clr:Control object Query Found .");
                        fflush(stdout);

                        qry_valuesCntrl[0]="True";
                        qry_valuesCntrl[1]="ClrPartRevise";

                        if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &n_found, &cntrl_tags));

                        printf("\n Clr:n_found control Obj= [%d] \n", n_found);fflush(stdout);
                        if (n_found>0)
                        {
                                flatERCRlz=1;
                                flatERCReview=0;
                        }
                }
                else
                {
                        printf("\n Clr:Control object Query NOT Found .....");fflush(stdout);
                }
        }

        printf("\n B--flatERCReview=> %d & flatERCRlz= %d\n", flatERCReview,flatERCRlz);fflush(stdout);
        if((flatERCReview==1) && (flatERCRlz==0))
        {
                if(AOM_ask_value_string(rev,"item_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
                printf("\n type_name = [%s]\n", type_name);fflush(stdout);
                printf("\n revision  = [%s]\n", Desc_obj);fflush(stdout);

                if (AOM_ask_value_int(rev,"sequence_id",&Desc_seq)!=ITK_ok)   PrintErrorStack();
                printf("\n sequence  = [%d]\n", Desc_seq);fflush(stdout);

                Desc_seq1 = Desc_seq2 + 1;
                printf("\n sequence1  = [%d]\n", Desc_seq1);fflush(stdout);

                if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();

                printf("\nValue of Desc_obj : %s\n",Desc_obj2);fflush(stdout);
                revi=strtok(Desc_obj2,";");
                printf("\nValue of revi : %s\n",revi);fflush(stdout);
                strcat(revi,";");
                printf("\nValue of revi : %s\n",revi);fflush(stdout);

                sprintf(revi1, "%d", Desc_seq1);
                strcat(revi,revi1);
                printf("\nValue of revi : %s\n",revi);fflush(stdout);

                if(POM_set_attr_string(1, &rev, attr_id, revi)) PrintErrorStack();
                printf("\nUpdating start2\n");fflush(stdout);
                if(AOM_lock(rev));
                if(AOM_set_value_int(rev,"sequence_id",Desc_seq1))PrintErrorStack();
                if(AOM_save_without_extensions(rev))PrintErrorStack();
                if(AOM_unlock(rev))PrintErrorStack();
                printf("\nUpdating end2\n");fflush(stdout);

                t5removeAllReleaseStatus(rev);
                if(RELSTAT_create_release_status("T5_LcsReview",&status_rel)) PrintErrorStack();
                if( RELSTAT_add_release_status(status_rel,1,&rev,retain)) PrintErrorStack();

                if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments))PrintErrorStack();
                printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
                for(i=0;i<cnt;i++)
                {
                        dataset = attachments[i];

                        if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
                        printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

                        if (strcmp(ObjectClassType,"T5_ClrPartRevisionMaster")==0)
                        {
                                if(AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
                                printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
                                oojname=strtok(ObjectName,"/");
                                strcat(oojname,"/");
                                strcat(oojname,revi);
                                printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);

                                if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

                                if(AOM_lock(dataset));
                                if(POM_set_attr_string(1,&dataset,form_attr_id,oojname)) PrintErrorStack();
                                if(AOM_save_without_extensions(dataset))PrintErrorStack();
                                if(AOM_unlock(dataset))PrintErrorStack();
                        }
                }
        }

        printf("\n Release Status for selected Color Part is : %s\n", ReleaseStatus);fflush(stdout);
        if(flatERCRlz==1 || (flatAPLRlz ==1 && tc_strstr(prtowning_group,"APL")!=NULL))
        {
                if(GRM_list_secondary_objects_only(rev,relation_type,&cnt,&attachments)) PrintErrorStack();
                printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
                for(i=0;i<cnt;i++)
                {
                        dataset = attachments[i];

                        if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
                        printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

                        if (strcmp(ObjectClassType,"T5_ClrPartRevisionMaster")==0)
                        {
                                if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
                                printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
                                oojname=strtok(ObjectName,"/");
                                strcat(oojname,"/");
                                printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);
                                break;
                        }
                }

                revi=strtok(Desc_obj2,";");
                printf("\nValue of revi in revision : %s\n",revi);fflush(stdout);
                if(POM_attr_id_of_attr("item_revision_id", "T5_ClrPartRevision", &attr_id))PrintErrorStack();
                if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();
                if(AOM_lock(rev));

                if (strcmp(revi,"NR")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"A;1")) PrintErrorStack();
                        strcat(oojname,"A;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"A")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"B;1")) PrintErrorStack();
                        strcat(oojname,"B;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"B")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"C;1")) PrintErrorStack();
                        strcat(oojname,"C;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"C")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"D;1")) PrintErrorStack();
                        strcat(oojname,"D;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"D")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"E;1")) PrintErrorStack();
                        strcat(oojname,"E;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"E")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"F;1")) PrintErrorStack();
                        strcat(oojname,"F;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"F")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"G;1")) PrintErrorStack();
                        strcat(oojname,"G;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"G")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"H;1")) PrintErrorStack();
                        strcat(oojname,"H;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"H")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"I;1")) PrintErrorStack();
                        strcat(oojname,"I;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"I")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"J;1")) PrintErrorStack();
                        strcat(oojname,"J;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"J")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"K;1")) PrintErrorStack();
                        strcat(oojname,"K;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"K")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"L;1")) PrintErrorStack();
                        strcat(oojname,"L;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"L")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"M;1")) PrintErrorStack();
                        strcat(oojname,"M;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"M")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"N;1")) PrintErrorStack();
                        strcat(oojname,"N;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"N")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"O;1")) PrintErrorStack();
                        strcat(oojname,"O;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"O")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"P;1")) PrintErrorStack();
                        strcat(oojname,"P;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"P")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"Q;1")) PrintErrorStack();
                        strcat(oojname,"Q;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"Q")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"R;1")) PrintErrorStack();
                        strcat(oojname,"R;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"R")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"S;1")) PrintErrorStack();
                        strcat(oojname,"S;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"S")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"T;1")) PrintErrorStack();
                        strcat(oojname,"T;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"T")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"U;1")) PrintErrorStack();
                        strcat(oojname,"U;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"U")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"V;1")) PrintErrorStack();
                        strcat(oojname,"V;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"V")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"W;1")) PrintErrorStack();
                        strcat(oojname,"W;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"W")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"X;1")) PrintErrorStack();
                        strcat(oojname,"X;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"X")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"Y;1")) PrintErrorStack();
                        strcat(oojname,"Y;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"Y")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"Z;1")) PrintErrorStack();
                        strcat(oojname,"Z;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
                if (strcmp(revi,"Z")==0)
                {
                        if(POM_set_attr_string(1, &rev, attr_id,"AA;1")) PrintErrorStack();
                        strcat(oojname,"AA;1");
                        if(AOM_lock(dataset));
                        if(POM_set_attr_string(1, &dataset, form_attr_id,oojname))  PrintErrorStack();
                        if(AOM_save_without_extensions(dataset))PrintErrorStack();
                        if(AOM_unlock(dataset))PrintErrorStack();
                }
            printf("\n\n Name of Revision --------------1:\n");fflush(stdout);
                if(AOM_save_without_extensions(dataset))PrintErrorStack();
                if(AOM_unlock(dataset))PrintErrorStack();

                if(AOM_save_without_extensions(rev))PrintErrorStack();
                if(AOM_unlock(rev))PrintErrorStack();


             printf("\n\n Name of Revision --------------2:\n");fflush(stdout);
                ERROR_CALL(AOM_refresh(rev,0));
                t5removeAllReleaseStatus(rev);

                if(flatAPLRlz ==1 && tc_strstr(prtowning_group,"APL")!=NULL)//Added by Hemal
                {
                        ERROR_CALL(RELSTAT_create_release_status("T5_LcsAPLWrkg",&status_rel));//Added By Hemal T5_LcsAPLWrkg
                        ERROR_CALL( RELSTAT_add_release_status(status_rel,1,&rev,retain));
                }
                else
                {
                        ERROR_CALL(RELSTAT_create_release_status("T5_LcsReview",&status_rel));
                        ERROR_CALL( RELSTAT_add_release_status(status_rel,1,&rev,retain));
                }
                ERROR_CALL(AOM_lock(rev));
                ERROR_CALL(AOM_save_without_extensions(rev));
                ERROR_CALL(AOM_unlock(rev));
        }

        tag_t NClrRelationExist = NULLTAG;
        int n_attchs,l =0;
        tag_t*  secondary_objects       = NULLTAG;

        ERROR_CALL(GRM_find_relation_type("TC_Is_Represented_By",&NClrRelationExist));
        if (NClrRelationExist!=NULLTAG)
        {
                ERROR_CALL(GRM_list_secondary_objects_only(rev,NClrRelationExist,&n_attchs,&secondary_objects));
                printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
                if(n_attchs>0)
                {
                        for (l=0;l<n_attchs ;l++ )
                        {
                                ERROR_CALL(GRM_find_relation(rev,secondary_objects[l],NClrRelationExist,&tRelationExist));
                                ERROR_CALL(GRM_delete_relation(tRelationExist));
                                ERROR_CALL(AOM_lock(rev));
                                ERROR_CALL(AOM_save_without_extensions(rev));
                                ERROR_CALL(AOM_unlock(rev));
                                printf("\nRelation Deleted Successfully\n"); fflush(stdout);
                        }
                }
        }

        if(AOM_ask_value_string(source_rev,"t5_NcPartNo",&t5NcPart)!=ITK_ok)PrintErrorStack();
        printf("\n t5NcPart = [%s]\n", t5NcPart);fflush(stdout);

        if(ITEM_find_item(t5NcPart,&UseMaster)!=ITK_ok)rintErrorStack();
        printf("\n Master found------>\n");

        if(ITEM_list_all_revs(UseMaster, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
        printf("\n\t ITEM_list_all_revs non-color count is ::%d:\n\t", ncItem_count);fflush(stdout);
        NonClrPrevRlzRevTag=NULLTAG;

        if(ncItem_count > 0)
        {
                for(ik=ncItem_count-1;ik>=0;ik--)
                {
                        if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
                        if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
                        {
                                NonClrPrevRlzRevTag=ncRev_list[ik];
                                break;
                        }
                }
        }

        char *NClrDesc = NULL;
        char *NewNClrDesc = NULL;
        char *ColorDesc = NULL;
        char *ColorIDStr = NULL;
        char *ColorIDStrNew = NULL;
		char *NClrDRStatus = NULL;
		char *NewColorDRStatus = NULL;

        ColorIDStrNew =(char *) MEM_alloc(100 * sizeof(char *));

        if(NonClrPrevRlzRevTag!=NULLTAG)
        {
                if(AOM_ask_value_string(NonClrPrevRlzRevTag,"object_desc",&NClrDesc)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(NonClrPrevRlzRevTag,"t5_PartStatus",&NClrDRStatus)!=ITK_ok) PrintErrorStack();
                printf("\n NClrDesc  = [%s] , NClrDRStatus = [%s]", NClrDesc,NClrDRStatus);fflush(stdout);

                if(NClrDesc)
                {
                        if(AOM_ask_value_string(rev,"object_desc",&ColorDesc)!=ITK_ok) PrintErrorStack();
                        printf("\n Before Update ColorDesc= [%s] ",ColorDesc);fflush(stdout);

                        if(tc_strstr(ColorDesc,"-")!=NULL)
                        {
                                ColorIDStr=strtok(ColorDesc,"-");
                                printf("  ColorIDStr= [%s] ",ColorIDStr);fflush(stdout);

                                strcpy(ColorIDStrNew,ColorIDStr);
                                strcat(ColorIDStrNew,"-");
                                strcat(ColorIDStrNew,NClrDesc);
                        }
                        else
                        {
                                strcpy(ColorIDStrNew,NClrDesc);
                        }
                        printf("\n ColorIDStrNew= [%s] ",ColorIDStrNew);fflush(stdout);

                        if(AOM_lock(rev)!=ITK_ok) PrintErrorStack();
                        if(AOM_set_value_string(rev,"object_desc",ColorIDStrNew)!=ITK_ok) PrintErrorStack();
						if(AOM_set_value_string(rev,"t5_DRstatus",NClrDRStatus)!=ITK_ok) PrintErrorStack();
                        if(AOM_save_without_extensions(rev)!=ITK_ok) PrintErrorStack();
                        if(AOM_unlock(rev))PrintErrorStack();
                        if(AOM_refresh(rev,1)!=ITK_ok) PrintErrorStack();
                        if(AOM_ask_value_string(rev,"object_desc",&NewNClrDesc)!=ITK_ok) PrintErrorStack();
						if(AOM_ask_value_string(rev,"t5_DRstatus",&NewColorDRStatus)!=ITK_ok) PrintErrorStack();
                        printf("\nClrRevCreVal : NewNClrDesc[%s] ,NewColorDRStatus= [%s]\n", NewNClrDesc,NewColorDRStatus);fflush(stdout);
                }

                ERROR_CALL(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind));
                if (tRelationFind!=NULLTAG)
                {
                        ERROR_CALL(GRM_find_relation(rev,NonClrPrevRlzRevTag,tRelationFind,&tRelationExist));
                        if(tRelationExist==NULLTAG)
                        {
                                printf("\n Non-Color relatioship not with Latest Color Revision-------->\n");   fflush(stdout);
                                ERROR_CALL(GRM_create_relation(rev,NonClrPrevRlzRevTag,tRelationFind,NULLTAG,&Rel_task));
                                ERROR_CALL(GRM_save_relation(Rel_task));
                                printf("\nRelation Created Successfully\n");fflush(stdout);
                        }
                }
        }

        return ITK_ok;
}

extern int tm_ClrPartValidation_custom_exit(int *decision, va_list args)
{
        int ifail = ITK_ok;
        METHOD_id_t  ClRevMstCreVal;
        METHOD_id_t  ClRevCreVal;
        METHOD_id_t  ClRevCreValPost;
        METHOD_id_t  ClRevCopyPre;
        METHOD_id_t  ClRevCopyPost;
        *decision = ALL_CUSTOMIZATIONS;

        if(METHOD_find_method("T5_ClrPart", IMAN_save_msg,&ClRevMstCreVal) !=ITK_ok) PrintErrorStack();
        if(METHOD_find_method("T5_ClrPartRevision", IMAN_save_msg,&ClRevCreVal) !=ITK_ok) PrintErrorStack();
        if(METHOD_find_method("T5_ClrPartRevision", IMAN_save_msg,&ClRevCreValPost) !=ITK_ok) PrintErrorStack();
        if(METHOD_find_method("T5_ClrPartRevision","ITEM_copy_rev",&ClRevCopyPre)!=ITK_ok) PrintErrorStack();
        if(METHOD_find_method("T5_ClrPartRevision","ITEM_copy_rev",&ClRevCopyPost)!=ITK_ok) PrintErrorStack();

        if (ClRevMstCreVal.id != NULLTAG)
        {
                printf("\nInside ClRevMstCreVal-------->\n");   fflush(stdout);
                if(METHOD_add_action(ClRevMstCreVal, METHOD_pre_action_type, (METHOD_function_t) ClRevMstCreValidation, NULL)!=ITK_ok) PrintErrorStack();
        }

        if (ClRevCreVal.id != NULLTAG)
        {
                printf("\nInside ClRevCreVal-------->\n");      fflush(stdout);
                if(METHOD_add_action(ClRevCreVal, METHOD_pre_action_type, (METHOD_function_t) ClRevCreValidation, NULL)!=ITK_ok) PrintErrorStack();
        }

        if (ClRevCreValPost.id != NULLTAG)
        {
                printf("\nInside ClRevCreValPost-------->\n");  fflush(stdout);
                if(METHOD_add_action(ClRevCreValPost, METHOD_post_action_type, (METHOD_function_t) ClRevCreValidationPost, NULL)!=ITK_ok) PrintErrorStack();
        }

        if (ClRevCopyPre.id != NULLTAG)
    {
        printf("\nInside ClRevCopyPre-------->\n");     fflush(stdout);
                if(METHOD_add_action(ClRevCopyPre,METHOD_pre_action_type,(METHOD_function_t) Cl_Revise_properties_Pre, NULL)!=ITK_ok)   PrintErrorStack();
    }

        if (ClRevCopyPost.id != NULLTAG)
    {
        printf("\nInside ClRevCopyPost-------->\n");    fflush(stdout);
                if(METHOD_add_action(ClRevCopyPost,METHOD_post_action_type,(METHOD_function_t) Cl_Revise_properties_Post, NULL)!=ITK_ok)        PrintErrorStack();
    }

        return(ITK_ok);
}

extern DLLAPI int tm_ClrPartValidation_register_callbacks()
{
        CUSTOM_register_exit ("tm_ClrPartValidation","USER_init_module",(CUSTOM_EXIT_ftn_t) tm_ClrPartValidation_custom_exit);

        printf("\n Inside CUSTOM_register_exit for tm_ClrPartValidation-------->\n");   fflush(stdout);

        return(ITK_ok);
}
