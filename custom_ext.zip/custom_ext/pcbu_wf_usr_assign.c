/********************************************************************************************************
*  File			: PCBU_Assign_User_Workflow.c
*  Created By	: Prachi Wade
*  Created On	: 28-Nov-2011
*  Project		: TCUA 	 
*  Purpose		:Handlers to PCBU assign users and attaching templates to workitem
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/

#include "iman_headers.h"
#include <epm_task_template_itk.h>
#include <project.h>
#include <arch.h>
#include <cr.h>

#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	Write_To_Log("CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
 
 
int PCBU_Skip_Task(EPM_action_message_t msg)
{
		int   ifail				= 0;
		char  *objecttype		= NULL;
		tag_t responsible_party = NULLTAG;
 		tag_t rootTask			= NULLTAG;
		tag_t *attachments		= NULLTAG;

  		int noAttachment =0,t=0;
		int is_Tertiary = 0;

		tag_t project			= NULLTAG;
	    char *project_ids		= NULL;
		tag_t team_tag			= NULLTAG;
		tag_t *mem				= NULLTAG;
		char *parent_name		= NULL;
		int num =0,z=0; 

		tag_t group_tag = NULLTAG;
	    tag_t role_tag = NULLTAG;
	    tag_t usertag = NULLTAG;
	    char group_name[SA_name_size_c+1];
	    char role_name[SA_name_size_c+1];
	    char *user_name=NULL;


		char *check_group = NULL;
		check_group =(char *) MEM_alloc (sizeof (char) * 128);

        TC_write_syslog("\nPCBU_Skip_Task\n");     
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		Write_To_Log("\nParent Name:%s\n",parent_name);

		CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
		Write_To_Log("Target Attachment:%d\n",noAttachment);
		if(noAttachment > 0)
		{
			 for(t=0;t<noAttachment;t++)
			 {
					  AOM_ask_value_string(attachments[t],"object_type",&objecttype);
					  Write_To_Log("\nobjecttype:%s\n",objecttype);
					  if(strcmp(objecttype,"T8_Project")==0)
					  {	
						 CALLAPI(AOM_ask_value_string(attachments[t],"project_ids",&project_ids));
 						 Write_To_Log("Project ids:%s\n",project_ids);
	 					 CALLAPI(PROJ_find(project_ids,&project)); 
						 AOM_ask_value_tag(project,"project_team",&team_tag);  
						 break;
					  }
			  }						  
		} 

		if(strcmp(parent_name,"PCBU Process")==0)
		{
			strcpy(check_group,"Marketing");
		}
		if(strstr(parent_name,"NPI")!= NULL)
		{
			strcpy(check_group,"NPI");
		}
		if(strstr(parent_name,"ERC")!= NULL)
		{
			strcpy(check_group,"ERC");
		}
		if(strstr(parent_name,"VD")!= NULL)
		{
			strcpy(check_group,"VD");
		}
		if(strstr(parent_name,"TS")!= NULL)
		{
			strcpy(check_group,"TS");
		}
		if(strstr(parent_name,"Finance")!= NULL)
		{
			strcpy(check_group,"Finance");
		}  

		Write_To_Log("check_group:%s\n",check_group);

		if(team_tag!=NULLTAG)
		{	
			CALLAPI(AOM_ask_value_tags(team_tag,"project_members",&num,&mem));
			Write_To_Log("num:%d\n",num);
			for(z=0;z<num;z++)
			{
				 AOM_ask_value_tag(mem[z],"the_group",&group_tag); 				 
				 SA_ask_group_name(group_tag,group_name); 
				 AOM_ask_value_tag(mem[z],"the_role",&role_tag); 
				 SA_ask_role_name(role_tag,role_name); 
				 AOM_ask_value_tag(mem[z],"the_user",&usertag);  
				 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
				 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
				 if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Tertiary")==0)
				 {
					is_Tertiary = 1;
					break;												 
				 }
									  
			}
	    }  
		 
		if(is_Tertiary==0)
		{
				Write_To_Log("\n Tertiary Not found..skip task\n");
				EPM_set_task_result(msg.task,"Approve");		
		}		 
      
		return 0;
}


int PCBU_Assign_Templates_To_WorkItem(EPM_action_message_t msg)
 {
	   int ifail = 0;

       tag_t *attachments = NULLTAG;
       tag_t rootTask     = NULLTAG;
       int	 noAttachment =0; 

	   char *projectId	  = NULL;
	   tag_t projectTag	  = NULLTAG;

	   char* fname		= NULL;
	   int n_items		= 0;
 	   int	cnt			=0;
	   tag_t *fld_content= NULLTAG;

	   char *taskName    = NULL;	
	   char *inputTask    = NULL;	
	   char *object_name = NULL;
	   int  i =0;

	   int tskcnt=0;
	   tag_t *epmtasks = NULLTAG;
	   int  attype = 1;
	   tag_t attach = NULLTAG;
	   tag_t remove = NULLTAG;
	   	char *  	aDatasetId = NULL;
		char *  	aDatasetRev	 = NULL;
		int j =0;
		int m =0;

	   tag_t folderTag = NULLTAG;
	   tag_t current_role_tag = NULLTAG;
	   char rolename[SA_name_size_c+1];
	   char *parent_name		= NULL;
	   char *user_id			= NULL;
	   int is_npi_closure = 0;
 
 	   printf("\n===========Inside PCBU_Assign_Templates_To_WorkItem============\n");  
 	   TC_write_syslog("\n===========Inside PCBU_Assign_Templates_To_WorkItem============\n");  

	   CALLAPI(AOM_ask_value_string(msg.task,"object_name",&inputTask));
	   printf("\nInput Task Name:%s\n",inputTask);
	   TC_write_syslog("\nInput Task Name:%s\n",inputTask);

	   CALLAPI(EPM_ask_root_task(msg.task,&rootTask)); 

	   CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	   Write_To_Log("\nParent Name:%s\n",parent_name);
 	   if(strstr(parent_name,"NPI Closure")!=NULL)
	   {
			 TC_write_syslog("\nis_npi_closure:1\n");
			 is_npi_closure = 1;
	   }

       CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	   printf("\nRoot Task Attachment:%d\n",noAttachment);
	   TC_write_syslog("\nRoot Task Attachment:%d\n",noAttachment);

		CALLAPI(POM_get_user_id(&user_id));      
		printf("Currently logged User:%s\n",user_id);

	   SA_ask_current_role(&current_role_tag); 	
	   SA_ask_role_name (current_role_tag,rolename); 
	   printf("\nSA_ask_role_name:%s\n",rolename);
	   TC_write_syslog("\nSA_ask_role_name:%s\n",rolename);

	   if(strstr(rolename,"DBA")!=NULL ||strstr(rolename,"Project Manager")!=NULL || strstr(rolename,"Project Administrator")!=NULL)
	   {
	     printf("\n continue..\n",noAttachment);
		  TC_write_syslog("\ncontinue..\n");
	   }
	   else
	   {
	    return 0;
	   }

 
	   if(noAttachment>0)
	   {
	      projectTag = attachments[0];
		  for(m=1;m<noAttachment;m++)
		  {
			printf("\nremoving other attachments\n");
		    TC_write_syslog("\nremoving other attachments\n");
			remove = attachments[m];
 	        CALLAPI(EPM_remove_attachments(rootTask,1,&remove)); 
		  }
	   }
	   else
	   {
		 printf("\n Project Not Found\n",noAttachment);
		 TC_write_syslog("\nProject Not Found\n");
		 return ITK_err;
	   }	  
   
	   //Get Project Id
	   CALLAPI(AOM_ask_value_string(projectTag,"object_name",&projectId));
	   printf("\nProject id:%s\n",projectId); 
	   TC_write_syslog("\nProject id:%s\n",projectId);

	   CALLAPI(AOM_ask_value_tags(projectTag,"contents",&cnt,&fld_content));
		TC_write_syslog("\nprojectTag contents:%d\n",cnt);
       if(cnt > 0)
		{  

			if(strstr(inputTask,"PM Review")!=NULL)
			{		
				 if(noAttachment>0)
				 {
					 projectTag = attachments[0];
					 // for(m=1;m<noAttachment;m++)
					 // {
						//printf("\nremoving other attachments\n");
						 //TC_write_syslog("\nremoving other attachments\n");
						//remove = attachments[m];
 						//CALLAPI(EPM_remove_attachments(rootTask,1,&remove)); 
					//  }
				}
 			}  

			if(strstr(inputTask,"Marketing")!=NULL)
			{		
				  for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	//printf("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"Marketing")!=NULL)
					{
					   printf("\nadding Marketing attachment\n");
					   TC_write_syslog("\naadding Marketing attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }
 			}   
			if(strstr(inputTask,"ERC")!=NULL)
			{				 
				for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	//printf("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"ERC")!=NULL)
					{
					   printf("\nadding ERC attachment\n");
					   TC_write_syslog("\naadding ERC attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }				 
			  
 			}
			if(strstr(inputTask,"NPI")!=NULL)
			{
				if(is_npi_closure==0)
				{
					for(i=0;i<cnt;i++)
					{ 
						CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
						//printf("\nobject_name:%s\n",object_name);
						if(strstr(object_name,"Letter from PMO")!=NULL)
						{
						   printf("\nadding NPI PMO Letter attachment\n");
						   TC_write_syslog("\nadding NPI PMO Letter attachment\n");
						   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
						   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
						   break;
						}					
					}		
				
				}
				else
				{

					for(i=0;i<cnt;i++)
					{ 
						CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
						//printf("\nobject_name:%s\n",object_name);
						if(strstr(object_name,"NPI")!=NULL)
						{
						  if(strstr(object_name,"Letter from PMO")!=NULL)
						  {
							  printf("\nskipping NPI PMO Letter attachment\n");
							  TC_write_syslog("\nskipping NPI PMO Letter attachment\n");
							  continue;
						  }
						  else
						  {
							   printf("\nadding NPI attachment\n");
							   TC_write_syslog("\naadding NPI attachment\n");
							   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
						       CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
						  }
						}					
					}			
				}
 			}
			/****/
			/*
			if(strstr(inputTask,"VD")!=NULL || strstr(inputTask,"TS")!=NULL)
			{
 				for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	printf("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"VD")!=NULL || strstr(object_name,"TS")!=NULL || strstr(object_name,"Manufacturing")!=NULL)
					{
					   printf("\nadding VD/TS attachment\n");
					   TC_write_syslog("\nadding VD/TS attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }			  
 			}
			*/

			/****/
		  
			if(strstr(inputTask,"VD")!=NULL)
			{
				TC_write_syslog("\ninside VD loop\n");
 				for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	TC_write_syslog("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"VD")!=NULL)
					{
					   TC_write_syslog("\nadding VD attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }			  
 			}
			if(strstr(inputTask,"TS")!=NULL)
			{
				TC_write_syslog("\ninside TS loop\n");
 				for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	TC_write_syslog("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"TS")!=NULL || strstr(object_name,"Manufacturing")!=NULL)
					{
					   TC_write_syslog("\nadding TS attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }			  
 			}
			 
			if(strstr(inputTask,"Finance")!=NULL)
			{
 				for(i=0;i<cnt;i++)
				  { 
				 	CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
				 	//printf("\nobject_name:%s\n",object_name);
					if(strstr(object_name,"Finance")!=NULL)
					{
					   printf("\nadding Finance attachment\n");
					   TC_write_syslog("\nadding Finance attachment\n");
 					   CALLAPI(AOM_ask_value_tag_at(projectTag,"contents",i,&attach));
  					   CALLAPI(EPM_add_attachments(rootTask,1,&attach,&attype)); 
 					}					
				  }			  
 			}

	   }

		
   
      
       return 0;
}


int check_if_project_already_in_workflow(tag_t projectTag, int *count)
{
	int ifail =0;
	int k	  =0;
 
	int    n_instances		= 0;
	int    n_classes		= 0;
	tag_t  *ref_classes		= 0;
	tag_t  *ref_instances	= NULLTAG;	
	tag_t  task_class		= NULLTAG;	
	tag_t  condition_class	= NULLTAG;	
	tag_t  classId			= NULLTAG;
	int	   *instance_levels;
	int	   *instance_where_found;
	int    *class_levels;
	int    *class_where_found;

  	tag_t   task_tag = NULLTAG;   
  	tag_t   job_tag = NULLTAG;   
 	char *object_name = NULL; 
	
	*count = 0;

	Write_To_Log("\nInside check_if_project_already_in_workflow\n");
 	if(projectTag != NULLTAG)
	{
	   *count=0 ;

	   CALLAPI(POM_referencers_of_instance(projectTag, 1,POM_in_ds_and_db,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
 	   CALLAPI(POM_class_id_of_class("EPMTask", &task_class));
	   for(k=0;k<n_instances;k++)
       {
 
			CALLAPI(POM_class_of_instance(ref_instances[k],&classId));
		    if(task_class==classId)
	        { 			 	
				task_tag = ref_instances[k];
				AOM_ask_value_string(ref_instances[k],"object_name",&object_name); 
				Write_To_Log("EPMTask Reference Found:%s\n",object_name);  
				*count = *count + 1;			 
	        }

	   }
	}
  

	return ifail;

}


//int PCBU_Insert_Data_in_Mint(EPM_action_message_t msg)
EPM_decision_t PCBU_Insert_Data_in_Mint(EPM_rule_message_t msg)
{
	  int ifail =0;  
	  tag_t    rootTask          = NULLTAG;
	  tag_t     *attachments     = NULLTAG;
	  char* object_name	=NULL;
	  char* object_type	=NULL;

	  int noAttachment=0,t=0;	 
	  char *command = NULL;
	  int num = 0;
 	  EPM_decision_t decision = EPM_go;
	   
     
	  Write_To_Log("\nInside PCBU_Insert_Data_in_Mint\n");   

	  command = MEM_alloc(500);

	  CALLAPI(EPM_ask_root_task(msg.task,&rootTask)); 
 		       
	  CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	  Write_To_Log("Target Attachment:%d\n",noAttachment);
	  if(noAttachment > 0)
	  {
          for(t=0;t<noAttachment;t++)
		  {
			  AOM_ask_value_string(attachments[t],"object_type",&object_type);
			  AOM_ask_value_string(attachments[t],"object_name",&object_name);
 			  Write_To_Log("\nobject_type:%s object_name:%s\n",object_type,object_name);
			  if(strcmp(object_type,"T8_Project")==0)
			  {	 
				 CALLAPI(check_if_project_already_in_workflow(attachments[t],&num));
			     Write_To_Log("\ncheck if project is in workflow:%d\n",num);
				 if(num<=1)
				 {
					 strcpy(command,"/home/req83/NPIexes/clients.sh");
					 strcat(command," "); 
					 strcat(command,"\""); 
					 strcat(command,object_name); 
					 strcat(command,"\""); 
					 strcat(command," & "); 
					 Write_To_Log("Command:%s\n",command);
					 system(command);
				 }				 
				 break;
			  }
		  
	     }
		  
	  }  
	  decision = EPM_go;
	  
	  return decision; 
	  
}

EPM_decision_t PCBU_Validate_Workflow(EPM_rule_message_t msg)
{
	
	  char      *object_name = NULL;	
	  char      *object_type = NULL;	
	  
	
	  tag_t     *attachments      = NULLTAG;
	  int  noAttachment =0,t=0;
	  tag_t    rootTask  = NULLTAG;
	  logical		   checkout = 0;
	  EPM_decision_t decision = EPM_nogo;
	 
	  tag_t project = NULLTAG;
	  char *project_ids  =NULL;
	  int ifail =0;

	  tag_t   team_tag = NULLTAG;
	  tag_t *mem = NULLTAG;
	  int num =0,k=0;
	  tag_t group_tag = NULLTAG;
	  tag_t role_tag = NULLTAG;
	  tag_t usertag = NULLTAG;
	  char group_name[SA_name_size_c+1];
	  char role_name[SA_name_size_c+1];
	  char *user_name=NULL;

	  int isMP =0,isEP=0,isVP=0,isTP=0,isFP=0,isNH=0;
	  int isMS=0,isES=0,isVS=0,isTS=0,isFS=0;

      Write_To_Log("\nValidate_Workflow\n");  
	  


	  CALLAPI(EPM_ask_root_task(msg.task,&rootTask)); 		       
	  CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	  Write_To_Log("Target Attachment:%d\n",noAttachment);
	  if(noAttachment > 0)
		{
          for(t=0;t<noAttachment;t++)
		  {
			  checkout = 0;
			  AOM_ask_value_string(attachments[t],"object_type",&object_type);
			  AOM_ask_value_string(attachments[t],"object_name",&object_name);
 			  printf("\nobject_type:%s object_name:%s\n",object_type,object_name);		  
			  CALLAPI(RES_is_checked_out(attachments[t],&checkout));
		      if(checkout == 1)
			  {
				  EMH_store_error_s1(EMH_severity_error,ITK_err,"Please check-in Project before submitting in workflow");	 
				  decision = EPM_nogo;
				  return decision; 
			  }  
		  
			  if(strcmp(object_type,"T8_Project")==0)
		      {
				CALLAPI(AOM_ask_value_string(attachments[t],"project_ids",&project_ids));
				Write_To_Log("Project ids:%s\n",project_ids);
	 			CALLAPI(PROJ_find(project_ids,&project)); 
				AOM_ask_value_tag(project,"project_team",&team_tag); 
				if(team_tag != NULLTAG)
				{
					AOM_refresh(team_tag,0);
					AOM_ask_value_tags(team_tag,"project_members",&num,&mem);
					Write_To_Log("num:%d\n",num);
					for(k=0;k<num;k++)
					{
						 user_name = "";
						 AOM_ask_value_tag(mem[k],"the_group",&group_tag); 				 
						 SA_ask_group_name(group_tag,group_name); 
						 AOM_ask_value_tag(mem[k],"the_role",&role_tag); 
						 SA_ask_role_name(role_tag,role_name); 
						 AOM_ask_value_tag(mem[k],"the_user",&usertag);  
					  	 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
						 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
						 if(strcmp(group_name,"Marketing")==0)
						 {
						    if(strcmp(role_name,"Primary")==0)
						    {
								  Write_To_Log("\nMarketing Primary:%s\n",user_name);	
								  isMP = 1;
							}
							if(strcmp(role_name,"Secondary")==0)
							{
							  	  Write_To_Log("\nMarketing Secondary:%s\n",user_name);
								  isMS = 1;							
							}							
						 } 
						 if(strcmp(group_name,"ERC")==0)
						 {
						    if(strcmp(role_name,"Primary")==0)
						    {
								  Write_To_Log("\nERC Primary:%s\n",user_name);	
								  isEP = 1;
							}
							if(strcmp(role_name,"Secondary")==0)
							{
							  	  Write_To_Log("\nERC Secondary:%s\n",user_name);
								  isES = 1;							
							}							
						 } 
						 if(strcmp(group_name,"VD")==0)
						 {
						    if(strcmp(role_name,"Primary")==0)
						    {
								  Write_To_Log("\nVD Primary:%s\n",user_name);	
								  isVP = 1;
							}
							if(strcmp(role_name,"Secondary")==0)
							{
							  	  Write_To_Log("\nVD Secondary:%s\n",user_name);
								  isVS = 1;							
							}							
						 } 
						 if(strcmp(group_name,"TS")==0)
						 {
						    if(strcmp(role_name,"Primary")==0)
						    {
								  Write_To_Log("\nTS Primary:%s\n",user_name);	
								  isTP = 1;
							}
							if(strcmp(role_name,"Secondary")==0)
							{
							  	  Write_To_Log("\nTS Secondary:%s\n",user_name);
								  isTS = 1;							
							}							
						 } 
						 if(strcmp(group_name,"Finance")==0)
						 {
						    if(strcmp(role_name,"Primary")==0)
						    {
								  Write_To_Log("\nFinance Primary:%s\n",user_name);	
								  isFP = 1;
							}
							if(strcmp(role_name,"Secondary")==0)
							{
							  	  Write_To_Log("\nFinance Secondary:%s\n",user_name);
								  isFS = 1;							
							}							
						 } 
						 if(strcmp(group_name,"NPI")==0)
						 {
						    if(strcmp(role_name,"Head")==0)
							{
								  Write_To_Log("\nNPI Head:%s\n",user_name);	
								  isNH = 1;
							} 												 
											 
						 }		

				
					}
				}

		     }
		   }
		   if(isMP==1 && isMS==1 && isEP==1 && isES==1 && isVP==1 && isVS==1 && isTP==1 && isTS==1 && isFP==1 && isFS==1 && isNH==1)
		   {
				decision = EPM_go;
		   }
		   else
		   {
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please assign CFT for all agencies");	 
				decision = EPM_nogo;
		   }
		    

	  }
 
	     return decision; 
	  
}

int PCBU_Project_User_Assign(EPM_action_message_t msg)
{
		
		char *check_group = NULL;
		char* object_name		=NULL;
	    char* object_desc		=NULL;
	    char* object_type		=NULL;
		tag_t parent_task		=NULLTAG;
		char* parent_name		=NULL;
 		
		
		tag_t rootTask			=NULLTAG;
		tag_t *attachments		=NULLTAG;
		int	  noAttachment=0,t=0;
		tag_t project			= NULLTAG;
	    char *project_ids		=NULL;
		tag_t team_tag			=NULLTAG;
		int num =0,k =0;
		tag_t *mem = NULLTAG;

		tag_t group_tag			=NULLTAG;
 		tag_t role_tag			=NULLTAG;
 		tag_t usertag			=NULLTAG;
		char group_name[SA_name_size_c+1];
		char role_name[SA_name_size_c+1];
		char *user_name=NULL;

 		char *tasktype			=NULL;

		int	  noAttachment1 = 0;
		tag_t *attachments1		=NULLTAG;
		int z =0,y=0;
 
		int ifail =0;
		int is_Tertiary = 0;

		char *job_name		= NULL;
		char *job_name_new	= NULL;
		tag_t job			= NULLTAG;

		check_group =(char *) MEM_alloc (sizeof (char) * 128);

 
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		Write_To_Log("\nParent Name:%s\n",parent_name);
 		if(strcmp(parent_name,"PCBU Process")==0)
		{
			strcpy(check_group,"Marketing");
		}
		if(strstr(parent_name,"NPI")!= NULL)
		{
			strcpy(check_group,"NPI");
		}
		if(strstr(parent_name,"ERC")!= NULL)
		{
			strcpy(check_group,"ERC");
		}
		if(strstr(parent_name,"VD")!= NULL)
		{
			strcpy(check_group,"VD");
		}
		if(strstr(parent_name,"TS")!= NULL)
		{
			strcpy(check_group,"TS");
		}
		if(strstr(parent_name,"Finance")!= NULL)
		{
			strcpy(check_group,"Finance");
		}  

		Write_To_Log("check_group:%s\n",check_group);

		CALLAPI(EPM_ask_root_task(msg.task,&rootTask)); 		       
	    CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
	    Write_To_Log("Target Attachment:%d\n",noAttachment);
	    if(noAttachment > 0)
		{
           for(t=0;t<noAttachment;t++)
		   {
			  AOM_ask_value_string(attachments[t],"object_type",&object_type);
			  if(strcmp(object_type,"T8_Project")==0)
		      {
				CALLAPI(AOM_ask_value_string(attachments[t],"object_name",&job_name_new));
				CALLAPI(AOM_ask_value_string(attachments[t],"project_ids",&project_ids));
				Write_To_Log("Project ids:%s\n",project_ids);
	 			CALLAPI(PROJ_find(project_ids,&project)); 
				AOM_ask_value_tag(project,"project_team",&team_tag);  
			    break;
			  }

		   }
		} 

		if(job_name_new!=NULL)
		{
			CALLAPI(EPM_ask_job(rootTask,&job));
			AOM_ask_value_string(job,"object_name",&job_name);
		    Write_To_Log("JobName Before:%s After:%s\n",job_name,job_name_new);
		    CALLAPI(AOM_set_value_string(job,"object_name",job_name_new));
		    AOM_save(job);
		    AOM_refresh(job,0);
		}

		if(team_tag != NULLTAG)
		{

			CALLAPI(AOM_ask_value_tags(team_tag,"project_members",&num,&mem));
			Write_To_Log("num:%d\n",num);
			for(z=0;z<num;z++)
			{
				 AOM_ask_value_tag(mem[z],"the_group",&group_tag); 				 
				 SA_ask_group_name(group_tag,group_name); 
				 AOM_ask_value_tag(mem[z],"the_role",&role_tag); 
				 SA_ask_role_name(role_tag,role_name); 
				 AOM_ask_value_tag(mem[z],"the_user",&usertag);  
				 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
				 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
				 if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Tertiary")==0)
				 {
					is_Tertiary = 1;
					break;												 
				 }
									  
			}

		}

		if(team_tag != NULLTAG)
		{
 			  CALLAPI(AOM_ask_value_tags(team_tag,"project_members",&num,&mem));
			  Write_To_Log("num:%d\n",num);
			  CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment1,&attachments1));	   
			  CALLAPI(EPM_ask_sub_tasks(rootTask,&noAttachment1,&attachments1)); 
 			  for(t=0;t<noAttachment1;t++)
			  {    
					//AOM_ask_value_string(attachments[t],"task_type",&tasktype);
					AOM_ask_value_string(attachments1[t],"object_type",&object_type);
					Write_To_Log("\nobject_type:%s\n",object_type);
					if(strstr(object_type,"EPMConditionTask")!=NULL)
					{
						AOM_ask_value_string(attachments1[t],"object_name",&object_name);		
						Write_To_Log("object_name:%s\n",object_name);
						if(strstr(object_name,"Primary")!= NULL)
						{
							for(y=0;y<num;y++)
							{
								 AOM_ask_value_tag(mem[y],"the_group",&group_tag); 				 
								 SA_ask_group_name(group_tag,group_name); 
								 AOM_ask_value_tag(mem[y],"the_role",&role_tag); 
								 SA_ask_role_name(role_tag,role_name); 
								 AOM_ask_value_tag(mem[y],"the_user",&usertag);  
								 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
								 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
								 if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Primary")==0)
								 {									
									Write_To_Log("\nGot Primary Role\n");		
									EPM_assign_responsible_party(attachments1[t],usertag);		
									break;											 
								 }
													  
							}
								 					 
						}					   
					    if(strstr(object_name,"Input")!= NULL)
						{
							for(y=0;y<num;y++)
							{
								 AOM_ask_value_tag(mem[y],"the_group",&group_tag); 				 
								 SA_ask_group_name(group_tag,group_name); 
								 AOM_ask_value_tag(mem[y],"the_role",&role_tag); 
								 SA_ask_role_name(role_tag,role_name); 
								 AOM_ask_value_tag(mem[y],"the_user",&usertag);  
								 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
								 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
								 //NPI - No Secondary/Tertiary
								 if(strcmp(check_group,"NPI")==0)
								 {
									 if(strcmp(group_name,"Project Administration")==0 && strcmp(role_name,"Project Manager")==0)
									 {									
											Write_To_Log("\nGot PM Role for NPI Input\n");
											EPM_assign_responsible_party(attachments1[t],usertag);
											break;											 
									 }

								 }
								 else
								 {
									 if(is_Tertiary==1)
									 {
										if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Tertiary")==0)
										{									
											Write_To_Log("\nGot Tertiary Role for Input\n");
											EPM_assign_responsible_party(attachments1[t],usertag);
											break;											 
										}
									 }
									 else
									 {
										if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Secondary")==0)
										{									
											Write_To_Log("\nGot Secondary Role for Input\n");
											EPM_assign_responsible_party(attachments1[t],usertag);
											break;											 
										}
									 } 
								 }
													  
							} 		
							 
						}
						
						if(strstr(object_name,"Secondary")!= NULL)
						{
							if(is_Tertiary==1)
							{
								for(y=0;y<num;y++)
							    {
									 AOM_ask_value_tag(mem[y],"the_group",&group_tag); 				 
									 SA_ask_group_name(group_tag,group_name); 
									 AOM_ask_value_tag(mem[y],"the_role",&role_tag); 
									 SA_ask_role_name(role_tag,role_name); 
									 AOM_ask_value_tag(mem[y],"the_user",&usertag);  
									 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
									 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
									 if(strcmp(group_name,check_group)==0 && strcmp(role_name,"Secondary")==0)
									 {									
										Write_To_Log("\nGot Secondary Role for Secondary\n");
										EPM_assign_responsible_party(attachments1[t],usertag);
										break;											 
									 }
													  
								}  

						    }							 
						}	

						if(strstr(object_name,"PM")!= NULL)
						{
							for(y=0;y<num;y++)
							{
								 AOM_ask_value_tag(mem[y],"the_group",&group_tag); 				 
								 SA_ask_group_name(group_tag,group_name); 
								 AOM_ask_value_tag(mem[y],"the_role",&role_tag); 
								 SA_ask_role_name(role_tag,role_name); 
								 AOM_ask_value_tag(mem[y],"the_user",&usertag);  
								 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
								 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
								 if(strcmp(role_name,"Project Manager")==0)
								 {									
									Write_To_Log("\nGot PM Role\n");
									EPM_assign_responsible_party(attachments1[t],usertag);
									break;											 
								 }
													  
							} 								 
 							 
						}	
						if(strstr(object_name,"Head")!= NULL)
						{
							for(y=0;y<num;y++)
							{
								 AOM_ask_value_tag(mem[y],"the_group",&group_tag); 				 
								 SA_ask_group_name(group_tag,group_name); 
								 AOM_ask_value_tag(mem[y],"the_role",&role_tag); 
								 SA_ask_role_name(role_tag,role_name); 
								 AOM_ask_value_tag(mem[y],"the_user",&usertag);  
								 AOM_ask_value_string(usertag,"user_name",&user_name); 					  											 
								 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);
								 if(strcmp(role_name,"Head")==0)
								 {									
									Write_To_Log("\nGot NPI Head Role\n");
									EPM_assign_responsible_party(attachments1[t],usertag);
									break;											 
								 }
													  
							} 								 
 							 
						}	

								 
					}

			  }
		}

		return 0; 

}
 

int pcbu_wf_usr_assign_register_action_handlers()
{
    int retcode = ITK_ok; 

	retcode =  EPM_register_action_handler("PCBU_Assign_Templates_To_WorkItem","Templates",PCBU_Assign_Templates_To_WorkItem);
	if ( retcode == ITK_ok )
	{
		printf("\nafter PCBU_Assign_Templates_To_WorkItem register");fflush(stdout);
	    TC_write_syslog("\nafter PCBU_Assign_Templates_To_WorkItem register\n");
	} 

	retcode = EPM_register_action_handler ("PCBU_Skip_Task_If_NtRqrd","Skip Task",PCBU_Skip_Task);
	if ( retcode == ITK_ok )
	{
		printf("\nafter PCBU_Skip_Task_If_NtRqrd register");fflush(stdout);
		TC_write_syslog("\nafter PCBU_Skip_Task_If_NtRqrd register"); 
	} 

	retcode =  EPM_register_rule_handler("PCBU_Validate_Workflow","Validate Project",PCBU_Validate_Workflow);
	if ( retcode == ITK_ok )
	{
		printf("\nafter PCBU_Validate_Workflow register");fflush(stdout);
		TC_write_syslog("\nafter PCBU_Validate_Workflow register"); 
	}

	retcode =  EPM_register_rule_handler("PCBU_Insert_Data_in_Mint","Program for Mint ",PCBU_Insert_Data_in_Mint);
	if ( retcode == ITK_ok )
	{
		printf("\nafter PCBU_Insert_Data_in_Mint register");fflush(stdout);
		TC_write_syslog("\nafter PCBU_Insert_Data_in_Mint register"); 
	}

	retcode = EPM_register_action_handler ("PCBU_Project_User_Assign","Assign Project Users",PCBU_Project_User_Assign);
	if ( retcode == ITK_ok )
	{
		printf("\nafter PCBU_Project_User_Assign register");fflush(stdout);
		TC_write_syslog("\nafter PCBU_Project_User_Assign register"); 
	}
 
	printf("\nend of pcbu_wf_usr_assign_register_custom_handlers");fflush(stdout);
	TC_write_syslog("\nend of pcbu_wf_usr_assign_register_custom_handlers\n");
	return retcode;
}



extern DLLAPI int pcbu_wf_usr_assign_register_custom_handlers( int *decision , va_list args)
{
	int retcode = ITK_ok;
	retcode = pcbu_wf_usr_assign_register_action_handlers();
	*decision  = ALL_CUSTOMIZATIONS;
	args = NULL;
	return retcode;
}




extern DLLAPI int pcbu_wf_usr_assign_register_callbacks()
{
     //CUSTOM_register_exit("pcbu_wf_usr_assign", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)pcbu_wf_usr_assign_register_custom_handlers);
	 CUSTOM_register_exit("pcbu_wf_usr_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)pcbu_wf_usr_assign_register_custom_handlers);
     printf("\nTata custom dll registering");
	 TC_write_syslog("\ninside pcbu_wf_usr_assign\n");
	 return ( ITK_ok );
}
