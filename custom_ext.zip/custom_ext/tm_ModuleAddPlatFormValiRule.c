/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   tm_ModuleAddPlatFormValiRule: Platform based modular BOM validation for vehicle.
*  Code                 :   tm_ModuleAddPlatFormValiRule.c
*  Created on			:   10-11-2022
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	10-11-2022					Mohan Tayade		Platform based modular BOM validation for vehicle.
*	2.	04-05-2023					Mohan Tayade		handle BUsiness unit as this is only for CVBU Vehicle and GM DML.
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_ModuleAddPlatFormValiRule (EPM_rule_message_t msg)
{
	int no_attach	=  0;
	int	i	=  0;
	tag_t	roottask        =  NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char*	CurrentTask		= NULL;
	char	*PlntToPlnt		= NULL;
	char	*TskNm			= NULL;
	char	*FromPlnt		= NULL;
	char	*rev_idd		= NULL;
	char	*DMLtype		= NULL;
	char	*inTaskDsgGrp		= NULL;
	char	*TaskDsgGrp		= NULL;
	char	*BomComInfo9		= NULL;
	char	*DMLBUnit		= NULL;
	char	*Partno		= NULL;
	char	*Toplnt		= NULL;
	char	*PartMstr_no		= NULL;
	char	*rel_sstatss =NULL;
	char	*Obj_PrtTypp =NULL;
	char	*rev_iiddd =NULL;
	char	*PrtDRstuss =NULL;
	char	*ChildPartQty =NULL;
	char	*PrtProjjj =NULL;
	char	*MDLAddress =NULL;
	char	*sChildMdlAddd =NULL;
	char	*rel_status		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	int	rel_status_cunt	=  0;
	int	NManSOAddFlag	=  0;
	int	iNManSODupFlag	=  0;
	int	ii	=  0;
	int	jk	=  0;
	int	NManMOAddFlag	= 0;
	int	iChildPartQty	= 0;
	int	iChildqty	= 0;
	int	mdlcunt	= 0;
	int	VCChildCunt	= 0;
	int	piStringCount	= 0;
	int	tsk	= 0;
	int	Mstr	= 0;
	int	chkBOMComFlag	= 0;
	int	Item_count	= 0;
	int	IsMilestoneLiveFlag	= 0;
	int	iManSOFlag	= 0;
	int	iManMOErrFlag	= 0;
	int	ManSOAddFlag	= 0;
	int	iManSODupFlag	= 0;
	int	CMRefcount	= 0;
	int	ManMOAddFlag	= 0;
	int	iChild	= 0;
	int	Tskcnt	= 0;
	int MDLrulefound =0;
	int     MDL_n_entry2    = 2;
	int     MDL_n_entry3    = 2;
	int     MDL_n_entry4    = 2;
	int     DR_n_entry    = 1;
	int     PRTSTVAL      =  0;
	int     UPdaFlag      =  0;
	int     fld      =  0;
	int     iBOMComp      =  0;
	int     iBomComInfo2      =  0;
	int     IsPartMilestoneLiveFlag      =  0;
	int     FlderObjCount      =  0;
	int     FlderSize      =  0;
	int     CPModuleAvailFlag      =  0;
	int     sCPModuleFlag      =  0;
	int     Conut_Mst      =  0;
	int     iChildd      =  0;
	int     iQtyAflag      =  0;
	int     cnt_ccvcls      =  0;
	int     RelRevFlag      =  0;
	int     DR_rsltCount      =  0;
	int     MDL_rsltCount2      =  0;
	int     MDL_rsltCount3      =  0;
	int     MDL_rsltCount4      =  0;
	int j =0;
	int countt =0;
	char   *PartPlfFrm=NULL;
	char   *sMDLinofA1=NULL;
	char   *sMDLinofA2=NULL;
	char   *sMDLinofA3=NULL;
	char   *sMDLinofA4=NULL;
	char   *sMDLinofA5=NULL;
	char   *sMDLinofA6=NULL;
	char   *sMDLinofA7=NULL;
	char   *sMDLinofA8=NULL;
	char   *sMDLinofA9=NULL;
	char   *sMDLinofA10=NULL;
	char **MDLrulevalueXO = NULL;
	char **MDLrulenameXO = NULL;
	char   *sChildMdlAdd =NULL;
	char   *Tsk_object_type =NULL;
	char   *Prt_object_type =NULL;
	char   *BomComInfo1 =NULL;
	char   *Prtrel_status =NULL;
	char   *PRTSubStr =NULL;
	char   *Prtrev_idd =NULL;
	char   *DML_Milestone =NULL;
	char   *DMLDR =NULL;
	char   *p_child_item_id=NULL;
	char   *rel_sstats=NULL;
	char   *Obj_PrtTyp=NULL;
	char   *rev_iidd=NULL;
	char   *PrtDRstus=NULL;
	char   *PrtProjj=NULL;
	char   *PartTyp =NULL;
	char   *BomComInfo2 =NULL;
	char   *BOMComp =NULL;
	char   *DMLProj =NULL;
	char	*sUnladenWeightt		=  NULL;
	char	*sdegreesWttDup		=  NULL;
	char	*sdegreesWtt		=  NULL;
	char	*sPrtColInd		=  NULL;
	char	*BomComInfo3		=  NULL;
	char	*BomComInfo4		=  NULL;
	char	*BomComInfo5		=  NULL;
	char	*BomComInfo8		=  NULL;
	char	*BomComInfo6		=  NULL;
	char	*sWeightRollup		=  NULL;
	char	*sDMLBUnit		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*AttrVal		=  NULL;
	char	*ErorStrg		=  NULL;
	char	*sdegreesWttDupp		=  NULL;
	char	*eptr		=  NULL;
	char	*sUnladenWeight		=  NULL;
	char	*sDMLDR		=  NULL;
	char **	AStringList =NULL;
	char **	BStringList =NULL;
	char **	CStringList =NULL;
	char **	DStringList =NULL;
	char DRStrng[20];
	char	*BomComInfo7		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char*   sPartObjyp=NULL;
	tag_t *MDLclosureruleee = NULLTAG;
	tag_t	p_window 	= NULLTAG;
	tag_t	MDLClosureTag 	= NULLTAG;
	tag_t	MDL_rule 	= NULLTAG;
	tag_t	p_top_line 	= NULLTAG;
	tag_t *VCChildobject=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	PartypObj		= NULLTAG;
	tag_t	DMLTagg 		= NULLTAG;
	tag_t	DMLTag 		= NULLTAG;
	tag_t	item_tag 	= NULLTAG;
	tag_t *FolderObj_tag= NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *ClsObjTag= NULLTAG;
	tag_t   *MDL_Obj_Tag      = NULLTAG;
	tag_t   *MDL_Obj_Tag3      = NULLTAG;
	tag_t   *MDL_Obj_Tag4      = NULLTAG;
	tag_t   *DRCntrlObjectTag      = NULLTAG;
	tag_t   *ccvMstrTag      = NULLTAG;
	tag_t   part_tsk_rel_typ      = NULLTAG;
	tag_t   master     = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	tag_t   MdlQry_Tag     = NULLTAG;
	tag_t   MdlQry_Tag3     = NULLTAG;
	tag_t   MdlQry_Tag4     = NULLTAG;
	tag_t   DRqryTag     = NULLTAG;
	tag_t DMLRevTg =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	logical is_latest;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    *MDL_qry_entry2[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry3[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry4[2]  = {"SYSCD","SUBSYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values3     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values4     =  (char **) MEM_alloc(50 * sizeof(char *));
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLBUnit =(char *) MEM_alloc(40 * sizeof(char *));
	sDMLDR =(char *) MEM_alloc(20 * sizeof(char *));
	ErorStrg =(char *) MEM_alloc(200 * sizeof(char *));
	sUnladenWeightt =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWttDup =(char *) MEM_alloc(200 * sizeof(char *));
	sdegreesWtt =(char *) MEM_alloc(200 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_ModuleAddPlatFormValiRule Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ModuleAddPlatFormValiRule Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n PO:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n PO: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n MDL:P7:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n MDL:P8:Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "MDLVAL";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n MDL:P9:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF and DR0/AR0 not considered for Veh DML
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&BomComInfo1)!=ITK_ok)   PrintErrorStack();
				// FROM to Plant not considered for GM DML-TODR
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&BomComInfo2)!=ITK_ok)   PrintErrorStack();
				//Child part type: ,M,D, and other dummy.
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&BomComInfo3)!=ITK_ok)   PrintErrorStack();
				//Part types considered.
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo4",&BomComInfo4)!=ITK_ok)   PrintErrorStack();
				//Part type with 0 qty
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&BomComInfo5)!=ITK_ok)   PrintErrorStack();
				// FROM to Plant not considered for GM DML-TODR
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo6",&BomComInfo6)!=ITK_ok)   PrintErrorStack();
				//DML Types:When task as input: ,Veh,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo7",&BomComInfo7)!=ITK_ok)   PrintErrorStack();
				//DML type : when DML as input:,TODR,
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo8",&BomComInfo8)!=ITK_ok)   PrintErrorStack();
				//DML BU considered: ALL CVBU
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo9",&BomComInfo9)!=ITK_ok)   PrintErrorStack();
				
				printf("\n MDL:P10:BomComInfo1 is  = [%s] BomComInfo2:%s\n BomComInfo3:[%s] \n BomComInfo4:[%s] \n BomComInfo5:[%s]\n ", BomComInfo1,BomComInfo2,BomComInfo3,BomComInfo4,BomComInfo5);fflush(stdout);
				printf("MDL:P11:BomComInfo6:[%s]\n BomComInfo7:[%s] BomComInfo8:[%s]\n",BomComInfo6,BomComInfo7,BomComInfo8);fflush(stdout);
				printf(" BomComInfo9:[%s]\n",BomComInfo9);fflush(stdout);
			}
			if(tc_strstr(BomComInfo1,"M001") == NULL)
			{
				char* sManMQMOSet = NULL ;
				char* sManSQMOSet = NULL ;
				char* sNManSQMOSet = NULL ;
				char* sNManMQMOSet = NULL ;
				char* sCPModuleAvailErr = NULL ;
				char* OtherZeroQtySet = NULL ;
				char* inValidQtySet = NULL ;
				char* sNManSODupErr = NULL ;
				char* sManSODupErr = NULL ;
				char* sManSOErr = NULL ;
				char* sManMOErr = NULL ;
				char* sFinalErr = NULL ;
				sManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
				sManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
				sNManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
				sNManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
				sCPModuleAvailErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				OtherZeroQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
				inValidQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
				sNManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				sManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				sManSOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				sManMOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				sFinalErr     =  (char *) MEM_alloc(100000 * sizeof(char));
				tc_strcpy (sManMQMOSet,"" );
				tc_strcpy (sManSQMOSet,"" );
				tc_strcpy (sNManSQMOSet,"" );
				tc_strcpy (sNManMQMOSet,"" );
				//Error list
				tc_strcpy (sCPModuleAvailErr,"" );
				tc_strcpy (OtherZeroQtySet,"" );
				tc_strcpy (inValidQtySet,"" );
				tc_strcpy (sNManSODupErr,"" );
				tc_strcpy (sManSODupErr,"" );
				tc_strcpy (sManSOErr,"" );
				tc_strcpy (sFinalErr,"" );

				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					printf("\n MDL:P12:inside T5_ChangeTaskRevision .....\n");fflush(stdout);
					//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
					printf("\n MDL:P13:sDMLtaskno:[%s].",sDMLtaskno);fflush(stdout);
					inTaskDsgGrp=subString(sDMLtaskno,11,2);
					printf(" Desg Grp:[%s].",inTaskDsgGrp);fflush(stdout);
					if(tc_strstr(inTaskDsgGrp,"00") != NULL)
					{
						if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
						if (tsk_dml_rel_type!=NULLTAG)
						{
							//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							printf("\n MDL:P14:DML Revision from Task for MR : %d",countt);fflush(stdout);
							for (j=0;j<countt ;j++ )
							{
								if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
								printf("\n MDL:P15: is_latest MR is : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n MDL:P16:is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									DMLRevTg = DMLRevision[j];
									if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
									printf("\n MDL:P17:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);

									if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
									if(item_tag==NULLTAG)
									{
										printf("\n MDL:P18:item_tag is NULL.\n");fflush(stdout);
										return decision;
									}
									else
									{
										printf("\n MDL:P19:item_tag found.\n");fflush(stdout);
										if(ITEM_ask_latest_rev (item_tag, &DMLTagg)!=ITK_ok)PrintErrorStack();
										if(DMLTagg==NULLTAG)
										{
											printf("\n MDL:P20:Object not found in Teamcenter...!!\n");fflush(stdout);
											return decision;
										}
										else
										{
											//DML Details:
											if(AOM_ask_value_string(DMLTagg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(DMLTagg,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
											printf("\n MDL:P21: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
											if(AOM_ask_value_string(DMLTagg,"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
											printf("\n MDL:P21:DMLBUnit:: %s ",DMLBUnit);fflush(stdout);
											tc_strcpy(sDMLBUnit,"");
											tc_strcpy(sDMLBUnit,",");
											tc_strcat(sDMLBUnit,DMLBUnit);
											tc_strcat(sDMLBUnit,",");
											printf(" and sDMLBUnit: %s \n",sDMLBUnit);fflush(stdout);
											if(tc_strstr(BomComInfo9,sDMLBUnit) != NULL)
											{
												tc_strcpy(sDMLrlstype,"");
												tc_strcpy(sDMLrlstype,",");
												tc_strcat(sDMLrlstype,DMLtype);
												tc_strcat(sDMLrlstype,",");
												printf("\n MDL:P22:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
												tc_strcpy(sDMLDR,"");
												tc_strcpy(sDMLDR,",");
												tc_strcat(sDMLDR,DMLDR);
												tc_strcat(sDMLDR,",");
												printf("\n MDL:P23:sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
												//for Veh DML only
												if(tc_strstr(BomComInfo7,sDMLrlstype) != NULL)
												{
													if(tc_strstr(BomComInfo1,sDMLno) != NULL)
													{
														printf("\n MDL:V:P20:DML has been bypassed. \n");fflush(stdout);
													}
													else
													{
														if(tc_strstr(BomComInfo1,"V001") == NULL)
														{
															printf("\n MDL:V:P21:Inside Vehicle DML..................");fflush(stdout);
															if(PlntToPlnt != NULL)
															{
																//not live for DR0/AR0: vehicle DML.
																if(tc_strstr(BomComInfo1,sDMLDR) == NULL)
																{
																	Tskcnt=0;
																	if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
																	printf("\n MDL:V:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
																	if (Tskcnt>0)
																	{
																		for (tsk=0;tsk<Tskcnt ;tsk++ )
																		{
																			if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
																			printf("\n MDL:V:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

																			if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
																			{
																				if(TaskDsgGrp) TaskDsgGrp=NULL;
																				if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																				TaskDsgGrp=subString(TskNm,11,2);
																				printf("\n MDL:V:P24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
																				if(tc_strstr(TaskDsgGrp,"00") != NULL)
																				{
																					if(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																					if (tsk_CMRef_type!=NULLTAG)
																					{
																						//Getting parts from CMReferences
																						CMRefcount=0;
																						if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																						printf("\n MDL:V:P25: Task CMHasSolutionItem: %d",CMRefcount);fflush(stdout);
																						if(CMRefcount > 0)
																						{
																							Mstr=0;
																							for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																							{
																								printf("\n MDL:V:P26:Design Mstr taken:%d",Mstr);fflush(stdout);
																								if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																								printf("\n MDL:V:P27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																								if(strcmp(Prt_object_type,"Folder")!=0)
																								{
																									// put condition for desi rev , to avoid other attachments.
																									if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																									printf("\n MDL:V:P28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																									Item_count=0;
																									//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																									All_item_tag= t5GetItemRevison(PartMstr_no);
																									if(All_item_tag==NULLTAG)
																									{
																										printf("\n MDL:V:P29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																										//return 0;
																									}
																									else
																									{
																										if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																										printf("\n MDL:V:P30:Total rev found: %d.", Item_count);fflush(stdout);
																										if(Item_count > 0)
																										{
																											ii=0;
																											sCPModuleFlag=0;
																											for(ii=Item_count-1;ii>=0;ii--)
																											{
																												PartPlfFrm=NULL;
																												PartPlfFrm =(char *) MEM_alloc(200 * sizeof(char *));
																												rel_status_cunt=0;
																												if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																												if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																												if(AOM_ask_value_string(rev_list[ii], "t5_Platform", &PartPlfFrm)!=ITK_ok)PrintErrorStack();
																												if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																												if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																												if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																												if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																												if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																												printf("\n MDL:V:P31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s PartPlfFrm:[%s]", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,PartPlfFrm);fflush(stdout);
																												//check revison
																												chkBOMComFlag=0;
																												printf("\n MDL:V:P32:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																												if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																												{
																													if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																													{
																														chkBOMComFlag=1;
																													}
																													else if(tc_strstr(BomComInfo1,"V002") == NULL)
																													{
																														chkBOMComFlag=1;
																													}
																													printf("\n MDL:V:P33:chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																													if(chkBOMComFlag >0)
																													{
																														tc_strcpy(sPartTyp,"");
																														tc_strcpy(sPartTyp,",");
																														tc_strcat(sPartTyp,PartTyp);
																														tc_strcat(sPartTyp,",");
																														printf("\n MDL:V:P34:sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																														if(tc_strstr(BomComInfo4,sPartTyp) != NULL)
																														{
																															//Check If platform value is NULL.
																															if((PartPlfFrm==NULL)|| (tc_strcmp(PartPlfFrm,"")==0))
																															{
																																printf("\n MDL:V:P35:Part Platform value is NULL.... \n");fflush(stdout);
																																EMH_clear_errors();
																																EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part platform value is NULL. \nPlease get it updated, then you can sign off this task. ",Partno);
																																decision = EPM_nogo;
																																return decision;
																															}
																															printf("\n MDL:V:P36:If moduler BOM then check mandatory module address, Duplication allowed in BOM. \n");fflush(stdout);
																															
																															//Quering control tables for mandatory module address: Duplication allowed in BOM.
																															if(QRY_find2("Control Objects...", &MdlQry_Tag));
																															if (MdlQry_Tag)
																															{
																																printf("\n MDL:V:P37:Found Query MdlQry_Tag \n");fflush(stdout);
																															}
																															else
																															{
																																printf("\n MDL:V:P38:Not Found Query MdlQry_Tag \n");fflush(stdout);
																															}

																															MDL_qry_values2[0] = "MANDTE";
																															MDL_qry_values2[1] = PartPlfFrm;
																															//MDL_qry_values2[1] = "MHCV";//hardcoded fro testing
																															if(QRY_execute(MdlQry_Tag, MDL_n_entry2, MDL_qry_entry2, MDL_qry_values2, &MDL_rsltCount2, &MDL_Obj_Tag));
																															printf(" \n MDL:V:P39:MDL_rsltCount2 :%d:", MDL_rsltCount2); fflush(stdout);
																															if(MDL_rsltCount2 > 0)
																															{
																																for(jk=0;jk<MDL_rsltCount2;jk++)
																																{
																																	sMDLinofA1=NULL;
																																	sMDLinofA2=NULL;
																																	sMDLinofA3=NULL;
																																	sMDLinofA4=NULL;
																																	sMDLinofA5=NULL;
																																	sMDLinofA6=NULL;
																																	sMDLinofA7=NULL;
																																	sMDLinofA8=NULL;
																																	sMDLinofA9=NULL;
																																	sMDLinofA10=NULL;
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																																	printf("\n MDL:V:P40:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																																	printf("\n MDL:V:P40:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
																																	if(tc_strcmp(sMDLinofA1,"Multi")==0)
																																	{
																																		if (tc_strlen(sMDLinofA2) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA2);
																																			printf("\n MDL:V:P40:M2..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA3) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA3);
																																			printf(" M3..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA4) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA4);
																																			printf(" M4..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA5) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA5);
																																			printf(" M5..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA6) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA6);
																																			printf(" M6..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA7) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA7);
																																			printf(" M7..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA8) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA8);
																																			printf(" M8..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA9) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA9);
																																			printf(" M9..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA10) > 1)
																																		{
																																			tc_strcat (sManMQMOSet,sMDLinofA10);
																																			printf(" M10.");fflush(stdout);
																																		}
																																		printf("\n MDL:V:P40:sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
																																	}
																																	else if(tc_strcmp(sMDLinofA1,"Single")==0)
																																	{
																																		if (tc_strlen(sMDLinofA2) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA2);
																																			printf("\n MDL:V:P41:M2..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA3) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA3);
																																			printf(" M3..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA4) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA4);
																																			printf(" M4..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA5) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA5);
																																			printf(" M5..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA6) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA6);
																																			printf(" M6..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA7) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA7);
																																			printf(" M7..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA8) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA8);
																																			printf(" M8..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA9) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA9);
																																			printf(" M9..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA10) > 1)
																																		{
																																			tc_strcat (sManSQMOSet,sMDLinofA10);
																																			printf(" M10.");fflush(stdout);
																																		}
																																		printf("\n MDL:V:P41sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n MDL:V:P41:Other case....");fflush(stdout);
																																	}
																																}
																																printf("\n MDL:V:P41:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
																																printf("\n MDL:V:P41:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
																															}
																															// checking for non mandatory module addresses.
																															printf("\n MDL:V:P41:If moduler BOM then check mandatory module address.. \n");fflush(stdout);
																															//Quering control tables for mandatory module address: Duplication allowed in BOM.
																															if(QRY_find2("Control Objects...", &MdlQry_Tag3));
																															if (MdlQry_Tag3)
																															{
																																printf("\n MDL:V:P42:Found Query MdlQry_Tag3 \n");fflush(stdout);
																															}
																															else
																															{
																																printf("\n MDL:V:P42:Not Found Query MdlQry_Tag3 \n");fflush(stdout);
																															}

																															MDL_qry_values3[0] = "NMANDTE";
																															MDL_qry_values3[1] = PartPlfFrm;
																															//MDL_qry_values3[1] = "MHCV";//hardcoded for testing
																															if(QRY_execute(MdlQry_Tag3, MDL_n_entry3, MDL_qry_entry3, MDL_qry_values3, &MDL_rsltCount3, &MDL_Obj_Tag3));
																															printf("\n MDL:V:P42:MDL_rsltCount3 :%d:", MDL_rsltCount3); fflush(stdout);
																															if(MDL_rsltCount3 > 0)
																															{
																																jk=0;
																																for(jk=0;jk<MDL_rsltCount3;jk++)
																																{
																																	sMDLinofA1=NULL;
																																	sMDLinofA2=NULL;
																																	sMDLinofA3=NULL;
																																	sMDLinofA4=NULL;
																																	sMDLinofA5=NULL;
																																	sMDLinofA6=NULL;
																																	sMDLinofA7=NULL;
																																	sMDLinofA8=NULL;
																																	sMDLinofA9=NULL;
																																	sMDLinofA10=NULL;
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																																	if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																																	printf("\n MDL:V:P42:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																																	printf("\n MDL:V:P42:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
																																	if(tc_strcmp(sMDLinofA1,"Multi")==0)
																																	{
																																		if (tc_strlen(sMDLinofA2) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA2);
																																			printf("\n MDL:V:P42:S2..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA3) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA3);
																																			printf(" S3..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA4) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA4);
																																			printf(" S4..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA5) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA5);
																																			printf(" S5..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA6) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA6);
																																			printf(" S6..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA7) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA7);
																																			printf(" S7..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA8) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA8);
																																			printf(" S8..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA9) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA9);
																																			printf(" S9..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA10) > 1)
																																		{
																																			tc_strcat (sNManMQMOSet,sMDLinofA10);
																																			printf(" S10.");fflush(stdout);
																																		}
																																		printf("\n MDL:V:P42:sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
																																	}
																																	else if(tc_strcmp(sMDLinofA1,"Single")==0)
																																	{
																																		if (tc_strlen(sMDLinofA2) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA2);
																																			printf("\n MDL:V:P43:S2..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA3) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA3);
																																			printf(" S3..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA4) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA4);
																																			printf(" S4..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA5) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA5);
																																			printf(" S5..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA6) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA6);
																																			printf(" S6..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA7) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA7);
																																			printf(" S7..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA8) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA8);
																																			printf(" S8..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA9) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA9);
																																			printf(" S9..");fflush(stdout);
																																		}
																																		if (tc_strlen(sMDLinofA10) > 1)
																																		{
																																			tc_strcat (sNManSQMOSet,sMDLinofA10);
																																			printf(" S10.");fflush(stdout);
																																		}
																																		printf("\n MDL:V:P43:sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
																																	}
																																	else
																																	{
																																		printf("\n MDL:V:P43:Other case....");fflush(stdout);
																																	}
																																}
																																printf("\n MDL:V:P43:Final sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
																																printf("\n MDL:V:P43:Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
																															}

																															//Expanding first level BOM for VC
																															printf ("\n MDL:V:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																															if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																															//if(CFM_find( "Latest Working", &MDL_rule )!=ITK_ok)PrintErrorStack();	//CONFIRM FOR CONTEXT.
																															if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																															if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																															if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																															if(BOM_set_window_top_line (p_window, NULLTAG, rev_list[ii], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																															//0qty
																															printf ("\n MDL:V:P44: PartTyp:%s \n",PartTyp);fflush(stdout);
																															if((tc_strcmp(PartTyp,"V")==0)||(tc_strcmp(PartTyp,"Vehicle")==0))
																															{
																																if(tc_strstr(BomComInfo1,"CON01") == NULL)
																																{
																																	printf ("\n MDL:Veh:CON02: BOMViewClosureRuleERC applied \n");fflush(stdout);
																																	if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																else if(tc_strstr(BomComInfo1,"CON02") == NULL)
																																{
																																	printf ("\n MDL:Veh:CON02: BOMViewClosureRuleERC1 applied \n");fflush(stdout);
																																	if(PIE_find_closure_rules2("BOMViewClosureRuleERC1",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																else if(tc_strstr(BomComInfo1,"CON05") == NULL)
																																{
																																	printf ("\n MDL:Veh:CON01: BOMLineSkipZeroQtyMaskUnconfig applied \n");fflush(stdout);
																																	if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																else
																																{
																																	printf ("\n MDL:Veh:CON01: TMLBOMExpandByQty applied \n");fflush(stdout);
																																	if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																																}
																																//if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																															}
																															else
																															{
																																printf ("\n MDL:V:P44: TMLBOMExpandByQty applied \n");fflush(stdout);
																																if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																															}
																															printf ("\n MDL:V:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																															if (MDLrulefound > 0)
																															{
																																MDLClosureTag = MDLclosureruleee[0];
																																printf ("\n MDL:V:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																															}
																															if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																															//0qty
																															if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																															printf("\n MDL:V:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);
																															
																															if(tc_strstr(BomComInfo1,"V004") == NULL)
																															{
																																printf("\n MDL:V:P46: Now checking for Mandatory multi occurance case..\n");fflush(stdout);
																																if((sManMQMOSet==NULL)|| (tc_strcmp(sManMQMOSet,"")==0))
																																{
																																	printf("\n MDL:V:P47:sManMQMOSet is NULL.\n");fflush(stdout);
																																}
																																else
																																{
																																	mdlcunt=0;
																																	piStringCount=0;
																																	if(EPM__parse_string(sManMQMOSet,",",&piStringCount,&AStringList)!=ITK_ok)PrintErrorStack();
																																	for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																																	{
																																		ManMOAddFlag=0;
																																		MDLAddress=NULL;
																																		MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																																		tc_strcpy (MDLAddress,"" );
																																		printf("\n MDL:V:P48:sManMQMOSet Part:%s ",AStringList[mdlcunt]);fflush(stdout);
																																		tc_strcat (MDLAddress,AStringList[mdlcunt]);
																																		printf ("\n MDL:V:P48:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
																																		if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																																		{
																																			printf("\n MDL:V:P48:MDLAddress is NULL.\n");fflush(stdout);
																																		}
																																		else
																																		{
																																			printf(" start.\n");fflush(stdout);
																																			iChild=0;
																																			for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																			{
																																				p_child_item_id=NULL;
																																				rel_sstats=NULL;
																																				Obj_PrtTyp=NULL;
																																				rev_iidd=NULL;
																																				PrtDRstus=NULL;
																																				PrtProjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:V:P48: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:V:P48: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																					if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																					{
																																						printf("\n MDL:V:P48:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																					}
																																					else
																																					{
																																						if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																						{
																																							sChildMdlAdd=NULL;
																																							sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																							tc_strcpy (sChildMdlAdd,"" );
																																							sChildMdlAdd = subString(p_child_item_id,4,5);
																																							printf("\n MDL:V:P48:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																							if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																							{
																																								ManMOAddFlag ++;
																																								printf("\n MDL:V:P48:module address found.:[%d] ", ManMOAddFlag);fflush(stdout);
																																								break; //As 1 or more times allowed, we are breaking it.
																																							}
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:V:P48:Final ManMOAddFlag.:[%d] ", ManMOAddFlag);fflush(stdout);
																																			if (ManMOAddFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				if((tc_strcmp(sManMOErr,"")==0) || (tc_strstr(sManMOErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sManMOErr,"\n");
																																					tc_strcat(sManMOErr,Partno);
																																					tc_strcat(sManMOErr,": ");
																																				}

																																				if(tc_strstr(sManMOErr,MDLAddress)==NULL)
																																				{
																																					iManMOErrFlag ++;
																																					if ((iManMOErrFlag ==20)|| (iManMOErrFlag ==40)||(iManMOErrFlag ==60)||(iManMOErrFlag ==80))
																																					{
																																						tc_strcat(sManMOErr,"\n");
																																					}
																																					tc_strcat(sManMOErr,MDLAddress);
																																					tc_strcat(sManMOErr,",");
																																					printf("\n MDL:V:P48:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManMOErr);fflush(stdout);
																																				}
																																				else
																																				{
																																					printf("\n MDL:V:P48:Module address already added... [%s]",MDLAddress);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				printf("\n MDLAddress is allowed and called multiple times...:[%s]\n",MDLAddress);fflush(stdout);
																																			}
																																		}
																																	}
																																}
																															}
																															if(tc_strstr(BomComInfo1,"V005") == NULL)
																															{
																																printf("\n MDL:V:P49: Now checking for Mandatory Single occurance case..\n");fflush(stdout);
																																if((sManSQMOSet==NULL)|| (tc_strcmp(sManSQMOSet,"")==0))
																																{
																																	printf("\n MDL:V:P49:sManSQMOSet is NULL.\n");fflush(stdout);
																																}
																																else
																																{
																																	mdlcunt=0;
																																	piStringCount=0;
																																	if(EPM__parse_string(sManSQMOSet,",",&piStringCount,&BStringList)!=ITK_ok)PrintErrorStack();
																																	for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																																	{
																																		ManSOAddFlag=0;
																																		MDLAddress=NULL;
																																		MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																																		tc_strcpy (MDLAddress,"" );
																																		printf("\n MDL:V:P49:sManSQMOSet Part:[%s]",BStringList[mdlcunt]);fflush(stdout);
																																		tc_strcat (MDLAddress,BStringList[mdlcunt]);
																																		printf ("\n MDL:V:P49:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
																																		if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																																		{
																																			printf("\n MDL:V:P49:MDLAddress is NULL..\n");fflush(stdout);
																																		}
																																		else
																																		{
																																			printf(" start..\n");fflush(stdout);
																																			iChild=0;
																																			for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																			{
																																				p_child_item_id=NULL;
																																				rel_sstats=NULL;
																																				Obj_PrtTyp=NULL;
																																				rev_iidd=NULL;
																																				PrtDRstus=NULL;
																																				PrtProjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:V:P49: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:V:P49: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																					if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																					{
																																						printf("\n MDL:V:P49: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																					}
																																					else
																																					{
																																						if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																						{
																																							sChildMdlAdd=NULL;
																																							sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																							tc_strcpy (sChildMdlAdd,"" );
																																							sChildMdlAdd = subString(p_child_item_id,4,5);
																																							printf("\n MDL:V:P49:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																							if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																							{
																																								ManSOAddFlag ++;
																																								printf("\n MDL:V:P49:ManSOAddFlag.:[%d] ", ManSOAddFlag);fflush(stdout);
																																								//break; //As only 1 qty allowed, we are NOT breaking it.
																																							}
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:V:P49:Final ManSOAddFlag.:[%d] ", ManSOAddFlag);fflush(stdout);
																																			if (ManSOAddFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				if((tc_strcmp(sManSOErr,"")==0) || (tc_strstr(sManSOErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sManSOErr,"\n");
																																					tc_strcat(sManSOErr,Partno);
																																					tc_strcat(sManSOErr,": ");
																																				}

																																				if(tc_strstr(sManSOErr,MDLAddress)==NULL)
																																				{
																																					iManSOFlag ++;
																																					if ((iManSOFlag ==20)|| (iManSOFlag ==40)||(iManSOFlag ==60)||(iManSOFlag ==80))
																																					{
																																						tc_strcat(sManSOErr,"\n");
																																					}
																																					tc_strcat(sManSOErr,MDLAddress);
																																					tc_strcat(sManSOErr,",");
																																					printf("\n MDL:V:P49:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSOErr);fflush(stdout);
																																				}
																																				else
																																				{
																																					printf("\n MDL:V:P49:Module address already added..- [%s]",MDLAddress);fflush(stdout);
																																				}
																																			}
																																			else if (ManSOAddFlag >1)
																																			{
																																				//Add to mandatory error set.
																																				if((tc_strcmp(sManSODupErr,"")==0) || (tc_strstr(sManSODupErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sManSODupErr,"\n");
																																					tc_strcat(sManSODupErr,Partno);
																																					tc_strcat(sManSODupErr,": ");
																																				}

																																				if(tc_strstr(sManSODupErr,MDLAddress)==NULL)
																																				{
																																					iManSODupFlag ++;
																																					if ((iManSODupFlag ==20)|| (iManSODupFlag ==40)||(iManSODupFlag ==60)||(iManSODupFlag ==80))
																																					{
																																						tc_strcat(sManSODupErr,"\n");
																																					}
																																					tc_strcat(sManSODupErr,MDLAddress);
																																					tc_strcat(sManSODupErr,",");
																																					printf("\n MDL:V:P49:Dup ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSODupErr);fflush(stdout);
																																				}
																																				else
																																				{
																																					printf("\n MDL:V:P49::MOdule address already added..: [%s]",MDLAddress);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				printf("\n MDL:V:P49:Single module address avail in BOM.. [%s]",MDLAddress);fflush(stdout);
																																			}
																																		}
																																	}
																																}
																															}
																															if(tc_strstr(BomComInfo1,"V006") == NULL)
																															{
																																printf("\n MDL:V:P50: Now checking for NON Mandatory multi occurance case..\n");fflush(stdout);
																																if((sNManMQMOSet==NULL)|| (tc_strcmp(sNManMQMOSet,"")==0))
																																{
																																	printf("\n MDL:V:P50:sNManMQMOSet is NULL.\n");fflush(stdout);
																																}
																																else
																																{
																																	mdlcunt=0;
																																	piStringCount=0;
																																	if(EPM__parse_string(sNManMQMOSet,",",&piStringCount,&CStringList)!=ITK_ok)PrintErrorStack();
																																	for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																																	{
																																		//NManMOAddFlag=0;
																																		MDLAddress=NULL;
																																		MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																																		tc_strcpy (MDLAddress,"" );
																																		printf("\n MDL:V:P50:sNManMQMOSet Part:%s ",CStringList[mdlcunt]);fflush(stdout);
																																		tc_strcat (MDLAddress,CStringList[mdlcunt]);
																																		printf ("\n MDL:V:P50:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
																																		if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																																		{
																																			printf("\n MDL:V:P50:MDLAddress is NULL.\n");fflush(stdout);
																																		}
																																		else
																																		{
																																			printf(" start.\n");fflush(stdout);
																																			iChild=0;
																																			/*for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																			{
																																				p_child_item_id=NULL;
																																				rel_sstats=NULL;
																																				Obj_PrtTyp=NULL;
																																				rev_iidd=NULL;
																																				PrtDRstus=NULL;
																																				PrtProjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																				printf("\n D: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n D: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																					if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																					{
																																						printf("\n D:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																					}
																																					else
																																					{
																																						if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																						{
																																							sChildMdlAdd=NULL;
																																							sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																							tc_strcpy (sChildMdlAdd,"" );
																																							sChildMdlAdd = subString(p_child_item_id,4,5);
																																							printf("\n D:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																							if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																							{
																																								NNManMOAddFlag ++;
																																								printf("\n D::module address found.:[%d] ", NManMOAddFlag);fflush(stdout);
																																								break; //As 1 or more times allowed, we are breaking it.
																																							}
																																						}
																																					}
																																				}
																																			}
																																			printf("\n D::Final NManMOAddFlag.:[%d] ", NManMOAddFlag);fflush(stdout);*/
																																			printf("\n MDL:V:P50:Check for Non Mandatory Multi Module address check.....Skipped, no need.");fflush(stdout);
																																		}
																																	}
																																}
																															}
																															if(tc_strstr(BomComInfo1,"V007") == NULL)
																															{
																																printf("\n MDL:V:P51: Now checking for non Mandatory Single occurance case..\n");fflush(stdout);
																																if((sNManSQMOSet==NULL)|| (tc_strcmp(sNManSQMOSet,"")==0))
																																{
																																	printf("\n MDL:V:P52:sNManSQMOSet is NULL.\n");fflush(stdout);
																																}
																																else
																																{
																																	mdlcunt=0;
																																	piStringCount=0;
																																	if(EPM__parse_string(sNManSQMOSet,",",&piStringCount,&DStringList)!=ITK_ok)PrintErrorStack();
																																	for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																																	{
																																		NManSOAddFlag=0;
																																		MDLAddress=NULL;
																																		MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																																		tc_strcpy (MDLAddress,"" );
																																		printf("\n MDL:V:P52:sNManSQMOSet Part:[%s]",DStringList[mdlcunt]);fflush(stdout);
																																		tc_strcat (MDLAddress,DStringList[mdlcunt]);
																																		printf ("\n MDL:V:P52:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
																																		if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																																		{
																																			printf("\n MDL:V:P52:MDLAddress is NULL..\n");fflush(stdout);
																																		}
																																		else
																																		{
																																			printf(" start..\n");fflush(stdout);
																																			iChild=0;
																																			for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																			{
																																				p_child_item_id=NULL;
																																				rel_sstats=NULL;
																																				Obj_PrtTyp=NULL;
																																				rev_iidd=NULL;
																																				PrtDRstus=NULL;
																																				PrtProjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:V:P52: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:V:P52: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																					if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																					{
																																						printf("\n MDL:V:P52:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																					}
																																					else
																																					{
																																						if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																						{
																																							sChildMdlAdd=NULL;
																																							sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																							tc_strcpy (sChildMdlAdd,"" );
																																							sChildMdlAdd = subString(p_child_item_id,4,5);
																																							printf("\n MDL:V:P52:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																							if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																							{
																																								NManSOAddFlag ++;
																																								printf("\n MDL:V:P52:NManSOAddFlag.:[%d] ", NManSOAddFlag);fflush(stdout);
																																								//break; //As only 1 qty allowed, we are NOT breaking it.
																																							}
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:V:P52:Final NManSOAddFlag.:[%d] ", NManSOAddFlag);fflush(stdout);
																																			if (NManSOAddFlag ==0)
																																			{
																																				//NO need to Add to mandatory error set.
																																				printf("\n MDL:V:P52:Non Mandatory single occurance %s, not called in BOM...",MDLAddress);fflush(stdout);
																																			}
																																			else if (NManSOAddFlag >1)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:V:P52:Non Mandatory single occurance, but duplicated. %s....",MDLAddress);fflush(stdout);
																																				if((tc_strcmp(sNManSODupErr,"")==0) || (tc_strstr(sNManSODupErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sNManSODupErr,"\n");
																																					tc_strcat(sNManSODupErr,Partno);
																																					tc_strcat(sNManSODupErr,": ");
																																				}
																																				if(tc_strstr(sNManSODupErr,MDLAddress)==NULL)
																																				{
																																					iNManSODupFlag ++;
																																					if ((iNManSODupFlag ==20)|| (iNManSODupFlag ==40)||(iNManSODupFlag ==60)||(iNManSODupFlag ==80))
																																					{
																																						tc_strcat(sNManSODupErr,"\n");
																																					}
																																					tc_strcat(sNManSODupErr,MDLAddress);
																																					tc_strcat(sNManSODupErr,",");
																																					printf("\n MDL:V:P52:Non Mandatory single occurance, but duplicated.%s added to error set.:[%s]",MDLAddress,sNManSODupErr);fflush(stdout);
																																				}
																																			}
																																			else
																																			{
																																				printf("\n MDL:V:P52:Non Mandatory single occurance only, so checking qty. [%s]",MDLAddress);fflush(stdout);
																																				//Check for qty now.//Mohan
																																			}
																																		}
																																	}
																																}
																															}
																															if(tc_strstr(BomComInfo1,"V008") == NULL)
																															{
																																printf("\n MDL:V:P53:checking for mandatory CP module addresses.\n");fflush(stdout);
																																//Quering control tables for mandatory module address: Duplication allowed in BOM.
																																if(QRY_find2("Control Objects...", &MdlQry_Tag4));
																																if (MdlQry_Tag4)
																																{
																																	printf("\n MDL:V:P53:Found Query MdlQry_Tag4 \n");fflush(stdout);
																																}
																																else
																																{
																																	printf("\n MDL:V:P53:Not Found Query MdlQry_Tag4 \n");fflush(stdout);
																																}
																																MDL_qry_values4[0] = "CPMODUL";
																																MDL_qry_values4[1] = PartPlfFrm;
																																//MDL_qry_values4[1] = "MHCV";//hardcoded for testing
																																if(QRY_execute(MdlQry_Tag4, MDL_n_entry4, MDL_qry_entry4, MDL_qry_values4, &MDL_rsltCount4, &MDL_Obj_Tag4));
																																printf("\n MDL:V:P53:MDL_rsltCount4 :%d:", MDL_rsltCount4); fflush(stdout);
																																if(MDL_rsltCount4 > 0)
																																{
																																	jk=0;
																																	for(jk=0;jk<MDL_rsltCount4;jk++)
																																	{
																																		sMDLinofA1=NULL;
																																		sMDLinofA2=NULL;
																																		sMDLinofA3=NULL;
																																		sMDLinofA4=NULL;
																																		sMDLinofA5=NULL;
																																		sMDLinofA6=NULL;
																																		sMDLinofA7=NULL;
																																		sMDLinofA8=NULL;
																																		sMDLinofA9=NULL;
																																		sMDLinofA10=NULL;
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																																		if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																																		printf("\n MDL:V:P53:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																																		printf("\n MDL:V:P53:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);

																																		iChild =0 ;
																																		for(iChild =0 ; iChild < VCChildCunt; iChild++)
																																		{
																																			p_child_item_id=NULL;
																																			rel_sstats=NULL;
																																			Obj_PrtTyp=NULL;
																																			rev_iidd=NULL;
																																			PrtDRstus=NULL;
																																			PrtProjj=NULL;

																																			if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																			if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																			printf("\n MDL:V:P53: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																			//NEED TO DISCUSS BELOW LCs
																																			//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																			//If child is NR WIP, it should be in same DML.
																																			if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																			{
																																				if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																				if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:V:P53:Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																				if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																				{
																																					printf("\n MDL:V:P53: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																				}
																																				else
																																				{
																																					if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAdd=NULL;
																																						sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAdd,"" );
																																						sChildMdlAdd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:V:P53:sMDLinofA1:[%s] and  sChildMdlAdd:[%s]\n",sMDLinofA1,sChildMdlAdd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA1,sChildMdlAdd)==0)
																																						{
																																							iChildd =0 ;
																																							for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																							{
																																								CPModuleAvailFlag=0;
																																								p_child_item_id=NULL;
																																								rel_sstatss=NULL;
																																								Obj_PrtTypp=NULL;
																																								rev_iiddd=NULL;
																																								PrtDRstuss=NULL;
																																								PrtProjjj=NULL;

																																								if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																								if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																								printf("\n MDL:V:P53: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																								//NEED TO DISCUSS BELOW LCs
																																								//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																								//If child is NR WIP, it should be in same DML.
																																								if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																								{
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																									printf("\n MDL:V:P53: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																									if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																									{
																																										sChildMdlAddd=NULL;
																																										sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																										tc_strcpy (sChildMdlAddd,"" );
																																										sChildMdlAddd = subString(p_child_item_id,4,5);
																																										printf("\n MDL:V:P53:sMDLinofA2:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA2,sChildMdlAddd);fflush(stdout);
																																										if(tc_strcmp(sMDLinofA2,sChildMdlAddd)==0)
																																										{
																																											CPModuleAvailFlag ++;
																																											printf("\n MDL:V:P53:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																											break;
																																										}
																																									}
																																								}
																																							}
																																							printf("\n MDL:V:P53:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							if (CPModuleAvailFlag ==0)
																																							{
																																								//Add to mandatory error set.
																																								printf("\n MDL:V:P53:CP modules not available...");fflush(stdout);
																																								if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																								{
																																									//tc_strcat(sCPModuleAvailErr,"\n");
																																									tc_strcat(sCPModuleAvailErr,Partno);
																																									tc_strcat(sCPModuleAvailErr,": ");
																																								}
																																								if(tc_strstr(sCPModuleAvailErr,sMDLinofA2)==NULL)
																																								{
																																									sCPModuleFlag ++;
																																									if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																									{
																																										tc_strcat(sCPModuleAvailErr,"\n");
																																									}
																																									tc_strcat(sCPModuleAvailErr,sMDLinofA2);
																																									tc_strcat(sCPModuleAvailErr,",");
																																									printf("\n MDL:V:P53:CP module address.%s added to error set.:[%s]",sMDLinofA2,sCPModuleAvailErr);fflush(stdout);
																																								}
																																							}
																																						}
																																						else if(tc_strcmp(sMDLinofA3,sChildMdlAdd)==0)
																																						{
																																							iChildd =0 ;
																																							for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																							{
																																								CPModuleAvailFlag=0;
																																								p_child_item_id=NULL;
																																								rel_sstatss=NULL;
																																								Obj_PrtTypp=NULL;
																																								rev_iiddd=NULL;
																																								PrtDRstuss=NULL;
																																								PrtProjjj=NULL;

																																								if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																								if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																								printf("\n MDL:V:P54: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																								//NEED TO DISCUSS BELOW LCs
																																								//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																								//If child is NR WIP, it should be in same DML.
																																								if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																								{
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																									printf("\n MDL:V:P54: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																									if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																									{
																																										sChildMdlAddd=NULL;
																																										sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																										tc_strcpy (sChildMdlAddd,"" );
																																										sChildMdlAddd = subString(p_child_item_id,4,5);
																																										printf("\n MDL:V:P54:sMDLinofA4:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA4,sChildMdlAddd);fflush(stdout);
																																										if(tc_strcmp(sMDLinofA4,sChildMdlAddd)==0)
																																										{
																																											CPModuleAvailFlag ++;
																																											printf("\n MDL:V:P54:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																											break;
																																										}
																																									}
																																								}
																																							}
																																							printf("\n MDL:V:P54:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							if (CPModuleAvailFlag ==0)
																																							{
																																								//Add to mandatory error set.
																																								printf("\n MDL:V:P54:CP modules not available...");fflush(stdout);
																																								if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																								{
																																									//tc_strcat(sCPModuleAvailErr,"\n");
																																									tc_strcat(sCPModuleAvailErr,Partno);
																																									tc_strcat(sCPModuleAvailErr,": ");
																																								}
																																								if(tc_strstr(sCPModuleAvailErr,sMDLinofA4)==NULL)
																																								{
																																									sCPModuleFlag ++;
																																									if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																									{
																																										tc_strcat(sCPModuleAvailErr,"\n");
																																									}
																																									tc_strcat(sCPModuleAvailErr,sMDLinofA4);
																																									tc_strcat(sCPModuleAvailErr,",");
																																									printf("\n MDL:V:P54:CP3 module address.%s added to error set.:[%s]",sMDLinofA4,sCPModuleAvailErr);fflush(stdout);

																																								}
																																							}
																																						}
																																						else if(tc_strcmp(sMDLinofA5,sChildMdlAdd)==0)
																																						{
																																							iChildd =0 ;
																																							for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																							{
																																								CPModuleAvailFlag=0;
																																								p_child_item_id=NULL;
																																								rel_sstatss=NULL;
																																								Obj_PrtTypp=NULL;
																																								rev_iiddd=NULL;
																																								PrtDRstuss=NULL;
																																								PrtProjjj=NULL;

																																								if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																								if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																								printf("\n MDL:V:P55: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																								//NEED TO DISCUSS BELOW LCs
																																								//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																								//If child is NR WIP, it should be in same DML.
																																								if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																								{
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																									printf("\n MDL:V:P55: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																									if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																									{
																																										sChildMdlAddd=NULL;
																																										sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																										tc_strcpy (sChildMdlAddd,"" );
																																										sChildMdlAddd = subString(p_child_item_id,4,5);
																																										printf("\n MDL:V:P55:sMDLinofA6:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA6,sChildMdlAddd);fflush(stdout);
																																										if(tc_strcmp(sMDLinofA6,sChildMdlAddd)==0)
																																										{
																																											CPModuleAvailFlag ++;
																																											printf("\n MDL:V:P55:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																											break;
																																										}
																																									}
																																								}
																																							}
																																							printf("\n MDL:V:P55:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							if (CPModuleAvailFlag ==0)
																																							{
																																								//Add to mandatory error set.
																																								printf("\n MDL:V:P55:CP modules not available...");fflush(stdout);
																																								if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																								{
																																									//tc_strcat(sCPModuleAvailErr,"\n");
																																									tc_strcat(sCPModuleAvailErr,Partno);
																																									tc_strcat(sCPModuleAvailErr,": ");
																																								}
																																								if(tc_strstr(sCPModuleAvailErr,sMDLinofA6)==NULL)
																																								{
																																									sCPModuleFlag ++;
																																									if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																									{
																																										tc_strcat(sCPModuleAvailErr,"\n");
																																									}
																																									tc_strcat(sCPModuleAvailErr,sMDLinofA6);
																																									tc_strcat(sCPModuleAvailErr,",");
																																									printf("\n MDL:V:P55:CP3 module address.%s added to error set.:[%s]",sMDLinofA6,sCPModuleAvailErr);fflush(stdout);
																																								}
																																							}
																																						}
																																						else if(tc_strcmp(sMDLinofA7,sChildMdlAdd)==0)
																																						{
																																							iChildd =0 ;
																																							for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																							{
																																								CPModuleAvailFlag=0;
																																								p_child_item_id=NULL;
																																								rel_sstatss=NULL;
																																								Obj_PrtTypp=NULL;
																																								rev_iiddd=NULL;
																																								PrtDRstuss=NULL;
																																								PrtProjjj=NULL;

																																								if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																								if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																								printf("\n MDL:V:P56: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																								//NEED TO DISCUSS BELOW LCs
																																								//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																								//If child is NR WIP, it should be in same DML.
																																								if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																								{
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																									printf("\n MDL:V:P56: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																									if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																									{
																																										sChildMdlAddd=NULL;
																																										sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																										tc_strcpy (sChildMdlAddd,"" );
																																										sChildMdlAddd = subString(p_child_item_id,4,5);
																																										printf("\n MDL:V:P56:sMDLinofA8:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA8,sChildMdlAddd);fflush(stdout);
																																										if(tc_strcmp(sMDLinofA8,sChildMdlAddd)==0)
																																										{
																																											CPModuleAvailFlag ++;
																																											printf("\n MDL:V:P56:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																											break;
																																										}
																																									}
																																								}
																																							}
																																							printf("\n MDL:V:P56:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							if (CPModuleAvailFlag ==0)
																																							{
																																								//Add to mandatory error set.
																																								printf("\n MDL:V:P56:CP modules not available...");fflush(stdout);
																																								if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																								{
																																									//tc_strcat(sCPModuleAvailErr,"\n");
																																									tc_strcat(sCPModuleAvailErr,Partno);
																																									tc_strcat(sCPModuleAvailErr,": ");
																																								}
																																								if(tc_strstr(sCPModuleAvailErr,sMDLinofA8)==NULL)
																																								{
																																									sCPModuleFlag ++;
																																									if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																									{
																																										tc_strcat(sCPModuleAvailErr,"\n");
																																									}
																																									tc_strcat(sCPModuleAvailErr,sMDLinofA8);
																																									tc_strcat(sCPModuleAvailErr,",");
																																									printf("\n MDL:V:P56:CP3 module address.%s added to error set.:[%s]",sMDLinofA8,sCPModuleAvailErr);fflush(stdout);
																																								}
																																							}
																																						}
																																						else if(tc_strcmp(sMDLinofA9,sChildMdlAdd)==0)
																																						{
																																							iChildd =0 ;
																																							for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																							{
																																								CPModuleAvailFlag=0;
																																								p_child_item_id=NULL;
																																								rel_sstatss=NULL;
																																								Obj_PrtTypp=NULL;
																																								rev_iiddd=NULL;
																																								PrtDRstuss=NULL;
																																								PrtProjjj=NULL;

																																								if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																								if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																								printf("\n MDL:V:P57: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																								//NEED TO DISCUSS BELOW LCs
																																								//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																								//If child is NR WIP, it should be in same DML.
																																								if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																								{
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																									if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																									if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																									printf("\n MDL:V:P57: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																									if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																									{
																																										sChildMdlAddd=NULL;
																																										sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																										tc_strcpy (sChildMdlAddd,"" );
																																										sChildMdlAddd = subString(p_child_item_id,4,5);
																																										printf("\n MDL:V:P57:sMDLinofA10:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA10,sChildMdlAddd);fflush(stdout);
																																										if(tc_strcmp(sMDLinofA10,sChildMdlAddd)==0)
																																										{
																																											CPModuleAvailFlag ++;
																																											printf("\n MDL:V:P57:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																											break;
																																										}
																																									}
																																								}
																																							}
																																							printf("\n MDL:V:P57:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							if (CPModuleAvailFlag ==0)
																																							{
																																								//Add to mandatory error set.
																																								printf("\n MDL:V:P57:CP modules not available...");fflush(stdout);
																																								if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																								{
																																									//tc_strcat(sCPModuleAvailErr,"\n");
																																									tc_strcat(sCPModuleAvailErr,Partno);
																																									tc_strcat(sCPModuleAvailErr,": ");
																																								}
																																								if(tc_strstr(sCPModuleAvailErr,sMDLinofA10)==NULL)
																																								{
																																									sCPModuleFlag ++;
																																									if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																									{
																																										tc_strcat(sCPModuleAvailErr,"\n");
																																									}
																																									tc_strcat(sCPModuleAvailErr,sMDLinofA10);
																																									tc_strcat(sCPModuleAvailErr,",");
																																									printf("\n MDL:V:P57:CP3 module address.%s added to error set.:[%s]",sMDLinofA10,sCPModuleAvailErr);fflush(stdout);
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																	printf("\n MDL:V:P58:Final sNManMQMOSet: %s",sCPModuleAvailErr); fflush(stdout);
																																}
																															}
																															if(tc_strstr(BomComInfo1,"V009") == NULL)
																															{
																																printf("\n MDL:V:P59:Checking bl_quantity ............................VCChildCunt:%d\n",VCChildCunt);fflush(stdout);
																																char	*sChildPartType		=  NULL;
																																sChildPartType =(char *) MEM_alloc(200 * sizeof(char *));
																																iChildqty =0 ;
																																for(iChildqty =0 ; iChildqty < VCChildCunt; iChildqty++)
																																{
																																	p_child_item_id=NULL;
																																	rel_sstatss=NULL;
																																	Obj_PrtTypp=NULL;
																																	rev_iiddd=NULL;
																																	PrtDRstuss=NULL;
																																	ChildPartQty=NULL;
																																	PrtProjjj=NULL;
																																	printf("\n MDL:V:P59:taken child :%d \n",iChildqty);fflush(stdout);
																																	if(AOM_ask_value_string(VCChildobject[iChildqty], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																	printf("\n MDL:V:P59: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																	//NEED TO DISCUSS BELOW LCs
																																	//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																	//If child is NR WIP, it should be in same DML.
																																	if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																	{
																																		if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																		if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																		if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																		if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																		if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_quantity",&ChildPartQty)!=ITK_ok)PrintErrorStack();
																																		printf("\n MDL:V:P59: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s ChildPartQty:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj,ChildPartQty);fflush(stdout);

																																		tc_strcpy(sChildPartType,"");
																																		tc_strcpy(sChildPartType,",");
																																		tc_strcat(sChildPartType,Obj_PrtTypp);
																																		tc_strcat(sChildPartType,",");
																																		printf("\n MDL:V:P59:sChildPartType:: [%s]",sChildPartType);fflush(stdout);
																																		if(tc_strstr(BomComInfo5,sChildPartType) != NULL)
																																		{
																																			printf("\n MDL:V:P59Dummy/IFD/CP should be with 0 qty:%s ", p_child_item_id);fflush(stdout);
																																			if(ChildPartQty)
																																			{
																																				iChildPartQty=atoi(ChildPartQty);
																																			}
																																			printf("\n MDL:V:P59:iChildPartQty:: [%d]",iChildPartQty);fflush(stdout);
																																			if(iChildPartQty==0)
																																			{
																																				printf("\n MDL:V:P59:Dummy/IFD/CP is with 0 qty:%s ", p_child_item_id);fflush(stdout);
																																			}
																																			else
																																			{
																																				printf("\n MDL:V:P59:Dummy/IFD/CP is NOT with 0 qty:%s ", p_child_item_id);fflush(stdout);
																																				//Add to mandatory error set.
																																				if((tc_strcmp(OtherZeroQtySet,"")==0) || (tc_strstr(OtherZeroQtySet,Partno)==NULL))
																																				{
																																					//tc_strcat(OtherZeroQtySet,"\n");
																																					tc_strcat(OtherZeroQtySet,Partno);
																																					tc_strcat(OtherZeroQtySet,": ");
																																				}
																																				if(tc_strstr(OtherZeroQtySet,p_child_item_id)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(OtherZeroQtySet,"\n");
																																					}
																																					tc_strcat(OtherZeroQtySet,p_child_item_id);
																																					tc_strcat(OtherZeroQtySet,",");
																																					printf("\n MDL:V:P59:Dummy/IFD/CP.%s added to error set.:[%s]",p_child_item_id,OtherZeroQtySet);fflush(stdout);
																																				}
																																			}
																																		}
																																		else
																																		{
																																			//Other than Dummy/IFD/CP
																																			printf("\n MDL:V:P60:Other than Dummy/IFD/CP should be with 1 qty:%s ", p_child_item_id);fflush(stdout);
																																			if(ChildPartQty)
																																			{
																																				iChildPartQty=atoi(ChildPartQty);
																																			}
																																			printf("\n MDL:V:P60:iChildPartQty:: [%d]",iChildPartQty);fflush(stdout);
																																			if((iChildPartQty==0)||(iChildPartQty==1)||((iChildPartQty >0)&& (iChildPartQty < 1)))
																																			{
																																				printf("\n MDL:V:P60:Module is with 0/1 qty:%s ", p_child_item_id);fflush(stdout);
																																			}
																																			else
																																			{
																																				printf("\n MDL:V:P60:Module is NOT with 0/1 qty:%s ", p_child_item_id);fflush(stdout);
																																				if((tc_strcmp(inValidQtySet,"")==0) || (tc_strstr(inValidQtySet,Partno)==NULL))
																																				{
																																					//tc_strcat(inValidQtySet,"\n");
																																					tc_strcat(inValidQtySet,Partno);
																																					tc_strcat(inValidQtySet,": ");
																																				}
																																				if(tc_strstr(inValidQtySet,p_child_item_id)==NULL)
																																				{
																																					iQtyAflag ++;
																																					if ((iQtyAflag ==10)|| (iQtyAflag ==20)||(iQtyAflag ==30)||(iQtyAflag ==40))
																																					{
																																						tc_strcat(inValidQtySet,"\n");
																																					}
																																					tc_strcat(inValidQtySet,p_child_item_id);
																																					tc_strcat(inValidQtySet,",");
																																					printf("\n MDL:V:P60:CP module address [%s] added to error set.:[%s]",sMDLinofA2,inValidQtySet);fflush(stdout);
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																														break; //COnsidered only one released revision.
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
															else
															{
																printf("\n MDL:V:P61:FAILED for V DML FROMTO-ststus is NULL.");fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);
																decision = EPM_nogo;
																return decision;
															}
															//if(TaskCMRef) MEM_free(TaskCMRef);
															//if(rev_list) MEM_free(rev_list);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
				{
					printf("\n MDL:GM:P12:inside ChangeRequestRevision loop for GM DML.\n");fflush(stdout);
					//if(AOM_ask_value_string(DMLTag,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
					printf("\n MDL:GM:P13:sDMLno....:%s.",sDMLno);fflush(stdout);
					if(ITEM_find_item (sDMLno, &item_tag)!=ITK_ok)PrintErrorStack();
					if(item_tag==NULLTAG)
					{
						printf("\n MDL:GM:P14:item_tag is NULL.\n");fflush(stdout);
						return decision;
					}
					else
					{
						printf("\n MDL:GM:P15:item_tag found.\n");fflush(stdout);
						if(ITEM_ask_latest_rev (item_tag, &DMLTagg)!=ITK_ok)PrintErrorStack();
						if(DMLTagg==NULLTAG)
						{
							printf("\n MDL:GM:P16:Object not found in Teamcenter...!!\n");fflush(stdout);
							return decision;
						}
						else
						{
							//DML Details:
							if(AOM_ask_value_string(DMLTagg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(DMLTagg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(DMLTagg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(DMLTagg,"t5_cDRstatus",&DMLDR)!=ITK_ok)PrintErrorStack();
							printf("\n MDL:GM:P17: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s] DMLDR:[%s]",DMLtype,DMLProj,PlntToPlnt,DMLDR);fflush(stdout);
							if(AOM_ask_value_string(DMLTagg,"t5_ERCBusiUt",&DMLBUnit)!=ITK_ok)PrintErrorStack();
							printf("\n MDL:GM:P21:DMLBUnit:: %s ",DMLBUnit);fflush(stdout);
							tc_strcpy(sDMLBUnit,"");
							tc_strcpy(sDMLBUnit,",");
							tc_strcat(sDMLBUnit,DMLBUnit);
							tc_strcat(sDMLBUnit,",");
							printf(" and sDMLBUnit: %s \n",sDMLBUnit);fflush(stdout);
							if(tc_strstr(BomComInfo9,sDMLBUnit) != NULL)
							{
								tc_strcpy(sDMLrlstype,"");
								tc_strcpy(sDMLrlstype,",");
								tc_strcat(sDMLrlstype,DMLtype);
								tc_strcat(sDMLrlstype,",");
								printf("\n MDL:GM:P18:sDMLrlstype:: %s Current  DMLtype:%s",sDMLrlstype,DMLtype);fflush(stdout);
								tc_strcpy(sDMLDR,"");
								tc_strcpy(sDMLDR,",");
								tc_strcat(sDMLDR,DMLDR);
								tc_strcat(sDMLDR,",");
								printf("\n MDL:GM:P19:sDMLDR:: %s Current  DMLDR:%s",sDMLDR,DMLDR);fflush(stdout);
								//for TODR DML only
								if(tc_strstr(BomComInfo8,sDMLrlstype) != NULL)
								{
									if(tc_strstr(BomComInfo1,sDMLno) != NULL)
									{
										printf("\n MDL:GM:P20:DML has been bypassed. \n");fflush(stdout);
									}
									else
									{
										if(tc_strstr(BomComInfo1,"M002") == NULL)
										{
											printf("\n MDL:GM:P21:Inside Gate Maturation DML..................");fflush(stdout);
											if(PlntToPlnt != NULL)
											{
												//From Plant-Toplant not considered.
												if(tc_strstr(BomComInfo2,PlntToPlnt) == NULL)
												{
													Tskcnt=0;
													if(AOM_ask_value_tags(DMLTagg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
													printf("\n MDL:GM:P22::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
													if (Tskcnt>0)
													{
														for (tsk=0;tsk<Tskcnt ;tsk++ )
														{
															if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
															printf("\n MDL:GM:P23:Tsk_object_type is :%s\n",Tsk_object_type);fflush(stdout);

															if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
															{
																if(TaskDsgGrp) TaskDsgGrp=NULL;
																if(AOM_UIF_ask_value(Dml_tasks[tsk],"item_id",&TskNm)!=ITK_ok)PrintErrorStack();
																TaskDsgGrp=subString(TskNm,11,2);
																printf("\n MDL:GM:P24: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] Toplnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,Toplnt);fflush(stdout);
																if(tc_strstr(TaskDsgGrp,"00") != NULL)
																{
																	if(GRM_find_relation_type("CMReferences", &tsk_CMRef_type)!=ITK_ok)PrintErrorStack();
																	if (tsk_CMRef_type!=NULLTAG)
																	{
																		//Getting parts from CMReferences
																		CMRefcount=0;
																		if(GRM_list_secondary_objects_only(Dml_tasks[tsk],tsk_CMRef_type,&CMRefcount,&TaskCMRef)!=ITK_ok)PrintErrorStack();
																		printf("\n MDL:GM:P25: Task CMRefcount: %d",CMRefcount);fflush(stdout);
																		if(CMRefcount > 0)
																		{
																			Mstr=0;
																			for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																			{
																				printf("\n MDL:GM:P26:Design Mstr:%d",Mstr);fflush(stdout);
																				if(AOM_ask_value_string(TaskCMRef[Mstr],"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
																				printf("\n MDL:GM:P27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
																				if(strcmp(Prt_object_type,"Folder")!=0)
																				{
																					// put condition for desi rev , to avoid other attachments.
																					if(AOM_ask_value_string(TaskCMRef[Mstr],"item_id",&PartMstr_no)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(TaskCMRef[Mstr], "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																					if(AOM_UIF_ask_value(TaskCMRef[Mstr], "release_status_list", &Prtrel_status)!=ITK_ok)PrintErrorStack();
																					printf("\n MDL:GM:P28:PartMstr_no %s attach part revision:%s and Prtrel_status:%s", PartMstr_no,Prtrev_idd,Prtrel_status);fflush(stdout);

																					Item_count=0;
																					//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																					All_item_tag= t5GetItemRevison(PartMstr_no);
																					if(All_item_tag==NULLTAG)
																					{
																						printf("\n MDL:GM:P29:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																						//return 0;
																					}
																					else
																					{
																						if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																						printf("\n MDL:GM:P30:Total rev found: %d.", Item_count);fflush(stdout);
																						if(Item_count > 0)
																						{
																							ii=0;
																							sCPModuleFlag=0;
																							for(ii=Item_count-1;ii>=0;ii--)
																							{
																								PartPlfFrm=NULL;
																								PartPlfFrm =(char *) MEM_alloc(200 * sizeof(char *));
																								rel_status_cunt=0;
																								if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_Platform", &PartPlfFrm)!=ITK_ok)PrintErrorStack();
																								if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																								if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																								if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																								if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																								printf("\n MDL:GM:P31:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s PartPlfFrm:[%s]", Partno,rev_idd,PartTyp,rel_status,sPartObjyp,PartPlfFrm);fflush(stdout);
																								//check revison
																								chkBOMComFlag=0;
																								printf("\n MDL:GM:P32:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																								if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																								{
																									if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																									{
																										chkBOMComFlag=1;
																									}
																									else if(tc_strstr(BomComInfo1,"M003") == NULL)
																									{
																										chkBOMComFlag=1;
																									}
																									printf("\n MDL:GM:P33:chkBOMComFlag:%d",chkBOMComFlag);fflush(stdout);
																									if(chkBOMComFlag >0)
																									{
																										tc_strcpy(sPartTyp,"");
																										tc_strcpy(sPartTyp,",");
																										tc_strcat(sPartTyp,PartTyp);
																										tc_strcat(sPartTyp,",");
																										printf("\n MDL:GM:P34:sPartTyp:: %s Current  PartTyp:%s",sPartTyp,PartTyp);fflush(stdout);
																										if(tc_strstr(BomComInfo4,sPartTyp) != NULL)
																										{
																											//Check If platform value is NULL.
																											if((PartPlfFrm==NULL)|| (tc_strcmp(PartPlfFrm,"")==0))
																											{
																												printf("\n MDL:GM:P35:Part Platform value is NULL.... \n");fflush(stdout);
																												EMH_clear_errors();
																												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Part platform value is NULL. \nPlease get it updated, then you can sign off this task. ",Partno);
																												decision = EPM_nogo;
																												return decision;
																											}
																											printf("\n MDL:GM:P36:If moduler BOM then check mandatory module address, Duplication allowed in BOM. \n");fflush(stdout);
																											//Quering control tables for mandatory module address: Duplication allowed in BOM.
																											if(QRY_find2("Control Objects...", &MdlQry_Tag));
																											if (MdlQry_Tag)
																											{
																												printf("\n MDL:GM:P37:Found Query MdlQry_Tag \n");fflush(stdout);
																											}
																											else
																											{
																												printf("\n MDL:GM:P38:Not Found Query MdlQry_Tag \n");fflush(stdout);
																											}

																											MDL_qry_values2[0] = "MANDTE";
																											MDL_qry_values2[1] = PartPlfFrm;
																											if(QRY_execute(MdlQry_Tag, MDL_n_entry2, MDL_qry_entry2, MDL_qry_values2, &MDL_rsltCount2, &MDL_Obj_Tag));
																											printf(" \n MDL:GM:P39:MDL_rsltCount2 :%d:", MDL_rsltCount2); fflush(stdout);
																											if(MDL_rsltCount2 > 0)
																											{
																												for(jk=0;jk<MDL_rsltCount2;jk++)
																												{
																													sMDLinofA1=NULL;
																													sMDLinofA2=NULL;
																													sMDLinofA3=NULL;
																													sMDLinofA4=NULL;
																													sMDLinofA5=NULL;
																													sMDLinofA6=NULL;
																													sMDLinofA7=NULL;
																													sMDLinofA8=NULL;
																													sMDLinofA9=NULL;
																													sMDLinofA10=NULL;
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																													printf("\n MDL:GM:P40:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																													printf("\n MDL:GM:P40:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
																													if(tc_strcmp(sMDLinofA1,"Multi")==0)
																													{
																														if (tc_strlen(sMDLinofA2) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA2);
																															printf("\n MDL:GM:P40:M2..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA3) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA3);
																															printf(" M3..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA4) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA4);
																															printf(" M4..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA5) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA5);
																															printf(" M5..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA6) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA6);
																															printf(" M6..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA7) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA7);
																															printf(" M7..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA8) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA8);
																															printf(" M8..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA9) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA9);
																															printf(" M9..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA10) > 1)
																														{
																															tc_strcat (sManMQMOSet,sMDLinofA10);
																															printf(" M10.");fflush(stdout);
																														}
																														printf("\n MDL:GM:P40:sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
																													}
																													else if(tc_strcmp(sMDLinofA1,"Single")==0)
																													{
																														if (tc_strlen(sMDLinofA2) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA2);
																															printf("\n MDL:GM:P41:M2..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA3) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA3);
																															printf(" M3..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA4) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA4);
																															printf(" M4..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA5) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA5);
																															printf(" M5..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA6) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA6);
																															printf(" M6..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA7) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA7);
																															printf(" M7..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA8) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA8);
																															printf(" M8..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA9) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA9);
																															printf(" M9..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA10) > 1)
																														{
																															tc_strcat (sManSQMOSet,sMDLinofA10);
																															printf(" M10.");fflush(stdout);
																														}
																														printf("\n MDL:GM:P41sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
																													}
																													else
																													{
																														printf("\n MDL:GM:P41:Other case....");fflush(stdout);
																													}
																												}
																												printf("\n MDL:GM:P41:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
																												printf("\n MDL:GM:P41:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
																											}
																											// checking for non mandatory module addresses.

																											printf("\n MDL:GM:P41:If moduler BOM then check mandatory module address.. \n");fflush(stdout);
																											//Quering control tables for mandatory module address: Duplication allowed in BOM.
																											if(QRY_find2("Control Objects...", &MdlQry_Tag3));
																											if (MdlQry_Tag3)
																											{
																												printf("\n MDL:GM:P42:Found Query MdlQry_Tag3 \n");fflush(stdout);
																											}
																											else
																											{
																												printf("\n MDL:GM:P42:Not Found Query MdlQry_Tag3 \n");fflush(stdout);
																											}

																											MDL_qry_values3[0] = "NMANDTE";
																											MDL_qry_values3[1] = PartPlfFrm;
																											if(QRY_execute(MdlQry_Tag3, MDL_n_entry3, MDL_qry_entry3, MDL_qry_values3, &MDL_rsltCount3, &MDL_Obj_Tag3));
																											printf("\n MDL:GM:P42:MDL_rsltCount3 :%d:", MDL_rsltCount3); fflush(stdout);
																											if(MDL_rsltCount3 > 0)
																											{
																												jk=0;
																												for(jk=0;jk<MDL_rsltCount3;jk++)
																												{
																													sMDLinofA1=NULL;
																													sMDLinofA2=NULL;
																													sMDLinofA3=NULL;
																													sMDLinofA4=NULL;
																													sMDLinofA5=NULL;
																													sMDLinofA6=NULL;
																													sMDLinofA7=NULL;
																													sMDLinofA8=NULL;
																													sMDLinofA9=NULL;
																													sMDLinofA10=NULL;
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																													if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																													printf("\n MDL:GM:P42:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																													printf("\n MDL:GM:P42:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
																													if(tc_strcmp(sMDLinofA1,"Multi")==0)
																													{
																														if (tc_strlen(sMDLinofA2) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA2);
																															printf("\n MDL:GM:P42:S2..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA3) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA3);
																															printf(" S3..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA4) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA4);
																															printf(" S4..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA5) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA5);
																															printf(" S5..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA6) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA6);
																															printf(" S6..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA7) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA7);
																															printf(" S7..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA8) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA8);
																															printf(" S8..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA9) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA9);
																															printf(" S9..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA10) > 1)
																														{
																															tc_strcat (sNManMQMOSet,sMDLinofA10);
																															printf(" S10.");fflush(stdout);
																														}
																														printf("\n MDL:GM:P42:sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
																													}
																													else if(tc_strcmp(sMDLinofA1,"Single")==0)
																													{
																														if (tc_strlen(sMDLinofA2) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA2);
																															printf("\n MDL:GM:P43:S2..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA3) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA3);
																															printf(" S3..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA4) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA4);
																															printf(" S4..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA5) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA5);
																															printf(" S5..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA6) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA6);
																															printf(" S6..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA7) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA7);
																															printf(" S7..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA8) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA8);
																															printf(" S8..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA9) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA9);
																															printf(" S9..");fflush(stdout);
																														}
																														if (tc_strlen(sMDLinofA10) > 1)
																														{
																															tc_strcat (sNManSQMOSet,sMDLinofA10);
																															printf(" S10.");fflush(stdout);
																														}
																														printf("\n MDL:GM:P43:sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
																													}
																													else
																													{
																														printf("\n MDL:GM:P43:Other case....");fflush(stdout);
																													}
																												}
																												printf("\n MDL:GM:P43:Final sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
																												printf("\n MDL:GM:P43:Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
																											}

																											//Expanding first level BOM for VC
																											printf ("\n MDL:GM:P44: Expanding first level BOM for VC..\n");fflush(stdout);
																											if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
																											if(CFM_find( "ERC release and above", &MDL_rule )!=ITK_ok)PrintErrorStack();
																											if(BOM_set_window_config_rule( p_window, MDL_rule )!=ITK_ok)PrintErrorStack();
																											if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
																											if(BOM_set_window_top_line (p_window, NULLTAG, rev_list[ii], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();
																											//0qty
																											printf ("\n MDL:V:P44:: PartTyp:%s\n",PartTyp);fflush(stdout);
																											if((tc_strcmp(PartTyp,"V")==0)||(tc_strcmp(PartTyp,"Vehicle")==0))
																											{
																												//if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												if(tc_strstr(BomComInfo1,"CON03") == NULL)
																												{
																													printf ("\n MDL:Veh:CON03: BOMViewClosureRuleERC applied \n");fflush(stdout);
																													if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																												else if(tc_strstr(BomComInfo1,"CON04") == NULL)
																												{
																													printf ("\n MDL:Veh:CON04: BOMViewClosureRuleERC1 applied \n");fflush(stdout);
																													if(PIE_find_closure_rules2("BOMViewClosureRuleERC1",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																												else if(tc_strstr(BomComInfo1,"CON06") == NULL)
																												{
																													printf ("\n MDL:Veh:CON06: BOMLineSkipZeroQtyMaskUnconfig applied \n");fflush(stdout);
																													if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																												else
																												{
																													printf ("\n MDL:Veh:CON03: TMLBOMExpandByQty applied \n");fflush(stdout);
																													if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																												}
																											}
																											else
																											{
																												printf ("\n MDL:V:P45:: TMLBOMExpandByQty applied \n");fflush(stdout);
																												if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &MDLrulefound, &MDLclosureruleee )!=ITK_ok)   PrintErrorStack();
																											}
																											printf ("\n MDL:GM:P44:MDLrulefound count %d \n",MDLrulefound);fflush(stdout);
																											if (MDLrulefound > 0)
																											{
																												MDLClosureTag = MDLclosureruleee[0];
																												printf ("\n MDL:GM:P44: MDLClosureTag closure rule found \n");fflush(stdout);
																											}
																											if(BOM_window_set_closure_rule( p_window,MDLClosureTag, 0, MDLrulenameXO,MDLrulevalueXO )!=ITK_ok)   PrintErrorStack();
																											//0qty
																											if(BOM_line_ask_child_lines (p_top_line, &VCChildCunt, &VCChildobject));
																											printf("\n MDL:GM:P45:No of child objects are VCChildCunt : [%d]\n",VCChildCunt);fflush(stdout);
																											
																											if(tc_strstr(BomComInfo1,"M004") == NULL)
																											{
																												printf("\n MDL:GM:P46: Now checking for Mandatory multi occurance case..\n");fflush(stdout);
																												if((sManMQMOSet==NULL)|| (tc_strcmp(sManMQMOSet,"")==0))
																												{
																													printf("\n MDL:GM:P47:sManMQMOSet is NULL.\n");fflush(stdout);
																												}
																												else
																												{
																													mdlcunt=0;
																													piStringCount=0;
																													if(EPM__parse_string(sManMQMOSet,",",&piStringCount,&AStringList)!=ITK_ok)PrintErrorStack();
																													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																													{
																														ManMOAddFlag=0;
																														MDLAddress=NULL;
																														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																														tc_strcpy (MDLAddress,"" );
																														printf("\n MDL:GM:P48:sManMQMOSet Part:%s ",AStringList[mdlcunt]);fflush(stdout);
																														tc_strcat (MDLAddress,AStringList[mdlcunt]);
																														printf ("\n MDL:GM:P48:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
																														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																														{
																															printf("\n MDL:GM:P48:MDLAddress is NULL.\n");fflush(stdout);
																														}
																														else
																														{
																															printf(" start.\n");fflush(stdout);
																															iChild=0;
																															for(iChild =0 ; iChild < VCChildCunt; iChild++)
																															{
																																p_child_item_id=NULL;
																																rel_sstats=NULL;
																																Obj_PrtTyp=NULL;
																																rev_iidd=NULL;
																																PrtDRstus=NULL;
																																PrtProjj=NULL;

																																if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																printf("\n MDL:GM:P48: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																//NEED TO DISCUSS BELOW LCs
																																//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																//If child is NR WIP, it should be in same DML.
																																if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																{
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																	printf("\n MDL:GM:P48: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																	if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																	{
																																		printf("\n MDL:GM:P48:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																	}
																																	else
																																	{
																																		if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																		{
																																			sChildMdlAdd=NULL;
																																			sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																			tc_strcpy (sChildMdlAdd,"" );
																																			sChildMdlAdd = subString(p_child_item_id,4,5);
																																			printf("\n MDL:GM:P48:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																			if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																			{
																																				ManMOAddFlag ++;
																																				printf("\n MDL:GM:P48:module address found.:[%d] ", ManMOAddFlag);fflush(stdout);
																																				break; //As 1 or more times allowed, we are breaking it.
																																			}
																																		}
																																	}
																																}
																															}
																															printf("\n MDL:GM:P48:Final ManMOAddFlag.:[%d] ", ManMOAddFlag);fflush(stdout);
																															if (ManMOAddFlag ==0)
																															{
																																//Add to mandatory error set.
																																if((tc_strcmp(sManMOErr,"")==0) || (tc_strstr(sManMOErr,Partno)==NULL))
																																{
																																	//tc_strcat(sManMOErr,"\n");
																																	tc_strcat(sManMOErr,Partno);
																																	tc_strcat(sManMOErr,": ");
																																}

																																if(tc_strstr(sManMOErr,MDLAddress)==NULL)
																																{
																																	iManMOErrFlag ++;
																																	if ((iManMOErrFlag ==20)|| (iManMOErrFlag ==40)||(iManMOErrFlag ==60)||(iManMOErrFlag ==80))
																																	{
																																		tc_strcat(sManMOErr,"\n");
																																	}
																																	tc_strcat(sManMOErr,MDLAddress);
																																	tc_strcat(sManMOErr,",");
																																	printf("\n MDL:GM:P48:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManMOErr);fflush(stdout);
																																}
																																else
																																{
																																	printf("\n MDL:GM:P48:Module address already added... [%s]",MDLAddress);fflush(stdout);
																																}
																															}
																															else
																															{
																																printf("\n MDLAddress is allowed and called multiple times...:[%s]\n",MDLAddress);fflush(stdout);
																															}
																														}
																													}
																												}
																											}
																											if(tc_strstr(BomComInfo1,"M005") == NULL)
																											{
																												printf("\n MDL:GM:P49: Now checking for Mandatory Single occurance case..\n");fflush(stdout);
																												if((sManSQMOSet==NULL)|| (tc_strcmp(sManSQMOSet,"")==0))
																												{
																													printf("\n MDL:GM:P49:sManSQMOSet is NULL.\n");fflush(stdout);
																												}
																												else
																												{
																													mdlcunt=0;
																													piStringCount=0;
																													if(EPM__parse_string(sManSQMOSet,",",&piStringCount,&BStringList)!=ITK_ok)PrintErrorStack();
																													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																													{
																														ManSOAddFlag=0;
																														MDLAddress=NULL;
																														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																														tc_strcpy (MDLAddress,"" );
																														printf("\n MDL:GM:P49:sManSQMOSet Part:[%s]",BStringList[mdlcunt]);fflush(stdout);
																														tc_strcat (MDLAddress,BStringList[mdlcunt]);
																														printf ("\n MDL:GM:P49:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
																														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																														{
																															printf("\n MDL:GM:P49:MDLAddress is NULL..\n");fflush(stdout);
																														}
																														else
																														{
																															printf(" start..\n");fflush(stdout);
																															iChild=0;
																															for(iChild =0 ; iChild < VCChildCunt; iChild++)
																															{
																																p_child_item_id=NULL;
																																rel_sstats=NULL;
																																Obj_PrtTyp=NULL;
																																rev_iidd=NULL;
																																PrtDRstus=NULL;
																																PrtProjj=NULL;

																																if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																printf("\n MDL:GM:P49: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																//NEED TO DISCUSS BELOW LCs
																																//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																//If child is NR WIP, it should be in same DML.
																																if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																{
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																	printf("\n MDL:GM:P49: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																	if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																	{
																																		printf("\n MDL:GM:P49: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																	}
																																	else
																																	{
																																		if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																		{
																																			sChildMdlAdd=NULL;
																																			sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																			tc_strcpy (sChildMdlAdd,"" );
																																			sChildMdlAdd = subString(p_child_item_id,4,5);
																																			printf("\n MDL:GM:P49:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																			if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																			{
																																				ManSOAddFlag ++;
																																				printf("\n MDL:GM:P49:ManSOAddFlag.:[%d] ", ManSOAddFlag);fflush(stdout);
																																				//break; //As only 1 qty allowed, we are NOT breaking it.
																																			}
																																		}
																																	}
																																}
																															}
																															printf("\n MDL:GM:P49:Final ManSOAddFlag.:[%d] ", ManSOAddFlag);fflush(stdout);
																															if (ManSOAddFlag ==0)
																															{
																																//Add to mandatory error set.
																																if((tc_strcmp(sManSOErr,"")==0) || (tc_strstr(sManSOErr,Partno)==NULL))
																																{
																																	//tc_strcat(sManSOErr,"\n");
																																	tc_strcat(sManSOErr,Partno);
																																	tc_strcat(sManSOErr,": ");
																																}

																																if(tc_strstr(sManSOErr,MDLAddress)==NULL)
																																{
																																	iManSOFlag ++;
																																	if ((iManSOFlag ==20)|| (iManSOFlag ==40)||(iManSOFlag ==60)||(iManSOFlag ==80))
																																	{
																																		tc_strcat(sManSOErr,"\n");
																																	}
																																	tc_strcat(sManSOErr,MDLAddress);
																																	tc_strcat(sManSOErr,",");
																																	printf("\n MDL:GM:P49:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSOErr);fflush(stdout);
																																}
																																else
																																{
																																	printf("\n MDL:GM:P49:Module address already added..- [%s]",MDLAddress);fflush(stdout);
																																}
																															}
																															else if (ManSOAddFlag >1)
																															{
																																//Add to mandatory error set.
																																if((tc_strcmp(sManSODupErr,"")==0) || (tc_strstr(sManSODupErr,Partno)==NULL))
																																{
																																	//tc_strcat(sManSODupErr,"\n");
																																	tc_strcat(sManSODupErr,Partno);
																																	tc_strcat(sManSODupErr,": ");
																																}

																																if(tc_strstr(sManSODupErr,MDLAddress)==NULL)
																																{
																																	iManSODupFlag ++;
																																	if ((iManSODupFlag ==20)|| (iManSODupFlag ==40)||(iManSODupFlag ==60)||(iManSODupFlag ==80))
																																	{
																																		tc_strcat(sManSODupErr,"\n");
																																	}
																																	tc_strcat(sManSODupErr,MDLAddress);
																																	tc_strcat(sManSODupErr,",");
																																	printf("\n MDL:GM:P49:Dup ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSODupErr);fflush(stdout);
																																}
																																else
																																{
																																	printf("\n MDL:GM:P49::MOdule address already added..: [%s]",MDLAddress);fflush(stdout);
																																}
																															}
																															else
																															{
																																printf("\n MDL:GM:P49:Single module address avail in BOM.. [%s]",MDLAddress);fflush(stdout);
																															}
																														}
																													}
																												}
																											}
																											if(tc_strstr(BomComInfo1,"M006") == NULL)
																											{
																												printf("\n MDL:GM:P50: Now checking for NON Mandatory multi occurance case..\n");fflush(stdout);
																												if((sNManMQMOSet==NULL)|| (tc_strcmp(sNManMQMOSet,"")==0))
																												{
																													printf("\n MDL:GM:P50:sNManMQMOSet is NULL.\n");fflush(stdout);
																												}
																												else
																												{
																													mdlcunt=0;
																													piStringCount=0;
																													if(EPM__parse_string(sNManMQMOSet,",",&piStringCount,&CStringList)!=ITK_ok)PrintErrorStack();
																													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																													{
																														//NManMOAddFlag=0;
																														MDLAddress=NULL;
																														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																														tc_strcpy (MDLAddress,"" );
																														printf("\n MDL:GM:P50:sNManMQMOSet Part:%s ",CStringList[mdlcunt]);fflush(stdout);
																														tc_strcat (MDLAddress,CStringList[mdlcunt]);
																														printf ("\n MDL:GM:P50:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
																														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																														{
																															printf("\n MDL:GM:P50:MDLAddress is NULL.\n");fflush(stdout);
																														}
																														else
																														{
																															printf(" start.\n");fflush(stdout);
																															iChild=0;
																															/*for(iChild =0 ; iChild < VCChildCunt; iChild++)
																															{
																																p_child_item_id=NULL;
																																rel_sstats=NULL;
																																Obj_PrtTyp=NULL;
																																rev_iidd=NULL;
																																PrtDRstus=NULL;
																																PrtProjj=NULL;

																																if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																printf("\n D: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																//NEED TO DISCUSS BELOW LCs
																																//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																//If child is NR WIP, it should be in same DML.
																																if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																{
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																	printf("\n D: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																	if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																	{
																																		printf("\n D:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																	}
																																	else
																																	{
																																		if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																		{
																																			sChildMdlAdd=NULL;
																																			sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																			tc_strcpy (sChildMdlAdd,"" );
																																			sChildMdlAdd = subString(p_child_item_id,4,5);
																																			printf("\n D:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																			if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																			{
																																				NNManMOAddFlag ++;
																																				printf("\n D::module address found.:[%d] ", NManMOAddFlag);fflush(stdout);
																																				break; //As 1 or more times allowed, we are breaking it.
																																			}
																																		}
																																	}
																																}
																															}
																															printf("\n D::Final NManMOAddFlag.:[%d] ", NManMOAddFlag);fflush(stdout);*/
																															printf("\n MDL:GM:P50:Check for Non Mandatory Multi Module address check.....Skipped, no need.");fflush(stdout);
																														}
																													}
																												}
																											}
																											if(tc_strstr(BomComInfo1,"M007") == NULL)
																											{
																												printf("\n MDL:GM:P51: Now checking for non Mandatory Single occurance case..\n");fflush(stdout);
																												if((sNManSQMOSet==NULL)|| (tc_strcmp(sNManSQMOSet,"")==0))
																												{
																													printf("\n MDL:GM:P52:sNManSQMOSet is NULL.\n");fflush(stdout);
																												}
																												else
																												{
																													mdlcunt=0;
																													piStringCount=0;
																													if(EPM__parse_string(sNManSQMOSet,",",&piStringCount,&DStringList)!=ITK_ok)PrintErrorStack();
																													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
																													{
																														NManSOAddFlag=0;
																														MDLAddress=NULL;
																														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
																														tc_strcpy (MDLAddress,"" );
																														printf("\n MDL:GM:P52:sNManSQMOSet Part:[%s]",DStringList[mdlcunt]);fflush(stdout);
																														tc_strcat (MDLAddress,DStringList[mdlcunt]);
																														printf ("\n MDL:GM:P52:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
																														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
																														{
																															printf("\n MDL:GM:P52:MDLAddress is NULL..\n");fflush(stdout);
																														}
																														else
																														{
																															printf(" start..\n");fflush(stdout);
																															iChild=0;
																															for(iChild =0 ; iChild < VCChildCunt; iChild++)
																															{
																																p_child_item_id=NULL;
																																rel_sstats=NULL;
																																Obj_PrtTyp=NULL;
																																rev_iidd=NULL;
																																PrtDRstus=NULL;
																																PrtProjj=NULL;

																																if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																																printf("\n MDL:GM:P52: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																																//NEED TO DISCUSS BELOW LCs
																																//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																//If child is NR WIP, it should be in same DML.
																																if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																																{
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																	if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																	if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																	printf("\n MDL:GM:P52: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																	if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																	{
																																		printf("\n MDL:GM:P52:: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																	}
																																	else
																																	{
																																		if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																		{
																																			sChildMdlAdd=NULL;
																																			sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																			tc_strcpy (sChildMdlAdd,"" );
																																			sChildMdlAdd = subString(p_child_item_id,4,5);
																																			printf("\n MDL:GM:P52:MDLAddress:[%s] and  sChildMdlAdd:[%s]\n",MDLAddress,sChildMdlAdd);fflush(stdout);
																																			if(tc_strcmp(MDLAddress,sChildMdlAdd)==0)
																																			{
																																				NManSOAddFlag ++;
																																				printf("\n MDL:GM:P52:NManSOAddFlag.:[%d] ", NManSOAddFlag);fflush(stdout);
																																				//break; //As only 1 qty allowed, we are NOT breaking it.
																																			}
																																		}
																																	}
																																}
																															}
																															printf("\n MDL:GM:P52:Final NManSOAddFlag.:[%d] ", NManSOAddFlag);fflush(stdout);
																															if (NManSOAddFlag ==0)
																															{
																																//NO need to Add to mandatory error set.
																																printf("\n MDL:GM:P52:Non Mandatory single occurance %s, not called in BOM...",MDLAddress);fflush(stdout);
																															}
																															else if (NManSOAddFlag >1)
																															{
																																//Add to mandatory error set.
																																printf("\n MDL:GM:P52:Non Mandatory single occurance, but duplicated. %s....",MDLAddress);fflush(stdout);
																																if((tc_strcmp(sNManSODupErr,"")==0) || (tc_strstr(sNManSODupErr,Partno)==NULL))
																																{
																																	//tc_strcat(sNManSODupErr,"\n");
																																	tc_strcat(sNManSODupErr,Partno);
																																	tc_strcat(sNManSODupErr,": ");
																																}
																																if(tc_strstr(sNManSODupErr,MDLAddress)==NULL)
																																{
																																	iNManSODupFlag ++;
																																	if ((iNManSODupFlag ==20)|| (iNManSODupFlag ==40)||(iNManSODupFlag ==60)||(iNManSODupFlag ==80))
																																	{
																																		tc_strcat(sNManSODupErr,"\n");
																																	}
																																	tc_strcat(sNManSODupErr,MDLAddress);
																																	tc_strcat(sNManSODupErr,",");
																																	printf("\n MDL:GM:P52:Non Mandatory single occurance, but duplicated.%s added to error set.:[%s]",MDLAddress,sNManSODupErr);fflush(stdout);
																																}
																															}
																															else
																															{
																																printf("\n MDL:GM:P52:Non Mandatory single occurance only, so checking qty. [%s]",MDLAddress);fflush(stdout);
																																//Check for qty now.//Mohan
																															}
																														}
																													}
																												}
																											}
																											if(tc_strstr(BomComInfo1,"M008") == NULL)
																											{
																												printf("\n MDL:GM:P53:checking for mandatory CP module addresses.\n");fflush(stdout);
																												//Quering control tables for mandatory module address: Duplication allowed in BOM.
																												if(QRY_find2("Control Objects...", &MdlQry_Tag4));
																												if (MdlQry_Tag4)
																												{
																													printf("\n MDL:GM:P53:Found Query MdlQry_Tag4 \n");fflush(stdout);
																												}
																												else
																												{
																													printf("\n MDL:GM:P53:Not Found Query MdlQry_Tag4 \n");fflush(stdout);
																												}
																												MDL_qry_values4[0] = "CPMODUL";
																												MDL_qry_values4[1] = PartPlfFrm;
																												if(QRY_execute(MdlQry_Tag4, MDL_n_entry4, MDL_qry_entry4, MDL_qry_values4, &MDL_rsltCount4, &MDL_Obj_Tag4));
																												printf("\n MDL:GM:P53:MDL_rsltCount4 :%d:", MDL_rsltCount4); fflush(stdout);
																												if(MDL_rsltCount4 > 0)
																												{
																													jk=0;
																													for(jk=0;jk<MDL_rsltCount4;jk++)
																													{
																														sMDLinofA1=NULL;
																														sMDLinofA2=NULL;
																														sMDLinofA3=NULL;
																														sMDLinofA4=NULL;
																														sMDLinofA5=NULL;
																														sMDLinofA6=NULL;
																														sMDLinofA7=NULL;
																														sMDLinofA8=NULL;
																														sMDLinofA9=NULL;
																														sMDLinofA10=NULL;
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo1",&sMDLinofA1)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo2",&sMDLinofA2)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo3",&sMDLinofA3)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo4",&sMDLinofA4)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo5",&sMDLinofA5)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo6",&sMDLinofA6)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo7",&sMDLinofA7)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo8",&sMDLinofA8)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_Userinfo9",&sMDLinofA9)!=ITK_ok)   PrintErrorStack();
																														if (AOM_ask_value_string(MDL_Obj_Tag4[jk],"t5_userinfo10",&sMDLinofA10)!=ITK_ok)   PrintErrorStack();
																														printf("\n MDL:GM:P53:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
																														printf("\n MDL:GM:P53:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);

																														iChild =0 ;
																														for(iChild =0 ; iChild < VCChildCunt; iChild++)
																														{
																															p_child_item_id=NULL;
																															rel_sstats=NULL;
																															Obj_PrtTyp=NULL;
																															rev_iidd=NULL;
																															PrtDRstus=NULL;
																															PrtProjj=NULL;

																															if(AOM_ask_value_string(VCChildobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																															if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
																															printf("\n MDL:GM:P53: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstats);fflush(stdout);
																															//NEED TO DISCUSS BELOW LCs
																															//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																															//If child is NR WIP, it should be in same DML.
																															if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstats,"APL")!=NULL)||(tc_strstr(rel_sstats,"STDSI")!=NULL))
																															{
																																if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
																																if(AOM_UIF_ask_value(VCChildobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
																																if(AOM_ask_value_string(VCChildobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
																																printf("\n MDL:GM:P53:Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);

																																if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
																																{
																																	printf("\n MDL:GM:P53: SKIPPED Child_item_id:%s ", p_child_item_id);fflush(stdout);
																																}
																																else
																																{
																																	if((tc_strstr(rel_sstats,"Released")!=NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")!=NULL))
																																	{
																																		sChildMdlAdd=NULL;
																																		sChildMdlAdd    =  (char *) MEM_alloc(10 * sizeof(char));
																																		tc_strcpy (sChildMdlAdd,"" );
																																		sChildMdlAdd = subString(p_child_item_id,4,5);
																																		printf("\n MDL:GM:P53:sMDLinofA1:[%s] and  sChildMdlAdd:[%s]\n",sMDLinofA1,sChildMdlAdd);fflush(stdout);
																																		if(tc_strcmp(sMDLinofA1,sChildMdlAdd)==0)
																																		{
																																			iChildd =0 ;
																																			for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																			{
																																				CPModuleAvailFlag=0;
																																				p_child_item_id=NULL;
																																				rel_sstatss=NULL;
																																				Obj_PrtTypp=NULL;
																																				rev_iiddd=NULL;
																																				PrtDRstuss=NULL;
																																				PrtProjjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:GM:P53: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:GM:P53: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																					if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAddd=NULL;
																																						sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAddd,"" );
																																						sChildMdlAddd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:GM:P53:sMDLinofA2:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA2,sChildMdlAddd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA2,sChildMdlAddd)==0)
																																						{
																																							CPModuleAvailFlag ++;
																																							printf("\n MDL:GM:P53:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							break;
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:GM:P53:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																			if (CPModuleAvailFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:GM:P53:CP modules not available...");fflush(stdout);
																																				if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sCPModuleAvailErr,"\n");
																																					tc_strcat(sCPModuleAvailErr,Partno);
																																					tc_strcat(sCPModuleAvailErr,": ");
																																				}
																																				if(tc_strstr(sCPModuleAvailErr,sMDLinofA2)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(sCPModuleAvailErr,"\n");
																																					}
																																					tc_strcat(sCPModuleAvailErr,sMDLinofA2);
																																					tc_strcat(sCPModuleAvailErr,",");
																																					printf("\n MDL:GM:P53:CP module address.%s added to error set.:[%s]",sMDLinofA2,sCPModuleAvailErr);fflush(stdout);
																																				}
																																			}
																																		}
																																		else if(tc_strcmp(sMDLinofA3,sChildMdlAdd)==0)
																																		{
																																			iChildd =0 ;
																																			for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																			{
																																				CPModuleAvailFlag=0;
																																				p_child_item_id=NULL;
																																				rel_sstatss=NULL;
																																				Obj_PrtTypp=NULL;
																																				rev_iiddd=NULL;
																																				PrtDRstuss=NULL;
																																				PrtProjjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:GM:P54: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:GM:P54: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																					if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAddd=NULL;
																																						sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAddd,"" );
																																						sChildMdlAddd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:GM:P54:sMDLinofA4:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA4,sChildMdlAddd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA4,sChildMdlAddd)==0)
																																						{
																																							CPModuleAvailFlag ++;
																																							printf("\n MDL:GM:P54:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							break;
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:GM:P54:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																			if (CPModuleAvailFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:GM:P54:CP modules not available...");fflush(stdout);
																																				if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sCPModuleAvailErr,"\n");
																																					tc_strcat(sCPModuleAvailErr,Partno);
																																					tc_strcat(sCPModuleAvailErr,": ");
																																				}
																																				if(tc_strstr(sCPModuleAvailErr,sMDLinofA4)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(sCPModuleAvailErr,"\n");
																																					}
																																					tc_strcat(sCPModuleAvailErr,sMDLinofA4);
																																					tc_strcat(sCPModuleAvailErr,",");
																																					printf("\n MDL:GM:P54:CP3 module address.%s added to error set.:[%s]",sMDLinofA4,sCPModuleAvailErr);fflush(stdout);

																																				}
																																			}
																																		}
																																		else if(tc_strcmp(sMDLinofA5,sChildMdlAdd)==0)
																																		{
																																			iChildd =0 ;
																																			for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																			{
																																				CPModuleAvailFlag=0;
																																				p_child_item_id=NULL;
																																				rel_sstatss=NULL;
																																				Obj_PrtTypp=NULL;
																																				rev_iiddd=NULL;
																																				PrtDRstuss=NULL;
																																				PrtProjjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:GM:P55: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:GM:P55: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																					if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAddd=NULL;
																																						sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAddd,"" );
																																						sChildMdlAddd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:GM:P55:sMDLinofA6:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA6,sChildMdlAddd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA6,sChildMdlAddd)==0)
																																						{
																																							CPModuleAvailFlag ++;
																																							printf("\n MDL:GM:P55:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							break;
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:GM:P55:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																			if (CPModuleAvailFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:GM:P55:CP modules not available...");fflush(stdout);
																																				if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sCPModuleAvailErr,"\n");
																																					tc_strcat(sCPModuleAvailErr,Partno);
																																					tc_strcat(sCPModuleAvailErr,": ");
																																				}
																																				if(tc_strstr(sCPModuleAvailErr,sMDLinofA6)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(sCPModuleAvailErr,"\n");
																																					}
																																					tc_strcat(sCPModuleAvailErr,sMDLinofA6);
																																					tc_strcat(sCPModuleAvailErr,",");
																																					printf("\n MDL:GM:P55:CP3 module address.%s added to error set.:[%s]",sMDLinofA6,sCPModuleAvailErr);fflush(stdout);
																																				}
																																			}
																																		}
																																		else if(tc_strcmp(sMDLinofA7,sChildMdlAdd)==0)
																																		{
																																			iChildd =0 ;
																																			for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																			{
																																				CPModuleAvailFlag=0;
																																				p_child_item_id=NULL;
																																				rel_sstatss=NULL;
																																				Obj_PrtTypp=NULL;
																																				rev_iiddd=NULL;
																																				PrtDRstuss=NULL;
																																				PrtProjjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:GM:P56: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:GM:P56: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																					if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAddd=NULL;
																																						sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAddd,"" );
																																						sChildMdlAddd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:GM:P56:sMDLinofA8:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA8,sChildMdlAddd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA8,sChildMdlAddd)==0)
																																						{
																																							CPModuleAvailFlag ++;
																																							printf("\n MDL:GM:P56:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							break;
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:GM:P56:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																			if (CPModuleAvailFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:GM:P56:CP modules not available...");fflush(stdout);
																																				if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sCPModuleAvailErr,"\n");
																																					tc_strcat(sCPModuleAvailErr,Partno);
																																					tc_strcat(sCPModuleAvailErr,": ");
																																				}
																																				if(tc_strstr(sCPModuleAvailErr,sMDLinofA8)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(sCPModuleAvailErr,"\n");
																																					}
																																					tc_strcat(sCPModuleAvailErr,sMDLinofA8);
																																					tc_strcat(sCPModuleAvailErr,",");
																																					printf("\n MDL:GM:P56:CP3 module address.%s added to error set.:[%s]",sMDLinofA8,sCPModuleAvailErr);fflush(stdout);
																																				}
																																			}
																																		}
																																		else if(tc_strcmp(sMDLinofA9,sChildMdlAdd)==0)
																																		{
																																			iChildd =0 ;
																																			for(iChildd =0 ; iChildd < VCChildCunt; iChildd++)
																																			{
																																				CPModuleAvailFlag=0;
																																				p_child_item_id=NULL;
																																				rel_sstatss=NULL;
																																				Obj_PrtTypp=NULL;
																																				rev_iiddd=NULL;
																																				PrtDRstuss=NULL;
																																				PrtProjjj=NULL;

																																				if(AOM_ask_value_string(VCChildobject[iChildd], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																																				if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																																				printf("\n MDL:GM:P57: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																																				//NEED TO DISCUSS BELOW LCs
																																				//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																																				//If child is NR WIP, it should be in same DML.
																																				if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																																				{
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																																					if(AOM_UIF_ask_value(VCChildobject[iChildd], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																																					if(AOM_ask_value_string(VCChildobject[iChildd],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																																					printf("\n MDL:GM:P57: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj);fflush(stdout);

																																					if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL))
																																					{
																																						sChildMdlAddd=NULL;
																																						sChildMdlAddd    =  (char *) MEM_alloc(10 * sizeof(char));
																																						tc_strcpy (sChildMdlAddd,"" );
																																						sChildMdlAddd = subString(p_child_item_id,4,5);
																																						printf("\n MDL:GM:P57:sMDLinofA10:[%s] and  sChildMdlAddd:[%s]\n",sMDLinofA10,sChildMdlAddd);fflush(stdout);
																																						if(tc_strcmp(sMDLinofA10,sChildMdlAddd)==0)
																																						{
																																							CPModuleAvailFlag ++;
																																							printf("\n MDL:GM:P57:CP module found.:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																							break;
																																						}
																																					}
																																				}
																																			}
																																			printf("\n MDL:GM:P57:CPModuleAvailFlag:[%d] ", CPModuleAvailFlag);fflush(stdout);
																																			if (CPModuleAvailFlag ==0)
																																			{
																																				//Add to mandatory error set.
																																				printf("\n MDL:GM:P57:CP modules not available...");fflush(stdout);
																																				if((tc_strcmp(sCPModuleAvailErr,"")==0) || (tc_strstr(sCPModuleAvailErr,Partno)==NULL))
																																				{
																																					//tc_strcat(sCPModuleAvailErr,"\n");
																																					tc_strcat(sCPModuleAvailErr,Partno);
																																					tc_strcat(sCPModuleAvailErr,": ");
																																				}
																																				if(tc_strstr(sCPModuleAvailErr,sMDLinofA10)==NULL)
																																				{
																																					sCPModuleFlag ++;
																																					if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																					{
																																						tc_strcat(sCPModuleAvailErr,"\n");
																																					}
																																					tc_strcat(sCPModuleAvailErr,sMDLinofA10);
																																					tc_strcat(sCPModuleAvailErr,",");
																																					printf("\n MDL:GM:P57:CP3 module address.%s added to error set.:[%s]",sMDLinofA10,sCPModuleAvailErr);fflush(stdout);
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																													printf("\n MDL:GM:P58:Final sNManMQMOSet: %s",sCPModuleAvailErr); fflush(stdout);
																												}
																											}
																											if(tc_strstr(BomComInfo1,"M009") == NULL)
																											{
																												printf("\n MDL:GM:P59:Checking bl_quantity ............................\n");fflush(stdout);
																												char	*sChildPartType		=  NULL;
																												sChildPartType =(char *) MEM_alloc(200 * sizeof(char *));
																												iChildqty =0 ;
																												for(iChildqty =0 ; iChildqty < VCChildCunt; iChildqty++)
																												{
																													p_child_item_id=NULL;
																													rel_sstatss=NULL;
																													Obj_PrtTypp=NULL;
																													rev_iiddd=NULL;
																													PrtDRstuss=NULL;
																													ChildPartQty=NULL;
																													PrtProjjj=NULL;

																													if(AOM_ask_value_string(VCChildobject[iChildqty], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
																													if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_rev_release_status_list", &rel_sstatss)!=ITK_ok)PrintErrorStack();
																													printf("\n MDL:GM:P59: p_child_item_id:%s Rel Status:%s", p_child_item_id,rel_sstatss);fflush(stdout);
																													//NEED TO DISCUSS BELOW LCs
																													//Standard parts/IFD/DUMMY/SPARE KIT should be skipped.
																													//If child is NR WIP, it should be in same DML.
																													if((tc_strstr(rel_sstatss,"Released")!=NULL)||(tc_strstr(rel_sstatss,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(rel_sstatss,"APL")!=NULL)||(tc_strstr(rel_sstatss,"STDSI")!=NULL))
																													{
																														if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_Design_t5_RevPartType",&Obj_PrtTypp)!=ITK_ok)PrintErrorStack();
																														if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_rev_item_revision_id", &rev_iiddd)!=ITK_ok)PrintErrorStack();
																														if(AOM_UIF_ask_value(VCChildobject[iChildqty], "bl_Design Revision_t5_PartStatus", &PrtDRstuss)!=ITK_ok)PrintErrorStack();
																														if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_Design Revision_t5_ProjectCode",&PrtProjjj)!=ITK_ok)PrintErrorStack();
																														if(AOM_ask_value_string(VCChildobject[iChildqty],"bl_quantity",&ChildPartQty)!=ITK_ok)PrintErrorStack();
																														printf("\n MDL:GM:P59: Obj_PrtTypp:%s PrtDRstuss:%s and rev_iiddd:%s PrtProjjj:%s ChildPartQty:%s", Obj_PrtTypp,PrtDRstuss,rev_iiddd,PrtProjjj,ChildPartQty);fflush(stdout);

																														tc_strcpy(sChildPartType,"");
																														tc_strcpy(sChildPartType,",");
																														tc_strcat(sChildPartType,Obj_PrtTypp);
																														tc_strcat(sChildPartType,",");
																														printf("\n MDL:GM:P59:sChildPartType:: [%s]",sChildPartType);fflush(stdout);
																														if(tc_strstr(BomComInfo5,sChildPartType) != NULL)
																														{
																															printf("\n MDL:GM:P59Dummy/IFD/CP should be with 0 qty:%s ", p_child_item_id);fflush(stdout);
																															if(ChildPartQty)
																															{
																																iChildPartQty=atoi(ChildPartQty);
																															}
																															printf("\n MDL:GM:P59:iChildPartQty:: [%d]",iChildPartQty);fflush(stdout);
																															if(iChildPartQty==0)
																															{
																																printf("\n MDL:GM:P59:Dummy/IFD/CP is with 0 qty:%s ", p_child_item_id);fflush(stdout);
																															}
																															else
																															{
																																printf("\n MDL:GM:P59:Dummy/IFD/CP is NOT with 0 qty:%s ", p_child_item_id);fflush(stdout);
																																//Add to mandatory error set.
																																if((tc_strcmp(OtherZeroQtySet,"")==0) || (tc_strstr(OtherZeroQtySet,Partno)==NULL))
																																{
																																	//tc_strcat(OtherZeroQtySet,"\n");
																																	tc_strcat(OtherZeroQtySet,Partno);
																																	tc_strcat(OtherZeroQtySet,": ");
																																}
																																if(tc_strstr(OtherZeroQtySet,p_child_item_id)==NULL)
																																{
																																	sCPModuleFlag ++;
																																	if ((sCPModuleFlag ==20)|| (sCPModuleFlag ==40)||(sCPModuleFlag ==60)||(sCPModuleFlag ==80))
																																	{
																																		tc_strcat(OtherZeroQtySet,"\n");
																																	}
																																	tc_strcat(OtherZeroQtySet,p_child_item_id);
																																	tc_strcat(OtherZeroQtySet,",");
																																	printf("\n MDL:GM:P59:Dummy/IFD/CP.%s added to error set.:[%s]",p_child_item_id,OtherZeroQtySet);fflush(stdout);
																																}
																															}
																														}
																														else
																														{
																															//Other than Dummy/IFD/CP
																															printf("\n MDL:GM:P60:Other than Dummy/IFD/CP should be with 1 qty:%s ", p_child_item_id);fflush(stdout);
																															if(ChildPartQty)
																															{
																																iChildPartQty=atoi(ChildPartQty);
																															}
																															printf("\n MDL:GM:P60:iChildPartQty:: [%d]",iChildPartQty);fflush(stdout);
																															if((iChildPartQty==0)||(iChildPartQty==1)||((iChildPartQty >0)&& (iChildPartQty < 1)))
																															{
																																printf("\n MDL:GM:P60:Module is NOT with 0/1 qty:%s ", p_child_item_id);fflush(stdout);
																															}
																															else
																															{
																																printf("\n MDL:GM:P60:Module is NOT with 0/1 qty:%s ", p_child_item_id);fflush(stdout);
																																if((tc_strcmp(inValidQtySet,"")==0) || (tc_strstr(inValidQtySet,Partno)==NULL))
																																{
																																	//tc_strcat(inValidQtySet,"\n");
																																	tc_strcat(inValidQtySet,Partno);
																																	tc_strcat(inValidQtySet,": ");
																																}
																																if(tc_strstr(inValidQtySet,p_child_item_id)==NULL)
																																{
																																	iQtyAflag ++;
																																	if ((iQtyAflag ==10)|| (iQtyAflag ==20)||(iQtyAflag ==30)||(iQtyAflag ==40))
																																	{
																																		tc_strcat(inValidQtySet,"\n");
																																	}
																																	tc_strcat(inValidQtySet,p_child_item_id);
																																	tc_strcat(inValidQtySet,",");
																																	printf("\n MDL:GM:P60:CP module address [%s] added to error set.:[%s]",sMDLinofA2,inValidQtySet);fflush(stdout);
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																										break; //COnsidered only one released revision.
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
											else
											{
												printf("\n MDL:GM:P61:FAILED for GM DML FROMTO-ststus is NULL.");fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please update FROM-TO DR-status value for Gate maturation DML and re-process DML. \nDML number: ",sDMLno);
												decision = EPM_nogo;
												return decision;
											}
											//if(TaskCMRef) MEM_free(TaskCMRef);
                                           //if(rev_list) MEM_free(rev_list);
										}
									}
								}
							}
						}
					}
				}
				//Error string
				printf("\n MDL:Final:sManMOErr:[%s] \n",sManMOErr);fflush(stdout);
				printf("\n MDL:Final:sManSOErr:[%s] \n",sManSOErr);fflush(stdout);
				printf("\n MDL:Final:sManSODupErr:[%s] \n",sManSODupErr);fflush(stdout);
				printf("\n MDL:Final:sNManSODupErr:[%s] \n",sNManSODupErr);fflush(stdout);
				printf("\n MDL:Final:sCPModuleAvailErr:[%s] \n",sCPModuleAvailErr);fflush(stdout);
				printf("\n MDL:Final:inValidQtySet:[%s] \n",inValidQtySet);fflush(stdout);
				printf("\n MDL:Final:OtherZeroQtySet:[%s] \n",OtherZeroQtySet);fflush(stdout);
				if(tc_strcmp(sManMOErr,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Below are mandatory module addresses, please attach in BOM. (ManMO)");
					tc_strcat(sFinalErr,sManMOErr);
				}
				if(tc_strcmp(sManSOErr,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Below are mandatory module addresses, please attach in BOM. (ManSO)");
					tc_strcat(sFinalErr,sManSOErr);
				}
				if(tc_strcmp(sManSODupErr,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Modules for below are module addresses are duplicated, please remove duplication. (ManSODup)");
					tc_strcat(sFinalErr,sManSODupErr);
				}
				if(tc_strcmp(sNManSODupErr,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Modules for below are module addresses are duplicated, please remove duplication. (NManSODup)");
					tc_strcat(sFinalErr,sNManSODupErr);
				}
				if(tc_strcmp(sCPModuleAvailErr,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Below are mandatory CAD module addresses, please attach in BOM.");
					tc_strcat(sFinalErr,sCPModuleAvailErr);
				}
				if(tc_strcmp(inValidQtySet,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Below modules are with more than 1 quantity.");
					tc_strcat(sFinalErr,inValidQtySet);
				}
				if(tc_strcmp(OtherZeroQtySet,"")!=0)
				{
					tc_strcat(sFinalErr,"\n");
					tc_strcat(sFinalErr,"Below IFD/Dummy/CP Modules are with more than 1 quantity. Its should be with 0 quantity.");
					tc_strcat(sFinalErr,OtherZeroQtySet);
				}
				if (tc_strlen(sFinalErr) > 0)
				{
					printf("\n MDLFinal Error:::[%s] \n",sFinalErr);fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Please find the below BOM error.\nPlease correct it and process. ",sFinalErr);
					decision = EPM_nogo;
					return decision;
				}
				else
				{
					printf("\n MDL:Final:NO Error...........\n");fflush(stdout);
				}
			}
		}
	}
	
	/*if(BomComInfo1){MEM_free(BomComInfo1);}
	if(BomComInfo2){MEM_free(BomComInfo2);}
	if(BomComInfo3){MEM_free(BomComInfo3);}
	if(BomComInfo4){MEM_free(BomComInfo4);}
	if(BomComInfo5){MEM_free(BomComInfo5);}
	if(BomComInfo6){MEM_free(BomComInfo6);}
	if(BomComInfo7){MEM_free(BomComInfo7);}
	if(BomComInfo8){MEM_free(BomComInfo8);}
	if(BomComInfo9){MEM_free(BomComInfo9);}
	if(sDMLtaskno){MEM_free(sDMLtaskno);}
	if(sDMLno){MEM_free(sDMLno);}
	if(DMLtype){MEM_free(DMLtype);}
	if(DMLProj){MEM_free(DMLProj);}
	if(PlntToPlnt){MEM_free(PlntToPlnt);}
	if(DMLDR){MEM_free(DMLDR);}
	if(DMLBUnit){MEM_free(DMLBUnit);}
	if(Tsk_object_type){MEM_free(Tsk_object_type);}
	if(Prt_object_type){MEM_free(Prt_object_type);}
	if(PartMstr_no){MEM_free(PartMstr_no);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(Prtrel_status){MEM_free(Prtrel_status);}
	if(Partno){MEM_free(Partno);}
	if(PartTyp){MEM_free(PartTyp);}
	if(PartPlfFrm){MEM_free(PartPlfFrm);}
	if(sPrtColInd){MEM_free(sPrtColInd);}
	if(rev_idd){MEM_free(rev_idd);}
	if(sMDLinofA1){MEM_free(sMDLinofA1);}
	if(sMDLinofA2){MEM_free(sMDLinofA2);}
	if(sMDLinofA3){MEM_free(sMDLinofA3);}
	if(sMDLinofA4){MEM_free(sMDLinofA4);}
	if(sMDLinofA5){MEM_free(sMDLinofA5);}
	if(sMDLinofA6){MEM_free(sMDLinofA6);}
	if(sMDLinofA7){MEM_free(sMDLinofA7);}
	if(sMDLinofA8){MEM_free(sMDLinofA8);}
	if(sMDLinofA9){MEM_free(sMDLinofA9);}
	if(sMDLinofA10){MEM_free(sMDLinofA10);}*/
	printf("\n tm_ModuleAddPlatFormValiRule Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ModuleAddPlatFormValiRule Function end...");
	return decision;
}
