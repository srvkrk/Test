#include "TMLLibrary_server_exits.h"



int tm_PTIReviewAct(EPM_action_message_t msg)
{

    printf("\n *********** ::start here:: **********");fflush(stdout);

	int error_code			= ITK_ok;
    int count			    = 0;
    int counttt			    = 0;
    int ClrIndFlag          = 0;    
    int tskcount            = 0;
    int l                   = 0;
    int partcnt             = 0;
    int k                   = 0;
    int no_attach           = 0;
    int i                   = 0;
    int r                   = 0;
    int eightyflag                   = 0;


	tag_t  DMLTag           = NULLTAG;
	tag_t  DMLRevTag        = NULLTAG;
	tag_t  query			= NULLTAG;
	tag_t  TagClassId	    = NULLTAG;
	tag_t  objTypeTag	    = NULLTAG;
	tag_t  AssyTag	        = NULLTAG;
	tag_t  tskreltype	    = NULLTAG;
	tag_t  roottask			= NULLTAG;
	tag_t  task_tag			= NULLTAG;
	tag_t  relation_type			= NULLTAG;

    tag_t  *contrlObjs      = NULLTAG;
    tag_t  *tskobjs         = NULLTAG;
    tag_t  *PartsTag        = NULLTAG;
    tag_t  *secondary_objects        = NULLTAG;


    char *ObjClassName			= NULL;
	char *item_id				= NULL;
    char *businessUnit			= NULL;
	char *releasetype			= NULL;
	char *fromtostatus			= NULL;
	char *sDMLDR				= NULL;
	char *RelTypeCat			= NULL;
	char *type_name			    = NULL;
	char *Object_ClrInd			= NULL;
	char *Part_no			    = NULL;
	char *DMLType			    = NULL;
	char *info1	                = NULL;
	char *info2				    = NULL;
	char *info3				    = NULL;
	char *info4				    = NULL;
	char *sDMYDMLType				    = NULL;
	tag_t  DMLTaskTag = NULLTAG;
	logical is_latest;
	char   objTypeofTask[TCTYPE_name_size_c+1];
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_entriesProj = (char **) MEM_alloc(30 * sizeof(char *));
	char **DML_qry_entry = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	char **qry_valuesProj = (char **) MEM_alloc(100 * sizeof(char *));
	char **DML_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	sDMYDMLType=(char *)MEM_alloc(20);

	tag_t  *Attachments	    = NULLTAG;

	printf("\n tm_PTIReviewAct Function started...");fflush(stdout);
	TC_write_syslog("\n tm_PTIReviewAct Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\tm_PTIReviewAct:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_PTIReviewAct:INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];
			if(DMLRevTag != NULLTAG)
			{
			  qry_entries[0] ="SYSCD";
			  qry_values[0]  ="PTI";
			  
			  ITK_CALL(QRY_find2("Control Objects...", &query));
			  ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
			  printf("\n tm_PTIReviewAct: Control objects : count==>%d \n",count);fflush(stdout);
			  if (count>0)
			  {

				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&info1));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&info2));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&info3));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&info4));
				printf("\n tm_PTIReviewAct :L1:info1 is : [%s]  L2:info2 is : [%s]  L3:info3 is : [%s] L4:info4 is : [%s]\n",info1,info2,info3,info4);fflush(stdout);

				if (tc_strstr(info1,"PTIOFF")==NULL)
				{
					ITK_CALL(POM_class_of_instance(DMLRevTag,&TagClassId));	//class=ChangeRequestRevision
					ITK_CALL(POM_name_of_class(TagClassId,&ObjClassName));
					printf("\n tm_PTIReviewAct : ObjClassName: %s",ObjClassName);

					if(tc_strstr(ObjClassName,"ChangeRequestRevision")!=NULL)
					{

                        ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLType));
						printf("\n tm_PTIReviewAct : DMLType: %s",DMLType);
						//info2: MR,TOMR,VEH
						
						tc_strcpy(sDMYDMLType,"");
						tc_strcpy(sDMYDMLType,",");
						tc_strcat(sDMYDMLType,DMLType);
						tc_strcat(sDMYDMLType,",");
						printf("\n DMY:sDMYDMLType: %s",sDMYDMLType);fflush(stdout);
						if(tc_strstr(info2,sDMYDMLType)!=NULL)
						{
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type ));
							ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,relation_type,&counttt,&secondary_objects));
							printf("\n rev: counttt:%d", counttt);fflush(stdout);
							eightyflag=0;
							for (r=0;r<counttt;r++)
							{
								task_tag=secondary_objects[r];
								if (task_tag != NULLTAG)
								{
									if(ITEM_rev_sequence_is_latest(task_tag,&is_latest)!=ITK_ok)PrintErrorStack();
									if(is_latest != true)
									{
									  printf("\n CV_PTI_is_Tskltst is not true .....\n");fflush(stdout);
									}
									else
									{
										if(AOM_ask_value_string(task_tag,"item_id",&item_id)!=ITK_ok)PrintErrorStack();
										printf("\n CV_PTI_:item_id : %s",item_id);fflush(stdout);
										if (tc_strstr(item_id,"_80")!=NULL)
										{
											eightyflag=1;
											printf("\n eightyflag.......... %d",eightyflag);fflush(stdout);
											break;
										}
									}
								}
							}
							if (eightyflag>0)
							{
								printf("\n eightyflag 1  %d",eightyflag);fflush(stdout);
								return 0;
							}
							else
							{
							  printf("\n eightyflag 2  %d",eightyflag);fflush(stdout);
							  return 1;
							}
						}
						else
						{
						  return 1;
						}
					}
				}
				else
				{
				  return 1;
				}				
			  }
			}
		}
	}
	printf("\n tm_PTIReviewAct Function end...");fflush(stdout);
	TC_write_syslog("\n tm_PTIReviewAct Function end...");
	//return error_code;
	return 0;
}