/***********************************************************************************************************************************
*  File				:	tm_MBPAGen.c 
*  Creator			: 	Sandeep/Abineshwar
*
*  Modification History :
*
*  S.No			Date				CR		Modified By				Modification Notes
*	1		27-Sep-2024					     Abineshwar			File and code developed for MBPA Generation
* *********************************************************************************************************************************
*/

//#include <tc/tc.h>
//#include <itk/mem.h>
//#include <base_utils/ResultCheck.hxx>
//#include <base_utils/IFail.hxx>
//#include <base_utils/DateTime.hxx>
//#include <epm/releasestatus.h>

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <pom/pom/pom_errors.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <mld/journal/journal.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>

#define ITK_errMBPA			(EMH_USER_error_base + 3)
#define	t5PartGenErr01 			(EMH_USER_error_base + 1000)
#define	t5PartGenErr02 			(EMH_USER_error_base + 1001)
#define	t5PartGenErr03 			(EMH_USER_error_base + 1002)
#define NULL_ERROR				(EMH_USER_error_base + 1003)
#define	t5PartGenErr04 			(EMH_USER_error_base + 1004)
#define	t5PartGenErr05 			(EMH_USER_error_base + 1005)
#define	t5PartGenErr06 			(EMH_USER_error_base + 1006)
#define	t5PartGenErr07 			(EMH_USER_error_base + 1007)
#define	t5PartGenErr08 			(EMH_USER_error_base + 1008)
#define	t5PartGenErr09 			(EMH_USER_error_base + 1009)
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}
#define CONST_PUID													"puid"
#define CONST_UNIQUEID												"uniqueId"
#define CONST_FIRST_ID												"FirstID"
#define CONST_SEC_ID												"SecID"
#define CONST_FINAL_ID												"FinalID"
#define SA_OBJECT_TYPE												"object_type"
#define SA_OBJECT_NAME 												"object_name"
#define SA_OBJECT_ID 												"item_id"

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}




char* subStringRest(char* mainStringf, int fromCharf, int toCharf)
{
        int i;
        char* retStringf=NULL;
         retStringf = (char*) MEM_alloc(2);;
        for(i=0; i < toCharf; i++ )
                *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        
        printf("retStringf=%s",retStringf);
        return retStringf;
}
char* subStringRest1(char* mainStringf, int fromCharf, int toCharf)
{
        int i;
        char* retStringf=NULL;
         retStringf = (char*) MEM_alloc(2);
        for(i=0; i < toCharf; i++ )
                *(retStringf+i) = *(mainStringf+i+fromCharf);
        //*(retStringf+i) = '\0';
        
        printf("retStringf=%s",retStringf);
        return retStringf;
}

char* GetCurrentyear()
{
    time_t t;
    char        *timestamp            =   NULL;
	timestamp = (char *) MEM_alloc(100 * sizeof(char *));
	time(&t);
    timestamp = ctime(&t);
    printf("\n Start Time..Of Report Generation..%s",timestamp);
    char* timestamp2 = NULL;
    timestamp2 = (char*) MEM_alloc(100);
    strcpy(timestamp2,timestamp);
    char* str1 = NULL;
    char* str2 = NULL;
    char* str3 = NULL;
    char* str4 = NULL;
    char* str5 = NULL;
    str1 = strtok(timestamp2," ");
    str2 = strtok(NULL," ");
    str3 = strtok(NULL," ");
    str4 = strtok(NULL," ");
    str5 = strtok(NULL," ");
    printf("\n str5 = %s",str5);
    char* str6 = NULL;
    str6 = subStringRest(str5, 2, 3);
    printf("\n str6 = %s",str6);
    char* retyear=NULL;
    retyear = (char*) MEM_alloc(3);
    strcpy(retyear,str6);
    return retyear;
}


int tm_updateObjMasterFormNameMBPA(tag_t tObj, char	*mbpaidname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;

	printf("\nInside tm_updateObjMasterFormNameMBPA");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\n tm_updateObjMasterFormNameMBPA: Item ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
    ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));


	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			printf("\n Type Name:");fflush(stdout);
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			

	
			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;
			

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			{
				printf("\n Inside secondary Type Name:%s,%s ..............\n",type_name,mbpaidname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mbpaidname));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
			
		}
	}
	return 0;
}

int tm_updateObjRevMasterFormNameMBPA(tag_t tObj, char	*mbpaid)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nInside tm_updateObjRevMasterFormNameMBPA ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(mbpaid)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,mbpaid);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);//fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s..............",type_name);//fflush(stdout);
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,mbpaid);fflush(stdout);				
				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
				printf("I am In Matched tm_updateObjRevMasterFormNameMBPA...................\n");
			}
			
			

		}
	}
	return 0;
}

int tm_MBPAGeneration_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	
	
	tag_t new_item				= NULLTAG;
	tag_t item_master_form		= NULLTAG;
	tag_t item_rev_master_form  = NULLTAG;
	int isnew              = 0;		
	
	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );
    
	printf("\n tm_MBPAGeneration_set_init_val Started ");fflush(stdout);
	
	char    *qryEntry[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
	char    *qryValues[3]= {"STDSI","AUTOGENMBPA","0"};

	tag_t qryTagCtrl=NULLTAG;
    int qryCount=0;
    tag_t* qryResult=NULLTAG;

    ITKCALL(QRY_find2("Control Objects...", &qryTagCtrl));
    if (qryTagCtrl)
    {
        printf("\n Control Object Query Found For Qry Task Has EPA \n");fflush(stdout);
        ITKCALL(QRY_execute(qryTagCtrl, 3, qryEntry, qryValues, &qryCount, &qryResult));
        printf("\n Control Object Query Count=%d",qryCount);fflush(stdout);
    }
	if(qryCount > 0)
	{
	
	    if(new_item != NULLTAG)
	    {
			tag_t  CurrentRoleTag = NULLTAG;
			char*	roleName	= NULL;
			char*	MBPAPlant	= NULL;
			MBPAPlant = (char *)MEM_alloc(20);
			
		    ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		    ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		    printf("\n roleName => %s\n",roleName); fflush(stdout);
			if(tc_strcmp(roleName,"mbpa_create_jsr") == 0)
			{
				tc_strcpy(MBPAPlant,"JSR");
			}
			else if(tc_strcmp(roleName,"mbpa_create_lko") == 0)
			{
				tc_strcpy(MBPAPlant,"LKO");
			}
			else if(tc_strcmp(roleName,"mbpa_create_pune") == 0)
			{
				tc_strcpy(MBPAPlant,"PUNECVBU");
			}
			else if(tc_strcmp(roleName,"mbpa_create_dwd") == 0)
			{
				tc_strcpy(MBPAPlant,"DWD");
			}
			else if(tc_strcmp(roleName,"mbpa_create_utk") == 0)
			{
				tc_strcpy(MBPAPlant,"PNR");
			}
		    else
			{
				EMH_clear_errors();
                EMH_store_error_s1(EMH_severity_error, ITK_errMBPA, "You are not Authorized user for MBPA Creation");
                return ITK_errMBPA;
			}
	    	
	    	tag_t			new_rev		= NULLTAG;
			if(ITEM_ask_latest_rev(new_item,&new_rev));
			
			
			
			/* MBPA ERC DML Validation Start*/
			char    *qryEntryCtrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
			char    *qryValuesCtrl[3]= {"STDSI","MBPADMLValidation","0"};
			tag_t qryTagmbaCtrl=NULLTAG;
			int qrymbpactrCount=0;
			tag_t* qryResultCtrlMB=NULLTAG;
			ITKCALL(QRY_find2("Control Objects...", &qryTagmbaCtrl));
            if (qryTagmbaCtrl)
            {
                printf("\n Control Object Query Found For MBPADMLValidation \n");fflush(stdout);
                ITKCALL(QRY_execute(qryTagmbaCtrl, 3, qryEntryCtrl, qryValuesCtrl, &qrymbpactrCount, &qryResultCtrlMB));
                printf("\n Control Object Query Count=%d",qrymbpactrCount);fflush(stdout);
            }
			if(qrymbpactrCount > 0)
			{
				printf("\n MBPA ERC DML Validation Started \n");fflush(stdout);
			    char* MBPAERCDMLNm;
			    char* MBPAERCDMLNmPlant;
			    AOM_ask_value_string(new_rev,"t5_TmpEcnNo",&MBPAERCDMLNm);
			    MBPAERCDMLNmPlant = (char *)MEM_alloc(25);
			    tc_strcpy(MBPAERCDMLNmPlant,MBPAERCDMLNm);
				
				int PlantDMLValidation = 0;
				tag_t       ERCDMLQryTg          = NULLTAG;
			    if(QRY_find2("Item Revision...", &ERCDMLQryTg));
			    if(ERCDMLQryTg != NULLTAG)
			    {
			    	printf("ERC DML query found.... \n");fflush(stdout);
			    	int         DMLCnt              = 0;
			    	tag_t       *DMLSet             = NULLTAG;
			    
			    
			    	char 		*DMLEntry[1] 	= 	{"Item ID"};
			    	char 		**DMLvalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
			    
			    	DMLvalues[0]				=	MBPAERCDMLNm;
			    	if(QRY_execute(ERCDMLQryTg,1,DMLEntry,DMLvalues,&DMLCnt,&DMLSet));
			    	tag_t refobjTypeTag = NULLTAG;
			    	if(DMLCnt > 0)
			    	{
						char* reftype_name = NULL;
						TCTYPE_ask_object_type (DMLSet[0], &refobjTypeTag);
						TCTYPE_ask_name2(refobjTypeTag,&reftype_name);
						printf("\n reftype_name = %s",reftype_name);fflush(stdout);
						if (tc_strcmp(reftype_name,"T5_EPARevision")==0)
						{
							PlantDMLValidation = 1;
						}
			    	}
			    	else
			    	{
			    		EMH_clear_errors();
			    		EMH_store_error_s1(EMH_severity_error, ITK_errMBPA, "Please try with valid ERC dml number");
			    		return ITK_errMBPA;
			    	}
				}
				
			    if(tc_strcmp(MBPAPlant,"JSR") == 0)
			    {
			    	tc_strcat(MBPAERCDMLNmPlant,"_APLJ");
			    }
			    else if(tc_strcmp(MBPAPlant,"LKO") == 0)
			    {
			    	tc_strcat(MBPAERCDMLNmPlant,"_APLL");
			    }
			    else if(tc_strcmp(MBPAPlant,"PUNECVBU") == 0)
			    {
			    	tc_strcat(MBPAERCDMLNmPlant,"_APLP");
			    }
			    else if(tc_strcmp(MBPAPlant,"DWD") == 0)
			    {
			    	tc_strcat(MBPAERCDMLNmPlant,"_APLD");
			    }
			    else if(tc_strcmp(MBPAPlant,"PNR") == 0)
			    {
			    	tc_strcat(MBPAERCDMLNmPlant,"_APLU");
			    }
			    
				
				if(PlantDMLValidation == 0)
				{
			        tag_t       DMLQryTg          = NULLTAG;
			        if(QRY_find2("Item Revision...", &DMLQryTg));
			        if(DMLQryTg != NULLTAG)
			        {
			        	printf("query found.... \n");fflush(stdout);
			        	int         DMLCnt              = 0;
			        	tag_t       *DMLSet             = NULLTAG;
			        
			        
			        	char 		*DMLEntry[1] 	= 	{"Item ID"};
			        	char 		**DMLvalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
			        
			        	DMLvalues[0]				=	MBPAERCDMLNmPlant;
			        	if(QRY_execute(DMLQryTg,1,DMLEntry,DMLvalues,&DMLCnt,&DMLSet));
			        	
			        	if(DMLCnt > 0)
			        	{
			        	}
			        	else
			        	{
			        		EMH_clear_errors();
			        		EMH_store_error_s1(EMH_severity_error, ITK_errMBPA, "Please try with valid ERC dml number");
			        		return ITK_errMBPA;
			        	}
			        }
				}
				printf("\n MBPA ERC DML Validation End \n");fflush(stdout);
			}
	    	/* MBPA ERC DML Validation End*/
			
	    	char* TempStartWith = NULL;
	    	char* TempStartWith1 = NULL;
	    	char* TempStartWith2 = NULL;
	    	TempStartWith = (char *)MEM_alloc(5);
	    	TempStartWith1 = (char *)MEM_alloc(5);
	    	TempStartWith2 = (char *)MEM_alloc(5);
	    	char* CurYear = NULL;
	    	char* CurYear1 = NULL;
	    	char* CurYear2 = NULL;
	    	CurYear = (char*) MEM_alloc(3);
	    	CurYear1 = (char*) MEM_alloc(3);
	    	CurYear2 = (char*) MEM_alloc(3);
	    	CurYear = GetCurrentyear();
	    	CurYear1 = GetCurrentyear();
			char* str6 = NULL;
			//CurYear2 = subStringRest1(CurYear1, 0, 1);
	    	printf("\n CurYear =%s",CurYear);
	    	printf("\n CurYear2 =%s",CurYear2);
			tc_strcpy(TempStartWith,"");
			tc_strcpy(TempStartWith1,"");
			STRNG_replace_str(CurYear,"\n","",&CurYear2);
	    	if (tc_strcmp(MBPAPlant,"JSR") == 0)
	    	{
	    		tc_strcpy(TempStartWith,"MJ");
	    		tc_strcpy(TempStartWith2,"MJ");
	    		tc_strcat(TempStartWith,CurYear2);
	    		tc_strcpy(TempStartWith1,"MJ");
	    		tc_strcat(TempStartWith1,CurYear2);
	    		tc_strcat(TempStartWith1,"*");
	    	}
	    	else if (tc_strcmp(MBPAPlant,"PUNECVBU") == 0)
	    	{
	    		tc_strcpy(TempStartWith,"MP");
				tc_strcpy(TempStartWith2,"MP");
	    		tc_strcat(TempStartWith,CurYear2);
	    		tc_strcpy(TempStartWith1,"MP");
	    		tc_strcat(TempStartWith1,CurYear2);
	    		tc_strcat(TempStartWith1,"*");
	    	}
	    	else if (tc_strcmp(MBPAPlant,"LKO") == 0)
	    	{
	    		
	    		tc_strcpy(TempStartWith,"ML");
				tc_strcpy(TempStartWith2,"ML");
	    		tc_strcat(TempStartWith,CurYear2);
	    		tc_strcpy(TempStartWith1,"ML");
	    		tc_strcat(TempStartWith1,CurYear2);
	    		tc_strcat(TempStartWith1,"*");
	    	}
	    	else if (tc_strcmp(MBPAPlant,"DWD") == 0)
	    	{
	    		tc_strcpy(TempStartWith,"MD");
				tc_strcpy(TempStartWith2,"MD");
	    		tc_strcat(TempStartWith,CurYear2);
	    		tc_strcpy(TempStartWith1,"MD");
	    		tc_strcat(TempStartWith1,CurYear2);
	    		tc_strcat(TempStartWith1,"*");
	    	}
	    	else if (tc_strcmp(MBPAPlant,"PNR") == 0)
	    	{	
	    		tc_strcpy(TempStartWith,"MU");
				tc_strcpy(TempStartWith2,"MU");
	    		tc_strcat(TempStartWith,CurYear2);
	    		tc_strcpy(TempStartWith1,"MU");
	    		tc_strcat(TempStartWith1,CurYear2);
	    		tc_strcat(TempStartWith1,"*");
	    	}
	    	printf("\n TempStartWith  :  %s ",TempStartWith);fflush(stdout);
	    	printf("\n TempStartWith1  :  %s ",TempStartWith1);fflush(stdout);
	    	
	    	const char *newIdValue={TempStartWith1};
	    	const char *attrVal="item_id";
	    
	    	CALLAPI(POM_enquiry_create("mbpagen_num_enq"));
	    
	    	const char *selAttrsMbpa[1] = {"puid"};
	    
	    	CALLAPI(POM_enquiry_add_select_attrs("mbpagen_num_enq", "T5_MBPAM", 1, selAttrsMbpa));
	    	CALLAPI(POM_enquiry_set_string_value("mbpagen_num_enq", "value", 1, &newIdValue,POM_enquiry_bind_value));
	    	CALLAPI(POM_enquiry_set_attr_expr   ("mbpagen_num_enq", "expression", "T5_MBPAM", attrVal, POM_enquiry_like, "value"));
	    	CALLAPI(POM_enquiry_set_where_expr  ("mbpagen_num_enq", "expression" ));
	    	CALLAPI(POM_enquiry_add_order_attr  ("mbpagen_num_enq","T5_MBPAM","creation_date",POM_enquiry_desc_order));
	    	
	    	int row1 = 0,column1 = 0;
	    	void ***MBPASet;
	    	CALLAPI(POM_enquiry_execute("mbpagen_num_enq",&row1,&column1,&MBPASet));
	    	printf("\n  No of  object found for MBPA starting with %s under T5_MBPAM class is %d \n",TempStartWith,row1);fflush(stdout);
	    	
	    	char* AutoGenMBPANum = NULL;
	    	char*	fnlitemidtoapnd		= NULL;
	    	char* TmpLstMBPANum = NULL;
	    	char*	itemidfnd			= NULL;
	    	char* tokenZ = NULL;
	    	AutoGenMBPANum = (char *)MEM_alloc(50);
	    	if(row1==0)
	    	{
	    		tc_strcpy(AutoGenMBPANum,TempStartWith);
	    		tc_strcat(AutoGenMBPANum,"0001");
	    		printf("\n  Final MBPA Number :: %s  ",AutoGenMBPANum);fflush(stdout);
	    	}
	    	else
	    	{
	    		tag_t 	gettag 				= NULLTAG;
	    		gettag=*(tag_t*)(MBPASet[0][0]);
	    		CALLAPI(AOM_ask_value_string(gettag,"item_id",&itemidfnd));
	    		printf("\n The last Generated MBPA Number :: %s \n",itemidfnd);fflush(stdout);
	    		
	    		
	            TmpLstMBPANum = (char*) MEM_alloc(20);;
	            strcpy(TmpLstMBPANum,itemidfnd);
	            printf("\n TmpLstMBPANum = %s",TmpLstMBPANum);
	            
	            
	            tokenZ = strtok(TmpLstMBPANum,TempStartWith2);
	            printf("\n tokenZ = %s",tokenZ);
	            
	            int 	tempitemidfnd 		= 0;
	            tempitemidfnd = atol(tokenZ);
	            
	            int fnlitemid = 0;
	            fnlitemid = tempitemidfnd + 1;
	            
	            printf("\n fnlitemid = %d",fnlitemid);
	            
	            
	            fnlitemidtoapnd = (char*) MEM_alloc(20);
	            strcpy(fnlitemidtoapnd,"");
	            sprintf(fnlitemidtoapnd,"%04ld",fnlitemid);
	            printf("\n fnlitemidtoapnd : %s \n",fnlitemidtoapnd);fflush(stdout);
	    		
	    		tc_strcpy(AutoGenMBPANum,TempStartWith2);
	    		tc_strcat(AutoGenMBPANum,fnlitemidtoapnd);
	    		
	    		
	    		
	    		
	    	}
	    	CALLAPI(POM_enquiry_delete("mbpagen_num_enq"));
	    	printf("\n AutoGenMBPANum : %s \n",AutoGenMBPANum);fflush(stdout);
			
	    	CALLAPI(AOM_lock(new_item));
	    	CALLAPI(AOM_set_value_string(new_item,"item_id",AutoGenMBPANum));
	    	CALLAPI(AOM_set_value_string(new_item,"object_name",AutoGenMBPANum));
	    	CALLAPI(AOM_save_without_extensions(new_item));						
	    	CALLAPI(AOM_unlock(new_item));
	    	CALLAPI(AOM_refresh(new_item,1));
			
			
			
			CALLAPI(tm_updateObjMasterFormNameMBPA(new_item, AutoGenMBPANum));//Update MASTER
			CALLAPI(tm_updateObjRevMasterFormNameMBPA(new_rev, AutoGenMBPANum));//Update MASTER
			
			CALLAPI(AOM_lock(new_rev));
	    	CALLAPI(AOM_set_value_string(new_rev,"object_name",AutoGenMBPANum));
			CALLAPI(AOM_set_value_string(new_rev,"t5_MepaPlantA",MBPAPlant));
	    	CALLAPI(AOM_save_without_extensions(new_rev));						
	    	CALLAPI(AOM_unlock(new_rev));
	    	CALLAPI(AOM_refresh(new_rev,1));
			//FL_user_update_newstuff_folder(new_item);
			
			//tag_t *RefRnce;
		    //int NoRefs;
		    //int *Levels;
		    //char **Relatins=NULL;
		    //CALLAPI(WSOM_where_referenced2(new_item, 1,&NoRefs,&Levels,&RefRnce,&Relatins));
			//tag_t relation_tag = NULLTAG;
			//CALLAPI(GRM_find_relation(new_item, RefRnce[0], NULL, &relation_tag)); //Adi
			//CALLAPI(GRM_delete_relation	(relation_tag));
			//FL_user_update_newstuff_folder(new_item);
	    	
	    	
	    	printf("\n After Setting Item_id and revision going to create part number \n");fflush(stdout);
	    	


	    	if(MBPASet) MEM_free(MBPASet);
	    	
	    	
	    }
	    else
	    {
	    	printf("\n Something is wrong, Please try with correct Input ");fflush(stdout);
	    }
	}
	else
	{
		printf("\nControl Object not found......Exit from tm_MBPAGeneration_set_init_val function .....Thank You ");fflush(stdout);
	}
	
	return ifail;
}



extern int MBPAGeninitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  mbpagen_iman_save;
	METHOD_id_t  designprt_iman_save;
	METHOD_id_t  designprt_save;
	
	printf("\n ############ After Rigister MBPAGeninitmodule");fflush(stdout);
	CALLAPI(METHOD_find_method("T5_MBPAM", TC_save_msg, &mbpagen_iman_save));
	if (mbpagen_iman_save.id != NULLTAG)
    {	
		printf("\n Before Rigister tm_MBPAGeneration_set_init_val");fflush(stdout);
		CALLAPI(METHOD_add_action(mbpagen_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_MBPAGeneration_set_init_val ,NULL));
		printf("\n After Rigister tm_MBPAGeneration_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_MBPAGeneration_set_init_val  == NULL");fflush(stdout);
	}
	
	return ifail;
	
}

DLLAPI int tm_MBPAGen_register_callbacks()
{
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_MBPAGen");fflush(stdout);   
	ifail = CUSTOM_register_exit ( "tm_MBPAGen", "USER_init_module", (CUSTOM_EXIT_ftn_t)MBPAGeninitmodule);
	printf("\n After registoring userservice....tm_MBPAGen");fflush(stdout);
	return(ITK_ok);
}
