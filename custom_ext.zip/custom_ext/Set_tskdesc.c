/********************************************************************************************************
*  File			: Set_tskdesc.c
*  Created By	: Abhilash
*  Created On	: 08-Jan-2019
*  Project		: TCUA 	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes


********************************************************************************************************/
#include "TMLLibrary_server_exits.h"

extern DLLAPI int Set_tskdesc(METHOD_message_t *msg, va_list args)
{
	int ifail				= ITK_ok;
	char   *objid					= NULL;
	char   *ErrorText				= NULL;
	
	tag_t  primary_object			= va_arg(args, tag_t);
	tag_t  objTypeTag				= NULLTAG;

	char* type_name= NULL;

	printf("\n Set_tskdesc Function started...");fflush(stdout);
	TC_write_syslog("\n Set_tskdesc Function started...");

	if(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n Set_tskdesc type_name -------->  : %s\n", type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_ChangeTask")==0) 
	{
		ifail = AOM_UIF_ask_value(primary_object,"item_id",&objid);
		printf("\n Set_tskdesc primary_object objid-------> :[%s]\n",objid);fflush(stdout);

		ifail = AOM_lock( primary_object );
		//ifail = AOM_refresh(primary_object,0);
		ifail = AOM_UIF_set_value(primary_object,"object_desc",objid);
		
		    if(ifail != ITK_ok)
            {
             ITK_CALL(AOM_unlock(primary_object));
            EMH_ask_error_text(ifail,&ErrorText);
            }
            else
            {
            ITK_CALL(AOM_save_without_extensions(primary_object));
            ITK_CALL(AOM_refresh(primary_object,0));
            ITK_CALL(AOM_unlock(primary_object));
            }
		
	}

	printf("\n Set_tskdesc Function end...");fflush(stdout);
	TC_write_syslog("\n Set_tskdesc Function end...");
	
	//if(objid){MEM_free(objid);}
	
	//return ifail;
	return 0;
}