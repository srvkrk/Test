/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Dhiraj
*  Module               :   Action Handler to Assign ChngSpeclist to DCR
*  Code                 :   DCR_ChngSpeclist_assign.c
*  Created on			:   
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"


/*
	Action Handler		:		CM_Remove_Subprocesses
	Description			:		This handler removes/deletes DML Task subprocesses
*/

int DCR_ChngSpeclist_assign(EPM_action_message_t msg)
{
	int		status				= ITK_ok;
	int		attachmentCount		= 0;
	int		att_count			= 0;
	int		j					= 0;
	int		k					= 0;
	int		ifail					= 0;
	
	tag_t	rootTask_t			= NULLTAG;
	tag_t*	taskAttachments		= NULLTAG;
	tag_t	userSession			= NULLTAG;
	char*   obj_type			= NULL;
	char*   arg					= NULL;
	char*   Val					= NULL;
	char*	property			= NULL;
	char*	value				= NULL;
	char*	UserId				= NULL;
	char*	ErrorText				= NULL;
	logical hasBypass			= true;
	
	tag_t	Patricipant_Type	= NULLTAG;
	tag_t   change_specialist   = NULLTAG;
	tag_t	participant			= NULLTAG;
	tag_t	UserTag				= NULLTAG;
	TC_write_syslog("inside ... DCR_ChngSpeclist_assign..\n");
	
	printf("\n DCR_ChngSpeclist_assign Function started...");fflush(stdout);
	TC_write_syslog("\n DCR_ChngSpeclist_assign Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	if(attachmentCount > 0)
	{
		for(att_count=0; att_count<attachmentCount; att_count++)
		{			
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[att_count],&obj_type));
			TC_write_syslog("Object Type = %s\n",obj_type);

			//			k = TC_number_of_arguments(msg.arguments);
			//			TC_write_syslog("kkkk = %d\n",k);
			//			for(j=0;j<k;j++)
			//			{
			//				ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &arg, &Val);
			//				TC_write_syslog("arg = %s\n",arg);
			//				TC_write_syslog("Val = %s\n",Val);
			//
			//				if(tc_strcmp(arg, "property") == 0)
			//				{
			//					property = MEM_alloc(250);
			//					tc_strcpy(property, "");
			//					tc_strcpy(property, Val);
			//				}
			//				if(tc_strcmp(arg, "value") == 0)
			//				{
			//					value = MEM_alloc(250);
			//					tc_strcpy(value, "");
			//					tc_strcpy(value, Val);
			//				}
			//			}
			
			
			
			if(tc_strcasecmp(obj_type,"T5_DChangeReportRevision")==0)
			{
				ITK_set_bypass(true);
				POM_get_user(&UserId, &UserTag);
				TC_write_syslog("UserId  = %s\n",UserId);

				change_specialist = UserTag;
				EPM_get_participanttype ("ChangeSpecialist1",&Patricipant_Type);
				EPM_create_participant(change_specialist,Patricipant_Type,&participant);
				
				ifail=AOM_lock(taskAttachments[att_count]);			
				
				//ifail=ITEM_rev_add_participant(taskAttachments[att_count],participant);
				ITK_CALL(PARTICIPANT_add_participant(taskAttachments[att_count],hasBypass,participant));
               if(ifail != ITK_ok)
               {
                ITK_CALL(AOM_unlock(taskAttachments[att_count]));
               EMH_ask_error_text(ifail,&ErrorText);
               }
               else
               {
               ITK_CALL(AOM_save_without_extensions(taskAttachments[att_count]));
               ITK_CALL(AOM_refresh(taskAttachments[att_count],0));
               ITK_CALL(AOM_unlock(taskAttachments[att_count]));
               }
	            			
				TC_write_syslog("DCR UPDATED..");
			}
		}
	}
	printf("\n DCR_ChngSpeclist_assign Function end...");fflush(stdout);
	TC_write_syslog("\n DCR_ChngSpeclist_assign Function end...");
	//MEM_free(UserId);
	//return status;
	return 0;
}