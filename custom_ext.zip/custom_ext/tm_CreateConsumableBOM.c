/***************************************************************************
*  File				:   tm_CreateConsumableBOM.c
*  Created By		: 	Sai D. Raypalwar.
*  Created On		:   30-Jun-2023
*  Project			:   TML
*  Purpose			:  
*  
*****************************************************************************/
#include <tccore/aom_prop.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov_msg.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <tie/tie_errors.h>
#include <tccore/grmtype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tc/wsouif_errors.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <epm/cr.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int *	decision 	=	0;
char*   output      =   NULL;


struct InputData      
{   
char InputPart[20];
char surfacevalue[10];
	
}; 

tag_t Qury_partnumber(char* partno)
{
	tag_t 			 Qryfnd 			 = NULLTAG;
	tag_t           childrev1            = NULLTAG;
	tag_t parttag = NULLTAG;
	ITK_CALL(QRY_find2("Item Revision...", &Qryfnd));
	if(Qryfnd != NULLTAG)
	{
		printf("\nFound Query Item Revision \n"); fflush(stdout);
		int 		n_entries			= 2;		
		char 		*qry_entries[2] 	= {"Item ID","Type"};
		//char	**qry_values= (char **) MEM_alloc(50 * sizeof(char *));
		char	*qry_values[]= {partno,"Design Revision"};
		int 		No_Qry_Found 		= 0;
		tag_t 		*partrevision 		= NULLTAG;
		tag_t 		part 				= NULLTAG;
		int 		P 					= 0;
		/* qry_values[0]=partno;
		//qry_values[1]="*";
		qry_values[1]="Design Revision";
		//QryValues[2]="T5_LcsAplpRlzd"; */
		
		ITK_CALL(QRY_execute(Qryfnd,n_entries,qry_entries,qry_values,&No_Qry_Found,&partrevision));
		printf("\n Total part found : %d",No_Qry_Found);fflush(stdout);
		if(No_Qry_Found > 0)
		{
			char	*PartitmID					= NULL;
			parttag=partrevision[0];
			ITK_CALL(AOM_ask_value_string(parttag,"item_id",&PartitmID));
			printf("\n\n Paste Part item id : %s",PartitmID);fflush(stdout);
		}
		
	}
	return parttag;
}

void parseAndPrintParts(const char *input, char part_no[][100], char value[][100], int *count) {
    const char *start = input;
    const char *end;
    int index = 0;

    // Process the input string until the end
    while ((end = strchr(start, '#')) != NULL) {
        // Copy the substring up to the next '#'
        int length = end - start;
        char substring[length + 1];
        strncpy(substring, start, length);
        substring[length] = '\0';

        // Split by '~'
        char *delimiter_pos = strchr(substring, '~');
        if (delimiter_pos != NULL) {
            // Null-terminate the part number string
            *delimiter_pos = '\0';
            // The part after '~' is the value
            strcpy(part_no[index], substring);
            strcpy(value[index], delimiter_pos + 1);

            // Increment the index
            index++;
        }

        // Move start to the character after '#'
        start = end + 1;
    }

    // Update the count of parts found
    *count = index;
}

void extractPartNoAndValue(const char *input, char *partNo, char *value) {
    char inputCopy[100]; // Assuming the input string won't exceed 100 characters
    strcpy(inputCopy, input); // Make a copy of the input string

    // Tokenize the input string using the delimiter '~'
    char *token = strtok(inputCopy, "~");
    if (token != NULL) {
        strcpy(partNo, token); // Copy the part number
    }

    token = strtok(NULL, "~");
    if (token != NULL) {
        strcpy(value, token); // Copy the value
    }
}

double calculateQty(char* Surfacearea, char* ConsperM)
{
	printf("\n calculateQty \n");
	
	double num = atof(ConsperM);
	double num2 = atof(Surfacearea);
	printf("\n Consumableavlue1 = %f ,surfacearea = %f \n",num,num2);
	double  result = num2 * num;
	printf("\n result %f \n",result);
	return result;
}

int CreateConsumablepart(char *selectedTask,char* tableData,int n_tags_found ,tag_t* tags_found,void *return_data)
{
	printf("\n n_tags_found: %d \n",n_tags_found);fflush(stdout);
	int 	iFail     		= ITK_ok ;
	const char *input = tableData;
	char part_noj[10][100], valuej[10][100]; // Arrays to hold the part numbers and values
    int count1 = 0;

    // Call the function to parse the parts
    parseAndPrintParts(input, part_noj, valuej, &count1);

    // Print all the part numbers and their corresponding values
    for (int i = 0; i < count1; i++) 
	{
        printf("Part No: %s, Value: %s\n", part_noj[i], valuej[i]);
    }
	
	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t   qryTagCntrlobj1		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;
	tag_t*	list_of_cntrl_tags1	= NULLTAG;
	char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char*	qry_entryCntrlformat1[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));
	char**	qry_valuesCntrlformat1	= (char **) MEM_alloc(5 * sizeof(char *));
	char Cpart_no[11][100], Cvalue[11][100]; // Arrays to hold the part numbers and values
	int count13 = 0;
	int controlObjfound	= 0;
	int controlObjfound1	= 0;
	int	n_entryCntrlobj = 3;
	int	n_entryCntrlobj1 = 3;
	int	cntrlcnt 		= 0;
	int	cntrlcnt1 		= 0;
	char* info1 =NULL;
	char* info2 =NULL;
	char* info3 =NULL;
	char* info4 =NULL;
	char* info5 =NULL;
	char* info6 =NULL;
	char* info7 =NULL;
	char* info8 =NULL;
	char* info9 =NULL;
	char* info10 =NULL;
	char* info11 =NULL;
	char* info12 =NULL;
	char* info13 =NULL;
	char* info14 =NULL;
	char* info15 =NULL;
	char* info16 =NULL;
	char* info17 =NULL;
	char* info18 =NULL;
	char* info19 =NULL;
	char* info20 =NULL;
	tag_t 	 		 parttag[10] ;
	char partNo1[50] = ""; // Buffer to store the part number
	char value11[50] = "";  // Buffer to store the value
	int index =0;
	
	if(QRY_find2("Control Objects...", &qryTagCntrlobj));
	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found for ADDULM \n");fflush(stdout);
		qry_valuesCntrlformat[0]="ADDULM-JSR";
		qry_valuesCntrlformat[1]="PART_Consumption";
		qry_valuesCntrlformat[2]="0";
							
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found for ADDULM \n");fflush(stdout);
	}
	if(controlObjfound>0)
	{
		for (cntrlcnt = 0; cntrlcnt < controlObjfound; cntrlcnt++)
		{
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo1", &info1);
			printf("\n info1: %s\n", info1);
			fflush(stdout);
			printf("\n tc_strlen(info1) %d\n", tc_strlen(info1));
			if(tc_strlen(info1)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info1, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					//printf("\n index: %d\n", index);
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo2", &info2);
			printf("\n info2: %s\n", info2);
			fflush(stdout);
			printf("\n tc_strlen(info2) %d\n", tc_strlen(info2));
			if(tc_strlen(info2)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info2, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					//printf("\n index: %d\n", index);
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo3", &info3);
			printf("\n info3: %s\n", info3);
			fflush(stdout);
			printf("\n tc_strlen(info3) %d\n", tc_strlen(info3));
			if(tc_strlen(info3)>0)
			{
		
				// Call the function to extract part number and value
				extractPartNoAndValue(info3, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					//printf("\n index: %d\n", index);
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo4", &info4);
			printf("\n info4: %s\n", info4);
			fflush(stdout);
			
			printf("\n tc_strlen(info4) %d\n", tc_strlen(info4));
			if(tc_strlen(info4)>0)
			{
		
				// Call the function to extract part number and value
				extractPartNoAndValue(info4, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					//printf("\n index: %d\n", index);
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo5", &info5);
			printf("\n info5: %s\n", info5);
			fflush(stdout);
			
			printf("\n tc_strlen(info5) %d\n", tc_strlen(info5));
			if(tc_strlen(info5)>0)
			{
		
				// Call the function to extract part number and value
				extractPartNoAndValue(info5, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo6", &info6);
			printf("\n info6: %s\n", info6);
			fflush(stdout);
			
			printf("\n tc_strlen(info6) %d\n", tc_strlen(info6));
			if(tc_strlen(info6)>0)
			{
		
				// Call the function to extract part number and value
				extractPartNoAndValue(info6, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo7", &info7);
			printf("\n info7: %s\n", info7);
			fflush(stdout);
			
			printf("\n tc_strlen(info7) %d\n", tc_strlen(info7));
			if(tc_strlen(info7)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info7, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo8", &info8);
			printf("\n info8: %s\n", info8);
			fflush(stdout);
			
			printf("\n tc_strlen(info8) %d\n", tc_strlen(info8));
			if(tc_strlen(info8)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info8, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					printf("\n index: %d\n", index);
					index++;
					
					count13++;
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo9", &info9);
			printf("\n info9: %s\n", info9);
			fflush(stdout);
			
			printf("\n tc_strlen(info9) %d\n", tc_strlen(info9));
			if(tc_strlen(info9)>0)
			{
		
				// Call the function to extract part number and value
				extractPartNoAndValue(info9, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					
					printf("\n index: %d\n", index);
					index++;
					count13++;
				}
			}
			AOM_ask_value_string(list_of_cntrl_tags[cntrlcnt], "t5_Userinfo10", &info10);
			printf("\n info10: %s\n", info10);
			fflush(stdout);
			
			printf("\n tc_strlen(info10) %d\n", tc_strlen(info10));
			if(tc_strlen(info10)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info10, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No11: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					//printf("\n index: %d\n", index);
					//count13++;
				} 
			}	
		}
	}
	
	if(QRY_find2("Control Objects...", &qryTagCntrlobj1));
	
	if (qryTagCntrlobj1)
	{
		printf("\n Control Object Query Found for ADDULM \n");fflush(stdout);
		qry_valuesCntrlformat1[0]="ADDULM-JSR";
		qry_valuesCntrlformat1[1]="PART11_Consumption";
		qry_valuesCntrlformat1[2]="0";
							
		if(QRY_execute(qryTagCntrlobj1, n_entryCntrlobj1, qry_entryCntrlformat1, qry_valuesCntrlformat1, &controlObjfound1, &list_of_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for ADDULM \n");fflush(stdout);
	}
	if(controlObjfound1>0)
	{
		for (cntrlcnt1 = 0; cntrlcnt1 < controlObjfound1; cntrlcnt1++)
		{
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo1", &info11);
			printf("\n info11: %s,\n", info11);
			fflush(stdout);
			printf("\n tc_strlen(info11) %d\n", tc_strlen(info11));
			if(tc_strlen(info11)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info11, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					//printf("\n index: %d\n", index);
					//count13++;
					//countCO++
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo2", &info12);
			printf("\n info12: %s,\n", info12);
			fflush(stdout);
			printf("\n tc_strlen(info12) %d\n", tc_strlen(info12));
			if(tc_strlen(info12)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info12, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo3", &info13);
			printf("\n info13: %s,\n", info13);
			fflush(stdout);
			printf("\n tc_strlen(info13) %d\n", tc_strlen(info13));
			if(tc_strlen(info13)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info13, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo4", &info14);
			printf("\n info14: %s,\n", info14);
			fflush(stdout);
			printf("\n tc_strlen(info14) %d\n", tc_strlen(info14));
			if(tc_strlen(info14)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info14, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo5", &info15);
			printf("\n info15: %s,\n", info15);
			fflush(stdout);
			printf("\n tc_strlen(info15) %d\n", tc_strlen(info15));
			if(tc_strlen(info15)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info15, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo6", &info16);
			printf("\n info16: %s,\n", info16);
			fflush(stdout);
			printf("\n tc_strlen(info16) %d\n", tc_strlen(info16));
			if(tc_strlen(info16)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info16, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo7", &info17);
			printf("\n info17: %s,\n", info17);
			fflush(stdout);
			printf("\n tc_strlen(info17) %d\n", tc_strlen(info17));
			if(tc_strlen(info17)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info17, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo8", &info18);
			printf("\n info18: %s,\n", info18);
			fflush(stdout);
			printf("\n tc_strlen(info18) %d\n", tc_strlen(info18));
			if(tc_strlen(info18)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info18, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo9", &info19);
			printf("\n info19: %s,\n", info19);
			fflush(stdout);
			printf("\n tc_strlen(info19) %d\n", tc_strlen(info19));
			if(tc_strlen(info19)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info19, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
			
			AOM_ask_value_string(list_of_cntrl_tags1[cntrlcnt1], "t5_Userinfo10", &info20);
			printf("\n info20: %s,\n", info20);
			fflush(stdout);
			printf("\n tc_strlen(info20) %d\n", tc_strlen(info20));
			if(tc_strlen(info20)>0)
			{
				// Call the function to extract part number and value
				extractPartNoAndValue(info20, partNo1, value11);
			
				// Print the result in the main function
				printf("CPart No: %s, CValue: %s\n", partNo1, value11);
				if(partNo1!=NULL)
				{
					strcpy(Cpart_no[index], partNo1);
					strcpy(Cvalue[index], value11);
					index++;
					
				}
			}
		}		
	}
	
	char* PartitmID =NULL;
	printf("\n index %d \n ",index);
	for (int l = 0; l <index; l++)
	{
		printf("\n CPart No[%d]: %s, CValue1: %s\n", l,Cpart_no[l], Cvalue[l]);
		
		tag_t  item =NULLTAG;
		tag_t  itemRev =NULLTAG;
		ITK_CALL(ITEM_find_item(Cpart_no[l],&item));
		ITK_CALL(ITEM_ask_latest_rev(item,&itemRev)); 
		if(itemRev!=NULLTAG)
		{
			char	*PartitmID					= NULL;
			//parttag=partrevision[0];
			ITK_CALL(AOM_ask_value_string(itemRev,"item_id",&PartitmID));
			printf("\n\n Paste Part item id : %s",PartitmID);fflush(stdout);
			parttag[l]=itemRev; 
		}
		/* parttag[l]=Qury_partnumber(Cpart_no[l]);
		if(parttag[l]!=NULLTAG)
		{
			ITK_CALL(AOM_ask_value_string(parttag[l],"item_id",&PartitmID));
			printf("\n  Part item id main: %s",PartitmID);fflush(stdout);
		} */
		else
		{
			printf("\n parttag is NULL \n");fflush(stdout);
		}
	}
	
	tag_t   latesttaskrev    		= NULLTAG;
	tag_t	solrelation_type		= NULLTAG;
	int csi = 0;
	
	if(n_tags_found>0)
	{
		
		ITK_CALL(ITEM_ask_latest_rev(tags_found[0],&latesttaskrev));
	}
	//int RelCount = 0;
	char			*Temp				= NULL;
	AOM_ask_value_string(tags_found[0],"object_type",&Temp);
	printf("\n tags_found[0] Object Type is : %s",Temp);fflush(stdout);
	AOM_ask_value_string(latesttaskrev,"object_type",&Temp);
	printf("\n latesttaskrev Object Type is : %s",Temp);fflush(stdout);
	
	
	int 			RelCount			 = 0;
	//char			*Temp				= NULL;
	char			*Part_no			= NULL;
	char*			Part_CS				= NULL;
	char*			Part_Dec			= NULL;
	char			*LifeCycle			= NULL;
	int				PartCnt				= 0;
	int				k					= 0;
	int				RawCnt				= 0;
	tag_t*			PartTags			= NULLTAG;
	tag_t   		partM            	= NULLTAG;
	tag_t			PNTag				= NULLTAG;
	tag_t			RAWrelation			= NULLTAG;
	tag_t*			RawTags				= NULLTAG;
	tag_t       	mbomviewtag			= NULLTAG;
	char        	*psmbomview			= NULL;
	char        	*view				= NULL;
	char        	*view1				= NULL;
	int         	viewcount			= 0; 
	tag_t       	*viewtag    		= NULLTAG;
	tag_t			viewtag1			= NULLTAG;	
	tag_t       	MBV         		= NULLTAG;
	tag_t       	MBVR            	= NULLTAG;
	
	tag_t*			occurrences1		= NULLTAG;
	tag_t*			occurrences2		= NULLTAG;
	tag_t*			occurrences3		= NULLTAG;
	tag_t*			occurrences4		= NULLTAG;
	tag_t*			occurrences5		= NULLTAG;
	tag_t*			occurrences6		= NULLTAG;
	tag_t*			occurrences7		= NULLTAG;
	tag_t*			occurrences8		= NULLTAG;
	tag_t*			occurrences9		= NULLTAG;
	tag_t*			occurrences10		= NULLTAG;
	tag_t       	window         		= NULLTAG;
	tag_t       	MBOM_RevRule		= NULLTAG;
	tag_t       	*MBOM_Closure_Tag	= NULLTAG;
	tag_t       	mbomClosure_Rule	= NULLTAG;
	int         	CRule_found       	= 0;
	int 			P 					= 0;
	tag_t       	top_bom_line    	= NULLTAG;
	tag_t       	top_bom_line1    	= NULLTAG;
	tag_t       	*Partchildttag		= NULLTAG;
	int         	Partchildcount      = 0;
	tag_t       	new_bl          	= NULLTAG;
	
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&solrelation_type));
	ITK_CALL(GRM_list_secondary_objects_only(latesttaskrev,solrelation_type,&PartCnt,&PartTags));
	if (PartCnt>0)
	{
		printf("\n part count :%d ",PartCnt);
		for (k=0;k<PartCnt ;k++ )
		{	
			int FlagP =0;
			char* surfaceAreaS =NULL;
			surfaceAreaS = (char *) MEM_alloc(80);
			tc_strcpy(surfaceAreaS,"");
			PNTag=PartTags[k];
 			ITK_CALL(AOM_ask_value_string(PNTag,"t5_JsrMakeBuyIndicator",&Part_CS));
			printf("\n t5_JsrMakeBuyIndicator : %s \n",Part_CS); 
			
			ITK_CALL(AOM_ask_value_string(PNTag,"object_desc",&Part_Dec));
			printf("\n Part Dec  : %s \n",Part_Dec);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(PNTag,"item_id",&Part_no));
			printf("\n Part_no  : %s \n",Part_no);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(Part_no,&partM));
			csi=0;
			for (csi=0;csi<count1;csi++)
			{
				//printf("\n ggggg.....PlantCsData[%d].csPartCount : %s\n",csi, Inputdata1[csi].InputPart);
				//printf("\n gg.....PlantCsData[%d].csValue : %s\n",csi, Inputdata1[csi].surfacevalue);
				printf(" inside solution item Part No: %s,  SValue: %s\n", part_noj[csi], valuej[csi]);
				
				if(tc_strcmp(Part_no,part_noj[csi])==0 )
				{
					FlagP++;
					tc_strcpy(surfaceAreaS, valuej[csi]);
					printf("\n part no : %s ,surfaceAreaS : %s",part_noj[csi],surfaceAreaS);
					break;
				}
			}
			
			//if(tc_strstr(Part_CS,"E99") && tc_strstr(Part_Dec,"LONG MEMBER"))
			if(FlagP>0)
			{
				
				ITKCALL(GRM_find_relation_type("T5_RPtRel", &RAWrelation));
				ITK_CALL(GRM_list_secondary_objects_only(PNTag,RAWrelation,&RawCnt,&RawTags));
				printf("\n RawCnt %d \n",RawCnt);
				if(RawCnt>0)
				{
					ITK_CALL(PS_find_view_type("T5_APLJView",&mbomviewtag))//get view tag
					
					ITK_CALL(PS_ask_view_type_name(mbomviewtag,&psmbomview));
					printf("\n Ps_view_type_name %s \n",psmbomview);fflush(stdout);
					
					ITK_CALL(ITEM_list_bom_views(partM,&viewcount, &viewtag));//partM is part number 
					printf("\n Number of bom view [%d] \n",viewcount);fflush(stdout);
					int i=0;
					if(viewcount>0)
					{
						for(i=0;i<viewcount;i++)
						{
							tag_t viewtype =NULLTAG;
							viewtag1=viewtag[i];
							ITK_CALL(PS_ask_bom_view_type(viewtag1,&viewtype));
							ITK_CALL(PS_ask_view_type_name(viewtype,&view));
							printf("\n  view [%s] \n",view);fflush(stdout);
							
						}
					}
					if(viewtag1 == NULLTAG || viewcount == 0)
					{
						ITK_CALL(AOM_lock(partM));
						double  result =0;
						int IndexCnt =0;
						ITK_CALL(PS_create_bom_view(mbomviewtag,"","",partM,&MBV));
						ITK_CALL(AOM_save_without_extensions(MBV));
						ITK_CALL(AOM_save_without_extensions(partM));
						ITK_CALL(AOM_unlock(partM));
						if(MBV!=NULLTAG)
						{
							printf("\n Inside BVR Creation \n");fflush(stdout);
							ITK_CALL(AOM_lock(PNTag));//partrevisionM -is part Revision
							ITK_CALL(PS_create_bvr(MBV,"","",false,PNTag,&MBVR));
							ITK_CALL(AOM_save_without_extensions(MBVR));
							ITK_CALL(AOM_save_without_extensions(PNTag));
							ITK_CALL(AOM_unlock(PNTag));
						}
						for(int IndexCnt =0;IndexCnt<index;IndexCnt++)
						{
							tag_t*	occurrences		= NULLTAG;
							result = calculateQty(surfaceAreaS,Cvalue[IndexCnt]);
							printf("\n result main [%d]=%f \n",IndexCnt,result);
							ITKCALL(PS_create_occurrences(MBVR,parttag[IndexCnt],NULLTAG,1,&occurrences));
							ITKCALL(PS_set_occurrence_qty(MBVR, occurrences[0],result));
						}
						
						ITKCALL(AOM_save_without_extensions(MBVR)); 
						ITKCALL(AOM_save_without_extensions(PNTag));
						ITKCALL(AOM_refresh(MBVR, 0));
						ITKCALL(AOM_refresh(PNTag, 0));
						
						printf("\n \n BOM View Expansion ........ \n");fflush(stdout);
						ITK_CALL(BOM_create_window(&window));
						ITK_CALL(CFM_find("ERC release and above", &MBOM_RevRule));
						
						ITK_CALL(PIE_find_closure_rules2( "BOMViewClosureRuleAPLJ",PIE_TEAMCENTER, &CRule_found, &MBOM_Closure_Tag ));
						
						printf ("APLJ closure rule count %d \n",CRule_found);fflush(stdout);
						if (CRule_found > 0)
						{
							mbomClosure_Rule = MBOM_Closure_Tag[0];
							printf ("closure rule found \n");fflush(stdout);
							
							ITK_CALL(BOM_window_set_closure_rule(window,mbomClosure_Rule,0,NULL,NULL));
							ITK_CALL(BOM_set_window_config_rule( window, MBOM_RevRule ));
							ITK_CALL(BOM_set_window_top_line(window, NULLTAG, PNTag, viewtag[0], &top_bom_line1));
							ITK_CALL(BOM_line_ask_all_child_lines(top_bom_line1, &Partchildcount, &Partchildttag));
							printf("\n\n Number of child  Part found in APLJ  : %d\n",Partchildcount);fflush(stdout);
							if (Partchildcount >0)
							{
								
								for(int P = 0; P < Partchildcount; P++)
								{
									ITK_CALL( AOM_set_value_string(Partchildttag[P],"bl_occ_t5_CurrentViewMaskJ","-12"));
									printf("\n\n Value set as -12 ");fflush(stdout);
									
								}
								
								
							}
						}
						printf("\n BOM is created \n");
						output = (char*) MEM_alloc(100 * sizeof(char));
						tc_strcpy(output,"SYS");
						printf("\n ***********successfully added*******  \n");
					}
					else
					{
						int flag =1;
						
						int viewcount12 =0;
						int countlb3 =0;
						tag_t       *viewtag12    		= NULLTAG;
						tag_t* bvrlb3 =NULLTAG;
						tag_t bvrold =NULLTAG;
						
						ITK_CALL(ITEM_rev_list_bom_view_revs(PNTag,&countlb3,&bvrlb3));
						printf("\n Number of bom view (countlb) [%d] \n",countlb3);fflush(stdout);
						
						if(countlb3>=2)
						{
							printf("\n Please correct data \n");
						}
						if(countlb3==0)
						{
							double  result =0;
							int IndexCnt =0;
							printf("\n Inside BVR2 Creation \n");fflush(stdout);
							
							ITK_CALL(PS_create_bvr(viewtag[0],"","",false,PNTag,&MBVR));
							ITK_CALL(AOM_save_without_extensions(MBVR));
							ITK_CALL(AOM_save_without_extensions(PNTag));
							
							for(int IndexCnt =0;IndexCnt<index;IndexCnt++)
							{
								tag_t*	occurrences		= NULLTAG;
								result = calculateQty(surfaceAreaS,Cvalue[IndexCnt]);
								printf("\n result main [%d]=%f \n",IndexCnt,result);
								ITKCALL(PS_create_occurrences(MBVR,parttag[IndexCnt],NULLTAG,1,&occurrences));
								ITKCALL(PS_set_occurrence_qty(MBVR, occurrences[0],result));
							}
							
							ITKCALL(AOM_save_without_extensions(MBVR)); 
							ITKCALL(AOM_save_without_extensions(PNTag));
							ITKCALL(AOM_refresh(MBVR, 0));
							ITKCALL(AOM_refresh(PNTag, 0));
							
							printf("\n \n BOM View Expansion ........ \n");fflush(stdout);
							ITK_CALL(BOM_create_window(&window));
							ITK_CALL(CFM_find("ERC release and above", &MBOM_RevRule));
							
							ITK_CALL(PIE_find_closure_rules2( "BOMViewClosureRuleAPLJ",PIE_TEAMCENTER, &CRule_found, &MBOM_Closure_Tag ));
							
							printf ("APLJ closure rule count %d \n",CRule_found);fflush(stdout);
							if (CRule_found > 0)
							{
								mbomClosure_Rule = MBOM_Closure_Tag[0];
								printf ("closure rule found \n");fflush(stdout);
								
								ITK_CALL(BOM_window_set_closure_rule(window,mbomClosure_Rule,0,NULL,NULL));
								ITK_CALL(BOM_set_window_config_rule( window, MBOM_RevRule ));
								ITK_CALL(BOM_set_window_top_line(window, NULLTAG, PNTag, viewtag[0], &top_bom_line1));
								ITK_CALL(BOM_line_ask_all_child_lines(top_bom_line1, &Partchildcount, &Partchildttag));
								printf("\n\n Number of child  Part found in APLJ  : %d\n",Partchildcount);fflush(stdout);
								if (Partchildcount >0)
								{
									
									for(int P = 0; P < Partchildcount; P++)
									{
										ITK_CALL( AOM_set_value_string(Partchildttag[P],"bl_occ_t5_CurrentViewMaskJ","-12"));
										printf("\n\n Value set as -12 ");fflush(stdout);
										
									}
									
									
								}
							}
							
							printf("\n countlb3==0\n");
							output = (char*) MEM_alloc(100 * sizeof(char));
							tc_strcpy(output,"SYS");
							printf("\n ***********successfully added*******  \n");
						}
						else
						{
							
							double  result =0;
							int IndexCnt =0;
							int count =0;
							int occ_count =0;
							tag_t* occ_tag =NULLTAG;
							printf("\n Delete previous Occurances & Add new occurences");fflush(stdout);
							ITK_CALL(PS_list_occurrences_of_bvr(bvrlb3[0],&occ_count,&occ_tag));
							printf("\n Number of occurences in BVR  %d \n\n",occ_count); fflush(stdout);
							if (occ_count>0)
							{
								ITK_CALL(AOM_lock(bvrlb3[0]));
								printf("\n Going to delete occurences \n\n"); fflush(stdout);
								for(count = 0; count < occ_count; count++)
								{
									ITK_CALL(PS_delete_occurrence(bvrlb3[0], occ_tag[count]));
									printf("\n check 1\n ");
								}
								ITK_CALL(AOM_save_without_extensions(bvrlb3[0]));
								ITK_CALL(AOM_unlock(bvrlb3[0]));
							}
							else
							{
								printf("\n Number of occurences is Zero \n\n"); fflush(stdout);
							}
							
							for(int IndexCnt =0;IndexCnt<index;IndexCnt++)
							{
								tag_t*	occurrences		= NULLTAG;
								result = calculateQty(surfaceAreaS,Cvalue[IndexCnt]);
								printf("\n result main [%d]=%f \n",IndexCnt,result);
								ITKCALL(PS_create_occurrences(bvrlb3[0],parttag[IndexCnt],NULLTAG,1,&occurrences));
								ITKCALL(PS_set_occurrence_qty(bvrlb3[0], occurrences[0],result));
							}
							
							ITKCALL(AOM_save_without_extensions(bvrlb3[0])); 
							ITKCALL(AOM_save_without_extensions(bvrlb3[0]));
							ITKCALL(AOM_refresh(bvrlb3[0], 0));
							
							printf("\n \n BOM View Expansion ........ \n");fflush(stdout);
							ITK_CALL(BOM_create_window(&window));
							ITK_CALL(CFM_find("ERC release and above", &MBOM_RevRule));
							
							ITK_CALL(PIE_find_closure_rules2( "BOMViewClosureRuleAPLJ",PIE_TEAMCENTER, &CRule_found, &MBOM_Closure_Tag ));
							
							printf ("APLJ closure rule count %d \n",CRule_found);fflush(stdout);
							if (CRule_found > 0)
							{
								mbomClosure_Rule = MBOM_Closure_Tag[0];
								printf ("closure rule found \n");fflush(stdout);
								
								ITK_CALL(BOM_window_set_closure_rule(window,mbomClosure_Rule,0,NULL,NULL));
								ITK_CALL(BOM_set_window_config_rule( window, MBOM_RevRule ));
								ITK_CALL(BOM_set_window_top_line(window, NULLTAG, PNTag, viewtag[0], &top_bom_line1));
								ITK_CALL(BOM_line_ask_all_child_lines(top_bom_line1, &Partchildcount, &Partchildttag));
								printf("\n\n Number of child  Part found in APLJ  : %d\n",Partchildcount);fflush(stdout);
								if (Partchildcount >0)
								{
									
									for(int P = 0; P < Partchildcount; P++)
									{
										ITK_CALL( AOM_set_value_string(Partchildttag[P],"bl_occ_t5_CurrentViewMaskJ","-12"));
										printf("\n\n Value set as -12 ");fflush(stdout);
										
									}
									
									
								}
								//printf("\n part nedd to be added\n");
								
							}
							//strcpy(output,"SYS");
							
							output = (char*) MEM_alloc(100 * sizeof(char));
							tc_strcpy(output,"SYS");
							printf("\n ***********successfully added*******  \n");
						
						}
					}
				}
				/* else
				{
					//strcpy(output,"RawCnt");
					output = (char*) MEM_alloc(100 * sizeof(char));
					tc_strcpy(output,"RawCnt");
					printf("\n Not have any Raw part \n");fflush(stdout);
				} */
			}
			
			
		}
		
		
	}
	/* else
	{
		//strcpy(output,"TNHP");
		output = (char*) MEM_alloc(100 * sizeof(char));
		tc_strcpy(output,"TNHP");
		printf("\n Selected Task Not having any Part. \n");
	} */
	printf("\n output Length : %d ", tc_strlen(output));fflush(stdout);
	*((char **) return_data) = (char *) MEM_alloc( tc_strlen(output) * sizeof(char));

	strcpy( *((char **) return_data), output);	
	MEM_free(output);
	return ITK_ok;
}

int CreateConsumableBOM(void *return_data)
{
	char 			*selectedTask		= 	NULL;
	char 			*tableData			= 	NULL;
	char* 			tokValue 			=	NULL;
	int 			n_tags_found		=	0;
    tag_t* 			tags_found 			= 	NULL;
	const char *	attrs[1];
    const char *	values[1];
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);
	USERARG_get_string_argument(&tableData);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	printf("\n Input tableData :: %s ",tableData);fflush(stdout);
	
	attrs[0] ="item_id";
	values[0] = (char *)selectedTask;
	ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);
	
	CreateConsumablepart(selectedTask,tableData,n_tags_found ,tags_found,return_data);
}
extern int tm_CreateConsumableBOMfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	int nargs = 2;
	int retValueType;
	int inputArgTypes[2] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //Base Part
	inputArgTypes[1] = USERARG_STRING_TYPE; //BaseRev
	
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n sai tm_CreateConsumableBOMfncalling before....CreateConsumableBOM");fflush(stdout);  
	ifail=USERSERVICE_register_method("CreateConsumableBOM",(USER_function_t)CreateConsumableBOM,nargs,inputArgTypes,retValueType);
	printf("\n sai tm_CreateConsumableBOMfncalling....>>>>>>>>>>>>>>>>>>>>>>>>>CreateConsumableBOM>>>>>>>>>>>>>>>>>>>>>>>\n\n\n");fflush(stdout); 
	return ifail;
}
extern DLLAPI int tm_CreateConsumableBOM_register_callbacks ()
{	
	int ifail    = ITK_ok;
	printf("\n sai Before registering userservice....tm_CreateConsumableBOM");fflush(stdout); 
	ifail = CUSTOM_register_exit("tm_CreateConsumableBOM", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_CreateConsumableBOMfncalling);
	printf("\n sai After registering userservice....tm_CreateConsumableBOM");fflush(stdout);
	return(ITK_ok);
}