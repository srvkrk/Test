/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ModularBomComplianceChk.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating Modular MBOM Accuracy check report for VC.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Venkat Mesala						    Base Code
* 			

* -----------------------------------------------------------------------------
* 
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
//#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <string.h>
#include <sys/stat.h>
//#include <epm/cr_effectivity.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

//void ReAssignedAbeyaser(tag_t Taskrev,tag_t AnalystTag,tag_t ToAssign,tag_t Assigner)
void ReAssignedAbeyaser(tag_t Taskrev,tag_t AnalystTag,tag_t ToAssign,tag_t Assigner)

{
	tag_t*			OldParticipantRel			= NULLTAG;
	tag_t		OldParticipantRelTag			= NULLTAG;
	tag_t		OldObjTypTask					= NULLTAG;
	tag_t		new_participant_type			= NULLTAG;
	tag_t		new_participant_tag				= NULLTAG;
	tag_t*		task_tag						= NULLTAG;
	tag_t		process_task					= NULLTAG;
	
	char*			type_name					= NULL;
	char*			Task_Id						= NULL;
	char*			root_target_attach			= NULL;
	char*			abeyuserid					= NULL; 
	char*			Preuserid					= NULL; 
	char*			Final_Touser				= NULL;
	char*			Temp_Final_To_user			= NULL;
	char*			Temp_Final_To_user1			= NULL;
	char*			frmusr						= NULL;
	char*			tusr						= NULL;
	char*			Task_no						= NULL;


	int		task_count					= 0;
	int		A							= 0;
	int		oldusrcount					= 0;
	int		n_participant_types = 1;

	printf("\n inside ReAssignedAbeyaserAssign1111111\n");
	ITKCALL(SA_ask_user_identifier2(ToAssign,&abeyuserid));
	ITKCALL(SA_ask_user_identifier2(Assigner,&Preuserid));
	ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
	ITKCALL(AOM_ask_value_string(Taskrev,"item_id",&Task_Id));
	ITKCALL(PARTICIPANT_ask_participants(Taskrev, AnalystTag, &oldusrcount, &OldParticipantRel));								
	printf("\n Task node name :%s count : %d taskid : [%s]  :To Assign user Id :[%s]: previoues user id : %s\n",type_name ,oldusrcount,Task_Id,abeyuserid,Preuserid);
	ITKCALL(EPM_ask_assigned_tasks(Assigner,2,&task_count,&task_tag));
	printf("\n Number of task found in responsible party  =%d\n",task_count);fflush(stdout);
	for(A = 0; A<task_count;A++)
	{
		process_task=task_tag[A];
		ITKCALL(AOM_UIF_ask_value(process_task,"root_target_attachments",&root_target_attach));
		if(tc_strstr(root_target_attach,Task_Id)!= NULL)
		{
			printf("\n Root attachment=%s",root_target_attach);fflush(stdout);
			printf("\n task id and process task matched \n");fflush(stdout);
			ITKCALL(EPM_assign_responsible_party(process_task,ToAssign));
			printf("\n---->> Assigned To user as responsible PARTY....................\n");fflush(stdout);
		}							
	}
									
}
//void getAbeyanceUsrId(char* usrLocation,char* usrAgencyDup ,char AbynceusrId[40] )
void getAbeyanceUsrId(char* usrLocation,char AbynceusrId[40] )
{
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t			qryTagCntrl				= NULLTAG;
	tag_t			*list_of_WSO_cntrl_tags	= NULLTAG;
	char*			userid					= NULL;
	char*			MbomAPlrev				= NULL;
	int				n_entryCntrl			= 3;
	int				control_number_found	= 0;
	int				ifail	= 0;
	printf("\n Inside abeyance userlocation and Agency :%s  \n",usrLocation);fflush(stdout);
	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl));
	if (qryTagCntrl != NULLTAG)
	{
		//if(tc_strcmp(usrLocation, "APL")== 0)
		//{
		
			printf("\n Control Object Query Found \n");fflush(stdout);
			//qry_valuesCntrl[0]="AbyPlntAPL";
			qry_valuesCntrl[0]="AbyPlntID";
			qry_valuesCntrl[1]=usrLocation;
			qry_valuesCntrl[2]="0";
				
			ITKCALL(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
	
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);

			if(control_number_found>0)
			{		
				ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &userid));
				printf("\n APL Abeyance User: %s\n",userid);fflush(stdout);
				tc_strcpy(AbynceusrId,"");
				tc_strcpy(AbynceusrId,userid);
			}
		//}
	/*	else if ((tc_strcmp(usrLocation, "STD")!=0))
		{
			printf("\n Control Object Query Found for STD\n");fflush(stdout);
			qry_valuesCntrl[0]="AbyPlntID"; 
			qry_valuesCntrl[1]=usrLocation;
			qry_valuesCntrl[2]="0";
			control_number_found =0;
			list_of_WSO_cntrl_tags= NULLTAG;
			ITKCALL(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);

			if(control_number_found>0)
			{		
				ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &userid));
				printf("\n STD Abeyance User: %s\n",userid);fflush(stdout);
				tc_strcpy(AbynceusrId,"");
				tc_strcpy(AbynceusrId,userid);
			}
		}*/
		else
		{
			printf("\n user Agency is NULL:");fflush(stdout);
		}
	}
	else
	{
		printf("\n Control Object Query not Found \n");fflush(stdout);
	}	
}

int ReportAbeyaserAssign(char*abusername, char *selectedTask, int n_tags_found, tag_t* tags_found)
{	
	int		ifail			= 0;
	int		status			= 0;
	int		tsk				= 0;
	int		st_count		= 0;
	int		ReleaseCount	= 0;
	int		n_entryCntr		= 4;
	int		i				= 0;
	int		signoffCount	= 0;
	int		iCntCntrl		= 0;
	int		count			= 0; 
	
	char*	taskid			= NULL;
	char*	Task_Id			= NULL;
	char*	WSO_Name_APL	= NULL;
	char*	Task_assignment	= NULL;
	char*	TaskAssignment	= NULL;
	char*	roleName		= NULL;
	char*	deparment		= NULL;
	char*	useragency		= NULL;
	char*	userlocation	= NULL;
	char*	username		= NULL;
	char*	Task_Rev		= NULL;
						
	//char	*AbyUser = NULL;
	 //AbyUser = (char *)MEM_alloc(50);
	char	AbyUser[40];
	char *Cur_userid		= NULL;
	Cur_userid = (char *)MEM_alloc(100);
	

    char *qry_entry[4] = {"SYSCD","SUBSYSCD", "Delete Indicator","Information-1"};
    char **qry_values = (char **)MEM_alloc(10 * sizeof(char *));
    char **qry_values1 = (char **)MEM_alloc(10 * sizeof(char *));
	char *qry_entry1[1]= {"Id"};

	tag_t*		status_list					= NULLTAG;
	tag_t		CurrentRoleTag				= NULLTAG;
	tag_t		qryTagCntrl					= NULLTAG;
	tag_t		qryTagCntrl1				= NULLTAG;
	tag_t*		t_cntrl_obj					= NULLTAG;
	tag_t*		UserTag						= NULLTAG;
	tag_t		UserTag1					= NULLTAG;
	tag_t*		signoffs					= NULLTAG;
	tag_t		AnalystTag					= NULLTAG;
	tag_t*		valueTag					= NULLTAG;
	tag_t*		WorkflowTasksTag			= NULLTAG;
	tag_t*		Member_tag			= NULLTAG;
	tag_t		Task						= NULLTAG;
	tag_t  		Taskrev  					= NULLTAG;
	tag_t  		Tsk_rev_tag  				= NULLTAG;
	tag_t		ToAssign					= NULLTAG;
	tag_t		Assigner					= NULLTAG;

	tag_t		group_tag					= NULLTAG;
	tag_t		currentgroup					= NULLTAG;

	logical			t5InProcess;

	char * 	groupname = NULL;
	char * 	abyinfo1 = NULL;
	char * 	abyinfo2 = NULL;
	char * 	abyinfo3 = NULL;
	char * 	abyinfo5 = NULL;
	char * 	abyinfo4 = NULL;
	char * 	abyinfo6 = NULL;
	char * 	abyinfo7 = NULL;
	char * 	abyinfo8 = NULL;

	char * 	default_group = NULL ;
	int			member_count		= 0 ;
	int			abeyance_control_number_found		= 0 ;
	int			abe_entryCntrl						= 3 ;
	tag_t*		abeyance_cntrl_tags		= NULLTAG;

	char *qry_entryCntrl[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));

	printf("\n inside abeyance user assigned\n");fflush(stdout);
	printf("\n	GivenTaskNum : %s\t",selectedTask);fflush(stdout);	
	printf("\n	Given Username : %s\t",abusername);fflush(stdout);

	if(n_tags_found >0)
	{
		
		for(tsk = 0 ;tsk < n_tags_found; tsk++)
		{
			Task=NULLTAG;	
			Task=tags_found[tsk];

			ITKCALL(AOM_ask_value_string(Task,"item_id",&taskid));
			printf("\n Task id is : %s ",taskid);fflush(stdout);
			
			ITKCALL(ITEM_ask_latest_rev(Task,&Taskrev));

			
			ITKCALL(QRY_find2("UserFind", &qryTagCntrl)); //control object creation required for checking the user access
			 if (qryTagCntrl != NULLTAG)
			 {
				printf("\n inside user find : %s\n",abusername);fflush(stdout);
				char *userid = NULL;
				char *root_target_attach = NULL;
				userid = (char *)MEM_alloc(100);
				tc_strcpy(userid, "");
				tc_strcpy(userid, "*");
				tc_strcat(userid, abusername);
				tc_strcat(userid, "*");
				printf("\n inside user find1 : %s\n",userid);fflush(stdout);
				qry_values1[0] = userid;
				int n_entryCntr =	1;
				int ii =	0;
				 ITKCALL (QRY_execute(qryTagCntrl, n_entryCntr, qry_entry1, qry_values1, &iCntCntrl, &UserTag));
				 if ((UserTag !=NULLTAG )&& (iCntCntrl >0) )
				 {
					printf("\n inside user execute : %s and count : %d\n",abusername,iCntCntrl);fflush(stdout);
					//for (i=0;i<iCntCntrl ;i++ )
					//{
						count	= 0; 
						UserTag1	= NULLTAG;
						username	= NULL;
						//ITKCALL(AOM_ask_value_tags(UserTag[i],"fnd0custom_user_profile",&count,&valueTag));
						ITKCALL(AOM_ask_value_string(UserTag[0],"user_name",&username));
						ITKCALL(AOM_UIF_ask_value(UserTag[0],"default_group",&default_group));
						

						ITKCALL(SA_find_groupmember_by_user(UserTag[0],&member_count,&Member_tag));
						printf("\n Task Member_tag count  and default group----->%d :%s \n",member_count,default_group); fflush(stdout);
						if (member_count >0)
						{

							for (ii=0; ii<member_count;ii++)
							{
								currentgroup=Member_tag[0];

								ITKCALL(SA_ask_groupmember_group(currentgroup,&group_tag ));
								ITKCALL(SA_ask_group_name2(group_tag,&groupname));
							}
						}
						
							
	
						printf("\n Value Tag Found Sucessfully222222222..!!!!!! : %s and user_count :%d and %s\n",username,member_count,groupname);fflush(stdout);

						//getAbeyanceUsrId(groupname,AbyUser);
						getAbeyanceUsrId(default_group,AbyUser);
						
						
						ITKCALL(AOM_ask_value_string(Taskrev,"item_id",&Task_Id));
						ITKCALL(AOM_ask_value_string(Taskrev,"item_revision_id",&Task_Rev));
						printf("\n Task no:%s AND Revision:%s ",Task_Id,Task_Rev);fflush(stdout);
						ITKCALL(AOM_ask_value_logical(Taskrev,"fnd0InProcess",&t5InProcess));
						printf("\n Task workflow inprocess or not ----->%d\n",t5InProcess); fflush(stdout);

						if(t5InProcess == 1)
						{	
							tc_strcpy(Cur_userid, "");
							tc_strcpy(Cur_userid, "*");
							tc_strcat(Cur_userid, AbyUser);
							tc_strcat(Cur_userid, "*");
							printf("\n inside user find1 : %s\n",Cur_userid);fflush(stdout);

							qry_values1[0] = Cur_userid;
							int n_entryCntr =	1;
							int ii =	0;
									
							iCntCntrl	= 0;
							char *cusername	= NULL;
							UserTag	= NULLTAG;
							tag_t curUserTag1	= NULLTAG;

							
							ITKCALL (QRY_execute(qryTagCntrl, n_entryCntr, qry_entry1, qry_values1, &iCntCntrl, &UserTag));
									
							if (iCntCntrl >0)
							{
								curUserTag1=UserTag[0];
								ITKCALL(AOM_ask_value_string(curUserTag1,"user_name",&cusername));
								printf("\n current user Found Sucessfull ..!!!!!! : %s \n",cusername);fflush(stdout);

							}


							 if (QRY_find2("Control Objects...", &qryTagCntrl1))
									;
							if (qryTagCntrl1)
							{
								printf("\n Control Object Query Found111111111 \n");
								fflush(stdout);
								qry_valuesCntrl1[0] = "Abeyance";
								qry_valuesCntrl1[1] = "aplstd";
								qry_valuesCntrl1[2] = "0";

								tag_t abeyancetag	= NULLTAG;

								if (QRY_execute(qryTagCntrl1, abe_entryCntrl, qry_entryCntrl, qry_valuesCntrl1, &abeyance_control_number_found, &abeyance_cntrl_tags));
								printf("\n  control object found for abeyance  user : %d \n",abeyance_control_number_found);fflush(stdout);

								if (abeyance_control_number_found > 0)
								{
									abeyancetag=abeyance_cntrl_tags[0];

									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo1",&abyinfo1));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo2",&abyinfo2));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo3",&abyinfo3));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo4",&abyinfo4));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo5",&abyinfo5));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo6",&abyinfo6));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo7",&abyinfo7));
									ITKCALL(AOM_ask_value_string(abeyancetag,"t5_Userinfo8",&abyinfo8));
									printf("\n current user Found Sucessfull ..!!!!!! abyinfo1 : %s \n abyinfo2 : %s  \n abyinfo3: %s  \n abyinfo4: %s \n abyinfo5 : %s  \n abyinfo6: %s  \n abyinfo7: %s  \n abyinfo8: %s \n",abyinfo1 ,abyinfo2, abyinfo3, abyinfo4,abyinfo5 ,abyinfo6 ,abyinfo7 , abyinfo8 );fflush(stdout);

								}
								else
								{
									printf("\n no control object found for abeyance  user\n");fflush(stdout);
								}
									
							}
								
							char*	AplStdRemarks	= NULL;
							char*	AplStdRemarks1	= NULL;

							ITKCALL(AOM_ask_value_string(Taskrev,"t5_AplStdRemrks",&AplStdRemarks));
							ITKCALL(AOM_UIF_ask_value(Taskrev,"t5_AplStdRemrks",&AplStdRemarks1));
							printf("\n Task assignment t5_AplStdRemarks ----->%s :%s\n",AplStdRemarks,AplStdRemarks1); fflush(stdout);
							if ((AplStdRemarks != NULL)&&((tc_strcmp(AplStdRemarks,"")!=0)))
							{
								int iii	= 0;
								int cnt	= 0;
								int Tsknodcnt	= 0;
								tag_t*	WorkflowTasksTag1	= NULLTAG;
								tag_t	Assigner	= NULLTAG;
								tag_t	ToAssign	= NULLTAG;
								char*	AplStdobject_name	= NULL;
								char*	AplStdobjectAssignee	= NULL;
								char 	*assignee			= NULL;
								char 	*newuser			= NULL;

								printf("\n inside Task assignment type ----->\n"); fflush(stdout);
								ITKCALL(AOM_ask_value_tags(Taskrev,"fnd0ActuatedInteractiveTsks",&Tsknodcnt,&WorkflowTasksTag1));

								printf("\n inside Task assignment type ----->11 : %d\n",Tsknodcnt); fflush(stdout);
								for (cnt = 0; cnt < Tsknodcnt ; cnt++) //object_name
								{
									ITKCALL(AOM_ask_value_string(WorkflowTasksTag1[cnt],"object_name",&AplStdobject_name));
									printf("\n Task assignment type display value :%s ",AplStdobject_name);fflush(stdout);
									ITKCALL(AOM_UIF_ask_value(WorkflowTasksTag1[0],"fnd0Assignee",&AplStdobjectAssignee));
									printf("\n AplStdobjectAssignee user of task :%s : %s",AplStdobject_name,AplStdobjectAssignee);fflush(stdout);
									assignee = strtok( AplStdobjectAssignee, "(" );
									newuser	  = strtok ( NULL, ")" );
									printf("\n AplStdobjectAssignee : newuser user of task :%s : %s",assignee,newuser);fflush(stdout); //APLPlanner  : aplplanner
									if(SA_find_user2(AbyUser,&ToAssign));
									if(SA_find_user2(newuser,&Assigner));
									if((Assigner == NULLTAG)||(ToAssign == NULLTAG))
									{
										printf("\nUser not found\n");
										return 1;
									}

									break;

								}
								ITKCALL(AOM_UIF_ask_value(Taskrev,"fnd0ActuatedInteractiveTsks",&TaskAssignment));
								printf("\n Task assignment type display value :%s ",TaskAssignment);fflush(stdout);
								//if( (tc_strcmp(useragency,"APL")==0))
								//if( (tc_strcmp(default_group,"APL")==0))
								if (tc_strstr(default_group, "APL") != NULL)
								{
									printf("\n Task APL assignment type display value :%s ",AplStdobject_name);fflush(stdout);

									if ((tc_strcmp(AplStdobject_name,"Work On DML")==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo1)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo2)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo3)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo4)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo5)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo6)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo7)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo8)==0) ||
										(tc_strcmp(AplStdobject_name,"Assign Planner and Reviewer")==0) ||  // testing pending
										(tc_strcmp(AplStdobject_name,"Run BOM Check")==0))
									{
										printf("\n inside work on DML: %s \n" ,AplStdobject_name); fflush(stdout);

										int extUsrCnt = 0;
										int oldusrcount = 0;
										/*tag_t *OldParticipantRel = NULLTAG;
										tag_t OldParticipantRelTag = NULLTAG;
										tag_t OldObjTypTask = NULLTAG;
										tag_t new_participant_type = NULLTAG;
										tag_t new_participant_tag = NULLTAG;*/
										char Oldtype_namee_task[TCTYPE_name_size_c + 1];
										AnalystTag = NULLTAG;
										tag_t objTypeTag = NULLTAG;
										char *type_name;
										
										ITKCALL(TCTYPE_find_type("Analyst", "Analyst", &AnalystTag));
										ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
										printf("\n APL Task: Name venkat : %s \n", type_name);fflush(stdout);
										//ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner,useragency);
										ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner);
										//printf("\n Task is assigned as per :%s : %s \n", type_name,AbyUser);fflush(stdout);
										
										
									}
									else if (tc_strcmp(AplStdobject_name,"Review The Changes Done By APL Planner")==0)
									{
										AnalystTag = NULLTAG;
										char*	type_name = NULL;
										printf("\n inside Review The Changes Done By APL Planner: %s \n" ,AplStdobject_name); fflush(stdout);
										ITKCALL(TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &AnalystTag));
										ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
										printf("\n APL Task: Name venkat : %s \n", type_name);fflush(stdout);
										//ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner,useragency);
										ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner);
										printf("\n responsible party assignment is not updated \n", type_name);fflush(stdout);
										//printf("\n Task is assigned as per New userid :%s : %s \n", type_name,AbyUser);fflush(stdout);
										
									}
									else
									{
									
										printf("\n Task not assigned to abeyance user worklist %s \n" ,Task_Id); fflush(stdout);
									}
								}
								//if( (tc_strcmp(default_group,"STD")==0))
								if (tc_strstr(default_group, "STD") != NULL)
								{
									printf("\n Task STD assignment type display value :%s ",AplStdobject_name);fflush(stdout);
									if ((tc_strcmp(AplStdobject_name,"Create EPA")==0)||
									 (tc_strcmp(AplStdobject_name,abyinfo1)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo2)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo3)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo4)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo5)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo6)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo7)==0) ||
									 (tc_strcmp(AplStdobject_name,abyinfo8)==0) )
									{
										printf("\n inside work on DML STD: %s \n" ,AplStdobject_name); fflush(stdout);
										int extUsrCnt = 0;
										int oldusrcount = 0;
										/*tag_t *OldParticipantRel = NULLTAG;
										tag_t OldParticipantRelTag = NULLTAG;
										tag_t OldObjTypTask = NULLTAG;
										
										tag_t new_participant_type = NULLTAG;
										tag_t new_participant_tag = NULLTAG;*/

										char Oldtype_namee_task[TCTYPE_name_size_c + 1];

										AnalystTag = NULLTAG;
										tag_t objTypeTag = NULLTAG;

										char *type_name;
										ITKCALL(TCTYPE_find_type("Analyst", "Analyst", &AnalystTag));
										ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
										printf("\n STD Task: Name venkat : %s \n", type_name);fflush(stdout);
										ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner);
										//printf("\n Task is assigned as per New Userid :%s : %s \n", type_name,AbyUser);fflush(stdout);
									}
									else if (tc_strcmp(AplStdobject_name,"Review the Changes")==0)
									{
										 AnalystTag = NULLTAG;
										 char*	type_name = NULL;
										printf("\n inside Review the Changes the ReAssignedAbeyaser fuction not called: %s \n" ,AplStdobject_name); fflush(stdout);

										ITKCALL(TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &AnalystTag));

										ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
										printf("\n APL Task: Name venkat : %s \n", type_name);fflush(stdout);
										
										ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner);
										//ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner,useragency);
										//printf("\n Task is assigned as per :%s : %s \n", type_name,AbyUser);fflush(stdout);
									}
									else
									{
										printf("\n Task not assigned to abeyance user worklist %s \n" ,Task_Id); fflush(stdout);
									}
								}
								else{

									printf("\ninside else condition :  \n" );fflush(stdout);
								
									if ((tc_strcmp(AplStdobject_name,"Create EPA")==0) )
									{
										printf("\n inside work on DML STD: %s \n" ,AplStdobject_name); fflush(stdout);
										int extUsrCnt = 0;
										int oldusrcount = 0;
										tag_t *OldParticipantRel = NULLTAG;
										tag_t OldParticipantRelTag = NULLTAG;
										tag_t OldObjTypTask = NULLTAG;
										
										tag_t new_participant_type = NULLTAG;
										tag_t new_participant_tag = NULLTAG;

										char Oldtype_namee_task[TCTYPE_name_size_c + 1];

										AnalystTag = NULLTAG;
										tag_t objTypeTag = NULLTAG;

										char *type_name;
										ITKCALL(TCTYPE_find_type("Analyst", "Analyst", &AnalystTag));
										ITKCALL (TCTYPE_ask_name2(AnalystTag, &type_name));
										printf("\n STD Task: Name venkat : %s \n", type_name);fflush(stdout);
										ReAssignedAbeyaser(Taskrev,AnalystTag,ToAssign,Assigner);
										//printf("\n Task is assigned as per New Userid :%s : %s \n", type_name,AbyUser);fflush(stdout);
									}
								}
							}
							else
							{
								printf("\n Task assignment t5_AplStdRemarks is null");
								
							}
						}
					//}
				}
			}
		}
	}
	return ifail ;
}
int abeyanceuser(void *return_data)
{
	int ifail	= 0; 
	printf("\n Before start the coding start  here abeyanceuser");fflush(stdout);
	char 			*selectedTask		=  NULL;
	char 			*user				=  NULL;
	int n_tags_found					=  0;
    tag_t* tags_found 					=  NULL;
	int retValueType					= 0;
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	const char *attrs[1];
    const char *values[1];
	//printf("\n I am in venkat main ITK program");fflush(stdout);
	USERARG_get_string_argument(&selectedTask);
	USERARG_get_string_argument(&user);	
	printf("\n we are in venkat main ITK program of selectedTask :: %s  :%s : ",user,selectedTask );fflush(stdout);
	char *args[100 / 2 + 1];
	char * token	 = NULL;
	char * token1	 = NULL;
	token=(char *) MEM_alloc(1000);
	int i = 0 ;


	int		Errorcount		= 0;
	int		arrycnt			= 0;
	char*  currecttaskid	= NULL;
	char**  SetErr	= NULL;
	SetErr = (char**)MEM_alloc( 1 * sizeof *SetErr );

	token = strtok(selectedTask," ;");
	while (token !=NULL)
	{
		arrycnt++;
		args[i++] = token;
		printf("\n Current task number :%d :%s \n",i,token);fflush(stdout);
		token = strtok(NULL, "; ");
	}
	printf(" array Size  : %d\n" ,arrycnt);fflush(stdout);
	for (i = 0; i < arrycnt; i++) 
	{
			printf(" array vules : %s\n" ,args[i]);fflush(stdout);
			attrs[0]	= NULL;
			values[0] = NULL;
			currecttaskid	=	NULL;
			currecttaskid	= args[i];

			printf(" array vules1111111111 :%d : %s\n" ,i,currecttaskid);fflush(stdout);
			if (currecttaskid != NULL)
			{
				printf(" array vules1 :%d : %s\n" ,i,currecttaskid);fflush(stdout);
				attrs[0] ="item_id";
				values[0] =currecttaskid ;
				ITKCALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

				printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);

				ReportAbeyaserAssign(user,currecttaskid,n_tags_found ,tags_found);
				//ReportAbeyaserAssign(user,selectedTask,n_tags_found ,tags_found,&SetErr,&icount);



			}
	}
	tag_t * docn_best = (tag_t *) MEM_alloc (1 * sizeof (tag_t));
	int n_docn_best = 1;
	USERSERVICE_array_t arrayStruct;
	docn_best=NULLTAG;

	ifail = USERSERVICE_return_tag_array(docn_best, n_docn_best, &arrayStruct);
	printf("\nAbeyance user assigned sucessfully=%d",arrayStruct.length);fflush(stdout);

	if (arrayStruct.length != 0)
	{
	*((USERSERVICE_array_t*) return_data) = arrayStruct;	
	}

	printf("\nAbeyance user assigned sucessfully*******");fflush(stdout);
return ifail;
}
extern int tm_abeyanceusercalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 2;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE; // Task Number
	inputArgTypes[1] = USERARG_STRING_TYPE; //user name
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n tm_abeyanceusercalling before....");fflush(stdout);  
	ifail=USERSERVICE_register_method("abeyanceuser",(USER_function_t)abeyanceuser,nargs,inputArgTypes,retValueType);
	
	return ifail;
}

extern DLLAPI int tm_abeyanceuser_register_callbacks ()
{	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_abeyanceuser");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_abeyanceuser", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_abeyanceusercalling);
	printf("\n After registering userservice....tm_abeyanceuser");fflush(stdout);
	return(ITK_ok);
}