/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : EPADetailReport.c
* Created By                   : Sneha Modak
* Created On                   : 10/10/2018
* Project                      : TML
* Description                  : On TMML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
	#include <cfm/cfm.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	//#include <tc/iman.h>
	//#include <tccore/imantype.h>
	//#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	//#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	//#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	//#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	//#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>
	#include <tccore/aom_prop.h>
	
	
	#include <bom/bom.h>
	#include <tc/folder.h>
	#include <pom/pom/pom.h>
	#include <tc/tc_macros.h>
	//#include <bom/bom_attr.h>
	#include <pie/pie.h>
	#include <user_exits/epm_toolkit_utils.h>
		#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"


#define MAX_LINE_LEN 1024
#define GRM_create_msg "GRM_create"   1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

		int 			TotalAffectedGrp					= 0;
		int 			TotalResltparts					= 0;
		int 			TotalAddparts					= 0;
		int 			TotalDelparts					= 0;
		int 			TotalQtychngparts				= 0;
		
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}



	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text (stat, &err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
	
		typedef struct delta_bom
	{
		int count;
		char **uidlist;
		int *status;
		
		
	}Delta_Bom;
	
int EPAMBPAExclusiveReport_func(char*,char*,char*,char*,char*,char*,char***,int*);
int EPAMBPAExclusiveReport_func_Signoff(char*,char*,char*,char***,int*);
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;

void  getAllPlantDetails( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if((strcmp(PlantName,"APLJ")==0))
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}

void tm_fnd_Prev_Official_Revision_Part(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	
	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;
					
				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}
	
	void getIndex(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=-1;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=k;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}

void getStrByIndex(char **view_list,int count,int idx,char **str)
{

		printf("\n **getStrByIndex");fflush(stdout);
		
		*str =view_list[idx];
	 
		


}
	
	void setAddStrInEPAReport(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrInEPAReport character found===%s",(*strset)[*count-1]);fflush(stdout);



	}



	
	
	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
	{

	*count=*count+1;
	if(*count==1)
	{
	printf("\n ****setAddTAG1");fflush(stdout);
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG2");fflush(stdout);
	}
	else
	{
	printf("\n **setAddTAG3");fflush(stdout);
	(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG4");fflush(stdout);
	printf("\n **serTAG6");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




	}
	
void setAddInt(int *count,int **objlist,int obj )
        {

        *count=*count+1;
        if(*count==1)
        {
        printf("\n ****setAddTAG1");fflush(stdout);
        (*objlist) = (int *)malloc((*count ) * sizeof(int ));
        printf("\n ***setAddTAG2");fflush(stdout);
        }
        else
        {
        printf("\n **setAddTAG3");fflush(stdout);
        (*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
        printf("\n ***setAddTAG4");fflush(stdout);
        printf("\n **serTAG6");fflush(stdout);
        }

        (*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




        }

void setFindStr(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=0;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=1;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}



static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}
/****************************************************************************/
/* Function Name    : FU_dumpItkErrors                                      */
/*                                                                          */
/* Called From      : ITK                                                   */
/*                                                                          */
/* Input Parms      : int stat                                              */
/*                    const char * prog_name                                */
/*                    int line_number                                       */
/*                    const char * file_name                                */
/*                                                                          */
/* Output Parms     : None                                                  */
/*                                                                          */
/* Functions called : None                                                  */
/*                                                                          */
/* File Description : Called by the ITK macro to log errors                 */
/*                                                                          */
/* Return Value     : Void                                                  */

/**********************************************************************/


/* Start of my implementation of createItem */
int EPAMBPAExclusiveReport( void *retValue )
//int AplDmlReleaseBetweenDates( void *retValue )
{
	
	int ifail = ITK_ok;
	logical found;
	char *dmlNumber	= NULL;
	char *Datefrom =NULL;
	char *Dateto =NULL;
	char *Agency=NULL;//Agency received from Front End(changed 07July 2018)......
	char *Plant=NULL;
	
	char *Type=NULL;
	char *Class=NULL;
	char *Flag=NULL;
	//char *PlantDup=NULL;
	char *Project_code=NULL;
	tag_t owner=NULLTAG;
	char *Owner_Name=NULL;
	
	char** bufferedXmlStrOut;
	int buff_cnt=0;
	tag_t dmlObject=NULLTAG;
	char* objectTypeStr = NULL;
	tag_t	query		= NULLTAG;
	
	FILE * DmlRelFile=NULL;
	tag_t		filetag = NULLTAG;
	IMF_file_t	fileDescriptor;
	tag_t		datasettype = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	char ReportGeneration_str[26] = {'\0'};
	char PlantDup[10]={'\0'};
	int count=0;
	int Dmlcount=0;//Added on 22nd June 2018
	tag_t *DmlList = NULLTAG;
	const char*    find_Dml_Number=NULL;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;	
	
	/**Commenting for Test ***/
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Agency);
	USERARG_get_string_argument(&Plant);
	USERARG_get_string_argument(&Type);
	USERARG_get_string_argument(&Class);
	USERARG_get_string_argument(&Flag);

	printf("Argument Received(EPAMBPAExclusiveReport) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received(EPAMBPAExclusiveReport) =%s\n",Dateto);fflush(stdout);
	printf("Agency Received=%s\n",Agency);fflush(stdout);
	printf("Plant Received=%s\n",Plant);fflush(stdout);	
	printf("Plant Received=%s\n",Type);fflush(stdout);
	printf("Plant Received=%s\n",Class);fflush(stdout);
	printf("Flag Value Received =%s\n",Flag);fflush(stdout);
	
	printf("After returning Value\n");fflush(stdout);
	
		
		
		//Calling Function to get EPA Details............
		
		   if(tc_strcmp(Flag,"0")==0)
		  {
			  CALLAPI(EPAMBPAExclusiveReport_func(Datefrom,Dateto,Agency,Plant,Type,Class,&bufferedXmlStrOut,&buff_cnt));
		  }else if(tc_strcmp(Flag,"1")==0)
		  {
			 CALLAPI(EPAMBPAExclusiveReport_func_Signoff(Datefrom,Dateto,Plant,&bufferedXmlStrOut,&buff_cnt));  
		  }
		
		//CALLAPI(EPAMBPAExclusiveReport_func(Datefrom,Dateto,Agency,Plant,Type,Class,&bufferedXmlStrOut,&buff_cnt));
		
		
	
	//Calling a Query Builder........
		
			int m =0;
			printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
			array_size = buff_cnt;
			string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
			for(m=0;m<buff_cnt;m++)
			{
				printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
				string_array[m] = bufferedXmlStrOut[m];
			}
			
				printf("\nBefore returning Value\n");fflush(stdout);
	
				ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

				//if (array_struct.length != 0)
				//*((USERSERVICE_array_t*) retValue) = array_struct;

             if (array_struct.length != 0)
				*((USERSERVICE_array_t*) retValue) = array_struct;	
					
	
	
	return ifail;
	
	
}


int EPAMBPAExclusiveReport_func(char* Datefrom,char*Dateto,char*Agency,char* Plant,char* Type,char* Class,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
		char **qry_entries3 = (char **) MEM_alloc(10 * sizeof(char *));
		char **qry_values3 = (char **) MEM_alloc(10 * sizeof(char *));
		tag_t	query		= NULLTAG;
		int ifail = ITK_ok;
		char * Epa_Number = NULL;
		char * Epa_NumberDup = NULL;
		char * Epa_Number_creation_date = NULL;
		char * Epa_Description = NULL;
		char * Epa_Descriptiondup = NULL;
		char * Epa_Class = NULL;
		char * Epa_Classdup = NULL;
		char * Epa_ClassDate = NULL;
		char * Epa_Validity = NULL;
		char * Epa_Validitydup = NULL;
		char * Epa_Aggregate = NULL;
		char *DMLEPAStampedDt=NULL;
		char *EPA_Subject=NULL;
		char *EPA_folloup_Ind=NULL;
		char *EPA_folloup_Inddup=NULL;
		char *EPAPPMRemarks=NULL;
		char *EPAPPMRemarksdup=NULL;
		char *VDREmarks=NULL;
		char *VDREmarksdup=NULL;
		char *CQRemarks=NULL;
		char *CQRemarksdup=NULL;
		char *VQRemarks=NULL;
		char *VQRemarksdup=NULL;
		char *MBPARemarks=NULL;
		char *TSRemarks=NULL;
		char *TSRemarksdup=NULL;
		char *LogisticRemarks=NULL;
		char *LogisticRemarksdup=NULL;
		char *MATRemarks=NULL;
		char *MATRemarksdup=NULL;
		char *CostReduction=NULL;
		char *CostReductiondup=NULL;
		char *FollowupReq=NULL;
		char *FollowupReqdup=NULL;
		char *MBPARemarksdup=NULL;
		char *DMLEPAStampedDtdup=NULL;
		char *EPA_Subjectdup=NULL;
		char * Epa_Aggregatedup = NULL;
		char *translated_PLant=NULL;
		char ReportFiredDate[26] = {'\0'};
		char ReportFiredDatestr[26] = {'\0'};
		//char *Plant=NULL;
		int	n_found		= 0;
		int k;
		tag_t *t_item1	= NULLTAG;
		int	taskcount= 0;
		tag_t *taskList = NULLTAG;
		time_t now;
		struct tm* now_tm;
		char *tokenized_from_Datestr=NULL;
		char *tokenized_to_Datestr=NULL;
		char *PlantNamestr=NULL;
		char *Agencystr=NULL;
		char *AgencystrDup=NULL;
		char *ActionagencyVar=NULL;
		char *Typestr=NULL;
		char *serial_num=NULL;
		char *Epa_Numberstr=NULL;
		char *Epa_CreationDatestr=NULL;
		char *RfEPAVal=NULL;
		char *Epa_Descriptionstr=NULL;
		char *Epa_Classstr=NULL;
		char *Epa_Validitystr=NULL;
		char *Epa_Aggregatestr=NULL;
		char *DML_number_EPAstr=NULL;
		char *DMLEPAcreationDatestr=NULL;
		char *DMLEPAStampedDtstr=NULL;
		char *EPA_Subjectstr=NULL;
		char *EPA_FollowupIndstr=NULL;
		char *EPAPPMRemarkstr=NULL;
		char *VDREmarksstr=NULL;
		char *CQRemarksstr=NULL;
		char *VQRemarksstr=NULL;
		char *MBPARemarksstr=NULL;
		char *TSRemarksstr=NULL;
		char *MATRemarksstr=NULL;
		char *LogisticRemarksstr=NULL;
		char *CostReductionstr=NULL;
		char *FollowupReqstr=NULL;
		char *ReportFiredonstr=NULL;
		char *HeadingstrExcl=NULL;
		char *ReportFiredTostr=NULL;
		char *ReportFiredfromstr=NULL;
		char *ReportFiredPLantstr=NULL;
		char *ReportFiredAgencystr=NULL;
		char *ReportFiredTypestr=NULL;
		char *SrlNumstr=NULL;
		char *RfEpaStr=NULL;
		char *EpaNumstr=NULL;
		char *EpaCreStr=NULL;
		char *DMLNumstr=NULL;
		char *DMLCreStr=NULL;
		char *DMLStampStr=NULL;
		char *ValidityStr=NULL;
		char *EpaSynopsisstr=NULL;
		char *EpaSubjectStr=NULL;
		char *EpaClass=NULL;
		char *EpaClassDate=NULL;
		char *ActionAgencyStr=NULL;
		char *CurrentUserId=NULL;
		char *WorkLocuser=NULL;
		tokenized_from_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
		tokenized_to_Datestr=(char *) MEM_alloc( 10 * sizeof(char) );
		PlantNamestr=(char *) MEM_alloc( 10 * sizeof(char) );
		Agencystr=(char *) MEM_alloc( 10 * sizeof(char) );
		Typestr=(char *) MEM_alloc( 10 * sizeof(char) );
		serial_num=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_Numberstr=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_Descriptionstr=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_Classstr=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_Validitystr=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_Aggregatestr=(char *) MEM_alloc( 10 * sizeof(char) );
		DML_number_EPAstr=(char *) MEM_alloc( 10 * sizeof(char) );
		DMLEPAStampedDtstr=(char *) MEM_alloc( 10 * sizeof(char) );
		EPA_Subjectstr=(char *) MEM_alloc( 10 * sizeof(char) );
		EPA_FollowupIndstr=(char *) MEM_alloc( 10 * sizeof(char) );
		EPAPPMRemarkstr=(char *) MEM_alloc( 10 * sizeof(char) );
		CQRemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		VQRemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		CostReductionstr=(char *) MEM_alloc( 10 * sizeof(char) );
		FollowupReqstr=(char *) MEM_alloc( 10 * sizeof(char) );
		VDREmarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		MBPARemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		TSRemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		LogisticRemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		MATRemarksstr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredonstr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredTostr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredPLantstr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredAgencystr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredTypestr=(char *) MEM_alloc( 10 * sizeof(char) );
		ReportFiredfromstr=(char *) MEM_alloc( 10 * sizeof(char) );
		HeadingstrExcl=(char *) MEM_alloc( 10 * sizeof(char) );
		SrlNumstr=(char *) MEM_alloc( 10 * sizeof(char) );
		RfEpaStr=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaNumstr=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaCreStr=(char *) MEM_alloc( 10 * sizeof(char) );
		DMLNumstr=(char *) MEM_alloc( 10 * sizeof(char) );
		DMLCreStr=(char *) MEM_alloc( 10 * sizeof(char) );
		DMLStampStr=(char *) MEM_alloc( 10 * sizeof(char) );
		ValidityStr=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaSynopsisstr=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaSubjectStr=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaClass=(char *) MEM_alloc( 10 * sizeof(char) );
		EpaClassDate=(char *) MEM_alloc( 10 * sizeof(char) );
		ActionAgencyStr=(char *) MEM_alloc( 10 * sizeof(char) );
		CurrentUserId=(char *) MEM_alloc( 10 * sizeof(char) );
		WorkLocuser=(char *) MEM_alloc( 10 * sizeof(char) );
		RfEPAVal=(char *) MEM_alloc( 10 * sizeof(char) );
		Epa_CreationDatestr=(char *) MEM_alloc( 10 * sizeof(char) );
		DMLEPAcreationDatestr=(char *) MEM_alloc( 10 * sizeof(char) );
		
		printf("Argument Received(EPAMBPAExclusiveReport) inside Function=%s\n",Datefrom);fflush(stdout);
		printf("Argument Received(EPAMBPAExclusiveReport) inside Function =%s\n",Dateto);fflush(stdout);
		printf("Agency Received inside Function =%s\n",Agency);fflush(stdout);
		printf("Plant Received inside Function =%s\n",Plant);fflush(stdout);	
		printf("Plant Received inside Function =%s\n",Type);fflush(stdout);
		printf("Plant Received inside Function =%s\n",Class);fflush(stdout);
	
		if(tc_strcmp(Plant,"CVBU JSR")==0)
		{
			tc_strdup("PlantName8",&translated_PLant);	
		}else if(tc_strcmp(Plant,"CAR")==0)
		{
			tc_strdup("PlantName1",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU LKO")==0)
		{
			tc_strdup("PlantName9",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU PNR")==0)
		{
			tc_strdup("PlantName2",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU PUNE")==0)
		{
			tc_strdup("PlantName3",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU")==0)
		{
			tc_strdup("PlantName4",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU and CVBU")==0)
		{
			tc_strdup("PlantName5",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU LKO")==0)
		{
			tc_strdup("PlantName10",&translated_PLant);
		}else if(tc_strcmp(Plant,"SMALLCAR AHD")==0)
		{
			tc_strdup("PlantName6",&translated_PLant);
		}else if(tc_strcmp(Plant,"SMALLCAR PNR")==0)
		{
			tc_strdup("PlantName7",&translated_PLant);
		}else if(tc_strcmp(Plant,"DHARWAD")==0)
		{
			tc_strdup("PlantName11",&translated_PLant);
		}else if(tc_strcmp(Plant,"TMLDL JSR")==0)
		{
			tc_strdup("PlantName12",&translated_PLant);
		}
		
			time(&now);
			now_tm = localtime(&now);
		
			strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
			printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);
		
			
			//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
			
			printf("Check 2\n");fflush(stdout);
			
			//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"<EPAMBPAExclusiveReport>");
			
			//sprintf(ReportFiredDatestr,"<ReportFiredDate>%s</ReportFiredDate>",ReportFiredDate);
			
			sprintf(HeadingstrExcl,",%s\n","****************************EPA EXCLUSIVE REPORT****************************");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,HeadingstrExcl);
			
			sprintf(ReportFiredonstr,",%s","REPORT FIRED ON :");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredonstr);
			
			sprintf(ReportFiredDatestr,",%s\n",ReportFiredDate);
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredDatestr);
			printf("Check 3\n");fflush(stdout);
			
			//sprintf(tokenized_from_Datestr,"<fromDate>%s</fromDate>",Datefrom);
			
			sprintf(ReportFiredfromstr,",%s","FROM DATE :");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredfromstr);
			
			sprintf(tokenized_from_Datestr,",%s\n",Datefrom);
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,tokenized_from_Datestr);
					
			//sprintf(tokenized_to_Datestr,"<ToDate>%s</ToDate>",Dateto);
			
			sprintf(ReportFiredTostr,",%s","TO DATE :");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredTostr);
			
			sprintf(tokenized_to_Datestr,",%s\n",Dateto);
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,tokenized_to_Datestr);
			
			//sprintf(PlantNamestr,"<PlantName>%s</PlantName>",Plant);
			
			sprintf(ReportFiredPLantstr,",%s","StrPlntName");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredPLantstr);
			
			sprintf(PlantNamestr,",%s\n",Plant);
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,PlantNamestr);
			
			//sprintf(Agencystr,"<Agency>%s</Agency>",Agency);
			
			sprintf(ReportFiredAgencystr,",%s","Action Agency   :");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredAgencystr);
			
			sprintf(Agencystr,",%s\n",Agency);
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Agencystr);
			
			//sprintf(Typestr,"<EPA Type>%s</EPA Type>",Type);
			
			sprintf(ReportFiredTypestr,",%s","EPA Type   ::    ");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ReportFiredTypestr);
			
			
			sprintf(Typestr,",%s\n\n",Type);
			
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Typestr);
			
			sprintf(SrlNumstr,"%s","Srl");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,SrlNumstr);
			
			sprintf(RfEpaStr,",%s"," RfEPA ");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,RfEpaStr);
			
			sprintf(EpaNumstr,",%s","EPA No");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaNumstr);
			
			sprintf(EpaCreStr,",%s","EPA Creation Date");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaCreStr);
			
			sprintf(DMLNumstr,",%s","DML No");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DMLNumstr);
			
			sprintf(DMLCreStr,",%s","DML Creation Date");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DMLCreStr);
			
			sprintf(DMLStampStr,",%s","DML EPA Stamped Dt");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DMLStampStr);
			
			sprintf(ValidityStr,",%s","Validity");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ValidityStr);
			
			sprintf(EpaSynopsisstr,",%s","EPA Synopsis ");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaSynopsisstr);
			
			sprintf(EpaSubjectStr,",%s","EPA Subject");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaSubjectStr);
			
			sprintf(EpaClass,",%s","EPA Class");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaClass);
			
			sprintf(EpaClassDate,",%s","EPA CLass Date");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EpaClassDate);
			
			sprintf(ActionAgencyStr,",%s","Action Agency");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,ActionAgencyStr);
			
			sprintf(CurrentUserId,",%s","Current User ID");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,CurrentUserId);
			
			sprintf(WorkLocuser,",%s\n\n","StrWrkLoc of User");
			
			setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,WorkLocuser);
	
		qry_entries3[0] = "creation_date before";
		qry_entries3[1] = "creation_date after";
		qry_entries3[2] = "Plant";

		qry_values3[0]=Datefrom;
		qry_values3[1]=Dateto;
		qry_values3[2]=translated_PLant;
		
		CALLAPI(QRY_find2("EPA Query based on PLant", &query));
		CALLAPI(QRY_execute(query, 3, qry_entries3, qry_values3, &n_found, &t_item1));
		
		if(n_found>0)
		{
			
			if(Agencystr!=NULL)
			{
				tc_strdup(Agencystr,&AgencystrDup);
				
				if(tc_strcmp(AgencystrDup,"TS")==0)
				{
				  tc_strdup("Update MEPA[TS]",&ActionagencyVar);	
				}else if((AgencystrDup,"Logistics")==0)
				{
					tc_strdup("Update MEPA[Logistics]",&ActionagencyVar);
				}else if((AgencystrDup,"VD")==0)
				{
				  tc_strdup("Update MEPA[VD]",&ActionagencyVar);	
				}else if((AgencystrDup,"AQ")==0)
				{
					tc_strdup("Update MEPA AQ",&ActionagencyVar);
				}else if((AgencystrDup,"STDS")==0)
				{
					tc_strdup("Update MEPA STDS",&ActionagencyVar);
				}else if((AgencystrDup,"VQA")==0)
				{
				   tc_strdup("Update MEPA[VQA]",&ActionagencyVar);	
				}else if((AgencystrDup,"SCM")==0)
				{
					tc_strdup("Update MEPA[SCM]",&ActionagencyVar);	
				}else if((AgencystrDup,"PPM")==0)
				{
					tc_strdup("Update MEPA (PPM)",&ActionagencyVar);
				}else if((AgencystrDup,"CQ")==0)
				{
					tc_strdup("Confirm Introduction On Vehicle",&ActionagencyVar);
				}else if((AgencystrDup,"QA")==0)
				{
					tc_strdup("Create MBPA",&ActionagencyVar);
				}else if((AgencystrDup,"MFG")==0)
				{
					 tc_strdup("Close MEPA",&ActionagencyVar);
				}else if((AgencystrDup,"QACQ")==0)
				{
					 tc_strdup("Update MEPA (QACQ)",&ActionagencyVar);
				}else if((AgencystrDup,"ALL")==0)
				{
					//To write a Query Builder......
					
					//To Check For Work Desc using Sig State........
					
					
				}else
				{
					
					
				}
				
				
			}
			
			
			
			//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"<Header_Column>");
			
			printf("Object Found through Query Builder.......\n");fflush(stdout);
			for(k=0;k<n_found;k++)
			{
				
				//sprintf(serial_num,"<SrNo>%d</SrNo>",(k+1));
				
				sprintf(serial_num,"%d",(k+1));
				
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,serial_num);
				
				
				sprintf(RfEPAVal,",%s","");
				
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,RfEPAVal);
				
					
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"item_id", &Epa_Number));
				if(Epa_Number!=NULL)
				{
					tc_strdup(Epa_Number,&Epa_NumberDup);
					
					//sprintf(Epa_Numberstr,"<EPA Number>%s</EPA Number>",Epa_NumberDup);
					
					sprintf(Epa_Numberstr,",%s",Epa_NumberDup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_Numberstr);
				}	
				 
				printf("Epa Number Obtained=%s\n",Epa_NumberDup);fflush(stdout);
				
				//CALLAPI(AOM_ask_value_date(t_item1[k] ,"creation_date", &Epa_Number_creation_date));
				//printf("Epa Creation Date Obtained=%s\n",Epa_Number_creation_date);fflush(stdout);
				
				sprintf(Epa_CreationDatestr,",%s","");
				
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_CreationDatestr);
				
				
				
				CALLAPI(AOM_ask_value_tags(t_item1[k],"T5_DMLTaskRelation",&taskcount,&taskList));
				printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
				
				if(taskcount>0)
				{
					int i;
					for(i=0;i<taskcount;i++)
					{
						char* task_name=NULL;
						char* task_namedup=NULL;
						char* EPA_number_EPA=NULL;
						char* DML_number_EPA=NULL;
						char* DML_number_EPAdup=NULL;
						tag_t task=taskList[i];
						CALLAPI(AOM_ask_value_string(taskList[i] ,"item_id",&task_name));
						printf("Task Name found =%s\n",task_name);fflush(stdout);
						tc_strdup(task_name,&task_namedup);
						EPA_number_EPA=tc_strtok(task_namedup,"_");
						DML_number_EPA=tc_strtok(NULL,"_");
						
						 if(DML_number_EPA!=NULL)
						 {
							 tc_strdup(DML_number_EPA,&DML_number_EPAdup); 
							 
							
							//sprintf(DML_number_EPAstr,"<EPA DML Number>%s</EPA DML Number>",DML_number_EPAdup);
							
							sprintf(DML_number_EPAstr,",%s",DML_number_EPAdup);
							
							setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DML_number_EPAstr);
							
							//Need to get creation Date from APLDML Revision Class........
							
							sprintf(DMLEPAcreationDatestr,",%s","");
							
							setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DMLEPAcreationDatestr);
							
							
							
							
							 
						 }	 
						printf("DML Number obtained from EPA Number=%s\n",DML_number_EPAdup);fflush(stdout);
					}
				}
				
				CALLAPI(AOM_UIF_ask_value(t_item1[k] ,"t5_EpaTskCrDate", &DMLEPAStampedDt));
			   
			   if(DMLEPAStampedDt!=NULL)
			   {
				   tc_strdup(DMLEPAStampedDt,&DMLEPAStampedDtdup);
				   
				   //sprintf(DMLEPAStampedDtstr,"<DML EPA Stamped Date>%s</DML EPA Stamped Date>",DMLEPAStampedDtdup);
				   
				   sprintf(DMLEPAStampedDtstr,",%s",DMLEPAStampedDtdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,DMLEPAStampedDtstr);
				   
			   }
			   
			   printf("t5_EpaTskCrDate found=%s\n",DMLEPAStampedDtdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_EpaValidity", &Epa_Validity));
			   
			   if(Epa_Validity!=NULL)
			   {
				   tc_strdup(Epa_Validity,&Epa_Validitydup);
				   
				   //sprintf(Epa_Validitystr,"<EPA Validity>%s</EPA Validity>",Epa_Validitydup);
				   
				   sprintf(Epa_Validitystr,",%s",Epa_Validitydup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_Validitystr);
			   }   
			   printf("Validity of EPA found=%s\n",Epa_Validitydup);fflush(stdout);
			   
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"object_desc", &Epa_Description));
				if(Epa_Description!=NULL)
				{
					tc_strdup(Epa_Description,&Epa_Descriptiondup);
					
					//sprintf(Epa_Descriptionstr,"<EPA Description>%s</EPA Description>",Epa_Descriptiondup);
					
					sprintf(Epa_Descriptionstr,",%s",Epa_Descriptiondup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_Descriptionstr);
					
				}	
			   printf("Epa Description Obtained=%s\n",Epa_Descriptiondup);fflush(stdout);
			   
			   CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_tx0Addressee", &EPA_Subject));
				if(EPA_Subject!=NULL)
				{
					tc_strdup(EPA_Subject,&EPA_Subjectdup);
					//sprintf(EPA_Subjectstr,"<EPA subject>%s</EPA subject>",EPA_Subjectdup);
					
					sprintf(EPA_Subjectstr,",%s",EPA_Subjectdup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EPA_Subjectstr);
					
				}
				
				printf("EPA Subject found=%s\n",EPA_Subjectdup);fflush(stdout);
			   
			   CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_EpaClass", &Epa_Class));
			   if(Epa_Class!=NULL)
			   {
				   tc_strdup(Epa_Class,&Epa_Classdup);
				   
					//sprintf(Epa_Classstr,"<EPA Class>%s</EPA Class>",Epa_Classdup);
					
					sprintf(Epa_Classstr,",%s",Epa_Classdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_Classstr);
				   
			   }   
			   printf("Epa Class found=%s\n",Epa_Classdup);fflush(stdout);
			   //CALLAPI(AOM_UIF_ask_value(t_item1[k] ,"t5_EpaClassDate", &Epa_ClassDate));///Need to check...
			   //printf("Epa Class Date found=%s\n",Epa_ClassDate);fflush(stdout);
			   
			   
			   
			   CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_tcfAggregate", &Epa_Aggregate));
			   
			   if(Epa_Aggregate!=NULL)
			   {
				   tc_strdup(Epa_Aggregate,&Epa_Aggregatedup);
				   
				   //sprintf(Epa_Aggregatestr,"<EPA Aggregate>%s</EPA Aggregate>",Epa_Aggregatedup);
				   
				   sprintf(Epa_Aggregatestr,",%s",Epa_Aggregatedup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,Epa_Aggregatestr);
				   
			   }   
			   printf("Aggregate of EPA found=%s\n",Epa_Aggregatedup);fflush(stdout);
			   
			   
			   
			    
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_EpaFolUpInd", &EPA_folloup_Ind));
				if(EPA_folloup_Ind!=NULL)
				{
					tc_strdup(EPA_folloup_Ind,&EPA_folloup_Inddup);
					
					//sprintf(EPA_FollowupIndstr,"<EPA Follow up Indicator>%s</EPA Follow up Indicator>",EPA_folloup_Inddup);
					
					sprintf(EPA_FollowupIndstr,",%s",EPA_folloup_Inddup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EPA_FollowupIndstr);
					
				}
				
				printf("Foolow Up Indicator found=%s\n",EPA_folloup_Inddup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_PPMRemarks", &EPAPPMRemarks));
				if(EPAPPMRemarks!=NULL)
				{
				
					tc_strdup(EPAPPMRemarks,&EPAPPMRemarksdup);
					//sprintf(EPAPPMRemarkstr,"<EPA PPM Remarks>%s</EPA PPM Remarks>",EPAPPMRemarksdup);
					
					sprintf(EPAPPMRemarkstr,",%s",EPAPPMRemarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,EPA_FollowupIndstr);
				}
				
				printf("t5_PPM Remarks found=%s\n",EPAPPMRemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_VDRemarks", &VDREmarks));
				if(VDREmarks!=NULL)
				{
					tc_strdup(VDREmarks,&VDREmarksdup);
					//sprintf(VDREmarksstr,"<VD Remarks>%s</VD Remarks>",VDREmarksdup);
					
					sprintf(VDREmarksstr,",%s",VDREmarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,VDREmarksstr);
					
				}
				printf("t5_VDRemarks found=%s\n",VDREmarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_CQRemarks", &CQRemarks));
				if(CQRemarks!=NULL)
				{
					tc_strdup(CQRemarks,&CQRemarksdup);
					//sprintf(CQRemarksstr,"<CQ Remarks>%s</CQ Remarks>",CQRemarksdup);
					
					sprintf(CQRemarksstr,",%s",CQRemarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,CQRemarksstr);
					
				}
				
				printf("t5_CQRemarks found=%s\n",CQRemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_VQARemarks", &VQRemarks));
				if(VQRemarks!=NULL)
				{
					tc_strdup(VQRemarks,&VQRemarksdup);
					//sprintf(VQRemarksstr,"<VQA Remarks>%s</VQA Remarks>",VQRemarksdup);
					
					sprintf(VQRemarksstr,",%s",VQRemarksdup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,VQRemarksstr);
					
				}
				
				printf("t5_VQARemarks found=%s\n",VQRemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_MBPARemarks", &MBPARemarks));
				if(MBPARemarks!=NULL)
				{
					tc_strdup(MBPARemarks,&MBPARemarksdup);
					//sprintf(MBPARemarksstr,"<MBPA Remarks>%s</MBPA Remarks>",MBPARemarksdup);
					
					sprintf(MBPARemarksstr,",%s",MBPARemarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,MBPARemarksstr);
					
				}
				
				printf("t5_MBPARemarks found=%s\n",MBPARemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_TSRemarks", &TSRemarks));
				if(TSRemarks!=NULL)
				{
					tc_strdup(TSRemarks,&TSRemarksdup);
					//sprintf(TSRemarksstr,"<TS Remarks>%s</TS Remarks>",TSRemarksdup);
					
					sprintf(TSRemarksstr,",%s",TSRemarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,TSRemarksstr);
				}
				
				printf("t5_TSRemarks found=%s\n",TSRemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_LogisticsRemarks", &LogisticRemarks));
				if(LogisticRemarks!=NULL)
				{
					tc_strdup(LogisticRemarks,&LogisticRemarksdup);
					//sprintf(LogisticRemarksstr,"<Logistics Remarks>%s</Logistics Remarks>",LogisticRemarksdup);
					
					sprintf(LogisticRemarksstr,",%s",LogisticRemarksdup);
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,LogisticRemarksstr);
					
				}
				
				printf("t5_LogisticsRemarks found=%s\n",LogisticRemarksdup);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_MATRemarks", &MATRemarks));
				if(MATRemarks!=NULL)
				{
					tc_strdup(MATRemarks,&MATRemarksdup);
					//sprintf(MATRemarksstr,"<MAT Remarks>%s</MAT Remarks>",MATRemarksdup);
					
					sprintf(MATRemarksstr,",%s",MATRemarksdup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,MATRemarksstr);
				}
				printf("t5_MATRemarks found=%s\n",MATRemarksdup);fflush(stdout);
				
				
			   /* CALLAPI(AOM_ask_value_double(t_item1[k] ,"t5_CostReduction", &CostReduction));//used as Double
			   if(CostReduction!=NULL)
			   {
				   tc_strdup(CostReduction,&CostReductiondup);
				   //sprintf(CostReductionstr,"<Cost Reduction>%s</Cost Reduction>",CostReductiondup);
				   
				   
				   sprintf(CostReductionstr,",%s",CostReductiondup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,CostReductionstr);
			   } */
			   
			   printf("t5_CostReduction found=%s\n",CostReductiondup);fflush(stdout);
			   
			   
			   CALLAPI(AOM_ask_value_string(t_item1[k] ,"t5_FialReq", &FollowupReq));
			   if(FollowupReq!=NULL)
			   {
				   tc_strdup(FollowupReq,&FollowupReqdup);
				   //sprintf(FollowupReqstr,"<Is FIAL Flow Required>%s</Is FIAL Flow Required>",FollowupReqdup);
				   
				   sprintf(FollowupReqstr,",%s\n",FollowupReqdup);
					
					
					setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,FollowupReqstr);
			   }
			   
			    printf("t5_FialReqAttr found=%s\n",FollowupReqdup);fflush(stdout);
			   
						

			}	
			
			//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"</Header_Column>");
			//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"</EPAMBPAExclusiveReport>");
		}else
		{
			printf("No Object Found through Query Builder.......\n");fflush(stdout);
			
		}
		
		
		/* if(RfEPAVal!=NULL) MEM_free(RfEPAVal);
		if(Epa_Numberstr!=NULL) MEM_free(Epa_Numberstr);
		if(Epa_CreationDatestr!=NULL) MEM_free(Epa_CreationDatestr);
		if(DML_number_EPAstr!=NULL) MEM_free(DML_number_EPAstr);
		if(DMLEPAcreationDatestr!=NULL) MEM_free(DMLEPAcreationDatestr);
		if(DMLEPAStampedDtstr!=NULL) MEM_free(DMLEPAStampedDtstr);
		if(Epa_Validitystr!=NULL) MEM_free(Epa_Validitystr);
		if(Epa_Descriptionstr!=NULL) MEM_free(Epa_Descriptionstr);
		if(EPA_Subjectstr!=NULL) MEM_free(EPA_Subjectstr);
		if(Epa_Classstr!=NULL) MEM_free(Epa_Classstr);
		if(Epa_Aggregatestr!=NULL) MEM_free(Epa_Aggregatestr);
		if(EPA_FollowupIndstr!=NULL) MEM_free(EPA_FollowupIndstr);
		if(VDREmarksstr!=NULL) MEM_free(VDREmarksstr);
		if(CQRemarksstr!=NULL) MEM_free(CQRemarksstr);
		if(VQRemarks!=NULL) MEM_free(VQRemarks);
		if(MBPARemarksstr!=NULL) MEM_free(MBPARemarksstr);
		if(TSRemarksstr!=NULL) MEM_free(TSRemarksstr);
		if(LogisticRemarksstr!=NULL) MEM_free(LogisticRemarksstr);
		if(MATRemarksstr!=NULL) MEM_free(MATRemarksstr);
		if(FollowupReqstr!=NULL) MEM_free(FollowupReqstr);
		if(HeadingstrExcl!=NULL) MEM_free(HeadingstrExcl);
		if(ReportFiredDatestr!=NULL) MEM_free(ReportFiredDatestr);
		if(ReportFiredfromstr!=NULL) MEM_free(ReportFiredfromstr);
		if(ReportFiredTostr!=NULL) MEM_free(ReportFiredTostr);
		if(ReportFiredPLantstr!=NULL) MEM_free(ReportFiredPLantstr);
		if(ReportFiredAgencystr!=NULL) MEM_free(ReportFiredAgencystr);
		if(ReportFiredTypestr!=NULL) MEM_free(ReportFiredTypestr);
		if(SrlNumstr!=NULL) MEM_free(SrlNumstr);
		if(EpaNumstr!=NULL) MEM_free(EpaNumstr);
		if(DMLNumstr!=NULL) MEM_free(DMLNumstr);
		if(DMLCreStr!=NULL) MEM_free(DMLCreStr);
		if(DMLStampStr!=NULL) MEM_free(DMLStampStr);
		if(EpaSynopsisstr!=NULL) MEM_free(EpaSynopsisstr);
		if(EpaClass!=NULL) MEM_free(EpaClass);
		if(EpaClassDate!=NULL) MEM_free(EpaClassDate);
		if(ActionAgencyStr!=NULL) MEM_free(ActionAgencyStr);
		if(CurrentUserId!=NULL) MEM_free(CurrentUserId);
		if(WorkLocuser!=NULL) MEM_free(WorkLocuser); */
		
		return ifail;
		
}

int EPAMBPAExclusiveReport_func_Signoff(char* Datefrom,char*Dateto,char* Plant,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	printf("**********Inside EPA Signoff Report Function***********\n");fflush(stdout);
	char *Datefrom_signoff=NULL;
	char *Dateto_Signoff=NULL;
	tag_t query_signoff = NULLTAG;
	int	n_found_signoff	= 0;
	char *translated_PLant=NULL;
	tag_t *t_item_Signoff = NULLTAG;
	translated_PLant=MEM_alloc(50);
	int ifail = ITK_ok;
	printf("Argument Received(EPAMBPAExclusiveReport) Signoff Report Function=%s\n",Datefrom);fflush(stdout);
	printf("Argument Received(EPAMBPAExclusiveReport) Signoff Report Function =%s\n",Dateto);fflush(stdout);
	printf("Argument Received(EPAMBPAExclusiveReport) Signoff Report Function =%s\n",Plant);fflush(stdout);
	
	if(tc_strcmp(Plant,"CVBU JSR")==0)
		{
			tc_strdup("PlantName8",&translated_PLant);	
		}else if(tc_strcmp(Plant,"CAR")==0)
		{
			tc_strdup("PlantName1",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU LKO")==0)
		{
			tc_strdup("PlantName9",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU PNR")==0)
		{
			tc_strdup("PlantName2",&translated_PLant);
		}else if(tc_strcmp(Plant,"CVBU PUNE")==0)
		{
			tc_strdup("PlantName3",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU")==0)
		{
			tc_strdup("PlantName4",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU and CVBU")==0)
		{
			tc_strdup("PlantName5",&translated_PLant);
		}else if(tc_strcmp(Plant,"PCBU LKO")==0)
		{
			tc_strdup("PlantName10",&translated_PLant);
		}else if(tc_strcmp(Plant,"SMALLCAR AHD")==0)
		{
			tc_strdup("PlantName6",&translated_PLant);
		}else if(tc_strcmp(Plant,"SMALLCAR PNR")==0)
		{
			tc_strdup("PlantName7",&translated_PLant);
		}else if(tc_strcmp(Plant,"DHARWAD")==0)
		{
			tc_strdup("PlantName11",&translated_PLant);
		}else if(tc_strcmp(Plant,"TMLDL JSR")==0)
		{
			tc_strdup("PlantName12",&translated_PLant);
		}
		
		 printf("Translated Plant received=%s\n",translated_PLant);fflush(stdout);
		   
	tc_strdup(Datefrom,&Datefrom_signoff);
	tc_strdup(Dateto,&Dateto_Signoff);
	char *qry_signoff[] = {"creation_date before","creation_date after","Plant"};
	char *qry_values_signoff[]={Datefrom_signoff,Dateto_Signoff,translated_PLant};
	
		CALLAPI(QRY_find2("EPALocwiseQry", &query_signoff));
		printf("Check 5.2\n");fflush(stdout);
		CALLAPI(QRY_execute(query_signoff, 3, qry_signoff, qry_values_signoff, &n_found_signoff, &t_item_Signoff));
		printf("Check 5.3\n");fflush(stdout);
		if(n_found_signoff>0)
		{
			printf("***********List of EPA's Found********************\n");fflush(stdout);
			
		}else
		{
			printf("************NO EPA's Found**************\n");fflush(stdout);
		}
		
		return ifail;
	
}
/* VARUN END */


/*Sneha -------------------EPA DETAIL REPORT *****/

	int PlantDisplayValue(char* plantNameValue,char** displayName)
	{
	  int ifail = ITK_ok;
	 
		printf("INSIDE TRANSLATED PLANT VALUES");fflush(stdout);	 
	   if(tc_strcmp(plantNameValue,"PlantName8")==0)
		{
			tc_strdup("CVBU JSR",displayName);	
		}
		else if(tc_strcmp(plantNameValue,"PlantName1")==0)
		{
			tc_strdup("CAR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName9")==0)
		{
			tc_strdup("CVBU LKO",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName2")==0)
		{
			tc_strdup("CVBU PNR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName3")==0)
		{
			tc_strdup("CVBU PUNE",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName4")==0)
		{
			tc_strdup("PCBU",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName5")==0)
		{
			tc_strdup("PCBU and CVBU",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName10")==0)
		{
			tc_strdup("PCBU LKO",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName6")==0)
		{
			tc_strdup("SMALLCAR AHD",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName7")==0)
		{
			tc_strdup("SMALLCAR PNR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName11")==0)
		{
			tc_strdup("DHARWAD",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName12")==0)
		{
			tc_strdup("TMLDL JSR",displayName);
		}
		
		printf("\n\n\n\n\n\n\n\n\nPlant name =************************************************************%s",displayName);fflush(stdout);	 
		return ifail;
	}
	

 int getQueryEPAcreatedCount( const char *type,char *val,char *Plant,char *Fromdate,char *Todate,int *n_found)
{
           int ifail = ITK_ok;

           printf("\n\n EPA value==%s \n",val);fflush(stdout);
		   printf("\n\n selection type==%s \n",type);fflush(stdout);

           tag_t        query           = NULLTAG;
           tag_t        *t_item1        = NULLTAG;



           int          n_found_qry         = 0;

		    if (tc_strcmp(type,"Plant")==0)
		   {
		   char
                   *qry_entries3[] = {(char *)type,"creation_date before","creation_date after"},
                   *qry_values3[]  = {val,Fromdate,Todate};

              
			QRY_find2("EPALocwiseQry", &query);
			QRY_execute(query, 3, qry_entries3, qry_values3, &n_found_qry, &t_item1);
		   
		   }
		   else
		   {
		   
           char
                   *qry_entries3[] = {"Plant",(char *)type,"creation_date before","creation_date after"},
                   *qry_values3[]  = {Plant,val,Fromdate,Todate};

              
			QRY_find2("EPALocwiseQry", &query);
			QRY_execute(query, 4, qry_entries3, qry_values3, &n_found_qry, &t_item1);
			}
			
			printf("\n\n getQueryEPAcreatedCount Rows111==%s %d\n",val,n_found_qry);fflush(stdout);

			*n_found=n_found_qry;

     return ifail;


} 


int getQueryEPAClosureCount( const char *type,char *val,char *Plant,char *Fromdate,char *Todate,int *n_found)
{
           int ifail = ITK_ok;

           printf("\n\n EPA value==%s \n",val);fflush(stdout);
		   printf("\n\n selection type==%s \n",type);fflush(stdout);

           tag_t        query           = NULLTAG;
           tag_t        *t_item1        = NULLTAG;



           int          n_found_qry         = 0;

		   if (tc_strcmp(type,"Plant")==0)
		   {
		   char
                   *qry_entries3[] = {(char *)type,"ClosureDate From","ClosureDate To"},
                   *qry_values3[]  = {val,Fromdate,Todate};

              
			QRY_find2("EPALocwiseQry", &query);
			QRY_execute(query, 3, qry_entries3, qry_values3, &n_found_qry, &t_item1);
		   
		   }
           else
		   {
		   
		   char
                   *qry_entries3[] = {"Plant",(char *)type,"ClosureDate From","ClosureDate To"},
                   *qry_values3[]  = {Plant,val,Fromdate,Todate};

              
			QRY_find2("EPALocwiseQry", &query);
			QRY_execute(query, 4, qry_entries3, qry_values3, &n_found_qry, &t_item1);
			
			}

			printf("\n\n getQueryEPAClosureCount Rows111==%s %d\n",val,n_found_qry);fflush(stdout);

			*n_found=n_found_qry;

     return ifail;


} 

 int getQueryEPAfromtask( const char *val,tag_t* items,int *count)
{
           int ifail = ITK_ok;

           
            //char *type="APLDML Revision";

           printf("\n\n concatenated DML==%s \n",val);fflush(stdout);
		   

           tag_t        query           = NULLTAG;
           tag_t        *t_item1        = NULLTAG;


		  int n_found=0;
                

           char
                   *qry_entries3[] = {"EPA Task ID"},
                   *qry_values3[]  = {(char *)val};

        

                     
                QRY_find2("EPALocwiseQry", &query);

               
      

                QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1);

                 printf("\n\n getQueryEPAfromtask Rows555==%s %d\n",val,n_found);fflush(stdout);


                       
					if (n_found>0)
					{
					*items=t_item1[0];
					*count=n_found;
					}

                     return ifail;


} 

 int getQueryItemRevision_AllType( const char *val,char *type,tag_t** items,int *n_found)
{
           int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryItemRevision_AllType......");fflush(stdout);

           printf("\n\n RowsVal object==%s",val);fflush(stdout);
           printf("\n RowsVal type==%s \n",type);fflush(stdout);
		  
           tag_t        query           = NULLTAG;
          
           char
                   *qry_entries3[] = {"Item ID","Type"},
                   *qry_values3[]  = {(char *)val,type};

        

                     
            QRY_find2("Item Revision...", &query);

               
      

            QRY_execute(query,2, qry_entries3, qry_values3, n_found, items);

            printf("\n\n getQueryItemRevision_AllType Rows555==%s \n",val);fflush(stdout);



                 return ifail;


} 


int getQueryTaskfromPart( const char *val,char *revision,tag_t** items,int *n_found)
{
           int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryTaskfromPart......");fflush(stdout);

           printf("\n Part Value DML==%s ",val);fflush(stdout);
           printf("\n Part Revision==%s \n",revision);fflush(stdout);
		  
           tag_t        query           = NULLTAG;
       
           char
                   *qry_entries3[] = {"ID","Revision","ReleaseStatus Not Equal"},
                  
                   *qry_values3[]  = {(char *)val,revision,"T5_LcsStdRlzd"};   
              

        

                     
            QRY_find2("Part-APLTask", &query);

			QRY_execute(query, 3, qry_entries3, qry_values3, n_found, items);
       

            printf("\n\n getQueryTaskfromPart Rows555==%s \n",val);fflush(stdout);
      

              
			
                 return ifail;


} 




 int getQueryEPAfromPart( const char *val,tag_t* items,int *count)
{
          int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryEPAfromPart......");fflush(stdout);

           printf("\n Part Value ==%s ",val);fflush(stdout);
		   

           tag_t        query           = NULLTAG;
           tag_t        *t_item1        = NULLTAG;


		  int n_found=0;
                

           char
                   *qry_entries3[] = {"ID"},
                   *qry_values3[]  = {(char *)val};

        

                     
                QRY_find2("Part-EPA Task", &query);

               
      

                QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &t_item1);

                 printf("\n\n getQueryEPAfromPart Rows555==%s %d\n",val,n_found);fflush(stdout);


                       
					if (n_found>0)
					{
					*items=t_item1[0];
					*count=n_found;
					}

                     return ifail;


} 

int DMLEPARptHeaderinBuffer(char*** bufferedXmlStrOut, int *buff_cnt)
{
	int				ifail 						= ITK_ok;
	
	char *StringValue=NULL;
	char *delimiterValue=NULL;
	
	
	StringValue=MEM_alloc(1000);
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(StringValue,"");
	tc_strcpy(delimiterValue,"");
	
	
	tc_strcat(delimiterValue,"\n-------------------------------------------------------------------------------------------------------------------------------------------");
	sprintf(StringValue,"\n %-s Pending EPA Number");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue," %-5s Pending DML Number");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue," %-5s Pending Part Number");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue," %-5s Parts under  DML");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue," %-5s Corresponding Task");
	tc_strcat(delimiterValue,StringValue);
	tc_strcat(delimiterValue,"\n-------------------------------------------------------------------------------------------------------------------------------------------");
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	printf("\n DMLEPARptHeaderinBuffer [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue); 
	if(StringValue!=NULL) MEM_free(StringValue); 

return ifail;
	
}


int DMLEPAReportBody(char*** bufferedXmlStrOut, int *buff_cnt,char *epa_number,char *dml_number,char *part_number_notrlz,char *partnumber_reqst,char *partnumber_reqst_task)
{
	int				ifail 						= ITK_ok;
	
	char *StringValue=NULL;
	char *delimiterValue=NULL;
	
	
	StringValue=MEM_alloc(1000);
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(StringValue,"");
	tc_strcpy(delimiterValue,"");
	
	
	if (tc_strlen(dml_number)==0)
	{
	tc_strdup("                     ",&dml_number);
	}
	
	if (tc_strlen(part_number_notrlz)==0)
	{
	tc_strdup("                     ",&part_number_notrlz);
	}
	
	if (tc_strlen(epa_number)==0)
	{
	tc_strdup("                   ",&epa_number);
	sprintf(StringValue,"\n%5s",epa_number);
	}
	else
	{
	sprintf(StringValue,"\n%20s",epa_number);
	}
	
	
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%25s",dml_number);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%25s",part_number_notrlz);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%25s",partnumber_reqst);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%25s",partnumber_reqst_task);
	tc_strcat(delimiterValue,StringValue);
	
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	printf("\n DMLEPAReportBody [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue); 
	if(StringValue!=NULL) MEM_free(StringValue); 

return ifail;
	
}

int SummaryHeaderinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* FromDate,char* Todate)
{
	int				ifail 						= ITK_ok;
	
	char *StringValue=NULL;
	char *delimiterValue=NULL;
	
	
	StringValue=MEM_alloc(1000);
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(StringValue,"");
	tc_strcpy(delimiterValue,"");
			
	sprintf(StringValue,"\n %-5s","Total Pending EPA");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%40s",FromDate);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%15s","Created");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%15s","Finalized");
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%15s",Todate);
	tc_strcat(delimiterValue,StringValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	printf("\n SummaryHeaderinBuffer [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue);
	if(StringValue!=NULL) MEM_free(StringValue); 	

return ifail;
	
}

int SummaryBodyinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char *summry_type,int TotalPending,int EpaCreated,int EpaFinalized)
{
	int				ifail 						= ITK_ok;
	
	char *StringValue=NULL;
	char *delimiterValue=NULL;
	
	
	StringValue=MEM_alloc(1000);
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(StringValue,"");
	tc_strcpy(delimiterValue,"");
	
	sprintf(StringValue,"\n %-5s",summry_type);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"\n %-5d",TotalPending);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%65d",EpaCreated);
	tc_strcat(delimiterValue,StringValue);
	sprintf(StringValue,"%15d",EpaFinalized);
	tc_strcat(delimiterValue,StringValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	printf("\n SummaryBodyinBuffer [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue); 
	if(StringValue!=NULL) MEM_free(StringValue); 

return ifail;
	
}

 
int PlantHeaderinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* Plant)
{
	int				ifail 						= ITK_ok;
	
	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	time(&now);
	now_tm = localtime(&now);
	strftime (ReportFiredDate, 26,"%d-%B-%Y", now_tm);
	printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);
	
	
	char *delimiterValue=NULL;
	delimiterValue=MEM_alloc(500);
	tc_strcpy(delimiterValue,"");
	
	char* plant_displayName=NULL;
	plant_displayName=MEM_alloc(100);
	tc_strcpy(plant_displayName,"");
	if (tc_strstr(Plant,"PlantName")!=NULL)
	{
	ITK_CALL(PlantDisplayValue(Plant,&plant_displayName));
	}
			
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"																				EPA REPORT FOR PLANT:[");
	sprintf(delimiterValue,"%5s",plant_displayName);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"]");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"REPORT FIRED ON:");
	sprintf(delimiterValue,"%2s",ReportFiredDate);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"==== ========== ============================== ========== ====================================================== ============================================== ============= =============================================================================== ================== ================== ============== ================= ===================== ================= =============== ================= =================  ===========================  ======================");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"SRL  EPA        EPA TASK                       DESIGN GRP  PART UNDER EPA      COLOUR_IND   COLOUR PART          PART DESCRIPTION                               EPA STATUS     EPA REMARKS                                                                    STDSI RELZ DATE    CREATOR            CREATION DATE  VEH TYPE          AGENCY          		 VALIDITY          FACTORY1        FACTORY2      	 FACTORY3    		REASON                       EPA LIFE CYCLE");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"==== ========== ============================== ========== ====================================================== ============================================== ============= =============================================================================== ================== ================== ============== ================= ===================== ================= =============== ================= =================  ===========================  ======================");
	
	
	printf("\n PlantHeaderinBuffer [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue);
	

return ifail;
	
}


 int PlantBodyinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* spaceValue,char* attributeValue)
{
	int				ifail 						= ITK_ok;
	
		
	char *delimiterValue=NULL;
	delimiterValue=MEM_alloc(1000);
	tc_strcpy(delimiterValue,"");
			
	if (attributeValue==NULL || tc_strlen(attributeValue)==0)
	{
	 tc_strdup("                     ",&attributeValue);
	}
	
	sprintf(delimiterValue,spaceValue,attributeValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	
	printf("\n PlantBodyinBuffer [%s]\n",delimiterValue); fflush(stdout);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue);
	

return ifail;
	
}


	

int AddValueinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* attrValue)
{
	int				ifail 						= ITK_ok;
	
	char *delimiterValue=NULL;
	
	
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(delimiterValue,"");
	tc_strcat(delimiterValue,",");
	tc_strcat(delimiterValue,attrValue);
		
	// sprintf(delimiterValue,",%s",attrValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue); 

return ifail;
	
}



int newlineValueinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* attrValue)
{
	int				ifail 						= ITK_ok;
	
	
	char *newlineValue=NULL;
	
	
	newlineValue=MEM_alloc(1000);
	
	tc_strcpy(newlineValue,"");
	tc_strcat(newlineValue,"\n,");
	tc_strcat(newlineValue,attrValue);
	
	// sprintf(newlineValue,",%s\n",attrValue);
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,newlineValue);
	
	if(newlineValue!=NULL) MEM_free(newlineValue); 

return ifail;
	
}
	
	 int ReleaseStatusObject(tag_t item_tag_rev, char *ReleaseStat)
		{
		 int ifail = ITK_ok;
		int ii             = 0;
		int	status_count   = 0;
		int status;	
		tag_t* status_list = NULLTAG;
        char *relStatus=NULL;
		char *lifecyclestat=NULL;
		lifecyclestat = (char *) MEM_alloc( 100 * sizeof(char) );  
		  
		status=WSOM_ask_release_status_list(item_tag_rev,&status_count,&status_list);
		printf("\n number of statuses for object: %d \n",  status_count);
		
		if (status_count>0)
		{
				if(status==ITK_ok)
				 {
					
					for (ii = 0; ii < status_count; ii++)
					{
						ITK_CALL (AOM_ask_name(status_list[ii], &relStatus));
						printf("\t ReleaseStat: %s\n", relStatus);fflush(stdout);
					}
				 }
				 
		 if (tc_strcmp(	relStatus,"T5_LcsAplRlzd")==0)
			{
			tc_strcpy(lifecyclestat,"APL RELEASED");
			}
			
		else if (tc_strcmp(	relStatus,"T5_LcsStdRlzd")==0)
			{
			tc_strcpy(lifecyclestat,"STDSI RELEASED");
			}
		else if (tc_strcmp(	relStatus,"T5_LcsErcRlzd")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC RELEASED");
			}
		else if (tc_strcmp(	relStatus,"T5_LcsReview")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC REVIEW");
			}
			
			else if (tc_strcmp(	relStatus,"T5_LcsWorking")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC WORKING");
			}
			else
			{
			tc_strcpy(lifecyclestat,relStatus);
			}
			printf("\t Lifecycle stat: %s\n", lifecyclestat);fflush(stdout);
			
		tc_strcpy(ReleaseStat,lifecyclestat);
		}
		
		MEM_free(lifecyclestat);
		
		return ifail;
		}	
			

int lovDisplayedName(char* lovType,char* lovValue,char** displayName)
{
		int				ifail 						= ITK_ok;

		int nlov=0;
		int nlovdesc=0;
		int numlov=0;
		tag_t* tagLov=NULLTAG;
		tag_t Lov=NULLTAG;
		LOV_usage_t   lov_usage;
		LOV_usage_t   lov_usage1;
		char **LovDisplay=NULL;
		char **getLovVal=NULL;
		char **desc_strings=NULL;
		
		 logical*      is_null;         
		 logical*      is_empty; 

		printf("\n  parameters are : %s   %s \n",lovType,lovValue); fflush(stdout);
		
		if (lovValue!=NULL && tc_strlen(lovValue)>0)
		{
			CALLAPI(LOV_find(lovType,&numlov,&tagLov ));
			printf("\n  No of TC LOV are : %d \n",numlov); fflush(stdout);
			
			if (numlov>0)
			{
		
				CALLAPI(LOV_ask_values_display_string(tagLov[0],&lov_usage,&nlov,&LovDisplay,&getLovVal )) ;
				CALLAPI(LOV_ask_value_descriptions(tagLov[0],&lov_usage1,&nlovdesc,&desc_strings,&is_null,&is_empty));
				
				printf("\n  No of TC LOV are : %d \n",nlov); fflush(stdout);
				printf("\n  No of TC LOV are : %d \n",nlovdesc); fflush(stdout);
				int x=0;
				for(x=0;x<nlov;x++)
				{
					printf("\n  In Loopp lovValue : [%s]:%s->%s-->%s \n",lovValue,getLovVal[x],LovDisplay[x],desc_strings[x]); fflush(stdout);
					if(tc_strcmp(lovValue,getLovVal[x])==0 || tc_strcmp(lovValue,desc_strings[x])==0) 
					 {
						break;
					 }
				 
				}
				
				printf("\n  lovValue Matched: [%s]:%s->%s->%s \n",lovValue,getLovVal[x],LovDisplay[x],desc_strings[x]); fflush(stdout);
				
				tc_strdup(desc_strings[x],displayName);
							
			}
		}

return ifail;
}


int GenerateDMLWiseEPAReport(tag_t *dml_rev_tag,int objectsize,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	
	int k=0,i=0,t=0,l=0,m=0,partcount=0,taskcount=0,n_tasksFnd=0;
	char *DMLID=NULL;
	char *DMLDup=NULL;
	char *ECNType=NULL;
	char *Part_number=NULL;
	char *Part_displaynumber=NULL;
	char *Part_creatondt=NULL;
	char *Part_releaseStat=NULL;
	char *epa_number=NULL;
	char *epa_task=NULL;
	char *epa_task_dup=NULL;
	char *dml_number=NULL;
	char *part_number_notrlz=NULL;
	char *part_number_notrlz_revision=NULL;
	char *displaynumber_notrlz=NULL;
	
	char *partnumber_reqst_task=NULL;
	char *tok_tasknumber=NULL;
	char *tasknumber=NULL;
	char *tasknumber_dup=NULL;
	
	
	char *TaskId=NULL;
	
	
	
	char* epaPlant=NULL;
	char* epaPlantDup=NULL;
	
	tag_t *part_rev_tag = NULLTAG;
	tag_t *APLtask_rev_tag = NULLTAG;
	tag_t *APLtask_rev_tag_notrlz = NULLTAG;
	tag_t EPA_Task_tag = NULLTAG;
	tag_t relatnType_tag = NULLTAG;
	tag_t partRelatn_Type_tag = NULLTAG;
	tag_t *task_obj_tag = NULLTAG;
	tag_t *part_obj_tag = NULLTAG;
	tag_t *APLDML_rev_tag = NULLTAG;
	tag_t *EPA_rev_tag = NULLTAG;
	
	
	Part_releaseStat=MEM_alloc(100);
	DMLDup=MEM_alloc(100);
	ECNType=MEM_alloc(100);
	epa_number=MEM_alloc(100);
	
	epa_task_dup=MEM_alloc(100);
	epaPlant=MEM_alloc(100);
	dml_number=MEM_alloc(100);
	part_number_notrlz=MEM_alloc(100);
	
	part_number_notrlz_revision=MEM_alloc(100);
	partnumber_reqst_task=MEM_alloc(100);
	tasknumber=MEM_alloc(100);
	tasknumber_dup=MEM_alloc(100);
	
	tok_tasknumber=MEM_alloc(100);
	
	tc_strcpy(DMLDup,"");
	tc_strcpy(ECNType,"");
	tc_strcpy(Part_releaseStat,"");
	tc_strcpy(epa_task_dup,"");
	tc_strcpy(epaPlant,"");
	tc_strcpy(epa_number,"");
	
	tc_strcpy(dml_number,"");
	tc_strcpy(part_number_notrlz,"");
	tc_strcpy(part_number_notrlz_revision,"");
	
	
	tc_strcpy(partnumber_reqst_task,"");
	tc_strcpy(tasknumber,"");
	tc_strcpy(tasknumber_dup,"");
	
	tc_strcpy(tok_tasknumber,"");
	
	

	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"===========================================================================================================================================");
	CALLAPI(DMLEPARptHeaderinBuffer(bufferedXmlStrOut,buff_cnt));
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	
	
	
	printf("Total DML found are =%d\n",objectsize);fflush(stdout);
	
	
	for (m=0;m<objectsize ;m++ )
	{
			
	  ITK_CALL(AOM_ask_value_string(dml_rev_tag[m],"item_id",&DMLID))
	  printf("\n DMLID: %s ", DMLID);fflush(stdout);
	  
	  tc_strdup(DMLID,&DMLDup);
	  DMLDup=tc_strtok(DMLDup,"_");
	  DMLDup=tc_strtok(NULL,"");
	  tc_strdup(DMLDup,&ECNType);
	  
	  printf("\n ECNType of DML: %s ", ECNType);fflush(stdout);
	  
			
			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
			if (relatnType_tag!=NULLTAG)
			{
				if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag[m], relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
				{
						return ifail;
				}
				printf("\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);
				
				
				for (l=0;l<n_tasksFnd ;l++ )
				{

				 // Retrieve the Task-Revision Tag.
				   tag_t task_rev_tag = NULLTAG;
				   
					task_rev_tag=task_obj_tag[l];
					if (task_rev_tag  != NULLTAG)
					{
					  ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskId));
					  printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskId); fflush(stdout);
					
					    int n_parts=0;
					  // Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
						ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
						if (partRelatn_Type_tag!=NULLTAG)
						{
						
						if ( (ifail = GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
							{
									return ifail;
							}
							printf("\n Total Parts found are are : %d \n",n_parts); fflush(stdout);
						}
						
						for(k=0;k<n_parts;k++)
						{
						
						   tag_t PartObjects = NULLTAG;
					       PartObjects=part_obj_tag[k];
						   
						   
						
							CALLAPI(AOM_ask_value_string(PartObjects ,"item_id", &Part_number));
							
							CALLAPI(AOM_UIF_ask_value(PartObjects ,"creation_date", &Part_creatondt));
							
							CALLAPI(AOM_ask_value_string(PartObjects ,"object_string", &Part_displaynumber));
							
							
							printf("Parts number is=%s\n",Part_number);fflush(stdout);
							printf("Parts display name=%s\n",Part_displaynumber);fflush(stdout);
							printf("Parts creation date is=%s\n",Part_creatondt);fflush(stdout);
							
							ITK_CALL (ReleaseStatusObject(PartObjects,Part_releaseStat));
							if(Part_releaseStat!=NULL)
							{
							printf("\n Parts release status is=%s",Part_releaseStat);fflush(stdout);
							} 
							
													
							/* get all  parts of expanded part number under requested DML */
							partcount=0;
							ITK_CALL (getQueryItemRevision_AllType(Part_number,"Design Revision",&part_rev_tag,&partcount));
							
							printf("\n number of the Part queried is [%d]",partcount);fflush(stdout);
							
							if (partcount>0)
							{
							   for (i=0;i<partcount;i++)
							   {
							    char *epa_number_notrlz=NULL;epa_number_notrlz=MEM_alloc(100);tc_strcpy(epa_number_notrlz,"");
							    char *assembly_notrlz=NULL;assembly_notrlz=MEM_alloc(100);tc_strcpy(assembly_notrlz,"");
								char *DML_notRelease=NULL;DML_notRelease=MEM_alloc(100);tc_strcpy(DML_notRelease,"");
								char *TaskIdPrint=NULL;TaskIdPrint=MEM_alloc(100);tc_strcpy(TaskIdPrint,"");
								char *TaskPartPrint=NULL;TaskPartPrint=MEM_alloc(100);tc_strcpy(TaskPartPrint,"");
								 
								
								
								 
								int PartPrint=0;
								
								tag_t Part_tag =NULLTAG;
								Part_tag = part_rev_tag[i];
							   
								CALLAPI(AOM_ask_value_string(Part_tag ,"item_id", &part_number_notrlz));
								printf("inside qyery all part\n");fflush(stdout);
								CALLAPI(AOM_ask_value_string(Part_tag ,"object_string", &displaynumber_notrlz));
								CALLAPI(AOM_ask_value_string(Part_tag ,"item_revision_id", &part_number_notrlz_revision));
								
								
								printf("\nPrevious Part number is [%d]%s",i,part_number_notrlz);fflush(stdout);
								printf("\nPrevious Part display is[%d]%s\n",i,displaynumber_notrlz);fflush(stdout);
								printf("\nPrevious Part Revision is[%d]%s\n",i,part_number_notrlz_revision);fflush(stdout);
								
								part_number_notrlz_revision=tc_strtok(part_number_notrlz_revision,";");
								tc_strcat(part_number_notrlz_revision,"*");
								printf("\nPrevious Part revision after tokking %s\n",part_number_notrlz_revision);fflush(stdout);
								
								/* get the Task of the part number which are not released */
								taskcount=0;
								ITK_CALL (getQueryTaskfromPart(part_number_notrlz,part_number_notrlz_revision,&APLtask_rev_tag_notrlz,&taskcount));
								//ITK_CALL (getQueryTaskfromPart(Part_number,&APLtask_rev_tag_notrlz,&taskcount));
								
								printf("Total task found which are not Rlz =%d\n",taskcount);fflush(stdout);
								
								if (taskcount>0)
									{
									
										for (t=0;t<taskcount;t++)
										{
											tag_t Task_tag =NULLTAG;
											Task_tag = APLtask_rev_tag_notrlz[t];
											
											 CALLAPI(AOM_ask_value_string(Task_tag ,"item_id", &tasknumber));
											 
											if (tasknumber!=NULL && tc_strlen(tasknumber)>0)
											{
												printf("\n task number is [%d]%s",t,tasknumber);fflush(stdout);
												
												tc_strdup(tasknumber,&tasknumber_dup);
												tasknumber_dup=tc_strtok(tasknumber_dup,"_");
												
												printf("\n task number dup is %s",tasknumber_dup);fflush(stdout);
												
												tc_strdup(tasknumber,&tok_tasknumber);
												tok_tasknumber=tc_strtok(tok_tasknumber,"_");
												tok_tasknumber=tc_strtok(NULL,"");
												printf("\n After Toking design grp found =%s",tok_tasknumber);fflush(stdout);
												tok_tasknumber=tc_strtok(tok_tasknumber,"_");
												tok_tasknumber=tc_strtok(NULL,"");
												
																					
												printf("\n After Toking ECNType found =%s",tok_tasknumber);fflush(stdout);
												
											if(tc_strcmp(tok_tasknumber,ECNType)==0) 
											{
												char *tasknumber_DML=NULL;tasknumber_DML=MEM_alloc(100);tc_strcpy(tasknumber_DML,"");
												//tc_strcat(tasknumber_EPA,"*");
												 tc_strcat(tasknumber_DML,tasknumber_dup);
												 tc_strcat(tasknumber_DML,"_");
												 tc_strcat(tasknumber_DML,ECNType); 
												 
												 printf("\n DML number to get =%s",tasknumber_DML);fflush(stdout);
												 
												int APLDMLcount=0;
												ITK_CALL (getQueryItemRevision_AllType(tasknumber_DML,"APL DML Revision",&APLDML_rev_tag,&APLDMLcount));
												
												printf("\n number of the APL DML queried is [%d]",APLDMLcount);fflush(stdout);
												
												int ii=0;
												if (APLDMLcount>0)
												{
												   for (ii=0;ii<APLDMLcount;ii++)
												    {
													   tag_t APLDML_tag =NULLTAG;
													   APLDML_tag = APLDML_rev_tag[ii];
												   
													   CALLAPI(AOM_ask_value_string(APLDML_tag ,"item_id", &tasknumber_DML));
													   printf("\n The DML number is %s",tasknumber_DML);fflush(stdout);
													   
													   char*  APLDMLReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
													   tc_strcpy(APLDMLReleaseStats,"");
											           ITK_CALL (ReleaseStatusObject(APLDML_tag,APLDMLReleaseStats));
													   printf("\n The DML release status is %s",APLDMLReleaseStats);fflush(stdout);
													   
													   if (APLDMLReleaseStats!=NULL)
													   {
														   if ((tc_strcmp(APLDMLReleaseStats,"STDSI RELEASED")==0))
														   {
														    printf("\n The APLDMLReleaseStats  STDSI RELEASED");fflush(stdout);
														   }
														   else
														   {
														    printf("\n The APLDMLReleaseStats NOT STDSI RELEASED");fflush(stdout);
														    PartPrint++;
															tc_strdup(displaynumber_notrlz,&assembly_notrlz);
															tc_strdup(tasknumber_DML,&DML_notRelease);
															tc_strdup(Part_displaynumber,&TaskPartPrint);
															tc_strdup(TaskId,&TaskIdPrint);
														   }
													   }
													   else
													   {
													    printf("\n The APLDMLReleaseStats is found NULL");fflush(stdout);
													   }
													   
													 if (APLDMLReleaseStats!=NULL)  MEM_free(APLDMLReleaseStats); 
													   
												    }
												   
												}
												
												 
											  
											printf("\n Similar ECNType found =%s\n",tok_tasknumber);fflush(stdout);
										  }
										
										 }
										
										}
									
									}
									
									
									/* get the EPA of the part number which are not released */									 
									int EPAcount=0;
									//ITK_CALL (getQueryEPAfromtask(tasknumber_EPA,&EPA_tag,&EPAcount));
									ITK_CALL (getQueryEPAfromPart(part_number_notrlz,&EPA_Task_tag,&EPAcount));
									
									printf("Total EPA Task found  are =%d\n",EPAcount);fflush(stdout);
								  
								    
									  if (EPA_Task_tag!=NULLTAG && EPAcount>0)
									  {
									   CALLAPI(AOM_ask_value_string(EPA_Task_tag ,"item_id", &epa_task));
									   
									   if(epa_task!=NULL && tc_strlen(epa_task)>0)
									   {
											tc_strdup(epa_task,&epa_task_dup);
											printf("\n epa_task %s",epa_task_dup);fflush(stdout);
											epa_number=tc_strtok(epa_task_dup,"_");
											printf("\n EPA number %s",epa_number);fflush(stdout);
											
										    EPAcount=0;
											ITK_CALL (getQueryItemRevision_AllType(epa_number,"EPA Revision",&EPA_rev_tag,&EPAcount));
											
											printf("\n number of the EPA queried is [%d]",EPAcount);fflush(stdout);
											
											
											int ii=0;
											if (EPAcount>0)
											{
											   for (ii=0;ii<EPAcount;ii++)
											   {
												   tag_t EPA_tag =NULLTAG;
												   EPA_tag = EPA_rev_tag[ii];
											   
												   CALLAPI(AOM_ask_value_string(EPA_tag ,"item_id", &epa_number));
												   printf("\n The EPA number is %s",epa_number);fflush(stdout);
												   
												   CALLAPI(AOM_ask_value_string(EPA_tag ,"t5_EpaPlantA", &epaPlantDup));
												   tc_strdup(epaPlantDup,&epaPlant);
												   printf("\n The EPA Plant is %s",epaPlant);fflush(stdout);
												   
												   
												   if ((tc_strcmp(epaPlant,"PlantName8")==0) || (tc_strcmp(epaPlant,"CVBU JSR")==0)) //CVBU JSR
												   {
												     tc_strdup("APLJ",&epaPlant);
												   }
												   else if ((tc_strcmp(epaPlant,"PlantName3")==0) || (tc_strcmp(epaPlant,"CVBU PUNE")==0))  //CVBU PUNE
												   {
												     tc_strdup("APLC",&epaPlant);
												   }
												   else if ((tc_strcmp(epaPlant,"PlantName9")==0) || (tc_strcmp(epaPlant,"CVBU LKO")==0))  //CVBU LKO
												   {
												     tc_strdup("APLL",&epaPlant);
												   }
												    else if ((tc_strcmp(epaPlant,"PlantName10")==0) || (tc_strcmp(epaPlant,"PCBU LKO")==0))  //PCBU LKO
												   {
												     tc_strdup("APLL",&epaPlant);
												   }
												   else if ((tc_strcmp(epaPlant,"PlantName11")==0) || (tc_strcmp(epaPlant,"DHARWARD")==0))  //DHARWARD
												   {
												     tc_strdup("APLD",&epaPlant);
												   }
												   else if ((tc_strcmp(epaPlant,"PlantName1")==0) || (tc_strcmp(epaPlant,"CAR")==0)) //CAR
												   {
												     tc_strdup("APLP",&epaPlant);
												   }
												   else if ((tc_strcmp(epaPlant,"PlantName2")==0) || (tc_strcmp(epaPlant,"CVBU PNR")==0)) //CVBU PNR
												   {
												     tc_strdup("APL",&epaPlant);
												   }
												    else if ((tc_strcmp(epaPlant,"PlantName6")==0) || (tc_strcmp(epaPlant,"SMALLCAR AHD")==0)) //SMALLCAR AHD
												   {
												     tc_strdup("APLS",&epaPlant);
												   }
												    else if ((tc_strcmp(epaPlant,"PlantName7")==0) || (tc_strcmp(epaPlant,"SMALLCAR PNR")==0)) //SMALLCAR PNR
												   {
												     tc_strdup("APLU",&epaPlant);
												   } 
												   
												   printf("\n EPA Plant belongs to  [%s] ECN Type",epaPlant);fflush(stdout);
												   
												   
													if(tc_strcmp(epaPlant,ECNType)==0) 
													{
													 printf("\n Similar ECNType found =%s\n",epaPlant);fflush(stdout);													
													   
													   char*  EPAReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
													   tc_strcpy(EPAReleaseStats,"");
													   ITK_CALL (ReleaseStatusObject(EPA_tag,EPAReleaseStats));
													   printf("\n The EPA release status is %s",EPAReleaseStats);fflush(stdout);
													   
													   if (EPAReleaseStats!=NULL)
													   {
														   if ((tc_strcmp(EPAReleaseStats,"STDSI RELEASED")==0))
														   {
														   printf("\n The EPAReleaseStats STDSI RELEASED");fflush(stdout);
														   }
														   else
														   {
														    printf("\n The EPAReleaseStats NOT STDSI RELEASED");fflush(stdout);
														    PartPrint++;
															tc_strdup(displaynumber_notrlz,&assembly_notrlz);
															tc_strdup(epa_number,&epa_number_notrlz);
															tc_strdup(Part_displaynumber,&TaskPartPrint);
															tc_strdup(TaskId,&TaskIdPrint);
														   }
													   }
													   else
													   {
														printf("\n The EPAReleaseStats is found NULL");fflush(stdout);
													   }
													  if (EPAReleaseStats!=NULL)  MEM_free(EPAReleaseStats);  
													}
													else
													{
													printf("\n Similar ECNType not found found =%s\n",ECNType);fflush(stdout);	
													}
											    }
											   
											}
											
										}
																						
									  }
								
							        if (tc_strlen(epa_number_notrlz)>0 || tc_strlen(DML_notRelease)>0 || tc_strlen(assembly_notrlz)>0 || tc_strlen(TaskPartPrint)>0 || tc_strlen(TaskIdPrint)>0 )
									{
									CALLAPI(DMLEPAReportBody(bufferedXmlStrOut,buff_cnt,epa_number_notrlz,DML_notRelease,assembly_notrlz,TaskPartPrint,TaskIdPrint));
									}
									
									/* if (PartPrint>=1)
									{
									setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
									} */
								
							
								  
								}
							}
							
							
							
						}
						
						
						
						
					
					
					}
				}
			
			}
	}						
			
			
			
			
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n===========================================================================================================================================");
	

	return ifail;
}	
	
int GenerateSummaryReport(int objectsize,char* Datefrom,char*Dateto,char* Plant,char* Factory,char*Reason,char* Epa_Type,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	
	int EPA_created_btwn_dates=0;
	int EPA_closed_btwn_dates=0;
	int Total_EPA_pending=0;
	int Total_EPA_finalized=0;
	
	int Total_EPA_Factory_pending=0;
	int Total_EPA_Factory_created=0;
	int Total_EPA_Factory_finalized=0;
	
	int Total_EPA_Reason_pending=0;
	int Total_EPA_Reason_created=0;
	int Total_EPA_Reason_finalized=0;
	
	int Total_EPA_Type_pending=0;
	int Total_EPA_Type_created=0;
	int Total_EPA_Type_finalized=0;
	
	char *LovDescription=NULL;
	char *summary_type=NULL;
	LovDescription=MEM_alloc(1000);
	summary_type=MEM_alloc(1000);
	tc_strcpy(summary_type,"");
	
	
	char *DatefromDup  =NULL;
	char *DatetoDup    =NULL;
	
	DatefromDup=MEM_alloc(20);
	DatetoDup=MEM_alloc(20);
	
	
	tc_strdup(Datefrom,&DatefromDup);
	DatefromDup=tc_strtok(DatefromDup," ");
	
	tc_strdup(Dateto,&DatetoDup);
	DatetoDup=tc_strtok(DatetoDup," ");
	
	printf("After Toking =%s\n",DatefromDup);fflush(stdout);
	printf("After Toking =%s\n",DatetoDup);fflush(stdout);
	
	
		
	/* EPA report Plant wise *************************************/
	EPA_created_btwn_dates=objectsize;
	printf("\n  EPA created between dates [%d]\n",EPA_created_btwn_dates); fflush(stdout);
	ITK_CALL (getQueryEPAcreatedCount("Plant",Plant,Plant,Datefrom,Dateto,&EPA_created_btwn_dates));
	printf("\n 2nd ---- EPA created between dates [%d]\n",EPA_created_btwn_dates); fflush(stdout);
		
	ITK_CALL (getQueryEPAClosureCount("Plant",Plant,Plant,Datefrom,Dateto,&EPA_closed_btwn_dates));
	printf("\n 3rd ---- EPA Closed between dates [%d]\n",EPA_closed_btwn_dates); fflush(stdout);
	
	Total_EPA_pending=EPA_created_btwn_dates-EPA_closed_btwn_dates;
	printf("\n 4th ---- EPA Total Pending [%d]\n",Total_EPA_pending); fflush(stdout);
	
	
	tc_strcpy(LovDescription,"");
	CALLAPI(lovDisplayedName("T5_PlantName",Plant,&LovDescription ));
	tc_strdup(LovDescription,&summary_type);
	printf("\n string=%s\n",summary_type);fflush(stdout);
	
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"                                                 EPA SUMMARY REPORT                                                 ");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	CALLAPI(SummaryHeaderinBuffer(bufferedXmlStrOut,buff_cnt,DatefromDup,DatetoDup));
	CALLAPI(SummaryBodyinBuffer(bufferedXmlStrOut,buff_cnt,summary_type,Total_EPA_pending,EPA_created_btwn_dates,EPA_closed_btwn_dates));
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	
	
	
	
	/* EPA report Factory wise ********************************/
	tc_strcpy(summary_type,"");
	if(Factory!=NULL && tc_strlen(Factory)>0)
	{
	ITK_CALL (getQueryEPAcreatedCount("Factory Code 1",Factory,Plant,Datefrom,Dateto,&Total_EPA_Factory_created));
	printf("\n 2nd ---- EPA created between dates Factory wise [%d]\n",Total_EPA_Factory_created); fflush(stdout);
		
	ITK_CALL (getQueryEPAClosureCount("Factory Code 1",Factory,Plant,Datefrom,Dateto,&Total_EPA_Factory_finalized));
	printf("\n 3rd ---- EPA Closed between dates Factory wise [%d]\n",Total_EPA_Factory_finalized); fflush(stdout);
	
	Total_EPA_Factory_pending=Total_EPA_Factory_created-Total_EPA_Factory_finalized;
	printf("\n 4th ---- EPA Total Pending Factory wise [%d]\n",Total_EPA_Factory_pending); fflush(stdout);
	
	tc_strcpy(LovDescription,"");
	CALLAPI(lovDisplayedName("T5_Category_code4Set",Factory,&LovDescription ));
	tc_strdup(LovDescription,&summary_type);
	printf("\n string=%s\n",summary_type);fflush(stdout);
	}
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"                                               EPA SUMMARY REPORT-Factory Wise                                                 ");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	CALLAPI(SummaryHeaderinBuffer(bufferedXmlStrOut,buff_cnt,DatefromDup,DatetoDup));
	CALLAPI(SummaryBodyinBuffer(bufferedXmlStrOut,buff_cnt,summary_type,Total_EPA_Factory_pending,Total_EPA_Factory_created,Total_EPA_Factory_finalized));
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	
	
	
	/* EPA report Reason wise **************************/
	tc_strcpy(summary_type,"");
	if(Reason!=NULL && tc_strlen(Reason)>0)
	{
	ITK_CALL (getQueryEPAcreatedCount("EPA Reason",Reason,Plant,Datefrom,Dateto,&Total_EPA_Reason_created));
	printf("\n 2nd ---- EPA created between dates Reason wise [%d]\n",Total_EPA_Reason_created); fflush(stdout);
		
	ITK_CALL (getQueryEPAClosureCount("EPA Reason",Reason,Plant,Datefrom,Dateto,&Total_EPA_Reason_finalized));
	printf("\n 3rd ---- EPA Closed between dates Reason wise [%d]\n",Total_EPA_Reason_finalized); fflush(stdout);
	
	Total_EPA_Reason_pending=Total_EPA_Reason_created-Total_EPA_Reason_finalized;
	printf("\n 4th ---- EPA Total Pending Reason wise [%d]\n",Total_EPA_Reason_pending); fflush(stdout);
	
	tc_strcpy(LovDescription,"");
	CALLAPI(lovDisplayedName("T5_Category_code1Set",Reason,&LovDescription ));
	tc_strdup(LovDescription,&summary_type);
	printf("\n string=%s\n",summary_type);fflush(stdout);
	}
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"                                               EPA SUMMARY REPORT-Reason Wise                                                 ");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	CALLAPI(SummaryHeaderinBuffer(bufferedXmlStrOut,buff_cnt,DatefromDup,DatetoDup));
	CALLAPI(SummaryBodyinBuffer(bufferedXmlStrOut,buff_cnt,summary_type,Total_EPA_Reason_pending,Total_EPA_Reason_created,Total_EPA_Reason_finalized));
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	
	
	
	/* EPA report Type wise **************************/
	tc_strcpy(summary_type,"");
	if(Epa_Type!=NULL && tc_strlen(Epa_Type)>0)
	{
	ITK_CALL (getQueryEPAcreatedCount("EPA Type",Epa_Type,Plant,Datefrom,Dateto,&Total_EPA_Type_created));
	printf("\n 2nd ---- EPA created between dates Epa_Type wise [%d]\n",Total_EPA_Type_created); fflush(stdout);
		
	ITK_CALL (getQueryEPAClosureCount("EPA Type",Epa_Type,Plant,Datefrom,Dateto,&Total_EPA_Type_finalized));
	printf("\n 3rd ---- EPA Closed between dates Epa_Type wise [%d]\n",Total_EPA_Type_finalized); fflush(stdout);
	
	Total_EPA_Type_pending=Total_EPA_Type_created-Total_EPA_Type_finalized;
	printf("\n 4th ---- EPA Total Pending Epa_Type wise [%d]\n",Total_EPA_Type_pending); fflush(stdout);
	
	tc_strcpy(LovDescription,"");
	CALLAPI(lovDisplayedName("T5_EpaTypeSet",Epa_Type,&LovDescription ));
	tc_strdup(LovDescription,&summary_type);
	printf("\n string=%s\n",summary_type);fflush(stdout);
	}
	
	
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"                                               EPA SUMMARY REPORT-Type Wise                                                 ");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	CALLAPI(SummaryHeaderinBuffer(bufferedXmlStrOut,buff_cnt,DatefromDup,DatetoDup));
	CALLAPI(SummaryBodyinBuffer(bufferedXmlStrOut,buff_cnt,summary_type,Total_EPA_Type_pending,Total_EPA_Type_created,Total_EPA_Type_finalized));
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n ====================================================================================================================");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
	
	
	printf("\n End Printing");fflush(stdout);
	
	return ifail;
}	


int GenerateEPAPlantReport(tag_t *epaobjects, int size,char *Plant,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	
	CALLAPI(PlantHeaderinBuffer(bufferedXmlStrOut,buff_cnt,Plant));
	
	int k=0;
	char *serial_num=NULL;
	char *Epa_Number=NULL;
	char *task_name=NULL;
	char *creationDt=NULL;
	char *Epa_creator=NULL;
	char *AgencyList=NULL;
	char *EPA_Closure_date=NULL;
	char *Epa_Description=NULL;
	char *EPA_Status=NULL;
	char *EPA_StatusDup=NULL;
	char *Epa_Validity=NULL;
	char *EPAReason=NULL;
	char *EPAReasonDup=NULL;
	char *EPAVehicle=NULL;
	char *EPAVehicleDup=NULL;
	char *EPA_Factory1=NULL;
	char *EPA_Factory1Dup=NULL;
	char *EPA_Factory2=NULL;
	char *EPA_Factory2Dup=NULL;
	char *EPA_Factory3=NULL;
	char *EPA_Factory3Dup=NULL;
	char *EPAReleaseStats=NULL;
	char *LovDescription=NULL;
	
	serial_num=MEM_alloc(1000);
	Epa_creator=MEM_alloc(1000);
	creationDt=MEM_alloc(1000);
	EPAReasonDup=MEM_alloc(1000);
	EPA_StatusDup=MEM_alloc(1000);
	EPAVehicleDup=MEM_alloc(1000);
	EPA_Factory1Dup=MEM_alloc(1000);
	EPA_Factory2Dup=MEM_alloc(1000);
	EPA_Factory3Dup=MEM_alloc(1000);
	LovDescription=MEM_alloc(1000);
	EPAReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
	
	
	tag_t *taskList = NULLTAG;
    tc_strcpy(Epa_creator,""); 
	
	int taskcount=0;	
	CALLAPI(AOM_ask_value_tags(epaobjects[k],"T5_DMLTaskRelation",&taskcount,&taskList));
	printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
	
		for(k=0;k<size;k++)
		{
		
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"item_id", &Epa_Number));
		CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"creation_date", &creationDt));
		CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"owning_user", &Epa_creator));
		CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_EpaAgencyList", &AgencyList));
		CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_EPAClosureDate", &EPA_Closure_date));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"object_desc", &Epa_Description));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaStatus", &EPA_Status));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaValidity", &Epa_Validity));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code1", &EPAReason));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code2", &EPAVehicle));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code4", &EPA_Factory1));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code5", &EPA_Factory2));
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code6", &EPA_Factory3));
		
		
		tc_strcpy(EPAReleaseStats,"");
		ITK_CALL (ReleaseStatusObject(epaobjects[k],EPAReleaseStats));
		printf("EPAReleaseStats found=%s\n",EPAReleaseStats);fflush(stdout);
		
		/* PRINTING THE ATTRIBUTE IN CONSOLE */
		
			if(Epa_Number!=NULL){
				printf("Epa Number Obtained=%s\n",Epa_Number);fflush(stdout);		}
		    if(creationDt!=NULL)  {
			  printf("t5_EpaTskCrDate found=%s\n",creationDt);fflush(stdout); 
			  creationDt=tc_strtok(creationDt," ");
			  }
			
			
			if(Epa_creator!=NULL) 
			{
			
			  printf("Epa_creator found=%s\n",Epa_creator);fflush(stdout); 
			  
			  Epa_creator=tc_strtok(Epa_creator," (");
			  printf("Epa_creator Tokkenized=%s\n",Epa_creator);fflush(stdout); 
			}
			
		    if(Epa_Validity!=NULL)   {
			 printf("Validity of EPA found=%s\n",Epa_Validity);fflush(stdout); }  
			if(Epa_Description!=NULL){
							   printf("Epa Description Obtained=%s\n",Epa_Description);fflush(stdout);		}
	
			if(AgencyList!=NULL)	{
				printf("AgencyList found=%s\n",AgencyList);fflush(stdout);}
			
							
			if(EPA_Closure_date!=NULL){
				printf("EPA_Closure_date found=%s\n",EPA_Closure_date);fflush(stdout);} 
				
			
			tc_strcpy(EPAReasonDup,"");
			tc_strcpy(EPA_StatusDup,"");
			tc_strcpy(EPAVehicleDup,"");
			tc_strcpy(EPA_Factory1Dup,"");
			tc_strcpy(EPA_Factory2Dup,"");
			tc_strcpy(EPA_Factory3Dup,"");
					
		
		if(EPAReason!=NULL && tc_strlen(EPAReason)>0)
				{
					printf("t5_Reason found=%s\n",EPAReason);fflush(stdout);	
					
					tc_strdup(EPAReason,&EPAReasonDup);
					printf("EPAReasonDup found=%s\n",EPAReasonDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_Category_code1Set",EPAReasonDup,&LovDescription ));
					//tc_strdup(LovDescription,&EPAReasonDup);
					
					STRNG_replace_str(LovDescription,",",";",&EPAReasonDup);	
					printf("\n replaced string=%s\n",EPAReasonDup);fflush(stdout);
					
				}
					
			if(EPA_Status!=NULL && tc_strlen(EPA_Status)>0)
			{
				printf("EPA_Status found=%s\n",EPA_Status);fflush(stdout);
				
				tc_strdup(EPA_Status,&EPA_StatusDup);
				
				tc_strcpy(LovDescription,"");
				CALLAPI(lovDisplayedName("T5_EpaStatusSet",EPA_StatusDup,&LovDescription ));
				
				tc_strdup(LovDescription,&EPA_StatusDup);
				printf("EPA_StatusDup found=%s\n",EPA_StatusDup);fflush(stdout);
				
			}
			
			if(EPAVehicle!=NULL && tc_strlen(EPAVehicle)>0)
			{
				printf("EPAVehicle found=%s\n",EPAVehicle);fflush(stdout);
				
				tc_strdup(EPAVehicle,&EPA_StatusDup);
				
				tc_strcpy(LovDescription,"");
				CALLAPI(lovDisplayedName("T5_Category_code2Set",EPAVehicleDup,&LovDescription ));
				
				tc_strdup(LovDescription,&EPAVehicleDup);
				printf("EPAVehicleDup found=%s\n",EPAVehicleDup);fflush(stdout);
				
			}
			
			if(EPA_Factory1!=NULL && tc_strlen(EPA_Factory1)>0)
			{
				printf("EPA_Factory1 found=%s\n",EPA_Factory1);fflush(stdout);
				
				tc_strdup(EPA_Factory1,&EPA_Factory1Dup);
				
				tc_strcpy(LovDescription,"");
				CALLAPI(lovDisplayedName("T5_Category_code4Set",EPA_Factory1Dup,&LovDescription ));
				
				tc_strdup(LovDescription,&EPA_Factory1Dup);
				printf("EPA_Factory1Dup found=%s\n",EPA_Factory1Dup);fflush(stdout);
				
			}
			
			if(EPA_Factory2!=NULL && tc_strlen(EPA_Factory2)>0)
			{
				printf("EPA_Factory2 found=%s\n",EPA_Factory2);fflush(stdout);
				
				tc_strdup(EPA_Factory2,&EPA_Factory2Dup);
				
				tc_strcpy(LovDescription,"");
				CALLAPI(lovDisplayedName("T5_Category_code5Set",EPA_Factory2Dup,&LovDescription ));
				
				tc_strdup(LovDescription,&EPA_Factory2Dup);
				printf("EPA_Factory2Dup found=%s\n",EPA_Factory2Dup);fflush(stdout);
				
			}
			
			if(EPA_Factory3!=NULL && tc_strlen(EPA_Factory3)>0)
			{
				printf("EPA_Factory3 found=%s\n",EPA_Factory3);fflush(stdout);
				
				tc_strdup(EPA_Factory3,&EPA_Factory3Dup);
				
				tc_strcpy(LovDescription,"");
				CALLAPI(lovDisplayedName("T5_Category_code6Set",EPA_Factory3Dup,&LovDescription ));
				
				tc_strdup(LovDescription,&EPA_Factory3Dup);
				printf("EPA_Factory3Dup found=%s\n",EPA_Factory3Dup);fflush(stdout);
				
			}
				
		
		
			/*Report Generation for EPA Plant */
				printf("Start Printing for EPA Plant");fflush(stdout);
				sprintf(serial_num,"\n %d",(k+1));
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,serial_num);
				
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%12s",Epa_Number));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%155s",EPA_StatusDup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%32s",Epa_Description));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%60s",EPA_Closure_date));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%30s",Epa_creator));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%15s",creationDt));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",EPAVehicleDup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",AgencyList));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",Epa_Validity));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",EPA_Factory1Dup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",EPA_Factory2Dup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",EPA_Factory3Dup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%10s",EPAReasonDup));
				CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%20s",EPAReleaseStats));
		       printf("End Printing for EPA Plant");fflush(stdout);
		    /*END*/
		
		/*GET THE TASK OF EPA*/
		int taskcount=0;	
		CALLAPI(AOM_ask_value_tags(epaobjects[k],"T5_DMLTaskRelation",&taskcount,&taskList));
		printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
		
				/* For getting Part Details */
				if(taskcount>0)
				{
				
				    char *DesignGrp=NULL;
				    char *DesignGrpTask=NULL;
					char **DesignGroupList;
					char *TaskCreation_dt=NULL;
					char *TaskCreated_by=NULL;
					
					int num=0;
					tag_t partRelatn_Type_tag = NULLTAG;
						
					DesignGrp=MEM_alloc(100);	
					TaskCreation_dt=MEM_alloc(100);	
					DesignGrpTask=MEM_alloc(100);	
					tc_strcpy(DesignGrpTask,"");
					
					
					int i;
					for(i=0;i<taskcount;i++)
					{
						tag_t task=taskList[i];
						if (task!=NULLTAG)
						{
						
							CALLAPI(AOM_ask_value_string(task ,"item_id",&task_name));
						    printf("Task Name found =%s\n",task_name);fflush(stdout);
							
							CALLAPI(AOM_UIF_ask_value(task ,"owning_user",&TaskCreated_by));
						    printf("Task TaskCreated_by found =%s\n",TaskCreated_by);fflush(stdout);
							
							
							CALLAPI(AOM_UIF_ask_value(task ,"creation_date",&TaskCreation_dt));
						    printf("Task creation_date found =%s\n",TaskCreation_dt);fflush(stdout);
							TaskCreation_dt=tc_strtok(TaskCreation_dt," ");

							 ITK_CALL(AOM_ask_value_strings(task,"t5_crdesigngroup",&num,&DesignGroupList));
									 
									 for (k=0;k<num;k++)
									 {
									 tc_strcpy(DesignGrp,"");
									 tc_strdup(DesignGroupList[k],&DesignGrp);
									 printf("\n  DesignGrp : %s \n",DesignGrp); fflush(stdout);
									 
									 tc_strcat(DesignGrpTask,DesignGrp);
									 tc_strcat(DesignGrpTask,";");
									 }					
									 
                            printf("Task Name Design =%s\n",DesignGrpTask);fflush(stdout);
							
							
							/*Report Generation for EPA TASK */
							printf("Start Printing for EPA Task");fflush(stdout);
							setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
							setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"		");
							CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%35s",task_name));
							CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%10s",DesignGrpTask));
							CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%237s",TaskCreated_by));
							CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%15s",TaskCreation_dt));
							/*Report Generation END for EPA Plant */
							
							/*GETTING PARTS OF EPA TASK */
							ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
							if (partRelatn_Type_tag!=NULLTAG)
							{
							tag_t *part_obj_tag = NULLTAG;
							int n_parts= 0;	
							
								if ( (ifail = GRM_list_secondary_objects_only( task,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
									{
											return ifail;
									}
								printf("\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
								
								int j=0;
								if (n_parts>0)
								{
								 for (j=0;j<n_parts ;j++ )
									{
											tag_t part_rev_tag = NULLTAG;
			   
											part_rev_tag=part_obj_tag[j];
																						
											 /**********Print the Part description in File */
											
											//Part properties
											char       	*PartNumberS                    		= NULL;
											char        *RevisionS                              = NULL;
											int        	SequenceS                           	= 0;
											char        *PartSeq                              	= NULL;
											char        *PartColourInd	                     	= NULL;
											char        *PartReleaseStats                      	= NULL;
											char 		*PartDescription						= NULL;
											
											PartSeq=MEM_alloc(10);
														


											ITK_CALL(AOM_ask_value_string(part_rev_tag,"item_id",&PartNumberS));
											printf("\n  part-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);


											ITK_CALL (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
											printf("\n  part-Rev RevisionS : %s \n",RevisionS); fflush(stdout);

											ITK_CALL (AOM_ask_value_int(part_rev_tag,"sequence_id",&SequenceS));
											printf("\n  part-Rev SequenceS : %d \n",SequenceS); fflush(stdout);

											
											ITK_CALL (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDescription));
											printf("\n    part-Rev PartDescription : %s \n",PartDescription); fflush(stdout);
											if (PartDescription==NULL)
											{
											 tc_strdup("NA",&PartDescription);
											}

											ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_ColourInd",&PartColourInd));
											printf("\n  part-Rev PartColourInd : %s \n",PartColourInd); fflush(stdout);
						
									
									        /*Report Generation for EPA parts */
											printf("Start Printing for EPA parts");fflush(stdout);
											setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
											CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%70s",PartNumberS));
											CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%4s",RevisionS));
											//CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%2d",SequenceS));
											CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%5s",PartColourInd));
											CALLAPI(PlantBodyinBuffer(bufferedXmlStrOut,buff_cnt,"%40s",PartDescription));
											/*Report Generation END for EPA parts */
									
									   
									}
								}
							
							}

							
						}
					}
				}
				
				
				
				
		
		}
	
	
	return ifail;
}
void tm_getSTDReleasedCtxt(char *cPlantname, char **cSTDRevisionRule, char	**cSTDClosureRule,char **cSTDPlantCS,char **cSTDParentCS)
{
	int     n_entryCntrl2    		= 	3;
	int		control_number_found2	=	0;
	
	char	*cRevisionRule			=	NULL;
	char	*cClosureRule			=	NULL;
	char	*cPlantCS               =	NULL;
	char	*cParentCS               =	NULL;

	char    *qry_entryCntrl1[3]  	= {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= (char **) MEM_alloc(5 * sizeof(char *));
	
	tag_t	qryTagCntrl				=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags2	=	NULLTAG;
	printf("\nInside tm_getSTDReleasedCtxt : %s",cPlantname);fflush(stdout);
	
	if(QRY_find2("Control Objects...", &qryTagCntrl));
	if(qryTagCntrl!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDStateInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo2", &cRevisionRule);
			printf("\n cRevisionRule: %s\n",cRevisionRule);fflush(stdout);
			*cSTDRevisionRule	=	NULL;
			*cSTDRevisionRule	=	(char	*)MEM_alloc(tc_strlen(cRevisionRule)+15);
			tc_strcpy(*cSTDRevisionRule,cRevisionRule);
		}
		else
		{
			printf("\nRevision rule query result null");fflush(stdout);
			*cSTDRevisionRule	=	NULL;
			*cSTDRevisionRule	=	(char	*)MEM_alloc(tc_strlen("STDP Working and Above")+15);
			tc_strcpy(*cSTDRevisionRule,"STDP Working and Above");
		}
		
		qry_valuesCntrl1[0]="STDStateInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo1", &cClosureRule);
			printf("\n cClosureRule: %s\n",cClosureRule);fflush(stdout);
			*cSTDClosureRule	=	NULL;
			*cSTDClosureRule	=	(char	*)MEM_alloc(tc_strlen(cClosureRule)+15);
			tc_strcpy(*cSTDClosureRule,cClosureRule);
		}
		else
		{
			printf("\nClosure rule query result null");fflush(stdout);
			*cSTDClosureRule	=	NULL;
			*cSTDClosureRule	=	(char	*)MEM_alloc(tc_strlen("BOMViewClosureRuleSTDP")+15);
			tc_strcpy(*cSTDClosureRule,"BOMViewClosureRuleSTDP");
		}
		qry_valuesCntrl1[0]="STDStateInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo8", &cPlantCS);
			printf("\n cPlantCS: %s\n",cPlantCS);fflush(stdout);
			*cSTDPlantCS	=	NULL;
			*cSTDPlantCS	=	(char	*)MEM_alloc(tc_strlen(cPlantCS)+15);
			tc_strcpy(*cSTDPlantCS,cPlantCS);
		}
		else
		{
			printf("\nClosure rule query result null");fflush(stdout);
			*cSTDPlantCS	=	NULL;
			*cSTDPlantCS	=	(char	*)MEM_alloc(tc_strlen("bl_Design Revision_t5_PunMakeBuyIndicator")+15);
			tc_strcpy(*cSTDPlantCS,"bl_Design Revision_t5_PunMakeBuyIndicator");
		}

		qry_valuesCntrl1[0]="STDStateInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo6", &cParentCS);
			printf("\n cParentCS: %s\n",cParentCS);fflush(stdout);
			*cSTDParentCS	=	NULL;
			*cSTDParentCS	=	(char	*)MEM_alloc(tc_strlen(cParentCS)+15);
			tc_strcpy(*cSTDParentCS,cParentCS);
		}
		else
		{
			printf("\nClosure rule query result null");fflush(stdout);
			*cSTDParentCS	=	NULL;
			*cSTDParentCS	=	(char	*)MEM_alloc(tc_strlen("t5_PunMakeBuyIndicator")+15);
			tc_strcpy(*cSTDParentCS,"t5_PunMakeBuyIndicator");
		}
	}
	
}
char* remove_specialCharDesc(char *in) 
{	
	//printf("\n Test Inside Function remove_specialCharDesc \n");fflush(stdout);
	printf("\nTest Inside Function remove_specialCharDesc\n"); fflush(stdout);
 
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		//if (in[j] != '\n' && in[j] != '\r'  && in[j] != ',' )
		if ( (in[j] != ',') )
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';
 
 
return tmp;
}
//Added by Deepti
int GenerateEPAReportNetDiff(tag_t *epaobjects, int size,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	
	char *Epa_Number=NULL;
	char *EPA_Plant=NULL;
	char *object_type=NULL;
	char *object_type1=NULL;
	char *epaTaskNo=NULL;
	char *EPAReason=NULL;
	char *EPAReasonDup=NULL;
	char *EPAVehicle=NULL;
	char *EPAVehicleDup=NULL;
	char *EPA_Status=NULL;
	char *EPA_StatusDup=NULL;
	char *VALIDITY=NULL;
    
	char *VALIDITY_REMARKS=NULL;
	char *VALIDITY_REMARKSDup=NULL;
	char *Reason=NULL;
	char *ReasonDup=NULL;
    char *EPA_Agency=NULL;
	char *EPA_AgencyDup=NULL;
	char *Factory_Code1=NULL;
	char *Factory_Code1Dup=NULL;
	char *Factory_Code2=NULL;
	char *Factory_Code2Dup=NULL;
	char *Factory_Code3=NULL;
	char *Factory_Code3Dup=NULL;
	char *EPA_Subject=NULL;
	char *EPA_Remarks=NULL;
	char   *PlantName=NULL;
	//char PlantName[40]=NULL;
	
	char *LovDescription=NULL;
	char *creationDt=NULL;
	char *Epa_creator=NULL;
	char *AgencyList=NULL;
	char *epa_plant=NULL;
	char *epaTaskNo1=NULL;
	char *DML_Number=NULL;
	char *All_DML_Number=NULL;
	char *Revision_type_DML= NULL;
	char *DMLReleasedate= NULL;
	char *DMLReleasedateDup= NULL;
	char *All_DML_Number_Release=NULL;
	char *DMLEPAStampedDt=NULL;
	char *EPAReleasedate=NULL;
	char *serial_num=NULL;
	tag_t  CurrentRoleTag = NULLTAG;


	tag_t	relation_type						= NULLTAG;
	tag_t*	EPATaskRevision						= NULLTAG;
	tag_t	EPATaskRevTag						= NULLTAG;
	tag_t*	PartTags							= NULLTAG;
	tag_t*	EPATaskRevision1						= NULLTAG;
	tag_t	EPATaskRevTag1						= NULLTAG;
	tag_t *dml_rev_tag_arr = NULLTAG;

	int count=0;
	int TaskCnt=0;
	int PartCnt=0;
	int k=0;
	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	//char roleName[SA_name_size_c+1];
    char* roleName;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];

	//struct ChldStruct ChldPrtList[3000];
										
	time(&now);
	now_tm = localtime(&now);

	strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
	printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);

	CALLAPI(AOM_ask_value_string(epaobjects[0] ,"item_id", &Epa_Number));
	printf("Epa_Number %s\n",Epa_Number);fflush(stdout);

	CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_EpaPlantA", &EPA_Plant));
	printf("EPA_Plant %s\n",EPA_Plant);fflush(stdout);

	CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA DETAILS REPORT For :["));
	CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Number));
	CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"]"));

	CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Report Fired On :"));
	CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,ReportFiredDate));
	CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));

	CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA NO               :"));
	CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Number));

	CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML No               :"));
	

	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
	CALLAPI(GRM_list_secondary_objects_only(epaobjects[0],relation_type,&count,&EPATaskRevision));


	EPAReasonDup=MEM_alloc(1000);
	LovDescription=MEM_alloc(1000);
	creationDt=MEM_alloc(1000);
	Epa_creator=MEM_alloc(1000);
	DML_Number=MEM_alloc(100);
	All_DML_Number=MEM_alloc(1000);
	Revision_type_DML = MEM_alloc(100);
	DMLReleasedate = MEM_alloc(100);
	DMLReleasedateDup=MEM_alloc(100);
	All_DML_Number_Release=MEM_alloc(1000);
	serial_num=MEM_alloc(10);

	VALIDITY_REMARKS=MEM_alloc(1000);
	VALIDITY=MEM_alloc(1000);
    Reason=MEM_alloc(1000);
	EPA_Agency=MEM_alloc(1000);
	Factory_Code1=MEM_alloc(1000);
	Factory_Code2=MEM_alloc(1000);
	Factory_Code3=MEM_alloc(1000);
	EPA_Remarks=MEM_alloc(1000);
	EPA_Subject=MEM_alloc(1000);


	printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
	if(count>0)
	{
		
		

		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_Category_code1", &EPAReason));

		tc_strcpy(EPAReasonDup,"");
		tc_strcpy(EPAVehicleDup,"");
		tc_strcpy(Epa_creator,""); 
		tc_strcpy(All_DML_Number,"");
		tc_strcpy(All_DML_Number_Release,"");
		tc_strcpy(VALIDITY_REMARKSDup,""); 
		tc_strcpy(ReasonDup,"");
		tc_strcpy(EPA_AgencyDup,"");
		tc_strcpy(Factory_Code1Dup,"");
		tc_strcpy(Factory_Code2Dup,"");
		tc_strcpy(Factory_Code3Dup,"");

		if(EPAReason!=NULL && tc_strlen(EPAReason)>0)
		{
			printf("t5_Reason found=%s\n",EPAReason);fflush(stdout);	
			
			tc_strdup(EPAReason,&EPAReasonDup);
			printf("EPAReasonDup found=%s\n",EPAReasonDup);fflush(stdout);
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_Category_code1Set",EPAReasonDup,&LovDescription ));
			
			STRNG_replace_str(LovDescription,",",";",&EPAReasonDup);	
			printf("\n replaced string=%s\n",EPAReasonDup);fflush(stdout);
			
		}
		
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_Category_code2", &EPAVehicle));
		if(EPAVehicle!=NULL && tc_strlen(EPAVehicle)>0)
		{
			printf("EPAVehicle found=%s\n",EPAVehicle);fflush(stdout);
			
			tc_strdup(EPAVehicle,&EPAVehicleDup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_Category_code2Set",EPAVehicleDup,&LovDescription ));
			
			tc_strdup(LovDescription,&EPAVehicleDup);
			printf("EPAVehicleDup found=%s\n",EPAVehicleDup);fflush(stdout);
			
		}
		
		CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaStatus", &EPA_Status));
		if(EPA_Status!=NULL && tc_strlen(EPA_Status)>0)
		{
			printf("EPA_Status found=%s\n",EPA_Status);fflush(stdout);
			
			tc_strdup(EPA_Status,&EPA_StatusDup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_EpaStatusSet",EPA_StatusDup,&LovDescription ));
			
			tc_strdup(LovDescription,&EPA_StatusDup);
			printf("EPA_StatusDup found=%s\n",EPA_StatusDup);fflush(stdout);
			
		}
		////////////////////////////////////////////////////////
        printf("*******************EPA New Changes*******************\n");fflush(stdout);
		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"t5_ValidityRemarks", &VALIDITY_REMARKS));
		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"t5_EpaValidity", &VALIDITY));
    

		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"t5_reason", &Reason));
		printf("\nt5_reason: %s\n",Reason);fflush(stdout);
		if(Reason!=NULL && tc_strlen(Reason)>0)
		{
			printf("Reason found=%s\n",Reason);fflush(stdout);
			
			tc_strdup(Reason,&ReasonDup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_reasonSet",ReasonDup,&LovDescription ));
			
			tc_strdup(LovDescription,&ReasonDup);
			printf("ReasonDup found=%s\n",ReasonDup);fflush(stdout);
			
		}
        
		
		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"t5_Agency", &EPA_Agency));
		printf("\nt5_Agency: %s\n",EPA_Agency);fflush(stdout);
        
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_Category_code4", &Factory_Code1));
		printf("\nt5_Category_code4: %s\n",Factory_Code1);fflush(stdout);
		if(Factory_Code1!=NULL && tc_strlen(Factory_Code1)>0)
		{
			printf("Factory_Code1 found=%s\n",Factory_Code1);fflush(stdout);
			
			tc_strdup(Factory_Code1,&Factory_Code1Dup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_Category_code4Set",Factory_Code1Dup,&LovDescription ));
			
			tc_strdup(LovDescription,&Factory_Code1Dup);
			printf("Factory_Code1Dup found=%s\n",Factory_Code1Dup);fflush(stdout);
			
		}
        
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_Category_code5", &Factory_Code2));
		printf("\nt5_Category_code5: %s\n",Factory_Code2);fflush(stdout);
		if(Factory_Code2!=NULL && tc_strlen(Factory_Code2)>0)
		{
			printf("Factory_Code2 found=%s\n",Factory_Code2);fflush(stdout);
			
			tc_strdup(Factory_Code2,&Factory_Code2Dup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_Category_code4Set",Factory_Code2Dup,&LovDescription ));
			
			tc_strdup(LovDescription,&Factory_Code2Dup);
			printf("Factory_Code2Dup found=%s\n",Factory_Code2Dup);fflush(stdout);
			
		}
        
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_Category_code6", &Factory_Code3));
		printf("\nt5_Category_code6: %s\n",Factory_Code3);fflush(stdout);
		if(Factory_Code3!=NULL && tc_strlen(Factory_Code3)>0)
		{
			printf("Factory_Code3 found=%s\n",Factory_Code3);fflush(stdout);
			
			tc_strdup(Factory_Code3,&Factory_Code3Dup);
			
			tc_strcpy(LovDescription,"");
			CALLAPI(lovDisplayedName("T5_Category_code4Set",Factory_Code3Dup,&LovDescription ));
			
			tc_strdup(LovDescription,&Factory_Code3Dup);
			printf("Factory_Code3Dup found=%s\n",Factory_Code3Dup);fflush(stdout);
			
		}

        
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"object_desc", &EPA_Subject));
        printf("EPA_Subject found=%s\n",EPA_Subject);fflush(stdout);
		CALLAPI(AOM_ask_value_string(epaobjects[0] ,"t5_EpaRemarks", &EPA_Remarks));
		printf("EPA_Remarks found=%s\n",EPA_Remarks);fflush(stdout);

		///////////////////////////////////////////////////////

		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"creation_date", &creationDt));
		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"owning_user", &Epa_creator));
		CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"t5_EpaAgencyList", &AgencyList));

		//CALLAPI(AOM_UIF_ask_value(epaobjects[0] ,"creation_date", &DMLEPAStampedDt));

		CALLAPI(AOM_UIF_ask_value(epaobjects[0],"date_released",&EPAReleasedate));

		CALLAPI(SA_ask_current_role(&CurrentRoleTag));
		CALLAPI(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

		getAllPlantDetails(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);

    
	  printf( "RoleName:%s\n", roleName);
      PlantName=subString(roleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  

		EPATaskRevTag1=NULLTAG;
		object_type1=NULL;
		epaTaskNo1=NULL;

		EPATaskRevTag1 = EPATaskRevision[0];
		
		
		CALLAPI(AOM_ask_value_string(EPATaskRevTag1,"object_type",&object_type1));
		printf("\n\n\t\t object_type1 is :%s",object_type1);fflush(stdout);
		if(strcmp(object_type1,"T5_EPATaskRevision")==0)
		{
			CALLAPI(AOM_ask_value_string( EPATaskRevTag1, "item_id", &epaTaskNo1));

			char* task_namedup=NULL;
			char* EPA_number_EPA=NULL;
			char* DML_number_EPA=NULL;

			tc_strdup(epaTaskNo1,&task_namedup);
            printf("\n***task_namedup :%s",task_namedup);fflush(stdout);
			EPA_number_EPA=tc_strtok(task_namedup,"_");
            printf("\n***EPA_number_EPA :%s",EPA_number_EPA);fflush(stdout);
			DML_number_EPA=tc_strtok(NULL,"_");
			printf("\n***DML_number_EPA :%s",DML_number_EPA);fflush(stdout);

			if(DML_number_EPA!=NULL)
			{
				printf("DML Number obtained from EPA Number=%s\n",DML_number_EPA);fflush(stdout);
				tc_strdup(DML_number_EPA,&DML_Number);

				tc_strcat(All_DML_Number,DML_Number);
				tc_strcat(All_DML_Number,";");
							
				//18PM001002
				if (tc_strstr(DML_Number,"AM")!=NULL)
				{
					printf("\n The task is AMDML");fflush(stdout);
					tc_strdup("APL DML Revision",&Revision_type_DML);
				}
				else
				{
					printf("\n The task is ERC DML");fflush(stdout);
					tc_strdup("ERC DML Revision",&Revision_type_DML);
				}
				
				
				int dmlcount=0;
				CALLAPI (getQueryItemRevision_AllType(DML_number_EPA,Revision_type_DML,&dml_rev_tag_arr,&dmlcount));
				printf("\n  DML count found in Report between dates: %d \n",dmlcount); fflush(stdout);
				
				if (dmlcount>0 )
				{
					tag_t dml_rev_tag=NULLTAG;
					dml_rev_tag=dml_rev_tag_arr[0];

					CALLAPI(AOM_UIF_ask_value(dml_rev_tag,"date_released",&DMLReleasedate))
					printf("\n DMLReleasedate: %s ", DMLReleasedate);fflush(stdout);
					
					if(DMLReleasedate!=NULL)
					{
						tc_strdup(DMLReleasedate,&DMLReleasedateDup);
						tc_strcat(All_DML_Number_Release,DMLReleasedateDup);
						
					} 
					
				}
	
				              
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,DML_number_EPA));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"ERC Release Date    :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_Release));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"APL Release Date    :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_Release));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"STD Release Date    :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_Release));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"REASON OF EPA         :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPAReasonDup));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA STATUS           :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_StatusDup));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"CREATOR              :"));
			    CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_creator));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Validity            :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,VALIDITY));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"CREATION DATE        :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,creationDt));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Factory Code 1      :"));
                CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Factory_Code1Dup));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"STDSI RELZ DATE      :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPAReleasedate));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Factory Code 2      :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Factory_Code2Dup));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Factory Code 3     :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Factory_Code3Dup));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"VALIDITY REMARKS     :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,VALIDITY_REMARKS));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"REASON               :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Reason));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Subject          :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Subject));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"REMARKS              :"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Remarks));
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Agency           : "));
                CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Agency));

				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"==== ========================================= ========== ====================================================== ===================================================== ============ ================== ================ ================= ======================"));
				
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"SRL"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA TASK"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DESIGN GRP"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"PART UNDER EPA"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"REV;SEQ"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"COLOUR_IND"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"COLOUR PART"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"PART DESCRIPTION"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA STATUS"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"STDSI RELZ DATE"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"CREATOR"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"CREATION DATE"));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"IMMIDIATE F PARENTS"));
				
				
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"==== ========================================= ========== ====================================================== ===================================================== ============ ================== ================ ================= ======================"));
				

				
			}

		}
	
		for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
		{
			EPATaskRevTag=NULLTAG;
			object_type=NULL;
			epaTaskNo=NULL;
			char *epaTaskNo=NULL;
			char **DesignGroupList;
			int num=0;
			int k1=0;
			char *DesignGrp=NULL;
			char *DesignGrpTask=NULL;
			char *TaskCreated_by=NULL;
			char *TaskCreation_dt=NULL;

			DesignGrp=MEM_alloc(100);
			DesignGrpTask=MEM_alloc(100);	
			tc_strcpy(DesignGrpTask,"");

			EPATaskRevTag = EPATaskRevision[TaskCnt];

			CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
			printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
			if(strcmp(object_type,"T5_EPATaskRevision")==0)
			{
				CALLAPI(AOM_ask_value_string( EPATaskRevTag, "item_id", &epaTaskNo));

				CALLAPI(AOM_ask_value_strings(EPATaskRevTag,"t5_crdesigngroup",&num,&DesignGroupList));
									 
				 for (k1=0;k1<num;k1++)
				 {
					 tc_strcpy(DesignGrp,"");
					 tc_strdup(DesignGroupList[k1],&DesignGrp);
					 printf("\n  DesignGrp : %s \n",DesignGrp); fflush(stdout);
					 
					 tc_strcat(DesignGrpTask,DesignGrp);
					 tc_strcat(DesignGrpTask,";");
				 }

				 CALLAPI(AOM_UIF_ask_value(EPATaskRevTag ,"owning_user",&TaskCreated_by));
				printf("Task TaskCreated_by found =%s\n",TaskCreated_by);fflush(stdout);
				
				
				CALLAPI(AOM_UIF_ask_value(EPATaskRevTag ,"creation_date",&TaskCreation_dt));
				printf("Task creation_date found =%s\n",TaskCreation_dt);fflush(stdout);
				TaskCreation_dt=tc_strtok(TaskCreation_dt," ");
				
				printf("Start Printing");fflush(stdout);
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				sprintf(serial_num,"\n,%d",(k+1));
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,serial_num);			
				

				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,epaTaskNo));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,DesignGrpTask));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_StatusDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPAReleasedate));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,TaskCreated_by));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,TaskCreation_dt));
				
				
				PartTags = NULLTAG;
				PartCnt =0;
				CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
					
					int j=0;
					for (j=0;j<PartCnt ;j++ )
					{
						tag_t part_rev_tag = NULLTAG;
				   
						part_rev_tag=PartTags[j];
																	
						/**********Print the Part description in File */
						
						//Part properties
						char       	*PartNumberS                    		= NULL;
						char        *RevisionS                              = NULL;
						int        	SequenceS                           	= 0;
						char        *PartSeq                              	= NULL;
						char        *PartColourInd	                     	= NULL;
						char        *PartReleaseStats                      	= NULL;
						char 		*PartDescription						= NULL;
						
						PartSeq=MEM_alloc(10);
									


						CALLAPI(AOM_ask_value_string(part_rev_tag,"item_id",&PartNumberS));
						printf("\n  part-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);


						CALLAPI (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
						printf("\n  part-Rev RevisionS : %s \n",RevisionS); fflush(stdout);

						CALLAPI (AOM_ask_value_int(part_rev_tag,"sequence_id",&SequenceS));
						printf("\n  part-Rev SequenceS : %d \n",SequenceS); fflush(stdout);

						
						CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDescription));
						printf("\n    part-Rev PartDescription : %s \n",PartDescription); fflush(stdout);
						if (PartDescription==NULL)
						{
						 tc_strdup("NA",&PartDescription);
						}

						

				
						/*Report Generation for EPA parts */
						printf("Start Printing for EPA parts");fflush(stdout);
						setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNumberS));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,RevisionS));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartColourInd));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartDescription));
						/*Report Generation END for EPA parts */
					}
				
				
				}
			}
		}

		//Net DIff
		k=0;
		CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
		CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"STRUCTURE CHANGES"));
		CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"-----------------"));

		CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"SRL"));
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"PART UNDER EPA"));
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"REV;SEQ"));		
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"PART DESCRIPTION"));
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"NEW Quantity"));
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"OLD Quantity"));
		CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"CS"));
		
		TaskCnt=0;
		for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
		{
		
			EPATaskRevTag=NULLTAG;
			EPATaskRevTag = EPATaskRevision[TaskCnt];

			object_type=NULL;
			epaTaskNo=NULL;

			CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
			printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
			if(strcmp(object_type,"T5_EPATaskRevision")==0)
			{
				CALLAPI(AOM_ask_value_string( EPATaskRevTag, "item_id", &epaTaskNo));

				PartTags = NULLTAG;
				PartCnt =0;
				CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
				if (PartCnt>0)
				{
					
					int j=0;
					for (j=0;j<PartCnt ;j++ )
					{
						tag_t part_rev_tag = NULLTAG;
				   
						part_rev_tag=PartTags[j];
																	
						/**********Print the Part description in File */
						
						//Part properties
						char *PartNumberS                    		= NULL;
						char *RevisionS                             = NULL;
						char *PartSeq                              	= NULL;
						char *PartCS	                     		= NULL;
						char *PartReleaseStats                      = NULL;
						char *PartDescription						= NULL;
					    char *ParentCS                              = NULL;
						char *Prevrule                              = NULL;
						char *Pclosurerule                          = NULL;
						char *Pchildcs                              = NULL;
						PartSeq=MEM_alloc(10);
									


						CALLAPI(AOM_ask_value_string(part_rev_tag,"item_id",&PartNumberS));
						printf("\n  part-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);


						CALLAPI (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
						printf("\n  part-Rev RevisionS : %s \n",RevisionS); fflush(stdout);

						
						CALLAPI (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDescription));
						printf("\n    part-Rev PartDescription : %s \n",PartDescription); fflush(stdout);
						if (PartDescription==NULL)
						{
						 tc_strdup("NA",&PartDescription);
						}
                          
                        
						tm_getSTDReleasedCtxt(PlantName,&Prevrule,&Pclosurerule,&Pchildcs,&ParentCS);
						CALLAPI (AOM_ask_value_string(part_rev_tag,ParentCS,&PartCS));
						printf("\n : part-Rev PartCS : %s \n",PartCS); fflush(stdout);
				
						/*Report Generation for EPA parts */
						printf("Start Printing for EPA parts");fflush(stdout);
						setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,"\n");

						CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						sprintf(serial_num,"\n,%d",(j+1));
						setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,serial_num);	

					
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNumberS));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,RevisionS));
						PartDescription = remove_specialCharDesc(PartDescription);
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartDescription));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
						CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartCS));
						/*Report Generation END for EPA parts */

						if(tc_strstr(RevisionS,"NR") == NULL)
						{
							//SETTING BOM WIONDOW FOR LATEST RVISION
							tag_t window =NULLTAG;
							tag_t	top_line		=NULLTAG;
							tag_t  *children2=NULLTAG;
							int nn=0;
							tag_t	All_item_tag = NULLTAG;
							tag_t	*rev_list	= NULLTAG;
							tag_t	rule		=NULLTAG;
							//tag_t Closrule =NULLTAG;
							PIE_scope_t scope;
							int n_closure_tags;
							tag_t *closure_tags;
							tag_t closure_tag;
							int flagRevRule=0,flagClosureRule=0;
							int ERCRelFlag=0;
							int count_status=0;
							int jk=0;
							char *rev_idd		= NULL;
							tag_t *status_lst = NULLTAG;
							char *status_name		= NULL;
							int childIterator =0;
							int iChildItemTag=0;
							tag_t	t_ChildItemRev = NULLTAG;

							char* Prt_DR=NULL;
							char* Prt_Tp=NULL;
							char* part_Rev=NULL;
							char* partLC=NULL;
							char* Revrule=NULL;
							char* Clorrule=NULL;
							char* PlantCS=NULL;
							

							if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
							//if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
							//if(CFM_find( "ERC release and above APLC", &rule )!=ITK_ok)PrintErrorStack();
							
                            tm_getSTDReleasedCtxt(PlantName,&Revrule,&Clorrule,&PlantCS,&ParentCS);
							if(CFM_find(Revrule, &rule )!=ITK_ok)PrintErrorStack();
							if (rule != NULLTAG)
							{
								printf("\nFind revRule\n");
								fflush(stdout);
								flagRevRule = 1;
							}
							if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();

							scope = PIE_TEAMCENTER;
							CALLAPI(PIE_find_closure_rules2(Clorrule, scope, &n_closure_tags, &closure_tags));
							printf("\n n_closure_tags:%d ..............", n_closure_tags);
							fflush(stdout);
							if (n_closure_tags == 1)
							{
								closure_tag = closure_tags[0];
								flagClosureRule = 1;
							}
							if(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL)!=ITK_ok)PrintErrorStack();	
							printf("\n flagClosureRule=>[%d] ", flagClosureRule);
							fflush(stdout);
							printf("\n flagRevRule=>[%d] ", flagRevRule);
							fflush(stdout);						
							if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
							//if(BOM_set_window_sort_compare_fn (window, (void *)bom_sort_function, NULL)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_top_line (window, NULLTAG,part_rev_tag, NULLTAG, &top_line)!=ITK_ok)PrintErrorStack();
							printf("\n inside bom_window-----555\n"); fflush(stdout);
							if(BOM_line_ask_child_lines (top_line, &nn, &children2));
							printf("\n\n\t\t No of child objects are n 555 : %d\n",nn);fflush(stdout);

							tag_t			AssyPreTag			= NULLTAG;

							tm_fnd_Prev_Official_Revision_Part(PartNumberS,part_rev_tag,&AssyPreTag);
							
							if(AssyPreTag)
							{
								//SETTING BOM WIONDOW FOR LATEST RVISION
								tag_t window_prev =NULLTAG;
								tag_t	rule1		=NULLTAG;
								tag_t	top_line_prev		=NULLTAG;
								int n=0;
								tag_t  *children1=NULLTAG;
                                PIE_scope_t scope;
								int n_closure_tags;
								tag_t *closure_tags;
								tag_t closure_tag;
								int flagRevRule=0,flagClosureRule=0;

								if(BOM_create_window (&window_prev)!=ITK_ok)PrintErrorStack();
								//if(CFM_find( "Latest Working", &rule1 )!=ITK_ok)PrintErrorStack();
								//if(CFM_find( "ERC release and above APLC", &rule1 )!=ITK_ok)PrintErrorStack();
								tm_getSTDReleasedCtxt(PlantName,&Revrule,&Clorrule,&PlantCS,&ParentCS);
								if(CFM_find(Revrule, &rule1 )!=ITK_ok)PrintErrorStack();
								if (rule1 != NULLTAG)
								{
									printf("\nFind revRule\n");
									fflush(stdout);
									flagRevRule = 1;
								}
								if(BOM_set_window_config_rule( window_prev, rule1 )!=ITK_ok)PrintErrorStack();
								scope = PIE_TEAMCENTER;
								CALLAPI(PIE_find_closure_rules2(Clorrule, scope, &n_closure_tags, &closure_tags));
								printf("\n n_closure_tags:%d ..............", n_closure_tags);
								fflush(stdout);
								if (n_closure_tags == 1)
								{
									closure_tag = closure_tags[0];
									flagClosureRule = 1;
								}
								if(BOM_window_set_closure_rule(window_prev,closure_tag,0,NULL,NULL)!=ITK_ok)PrintErrorStack();	
								printf("\n flagClosureRule=>[%d] ", flagClosureRule);
								fflush(stdout);
								printf("\n flagRevRule=>[%d] ", flagRevRule);
								fflush(stdout);
								if(BOM_set_window_pack_all (window_prev, false)!=ITK_ok)PrintErrorStack();
								//if(BOM_set_window_sort_compare_fn (window, (void *)bom_sort_function, NULL)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_top_line (window_prev, NULLTAG, AssyPreTag, NULLTAG, &top_line_prev)!=ITK_ok)PrintErrorStack();
								printf("\n inside bom_window-----444\n"); fflush(stdout);
								n=0;
								if(BOM_line_ask_child_lines (top_line_prev, &n, &children1));
								printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

								//COMPARING BOM HERE.
								//if(BOM_compare_execute(NULLTAG, top_line, top_line_prev,BOM_std_compare_single_level_seq_name , BOM_compare_output_report)!=ITK_ok)PrintErrorStack();
								if(BOM_compare_execute(NULLTAG, top_line, top_line_prev,"IMAN_bcm_ext_var_level" , BOM_compare_output_report)!=ITK_ok)PrintErrorStack();
								printf("\n after compair..11111\n");fflush(stdout);
								//printf("\n difference in  :: %s =============    %s\n",SVRname,SVR);fflush(stdout); 
								int report_length = 0;
								int report_width = 0;
								int column_spacer = 0;
								int column_count = 0;
								int* column_width = 0;
								
								char** report_lines =NULL;
								tag_t* report_items=NULL;
								int ii =0,j=0;
								char* line=NULL;
								printf("\n DMLPrint:after compair..\n");fflush(stdout);

								BOM_compare_report(top_line, &report_length, &report_lines,&report_items);
								printf("\n DMLPrint:after compair..\n");fflush(stdout);
								if(report_length >0)
								{
									BOM_compare_report_size(top_line,&report_width,&column_spacer,&column_count,&column_width );
									printf("\n Report length %d report details %d %d %d ------>> %d %d %d \n", report_length,report_width,column_spacer,column_count,column_width[0],column_width[1],column_width[2],column_width[3]);
                                    

									for(ii = 1; ii < report_length; ii++)
									{
										printf("\n DMLPrint:Line is: %s , Line nos %d , Report length %d\n", report_lines[ii],ii,report_length);fflush(stdout); 
									}
									int Col_1_Start=0;
									int Col_1_End=						column_width[0];
									int Col_2_Start=	Col_1_End +		column_spacer;
									int Col_2_End=		Col_2_Start +	column_width[1];
									int Col_3_Start=	Col_2_End +		column_spacer;    
									int Col_3_End=		Col_3_Start +	column_width[2];
									int Col_4_Start=	Col_3_End +		column_spacer;    
									int Col_4_End=		Col_4_Start +	column_width[3];
                                    int Col_5_Start=	Col_4_End +		column_spacer;    
									int Col_5_End=		Col_5_Start +	column_width[4];
									int Col_6_Start=	Col_5_End +		column_spacer;    
									int Col_6_End=		Col_6_Start +	column_width[5];
									int Col_7_Start=	Col_6_End +		column_spacer;    
									int Col_7_End=		Col_7_Start +	column_width[6];

									
									//char* qty=NULL;

									
									int n_item1=0;
									int i=1;
									int cnt=0,cnt1=0,cnt2=0;
									tag_t	*List = NULLTAG;
									tag_t	child_name = NULLTAG;
									int q=0;
                                    
									
									if (report_length==1)
									{
										CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"No Changes"));
									}
									printf("\n Report details column length \n %d %d \n %d %d \n %d %d \n %d %d \n %d %d \n %d %d \n %d %d \n", Col_1_Start,Col_1_End,Col_2_Start,Col_2_End,Col_3_Start,Col_3_End,Col_4_Start,Col_4_End,Col_5_Start,Col_5_End,Col_6_Start,Col_6_End,Col_7_Start,Col_7_End);fflush(stdout); 
									/*-----------------------------------------Akshata------------------------------------------------------*/
  
									for(ii = 1; ii < report_length; ii++)
									{
										    tag_t my_cmp_item = NULLTAG;
											my_cmp_item = report_items[ii];
										
											int count1=0;
											tag_t* bomline_list1 = NULLTAG;
											int count2 =0;
											
											char* Col1=NULL;
											char* ch = NULL;
											char* ch1 = NULL;
											char* Col2=NULL;
											char* Col3=NULL;
											char* Col4=NULL;
											char* Col5=NULL;
											char* Col6=NULL;
											char* Col7=NULL;
											char* Col2_O=NULL;
											
											char* Col1_prt=NULL;
											tag_t* bomline_list2 = NULLTAG;
											BOM_compare_list_bomlines(my_cmp_item,&count1,&bomline_list1,&count2,&bomline_list2);
											char* blItemid1 = NULL;
											char* blrev1 = NULL;
											char* blqt2 = NULL;
									        char* blqt1 = NULL;
											//char* blItemid2 = NULL;
											//char* blrev2 = NULL;
											char* qty = NULL;
											char *ChildPartDescription	= NULL;
											char *ChildPartCS  = NULL;
                                            
											// ch=(char *) MEM_alloc(column_width[2] + 20);
											// line=(char *) MEM_alloc(report_length + 100);
											// Col1=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col3=(char *) MEM_alloc( 100 * sizeof(char) );
											// ch=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col4=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col5=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col6=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2_O=(char *) MEM_alloc( 100 * sizeof(char) );
											// blqt2 = (char *) MEM_alloc(column_width[3] + 20);
											// blqt1 = (char *) MEM_alloc(column_width[3] + 20);
                                            // blqt2 = (char *)MEM_alloc(1* sizeof(char *));
                                            // blqt1 = (char *)MEM_alloc(1* sizeof(char *));
                                            // Col7 = (char *)MEM_alloc(1* sizeof(char *));
                                            // qty = (char *)MEM_alloc(1* sizeof(char *));

											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------
											line  =(char *) MEM_realloc(line,100* sizeof(char*));
											Col1  =(char *) MEM_realloc(Col1,100* sizeof(char*));
											Col2  =(char *) MEM_realloc(Col2,100* sizeof(char*));
											Col3  =(char *) MEM_realloc(Col3,100* sizeof(char*));
											Col4  =(char *) MEM_realloc(Col4,100* sizeof(char*));
											Col5  =(char *) MEM_realloc(Col5,100* sizeof(char*));
											Col6  =(char *) MEM_realloc(Col6,100* sizeof(char*));
											Col2_O=(char *) MEM_realloc(Col2_O,100* sizeof(char*));
											blqt2 =(char *) MEM_realloc(blqt2,100* sizeof(char *));
											blqt1 =(char *) MEM_realloc(blqt1,100* sizeof(char *));
											Col7  =(char *) MEM_realloc(Col7,100* sizeof(char *));
											qty   =(char *) MEM_realloc(qty,100* sizeof(char *));
											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------

											tc_strcpy (line,"");
											tc_strcpy (Col1,"");
											tc_strcpy (Col2,"");
											tc_strcpy (Col3,"");
											tc_strcpy (Col4,"");
											tc_strcpy (Col5,"");
											tc_strcpy (Col6,"");
											tc_strcpy (Col7,"");
											tc_strcpy (Col2_O,"");
											tc_strcat (line,report_lines[ii]);
											printf("\n Line is ------->>>>>>> %s , Line nos %d , Report length %d \n", line,ii,report_length);fflush(stdout); 
					
											tc_strcat (Col1,subString(line,Col_1_Start,column_width[0]));
											tc_strcat (Col2,subString(line,Col_2_Start,column_width[1]));
											tc_strcat (Col3,subString(line,Col_3_Start,column_width[2]));
											//tc_strcat (ch,subString(line,Col_3_Start,column_width[2]));
											tc_strcat (Col4,subString(line,Col_4_Start,column_width[3]));
											tc_strcat (Col5,subString(line,Col_5_Start,column_width[4]));
											tc_strcat (Col6,subString(line,Col_4_Start,column_width[3]));
											STRNG_replace_str(Col2,",",";",&Col2_O);

											//get item tag from rev
											int Col1_count=0;
											Col1_prt=NULL;
											printf("\n Col1...: %s", Col1);fflush(stdout);
											Col1_prt = strtok( Col1, " " );
											printf("\n Col1_prt...: %s", Col1_prt);fflush(stdout);
											printf("\n Col2...: %s", Col2);fflush(stdout);
											printf("\n Col2_O...: %s", Col2_O);fflush(stdout);
											printf("\n Col3...: %s", Col3);fflush(stdout);
											printf("\n Col4...: %s", Col4);fflush(stdout);
											tc_strcpy(Col5,Col4);
											printf("\n Col5...: %s", Col5);fflush(stdout);
											printf("\n Col6...: %s", Col6);fflush(stdout);
											printf("\n Col7...: %s", Col7);fflush(stdout);    
                                            
											
										    
											if((count1 && count2) && (cnt==0))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Quantity Changed : "));
												cnt++;
											}
											
											if(tc_strcmp(Col1,PartNumberS)==0)
											{
												continue;
											}
											if (!tc_strstr(Col2_O,"\\") && (count1 && count2))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col2_O));
											}
											
											printf("\n DMLPrint: Col333333:%s",Col3);fflush(stdout);
											if (!tc_strstr(Col3,"\\") && (count1 && count2))
											{
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col3));
											}
											if(count1 && count2)
											{
												
												printf("\n************** Inside quantity changed parts ************\n");fflush(stdout);
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_item_item_id",&blItemid1));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_item_revision_id",&blrev1));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_object_desc",&ChildPartDescription));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],PlantCS,&ChildPartCS));
												//CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_quantity",&blqt1));
												tc_strcpy(qty,Col4);
                                                
                                                
												char *token;
												token = strtok(qty, "->");//2->1
												tc_strcpy(blqt1,token);
                                                printf("\n##blqt1##: %s\n", blqt1);
												while (token != NULL) 
												{
													printf("%s\n", token);
													token = strtok(NULL, "->"); 
													tc_strcpy(blqt2,token);
													printf("\n##blqt2##:%s\n", blqt2);
													break;
												}
                                                
												printf("\nChild part CS : [%s] \n",ChildPartCS);fflush(stdout);
												printf("\nPart-Rev ChildPartDescription : %s \n",ChildPartDescription); fflush(stdout);
												printf("\nCurrent bl item ===>%s %s",blItemid1,blrev1);fflush(stdout);
												printf("\nCurrent bl blqt1 ===>%s",blqt1);fflush(stdout);
												printf("\nPrev bl blqt2 ===>%s",blqt2);fflush(stdout);
																																	
												ChildPartDescription = remove_specialCharDesc(ChildPartDescription);
												printf("\n*******ChildPartDescription******** : %s \n",ChildPartDescription); fflush(stdout);
												tc_strcpy(Col4,ChildPartDescription);
                                                if (Col4 == NULL)
												{
													tc_strcpy(Col4,"NA");
													
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col4));
																								
											}
											if((!tc_strstr(Col5,"\\")) && (!tc_strstr(Col6,"\\")) && (count1 && count2))
											{
                                                tc_strcpy(Col5,blqt1);
												tc_strcpy(Col6,blqt2);
												printf("\nCol5 : %s",Col5);fflush(stdout);
												printf("\nCol6 : %s",Col6);fflush(stdout);
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col5));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col6));
												
											}
											if((!tc_strstr(Col7,"\\")) && (count1 && count2))
											{
												
												tc_strcpy(Col7,ChildPartCS);
												printf("\nCol7 : %s",Col7);fflush(stdout);
												if (Col7 == NULL)
												{
														tc_strdup("NA",&Col7);
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col7));	
												printf("\nData1 <%s> \n", Col1);fflush(stdout); 
											    printf("\nData2 <%s> \n", Col2);fflush(stdout); 
											    printf("\nData3 <%s> \n", Col3);fflush(stdout); 
											    printf("\nData4 <%s> \n", Col4);fflush(stdout); 
												printf("\nData5 <%s> \n", Col5);fflush(stdout); 
												printf("\nData6 <%s> \n", Col6);fflush(stdout); 
												printf("\nData7 <%s> \n", Col7);fflush(stdout);
											}
											
												
									}
									
									
									for(ii = 1; ii < report_length; ii++)
									{
											//line=report_lines[ii];
											tag_t my_cmp_item = NULLTAG;
											my_cmp_item = report_items[ii];
										    
											char* Col1=NULL;
											char* ch = NULL;
											//char* ch1 = NULL;
											char* Col2=NULL;
											char* Col3=NULL;
											char* Col4=NULL;
											char* Col5=NULL;
											char* Col6=NULL;
											char* Col7=NULL;
											char* Col2_O=NULL;
											char* Col1_prt=NULL;

											int count1=0;
											tag_t* bomline_list1 = NULLTAG;
											int count2 =0;
											tag_t* bomline_list2 = NULLTAG;
											BOM_compare_list_bomlines(my_cmp_item,&count1,&bomline_list1,&count2,&bomline_list2);
											char* blItemid1 = NULL;
											char* blrev1 = NULL;
											char* blqt2 = NULL;
									        char* blqt1 = NULL;
											char* qty = NULL;
											char *ChildPartDescription	= NULL;
											char *ChildPartCS  = NULL;
											line=(char *) MEM_alloc(report_length + 100);
											
											// Col1=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col3=(char *) MEM_alloc( 100 * sizeof(char) );
											// ch=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col4=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col5=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col6=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2_O=(char *) MEM_alloc( 100 * sizeof(char) );
											
											// blqt2 = (char *)MEM_alloc(1* sizeof(char *));
											// blqt1 = (char *)MEM_alloc(1* sizeof(char *));
											// Col7 = (char *)MEM_alloc(1* sizeof(char *));
											// qty = (char *)MEM_alloc(1* sizeof(char *));

											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------
											line  =(char *) MEM_realloc(line,100* sizeof(char*));
											Col1  =(char *) MEM_realloc(Col1,100* sizeof(char*));
											Col2  =(char *) MEM_realloc(Col2,100* sizeof(char*));
											Col3  =(char *) MEM_realloc(Col3,100* sizeof(char*));
											Col4  =(char *) MEM_realloc(Col4,100* sizeof(char*));
											Col5  =(char *) MEM_realloc(Col5,100* sizeof(char*));
											Col6  =(char *) MEM_realloc(Col6,100* sizeof(char*));
											Col2_O=(char *) MEM_realloc(Col2_O,100* sizeof(char*));
											blqt2 =(char *) MEM_realloc(blqt2,100* sizeof(char *));
											blqt1 =(char *) MEM_realloc(blqt1,100* sizeof(char *));
											Col7  =(char *) MEM_realloc(Col7,100* sizeof(char *));
											qty   =(char *) MEM_realloc(qty,100* sizeof(char *));
											ch    =(char *) MEM_realloc(qty,100* sizeof(char *));
											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------

											
											tc_strcpy (line,"");
											tc_strcpy (Col1,"");
											tc_strcpy (Col2,"");
											tc_strcpy (Col3,"");
											tc_strcpy (ch,"");
										//	tc_strcpy (ch1,"");
											tc_strcpy (Col4,"");
											tc_strcpy (Col5,"");
											tc_strcpy (Col6,"");
                                            tc_strcpy (Col7,"");
											tc_strcpy (Col2_O,"");
											tc_strcat (line,report_lines[ii]);
											printf("\n Line is ------->>>>>>> %s , Line nos %d , Report length %d \n", line,ii,report_length);fflush(stdout); 
					
											tc_strcat (Col1,subString(line,Col_1_Start,column_width[0]));
											tc_strcat (Col2,subString(line,Col_2_Start,column_width[1]));
											tc_strcat (Col3,subString(line,Col_3_Start,column_width[2]));
											tc_strcat (ch,subString(line,Col_3_Start,column_width[2]));
											tc_strcat (Col4,subString(line,Col_4_Start,column_width[3]));
											tc_strcat (Col5,subString(line,Col_5_Start,column_width[4]));
											tc_strcat (Col6,subString(line,Col_4_Start,column_width[3]));
											STRNG_replace_str(Col2,",",";",&Col2_O);
											
											//get item tag from rev
											int Col1_count=0;
											Col1_prt=NULL;
											printf("\n Col1...: %s", Col1);fflush(stdout);
											Col1_prt = strtok( Col1, " " );
											printf("\n Col1_prt...: %s", Col1_prt);fflush(stdout);
											printf("\n Col2...: %s", Col2);fflush(stdout);
											printf("\n Col2_O...: %s", Col2_O);fflush(stdout);
											printf("\n Col3...: %s", Col3);fflush(stdout);
											printf("\n Col4...: %s", Col4);fflush(stdout);
											tc_strcpy(Col5,Col4);
											printf("\n Col5...: %s", Col5);fflush(stdout);
											printf("\n Col6...: %s", Col6);fflush(stdout);
											printf("\n Col7...: %s", Col7);fflush(stdout);

                                            if((count1 && !count2) && (cnt1==0))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
									            CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Added Parts : "));
												cnt1++;
											}
											if(tc_strcmp(Col1,PartNumberS)==0)
											{
												continue;
											}
											if (!tc_strstr(Col2_O,"\\") && (count1 && !count2) && (tc_strstr(Col5,"->0")))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col2_O));
												
											}
											printf("\n DMLPrint: Col333333:%s",Col3);fflush(stdout);
											if (!tc_strstr(Col3,"\\") && (count1 && !count2) && (tc_strstr(Col5,"->0")))
											{
												Col3 = strtok(ch, "->()");
                                                printf("\n*********Col3********%s\n", Col3);
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col3));
												
											}
											if (count1 && !count2)
											{
												
												printf("\n************** Inside Added parts ************\n");fflush(stdout);
																					
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_item_item_id",&blItemid1));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_item_revision_id",&blrev1));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_rev_object_desc",&ChildPartDescription));
												CALLAPI(AOM_ask_value_string(bomline_list1[0],PlantCS,&ChildPartCS));
												//CALLAPI(AOM_ask_value_string(bomline_list1[0],"bl_quantity",&blqt1));
							                   // tc_strcpy(blqt2,"0");
												tc_strcpy(qty,Col4);
                                               
                                                
												char *token;
												token = strtok(qty, "->");//2->1
												tc_strcpy(blqt1,token);
                                                printf("\n##blqt1##: %s\n", blqt1);
												while (token != NULL) 
												{
													printf("%s\n", token);
													token = strtok(NULL, "->"); 
													tc_strcpy(blqt2,token);
													printf("\n##blqt2##:%s\n", blqt2);
													break;
												}
												printf("\nChild part CS : [%s] \n",ChildPartCS);fflush(stdout);
												printf("\nPart-Rev ChildPartDescription : %s \n",ChildPartDescription); fflush(stdout);
												printf("\nCurrent bl item ===>%s %s",blItemid1,blrev1);fflush(stdout);
												printf("\nCurrent bl blqt1 ===>%s",blqt1);fflush(stdout);
												printf("\nPrev bl blqt2 ===>%s",blqt2);fflush(stdout);
												
												ChildPartDescription = remove_specialCharDesc(ChildPartDescription);
												printf("\n*******ChildPartDescription******** : %s \n",ChildPartDescription); fflush(stdout);
												tc_strcpy(Col4,ChildPartDescription);

												printf("\nCol4 : %s",Col4);fflush(stdout);
												if (Col4 == NULL)
												{
													tc_strdup("NA",&Col4);
													//tc_strcpy(Col4,"NA");
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col4));
												printf("\nCol4 : %s",Col4);fflush(stdout);
												
                                                	
											}
                                            if((!tc_strstr(Col5,"\\")) && (!tc_strstr(Col6,"\\")) && (count1 && !count2))
											{
												tc_strcpy(Col5,blqt1);
												tc_strcpy(Col6,blqt2);
												printf("\nCol5 : %s",Col5);fflush(stdout);
												printf("\nCol6 : %s",Col6);fflush(stdout);
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col5));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col6));
												
											}
											if((!tc_strstr(Col7,"\\")) && (count1 && !count2))
											{
												
												tc_strcpy(Col7,ChildPartCS);
												printf("\nCol7 : %s",Col7);fflush(stdout);
												if (Col7 == NULL)
												{
													tc_strdup("NA",&Col7);
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col7));	
												printf("\nData1 <%s> \n", Col1);fflush(stdout); 
											    printf("\nData2 <%s> \n", Col2);fflush(stdout); 
											    printf("\nData3 <%s> \n", Col3);fflush(stdout); 
											    printf("\nData4 <%s> \n", Col4);fflush(stdout); 
												printf("\nData5 <%s> \n", Col5);fflush(stdout); 
												printf("\nData6 <%s> \n", Col6);fflush(stdout);
												printf("\nData7 <%s> \n", Col7);fflush(stdout); 
												
											}
											
													
									}
								    
									for(ii = 1; ii < report_length; ii++)
									{
											//line=report_lines[ii];
											tag_t my_cmp_item = NULLTAG;
											my_cmp_item = report_items[ii];
										
											int count1=0;
											tag_t* bomline_list1 = NULLTAG;
											int count2 =0;
											tag_t* bomline_list2 = NULLTAG;
											BOM_compare_list_bomlines(my_cmp_item,&count1,&bomline_list1,&count2,&bomline_list2);
											
											char* Col1=NULL;
											char* ch = NULL;
											//char* ch1 = NULL;
											char* Col2=NULL;
											char* Col3=NULL;
											char* Col4=NULL;
											char* Col5=NULL;
											char* Col6=NULL;
											char* Col7=NULL;
											char* Col2_O=NULL;
											char* Col1_prt=NULL;
											char* blItemid2 = NULL;
											char* blrev2 = NULL;
											char* blqt2 = NULL;
									        char* blqt1 = NULL;
											char* qty = NULL;
											char *ChildPartDescription	= NULL;
											char *ChildPartCS  = NULL;	

                                            // line=(char *) MEM_alloc(report_length + 100);
											// Col1=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col3=(char *) MEM_alloc( 100 * sizeof(char) );
											// ch=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col4=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col5=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col6=(char *) MEM_alloc( 100 * sizeof(char) );
											// Col2_O=(char *) MEM_alloc( 100 * sizeof(char) );
											// blqt2 = (char *) MEM_alloc(column_width[3] + 20);
											// blqt1 = (char *) MEM_alloc(column_width[3] + 20);
                                            // blqt2 = (char *)MEM_alloc(1* sizeof(char *));
                                            // blqt1 = (char *)MEM_alloc(1* sizeof(char *));
                                            // Col7 = (char *)MEM_alloc(1* sizeof(char *));
                                            // qty = (char *)MEM_alloc(1* sizeof(char *));
											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------
											line  =(char *) MEM_realloc(line,100* sizeof(char*));
											Col1  =(char *) MEM_realloc(Col1,100* sizeof(char*));
											Col2  =(char *) MEM_realloc(Col2,100* sizeof(char*));
											Col3  =(char *) MEM_realloc(Col3,100* sizeof(char*));
											Col4  =(char *) MEM_realloc(Col4,100* sizeof(char*));
											Col5  =(char *) MEM_realloc(Col5,100* sizeof(char*));
											Col6  =(char *) MEM_realloc(Col6,100* sizeof(char*));
											Col2_O=(char *) MEM_realloc(Col2_O,100* sizeof(char*));
											blqt2 =(char *) MEM_realloc(blqt2,100* sizeof(char *));
											blqt1 =(char *) MEM_realloc(blqt1,100* sizeof(char *));
											Col7  =(char *) MEM_realloc(Col7,100* sizeof(char *));
											qty   =(char *) MEM_realloc(qty,100* sizeof(char *));
											ch    =(char *) MEM_realloc(qty,100* sizeof(char *));
											//------------------------------changes done for TCUA/CR/PLM SYS/PLM/24/0051 --------------------------------------------------
                                            
											tc_strcpy (line,"");
											tc_strcpy (Col1,"");
											tc_strcpy (Col2,"");
											tc_strcpy (Col3,"");
											tc_strcpy (ch,"");
											//tc_strcpy (ch1,"");
											tc_strcpy (Col4,"");
											tc_strcpy (Col5,"");
											tc_strcpy (Col6,"");
											tc_strcpy (Col7,"");
											tc_strcpy (Col2_O,"");
											tc_strcat (line,report_lines[ii]);
											printf("\n Line is ------->>>>>>> %s , Line nos %d , Report length %d \n", line,ii,report_length);fflush(stdout); 
					
											tc_strcat (Col1,subString(line,Col_1_Start,column_width[0]));
											tc_strcat (Col2,subString(line,Col_2_Start,column_width[1]));
											tc_strcat (Col3,subString(line,Col_3_Start,column_width[2]));
											tc_strcat (ch,subString(line,Col_3_Start,column_width[2]));
											tc_strcat (Col4,subString(line,Col_4_Start,column_width[3]));
											tc_strcat (Col5,subString(line,Col_5_Start,column_width[4]));
											tc_strcat (Col6,subString(line,Col_4_Start,column_width[3]));

											STRNG_replace_str(Col2,",",";",&Col2_O);

											//get item tag from rev
											int Col1_count=0;
											Col1_prt=NULL;
											printf("\n Col1...: %s", Col1);fflush(stdout);
											Col1_prt = strtok( Col1, " " );
											printf("\n Col1_prt...: %s", Col1_prt);fflush(stdout);
											printf("\n Col2...: %s", Col2);fflush(stdout);
											printf("\n Col2_O...: %s", Col2_O);fflush(stdout);
											printf("\n Col3...: %s", Col3);fflush(stdout);
											printf("\n Col4...: %s", Col4);fflush(stdout);
											tc_strcpy(Col5,Col4);
											printf("\n Col5...: %s", Col5);fflush(stdout);
											printf("\n Col6...: %s", Col6);fflush(stdout);
											printf("\n Col7...: %s", Col7);fflush(stdout);
                                            if((!count1 && count2) && (cnt2==0))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
									            CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Deleted Parts : "));
									            cnt2++;
											}
											if(tc_strcmp(Col1,PartNumberS)==0)
											{
												continue;
											}
											if (!tc_strstr(Col2_O,"\\") && (!count1 && count2) && (tc_strstr(Col5,"0->")))
											{
												CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt," "));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col2_O));
											}
											printf("\n DMLPrint: Col333333:%s",Col3);fflush(stdout);
											if (!tc_strstr(Col3,"\\") && (!count1 && count2) && (tc_strstr(Col5,"0->")))
											{
												Col3 = strtok(ch, "()->");
                                                printf("\n*********Col3********%s\n", Col3);
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col3));
											}
											if (!count1 && count2)
											{
												printf("\n************** Inside deleted parts ************\n");fflush(stdout);
																					
												CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_item_item_id",&blItemid2));
												CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_rev_item_revision_id",&blrev2));
												CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_rev_object_desc",&ChildPartDescription));
												CALLAPI(AOM_ask_value_string(bomline_list2[0],PlantCS,&ChildPartCS));
                                               // CALLAPI(AOM_ask_value_string(bomline_list2[0],"bl_quantity",&blqt2));
												//tc_strcpy(blqt1,"0");
												tc_strcpy(qty,Col4);
                                               
                                                
												char *token;
												token = strtok(qty, "->");//2->1
												tc_strcpy(blqt1,token);
                                                printf("\n##blqt1##: %s\n", blqt1);
												while (token != NULL) 
												{
													printf("%s\n", token);
													token = strtok(NULL, "->"); 
													tc_strcpy(blqt2,token);
													printf("\n##blqt2##:%s\n", blqt2);
													break;
												}

												printf("\nChild part CS : [%s] \n",ChildPartCS);fflush(stdout);
												printf("\nPart-Rev ChildPartDescription : %s \n",ChildPartDescription); fflush(stdout);
												printf("\nCurrent bl item ===>%s %s",blItemid2,blrev2);fflush(stdout);
                                                printf("\nCurrent bl blqt1 ===>%s",blqt1);fflush(stdout);
												printf("\nPrev bl blqt2 ===>%s",blqt2);fflush(stdout);
												
												ChildPartDescription = remove_specialCharDesc(ChildPartDescription);
												printf("\n*******ChildPartDescription******** : %s \n",ChildPartDescription); fflush(stdout);
												tc_strcpy(Col4,ChildPartDescription);
												
												printf("\nCol4 : %s",Col4);fflush(stdout);
											    
												if (Col4 == NULL)
												{
													tc_strdup("NA",&Col4);
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col4));
												
											}	
											if((!tc_strstr(Col5,"\\")) && (!tc_strstr(Col6,"\\")) && (!count1 && count2))
											{
												tc_strcpy(Col5,blqt1);
												tc_strcpy(Col6,blqt2);
												printf("\nCol5 : %s",Col5);fflush(stdout);
												printf("\nCol6 : %s",Col6);fflush(stdout);
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col5));
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col6));
											}								
											if((!tc_strstr(Col7,"\\")) && (!count1 && count2))
											{
												
                                                tc_strcpy(Col7,ChildPartCS);
												printf("\ncol7 : %s",Col7);fflush(stdout);
												if (Col7==NULL)
												{
													tc_strdup("NA",&Col7);
												}
												CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Col7));	
												printf("\nData1 <%s> \n", Col1);fflush(stdout); 
											    printf("\nData2 <%s> \n", Col2);fflush(stdout); 
											    printf("\nData3 <%s> \n", Col3);fflush(stdout); 
											    printf("\nData4 <%s> \n", Col4);fflush(stdout); 
												printf("\nData5 <%s> \n", Col5);fflush(stdout); 
												printf("\nData6 <%s> \n", Col6);fflush(stdout);
												printf("\nData7 <%s> \n", Col7);fflush(stdout); 
											}
											
											
									}
									
									/*-----------------------------------------------------------------------------------------------*/
										if(report_lines) MEM_free(report_lines);
										if(line) MEM_free(line);
										if(report_items) MEM_free(report_items);

										if(column_width) MEM_free(column_width);
								}
								else
								{
									ERCRelFlag=1;
									CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"NO BOM Difference."));
									printf("\n NO BOM Difference...break...\n");fflush(stdout);
								}
							}
												 
														
						}


					}
				
				
				}
			}	
		
		
		}

	}

	

	return ifail;
}

	
int GenerateDetailReport(tag_t *epaobjects, int size,char *Report_Type,char *Datefrom,char *Dateto,char *skipPart,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	
	
	int k=0;
	char *serial_num=NULL;
	char *dml_count=NULL;
	char *Epa_Number=NULL;
	char *DML_Number=NULL;
	char *All_DML_Number=NULL;
	char *All_DML_Number_DR=NULL;
	char *All_DML_Number_Desc=NULL;
	char *All_DML_Number_Release=NULL;
	char *DMLEPAStampedDt=NULL;
	char *Epa_creator=NULL;
	char *Epa_Validity=NULL;
	char *Epa_Description=NULL;
	char *EPA_Subject=NULL;
	char *Epa_Class=NULL;
	char *Epa_Aggregate=NULL;
	char *EPA_Plant=NULL;
	char *EPA_PlantDup=NULL;
	char *EPA_Status=NULL;
	char *EPA_StatusDup=NULL;
	char *EPAReason=NULL;
	char *EPAReasonDup=NULL;
	char *EPA_Type=NULL;
	char *EPA_TypeDup=NULL;
	char *EPA_Category=NULL;
	char *EPA_CategoryDup=NULL;
	char *EPA_Factory=NULL;
	char *EPA_FactoryDup=NULL;
	char *MBPARemarks=NULL;
	char *TSRemarks=NULL;
	char *EPA_Project=NULL;
	char *EPA_Closure=NULL;
	char *EPA_Closure_date=NULL;
	char *EPA_Closure_remark=NULL;
	char *EPA_Closure_remark_dup=NULL;
	char *EPA_Targetdt=NULL;
	char *EPA_Priority=NULL;
	char *closure_comnt= NULL;
	char *closure_comnt_dup= NULL;
	char *Aggregate_type= NULL;
	char *Aggregate_type_dup= NULL;
	char *Model= NULL;
	char *Model_dup= NULL;
	char *LstSmplDate= NULL;
	char *TDoIremarks= NULL;
	char *TDoIremarksDup= NULL;
	char *AgencyList= NULL;
	char *ChassisNo= NULL;
	char *MBPA_no= NULL;
	char *MBPA_desc= NULL;
	char *MBPA_desc_dup= NULL;
	char *MBPA_creator= NULL;
	char *MBPA_create_dt= NULL;
	
	char *Revision_type_DML= NULL;
	char *DMLDRstat= NULL;
	char *DMLDRstatDup= NULL;
	char *DMLDescription= NULL;
	char *DMLDescriptionDup= NULL;
	char *DMLReleasedate= NULL;
	char *DMLDescriptionDup2= NULL;
	char *DMLReleasedateDup= NULL;
	char *LovDescription=NULL;
	
	
	
	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	
	serial_num=MEM_alloc(10);
	dml_count=MEM_alloc(10);
	DML_Number=MEM_alloc(100);
	EPA_TypeDup=MEM_alloc(1000);
	EPA_CategoryDup=MEM_alloc(1000);
	EPAReasonDup=MEM_alloc(1000);
	EPA_StatusDup=MEM_alloc(1000);
	EPA_FactoryDup=MEM_alloc(1000);
	EPA_PlantDup=MEM_alloc(1000);
	DMLDRstatDup=MEM_alloc(100);
	Aggregate_type_dup=MEM_alloc(100);
	Model_dup=MEM_alloc(100);
	LovDescription=MEM_alloc(1000);
	DMLDescriptionDup=MEM_alloc(100);
	DMLDescriptionDup2=MEM_alloc(100);
	DMLReleasedateDup=MEM_alloc(100);
	All_DML_Number=MEM_alloc(1000);
	All_DML_Number_DR=MEM_alloc(1000);
	All_DML_Number_Desc=MEM_alloc(1000);
	All_DML_Number_Release=MEM_alloc(1000);
	Revision_type_DML = MEM_alloc(100);
	DMLReleasedate = MEM_alloc(100);
	closure_comnt_dup = MEM_alloc(1000);
	EPA_Closure_remark_dup = MEM_alloc(1000);
	TDoIremarksDup = MEM_alloc(500);
	MBPA_desc_dup = MEM_alloc(500);
	char* EPAReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
	
	tag_t *taskList = NULLTAG;
	tag_t *dml_rev_tag_arr = NULLTAG;
	
	
	char *DatefromDup  =NULL;
	char *DatetoDup    =NULL;
	
	DatefromDup=MEM_alloc(20);
	DatetoDup=MEM_alloc(20);
	
	
	tc_strdup(Datefrom,&DatefromDup);
	DatefromDup=tc_strtok(DatefromDup," ");
	
	tc_strdup(Dateto,&DatetoDup);
	DatetoDup=tc_strtok(DatetoDup," ");
	
	printf("After Toking =%s\n",DatefromDup);fflush(stdout);
	printf("After Toking =%s\n",DatetoDup);fflush(stdout);
			
	 
			time(&now);
			now_tm = localtime(&now);
		
			strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
			printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);
	
	
			if(tc_strcmp(Report_Type,"DateType")==0) 
			{
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"**************************************************************************************************************EPA REPORT BETWEEN DATES***********************************************************************************************************************************************************"));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"FROM DATE"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,DatefromDup));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"TO DATE"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,DatetoDup));
			}
			else if(tc_strcmp(Report_Type,"ListType")==0) 
			{ 
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"**************************************************************************************************************EPA LIST WISE REPORT***********************************************************************************************************************************************************"));
			}
			
			
			
			
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"Report fired On"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,ReportFiredDate));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"SRL"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA No"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Reason"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Creation Date"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Creator"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Validity"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Synopsis "));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Lifecycle state "));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Subject"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Class"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Aggregate"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML Count"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML Number"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML Description"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML Release Date"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"DML DR"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Type"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Category"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Status"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Agency"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Factory"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Project"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Closure"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Closure Remark"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA Released Date"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Closure Comment"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Plant"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"TRGT DATE OF INTRO"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"TDoI REMARKS"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Aggregate Type"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Model"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"CHASSIS NO"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"EPA PRIORITY"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"LATEST SAMPLE DATE"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"MBPA NO"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"MBPA Desc"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"MBPA Creator"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"MBPA Creation Date"));
			if (tc_strcmp(skipPart,"false")==0)
			{

            CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part Under EPA"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"REV;SEQ"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part CS"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part DR Status"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part Project Code"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part Colour Indicator"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"Part Description"));
            CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"INVALID PARTS"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"REV"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"SEQ"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"VALID PARTS"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"REV"));
			CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"SEQ"));
			
			}
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
			
			
			
			
			
			for(k=0;k<size;k++)
			{
				char* Epa_Description_Dup=NULL;
				char* EPA_Subject_Dup=NULL;
				
				
				
				
				
					
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"item_id", &Epa_Number));
				printf("11111\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"creation_date", &DMLEPAStampedDt));
				printf("2222\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"owning_user", &Epa_creator));
				printf("3333\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaValidity", &Epa_Validity));
				printf("44444\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"object_desc", &Epa_Description));
				printf("5555\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_tx0Addressee", &EPA_Subject));
				printf("6666\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaClass", &Epa_Class));
				printf("7777\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_tcfAggregate", &Epa_Aggregate));
				printf("8888\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaPlantA", &EPA_Plant));
				printf("9999\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code1", &EPAReason));  //t5_EPAReason,t5_reason
				printf("11111aaa\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaStatus", &EPA_Status));
				printf("11111bbb111\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EpaType", &EPA_Type));				
				printf("11111ccc\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_Category_code4", &EPA_Factory));
				printf("11111dddd\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_MBPARemarks", &MBPARemarks));
				printf("11111eeee\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_TSRemarks", &TSRemarks));
				printf("11111fff\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_cprojectcode", &EPA_Project));
				printf("11111gggg\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"CMClosure", &EPA_Closure));
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_RemarksEPAClosure", &EPA_Closure_remark));
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_EPAClosureDate", &EPA_Closure_date));
				printf("11111hhh\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_ClosureComments", &closure_comnt));
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_TargetDtIntro", &EPA_Targetdt));
				printf("11111iii\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_ChasisTypeList", &Aggregate_type));
				printf("11111jjj\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_ModelList", &Model));
				printf("11111kkk\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_EPACategory_code1", &EPA_Category));				
				printf("11111lll\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_LstSmplDate", &LstSmplDate));
				printf("11111mmmm\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_TrgtDtIntRem", &TDoIremarks));
				printf("11111nnnn\n");fflush(stdout);
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_EpaAgencyList", &AgencyList));
				printf("11111oooo\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_ChasisNo", &ChassisNo));
				printf("11111pppp\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_WbsPriority", &EPA_Priority));
				printf("11111qqqqq\n");fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_MbpaNo", &MBPA_no));
				printf("11111rrrrr\n");fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_MbpaDesc", &MBPA_desc));
				printf("11111ssss\n");fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(epaobjects[k] ,"t5_MbpaCretor", &MBPA_creator));
				printf("11111uuuu\n");fflush(stdout);
				
				CALLAPI(AOM_UIF_ask_value(epaobjects[k] ,"t5_MbpaCreDate", &MBPA_create_dt));
				printf("11111vvvv\n");fflush(stdout);
				
				
				
				/*GETTING THE EPA TASK */
				int taskcount=0;	
				CALLAPI(AOM_ask_value_tags(epaobjects[k],"T5_DMLTaskRelation",&taskcount,&taskList));
				printf("\n No of Task Found ====>[%d]\n", taskcount);fflush(stdout);
				
				
				tc_strcpy(All_DML_Number,"");
				tc_strcpy(All_DML_Number_DR,"");
				tc_strcpy(All_DML_Number_Desc,"");
				tc_strcpy(All_DML_Number_Release,"");
				tc_strcpy(DMLReleasedateDup,"");
				
				if(taskcount>0)
				{
										
					int i;
					for(i=0;i<taskcount;i++)
					{
						char* task_name=NULL;
						char* task_namedup=NULL;
						char* EPA_number_EPA=NULL;
						char* DML_number_EPA=NULL;
						
						
						tag_t task=taskList[i];
						CALLAPI(AOM_ask_value_string(taskList[i] ,"item_id",&task_name));
						printf("Task Name found =%s\n",task_name);fflush(stdout);			
												
						tc_strdup(task_name,&task_namedup);
						EPA_number_EPA=tc_strtok(task_namedup,"_");
						DML_number_EPA=tc_strtok(NULL,"_");
						
						
						 if(DML_number_EPA!=NULL)
						{
							printf("DML Number obtained from EPA Number=%s\n",DML_number_EPA);fflush(stdout);
							tc_strdup(DML_number_EPA,&DML_Number);
							
							tc_strcat(All_DML_Number,DML_Number);
							tc_strcat(All_DML_Number,";");
							
							//18PM001002
							if (tc_strstr(DML_Number,"AM")!=NULL)
							{
							printf("\n The task is AMDML");fflush(stdout);
							tc_strdup("APL DML Revision",&Revision_type_DML);
							}
							else
							{
							printf("\n The task is ERC DML");fflush(stdout);
							tc_strdup("ERC DML Revision",&Revision_type_DML);
							}
							
							//ITK_CALL(getQueryItemRevisionEPAtask(DML_number_EPA,&dml_rev_tag,Revision_type_DML)); //Function for Query ERC DML	
							
							int dmlcount=0;
							ITK_CALL (getQueryItemRevision_AllType(DML_number_EPA,Revision_type_DML,&dml_rev_tag_arr,&dmlcount));
							printf("\n  DML count found in Report between dates: %d \n",dmlcount); fflush(stdout);
							
							if (dmlcount>0 )
							{
							    tag_t dml_rev_tag=NULLTAG;
								dml_rev_tag=dml_rev_tag_arr[0];
								
								ITK_CALL (AOM_ask_value_string(dml_rev_tag,"t5_cDRstatus",&DMLDRstat));
								printf("\n  DMLDRstat : %s \n",DMLDRstat); fflush(stdout);
								if(DMLDRstat!=NULL)
								{
								tc_strdup(DMLDRstat,&DMLDRstatDup);
								tc_strcat(All_DML_Number_DR,DMLDRstatDup);
								tc_strcat(All_DML_Number_DR,";");
								}
								
								ITK_CALL(AOM_ask_value_string(dml_rev_tag,"object_desc",&DMLDescription))
								printf("\n DMLDescription: %s ", DMLDescription);fflush(stdout);
								if(DMLDescription!=NULL)
								{
								tc_strdup(DMLDescription,&DMLDescriptionDup);
								 STRNG_replace_str(DMLDescriptionDup,",",";",&DMLDescriptionDup2);
								 tc_strcat(All_DML_Number_Desc,DMLDescriptionDup2);
								 tc_strcat(All_DML_Number_Desc,";");
								}
							
							    ITK_CALL(AOM_UIF_ask_value(dml_rev_tag,"date_released",&DMLReleasedate))
								printf("\n DMLReleasedate: %s ", DMLReleasedate);fflush(stdout);
								
								
								if(DMLReleasedate!=NULL)
								{
								tc_strdup(DMLReleasedate,&DMLReleasedateDup);
								tc_strcat(All_DML_Number_Release,DMLReleasedateDup);
								tc_strcat(All_DML_Number_Release,";");
								} 
							}
							else
							{
								printf("\n getQueryItemRevisionEPAtask:  tag is nulltag\n");fflush(stdout);
							}
						}	
						
					}
				   
				}
				
				
			
				
				
				
				
				int DMLcount=0;
				DMLcount=taskcount;
				printf("Task number found =%d\n",DMLcount);fflush(stdout);
				
				
				if(Epa_Number!=NULL){
					printf("Epa Number Obtained=%s\n",Epa_Number);fflush(stdout);		}
			   if(DMLEPAStampedDt!=NULL)  {
				  printf("t5_EpaTskCrDate found=%s\n",DMLEPAStampedDt);fflush(stdout); }
			   if(Epa_Validity!=NULL)   {
				 printf("Validity of EPA found=%s\n",Epa_Validity);fflush(stdout); }  
				if(Epa_Description!=NULL){
								   printf("Epa Description Obtained=%s\n",Epa_Description);fflush(stdout);
								   STRNG_replace_str(Epa_Description,",",";",&Epa_Description_Dup);}
				if(EPA_Subject!=NULL){
					printf("EPA Subject found=%s\n",EPA_Subject);fflush(stdout);		
					 STRNG_replace_str(EPA_Subject,",",";",&EPA_Subject_Dup);}
			   if(Epa_Class!=NULL) {
				    printf("Epa Class found=%s\n",Epa_Class);fflush(stdout);  }   
			   if(Epa_Aggregate!=NULL)   {
				  printf("Aggregate of EPA found=%s\n",Epa_Aggregate);fflush(stdout); } 

               
				tc_strcpy(EPAReleaseStats,"");
				ITK_CALL (ReleaseStatusObject(epaobjects[k],EPAReleaseStats));
				printf("EPAReleaseStats found=%s\n",EPAReleaseStats);fflush(stdout);				  
				
				tc_strcpy(EPAReasonDup,"");
				tc_strcpy(EPA_TypeDup,"");
				tc_strcpy(EPA_StatusDup,"");
				tc_strcpy(EPA_FactoryDup,"");
				tc_strcpy(EPA_PlantDup,"");
				tc_strcpy(EPA_CategoryDup,"");
				tc_strcpy(Model_dup,"");
				tc_strcpy(TDoIremarksDup,"");
				tc_strcpy(Aggregate_type_dup,"");				
				tc_strcpy(closure_comnt_dup,"");
				tc_strcpy(EPA_Closure_remark_dup,"");
				tc_strcpy(MBPA_desc_dup,"");
				
				if(EPAReason!=NULL && tc_strlen(EPAReason)>0)
				{
					printf("t5_Reason found=%s\n",EPAReason);fflush(stdout);	
					
					tc_strdup(EPAReason,&EPAReasonDup);
					printf("EPAReasonDup found=%s\n",EPAReasonDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_Category_code1Set",EPAReasonDup,&LovDescription ));
					//tc_strdup(LovDescription,&EPAReasonDup);
					
					STRNG_replace_str(LovDescription,",",";",&EPAReasonDup);	
					printf("\n replaced string=%s\n",EPAReasonDup);fflush(stdout);
					
				}
					
								
				if (EPA_Type!=NULL && tc_strlen(EPA_Type)>0)
				{
					printf("EPA_Type found=%s %d \n",EPA_Type,tc_strlen(EPA_Type));fflush(stdout);
					
					
					tc_strdup(EPA_Type,&EPA_TypeDup);
					printf("EPA_TypeDup found=%s\n",EPA_TypeDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_EpaTypeSet",EPA_TypeDup,&LovDescription ));
					
					tc_strdup(LovDescription,&EPA_TypeDup);
					
				}
						
					if (EPA_Category!=NULL && tc_strlen(EPA_Category)>0)
				{
					printf("EPA_Category found=%s %d \n",EPA_Category,tc_strlen(EPA_Category));fflush(stdout);
					
					
					tc_strdup(EPA_Category,&EPA_CategoryDup);
					printf("EPA_CategoryDup found=%s\n",EPA_CategoryDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_EPACategory_code1Set",EPA_CategoryDup,&LovDescription ));
					
					//tc_strdup(LovDescription,&EPA_CategoryDup);
					STRNG_replace_str(LovDescription,",",";",&EPA_CategoryDup);	
					printf("\n replaced string=%s\n",EPA_CategoryDup);fflush(stdout);
					
				}		
						
				if(EPA_Status!=NULL && tc_strlen(EPA_Status)>0)
				{
					printf("EPA_Status found=%s\n",EPA_Status);fflush(stdout);
					
					tc_strdup(EPA_Status,&EPA_StatusDup);
					printf("EPA_StatusDup found=%s\n",EPA_StatusDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_EpaStatusSet",EPA_StatusDup,&LovDescription ));
					
					tc_strdup(LovDescription,&EPA_StatusDup);
					
				}
				
				if(EPA_Factory!=NULL && tc_strlen(EPA_Factory)>0)
				{
					printf("EPA_Factory found=%s\n",EPA_Factory);fflush(stdout);
					
					tc_strdup(EPA_Factory,&EPA_FactoryDup);
					printf("EPA_FactoryDup found=%s\n",EPA_FactoryDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					CALLAPI(lovDisplayedName("T5_Category_code4Set",EPA_FactoryDup,&LovDescription ));
					
					tc_strdup(LovDescription,&EPA_FactoryDup);
					
				}
				
				if(EPA_Plant!=NULL && tc_strlen(EPA_Plant)>0) 
				{
				    printf("EPA_Plant found=%s\n",EPA_Plant);fflush(stdout);
					tc_strdup(EPA_Plant,&EPA_PlantDup);
					printf("EPA_PlantDup found=%s\n",EPA_PlantDup);fflush(stdout);
					tc_strcpy(LovDescription,"");
					if (tc_strstr(EPA_PlantDup,"PlantName")!=NULL)
					{
						CALLAPI(lovDisplayedName("T5_PlantName",EPA_PlantDup,&LovDescription ));
						
						tc_strdup(LovDescription,&EPA_PlantDup);
						
						
						
						ITK_CALL(PlantDisplayValue(EPA_PlantDup,&EPA_PlantDup));
						printf("Changed EPA_PlantDup found=%s\n",EPA_PlantDup);fflush(stdout);
					}
			    } 	
				
				
				 if(TDoIremarks!=NULL && tc_strlen(TDoIremarks)>0) 
				 {
				     printf("TDoIremarks found=%s\n",TDoIremarks);fflush(stdout);
					 tc_strdup(TDoIremarks,&TDoIremarksDup);
					 printf("TDoIremarksDup found=%s\n",TDoIremarksDup);fflush(stdout);
					 tc_strcpy(LovDescription,"");
					 CALLAPI(lovDisplayedName("T5_TrgtDtIntRemSet",TDoIremarksDup,&LovDescription ));
					
					tc_strdup(LovDescription,&TDoIremarksDup);
			   }
				
				
				if(MBPARemarks!=NULL){
									printf("t5_MBPARemarks found=%s\n",MBPARemarks);fflush(stdout);}
			
				if(TSRemarks!=NULL){
						printf("t5_TSRemarks found=%s\n",TSRemarks);fflush(stdout);}
				
				if(EPA_Project!=NULL)	{
					printf("EPA_Project found=%s\n",EPA_Project);fflush(stdout);}
					
					if(AgencyList!=NULL)	{
					printf("AgencyList found=%s\n",AgencyList);fflush(stdout);}
				
			
 			  	if(EPA_Closure!=NULL){
					printf("EPA_Closure found=%s\n",EPA_Closure);fflush(stdout);} 
					
				if(EPA_Closure_date!=NULL){
					printf("EPA_Closure_date found=%s\n",EPA_Closure_date);fflush(stdout);} 
					
				if(EPA_Closure_remark!=NULL){
					printf("EPA_Closure_remark found=%s\n",EPA_Closure_remark);fflush(stdout);
					STRNG_replace_str(EPA_Closure_remark,",",";",&EPA_Closure_remark_dup);
					} 
					
				
					
				if(Epa_creator!=NULL)		{
				
				printf(" Epa_creator found=%s\n",Epa_creator);fflush(stdout);}	
					      
			  
			  
			  if(EPA_Targetdt!=NULL) {
				     printf("EPA_Targetdt found=%s\n",EPA_Targetdt);fflush(stdout);
			   } 

			     if(ChassisNo!=NULL) {
				     printf("ChassisNo found=%s\n",ChassisNo);fflush(stdout);
			   } 
			   
			   
			     if(EPA_Priority!=NULL) {
				     printf("EPA_Priority found=%s\n",EPA_Priority);fflush(stdout);
			   } 
			   
				if(closure_comnt!=NULL) {
				     printf("closure_comnt found=%s\n",closure_comnt);fflush(stdout);
					 STRNG_replace_str(closure_comnt,",",";",&closure_comnt_dup);
			   }
			   
			   if(Aggregate_type!=NULL) {
				     printf("Aggregate_type found=%s\n",Aggregate_type);fflush(stdout);
					 STRNG_replace_str(Aggregate_type,",",";",&Aggregate_type_dup);
			   }
			   
			   
			   
			   if(Model!=NULL) {
				     printf("Model found=%s\n",Model);fflush(stdout);
					 STRNG_replace_str(Model,",",";",&Model_dup);
			   }
			   
			   if(LstSmplDate!=NULL) {
				     printf("LstSmplDate found=%s\n",LstSmplDate);fflush(stdout);
					
			   }
			   
			   
			   	if(MBPA_no!=NULL){
					printf("MBPA_no found=%s\n",MBPA_no);fflush(stdout);
					
					}
					
					if(MBPA_creator!=NULL){
					printf("MBPA_creator found=%s\n",MBPA_creator);fflush(stdout);
					
					}
					
					if(MBPA_create_dt!=NULL){
					printf("MBPA_create_dt found=%s\n",MBPA_create_dt);fflush(stdout);
					
					}
					
					
					if(MBPA_desc!=NULL){
					printf("MBPA_desc found=%s\n",MBPA_desc);fflush(stdout);
					STRNG_replace_str(MBPA_desc,",",";",&MBPA_desc_dup);
					}
			   
				
				/*Report Generation */
				printf("Start Printing");fflush(stdout);
				CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
				sprintf(serial_num,"\n,%d",(k+1));
				setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,serial_num);
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Number));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPAReasonDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,DMLEPAStampedDt));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_creator));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Validity));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Description_Dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPAReleaseStats));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Subject_Dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Class));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Epa_Aggregate));
				sprintf(dml_count,"%d",DMLcount);
				//setAddStrInEPAReport(buff_cnt,bufferedXmlStrOut,dml_count);
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,dml_count));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_Desc));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_Release));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,All_DML_Number_DR));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_TypeDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_CategoryDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_StatusDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,AgencyList));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_FactoryDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Project));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Closure));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Closure_remark_dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Closure_date));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,closure_comnt_dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_PlantDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Targetdt));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,TDoIremarksDup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Aggregate_type_dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,Model_dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,ChassisNo));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,EPA_Priority));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,LstSmplDate));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,MBPA_no));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,MBPA_desc_dup));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,MBPA_creator));
				CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,MBPA_create_dt));
			
				
			if (tc_strcmp(skipPart,"false")==0)
			{
			    /*GETTING THE EPA INVALID PARTS */

		/*	    tag_t *inValidPartList = NULLTAG;
			   	int invalidPartcount=0;	
				CALLAPI(AOM_ask_value_tags(epaobjects[k],"T5_EPAHasInvalidPart",&invalidPartcount,&inValidPartList));
				printf("\n No of Invalid Parts relation found ====>[%d]\n", invalidPartcount);fflush(stdout);
				
				 char* assemblyInvalid=NULL;
				  char* assemblyInvalidid=NULL;
				   assemblyInvalid=MEM_alloc(10000);
				   tc_strcpy(assemblyInvalid,"");
				
				if (invalidPartcount>0)
				{
				   int k=0;
				   
				   
				   for(k=0;k<invalidPartcount;k++)
					{
					  tag_t invalidPart=inValidPartList[k];
						if (invalidPart!=NULLTAG)
						{
						  CALLAPI(AOM_ask_value_string(invalidPart ,"item_id",&assemblyInvalidid));
						  printf("Assembly Name found for invalid part =%s\n",assemblyInvalidid);fflush(stdout);
						  tc_strcat(assemblyInvalid,assemblyInvalidid);
						  tc_strcat(assemblyInvalid,";");
						}
					}
				}
				
	*/	
				
				/*GETTING THE EPA VALID PARTS */

		/*	    tag_t *ValidPartList = NULLTAG;
			   	int validPartcount=0;	
				CALLAPI(AOM_ask_value_tags(epaobjects[k],"T5_EPAHasInvalidPart",&validPartcount,&ValidPartList));
				printf("\n No of valid Parts relation found ====>[%d]\n", validPartcount);fflush(stdout);
				
				char* assemblyValid=NULL;
				char* assemblyValidid=NULL;
				   assemblyValid=MEM_alloc(1000);
				   tc_strcpy(assemblyValid,"");
				
				if (validPartcount>0)
				{
				   int k=0;
				   
				
				   for(k=0;k<validPartcount;k++)
					{
					  tag_t validPart=ValidPartList[k];
						if (validPart!=NULLTAG)
						{
						  //CALLAPI(AOM_ask_value_string(validPart ,"t5_Assembly",&assemblyValidid));
						  CALLAPI(AOM_ask_value_string(validPart ,"item_id",&assemblyValidid));
						  printf("Assembly Name found for valid part =%s\n",assemblyValidid);fflush(stdout);
						  tc_strcat(assemblyValid,assemblyValidid);
						  tc_strcat(assemblyValid,";");
						}
					}
				}
				
				
	*/			 
		         //CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,assemblyInvalid));
				 //CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,assemblyValid));
				
				
			    int count=0;
				/* For getting Part Details */
				if(taskcount>0)
				{
					tag_t partRelatn_Type_tag = NULLTAG;
									
					int i;
					for(i=0;i<taskcount;i++)
					{
					    
						tag_t task=taskList[i];
						if (task!=NULLTAG)
						{
						
													
							ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
							if (partRelatn_Type_tag!=NULLTAG)
							{
							tag_t *part_obj_tag = NULLTAG;
							int n_parts= 0;	
							
								if ( (ifail = GRM_list_secondary_objects_only( task,partRelatn_Type_tag,&n_parts, &part_obj_tag )) != ITK_ok )
									{
											return ifail;
									}
								printf("\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
								
								 int j=0;
								if (n_parts>0)
								{
								 
								 for (j=0;j<n_parts ;j++ )
									{
									       count=count+1;
											tag_t part_rev_tag = NULLTAG;
			   
											part_rev_tag=part_obj_tag[j];
																						
											 /**********Print the Part description in File */
											
											//Part properties
											char       	*PartNumberS                    		= NULL;
											char        *RevisionS                              = NULL;
											int        	SequenceS                           	= 0;
											char        *PartSeq                              	= NULL;
											char        *PartCS                              	= NULL;
											char        *PartDRStat                          	= NULL;
											char        *PartDesignGrp                       	= NULL;
											char        *ProjectCode	                      	= NULL;
											char        *PartColourInd	                      	= NULL;
											char        *PartReleaseStats                      	= NULL;
											char 		*PartDescription						= NULL;
											char 		*PartDescriptionDup						= NULL;
											
											PartSeq=MEM_alloc(10);
											PartDescriptionDup=MEM_alloc(100);
											tc_strcpy(PartDescriptionDup,"");			

											char PlantCS[40];
											char PlantOptCS[40];
											char PlantIA[40];
											char PlantStore[40];
											char UserAgency[40];
										
											tag_t  CurrentRoleTag = NULLTAG;
											char       *roleName=NULL;
											ITKCALL(SA_ask_current_role(&CurrentRoleTag));
											ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));   //API Change
											printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

											ITK_CALL(AOM_ask_value_string(part_rev_tag,"item_id",&PartNumberS));
											printf("\n  part-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);


											ITK_CALL (AOM_ask_value_string(part_rev_tag,"item_revision_id",&RevisionS));
											printf("\n  part-Rev RevisionS : %s \n",RevisionS); fflush(stdout);

											ITK_CALL (AOM_ask_value_int(part_rev_tag,"sequence_id",&SequenceS));
											printf("\n  part-Rev SequenceS : %d \n",SequenceS); fflush(stdout);

											
											ITK_CALL (AOM_ask_value_string(part_rev_tag,"object_desc",&PartDescription));
											printf("\n    part-Rev PartDescription : %s \n",PartDescription); fflush(stdout);
											if (PartDescription==NULL)
											{
											 tc_strdup("NA",&PartDescription);
											}
											else
											{
											 STRNG_replace_str(PartDescription,",",";",&PartDescriptionDup);	
											}

											ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_PartStatus",&PartDRStat));
											printf("\n  part-Rev PartDRStat : %s \n",PartDRStat); fflush(stdout);


											ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_DesignGrp",&PartDesignGrp));
											printf("\n  part-Rev PartDesignGrp : %s \n",PartDesignGrp); fflush(stdout);

											getAllPlantDetails(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
											
											ITK_CALL (AOM_ask_value_string(part_rev_tag,PlantCS,&PartCS));
											printf("\n : part-Rev PartCS : %s \n",PartCS); fflush(stdout);

											ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_ProjectCode",&ProjectCode));
											printf("\n  part-Rev ProjectCode : %s \n",ProjectCode); fflush(stdout);
											
											ITK_CALL (AOM_ask_value_string(part_rev_tag,"t5_ColourInd",&PartColourInd));
											printf("\n  part-Rev PartColourInd : %s \n",PartColourInd); fflush(stdout);

											PartReleaseStats = 	(char *) MEM_alloc( 100 * sizeof(char) );
											tc_strcpy(PartReleaseStats,"");
											ITK_CALL (ReleaseStatusObject(part_rev_tag,PartReleaseStats));
										
										printf("\n The Part loop count %d",count);												
										 if (count>1)
										 {
										  CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"));
										 }
										
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNumberS));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,RevisionS));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartCS));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartDRStat));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,ProjectCode));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartColourInd));
										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartDescriptionDup));
										
										 
									}
								}
							
							}

							
						}
					}
				}


				  /* Getting Valid & Invalid parts detalis */


		          tag_t        query                      = NULLTAG;
				  int          n_found;
				  tag_t * result = NULLTAG;
				  char       	*partNoInvalid            = NULL;
				  char       	*RevInvalid               = NULL;
				  char       	*SeqInvalid               = NULL;
				  char       	*partNovalid              = NULL;
				  char       	*RevValid                 = NULL;
				  char       	*SeqValid                 = NULL;
				  int InValCnt;
				  int ValCnt;
				  char* PartNoList                        = NULL;
			   
				  int n_valid_rows;
				  tag_t *valid_rowTag = NULLTAG;
				  int n_invalid_rows;
				  tag_t *invalid_rowTag = NULLTAG;
				  
				  char
                   *qry_entries3[] = {"Item ID","Type"},
                   *qry_values3[]  = {Epa_Number,"EPA Revision"};
				  
				    QRY_find2("Item Revision...", &query);
                    QRY_execute(query,2, qry_entries3, qry_values3, &n_found,&result );
			        printf("\n number of EPA Revision founds=%d\n",n_found);fflush(stdout);

			       if(n_found>0)
				      {
                   


				        int i;
				        for (i =0; i<n_found; i++ )
					        {
					         tag_t epa_rev =NULLTAG;
					         epa_rev = result[i];
							

						     CALLAPI(AOM_ask_table_rows(epa_rev,"t5_EpaCrTabInValid",&n_invalid_rows,&invalid_rowTag));
				             printf("\n no of table rows found for Invalid Parts:%d \n",n_invalid_rows);fflush(stdout);

							 CALLAPI(AOM_ask_table_rows(epa_rev,"t5_EpaCmTabValid",&n_valid_rows,&valid_rowTag));
				              printf("\n no of table rows found for valid Parts:%d \n",n_valid_rows);fflush(stdout);

               //case:1
                              if ((n_invalid_rows == n_valid_rows)||(n_invalid_rows >= n_valid_rows))
					            {

					             for(InValCnt=0; InValCnt<n_invalid_rows; InValCnt++)
						            { 
                                     
									 if (tc_strcmp(PartNoList,"NULL")==0) MEM_free(PartNoList);
					                       PartNoList=(char *)MEM_alloc(1000);

                                      CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_PartNumberInValid",&partNoInvalid));
									  CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_RevisionInValid",&RevInvalid));
									  CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_SequenceInValid",&SeqInvalid));
                                      printf("\n InValid part no:[%s]  Rev:[%s]  Seq:[%s] \n",partNoInvalid,RevInvalid,SeqInvalid);fflush(stdout);
                                  
								  	if(n_valid_rows>InValCnt)
										{

									  for(ValCnt=InValCnt; ValCnt<n_valid_rows; ValCnt++)
										{
                                            
										  
                                          CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_PartNumberValid",&partNovalid));
                                          CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_RevisionValid",&RevValid));
                                          CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_SequenceValid",&SeqValid));

                                          printf("\n Valid part no:[%s]  Rev:[%s]  Seq:[%s] \n",partNovalid,RevValid,SeqValid);fflush(stdout);


                                          

									         if((InValCnt==0||ValCnt==0)&&(count<1))
										    {
                                        tc_strcpy(PartNoList,",,,,,,,");
										tc_strcat(PartNoList,partNoInvalid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,RevInvalid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,SeqInvalid);

										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,partNovalid);
                                        tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,RevValid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,SeqValid);



										}
										else if((InValCnt==0||ValCnt==0)&&(count>1))
											{

										tc_strcpy(PartNoList,partNoInvalid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,RevInvalid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,SeqInvalid);

										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,partNovalid);
                                        tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,RevValid);
										tc_strcat(PartNoList,",");
										tc_strcat(PartNoList,SeqValid);
										
										}

										
										else
										{
											tc_strcpy(PartNoList,"\n");
											tc_strcat(PartNoList,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
										    tc_strcat(PartNoList,partNoInvalid);
											tc_strcat(PartNoList,",");
											tc_strcat(PartNoList,RevInvalid);
											tc_strcat(PartNoList,",");
											tc_strcat(PartNoList,SeqInvalid);

											tc_strcat(PartNoList,",");
										    tc_strcat(PartNoList,partNovalid);
                                            tc_strcat(PartNoList,",");
										    tc_strcat(PartNoList,RevValid);
										    tc_strcat(PartNoList,",");
											tc_strcat(PartNoList,SeqValid);
											
										}
										

                                    CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNoList));

							          break;
					
                                    }

										}

										else
										{
											tc_strcpy(PartNoList,"\n");
											tc_strcat(PartNoList,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
											tc_strcat(PartNoList,partNoInvalid);
										    tc_strcat(PartNoList,",");
										    tc_strcat(PartNoList,RevInvalid);
										    tc_strcat(PartNoList,",");
										    tc_strcat(PartNoList,SeqInvalid);

										 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNoList));



										}

									
									}
									
					             }

				//case:2


								 else  // ( n_valid_rows > n_invalid_rows )
								
								 {
								 
								 
									  for(ValCnt=0; ValCnt<n_valid_rows; ValCnt++)
										{
										  if (tc_strcmp(PartNoList,"NULL")==0) MEM_free(PartNoList);
					                       PartNoList=(char *)MEM_alloc(1000);


										  CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_PartNumberValid",&partNovalid));
                                          CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_RevisionValid",&RevValid));
                                          CALLAPI(AOM_ask_value_string(valid_rowTag[ValCnt],"t5_SequenceValid",&SeqValid));

                                          printf("\n Valid part no:[%s]  Rev:[%s]  Seq:[%s] \n",partNovalid,RevValid,SeqValid);fflush(stdout);


										  if(n_invalid_rows>ValCnt)

											{


										      for(InValCnt=ValCnt; InValCnt<n_invalid_rows; InValCnt++)
						                        { 
                                     
									

                                                      CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_PartNumberInValid",&partNoInvalid));
									                  CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_RevisionInValid",&RevInvalid));
									                  CALLAPI(AOM_ask_value_string(invalid_rowTag[InValCnt],"t5_SequenceInValid",&SeqInvalid));

                                                      printf("\n InValid part no:[%s]  Rev:[%s]  Seq:[%s] \n",partNoInvalid,RevInvalid,SeqInvalid);fflush(stdout);



													

									         if((InValCnt==0||ValCnt==0)&&(count<1))

										      {
                                                    tc_strcpy(PartNoList,",,,,,,,");
										            tc_strcat(PartNoList,partNoInvalid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,RevInvalid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,SeqInvalid);

										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,partNovalid);
                                                    tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,RevValid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,SeqValid);



										      }

											  else if ((InValCnt==0||ValCnt==0)&&(count>1))
											  {

												    tc_strcpy(PartNoList,partNoInvalid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,RevInvalid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,SeqInvalid);

										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,partNovalid);
                                                    tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,RevValid);
										            tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,SeqValid);

											  }

										      else

										      {
											        tc_strcpy(PartNoList,"\n");
											        tc_strcat(PartNoList,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
										            tc_strcat(PartNoList,partNoInvalid);
											        tc_strcat(PartNoList,",");
											        tc_strcat(PartNoList,RevInvalid);
											        tc_strcat(PartNoList,",");
											        tc_strcat(PartNoList,SeqInvalid);

											        tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,partNovalid);
                                                    tc_strcat(PartNoList,",");
										            tc_strcat(PartNoList,RevValid);
										            tc_strcat(PartNoList,",");
											        tc_strcat(PartNoList,SeqValid);
											
										       }
										
                                                     CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNoList));

							                          break;
					
                                               }

											}


											else

											{

                                                     tc_strcpy(PartNoList,"\n");
											         tc_strcat(PartNoList,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
                                                     tc_strcat(PartNoList,partNovalid);
										             tc_strcat(PartNoList,",");
										             tc_strcat(PartNoList,RevValid);
										             tc_strcat(PartNoList,",");
										             tc_strcat(PartNoList,SeqValid);

										             CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,PartNoList));


											}
								 
								 
								 
								 }

								

				              }
							   
							
									
							  
							 
			
			            }




				
			}
			

				
			}
			else
			{
			 printf("\n Part details printing is skipped by user");fflush(stdout);
			}
				
				
				
				
				printf("\n End Printing");fflush(stdout);
				
				
			}
			
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,""));
			CALLAPI(newlineValueinBuffer(bufferedXmlStrOut,buff_cnt,"**************************************************************************************************************EPA REPORT COMPLETED******************************************************************************************************************************************************************************"));
			printf("\n DETAILED REPORT COMPLETED");fflush(stdout);
			
	/* if(serial_num!=NULL) MEM_free(serial_num); 
	if(dml_count!=NULL) MEM_free(dml_count); 
	if(DML_Number!=NULL) MEM_free(DML_Number); 
	if(All_DML_Number!=NULL) MEM_free(All_DML_Number); 
	if(All_DML_Number_DR!=NULL) MEM_free(All_DML_Number_DR); 
	if(All_DML_Number_Desc!=NULL) MEM_free(All_DML_Number_Desc); 
	if(All_DML_Number_Release!=NULL) MEM_free(All_DML_Number_Release); 
	if(Revision_type_DML!=NULL) MEM_free(Revision_type_DML); 
	if(DMLReleasedate!=NULL) MEM_free(DMLReleasedate); 	 */

printf("\n %d IFAIL EPA DETAILED REPORT ",ifail);fflush(stdout);
return ifail;
}

/*extern int EPADetailReportServiceFncClient( char *Report_Type,char *Datefrom ,char *Dateto,char *Plant,char *Factory,char *Reason,char *EpaType,char *SkipPart)
{
	int				ifail 						= ITK_ok;
	int n_objects = 0;
	FILE* fp=NULL;
	int n_cntrObj = 0;
    tag_t *objects = NULL;
    tag_t query = NULLTAG;
	int array_size = 0; 
	char **string_array 	= NULL;
	tag_t *cntrObj 	= NULL;
	char* Filename= NULL;
	Filename=MEM_alloc(1000);
	
	tc_strcpy(Filename,"");
	tc_strcpy(Filename,"");
	tc_strcat(Filename,"EPA_STATUS_");
	tc_strcat(Filename,Datefrom);
	tc_strcat(Filename,"_");
	tc_strcat(Filename,Dateto);
	tc_strcat(Filename,".csv");

	//USERSERVICE_array_t 	array_struct;
	
	/* char *Report_Type= NULL; */
	/* char *Datefrom  =NULL;
	char *Dateto    =NULL;
	char *Plant     =NULL;
	char *Factory   =NULL;
	char *Reason    =NULL;
	char *EpaType	=NULL;
	char *SkipPart  =NULL; */
	
	
/* 	
	ifail = USERARG_get_tag_array_argument(&n_objects, &objects); 
	USERARG_get_string_argument(&Report_Type);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Plant);
	USERARG_get_string_argument(&Factory);
	USERARG_get_string_argument(&Reason);
	USERARG_get_string_argument(&EpaType);
	USERARG_get_string_argument(&SkipPart); 
	char** bufferedXmlStrOut;
	int buff_cnt=0;
		
		
	printf("Argument Received(EPADetailReportServiceFnc) Report Type=%s\n",Report_Type);fflush(stdout);	
	printf("Argument Received(EPADetailReportServiceFnc) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) =%s\n",Dateto);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) Plant=%s\n",Plant);fflush(stdout); 
	printf("Argument Received(EPADetailReportServiceFnc) Factory Received=%s\n",Factory);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) Reason Received=%s\n",Reason);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) EpaType Received=%s\n",EpaType);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) SkipPart Received=%s\n",SkipPart);fflush(stdout);
	
	
	
	printf("After returning Value\n");fflush(stdout);
	
	char
	*qry_entries[] = { "Created After","Created Before","Type"},
	*qry_values[]  = {Datefrom,Dateto,"EPA Revision"};

	ITK_CALL(QRY_find2("General...", &query));
	printf("\n query found");fflush(stdout);
	ITK_CALL(QRY_execute(query,3, qry_entries, qry_values, &n_objects, &objects));
	printf("\n query executed");fflush(stdout);

	//printf("\n\n queryCountryObject ==[%d] \n",n_cntrObj);fflush(stdout);
	printf("\n\n n_objects ==[%d] \n",n_objects);fflush(stdout);
	
	
	
	
	if(tc_strcmp(Report_Type,"Summary")==0) 
	 {
	 CALLAPI(GenerateSummaryReport(n_objects,Datefrom,Dateto,Plant,Factory,Reason,EpaType,&bufferedXmlStrOut,&buff_cnt));
	 }
	else if(tc_strcmp(Report_Type,"DMLType")==0) 
	 {
	 CALLAPI(GenerateDMLWiseEPAReport(objects,n_objects,&bufferedXmlStrOut,&buff_cnt));
	 }
	 else if(tc_strcmp(Report_Type,"PlantType")==0) 
	 {
	 CALLAPI(GenerateEPAPlantReport(objects,n_objects,Plant,&bufferedXmlStrOut,&buff_cnt));
	 }	 
	 
	 else
	 {
	 CALLAPI(GenerateDetailReport(objects,n_objects,Report_Type,Datefrom,Dateto,SkipPart,&bufferedXmlStrOut,&buff_cnt));
	 }
	
	
	fp=fopen(Filename,"w");
	
	
			int m =0;
			printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
			array_size = buff_cnt;
			string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
			for(m=0;m<buff_cnt;m++)
			{
				printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
				fprintf(fp,"%s",bufferedXmlStrOut[m]);fflush(fp);
				string_array[m] = bufferedXmlStrOut[m];
			}
			
				printf("\nBefore returning Value\n");fflush(stdout);
	
				//ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

				
             // if (array_struct.length != 0)
				//*((USERSERVICE_array_t*) return_data) = array_struct; 	
	
	fclose(fp);
	return ifail;
}*/

extern int EPADetailReportServiceFnc( void *return_data )
{
	int				ifail 						= ITK_ok;
	int n_objects = 0;
    tag_t *objects = NULL;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	
	char *Report_Type= NULL;
	char *Datefrom  =NULL;
	char *Dateto    =NULL;
	char *Plant     =NULL;
	char *Factory   =NULL;
	char *Reason    =NULL;
	char *EpaType	=NULL;
	char *SkipPart  =NULL;
	
	
	
	ifail = USERARG_get_tag_array_argument(&n_objects, &objects); 
	USERARG_get_string_argument(&Report_Type);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	USERARG_get_string_argument(&Plant);
	USERARG_get_string_argument(&Factory);
	USERARG_get_string_argument(&Reason);
	USERARG_get_string_argument(&EpaType);
	USERARG_get_string_argument(&SkipPart);
	
		
		
	printf("Argument Received(EPADetailReportServiceFnc) Report Type=%s\n",Report_Type);fflush(stdout);	
	printf("Argument Received(EPADetailReportServiceFnc) =%s\n",Datefrom);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) =%s\n",Dateto);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) Plant=%s\n",Plant);fflush(stdout); 
	printf("Argument Received(EPADetailReportServiceFnc) Factory Received=%s\n",Factory);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) Reason Received=%s\n",Reason);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) EpaType Received=%s\n",EpaType);fflush(stdout);
	printf("Argument Received(EPADetailReportServiceFnc) SkipPart Received=%s\n",SkipPart);fflush(stdout);
	
	
	
	printf("After returning Value\n");fflush(stdout);
	
	
	
	
	char** bufferedXmlStrOut;
	int buff_cnt=0;
	
	if(tc_strcmp(Report_Type,"Summary")==0) 
	 {
	 CALLAPI(GenerateSummaryReport(n_objects,Datefrom,Dateto,Plant,Factory,Reason,EpaType,&bufferedXmlStrOut,&buff_cnt));
	 }
	else if(tc_strcmp(Report_Type,"DMLType")==0) 
	 {
	 CALLAPI(GenerateDMLWiseEPAReport(objects,n_objects,&bufferedXmlStrOut,&buff_cnt));
	 }
	 else if(tc_strcmp(Report_Type,"PlantType")==0) 
	 {
	 CALLAPI(GenerateEPAPlantReport(objects,n_objects,Plant,&bufferedXmlStrOut,&buff_cnt));
	 }
	 else if(tc_strcmp(Report_Type,"EPANetDiff")==0) 
	 {
	 CALLAPI(GenerateEPAReportNetDiff(objects,n_objects,&bufferedXmlStrOut,&buff_cnt));
	 }
	 
	 else
	 {
	 CALLAPI(GenerateDetailReport(objects,n_objects,Report_Type,Datefrom,Dateto,SkipPart,&bufferedXmlStrOut,&buff_cnt));
	 }
	
	
	
	
	
			int m =0;
			printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
			array_size = buff_cnt;
			string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
			for(m=0;m<buff_cnt;m++)
			{
				printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
				string_array[m] = bufferedXmlStrOut[m];
			}
			
				printf("\nBefore returning Value\n");fflush(stdout);
	
				ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

				
             if (array_struct.length != 0)
				*((USERSERVICE_array_t*) return_data) = array_struct;	
	
	
	return ifail;
}

extern int EPADetailReportRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 9;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	inputArgTypes[7] = USERARG_STRING_TYPE;
	inputArgTypes[8] = USERARG_STRING_TYPE;
	
	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
	printf("\n EPADetailReportServiceFnc before....EPADetailReportServiceCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("EPADetailReportServiceFnc",(USER_function_t)EPADetailReportServiceFnc,nargs,inputArgTypes,retValueType);
 
	
	return ifail;
	
}

extern int EPAMBPAExclusiveReportUserService()
{
	printf("Entered into EPAMBPAExclusiveReportFn1......(\n");
	
	int ifail = ITK_ok;
	/**Commented for Testing **/
	//int nargs = 2;
	//int nargs =6;
          int nargs=7;
	int retValueType;
	//int inputArgTypes[4] = {0,0,0,0};
	int inputArgTypes[6];
	printf("\n before calling *decision(EPAMBPAExclusiveReport)");fflush(stdout);
	//*decision=ALL_CUSTOMIZATIONS;
	printf(" \n After  calling *decision(EPAMBPAExclusiveReport)");fflush(stdout);
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	/**Commented for Testing **/
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	
	//inputArgTypes[2] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	//inputArgTypes[5] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	//inputArgTypes[0] = USERARG_TAG_TYPE;
	//retValueType = USERARG_VOID_TYPE;
	//retValueType = USERARG_STRING_TYPE;
	//retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	//retValueType = USERARG_STRING_TYPE;
	
    ifail=USERSERVICE_register_method("EPAMBPAExclusiveReport",(USER_function_t)EPAMBPAExclusiveReport,nargs,inputArgTypes,retValueType);
	
	printf("Exited from EPAMBPAExclusiveReportFn1......\n");
	
	return ifail;
	
}



extern int AllEPAReportServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	CALLAPI(EPADetailReportRegisterServiceFnc());
	CALLAPI(EPAMBPAExclusiveReportUserService());


	
	return ifail;
	
}

extern DLLAPI int tm_EPAReports_register_callbacks ()
{
	printf("\n tm_EPAReports_register_callbacks....");  
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....");   
	ifail=CUSTOM_register_exit ( "tm_EPAReports", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllEPAReportServiceFnc);
	printf("\n After registoring userservice....");
	return ( ITK_ok );
}



/*  int ITK_user_main( int argc , char* argv[] )
{            
               ITK_set_journalling (TRUE);
               
               //char* property[10];
               char **property = (char **) MEM_alloc(10 * sizeof(char *));
               char **propertyVal = (char **) MEM_alloc(10 * sizeof(char *));
               
               char* Report_Type = ITK_ask_cli_argument("-rt=");
               char* Datefrom = ITK_ask_cli_argument("-fd=");
               char* Dateto = ITK_ask_cli_argument("-td=");
               char* Plant = ITK_ask_cli_argument("-plant=");
               char* Factory = NULL;
               char* Reason = NULL;
               char* EpaType = NULL;
               char* SkipPartinput = ITK_ask_cli_argument("-sp=");
               char* SkipPart = NULL;
			   
			   
			   if(tc_strcmp(SkipPartinput,"false")==0)
			   {
				   SkipPart="false";
			   }
			   else
			   {
					   SkipPart="true";
               }
               //ITK_CALL(ITK_init_module("infodba","infodba","dba"));              
               //error(z,"login success\n");
               
               ITK_CALL(ITK_auto_login());
               printf("login Pratik \n");fflush(stdout);
               
			   ITK_CALL(EPADetailReportServiceFncClient( Report_Type,Datefrom ,Dateto,Plant,Factory,Reason,EpaType,SkipPart));
               
               //ITK_CALL(POM_logout(false))   ;
               return 0;
}
  */
