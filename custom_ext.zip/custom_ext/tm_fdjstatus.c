/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ModularBomComplianceChk.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating Modular MBOM Accuracy check report for VC.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 18/04/2023  	 Anvesh Bujule						    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>


int FDJcount=0;
int GCIcount=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}



//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* FDJCalulate()
{
	char* ptr = NULL;
	float WCQresult;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);

	printf("\n FDJcount [%d],GCIcount[%d]",FDJcount,GCIcount); fflush(stdout);

	WCQresult = (float)(GCIcount) / FDJcount * 100.0;

	printf("\n  after calculation: WCQresult = %.2f%%", WCQresult); fflush(stdout);
	sprintf(ptr,"%10lf",WCQresult);
	printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

	return ptr;
	
	
}

extern int fdjstatus(void *retValue)
{

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	 //char *output	 = NULL;

	 int status				= ITK_ok;
	//char *fromdate			= NULL;
	//char *todate			= NULL;
	char *type				= NULL;
	int i = 0;
	int n_entries;
	int n_entries1;

	tag_t queryTag1			= NULLTAG;
	tag_t queryTag			= NULLTAG;
	tag_t VehicleTag1		= NULLTAG;
	int resultCount			= 0;
	int resultCount11		= 0;
	tag_t *VehicleTags		= NULLTAG;
	tag_t *ERCDMLTags1		= NULLTAG;
	tag_t ERCDMLTag			= NULLTAG;
	tag_t ERCDMLTag1		= NULLTAG;
	tag_t objTypeTag		= NULLTAG;
	tag_t VCMain			= NULLTAG;
	tag_t DMLtag			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	tag_t VCMainchld1		= NULLTAG;
	char  type_name[TCTYPE_name_size_c+1];

	char *DmlId			= NULL;
	char *DmlIdDup		= NULL;
	char *DmlRelType	= NULL;
	char *DmlRelTypeDup = NULL;
	char *DmlRelStat	= NULL;
	char *DmlRelStatDup = NULL;
	char *PartNum		= NULL;
	char *PartRev		= NULL;
	char *VCtargetid	= NULL;
	char *VCtargetrevid = NULL;
	char *VCtestid		= NULL;
	char *VCtestrevid	= NULL;
	char *VCtestDescp	= NULL;
	//int VCtestPlatform	= 0;
	char *VCtestProgScale = NULL;
	char *VCtestDateRel = NULL;
	char *WCQfinal		= NULL;
	char *DMLno			= NULL;
	char *DMLRevno		= NULL;
	char *DMLRelType	= NULL;
	char *VCtestPlatform = NULL;
	double GCIValue;
	double TestGCIValue;
	double TestDVAValue;
	int TestDMUscore;


	tag_t* TechSPecObjSet	= NULLTAG;
	int TechSpecCount		= 0;
	tag_t TechSPecObj		= NULLTAG;
	char *descDup			= NULL;
	tag_t FDJRelationFind	= NULLTAG;
	tag_t GCIRelationFind	= NULLTAG;
	tag_t snapshotObj		= NULLTAG;
	tag_t VCRevTag			= NULLTAG;
	tag_t lov_tag			= NULLTAG;
	int snapshotCount		= 0;
	tag_t* snapshotObjSet	= NULLTAG;
	tag_t* VCMainchld		= NULLTAG;
	tag_t* FDJObjectTag		= NULLTAG;
	tag_t* GCIObjectTag		= NULLTAG;
	tag_t GCIObject			= NULLTAG;
	char snapshotObjtype_name[TCTYPE_name_size_c+1];
	tag_t snapshotObjTypeTag= NULLTAG;
	tag_t FDJObject			= NULLTAG;
	char* snapshot_itemid	= NULL;
	char* SSTopLineRev		= NULL;
	char* VCDRstatus		= NULL;
	char* VCColInd			= NULL;
	char* VCid				= NULL;
	char* VCrevid			= NULL;
	char* FDJStatus			= NULL;
	int EligibleVCatDR3 =0;
	int j =0;
	int DR3count =0;
	int FDJapprove =0;
 
	char** bufferedXmlStrOut;
	int buff_cnt=0;
	int VCchldcount=0;
	int FDJ_count=0;
	int GCI_count=0;
	int gci=0;
	int fdj=0;
    int refcount=0;
	tag_t reflist2 = NULLTAG;
	tag_t *reflist = NULLTAG;
	tag_t dad_tag=NULLTAG;

	int DVAreportflag1 =0;
    tag_t DVAfoldertypetag = NULLTAG;
    char* username = NULL;
    char* documentName = NULL;
    tag_t user_tag=NULLTAG;
    tag_t homefoldertag = NULLTAG;
    FL_sort_criteria_t flcriteria;
	tag_t DatasetType=NULLTAG;
	tag_t DVAfoldertag = NULLTAG;
	tag_t object_create_input_tag3 = NULLTAG;
	char*	foldername	=NULL;
	char*	date	=NULL;
	char*	year	=NULL;
	char*	to	=NULL;
	char*	m	=NULL;
	char*	cMonth	=NULL;
	char*	fromdatevalue	=NULL;
	char*	toyear	=NULL;
	char*	toMonth	=NULL;
	char*	todatevalue	=NULL;
	int f =0;

	//int GCIcount=0;
	//int FDJcount=0;
	FILE* file=NULL;
	char fsuccess_nam[500];
	char *Csvpath=NULL;
	Csvpath = (char *)MEM_alloc(500);

    fromdatevalue = (char *)MEM_alloc(500);
    todatevalue = (char *)MEM_alloc(500);
	toMonth = (char *)malloc(500 * sizeof(char));
	cMonth = (char *)malloc(500 * sizeof(char));
	char *GCIDocPath=NULL;
	GCIDocPath = (char *)MEM_alloc(500);

	int vcattr =0;
	descDup = (char *)malloc(500 * sizeof(char));

	 char		*fromdate 		= NULL;
	 char		*todate 		= NULL;
     USERARG_get_string_argument(&fromdate);
	 USERARG_get_string_argument(&todate);

	 printf("\n Value of from date [%s]\n",fromdate); fflush(stdout);
	 printf("\n Value of to date [%s]\n",todate); fflush(stdout);


      tc_strtok(fromdate,"{");     ///[DateTime {8/5/2020}]
      m=tc_strtok(NULL,"/");


	  printf("\n value of m is ************** [%s]\n",m); fflush(stdout);
      date=tc_strtok(NULL,"/");

	  printf("\n value of date is ************** [%s]\n",date); fflush(stdout);
      year=tc_strtok(NULL,"}");

	   printf("\n value of year is ************** [%s]\n",year); fflush(stdout);



      if(tc_strcmp(m,"1")==0)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(tc_strcmp(m,"2")==0)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(tc_strcmp(m,"3")==0)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(tc_strcmp(m,"4")==0)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(tc_strcmp(m,"5")==0)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(tc_strcmp(m,"6")==0)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(tc_strcmp(m,"7")==0)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(tc_strcmp(m,"8")==0)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(tc_strcmp(m,"9")==0)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(tc_strcmp(m,"10")==0)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(tc_strcmp(m,"11")==0)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(tc_strcmp(m,"12")==0)
	  {
		tc_strcpy(cMonth,"Dec");
	  }



     tc_strcpy(fromdatevalue,"");
     tc_strcat(fromdatevalue,date);
     tc_strcat(fromdatevalue,"-");
     tc_strcat(fromdatevalue,cMonth);
     tc_strcat(fromdatevalue,"-");
     tc_strcat(fromdatevalue,year);

     printf("\n value of from date is ************** [%s]\n",fromdatevalue); fflush(stdout);


      tc_strtok(todate,"{");     ///[DateTime {8/5/2020}]
      to=tc_strtok(NULL,"/");

	  printf("\n value of to is ************** [%s]\n",to); fflush(stdout);
      todate=tc_strtok(NULL,"/");

	  printf("\n value of todate is ************** [%s]\n",todate); fflush(stdout);
      toyear=tc_strtok(NULL,"}");

	  printf("\n value of toyear is ************** [%s]\n",toyear); fflush(stdout);



      if(tc_strcmp(to,"1")==0)
	  {
		tc_strcpy(toMonth,"Jan");
	  }
	  else if(tc_strcmp(to,"2")==0)
	  {
		tc_strcpy(toMonth,"Feb");
	  }
	  else if(tc_strcmp(to,"3")==0)
	  {
		tc_strcpy(toMonth,"Mar");
	  }
	  else if(tc_strcmp(to,"4")==0)
	  {
		tc_strcpy(toMonth,"Apr");
	  }
	  else if(tc_strcmp(to,"5")==0)
	  {
		tc_strcpy(toMonth,"May");
	  }
	  else if(tc_strcmp(to,"6")==0)
	  {
		tc_strcpy(toMonth,"Jun");
	  }
	  else if(tc_strcmp(to,"7")==0)
	  {
		tc_strcpy(toMonth,"Jul");
	  }
	  else if(tc_strcmp(to,"8")==0)
	  {
		tc_strcpy(toMonth,"Aug");
	  }
	  else if(tc_strcmp(to,"9")==0)
	  {
		tc_strcpy(toMonth,"Sep");
	  }
	  else if(tc_strcmp(to,"10")==0)
	  {
		tc_strcpy(toMonth,"Oct");
	  }
	  else if(tc_strcmp(to,"11")==0)
	  {
		tc_strcpy(toMonth,"Nov");
	  }
	  else if(tc_strcmp(to,"12")==0)
	  {
		tc_strcpy(toMonth,"Dec");
	  }

     tc_strcpy(todatevalue,"");
     tc_strcat(todatevalue,todate);
     tc_strcat(todatevalue,"-");
     tc_strcat(todatevalue,toMonth);
     tc_strcat(todatevalue,"-");
     tc_strcat(todatevalue,toyear);


    printf("\n value of To date date is11 ************** [%s]\n",todatevalue); fflush(stdout);

	n_entries = 5;

	char *qry_entries[5] = {"Part Type","AR/DR Status","CCVC No","From date","To Date"};
	char **qry_values = (char **) MEM_alloc(60 * sizeof(char *));

	qry_values[0] = "Vehicle";
	qry_values[1] = "DR3";
	qry_values[2] = "Configurable VC";
	qry_values[3] = fromdatevalue;
	qry_values[4] = todatevalue;	


	ITK_CALL(POM_get_user(&username,&user_tag));
	printf("\n\n username :%s\n",username);fflush(stdout);

	ITK_CALL(SA_ask_user_home_folder(user_tag,&homefoldertag));

    ITK_CALL(FL_ask_sort_criteria(homefoldertag,&flcriteria));
			documentName = NULL;
			documentName = (char *)MEM_alloc(50);

			//tc_strcpy(documentName, "");
			tc_strcpy(documentName, "");
			tc_strcat(documentName, "WCQ Result Report");
			/*tc_strcat(documentName, "_");
			tc_strcat(documentName, CurRe);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, CurSe);
			tc_strcat(documentName, "_");
			tc_strcat(documentName, Data);*/

			ITK_CALL(FL_ask_references(homefoldertag,flcriteria,&refcount,&reflist));
			printf("\n the refrence count is*** :[%d]\n",refcount);   fflush(stdout);

		   int DVAreportflag=0;

			for(f=0;f<refcount;f++)
			{
				reflist2=reflist[f];

				ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

				if(tc_strcmp(foldername,"WCQ Result Report")==0)
				{

					printf("\n\n Folder is already available\n");fflush(stdout);

				   /*ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
				   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
				   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
				   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
				   ITK_CALL(AOM_save(dad_tag));

				   ITK_CALL(AOM_lock(dad_tag));


				   ITK_CALL(FL_insert(reflist2,dad_tag,000));
				   ITK_CALL(AOM_save(reflist2));


				   ITK_CALL(AOM_refresh(dad_tag, TRUE));

				   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

				   ITK_CALL(AE_save_myself(dad_tag));*/

				   DVAreportflag++;


				  //ITK_CALL(FL_insert(reflist2,file_tag,999));

				}
				else
				{
					//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

				}

			}

		
	         //printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);

  
	  if(DVAreportflag==0)
	  {
		  printf("\n\n INside folder creation condition :%s\n");fflush(stdout);

		ITK_CALL(TCTYPE_find_type( "Folder",NULL, &DVAfoldertypetag));
		ITK_CALL(TCTYPE_construct_create_input(DVAfoldertypetag, &object_create_input_tag3));
		ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name","WCQ Result Report"));

		ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&DVAfoldertag));

		ITK_CALL(AOM_save(DVAfoldertag));

		ITK_CALL(FL_insert(homefoldertag,DVAfoldertag,999));
		ITK_CALL(AOM_save(homefoldertag));

		  //(FL_insert(reflist2,file_tag,999))
	  }


    if(QRY_find("Vehicle DR3", &queryTag1));
	printf("\n After DR3 Vehicle : QRY_find \n");fflush(stdout);
	if (queryTag1)
	{
		printf("\n Found Query DR3 Vehicle  \n");fflush(stdout);
	}
	else
	{
		printf("\n NotFound Query DR3 Vehicle");fflush(stdout);
		//goto CLEANUP;
	}

	if(QRY_execute(queryTag1, n_entries, qry_entries, qry_values, &resultCount, &VehicleTags));

     printf("\t resultCount :%d:\n", resultCount);fflush(stdout);

   ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path",0,&GCIDocPath));
	printf("\n GCIDocPath :[%s]\n",GCIDocPath); fflush(stdout);
	tc_strcpy(Csvpath,"");
   // tc_strcpy(Csvpath,"/user/uaprodtrl/4D_updation_shell/");
    tc_strcpy(Csvpath,GCIDocPath);
	sprintf(fsuccess_nam,"WCQResult.csv");
	tc_strcat(Csvpath,fsuccess_nam);
	printf("\n file path is*** :[%s]\n",Csvpath); fflush(stdout);
	file = fopen(Csvpath,"w");

	if(file!=NULL)
	{
		printf("\n file is opening\n");   fflush(stdout);	
	}
	else
	{
		printf("\n file is not opening\n");   fflush(stdout);	
	}

	fprintf(file,"VC No.(released* & WIP),VC description,Rev Seq.,Platform,Program Scale,Release Date,DML No.,DML Type,DVA index(D),DMU Demerit Score(S),GCI(A)\n");

	if (resultCount>0)
	{

		for(i=0;i<resultCount;i++)
		{

				VehicleTag1 = VehicleTags[i];

				ITK_CALL(AOM_ask_value_string(VehicleTag1,"item_id",&PartNum));
										
				ITK_CALL(AOM_ask_value_string(VehicleTag1,"item_revision_id",&PartRev));

				ITK_CALL(ITEM_find_item (PartNum,&VCMain));
				printf("\n Vehicle No -------->[%s]",PartNum); fflush(stdout);

				ITK_CALL(ITEM_list_all_revs(VCMain,&VCchldcount,&VCMainchld));

				if (VCchldcount>0)
				{
					DR3count=0;
					for(j=0;j<VCchldcount;j++)
					{

						ITK_CALL(AOM_ask_value_string(VCMainchld[j],"t5_PartStatus",&VCDRstatus));
						printf("\n vehicle DR status is [%s]\n",VCDRstatus); fflush(stdout);

						if (tc_strcmp(VCDRstatus,"DR3")==0)
						{
							DR3count++;

							ITK_CALL(AOM_ask_value_string(VCMainchld[j],"item_id",&VCtargetid));
							ITK_CALL(AOM_ask_value_string(VCMainchld[j],"item_revision_id",&VCtargetrevid));

						}
						
					}

					if(DR3count==1)
					{

						printf("\n DR3 count is equal to 1........\n"); fflush(stdout);
						printf("\n vehicle to be checked for further process......................... [%s][%s]\n",VCtargetid,VCtargetrevid); fflush(stdout);

						ITK_CALL(ITEM_find_rev(VCtargetid,VCtargetrevid,&VCRevTag));

						ITK_CALL(AOM_ask_value_string(VCRevTag,"item_id",&VCtestid));
						ITK_CALL(AOM_ask_value_string(VCRevTag,"item_revision_id",&VCtestrevid));
						ITK_CALL(AOM_ask_value_string(VCRevTag,"object_desc",&VCtestDescp));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"t5_Platform",&VCtestPlatform));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"t5_ProgramScale",&VCtestProgScale));
						ITK_CALL(AOM_UIF_ask_value(VCRevTag,"date_released",&VCtestDateRel));
						if(AOM_ask_value_string(VCRevTag,"t5_ColourInd",&VCColInd));

						printf("colour ind is :%s\n",VCColInd);fflush(stdout);
						printf("\n testing......................... [%s],[%s]\n",VCtestid,VCtestrevid); fflush(stdout);

						if (tc_strcmp(VCColInd,"C")!=0)
						{
							ITK_CALL(GRM_find_relation_type("T5_AssmhasFDJ", &FDJRelationFind));   
							if (FDJRelationFind!=NULLTAG)
							{

								ITK_CALL(GRM_list_secondary_objects_only(VCRevTag, FDJRelationFind, &FDJ_count, &FDJObjectTag));
								printf("\n FDJ_count********** [%d]\n",FDJ_count); fflush(stdout);

								if(FDJ_count>0)
								{

										for(fdj=0;fdj<FDJ_count;fdj++)
										{

											FDJObject=FDJObjectTag[fdj];

											ITK_CALL(AOM_ask_value_string(FDJObject,"t5_FDJStatus",&FDJStatus));
											printf("\n FDJStatus [%s]\n",FDJStatus); fflush(stdout);


											FDJapprove=0;
											if(tc_strcmp(FDJStatus,"FDJ Approved")==0)
											{

												FDJcount++;
											 
												printf("\n ***FDJ is Approved***\n"); fflush(stdout);

												FDJapprove=1;


											}

											if(FDJapprove>0)
											{

												ITK_CALL(GRM_find_relation_type("T5_GCI_relation", &GCIRelationFind));

												ITK_CALL(GRM_list_secondary_objects_only(VCRevTag, GCIRelationFind, &GCI_count, &GCIObjectTag));
												printf("\n GCI_count********** [%d]\n",GCI_count); fflush(stdout);

 
												for(gci=0;gci<GCI_count;gci++)
												{

													GCIObject=GCIObjectTag[gci];

													ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&GCIValue));
													printf("\n GCIValue [%f]\n",GCIValue); fflush(stdout);

													if (GCIValue>85)
													{

														ITK_CALL(AOM_ask_value_string(GCIObject,"t5_DVLODmlNo1",&DMLno));
														printf("\n DMLno [%s]\n",DMLno); fflush(stdout);

														if(DMLno!=NULL)
														{

															ITK_CALL(ITEM_find_item (DMLno,&DMLtag));
															ITK_CALL(ITEM_ask_latest_rev(DMLtag, &DMLRevTag));
															ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLRelType));
															printf("\n DMLRelType [%s]\n",DMLRelType); fflush(stdout);


														}

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_geometry_conf_index_a1",&TestGCIValue));
								
														printf("\n GCIValue [%f]\n",TestGCIValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCIObject,"t5_DVA_value_d1",&TestDVAValue));
								
														printf("\n TestDVAValue [%f]\n",TestDVAValue); fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCIObject,"t5_demerit_score_rating_S1",&TestDMUscore));
								
														printf("\n TestDMUscore [%d]\n",TestDMUscore); fflush(stdout);

														GCIcount++;
														printf("\n ***************GCI value is greater than 85***********************\n"); fflush(stdout);

														printf("\n VCtestid [%s] VCtestDescp [%s] VCtestrevid [%s]  VCtestPlatform [%s] VCtestProgScale [%s] VCtestDateRel [%s] DMLno[%s] DMLRelType[%s] TestDVAValue[%f] TestDMUscore[%d] TestGCIValue[%f]\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);fflush(stdout);
														fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%f,%d,%f,\n",VCtestid,VCtestDescp,VCtestrevid,VCtestPlatform,VCtestProgScale,VCtestDateRel,DMLno,DMLRelType,TestDVAValue,TestDMUscore,TestGCIValue);



													}
												
												   
												}


											}

										
										}
										
								
								}


							
							}


						}
					}
					else
					{
									printf("\n DR3 count is more than one........"); fflush(stdout);

					}

				}
							
		}
	}



	printf("\n The value of count%d\n",EligibleVCatDR3);fflush(stdout);
	printf("\n FDJcount [%d]",FDJcount); fflush(stdout);
	printf("\n GCIcount [%d]",GCIcount); fflush(stdout);

	WCQfinal=FDJCalulate();
	printf("\n WCQfinal [%s]..................................................................",WCQfinal); fflush(stdout);
    fprintf(file,"\n\n\n\n\n\n (WCQ Result 8 = No. of Eligible VCs at DR3 with GCI > 85%) / (No. of Eligible VCs at DR3 for WCQ Result 8) * 100\n");
	fprintf(file,"\nNo. of Eligible VCs at DR3 with GCI = %d\nNo. of Eligible VCs at DR3 for WCQ Result 8 = %d\n",GCIcount,FDJcount);
	fprintf(file,"WCQ RESULT 8 = %s\n",WCQfinal);

	fclose(file);



	   for(f=0;f<refcount;f++)
		{
			reflist2=reflist[f];

			ITK_CALL(WSOM_ask_name2(reflist2,&foldername));

			if(tc_strcmp(foldername,"WCQ Result Report")==0)
			{

				printf("\n\n Folder is already created condition\n");fflush(stdout);

			   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
			   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
			   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
			   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
			   ITK_CALL(AOM_save(dad_tag));

			   //ITK_CALL(AOM_lock(dad_tag));
			   
               printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);
			   ITK_CALL(AOM_refresh(dad_tag, TRUE));

			   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

			   printf("\n\n inside DVA Reports condition5454545454545477777 :\n");fflush(stdout);

			   ITK_CALL(AE_save_myself(dad_tag));

			   printf("\n\n inside DVA Reports condition5454545454545488888888 :\n");fflush(stdout);

			   ITK_CALL(FL_insert(reflist2,dad_tag,000));
			   ITK_CALL(AOM_save(reflist2));
			   printf("\n\n inside DVA Reports condition545454545454545566 :\n");fflush(stdout);

			    DVAreportflag1 =1;


			  //ITK_CALL(FL_insert(reflist2,file_tag,999));

			}
			else
			{
				//printf("\n\n Inside else condition Folder creation condition\n");fflush(stdout);	

			}

		}

	  if(DVAreportflag1 == 0)
	  {
		   ITK_CALL( TCTYPE_find_type("MSExcel", NULL,&DatasetType));
		   ITK_CALL(TCTYPE_construct_create_input(DatasetType, &object_create_input_tag3))
		   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",documentName));;
		   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));
		   ITK_CALL(AOM_save(dad_tag));

		   //ITK_CALL(AOM_lock(dad_tag));
		   //ITK_CALL(FL_insert(homefoldertag,dad_tag,000));
		    printf("\n\n inside dataset attach condition 2222222222222:\n");fflush(stdout);



		   ITK_CALL(AOM_refresh(dad_tag, TRUE));

		   ITK_CALL(AE_import_named_ref(dad_tag,"excel",Csvpath,NULL,SS_BINARY));

		  // ITK_CALL(AE_save_myself(dad_tag)); 
		   ITK_CALL(AOM_save(dad_tag)); 

		   printf("\n\n inside dataset attach condition54545454545454 :\n");fflush(stdout);

		   ITK_CALL(FL_insert(DVAfoldertag,dad_tag,000));
		   ITK_CALL(AOM_save(DVAfoldertag));

		   printf("\n\n inside dataset attach condition :\n");fflush(stdout);

		   
       }
		 
	    printf("\n\n END of FDJ Code 4444\n");fflush(stdout);

	  /**((char **) retValue) = (char *) MEM_alloc( (strlen(strDVA) + 1) * sizeof(char));
      strcpy( *((char **) retValue), strDVA);*/


	
	
	return 0;
}


int tm_fdjstatus1()
{
	/*int ifail = ITK_ok;
    char*Vehicleid =NULL;
    char*VCTname =NULL;

	USERARG_get_string_argument(&Vehicleid);
    DVAcalculations1(Vehicleid,&VCTname);

	printf("VCTname:%s........\n",VCTname);
	*((char **) return_data) = (char *) MEM_alloc( (strlen(VCTname) + 1) * sizeof(char));
    strcpy( *((char **) return_data), VCTname);

	  printf("VCTname* :: %s\n",VCTname);fflush(stdout);

	printf("\n Inside the DVA fun111111111...............");fflush(stdout);
	return ifail;*/




	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS;

	//int inputArgTypes[] = {0};
	int retValueType;
	int nargs = 2;

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	

      
    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("fdjstatus",(USER_function_t)fdjstatus,nargs,inputArgTypes,retValueType);


return ifail;

}

extern int tm_fdjstatuscalling(int *decision, va_list args)
{
	/*int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	int inputArgTypes[1] = {0};
	int retValueType;
	inputArgTypes[0] = USERARG_STRING_TYPE;
	int nargs = 1;
    retValueType = USERARG_STRING_TYPE ;
	ifail=USERSERVICE_register_method("DVAcalculations",(USER_function_t)DVAcalculations,nargs,inputArgTypes,retValueType);*/

	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	tm_fdjstatus1();

	return ifail;


}


extern DLLAPI int tm_fdjstatus_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_fdjstatus");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_fdjstatus", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_fdjstatuscalling);
	printf("\n After registering userservice....tm_fdjstatus");fflush(stdout);
	return(ITK_ok);
}


