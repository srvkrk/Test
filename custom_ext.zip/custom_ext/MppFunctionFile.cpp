#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <vector>
#include <iomanip>
#include <iterator>
//#include <base_utils/IFail.hxx>
//#include <base_utils/TcResultStatus.hxx>
//#include <base_utils/ScopedPtr.hxx>
//#include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <pie/pie.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <tccore/tctype.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <sa/tcfile.h>
#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>
#include <bom/bom.h>
using namespace std;
//using namespace Teamcenter;
#include <nlohmann/json.hpp>
#include <cryptopp/hmac.h>
#include <cryptopp/sha.h>
#include <cryptopp/hex.h>
#include <cryptopp/base64.h>
#include <cryptopp/filters.h>
#include <curl/curl.h>
#include <map>
using json = nlohmann::json;
vector<string> childpartlist;
vector<string> StationList;
vector<string> operationlist;
vector<string> designrevisionlist;



struct PlantInfo {
    string plantCode;
    string plantName;
};

class Item{
	private :
	string OpItemID;

	public :
	//Item(string operation) : OpItemID(operation) {}
	//Item(string operation){}
    ~Item(){
        cout << "Destructer called" << endl;
    }
	//Item() = default;
	tag_t ReturnItemRevision(string operation)
	{
		this->OpItemID = operation;
		tag_t OperationItemTag = NULLTAG;
		tag_t OperationLatestRevisionTag = NULLTAG;
		logical isCheckOut = 0;
		ITEM_find_item(OpItemID.c_str(),&OperationItemTag);
		if(OperationItemTag!=NULLTAG)
		{
			char *OperationLatestRevisionItemId = NULL;
			char *OperationLatestRevisionItemRevisionid = NULL;
			int OperationLatestRevisionItemSequenceid = NULL;
			ITEM_ask_latest_rev(OperationItemTag,&OperationLatestRevisionTag);
			AOM_ask_value_string(OperationLatestRevisionTag,"item_id",&OperationLatestRevisionItemId);
			AOM_ask_value_string(OperationLatestRevisionTag,"item_revision_id",&OperationLatestRevisionItemRevisionid);
			AOM_ask_value_int(OperationLatestRevisionTag,"sequence_id",&OperationLatestRevisionItemSequenceid);

			return OperationLatestRevisionTag;
		}
	}
    

};
tag_t GetBomLine(string ItemID , char *type)
{
    cout << "Inside GetBomLine" << endl;

    tag_t ItemRevisinQueryTag = NULLTAG;
    tag_t ReturnTag = NULLTAG;
    char *QueryInputEntry[2] = {"Item ID","Type"};
    char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
    int QueryOutputCount = 0;
    tag_t *QueryOutputTags = NULLTAG;
    QRY_find2("Item Revision...",&ItemRevisinQueryTag);
    if(ItemRevisinQueryTag!=NULLTAG)
    {
        QueryInputValue[0] = ItemID.c_str();
        QueryInputValue[1] = type;
        QRY_execute(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue, &QueryOutputCount, &QueryOutputTags);
        cout << "Number of process found : " << QueryOutputCount << endl;
        if(QueryOutputCount>0)
        {
            int BVRCount = 0 ,
                BVRFlag = 0 ;
            tag_t *BVRTags = NULLTAG;
            tag_t BVRStoreTag = NULLTAG;
            ITEM_rev_list_bom_view_revs(QueryOutputTags[0], &BVRCount, &BVRTags);
            if(BVRCount>0)
            {
                for(int BVRIterator = 0;BVRIterator<BVRCount;BVRIterator++)
                {
                    char *BVRObjName = NULL;
                    string BVRObjectName;
                    AOM_ask_value_string(BVRTags[BVRIterator],"object_name",&BVRObjName);
                    BVRObjectName = BVRObjName;
                    cout << "BVR Object Name : " << BVRObjName << endl;
                    size_t position = BVRObjectName.find("View");
                    if (position != string::npos) 
                    {
                        BVRFlag++;
                        BVRStoreTag = BVRTags[BVRIterator];
                        cout << "BVR View found" << endl;
                        break;
                    }
                    else 
                    {
                        cout << "BVR View not found!" << endl;
                    }
                }
            }
            if(BVRFlag>0)
            {
                int CountOperations = 0;
                tag_t revRule = NULLTAG;
                tag_t window = NULLTAG;
                tag_t TopLineTag = NULLTAG;
                tag_t *TagOperations = NULLTAG;
                CFM_find("Latest Working", &revRule);
                BOM_create_window(&window);
                BOM_set_window_config_rule(window,revRule);
                BOM_set_window_pack_all(window,true);
                BOM_set_window_top_line(window, NULLTAG,QueryOutputTags[0] ,BVRStoreTag, &TopLineTag);
                return TopLineTag;
            }
            else{
                return ReturnTag;
            }
        }
        else{
            return ReturnTag;
        }
    }
    else{
        return ReturnTag;
    }
}
string FunctionForStringEncode(const string& input) {
    string encoded;
    CryptoPP::StringSource ss(input, true,
        new CryptoPP::Base64Encoder(
            new CryptoPP::StringSink(encoded), false
        )
    );

    for (auto& c : encoded) {
        if (c == '+') c = '-';
        else if (c == '/') c = '_';
    }
    encoded.erase(remove(encoded.begin(), encoded.end(), '='), encoded.end());
    return encoded;
}

string SHACreation(const string& data, const string& key) {
    string mac;
    CryptoPP::HMAC<CryptoPP::SHA256> hmac((const CryptoPP::byte*)key.data(), key.size());

    CryptoPP::StringSource ss(data, true,
        new CryptoPP::HashFilter(hmac,
            new CryptoPP::StringSink(mac)
        )
    );
    return mac;
}
time_t getCurrentEpochTime() {
    return time(nullptr);
}  
string CurrentDateToBePrinted() {
    // Get the current time
    time_t now = time(nullptr);
    tm* localTime = localtime(&now);
 
    // Format the time into a string (e.g., "2025-02-13_12-45-30")
    ostringstream oss;
    oss << (1900 + localTime->tm_year) << "-"
        << (1 + localTime->tm_mon) << "-"
        << localTime->tm_mday;
 
    return oss.str();
} 
string getCurrentDateTime1() {
    // Get the current time
    time_t now = time(nullptr);
    tm* localTime = localtime(&now);
 
    // Format the time into a string (e.g., "2025-02-13_12-45-30")
    ostringstream oss;
    oss << (1900 + localTime->tm_year) << "_"
        << (1 + localTime->tm_mon) << "_"
        << localTime->tm_mday << "_";
 
    return oss.str();
}
void SendToPalmsys(json MppToPalmsysReturn)
{
    cout << "Inside SendToPalmsys " << endl;

    tag_t COQueryTag = NULLTAG;
    char *Co_URL = NULL;
    char *Co_Key = NULL;
    char *Co_cr = NULL;
    char *Co_aud = NULL;
    char *Co_iss = NULL;
    char *Co_owner = NULL;
    char *Co_ProjId = NULL;
    QRY_find2("Control Objects...",&COQueryTag);
    if(COQueryTag!=NULLTAG)
    {
        char **Valuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *Entries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        Valuesp[0]="SendToPalmsys";
        Valuesp[1]="Creation";
        Valuesp[2]="0";
        int COCountp = 0;
        tag_t *COTagsP = NULLTAG;
        QRY_execute(COQueryTag, 3, Entries, Valuesp, &COCountp, &COTagsP);
        if(COCountp>0)
        {
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo1",&Co_URL); // https://pfirstdev2.tatamotors.com:2014/Pfirst/ws/app2015/sendtopalmsys
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo2",&Co_Key); // Sendtopalmsys
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo3",&Co_cr); // 005
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo4",&Co_aud); // sysv1
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo5",&Co_iss); // plm
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo6",&Co_owner); // ttl1313924293
            AOM_ask_value_string(COTagsP[0],"t5_Userinfo7",&Co_ProjId); // wsproj
            json header = {
                {"alg", "HS256"},
                {"typ", "JWT"}
            };

            time_t currentEpoch = getCurrentEpochTime();
            cout << "currentEpoch : " << currentEpoch << endl;
            // json payload = {
            //     {"cr", "005"},
            //     {"aud", "sysv1"},
            //     {"iss","plm"},
            //     {"owner","ttl1313924293"},
            //     {"iat", currentEpoch},
            //     {"exp",currentEpoch + 500},
            //     {"proj_id","wsproj"}
            // };
            json payload = {
                {"cr", Co_cr},
                {"aud", Co_aud},
                {"iss",Co_iss},
                {"owner",Co_owner},
                {"iat", currentEpoch},
                {"exp",currentEpoch + 500},
                {"proj_id",Co_ProjId}
            };

            string encodedHeader = FunctionForStringEncode(header.dump());
            string encodedPayload = FunctionForStringEncode(payload.dump());

            string message = encodedHeader + "." + encodedPayload;

            //string palmsysKey = "Sendtopalmsys";
            string palmsysKey = Co_Key;
            string signature = SHACreation(message, palmsysKey);
            string encodedSignature = FunctionForStringEncode(signature);

            string jwt = message + "." + encodedSignature;
            string result = "Authorization: Bearer " + jwt;
            cout << "result: " << result << endl;

            //curl_global_init(CURL_GLOBAL_DEFAULT);    
            CURL* curl;
            CURLcode res;
            
            //string url = "https://pfirstdev2.tatamotors.com:2014/Pfirst/ws/app2015/sendtopalmsys";
            string url = Co_URL;
            string ApplicationHeader = "Content-Type: application/json";
            string s1 = "curl -X POST "+ url;
            string s2 = s1 + " -H \"";
            string s3 = s2 + result;
            string s4 = s3 + "\" -H \"";
            string s5 = s4 + ApplicationHeader;
            string s6 = s5 + "\" -d \'";
            string s7 = s6 + MppToPalmsysReturn.dump() + "\'";
            string cmd =  s7;
            cout << "command = " << cmd.c_str() << endl;
            int returnCode = system(cmd.c_str());
        }
    }

    
}

vector<PlantInfo> GetGroup(string plant,string Input)
{
    cout << "Inside GetGroup " << endl;
    vector<PlantInfo> result;
    string code, city,group;
    stringstream ss(Input);
    string segment;    
    string token;
    while (getline(ss, token, ';')) {
        if (!token.empty()) {
            stringstream pairStream(token);
            getline(pairStream, code, '-');
            getline(pairStream, city, '-');
            getline(pairStream, group, '-');
            if (code == plant) {
                //cout << "Plant Code: " << code << ", Plant Name: " << city << endl;
                result.push_back({code,city});
            }
        }
    }
    return result;
}

struct ProcessDataReturn {
    string OperationID;
};

struct OperationDataReturn {
    string ProcessItemId;
    string ProcessMOSTFrequency;
    string ProcessMOSTDivision;
    string ProcessMOSTMen;
    string ProcessGangSize;
    string ProcessAPLGangSize;
    string ProcessMOSTOnOff;
    string ProcessCycleTime;
    string ProcessCW;
    string ProcessPSDCalTime;
    string ProcessAPLCalTime;
    string ProcessDesciption;
    string ProcessModifiedUser;
    string ProcessModifiedDate;
}; 

int ToReturnProcessStructure(string ProcessItemId)
{
    cout << "Inside ToReturnProcessStructure" << endl;

    tag_t ItemRevisinQueryTag = NULLTAG;
    char *QueryInputEntry[2] = {"Item ID","Type"};
    char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
    int QueryOutputCount = 0;
    tag_t *QueryOutputTags = NULLTAG;
    QRY_find2("Item Revision...",&ItemRevisinQueryTag);
    if(ItemRevisinQueryTag!=NULLTAG)
    {
        QueryInputValue[0] = ProcessItemId.c_str();
        QueryInputValue[1] = "MEProcessRevision";
        QRY_execute(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue, &QueryOutputCount, &QueryOutputTags);
        cout << "Number of process found : " << QueryOutputCount << endl;
        if(QueryOutputCount>0)
        {
            int BVRCount = 0 ,
                BVRFlag = 0 ;
            tag_t *BVRTags = NULLTAG;
            tag_t BVRStoreTag = NULLTAG;
            ITEM_rev_list_bom_view_revs(QueryOutputTags[0], &BVRCount, &BVRTags);
            if(BVRCount>0)
            {
                for(int BVRIterator = 0;BVRIterator<BVRCount;BVRIterator++)
                {
                    char *BVRObjName = NULL;
                    string BVRObjectName;
                    AOM_ask_value_string(BVRTags[BVRIterator],"object_name",&BVRObjName);
                    BVRObjectName = BVRObjName;
                    cout << "BVR Object Name : " << BVRObjName << endl;
                    size_t position = BVRObjectName.find("View");
                    if (position != string::npos) 
                    {
                        BVRFlag++;
                        BVRStoreTag = BVRTags[BVRIterator];
                        cout << "BVR View found" << endl;
                        break;
                    }
                    else 
                    {
                        cout << "BVR View not found!" << endl;
                    }
                }
            }
            if(BVRFlag>0)
            {
                int CountOperations = 0;
                tag_t revRule = NULLTAG;
                tag_t window = NULLTAG;
                tag_t TopLineTag = NULLTAG;
                tag_t *TagOperations = NULLTAG;
                CFM_find("Latest Working", &revRule);
                BOM_create_window(&window);
                BOM_set_window_config_rule(window,revRule);
                BOM_set_window_pack_all(window,true);
                BOM_set_window_top_line(window, NULLTAG,QueryOutputTags[0] ,BVRStoreTag, &TopLineTag);
		        BOM_line_ask_child_lines(TopLineTag, &CountOperations, &TagOperations);
                cout << "Number of operations found under the process are : " << CountOperations << endl;
                if(CountOperations>0)
                {
                    for(int OperationIterator = 0;OperationIterator<CountOperations;OperationIterator++)
                    {
                        tag_t OperationItemTag = NULLTAG;
                        char *OperationItemId = NULL;
                        AOM_ask_value_tag(TagOperations[OperationIterator],bomAttr_lineItemRevTag, &OperationItemTag);
                        if(OperationItemTag!=NULLTAG)
                        {
                            AOM_ask_value_string(OperationItemTag,"item_id",&OperationItemId);
                            cout << "Operation Item ID : " << OperationItemId << endl;
                        }
                    }
                }
            }
        }
    }
    return 0;
}

vector<OperationDataReturn> ToRetrieveProperties(char *ID,string TypeString)
{
    //OperationDataReturn DataToBeReturn;
    vector<OperationDataReturn> result;
    tag_t ItemRevisinQueryTag = NULLTAG;
    char *QueryInputEntry[2] = {"Item ID","Type"};
    char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
    int QueryOutputCount = 0;
    tag_t *QueryOutputTags = NULLTAG;
    QRY_find2("Item Revision...",&ItemRevisinQueryTag);
    if(ItemRevisinQueryTag!=NULLTAG)
    {
        if(TypeString == "Process")
        {
            cout << "Inside Process" << endl;
            QueryInputValue[0] = ID;
            QueryInputValue[1] = "MEProcessRevision";
        }
        else
        {
            cout << "Inside Operation" << endl;
            QueryInputValue[0] = ID;
            QueryInputValue[1] = "MEOPRevision";
        }
        cout << "value of QueryInputValue[0] : " << QueryInputValue[0] << endl;
        cout << "value of QueryInputValue[1] : " << QueryInputValue[1] << endl;
        QRY_execute(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue, &QueryOutputCount, &QueryOutputTags);
        cout << "Number of process found : " << QueryOutputCount << endl;
        if(QueryOutputCount>0)
        {
            for(int ProcessIterator = 0;ProcessIterator<QueryOutputCount;ProcessIterator++)
            {
                char *ProcessItemId = NULL;
                char *ProcessMOSTFrequency = NULL;
                char *ProcessMOSTDivision = NULL;
                char *ProcessMOSTMen = NULL;
                char *ProcessGangSize = NULL;
                char *ProcessAPLGangSize = NULL;
                char *ProcessMOSTOnOff = NULL;
                char *ProcessCycleTime = NULL;
                char *ProcessCW = NULL;
                char *ProcessPSDCalTime = NULL;
                char *ProcessAPLCalTime = NULL;
                char *ProcessDesciption = NULL;
                char *ProcessModifiedUser = NULL;
                char *ProcessModifiedDate = NULL;

                int ProcessModifiedUserCount = 0;
                tag_t *ProcessModifiedUserTags = NULLTAG;
                if(TypeString == "Process")
                {
                    cout << "Inside Process" << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"item_id",&ProcessItemId);
                    cout << "Process Item ID is        : " << ProcessItemId << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEMstFrequency",&ProcessMOSTFrequency);
                    cout << "ProcessMOSTFrequency is   : " << ProcessMOSTFrequency << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEMstDivision",&ProcessMOSTDivision);
                    cout << "ProcessMOSTDivision is    : " << ProcessMOSTDivision << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEMstMen",&ProcessMOSTMen);
                    cout << "ProcessMOSTMen is         : " << ProcessMOSTMen << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEGangSize",&ProcessGangSize);
                    cout << "ProcessGangSize is        : " << ProcessGangSize << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEAplGangSize",&ProcessAPLGangSize);
                    cout << "ProcessAPLGangSize is     : " << ProcessAPLGangSize << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEMstonoff",&ProcessMOSTOnOff);
                    cout << "ProcessMOSTOnOff is       : " << ProcessMOSTOnOff << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEDPECT",&ProcessCycleTime);
                    cout << "ProcessCycleTime is       : " << ProcessCycleTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PEDPECW",&ProcessCW);
                    cout << "ProcessCW is              : " << ProcessCW << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_PSDCalTime",&ProcessPSDCalTime);
                    cout << "ProcessPSDCalTime is      : " << ProcessPSDCalTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_PR_APLCalTime",&ProcessAPLCalTime);
                    cout << "ProcessAPLCalTime is      : " << ProcessAPLCalTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"object_desc",&ProcessDesciption);
                    cout << "ProcessDesciption is      : " << ProcessDesciption << endl;
                    AOM_ask_value_tags(QueryOutputTags[ProcessIterator],"last_mod_user",&ProcessModifiedUserCount,&ProcessModifiedUserTags);
                    if(ProcessModifiedUserCount>0)
                    {
                        AOM_ask_value_string(ProcessModifiedUserTags[0],"user_id",&ProcessModifiedUser);
                    }
                    cout << "ProcessModifiedUser is      : " << ProcessModifiedUser << endl;
                    AOM_UIF_ask_value(QueryOutputTags[ProcessIterator],"last_mod_date",&ProcessModifiedDate);
                    cout << "ProcessModifiedDate is      : " << ProcessModifiedDate << endl;
                    result.push_back({ProcessItemId,
                                    ProcessMOSTFrequency,
                                    ProcessMOSTDivision,
                                    ProcessMOSTMen,
                                    ProcessGangSize,
                                    ProcessAPLGangSize,
                                    ProcessMOSTOnOff,
                                    ProcessCycleTime,
                                    ProcessCW,
                                    ProcessPSDCalTime,
                                    ProcessAPLCalTime,
                                    ProcessDesciption,
                                    ProcessModifiedUser,
                                    ProcessModifiedDate});
                }
                else
                {
                    cout << "Inside Operation" << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"item_id",&ProcessItemId);
                    cout << "Process Item ID is        : " << ProcessItemId << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEMstFrequency",&ProcessMOSTFrequency);
                    cout << "ProcessMOSTFrequency is   : " << ProcessMOSTFrequency << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEMstDivision",&ProcessMOSTDivision);
                    cout << "ProcessMOSTDivision is    : " << ProcessMOSTDivision << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEMstMen",&ProcessMOSTMen);
                    cout << "ProcessMOSTMen is         : " << ProcessMOSTMen << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEGangSize",&ProcessGangSize);
                    cout << "ProcessGangSize is        : " << ProcessGangSize << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEAplGangSize",&ProcessAPLGangSize);
                    cout << "ProcessAPLGangSize is     : " << ProcessAPLGangSize << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEMstonoff",&ProcessMOSTOnOff);
                    cout << "ProcessMOSTOnOff is       : " << ProcessMOSTOnOff << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEDPECT",&ProcessCycleTime);
                    cout << "ProcessCycleTime is       : " << ProcessCycleTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PEDPECW",&ProcessCW);
                    cout << "ProcessCW is              : " << ProcessCW << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_PSDCalTime",&ProcessPSDCalTime);
                    cout << "ProcessPSDCalTime is      : " << ProcessPSDCalTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"t5_OP_APLCalTime",&ProcessAPLCalTime);
                    cout << "ProcessAPLCalTime is      : " << ProcessAPLCalTime << endl;
                    AOM_ask_value_string(QueryOutputTags[ProcessIterator],"object_desc",&ProcessDesciption);
                    cout << "ProcessDesciption is      : " << ProcessDesciption << endl;
                    AOM_ask_value_tags(QueryOutputTags[ProcessIterator],"last_mod_user",&ProcessModifiedUserCount,&ProcessModifiedUserTags);
                    if(ProcessModifiedUserCount>0)
                    {
                        AOM_ask_value_string(ProcessModifiedUserTags[0],"user_id",&ProcessModifiedUser);
                    }
                    cout << "ProcessModifiedUser is      : " << ProcessModifiedUser << endl;
                    AOM_UIF_ask_value(QueryOutputTags[ProcessIterator],"last_mod_date",&ProcessModifiedDate);
                    cout << "ProcessModifiedDate is      : " << ProcessModifiedDate << endl;
                    result.push_back({ProcessItemId,
                                    ProcessMOSTFrequency,
                                    ProcessMOSTDivision,
                                    ProcessMOSTMen,
                                    ProcessGangSize,
                                    ProcessAPLGangSize,
                                    ProcessMOSTOnOff,
                                    ProcessCycleTime,
                                    ProcessCW,
                                    ProcessPSDCalTime,
                                    ProcessAPLCalTime,
                                    ProcessDesciption,
                                    ProcessModifiedUser,
                                    ProcessModifiedDate});
                }
                
            }
        }
    }

    return result;
}

json MppToPalmsys(string ProductBOPItemId,string ProductBOPObjectDesc)
{
    //json processArray = json::array();
    //root["ProductBOP_ID"] = ProductBOPItemId;
    json processArray = json::array();

    tag_t pBOPRevTag = NULLTAG;
    int pBOPStructureCount = 0;
    tag_t* pBOPStructureTag = NULL;

    const char* pBOPType = "MEProductBOPRevision";
    pBOPRevTag = GetBomLine(ProductBOPItemId, pBOPType);

    BOM_line_ask_child_lines(pBOPRevTag, &pBOPStructureCount, &pBOPStructureTag);
    cout << "Number of processes found under the pBOP: " << pBOPStructureCount << endl;

    if (pBOPStructureCount > 0)
    {
        for (int i = 0; i < pBOPStructureCount; i++)
        {
            json process;
            char* ProcessItemId = NULL;
            char* ProcessItemDesc = NULL;
            AOM_ask_value_string(pBOPStructureTag[i], "bl_item_item_id", &ProcessItemId);
            cout << "Process Item ID: " << ProcessItemId << endl;
            AOM_ask_value_string(pBOPStructureTag[i], "bl_item_object_desc", &ProcessItemDesc);
            string processStr;
            string processDescStr;
            processStr = ProcessItemId;
            processDescStr = ProcessItemDesc;
            process["Process_ID"] = processStr;

            string TypeString = "Process";
            //OperationDataReturn ProcessProperties = ToRetrieveProperties(ProcessItemId, TypeString);
            vector<OperationDataReturn> ProcessProperties = ToRetrieveProperties(ProcessItemId, TypeString);

            cout << "Printing Process values" << endl;
            for (const auto& PP : ProcessProperties) {
                cout << "ProcessItemId       : " << PP.ProcessItemId << endl;
                cout << "ProcessMOSTFrequency: " << PP.ProcessMOSTFrequency << endl;
                cout << "ProcessMOSTDivision : " << PP.ProcessMOSTDivision << endl;
                cout << "ProcessMOSTMen      : " << PP.ProcessMOSTMen << endl;
                cout << "ProcessGangSize     : " << PP.ProcessGangSize << endl;
                cout << "ProcessAPLGangSize  : " << PP.ProcessAPLGangSize << endl;
                cout << "ProcessMOSTOnOff    : " << PP.ProcessMOSTOnOff << endl;
                cout << "ProcessCycleTime    : " << PP.ProcessCycleTime << endl;
                cout << "ProcessCW           : " << PP.ProcessCW << endl;
                cout << "ProcessPSDCalTime   : " << PP.ProcessPSDCalTime << endl;
                cout << "ProcessAPLCalTime   : " << PP.ProcessAPLCalTime << endl;
                cout << "ProcessDesciption   : " << PP.ProcessDesciption << endl;
                cout << "ProcessModifiedUser : " << PP.ProcessModifiedUser << endl;
                cout << "ProcessModifiedDate : " << PP.ProcessModifiedDate << endl;
                process["Type"] = "Process";
                process["ProductBOP_ID"] = ProductBOPItemId;
                process["ProductBOP_Desc"] = ProductBOPObjectDesc;
                process["Process_MOST_Frequency"] = PP.ProcessMOSTFrequency;
                process["Process_MOST_Division"] = PP.ProcessMOSTDivision;
                process["Process_MOST_Men"] = PP.ProcessMOSTMen;
                process["Process_Gang_Size"] = PP.ProcessGangSize;
                process["Process_APL_Gang_Size"] = PP.ProcessAPLGangSize;
                process["Process_MOST_OnOff"] = PP.ProcessMOSTOnOff;
                process["Process_Cycle_Time"] = PP.ProcessCycleTime;
                process["Process_CW"] = PP.ProcessCW;
                process["Process_PSD_Cal_Time"] = PP.ProcessPSDCalTime;
                process["Process_APL_Cal_Time"] = PP.ProcessAPLCalTime;
                process["Process_Desciption"] = PP.ProcessDesciption;
                process["Process_Modified_User"] = PP.ProcessModifiedUser;
                process["Process_Modified_Date"] = PP.ProcessModifiedDate;
            }

            json operationArray = json::array();
            tag_t processRevTag = NULLTAG;
            const char* processType = "MEProcessRevision";
            processRevTag = GetBomLine(ProcessItemId, processType);

            int processStructureCount = 0;
            tag_t* processStructureTag = NULL;
            BOM_line_ask_child_lines(processRevTag, &processStructureCount, &processStructureTag);

            cout << "Number of operations found under the process: " << processStructureCount << endl;

            if (processStructureCount > 0)
            {
                for (int j = 0; j < processStructureCount; j++)
                {
                    json operation;
                    char* OperationItemId = NULL;
                    AOM_ask_value_string(processStructureTag[j], "bl_item_item_id", &OperationItemId);
                    cout << "Operation Item ID: " << OperationItemId << endl;

                    string operationStr;
                    operationStr = OperationItemId;
                    operation["Operation_ID"] = operationStr;

                    string TypeString1 = "Operation";
                    //OperationDataReturn OperationProperties = ToRetrieveProperties(OperationItemId, TypeString1);
                    vector<OperationDataReturn> OperationProperties = ToRetrieveProperties(OperationItemId, TypeString1);

                    cout << "Printing Operation values" << endl;
                    for (const auto& OP : OperationProperties) {
                        cout << "OperationItemId        : " << OP.ProcessItemId << endl;
                        cout << "OperationMOSTFrequency : " << OP.ProcessMOSTFrequency << endl;
                        cout << "OperationMOSTDivision  : " << OP.ProcessMOSTDivision << endl;
                        cout << "OperationMOSTMen       : " << OP.ProcessMOSTMen << endl;
                        cout << "OperationGangSize      : " << OP.ProcessGangSize << endl;
                        cout << "OperationAPLGangSize   : " << OP.ProcessAPLGangSize << endl;
                        cout << "OperationMOSTOnOff     : " << OP.ProcessMOSTOnOff << endl;
                        cout << "OperationCycleTime     : " << OP.ProcessCycleTime << endl;
                        cout << "OperationCW            : " << OP.ProcessCW << endl;
                        cout << "OperationPSDCalTime    : " << OP.ProcessPSDCalTime << endl;
                        cout << "OperationAPLCalTime    : " << OP.ProcessAPLCalTime << endl;
                        cout << "OperationDesc          : " << OP.ProcessDesciption << endl;
                        cout << "OperationModifiedUser  : " << OP.ProcessModifiedUser << endl;
                        cout << "OperationModifiedDate  : " << OP.ProcessModifiedDate << endl;
                        operation["Type"] = "Operation";
                        operation["ProductBOP_ID"] = ProductBOPItemId;
                        operation["ProductBOP_Desc"] = ProductBOPObjectDesc;
                        operation["Operation_MOST_Frequency"] = OP.ProcessMOSTFrequency;
                        operation["Operation_MOST_Division"] = OP.ProcessMOSTDivision;
                        operation["Operation_MOST_Men"] = OP.ProcessMOSTMen;
                        operation["Operation_Gang_Size"] = OP.ProcessGangSize;
                        operation["Operation_APL_Gang_Size"] = OP.ProcessAPLGangSize;
                        operation["Operation_MOST_OnOff"] = OP.ProcessMOSTOnOff;
                        operation["Operation_Cycle_Time"] = OP.ProcessCycleTime;
                        operation["Operation_CW"] = OP.ProcessCW;
                        operation["Operation_PSD_Cal_Time"] = OP.ProcessPSDCalTime;
                        operation["Operation_APL_Cal_Time"] = OP.ProcessAPLCalTime;
                        operation["Operation_Desc"] = OP.ProcessDesciption;
                        operation["Operation_Modified_User"] = OP.ProcessModifiedUser;
                        operation["Operation_Modified_Date"] = OP.ProcessModifiedDate;
                        operation["Process_ID"] = processStr;
                        operation["Process_Desc"] = processDescStr;
                    }                    
                    //operationArray.push_back(operation); 
                    processArray.push_back(operation);
                    MEM_free(OperationItemId);
                }
                MEM_free(processStructureTag);
            }            
            //process["Process_Structure"] = operationArray;
            processArray.push_back(process);
            MEM_free(ProcessItemId);
        }
        //root["data"] = processArray;
        MEM_free(pBOPStructureTag);
    }
    return processArray;
}
json MppToPalmsysProcess(string ProcessItemId,string ProcessObjectDesc)
{
    json processArray = json::array();
    json process;
    tag_t processRevTag = NULLTAG;
    int processStructureCount = 0;
    tag_t* processStructureTag = NULL;

    const char* processType = "MEProcessRevision";
    processRevTag = GetBomLine(ProcessItemId, processType);
    process["Process_ID"] = ProcessItemId;
    string TypeString = "Process";
    vector<OperationDataReturn> ProcessProperties = ToRetrieveProperties(ProcessItemId.c_str(), TypeString);
    cout << "Printing Process values" << endl;
    for (const auto& PP : ProcessProperties) {
        cout << "ProcessItemId       : " << PP.ProcessItemId << endl;
        cout << "ProcessMOSTFrequency: " << PP.ProcessMOSTFrequency << endl;
        cout << "ProcessMOSTDivision : " << PP.ProcessMOSTDivision << endl;
        cout << "ProcessMOSTMen      : " << PP.ProcessMOSTMen << endl;
        cout << "ProcessGangSize     : " << PP.ProcessGangSize << endl;
        cout << "ProcessAPLGangSize  : " << PP.ProcessAPLGangSize << endl;
        cout << "ProcessMOSTOnOff    : " << PP.ProcessMOSTOnOff << endl;
        cout << "ProcessCycleTime    : " << PP.ProcessCycleTime << endl;
        cout << "ProcessCW           : " << PP.ProcessCW << endl;
        cout << "ProcessPSDCalTime   : " << PP.ProcessPSDCalTime << endl;
        cout << "ProcessAPLCalTime   : " << PP.ProcessAPLCalTime << endl;
        cout << "ProcessDesciption   : " << PP.ProcessDesciption << endl;
        cout << "ProcessModifiedUser : " << PP.ProcessModifiedUser << endl;
        cout << "ProcessModifiedDate : " << PP.ProcessModifiedDate << endl;
        process["Type"] = "Process";
        process["Process_MOST_Frequency"] = PP.ProcessMOSTFrequency;
        process["Process_MOST_Division"] = PP.ProcessMOSTDivision;
        process["Process_MOST_Men"] = PP.ProcessMOSTMen;
        process["Process_Gang_Size"] = PP.ProcessGangSize;
        process["Process_APL_Gang_Size"] = PP.ProcessAPLGangSize;
        process["Process_MOST_OnOff"] = PP.ProcessMOSTOnOff;
        process["Process_Cycle_Time"] = PP.ProcessCycleTime;
        process["Process_CW"] = PP.ProcessCW;
        process["Process_PSD_Cal_Time"] = PP.ProcessPSDCalTime;
        process["Process_APL_Cal_Time"] = PP.ProcessAPLCalTime;
        process["Process_Desciption"] = PP.ProcessDesciption;
        process["Process_Modified_User"] = PP.ProcessModifiedUser;
        process["Process_Modified_Date"] = PP.ProcessModifiedDate;
    }
    BOM_line_ask_child_lines(processRevTag, &processStructureCount, &processStructureTag);
    cout << "Number of operations found under process : " << processStructureCount << endl;
    if (processStructureCount > 0)
    {
        for (int j = 0; j < processStructureCount; j++)
        {
            json operation;
            char* OperationItemId = NULL;
            AOM_ask_value_string(processStructureTag[j], "bl_item_item_id", &OperationItemId);
            cout << "Operation Item ID: " << OperationItemId << endl;

            string operationStr;
            operationStr = OperationItemId;
            operation["Operation_ID"] = operationStr;

            string TypeString1 = "Operation";
            vector<OperationDataReturn> OperationProperties = ToRetrieveProperties(OperationItemId, TypeString1);

            cout << "Printing Operation values" << endl;
            for (const auto& OP : OperationProperties) {
                cout << "OperationItemId        : " << OP.ProcessItemId << endl;
                cout << "OperationMOSTFrequency : " << OP.ProcessMOSTFrequency << endl;
                cout << "OperationMOSTDivision  : " << OP.ProcessMOSTDivision << endl;
                cout << "OperationMOSTMen       : " << OP.ProcessMOSTMen << endl;
                cout << "OperationGangSize      : " << OP.ProcessGangSize << endl;
                cout << "OperationAPLGangSize   : " << OP.ProcessAPLGangSize << endl;
                cout << "OperationMOSTOnOff     : " << OP.ProcessMOSTOnOff << endl;
                cout << "OperationCycleTime     : " << OP.ProcessCycleTime << endl;
                cout << "OperationCW            : " << OP.ProcessCW << endl;
                cout << "OperationPSDCalTime    : " << OP.ProcessPSDCalTime << endl;
                cout << "OperationAPLCalTime    : " << OP.ProcessAPLCalTime << endl;
                cout << "OperationDesc          : " << OP.ProcessDesciption << endl;
                cout << "OperationModifiedUser  : " << OP.ProcessModifiedUser << endl;
                cout << "OperationModifiedDate  : " << OP.ProcessModifiedDate << endl;
                operation["Type"] = "Operation";
                operation["Operation_MOST_Frequency"] = OP.ProcessMOSTFrequency;
                operation["Operation_MOST_Division"] = OP.ProcessMOSTDivision;
                operation["Operation_MOST_Men"] = OP.ProcessMOSTMen;
                operation["Operation_Gang_Size"] = OP.ProcessGangSize;
                operation["Operation_APL_Gang_Size"] = OP.ProcessAPLGangSize;
                operation["Operation_MOST_OnOff"] = OP.ProcessMOSTOnOff;
                operation["Operation_Cycle_Time"] = OP.ProcessCycleTime;
                operation["Operation_CW"] = OP.ProcessCW;
                operation["Operation_PSD_Cal_Time"] = OP.ProcessPSDCalTime;
                operation["Operation_APL_Cal_Time"] = OP.ProcessAPLCalTime;
                operation["Operation_Desc"] = OP.ProcessDesciption;
                operation["Operation_Modified_User"] = OP.ProcessModifiedUser;
                operation["Operation_Modified_Date"] = OP.ProcessModifiedDate;
                operation["Process_ID"] = ProcessItemId;
                operation["Process_Desc"] = ProcessObjectDesc;
            }
            processArray.push_back(operation);
            MEM_free(OperationItemId);
        }
        MEM_free(processStructureTag);

    }
    processArray.push_back(process);     

    return processArray;
}

json MppToPalmsysOperation(string OperationItemId,string OperationObjectDesc)
{
    json processArray = json::array();    
    string operationStr;
    operationStr = OperationItemId;
    vector<string> ProcessName;
    Item *p = new Item();
    tag_t LatestOPRevision = NULLTAG;
    LatestOPRevision = p->ReturnItemRevision(operationStr);
    if(LatestOPRevision!=NULLTAG)
    {
        int ParentCount = 0;
        int *Levels = 0;
        tag_t *ParentTags = NULLTAG;
        PS_where_used_all(LatestOPRevision,1,&ParentCount,&Levels,&ParentTags);
        if(ParentCount>0)
        {
            for(int OPParentIterator = 0;OPParentIterator<ParentCount;OPParentIterator++)
            {
                char *OPParentObjType = NULL;
                char *OPParentItemId = NULL;
                string OPParentObjType_str;
                string OPParentItemId_str;
                AOM_ask_value_string(ParentTags[OPParentIterator],"object_type",&OPParentObjType);
                cout << "OPParentObjType : "<< OPParentObjType << endl;
                OPParentObjType_str = OPParentObjType;
                if((OPParentObjType_str=="MEProcessRevision") || (OPParentObjType_str=="Process Revision"))
                {
                    AOM_ask_value_string(ParentTags[OPParentIterator],"item_id",&OPParentItemId);
                    cout << "OPParentItemId : "<< OPParentItemId << endl;
                    OPParentItemId_str = OPParentItemId;
                    ProcessName.push_back(OPParentItemId_str);
                }
            }MEM_free(ParentTags);
            cout << "after for loop end"<< endl;
        }
        for(int ProcessIterator = 0; ProcessIterator<ProcessName.size();ProcessIterator++)
        {
            cout << "Parent Process Name : " << ProcessName[ProcessIterator] << endl;
            string TypeString1 = "Operation";
            vector<OperationDataReturn> OperationProperties = ToRetrieveProperties(OperationItemId.c_str(), TypeString1);
            cout << "Printing Operation values" << endl;
            for (const auto& OP : OperationProperties) {
               
                json operation;
                cout << "OperationItemId        : " << OP.ProcessItemId << endl;
                cout << "OperationMOSTFrequency : " << OP.ProcessMOSTFrequency << endl;
                cout << "OperationMOSTDivision  : " << OP.ProcessMOSTDivision << endl;
                cout << "OperationMOSTMen       : " << OP.ProcessMOSTMen << endl;
                cout << "OperationGangSize      : " << OP.ProcessGangSize << endl;
                cout << "OperationAPLGangSize   : " << OP.ProcessAPLGangSize << endl;
                cout << "OperationMOSTOnOff     : " << OP.ProcessMOSTOnOff << endl;
                cout << "OperationCycleTime     : " << OP.ProcessCycleTime << endl;
                cout << "OperationCW            : " << OP.ProcessCW << endl;
                cout << "OperationPSDCalTime    : " << OP.ProcessPSDCalTime << endl;
                cout << "OperationAPLCalTime    : " << OP.ProcessAPLCalTime << endl;
                cout << "OperationDesc          : " << OP.ProcessDesciption << endl;
                cout << "OperationModifiedUser  : " << OP.ProcessModifiedUser << endl;
                cout << "OperationModifiedDate  : " << OP.ProcessModifiedDate << endl;
               
                operation["Operation_ID"] = OP.ProcessItemId;
                operation["Type"] = "Operation";
                operation["Operation_MOST_Frequency"] = OP.ProcessMOSTFrequency;
                operation["Operation_MOST_Division"] = OP.ProcessMOSTDivision;
                operation["Operation_MOST_Men"] = OP.ProcessMOSTMen;
                operation["Operation_Gang_Size"] = OP.ProcessGangSize;
                operation["Operation_APL_Gang_Size"] = OP.ProcessAPLGangSize;
                operation["Operation_MOST_OnOff"] = OP.ProcessMOSTOnOff;
                operation["Operation_Cycle_Time"] = OP.ProcessCycleTime;
                operation["Operation_CW"] = OP.ProcessCW;
                operation["Operation_PSD_Cal_Time"] = OP.ProcessPSDCalTime;
                operation["Operation_APL_Cal_Time"] = OP.ProcessAPLCalTime;
                operation["Operation_Desc"] = OP.ProcessDesciption;
                operation["Operation_Modified_User"] = OP.ProcessModifiedUser;
                operation["Operation_Modified_Date"] = OP.ProcessModifiedDate;
                operation["Process_ID"] = ProcessName[ProcessIterator];
               
                processArray.push_back(operation);  
            }
        }
        cout << "latest revision found" << endl;
    }
    cout << "Printing json object " << endl;
    cout << processArray.dump() << endl;
    return processArray;
}
void getplantdetails(string  plantcode, char closurerulename[50],char  revisionrulename[50],char attributename[50])
{

    tag_t plantQueryTag = NULLTAG;
    QRY_find2("Control Objects...",&plantQueryTag);
    if(plantQueryTag!=NULL)
    {

        cout << "Plant code  " << plantcode << endl;
        char **plantValuesp = (char **) MEM_alloc(5 * sizeof(char *));
        char *plantEntries[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        plantValuesp[0]="mppplnatdetails";
        plantValuesp[1]="mppplnatdetails";
        plantValuesp[2]="0";
        int plantCOCountp = 0;
       
        tag_t *plantCOTagsP = NULLTAG;

        QRY_execute(plantQueryTag, 3, plantEntries, plantValuesp, &plantCOCountp, &plantCOTagsP);
        if(plantCOTagsP>0)
        {
            char *UserInfo1 = NULL;
            char *UserInfo2 = NULL;
            char *UserInfo3 = NULL;
            char *UserInfo4 = NULL;
            char *UserInfo5 = NULL;
            char* token =NULL;
            char closurerule[50] = {0};
            char RR[50] = {0};
            char attribute[50] = {0};

            if(plantcode.find("1001")!=string::npos) //Pune Plant
            {
               AOM_ask_value_string(plantCOTagsP[0],"t5_Userinfo1",&UserInfo1);
               cout << "Control Object User Info 1 value is : " << UserInfo1 << endl;
               //BOMViewClosureRulesSTDP,STDP Released and Above,t5_PunMakeBuyIndicator
               //Closure Rule:- BOMViewClosureRulesSTDP
               //RR:- STDP Released and Above
               //t5_PunMakeBuyIndicator     

                token = strtok(UserInfo1, ",");
                if (token) {
                    strncpy(closurerule, token, sizeof(closurerule) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(RR, token, sizeof(RR) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(attribute, token, sizeof(attribute) - 1);
                }
                std::cout << "Part 1: " << closurerule << "\n";
                std::cout << "Part 2: " << RR << "\n";
                std::cout << "Part 3: " << attribute << "\n";


                tc_strcpy(closurerulename,closurerule);
                tc_strcpy(revisionrulename,RR);
                tc_strcpy(attributename,attribute);


            }
            else if(plantcode.find("2001")!=string::npos) //JSR Plant
            {
                AOM_ask_value_string(plantCOTagsP[0],"t5_Userinfo2",&UserInfo2);
                cout << "Control Object User Info 2 value is : " << UserInfo2 << endl;

                token = strtok(UserInfo2, ",");
                if (token) {
                    strncpy(closurerule, token, sizeof(closurerule) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(RR, token, sizeof(RR) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(attribute, token, sizeof(attribute) - 1);
                }
                std::cout << "Part 1: " << closurerule << "\n";
                std::cout << "Part 2: " << RR << "\n";
                std::cout << "Part 3: " << attribute << "\n";

                tc_strcpy(closurerulename,closurerule);
                tc_strcpy(revisionrulename,RR);
                tc_strcpy(attributename,attribute);
            }
            else if(plantcode.find("3001")!=string::npos) //UTK
            {
                AOM_ask_value_string(plantCOTagsP[0],"t5_Userinfo3",&UserInfo3);
                cout << "Control Object User Info 1 value is : " << UserInfo3 << endl;
                token = strtok(UserInfo3, ",");
                if (token) {
                    strncpy(closurerule, token, sizeof(closurerule) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(RR, token, sizeof(RR) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(attribute, token, sizeof(attribute) - 1);
                }
                std::cout << "Part 1: " << closurerule << "\n";
                std::cout << "Part 2: " << RR << "\n";
                std::cout << "Part 3: " << attribute << "\n";

                tc_strcpy(closurerulename,closurerule);
                tc_strcpy(revisionrulename,RR);
                tc_strcpy(attributename,attribute);
            }
            else if(plantcode.find("3100")!=string::npos) // LKO
            {
                AOM_ask_value_string(plantCOTagsP[0],"t5_Userinfo4",&UserInfo4);
                cout << "Control Object User Info 1 value is : " << UserInfo4 << endl;
                token = strtok(UserInfo4, ",");
                if (token) {
                    strncpy(closurerule, token, sizeof(closurerule) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(RR, token, sizeof(RR) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(attribute, token, sizeof(attribute) - 1);
                }
                std::cout << "Part 1: " << closurerule << "\n";
                std::cout << "Part 2: " << RR << "\n";
                std::cout << "Part 3: " << attribute << "\n";

                tc_strcpy(closurerulename,closurerule);
                tc_strcpy(revisionrulename,RR);
                tc_strcpy(attributename,attribute);
            }
            else if(plantcode.find("1500")!=string::npos)// DWD
            {
                AOM_ask_value_string(plantCOTagsP[0],"t5_Userinfo5",&UserInfo5);
                cout << "Control Object User Info 1 value is : " << UserInfo5 << endl;
                token = strtok(UserInfo5, ",");
                if (token) {
                    strncpy(closurerule, token, sizeof(closurerule) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(RR, token, sizeof(RR) - 1);
                }
                token = strtok(nullptr, ",");
                if (token) {
                    strncpy(attribute, token, sizeof(attribute) - 1);
                }
                std::cout << "Part 1: " << closurerule << "\n";
                std::cout << "Part 2: " << RR << "\n";
                std::cout << "Part 3: " << attribute << "\n";

                tc_strcpy(closurerulename,closurerule);
                tc_strcpy(revisionrulename,RR);
                tc_strcpy(attributename,attribute);
                
            }
            
        }
    }

    cout << "Get Plant Details completed...... "  << "\n";
    
}
tag_t GetplantwiseBomLine(string ItemID , char *type,char *closurerule, char *revisionrule1, char*makebuyindicator)
{
    cout << "Inside GetBomLine" << endl;

    tag_t ItemRevisinQueryTag = NULLTAG;
    tag_t ReturnTag = NULLTAG;
    char *QueryInputEntry[2] = {"Item ID","Type"};
    char **QueryInputValue = (char **) MEM_alloc(5 * sizeof(char *));
    int QueryOutputCount = 0;
    tag_t *QueryOutputTags = NULLTAG;
    int CountOperations = 0;
    tag_t revRule = NULLTAG;
    tag_t window = NULLTAG;
    tag_t TopLineTag = NULLTAG;
    tag_t *TagOperations = NULLTAG;
    //scope=PIE_TEAMCENTER;
    int 	n_closure_tags;
    tag_t * 	closure_tags;
    tag_t  	closure_tag;
    const char *revisionrule11 =revisionrule1;
    tag_t  *children=NULLTAG;
    cout << "Item ID inside function " << ItemID << endl;
    cout << "Item ID inside type " << type << endl;
    
    QRY_find2("Item Revision...",&ItemRevisinQueryTag);
    if(ItemRevisinQueryTag!=NULLTAG)
    {
        QueryInputValue[0] = ItemID.c_str();
        QueryInputValue[1] = type;
        QRY_execute(ItemRevisinQueryTag, 2, QueryInputEntry, QueryInputValue, &QueryOutputCount, &QueryOutputTags);
        cout << "Number of Design rev found : " << QueryOutputCount << endl;
        if(QueryOutputCount>0)
        {
            int BVRCount = 0 ,
            BVRFlag = 0 ;
            tag_t *BVRTags = NULLTAG;
            tag_t BVRStoreTag = NULLTAG;
            int countB=0;
            char *childid=NULL;
            char *plantcs=NULL;
            ITEM_rev_list_bom_view_revs(QueryOutputTags[0], &BVRCount, &BVRTags);
            if(BVRCount>0)
            {
                for(int BVRIterator = 0;BVRIterator<BVRCount;BVRIterator++)
                {
                    char *BVRObjName = NULL;
                    string BVRObjectName;
                    AOM_ask_value_string(BVRTags[BVRIterator],"object_name",&BVRObjName);
                    BVRObjectName = BVRObjName;
                    cout << "BVR Object Name : " << BVRObjName << endl;
                    size_t position = BVRObjectName.find("View");
                    size_t position1 = BVRObjectName.find("view");
                    if (position != string::npos ||position1 != string::npos ) 
                    {
                        BVRFlag++;
                        BVRStoreTag = BVRTags[BVRIterator];
                        cout << "BVR View found" << endl;
                        break;
                    }
                    else 
                    {
                        cout << "BVR View not found!" << endl;
                    }
                }
            }
            if(BVRFlag>0)
            {

                CFM_find(revisionrule1, &revRule);
                cout << "1 " << endl;
                BOM_create_window(&window);
                cout << "2" << endl;
                BOM_set_window_config_rule(window,revRule);
                cout << "3" << endl;
                PIE_find_closure_rules2(closurerule,PIE_TEAMCENTER,&n_closure_tags,&closure_tags);
                cout << "4" << endl;
                
                closure_tag=closure_tags[0];
                cout << "5" << endl;
                BOM_window_set_closure_rule(window,closure_tags[0],0,NULL,NULL);
                cout << "6" << endl;
                BOM_set_window_pack_all(window,true);
                cout << "7" << endl;
                BOM_window_hide_suppressed(window);
                cout << "8" << endl;
                BOM_set_window_top_line(window, NULLTAG,QueryOutputTags[0] ,BVRStoreTag, &TopLineTag);
                cout << "9" << endl;
                BOM_line_ask_child_lines(TopLineTag, &countB, &children);
                cout << "Child Count:-" << countB<<endl;
                if(countB>0)
                {
                    for(int a=0; a<countB;a++)
                    {
                        AOM_ask_value_string(children[a],"bl_rev_awp0Item_item_id",& childid);
                        cout << "Child Item ID:-" << childid<<endl;
                        string Designrev =childid;
                        AOM_ask_value_string(children[a],makebuyindicator,& plantcs);
                        cout << "CS of child :-" << plantcs<<endl;
                        string splantcs =plantcs;
                        if(splantcs.find("F")!=string::npos || splantcs.find("F30")!=string::npos || splantcs.find("F40")!=string::npos || splantcs.find("F50")!=string::npos)
                        {
                            childpartlist.push_back(Designrev);
                            cout << "Not Expanding Part :-" << Designrev<<endl;
                        
                        }
                        else if (splantcs.empty())
                        {
                            cout << "Not Expanding Part :-" <<endl;

                        }
                        else
                        {
                            GetplantwiseBomLine(Designrev, type,closurerule,revisionrule1,makebuyindicator);
                            childpartlist.push_back(Designrev);

                        }
                       

                    }

                }
                
            }
            
        }
       
    }
    
}
vector<string> BOMchildID(string ItemID , char *type,char *closurerule, char *revisionrule1, char*makebuyindicator)
{

    //vector<string> childpartlist;
    
    cout << "Inside BOM Vector................ "  << "\n";
    
    GetplantwiseBomLine(ItemID, type,closurerule,revisionrule1,makebuyindicator);

    cout << "Vector Size "  <<childpartlist.size()<< "\n";
    for(int b=0;b<childpartlist.size();b++)
    {
        cout << "Value inside Vector:-" <<childpartlist[b] <<"\n";

    }
    return childpartlist;

}

