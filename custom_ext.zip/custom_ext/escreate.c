#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tccore/item_msg.h>
#include <pie/pie.h>

#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define POM_enquiry_desc_order 1
#define POM_enquiry_like 16001

int cnt = 0;
int cntFlag = 0;

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


static int report_error(char *file, int line, char *call, int status, logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        int const    *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
        if (n_errors > 0)
        {
            printf("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            printf("\n%s\n", error_message_string);
        }

        printf("error %d at line %d in %s\n", status, line, file);
        printf("%s\n", call);

        if (exit_on_error)
        {
            printf("\nExiting program!\n");
            exit (status);
        }
    }
    return status;
}

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;

int val(char c)
{
    if (c >= '0' && c <= '9')
        return (int)c - '0';
    else
        return (int)c - 'A' + 10;
}
 
// Function to convert a number from given base 'b'
// to decimal
int toDeci(char *str, int base)
{
    int len = strlen(str);
    int power = 1; // Initialize power of base
    int num = 0;  // Initialize result
    int i;
 
    // Decimal equivalent is str[len-1]*1 +
    // str[len-1]*base + str[len-1]*(base^2) + ...
    for (i = len - 1; i >= 0; i--)
    {
        // A digit in input number must be
        // less than number's base
        if (val(str[i]) >= base)
        {
           printf("Invalid Number");
           return -1;
        }
 
        num += val(str[i]) * power;
        power = power * base;
    }
 
    return num;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


//Start Code to Explode BOM -3
void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	
	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,"View")==0)
				{
					flagBVR=1;	
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					if(tc_strcmp(viewTok,ViewBVR)==0)
					{
						flagBVR=1;	
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);		
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				
				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}
	
	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;
	
	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;	
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);	
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{
			
			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);	
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;
		
		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);
		
	}
	return ifail;
}
//End Code to Explode BOM -3


void  GetPlantDetails1( char * ES_Plnt ,char  getPlantCS[40] ,char  getLCSAPLRlz[40],char  getLCSSTDWrkg[40],char  getLCSSTDRlz[40],char  ContexPlantVal[40], char View[40], char ClsrRule[40], char RevRule[40])
{
      printf( "ES_Plnt:%s\n", ES_Plnt);

	  if(strcmp(ES_Plnt,"DHARWAD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApldRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDdWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStddRlzd");
		tc_strcpy(ContexPlantVal,"DHARWAD");
		tc_strcpy(View,"APLD View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLD");
		//tc_strcpy(RevRule,"APLD Released data only");
		tc_strcpy(RevRule,"APLD Released and Above");

	  }else  if(strcmp(ES_Plnt,"CVBU PUNE")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplpRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdpRlzd");
		tc_strcpy(ContexPlantVal,"CVBU Pune");
		tc_strcpy(View,"APLP View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLP");
		//tc_strcpy(RevRule,"APLP Released data only");
		tc_strcpy(RevRule,"APLP Released and Above");

	  }else  if( strcmp(ES_Plnt,"CAR")==0 || strcmp(ES_Plnt,"PCBU")==0 )
	  {
		printf("\n Inside CAR plnt ....");
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdRlzd");
		tc_strcpy(ContexPlantVal,"CAR");
		tc_strcpy(View,"APLC View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLC");
		//tc_strcpy(RevRule,"APLC Released data only");
		tc_strcpy(RevRule,"APLC Released and Above");

	  }else  if(strcmp(ES_Plnt,"CVBU JSR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApljRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDjWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdjRlzd");
		tc_strcpy(ContexPlantVal,"CVBU JSR");
		tc_strcpy(View,"APLJ View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLJ");
		//tc_strcpy(RevRule,"APLJ Released data only");
		tc_strcpy(RevRule,"APLJ Released and Above");


	  }else  if(strcmp(ES_Plnt,"CVBU LKO")==0 || strcmp(ES_Plnt,"PCBU LKO")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApllRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDlWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdlRlzd");
		tc_strcpy(ContexPlantVal,"CVBU LKO");
		tc_strcpy(View,"APLL View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLL");
		//tc_strcpy(RevRule,"APLL Released data only");
		tc_strcpy(RevRule,"APLL Released and Above");


	  }else  if(strcmp(ES_Plnt,"SMALLCAR AHD")==0 )
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplaRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDaWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdaRlzd");
		tc_strcpy(ContexPlantVal,"SMALLCAR AHD");
		tc_strcpy(View,"APLA View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLA");
		//tc_strcpy(RevRule,"APLA Released data only");
		tc_strcpy(RevRule,"APLA Released and Above");


	  }else  if(strcmp(ES_Plnt,"CVBU PNR")==0 || strcmp(ES_Plnt,"SMALLCAR PNR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsApluRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDuWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStduRlzd");
		tc_strcpy(ContexPlantVal,"CVBU PNR");
		tc_strcpy(View,"APLU View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLU");
		//tc_strcpy(RevRule,"APLU Released data only");
		tc_strcpy(RevRule,"APLU Released and Above");

	  }else  if(strcmp(ES_Plnt,"TMLDL JSR")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplsRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDsWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdsRlzd");
		tc_strcpy(ContexPlantVal,"CVBU JSR");
		tc_strcpy(View,"APLJ View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLJ");
		//tc_strcpy(RevRule,"APLJ Released data only");
		tc_strcpy(RevRule,"APLJ Released and Above");

	  }
	  else  if(strcmp(ES_Plnt,"PUVBU")==0) // to be change first
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcsAplvRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDvWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdvRlzd");

		tc_strcpy(ContexPlantVal,"PUVBU");
		tc_strcpy(View,"APLV View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLV");
		//tc_strcpy(RevRule,"APLV Released data only");
		tc_strcpy(RevRule,"APLV Released and Above");

	  }
	  else
	 {
		printf("\n Inside Else ....");
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getLCSAPLRlz,"T5_LcspAplpRlzd");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlz,"T5_LcsStdpRlzd");
		tc_strcpy(ContexPlantVal,"CVBU Pune");
		tc_strcpy(View,"APLP View");
		tc_strcpy(ClsrRule,"BOMViewClosureRuleAPLP");
		//tc_strcpy(RevRule,"APLP Released data only");
		tc_strcpy(RevRule,"APLP Released and Above");


	  }
}



extern EPM_decision_t DLLAPI estimate_sheet_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	int status1;
	int status2;
	int status3;
	int status4;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char*	ESPlt;
	char*	EsShop;
	char*	ESProcEdn;
	char*	PsdStdTime;
	char *  ChildRelErr = NULL;
	char *  SetChildRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];
	int   ifail				= 0;

	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			OprNo				= NULL;
	char*			WcNum				= NULL;
	char*			APLTime				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	char PlantCS[40];
	char LcsAplRlz[40];
	char LcsStdWrkg[40];
	char LcsStdRlz[40];
	char ContxtPlntVal[40];
	char ESView[40];
	char ClosureRule[40];
	char RevsnRule[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
    
	cntFlag = 0;
	char *  Errr = NULL;
	char *  APLTimeSet = NULL;
	char *  PrtSet = NULL;

char *username= NULL;
char *userid= NULL;

	int cnt = 0;
	int cnt1 = 0;
	int cntFlag = 0;
tag_t			user_tag				=NULLTAG;

	printf("\n Calling estimate_sheet_signoff_checks_Func %d.....\n",iNumAttch);

	if (tc_strcmp(Errr,"NULL") !=0) MEM_free(Errr);
				Errr=(char *)MEM_alloc(500);
				tc_strcpy(Errr," ");


if (tc_strcmp(APLTimeSet,"NULL") !=0) MEM_free(APLTimeSet);
				APLTimeSet=(char *)MEM_alloc(500);
				tc_strcpy(APLTimeSet," ");

if (tc_strcmp(PrtSet,"NULL") !=0) MEM_free(PrtSet);
				PrtSet=(char *)MEM_alloc(500);
				tc_strcpy(PrtSet," ");


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n estimate_sheet_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


 	ITKCALL( TCTYPE_find_type("T5_EstimateSheetRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		//char *qry_entries[1];
		//char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;
		int n_found1=0;
		 tag_t	*itemclass	= NULLTAG;
		 tag_t	*CntrlObjs	= NULLTAG;
		  tag_t item = NULLTAG;
			tag_t query = NULLTAG;
			tag_t query1 = NULLTAG;
			int n_entries=4;
			int n_entries1=2;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PEPlantName",&ESPlt));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_EstShop",&EsShop));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PEProcessEDNNo",&ESProcEdn));
			ITKCALL(AOM_ask_value_string(pTagAttch[i], "t5_PETimeOpnPsd",&PsdStdTime));

			printf("\n itemid %s.....\n",itemid);
			printf("\n ESPlt %s.....\n",ESPlt);
			printf("\n EsShop %s.....\n",EsShop);
			printf("\n ESProcEdn %s.....\n",ESProcEdn);
			printf("\n PsdStdTime %s.....\n",PsdStdTime);
			
	GetPlantDetails1(ESPlt,PlantCS,LcsAplRlz,LcsStdWrkg,LcsStdRlz,ContxtPlntVal,ESView,ClosureRule,RevsnRule);
	printf("\n PlantCS: %s \n",PlantCS);
	printf("\n LcsAplRlz: %s \n",LcsAplRlz);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
	printf("\n LcsStdRlz: %s \n",LcsStdRlz);
	printf("\n ContxtPlntVal: %s \n",ContxtPlntVal);
	printf("\n ESView: %s \n",ESView);
	printf("\n ClosureRule: %s \n",ClosureRule);
	printf("\n RevsnRule: %s \n",RevsnRule);

char
         *qry_entries[4] = {"ID","Plant Name","*Shop Name","Process EDN Number"},
         *qry_values[4] =  {itemid,ESPlt,EsShop,ESProcEdn};

	
    IFERR_REPORT(QRY_find("EstimateRevPlantShopEdnQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_tags_found, &itemclass));
    printf("\n n_tags_found %d", n_tags_found);fflush(stdout);

		item = itemclass[0];

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			if (!SetChildRelErr) MEM_free(SetChildRelErr);
			SetChildRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetChildRelErr,"");

			if(tc_strcmp(type_itemRev,"T5_EstimateSheetRevision" )==0)
			{
					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(item,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);

							AssyTag				= NULLTAG;
							AssyTag=PartTags[k];

							OprNo=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&OprNo));
							printf("\n\n\t\t Operation Number is :%s",OprNo);fflush(stdout);
							
							WcNum=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"t5_EPOCHPEBCNo",&WcNum));
							printf("\n\n\t\t WorkCenter Number is :%s",WcNum);fflush(stdout);
							printf("\n\n\t\t WorkCenter length is :%d",strlen(WcNum));fflush(stdout);

							if(strlen(WcNum)==0)
							{
								if(cnt==0)
								{
										cnt = 1;
										tc_strcat(Errr,"\nWork Centers Not found for below operations of Estimate Sheet");
										tc_strcat(Errr,"\nPlease Ensure Work Centers are present on all operations for Estimate sheet\n");
										tc_strcat(Errr,OprNo);
										tc_strcat(Errr,",");
										

								}else
									{
										 
										tc_strcat(Errr,OprNo);
										tc_strcat(Errr,",");
									   cnt = cnt+1;
								   }
								   
							}


							APLTime=NULL;
							ITKCALL(AOM_ask_value_string(AssyTag,"t5_PETimeOpnApl",&APLTime));
							printf("\n\n\t\t APLTime  is :%s",APLTime);fflush(stdout);

							if( tc_strcmp(APLTime,"0")!=0 || tc_strcmp(APLTime,"0.0")!=0 || tc_strcmp(APLTime,"0.00")!=0 )
							{
								/*check whether process sheet attached to ES or not.
								if process sheet not attached
								{
									if(cnt1==0)
									{
											cnt1 = 1;
											tc_strcat(APLTimeSet,"\nProcess Sheet attachment to each Operation with non-zero timing is Mandatory");
											tc_strcat(APLTimeSet,"\nSOLUTION: Please make sure process sheet send to PLM from NPP\n");
											tc_strcat(APLTimeSet,OprNo);
											tc_strcat(APLTimeSet,",");

									}
									else
										{
											tc_strcat(APLTimeSet,OprNo);
											tc_strcat(APLTimeSet,",");
										    cnt1 = cnt1+1;
									   }


								}
								*/

							}

						}
					}
					else
					{
							if (PartCnt==0)
							{
								printf("\n Estimate Sheet with zero operations");
								EMH_clear_errors();
								status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nOperations are not present for the Estimate Sheet you are releasing\nPlease Ensure You release the Estimate Sheet with operations");
								//status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,"\nOperations are not present for the Estimate Sheet you are releasing\nPlease Ensure You release the Estimate Sheet with operations");
								decision = EPM_nogo;
								return ITK_errStore;
							}
						

					}


					printf("\n Errr: %s\n",Errr);fflush(stdout);
					
				if( tc_strcmp(CurrentTask,"Assign Estimate Sheet" )==0 || ( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) ) )
				{
					if(cnt>0)
					{
						printf("\n Estimate Sheet with blank WC:  %s \n",Errr);
						EMH_clear_errors();
						status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,Errr);
						decision = EPM_nogo;
						return ITK_errStore;
					}
				}


					// Process Sheet ES Checks
					if(POM_get_user_id (&userid)==ITK_ok);
					printf("\n\n  userid : %s\n",userid); fflush(stdout);

					ITKCALL(POM_get_user(&username,&user_tag));
            		printf("\n Starting for username :%s....\n",username);fflush(stdout);

					//if(nlsStrCmp(userid,"pgm02434")==0 && nlsStrCmp(t5PEDNTypeDup,"AW")==0 )
					if( tc_strcmp(userid,"pgm02434")==0 && tc_strcmp(CurrentTask,"Assign Estimate Sheet")==0 )
					{
					  printf("\nSetting attribute");fflush(stdout);

					  ITKCALL(AOM_lock(item));
							ITKCALL ( AOM_set_value_string(item,"t5_PfdStatus","True"));
							ITKCALL(AOM_save(item));
							ITKCALL(AOM_unlock(item));
					}


	

 //if(nlsStrCmp(StrUsrNamDup,"pgm02434")==0 && nlsStrCmp(t5PEDNTypeDup,"AR")==0 )
				if( tc_strcmp(userid,"pgm02434")==0 && tc_strcmp(CurrentTask,"Reviewer can review Estimate")==0 )
					{
						printf("\nBypass process sheet check");
						goto CLEANUP;
					}

					printf("\n ESPlt %s.....\n",ESPlt);

					if( tc_strcmp(ESPlt,"CVBU PUNE")==0 && tc_strcmp(CurrentTask,"Reviewer can review Estimate")==0 )
					{
						if(cnt1>0)
						{
							printf("\n Process Sheet check for non zero APL timing:  %s \n",APLTimeSet);
							EMH_clear_errors();
							status2=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,APLTimeSet);
							decision = EPM_nogo;
							return ITK_errStore;
						}


					}


				if( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) )
					{
					  if(strlen(PsdStdTime)==0)
						{
								printf("\n Estimate Sheet with no PSD timing");
								EMH_clear_errors();
								status3=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"\nPlease do the following activity before signoff the Estimate Sheet\nSelect Estimate Sheet, Manufacturing --> Planning --> Estimate Sheet --> Update All Estimate Operation(PSD View)");
								decision = EPM_nogo;
								return ITK_errStore;
						}
					}

					//Explode latest Released Item Rev upto 99 lvl and check for ES created for inhouse parts, if not give softcheck. //

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"MultiLvlExplsn", "Estimate Sheet"};


					IFERR_REPORT(QRY_find("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					IFERR_REPORT(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						int escnt=0;
						if( tc_strcmp(CurrentTask,"Assign Estimate Sheet" )==0 || ( (tc_strstr(CurrentTask,"Update Time by")!=NULL) && (tc_strstr(CurrentTask,"PSD")!=NULL) ) )
						{

							tag_t*			EstToMstrRelTags			= NULLTAG;
							tag_t *  rev_list;
							int n_entriesds=1;
							int n_entrieses=2;

							int  EstToMstrRel=0;
							int  dsrev=0;

							EstToMstrRel=0;
							CALLAPI(AOM_ask_value_tags(item,"T5_Estimate_Design_Relation",&EstToMstrRel,&EstToMstrRelTags));
							printf("\n\n\t\t EstToMstrRel Count is :%d",EstToMstrRel);fflush(stdout);

							if(EstToMstrRel>0)
							{
								tag_t			DesgnTag	= NULLTAG;

								tag_t queryds = NULLTAG;
								tag_t queryes = NULLTAG;

								char *DesignId = NULL;
								char *DesignRevId = NULL;
								char *RelStat_Name = NULL;

								char * ItemName ;
								char * PrtType ;
								char * PrtCS ;

								char   *taskowning_groupVal=NULL;

								tag_t	*itemrevdsclass	= NULLTAG;
								tag_t	*esclass	= NULLTAG;
								tag_t	DesignrevTag	= NULLTAG;

								int ds_tags_found=0;
								int es_tags_found=0;
								int stat_count=0;
								tag_t*    stat_list=NULLTAG;

								int FlagGotLatestRev=0;
								int ChldCnt=0;
								int StructChldCnt=0;
								

								int iChildItemTag_DVC	= 0;
								tag_t t_ChildItemRev_DVC	= NULLTAG;

								struct	BomChldStrut	ChldStrutERC[5000];

								tag_t	objChild			= NULLTAG;
								tag_t	objChild_bvr			= NULLTAG;
								int child_lvl=0;
								char	*c_Qty						=	NULL;



								//char *qry_entriesds[1] = {"Item ID"};
								//char **qry_valuesds =	(char **) MEM_alloc(10 * sizeof(char *));

								DesgnTag=EstToMstrRelTags[0];
								ITKCALL(AOM_ask_value_string(DesgnTag,"item_id",&DesignId));
								printf("\n\n\t\t DesignId is :%s",DesignId);fflush(stdout);

								IFERR_REPORT(QRY_find("GetLatestItemRev", &queryds));
								printf("\n found qryy ");fflush(stdout);
								
								char
								*qry_entriesds[1] = {"ID"},
								*qry_valuesds[1] =  {DesignId};

								//qry_valuesds[0]=DesignId;

								IFERR_REPORT(QRY_execute(queryds, n_entriesds, qry_entriesds, qry_valuesds, &ds_tags_found, &itemrevdsclass));
								printf("\n ds_tags_found %d", ds_tags_found);fflush(stdout);

								FlagGotLatestRev=0;
								for (dsrev = 0; dsrev<ds_tags_found; dsrev++)
								{
									DesignrevTag=NULLTAG;
									DesignrevTag=itemrevdsclass[dsrev];

									DesignRevId=NULL;
									ITKCALL(AOM_ask_value_string(DesignrevTag,"item_revision_id",&DesignRevId));
									printf("\n\n\t\t DesignRevId is :%s",DesignRevId);fflush(stdout);

									stat_list=NULLTAG;
									stat_count=0;
									ITKCALL(WSOM_ask_release_status_list(DesignrevTag,&stat_count,&stat_list));
									printf("\n stat_count :%d is\n",stat_count);fflush(stdout);

									RelStat_Name=NULL;
									ITKCALL(AOM_ask_name(stat_list[stat_count-1],&RelStat_Name));
									printf("\n RelStat_Name is :%s\n",RelStat_Name);fflush(stdout);

									if(tc_strcmp(RelStat_Name,"")!=0)
										{
										printf("\n Test11");fflush(stdout);
											if (tc_strcmp(RelStat_Name,LcsAplRlz)==0 || tc_strcmp(RelStat_Name,LcsStdWrkg)==0 || tc_strcmp(RelStat_Name,LcsStdRlz)==0)
											{
												printf("\n Got Latest Rev : [%s,%s]",DesignId,DesignRevId);fflush(stdout);
												FlagGotLatestRev=1;
												break;
											}
										}
								}

								printf("\n FlagGotLatestRev : [%d]",FlagGotLatestRev);fflush(stdout);

								if(FlagGotLatestRev==1)
								{
									printf("\n Latest Partnumber Rev is : [%s,%s]",DesignId,DesignRevId);fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(DesignrevTag,"owning_group",&taskowning_groupVal));
										printf("\n  taskowning_groupVal:%s ..............",taskowning_groupVal);fflush(stdout);

										//if((tc_strstr(taskowning_groupVal,"APL")!=NULL)|| (tc_strstr(taskowning_groupVal,"STD")!=NULL) )
										if((tc_strstr(taskowning_groupVal,"APL")!=NULL))
										{
											ITKCALL(Get_Part_BOM_Lvl(DesignrevTag,99,ClosureRule,RevsnRule,ESView,ChldStrutERC,&StructChldCnt));

										}
										else
										{
											ITKCALL(Get_Part_BOM_Lvl(DesignrevTag,99,ClosureRule,RevsnRule,"View",ChldStrutERC,&StructChldCnt));
										}


									printf("\n\t\t StructChldCnt:%d",StructChldCnt);fflush(stdout);
									
									ChldCnt=0;
									  for ( ChldCnt = 1; ChldCnt <= StructChldCnt; ChldCnt++)
									  {
										objChild		= NULLTAG;
										objChild_bvr	= NULLTAG;
										c_Qty			= NULL;
										child_lvl       =0;

										printf("\nPrint Item ID==>%d\n",ChldCnt);fflush(stdout);

										objChild=ChldStrutERC[ChldCnt].child_objs;
										objChild_bvr=ChldStrutERC[ChldCnt].child_objs_bvr;
										child_lvl=ChldStrutERC[ChldCnt].child_objs_lvl;
										
										ItemName=NULL;
										AOM_ask_value_string(objChild,"item_id",&ItemName);
										printf("\nItemName==>%s\n",ItemName);fflush(stdout);

										printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);


										AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
										printf("\nQty==>%s\n",c_Qty);fflush(stdout);

										PrtType=NULL;
										ITKCALL(AOM_ask_value_string(objChild,"t5_PartType",&PrtType));
										printf("\n\n\t PrtType-->%s",PrtType);fflush(stdout);

										if( (strcmp(PrtType,"G") != 0) || (strcmp(PrtType,"D")!=0) )
										{
											printf("\n\n\t\t inside Validation");	fflush(stdout);

											PrtCS=NULL;
											ITKCALL(AOM_ask_value_string(objChild,PlantCS,&PrtCS));
											printf("\n\n\t PrtCS-->%s",PrtCS);fflush(stdout);

											if( (strcmp(PrtCS,"E50") == 0) || (strcmp(PrtCS,"E99")==0) )
											{
												
												IFERR_REPORT(QRY_find("EstimateRevPlantShopEdnQry", &queryes));
												printf("\n found queryes ");fflush(stdout);
												
												char
												*qry_entrieses[2] = {"ID","Plant Name"},
												*qry_valueses[2] =  {ItemName,ESPlt};

												//qry_valuesds[0]=DesignId;

												es_tags_found=0;
												IFERR_REPORT(QRY_execute(queryes, n_entrieses, qry_entrieses, qry_valueses, &es_tags_found, &esclass));
												printf("\n es_tags_found %d", es_tags_found);fflush(stdout);

												if(es_tags_found>0)
												{
													printf("\n Estimate Available for :[%s]",ItemName);fflush(stdout);
												}
												else
												{
													printf("\n Estimate Not Available for :[%s]",ItemName);fflush(stdout);
													if(escnt==0)
													{
															escnt = 1;
															tc_strcat(PrtSet,"\nEstimate Sheet Not Available for Following Parts");
															tc_strcat(PrtSet,"\nPlease Ensure Estimate Sheet gets available in system for Following Parts\n");
															tc_strcat(PrtSet,ItemName);
															tc_strcat(PrtSet,",");
															

													}
													else
													{	 
														if(tc_strstr(PrtSet,ItemName)==NULL)
														{
															tc_strcat(PrtSet,ItemName);
															tc_strcat(PrtSet,",");
														}
															escnt = escnt+1;
													 }


												}

												
												

											}

											
										} 
										 



									 }
								  }

							}
						} 

						if(escnt>0)
						{
							printf("\n Estimate Sheet 99 lvl explosion... %s \n",PrtSet);
							EMH_clear_errors();
							status1=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,PrtSet);
							decision = EPM_nogo;
							return ITK_errStore;
						}


					}// if(n_found1>0) end of control object


					//End of Explode latest Released Item Rev upto 99 lvl and check for ES created for inhouse parts, if not give softcheck. //
			 }
		}
  }



CLEANUP:
	decision = EPM_go;
	return decision;
}


int ES_APLPrereleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_APLPrereleased***************\n ");fflush(stdout);


   strcpy(lcsToset,"T5_APLPre-Released");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_APLPrereleased \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}


	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];


									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////



								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));

							
							
						}
					}

	}

	return error_code;
}


int ES_APLFinalReleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_APLFinalReleased***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_APLFinalReleased");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_APLFinalReleased \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status /////

								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
							
							
						}
					}

	}

	return error_code;
}


int ES_PSDWorking( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_PSDWorking***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_PSDWorking");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDWorking \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

			CALLAPI(AOM_lock(DMLTag));
           CALLAPI(AOM_set_value_string(DMLTag,"t5_PEAgency","PSD"));
			CALLAPI(AOM_save(DMLTag));
		    CALLAPI(AOM_unlock(DMLTag));

	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{
	    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////

								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
							
							
						}
					}

	}

	return error_code;
}


int ES_PSDFinalReleased( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	date_t Release_date;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_PSDFinalReleased***************\n ");fflush(stdout);
   strcpy(lcsToset,"T5_PSDFinalReleased");

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ES_PSDFinalReleased \n"); fflush(stdout);

	


	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
			printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
		   CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
     	  // CALLAPI(ITK_set_bypass(TRUE));
		   CALLAPI(AOM_lock(DMLTag));
           CALLAPI(AOM_set_value_date(DMLTag,"t5_ActualRelDate",Release_date));
			CALLAPI(AOM_save(DMLTag));
		    CALLAPI(AOM_unlock(DMLTag));
	}

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{

		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(DMLTag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
					printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

									// remove status ///
											tag_t		tReleaseStatusList_checkin=NULLTAG; 
											tag_t		class_id				=     NULLTAG;

											char		*class_name				=    NULL;

											int			n_values_checkin			=0; 
											int			cunt1			=0; 
											int			cunt2			=0; 

											logical		log1;
											tag_t*		attr_tags_checkin		=	NULLTAG; 
											logical		*is_it_null_checkin		=   NULL; 
											logical		*is_it_empty_checkin	=   NULL; 

										int       st_count=0;
										tag_t*    status_list;


											ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
											ITK_CALL(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);

											ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
											printf("\n after getting rel stat...");fflush(stdout);

									/*
											CALLAPI(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
											printf("\n st_count:[%d]",st_count);fflush(stdout);

											if(st_count>0)
											{
												for (cunt2 =  0; cunt2 < st_count; cunt2++)
												{
													CR_remove_release_status(AssyTag,status_list[cunt2]);	
												}
											}
									*/
											

											ITK_CALL(POM_unload_instances (1,&AssyTag));
											printf("\n test2 \n");fflush(stdout);
											ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
											printf("\n test3 \n");fflush(stdout);
											ITK_CALL(POM_is_loaded(AssyTag,&log1));
											printf("\n test4 \n");fflush(stdout);

											if(log1 == 1)
											{
												 printf(" Load Success\n " );
											}
											else
											printf("Load Failure\n"  );
											

											ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
											printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

											if(n_values_checkin>0)
											{
												printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
												ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
												printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);


												for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
												{
													printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
													ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

													printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
													
													ITK_CALL(POM_save_instances(1,&AssyTag,1));
													//ITK_CALL(POM_refresh_instances(1,&AssyTag,class_id,2));
													ITK_CALL(AOM_lock(AssyTag));
													ITK_CALL(AOM_save(AssyTag));
													ITK_CALL(AOM_refresh(AssyTag,1));
													ITK_CALL(AOM_unlock(AssyTag));
												}
											}

									//// End of remove status //////

								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
							
							
						}
					}
	}

	return error_code;
}



int Save_ES_Msg( METHOD_message_t *msg, va_list  args )
{

    tag_t	TaskTag		= va_arg(args, const tag_t);

	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *item_id 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *groupName 	   = NULL;
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;

	//const char*   CR_EM_role = "CR_ERC_EM";
	const char*   ES_Planner_role = "ES_Planner";
	const char*   ES_Reviewer_role = "ES_Reviewer";

	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;

	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name3[TCTYPE_name_size_c+1];
	char   userid[SA_user_size_c+1];
	WSO_search_criteria_t  	criteria;

	groupName = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"EstimateSheet_WF");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

    printf("\n **************inside Save_CR_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_EstimateSheetRevision")==0)
	{
		    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskTag, "item_id", &item_id);
			AOM_ask_value_string( TaskTag,"t5_PEPlannedBy",&EstPlanner);
            AOM_ask_value_string( TaskTag, "t5_PEProcessApproveBy", &EstReviewer);

			 AOM_ask_value_string( TaskTag, "t5_PEPlantName", &EstPlntName);

	printf("\n EstPlntName is : %s\n",EstPlntName);fflush(stdout);
	
	if(strcmp(EstPlntName,"CAR")==0 || strcmp(EstPlntName,"PCBU")==0)
    {
		tc_strcpy(PsdRoleName,"EstimateCAR AssignReview");
	}
	else if(strcmp(EstPlntName,"CVBU PUNE")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUPUNE AssignReview");
	}
	else if(strcmp(EstPlntName,"CVBU JSR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUJSR AssignReview");
	}
	else if(strcmp(EstPlntName,"CVBU LKO")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBULKO AssignReview");
	}
	else if(strcmp(EstPlntName,"CVBU PNR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateCVBUUTK AssignReview");
	}
	else if(strcmp(EstPlntName,"DHARWAD")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateDHARWAD AssignReview");
	}
	else if(strcmp(EstPlntName,"SMALLCAR AHD")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateSANAND AssignReview");
	}
	else if(strcmp(EstPlntName,"SMALLCAR PNR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateSMALLCARPNR AssignReview");
	}
	else if(strcmp(EstPlntName,"PCBU LKO")==0)
	{
		tc_strcpy(PsdRoleName,"EstimatePCBULKO AssignReview");
	}
	else if(strcmp(EstPlntName,"TMLDL JSR")==0)
	{
		tc_strcpy(PsdRoleName,"EstimateTMLDLJSR AssignReview");
	}
	else
	{
		printf("\nInvalid PlantName on Estimate sheet......\n");fflush(stdout); 
	}	


			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n EstPlanner : %s\n",EstPlanner);fflush(stdout);
			printf("\n EstReviewer is : %s\n",EstReviewer);fflush(stdout);
			printf("\n PsdRoleName is : %s\n",PsdRoleName);fflush(stdout);
			

			//############################### REMOVE PARTICIPALNTS START################################/

			/*if(GRM_find_relation_type("HasParticipant", &CR_rel_type)!=ITK_ok)PrintErrorStack();
			if (CR_rel_type!=NULLTAG)
			{
				printf("\n MT:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
				if(GRM_list_secondary_objects_only(TaskTag,CR_rel_type,&Relcount,&RelCRTags)!=ITK_ok)PrintErrorStack();
				printf("\n MT: RelCRTags count: %d",Relcount);fflush(stdout);	
				for (jk=0;jk<Relcount ;jk++ )
				{						
					CR_Asgn_Part = RelCRTags[jk];
					if(TCTYPE_ask_object_type(CR_Asgn_Part,&ObjTypCR));
					if(TCTYPE_ask_name(ObjTypCR,type_namee));
					printf("\n CR: Participants Name: %s", type_namee);fflush(stdout);					
					if ((tc_strcmp(type_namee,"T5_IRMS_DeptHead")==0)||(tc_strcmp(type_namee,"T5_IRMS_EM")==0))
					{
						if(AOM_UIF_ask_value(CR_Asgn_Part,"fnd0AssigneeUser",&CRAssignee)!=ITK_ok)PrintErrorStack();
						printf("\n Removing: CRAssignee: [%s] ",CRAssignee);fflush(stdout);
						AOM_lock(TaskTag);
						if(ITEM_rev_remove_participant (TaskTag,CR_Asgn_Part)!=ITK_ok)PrintErrorStack();
						AOM_save(TaskTag);
						AOM_unlock(TaskTag);
					}
					
				}
			}*/

			if(EstPlanner!=NULL)
			{
				printf("\n EstPlanner ....");fflush(stdout);
				if(SA_find_group(groupName, &Grp_tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(ES_Planner_role,&CR_GrHd_Tag)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(CR_GrHd_Tag,Grp_tag1,&No_GH,&GHTags)!=ITK_ok)PrintErrorStack();
				printf("\n EstPlanner CR:No_GH :[%d]",No_GH);  fflush(stdout);
				if(No_GH>0)
				{
					for(ii=0;ii<No_GH;ii++)
					{	
						printf("\n EstPlanner CR:EM no: [%d]",ii);fflush(stdout);
						if (AOM_ask_value_string(GHTags[ii],"user_name",&member_name)!=ITK_ok)   PrintErrorStack();
						if(TCTYPE_ask_object_type(GHTags[ii],&objTypeTag2));
						if(TCTYPE_ask_name(objTypeTag2,type_name1));
						printf("\n   EstPlanner  type_name1 :: %s\n", type_name1);fflush(stdout);

						printf("\n EstPlanner User ID Name :[%s]\n",userid);
						printf("\n EstPlanner member_name :[%s]\n",member_name);
						if(strcmp(member_name,EstPlanner)==0)
						{
							if(EPM_get_participanttype ("T5_EstimatePlanner",&participant_type2)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags[ii],participant_type2,&participant_tag2)!=ITK_ok)PrintErrorStack();
							AOM_lock(TaskTag);			
							if(ITEM_rev_add_participant(TaskTag,participant_tag2)!=ITK_ok)PrintErrorStack();
							AOM_save(TaskTag);
							AOM_unlock(TaskTag);
							printf("\n EstPlanner Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags);
				}

			if(EstReviewer!=NULL)
			{
				printf("\n EstReviewer CR:Setting Group_Head...");fflush(stdout);
				if(SA_find_group(groupName, &Grp_tag2)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(ES_Reviewer_role,&CR_GrHd_Tag1)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(CR_GrHd_Tag1,Grp_tag2,&No_GH1,&GHTags1)!=ITK_ok)PrintErrorStack();
				printf("\n EstReviewer CR:No_GH1 :[%d]",No_GH1);  fflush(stdout);
				if(No_GH1>0)
				{
					for(iii=0;iii<No_GH1;iii++)
					{	
						printf("\n EstReviewer CR:EM no: [%d]",iii);fflush(stdout);
						if (AOM_ask_value_string(GHTags1[iii],"user_name",&member_name1)!=ITK_ok)   PrintErrorStack();
						if(TCTYPE_ask_object_type(GHTags1[iii],&objTypeTag4));
						if(TCTYPE_ask_name(objTypeTag4,type_name2));
						printf("\n   EstReviewer  type_name2 :: %s\n", type_name2);fflush(stdout);

						printf("\n EstReviewer User ID Name :[%s]\n",userid);
						printf("\n EstReviewer member_name1 :[%s]\n",member_name1);
						if(strcmp(member_name1,EstReviewer)==0)
						{
							if(EPM_get_participanttype ("T5_EstimateReviewer",&participant_type3)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags1[iii],participant_type3,&participant_tag3)!=ITK_ok)PrintErrorStack();
							AOM_lock(TaskTag);			
							if(ITEM_rev_add_participant(TaskTag,participant_tag3)!=ITK_ok)PrintErrorStack();
							AOM_save(TaskTag);
							AOM_unlock(TaskTag);
							printf("\n EstReviewer Assigned..DoneXXXX\n");

						}
					}
				}
				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags1);
				}			


			/*if(PsdRoleName!=NULL)
			{
				printf("\n PsdRoleName CR:Setting Group_Head...");fflush(stdout);
				if(SA_find_group(groupName, &Grp_tag3)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(PsdRoleName,&CR_GrHd_Tag2)!=ITK_ok)PrintErrorStack();
				if(SA_find_groupmember_by_role(CR_GrHd_Tag2,Grp_tag3,&No_GH2,&GHTags2)!=ITK_ok)PrintErrorStack();
				printf("\n PsdRoleName CR:No_GH2 :[%d]",No_GH2);  fflush(stdout);
				if(No_GH2>0)
				{
					for(ij=0;ij<No_GH2;ij++)
					{	
						printf("\n PsdRoleName CR:EM no: [%d]",ij);fflush(stdout);
						if (AOM_ask_value_string(GHTags2[ij],"user_name",&member_name2)!=ITK_ok)   PrintErrorStack();
						if(TCTYPE_ask_object_type(GHTags2[ij],&objTypeTag3));
						if(TCTYPE_ask_name(objTypeTag3,type_name3));
						printf("\n PsdRoleName type_name3 :: %s\n", type_name3);fflush(stdout);

						printf("\n PsdRoleName User ID Name :[%s]\n",userid);
						printf("\n PsdRoleName member_name2 :[%s]\n",member_name2);
						//if(strcmp(member_name2,EstReviewer)==0)
						//{
							if(EPM_get_participanttype ("T5_EstimateActor",&participant_type5)!=ITK_ok)PrintErrorStack();
							if(EPM_get_participanttype ("T5_EstimateApprover",&participant_type4)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags2[ij],participant_type5,&participant_tag5)!=ITK_ok)PrintErrorStack();
							if(EPM_create_participant(GHTags2[ij],participant_type4,&participant_tag4)!=ITK_ok)PrintErrorStack();
							AOM_lock(TaskTag);			
							if(ITEM_rev_add_participant(TaskTag,participant_tag5)!=ITK_ok)PrintErrorStack();
							if(ITEM_rev_add_participant(TaskTag,participant_tag4)!=ITK_ok)PrintErrorStack();
							AOM_save(TaskTag);
							AOM_unlock(TaskTag);
							printf("\n PsdRoleName Assigned..DoneXXXX\n");

						//}
					}

				}

				AOM_refresh ( TaskTag,TRUE);
				MEM_free(GHTags2);
				}			
			*/
	}

    return error_code;

}

void  GetESPlantFromRole( char  getPlantES[40])
{
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	char   *PlantName=NULL;


	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

      PlantName=subString(roleName,3,4);
      printf( "PlantName:%s\n", PlantName);fflush(stdout);

	  tc_strcpy(getPlantES,PlantName);
	  printf( "getPlantES:%s\n", getPlantES);fflush(stdout);
}

int myESDomainNameLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	GetESPlantFromRole(PlantES);
	printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DDMAIN");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JDMAIN");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LDMAIN");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"ADMAIN");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"UDMAIN");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SDMAIN");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PDMAIN");
		}

	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
         *qry_values[2] =  {"*", CntrlSysCD};


    IFERR_REPORT(QRY_find("ControlObjQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

int myESShopNameLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	GetESPlantFromRole(PlantES);
	printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DSHOP");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JSHOP");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LSHOP");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"ASHOP");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"USHOP");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SSHOP");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PSHOP");
		}

	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
         *qry_values[2] =  {"*", CntrlSysCD};


    IFERR_REPORT(QRY_find("ControlObjQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

int myESTobeApprovedLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
	{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char PlantES[40];
	char CntrlSysCD[40];
    int
        error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
		tag_t query = NULLTAG,
        *cntr_objects = NULL,
        user = NULLTAG;

	GetESPlantFromRole(PlantES);
	printf( "PlantES : [%s]\n", PlantES);fflush(stdout);
	
		if(strcmp(PlantES,"APLP")==0)
		{
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

		else if(strcmp(PlantES,"APLD")==0)
		{
		 tc_strcpy(CntrlSysCD,"DAPPBY");
		}

		else if(strcmp(PlantES,"APLC")==0)
		{
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

		else if(strcmp(PlantES,"APLJ")==0)
		{
		 tc_strcpy(CntrlSysCD,"JAPPBY");
		}

		else if(strcmp(PlantES,"APLL")==0)
		{
		 tc_strcpy(CntrlSysCD,"LAPPBY");
		}

		else if(strcmp(PlantES,"APLA")==0)
		{
		 tc_strcpy(CntrlSysCD,"AAPPBY");
		}

		else if(strcmp(PlantES,"APLU")==0)
		{
		 tc_strcpy(CntrlSysCD,"UAPPBY");
		}

		else if(strcmp(PlantES,"APLS")==0)
		{
		 tc_strcpy(CntrlSysCD,"SAPPBY");
		}
		else 
		{
		 printf("\n inside .... ");fflush(stdout);
		 tc_strcpy(CntrlSysCD,"PAPPBY");
		}

	printf( "\n CntrlSysCD : [%s]\n", CntrlSysCD);fflush(stdout);

		char
         *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
         *qry_values[2] =  {"*", CntrlSysCD};


    IFERR_REPORT(QRY_find("ControlObjQry", &query));
	printf("\nTCDC-- ");fflush(stdout);
    IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\nTCDC%d", n_found);fflush(stdout);

    *n_values = n_found;
    printf("\nTCDC== %d\n", *n_values);fflush(stdout);

    *values = (char **)MEM_alloc (*n_values * sizeof(char*));
    memset( *values, 0,  *n_values * sizeof(char*));

    for (ii = 0; ii < n_found; ii++)
    {
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_SubSyscd",&item_sequence_id));

		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
        strcpy((*values)[ii], item_sequence_id);
    }
    TAG_free(cntr_objects);
    TAG_free(item_sequence_id);

    return error_code;
}

extern int escreate_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method;
    int ifail=0;  

 
if( ifail == ITK_ok )
    {
        printf("\n T5_PEShopNameLOVType Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_PEShopNameLOVType",
            LOV_ask_values_msg,
            &myESDomainNameLOVValuesMethodP,  0,
            &method);
		printf("\n after T5_PEShopNameLOVType Project Codecm \n");fflush(stdout);
	}

if( ifail == ITK_ok )
    {
        printf("\n T5_EstShopLOVType Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_EstShopLOVType",
            LOV_ask_values_msg,
            &myESShopNameLOVValuesMethodP,  0,
            &method);
    printf("\n after T5_EstShopLOVType Project Codecm \n");fflush(stdout);
	}


if( ifail == ITK_ok )
    {
        printf("\n T5_PEProcessApproveByLOVTyp Project Codecm \n");fflush(stdout);
		ifail = METHOD_register_method( "T5_PEProcessApproveByLOVTyp",
            LOV_ask_values_msg,
            &myESTobeApprovedLOVValuesMethodP,  0,
            &method);
    printf("\n after T5_PEProcessApproveByLOVTyp Project Codecm \n");fflush(stdout);
	}


  
   ifail = METHOD_find_method("T5_EstimateSheetRevision", TC_save_msg, &method);
   if (method.id != NULLTAG)
   {
			ifail = METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Save_ES_Msg, NULL)!=ITK_ok;
			printf("\n rrrrrrrrRegistered as Post-Action for T5_EstimateSheetRevision Save\n");fflush(stdout);
   }else
		{
			printf("\n Method not found!TC_save_msg\n");fflush(stdout);
		}
  


  if( ITK_ok == EPM_register_action_handler("ES_APLPrereleased", "", ES_APLPrereleased))
  {
  	printf("\t\n Registered Action Handler ES_APLPrereleased\n");fflush(stdout);
  }else
  {
  	printf("\t FAILED to register Action Handler ES_APLPrereleased\n");fflush(stdout);
  }
     

  if( ITK_ok == EPM_register_action_handler("ES_APLFinalReleased", "", ES_APLFinalReleased))
  {
  	printf("\t\n Registered Action Handler ES_APLFinalReleased\n");fflush(stdout);
  }else
  {
  	printf("\t FAILED to register Action Handler ES_APLFinalReleased\n");fflush(stdout);
  }


  if( ITK_ok == EPM_register_action_handler("ES_PSDWorking", "", ES_PSDWorking))
  {
  	printf("\t\n Registered Action Handler ES_PSDWorking\n");fflush(stdout);
  }else
  {
  	printf("\t FAILED to register Action Handler ES_PSDWorking\n");fflush(stdout);
  }


  if( ITK_ok == EPM_register_action_handler("ES_PSDFinalReleased", "", ES_PSDFinalReleased))
  {
  	printf("\t\n Registered Action Handler ES_PSDFinalReleased\n");fflush(stdout);
  }else
  {
  	printf("\t FAILED to register Action Handler ES_PSDFinalReleased\n");fflush(stdout);
  }


	if( ITK_ok == EPM_register_rule_handler ("estimate_sheet_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)estimate_sheet_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler estimate_sheet_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler estimate_sheet_signoff_checks_Func\n");fflush(stdout);
   }


    return ITK_ok;


}

extern DLLAPI int escreate_register_callbacks()
{
	 CUSTOM_register_exit("escreate", "USER_init_module", (CUSTOM_EXIT_ftn_t)escreate_register_method);

     printf("\n registered function escreate\n");	fflush(stdout);

	 return ( ITK_ok );
}
