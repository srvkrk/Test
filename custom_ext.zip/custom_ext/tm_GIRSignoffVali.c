/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Prasad Sagare
*  Module               :   ..
*  Code                 :   tm_GIR_Release_Vali.c
*  Created on			:  
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

extern EPM_decision_t DLLAPI tm_GIRSignoffVali(EPM_rule_message_t msg)
{
	int i							= 0;
	int j							= 0;
	int k							= 0;
	int l							= 0;
	int qq							= 0;
	int dc							= 0;
	int ii							= 0;
	int ifail						= 0;
	int count						= 0;
	int task_cnt					= 0;
	
	int dml_cnt						= 0;
	int rev_cnt						= 0;
	int prt_cnt						= 0;
	int status_cnt					= 0;
	int ChildCunt					= 0;
	int partRevflag					= 0;
	int GIDFlag						= 0;
	int iChild						= 0;
	int GrpChildPass				= 0;
	int D_TskCnt					= 0;
	int n_parents					= 0;
	int rulefounddd					= 0;
	int *levels = 0;
	int DCR_n_entry = 1;
	int DCR_rsltCount =	0;
	int dChildvALIPass =	0;

	logical		is_latest;

	char *dr_status					= NULL;
	char *status_name				= NULL;
	char *CurrentTask				= NULL;
	char *release_type				= NULL;
	char *DMLReason					= NULL;
	char *Arch_obj					= NULL;
	char *AssID						= NULL;
	char *relstat					= NULL;
	char *zTasknum					= 0;

	tag_t *attachments				= NULLTAG;
	tag_t *task_list				= NULLTAG;
	tag_t *dml_list					= NULLTAG;
	tag_t *part_list				= NULLTAG;
	tag_t *rev_list					= NULLTAG;
	tag_t *status_list				= NULLTAG;
	tag_t *DCR_list					= NULLTAG;
	tag_t *DTskObj					= NULLTAG;
	tag_t *parents					= NULLTAG;
	tag_t *DCRCntrlObjectTag		= NULLTAG;
	tag_t p_top_line				= NULLTAG;
	tag_t *POclosureruleee			= NULLTAG;
	tag_t *Childobject				= NULLTAG;

	tag_t DMLTag					= NULLTAG;
	tag_t part_tag					= NULLTAG;
	tag_t root_task					= NULLTAG;
	tag_t TaskRelType				= NULLTAG;
	tag_t PartRelType				= NULLTAG;
	tag_t DCR_RelType				= NULLTAG;
	tag_t DCRqryTag					= NULLTAG;
	tag_t DumItmTag					= NULLTAG;
	tag_t SolutionRelTag			= NULLTAG;
	tag_t DumRevtag					= NULLTAG;
	tag_t p_window					= NULLTAG;
	tag_t p_rule					= NULLTAG;
	tag_t POclose_taggg				= NULLTAG;
	tag_t SoluRelTag				= NULLTAG;

	char **POrulenameXO = NULL;
	char **POrulevalueXO = NULL;

	char    *DCR_qry_entry[1]	=	{"SYSCD"};
	char    **DCR_qry_values2   =  (char **) MEM_alloc(100 * sizeof(char *));

	char *p_child_item_id=NULL;
	char *rel_sstats=NULL;
	char *Obj_PrtTyp=NULL;
	char *rev_iidd=NULL;
	char *PrtDRstus=NULL;
	char *PrtProjj=NULL;
	char *DCRinfo1 =	NULL;
	char *DCRinfo2 =	NULL;
	char *DCRinfo3 =	NULL;
	char *DCRinfo7 =	NULL;
	char *part_type = NULL;
	char *partRevision = NULL;
	char *partSeq = NULL;
	char *partRevStr = NULL;
	char *StrPartType =	NULL;
	char *StrDmlRlzType =	NULL;
	char *itemIDNm =	NULL;
	char *DMLRlztype = NULL;
	char *DMLPrtCd = NULL;
	char *DMLID = NULL;
	char *DR2Prt = NULL;
	char *DMLBU = NULL;

	StrPartType =(char *)MEM_alloc(10);
	StrDmlRlzType =(char *)MEM_alloc(50);
	int jm=0;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	EPM_decision_t decision = EPM_go;

	printf("\n tm_GIRSignoffVali Function started...");fflush(stdout);
	TC_write_syslog("\n tm_GIRSignoffVali Function started...");

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	//printf("\ninside Check_DCR_required\n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\ntm_GIRSignoffVali-->CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\ntm_GIRSignoffVali-->Number of attachments:[%d]\n",count);	fflush(stdout);

	if(count > 0)
	{
		printf("\n : Root Task Count is [%d]\n",count);fflush(stdout);
		for(jm=0;jm<count;jm++)
		{
			if(TCTYPE_ask_object_type(attachments[jm],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n : Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &TaskRelType));
				CALLAPI(GRM_list_primary_objects_only(attachments[i], TaskRelType, &dml_cnt, &dml_list));//Task to DML
				printf("\ntm_GIRSignoffVali-->DML count:[%d]\n", dml_cnt);

				for(dc=0; dc<dml_cnt; dc++)
				{
					CALLAPI(ITEM_rev_sequence_is_latest(dml_list[dc],&is_latest));
					printf("\n\n\t\t tm_GIRSignoffVali-->is_latest : %d\n",is_latest);fflush(stdout);

					if(is_latest != true)
					{
						printf("\n\n tm_GIRSignoffVali-->Not latest DML Revision.....\n");fflush(stdout);
					}
					else
					{
						DMLTag = dml_list[dc];//DML Tag
					}
				}

				if (DMLTag != NULLTAG)
				{
					CALLAPI(AOM_UIF_ask_value(DMLTag, "t5_rlstype", &release_type)); 
					CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRlztype));
					CALLAPI(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&DMLPrtCd));
					CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&DMLID));
					CALLAPI(AOM_ask_value_string(DMLTag,"t5_ERCBusiUt",&DMLBU));
					printf("\n tm_GIRSignoffVali-->DMLRlztype==> [%s] ReleaseType==> [%s] Project Code==> [%s] Business Unit==> [%s]",DMLRlztype,release_type,DMLPrtCd,DMLBU);fflush(stdout);

					if(QRY_find2("ControlObjects", &DCRqryTag));
					if (DCRqryTag != NULLTAG)
					{
						printf("\n tm_GIRSignoffVali-->GroupIDDML:Found Query ControlObjects \n");fflush(stdout);
						
						DCR_qry_values2[0] = "GroupIDDML";

						if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
					}
					else
					{
						printf("\n tm_GIRSignoffVali-->GroupIDDML:Not Found Query ControlObjects \n");fflush(stdout);
					}

					printf(" \n tm_GIRSignoffVali-->GroupIDDML:DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
					if(DCR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo1",&DCRinfo1)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo2",&DCRinfo2)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_GIRSignoffVali-->DCRinfo1: %s ", DCRinfo1);fflush(stdout);

						if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo3",&DCRinfo3)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_GIRSignoffVali-->DCRinfo3: [%s]", DCRinfo3);fflush(stdout);

						if (tc_strstr(DCRinfo1,"OnGIR")==NULL)
						{
							if (tc_strcmp(DMLRlztype,"GIR") == 0)
							{
								CALLAPI(GRM_find_relation_type("CMHasSolutionItem", &PartRelType));
								CALLAPI(GRM_list_secondary_objects_only(attachments[i],PartRelType, &prt_cnt, &part_list));
								
								printf("\n tm_GIRSignoffVali-->Part Count:[%d] ", prt_cnt); fflush(stdout);
								
								if(tc_strstr(DCRinfo3,"ValiOFF")== NULL)
								{
									if(prt_cnt > 0)
									{
										for(j=0; j<prt_cnt; j++)
										{
											partRevflag=1;

											CALLAPI(AOM_ask_value_string(part_list[j],"item_id", &itemIDNm));
											CALLAPI(AOM_ask_value_string(part_list[j],"t5_PartType", &part_type));
											CALLAPI(AOM_ask_value_string(part_list[j],"item_revision_id", &partRevision));
											CALLAPI(AOM_UIF_ask_value(part_list[j],"IMAN_master_form_rev", &partSeq));
											//CALLAPI(AOM_UIF_ask_value(part_list[j],"sequence_id", &partSeq));
											CALLAPI(AOM_ask_value_string(part_list[j],"t5_PartStatus", &DR2Prt));
											printf("\n tm_GIRSignoffVali-->DCRVali:part type=[%s] & Item ID=[%s] & Part DR=[%s] ",part_type,itemIDNm,DR2Prt); fflush(stdout);
											if ((tc_strcmp(part_type,"G") == 0))
											{
												GIDFlag = 1;

												if(tc_strstr(DCRinfo3,"NFGrp") == NULL)
												{
													if(tc_strstr(partRevision,"NR") !=NULL)
													{
														printf("\ntm_GIRSignoffVali :ERRORRRR Group ID NR Revision should not be attached to DML for release", AssID);fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR:Group ID NR Revision should not be attached to DML for release, Please Release NR Revision of Group ID through 'Module Release'- ",AssID);
														return ITK_err;
													}
												}
												printf("\n tm_GIRSignoffVali-->Group ID part found\n");fflush(stdout);
												CALLAPI(PS_where_used_all(part_list[j],1,&n_parents,&levels,&parents));
												printf("\n\t tm_GIRSignoffVali where_used count of objects are Drag Drop : [%d]",n_parents); fflush(stdout);
												if(n_parents > 0)
												{
													printf("\n tm_GIRSignoffVali inside n_parents count greated than zero"); fflush(stdout);
													for (ii = 0; ii < n_parents; ii++ )
													{
														printf("\n tm_GIRSignoffVali inside For loop [%d]",ii); fflush(stdout);
														CALLAPI(AOM_ask_value_string(parents[ii],"item_id",&AssID));
														printf("\n\t [%d] Parant of Group ID :[%s] ",ii,AssID);fflush(stdout);
														CALLAPI(AOM_UIF_ask_value(parents[ii],"release_status_list",&relstat));
														printf("\t release Stat [%s]",relstat);fflush(stdout);
														if((tc_strstr(relstat,"Released") == NULL) || (tc_strstr(rel_sstats,"T5_LcsErcRlzd")==NULL)||(tc_strstr(rel_sstats,"APL")==NULL)||(tc_strstr(rel_sstats,"STDSI")==NULL))
														{
															DumItmTag= t5GetItemRevison(AssID);
															if(DumItmTag==NULLTAG)
															{
																printf("\n tm_GIRSignoffVali:DumItmTag is NULL.\n");fflush(stdout);
															}
															if(GRM_find_relation_type("CMHasSolutionItem", &SolutionRelTag)!=ITK_ok)PrintErrorStack();
															if (SolutionRelTag!=NULLTAG)
															{
																printf("\n DMY::OK for SolutionRelTag.");fflush(stdout);
															}
															if(ITEM_ask_latest_rev(DumItmTag, &DumRevtag)!=ITK_ok)PrintErrorStack();
															printf("\n tm_GIRSignoffVali:Latest Revision of found Group ID found");fflush(stdout);
															if(GRM_list_primary_objects_only(DumRevtag,SolutionRelTag,&D_TskCnt,&DTskObj)!=ITK_ok)PrintErrorStack();
															printf("\n tm_GIRSignoffVali::Task Count :-------------------->>>>  %d\n",D_TskCnt);fflush(stdout);

															if (D_TskCnt > 0)
															{
																for (qq =0 ; qq < D_TskCnt; qq++ )
																{
																	if( AOM_ask_value_string(DTskObj[qq],"item_id",&zTasknum)==ITK_ok)
																	printf("\n tm_GIRSignoffVali: sDMLno [%s] and Task name zTasknum[ %s].\n",DMLID,zTasknum); fflush(stdout);
																	if(tc_strstr(zTasknum,DMLID)!= NULL)
																	{
																		printf("\n tm_GIRSignoffVali: Validation Pass..Parent is attached to the Same DML");fflush(stdout);
																		dChildvALIPass=1;
																		//Group id having one child part clear.
																		break;
																	}
																}
															}
														}
													}
													if(dChildvALIPass == 0)
													{
														printf("\ntm_GIRSignoffVali :ERRORRRR ERC Review Parent Part [%s] of Group ID should be attached to same DML for release", AssID);fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR:ERC Review Parent Part of Group ID should be attached to same DML for release- ",AssID);
														return ITK_err;
													}
												}
												else
												{
													printf("\n tm_GIRSignoffVali-->Group ID part itemIDNm [%s] has not attached to any Assepmbly\n",itemIDNm);fflush(stdout);
													EMH_store_error_s2(EMH_severity_error,ITK_err,"Group ID part is not attached to any Assepmbly, Please attach Group ID in Assembly",itemIDNm);
													return EPM_nogo;
												}
											}
											else
											{
												printf("\n tm_GIRSignoffVali-:in side the Part tyep non Group ID\n");fflush(stdout);
												if(BOM_create_window (&p_window)!=ITK_ok)PrintErrorStack();
												if(CFM_find( "ERC Review And Above", &p_rule )!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_config_rule( p_window, p_rule )!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_pack_all (p_window, true)!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_top_line (p_window, NULLTAG, part_list[j], NULLTAG, &p_top_line)!=ITK_ok)PrintErrorStack();

												if(tc_strstr(DCRinfo3,"BOMEZ")==NULL)
												{
													printf ("\ntm_GIRSignoffVali: TMLBOMExpandByQty apply.. \n");fflush(stdout);
													if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefounddd, &POclosureruleee )!=ITK_ok)   PrintErrorStack();
												}
												else
												{
													printf ("\ntm_GIRSignoffVali: BOMLineSkipZeroQtyMaskUnconfig apply.. \n");fflush(stdout);
													if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefounddd, &POclosureruleee )!=ITK_ok)   PrintErrorStack();
												}
												printf ("\ntm_GIRSignoffVali:rulefounddd count %d \n",rulefounddd);fflush(stdout);
												if (rulefounddd > 0)
												{
													POclose_taggg = POclosureruleee[0];
													printf ("\ntm_GIRSignoffVali: closure rule found \n");fflush(stdout);
												}
												if(BOM_window_set_closure_rule( p_window,POclose_taggg, 0, POrulenameXO,POrulevalueXO )!=ITK_ok)   PrintErrorStack();
												//0qty

												if(BOM_line_ask_child_lines (p_top_line, &ChildCunt, &Childobject));
												printf("\n tm_GIRSignoffVali:No of child objects are ChildCunt : %d\n",ChildCunt);fflush(stdout);
												iChild=0;
												dChildvALIPass = 0;
												for(iChild =0 ; iChild < ChildCunt; iChild++)
												{
													GrpChildPass=0;
													p_child_item_id=NULL;
													rel_sstats=NULL;
													Obj_PrtTyp=NULL;
													rev_iidd=NULL;
													PrtDRstus=NULL;
													PrtProjj=NULL;

													if(AOM_ask_value_string(Childobject[iChild], "bl_item_item_id", &p_child_item_id )!=ITK_ok)PrintErrorStack();
													if(AOM_UIF_ask_value(Childobject[iChild], "bl_rev_release_status_list", &rel_sstats)!=ITK_ok)PrintErrorStack();
													printf("\ntm_GIRSignoffVali: p_child_item_id:[%s] Rel Status:[%s]", p_child_item_id,rel_sstats);fflush(stdout);
													//If child is NR WIP, it should be in same DML.
													if((tc_strstr(rel_sstats,"Released")==NULL)||(tc_strstr(rel_sstats,"T5_LcsErcRlzd")==NULL)||(tc_strstr(rel_sstats,"APL")==NULL)||(tc_strstr(rel_sstats,"STDSI")==NULL))
													{
														if(AOM_ask_value_string(Childobject[iChild],"bl_Design_t5_RevPartType",&Obj_PrtTyp)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(Childobject[iChild], "bl_rev_item_revision_id", &rev_iidd)!=ITK_ok)PrintErrorStack();
														if(AOM_UIF_ask_value(Childobject[iChild], "bl_Design Revision_t5_PartStatus", &PrtDRstus)!=ITK_ok)PrintErrorStack();
														if(AOM_ask_value_string(Childobject[iChild],"bl_Design Revision_t5_ProjectCode",&PrtProjj)!=ITK_ok)PrintErrorStack();
														printf("\n tm_GIRSignoffVali: Obj_PrtTyp:%s PrtDRstus:%s and rev_iidd:%s PrtProjj:%s", Obj_PrtTyp,PrtDRstus,rev_iidd,PrtProjj);fflush(stdout);
														if(tc_strcmp(Obj_PrtTyp,"G")==0)
														{
															DumItmTag= t5GetItemRevison(p_child_item_id);
															if(DumItmTag==NULLTAG)
															{
																printf("\n tm_GIRSignoffVali:DumItmTag is NULL.\n");fflush(stdout);
															}
															if(GRM_find_relation_type("CMHasSolutionItem", &SoluRelTag)!=ITK_ok)PrintErrorStack();
															if (SoluRelTag!=NULLTAG)
															{
																printf("\n tm_GIRSignoffVali:OK for SoluRelTag.");fflush(stdout);
															}
															if(ITEM_ask_latest_rev(DumItmTag, &DumRevtag)!=ITK_ok)PrintErrorStack();
															printf("\n tm_GIRSignoffVali:latest revision of Group ID part");fflush(stdout);
															if(GRM_list_primary_objects_only(DumRevtag,SoluRelTag,&D_TskCnt,&DTskObj)!=ITK_ok)PrintErrorStack();
															printf("\n tm_GIRSignoffVali::Task Count :-------------------->>>>  %d\n",D_TskCnt);fflush(stdout);

															if (D_TskCnt > 0)
															{
																for (qq =0 ; qq < D_TskCnt; qq++ )
																{
																	if( AOM_ask_value_string(DTskObj[qq],"item_id",&zTasknum)==ITK_ok)
																	printf("\n tm_GIRSignoffVali: DMLID [%s] and Task name zTasknum[ %s].\n",DMLID,zTasknum); fflush(stdout);
																	if(tc_strstr(zTasknum,DMLID)!=NULL)
																	{
																		printf("\n tm_GIRSignoffVali:attached in same DML OKKK..");fflush(stdout);
																		dChildvALIPass=1;
																		//Group id having one child part clear.
																		break;
																	}
																}
															}
														}
													}
												}
												if(dChildvALIPass == 0)
												{
													if (tc_strstr(DCRinfo2,"PS008")==NULL)
													{
														printf("\n tm_GIRSignoffVali:ERRORRRR.ERC Review Group ID :[%s] should be attached to same DML for release", p_child_item_id);fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"ERROR: Bellow ERC Review Group ID part Should be attached to the same DML- ",p_child_item_id);
														return ITK_err;
													}
												}
												printf("\n tm_GIRSignoffVali-->Allowed to attach the part if it is present in any of the Group ID present in the DML\n");fflush(stdout);
											}
										} //end of for loop==prt_cnt
									}
								}
							}
							if(partRevflag == 0)
							{
								printf("\nNo Part is attached to DML task, Hence returning EPM_nogo.\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly attach the part to the DML, Blank Task can't be completed");
								return EPM_nogo;
							}
							if(GIDFlag == 0)
							{
								printf("\nAtleast one Group ID to be attached to the DML Task, Hence returning EPM_nogo\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly attach the Atleast one Group ID to be the DML Task");
								return EPM_nogo;
							}
						}
						else
						{
							printf(" \n *************tm_GIRSignoffVali--> GIR Check is off ***************"); fflush(stdout);
						}
					}
				}
				else
				{
					printf("\ntm_GIRSignoffVali-->DMLTag not found....\n");fflush(stdout);
				}
			}
		}
	}

	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(release_type){MEM_free(release_type);}
	if(DMLRlztype){MEM_free(DMLRlztype);}
	if(DMLPrtCd){MEM_free(DMLPrtCd);}
	if(DMLID){MEM_free(DMLID);}
	if(DMLBU){MEM_free(DMLBU);}
	if(DCRinfo1){MEM_free(DCRinfo1);}
	if(DCRinfo2){MEM_free(DCRinfo2);}
	if(DCRinfo3){MEM_free(DCRinfo3);}
	if(itemIDNm){MEM_free(itemIDNm);}
	if(part_type){MEM_free(part_type);}
	if(partRevision){MEM_free(partRevision);}
	if(partSeq){MEM_free(partSeq);}
	if(DR2Prt){MEM_free(DR2Prt);}
	if(AssID){MEM_free(AssID);}
	if(relstat){MEM_free(relstat);}
	if(p_child_item_id){MEM_free(p_child_item_id);}
	if(rel_sstats){MEM_free(rel_sstats);}
	if(Obj_PrtTyp){MEM_free(Obj_PrtTyp);}
	if(rev_iidd){MEM_free(rev_iidd);}
	if(PrtDRstus){MEM_free(PrtDRstus);}
	if(PrtProjj){MEM_free(PrtProjj);}
	if(zTasknum){MEM_free(zTasknum);}
	printf("\n tm_GIRSignoffVali-->Completed \n"); fflush(stdout);*/
	printf("\n tm_GIRSignoffVali Function end...");fflush(stdout);
	TC_write_syslog("\n tm_GIRSignoffVali Function end...");
	return decision;
}