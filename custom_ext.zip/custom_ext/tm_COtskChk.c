#include "TMLLibrary_server_exits.h"

int tm_COtskChk(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int error_code			= ITK_ok;
	int	taskflag            = 0;
	int	count               = 0;
	tag_t  roottask			= NULLTAG;
	tag_t  query			= NULLTAG;
	tag_t  objTypTag        = NULLTAG;
	tag_t  DMLRevTg         = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLTaskTag       = NULLTAG;
	tag_t  *contrlObjs       = NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  *DMLRevision     = NULLTAG;
	char * dmlTaskNo   = NULL;
	char * DMLtype     = NULL;
	char * sDMLno      = NULL;
	char * DMLprirty   = NULL;
	char * sCOInfo1    = NULL;
	char * sCOInfo2    = NULL;
	char * sCOInfo3    = NULL;
	char * sCOInfo4    = NULL;
	char* ObjTyp = NULL;
	logical is_latest;

	//EPM_decision_t decision = EPM_go;
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));

	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	printf("\n tm_COtskChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_COtskChk Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_COtskChk:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_COtskChk:INSIDE Attachments.");fflush(stdout);
			DMLTaskTag=taskAttachments[i];

			if (DMLTaskTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="COCHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n tm_COtskChk Control objects : count==>%d \n",count);fflush(stdout);

				if (count>0)
				{

					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sCOInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sCOInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sCOInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sCOInfo4));
					printf("\n L1:sCOInfo1 is : [%s]  L2:sCOInfo2 is : [%s]  L3:sCOInfo3 is : [%s] L4:sCOInfo4 is : [%s]\n",sCOInfo1,sCOInfo2,sCOInfo3,sCOInfo4);fflush(stdout);

					if(tc_strstr(sCOInfo2,"COOFF1") != NULL)
					{
						return 0;
					}
					if(tc_strstr(sCOInfo2,"COOFF3") != NULL)
					{
						return 1;
					}

					if(tc_strstr(sCOInfo2,"COOFF2") == NULL)
					{
						
						if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
						if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n tm_COtskChk: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

						if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
						{
							if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
							printf("\n tm_COtskChk--DML Task No: [%s] \n", dmlTaskNo);fflush(stdout);
							taskflag=0;
							if(tc_strstr(dmlTaskNo,"_CO")!=NULL)
							{
							  taskflag=1;
							}
							printf("\n tm_COtskChk--taskflag= %d ",taskflag);fflush(stdout);

							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n tm_COtskChk--DML Revision from Task for : %d",countt);fflush(stdout);


								for (j=0;j<countt ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n tm_COtskChk--is_latest  is : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
									   printf("\n tm_COtskChk--is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];
										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										printf("\n tm_COtskChk--for sDMLno : [%s] ",sDMLno);fflush(stdout);

										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										printf(" tm_COtskChk Release Type: [%s]", DMLtype); fflush(stdout);

										if (tc_strcmp(DMLtype,"TODR")==0)	//for Gate Maturation
										{

											if (taskflag==1)
											{
												printf("\n tm_COtskChk: CO task found.....\n");fflush(stdout);
												return 1;
											}
											else
											{
												printf("\n tm_COtskChk: Other group task..... \n");fflush(stdout);
												return 0;
											}
										}
										else
										{
											printf("\n tm_COtskChk:Not for DML type. \n");fflush(stdout);
											return 0;
										}
									}
								}
							}
						}
					}
					else
					{
						return 0;
					}
				}
			}
		}
	}
    printf("\n tm_COtskChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_COtskChk Function end...");
	//return error_code;
	return 0;
}