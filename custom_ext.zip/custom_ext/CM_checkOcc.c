/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   CM_checkOcc.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t CM_checkOcc(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int l					= 0;
	int	n					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVC				= 0;
	int n_parents			= 0;
	int *levels				= 0;
	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t   DMLObject		= NULLTAG;
	tag_t	objTypeTag		= NULLTAG;
	tag_t	AssyTag			= NULLTAG;
	tag_t	ArchAssyTag		= NULLTAG;
	tag_t  *parents			= NULL;
	tag_t  ArchobjTypeTag	= NULLTAG;
	tag_t  *children1		= NULLTAG;
	tag_t  Childobject		= NULLTAG;
	tag_t   window,rule,item_tag = null_tag,top_line;
	tag_t  primaryobjtype			= NULLTAG;
	tag_t  probj			= NULLTAG;
	
	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *Part_type		=NULL;
	char   *DMLDRstauts		=NULL;
	char   *value			=NULL;
	char   *Arch_obj		=NULL;
	char   *child_bl_formula=NULL;
	char*   ObjTyp=NULL;
	char*   type_name=NULL;
	char*   Archtype_name=NULL;
	char*   primaryobj_name=NULL;
	char* child_bl_formula_cmp = NULL;
	//BOM_LINE
	char *child_rev_id = NULL;
 	char *child_rev_seq = NULL;
	char *child_rev_stat = NULL;
	char *child_objType = NULL;
	char *mod_addr = NULL;
 	int			revid			= 0;
 	int			revseq			= 0;
 	int			revstat			= 0;
 	int			blobjType		= 0;
 	int			modadd			= 0;
 	int			Variantflag		= 0;
 	int			Variantflag1		= 0;
	int	ifail = 0;
	char *username;
	char *userid;
	tag_t user_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;
	int designer_found=0,manager_found=0;
	tag_t * 	list;
	tag_t top_bom_line=NULLTAG;
	char   *OccUIDflag				= NULL;

	EPM_decision_t decision = EPM_go;
	
	printf("\n CM_checkOcc Function started...");fflush(stdout);
	TC_write_syslog("\n CM_checkOcc Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
					if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
					printf("\n\t count is : %d",count);
					
					if(count >0)
					{
						flagVC=0;
						for(j=0;j<count;j++)
						{
						  if(AOM_ask_value_string(SecObject[j],"object_type",&objecttype));
						  if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
						  if(AOM_ask_value_string(SecObject[j],"object_desc",&objectdesc));
						  //if(AOM_ask_value_string(SecObject[j],"release_status_list",&objectrelstatus));
						  if(AOM_ask_value_string(SecObject[j],"t5_PartStatus",&objectDRstatus));
						  if(AOM_ask_value_string(SecObject[j],"t5_PartType",&Part_type));

						  printf("\n\n\t CP Part_no  is :%s",Part_type);	fflush(stdout);
						  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
						  printf("SecObject objectdesc = [%s]\n",objectdesc);fflush(stdout);
						  //printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  printf("SecObject objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
						  						  
						  if(GRM_find_relation(taskAttachments[i],SecObject[j],DmlItemsRelation,&probj));
						  //ifail = GRM_ask_primary (SecObject[j],&probj);
						  if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
						  if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
						  printf("\n primaryobj_name -------->  :%s\n", primaryobj_name);fflush(stdout);
						  if (strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0)
						  {
//						  ifail = AOM_UIF_ask_value(probj,"t5_Occcurance_Flag",&OccUIDflag);
//						  printf("\n Set_OccUID OccUIDflag--------> :%s\n",OccUIDflag);fflush(stdout);
//						  if(tc_strcmp(OccUIDflag,"False")==0)
//						  {
		
							if(strcmp(Part_type,"M")==0)
							{
							  AssyTag=SecObject[j];
							  if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							  if(TCTYPE_ask_name2(objTypeTag,&type_name));
							  printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

							  if(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
							  printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
								
								/////////Module Variant Formula  Validation////////
								int parent_item_seq=0;
								tag_t itemrev =NULLTAG;
								char* Trgt_bl_formula=NULL;
								char*  Part_no =NULL;
								int    bl_config=0;
								//int n_parents=0;
								//int *levels = 0;
								//tag_t *parents = NULL;
								int jd=0;
//								tag_t ArchAssyTag =NULLTAG;
//								char* Arch_obj= NULL;
//								tag_t ArchobjTypeTag=NULLTAG;
//								char   Archtype_name=NULL;
//								tag_t window=NULLTAG;
//								tag_t  rule=NULLTAG;
//								tag_t top_line =NULLTAG;
								int n_BL=0;
								int p1=0;
//								tag_t *children1= NULL;
//								tag_t Childobject=NULLTAG;
								char* child_item_id = NULL;
								//char* child_bl_formula_cmp = NULL;
								char* child_bl_formula = NULL;
								tag_t  	master =	NULLTAG;
								char*  Arch_obj_str = NULL;
								tag_t relation_dep=	NULLTAG;
								int countConfigCtx = 0;
								tag_t  *ConfigCtxSecObject	= NULLTAG;
								tag_t ConfigCtx = NULLTAG;
								tag_t  ConfigCtxObjTypeTag=NULLTAG;
								char*   Config_CtxType=NULL;
								char*	 SmVCContext			= NULL;
								char*	 SmCrIDContext			= NULL;
								char*	 ContextobjName			= NULL;

								tag_t	qry_t1	= NULLTAG;
								char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entr1 = 1;
								char    *qry_entr1[1]  = {"SYSCD"};
								int rsltCunt1=0;
								tag_t *CntrlObjTag1=NULLTAG;

								tag_t	queryTag	= NULLTAG;
								char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entries = 1;
								int resultCount=0;
								char *qry_entries[1] = {"ID"};

								tag_t *ConId  = NULL;
								int j=0;
								tag_t Optfmly_tag = NULLTAG;

								int dmlIncnt =0;
								int CmpleteVrf=0;
								char *username1;
								tag_t user_tag1=NULLTAG;
								char *userid1;

								logical bl_config_log;
								
								if(n_parents>0)
								{
								  for (jd=0;jd<n_parents;jd++ )
								  {
									ArchAssyTag=parents[jd];
									if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
									printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
									if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name))PrintErrorStack();
									printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);

										if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
										if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
										if(top_line!=NULLTAG)
										{
											if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
											printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
											if (n_BL >0)
											{
												
												for (p1=0;p1<n_BL ;p1++ )
												{
													if(Childobject) Childobject=NULLTAG;
													Childobject=children1[p1];

													if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
													printf("\n\t Design Object ===> :: %s\n",child_item_id); fflush(stdout);
													
													if (tc_strcmp(objectId,child_item_id)==0)
													{
														bl_config = 0;
														printf("\n bl_config= [%d]\n", bl_config);

														//if(BOM_line_ask_attribute_logical(Childobject, bl_config, &bl_config_log));
														if(AOM_ask_value_logical(Childobject,"bl_is_occ_configured", &bl_config_log));
														
														
														printf("\n bl_config_log= [%d]\n",bl_config_log);
														if (bl_config_log == 0)
														{
															printf("\n Inside bl_config_log::Flag ::>>> false \n"); fflush(stdout);
															printf("bl_config_log= [%d]\n",bl_config_log);fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,ITK_err,"Please untick option {Show Unconfigured By Occurance Effectivity }","By sending module to Structure manager ->View ->Show Unconfigured By Occurance Effectivity");
															decision = EPM_nogo;
															return decision;
														}
														else
														{
															//printf("bl_config_log= [%d]\n",bl_config_log);fflush(stdout);
															printf("bl_config_log value 1==True Allowed to create occurance\n");fflush(stdout);
															break;
														}
													}
												}
											}
										}
									}
									else
									{
										printf("\n NOT T5_ArchModuleRevision Skip\n");fflush(stdout);
										//break;
									}
									
								  }
								}
								else
								{
									printf("\n Module not attached to any architecture node. \n"); fflush(stdout);

								}
							}
//						  }
//						  else if(tc_strcmp(OccUIDflag,"True")==0)
//						  {
//							printf("\n Inside because OccUIDflag--------> :%s NOT Allowed\n",OccUIDflag);fflush(stdout);
//							EMH_clear_errors();
//							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please go to Module (VF Change) click on Part attached then","Go to Edit-->Properties On Relation--> Remove the UID that you want to remove and proceed");
//							decision = EPM_nogo;
//							return decision;
//						  }
						  }
						}
					}	
				}
			}
		}
	}
	printf("\n CM_checkOcc Function end...");fflush(stdout);
	TC_write_syslog("\n CM_checkOcc Function end...");
	return decision;
}


