
//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Business Object T5_MatCdeImpl

*/

#ifndef TRL001__T5_MATCDEIMPL_HXX
#define TRL001__T5_MATCDEIMPL_HXX

#include <T5_tm_mcnlib/T5_MatCdeGenImpl.hxx>

#include <T5_tm_mcnlib/libt5_tm_mcnlib_exports.h>

#define T5_MatCdePomClassName "T5_MatCde"

namespace TRL001
{
   class T5_MatCdeImpl; 
   class T5_MatCdeDelegate;
}
 
class  T5_TM_MCNLIB_API TRL001::T5_MatCdeImpl
           : public TRL001::T5_MatCdeGenImpl 
{
public:


   /**
    * Description for the Finalize Create Input
    * @param creInput - desc for  creInput parameter
    * @return - Return desc for Initialize for Create
    */
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    // Constructor for a T5_MatCde
    explicit T5_MatCdeImpl( T5_MatCde& busObj );

    // Destructor
    ~T5_MatCdeImpl();


private:
    // Default Constructor for the class
    T5_MatCdeImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_MatCdeImpl( const T5_MatCdeImpl& );

    // Copy constructor
    T5_MatCdeImpl& operator=( const T5_MatCdeImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class TRL001::T5_MatCdeDelegate;

};

#include <T5_tm_mcnlib/libt5_tm_mcnlib_undef.h>
#endif // TRL001__T5_MATCDEIMPL_HXX
