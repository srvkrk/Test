#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>

#define ITK_errStore (EMH_USER_error_base + 3)

//extern DLLAPI int checkin_register_method(int *decision, va_list args);
//extern DLLAPI int t5_LOV_register_method(int *decision);

int myAskModALOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVValuesMethodP( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVPartPlatformValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVvendorEEPartValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVCVAValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVPartCVPCValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVKeyWordValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVStartPartValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int T5_PartCategoryLOVMethod( METHOD_message_t *msg, va_list  args ) ;	// Added by Aashish_w
int  create_proto_method(METHOD_message_t *msg, va_list args);
//int  create_proto_method1(METHOD_message_t *msg, va_list args);
int myAskLOVValuesVendorId( METHOD_message_t *msg, va_list  args );
int myAskLOVForSupplierList( METHOD_message_t *msg, va_list  args );
int checkin_attr_validation( METHOD_message_t *msg, va_list  args );//Kalpesh
int t5_LOVDMLReasonValuesMethod( METHOD_message_t *msg, va_list  args ) ;
//int dynamic_dmlreasonLov_LengthsMethod( METHOD_message_t *msg, va_list  args );
int myAskLOVDesignSubGroupMethod( METHOD_message_t *msg, va_list  args ) ;
int myAskLOVDesignationMethod( METHOD_message_t *msg, va_list  args ) ;
extern DLLAPI int checkin_method_1(METHOD_message_t *m, va_list args);
extern DLLAPI int checkin_method_2(METHOD_message_t *m, va_list args);

static int PrintErrorStack( void )
{
	/*
	*
	* PURPOSE : Function to dump the ITK error stack
	*
	* RETURN : causes program termination. If you made it here
	*          you're not coming back modified for cust.c to not call exit()
	*          but to just print the error stack
	*
	* NOTES : This version will always return ITK_ok, which is quite strange
	*           actually. But if the error reporting was "OK" then that makes
	*           sense
	*
	*/
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d  ",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "\n Error(PrintErrorStack): ");
        fprintf( stderr, "\t%6d: %s ", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

extern DLLAPI int  create_proto_method(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	tag_t  objTypeTagDi =NULLTAG;

	//tag_t* new_item;
	//tag_t new_item = NULLTAG;
	char   *Item_id=NULL;
	//char   *parttyp=NULL;
	//char   *modtyp=NULL;
	char   *dumy_Item_ID_str=NULL;
	char   *Item_ID_str=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	char   *type_name2=NULL;
	WSO_description_t desc;
	tag_t  sequence_id_c;
	//char   type_name2[TCTYPE_name_size_c+1];

	//new_item = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);

	//EPM_decision_t decision=EPM_go;

	printf("\nTCDCI am in create_proto_method function \n");fflush(stdout);

	if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok) PrintErrorStack();

	printf("\nTCDCI itemid %s\n",Item_id);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTagDi));
	if(TCTYPE_ask_name2(objTypeTagDi,&type_name2));
	printf("\nTCDCtype_name2:     %s\n", type_name2);

	if (WSOM_describe(objTag, &desc) !=ITK_ok)   ;
	//if (AOM_ask_value_int(object,"sequence_id",&sequence_id_c)!=ITK_ok) PrintErrorStack();

	printf("TCDCObject Name:     %s\n", desc.object_name);
	printf("TCDCObject Type:     %s\n", desc.object_type);
	printf("TCDCRevision ID:     %s\n", desc.revision_id);

	//if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok);
	//if( AOM_ask_value_string(objTag,"t5_Typofmod",&modtyp)==ITK_ok);
	//printf("\nTCDCI am parttype %s \n",parttyp);fflush(stdout);

	//printf("\n I am in create_proto_method function \n");fflush(stdout);
	//dumy_Item_ID_str=MEM_string_copy(Item_id) ;
	//projectcode=subString(dumy_Item_ID_str,0,4);
	//desgngrp=subString(dumy_Item_ID_str,4,2);
	//
	//if(strcmp(desgngrp,"01")==0  && strcmp(modtyp,"01-Interior M0")==0 )
	//{
	//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"if sample error");
	//return ITK_errStore;
	//}
}

extern int checkin_register_method(int *decision, va_list args)
{
	METHOD_id_t  method;
	METHOD_id_t  methoddum1 ;
	METHOD_id_t  methoddum ;
	int	ifail = 0;
	*decision = ALL_CUSTOMIZATIONS;

	printf("\n Begining of checkin_register_method before method calling------\n");fflush(stdout);

	if ( METHOD_find_method(RES_Type, RES_checkin_msg, &method) !=ITK_ok) PrintErrorStack();

	printf("\n checkin_register_method--After METHOD_find_method RES_Type RES_checkin_msg------\n");fflush(stdout);

	//if( METHOD_find_method("T5_DummyPartRevision", ITEM_create_msg, &methoddum) !=ITK_ok) PrintErrorStack();
	//if( METHOD_find_method("T5_DummyPartRevision", IMAN_save_msg, &methoddum1) !=ITK_ok) PrintErrorStack();
	//if( METHOD_find_method("T5_DummyPartRevision", IMAN_save_msg, &methoddum1) !=ITK_ok) PrintErrorStack();
	//if( METHOD_add_action(methoddum1, METHOD_pre_action_type, (METHOD_function_t) create_proto_method, NULL)!=ITK_ok) PrintErrorStack();
	//if( METHOD_add_action(methoddum1, METHOD_pre_action_type, (METHOD_function_t) create_proto_method1, NULL)!=ITK_ok) PrintErrorStack();

    if (method.id )
    {
		printf("\n checkin_register_method--Before METHOD_add_action method METHOD_pre_action_type checkin_method_1------\n");fflush(stdout);

        if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) checkin_method_1, NULL)!=ITK_ok) PrintErrorStack();

		printf("\n checkin_register_method--After METHOD_add_action method METHOD_pre_action_type checkin_method_1------\n");fflush(stdout);
    }
     else
        printf("\n Method not found for checkin \n");fflush(stdout);

	//Neha CR-FY24-0020
	if (method.id )
    {
        if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) checkin_method_2, NULL)!=ITK_ok) PrintErrorStack();

		printf("\n Registered as Post-Action for check-in - std Part\n");fflush(stdout);
    }
     else
        printf("\n Method not found for checkin std Part\n");fflush(stdout);

		
	//Kalpesh(Pre_condition on check-in)(21_aug_19)
	if (method.id )
	{
	    if( METHOD_add_pre_condition(method, (METHOD_function_t) checkin_attr_validation, NULL) != ITK_ok) PrintErrorStack();
		printf("\n Method for mandatory attribute validation on check-in \n");fflush(stdout);
	}
	else
	{
		printf("\n Method(checkin_attr_validation) not found...!!\n");fflush(stdout);
	}
    //End(Kalpesh)

	if( ifail == ITK_ok )
    {
        printf("\n Before T5_ProjCodeLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_ProjCodeLOVType",
										LOV_ask_values_msg,
										&myAskLOVValuesMethodP,  0,
										&method);
		printf("\n After T5_ProjCodeLOVType METHOD_register_method--");fflush(stdout);
	}
    
	if( ifail == ITK_ok )
    {
		printf("\n Before T5_KeyWordLOVType METHOD_register_method--");fflush(stdout);
        ifail = METHOD_register_method( "T5_KeyWordLOVType",
										LOV_ask_values_msg,
										&myAskLOVKeyWordValuesMethod,  0,
										&method);
		printf("\n After T5_KeyWordLOVType METHOD_register_method--");fflush(stdout);
    }

	if( ifail == ITK_ok )
    {
        printf("\n Before T5_MatlClsLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_MatlClsLOVType",
										LOV_ask_values_msg,
										&myAskLOVValuesMethod,  0,
										&method);
		printf("\n After T5_MatlClsLOVType METHOD_register_method--");fflush(stdout);
	}

	if( ifail == ITK_ok )
    {
        printf("\n Before T5_PartPlatformLOVString METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_PartPlatformLOVString",
										LOV_ask_values_msg,
										&myAskLOVPartPlatformValuesMethod,  0,
										&method);
		printf("\n After T5_PartPlatformLOVString METHOD_register_method--");fflush(stdout);
	}
	// Aadded by Aadarsh - Beginning
	if( ifail == ITK_ok )
    {
        printf("\n Before T5_VendorNEEpartLOVString METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_VendorNEEpartLOVString",
										LOV_ask_values_msg,
										&myAskLOVvendorEEPartValuesMethod,  0,
										&method);
		printf("\n After T5_VendorNEEpartLOVString METHOD_register_method--");fflush(stdout);
	}
	//Added by Rohit Starts
	if( ifail == ITK_ok )
    {
        printf("\n Before T5_JLRCVAString METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_JLRCVAString",
										LOV_ask_values_msg,
										&myAskLOVCVAValuesMethod,  0,
										&method);
		printf("\n After T5_JLRCVAString METHOD_register_method--");fflush(stdout);
	}

	if( ifail == ITK_ok )
    {
        printf("\n Before T5_JLRCVPCString METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_JLRCVPCString",
										LOV_ask_values_msg,
										&myAskLOVPartCVPCValuesMethod,  0,
										&method);
		printf("\n After T5_JLRCVPCString METHOD_register_method--");fflush(stdout);
	}
	//Added by Rohit Ends

	if( ifail == ITK_ok )
    {
		printf("\n Before T5_StartPartLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_StartPartLOVType", LOV_ask_values_msg, &myAskLOVStartPartValuesMethod, 0, &method);
		printf("\n After T5_StartPartLOVType METHOD_register_method--");fflush(stdout);
	}

	/**************** Aashish_w --> Part category LOV in TCUA Starts ******************/
	if( ifail == ITK_ok )
	{
		printf("\n Before T5_PartCategoryLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_PartCategoryLOVType",LOV_ask_values_msg,&T5_PartCategoryLOVMethod,0,&method);  // for CMITEST AND PRODUCTION
		//ifail = METHOD_register_method( "T5_PartCategoryLOV",LOV_ask_values_msg,&T5_PartCategoryLOVMethod,0,&method);		// for UADEV
		printf("\n After T5_PartCategoryLOVType METHOD_register_method--");fflush(stdout);
	} 
	/**************** Aashish_w --> Part category LOV in TCUA END ********************/


	/*************************************************************************
      To fetch Keyword Description from classification in LOV
    *************************************************************************/
	
	if( ifail == ITK_ok )
    {
		printf("\n Before T5_KeyWordClassiLOVType METHOD_register_method--");fflush(stdout);
        ifail = METHOD_register_method( "T5_KeyWordClassiLOVType",
										LOV_ask_values_msg,
										&t5_LOVKeyWordDescValuesMethod,  0,
										&method);
		printf("\n After T5_KeyWordClassiLOVType METHOD_register_method--");fflush(stdout);
    }
	if( ifail == ITK_ok )
    {
        printf("\n Before T5_CMModAddrLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method("T5_CMModAddrLOVType", LOV_ask_values_msg, &myAskModALOVValuesMethod,  0, &method);
		printf("\n After T5_CMModAddrLOVType METHOD_register_method--");fflush(stdout);
	}
	else
	{
		printf("\n ifail--Module Address T5_CMModAddrLOVType \n");fflush(stdout);
	}	
	
	/****************************VendorId LOV 18.08.2018********************************/
	if( ifail == ITK_ok )
    {
        printf("\n Before T5_VendorIDLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_VendorIDLOVType", LOV_ask_values_msg, &myAskLOVValuesVendorId,  0, &method);
		printf("\n After T5_VendorIDLOVType METHOD_register_method--");fflush(stdout);
	}
	else
	{
		printf("\n ifail--VendorID LOV T5_VendorIDLOVType \n");fflush(stdout);
	}
	/****************************VendorId LOV 18.08.2018********************************/
   
	/****************************SupplierID LOV 24.06.2019********************************/
	if( ifail == ITK_ok )
    {
        printf("\n Before T5_SupplierLovType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_SupplierLovType", LOV_ask_values_msg, &myAskLOVForSupplierList,  0, &method);
		printf("\n After T5_SupplierLovType METHOD_register_method--");fflush(stdout);
	}
	else
	{
		printf("\n ifail--SupplierID LOV T5_SupplierLovType \n");fflush(stdout);
	}
	if( ifail == ITK_ok )
    {
		printf("\n Before T5_DsgSubGrpLOV METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_DsgSubGrpLOV", LOV_ask_values_msg, &myAskLOVDesignSubGroupMethod, 0, &method);
		printf("\n After T5_DsgSubGrpLOV METHOD_register_method--");fflush(stdout);
	}
	else
	{
		printf("\n ifail--T5_DsgSubGrpLOV \n");fflush(stdout);
	}

	if( ifail == ITK_ok )
    {
		printf("\n Before T5_DesignationLOV METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_DesignationLOV", LOV_ask_values_msg, &myAskLOVDesignationMethod, 0, &method);
		printf("\n After T5_DesignationLOV METHOD_register_method--");fflush(stdout);
	}
	else
	{
		printf("\n ifail--T5_DesignationLOV \n");fflush(stdout);
	}
	/****************************End SupplierID LOV 24.06.2019********************************/

   return ifail;
}

DLLAPI int tel_user_init_register_callbacks ()
{
	int ifail=0;

	printf("\n Begining of checkin_register_callback------\n");fflush(stdout);

	/* exit(EXIT_SUCCESS);*/
	if(CUSTOM_register_exit ( "tel_user_init", "USER_init_module", (CUSTOM_EXIT_ftn_t)  checkin_register_method) !=ITK_ok);

	//ifail=CUSTOM_register_exit ( "tel_user_init", "USER_init_module", (CUSTOM_EXIT_ftn_t)  t5_LOV_register_method);
	//printf("\n - after calling t5_LOV_register_callbacks");

	printf("\n tel_user_init_register_callbacks--processing is completed------\n\n");fflush(stdout);

	return ( ITK_ok );
}
