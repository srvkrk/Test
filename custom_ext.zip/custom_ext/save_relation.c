/****************************************************************************************************
*  File                 :		save_relation.c
*  Created By			:		Yogendra Kumar Mahikwar
*  Created On			:		23-July-2012
*  Purpose				:		 Model Indicator and drawing Indicator field should be read only for user. The indicators should be updated on attaching of model or drawing by the system..			
*								This is called at pre action of save.
*  Modification History :		Set the Value of Application OwnerD in DataSet based on ProPrt/ProAsm.
								Datatype Selection if ApplicationOwner value in DesignRevision is blank. 
*  Modification Date    :		22-Oct-2016
*  Modification  By	    :		Deepti Meshram
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <user_exits/user_exits.h>
#include <ss/ss_const.h>
#include <ae/ae.h>
#include <tccore/aom_prop.h>
#include <epm/epm_errors.h>
#include <sys/stat.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <tccore/custom.h>
#include <ae/dataset.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <tccore/method.h>
#include <ps/ps_errors.h>
#include <tccore/aom.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <fclasses/tc_time.h>
#include <unidefs.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <tccore/tc_msg.h>
#include <tccore/iman_msg.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/grmtype.h>
#include <pom/pom/pom.h>
#include <ai/sample_err.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

#define ITK_err 919002
#define CONNECT_FAIL (EMH_USER_error_base + 2)

#define ITEM_CHECKED_OUT  EMH_USER_error_base + 5
#define JT_PDF_NOT_FOUND  EMH_USER_error_base + 8
#define ITEMS_NOTFOUND_INDENT  EMH_USER_error_base+24
#define DESREV_CONTLIMIT  EMH_USER_error_base+25

char	*t5ApplOwnerDValCheck		=	NULL; //Added by Deepti
logical getIndentRefNo(char *IndentRefNo);
int getJTPDFItemRev(tag_t DesignRevTag);


 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


	//  ********* Dhiraj ********** //
extern DLLAPI int Indent_Design_relation(METHOD_message_t *m,va_list args)
{
	int		error_code				=	ITK_ok;
	int		design_rev_cnt			=	0;
	int		dataset_cnt,i			=	0;
	int		result,count			=   0;
	tag_t	objTag					=	va_arg(args, tag_t);
	tag_t	objTypeTag				=	NULLTAG;
	tag_t	priObjTag				=	NULLTAG;
	tag_t	priObjTypeTag			=	NULLTAG;

	tag_t	secObjTag				=	NULLTAG;
	tag_t	secObjTypeTag			=	NULLTAG;
	tag_t	select_itemrev			=   NULLTAG;
	tag_t	dataset_relation_type	=   NULLTAG;
	tag_t	obj_type				=   NULLTAG;
	tag_t	relation				=   NULLTAG;

	tag_t	*design_rev_tag			=	NULLTAG;
	tag_t	*DatasetList			=	NULLTAG;
	tag_t	*secondary_list			=	NULLTAG;

	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	
	char	*designrevName			=	NULL;
	char	*designrev				=	NULL;
	char	*chkout_val				=   NULL;
	char	*IndentCategory			=   NULL;
	char	*dataset_typeName		=   NULL;

	const char 
		*attrs[1] = {"item_id"},
		*values[1] = {"*"};


	TC_write_syslog("Indent_Design_relation..in save relation...\n");
	
	GRM_find_relation_type("T5ERCDtl", &relation);


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
    if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	TC_write_syslog("relation type_name ::  %s\n", type_name);
	//printf("\nrelation type_name ::  %s\n", type_name);fflush(stdout);

	if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	TC_write_syslog("primary obj type_name ::  %s\n", type_name1);
	//printf("\nprimary obj type_name ::  %s\n", type_name1);fflush(stdout);

	if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	TC_write_syslog("sec obj type_name ::  %s\n", type_name2);
	//printf("\nsec obj type_name ::  %s\n", type_name2);fflush(stdout);

	
	//// Check Design Revision Count with "Indent Has Parts" relation, Max. limit is 40 Design rev can attach only...
	if(priObjTag != NULLTAG)
	{
		if(tc_strcasecmp(type_name1,"T5_ERCIndRevision")==0)
		{
			GRM_list_secondary_objects_only(priObjTag, relation, &count, &secondary_list);
			TC_write_syslog("\nCheck Design Revision Count   :: %d",count);

			if(count >= 41 )
			{
				EMH_store_error_s1(EMH_severity_error,DESREV_CONTLIMIT,"Design Revision count is reached max. limit to 50 with Indents Has Parts relation. Please Create new ERC Indent.");
				return DESREV_CONTLIMIT;
			}
		}
	}
	

	if(strcmp(type_name2,"Design Revision")==0)
	{
		 AOM_ask_value_string(secObjTag,"item_id",&designrevName);
		 TC_write_syslog("designrevName ::  %s\n", designrevName);
		 //printf("\ndesignrevName ::  %s\n", designrevName);fflush(stdout);

		 AOM_ask_value_string(secObjTag,"item_revision_id",&designrev);
		 TC_write_syslog("designrev ::  %s\n", designrev);
		// printf("\ndesignrevName ::  %s\n", designrev);fflush(stdout);

		if(designrevName != NULL && designrev != NULL)
		{
			values[0] = designrevName;
			ITEM_find_item_revs_by_key_attributes(1,attrs, values,designrev,&design_rev_cnt, &design_rev_tag);
			TC_write_syslog("design_rev_cnt ::  %d\n", design_rev_cnt);
			
			if(design_rev_cnt > 0)
			{
				if(design_rev_tag != NULLTAG)
				{				
					select_itemrev = design_rev_tag[0];
					AOM_ask_value_string(select_itemrev,"checked_out", &chkout_val);
					TC_write_syslog("chkout_val ::  %s\n", chkout_val);

					if(tc_strcmp(chkout_val,"Y") == 0)
					{					
						EMH_store_error_s2(EMH_severity_error,ITEM_CHECKED_OUT,designrevName,"is checked-out, kindly check-in Design Revision then attach to Indent.");
						return ITEM_CHECKED_OUT;
					}
				}
			}
		}
	}


	if(strcmp(type_name1,"T5_ERCIndRevision")==0)
	{

		AOM_ask_value_string(priObjTag,"t5PrtIndCat",&IndentCategory);
		TC_write_syslog("IndentCategory ::  %s\n", IndentCategory);
		//printf("\ndesignrevName ::  %s\n", designrevName);fflush(stdout);

		if (tc_strcmp(IndentCategory,"PLM Parts with Drawing")==0)
		{
			TC_write_syslog("PLM Parts with Drawing..");
			GRM_find_relation_type("IMAN_specification",&dataset_relation_type);

			GRM_list_secondary_objects_only(secObjTag,dataset_relation_type,&dataset_cnt,&DatasetList);
			TC_write_syslog("dataset_cnt ::  %d\n", dataset_cnt);

			if(dataset_cnt > 0)
			{
				for(i=0;i<dataset_cnt;i++)
				{
					AOM_ask_value_string(DatasetList[i],"object_type",&dataset_typeName);
					TC_write_syslog("dataset_typeName ::  %s\n", dataset_typeName);

					if(strcmp(dataset_typeName,"ProPrt")==0 || strcmp(dataset_typeName,"ProDrw")==0 || strcmp(dataset_typeName,"ProAsm")==0)
					{
						/// Calling function to get PDF and JT, from IMAN_rendering relation..
						result = getJTPDFItemRev(secObjTag);
						TC_write_syslog("result   %d",result);
						if(result == 1)
						{
							//EMH_store_error_s3(EMH_severity_error,ITEM_NOTMATCH,"Please attach ",DmlItemNumber," in Problem items relationship with DCR ");
							EMH_store_error_s3(EMH_severity_error,JT_PDF_NOT_FOUND,"Please attach JT/PDF to ", designrevName ," in relationship IMAN Rendering..");
							return JT_PDF_NOT_FOUND;
						}
					}
				}
			}
		}
	}
	
	MEM_free(DatasetList);
	return error_code;
}


int getJTPDFItemRev(tag_t DesignRevTag)
{
	int			n_attchs,i		= 0;
	int			ref_count_d		= 0;
	int			result			= 1;
	int			ifail				=	ITK_ok;
	tag_t		ref_type		= NULLTAG;
	tag_t		objTag			= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	tag_t*    secondary_list	 = NULLTAG;	
	tag_t*		namRefObject_d	= NULLTAG;
	char*		type_name		= NULL;
	
	if(GRM_find_relation_type("IMAN_Rendering",&ref_type)!= ITK_ok);
	if(GRM_list_secondary_objects_only(DesignRevTag,ref_type,&n_attchs,&secondary_list) != ITK_ok);
	TC_write_syslog("Total n attches ::  %d\n", n_attchs);
	
	for (i= 0; i < n_attchs; i++)
	{
		objTag = secondary_list[i];

		AOM_ask_value_string(objTag,"object_type",&type_name);
		TC_write_syslog("type_name ::  %s\n", type_name);
	
		if(tc_strcmp(type_name,"PDF") ==0)
		{
			AE_ask_dataset_named_refs(objTag,&ref_count_d, &namRefObject_d);
			TC_write_syslog("ref_count_d Count ::  %d\n", ref_count_d);

			if(ref_count_d > 0)
				result = 0;
		}
	}
	
	MEM_free(namRefObject_d);
	MEM_free(secondary_list);

	return result;
}


int Indent_Reviewers_assign(EPM_action_message_t msg )
{
	int ifail = ITK_ok;

	int			count, att_count,strlen = 0;
	int			member_count,mem_count		= 0;
	int			member_count1, rp_count		= 0;
	tag_t		rootTask_t			= NULLTAG;
	tag_t*		attachments			= NULLTAG;
	tag_t*		ChfEng_Members	    = NULLTAG;
	tag_t*		FunEng_Members	    = NULLTAG;
	tag_t*		Proto_Members	    = NULLTAG;
	tag_t*		members			    = NULLTAG;
	tag_t*		rps				    = NULLTAG;

	tag_t		Chf_user_tag	    = NULLTAG;
	tag_t		Mgr_user_tag	    = NULLTAG;
	tag_t		Mgr_Type_tag	    = NULLTAG;
	tag_t		ChfEng_Type_tag	    = NULLTAG;
	tag_t		Mgr_participant	    = NULLTAG;
	tag_t		ChfEng_participant  = NULLTAG;
	tag_t		Grp_tag				= NULLTAG;
	tag_t		role_tag		    = NULLTAG;
	tag_t		Func_role_tag		    = NULLTAG;
	tag_t		objTag				=  NULLTAG;
	tag_t		BU_Grp_tag				=  NULLTAG;
	tag_t		BU_role_tag				=  NULLTAG;
	tag_t		proto_Type_tag				=  NULLTAG;
	tag_t		proto_participant				=  NULLTAG;
	
	char*		obj_type			= NULL;
	char*		IndentChfEng		= NULL;
	char*		IndentApprover		= NULL;
	char*		tempChfEng			= NULL;
	char		*groupName			= NULL;
	char		*RoleName			= NULL;
	char		*FunctionalRoleName	= NULL;
	char		*user_id			= NULL;
	char		*type_name			= NULL;
	char		*IndentRoleName		= NULL;
	char		*IndentGrpName		= NULL;
	char		*ERCBU				= NULL;
	char		*PowerTrainInd		= NULL;

	char		ChfEngRev[20]			= {'\0'};
	char		tempChfEngRev[20]		= {'\0'};

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"ERC_Designers_Group");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	RoleName = (char	*)MEM_alloc(100);
	tc_strcpy(RoleName,"Chf_Eng_Role");
	printf("\n MT: RoleName  --> %s\n",RoleName);   fflush(stdout);

	IndentGrpName = (char	*)MEM_alloc(100);
	tc_strcpy(IndentGrpName,"Indent_Participants_Group");
	printf("\n MT: IndentGrpName  --> %s\n",IndentGrpName);   fflush(stdout);

	FunctionalRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(FunctionalRoleName,"Functional_Head_Grp");
	printf("\n MT: Functional RoleName  --> %s\n",FunctionalRoleName);   fflush(stdout);

	IndentRoleName = (char	*)MEM_alloc(100);
	

	EPM_ask_root_task(msg.task,&rootTask_t);
	EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments);

	if(count>0)
	{
		objTag = attachments[0];
	}
		
	if(count > 0)
	{
		for(att_count=0; att_count<count; att_count++)
		{
			WSOM_ask_object_type2(objTag, &obj_type);
			TC_write_syslog("Object Type = %s\n",obj_type);

			if(tc_strcmp(obj_type,"T5_ERCIndRevision") == 0)
			{
				AOM_ask_value_string(objTag,"t5PrtIndChfEng",&IndentChfEng);
				TC_write_syslog("IndentChfEng ::  %s\n", IndentChfEng);

				AOM_ask_value_string(objTag,"t5PrtIndApprov",&IndentApprover);
				TC_write_syslog("IndentApprover ::  %s\n", IndentApprover);
				
				AOM_ask_value_string(objTag,"t5ERCIndBU",&ERCBU);
				TC_write_syslog("ERCBU ::  %s\n", ERCBU);

				AOM_ask_value_string(objTag,"t5IndChkPRD",&PowerTrainInd);
				TC_write_syslog("PowerTrainInd ::  %s\n", PowerTrainInd);

				if(tc_strcmp(PowerTrainInd,"Y") == 0)
				{
					tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
				}
				else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
				{
					tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
				}
				else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
				{
					tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
				}

				TC_write_syslog("ERCBU  :: %s  ,  IndentRoleName ::  %s\n", ERCBU, IndentRoleName);
				

				if(IndentChfEng != NULL && IndentApprover != NULL)
				{
					
					if(SA_find_group(groupName, &Grp_tag)!=ITK_ok);
								
					/// Assignning Manager Review
					member_count = 0;
					if(SA_find_role2(FunctionalRoleName,&Func_role_tag)!=ITK_ok);
					if(SA_find_groupmember_by_role(Func_role_tag,Grp_tag,&member_count,&FunEng_Members)!=ITK_ok);
					TC_write_syslog("FunEng_Members member_count fun::  %d\n", member_count);

					if(member_count > 0)
					{
						for(mem_count=0; mem_count<member_count; mem_count++)
						{
							if(SA_ask_groupmember_user(FunEng_Members[mem_count], &Mgr_user_tag)!=ITK_ok);							
							
							if((POM_ask_user_id(Mgr_user_tag, &user_id))!=ITK_ok);
							TC_write_syslog("user_id  ::  %s\n", user_id);
							if(tc_strstr(IndentApprover, user_id) != NULL)
							{		
								TC_write_syslog("T5_IndMngrReviw ............. \n");
								TC_write_syslog(" Func user_id  ::  %s\n", user_id);
								if(EPM_get_participanttype ("T5_IndMngrReviw",&Mgr_Type_tag)!=ITK_ok);
								if(EPM_create_participant(FunEng_Members[mem_count],Mgr_Type_tag,&Mgr_participant)!=ITK_ok)
								AOM_unlock(objTag);
								AOM_refresh(objTag,TRUE);
								//AOM_unlock(Mgr_participant);
								//AOM_refresh(Mgr_participant,TRUE);
								AOM_lock(objTag);	 PrintErrorStack();
								if(ITEM_rev_add_participant(objTag,Mgr_participant)!=ITK_ok);
								AOM_save(objTag); PrintErrorStack();
								AOM_unlock(objTag); PrintErrorStack();
								//AOM_unlock(FunEng_Members[mem_count]);
								//AOM_refresh(FunEng_Members[mem_count],TRUE);
								break;
							}
						}
						
						AOM_unlock(objTag); PrintErrorStack();
						AOM_refresh(objTag,TRUE); PrintErrorStack();
						MEM_free(user_id);	
						MEM_free(FunEng_Members);
					}	
					

					//// Assigning Chief Eng Review..
					member_count = 0;
					if(SA_find_role2(RoleName,&role_tag)!=ITK_ok);
					if(SA_find_groupmember_by_role(role_tag,Grp_tag,&member_count,&ChfEng_Members)!=ITK_ok);
					TC_write_syslog("ChfEng_Members member_count ::  %d\n", member_count);

					if(member_count > 0)
					{
						for(mem_count=0; mem_count<member_count; mem_count++)
						{
							if(SA_ask_groupmember_user(ChfEng_Members[mem_count], &Chf_user_tag)!=ITK_ok);							
							
							if((POM_ask_user_id(Chf_user_tag, &user_id))!=ITK_ok);
							TC_write_syslog("user_id  ::  %s\n", user_id);
							if(tc_strstr(IndentChfEng, user_id) != NULL)
							{
								TC_write_syslog("T5_IndChfEng ............. \n");
								TC_write_syslog("Chf user_id  ::  %s\n", user_id);
								if(EPM_get_participanttype ("T5_IndChfEng",&ChfEng_Type_tag)!=ITK_ok);
								if(EPM_create_participant(ChfEng_Members[mem_count],ChfEng_Type_tag,&ChfEng_participant)!=ITK_ok)
								AOM_unlock(objTag); PrintErrorStack();
								AOM_refresh(objTag,TRUE); PrintErrorStack();
								AOM_lock(objTag);	PrintErrorStack();
								if(ITEM_rev_add_participant(objTag,ChfEng_participant)!=ITK_ok);
								AOM_save(objTag); PrintErrorStack();
								AOM_unlock(objTag); PrintErrorStack();
								break;
							}							
						}

						AOM_unlock(objTag);
						AOM_refresh(objTag,TRUE);
						MEM_free(user_id);	
						MEM_free(ChfEng_Members);
					}

				
					/// Assignning Proto Indent Review
					member_count = 0;
					if(SA_find_group(IndentGrpName, &BU_Grp_tag)!=ITK_ok);
					if(SA_find_role2(IndentRoleName,&BU_role_tag)!=ITK_ok);
					if(SA_find_groupmember_by_role(BU_role_tag,BU_Grp_tag,&member_count,&Proto_Members)!=ITK_ok);
					TC_write_syslog("Proto_Members member_count ::  %d\n", member_count);

					if(member_count > 0)
					{
						for(mem_count=0; mem_count<member_count; mem_count++)
						{		
							TC_write_syslog("T5_ProtoInd ............. \n");
							if(EPM_get_participanttype ("T5_ProtoInd",&proto_Type_tag)!=ITK_ok);
							if(EPM_create_participant(Proto_Members[mem_count],proto_Type_tag,&proto_participant)!=ITK_ok)
							AOM_unlock(objTag); PrintErrorStack();
							AOM_refresh(objTag,TRUE);  PrintErrorStack();
							AOM_lock(objTag);  PrintErrorStack();
							if(ITEM_rev_add_participant(objTag,proto_participant)!=ITK_ok);
							AOM_save(objTag); PrintErrorStack();
							AOM_unlock(objTag); PrintErrorStack();
						}
						
						AOM_unlock(objTag); PrintErrorStack();
						AOM_refresh(objTag,TRUE); PrintErrorStack();
						MEM_free(Proto_Members);  
					}
				}
			}
		}
	}
	return ifail;
}


int generate_indent_refno(EPM_action_message_t msg)
{
	int ifail = ITK_ok;

	int			count				= 0;
	int			att_count			= 0;
	tag_t		rootTask_t			= NULLTAG;
	tag_t*		attachments			= NULLTAG;

	tag_t		objTag				= NULLTAG;
	logical		found				= false;
	char*		obj_type			= NULL;
	char*		ERCBU				= NULL;
	char*		IndentRoleName		= NULL;
	char*		IndentRefNo			= NULL;
	char*		PowerTrainInd			= NULL;
	char*		IndentRefNum			= NULL;

	IndentRoleName = (char	*)MEM_alloc(100);
	IndentRefNo = (char	*)MEM_alloc(100);
	
	if(EPM_ask_root_task(msg.task,&rootTask_t)!=ITK_ok);
	if(EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments)!=ITK_ok);
	TC_write_syslog("Count :: %d",count);
	
	if(count > 0)
	{
		objTag = attachments[0];
	}
	
	if(count > 0)
	{
		WSOM_ask_object_type2(objTag, &obj_type);
		TC_write_syslog("Object Type = %s\n",obj_type);

		if(tc_strcmp(obj_type,"T5_ERCIndRevision") == 0)
		{
			AOM_ask_value_string(objTag,"t5ERCIndBU",&ERCBU);
			TC_write_syslog("ERCBU ::  %s\n", ERCBU);
			
			AOM_ask_value_string(objTag,"t5IndChkPRD",&PowerTrainInd);
			TC_write_syslog("PowerTrainInd ::  %s\n", PowerTrainInd);

			if(ERCBU != NULL)
			{
				if(tc_strcmp(PowerTrainInd,"Y") == 0)
				{
					tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
				}
				else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
				{
					tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
				}
				else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
				{
					tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
				}
			}
			TC_write_syslog("ERCBU  :: %s  ,  IndentRoleName ::  %s\n", ERCBU, IndentRoleName);

			if(IndentRoleName != NULL)
			{
				AOM_lock(objTag);
				AOM_set_value_string(objTag, "t5Indentee", IndentRoleName);
				AOM_save(objTag);
				AOM_unlock(objTag);
				AOM_refresh(objTag,TRUE);
			}
			
			AOM_get_value_string(objTag, "t5RefNo", &IndentRefNum);  
			TC_write_syslog("IndentRefNum ::  %s\n", IndentRefNum);

			if(IndentRefNum != NULL && tc_strstr(IndentRefNum,"PUN189999") == NULL)
			{
				//// Calling Function to get the Ref No.
				found = getIndentRefNo(IndentRefNo);
				if(found == true && IndentRefNo != NULL)
				{
					TC_write_syslog("IndentRefNo ::  %s\n", IndentRefNo);
					
					AOM_lock(objTag);
					AOM_set_value_string(objTag, "t5RefNo", IndentRefNo);
					AOM_save(objTag);
					AOM_unlock(objTag);
					AOM_refresh(objTag,TRUE);
				}
			}
		}	
	}
	
	MEM_free(IndentRefNum);
	return ifail;
}


logical getIndentRefNo(char *IndentRefNo)
{
   time_t now;
   char* result	=  NULL;
   char* finalrefno	=  NULL;
  // char* nxtSrl	=  NULL;
   char* location = "UAPUN";
   char* FixValue = "9999";
   char year [12] = {'\0'};
   char Sec [12] = {'\0'};
   char *sub = NULL;
   char *refno = NULL;
   char *latestRefNo = NULL;
   char    nxtSrl[25]= {'\0'};
   char    IndRefNo[25]= {'\0'};

   int		num_found		= 0;
   logical	found;
   int		latestref_int		= 0;
   char
        *qry_entries[1] = {"Indent Reference No"},
        *qry_values[1]	= {"*"};

   tag_t		query_tag		= NULLTAG;
   tag_t*		results			= NULLTAG;

   result = (char	*)MEM_alloc(100);
   finalrefno = (char	*)MEM_alloc(100);
  // nxtSrl = (char	*)MEM_alloc(100);
   sub = (char	*)MEM_alloc(100);

   if ( time(&now) != (time_t)(-1) )
   {
      struct tm *mytime = localtime(&now);
      if ( mytime )
      {
         if ( strftime(year, sizeof year, "%Y", mytime) )
         {
			TC_write_syslog("year ::  %s\n", year);
			sub = subString(year,2, 2);
			TC_write_syslog("sub ::  %s\n", sub);
         }

		 if ( strftime(Sec, sizeof year, "%S", mytime) )
         {
			TC_write_syslog("Sec ::  %s\n", Sec);
         }
      }
   }
	
	tc_strcpy(result,"");
   	tc_strcat(result,location);
	tc_strcat(result,sub);
	tc_strcat(result,FixValue);
	tc_strcat(result,"*");
	TC_write_syslog("result ::  %s\n", result);
   
	if(result != NULL)
	{
		qry_values[0] = result;
		QRY_find("Indent Ref Gen..", &query_tag);
		
		if(query_tag != NULLTAG)
		{
			QRY_execute(query_tag, 1, qry_entries, qry_values, &num_found, &results);
			TC_write_syslog("num_found ::  %d\n", num_found);
			if(num_found==0)
			{
				found=false;
			}
			if(num_found > 0)
			{
				AOM_ask_value_string(results[0] ,"t5RefNo", &refno);				
				TC_write_syslog("refno ::  %s\n", refno);
				latestRefNo = subString(refno,11, 5);
				TC_write_syslog("latestRefNo ::  %s\n", latestRefNo);
				
				if(latestRefNo != NULL)
				{
					latestref_int = atoi(latestRefNo);
					//TC_write_syslog("latestref_int ::  %d\n", latestref_int);
					latestref_int = latestref_int + 1;
					//TC_write_syslog("latestref_int ::  %d\n", latestref_int);
					
					sprintf (nxtSrl, "%d",latestref_int);
					TC_write_syslog("nxtSrl ::  %s\n", nxtSrl);
				}

				if(nxtSrl != NULL)
				{
					tc_strcpy(finalrefno,"");
					tc_strcat(finalrefno,location);
					tc_strcat(finalrefno,sub);
					tc_strcat(finalrefno,FixValue);
					tc_strcat(finalrefno,nxtSrl);
					tc_strcat(finalrefno,"_");
					tc_strcat(finalrefno,Sec);
					TC_write_syslog("finalrefno ::  %s\n", finalrefno);

					if(finalrefno != NULL)
					{
						tc_strcpy(IndentRefNo,"");
						tc_strcat(IndentRefNo,finalrefno);
						found=true;
					}
				}
			}
		}
	}

	return found;
}


int CM_Gen_ERC_IndentReport(EPM_action_message_t msg)
{
	time_t now;
	int			ifail							= ITK_ok;
	int			count,transfermodeCnt			= 0;
	char		outputtime[50]					= {'\0'};
	char		Data[50]						= {'\0'};
	
	time_t t ;
    struct tm *tmp ;
	time( &t );

	tag_t		rootTask_t		= NULLTAG;
	tag_t		objTag			= NULLTAG;
	tag_t		PLMSession		= NULLTAG;
	tag_t		specRelationType_t		= NULLTAG;
	tag_t		msExlType		= NULLTAG;
	tag_t		MsXlDataset		= NULLTAG;
	tag_t		specificationRel_t		= NULLTAG;
	tag_t		MsXlatestDat_t		= NULLTAG;
	tag_t*		attachments		= NULLTAG;
	tag_t*		transfermodes	= NULLTAG;

	char*		obj_type			= NULL;
	char*		indentNumber		= NULL;
	char*		indentrevision		= NULL;
	char*		token				= NULL;
	char		mainFile[100];
	char		XlsxFile[100];
	char		command[512];
	struct    tm when;
	
	if(EPM_ask_root_task(msg.task,&rootTask_t)!=ITK_ok);
	if(EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments)!=ITK_ok);
	TC_write_syslog("Count :: %d",count);
	
	GRM_find_relation_type("IMAN_specification",&specRelationType_t);

	if(count > 0)
	{
		objTag = attachments[0];
	}

	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputtime,"%s",Data);
	TC_write_syslog("outputtime :: %s\n",outputtime);
	

	if(objTag != NULLTAG)
	{
		WSOM_ask_object_type2(objTag,&obj_type);
		TC_write_syslog("obj_type :: %s",obj_type);

		if(tc_strcasecmp(obj_type,"T5_ERCIndRevision")==0)
		{
			AOM_ask_value_string(objTag,"t5RefNo",&indentNumber);
			TC_write_syslog("\nindentNumber :: %s",indentNumber);
			
			AOM_ask_value_string(objTag,"current_revision_id",&indentrevision);
			TC_write_syslog("\nindentrevision :: %s",indentrevision);
			
			token=strtok(indentrevision,";");

			tc_strcpy(mainFile,"");
			tc_strcat(mainFile,"/tmp/");
			tc_strcat(mainFile,indentNumber);
			tc_strcat(mainFile,"_");
			tc_strcat(mainFile,token);
			tc_strcat(mainFile,"_");
			tc_strcat(mainFile,outputtime);
			tc_strcat(mainFile,".xml");
			TC_write_syslog("\nMain File = %s\n",mainFile);

			
			tc_strcpy(XlsxFile,"");
			tc_strcat(XlsxFile,"/tmp/Indent_");
			tc_strcat(XlsxFile,indentNumber);
			tc_strcat(XlsxFile,"_");
			tc_strcat(XlsxFile,token);
			tc_strcat(XlsxFile,"_");
			tc_strcat(XlsxFile,outputtime);
			tc_strcat(XlsxFile,".xls");
			TC_write_syslog("Xlsx File = %s\n",XlsxFile);
		
			PIE_create_session(&PLMSession);
			PIE_session_set_file(PLMSession,mainFile);

			PIE_find_transfer_mode2("T5_ERC_MFG_Indent_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes);
			TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);

			if(transfermodeCnt > 0)
			{
				PIE_session_set_transfer_mode(PLMSession,transfermodes[0]);
				PIE_session_export_objects(PLMSession,1,&objTag);

				sprintf(command,"$TC_ROOT/bin/tml_tools/indent.sh %s %s",mainFile,XlsxFile);
				TC_write_syslog("Command = %s\n",command);
				system(command);

				if(access(XlsxFile,F_OK)!=-1)
				{
					TC_write_syslog("XLS file created successfully\n");
					AE_find_datasettype2("MSExcel",&msExlType);

					if(msExlType == NULLTAG)
					{
						TC_write_syslog("Could not find Dataset Type MSExcel. Please check data model\n");						 
					}

					AE_create_dataset_with_id(msExlType,indentNumber,"ERC Indent Report","","",&MsXlDataset);
					AE_save_myself(MsXlDataset);
					GRM_create_relation(objTag,MsXlDataset,specRelationType_t,NULLTAG,&specificationRel_t);
					AOM_load(specificationRel_t);
					GRM_save_relation(specificationRel_t);
					AE_ask_dataset_latest_rev(MsXlDataset,&MsXlatestDat_t);
					AOM_refresh(MsXlatestDat_t,TRUE);
					AE_import_named_ref(MsXlatestDat_t,"excel",XlsxFile,NULL,SS_BINARY);
					AE_save_myself(MsXlatestDat_t);
					remove(XlsxFile);
				}
			}
		}
	}

	return ifail;
}

EPM_decision_t Chk_DsgnRevObjs_Indent(EPM_rule_message_t msg)
{
	int				attachmentCount,count		= 0;
	logical			epmmsg						= false;	
	tag_t			rootTask_t					= NULLTAG;
	tag_t			objTag						= NULLTAG;
	tag_t			relation					= NULLTAG;

	tag_t*			taskAttachments				= NULLTAG;
	tag_t*			secondary_list				= NULLTAG;

	char*			obj_type					= NULL;
	char*			type_name2					= NULL;

	
	EPM_ask_root_task(msg.task,&rootTask_t);
	EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments);
	TC_write_syslog("\nattachmentCount  :: %d",attachmentCount);

	GRM_find_relation_type("T5ERCDtl", &relation);

	if(attachmentCount > 0)
	{
		objTag = taskAttachments[0];
	}

	if(objTag != NULLTAG)
	{
		WSOM_ask_object_type2(objTag,&obj_type);
		TC_write_syslog("obj_type :: %s",obj_type);

		if(tc_strcasecmp(obj_type,"T5_ERCIndRevision")==0)
		{
			GRM_list_secondary_objects_only(objTag, relation, &count, &secondary_list);
			
			TC_write_syslog("\ncount  :: %d",count);

			if(count > 0)
			{
				TC_write_syslog(" TRUE... \n");
				epmmsg = true;
				return EPM_go;				
			}
		}
	}

	if(epmmsg == false)
	{
		TC_write_syslog("\nItems not availble in ERC Indent. Hence returning EPM_nogo.Kindly attached Items in Indent\n");
		EMH_store_error_s1(EMH_severity_error,ITEMS_NOTFOUND_INDENT,"Please attach Item Revisions in Indents Has Parts relationship with Indent.");
		return EPM_nogo;
	}
}



extern DLLAPI int  save_method_17(METHOD_message_t *msg, va_list args)
{

		int		error_code				=	ITK_ok;
		int		desclength				=	0;
		int		revdesccnt				=	0;
		int		prt_seq				=	0;

		tag_t	objTag					=	va_arg(args, tag_t);
		tag_t	objTypeTag				=	NULLTAG;
		tag_t	priObjTag				=	NULLTAG;
		tag_t	priObjTypeTag			=	NULLTAG;
		tag_t	secObjTag				=	NULLTAG;
		tag_t	secObjTypeTag			=	NULLTAG;

		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		char   type_name2[TCTYPE_name_size_c+1];

		char	*desid					=	NULL;   
		char	*prtnumber					=	NULL;   
		char	*DesRevDesc				=	NULL;
		char	*ReplacedDesRevDesc		=	NULL;
		char	*NewReplacedDescription	=	NULL;
		char	*ItemMaterial			=	NULL;
		char	*DrwName				=	NULL;
		char	*FileName				=	NULL;
		char	*t5ApplOwnerDValCheckss				=	NULL;
		char	*t5ApplOwnerDValCheckss11				=	NULL;
   



      EPM_decision_t decision=EPM_go;

      printf("\n save_method_17::It's the time to save IMAN_specification relation \n");fflush(stdout);


	  if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	  printf("\n save_method_17::type_name :%s\n", type_name);fflush(stdout);


	  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	  printf("\n save_method_17::pri_type_name :%s\n", type_name1);fflush(stdout);

	  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	  printf("\n save_method_17::sec_type_nameAPPown :%s\n", type_name2);fflush(stdout);

	  
	  if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheck)!=ITK_ok);
	  printf("\n Before saving re;ation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheck);fflush(stdout);
	  if( AOM_ask_value_string(priObjTag,"item_id",&prtnumber)!=ITK_ok);
		if( AOM_ask_value_int(priObjTag,"sequence_id",&prt_seq)==ITK_ok)

	  printf("\n Before saving re;ation of dataset t5ApplOwnerDValCheck %s for part %s  %d and now the dataset in process is %s \n", t5ApplOwnerDValCheck,prtnumber,prt_seq,type_name2);fflush(stdout);

	  
	 if (tc_strcmp(t5ApplOwnerDValCheck,"")==0)
	{
		 printf("\n t5ApplOwnerDValCheck is not set");fflush(stdout);
		 if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0) || (tc_strstr(type_name2,"Creo")!=NULL) )
		{
			 //set proE value
			if(AOM_lock(secObjTag))PrintErrorStack();
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","ProEPart")!=ITK_ok);
			printf("\n ProAsm first AOM_set_value_string for app owner: ProEPart \n");fflush(stdout);
			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n ProAsm first save..\n");fflush(stdout);
			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n ProAsm first unlock..\n");fflush(stdout);	
			if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
			if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
			printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
			if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
			printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
			 
		}
		else if ((tc_strcmp(type_name2,"CMI2Part")==0) || (tc_strcmp(type_name2,"Cat-Part")==0))
		{
			//cat-part
			if(AOM_lock(secObjTag))PrintErrorStack();
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Part")!=ITK_ok);
			printf("\n in CMI2Part AOM_set_value_string for app owner: Cat-Part \n");fflush(stdout);
			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n in CMI2Part save..\n");fflush(stdout);
			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n in CMI2Part unlock..\n");fflush(stdout);	
			if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
			if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
			printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
			if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
			printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
		}
		else if (tc_strcmp(type_name2,"Cat-Product")==0|| tc_strcmp(type_name2,"CMI2Product")==0)
		{
			if(AOM_lock(secObjTag))PrintErrorStack();
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Product")!=ITK_ok);
			printf("\n in CMI2Product� AOM_set_value_string for app owner: Cat-Product \n");fflush(stdout);
			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n in CMI2Product� save..\n");fflush(stdout);
			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n in CMI2Product� unlock..\n");fflush(stdout);	
			if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
			if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
			printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
			if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
			printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
			
		}


		else if (tc_strcmp(type_name2,"T5_Alias")==0) 
		{
			if(AOM_lock(secObjTag))PrintErrorStack();
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Alias")!=ITK_ok);
			printf("\n in Alias AOM_set_value_string for app owner: Alias\n");fflush(stdout);
			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n in Alias save..\n");fflush(stdout);
			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n in Alias unlock..\n");fflush(stdout);	
			if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
			if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
			printf("\n after Alias dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
			if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
			printf("\n after saving relation of Alias dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
			
		}  

		
		/*if( (tc_strcmp(type_name2,"CMI2Part")!=0 ) && (tc_strcmp(type_name2,"CMI2Product")!=0 ) && (tc_strcmp(type_name2,"ProPrt")!=0 ) && (tc_strcmp(type_name2,"ProAsm")!=0 ))
		{
			printf("\n No CMI2Part/CMI2Product/ProPrt/ProAsm� Dataset found ..\n");fflush(stdout);
			if(AOM_lock(secObjTag))PrintErrorStack();
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
			printf("\n AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n save..\n");fflush(stdout);
			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n unlock..\n");fflush(stdout);	
		}*/

	}
	else
	{printf("\n t5ApplOwnerDValCheck is set not going to update it in this loop");fflush(stdout);}

	

      return error_code;
}


				/*********** Adi Alias ************/

extern DLLAPI int  save_method_18(METHOD_message_t *msg, va_list args)
{

		tag_t	objTag					=	va_arg(args, tag_t);
		tag_t	objTypeTag				=	NULLTAG;
		tag_t	priObjTag				=	NULLTAG;
		tag_t	priObjTypeTag			=	NULLTAG;
		tag_t	secObjTag				=	NULLTAG;
		tag_t	secObjTypeTag			=	NULLTAG;

		char   type_name[TCTYPE_name_size_c+1];
		char   type_name1[TCTYPE_name_size_c+1];
		char   type_name2[TCTYPE_name_size_c+1];
		//char   t5ApplOwnerDValCheckaaa[TCTYPE_name_size_c+1];


		tag_t	LatestRev		= NULLTAG; 
		tag_t	ref_item		= NULLTAG;  
		char* RevL				= NULL;			 
		char* object_name1		= NULL;	 
		char* ver_name			= NULL;		 
		char* item_id1			= NULL;	 
		char *AliasTransFileName= NULL;
		char *t5ApplOwnerDValCheckaaa= NULL;
		char *t5ApplOwnerDValCheckss =	NULL; //Adi TZ1.37 
		char *t5ApplOwnerDValCheckss11=	NULL; //Adi TZ1.37 
	 

	 printf("\n in save method 18888888888888 \n");fflush(stdout);

	 if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);
	  printf("\n save_method_18::type_name :%s\n", type_name);fflush(stdout);



	  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	  //if (TCTYPE_ask_name(priObjTypeTag,t5ApplOwnerDValCheckaaa)!=ITK_ok);
	  if( AOM_ask_value_string(priObjTypeTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckaaa)!=ITK_ok);

	  printf("\n save_method_18::pri_type_name :%s  application owner is %s \n", type_name1,t5ApplOwnerDValCheckaaa);fflush(stdout);


	  
	  	  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
	  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
	  if (TCTYPE_ask_name(secObjTypeTag,type_name2)!=ITK_ok);
	  printf("\n save_method_18::sec_type_name :%s\n", type_name2);fflush(stdout);

		if(tc_strcmp(type_name2,"T5_Alias")==0)
		{
			printf("\n DATASET TYPE IS [%s] \n" ,type_name2);fflush(stdout);

			//Adi TZ 1.37 BEGINS
			if(AOM_lock(secObjTag))PrintErrorStack();									
			if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Alias")!=ITK_ok);   
			printf("\n in Alias AOM_set_value_string for app owner \n");fflush(stdout);

			if(AOM_save(secObjTag))PrintErrorStack();
			printf("\n in Alias save..\n");fflush(stdout);

			if(AOM_unlock(secObjTag))PrintErrorStack();
			printf("\n in Alias unlock..\n");fflush(stdout);
			
			if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
			printf("\n in Alias refresh..\n");fflush(stdout);

			if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
			printf("\n After Alias dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);

			if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
			printf("\n After saving relation of Alias dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
			//Adi TZ 1.37 ENDS

			AOM_get_value_string(priObjTag, "object_name", &object_name1);	
			printf("\n object_name1 [%s] \n" ,object_name1);fflush(stdout);

			//AOM_get_value_string(objTag, "revision_number", &ver_name);	
			//printf("\n ver_name [%s] \n" ,ver_name);fflush(stdout);

			if(ITEM_find_item(object_name1,&ref_item));

			if(ITEM_ask_latest_rev(ref_item,&LatestRev));
			
			if( AOM_ask_value_string(LatestRev,"item_revision_id",&RevL)==ITK_ok) 
			printf("\n item_revision_id AAA--------------%s \n",RevL);fflush(stdout);

			if( AOM_ask_value_string(LatestRev,"item_id",&item_id1)==ITK_ok) 
			printf("\n item_id1 AAA--------------%s \n",item_id1);fflush(stdout);
			 				
			AliasTransFileName=malloc(2000);
			strcpy(AliasTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i='");
			//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");
			tc_strcat(AliasTransFileName,item_id1);
			tc_strcat(AliasTransFileName,"'");
			tc_strcat(AliasTransFileName," ");

			tc_strcat(AliasTransFileName,"-r='");
			tc_strcat(AliasTransFileName,RevL);
			tc_strcat(AliasTransFileName,"'");
			tc_strcat(AliasTransFileName," ");

			tc_strcat(AliasTransFileName,"-dt='");
			tc_strcat(AliasTransFileName,type_name2);
			tc_strcat(AliasTransFileName,"'");
			tc_strcat(AliasTransFileName," ");

			tc_strcat(AliasTransFileName,"-dn='");
			tc_strcat(AliasTransFileName,object_name1);
			tc_strcat(AliasTransFileName,"'");
			tc_strcat(AliasTransFileName," ");

			tc_strcat(AliasTransFileName,"-pr=1");
			tc_strcat(AliasTransFileName," ");
			tc_strcat(AliasTransFileName,"-pn=SIEMENS");
			tc_strcat(AliasTransFileName," ");
			tc_strcat(AliasTransFileName,"-tn=aliastocatpart");
			tc_strcat(AliasTransFileName," ");
			tc_strcat(AliasTransFileName,"-ty=COMMAND_LINE");

			printf("\n AliasTransFileName  T5_Alias before system is  =>%s\n", AliasTransFileName);fflush(stdout);

			system(AliasTransFileName);

			printf("\n After T5_Alias dispatcher_create_rqst shell =>%s\n", AliasTransFileName);fflush(stdout);

		}
	return ITK_ok;

}
			/*********** Adi Alias ************/

extern int save_relation_custom_exit(int *decision, va_list args)
{
    int ifail = ITK_ok;
    METHOD_id_t  method ;
	METHOD_id_t  method_action ;


    *decision = ALL_CUSTOMIZATIONS;  

    /* do something useful here, for now just return */
	printf("\n\n save_relation.c:it, via Custom Exits.\n");fflush(stdout);
    if ( METHOD_find_method("IMAN_specification", IMAN_save_msg, &method) !=ITK_ok);

 
    if (method.id != NULLTAG)
	{
		printf("\n !!!!!!!!!!!IMAN_specification ---Method is  found!!!!!!!!!!\n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_17, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}

	else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	}

	/*********** Alias ************/
 
    if (method.id != NULLTAG)
	{
		printf("\n !!!!!!!!!!! IMAN_specification ---Method is  found save_method_18 !!!!!!!!!!\n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) save_method_18, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	/*********** Alias ************/

	/// Changes by Dhiraj for Indent..

	if ( METHOD_find_method("T5ERCDtl", IMAN_save_msg, &method_action) !=ITK_ok);
	
	if (method_action.id != NULLTAG)
	{
		if( METHOD_add_action(method_action, METHOD_pre_action_type, (METHOD_function_t) Indent_Design_relation, NULL)!=ITK_ok);

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}

	}
	
	//Calling Action Handler for assigning Reviwers to indent..
	ifail=Indent_register_action_handlers();


	//Calling Rule Handler to check no. of design revision attach
	ifail=Indent_register_rule_handlers();


    return ifail;
}


int Indent_register_action_handlers()
{
	int ifail = ITK_ok;

	EPM_register_action_handler("Indent_Reviewers_assign","Assign MGR, Chief Eng and Proto Planner Reviwers", Indent_Reviewers_assign);
	TC_write_syslog("Registered Action Handler Indent_Reviewers_assign..\n");

	EPM_register_action_handler("generate_indent_refno","Generate Indent Ref No. after approval from manager",generate_indent_refno);
	TC_write_syslog("Registered Action Handler generate_indent_refno\n");

	EPM_register_action_handler("CM_Gen_ERC_IndentReport","Generate ERC Indent Report after Chief Reviwer",CM_Gen_ERC_IndentReport);
	TC_write_syslog("Registered Action Handler CM_Gen_ERC_IndentReport\n");

	return ifail;
}


int Indent_register_rule_handlers()
{
	int ifail = ITK_ok;

	EPM_register_rule_handler("Chk_DsgnRevObjs_Indent","Rule handler to validate no. of Design Rev. objs to indent",Chk_DsgnRevObjs_Indent);
	TC_write_syslog("Registered Rule Handler Chk_DsgnRevObjs_Indent..\n");

	return ifail;
}




extern DLLAPI int save_relation_register_callbacks ()
{
     printf("\n \n save_relation.c:::Hello Teamcenter, via Custom Exit\n");fflush(stdout);

     CUSTOM_register_exit ( "save_relation", "USER_init_module", (CUSTOM_EXIT_ftn_t) save_relation_custom_exit);

     return ( ITK_ok );
}
