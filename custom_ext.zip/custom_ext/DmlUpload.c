/*
# Basic Assumptions of this code :
#	1. If Item exists then; Item Revision also exists.
#	2. DML and Task are never Revised so, there exists only one version of DML and Task
#	3. Same Task Number with different design groups will be treated as different objects which will have object and object revision.
#	
# 
# 
*/

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

//PrintErrorStack();

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
//    	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Part Type"
//	 919003: error_919003, "Part Type"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"

    return ITK_ok;
}


#define ITK_CALL(X) 							\
		printf(#X);								\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			printf("\tSUCCESS\n");				\
		}										\


GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return strlen( pInput );
}



typedef struct  
{
	char* DmlIdS;  
	char* DmlDescS;
	char* DmlProjcodeS;
	char* DmlGrpS;
	char* DescriptionS;
	char* DispositionS;
	char* AuthorisedByS;	//
	char* CreatorS;	//
	char* RequestorS;
	char* AnalystS;	//	
	char* AdministratorS;	//	
	char* DmlLcsS;	//
	char* DmlStatsS;	//
	char* DmlPlanningStatusS;	//
	char* ClosureS;

	char* DMLTaskS;
	char* DMLTaskDescS;
	char* DMLTaskDsgGrpS;

	char* TcPartNumberS;
	char* RevisionS;
	char* SequenceS;


} DmlInputFile;




int t5CreateObject(char* type_name, char* DmlIdS,  char* DmlDescS, char* DmlProjcodeS, char* DmlGrpS, tag_t* item1)
{
	tag_t dml_rev_create_input_tag	= NULLTAG;                              
	tag_t dml_type_tag				= NULLTAG;
	tag_t object_create_input_tag		= NULLTAG;
	tag_t new_object						= NULLTAG;
	tag_t rev_type_tag				= NULLTAG;

	printf("\n t5CreateObject : Inside the program t5CreateObject\n");


	/* Construct a CreateInput object for dml */
	TCTYPE_find_type(type_name, NULL, &dml_type_tag);    
	if(dml_type_tag)
	{
		printf("\n t5CreateObject :  dml_type_tag Tag Found.");
	}
	TCTYPE_construct_create_input(dml_type_tag, &object_create_input_tag);

	AOM_set_value_string(object_create_input_tag, "item_id", DmlIdS);
	AOM_set_value_string(object_create_input_tag, "object_name", DmlDescS);
	//AOM_set_value_tag(object_create_input_tag, "revision",dml_rev_create_input_tag);
	
	//Create ChangeRequest Object and ChangeRequest Revision
	TCTYPE_create_object(object_create_input_tag, &new_object);
	if(new_object)
	{
		printf("\n t5CreateObject : %s object created.",type_name);
		AOM_save(new_object);
		AOM_unlock(new_object);
		*item1 = new_object;
	}

	printf("\n t5CreateObject : Exiting the program t5CreateObject\n");
	return 0;
}
;


int Find_Item(char* ItemIdS)
{
	//boolean flag		= TRUE;
	int n_tags_found	= 0	; 
	int status	= 0	;
	int ifail = ITK_ok;
	char* PartRev_id;
	char* PartItem_id;
	char* item_type;
	tag_t *item_tags_found = NULLTAG;
	tag_t *rev_tag	 = NULLTAG;
	
	char		   *ObjectClassType		= NULL;
    char		   *ObjectClassType1		= NULL;
    char		   *ObjectClassType2		= NULL;
    char		   *ObjectClassType3		= NULL;
 

	printf("\n\n Inside Find_Item ! ! ! \n\n");  fflush(stdout);
	printf("\n Inside Find_Item ItemIdS [%s] ",ItemIdS);  fflush(stdout);


	ifail = ITEM_find_item( ItemIdS, &item_tags_found );

//	ifail = ITEM_ask_type2 (item_tags_found, &item_type);
//	printf("\n Inside Find item_typeS [%s] ",item_type);  fflush(stdout);

	if (item_tags_found != NULLTAG)
	{
		if (AOM_ask_value_string(item_tags_found,"object_name",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
		printf("\n\n object_name : %s \n",ObjectClassType);

		if (AOM_ask_value_string(item_tags_found,"item_id",&ObjectClassType1)!=ITK_ok)   PrintErrorStack();
		printf("\n\n item_id : %s \n",ObjectClassType1);
	
		return 1;

	}
	else
		return 0;
}
;

void Query_Create_Object(char* type_name,char* DmlIdS,char* DmlDescS,char* DmlProjcodeS,char* DmlGrpS, tag_t* item1)
{
	int		status				= 0;
	char*	tempString			= NULL;
	int		flag				= 0;
	
	tag_t search_obj_tag = NULLTAG;

	flag = Find_Item(DmlIdS);


	if (flag == 1)
	{
		printf("\n Query_Create_Object : DML already found ! ! ! \n");  fflush(stdout);
	}
	if (flag == 0)
	{
		printf("\n Query_Create_Object : DML Not Found Hence Creating the DML with DML Revision... ");  fflush(stdout);

		// Create DML, DML Revision objects.
		status = t5CreateObject(type_name,DmlIdS, DmlDescS, DmlProjcodeS, DmlGrpS, &search_obj_tag);
		if(search_obj_tag != NULLTAG)
		{
			printf("\n Query_Create_Object : Object created with partnumber as %s\n",DmlIdS);fflush(stdout);
			*item1 = search_obj_tag;
		}
		else
		{
			printf("\n*** Query_Create_Object : Object creation failed with partnumber as %s ***\n",DmlIdS);fflush(stdout);
		}
	}
	//return search_obj_tag;
	/* Enhancement to do : if newly created item then only search_obj_tag is returned. Return the search_obj_tag if the object is already found in plm.  */
}
;



int ITK_user_main(int argc, char* argv[])
{
	int BUFFER_SIZE						=	500;
	int status = 0;
	int flag = 0;
	int ifail = ITK_ok;

	char *inputline				= NULL;
	//char*	DmlIdS				= NULL;
	//char*	DMLProjcode			= NULL;
	//char*	DMLDesc				= NULL;
	//char*	DMLGrp				= NULL;
	char*	argstring;

	char**	stringArray			= NULL;
	char*	tempString			= NULL;
	char*	item_type			= NULL;
    char*	ObjectClassType4	= NULL;

	DmlInputFile DmlStruct;
	int n_tags_found = 0;

	tag_t	itemTypeTag		= NULLTAG;
	tag_t	newItemTag		= NULLTAG;
	tag_t	itemCreInTag	= NULLTAG;
	tag_t	itemRevCreInTag	= NULLTAG;
	tag_t	itemRevTypeTag	= NULLTAG;
	tag_t	newDmlTag		= NULLTAG;
	tag_t	newDmlRevTag	= NULLTAG;
	tag_t	newTaskTag		= NULLTAG;
	tag_t	newTaskRevTag	= NULLTAG;
	tag_t	tRelationFind	= NULLTAG;
	tag_t	Rel_task		= NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	tag_t	PartRel_task	= NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t	tPartRelationExist		= NULLTAG;
	
	ITK_initialize_text_services (0);

	tag_t *tags_left = NULLTAG;
	tag_t *tags_right = NULLTAG;


	FILE *fp1;

	//ITK_CALL(ITK_auto_login ());
	if( ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;


    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

	argstring=ITK_ask_cli_argument("-i=");

	fp1=fopen(argstring,"r");

	if (argstring != 0)
    {
        /* user has given an fp1 file, rather then using stdin */
        if( !(fp1 = fopen( argstring, "rt" )))
        {
            fprintf(stderr, "\nCannot open fp1 file %s\n",argstring);
            exit( EXIT_FAILURE );
        }
        else
            printf("\nUsing input file %s\n",argstring);
    }
    else
    {
        printf("\nInput from Standard Input (stdin)\n");
    }

	if(fp1!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,BUFFER_SIZE,fp1)!=NULL)
		{
			fputs(inputline,stdout);
			
			// START : DML Attributes
			DmlStruct.DmlIdS=strtok(inputline,",");	//1
			printf("\n DmlIdS :%s",DmlStruct.DmlIdS); fflush(stdout);	

			DmlStruct.DmlDescS=strtok(NULL,",");	//2
			printf("\n DmlDescS :%s",DmlStruct.DmlDescS); fflush(stdout);

			DmlStruct.DmlProjcodeS=strtok(NULL,",");	//3
			printf("\n DmlProjcodeS :%s",DmlStruct.DmlProjcodeS); fflush(stdout);

			DmlStruct.DmlGrpS=strtok(NULL,",");	//4
			printf("\n DmlGrpS :%s",DmlStruct.DmlGrpS); fflush(stdout);

			DmlStruct.DescriptionS=strtok(NULL,",");	//5
			printf("\n DescriptionS :%s",DmlStruct.DescriptionS); fflush(stdout);

			DmlStruct.DispositionS=strtok(NULL,",");	//6			
			printf("\n DispositionS :%s",DmlStruct.DispositionS); fflush(stdout);

			DmlStruct.AuthorisedByS=strtok(NULL,",");	//7
			printf("\n AuthorisedByS :%s",DmlStruct.AuthorisedByS); fflush(stdout);

			DmlStruct.CreatorS=strtok(NULL,",");	//8
			printf("\n CreatorS :%s",DmlStruct.CreatorS); fflush(stdout);

			DmlStruct.RequestorS=strtok(NULL,",");	//9
			printf("\n RequestorS :%s",DmlStruct.RequestorS); fflush(stdout);

			DmlStruct.AnalystS=strtok(NULL,",");	//10
			printf("\n AnalystS :%s",DmlStruct.AnalystS); fflush(stdout);

			DmlStruct.AdministratorS=strtok(NULL,",");	//11
			printf("\n AdministratorS :%s",DmlStruct.AdministratorS); fflush(stdout);

			DmlStruct.DmlLcsS=strtok(NULL,",");	//12
			printf("\n DmlLcsS :%s",DmlStruct.DmlLcsS); fflush(stdout);

			DmlStruct.DmlStatsS=strtok(NULL,",");	//13
			printf("\n DmlStatsS :%s",DmlStruct.DmlStatsS); fflush(stdout);

			DmlStruct.DmlPlanningStatusS=strtok(NULL,",");	//14
			printf("\n DmlPlanningStatusS :%s",DmlStruct.DmlPlanningStatusS); fflush(stdout);

			DmlStruct.ClosureS=strtok(NULL,",");	//15
			printf("\n ClosureS :%s",DmlStruct.ClosureS); fflush(stdout);
			

			// START : DML Attributes.

			DmlStruct.DMLTaskS=strtok(NULL,"#");	//16
			printf("\n\n DMLTaskS :%s",DmlStruct.DMLTaskS); fflush(stdout);

			DmlStruct.DMLTaskDescS=strtok(NULL,"#");	//17
			printf("\n DMLTaskDescS :%s",DmlStruct.DMLTaskDescS); fflush(stdout);

			// START : TC Part Attributes.
			DmlStruct.TcPartNumberS=strtok(NULL,"$");	//18
			printf("\n TcPartNumberS :%s",DmlStruct.TcPartNumberS); fflush(stdout);
			DmlStruct.RevisionS=strtok(NULL,"$");	//19
			printf("\n RevisionS :%s",DmlStruct.RevisionS); fflush(stdout);
			DmlStruct.SequenceS=strtok(NULL,"$");	//20
			printf("\n SequenceS :%s",DmlStruct.SequenceS); fflush(stdout);
			
			// Calling Function to Query and Create the DML.
			Query_Create_Object("ChangeRequest",DmlStruct.DmlIdS,DmlStruct.DmlDescS,DmlStruct.DmlProjcodeS,DmlStruct.DmlGrpS,&newDmlTag);

			if (newDmlTag  != NULLTAG)
			{
				// Finding the Dml Revision for Creating its relation with the Task.

				ITK_CALL(ITEM_find_revision(newDmlTag,"A",&newDmlRevTag)) ;
				if (newDmlRevTag  != NULLTAG)
				{
					printf("\n YYYY \n");  fflush(stdout);
				}
				else
				{
					printf("\n XXXX \n");  fflush(stdout);
				}
			}


			ifail = ITEM_ask_type2 (newDmlRevTag, &item_type);
			printf("\n NNNN item_typeS [%s] ",item_type);  fflush(stdout);

			// Calling Function to Query and Create the Task.
			Query_Create_Object("T5_ChangeTask",DmlStruct.DMLTaskS,DmlStruct.DmlDescS,DmlStruct.DmlProjcodeS,DmlStruct.DmlGrpS,&newTaskTag);


			// Checking whether Relation exist between DML and Task

			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tRelationFind));
			if (tRelationFind	!=	NULLTAG)
			{
				/*Now Creating Relation Between Requirement and DVM Object*/
				GRM_find_relation(newDmlRevTag,newTaskTag,tRelationFind,&tRelationExist);  
				if (tRelationExist==NULLTAG)
				{
					//###  Creating Relation between DML and Task  ###

					printf("\n Now Creating Relation Between DML and DML Task Object \n");fflush(stdout);
					ITK_CALL(GRM_create_relation(newDmlRevTag,newTaskTag,tRelationFind,NULLTAG,&Rel_task));
					ITK_CALL(GRM_save_relation  (Rel_task)); 
					printf("\nRelation Created Successfully\n");fflush(stdout);							
				}
			}


			// Finding the DML-Task-Revision tag for creating relation with TC Part.

			tRelationFind = NULLTAG;
			if (newDmlTag  != NULLTAG)
			{			
				ITK_CALL(ITEM_find_revision(newTaskTag,"A",&newTaskRevTag)) ;
				if (newTaskRevTag  != NULLTAG)
				{
					printf("\n YYYY111 \n");  fflush(stdout);
				}
				else
				{
					printf("\n XXXX222 \n");  fflush(stdout);
				}
				ifail = ITEM_ask_type2 (newTaskRevTag, &item_type);
				printf("\n NNNN item_typeS [%s] ",item_type);  fflush(stdout);
			}

			
			tag_t *tags_found = NULL;
			int n_tags_found= 0;
			char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
			char **values = (char **) MEM_alloc(1 * sizeof(char *));

			attrs[0]	= "item_id";
			values[0]	= (char *)DmlStruct.TcPartNumberS;


			
			// Finding the part Number to be attached to Task Revions Tag  ###

			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

			item_tag = tags_found[0];

			if (AOM_ask_value_string(item_tag,"item_id",&ObjectClassType4)!=ITK_ok)   PrintErrorStack();
			printf("\n\n ObjectClassType4 Item id is ---->  :%s\n",ObjectClassType4);

			if (item_tag==NULLTAG)
			{
				printf("\n Part not available\n");fflush(stdout);
			}
			else
			{
				//###  Finding the Relation between DML Task Revions Tag and Part  ###

				ITK_CALL(GRM_find_relation_type  ("CMHasSolutionItem",&tRelationFind));

				if (tRelationFind!=NULLTAG)
				{
					/*Now Creating Relation Between Requirement and DVM Object*/
					GRM_find_relation(newTaskRevTag,item_tag,tRelationFind,&tPartRelationExist);  
					if (tPartRelationExist==NULLTAG)
					{

						//###  Creating Relation between DML Task and part  ###
						printf("\n Now Creating Relation Between DML and DML Task Object \n");fflush(stdout);
						ITK_CALL(GRM_create_relation(newTaskRevTag,item_tag,tRelationFind,NULLTAG,&PartRel_task));
						ITK_CALL(GRM_save_relation  (PartRel_task)); 
						printf("\nRelation Created Successfully\n");fflush(stdout);					
					}
				}
			}
		}
	}

	ITK_exit_module (TRUE);
	return status;
}