
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ESDSSpec.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   16-11-2018
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 16/11/2018   	 GP			    			Base Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov.h>
//#include <tc/tc.h>
#include <lov/lov_msg.h> 

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}



/* CHARACTER ARRAY */

void setAddStr_ESDS(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = (char *)malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr_ESDS character found===%s",(*strset)[*count-1]);fflush(stdout);
}
	
/*********************************/

int tm_updateObjMasterFormNameESDS(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;

	printf("\n Inside tm_updateObjMasterFormNameESDS \n");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\n tm_updateObjMasterFormName: Item ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
    ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));


	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			printf("\n Type Name:");fflush(stdout);
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			

	
			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;
			

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
            //if (tc_strcmp(type_name,"T5_MBOMDMLMaster")==0)
			//if (tc_strcmp(type_name,"T5_CkdDmlMaster")==0)
			if (tc_strcmp(type_name,"T5_EPSExpMaster")==0)
			{
				printf("\n Inside secondary Type Name:%s,%s ..............\n",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
			
		}
	}
	return 0;
}

int tm_updateObjRevMasterFormNameESDS(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\n Inside tm_updateObjRevMasterFormNameESDS \n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............\n",type_name);//fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s..............\n",type_name);//fflush(stdout);
			
			//if (tc_strcmp(type_name,"T5_MBOMDMLRevisionMaster")==0)
			//if(tc_strcmp(type_name,"T5_CkdDmlRevisionMaster")==0)
			if(tc_strcmp(type_name,"T5_EPSExpRevisionMaster")==0)

			{
				printf("\nInside secondary Type Name:%s,%s ..............\n",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
				printf("I am In Matched T5_EPSExpRevisionMaster...................\n");
			}
			else
			{
				printf("Not Matched...................\n");
			}
			

		}
	}
	return 0;
}

int tm_esds_num_gen( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	//char* item_id  = va_arg(args, char*);
    //const char* item_name = va_arg(args, char*);
    //const char* type_name = va_arg(args, char*);
    //const char* rev_id = va_arg(args, char*);
    //tag_t*      new_item = va_arg(args, tag_t*);
    //tag_t*      new_rev = va_arg(args, tag_t*);
    //tag_t       item_master_form = va_arg(args, tag_t);
    //tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	// Ketan New //

	tag_t new_item				= NULLTAG;
	int isnew              = 0;

	va_list largs;    
	va_copy( largs, args );
	new_item				= va_arg(largs, tag_t);
	isnew					= va_arg(largs, int);
	va_end( largs );

	//
	
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	SmlChckStr1		= NULL;
	char*	BscDmlA			= NULL;
	char	*ESorDS			= NULL;
	char	*VcNo			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[6]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);

	printf("\n Ketan Inside tm_esds_num_gen \n");fflush(stdout);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n Current Year ==> %s \n",CurrYear);fflush(stdout);
	
	SmlChckStr1 =  MEM_alloc(50);
	BscDmlA =  MEM_alloc(50);

	tag_t new_rev = NULLTAG;

	printf("\n isnew : %d\n",isnew); fflush(stdout);
	
	//if(*new_item != NULLTAG)
	if(new_item != NULLTAG && isnew==1)
	{
		printf("\n Inside new_item Test 1 \n");fflush(stdout);

		CALLAPI(ITEM_ask_latest_rev(new_item, &new_rev));
		
		char *value  = NULL;
		
		CALLAPI(AOM_ask_value_string(new_item,"t5_EsSpecTyp",&ESorDS));
		CALLAPI(AOM_ask_value_string(new_rev,"t5_ESRelVcNo",&VcNo));

		printf("\n This is Spec Type :  %s \n",ESorDS);fflush(stdout);	

		if(tc_strcmp(ESorDS,"E")==0)
		{
			printf("\n for ES \n");fflush(stdout);	
			tc_strcpy(SmlChckStr1,"ES");
		}
		else
		{
			printf("\n for DS \n");fflush(stdout);	
			tc_strcpy(SmlChckStr1,"DS");
		}
		tc_strcpy(BscDmlA,SmlChckStr1);
		tc_strcat(SmlChckStr1,"*");
		tc_strcat(SmlChckStr1,CurrYear);
		
		printf("\n Current Spec String ==> %s",BscDmlA);fflush(stdout);

		char *newid;
		char *item_idval=NULL;

		newid=(char *) MEM_alloc (20);
		
		tc_strcpy(newid,SmlChckStr1);

		const char *new_id_val={newid};
		const char *attr="item_id";

		CALLAPI(POM_enquiry_create("ckd_dml_enq"));

		const char *sel_attrs[1] = {"puid"};

		CALLAPI(POM_enquiry_add_select_attrs("ckd_dml_enq", "T5_EPSExp", 1, sel_attrs));
		CALLAPI(POM_enquiry_set_string_value("ckd_dml_enq", "value", 1, &new_id_val,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("ckd_dml_enq", "expression", "T5_EPSExp", attr, POM_enquiry_like, "value"));
		CALLAPI(POM_enquiry_set_where_expr ( "ckd_dml_enq", "expression" ));
		CALLAPI(POM_enquiry_add_order_attr ( "ckd_dml_enq","T5_EPSExp","creation_date",POM_enquiry_desc_order));
		
		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		//POM_enquiry_add_order_attr ( "ckd_dml_enq","T5_EPSExp","item_id",POM_enquiry_desc_order);

		CALLAPI(POM_enquiry_execute("ckd_dml_enq", &rows, &columns, &report));

		printf("\n Test 2 \n");fflush(stdout);

		if (rows != 0)
		{
			printf("\n Test 3 \n");fflush(stdout);
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n number of row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(objtag,"item_id",&item_idval));
			printf("\n The ESDSName is : %s \n",item_idval);fflush(stdout);		

			int		runningSrl;
			/*
			char *CkdRSrlNo;
			CkdRSrlNo=(char *) MEM_alloc (20);
			tc_strcpy(CkdRSrlNo,subString(item_idval,5,10));
			*/
			//const char* from = "1000010100";  
			char* from = item_idval;  
			char *CkdRSrlNo = MEM_alloc(4);
			strncpy(CkdRSrlNo, from+2, 3);
			CkdRSrlNo[4] = '\0';			

			printf("\n \n Received running serial :  %s \n",CkdRSrlNo);fflush(stdout);	
			runningSrl = atoi(CkdRSrlNo);
			runningSrl = runningSrl + 1001;
			
			printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
			char runningSrlChar[10];	
			sprintf(runningSrlChar, "%d", runningSrl);
			char *FinalRSrl = (char*) malloc(10);
			strncpy(FinalRSrl, runningSrlChar+1, 4);
			tc_strcat(BscDmlA,FinalRSrl);		
		}
		else
		{	
			printf("\n Test 4 \n");fflush(stdout);
			tc_strcat(BscDmlA,"001");
			//tc_strcat(BscDmlA,CurrYear);
		}
		printf("\n Test 5 \n");fflush(stdout);

		tc_strcat(BscDmlA,"/");
		tc_strcat(BscDmlA,CurrYear);
		POM_enquiry_delete("ckd_dml_enq");
		//item_id=BscDmlA;
		printf("\n Final Build DML ID will be :  %s \n",BscDmlA);fflush(stdout);	
		
		if(BscDmlA!= NULL)
		{
			printf("\n New Test 6 \n");fflush(stdout);
			CALLAPI(AOM_lock(new_item));
			CALLAPI(AOM_set_value_string(new_item,"item_id", BscDmlA));
			printf("\n new_item : set the item_id_ESDSName created :");fflush(stdout);	
			CALLAPI(AOM_set_value_string(new_item,"object_name", BscDmlA));
			printf("\n new_item : set the object_name_ESDSName created :");fflush(stdout);	
			CALLAPI(AOM_save_without_extensions(new_item));						
			CALLAPI(AOM_unlock(new_item));

			CALLAPI(AOM_lock(new_rev));
			CALLAPI(AOM_set_value_string(new_rev,"object_name", BscDmlA));
			printf("\n new_rev :set the object_name_ESDSName created :\n");fflush(stdout);	
			CALLAPI(AOM_save_without_extensions(new_rev));						
			CALLAPI(AOM_unlock(new_rev));

			CALLAPI(tm_updateObjMasterFormNameESDS(new_item, BscDmlA));//Update MASTER
			CALLAPI(tm_updateObjRevMasterFormNameESDS(new_rev, BscDmlA));//Update MASTER
      
			// CALLAPI(AOM_lock(item_master_form));
			// CALLAPI(AOM_set_value_string(item_master_form,"object_name", BscDmlA));
			// CALLAPI(AOM_save_without_extensions(item_master_form));						
			// CALLAPI(AOM_unlock(item_master_form));
      		// 
			// char *rev_master_form_id=NULL;
			// rev_master_form_id=MEM_alloc(30);
			// tc_strcpy(rev_master_form_id,BscDmlA); 
			// tc_strcat(rev_master_form_id,"/"); 
			// tc_strcat(rev_master_form_id,rev_id); 
			// CALLAPI(AOM_lock(item_rev_master_form));
			// CALLAPI(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
			// CALLAPI(AOM_save_without_extensions(item_rev_master_form));
			// CALLAPI(AOM_unlock(item_rev_master_form));

			printf("\n ES/DS Item ID Updated With %s",BscDmlA);fflush(stdout);			
      
			//MEM_free(rev_master_form_id);
		}
		
		if (VcNo!=NULL)
		{
			printf("\n Test 7 \n");fflush(stdout);
			CALLAPI(POM_enquiry_create("vc_query"));
			tc_strcpy(newid,VcNo);
			const char *new_id_val1={newid};
			
			CALLAPI(POM_enquiry_add_select_attrs("vc_query", "Design", 1, sel_attrs));
			CALLAPI(POM_enquiry_set_string_value("vc_query", "value", 1, &new_id_val1,POM_enquiry_bind_value));
			CALLAPI(POM_enquiry_set_attr_expr ("vc_query", "expression", "Design", attr, POM_enquiry_equal, "value"));
			CALLAPI(POM_enquiry_set_where_expr ( "vc_query", "expression" ));
			CALLAPI(POM_enquiry_add_order_attr ( "vc_query","Design","creation_date",POM_enquiry_desc_order));
			
			int  rows1 = 0, columns1 = 0;
			void ***report1;

			//POM_enquiry_add_order_attr ( "ckd_dml_enq","T5_EPSExp","item_id",POM_enquiry_desc_order);

			POM_enquiry_execute("vc_query", &rows1, &columns1, &report1);
			POM_enquiry_delete("vc_query");
			tag_t objtag1 = NULLTAG;
			char *item_Vc=NULL;
		
			if (rows1 != 0)
			{
				printf("\n Test 8 \n");fflush(stdout);
				objtag1  = *(tag_t*)(report1[0][0]);

				printf("\n \n Ketan number of row : %d cols : %d \n",rows1,columns1);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(objtag1,"item_id",&item_Vc));
				printf("\n VC no is %s ",item_Vc);fflush(stdout);
      
				tag_t vcrevtag=NULLTAG;
				char *item_NewVc=NULL;
				char *item_NewEsVc=NULL;
      
				CALLAPI(ITEM_ask_latest_rev (objtag1, &vcrevtag));
				
				tag_t relation_type,relation = NULLTAG;
				
				CALLAPI(AOM_ask_value_string(vcrevtag,"item_id",&item_NewVc));
				printf("\n new VC no is %s ",item_NewVc);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(new_rev,"item_id",&item_NewEsVc));
				printf("\n new esvc VC no is %s ",item_NewEsVc);fflush(stdout);

				CALLAPI(GRM_find_relation_type("T5_EpsVhR",&relation_type));
				CALLAPI(GRM_create_relation(new_rev,vcrevtag, relation_type,NULLTAG,&relation));
				CALLAPI(GRM_save_relation(relation));

				// Ketan Added for ESDS Release Status

				tag_t   qryTagCntrlobj		= NULLTAG;
				tag_t*	list_of_cntrl_tags	= NULLTAG;

				char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
				char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

				int controlObjfound	= 0;
				int	n_entryCntrlobj = 3;
				int	cntrlcnt		= 0;
				
				char*	ESDS_Lcs 		= NULL;
				
				if(QRY_find2("Control Objects...", &qryTagCntrlobj));

				if (qryTagCntrlobj)
				{
					printf("\n Control Object Query Found for ESDS Stamping \n");fflush(stdout);
					qry_valuesCntrlformat[0]="Stamping";
					qry_valuesCntrlformat[1]="ESDS";
					qry_valuesCntrlformat[2]="0";
										
					if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
				}
				else
				{
					printf("\n Control Object Query not Found for ESDS Stamping  \n");fflush(stdout);
				}

				printf("\n controlObjfound is for ESDS Stamping ==> %d\n",controlObjfound);fflush(stdout);

				if(controlObjfound>0)
				{
					printf("\n Live... Inside ESDS Stamping  \n");fflush(stdout);

					tag_t	ESDS_tag		= NULLTAG;
					tag_t	ESDS_rev_tag	= NULLTAG;
					tag_t	status_rel		= NULLTAG;
	
					char*	ESDS_No			= NULL;
					char*	ESDSRev_No		= NULL;

					logical	retain	= 0;

					CALLAPI(AOM_ask_value_string(new_rev,"item_id",&ESDS_No));
					printf("\n ESDS_No => %s ",ESDS_No);fflush(stdout);

					CALLAPI(ITEM_find_item (ESDS_No, &ESDS_tag));

					if(ESDS_tag != NULLTAG )
					{
						CALLAPI(ITEM_ask_latest_rev(ESDS_tag,&ESDS_rev_tag));
						AOM_ask_value_string( ESDS_rev_tag, "item_id", &ESDSRev_No);

						printf("\n ESDSRev_No : %s\n",ESDSRev_No);fflush(stdout);
					}
					
					AOM_ask_value_string( list_of_cntrl_tags[cntrlcnt], "t5_Userinfo1", &ESDS_Lcs);
					printf("\n Ketan ES LCS : %s\n",ESDS_Lcs);fflush(stdout);
									
					if(RELSTAT_create_release_status(ESDS_Lcs,&status_rel));
					if(RELSTAT_add_release_status(status_rel,1,&ESDS_rev_tag,retain));

					printf("\n Test 9 \n");fflush(stdout);
				}
				// Ended
			}
		}	
	}
	return ifail;
}

/*POPULATE VC NUMBER LIST OF VALUES FOR ES/DS DOCUMENT*/
/****************************************************************************
Function:       dynamic_VCList_LOV
Description:    This function to POPULATE VC NUMBER LIST OF VALUES FOR ES/DS DOCUMENT
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_VCList_LOV( char*** ES_VCList  ) 
{
	/* va_list for LOV_ask_values_msg */
 
    char*	user_name_string= NULL;
    char***	values			= NULL;
	char*	rolename		= NULL;
  
    int   ifail = ITK_ok;
    
    rolename =  (char *)MEM_alloc(100);

 	tag_t  user = NULLTAG;
 
    int Lov_cnt=0;
  
	printf("\n dynamic_VCList_LOV \n");fflush(stdout);

	int cnt=0;
	int  rows1 = 0, columns1 = 0;
	char **Qry_Values = (char **) MEM_alloc(500* sizeof(char*));
	char **names = (char **) MEM_alloc(500* sizeof(char*));
	//void ***report1;
	tag_t query;
	tag_t *report1;
	QRY_find2("DesRev_ERC_Rlzd",&query); //DesRevPartType_bymoddate
	names[0]="Part Type";
	names[1]="Name";
	Qry_Values[0]="Vehicle Combination" ;
	Qry_Values[1]="T5_LcsErcRlzd" ;
	if(query != NULLTAG)
	{
	    printf("\n going to execute the query \n");fflush(stdout);
	    QRY_execute(query,2,names,Qry_Values,&rows1,&report1);
	}
	printf("\n number of row : %d \n",rows1);fflush(stdout);

	//POM_enquiry_execute(QryCmd, &rows1, &columns1, &report1);
	//CALLAPI(POM_enquiry_delete(QryCmd)); 
	tag_t objtag1 = NULLTAG;
	char *item_Vc=NULL;
		
		if (rows1 != 0)
		{
		   for (cnt=0;cnt<rows1;cnt++)
		   {
			//objtag1  = *(tag_t*)(report1[cnt][0]);
            objtag1  = report1[cnt];
			//printf("\n \n number of row : %d cols : %d \n",rows1,columns1);fflush(stdout);
			
			AOM_ask_value_string(objtag1,"item_id",&item_Vc);
			printf("\n VC no is %s ",item_Vc);fflush(stdout);
			
		    setAddStr_ESDS(&Lov_cnt,ES_VCList,item_Vc);
		   }
		}
	

    return Lov_cnt;
}


/****************************************************************************
Function:       dynamic_VCList_LengthsMethod
Description:    This function to POPULATE VC NUMBER LIST OF VALUES FOR ES/DS DOCUMENT
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_VCList_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **ES_VCList=NULL;
  
    int ifail = ITK_ok;
   
  	printf("\n dynamic_VCList_LengthsMethod \n");fflush(stdout);
  
	*length=dynamic_VCList_LOV(&ES_VCList);
	printf("\n dynamic_VCList_LengthsMethod===>[%d] \n",*length);fflush(stdout);
  
     return ifail; 
}

/****************************************************************************
Function:       dynamic_VCList_ValuesMethod
Description:    This function to POPULATE VC NUMBER LIST OF VALUES FOR ES/DS DOCUMENT
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_VCList_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** ES_VCList;
	int Lov_cnt=0;
   
  
	 printf("\n dynamic_VCList_ValuesMethod");fflush(stdout);
	  
	 *n_values=dynamic_VCList_LOV(&ES_VCList);
	 printf("\n dynamic_VCList_ValuesMethod==>[%d]",*n_values);fflush(stdout);

	 *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	 memset (*values, 0,  *n_values * sizeof(char*));

	 for (ii = 0; ii < *n_values; ii++)
	{ 
						
		(*values)[ii] = (char *) MEM_alloc (strlen(ES_VCList[ii]) + 1);
		tc_strcpy ((*values)[ii], ES_VCList[ii]);
				   
	  } 
	  
    return ifail; 
}

extern int ESDSSpecinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  esds_item_create;
	METHOD_id_t  ckddml_rev_iman_save;
	METHOD_id_t  ckddml_rev_imantype_init_intl_props;
	METHOD_id_t methodpos;
	
	printf("\n ############ Ketan After Register ESDSSpecinitmodule");fflush(stdout);
	
	//CALLAPI(METHOD_find_method("T5_EPSExp", "ITEM_create", &esds_item_create));
	CALLAPI(METHOD_find_method("T5_EPSExp",TC_save_msg, &esds_item_create));
	if (esds_item_create.id != NULLTAG)
    {	
		printf("\n  before Register tm_esds_num_gen");fflush(stdout);
		CALLAPI(METHOD_add_action(esds_item_create, METHOD_post_action_type,(METHOD_function_t)tm_esds_num_gen ,NULL));
		printf("\n After Register tm_esds_num_gen");fflush(stdout);
    }
	else
	{
		printf("\n After Register tm_esds_num_gen  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	//	printf("\n IN ******************************going to register dynamic_VCList_ValuesMethod == REGISTER");fflush(stdout);	
   /* End  */
	/* VC NUMBER LIST OF VALUES POPULATE FOR ES/DS DOCUMENT*/
	CALLAPI(METHOD_register_method( "T5_ESRelVcNoLov",LOV_ask_values_msg,&dynamic_VCList_ValuesMethod, 0,&methodpos));
    CALLAPI(METHOD_register_method( "T5_ESRelVcNoLov",LOV_ask_num_of_values_msg,&dynamic_VCList_LengthsMethod,0,&methodpos));
	//printf("\n IN ******************************dynamic_VCList_ValuesMethod == REGISTER  END");fflush(stdout);	
   /* End  */


	return ifail;
	
}

extern DLLAPI int tm_ESDSSpec_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registering user service....tm_ESDSSpec");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ESDSSpec", "USER_init_module", (CUSTOM_EXIT_ftn_t)ESDSSpecinitmodule);
	//ifail=CUSTOM_register_exit ( "tm_ESDSSpec", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)ESDSSpecinitmodule);
	//printf("\n After registering user service....tm_ESDSSpec");fflush(stdout);
	return ( ITK_ok );
}
