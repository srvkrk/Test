/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *--------------------------------------------------------------------------------------------------------
** Filename		:	tm_PartRelGMDMLRep.c(.so File)
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating DR migration DML report Featured Required in TCUA like TCE.
*				  > This ITK functions will calle in Rich Client for generating report.
* Module  		     

* Since		    :   10-05-2024
* ENVIRONMENT	:   C,ITK

*
* History

*--------------------------------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 03/05/2024 	 Akhilesh Mittal	   DR migration DML report Featured Required in TCUA like TCE
* 			
* -------------------------------------------------------------------------------------------------------
* //Input argument==  ./tm_PartRelGMDMLRep -V=51696168000R,29990249000R -Usr="akumar1.ttl"
*****************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
int PartRelGMDMLRep(void *return_data)
{
	
	int 				ifail						= ITK_ok;
	int 				n_tags_found				= 0;
    tag_t				*tags_found 				= NULLTAG;
    tag_t				item_id 					= NULLTAG;
	const char 			*attrs[1];
    const char 			*values[1];
	char 				*InputVcs					= NULL;
	char 				*OutFile					= NULL;
	FILE				*uservclist					= NULL;
	FILE				*Report						= NULL;
	char*   			itemid	     		     	= NULL;
	char*   			vc_number     		    	= NULL;
	char*   			UserName     		    	= NULL;
	char	command[1000];
	OutFile = (char *) MEM_alloc(100 * sizeof(char *));
	printf("\n I am in main ITK program");fflush(stdout);
	USERARG_get_string_argument(&InputVcs);
    USERARG_get_string_argument(&UserName);

	printf("\n InputVcs Number :: %s ",InputVcs);fflush(stdout);
	printf("\n Login user :: %s ",UserName);fflush(stdout);
	printf("\n Going to call Exe");fflush(stdout);	

	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"GMRelRpt","CONFIG","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;
	
	// Deprecated API: QRY_find changed to QRY_find2
	ITKCALL(QRY_find2("Control Objects...",&qryTagCntrl1));
	
	//CALLAPI(QRY_find("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			sprintf(cmd,"%s %s %s &",t5_Userinfo1,InputVcs,UserName);
			printf("Excuting Command = %s",cmd);fflush(stdout);
			system(cmd);
			printf("After executing Command");fflush(stdout);
	   }
	}
	
	return ifail;
	//return ITK_ok;
}
extern int tm_PartRelGMDMLRepfncalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 	
	
	int nargs = 2;
	int retValueType;
	int inputArgTypes[2] = {0};
	inputArgTypes[0] = USERARG_STRING_TYPE; //InputVcs
	inputArgTypes[1] = USERARG_STRING_TYPE; //UserName
	
		
	retValueType = USERARG_STRING_TYPE ; 
	printf("\n tm_PartRelGMDMLRepfncalling before....PartRelGMDMLRep");fflush(stdout);  
	ifail=USERSERVICE_register_method("PartRelGMDMLRep",(USER_function_t)PartRelGMDMLRep,nargs,inputArgTypes,retValueType);
	
	return ifail;
}
extern DLLAPI int tm_PartRelGMDMLRep_register_callbacks ()
{	
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_PartRelGMDMLRep");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_PartRelGMDMLRep", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_PartRelGMDMLRepfncalling);
	printf("\n After registering userservice....tm_PartRelGMDMLRep");fflush(stdout);
	return(ITK_ok);
}