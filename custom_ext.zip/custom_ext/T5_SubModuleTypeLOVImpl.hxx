//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_SubModuleTypeLOVImpl
//

#ifndef TRL001__T5_SUBMODULETYPELOVIMPL_HXX
#define TRL001__T5_SUBMODULETYPELOVIMPL_HXX

#include <T5_newpartreq/T5_SubModuleTypeLOVGenImpl.hxx>

#include <T5_newpartreq/libt5_newpartreq_exports.h>


namespace TRL001
{
    class T5_SubModuleTypeLOVImpl; 
    class T5_SubModuleTypeLOVDelegate;
}

class  T5_NEWPARTREQ_API TRL001::T5_SubModuleTypeLOVImpl
    : public TRL001::T5_SubModuleTypeLOVGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_SubModuleTypeLOV
    explicit T5_SubModuleTypeLOVImpl( T5_SubModuleTypeLOV& busObj );

    ///
    /// Destructor
    virtual ~T5_SubModuleTypeLOVImpl();

private:
    ///
    /// Default Constructor for the class
    T5_SubModuleTypeLOVImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_SubModuleTypeLOVImpl( const T5_SubModuleTypeLOVImpl& );

    ///
    /// Copy constructor
    T5_SubModuleTypeLOVImpl& operator=( const T5_SubModuleTypeLOVImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_SubModuleTypeLOVDelegate;

};

#include <T5_newpartreq/libt5_newpartreq_undef.h>
#endif // TRL001__T5_SUBMODULETYPELOVIMPL_HXX
