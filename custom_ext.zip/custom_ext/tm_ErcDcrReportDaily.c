/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ErcDcrReportDaily.c
*
* Description	: > Generate Weekly report on ERC DCR object on Plant basis.
*				  
* Module  		        
* Since		    :   30-08-2023
* ENVIRONMENT	:   C, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 30/08/2023   	 Vaibhav Bodkhe						    Base Code
* 			

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}



signed long daysInSecond(signed int day){
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y-%H-%M",timeptr);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y_%H_%M",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int ITK_user_main(int argc,char *argv[])
{
	int iFail     = 0;
	int status     = 0;
	int dmlcounter     = 0;
	char*  Plant = ITK_ask_cli_argument("-P=");
	char*   From_date = NULL;
	char*   To_date = NULL;
	FILE *Report = NULL;
	
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);
	printf("\n Login to DB succesfully\n");
	char CurrentDate[20]={0};
	getCurrentDateTime(CurrentDate);
	printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
	char* filename =NULL;
	filename=(char*) MEM_alloc(100);
	tc_strcpy(filename,"");
	tc_strcpy(filename,Plant);
	tc_strcat(filename,"_ERC_DCR_REPORT_Daily_");
	tc_strcat(filename,CurrentDate);
	tc_strcat(filename,".csv");
	printf("\n File Name %s\n",filename);fflush(stdout);
	Report = fopen(filename,"w");
	
	struct tm *timeinfo;
	time_t t1;
	time_t t3;
	char buffer[256];
	
	t1 = time(NULL);
    t3 = shiftDate(t1,-1);
	timeinfo = localtime(&t3);
	strftime (buffer, 20, "%d-%b-%Y",timeinfo);
	printf("Date After :%s\n",buffer);

	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,buffer);
	tc_strcat(From_date," 00:00");
	
	t3 = shiftDate(t1,-1);
	timeinfo = localtime(&t3);
	strftime (buffer, 20, "%d-%b-%Y",timeinfo);
	printf("Date Before :%s\n",buffer);

	tc_strcpy(To_date,"");
	tc_strcpy(To_date,buffer);
	tc_strcat(To_date," 23:59");
	printf("\n\n\n\n\nFrom date [%s] \n To Date [%s]\n\n\n",From_date,To_date);fflush(stdout);
	fprintf(Report,"\n Report ,For, Date,:%s,:%s \n",From_date,To_date);fflush(Report);
	fprintf(Report, "\n S.No,ERC DML,DML Description,LCS,DR Status ,Project code,Creator,Creation Date,Closure Time,Release Type,DCR no,Reason For Change, STDSI Planner\n");fflush(Report);
	char*   TaskPlant 		= NULL;
	char*   STDSUserPlant   = NULL;
	char*   STDRoleName   = NULL;
	int 	Obj_Count   = 0;
    tag_t*  ERC_DMLTag 	= NULLTAG;
	tag_t   querytag	= NULLTAG;
	TaskPlant = (char *) MEM_alloc(100);
	STDSUserPlant = (char *) MEM_alloc(100);
	STDRoleName = (char *) MEM_alloc(100);
	tc_strcpy(TaskPlant,"");
	tc_strcpy(STDSUserPlant,"");
	tc_strcpy(STDRoleName,"");
	if(tc_strcmp(Plant,"JSR")==0)
	{
		tc_strcpy(TaskPlant,"APLJ");
		tc_strcpy(STDSUserPlant,"STDJSR");
		tc_strcpy(STDRoleName,"STDJ_Analyst");
	}
	else if(tc_strcmp(Plant,"PUNE")==0)
	{
		tc_strcpy(TaskPlant,"APL");
		tc_strcpy(STDSUserPlant,"STDPUNE");
		tc_strcpy(STDRoleName,"STDP_Analyst");
	}
	else if(tc_strcmp(Plant,"PNR")==0)
	{
		tc_strcpy(TaskPlant,"APLU");
		tc_strcpy(STDSUserPlant,"STDUTK");
		tc_strcpy(STDRoleName,"STDU_Analyst");
	}
	else if(tc_strcmp(Plant,"DWD")==0)
	{
		tc_strcpy(TaskPlant,"APLD");
		tc_strcpy(STDSUserPlant,"STDDWD");
		tc_strcpy(STDRoleName,"STDD_Analyst");
	}
	else if(tc_strcmp(Plant,"LKO")==0)
	{
		tc_strcpy(TaskPlant,"APLL");
		tc_strcpy(STDSUserPlant,"STDLKO");
		tc_strcpy(STDRoleName,"STDL_Analyst");
	}
	printf("\n TaskPlant is %s \n STDSUserPlant is %s \n STDRoleName %s \n",TaskPlant,STDSUserPlant,STDRoleName);fflush(stdout);
	char    	*qryentrs[4]	= {"ID","Name","date_released_after","date_released_before"};	
	char		**qryvalue= (char **) MEM_alloc(500 * sizeof(char *));
	ITK_CALL(QRY_find("ERCDMLReleased",&querytag));
	if(querytag != NULLTAG)
	{
		printf("\n\n Inside Query Execute ");fflush(stdout);
		int i =0;
		int j =0;
		int countpdml =0;
		char*  rlsztype =NULL;
		char*  NewRlzType =NULL;
		char*  rlsstatus =NULL;
		char*  dmlobjid =NULL;
		char*  dmlrlszstatus =NULL;
		char*  projcode =NULL;
		char**  designgrp;
		char*  dmluser =NULL;
		char*  dmlobjdesc =NULL;
		char*  dmlobjdesc1 =NULL;
		char*  dmlobjdesc2 =NULL;
		char*  creationdDate =NULL;
		char*  DRstatus =NULL;
		char*  dateRelz =NULL;
		char*  PlantdmlName =NULL;
		char*  Planttemp =NULL;
		char*  Getplantname =NULL;
		char*  Getplant =NULL;
		int GM_Count      = 0;
		int Admin_count   = 0;
		int Priv_count    = 0;
		int grpmemitr     = 0;
		int usercnt     = 0;
		int ii     = 0;
		int num111     = 0;
		tag_t  *Usertaglist   = NULLTAG;
		tag_t  Proj_tag   = NULLTAG;
		tag_t* GM_Found1  = NULLTAG;
		tag_t* GM_Found2  = NULLTAG;
		tag_t* GM_Found3  = NULLTAG;
		char *GrpMembName = NULL;
		char *STDAnalyst1  = NULL;
		char *STDAnalyst  = NULL;
		STDAnalyst = (char *) MEM_alloc(500);
		char* stdAnlystRole = NULL;
		stdAnlystRole = (char*) MEM_alloc(100);
		Planttemp = (char *) MEM_alloc(100);
		Getplantname = (char *) MEM_alloc(100);
		Getplant = (char *) MEM_alloc(100);
		tag_t* plantDML = NULLTAG;
		tag_t TskToDMLRel = NULLTAG;
		qryvalue[0]="*";
		qryvalue[1]="T5_LcsErcRlzd"; //ERC Released
		//qryvalue[2]="01-Jan-2023 00:00";
		qryvalue[2]=From_date;
		//qryvalue[3]="31-Aug-2023 23:59";
		qryvalue[3]=To_date;
		ITK_CALL(QRY_execute(querytag,4, qryentrs, qryvalue, &Obj_Count, &ERC_DMLTag));
		printf("\n\n Number of object Found %d \n\n",Obj_Count);fflush(stdout);
		for(i=0;i<Obj_Count;i++)
		{
			AOM_ask_value_string(ERC_DMLTag[i],"item_id",&dmlobjid);
			printf("\n ERC DML id :%s\n",dmlobjid);fflush(stdout);
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
			if (TskToDMLRel!=NULLTAG)
			{
				ITKCALL(GRM_list_secondary_objects_only(ERC_DMLTag[i],TskToDMLRel,&countpdml,&plantDML));
				printf("\n*****countpdml:%d \n",countpdml);fflush(stdout);
			
				for(j=0;j<countpdml;j++)
				{
					
					AOM_ask_value_string(plantDML[j], "item_id", &PlantdmlName);
					printf("\n Plant DML:%s",PlantdmlName);fflush(stdout);
				
					Planttemp = strtok(PlantdmlName,"_");
					Getplantname = strtok(NULL,"_");
					printf("\n      Planttemp %s, \n      Getplantname %s ",Planttemp,Getplantname);fflush(stdout);
					
					if(tc_strcmp(Getplantname,TaskPlant) == 0)
					{
						AOM_UIF_ask_value(ERC_DMLTag[i],"release_status_list",&dmlrlszstatus);
						printf("\nERC DML Rls status :%s\n ",dmlrlszstatus);fflush(stdout);
						AOM_ask_value_string(ERC_DMLTag[i],"current_desc",&dmlobjdesc2);
						//STRNG_replace_str(dmlobjdesc,","," ",&dmlobjdesc1);
						//STRNG_replace_str(dmlobjdesc1,"\n"," ",&dmlobjdesc2);
						STRNG_clean_up_string(dmlobjdesc2);
						printf("\n ERC DML Description After replace:%s\n ",dmlobjdesc2);fflush(stdout);
						AOM_ask_value_string(ERC_DMLTag[i],"t5_cprojectcode",&projcode);
						printf("\n ERC DML Project code :%s\n ",projcode);fflush(stdout);
					//	AOM_UIF_ask_value(ERC_DMLTag[i],"t5_crdesigngroup",&designgrp);
						AOM_ask_value_strings(ERC_DMLTag[i],"t5_crdesigngroup",&num111,&designgrp);
						printf("\n num of t5_crdesigngroup : %d\n",num111);fflush(stdout);
						printf("\n ERC DML Design Group :%s\n ",designgrp[0]);fflush(stdout);
						AOM_UIF_ask_value(ERC_DMLTag[i],"owning_user",&dmluser);
						printf("\n ERC DML user :%s\n ",dmluser);fflush(stdout);
						AOM_UIF_ask_value(ERC_DMLTag[i],"creation_date",&creationdDate);
						printf("\n ERC DML creation Date :%s\n ",creationdDate);fflush(stdout);
						AOM_ask_value_string(ERC_DMLTag[i],"t5_cDRstatus",&DRstatus);
						printf("\n ERC DML DR Status :%s\n ",DRstatus);fflush(stdout);
						AOM_UIF_ask_value(ERC_DMLTag[i],"date_released",&dateRelz);
						printf("\n ERC DML Closure/Release Date :%s\n ",dateRelz);fflush(stdout);
						//AOM_ask_value_string(ERC_DMLTag[i],"t5_rlstype",&rlsztype);
						AOM_UIF_ask_value(ERC_DMLTag[i],"t5_rlstype",&NewRlzType);
						//NewRlzType = t5_Releasetype(rlsztype);
						
						tag_t dcrrel =NULLTAG;
						tag_t* DCR_Tag =NULLTAG;
						int DCR_Count = 0;
						int k = 0;
						char* dcritemid =NULL;
						char* Dcr_reason =NULL;
						char* Dcr_reason1 =NULL;
						GRM_find_relation_type("CMImplements",&dcrrel);
						if(dcrrel!=NULLTAG)
						{
							GRM_list_secondary_objects_only(ERC_DMLTag[i],dcrrel,&DCR_Count,&DCR_Tag);
						}
						printf("\n ERC DCR Count :%d\n ",DCR_Count);fflush(stdout);
						tc_strcpy(stdAnlystRole,"");
						if(DCR_Count>0)
						{
							for(k=0;k<DCR_Count;k++)
							{
								//if multiple design grp strtok Design group  or get AOM get valu strings.
								tc_strcpy(stdAnlystRole,designgrp[0]);
								tc_strcat(stdAnlystRole,"_");
								tc_strcat(stdAnlystRole,STDRoleName);
								//Find STD Planner From Project 
								/* PROJ_find(projcode,&Proj_tag);
								if(Proj_tag!=NULLTAG)
								{
									printf("\n Going to find  Project Team.........\n");fflush(stdout);
									ITKCALL(PROJ_ask_team(Proj_tag,&GM_Count,&GM_Found1,&Admin_count,&GM_Found2,&Priv_count,&GM_Found3));
									printf("\n GM_Count %d",GM_Count);fflush(stdout);
									printf("\n Admin_count %d",Admin_count);fflush(stdout);
									printf("\n Priv_count %d",Priv_count);fflush(stdout);
									if(GM_Count>0)
									{
										tc_strcpy(STDAnalyst,"");
										for(grpmemitr=0;grpmemitr<GM_Count;grpmemitr++)
										{
											AOM_ask_value_string(GM_Found1[grpmemitr],"object_name",&GrpMembName);
											if(tc_strstr(GrpMembName,stdAnlystRole)!=NULL)
											{
												AOM_ask_value_string(GM_Found1[grpmemitr],"user_name",&STDAnalyst1);
												printf("\n GrpMembName %s\n",GrpMembName);fflush(stdout);
												printf("\n STD Analyst User ID  %s\n",STDAnalyst1);fflush(stdout);
												tc_strcat(STDAnalyst,STDAnalyst1);
												tc_strcat(STDAnalyst," ");
												//break;
											}
										}
										printf("\n brfore missing:%s",STDAnalyst);fflush(stdout);
										if(tc_strcmp(STDAnalyst,"")==0)
										{
											tc_strcpy(STDAnalyst,"");
											tc_strcpy(STDAnalyst,"Missing");
										}
									}
								} */
								
								//ITKCALL(SA_find_groupmember_by_rolename("09_STDJ_Analyst","STDJSR",NULL,&usercnt,&Usertaglist));
								//Find STD Planner from Role & group.......
								ITKCALL(SA_find_groupmember_by_rolename(stdAnlystRole,STDSUserPlant,NULL,&usercnt,&Usertaglist));
								printf("\n Number of user found %d",usercnt);
								tc_strcpy(STDAnalyst,"");
								for(ii=0;ii<usercnt;ii++)
								{
									AOM_ask_value_string(Usertaglist[ii],"user_name",&STDAnalyst1);
									//printf("\n STDAnalyst1 %s\n",STDAnalyst1);fflush(stdout);
									tc_strcat(STDAnalyst,STDAnalyst1);
									tc_strcat(STDAnalyst," ");
									tc_strcat(STDAnalyst,"|");
									tc_strcat(STDAnalyst," ");
								}
								printf("\n STD Analyst 1 ok :%s",STDAnalyst);fflush(stdout);
								if(tc_strcmp(STDAnalyst,"")==0)
								{
									tc_strcpy(STDAnalyst,"");
									tc_strcpy(STDAnalyst,"Missing");
								}
								printf("\n STD Analyst 2 ok :%s",STDAnalyst);fflush(stdout);
								dmlcounter++;
								AOM_ask_value_string(DCR_Tag[k], "item_id", &dcritemid);
								AOM_ask_value_string(DCR_Tag[k], "t5_DcrCreRC", &Dcr_reason);
								printf("\n DCR ID :%s",dcritemid);fflush(stdout);
								STRNG_replace_str(Dcr_reason,","," ",&Dcr_reason1);
								printf("\n DCR Reason for change :%s",Dcr_reason1);fflush(stdout);
								//if(k==0)
								//{
									fprintf(Report,"%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",dmlcounter,dmlobjid,dmlobjdesc2,dmlrlszstatus,DRstatus,projcode,dmluser,creationdDate,dateRelz,NewRlzType,dcritemid,Dcr_reason1,STDAnalyst);fflush(Report);
								//}
								/* else
								{
									fprintf(Report,"%d,%s,,,,,,,,,%s,%s,\n",dmlcounter,dmlobjid,dcritemid,Dcr_reason1);fflush(Report);
								} */
							}
						}
					}
				}
				if(plantDML)
					MEM_free(plantDML);
			}
		}
		
		if(ERC_DMLTag)
			MEM_free(ERC_DMLTag);
		if(TaskPlant)
			MEM_free(TaskPlant);
		if(STDSUserPlant)
			MEM_free(STDSUserPlant);
	}
	fprintf(Report,"\n ,END,OF REPORT,");fflush(Report);
	fclose(Report);
	if(dmlcounter > 0)
	{
		printf("\n Going to send mail...........\n");
		char*  usermailid =NULL;
		char*  Sampleuser1 =NULL;
		char*  usermailidsample =NULL;
		char*  mailcommand =NULL;
		usermailid = (char*) MEM_alloc(5000);
		Sampleuser1 = (char*) MEM_alloc(500);
		mailcommand = (char*) MEM_alloc(5000);
		char    	*QryEntry[3]	= {"Id" ,"t5_useragency","t5_userlocation"};	
		char		**QryValue= (char **) MEM_alloc(500 * sizeof(char *));
		tag_t querytag = NULLTAG;
		QRY_find("UserFind",&querytag);
		if(querytag!=NULLTAG)
		{
			QryValue[0]="*";
			QryValue[1]="STD";
			QryValue[2]=Plant;
			int UsrCnt = 0;
			int useritr = 0;
			tag_t* User_Tag = NULLTAG;
			tag_t Person_Tag = NULLTAG;
			char *userid[SA_user_size_c+1];	
			char* Person_Name =NULL;
			char* emailID =NULL;
			QRY_execute(querytag,3, QryEntry, QryValue, &UsrCnt, &User_Tag);
			printf("\n\n Number of User Found %d \n\n",UsrCnt);fflush(stdout);
			if(UsrCnt>0)
			{
				for(useritr=0;useritr<UsrCnt;useritr++)
				{
					SA_ask_user_identifier(User_Tag[useritr],userid);  
					SA_ask_user_person_name2(User_Tag[useritr], &Person_Name);
					SA_find_person2 ( Person_Name, &Person_Tag);
					SA_ask_person_email_address ( Person_Tag, &emailID);
					printf("\nUser ID [%s] \t Person Name :[%s] \t Person email ID[%s]\n",userid,Person_Name,emailID); 
					tc_strcat(usermailid,emailID);
					tc_strcat(usermailid," ");
				} 
			}
			else
			{
				tc_strcpy(usermailid,"Tejashree.Javali1@tatamotors.com suhas.chitragar@tatamotors.com vb925028.ttl@tatamotors.com");
				tc_strcat(usermailid," ");
			}
		}
		printf("\n Email Addresses %s \n",usermailid);
		//tc_strcpy(Sampleuser1,"monazirn.ttl@tatamotors.com");
		//,sr922335.ttl@tatamotors.com,nk2.ttl@tatamotors.com,manishk1.ttl@tatamotors.com,sandeepg.ttl@tatamotors.com,monazirn.ttl@tatamotors.com,
		//tc_strcpy(Sampleuser1,"vb925028.ttl@tatamotors.com");
		//tc_strcpy(Sampleuser1,"monazirn.ttl@tatamotors.com");
		//sprintf(mailcommand,"echo -e \"Hello Team,\nThis is System Generated mail,don't reply to this mail. Please find attached Report.\nThanks\nPLM Team\" | Mail -s  \"TCUA-ERC-DCR Daily Report\" -a %s -c `cat CC.txt` %s",filename,Sampleuser1);
		sprintf(mailcommand,"echo -e \"Hello Team,\nThis is System Generated mail,don't reply to this mail. Please find attached Report.\nThanks\nPLM Team\" | Mail -s  \"TCUA-ERC-DCR Daily Report\" -a %s -c `cat CC.txt` %s",filename,usermailid);
		system(mailcommand);
		printf("\n Mail send successful  ..\n");
		if(mailcommand)
			MEM_free(mailcommand);
		if(usermailid)
			MEM_free(usermailid);
	}
	else
	{
		printf("\n ERC- DCR Not found Hence Mail Not Delivered......\n");
	}
	return ITK_ok;
}

