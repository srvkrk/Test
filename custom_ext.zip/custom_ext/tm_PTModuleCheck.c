/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Bhaskar Dimble
*  Module               :   Workflow Rule Handler to check for various module release check for TCE loaded modules
*  Code                 :   tm_PTModuleCheck.c
*  Created on			:   May 7th, 2019
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Rule Handler		:		tm_PTModuleCheck
	Description			:		This handler apply the module release check for TCE loaded modules
*/

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;

// fun To Set String is present array.
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

// fun To Find String is present in array.
void setFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{
		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			printf("\n part present in structure hence is OK \n");
			break;
		}

	}
}

EPM_decision_t tm_PTModuleCheck(EPM_rule_message_t msg)
{
  int	count,i,j,r,k,t,l,k1;
  int	p1,m1,g,b1				= 0;
  int 	sequence_id				= 0;
  int	m,n						= 0;
  int	Itemscnt				= 0;
  int	jd,hp					= 0;
  int   n_attchs,partcnt		= 0;
  int   n_instances				= 0;
  int	*instance_levels		= 0;
  int	*instance_where_found	= 0;
  int   n_classes				= 0;
  int   *class_levels			= 0;
  int   *class_where_found		= 0;
  int	n_entries				= 1;
  int	n_Chkentries			= 2;
  int	resultCount				= 0;
  int	attachmentCount			= 0;
  int	ChkCount				= 0;
  int  ifail					= 0;
  int  n_parents,n1_parents		= 0;
  int  cnt						= 0;
  int  cntFlag					= 0;
  int  *levels					= 0;
  int  status					= ITK_ok;
  int  iNo_entry				= 1;
  int  iRsltCount				= 0;
  int  atchprt					= 0;
  int  ParentPrtAttachFlg		= 0;
  int  SignOffErrCunt			= 0;
  int  Prnt						= 0;
  int Nflag						= 0;
  int countDep,countDep1		= 0;
  int countConfigCtx			= 0;
  int countCtx					= 0;
  int PartNoStrucCnt			= 0;
  int PartStrNoParentCnt		= 0;
  int Incmptcnt					= 0;
  int cmptlecnt					= 0;
  int flagmdl					= 0;
  int DupVarFr					= 0;
  int Dflag						= 0;

  char  *Context_Str			= NULL;
  char *class_nameCtx			= NULL;
  char*	DMLNo					= NULL;
  char *ItemPType				= NULL;
  char *ItemName1				= NULL;
  char *HangingPrtErr			= NULL;
  char *ColIndYPrt				= NULL;
  char *SetHangingPrtErr		= NULL;
  char PartStrNoStruc[1500];
  char PartStrNoParent[1500];
  char MudleInCmpt[1500];
  char MudleCmpt[1500];
  char MudleDupcpy[1500];
  char  *sAtchPrt				= NULL;
  char	*sPrntNo				= NULL;
  char	*sInfo4					= NULL;
  char*  type_name3=NULL;
  char  *sQry_entry[1]  = {"SYSCD"};
  char  **sQry_value     =  (char **) MEM_alloc(10 * sizeof(char *));
  char* NoDrawingListD			= NULL;
  char* DrawingListN			= NULL;
  char* DMLnom					= NULL;
  char	*s						= NULL;
  char	*user_name				= NULL;
  char	*class_name				= NULL;
  char	*class_name1			= NULL;
  char	*proj_value				= NULL;
  char*	 object_type			= NULL;
  char*	 Object_PartType		= NULL;
  char*	 t5current_name			= NULL;
  char*	 t5current_name1		= NULL;
  char*	 DMLtype				= NULL;
  char*	 Part_no				= NULL;
  char*	 ReChkPart_no			= NULL;
  char*	 Arch_obj				= NULL;
  char*	 Arch_obj_str			= NULL;
  char*	 SmVCContext			= NULL;
  char*	 SmCrIDContext			= NULL;
  char*	 ContextobjName			= NULL;
  char*	 CtxtrimobjName			= NULL;
  char*	 TargetThread			= NULL;
  char*	 ReleaseStatus			= NULL;
  char*	 current_name			= NULL;
  char*	 projectname			= NULL;
  char *child_item_id			= NULL;
  char *StrChk_item_id			= NULL;
  char *child_bl_formula		= NULL;
  char *Strchk_bl_formula		= NULL;
  char *Trim_bl_formula			= NULL;
  char *revisionID				= NULL;
  char *t5Des_Rev				= NULL;
  char *t5rlz_list				= NULL;
  char *taskGrp					= NULL;
  char *curentname				= NULL;
  char*	username				= NULL;
  char *qry_entries[1] = {"ID"};
  //char *qry_entriesChk[1] = {"Name"};
  char *qry_entriesChk[2] = {"Name","Type"};
  char*  type_name=NULL;
  char*  type_name4=NULL;
  char*  Config_CtxType=NULL;
  char*  Archtype_name=NULL;
  char*  Ctxtype_name=NULL;
  char  objecttype[WSO_name_size_c+1];
  char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
  char **values = (char **) MEM_alloc(1 * sizeof(char *));
  char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
  char **qry_valuesChk = (char **) MEM_alloc(10 * sizeof(char *));
  tag_t relation_type			= NULLTAG;
  tag_t tsk_dml_rel_type		= NULLTAG;
  tag_t *attachments			= NULLTAG;
  tag_t *DMLRevision			= NULLTAG;
  tag_t  *secondary_objects		= NULLTAG;
  tag_t login_user_tag			= NULLTAG;
  tag_t owner_tag				= NULLTAG;
  tag_t class_id				= NULLTAG;
  tag_t class_id1				= NULLTAG;
  tag_t attchments1				= NULLTAG;
  tag_t root_task				= NULLTAG;
  tag_t *rev_tag				= NULLTAG;
  tag_t bom_window				= NULLTAG;
  tag_t master					= NULLTAG;
  tag_t  *children1				= NULLTAG;
  tag_t  *bomchild				= NULLTAG;
  tag_t  *children				= NULLTAG;

  tag_t *PartsTag				= NULLTAG;
  tag_t AssyTag					= NULLTAG;
  tag_t ArchAssyTag				= NULLTAG;
  tag_t CtxAssyTag				= NULLTAG;
  tag_t objTypeTag				= NULLTAG;
  tag_t ArchobjTypeTag			= NULLTAG;
  tag_t ctxobjTypeTag			= NULLTAG;
  tag_t relation_dep			= NULLTAG;
  tag_t relation_Ctx			= NULLTAG;
  tag_t Childobject				= NULLTAG;
  tag_t bomChildobject			= NULLTAG;
  tag_t StrChkArchObj			= NULLTAG;
  tag_t Desobject				= NULLTAG;
  tag_t ref_instancesTemp		= NULLTAG;
  tag_t window,rule = null_tag,top_line,top_line1,bom_rule,bomtop_line;
  tag_t DMLLcmTag				= NULLTAG;
  tag_t DMLRevTag				= NULLTAG;
  tag_t objTypeTagDi1			= NULLTAG;
  tag_t ConfigCtxObjTypeTag		= NULLTAG;
  tag_t *ref_instances			= NULLTAG;
  tag_t *ref_classes			= NULLTAG;
  tag_t	queryTag				= NULLTAG;
  tag_t rootTask_t				= NULLTAG;
  tag_t	queryChkTag				= NULLTAG;
  tag_t *rev					= NULLTAG;
  tag_t *Chkrev					= NULLTAG;
  tag_t  *secondary_objects1	= NULLTAG;
  tag_t  *ConfigCtxSecObject	= NULLTAG;
  tag_t  *secondary_objects2	= NULLTAG;
  tag_t  *CtxSecObject			= NULLTAG;
  tag_t  primary				= NULLTAG;
  tag_t  primary1				= NULLTAG;
  tag_t  ConfigCtx				= NULLTAG;
  tag_t  objTypeTagDi			= NULLTAG;
  tag_t tAttchPartTag			= NULLTAG;
  tag_t tPrntTag				= NULLTAG;
  tag_t Optfmly_tag				= NULLTAG;
  tag_t	secObjTag				= NULLTAG;
  tag_t *CntrlObjtTag			= NULLTAG;
  tag_t	secObjTypeTag			= NULLTAG;
  tag_t tQryTag					= NULLTAG;
  tag_t *parents				= NULLTAG;
  tag_t *parents1				= NULLTAG;
  tag_t  *taskAttachments		= NULLTAG;
  ItemPType = NULL;
  ItemName1 = NULL;
  logical is_latest;


    //ref_instancesTemp = malloc( sizeof(1) );
    EPM_decision_t decision = EPM_go;
    char* type_name2 = NULL;
	printf("\n tm_PTModuleCheck Function started...");fflush(stdout);
	TC_write_syslog("\n tm_PTModuleCheck Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
    //ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		//ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		//printf("Object Type = %s\n",obj_type);fflush(stdout);
        secObjTag=taskAttachments[Itemscnt];
		if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
		if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
		if(tc_strcasecmp(type_name2,"Design Revision")==0)
		{
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
			//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));
			ITK_CALL(AOM_ask_value_string(secObjTag,"item_id",&Part_no));
			printf("\n tm_PTModuleCheck: Part_no  is :%s\n",Part_no);	fflush(stdout);

			ITK_CALL(PS_where_used_all(taskAttachments[Itemscnt],1,&n_parents,&levels,&parents));
			printf("\n\t tm_PTModuleCheck: CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1

			if(n_parents>0)
			{
				for (jd=0;jd<n_parents;jd++ )
				  {
						ArchAssyTag=parents[jd];
						CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));    //003915
						printf("\n\ttm_PTModuleCheck:: Architecture Object is :%s",Arch_obj);	fflush(stdout);

						if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
						if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
						printf("\n\ttm_PTModuleCheck:: Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

						if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
						{
						  printf("\n\ttm_PTModuleCheck:: Inside T5_ArchModuleRevision........");fflush(stdout);
						  if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
						  if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
						  if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
						  if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
						  if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

							  if(top_line!=NULLTAG)
							  {
								if(BOM_line_ask_child_lines (top_line, &n, &children1));
								printf("\n\ttm_PTModuleCheck:: No of child objects are n : %d",n);fflush(stdout);

									if (n >0)
									{
										  for (p1=0;p1<n ;p1++ )
										  {
												if(Childobject) Childobject=NULLTAG;
												Childobject=children1[p1];
												CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
												printf("\n\ttm_PTModuleCheck:: Design Object ===> :: %s",child_item_id); fflush(stdout);

												if(tc_strcmp(Part_no,child_item_id)==0)
												{
												   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
												   printf("\n\ttm_PTModuleCheck:: child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

													CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
													CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
													printf("\n\ttm_PTModuleCheck:: Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

													CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
													if(relation_dep != NULLTAG)
													{
														printf("\n\t tm_PTModuleCheck::Variant ConfigContext relation found......");	fflush(stdout);
													}

													CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
													printf("\n\ttm_PTModuleCheck: Configuration Context count is : %d",countConfigCtx);

													if(countConfigCtx>0)
													{
														  ConfigCtx=ConfigCtxSecObject[0];
														  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
														  CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
														  printf( "\n\ttm_PTModuleCheck: Config relation Config_CtxType :%s ..",Config_CtxType);

														  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
														  printf("\n\ttm_PTModuleCheck: SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

														  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
														  printf("\n\ttm_PTModuleCheck: SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

														  if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
														  printf("\n\ttm_PTModuleCheck: After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
														  if (queryTag)
														  {
															printf("\n\tFound Query");fflush(stdout);
														  }
														  else
														  {
															printf("\n\tNot Found Query");fflush(stdout);
														  }

														  qry_values[0] = SmCrIDContext;

														  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
														  printf("\n\t tm_PTModuleCheckr: esultCount : %d\n", resultCount); fflush(stdout);


														if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
														{
															printf("\ntm_PTModuleCheck: CC available Variant formula not available \n"); fflush(stdout);
															EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
															decision = EPM_nogo;
															return decision;
														}
														else
														{
															if(resultCount > 0)
															{
															  for (j=0;j<resultCount;j++ )
															  {
																 Optfmly_tag = rev[j];
																 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
																 printf("\n\ttm_PTModuleCheck: ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

																 if(ContextobjName)
																 {
																	printf("\n\ttm_PTModuleCheck: child_bl_formula value:%s",child_bl_formula);
																	printf("\n\ttm_PTModuleCheck: child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(child_bl_formula,ContextobjName)); fflush(stdout);

																	if(tc_strstr(child_bl_formula,ContextobjName)==NULL)
																	{
																		printf("\ntm_PTModuleCheck: inside iff \n"); fflush(stdout);
																		Incmptcnt++;

																		tc_strcat(MudleInCmpt,child_item_id);
																		tc_strcat(MudleInCmpt,",");
																		printf("\n\n\t\t tm_PTModuleCheck:for other parttypes MudleInCmpt : %s = %d\n",MudleInCmpt,Incmptcnt);fflush(stdout);
																	}
																	else
																	 {
																		printf("\n tm_PTModuleCheck: tm_PTModuleCheck: inside else \n"); fflush(stdout);
																		cmptlecnt++;
																	 }
																 }
															  }
															}
														}
													}

													if(cmptlecnt > 0)
													{
														printf("\n\ttm_PTModuleCheck: Main Part => %s with his Complete Variant formula = %s\n",Part_no,child_bl_formula); fflush(stdout);
														if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
														if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();

														if(top_line1!=NULLTAG)
														{
															if(BOM_line_ask_child_lines (top_line1, &n, &children1));
															printf("\n\ttm_PTModuleCheck: No of child objects are n : %d",n);fflush(stdout);

															if (n >0)
															{
																  printf("\n\ttm_PTModuleCheck: No of child are greater than 0 : %d",n);fflush(stdout);
																  for (p1=0;p1<n ;p1++ )
																  {
																	if(StrChkArchObj) StrChkArchObj=NULLTAG;
																	StrChkArchObj=children1[p1];
																	CALLAPI(AOM_ask_value_string(StrChkArchObj, "bl_item_item_id", &StrChk_item_id ));

																		if(tc_strcmp(Part_no,StrChk_item_id)!=0)
																		{
																			printf("\n\ttm_PTModuleCheck: StrChk_item_id Object ===> :: %s",StrChk_item_id); fflush(stdout);
																			CALLAPI(AOM_ask_value_string(StrChkArchObj, "bl_formula", &Strchk_bl_formula ));
																			printf("\n\ttm_PTModuleCheck: Strchk_bl_formula--------------> %s\n",Strchk_bl_formula); fflush(stdout);

																			if(tc_strcmp(child_bl_formula,Strchk_bl_formula)==0)
																			{
																				printf("\ntm_PTModuleCheck: inside cmptlecnt loop \n"); fflush(stdout);
																				DupVarFr++;

																				tc_strcat(MudleDupcpy,StrChk_item_id);
																				tc_strcat(MudleDupcpy,",");
																				printf("\n\n\t\ttm_PTModuleCheck: for other parttypes MudleDupcpy : %s = %d\n",MudleDupcpy,DupVarFr);fflush(stdout);
																			}
																		}
																  }
															}
														}
													}
												}
										  }
									}
							  }
						}
				  }
			}
			else
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Module not attached to any architecture node.");
				decision = EPM_nogo;
				return decision;
			}

			if (DupVarFr>0)
			{
				EMH_clear_errors();
				EMH_store_error_s4(EMH_severity_error,ITK_err, "Same variant formula is already available for Modules ",Part_no, " and ",MudleDupcpy);
				decision = EPM_nogo;
				return decision;
			}

			 if (Incmptcnt>0)
		    {
				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Modules :: ",MudleInCmpt);
				decision = EPM_nogo;
				return decision;
		    }
		}
	}
	//if(AOM_ask_value_string(rev,"object_type",&objecttype));
	printf("\n tm_PTModuleCheck Function end...");fflush(stdout);
	TC_write_syslog("\n tm_PTModuleCheck Function end...");
	return EPM_go;
}

EPM_decision_t ChkPTModule(EPM_rule_message_t msg)
{
	int ifail=0,count=0,n_parents=0;
	int RlzRevFlag				= 0;
	int status_count			= 0;
	int rs						= 0;
	char*  CurrentTask			= NULL;
	char*  t5current_name		= NULL;
	char* type_name2= NULL;
	char*  procedure_name		= NULL;
	char*  Part_no				= NULL;
	char* DMLSubStr				= NULL;
	char *ProObjRelSt			= NULL;

	tag_t *attachments			= NULLTAG;
	tag_t *DMLRevision			= NULLTAG;
	tag_t *parents				= NULLTAG;
	tag_t DMLLcmTag				= NULLTAG;
	tag_t DMLRevTag				= NULLTAG;
	tag_t  root_task			= NULLTAG;
	tag_t* status_list			= NULLTAG;
	tag_t secObjTypeTag			= NULLTAG;

	EPM_decision_t decision = EPM_go;
	logical  t5InProcess;

	printf("\n ChkPTModule Function started...");fflush(stdout);
	TC_write_syslog("\n ChkPTModule Function started...");

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	//printf("\n\n\t\t Root task found for CheckDMLActiveinLCCheckDMLActiveinLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	//printf("\nCurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	//printf("\n\n\t\t EPM_ask_attachments of :: %d",count);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
	}

	if (TCTYPE_ask_object_type(DMLLcmTag,&secObjTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
	if(tc_strcasecmp(type_name2,"Design Revision")==0)
	{
		//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cprojectcode",&dmlProjID));
		//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_cDRstatus",&dmlDRStatus));
		//ITK_CALL(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&dmlRelType));
		ITK_CALL(AOM_ask_value_string(DMLLcmTag,"item_id",&Part_no));
		printf("\n ChkPTModule: Part_no  is :%s\n",Part_no);	fflush(stdout);
		DMLSubStr=NULL;

		DMLSubStr=subString(Part_no, 4, 1);

		if(tc_strlen(Part_no) == 14)

		if(WSOM_ask_release_status_list(DMLLcmTag,&status_count,&status_list)==ITK_ok)
		printf("\nChkPTModule: status_count: %d ", status_count);fflush(stdout);
		RlzRevFlag=0;
		for (rs = 0; rs < status_count; rs++)
		{
			if (AOM_ask_name(status_list[rs], &ProObjRelSt)==ITK_ok)
			printf("\t :%s ", ProObjRelSt);fflush(stdout);
			if (((tc_strcmp(ProObjRelSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ProObjRelSt,"ERC Released")==0)) && (tc_strlen(Part_no) == 14) && (tc_strcmp(DMLSubStr,"P")==0)  )
			{
				RlzRevFlag=1;
				break;
			}
		}
		if (RlzRevFlag==0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, " Only ERC Released PowerTrain Module is allowed to submit into Workflow to update Variant Formula");
			decision = EPM_nogo;
			return decision;
		}
	}
	CALLAPI(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
	printf("\n ChkPTModule: EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);

	CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
	printf("\n ChkPTModule: procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);

	if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "Module already submitted in Lifecycle ... You can not submit it again...");
		decision = EPM_nogo;
		return decision;
	}
	else
	{
		decision = EPM_go;
	}
	printf("\n ChkPTModule Function end...");fflush(stdout);
	TC_write_syslog("\n ChkPTModule Function end...");
	return decision;
}

EPM_decision_t CM_DMLCheckList(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int l					= 0;
	int	n					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVC				= 0;
	int n_parents			= 0;
	int *levels				= 0;
	int n_entries			= 1;
	int n_Chkentries		= 2;
	int resultCount			= 0;
	int ChkCount			= 0;
	int  revid				= 0;
 	int  revseq				= 0;
 	int  revstat			= 0;
 	int  blobjType			= 0;
 	int  modadd				= 0;
 	int  Variantflag		= 0;
 	int  Variantflag1		= 0;
	int	 ifail				= 0;
	//int designer_found=0,manager_found=0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t  DMLObject		= NULLTAG;
	tag_t  objTypeTag		= NULLTAG;
	tag_t  AssyTag			= NULLTAG;
	tag_t  ArchAssyTag		= NULLTAG;
	tag_t  *parents			= NULLTAG;
	tag_t  ArchobjTypeTag	= NULLTAG;
	tag_t  *children1		= NULLTAG;
	tag_t  Childobject		= NULLTAG;
	tag_t  window,rule,item_tag = null_tag,top_line;
	tag_t *rev				= NULLTAG;
	tag_t *Chkrev			= NULLTAG;
    tag_t  queryChkTag		= NULLTAG;
	tag_t user_tag			= NULLTAG;
	tag_t *list				= NULLTAG;
	tag_t top_bom_line		= NULLTAG;
	char *objecttype		= NULL;
	char *objectId			= NULL;
	char *objectdesc		= NULL;
	char *objectrelstatus	= NULL;
	char *DMLNo				= NULL;
	char *Part_type			= NULL;
	char *current_name		= NULL;
	char *value				= NULL;
	char *Arch_obj			= NULL;
	char *child_bl_formula	= NULL;
	char *child_rev_id		= NULL;
 	char *child_rev_seq		= NULL;
	char *child_rev_stat	= NULL;
	char *child_objType		= NULL;
	//char *mod_addr			= NULL;
	//char *username;
	//char *userid;
	//char *designer_role		= NULL;
	//char *manager_role		= NULL;
	char*  ObjTyp=NULL;
	char*  type_name=NULL;
	char*  Archtype_name=NULL;
	char* child_bl_formula_cmp = NULL;
	char *qry_entries[1]	= {"ID"};
	//char *qry_entriesChk[1] = {"Name"};
	char *qry_entriesChk[2] = {"Name","Type"};
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	char **qry_valuesChk = (char **) MEM_alloc(100 * sizeof(char *));

	EPM_decision_t decision = EPM_go;

	printf("\n CM_DMLCheckList Function started...");fflush(stdout);
	TC_write_syslog("\n CM_DMLCheckList Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\nCM_DMLCheckList: No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n*******CM_DMLCheckList: INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				  CALLAPI(AOM_ask_value_string(taskAttachments[i],"current_name",&current_name));
			      printf("\n\n\t\tCM_DMLCheckList: current_name is :%s\n",current_name);fflush(stdout);

				  DMLNo=subString(current_name,0,10);
				  printf("\n\n\t\tCM_DMLCheckList: DML Number:-------> %s\n", DMLNo); fflush(stdout);

				  if(QRY_find2("GetChkLst", &queryChkTag));
				  printf("\n\n\t\tCM_DMLCheckList: After GetChkLst QRY_find2------------>");fflush(stdout);
				  if (queryChkTag)
				  {
					printf("\n\n\t\tCM_DMLCheckList:Found Query-------->");fflush(stdout);
				  }
				  else
				  {
					printf("\n\n\t\tCM_DMLCheckList: Not Found Query---->");fflush(stdout);
				  }

				  trimLeading(DMLNo);
				  qry_valuesChk[0] = DMLNo;
				  qry_valuesChk[1] = "ERC DML Checklist";
				  if(QRY_execute(queryChkTag, n_Chkentries, qry_entriesChk, qry_valuesChk, &ChkCount, &Chkrev));
				  printf("\n\n\t\tCM_DMLCheckList: ChkCount:-------> %d\n", ChkCount); fflush(stdout);

				  if(ChkCount==0)
				  {
					  EMH_clear_errors();
					  EMH_store_error_s3(EMH_severity_warning,ITK_err, "Please Create Checklist for DML=> ",DMLNo,"\nHelp: Select DML goto File->New->Change Classes->ERC DML CheckList");
					  decision = EPM_nogo;
					  return decision;
				  }

			}
		}
	}
	printf("\n CM_DMLCheckList Function end...");fflush(stdout);
	TC_write_syslog("\n CM_DMLCheckList Function end...");
	return decision;
}

EPM_decision_t CM_IncompleteVC(EPM_rule_message_t msg)
{
	int stat = ITK_ok;
	int ifail = 0;
	int cnt = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int p36 = 0;
	int structcount = 0;
	int structcount1 = 0;
	int cnt12 = 0;
	int ju = 0;
	int n_lines1 = 0;
	int n_lines2 = 0;
	int n_lines = 0;
	int errorflag34 = 0;
	int n_lines3 = 0;
	int p1 = 0;
	int a = 0;
	int b = 0;
	int noAttachment = 0;
	int n_bom_views1 = 0;
	int n_bom_views = 0;
	int resultCount = 0;
	int countConfigCtx = 0;
	int n_entries = 1;
	int rulefound = 0;
	int Childstrcnt = 0;
	int flag = 0;
	int flagok = 0;
	int flagerr = 0;
	int RetflagOK = 0;
	int Intcount = 0;
	int VNo_entry = 1;
	int STDaloneWayFlag = 0;
	int VRsltCount = 0;

	char *test1 = (char*)MEM_alloc(sizeof(char) * 3000);
	char* relation_name=NULL;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **PartNumberSet = (char **) MEM_alloc(1 * sizeof(char *));
	char *qry_entries[1] = {"ID"};
	char RevMisMatch[900];
	char AllOptions[700];
	char AllOptionValues[700];
	char *child_item_id1 = NULL;
	char *objecttype = NULL;
	char *objectname = NULL;
	char *objecttypeveh = NULL;
	char *objectnameveh = NULL;
	char *TempVal = NULL;
	char *Item_ID_str = NULL;
	char* Config_CtxType=NULL;
	char* SmVCContext = NULL;
	char* SmCrIDContext = NULL;
	char *child_item_id = NULL;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char* ContextobjName = NULL;
	char PartNum[300];
	char *Varruletxt = NULL;
	char *sVInfo1 = NULL;
	char *sep = ",";

	tag_t DMLTag = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t Desrev = NULLTAG;
	tag_t primary1 = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t top_line1 = NULLTAG;
	tag_t Childobject = NULLTAG;
	tag_t bom_window = NULLTAG;
	tag_t bom_window1 = NULLTAG;
	tag_t *lines1 = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *attachments1	= NULLTAG;
	tag_t *attachments12 = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t DmlItemsRelation_t = NULLTAG;
	tag_t rev = NULLTAG;
	tag_t view_type = NULLTAG;
	tag_t *bom_views = NULLTAG;
	tag_t *bom_views1 = NULLTAG;
	tag_t *OptionValue = NULLTAG;
	tag_t *option_revs = NULLTAG;
	tag_t *VCntrlObjtTag = NULLTAG;
	tag_t item = NULLTAG;
	tag_t *ConfigCtxSecObject = NULLTAG;
	tag_t ConfigCtx = NULLTAG;
	tag_t ConfigCtxObjTypeTag = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t *lines2 = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t bom_view = NULLTAG;
	tag_t bom_view1 = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t relation_dep = NULLTAG;
	tag_t   VQryTag     = NULLTAG;

	char    *VQry_entry[1]  = {"SYSCD"};
	char    **VQry_value     =  (char **) MEM_alloc(100 * sizeof(char *));

	EPM_decision_t decision = EPM_go;

	TempVal=(char *) MEM_alloc(1000);

	//for comparing and making not Matching list
	printf("\n CM_IncompleteVC Function started...");fflush(stdout);
	TC_write_syslog("\n CM_IncompleteVC Function started...");

	tc_strcpy(test1,"");

	//end here
	struct modstruct
	{
		//part details
		char parent_part[100];
		int child;
	} childstr[10000];

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n CM_IncompleteVC: erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("CM_IncompleteVC: Target Attachment:%d\n",noAttachment);fflush(stdout);

	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		printf("CM_IncompleteVC: Target Attachment found greater than zero:%d\n",noAttachment);fflush(stdout);
	}
	
	if(QRY_find2("ControlObjects", &VQryTag));
	if (VQryTag)
	{
		printf("\n Found Qry PTModule ControlObjects.. \n");fflush(stdout);
	}
	else
	{
		printf("\n Not Found Qry PTModule ControlObjects.. \n");fflush(stdout);
	}

	VQry_value[0] = "PTModule";
	if(QRY_execute(VQryTag, VNo_entry, VQry_entry, VQry_value, &VRsltCount, &VCntrlObjtTag));
	printf(" \n PTModule:VRsltCount.:[%d]", VRsltCount); fflush(stdout);
	if(VRsltCount > 0)
	{
		CALLAPI(AOM_ask_value_string(VCntrlObjtTag[0],"t5_Userinfo1",&sVInfo1));
		printf(" sVInfo1.: [%s]\n", sVInfo1);fflush(stdout);
	}
	if(tc_strstr(sVInfo1,"PT001") == NULL)
	{
		CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		printf("CM_IncompleteVC: DmlItemsRelation_t fouund:\n");fflush(stdout);

		if(relation_type != NULLTAG)
		{
			printf("\n CM_IncompleteVC: relation_type found \n");fflush(stdout);
			CALLAPI(TCTYPE_ask_name2( relation_type,&relation_name));
			printf("\n CM_IncompleteVC: Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
			printf("\n CM_IncompleteVC: Checkin- impacted items:%d\n",cnt);fflush(stdout);
			if(tc_strstr(sVInfo1,"PT002") != NULL)
			{
				printf("CM_IncompleteVC: Direct pass..:\n");fflush(stdout);
				decision = EPM_go;
				return decision;
			}
			if(tc_strstr(sVInfo1,"PT003") == NULL)
			{
				if (cnt ==0)
				{
					STDaloneWayFlag=1;
				}
			}
			printf("\n CM_IncompleteVC:STDaloneWayFlag:%d \n",STDaloneWayFlag);fflush(stdout);

			for(i=0;i<cnt;i++)
			{
				printf("\n CM_IncompleteVC: to find impacted items[i]\n");fflush(stdout);
				rev1 = attachments1[i];
				if(AOM_ask_value_string(rev1,"object_type",&objecttype));
				if(AOM_ask_value_string(rev1,"object_name",&objectname));

				if (strcmp(objecttype,"VariantRule")==0)
				{
					strcpy(TempVal,objectname);
					primary1=rev1;
					if(AOM_ask_value_string(rev1,"cfg0VariantRuleText",&Varruletxt));
					printf("\n CM_IncompleteVC: Variant rule text is :%s\n",Varruletxt);fflush(stdout);
				}
			}

			for(j=0;j<cnt;j++)
			{
			  printf("\n CM_IncompleteVC: to find impacted items [j]\n");fflush(stdout);
			  rev = attachments1[j];
			  if(AOM_ask_value_string(rev,"object_type",&objecttype));
			  if(AOM_ask_value_string(rev,"object_name",&objectname));

				if (strcmp(objecttype,"T5_PlatformRevision")==0)
				{
					printf( "\n CM_IncompleteVC :INside platform\n"); fflush(stdout);

					if ( rev !=NULLTAG )
					{
						CALLAPI ( PS_find_view_type( "view", &view_type ));
						printf("\n CM_IncompleteVC: PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
							printf("\nCM_IncompleteVC: View found \n"); fflush(stdout);
							CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
							CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							bom_view = bom_views[0];
						}
						else
						{
							printf("\nCM_IncompleteVC: View not found check.......\n"); fflush(stdout);
						}
					}

					if ( bom_view != NULLTAG )
					{
						printf("CM_IncompleteVC: before BOM_create_window..\n");	fflush(stdout);
						CALLAPI ( BOM_create_window( &bom_window ));
						CALLAPI(CFM_find( "ERC release and above", &rule ))
						//CALLAPI(CFM_find( "Latest Working", &rule ))
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
						CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

						printf ("CM_IncompleteVC: rule count %d \n",rulefound);fflush(stdout);
						if (rulefound > 0)
						{
							close_tag = closurerule[0];
							printf ("CM_IncompleteVC: closure rule found \n");fflush(stdout);
							// MEM_free(tags_found);
						}

						CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
						printf ("CM_IncompleteVC: After closure rule set  \n");fflush(stdout);
						CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
						printf ("CM_IncompleteVC: After Set window to line\n");fflush(stdout);
						CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
						printf ("CM_IncompleteVC: After BOM Back");fflush(stdout);

						if(top_line!=NULLTAG)
						{
							printf ("\nCM_IncompleteVC: top_line Tag found");fflush(stdout);
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));	 // Platform Expansion
							printf("\n CM_IncompleteVC: Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);
							CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
							CALLAPI(BOM_window_show_variants(bom_window))   ;
							//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
							//if(BOM_variant_config_apply (bom_variant_config))   ;

							//if(BOM_variant_rule_apply(primary1))   ;
							printf("\n CM_IncompleteVC: After inside bom_window-----\n"); fflush(stdout);
							CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&primary1))   ;
							printf("\n CM_IncompleteVC: After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

							//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
							CALLAPI(BOM_window_hide_variants(bom_window))   ;

							if (n_lines >0)
							{
								printf("CM_IncompleteVC: n_lines greater than zero\n");fflush(stdout);
								for (a=0 ;a < n_lines ;a++ )
								{
									printf("CM_IncompleteVC: n_lines a [%d]\n",a+1);fflush(stdout);
									CALLAPI(BOM_line_ask_child_lines(lines[a], &n_lines3, &lines1)); //arch_Node Expansion

									if (n_lines3 >0)
									{
										printf("CM_IncompleteVC: n_lines3>0: [%d]\n",n_lines3);fflush(stdout);
										structcount=0;
										for (b=0;b<n_lines3 ;b++ )
										{
											structcount++;
											if(Childobject) Childobject=NULLTAG;
											Childobject=lines1[b];

											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("CM_IncompleteVC: structcount: [%d]  child_item_id ..:[%s] ",structcount,child_item_id);fflush(stdout);
											setAddStr(&Intcount,&PartNumberSet,child_item_id);
										}
									}
								}
							}
						}
						else
						{
							printf ("\nCM_IncompleteVC: top_line Tag Not found ");fflush(stdout);
						}
					}
				}
			}
		}

		if(STDaloneWayFlag ==0)
		{
			if(DmlItemsRelation_t != NULLTAG)
			{
				printf("\n CM_IncompleteVC: inside DmlItemsRelation_t not NULL loop \n");fflush(stdout);

				CALLAPI(GRM_list_secondary_objects_only(DMLTag,DmlItemsRelation_t,&cnt12,&attachments12));
				printf("\n CM_IncompleteVC: Checkin- impacted items:%d\n",cnt12);fflush(stdout);
		
				if (cnt12 == 1)
				{
					for(k=0;k<cnt12;k++)
					{
						printf("\n CM_IncompleteVC: to find impacted items[k]\n");fflush(stdout);
						Desrev = attachments12[k];
						if(AOM_ask_value_string(Desrev,"object_type",&objecttypeveh));
						if(AOM_ask_value_string(Desrev,"object_name",&objectnameveh));

						 if (strcmp(objecttypeveh,"Design Revision")==0)
						{
							 CALLAPI ( PS_find_view_type( "view", &view_type ));
							printf("\nCM_IncompleteVC: PS_find_view_type is found......\n" ); fflush(stdout);

							if ( view_type != NULLTAG )
							{
								CALLAPI ( ITEM_ask_item_of_rev( Desrev, &item ));
								CALLAPI ( ITEM_list_bom_views( item, &n_bom_views1, &bom_views1 ));

								bom_view1 = bom_views1[0];

								if ( bom_view1 != NULLTAG )
								{
									printf(" CM_IncompleteVC: before BOM_create_window2..\n");	fflush(stdout);
									CALLAPI ( BOM_create_window( &bom_window1 ));
									CALLAPI(CFM_find( "ERC release and above", &rule1 ))
									//CALLAPI(CFM_find( "Latest Working", &rule ))
									CALLAPI(BOM_set_window_config_rule( bom_window1, rule1 ));

									CALLAPI(BOM_set_window_pack_all(bom_window1, FALSE));
									CALLAPI ( BOM_set_window_top_line( bom_window1, NULLTAG, Desrev, NULLTAG, &top_line1 ));
									printf( " CM_IncompleteVCA: after BOM_set_window_top_line..\n");fflush(stdout);

									if(top_line1!=NULLTAG)
									{
										CALLAPI(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines3));
										//printf("\n Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);
											printf(  "CM_IncompleteVC: Desrev child_item_no ..:%d\n",n_lines1);fflush(stdout);
										if (n_lines1 >0)
										{
											flagok  =0;
											flagerr =0;
											for (p1=0;p1<n_lines1 ;p1++ )
											{
												if(Childobject) Childobject=NULLTAG;
												Childobject=lines3[p1];
												CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id1 ));
												printf("\n CM_IncompleteVC: child_item_id1 under VC is ......: %s\n",child_item_id1);

												//setFindStr(Set,IntofSet,CheckStr,&RetflagOK);
												setFindStr(PartNumberSet,Intcount,child_item_id1,&RetflagOK);
												printf("\n CM_IncompleteVC: RetflagOK is :::::::: [ %d ]",RetflagOK);

												if (RetflagOK == 1)
												{
													printf("\nCM_IncompleteVC: part [ %s ] present in Set of String", child_item_id1);fflush(stdout);
												}
												else if (RetflagOK == 0)
												{
													tc_strcat(test1,child_item_id1);
													tc_strcat(test1,sep);
													flagerr++;
												}
											}
										}
										printf("\nCM_IncompleteVC: Cat string is ::>> %s\n",test1);fflush(stdout);
										if (flagerr > 0)
										{
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_warning,ITK_err, "Structure parts not matching please refer not matching parts :-",test1);
											tc_strcpy(test1,"");
											printf("\nCM_IncompleteVC: B.test1 null.\n"); fflush(stdout);
											decision = EPM_nogo;
											return decision;
										}

									}
								}
							}
							else
							{
								printf("\nCM_IncompleteVC: View not found check.......\n"); fflush(stdout);
							}
						}
					}
				}
			}
		}
	}

	printf("\n CM_IncompleteVC Function end...");fflush(stdout);
	TC_write_syslog("\n CM_IncompleteVC Function end...");

	return decision;
}
