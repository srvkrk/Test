/*
preference	AutoSOR_CC_path		uadev path	/home/uadev/devgroups/dbk/PPPMProjectCodes_list
preference	AutoSOR_CC_path		cmitest path	
preference	AutoSOR_CC_path		uaprodtrl path	
preference	SOR_PPPMPrjCode		ON/OFF
*/
#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/grm_msg.h>
//#include <sys/time.h>
#include <time.h>
//#include "soapH.h"
//#include "pronextSOAP.nsmap"

#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PLM_error (EMH_USER_error_base + 325)

//------------------------------------------------------------
#define NO_OF_PPPM_PROJECT 100
#define PPPM_PROJECT_NAME_DESC 2

//struct PPPM_ProjectInfo
//{
//        char PPPM_PROJECT_CODE[80];
//        char PROJECT_DESCSCRIPTION[80];
//}
//sProjectInfo;
//
//struct ProjectVariant
//{
//        char TOTAL_VOLUME[80];
//        char VARIANT_ID[80];
//        char LOCATION[20];
//        char VARIANT_NAME[20];
//}
//sProjectVariant;
//
//struct ProjectBase
//{
//        char PPPM_PROJECT_CODE[80];
//        char PROJECT_DESCSCRIPTION[80];
//        char MANUF_LOC[20];
//        char PRONEXT_PROJ_SRL[20];
//        char BUSINESS_UNIT[20];
//        char PROJ_CODE[20];
//        struct ProjectVariant PrjVariant[50];
//}
//sProjectBase;

//------------------------------------------------------------


int AutoSorPPPMAskLOVValuesMethod( METHOD_message_t *msg, va_list  args );

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

//check session project and sor project are matching then only allow to save object
char* time_stamp()
{

	char *timestamp = (char *)malloc(sizeof(char) * 30);
	time_t ltime;
	ltime=time(NULL);
	struct tm *tm_now;
	tm_now=localtime(&ltime);
	sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now->tm_year+1900, tm_now->tm_mon, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	//sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now.tm_year+1900, tm_now.tm_mon, tm_now.tm_mday, tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
	return timestamp;
}

void checkHostName(int hostname)
{
    if (hostname == -1)
    {
        perror("gethostname");
        exit(1);
    }
}

// Returns host information corresponding to host name
void checkHostEntry(struct hostent * hostentry)
{
    if (hostentry == NULL)
    {
        perror("gethostbyname");
        exit(1);
    }
}

// Converts space-delimited IPv4 addresses
// to dotted-decimal format
void checkIPbuffer(char *IPbuffer)
{
    if (NULL == IPbuffer)
    {
        perror("inet_ntoa");
        exit(1);
    }
}

// Driver code
int host_tcua(char hostbuffer1[256])
{
    char hostbuffer[256];
    char *IPbuffer;
    struct hostent *host_entry;
    int hostname;

    // To retrieve hostname
    hostname = gethostname(hostbuffer, sizeof(hostbuffer));
    checkHostName(hostname);

    // To retrieve host information
    host_entry = gethostbyname(hostbuffer);
    checkHostEntry(host_entry);

    // To convert an Internet network
    // address into ASCII string
    IPbuffer = inet_ntoa(*((struct in_addr*)
                           host_entry->h_addr_list[0]));

	tc_strcpy(hostbuffer1,hostbuffer);
    printf("Hostname: %s\n", hostbuffer);
    printf("Hostname: %s\n", hostbuffer1);
    printf("Host IP: %s", IPbuffer);

    return 0;
}
//check object in control table
int tm_check_info_control_object ( char *syscd, char *subsyscd, char *info1, char *info2 )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	char *l_info1 = NULL ;
	char *l_info2 = NULL ;

	ITK_CALL ( QRY_find ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
		tc_strcpy( info1, l_info1 );
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
		tc_strcpy( info2, l_info2 );

		TC_write_syslog ( "\ninfo1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	}

	return n_found ;
}

int AutoSor_PPPM_proj_LOV_Method( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag = va_arg(args, const tag_t);
	int* n_values = va_arg(args, int*);
	char ***values = va_arg(args, char***);
	int error_code = ITK_ok;
	int n_found_SOR_LOV = 0 ;
	int n_found = 0;

	char *val1 = NULL ;
	char *AllProjectStr = NULL ;
	char *pppmcode3 = NULL ;
	int iPrjCounter = 0 ;
	int jc = 0 ;
	//struct PPPM_ProjectInfo mysProjectInfo [100] ;

	char **project_details = NULL;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	int  ii = 0;
	char *ProjectCode = NULL;
	char line[250] = { 0 };
	int count = 0 ;
	int ij = 0;
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	//char const *fileName = "/tmp/a.txt";
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *pppm_cmd_to_execute = NULL;
	char *command = NULL;
	//char command[512];
	FILE* file = NULL ;
	char *sAutoSOR_CC_path = NULL;
	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *pppm_file_path = NULL;
	char *shell_path = NULL;
	char hostbuffer[256];

	host_tcua(hostbuffer);

	printf ( "\nhostbuffer : %s",hostbuffer );

	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	
	
	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
		return 0;
	}


	n_found_SOR_LOV = tm_check_control_object ( "SORLOVBYPASS", "LOVBYPASSALLOW" );//webservice call handling
	if ( n_found_SOR_LOV > 0 )
	{
		n_found = 1;
		*n_values = 1;
		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));
		for ( ii = 0; ii < n_found; ii++ )
		{
			(*values)[ii] = (char *) MEM_alloc ( 128 );
			strcpy((*values)[ii], "M-L95.3-CAD.698-SIGNA REFRESH");
		}
	}
	else//call client code
	{
		ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
		//printf ( "\nsAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
		//TC_write_syslog ( "\nsAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;

		ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
		ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
        printf ("\nLogged in user: [%s] [%s]",userid,username);fflush(stdout);
        TC_write_syslog ("\nLogged in user: [%s] [%s]",userid,username);fflush(stdout);

		ITK_CALL ( SA_ask_current_project ( &Currproj ) );
		if ( Currproj != NULLTAG )
		{
			ITK_CALL ( AOM_ask_value_string(Currproj,"object_name",&curr_proj_name) );
		}
		printf ("\ncurr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;
		TC_write_syslog ("\ncurr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;

        n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

		if ( n_found_SOR_PF_info < 0 )
	    {
	    	TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
	    	return 0;
	    }

        n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

		if ( n_found_SOR_PF_info1 < 0 )
	    {
	    	TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
	    	return 0;
	    }
		
		timestamp = time_stamp ( ) ;
		sprintf( fileName, "/%s/pppm_%s_%s_%s.txt",pppm_file_path, userid,curr_proj_name,timestamp );
		printf ( "\nfileName : [%s]", fileName ); fflush ( stdout) ;
		TC_write_syslog ( "\nfileName : [%s]", fileName );
		command = ( char * ) MEM_alloc ( 1000 * sizeof ( char ) ) ;
		//sprintf ( pppm_cmd_to_execute, "/home/uadev/devgroups/dbk/PPPMProjectCodes_list/PPPMProjectCodes_list -d=%s -f=%s", curr_proj_name, fileName ) ;
		sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"",shell_path, curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
		system( command );

		printf ( "\ncmd_to_execute : [%s]", command ); fflush ( stdout) ;
		TC_write_syslog ( "\ncmd_to_execute : [%s]", command );

		file = fopen(fileName, "r");
	
		if ( !file )
		{
			printf("\nUnable to open 1 : [%s] ", fileName);fflush ( stdout ) ;
			TC_write_syslog("\nUnable to open 1 : [%s] ", fileName);fflush ( stdout ) ;
			return -1;
		}

		project_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			project_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( project_details[ij], line ) ;
			printf("\nproject_details[ij] : [%s] tc_strlen(project_details[ij]) : [%d]", project_details[ij],tc_strlen(project_details[ij])); fflush ( stdout ) ;
			TC_write_syslog("\nproject_details[ij] : [%s] tc_strlen(project_details[ij]) : [%d]", project_details[ij],tc_strlen(project_details[ij])); fflush ( stdout ) ;
			ij = ij + 1;
		}
		fclose ( file ) ;
		*n_values = ij;
		*values = (char **)MEM_alloc (ij * sizeof(char*));
		for ( ii = 0; ii < ij; ii++ )
		{
			(*values)[ii] = (char *) MEM_alloc ( 200 );
			tc_strcpy((*values)[ii], project_details[ii]);
			printf("\n*values)[%d] : [%s]",ii,(*values)[ii]);fflush ( stdout ) ;
			TC_write_syslog("\n*values)[%d] : [%s]",ii,(*values)[ii]);fflush ( stdout ) ;
		}
		printf("\nAutoSor_PPPM_proj_LOV_Method : Project Name Desc details END code\n\n\n" ) ; fflush ( stdout) ;
		TC_write_syslog("\nAutoSor_PPPM_proj_LOV_Method : Project Name Desc details END code\n\n\n" ) ;
	}

	return error_code;
}


int tm_get_pppm_variant ( tag_t objTag, char *dml_project_code, char *sor_t5_PPPMPrjCode_desc)
{
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *var_cmd_to_execute = NULL;
	char *command = NULL;
	//char command[512];
	FILE* file = NULL ;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	char **variant_details = NULL;
	char **variant_details_read = NULL;
	int ij = 0;
	char line[250] = { 0 };
	char *sor_t5_PPPMPrjCode = NULL;
	int iIndex = 0;

	char *s_srl_no = NULL;
	char *s_volume_inf = NULL;
	char *s_var_id = NULL;
	char *s_location = NULL;
	char *s_var_name = NULL;

	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_SORVar";
	int num_rows_to_append = 0;
	char *sAutoSOR_CC_path = NULL;
	char hostbuffer[256];

	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *shell_path = NULL;
	char *pppm_file_path = NULL;

	host_tcua(hostbuffer);

	printf ( "\nhostbuffer : %s",hostbuffer );

	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	
	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
		return 0;
	}

	printf ( "\nhostbuffer : %s",hostbuffer );

	TC_write_syslog ("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc before : [%s]",sor_t5_PPPMPrjCode_desc);


	if ( tc_strcmp ( sor_t5_PPPMPrjCode_desc, "" ) == 0 )
	{
		printf ( "\ntm_get_pppm_variant: sor_t5_PPPMPrjCode_desc is null select from drop down" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc is null select from drop down" ) ;
		return -1;
	}

	ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
	//printf ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
	//TC_write_syslog ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;
		

	sor_t5_PPPMPrjCode = tc_strtok ( sor_t5_PPPMPrjCode_desc, "$" );

	printf("\ntm_get_pppm_variant : Project code after strtok : [%s]",sor_t5_PPPMPrjCode); fflush ( stdout) ;
	TC_write_syslog ("\ntm_get_pppm_variant: sor_t5_PPPMPrjCode after strtok : [%s]",sor_t5_PPPMPrjCode);
	TC_write_syslog ("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc after strtok : [%s]",sor_t5_PPPMPrjCode_desc);

	ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
	ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
	printf ("\ntm_get_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);
	TC_write_syslog ("\ntm_get_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);

	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
		return 0;
	}

    n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

	if ( n_found_SOR_PF_info1 < 0 )
	{
		TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
		return 0;
	}

	timestamp = time_stamp ( ) ;
	sprintf( fileName, "/%s/pppm_var_%s_%s_%s.txt",pppm_file_path, userid,dml_project_code,timestamp );
	printf ( "\ntm_get_pppm_variant : fileName : [%s]", fileName ); fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : fileName : [%s]", fileName );
	command = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
	//PPPMVariantInfo -u=infodba -p=infodba -d="2228" -m="M-L155.5-MHCV_PD-MHCV PRODUCTIONISED VC_TIPPER" -f="/tmp/a.txt" 
	//sprintf ( var_cmd_to_execute, "/home/uadev/devgroups/dbk/PPPMProjectCodes_list/PPPMVariantInfo -d=\"%s\" -m=\"%s\" -f=\"%s\"", dml_project_code, sor_t5_PPPMPrjCode, fileName ) ;
	sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
	system( command );

	printf ( "\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command ); fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command );

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	variant_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
	while ( fgets ( line, sizeof ( line ), file ) )
	{
		line[tc_strlen(line)-2] = '\0';
		variant_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
		tc_strcpy ( variant_details[ij], line ) ;
		printf("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		TC_write_syslog("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		ij = ij + 1;
	}
	fclose ( file ) ;

	printf("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij ); fflush ( stdout) ;
	TC_write_syslog("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij );

	//information same file read twice first for to count no of records

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	ITK_CALL ( AOM_ask_table_rows ( objTag, "t5_SORVar", &n_table_rows, &table_rowsTag ) ) ;
	printf ( "\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows
	fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows

	if ( n_table_rows > 0 )
	{

		TC_write_syslog ( "\ntm_get_pppm_variant : deleting old variant for PPPM project code selected \n" ) ;//need to delete old rows
		//ITK_CALL ( RES_checkout(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		ITK_CALL ( AOM_lock(objTag) ) ;
		ITK_CALL ( AOM_delete_table_rows(objTag, "t5_SORVar", 0, n_table_rows) );

		ITK_CALL ( AOM_save(objTag) ); 
        ITK_CALL ( AOM_unlock(objTag) ); 
		ITK_CALL ( AOM_refresh ( objTag,TRUE ) );

		TC_write_syslog ( "\ntm_get_pppm_variant : deleting old variant for previous PPPM project code completed... \n" ) ;//need to delete old rows
        
	}


	printf ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc ) ;//need to delete old rows
	fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc ) ;//need to delete old rows

	//if ( ( n_table_rows <= 0 ) && ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 ) )//no of rows are zero then only append
	if ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 )//pppm project is not blank
	{
		num_rows_to_append = ij ;
		//ITK_CALL ( RES_checkout(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		ITK_CALL ( AOM_lock ( objTag ) ) ;
		ITK_CALL ( AOM_append_table_rows ( objTag, table_property_name,num_rows_to_append, &NewLevel, &table_rows1Tag ) ) ;

		variant_details_read = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			variant_details_read[iIndex] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( variant_details_read[iIndex], line ) ;
			//printf("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			//TC_write_syslog("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			
			
			s_srl_no = tc_strtok ( variant_details_read[iIndex], "^" );
			s_volume_inf = tc_strtok ( NULL, "^" );
			s_var_id = tc_strtok (  NULL, "^" );
			s_location = tc_strtok (  NULL, "^" );
			s_var_name = tc_strtok (  NULL, "^" );
			TC_write_syslog("\ntm_get_pppm_variant : s_srl_no : [%s]",s_srl_no);
			TC_write_syslog("\ntm_get_pppm_variant : s_volume_inf : [%s]",s_volume_inf);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_id : [%s]",s_var_id);
			TC_write_syslog("\ntm_get_pppm_variant : s_location : [%s]",s_location);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_name : [%s]\n",s_var_name);

			
			ITK_CALL ( AOM_lock ( table_rows1Tag[iIndex] ) );
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VaraintId", s_var_id ) ) ;
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VariantName", s_var_name ) ) ;
			ITK_CALL ( AOM_save ( table_rows1Tag[iIndex] ) );
			ITK_CALL ( AOM_unlock ( table_rows1Tag[iIndex] ) );
			ITK_CALL ( AOM_refresh ( table_rows1Tag[iIndex],TRUE ) );
			iIndex = iIndex + 1;

		}
		fclose ( file ) ;

		ITK_CALL ( AOM_save(objTag) ); 
        ITK_CALL ( AOM_unlock(objTag) ); 
		ITK_CALL ( AOM_refresh ( objTag,TRUE ) );

	}
	else
	{
		printf ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode is blank and no of table rows are zero" ) ;//need to delete old rows
		fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc is blank and no of table rows are zero " ) ;//need to delete old rows

	}
	return 0;
}
extern DLLAPI int SOR_save_method_post ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	const char *reason = "";
	const char *change_id = "";
	const char *dir_name = "";
	char *sor_t5_PPPMPrjCode = NULL;
	char *SOR_validation = NULL;

	//variant code
	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_SORVar";
	int num_rows_to_append = 5;
	int row_index = 0;
	int iCntr = 0 ;
	char var_id [30] = { 0 };
	char var_name [50] = { 0 };
	//char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;

	
	char *PPPMPrjCodeDetailval = NULL ;
	PPPMPrjCodeDetailval = ( char * ) MEM_alloc ( 25000 * sizeof ( char ) ) ;	//project details for input pppm project
	//variant code

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );

	printf ( "\nSOR_save_method_post : type_name : [%s]", type_name ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSOR_save_method_post : type_name : [%s]", type_name ) ;
//	if ( tc_strcmp ( type_name, "T5_AutoSorRevision" ) == 0 )
//	{
//		
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_BarrelCode", &dml_project_code ) ) ;
//		printf ( "\nSOR_save_method_post : SOR_save_method_post : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : SOR_save_method_post : dml_project_code : [%s]", dml_project_code ) ;
//
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
//		printf ( "\nSOR_save_method_post : sor_t5_PPPMPrjCode : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : sor_t5_PPPMPrjCode : [%s]", sor_t5_PPPMPrjCode ) ;
//
//		printf ( "\nSOR_save_method_post : calling get variant info and populate post action\n" ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : calling get variant info and populate\n" ) ;
//
//		//tm_get_pppm_variant ( objTag, dml_project_code, sor_t5_PPPMPrjCode);
//			
//	}
	return ITK_ok;
}

extern DLLAPI int SOR_save_method_pre ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;
	//---------------------------
	
	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );

	
	printf ( "\nSOR_save_method_pre : type_name : [%s]", type_name ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSOR_save_method_pre : type_name : [%s]", type_name ) ;
//	if ( tc_strcmp ( type_name, "T5_AutoSorRevision" ) == 0 )
//	{
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_BarrelCode", &dml_project_code ) ) ;
//		printf ( "\nSOR_save_method_pre : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_pre : dml_project_code : [%s]", dml_project_code ) ;
//
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
//		printf ( "\nSOR_save_method_pre : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_pre : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ;
//
//		//tm_get_pppm_variant ( objTag, dml_project_code, sor_t5_PPPMPrjCode);
//	}
	return ITK_ok;
}
extern DLLAPI int sor_checkin_method(METHOD_message_t *m, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	char *sor_t5_PPPMPrjCode = NULL;
	char *sor_t5_CtrlCommodity = NULL;
	char *sor_t5_CtrlSorCat = NULL;
	char *sor_t5_CtrlProcessType = NULL;
	char *Release_status_SOR = NULL;
	tag_t rel_status_SOR		   = NULLTAG;
	logical retain_released_date_SOR = TRUE;
	int tm_AutoSOR_checkin = 0;

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) ) ;

	//t5_BarrelCode



	if ( tc_strcmp ( type_name,"T5_AutoSorRevision" ) == 0 )
	{


		tm_AutoSOR_checkin = tm_check_control_object ("AUTOSORCHECKIN","ON");
		
		printf("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout) ;
		TC_write_syslog("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout);

		if ( tm_AutoSOR_checkin > 0 )
		{


			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
			printf ( "\nsor_t5_PPPMPrjCode checkin : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_PPPMPrjCode checkin : [%s]", sor_t5_PPPMPrjCode ) ;
			if ( ( sor_t5_PPPMPrjCode == NULL ) || ( tc_strcmp (sor_t5_PPPMPrjCode, "" ) == 0 ) ||  ( tc_strlen (sor_t5_PPPMPrjCode ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid PPPM project code from dropdown list");
				printf("\nselect valid PPPM project code from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid PPPM project code from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlCommodity", &sor_t5_CtrlCommodity  ) ) ;
			printf ( "\nsor_t5_CtrlCommodity checkin : [%s]", sor_t5_CtrlCommodity ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlCommodity checkin : [%s]", sor_t5_CtrlCommodity ) ;
			if ( ( sor_t5_CtrlCommodity == NULL ) || ( tc_strcmp (sor_t5_CtrlCommodity, "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlCommodity ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid Commodity from dropdown list");
				printf("\nselect valid Commodity from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid Commodity from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlSorCat", &sor_t5_CtrlSorCat  ) ) ;
			printf ( "\nsor_t5_CtrlSorCat checkin : [%s]", sor_t5_CtrlSorCat ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlSorCat checkin : [%s]", sor_t5_CtrlSorCat ) ;
			if ( ( sor_t5_CtrlSorCat == NULL ) || ( tc_strcmp (sor_t5_CtrlSorCat, "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlSorCat ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid SOR Category from dropdown list");
				printf("\nselect valid SOR Category from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid SOR Category from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlProcessType", &sor_t5_CtrlProcessType   ) ) ;
			printf ( "\nsor_t5_CtrlProcessType  checkin : [%s]", sor_t5_CtrlProcessType  ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlProcessType  checkin : [%s]", sor_t5_CtrlProcessType  ) ;
			if ( ( sor_t5_CtrlProcessType  == NULL ) || ( tc_strcmp (sor_t5_CtrlProcessType , "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlProcessType  ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid Process Type from dropdown list");
				printf("\nselect valid Process Type from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid Process Type from dropdown list\n");
				return PLM_error;
			}

			removeAllReleaseStatus (objTag);

			ITK_CALL (CR_create_release_status("T5_LcsReview",&rel_status_SOR));
			ITK_CALL(EPM_add_release_status(rel_status_SOR,1,&objTag ,retain_released_date_SOR));

			ITK_CALL(AOM_UIF_ask_value(objTag,"release_status_list",&Release_status_SOR));
			printf ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ; fflush ( stdout) ;
			printf("\nERC Review stamping on SOR....");fflush(stdout);
			TC_write_syslog("\nERC Review stamping on SOR....");fflush(stdout);

		}

		else
		{
			printf("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout) ;
			TC_write_syslog("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout);
			return 0;
		}
	}

	return ITK_ok;
}


removeAllReleaseStatus (tag_t objTag)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	printf ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;
	TC_write_syslog ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;

	ITK_CALL (WSOM_ask_release_status_list(objTag,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		ITK_CALL(POM_class_of_instance(objTag,&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		ITK_CALL(POM_unload_instances (1,&objTag));
		ITK_CALL(POM_load_instances(1,&objTag,class_id,1));
		ITK_CALL(POM_is_loaded(objTag,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		ITK_CALL( POM_length_of_attr(objTag, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			ITK_CALL( POM_ask_attr_tags(objTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				ITK_CALL(POM_remove_from_attr(1,&objTag,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				ITK_CALL(POM_save_instances(1,&objTag,1));

				ITK_CALL(POM_refresh_instances(1,&objTag,class_id,2));

				ITK_CALL(AOM_lock(objTag));

				ITK_CALL(AOM_save(objTag));
				ITK_CALL(AOM_refresh(objTag,1));

			}

			 ITK_CALL(AOM_unlock(objTag));
		}
		printf("\n Status removed");;fflush(stdout);
	}
}


//check object in control table
int tm_check_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	return n_found ;
}
//dbk added code for SOR
int Get_dml_details ( tag_t task_tag, char *sdml_no, char *s_dml_project_code, char *dml_rlz_type, char *business_unit, char *product_line )
{
	int Tskcount = 0 ;
	int	ifail = 0;
	tag_t *ERCDmlRevision = NULLTAG;
	tag_t ERCDml = NULLTAG;
	char *st5_rlstype = NULL;
	char *st5_cprojectcode = NULL;
	char *st5_ERCBusiUt = NULL;
	char *st5_cDRstatus = NULL;
	char *sitem_id_dml_task_no = NULL;
	char *st5_ProductLine = NULL;
	tag_t dml_tsk_rel_type = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t ERCDmlobjTypeTag = NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	char ERCDmltype_name[TCTYPE_name_size_c+1] ;
	tag_t projobj = NULLTAG;

	//tag_t * 	item
	ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ) ;
	ITK_CALL ( GRM_list_primary_objects_only ( task_tag, dml_tsk_rel_type, &Tskcount, &ERCDmlRevision ) ) ;//task to dml traversal
	printf ( "\nTask count : [%d]", Tskcount ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nTask count : [%d]", Tskcount ) ;
	if ( Tskcount > 0 )
	{
		ITK_CALL ( TCTYPE_ask_object_type (ERCDmlRevision[0], &objTypeTag ) ) ;
		ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) ) ;
		printf ( "\ntask type_name : [%s]", type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\ntask type_name : [%s]", type_name ) ;

		if ( tc_strcmp ( type_name, "ChangeRequestRevision" ) == 0 )
		{

			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_rlstype", &st5_rlstype ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cprojectcode", &st5_cprojectcode ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ERCBusiUt", &st5_ERCBusiUt ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cDRstatus", &st5_cDRstatus ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ProductLine", &st5_ProductLine ) ) ;

			tc_strcpy ( business_unit, st5_ERCBusiUt ) ;
			tc_strcpy ( product_line, st5_ProductLine ) ;
			tc_strcpy ( dml_rlz_type, st5_rlstype ) ;


			printf ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			printf ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			printf ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			printf ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			printf ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project

			ITK_CALL(PROJ_find(st5_cprojectcode,&projobj));
			ITK_CALL(SA_set_current_project(projobj));
		
			printf ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ;


			ITEM_ask_item_of_rev ( ERCDmlRevision[0], &ERCDml ) ;

			ITK_CALL(TCTYPE_ask_object_type(ERCDml,&ERCDmlobjTypeTag));
			ITK_CALL(TCTYPE_ask_name(ERCDmlobjTypeTag,ERCDmltype_name));
			printf ( "\nERCDmltype_name : [%s]", ERCDmltype_name ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nERCDmltype_name : [%s]", ERCDmltype_name ) ;

			if ( tc_strcmp ( ERCDmltype_name, "ChangeRequest" ) == 0 )
			{

				ITK_CALL(AOM_ask_value_string(ERCDml,"item_id",&sitem_id_dml_task_no));
				printf ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ;

				tc_strcpy ( sdml_no, sitem_id_dml_task_no ) ;
				tc_strcpy ( s_dml_project_code, st5_cprojectcode ) ;

				printf ( "\nsdml_no : [%s]", sdml_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsdml_no : [%s]", sdml_no ) ;
				printf ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ; fflush ( stdout) ;
				TC_write_syslog ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ;
			}
		}



	}
	return ifail;
}

int Create_SOR ( tag_t objTag, char *type_name,char *myItem_id, char *PartRevision,char *PartSequence, char *dml_no, char *dml_project_code, char *business_unit, char *product_line)
{
	int retcode = ITK_ok ;
	char *SOR_item_id = NULL ;
	tag_t tItemTag = NULLTAG ;
	tag_t tRevTypeTag = NULLTAG ;
	tag_t tRevCreateInputTag  = NULLTAG ;
	int nItems = 0 ;
	tag_t *items = NULLTAG ;
	tag_t latestDesrev = NULLTAG ;
	tag_t latestSorrev = NULLTAG ;
	tag_t tRelationExist = NULLTAG ;
	tag_t PartSorRelTag = NULLTAG ;
	tag_t tRelationFind	= NULLTAG ;
	tag_t tItemTypeTag = NULLTAG ;
	tag_t tItemCreateInputTag = NULLTAG ;
	char *myitem_revision_id = NULL ;
	char *myitem_revision_id_1 = NULL ;
	char *Release_status_SOR = NULL ;
	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;
	logical  retain_released_date_SOR  = TRUE;
	tag_t status_rel_SOR		   = NULLTAG;

	//if ( tc_strcmp ( type_name, "Design Revision" ) == 0 )//if Design Revision then only create SOR
	{
		SOR_item_id = MEM_alloc ( 50*sizeof ( char ) ) ;

		tc_strcpy ( SOR_item_id, "SOR_" ) ;
		tc_strcat ( SOR_item_id, myItem_id ) ;
		tc_strcat ( SOR_item_id, "_" ) ;
		tc_strcat ( SOR_item_id, PartRevision ) ;//Revision

		printf ( "\nmyItem_id : [%s] \n", myItem_id ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nmyItem_id : [%s] \n", myItem_id ) ;
		printf ( "\nPartRevision : [%s] \n", PartRevision ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nPartRevision : [%s] \n", PartRevision ) ;
		printf ( "\nSOR_item_id : [%s] \n", SOR_item_id ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nSOR_item_id : [%s] \n", SOR_item_id ) ;

		const char *names [2] = { "object_type","item_id" } ;
		const char *values [2] = { "T5_AutoSor",SOR_item_id } ;

		ITK_CALL ( ITEM_find_items_by_key_attributes ( 2, names, values, &nItems, &items ) ) ;
		printf ( "\nno of T5_AutoSor : [%d]\n", nItems ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nno of T5_AutoSor : [%d]\n", nItems ) ;

		if ( nItems == 0 )
		{

			ITK_CALL ( TCTYPE_find_type ( "T5_AutoSorRevision", NULL, &tRevTypeTag ) ) ;
			ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
			printf ( "\nT5_AutoSorRevision test" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nT5_AutoSorRevision test" ) ;
			//if ( retcode == ITK_ok && tRevCreateInputTag != NULLTAG )
			{

				ITK_CALL ( TCTYPE_find_type ( "T5_AutoSor", NULL, &tItemTypeTag ) ) ;
				ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
				printf("\nfind the item type T5_AutoSor\n"); fflush ( stdout) ;
				TC_write_syslog("\nfind the item type T5_AutoSor\n");

				//if ( retcode == ITK_ok && tItemCreateInputTag != NULLTAG )
				{
					ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", SOR_item_id ) ) ;		//item
					ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", SOR_item_id ) ) ;
					ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;

					
					ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DmlNumber", dml_no ) ) ;	//dml no
					ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_BarrelCode", dml_project_code ) ) ;	//dml project code
					ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DMLVertical", product_line ) ) ;	//dml vertical
					ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_BusinessUnit", business_unit ) ) ;	//dml business_unit
					//AOM_set_value_string ( tRevCreateInputTag, "t5_SorReviewer", DML_SorReviewer ) ;	//dml SorReviewer from dml manager



					ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;

					//ITK_CALL ( AOM_refresh ( tItemTag, 1 ) ) ;
					ITK_CALL ( AOM_save_with_extensions ( tItemTag ) ) ;
					ITK_CALL ( AOM_unlock ( tItemTag ) ) ;
					ITK_CALL ( ITEM_ask_latest_rev ( tItemTag, &latestSorrev ) ) ;


					ITK_CALL (CR_create_release_status("T5_LcsWorking",&status_rel_SOR));
					ITK_CALL(EPM_add_release_status(status_rel_SOR,1,&latestSorrev ,retain_released_date_SOR));
					printf("\nERC Working stamping on SOR....");fflush(stdout);
					TC_write_syslog("\nERC Working stamping on SOR....");fflush(stdout);


					ITK_CALL ( RES_checkout ( latestSorrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create

					printf("\nSOR [%s] revision [%s] created successfully\n",SOR_item_id, SOR_item_id ) ; fflush ( stdout) ;
					TC_write_syslog("\nSOR [%s] revision [%s] created successfully\n",SOR_item_id, SOR_item_id ) ;

					ITK_CALL ( ITEM_find_items_by_key_attributes ( 2, names, values, &nItems, &items ) ) ;

					printf("\nNo of sor tag : %d",nItems); fflush ( stdout) ;
					TC_write_syslog("\nNo of sor tag : %d",nItems);
					ITK_CALL ( ITEM_ask_latest_rev ( items[0], &latestSorrev ) ) ;
					ITK_CALL ( AOM_ask_value_string ( latestSorrev, "item_revision_id", &myitem_revision_id ) ) ;
					printf("\nSOR revision : %s",myitem_revision_id); fflush ( stdout) ;
					TC_write_syslog("\nSOR revision : %s",myitem_revision_id);

					ITK_CALL ( AOM_UIF_ask_value ( latestSorrev, "release_status_list", &Release_status_SOR ) ) ;
					printf("\nRelease_status_SOR : %s",Release_status_SOR); fflush ( stdout) ;
					TC_write_syslog("\nRelease_status_SOR: %s",Release_status_SOR);

					ITK_CALL ( AOM_ask_value_string ( objTag, "item_revision_id", &myitem_revision_id_1 ) ) ;
					printf("\nDes revision : %s",myitem_revision_id_1); fflush ( stdout) ;
					TC_write_syslog("\nDes revision : %s",myitem_revision_id_1);

					//---------------------------relation create----------------------------
					printf("\nfind T5_PartSorRel"); fflush ( stdout) ;
					TC_write_syslog("\nfind T5_PartSorRel");
					ITK_CALL ( GRM_find_relation_type ( "T5_PartSorRel", &tRelationFind ) ) ;

					printf("\nfound relation T5_PartSorRel\n");fflush(stdout);
					TC_write_syslog("\nfound relation T5_PartSorRel\n");fflush(stdout);
					ITK_CALL( GRM_find_relation(objTag,latestSorrev,tRelationFind,&tRelationExist));

					printf("\n AFTER TESTING HERE tRelationExist \n");fflush(stdout);
					TC_write_syslog("\n AFTER TESTING HERE tRelationExist \n");fflush(stdout);
					if(tRelationExist)
					{
						printf("\ntRelationExist tRelationExist tRelationExist \n");fflush(stdout);
						TC_write_syslog("\ntRelationExist tRelationExist tRelationExist \n");fflush(stdout);
					}
					else
					{
						printf("\ntRelationExist DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
						TC_write_syslog("\ntRelationExist DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
						ITK_CALL ( GRM_create_relation ( objTag, latestSorrev, tRelationFind, NULLTAG, &PartSorRelTag ) ) ;//latest part revision and dad doc revision
						ITK_CALL ( GRM_save_relation ( PartSorRelTag ) ) ;
						ITK_CALL ( AOM_refresh ( objTag,0 ) );
						printf("\nSOR [%s] revision [%s] and part relation created successfully\n",SOR_item_id, SOR_item_id ); fflush ( stdout) ;
						TC_write_syslog("\nSOR [%s] revision [%s] and part relation created successfully\n",SOR_item_id, SOR_item_id );
					}
					//---------------------------relation create----------------------------

				}
			}
		}
	}

	return ITK_ok;
}

int SorCrValidation ( tag_t task_tag, tag_t design_tag )
{
	int	ifail = 0;

	char *sitem_id_partno = NULL;
	char *sitem_revision_id = NULL;
	char *st5_PartType = NULL;
	char *st5_DrawingInd = NULL;
	char *st5_ColourInd = NULL;
	char *PartRevision = NULL;
	char *PartSequence = NULL;
	char dsg_type_name[TCTYPE_name_size_c+1];
	tag_t desgobjTypeTag = NULLTAG ;
	char *dml_no = NULL;
	char *dml_project_code = NULL;
	char *dml_rlz_type = NULL;
	char *business_unit = NULL;
	char *product_line = NULL;
	int n_found_BU = 0 ;
	int n_found_PL = 0 ;
	int n_found_PRT_TYPE = 0 ;
	int n_found_DRW_IND = 0 ;
	int n_found_CLR_IND = 0 ;
	int n_found_DML_PRJ_CODE = 0 ;
	int n_found_DML_RLZ_TYPE = 0 ;
	int n_found_BO_CLASS_TYPE = 0 ;

	dml_no = ( char * ) MEM_alloc ( 20 * sizeof ( char ) );
	dml_project_code = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );
	dml_rlz_type = ( char * ) MEM_alloc ( 100 * sizeof ( char ) );
	business_unit = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );
	product_line = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );

	Get_dml_details ( task_tag, dml_no, dml_project_code, dml_rlz_type, business_unit, product_line ) ;


	printf ( "\nSorCrValidation dml_rlz_type : [%s]", dml_rlz_type ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation dml_rlz_type : [%s]", dml_rlz_type ) ;
	printf ( "\nSorCrValidation business_unit : [%s]", business_unit ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation business_unit : [%s]", business_unit ) ;
	printf ( "\nSorCrValidation product_line : [%s]", product_line ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation product_line : [%s]", product_line ) ;
	printf ( "\nSorCrValidation dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation dml_project_code : [%s]", dml_project_code ) ;

	printf ( "\nSorCrValidation DML : [%s]", dml_no ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation DML : [%s]", dml_no ) ;

	n_found_BU = tm_check_control_object ( "SORCOBU", business_unit );//busniness unit
	n_found_PL = tm_check_control_object ( "SORCOPL", product_line );//product line or vertical
	n_found_DML_PRJ_CODE = tm_check_control_object ( "SORDMLPRCODE", dml_project_code );//product line or vertical
	n_found_DML_RLZ_TYPE = tm_check_control_object ( "SORDMLRLZTYPE", dml_rlz_type );//dml release type

	printf ( "\ndml release type count [%s] : [%d]", dml_rlz_type, n_found_DML_RLZ_TYPE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\ndml release type count [%s] : [%d]", dml_rlz_type, n_found_DML_RLZ_TYPE ) ;

	if ( n_found_DML_RLZ_TYPE <= 0 ) //dml release type control object not found hence skipping
	{
		printf ( "\thence skipping SOR creation dml release type" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation dml release type" ) ;
		return 0 ;
	}


	printf ( "\nBusiness unit count [%s] : [%d]", business_unit, n_found_BU ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nBusiness unit count [%s] : [%d]", business_unit, n_found_BU ) ;

	if ( n_found_BU <= 0 ) //Business unit control object not found hence skipping
	{
		printf ( "\thence skipping SOR creation BU" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation BU" ) ;
		return 0 ;
	}

	printf ( "\nProduct Line vertical count [%s] : [%d]", product_line, n_found_PL ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nProduct Line vertical count [%s] : [%d]", product_line, n_found_PL ) ;

	if ( n_found_PL <= 0 ) //vertical control object "not found" hence skipping SOR creation
	{
		printf ( "\thence skipping SOR creation vertical" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation vertical" ) ;
		return 0 ;
	}

	printf ( "\nDML Product code count [%s] : [%d]", dml_project_code, n_found_DML_PRJ_CODE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nDML Product code count [%s] : [%d]", dml_project_code, n_found_DML_PRJ_CODE ) ;

//	if ( n_found_DML_PRJ_CODE > 0 )//project code "found" hence skip sor creation for those project
//	{
//		printf ( "\thence skipping SOR creation projectcode" ) ;
//		TC_write_syslog ( "\thence skipping SOR creation projectcode" ) ;
//		return 0 ;
//	}

	if ( n_found_DML_PRJ_CODE <= 0 )//project code "found" hence skip sor creation for those project
	{
		printf ( "\thence skipping SOR creation projectcode" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation projectcode" ) ;
		return 0 ;
	}

	ITK_CALL ( TCTYPE_ask_object_type ( design_tag, &desgobjTypeTag ) );
	ITK_CALL ( TCTYPE_ask_name ( desgobjTypeTag, dsg_type_name ) );

	n_found_BO_CLASS_TYPE = tm_check_control_object ( "SORBOCLSTYPE", dsg_type_name );//Design Revision

	printf ( "\nBusiness object type or class count [%s] : [%d]", dsg_type_name, n_found_BO_CLASS_TYPE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nBusiness object type or class count [%s] : [%d]", dsg_type_name, n_found_BO_CLASS_TYPE ) ;

	//if ( tc_strcmp ( dsg_type_name, "Design Revision" ) == 0 )//it was handling only design revision hence control object base to handle various classes
	if ( n_found_BO_CLASS_TYPE > 0 ) // if business object type or class found in control object then only create SOR = Design Revision
	{
		ITK_CALL ( AOM_ask_value_string ( design_tag, "item_id", &sitem_id_partno ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "item_revision_id", &sitem_revision_id ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_PartType", &st5_PartType ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_DrawingInd", &st5_DrawingInd ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_ColourInd", &st5_ColourInd ) ) ;


		printf ( "\nsitem_id_partno : [%s]", sitem_id_partno ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsitem_id_partno : [%s]", sitem_id_partno ) ;
		printf ( "\nsitem_revision_id : [%s]", sitem_revision_id ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsitem_revision_id : [%s]", sitem_revision_id ) ;
		printf ( "\nst5_PartType : [%s]", st5_PartType ) ;//check valid part types
		fflush ( stdout) ;
		TC_write_syslog ( "\nst5_PartType : [%s]", st5_PartType ) ;//check valid part types
		printf ( "\nst5_DrawingInd : [%s]", st5_DrawingInd ) ;//check drawing ind D/A
		fflush ( stdout) ;
		TC_write_syslog ( "\nst5_DrawingInd : [%s]", st5_DrawingInd ) ;//check drawing ind D/A
		printf ( "\nsst5_ColourInd : [%s]", st5_ColourInd ) ;//check colour ind
		fflush ( stdout) ;
		TC_write_syslog ( "\nsst5_ColourInd : [%s]", st5_ColourInd ) ;//check colour ind

		n_found_PRT_TYPE = tm_check_control_object ( "SORCOPRTTYPE", st5_PartType );//valid part types
		n_found_DRW_IND = tm_check_control_object ( "SORCODRWIND", st5_DrawingInd );//valid drawing ind
		n_found_CLR_IND = tm_check_control_object ( "SORCOCLRIND", st5_ColourInd );//valid colour ind



		printf ( "\nPart type count [%s] : [%d]", st5_PartType, n_found_PRT_TYPE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nPart type count [%s] : [%d]", st5_PartType, n_found_PRT_TYPE ) ;

		if ( n_found_PRT_TYPE <= 0 )//part type not found in control object
		{
			printf ( "\thence skipping SOR creation part type" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation part type" ) ;
			return 0 ;
		}

		printf ( "\nDrawing indicator count [%s] : [%d]", st5_DrawingInd, n_found_DRW_IND ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nDrawing indicator count [%s] : [%d]", st5_DrawingInd, n_found_DRW_IND ) ;

		if ( n_found_DRW_IND <= 0 )//drawing indicator not found in control object
		{
			printf ( "\thence skipping SOR creation drawing indicator" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation drawing indicator" ) ;
			return 0 ;
		}

		printf ( "\nColour indicator count [%s] : [%d]", st5_ColourInd, n_found_CLR_IND ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nColour indicator count [%s] : [%d]", st5_ColourInd, n_found_CLR_IND ) ;

		if ( n_found_CLR_IND <= 0 )//colour indicator not found in control object
		{
			printf ( "\thence skipping SOR creation colour indicator" ) ;  fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation colour indicator" ) ;
			return 0 ;
		}


		if ( tc_strstr ( sitem_revision_id, ";" ) != NULL )
		{
			PartRevision = strtok(sitem_revision_id, ";");
			PartSequence = strtok(NULL, ";");
		}
		else
		{
			PartRevision = MEM_alloc ( 10 ) ;
			PartSequence = MEM_alloc ( 10 ) ;
			tc_strcpy ( PartRevision, sitem_revision_id ) ;
			tc_strcpy ( PartSequence, "" ) ;
		}
		
		if ( tc_strcmp ( PartRevision, "NR" ) == 0 )
		{
			Create_SOR ( design_tag, dsg_type_name, sitem_id_partno, PartRevision, PartSequence, dml_no, dml_project_code, business_unit, product_line) ;
		}
	}
	else
	{
		printf ( "\thence skipping SOR creation business object type or class" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation business object type or class" ) ;
		return 0 ;
	}

	return ifail;
}
//dbk added code for SOR
int T5TaskToPart_SORCreateVal ( METHOD_message_t *msg, va_list  args )
{
	va_list largs;
	va_copy( largs, args );
	char type_name[TCTYPE_name_size_c+1];
	char secndry_obj_type_name[TCTYPE_name_size_c+1];
	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	tag_t  *new_relation = va_arg(largs, tag_t *);
	tag_t objTypeTag1 = NULLTAG ;
	tag_t objTypeTag2 = NULLTAG ;
	char   relation_name[TCTYPE_name_size_c+1];
	int n_found_BO_CLASS_TYPE = 0 ;
	int n_AUTOSOR_LIVE = 0;
	int n_AUTOSOR_TASK_BOTYPE = 0;
	int n_AUTOSOR_TASK_PART_REL_NAME = 0;

	n_AUTOSOR_LIVE = tm_check_control_object ( "AUTOSOR_LIVE", "TRUE" );//autosor functionality live

	if ( n_AUTOSOR_LIVE > 0 )
	{
		
		printf ( "\nAutoSOR is live : [%d]",n_AUTOSOR_LIVE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nAutoSOR is live : [%d]",n_AUTOSOR_LIVE ) ;
		
		ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &objTypeTag1 ) ) ;
		ITK_CALL ( TCTYPE_ask_name ( objTypeTag1, type_name ) ) ;

		ITK_CALL ( TCTYPE_ask_object_type ( secondary_object, &objTypeTag2 ) ) ;
		ITK_CALL ( TCTYPE_ask_name ( objTypeTag2, secndry_obj_type_name ) ) ;
		ITK_CALL ( TCTYPE_ask_name ( relation_type, relation_name ) ) ;

		//dbk added code for SOR
		printf ( "\nT5TaskToPart_SORCreateVal : dbk testing after SOR T5TaskToPart_SORCreateVal" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : dbk testing after SOR T5TaskToPart_SORCreateVal" ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : secndry_obj_type_name : [%s]", secndry_obj_type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : secndry_obj_type_name : [%s]", secndry_obj_type_name ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : type_name : [%s]", type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : type_name : [%s]", type_name ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : relation_name : [%s]", relation_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : relation_name : [%s]", relation_name ) ;

		n_found_BO_CLASS_TYPE = tm_check_control_object ( "SORBOCLSTYPE", secndry_obj_type_name );//Design Revision is secondary object
		printf ( "\nT5TaskToPart_SORCreateVal : first check Business object type or class count [%s] : [%d]", secndry_obj_type_name, n_found_BO_CLASS_TYPE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : first check Business object type or class count [%s] : [%d]", secndry_obj_type_name, n_found_BO_CLASS_TYPE ) ;
	
		printf("\ndml TASK Business object type name : [%s]",type_name); fflush ( stdout) ;
		TC_write_syslog("\ndml TASK Business object type name : [%s]",type_name);
		
		n_AUTOSOR_TASK_BOTYPE = tm_check_control_object ( "AUTOSOR_TASK_BOTYPE", type_name );//task business object type ERC TASK/APL task
		//if ( ( n_found_BO_CLASS_TYPE > 0 ) && ( tc_strcmp ( type_name, "T5_ChangeTaskRevision" ) == 0 ) )
		if ( ( n_found_BO_CLASS_TYPE > 0 ) && ( n_AUTOSOR_TASK_BOTYPE > 0 ) )
		{
			//printf("\ndbk testing 1");
			printf("\nRelation object check : [%s]",relation_name); fflush ( stdout) ;
			TC_write_syslog("\nRelation object check : [%s]",relation_name);
			//if ( tc_strcmp ( relation_name, "CMHasSolutionItem" ) == 0 )
			n_AUTOSOR_TASK_PART_REL_NAME = tm_check_control_object ( "AUTOSOR_TASK_PART_REL_NAME", relation_name );
			if ( n_AUTOSOR_TASK_PART_REL_NAME > 0 )
			{
				TC_write_syslog("\nbefore SorCrValidation");
				SorCrValidation ( primary_object, secondary_object );
				TC_write_syslog("\nafter SorCrValidation");
			}
		}
		//printf("\ndbk testing after SOR");
		TC_write_syslog("\nend T5TaskToPart_SORCreateVal");
	}
	else
	{
		printf ( "\nAutoSOR is not live : [%d]",n_AUTOSOR_LIVE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nAutoSOR is not live : [%d]",n_AUTOSOR_LIVE ) ;
		
	}
	return ITK_ok;
}

int SOR_Save_PreCond_Validation(METHOD_message_t *msg, va_list args)
{
	printf("\n***** INSIDE SOR_Save_PreCond_Validation ***** \n");fflush(stdout);
	int	ifail = 0;
	tag_t P_Obj_Type = NULLTAG;
	char Ptype_name[WSO_name_size_c+1];
	tag_t Currproj = NULLTAG;
	char *st5_session_prj_code = NULL;
	char *sor_t5_BarrelCode = NULL;


	tag_t P_Obj = va_arg(args, tag_t);
	tag_t S_Obj =  va_arg(args, tag_t);

	ITK_CALL ( TCTYPE_ask_object_type(P_Obj,&P_Obj_Type ) );
	ITK_CALL ( TCTYPE_ask_name(P_Obj_Type,Ptype_name ) );
	printf("\nmethod_save_pre_cond_sor BO type:  %s\n",Ptype_name);fflush(stdout);
	TC_write_syslog ("\nmethod_save_pre_cond_sor BO type:  %s\n",Ptype_name);fflush(stdout);

	if ( tc_strcmp ( Ptype_name, "T5_AutoSorRevision" ) == 0)
	{

		
		ITK_CALL ( SA_ask_current_project ( &Currproj ) );
		ITK_CALL ( AOM_ask_value_string(Currproj,"object_name",&st5_session_prj_code) );
		printf ( "\nsession st5_session_prj_code : [%s]", st5_session_prj_code ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsession st5_session_prj_code : [%s]", st5_session_prj_code ) ;

		ITK_CALL ( AOM_ask_value_string ( P_Obj, "t5_BarrelCode", &sor_t5_BarrelCode ) ) ;
		TC_write_syslog ( "\nsor_t5_BarrelCode : [%s]", sor_t5_BarrelCode ) ;
		
		if ( tc_strcmp ( st5_session_prj_code, sor_t5_BarrelCode ) != 0 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Change session project value as per dml project!!!");
			return ITK_err;
		}
	}

	return ifail;
}

extern DLLAPI int prop_PPPProjValueChange_ChngVariant(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;

	
	TC_write_syslog("\nINSIDE prop_PPPProjValueChange_ChngVariant*** \n");fflush(stdout);
	
	tag_t autosorRev = msg->object_tag;

	// 	ITK_CALL ( AOM_set_value_string ( autosorRev, "t5_RefSOR", "Used by Designer" ) ) ;		//testing
			
	ITK_CALL ( AOM_ask_value_string ( autosorRev, "t5_BarrelCode", &dml_project_code ) ) ;
	printf ( "\nprop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ;

	ITK_CALL ( AOM_ask_value_string ( autosorRev, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
	printf ( "\nprop_PPPProjValueChange_ChngVariant : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_PPPProjValueChange_ChngVariant : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ;

	if ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 )
	{
		tm_get_pppm_variant ( autosorRev, dml_project_code, sor_t5_PPPMPrjCode);
	}
	else
	{
		TC_write_syslog("\nprop_PPPProjValueChange_ChngVariant : Select valid PPPM Project code\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid PPPM project code from dropdown list");
		return PLM_error;
	}

	return error_code;
}


extern int tm_AutoSOR_CUST_register_method(int *decision, va_list args)
{

	METHOD_id_t  method;
	METHOD_id_t  method_sor_checkin;
	//METHOD_id_t  method_save_post_act;
	METHOD_id_t  method_save_post_act_sor;
	METHOD_id_t  method_save_pre_act_sor;
	METHOD_id_t  method_save_pre_cond_sor;
	METHOD_id_t  methodPPPProjValueChange;
	METHOD_id_t  method_grm_pre_act_sor;
	int	ifail = 0;

	*decision = ALL_CUSTOMIZATIONS;

	ITK_CALL ( METHOD_find_method ( "T5_AutoSorRevision", "IMAN_save", &method_save_pre_act_sor  ) );
	if ( method_save_pre_act_sor.id != NULLTAG )
	{
		ITK_CALL ( METHOD_add_action ( method_save_pre_act_sor, METHOD_pre_action_type, (METHOD_function_t) SOR_save_method_pre, NULL ) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_save_method_pre not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_method ( "T5_AutoSorRevision", "IMAN_save", &method_save_post_act_sor  ) );
	if ( method_save_post_act_sor.id != NULLTAG )
	{
		ITK_CALL ( METHOD_add_action ( method_save_post_act_sor, METHOD_post_action_type, (METHOD_function_t) SOR_save_method_post, NULL ) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_save_method_post not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_method("T5_AutoSorRevision", "IMAN_save", &method_save_pre_cond_sor) );
	if (method_save_pre_cond_sor.id != NULLTAG)
	{
		ITK_CALL(METHOD_add_pre_condition(method_save_pre_cond_sor,(METHOD_function_t) SOR_Save_PreCond_Validation,NULL) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_Save_PreCond_Validation not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_prop_method("T5_AutoSorRevision", "t5_PPPMPrjCode", PROP_set_value_string_msg, &methodPPPProjValueChange) );
	if (methodPPPProjValueChange.id != NULLTAG)
	{
		ITK_CALL ( METHOD_add_action(methodPPPProjValueChange, METHOD_post_action_type, (METHOD_function_t) prop_PPPProjValueChange_ChngVariant, NULL) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_Save_PreCond_Validation not found\n");fflush(stdout);
	}
	
	ITK_CALL ( METHOD_find_method(RES_Type, RES_checkin_msg, &method_sor_checkin) );
	if (method_sor_checkin.id != NULLTAG)
    {
        ITK_CALL( METHOD_add_action(method_sor_checkin, METHOD_pre_action_type, (METHOD_function_t) sor_checkin_method, NULL));

		printf("\nSOR Pre-Action for check-in\n");fflush(stdout);
		TC_write_syslog("\nSOR Pre-Action for check-in\n");fflush(stdout);
    }
	else
	{
		TC_write_syslog("\nSOR sor_checkin_method not found\n");fflush(stdout);
	}
	

	ITK_CALL ( METHOD_find_method("ImanRelation", GRM_create_msg, &method_grm_pre_act_sor) );
	if (method_grm_pre_act_sor.id != NULLTAG)
	{
		ITK_CALL( METHOD_add_action(method_grm_pre_act_sor, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPart_SORCreateVal, NULL));
		printf("\nSOR Registered as METHOD_pre_action_type for T5TaskToPartCreateVal\n");fflush(stdout);
		TC_write_syslog("\nSOR Registered as METHOD_pre_action_type for T5TaskToPartCreateVal\n");fflush(stdout);
	}
	else
	{
		TC_write_syslog("\nSOR T5TaskToPart_SORCreateVal not found\n");fflush(stdout);
	}

//	ITK_CALL ( METHOD_find_method("ImanRelation", TC_delete_msg, &method3) );
//	if (method3.id != NULLTAG)
//	{
//		ITK_CALL( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPart_SORDeleteVal, NULL));
//		printf("\nRegistered as METHOD_pre_action_type for T5TaskToPart_SORDeleteVal \n");fflush(stdout);
//	}

	ITK_CALL ( METHOD_register_method ( "T5_PPPMPrjCodeLOVType", LOV_ask_values_msg, &AutoSor_PPPM_proj_LOV_Method,  0, &method ) ) ;
//	TC_write_syslog("\nafter PPPMProject Code\n");fflush(stdout);


    return ifail;
}

DLLAPI int tm_AutoSOR_register_callbacks ()
{

	int ifail=0;
	printf("\nregister_callback for tm_AutoSOR\n");fflush(stdout);
	TC_write_syslog("\nregister_callback for tm_AutoSOR\n");fflush(stdout);

	ITK_CALL ( CUSTOM_register_exit ( "tm_AutoSOR", "USER_init_module", (CUSTOM_EXIT_ftn_t)  tm_AutoSOR_CUST_register_method ) ) ;
	TC_write_syslog("\nafter register_callback for tm_AutoSOR\n");fflush(stdout);


	return ( ITK_ok );
}