/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Rudresh Marde
*  Module               :   Workflow Action Handler PO Check and attach NOPO report to DML as xls.
*  Code                 :   tm_DCR_COC_Approval_mail.c
*  Created on			:   12/02/2025
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_DCR_COC_Approval_mail(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int				tskcount 					= 0;
	int             Support_n_entry             = 1;
	int             Support_rsltCount           = 0;
    //int             wfcount                     = NULL;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
    char            * dcr_no                    = NULL;
	tag_t	        dcr_tag				        = NULLTAG; 
	tag_t	        rev_tag				        = NULLTAG;
	tag_t	        objTypTag			        = NULLTAG;
	tag_t	        job_Tag3			        = NULLTAG;
	tag_t	        jobtype_Tag3			    = NULLTAG;
	char	        *ObjTyp				        = NULL;
	char	        *dcrtype_name				= NULL;
	char	        *Certification_Impact		= NULL; 
	char	        *dcr_RootCausAnalysis		= NULL;
	char	        *parent_name		        = NULL;
	char	        *dcr_name		            = NULL;
	char	        *taskname		            = NULL;
	char	        *status		                = NULL;
	char	        *object_name		        = NULL;
	char	        *dcr_ChangDesc		        = NULL;
	char	        *dcr_Proposed_Solution		= NULL;
	tag_t            rootTask                   = NULLTAG;
	tag_t           *subtask                    = NULLTAG;
	tag_t           *SupportCntrlObjectTag                    = NULLTAG;
	tag_t            finaltask                  = NULLTAG;
	tag_t	         SupportqryTag		        = NULLTAG;
	char            *emailCC                    = NULL;
	char            *CERTMAILInfo1              = NULL;
	char            *CERTMAILInfo5              = NULL;
	char            *CERTMAILInfo6              = NULL;
	char            *eMailTo                    = NULL;
	char            *emailBody	                = NULL;
	char            *emailSub	                = NULL;
	char            *buff			            = NULL;
	char            *Support_qry_entry[1]  = {"SYSCD"};
    char    **Support_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	eMailTo=(char *) MEM_alloc(100000 * sizeof(char *));
	emailCC=(char *) MEM_alloc(100000 * sizeof(char *));
	emailBody = (char *) MEM_alloc( 10000 * sizeof(char) );
	emailSub = (char *) MEM_alloc( 50000 * sizeof(char) );
	buff=(char *) MEM_alloc(500000 * sizeof(char *));

	int i      =  0;
	int no_attach	=  0;
	tag_t *taskAttachments=NULLTAG;

	printf("\n tm_DCR_COC_Approval_mail Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DCR_COC_Approval_mail Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n DCR:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			rev_tag=taskAttachments[i];
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n DCR: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
			{
				//GETTING CERTMAIL obj.
				if(QRY_find2("ControlObjects", &SupportqryTag));
				if (SupportqryTag)
				{
					printf("\n DCR-->L2:Found Query SupportqryTag \n");fflush(stdout);
				}
				else
				{
					printf("\n DCR-->L3:Not Found Query SupportqryTag \n");fflush(stdout);
				}

				Support_qry_values2[0] = "CERTMAIL";
				if(QRY_execute(SupportqryTag, Support_n_entry, Support_qry_entry, Support_qry_values2, &Support_rsltCount, &SupportCntrlObjectTag));
				printf(" \n CheckSupportLogin-->L4:Support_rsltCount :%d:", Support_rsltCount); fflush(stdout);
				if(Support_rsltCount > 0)
				{
					//ON/OFF
					if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo1",&CERTMAILInfo1)!=ITK_ok) ;  
					printf("\n CheckSupportLogin-->CERTMAILInfo1 is : [%s]\n", CERTMAILInfo1);fflush(stdout);
					//Mail Ids.
					if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo5",&CERTMAILInfo5)!=ITK_ok);   
					printf("\n CheckSupportLogin-->CERTMAILInfo5 is : [%s]\n", CERTMAILInfo5);fflush(stdout);
					//Mail Ids.
					if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo6",&CERTMAILInfo6)!=ITK_ok);
					printf("\n CheckSupportLogin-->CERTMAILInfo6 is : [%s]\n", CERTMAILInfo6);fflush(stdout);
					if (tc_strstr(CERTMAILInfo1,"CERTMAILOFF")==NULL)
					{
						AOM_ask_value_string(rev_tag,"object_name",&dcr_name);
						printf("\nInside [%s] \n",dcr_name);fflush(stdout);
						AOM_ask_value_string(rev_tag,"item_id",&dcr_no);
						printf("\nInside dcr_no [%s] \n",dcr_no);fflush(stdout);
						AOM_ask_value_string(rev_tag,"t5_DcrRootCausAnalysis",&dcr_RootCausAnalysis);
						printf("\n Inside dcr_RootCausAnalysis [%s]\n",dcr_RootCausAnalysis);fflush(stdout);
						AOM_ask_value_string(rev_tag,"t5_DcrDesc",&dcr_ChangDesc);
						printf("\n Inside dcr_ChangDesc [%s] \n",dcr_ChangDesc);fflush(stdout);
						AOM_ask_value_string(rev_tag,"t5_DcrCreProSol",&dcr_Proposed_Solution);
						printf("\n Inside dcr_Proposed_Solution [%s] [\n",dcr_Proposed_Solution);fflush(stdout);
						AOM_ask_value_string(rev_tag,"t5_Certification_Impact",&Certification_Impact);
						printf("\n 1...Certification_Impact value is newwww %s",Certification_Impact);fflush(stdout);


						if(tc_strcmp(Certification_Impact,"YES")==0)
						{
							printf("\nAAAAAAAAAAAAAAA [%s] \n",Certification_Impact);fflush(stdout);
							EPM_get_current_job(rev_tag,&job_Tag3,&jobtype_Tag3);
							TCTYPE_ask_name2(jobtype_Tag3,&dcrtype_name);

							EPM_ask_root_task(job_Tag3,&rootTask);               					    
							EPM_ask_sub_tasks(rootTask,&tskcount,&subtask);                           
							AOM_ask_value_string(rootTask,"object_name",&parent_name);
							printf("\n Parent Name: %s",parent_name);fflush(stdout);
							printf("No of subtasks = %d\n",tskcount);fflush(stdout);

							for (int i=0;i<tskcount;i++ )
							{
								finaltask  = subtask[i];
								AOM_ask_value_string(finaltask,"fnd0AliasTaskName",&taskname);
								printf("\n taskname: %s",taskname);fflush(stdout);

								if(tc_strcmp(taskname,"DCR Task SubProcess")==0)
								{
									AOM_ask_value_string(finaltask,"fnd0Status",&status);
									printf("\n status: %s",status);fflush(stdout);
									
									if (tc_strlen(CERTMAILInfo5) >0)
									{
										tc_strcpy(eMailTo,CERTMAILInfo5);
									}
									if (tc_strlen(CERTMAILInfo6) >0)
									{
										tc_strcpy(emailCC,CERTMAILInfo6);
									}	
									tc_strcpy(emailBody,"Hi Certification Team,\nPlease find the DCR details which has Certification Impact as YES. ");
									tc_strcat(emailBody,".");
									tc_strcat(emailBody,"\n");
									tc_strcat(emailBody,"Change Issue Desc: ");
									tc_strcat(emailBody,dcr_ChangDesc);
									tc_strcat(emailBody,".");
									tc_strcat(emailBody,"\n");
									tc_strcat(emailBody,"Root Cause Analysis: ");
									tc_strcat(emailBody,dcr_RootCausAnalysis);
									tc_strcat(emailBody,".");
									tc_strcat(emailBody,"\n");
									tc_strcat(emailBody,"Proposed Solution: ");
									tc_strcat(emailBody,dcr_Proposed_Solution);
									tc_strcpy(emailSub,dcr_no);
									printf("\n eMailTo [%s]\n",eMailTo);fflush(stdout);
									printf("\n emailBody [%s]\n",emailBody);fflush(stdout);
									printf("\n emailSub [%s]!!\n",emailSub);fflush(stdout);

									sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",emailBody,emailSub,emailCC,eMailTo);
									printf("\n buff [%s]!!\n",buff);fflush(stdout);
									system(buff);
									
								}
							}
						}
						else
						{
							printf("\n BBBBBBBBBBBBBBBBBb [%s] \n",dcr_name);fflush(stdout);
						}
					}
				}
			}
		}
	}
    printf("\n tm_DCR_COC_Approval_mail Function end...");fflush(stdout);
	TC_write_syslog("\n tm_DCR_COC_Approval_mail Function end...");
	//return error_code;
	return 0;
}