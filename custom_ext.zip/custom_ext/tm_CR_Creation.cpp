/*******************************************************************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *-----------------------------------------------------------------------------------------------------------------------------
** Filename		:	tm_CR_Creation.cpp
*
* Description	: > This register custom user service. Implemented Custom ITK functions for CR Workflow functionlities.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   09-Dec-2025
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------------------------------------------------------
* Date         	 Developer Name													Description of Change
* 09-Dec-2025  	 Pravin Jagdale /Chetan Borse /Amol Magdum 					Base Code for user assignment
* 			

* -----------------------------------------------------------------------------------------------------------------------------
* 
*******************************************************************************************************************************/

#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <set>
#include <streambuf>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <fstream>
#include <sstream> 
#include <stdexcept>
#include <map>
//#include <base_utils/IFail.hxx>
//#include <base_utils/TcResultStatus.hxx>
// #include <base_utils/ScopedPtr.hxx>
// #include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
//#include <bom/bom.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <ps/ps.h>
#include <ae/dataset.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <Fnd0Participant/participant.h>

#define ITK_err 919002
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
 
                if (return_code != ITK_ok)
                {
                                int                                                           index = 0;
                                int                                                           n_ifails = 0;
                                const int*                            severities = 0;
                                const int*                            ifails = 0;
                                const char**      texts = NULL;
 
                                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                                printf("%3d error(s)\n", n_ifails);
                                for( index=0; index<n_ifails; index++)
                                {
                                                printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                                                TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                                }
                                EMH_clear_errors();
				 }
                return return_code;
 
}

using namespace std;
int cntFlag = 0;

ofstream MainFile;

/***********************  Req. Doc attachment handler *******************************/
int CRAttachdoc(EPM_action_message_t msg)
{
    int noAttachment     = 0;
    tag_t *attachements  = NULLTAG;
    tag_t rootTask       = NULLTAG;

    char *Objtype        = NULL;

    string Objtype2;

    cout << "Inside CRAttachdoc"<< endl;
    EPM_ask_root_task(msg.task,&rootTask);
    EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachements);
    cout << "Number of noAttachment are : " << noAttachment << endl;

    if(noAttachment >0)
    {
        for(int i=0;i<noAttachment;i++)
        {
            int n_reqdoc =0;
            tag_t Reltype = NULLTAG;
            tag_t *reqdoctag = NULLTAG;
            //tag_t isltstDML = NULLTAG;
            AOM_ask_value_string(attachements[i],"object_type",&Objtype);
            cout << "Objtype is " << Objtype << endl;
            // ITEM_ask_latest_rev(attachements[i],&isltstDML);
            Objtype2 = Objtype;

            if(Objtype2 == "T5_PrRpItRevision")
            {
                cout << "inside T5_PrRpItRevision if condition " << endl;
                GRM_find_relation_type("T5_ScoAttoCR",&Reltype);
                GRM_list_secondary_objects_only(attachements[i],Reltype,&n_reqdoc,&reqdoctag);
                cout << "Number of n_reqdoc are : " << n_reqdoc << endl; 

                if(n_reqdoc > 0) 
                {
                    cout << "IFFFFFFF" << endl;
                    for(int doc=0;doc<n_reqdoc;doc++)
                    {
                        string Str = "Requirement_Doc";
                        char *reqdocname = NULL;                      

                        AOM_ask_value_string(reqdoctag[doc],"object_name",&reqdocname);
                        cout << "Req Doc name is "<< reqdocname << endl;
                        string reqdocname_str(reqdocname);
                        if(reqdocname_str.find(Str)!=string::npos)  // Found
                        {
                            cout << "Req Doc...." << endl;
                            break;
                        }
                      else
                        {
                            int QryEntryCount =3;
                            int NoOfControlObjectFound =0;
                            char *CRNum = NULL;
                            char *Creation_Date = NULL;
                            char *Plant_name = NULL;
                            char *Owning_user =NULL;
                            char *Department = NULL;
                            char *Synopsis = NULL;
                            char *Object_desc = NULL;
                            char *LocPath = NULL;
                            char *LocPath1=NULL;
                            tag_t *ControlObjectTags = NULLTAG;
                            tag_t ControlObjectQuery = NULLTAG;
                            string Filename;
                            string FileLoc;

                            tag_t datasettype =NULLTAG;
                            tag_t tool       = NULLTAG;
                            tag_t Newdataset = NULLTAG;
                            tag_t reltag = NULLTAG;
                            tag_t Rel =NULLTAG;
                            tag_t filetag= NULLTAG;
	                        tag_t *filedescriptor=NULLTAG;
                            //IMF_file_t filedescriptor;
                            char *QryEntry[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
                            char **QryValues = (char **) MEM_alloc(5 * sizeof(char *));

                                std::time_t t = std::time(nullptr);
                                std::tm* now = std::localtime(&t);

                                std::ostringstream oss;
                                oss << now->tm_mday << "/" 
                                    << (now->tm_mon + 1) << "/" 
                                    << (now->tm_year + 1900);

                                std::string currentDate = oss.str();   // single string
                                std::cout << "Current date: " << currentDate << std::endl;

                            AOM_ask_value_string(attachements[i],"item_id",&CRNum);
                            cout << "CR Number is : " << CRNum << endl;

                            // AOM_ask_value_string(attachements[i],"creation_date",&Creation_Date);
                            // cout << "Creation Date : "  << currentDate << endl;

                            AOM_ask_value_string(attachements[i],"t5_ParentProductLine",&Plant_name);
                            cout << "Plant Name : " << Plant_name << endl;

                            // AOM_ask_value_string(attachements[i],"owning_user",&Owning_user);
                            // cout << "Owning_user : " << Owning_user << endl;

                             AOM_UIF_ask_value(attachements[i],"owning_user",&Owning_user);
                            cout << "Owning_user2 : " << Owning_user << endl;

                            AOM_ask_value_string(attachements[i],"t5_PrRpDept",&Department);
                            cout << "Department : " << Department << endl;

                            AOM_ask_value_string(attachements[i],"object_name",&Synopsis);
                            cout << "Synopsis : " << Synopsis << endl;

                            AOM_ask_value_string(attachements[i],"object_desc",&Object_desc);
                            cout << "Object_desc : " << Object_desc << endl;


                            QRY_find2("Control Objects..." ,&ControlObjectQuery);
                            if (ControlObjectQuery!=NULLTAG)
                            {
                                cout << "Control Object Query Found" << endl;
                                QryValues[0] = "LocalPath";
                                QryValues[1] = "LocalPath";
                                QryValues[2] = "0";

                                QRY_execute(ControlObjectQuery, QryEntryCount, QryEntry, QryValues, &NoOfControlObjectFound, &ControlObjectTags);
                                cout << "No Of Control Object Found : " << NoOfControlObjectFound << endl;
                                for(int COCnt = 0;COCnt<NoOfControlObjectFound;COCnt++)
                                {
                                    AOM_ask_value_string(ControlObjectTags[COCnt],"t5_Userinfo1",&LocPath);
                                    cout << "LocPath : " << LocPath << endl;

                                    string CRNO;
                                    CRNO=CRNum;
                                    Filename= "Requirement_Doc_" + CRNO + ".txt";
                                    cout << "Filename is :" << Filename << endl;

                                    replace(Filename.begin(), Filename.end(), '/', '_');  // Replace '/' (space) with '_'                                  
                                    replace(Filename.begin(), Filename.end(), ' ', '_');  // Replace ' ' (space) with '_'
                                    cout << "Filename is :" << Filename << endl;

                                    //LocPath1="/tmp/";
                                    //cout << "LocPath1 is :" << LocPath1 << endl;                                  
                                    FileLoc= LocPath + Filename ;
                                    cout << "FileLoc is :" << FileLoc << endl;



                                    MainFile.open(FileLoc,ios::trunc);
                                    if(MainFile.is_open())
                                    {
                                        cout << "Inside file pointer..." << endl;
                                        // MainFile << "|Customer Name :        |";
                                        // MainFile << "TATA Motors Limited       ";
                                        // MainFile << "Date: " << Creation_Date << endl;
                                        // MainFile << "------------------------------------------------------------------------------------------------------------------" << endl;
                                        // MainFile << "CVBU PUNE           "<< CRNum << endl;
                                        // MainFile << endl;
                                        // MainFile << endl;


                                        MainFile << "---------------------------------------------------START---------------------------------------------------------------\n\n";
                                        MainFile << " | Customer Name :             | Tata Motors Limited         | Date:" << currentDate                        <<"\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Change Request Form         | Page: 1                     |"<< Plant_name<<                               "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Customer's Ref No           | " << CRNum  <<                                                          " \n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Request Log No :            |                             | Div./Dept :   " <<   Department <<            "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Phone :                     |  Version No.:               | Proposed By : "<< Owning_user <<            "\n";    
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";  
                                        MainFile << " | System Name :               | PLM Implementaion in Tata Motors                                           \n";                     
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Reason for this Change : " << Synopsis  <<                                                              "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Name of the affected agencies (if any) : " << Plant_name  << "/" << Department <<                       "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Description of Request : " << Object_desc <<                                                            "\n"; 
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | User Authorization:                                                                                      \n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | TTL Authorization for Feasibility Study: Avinash Deshpande                                               \n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Feasibilty:                                                                                              \n";
                                        MainFile << " | (Technical / Operational Feasibility - feasible)                                                         \n\n";
                                        MainFile << " | Resource Requirements  (Development Projects only):                                                      \n";
                                        MainFile << " | (Include Efforts, Time estimates, Hardware/Software resource requirements)                               \n\n"; 
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";                                                                                       
                                        MainFile << " | On - "   << currentDate  <<                                                                              "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | Disposal Action: "                                                                                       "\n";
                                        MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                        MainFile << " | TTL Authorization:  Avinash Deshpande                                                                     \n";
                                        MainFile << "-------------------------------------------------END------------------------------------------------------------------\n\n";


                                    }
                                    MainFile.close();

                                   // ResultStatus Status;
                                    tag_t datasetClassTag=NULLTAG;
                                    tag_t DatasetTag=NULLTAG;
                                    tag_t createInputDatasetTag=NULLTAG;
                                    tag_t relationTag = NULLTAG;
                                    tag_t returnRelationTag  = NULLTAG;
                                    const char *p = NULL;
                                    p=Filename.c_str();

                                    TCTYPE_find_type("Text","Dataset",&datasetClassTag);
                                    cout<<"Going 777"<<endl;
                                    TCTYPE_construct_create_input(datasetClassTag,&createInputDatasetTag);
                                    cout<<"Going 888"<<endl;
                                    TCTYPE_set_create_display_value(createInputDatasetTag,"object_name",1,&p);
                                    cout<<"Going 999"<<endl;
                                    TCTYPE_create_object(createInputDatasetTag,&DatasetTag);
                                    cout<<"Going 121"<<endl;
                                    AE_import_named_ref(DatasetTag,"Text",FileLoc.c_str(),p,SS_TEXT);
                                    cout<<"Going 122"<<endl;
                                    AOM_save_without_extensions(DatasetTag);
                                    cout<<"Going 123"<<endl;
                                    AOM_refresh(DatasetTag,1);
                                    cout<<"Going 124"<<endl;

                                    GRM_find_relation_type("T5_ScoAttoCR",&relationTag);
                                    cout<<"Going 125"<<endl;
                                    GRM_create_relation(attachements[i],DatasetTag,relationTag,NULLTAG,&returnRelationTag);
                                    cout<<"Going 126"<<endl;
                                    GRM_save_relation(returnRelationTag);
                                    cout<<"Going 127"<<endl;                                  

                                }
                            }
                        }
                    }                  
                }
                else
                {
                    int QryEntryCount1 =3;
                    int NoOfControlObjectFound1 =0;
                    char *CRNum = NULL;
                    char *Creation_Date = NULL;
                    char *Plant_name = NULL;
                    char *Owning_user =NULL;
                    char *Department = NULL;
                    char *Synopsis = NULL;
                    char *Object_desc = NULL;
                    char *LocPath = NULL;
                    char *LocPath1=NULL;
                    tag_t *ControlObjectTags1 = NULLTAG;
                    tag_t ControlObjectQuery1 = NULLTAG;
                    string Filename;
                    string FileLoc;

                    tag_t datasettype =NULLTAG;
                    tag_t tool       = NULLTAG;
                    tag_t Newdataset = NULLTAG;
                    tag_t reltag = NULLTAG;
                    tag_t Rel =NULLTAG;
                    tag_t filetag= NULLTAG;
                    tag_t *filedescriptor=NULLTAG;
                    //IMF_file_t filedescriptor;
                    char *QryEntry1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
                    char **QryValues1 = (char **)MEM_alloc(5 * sizeof(char *));

                        std::time_t t = std::time(nullptr);
                        std::tm* now = std::localtime(&t);

                        std::ostringstream oss;
                        oss << now->tm_mday << "/" 
                            << (now->tm_mon + 1) << "/" 
                            << (now->tm_year + 1900);

                        std::string currentDate = oss.str();   // single string
                        std::cout << "Current date: " << currentDate << std::endl;

                    AOM_ask_value_string(attachements[i],"item_id",&CRNum);
                    cout << "CR Number is : " << CRNum << endl;

                    // AOM_ask_value_string(attachements[i],"creation_date",&Creation_Date);
                    // cout << "Creation Date : "  << currentDate << endl;

                    AOM_ask_value_string(attachements[i],"t5_ParentProductLine",&Plant_name);
                    cout << "Plant Name : " << Plant_name << endl;

                    // AOM_ask_value_string(attachements[i],"owning_user",&Owning_user);
                    // cout << "Owning_user : " << Owning_user << endl;

                        AOM_UIF_ask_value(attachements[i],"owning_user",&Owning_user);
                    cout << "Owning_user2 : " << Owning_user << endl;

                    AOM_ask_value_string(attachements[i],"t5_PrRpDept",&Department);
                    cout << "Department : " << Department << endl;

                    AOM_ask_value_string(attachements[i],"object_name",&Synopsis);
                    cout << "Synopsis : " << Synopsis << endl;

                    AOM_ask_value_string(attachements[i],"object_desc",&Object_desc);
                    cout << "Object_desc : " << Object_desc << endl;


                    QRY_find2("Control Objects..." ,&ControlObjectQuery1);
                    if (ControlObjectQuery1!=NULLTAG)
                    {
                        cout << "Control Object Query Found" << endl;
                        QryValues1[0] = "LocalPath";
                        QryValues1[1] = "LocalPath";
                        QryValues1[2] = "0";

                        QRY_execute(ControlObjectQuery1, QryEntryCount1, QryEntry1, QryValues1, &NoOfControlObjectFound1, &ControlObjectTags1);
                        cout << "No Of Control Object Found : " << NoOfControlObjectFound1 << endl;
                        for(int COCnt = 0;COCnt<NoOfControlObjectFound1;COCnt++)
                        {
                            AOM_ask_value_string(ControlObjectTags1[COCnt],"t5_Userinfo1",&LocPath);
                            cout << "LocPath : " << LocPath << endl;

                            string CRNO;
                            CRNO=CRNum;
                            Filename= "Requirement_Doc_" + CRNO + ".txt";
                            cout << "Filename is :" << Filename << endl;

                            replace(Filename.begin(), Filename.end(), '/', '_');  // Replace '/' (space) with '_'                                  
                            replace(Filename.begin(), Filename.end(), ' ', '_');  // Replace ' ' (space) with '_'
                            cout << "Filename is :" << Filename << endl;

                            //LocPath1="/tmp/";
                            //cout << "LocPath1 is :" << LocPath1 << endl;                                  
                            FileLoc= LocPath + Filename ;
                            cout << "FileLoc is :" << FileLoc << endl;



                            MainFile.open(FileLoc,ios::trunc);
                            if(MainFile.is_open())
                            {
                                cout << "Inside file pointer..." << endl;
                                // MainFile << "|Customer Name :        |";
                                // MainFile << "TATA Motors Limited       ";
                                // MainFile << "Date: " << Creation_Date << endl;
                                // MainFile << "------------------------------------------------------------------------------------------------------------------" << endl;
                                // MainFile << "CVBU PUNE           "<< CRNum << endl;
                                // MainFile << endl;
                                // MainFile << endl;


                                MainFile << "---------------------------------------------------START---------------------------------------------------------------\n\n";
                                MainFile << " | Customer Name :             | Tata Motors Limited         | Date:" << currentDate                        <<"\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Change Request Form         | Page: 1                     |"<< Plant_name<<                               "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Customer's Ref No           | " << CRNum  <<                                                          " \n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Request Log No :            |                             | Div./Dept :   " <<   Department <<            "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Phone :                     |  Version No.:               | Proposed By : "<< Owning_user <<            "\n";    
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";  
                                MainFile << " | System Name :               | PLM Implementaion in Tata Motors                                           \n";                     
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Reason for this Change : " << Synopsis  <<                                                              "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Name of the affected agencies (if any) : " << Plant_name  << "/" << Department <<                       "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Description of Request : " << Object_desc <<                                                            "\n"; 
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | User Authorization:                                                                                      \n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | TTL Authorization for Feasibility Study: Avinash Deshpande                                               \n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Feasibilty:                                                                                              \n";
                                MainFile << " | (Technical / Operational Feasibility - feasible)                                                         \n\n";
                                MainFile << " | Resource Requirements  (Development Projects only):                                                      \n";
                                MainFile << " | (Include Efforts, Time estimates, Hardware/Software resource requirements)                               \n\n"; 
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";                                                                                       
                                MainFile << " | On - "   << currentDate  <<                                                                              "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | Disposal Action: "                                                                                       "\n";
                                MainFile << "----------------------------------------------------------------------------------------------------------------------\n\n";
                                MainFile << " | TTL Authorization:  Avinash Deshpande                                                                     \n";
                                MainFile << "-------------------------------------------------END------------------------------------------------------------------\n\n";


                            }
                            MainFile.close();

                            // ResultStatus Status;
                            tag_t datasetClassTag=NULLTAG;
                            tag_t DatasetTag=NULLTAG;
                            tag_t createInputDatasetTag=NULLTAG;
                            tag_t relationTag = NULLTAG;
                            tag_t returnRelationTag  = NULLTAG;
                            const char *p = NULL;
                            p=Filename.c_str();

                            TCTYPE_find_type("Text","Dataset",&datasetClassTag);
                            cout<<"Going 777"<<endl;
                            TCTYPE_construct_create_input(datasetClassTag,&createInputDatasetTag);
                            cout<<"Going 888"<<endl;
                            TCTYPE_set_create_display_value(createInputDatasetTag,"object_name",1,&p);
                            cout<<"Going 999"<<endl;
                            TCTYPE_create_object(createInputDatasetTag,&DatasetTag);
                            cout<<"Going 121"<<endl;
                            AE_import_named_ref(DatasetTag,"Text",FileLoc.c_str(),p,SS_TEXT);
                            cout<<"Going 122"<<endl;
                            AOM_save_without_extensions(DatasetTag);
                            cout<<"Going 123"<<endl;
                            AOM_refresh(DatasetTag,1);
                            cout<<"Going 124"<<endl;

                            GRM_find_relation_type("T5_ScoAttoCR",&relationTag);
                            cout<<"Going 125"<<endl;
                            GRM_create_relation(attachements[i],DatasetTag,relationTag,NULLTAG,&returnRelationTag);
                            cout<<"Going 126"<<endl;
                            GRM_save_relation(returnRelationTag);
                            cout<<"Going 127"<<endl;                                  

                        }
                    }
                }

            }   
            cout << "Outside the main if condition..." << endl;        
        }
    }
    return 0;
}
/***********************  CR Assignment Handler *******************************/

void setAddTAG_1(int *count,tag_t **objlist,tag_t obj ) 

{

	*count=*count+1;

	if(*count==1)

	{

		//printf("\n ****setAddTAG_11");fflush(stdout);

		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}

	else

	{

		//printf("\n ****setAddTAG_12");fflush(stdout);

		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));

	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}

int Dept_Review_CR_PLM_ERC(tag_t object_type)
{
    EPM_decision_t decision;
	
	char*			CR_Number				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
    char*			rolename1			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;
    tag_t			currentRole			= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags1 = NULLTAG; 
    tag_t*          OldParticipantRel   = NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_Dept_Reviewer=0;
    int     oldusrcount    = 0;
                    

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
    char* Validation = NULL;
    Validation = (char *)MEM_alloc(3000 * sizeof(char));

	char*	Temp_CR_Number	= NULL;
	int max_char_size = 80;
    Temp_CR_Number = (char *)MEM_alloc(max_char_size * sizeof(char));

    cout << "Inside Dept_Review_CR_PLM_ERC  : "  << endl;
	(AOM_ask_value_string(object_type,"item_id",&CR_Number));
	
    cout << "CR : Dept_Review_CR_PLM_ERC:  is  : " << CR_Number << endl;
	tc_strcpy(Temp_CR_Number, CR_Number);
    cout << "CR for Dept_Review_CR_PLM_ERC  : " << Temp_CR_Number << endl;
	

	ITK_CALL(SA_find_group("CR_Workflow_Group",&group_tag));
    cout << "CR_Workflow_Group Name  tag found " << endl;

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
        cout << "No of Participant found in CR_Workflow_Group DeptReview role are : " << num_of_roles << endl;
	}
		

	if(num_of_roles>0)
	{
		FlaggAssign_Dept_Reviewer = 0;//added
		for (i=0;i<num_of_roles ;i++ )
		{
            ITK_CALL(SA_ask_current_role(&currentRole));
            ITK_CALL(SA_ask_role_name2(currentRole,&rolename1));
            cout << "currentRole name is :" << rolename1 << endl;

			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			cout << "value of i : " << i;
            cout << "and  Role Name is :" << rolename << endl;
		

			if((tc_strstr(rolename1, "DeptReviewERC") != NULL) || (tc_strstr(rolename1, "ERCDeveloper") != NULL)) // && (tc_strstr(rolename, "Designer") != NULL))
			{
				cout << "Match Found for Assign_dept_reviewer => " << rolename << endl;
                if(tc_strstr(rolename, "DeptReviewERC") != NULL)
                {
                    role_tag = role_tags[i];
                    //role_tag = currentRole;
                    ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
                    cout << "No of Group CR_Workflow_Group found in Role are :" << num_of_members << endl;
                    if(num_of_members>0)
                    {
                        tag_t*	ptypes		= NULLTAG;
                        tag_t*	ptypes2		= NULLTAG;
                        int p1=0;
                        int p2=0;

                        for (b=0;b<num_of_members ;b++)
                        {
                            ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
                            ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
                            cout << "Dept_Reviewer of ERC : User ID Name :" << userid << endl;
                            FlaggAssign_Dept_Reviewer = 1;

                                TCTYPE_find_type("T5_GroupHead", "T5_GroupHead", &participant_type);
                                cout << "T5_GroupHead ------------1" << endl;
                                setAddTAG_1(&p1,&ptypes,participant_type);
                                cout << "T5_GroupHead ------------2" << endl;
                                setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                                cout << "T5_GroupHead ------------3" << endl;
                            
                        }
                        tag_t* participant_list = NULLTAG;
                        logical bypass_assignable_check =true;
                        int k = 0;

                        tag_t   type1TypeTag			= NULLTAG;

                        char*    type1type_name;
                        cout << "p1 =>" << p1;
                        cout << "and p2 =>" << p2 << endl; 
                        for(k=0;k<p2;k++)
                        {
                            tag_t type1 = ptypes[k];
                            if(type1 != NULLTAG )
                            {
                                if(TCTYPE_ask_object_type(type1,&type1TypeTag));
                                if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
                                cout << "ype1type_name =>" << type1type_name << endl;
                            }
                            else
                            {
                                cout << "type is NULL" << endl;
                            }
                        }

                        PARTICIPANT_ask_participants(object_type,participant_type,&oldusrcount,&OldParticipantRel);
                        printf("\n Get the participant type" );
                        PARTICIPANT_remove_participants(object_type,oldusrcount,OldParticipantRel);
                        cout << "Participant removed " << endl;
                        ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
                        cout << "New Participant added " << endl;
                    }
                    if(FlaggAssign_Dept_Reviewer==1)
                    {
                        cout << "FlaggAssign_Dept_Reviewer : Break" << endl;
                        //cntFlag = 1;
                        // decision=EPM_go;
                        // return decision;
                        break;
                    }
                }
			}
			
            else
            {
                 cntFlag = 1;
                 break;
                // tc_strcpy(Validation," ");
                // cout << "Doc not attached "<< endl;
                // tc_strcat(Validation,"\nPlease select the correct role\n !!!");
                // EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
                // decision=EPM_nogo;
                // return decision;
                //return ITK_err;
            
            }
		}	
        cout << "Outsidse for loop" << endl;
        //decision=EPM_go;	
	}	
    cout << "FlaggAssign_Dept_Reviewer for default :" << FlaggAssign_Dept_Reviewer << endl;
	return 0;

}
int Dept_Review_CR_PLM_NONERC(tag_t object_type)
{
    EPM_decision_t decision;
	
	char*			CR_Number				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
    char*			rolename1			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;
    tag_t			currentRole			= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags1 = NULLTAG; 
    tag_t*          OldParticipantRel   = NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_Dept_Reviewer=0;
    int     oldusrcount    = 0;
                    

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
    char* Validation = NULL;
    Validation = (char *)MEM_alloc(3000 * sizeof(char));

	char*	Temp_CR_Number	= NULL;
	int max_char_size = 80;
    Temp_CR_Number = (char *)MEM_alloc(max_char_size * sizeof(char));

    cout << "Inside Dept_Review_CR_PLM_NONERC  : "  << endl;
	(AOM_ask_value_string(object_type,"item_id",&CR_Number));
	
    cout << "CR : Dept_Review_CR_PLM_NONERC:  is  : " << CR_Number << endl;
	tc_strcpy(Temp_CR_Number, CR_Number);
    cout << "CR for Dept_Review_CR_PLM_NONERC  : " << Temp_CR_Number << endl;
	

	ITK_CALL(SA_find_group("CR_Workflow_Group",&group_tag));
    cout << "CR_Workflow_Group Name  tag found " << endl;

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
        cout << "No of Participant found in CR_Workflow_Group DeptReview role are : " << num_of_roles << endl;
	}
		

	if(num_of_roles>0)
	{
		FlaggAssign_Dept_Reviewer = 0;//added
		for (i=0;i<num_of_roles ;i++ )
		{
            ITK_CALL(SA_ask_current_role(&currentRole));
            ITK_CALL(SA_ask_role_name2(currentRole,&rolename1));
            cout << "currentRole name is :" << rolename1 << endl;

			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			cout << "value of i : " << i;
            cout << "and  Role Name is :" << rolename << endl;
		

			if((tc_strstr(rolename1, "DeptReviewNONERC") != NULL) || (tc_strstr(rolename1, "NONERCDeveloper") != NULL)) // && (tc_strstr(rolename, "Designer") != NULL))
			{
				cout << "Match Found for Assign_dept_reviewer => " << rolename << endl;
                if(tc_strstr(rolename, "DeptReviewNONERC") != NULL)
                {
                    role_tag = role_tags[i];
                    //role_tag = currentRole;
                    ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
                    cout << "No of Group CR_Workflow_Group found in Role are :" << num_of_members << endl;
                    if(num_of_members>0)
                    {
                        tag_t*	ptypes		= NULLTAG;
                        tag_t*	ptypes2		= NULLTAG;
                        int p1=0;
                        int p2=0;

                        for (b=0;b<num_of_members ;b++)
                        {
                            ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
                            ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
                            cout << "Dept_Reviewer of ERC : User ID Name :" << userid << endl;
                            FlaggAssign_Dept_Reviewer = 1;

                                TCTYPE_find_type("T5_GroupHead", "T5_GroupHead", &participant_type);
                                cout << "T5_GroupHead ------------1" << endl;
                                setAddTAG_1(&p1,&ptypes,participant_type);
                                cout << "T5_GroupHead ------------2" << endl;
                                setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                                cout << "T5_GroupHead ------------3" << endl;
                            
                        }
                        tag_t* participant_list = NULLTAG;
                        logical bypass_assignable_check =true;
                        int k = 0;

                        tag_t   type1TypeTag			= NULLTAG;

                        char*    type1type_name;
                        cout << "p1 =>" << p1;
                        cout << "and p2 =>" << p2 << endl; 
                        for(k=0;k<p2;k++)
                        {
                            tag_t type1 = ptypes[k];
                            if(type1 != NULLTAG )
                            {
                                if(TCTYPE_ask_object_type(type1,&type1TypeTag));
                                if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
                                cout << "ype1type_name =>" << type1type_name << endl;
                            }
                            else
                            {
                                cout << "type is NULL" << endl;
                            }
                        }             
                            PARTICIPANT_ask_participants(object_type,participant_type,&oldusrcount,&OldParticipantRel);
                            printf("\n Get the participant type" );
                            PARTICIPANT_remove_participants(object_type,oldusrcount,OldParticipantRel);
                            cout << "Participant removed " << endl;
                            ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
                            cout << "New Participant added " << endl;
                    }
                    if(FlaggAssign_Dept_Reviewer==1)
                    {
                        cout << "FlaggAssign_Dept_Reviewer : Break" << endl;
                        //cntFlag = 1;
                        // decision=EPM_go;
                        // return decision;
                        break;
                    } 
                }          
			}
			
            else
            {
                 cntFlag = 1;
                 break;
                // tc_strcpy(Validation," ");
                // cout << "Doc not attached "<< endl;
                // tc_strcat(Validation,"\nPlease select the correct role\n !!!");
                // EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
                // decision=EPM_nogo;
                // return decision;
                //return ITK_err;
            
            }
		}	
        cout << "Outsidse for loop" << endl;
        //decision=EPM_go;	
	}	
    cout << "FlaggAssign_Dept_Reviewer for default :" << FlaggAssign_Dept_Reviewer << endl;
	return 0;

}
int Dept_Review_CR_PLM_SYS(tag_t object_type)
{
    EPM_decision_t decision;
	
	char*			CR_Number				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
    char*			rolename1			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;
    tag_t			currentRole			= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags1 = NULLTAG; 
    tag_t*          OldParticipantRel   = NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_Dept_Reviewer=0;
    int     oldusrcount    = 0;
                    

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
    char* Validation = NULL;
    Validation = (char *)MEM_alloc(3000 * sizeof(char));

	char*	Temp_CR_Number	= NULL;
	int max_char_size = 80;
    Temp_CR_Number = (char *)MEM_alloc(max_char_size * sizeof(char));

    cout << "Inside Dept_Review_CR_PLM_SYS  : "  << endl;
	(AOM_ask_value_string(object_type,"item_id",&CR_Number));
	
    cout << "CR : Dept_Review_CR_PLM_SYS:  is  : " << CR_Number << endl;
	tc_strcpy(Temp_CR_Number, CR_Number);
    cout << "CR for Dept_Review_CR_PLM_SYS  : " << Temp_CR_Number << endl;
	

	ITK_CALL(SA_find_group("CR_Workflow_Group",&group_tag));
    cout << "CR_Workflow_Group Name  tag found " << endl;

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
        cout << "No of Participant found in CR_Workflow_Group DeptReview role are : " << num_of_roles << endl;
	}
		

	if(num_of_roles>0)
	{
		FlaggAssign_Dept_Reviewer = 0;//added
		for (i=0;i<num_of_roles ;i++ )
		{
            ITK_CALL(SA_ask_current_role(&currentRole));
            ITK_CALL(SA_ask_role_name2(currentRole,&rolename1));
            cout << "currentRole name is :" << rolename1 << endl;

			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			cout << "value of i : " << i;
            cout << "and  Role Name is :" << rolename << endl;
		

			if((tc_strstr(rolename1, "DeptReviewTML") != NULL) || (tc_strstr(rolename1, "TMLUSER") != NULL)) // && (tc_strstr(rolename, "Designer") != NULL))
			{
				cout << "Match Found for Assign_dept_reviewer => " << rolename << endl;
                if(tc_strstr(rolename, "DeptReviewTML") != NULL)
                {
                    role_tag = role_tags[i];
                    //role_tag = currentRole;
                    ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
                    cout << "No of Group CR_Workflow_Group found in Role are :" << num_of_members << endl;
                    if(num_of_members>0)
                    {
                        tag_t*	ptypes		= NULLTAG;
                        tag_t*	ptypes2		= NULLTAG;
                        int p1=0;
                        int p2=0;

                        for (b=0;b<num_of_members ;b++)
                        {
                            ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
                            ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
                            cout << "Dept_Reviewer of ERC : User ID Name :" << userid << endl;
                            FlaggAssign_Dept_Reviewer = 1;

                                TCTYPE_find_type("T5_GroupHead", "T5_GroupHead", &participant_type);
                                cout << "T5_GroupHead ------------1" << endl;
                                setAddTAG_1(&p1,&ptypes,participant_type);
                                cout << "T5_GroupHead ------------2" << endl;
                                setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                                cout << "T5_GroupHead ------------3" << endl;
                            
                        }
                        tag_t* participant_list = NULLTAG;
                        logical bypass_assignable_check =true;
                        int k = 0;

                        tag_t   type1TypeTag			= NULLTAG;

                        char*    type1type_name;
                        cout << "p1 =>" << p1;
                        cout << "and p2 =>" << p2 << endl; 
                        for(k=0;k<p2;k++)
                        {
                            tag_t type1 = ptypes[k];
                            if(type1 != NULLTAG )
                            {
                                if(TCTYPE_ask_object_type(type1,&type1TypeTag));
                                if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
                                cout << "ype1type_name =>" << type1type_name << endl;
                            }
                            else
                            {
                                cout << "type is NULL" << endl;
                            }
                        }             
                            PARTICIPANT_ask_participants(object_type,participant_type,&oldusrcount,&OldParticipantRel);
                            printf("\n Get the participant type" );
                            PARTICIPANT_remove_participants(object_type,oldusrcount,OldParticipantRel);
                            cout << "Participant removed " << endl;
                            ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
                            cout << "New Participant added " << endl;
                    }
                    if(FlaggAssign_Dept_Reviewer==1)
                    {
                        cout << "FlaggAssign_Dept_Reviewer : Break" << endl;
                        //cntFlag = 1;
                        // decision=EPM_go;
                        // return decision;
                        break;
                    } 
                }          
			}
			
            else
            {
                 cntFlag = 1;
                 break;
                // tc_strcpy(Validation," ");
                // cout << "Doc not attached "<< endl;
                // tc_strcat(Validation,"\nPlease select the correct role\n !!!");
                // EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
                // decision=EPM_nogo;
                // return decision;
                //return ITK_err;
            
            }
		}	
        cout << "Outsidse for loop" << endl;
        //decision=EPM_go;	
	}	
    cout << "FlaggAssign_Dept_Reviewer for default :" << FlaggAssign_Dept_Reviewer << endl;
	return 0;

}
int Dept_Review_CR_OTHERS(tag_t object_type)
{
    EPM_decision_t decision;
	
	char*			CR_Number				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
    char*			rolename1			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;
    tag_t			currentRole			= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags1 = NULLTAG; 
    tag_t*          OldParticipantRel   = NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_Dept_Reviewer=0;
    int     oldusrcount    = 0;
                    

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
    char* Validation = NULL;
    Validation = (char *)MEM_alloc(3000 * sizeof(char));

	char*	Temp_CR_Number	= NULL;
	int max_char_size = 80;
    Temp_CR_Number = (char *)MEM_alloc(max_char_size * sizeof(char));

    cout << "Inside Dept_Review_CR_OTHERS  : "  << endl;
	(AOM_ask_value_string(object_type,"item_id",&CR_Number));
	
    cout << "CR : Dept_Review_CR_OTHERS:  is  : " << CR_Number << endl;
	tc_strcpy(Temp_CR_Number, CR_Number);
    cout << "CR for Dept_Review_CR_OTHERS  : " << Temp_CR_Number << endl;
	

	ITK_CALL(SA_find_group("CR_Workflow_Group",&group_tag));
    cout << "CR_Workflow_Group Name  tag found " << endl;

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
        cout << "No of Participant found in CR_Workflow_Group DeptReview role are : " << num_of_roles << endl;
	}
		

	if(num_of_roles>0)
	{
		FlaggAssign_Dept_Reviewer = 0;//added
		for (i=0;i<num_of_roles ;i++ )
		{
            ITK_CALL(SA_ask_current_role(&currentRole));
            ITK_CALL(SA_ask_role_name2(currentRole,&rolename1));
            cout << "currentRole name is :" << rolename1 << endl;

			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			cout << "value of i : " << i;
            cout << "and  Role Name is :" << rolename << endl;
		

			if((tc_strstr(rolename1, "DeptReviewTTL") != NULL) || (tc_strstr(rolename1, "USERTTL") != NULL)) // && (tc_strstr(rolename, "Designer") != NULL))
			{
				cout << "Match Found for Assign_dept_reviewer => " << rolename << endl;
                if(tc_strstr(rolename, "DeptReviewTTL") != NULL)
                {
                    role_tag = role_tags[i];
                    //role_tag = currentRole;
                    ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
                    cout << "No of Group CR_Workflow_Group found in Role are :" << num_of_members << endl;
                    if(num_of_members>0)
                    {
                        tag_t*	ptypes		= NULLTAG;
                        tag_t*	ptypes2		= NULLTAG;
                        int p1=0;
                        int p2=0;

                        for (b=0;b<num_of_members ;b++)
                        {
                            ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
                            ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
                            cout << "Dept_Reviewer of ERC : User ID Name :" << userid << endl;
                            FlaggAssign_Dept_Reviewer = 1;

                                TCTYPE_find_type("T5_GroupHead", "T5_GroupHead", &participant_type);
                                cout << "T5_GroupHead ------------1" << endl;
                                setAddTAG_1(&p1,&ptypes,participant_type);
                                cout << "T5_GroupHead ------------2" << endl;
                                setAddTAG_1(&p2,&ptypes2,member_tags[b]);
                                cout << "T5_GroupHead ------------3" << endl;
                            
                        }
                        tag_t* participant_list = NULLTAG;
                        logical bypass_assignable_check =true;
                        int k = 0;

                        tag_t   type1TypeTag			= NULLTAG;

                        char*    type1type_name;
                        cout << "p1 =>" << p1;
                        cout << "and p2 =>" << p2 << endl; 
                        for(k=0;k<p2;k++)
                        {
                            tag_t type1 = ptypes[k];
                            if(type1 != NULLTAG )
                            {
                                if(TCTYPE_ask_object_type(type1,&type1TypeTag));
                                if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
                                cout << "ype1type_name =>" << type1type_name << endl;
                            }
                            else
                            {
                                cout << "type is NULL" << endl;
                            }
                        }             
                            PARTICIPANT_ask_participants(object_type,participant_type,&oldusrcount,&OldParticipantRel);
                            printf("\n Get the participant type" );
                            PARTICIPANT_remove_participants(object_type,oldusrcount,OldParticipantRel);
                            cout << "Participant removed " << endl;
                            ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
                            cout << "New Participant added " << endl;
                    }
                    if(FlaggAssign_Dept_Reviewer==1)
                    {
                        cout << "FlaggAssign_Dept_Reviewer : Break" << endl;
                        //cntFlag = 1;
                        // decision=EPM_go;
                        // return decision;
                        break;
                    } 
                }          
			}
			
            else
            {
                 cntFlag = 1;
                 break;
                // tc_strcpy(Validation," ");
                // cout << "Doc not attached "<< endl;
                // tc_strcat(Validation,"\nPlease select the correct role\n !!!");
                // EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
                // decision=EPM_nogo;
                // return decision;
                //return ITK_err;
            
            }
		}	
        cout << "Outsidse for loop" << endl;
        //decision=EPM_go;	
	}	
    cout << "FlaggAssign_Dept_Reviewer for default :" << FlaggAssign_Dept_Reviewer << endl;
	return 0;

}

//int CR_assigment(EPM_action_message_t msg)
extern EPM_decision_t DLLAPI CR_assigment(EPM_rule_message_t msg)
{

    EPM_decision_t decision;

    int error_code = ITK_ok;
    int noAttachment    = 0;
    char *type_name		=	NULL;
    char *object_name1 = NULL;
    char *CRNumber     = NULL;
    char *groupName = NULL;
    char *username = NULL;
    char *userid = NULL;
    char *rolename = NULL;
    tag_t rootTask      = NULLTAG;
    tag_t *attachements  = NULLTAG;
    tag_t objTypeTag    = NULLTAG;
    tag_t cr_rev_tag = NULLTAG;
    tag_t userTag = NULLTAG;
    tag_t groupTag = NULLTAG;
    tag_t user_tag = NULLTAG;
    tag_t role_tag = NULLTAG;
    char* Validation = NULL;
    Validation = (char *)MEM_alloc(3000 * sizeof(char));


    cout << "Inside CR_assigment"<< endl;
    EPM_ask_root_task(msg.task,&rootTask);
    EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachements);
    cout << "Number of noAttachment are : " << noAttachment << endl;

    if (noAttachment > 0)
    {
        cr_rev_tag = attachements[0];
        if (TCTYPE_ask_object_type(cr_rev_tag, &objTypeTag))
            ;
        if (TCTYPE_ask_name2(objTypeTag, &type_name))
            ;
        cout << "type_name changes done: for workspaceobject  : " << type_name << endl;
        
    }

    //if(type_name == "T5_PrRpItRevision")
    if (strcmp(type_name, "T5_PrRpItRevision") == 0)
    {
        cout << "inside class T5_PrRpItRevision......" << endl;
        AOM_ask_value_string(cr_rev_tag,"object_name",&object_name1);
        cout << "object_name1 :" << object_name1 << endl;

        AOM_ask_value_string(cr_rev_tag,"item_id",&CRNumber);
        cout << "CRNumber :" << CRNumber << endl;

        ITK_CALL (POM_get_user( &username, &user_tag ));
		ITK_CALL (SA_ask_user_identifier2 (user_tag, &userid )) ;
        cout << "Logged in userid:" << userid << endl;
        cout << "Logged in username:" << username << endl;

        SA_ask_current_role(&role_tag);     
        SA_ask_role_name2(role_tag,&rolename);
        cout << "Current rolename:" << rolename << endl;
        cout << "cntFlag : " << cntFlag << endl;

        if((tc_strstr(rolename,"ERCDeveloper")!=NULL) || (tc_strstr(rolename,"NONERCDeveloper")!=NULL) || (tc_strstr(rolename,"TMLUSER")!=NULL))
        {

            if((tc_strstr(CRNumber,"PLM_ERC")!=NULL) && (tc_strstr(rolename,"ERCDeveloper")!=NULL))
            {  
                cout <<" calling function to Dept_Review_CR For PLM_ERC Team" << endl;
                ITK_CALL(Dept_Review_CR_PLM_ERC(cr_rev_tag));// PLM_ERC (Analyst)
                //mandatorymodulecheck(item_rev_tag,&SetChildRelErr,&icount);
            }
            else if((tc_strstr(CRNumber,"PLM_NONERC")!=NULL) && (tc_strstr(rolename,"NONERCDeveloper")!=NULL))
            {
                cout <<" calling function to Dept_Review_CR For NONERC Team" << endl;
                ITK_CALL(Dept_Review_CR_PLM_NONERC(cr_rev_tag));// PLM_NONERC (Analyst)
            }
            else if((tc_strstr(CRNumber,"PLM_SYS")!=NULL) && (tc_strstr(rolename,"PLMSYSUSER")!=NULL))
            {
                cout <<" calling function to Dept_Review_CR For PLM_SYS Team" << endl;
                ITK_CALL(Dept_Review_CR_PLM_SYS(cr_rev_tag));// PLM_SYS (Analyst)
            }
            else if(((tc_strstr(CRNumber,"PE")!=NULL) || (tc_strstr(CRNumber,"APL")!=NULL) || (tc_strstr(CRNumber,"ECM-STDSI")!=NULL) || (tc_strstr(CRNumber,"CE")!=NULL) || (tc_strstr(CRNumber,"OTHERS")!=NULL) || (tc_strstr(CRNumber,"QA")!=NULL) || (tc_strstr(CRNumber,"STDSI")!=NULL)) && (tc_strstr(rolename,"USERTTL")!=NULL))
            {
                cout <<" calling function to DeptDept_Review_CR_OTHERS_Review_CR For PLM_SYS Team" << endl;
                ITK_CALL(Dept_Review_CR_OTHERS(cr_rev_tag));// PLM_SYS (Analyst)
            }
            else
            {
                cout <<" calling function to Dept_Review_CR For OTHERS Team" << endl;
                //ITK_CALL(Dept_Review_CR(cr_rev_tag));// Analyst
                tc_strcpy(Validation," ");
                cout << "Select the correct Dept"<< endl;
                tc_strcat(Validation,"\nPlease Select the correct Dept\n !!!");
                EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
                decision=EPM_nogo;
                return ITK_err;
            }
        }
        else
        {
            tc_strcpy(Validation," ");
            cout << "Doc not attached 111111111"<< endl;
            tc_strcat(Validation,"\nPlease select the correct role\n !!!");
            EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
            decision=EPM_nogo;
            return ITK_err;
        }
        cout << "cntFlag : " << cntFlag << endl;
        if(cntFlag ==1)
        {
            cout << "Inside EPM_NOGO........." << endl;
            tc_strcpy(Validation," ");
            cout << "Doc not attached 22222222222"<< endl;
            tc_strcat(Validation,"\nPlease select the correct role\n !!!");
            EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
            decision=EPM_nogo;
            //return decision;
            return ITK_err;
        }
        else
        {
            cout << "Inside EPM_GO............" << endl;
            decision = EPM_go;
        }
    }
    //return error_code;
    return decision;
}

//--------------------------------------------/      Added by amm  FSD validation  /------------------------------//-----------------------//

extern EPM_decision_t DLLAPI cr_signoff_checks_Func(EPM_rule_message_t msg)
{

    //variable decleration
    EPM_decision_t decision;

    int noAttachment     = 0;
    tag_t *attachements  = NULLTAG;
    tag_t CR_tag         =NULLTAG;
    tag_t rootTask       = NULLTAG;

    char *Objtype        = NULL;
    char *Objtype_new        = NULL;
    char *reqdocname       =NULL;
    tag_t Reltype       = NULLTAG;
    int n_reqdoc =0;
    tag_t *reqdoctag = NULLTAG;
	
	//added by amm FSD control object
	int n_entries11 = 3;
	char *qry_entries11[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *CtIndSubject = NULL;
	int resultCount = 0;
	tag_t Cntl_obj_Qtag11 = NULLTAG;
	tag_t *qry_cntrlobj11 = NULLTAG;
	char *ref_name		  = NULL;
	int	ifail		= ITK_ok;
	tag_t   sec_obj	= NULLTAG;
	int j =0;
	char *type	=NULL;
	//---------------------------//------------------------
	int count	= 0;
	tag_t *ref	= NULLTAG;
	char* Validation = NULL;
	int flg = 0;
	Validation = (char *)MEM_alloc(3000 * sizeof(char));
	
	
	//by amm FSD control object

    cout << "inside cr_signoff_checks_Func-------------"<< endl;
    EPM_ask_root_task(msg.task,&rootTask);
    EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachements);
    cout << "Number of noAttachment at cr_signoff_checks_Func are ---------: " << noAttachment << endl;


	QRY_find2("Control Objects...", &Cntl_obj_Qtag11);
	if(Cntl_obj_Qtag11!=NULLTAG)
	{
		cout << "Change Request FSD validation Control Object query found" << endl;
		qry_values11[0] = "FSD_chk_mgr_assign";
		qry_values11[1] = "active";
		qry_values11[2] = "0";
		QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11);
		cout << "Change Request FSD validation Control Object found1111--->" << resultCount << endl;
		if(resultCount>0)
		{

			if(noAttachment >0)
			{
				for(int i=0;i<noAttachment;i++)
				{
					CR_tag = attachements[i];
					AOM_ask_value_string(CR_tag,"object_type",&Objtype);
					cout << "Objtype VALUE at cr_signoff_checks_Func is : " << Objtype << endl;
					Objtype_new = Objtype;
					cout << "Objtype_new VALUE at cr_signoff_checks_Func is : " << Objtype_new << endl;
					if (strcmp(Objtype_new, "T5_PrRpItRevision") == 0)
					{
						
						cout << "amm inside T5_PrRpItRevision if condition " << endl;
						GRM_find_relation_type("T5_ScoAttoCR",&Reltype);
						GRM_list_secondary_objects_only(CR_tag,Reltype,&n_reqdoc,&reqdoctag);
						cout << "amm Number of n_reqdoc are : " << n_reqdoc << endl;
						
						if(n_reqdoc > 0) 
						{
							cout << "inside if amm Number of n_reqdoc are : " << n_reqdoc << endl;
							for(int m=0;m<n_reqdoc;m++)
							{
								string Str = "FSD_TC";
								 // string Str = "Requirement_Doc";
								flg = 0;
								 AOM_ask_value_string(reqdoctag[m],"object_name",&reqdocname);
								cout << "amm Req Doc name is "<< reqdocname << endl;

								 AOM_ask_value_string(reqdoctag[m],"object_type",&type);
								cout << "amm Req Doc type is "<< type << endl;

								string reqdocname_str(reqdocname);

								//added by amol for name ref
								if((tc_strstr(type,"Word")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
								{
									flg = 1;
									cout << "Word file found " << flg <<endl;
									break;
									/*AE_ask_all_dataset_named_refs2(sec_obj,"word",&count,&ref);
									
									cout << "amm dataset attached count is "<< count << endl;
									for(j=0;j<count;j++)
									{
										IMF_ask_original_file_name2(ref[j],&ref_name);

										cout << "ref name "<< ref_name << endl;

										string reqdocname_str(reqdocname);
										if()  // Found
										{
											cout << "TCD_CR IS..." << endl;
											decision = EPM_go;
											break;
										}
										else
										{

											cout << "Functional Specification document is not attached to CR....  "<< reqdocname << endl;
											tc_strcat(Validation,"\n !!!");
											EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Functional Specification document is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n", "error");
											return ITK_err;
											
										
										}

									}*/

								}
								else
								{
									cout << "Not a word file" << endl;
								}


							}
							if(flg==1)
							{
								decision = EPM_go;
								break;
							}
							else
							{
								tc_strcpy(Validation," ");
								cout << "Doc not attached "<< endl;
								tc_strcat(Validation,"\nFunctional Specification document is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n !!!");
								EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
								decision = EPM_nogo;
							}
						}
						else
						{
							tc_strcpy(Validation," ");
							cout << "Doc not attached "<< endl;
							tc_strcat(Validation,"\nFunctional Specification document is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n !!!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
							decision = EPM_nogo;
						}

						

					}


				}
			}
			cout << "amm noAttachment are not found"<< endl;
		}
		else
		{
			cout << "*** Control object not found ***" << endl;
		}
	}
	else
	{
		cout << "Cntl_obj_Qtag11 is NULLTAG " << endl;
	}


	
	//	ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
	//	cout << "Change Request FSD validation Control Object found22222---> usrinfo1 ---> [ %s ]" << usrinf1 << endl;
		
	
	
    cout << "amm resultCount are not found"<< endl;



	//decision = EPM_go;
    return decision;

}

//------------------------------------------------ TCD Validation start -------- cr_TCDsignoff_vldn --------------------------------------------------------------//
extern EPM_decision_t DLLAPI cr_TCDsignoff_vldn(EPM_rule_message_t msg)
{
    //variable decleration
    EPM_decision_t decision;

    int noAttachment     = 0;
    tag_t *attachements  = NULLTAG;
    tag_t CR_tag         =NULLTAG;
    tag_t rootTask       = NULLTAG;

    char *Objtype        = NULL;
    char *Objtype_new        = NULL;
    char *reqdocname       =NULL;
    tag_t Reltype       = NULLTAG;
    int n_reqdoc =0;
    tag_t *reqdoctag = NULLTAG;
	
	//added by amm FSD control object
	int n_entries11 = 3;
	char *qry_entries11[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *CtIndSubject = NULL;
	int resultCount = 0;
	tag_t Cntl_obj_Qtag11 = NULLTAG;
	tag_t *qry_cntrlobj11 = NULLTAG;
	char *ref_name		  = NULL;
	int	ifail		= ITK_ok;
	tag_t   sec_obj	= NULLTAG;
	int j =0;
	char *type	=NULL;
	//---------------------------//------------------------
	int count	= 0;
	tag_t *ref	= NULLTAG;
	char* Validation = NULL;
	int flg = 0;
	Validation = (char *)MEM_alloc(3000 * sizeof(char));
	
	
	//by amm FSD control object

    cout << "inside cr_TCDsignoff_vldn -------------"<< endl;
    EPM_ask_root_task(msg.task,&rootTask);
    EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachements);
    cout << "TCD Number of noAttachment at cr_TCDsignoff_vldn are ---------: " << noAttachment << endl;


	QRY_find2("Control Objects...", &Cntl_obj_Qtag11);
	if(Cntl_obj_Qtag11!=NULLTAG)
	{
		cout << "Change Request TCD validation Control Object query found ---->" << endl;
		qry_values11[0] = "TCD_chk_Sco_gen";
		qry_values11[1] = "active";
		qry_values11[2] = "0";
		QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11);
		cout << "Change Request TCD validation Control Object found22222 --->" << resultCount << endl;
		if(resultCount>0)
		{

			if(noAttachment >0)
			{
				for(int i=0;i<noAttachment;i++)
				{
					CR_tag = attachements[i];
					AOM_ask_value_string(CR_tag,"object_type",&Objtype);
					cout << "Objtype VALUE at cr_TCDsignoff_vldn is : " << Objtype << endl;
					Objtype_new = Objtype;
					cout << "Objtype_new VALUE at cr_TCDsignoff_vldn is : " << Objtype_new << endl;								//Test Case document(TCD)
					if (strcmp(Objtype_new, "T5_PrRpItRevision") == 0)
					{
						
						cout << "amm inside T5_PrRpItRevision if condition at Test Case document(TCD) " << endl;
						GRM_find_relation_type("T5_ScoAttoCR",&Reltype);
						GRM_list_secondary_objects_only(CR_tag,Reltype,&n_reqdoc,&reqdoctag);
						cout << "amm Number of n_reqdoc at Test Case document(TCD) are : " << n_reqdoc << endl;
						
						if(n_reqdoc > 0) 
						{
							cout << "inside if amm Number of n_reqdoc at Test Case document(TCD) : " << n_reqdoc << endl;
							for(int m=0;m<n_reqdoc;m++)
							{
								string Str = "TCD_CR";
								 // string Str = "Requirement_Doc";
								flg = 0;
								 AOM_ask_value_string(reqdoctag[m],"object_name",&reqdocname);
								cout << "amm Req Test Case Doc(TCD) name is "<< reqdocname << endl;

								 AOM_ask_value_string(reqdoctag[m],"object_type",&type);
								cout << "amm Req Test Case Doc(TCD) type is "<< type << endl;

								string reqdocname_str(reqdocname);

								//added by amol for name ref
							//	if((tc_strstr(type,"Word")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
								if((tc_strstr(type,"Excel")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
							//	if((tc_strstr(type,"MS ExcelX")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
							//	if ((tc_strstr(type, "MSExcelX") != NULL) && (reqdocname_str.find("TCD_CR") != string::npos))
								//	TCD_CR_TCUA_CR_PLM_SYS_PLM_25_0005.xlsx
								{
									flg = 1;
									cout << "Test Case Doc(TCD) excel file found111 " << flg <<endl;
									break;
									/*AE_ask_all_dataset_named_refs2(sec_obj,"word",&count,&ref);
									
									cout << "amm dataset attached count is "<< count << endl;
									for(j=0;j<count;j++)
									{
										IMF_ask_original_file_name2(ref[j],&ref_name);

										cout << "ref name "<< ref_name << endl;

										string reqdocname_str(reqdocname);
										if()  // Found
										{
											cout << "TCD_CR IS..." << endl;
											decision = EPM_go;
											break;
										}
										else
										{

											cout << "Functional Specification document is not attached to CR....  "<< reqdocname << endl;
											tc_strcat(Validation,"\n !!!");
											EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Functional Specification document is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n", "error");
											return ITK_err;
											
										
										}

									}*/

								}
								else
								{
									cout << "Not a Test Case document(TCD) excel file" << endl;
								}


							}
							if(flg==1)
							{
								decision = EPM_go;
								break;
							}
							else
							{
								tc_strcpy(Validation," ");
								cout << "Test Case document(TCD) not attached "<< endl;
							//	tc_strcat(Validation,"\n Test Case document(TCD) is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n !!!");
								tc_strcat(Validation,"\n Test case document is not attached to CR. Please ensure to attach Test Case Doc with Name Like 'TCD_CR<CR_No.>'. Sample TCD template is attached to TZ release object for this TZ.");
								EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
								decision = EPM_nogo;
							}
						}
						else
						{
							tc_strcpy(Validation," ");
							cout << "Test Case document(TCD) not attached "<< endl;
							tc_strcat(Validation,"\n Test case document is not attached to CR. Please ensure to attach Test Case Doc with Name Like 'TCD_CR<CR_No.>'. You can download the sample template By referring TZ Release object for this TZ.\n !!!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
							decision = EPM_nogo;
						}

						

					}


				}
			}
			cout << "amm noAttachment are not found at Test Case document(TCD)"<< endl;
		}
		else
		{
			cout << "*** Control object for Test Case document(TCD) not found ***" << endl;
		}
	}
	else
	{
		cout << "Cntl_obj_Qtag11 is NULLTAG ---->Test Case document(TCD) " << endl;
	}


	
	//	ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
	//	cout << "Change Request FSD validation Control Object found22222---> usrinfo1 ---> [ %s ]" << usrinf1 << endl;
		
	
	
    cout << "amm resultCount are not found at Test Case document(TCD)"<< endl;



	//decision = EPM_go;
    return decision;

}

//------------------------------------------------ TCD Validation End ----- cr_TCDsignoff_vldn --------------------------------------------------------------//

//------------------------------------------------ Peer Testing Validation start -------- cr_PeerTest_vldn --------------------------------------------------------------//

extern EPM_decision_t DLLAPI cr_PeerTest_vldn(EPM_rule_message_t msg)				//Point no 3 - Peer Testing Validation
{
    //variable decleration
    EPM_decision_t decision;

    int noAttachment     = 0;
    tag_t *attachements  = NULLTAG;
    tag_t CR_tag         =NULLTAG;
    tag_t rootTask       = NULLTAG;

    char *Objtype        = NULL;
    char *Objtype_new        = NULL;
    char *reqdocname       =NULL;
    tag_t Reltype       = NULLTAG;
    int n_reqdoc =0;
    tag_t *reqdoctag = NULLTAG;
	
	//added by amm FSD control object
	int n_entries11 = 3;
	char *qry_entries11[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	char *usrinf1 = NULL;
	char *usrinf2 = NULL;
	char *usrinf3 = NULL;
	char *CtIndSubject = NULL;
	int resultCount = 0;
	tag_t Cntl_obj_Qtag11 = NULLTAG;
	tag_t *qry_cntrlobj11 = NULLTAG;
	char *ref_name		  = NULL;
	int	ifail		= ITK_ok;
	tag_t   sec_obj	= NULLTAG;
	int j =0;
	char *type	=NULL;
	//---------------------------//------------------------
	int count	= 0;
	tag_t *ref	= NULLTAG;
	char* Validation = NULL;
	int flg = 0;
	Validation = (char *)MEM_alloc(3000 * sizeof(char));
	
	
	//by amm FSD control object

    cout << "inside cr_PeerTest_vldn -------------"<< endl;
    EPM_ask_root_task(msg.task,&rootTask);
    EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachements);
    cout << "Peer Testing Number of noAttachment at cr_PeerTest_vldn are ---------: " << noAttachment << endl;


	QRY_find2("Control Objects...", &Cntl_obj_Qtag11);
	if(Cntl_obj_Qtag11!=NULLTAG)
	{
		cout << "Change Request Peer Testing validation Control Object query found ---->" << endl;
		qry_values11[0] = "PeerTestDoc_chk";				//cr_PeerTest_vldn
		qry_values11[1] = "active";
		qry_values11[2] = "0";
		QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount, &qry_cntrlobj11);
		cout << "Change Request Peer Testing validation Control Object found22222 --->" << resultCount << endl;
		if(resultCount>0)
		{

			if(noAttachment >0)
			{
				for(int i=0;i<noAttachment;i++)
				{
					CR_tag = attachements[i];
					AOM_ask_value_string(CR_tag,"object_type",&Objtype);
					cout << "Objtype VALUE at Peer Testing assignment is : " << Objtype << endl;
					Objtype_new = Objtype;
					cout << "Objtype_new VALUE at Peer Testing assignment is : " << Objtype_new << endl;								//Test Case document(TCD)
					if (strcmp(Objtype_new, "T5_PrRpItRevision") == 0)
					{
						
						cout << "amm inside T5_PrRpItRevision if condition at Peer Testing assignment " << endl;
						GRM_find_relation_type("T5_ScoAttoCR",&Reltype);
						GRM_list_secondary_objects_only(CR_tag,Reltype,&n_reqdoc,&reqdoctag);
						cout << "amm Number of n_reqdoc at Peer Testing assignment are : " << n_reqdoc << endl;
						
						if(n_reqdoc > 0) 
						{
							cout << "inside if amm Number of n_reqdoc at Peer Testing assignment : " << n_reqdoc << endl;
							for(int m=0;m<n_reqdoc;m++)
							{
								//string Str = "TCD_TC";
								string Str = "Peer_Test";
							
								flg = 0;
								 AOM_ask_value_string(reqdoctag[m],"object_name",&reqdocname);
								cout << "amm3 Req Peer Testing assignment name is "<< reqdocname << endl;

								 AOM_ask_value_string(reqdoctag[m],"object_type",&type);
								cout << "amm3 Req Peer Testing assignment type is "<< type << endl;

								string reqdocname_str(reqdocname);

								//added by amol for name ref
							//	if((tc_strstr(type,"Word")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
								if((tc_strstr(type,"Excel")!=NULL) && (reqdocname_str.find(Str)!=string::npos))
								{
									flg = 1;
									cout << "Peer Testing assignment excel file found111 " << flg <<endl;
									break;
									/*AE_ask_all_dataset_named_refs2(sec_obj,"word",&count,&ref);
									
									cout << "amm dataset attached count is "<< count << endl;
									for(j=0;j<count;j++)
									{
										IMF_ask_original_file_name2(ref[j],&ref_name);

										cout << "ref name "<< ref_name << endl;

										string reqdocname_str(reqdocname);
										if()  // Found
										{
											cout << "TCD_CR IS..." << endl;
											decision = EPM_go;
											break;
										}
										else
										{

											cout << "Functional Specification document is not attached to CR....  "<< reqdocname << endl;
											tc_strcat(Validation,"\n !!!");
											EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Functional Specification document is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n", "error");
											return ITK_err;
											
										
										}

									}*/

								}
								else
								{
									cout << "Not a Peer Testing assignment excel file" << endl;
								}


							}
							if(flg==1)
							{
								decision = EPM_go;
								break;
							}
							else
							{
								tc_strcpy(Validation," ");
								cout << "Peer Testing assignment not attached "<< endl;
							//	tc_strcat(Validation,"\n Test Case document(TCD) is not attached to CR.Please ensure to attach FSD document to CR with Name Like 'FSD%'.You can download the sample template By referring TZ Release object for this TZ.\n !!!");
								tc_strcat(Validation,"\n Peer Testing is not attached to CR. Please ensure to attach Peer Testing document to CR with Name Like 'Peer_Test_CR<CR_No.>'. Sample template is attached to TZ release object for this TZ.");
								EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
								decision = EPM_nogo;
							}
						}
						else
						{
							tc_strcpy(Validation," ");
							cout << "Peer Testing assignment document(TCD) not attached "<< endl;
							tc_strcat(Validation,"\n Peer Testing document is not attached to CR. Please ensure to attach Peer Testing Doc with Name Like 'Peer_Test_CR<CR_No.>'. You can download the sample template By referring TZ Release object for this TZ.\n !!!");
							EMH_store_error_s1(EMH_severity_error,ITK_err,Validation);
							decision = EPM_nogo;
						}

						

					}


				}
			}
			cout << "amm noAttachment are not found at Peer Testing document(PeerTest)"<< endl;
		}
		else
		{
			cout << "*** Control object for Peer Testing document(PeerTest) not found ***" << endl;
		}
	}
	else
	{
		cout << "Cntl_obj_Qtag11 is NULLTAG ----> Peer Testing document(PeerTest) " << endl;
	}


	
	//	ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0], "t5_Userinfo1", &usrinf1));
	//	cout << "Change Request FSD validation Control Object found22222---> usrinfo1 ---> [ %s ]" << usrinf1 << endl;
		
	
	
    cout << "amm resultCount are not found at Peer Testing document(PeerTest)"<< endl;



	//decision = EPM_go;
    return decision;

}

//------------------------------------------------ Peer Testing Validation End ----- cr_TCDsignoff_vldn --------------------------------------------------------------//


extern int tm_CR_Creation_register_method(int *decision, va_list args)
{

    if (ITK_ok == EPM_register_action_handler("CRAttachdoc", "", CRAttachdoc))
    {
        cout << "CRAttachdoc registered"<< endl;
    }
    else
    {
        cout << "CRAttachdoc not registered"<< endl;
    }
	if (ITK_ok == EPM_register_rule_handler("CR_assigment", "This Handler is used to display message", (EPM_rule_handler_t)CR_assigment))
    {
        
        cout << "CR_assigment registered"<< endl;
        
    }
    else
    {
        
        cout << "CR_assigment not registered"<< endl;
       
    }

	 //added by Amol ----> FSD Validation

    if (ITK_ok == EPM_register_rule_handler("cr_signoff_checks_Func", "This Handler is used to display message", (EPM_rule_handler_t)cr_signoff_checks_Func))
    {
        
        cout << "cr_signoff_checks_Func registered"<< endl;
        
    }
    else
    {
        
        cout << "cr_signoff_checks_Func not registered"<< endl;
       
    }

	//added by Amol ----->cr_TCDsignoff_vldn--->TCD Document

    if (ITK_ok == EPM_register_rule_handler("cr_TCDsignoff_vldn", "This Handler is used to display message", (EPM_rule_handler_t)cr_TCDsignoff_vldn))
    {
        
        cout << "cr_TCDsignoff_vldn registered"<< endl;
        
    }
    else
    {
        
        cout << "cr_TCDsignoff_vldn not registered"<< endl;
       
    }

	//added by Amol ----->cr_PeerTest_vldn--->Peer Test Document

    if (ITK_ok == EPM_register_rule_handler("cr_PeerTest_vldn", "This Handler is used to display message", (EPM_rule_handler_t)cr_PeerTest_vldn))
    {
        
        cout << "cr_PeerTest_vldn registered"<< endl;
        
    }
    else
    {
        
        cout << "cr_PeerTest_vldn not registered"<< endl;
       
    }
   return 0;
}

//extern int tm_CR_validation_register_method(int *decision, va_list args)
//{
//
//   //added by Amol
//
//    if (ITK_ok == EPM_register_rule_handler("cr_signoff_checks_Func", "This Handler is used to display message", (EPM_rule_handler_t)cr_signoff_checks_Func))
//    {
//        
//        cout << "cr_signoff_checks_Func registered"<< endl;
//        
//    }
//    else
//    {
//        
//        cout << "cr_signoff_checks_Func not registered"<< endl;
//       
//    }
//  return 0;
//}

extern "C" DLLAPI int tm_CR_Creation_register_callbacks()
{
    cout << "Before registered function in CR Workflow"<< endl;
    CUSTOM_register_exit("tm_CR_Creation", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_CR_Creation_register_method);
    cout << "registered function tm_CR_Creation"<< endl;
    return 0;
}