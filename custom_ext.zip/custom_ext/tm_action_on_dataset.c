/********************************************************************************************************
*  File			: action_on_dataset.c
*  Created By	: Prachi Wade
*  Created On	: 09-May-2011
*  Project		: TCUA
*  Purpose		: Custom user exit for - checkout,checkin and cancelcheckout of an item alongwith dataset
*  Arguments	:

*  Modification History :
*  S.No    Date     CR      Modified By         Modification Notes
*1             01/09/2011    Anil Gautam		setting mod desc null after checkout the design object.
*2           10/11/2012	Sharvari Karale	Handled checkin/checkout and save process for PROE datasets .
*3           04/05/2016	Deepti Meshram	Handled single release status while doing checkin/checkout of Design Revision .
*4           19/10/2016	Muktesh	Cancel Checkout and closed BOM window.
*5			 13/01/2018		Upendra Patil		Validation on checkIn for CATIA dataset attachment based on part type.
*6			 14/01/2019		Paridhi Sharma		Functionality to show latest reference Drawing.
*7			 30/10/2021		Tushar Rasane		Add DVA Validation on Module Check IN.
*8			 18/12/2021		Tushar Rasane		Add QA attributes Validation on Module Check IN.
*9			 01/02/2022		Tushar Rasane		New DFQ Document Attribute "DVA Cpk Value" to be added on DFQ Document.
*10 		 08/07/2023		Alokesh Ghosh		check in the standard part generic, its latest generic revision should be auto replaced in all of its existing instances “generic relation” (instance to generic relation)
********************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h> //MBOM implementation for CV TZ-1.70
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>

#include <tccore/aom_prop.h>
#include <cfm/cfm.h>
#include <fclasses/tc_date.h>

//#include <epm/cr_effectivity.h>
//#include <itk/mem.h>
//#include <sa/imanfile.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>




#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define EXIT_IF_NULL(X) (check_value(#X, (X)))
//PrintErrorStack();

#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errErr (EMH_USER_error_base + 99)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "\n Error(PrintErrorStack): ");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void  GetPlantWiseAPLBomInfort( char* APlPltNm ,char  BVRInfo[40],char  RRInfo[40],char  CRInfo[40],char RelStInfo[40]) //Deepti TZ1.55
{
		char*			Dsgn_No				= NULL;
		char*			PLT_Code			= NULL;
		char*			item_id			= NULL;


		char  ItemIDCpy[40];

		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

		int cntrlcnt=0;
		int  control_number_found1=0;

		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

		tag_t   qryTagCntrl1     = NULLTAG;
		int     n_entryCntrl1    = 3;

		char *bvr			= NULL;
		char *RevisionRule			= NULL;
		char *ClosurRule			= NULL;
		char *aplRlzState			= NULL;

		printf("\n APlPltNm is : %s\n",APlPltNm);fflush(stdout);

		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="APLBVRInfCheckin";
			qry_valuesCntrl1[1]=APlPltNm;
			qry_valuesCntrl1[2]="0";

			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found \n");fflush(stdout);
		}	

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

		if(control_number_found1>0)
		{

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &bvr);
			printf("\n bvr: %s\n",bvr);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &RevisionRule);
			printf("\n RevisionRule: %s\n",RevisionRule);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &ClosurRule);
			printf("\n ClosurRule: %s\n",ClosurRule);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &aplRlzState);
			printf("\n aplRlzState: %s\n",aplRlzState);fflush(stdout);

			tc_strcpy(BVRInfo,bvr);
			tc_strcpy(RRInfo,RevisionRule);
			tc_strcpy(CRInfo,ClosurRule);
			tc_strcpy(RelStInfo,aplRlzState);
		}
		else
		{
			tc_strcpy(BVRInfo,"APLC View");
			tc_strcpy(RRInfo,"ERC release and above APLC");
			tc_strcpy(CRInfo,"BOMViewClosureRuleAPLC");
			tc_strcpy(RelStInfo,"APLC Released");
		}



		printf( "hi BVRInfo:%s\n", BVRInfo);fflush(stdout);
		printf( "hi RRInfo:%s\n", RRInfo);fflush(stdout);
		printf( "hi CRInfo:%s\n", CRInfo);fflush(stdout);
		printf( "hi RelStInfo:%s\n", RelStInfo);fflush(stdout);

}
;
void setAddStr1(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}
;
static int t5UpdateLifecycleStateAD(tag_t object_tag, char* lifecycleStateName)
{
	int n_values_checkin = 0;
	int cunt1 = 0;
	int ifail=0;

	char *class_name = NULL;

	tag_t		class_id				=     NULLTAG;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	tag_t			status_rel					= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical			retain							= 0;

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n t5UpdateLifecycleStateAD--class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" t5UpdateLifecycleStateAD--Load Success\n " );
	}
	else
	printf(" t5UpdateLifecycleStateAD--Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n t5UpdateLifecycleStateAD--n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n t5UpdateLifecycleStateAD--n_values11 is :%d\n",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n t5UpdateLifecycleStateAD--Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);

			CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
			printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

			CALLAPI(POM_save_instances(1,&object_tag,1));

			CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

			CALLAPI(AOM_lock(object_tag));

			CALLAPI(AOM_save_without_extensions(object_tag));
			CALLAPI(AOM_refresh(object_tag,1));
		}

		 CALLAPI(AOM_unlock(object_tag));
	}

	if (RELSTAT_create_release_status(lifecycleStateName,&status_rel)!=ITK_ok) PrintErrorStack();
	if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();

	return 0;
}

//MBOM implementation for CV TZ-1.69  Start
void  get_CtrlVal_RelStateChkInf( char * Plt_Code ,char  RevwLC[40],char RevwLCActVal[40],char  WrkngLC[40],char  WrkngLCActVal[40],char RlzdLC[40],char  RlzdLCActVal[40],char View[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevwVal 			= NULL;
	 char *WrkngVal			= NULL;
	 char *RlzdVal			= NULL;	
	 char *BvrVal			= NULL;
	 char *RevwActVal		= NULL;
	 char *WrkngActVal	= NULL;
	 char *RlzdActVal		= NULL;

	printf("\n Inside get_CtrlVal_RelStateChkInf Plt_Code:%s",Plt_Code);fflush(stdout);
 
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n get_CtrlVal_RelStateChkInf--Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="ReleaseStateInf";
		qry_valuesCntrl1[1]=Plt_Code;
		qry_valuesCntrl1[2]="0";

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n get_CtrlVal_RelStateChkInf--Control Object Query not Found \n");fflush(stdout);
	}	
			
	printf("\n get_CtrlVal_RelStateChkInf--control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevwVal);
		printf("\n get_CtrlVal_RelStateChkInf--RevwVal: %s\n",RevwVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &WrkngVal);
		printf("\n get_CtrlVal_RelStateChkInf--WrkngVal: %s\n",WrkngVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &RlzdVal);
		printf("\n get_CtrlVal_RelStateChkInf--RlzdVal: %s\n",RlzdVal);fflush(stdout);
		
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &BvrVal);
		printf("\n get_CtrlVal_RelStateChkInf--BvrVal: %s\n",BvrVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &RevwActVal);
		printf("\n get_CtrlVal_RelStateChkInf--RevwActVal: %s\n",RevwActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &WrkngActVal);
		printf("\n get_CtrlVal_RelStateChkInf--WrkngActVal: %s\n",WrkngActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &RlzdActVal);
		printf("\n get_CtrlVal_RelStateChkInf--RlzdActVal: %s\n",RlzdActVal);fflush(stdout);
					
		if(tc_strlen(RevwVal)>0) 
		{ 
			tc_strcpy(RevwLC,RevwVal);
		}
		if(tc_strlen(WrkngVal)>0) 
		{ 
			tc_strcpy(WrkngLC,WrkngVal);
		}
		if(tc_strlen(RlzdVal)>0) 				
		{
			tc_strcpy(RlzdLC,RlzdVal);
		}
		
		if(tc_strlen(BvrVal)>0) 
		{
			tc_strcpy(View,BvrVal);
		}
		if(tc_strlen(RevwActVal)>0) 
		{
			tc_strcpy(RevwLCActVal,RevwActVal);
		}
		if(tc_strlen(WrkngActVal)>0) 
		{
			tc_strcpy(WrkngLCActVal,WrkngActVal);
			printf("\n get_CtrlVal_RelStateChkInf--WrkngLCActVal: %s,WrkngActVal:%s\n",WrkngLCActVal,WrkngActVal);fflush(stdout);
		}
		if(tc_strlen(RlzdActVal)>0) 
		{
			tc_strcpy(RlzdLCActVal,RlzdActVal);
			printf("\n get_CtrlVal_RelStateChkInf--RlzdActVal: %s,RlzdLCActVal:%s\n",RlzdActVal,RlzdLCActVal);fflush(stdout);
		}

		printf("\n get_CtrlVal_RelStateChkInf--New get_CtrlVal_RelStateChkInf WrkngLCActVal: %s,RlzdLCActVal:%s\n",WrkngLCActVal,RlzdLCActVal);fflush(stdout);		
	}
}
//MBOM implementation for CV TZ-1.69  End

//CATIA and PRO/E Specific Validation on Dataset to check whether Named Reference relationship file contains Physical File.
//Pro/E Specific Validation to
static int t5CheckForEmptyNamedRef(tag_t dataset, char* ObjectClassType, char* reference_name, tag_t namedRefTag)
{
	int ifail=0;
	int i = 0;
	int instFlagInt = 0;
	int gen_found = 0;
	char *prevVerFileExt = NULL;
	char *prevVerFileExtDup = NULL;
	char *currentVerFileExt = NULL;
	char *currentVerFileExtDup = NULL;
		 
	char *prevRevOrigFileNameDup = NULL;
	char *prevRevOrigFileName = NULL;
	char *CurrentRevOrigFileNameDup = NULL;
	char *CurrentRevOrigFileName = NULL;

	tag_t referenced_object = NULLTAG;
	tag_t *generic_tagS = NULLTAG;

	AE_reference_type_t my_ref_type;

	printf("\n t5CheckForEmptyNamedRef-->Inside Function\n"); fflush(stdout);

	CALLAPI(AE_ask_dataset_named_ref2(dataset, reference_name, &my_ref_type, &referenced_object));

	if(referenced_object == NULLTAG)
	{
		if(tc_strcmp(ObjectClassType,"ProAsm") == 0 || tc_strcmp(ObjectClassType,"ProPrt") == 0)
		{
			//CALLAPI(AOM_get_value_tags(dataset,"IPEM_master_dependency",&gen_found,&generic_tagS)); //commented on 10.09.2024 for TCUA 14.3
			CALLAPI(AOM_ask_value_tags(dataset,"IPEM_master_dependency",&gen_found,&generic_tagS)); //Replaced API on 10.09.2024 for TCUA 14.3
			printf("\n t5CheckForEmptyNamedRef-->Generic Count is %d",gen_found);fflush(stdout);
			if (gen_found>0)
			{
				instFlagInt = 1;
			}
		}
	}

	printf("\nValue of instFlagInt -- %d", instFlagInt);fflush(stdout);
	if(instFlagInt == 0)
	{
		if(referenced_object == NULLTAG)
		{
			printf("\n*** t5CheckForEmptyNamedRef :: WARNING :: No CAD File attached to Dataset in the Named Reference Relationship ***\n");
			EMH_store_error_s1(EMH_severity_error,ITK_err,"No CAD File attached to Dataset in the Named Reference Relationship. \nTo Verify :: RIGHT CLICK Dataset --> NAMED REFERENCES");
			printf("\nt5CheckForEmptyNamedRef :: 1 Exiting Function\n");fflush(stdout);
			return ITK_err;
		}
		else
		{
			if(namedRefTag)
			{
				if(AOM_ask_value_string(namedRefTag,"file_ext",&prevVerFileExtDup)!=ITK_ok) PrintErrorStack();
				if(prevVerFileExtDup) tc_strdup(prevVerFileExtDup, &prevVerFileExt);

				if(AOM_ask_value_string(referenced_object,"file_ext",&currentVerFileExtDup)!=ITK_ok) PrintErrorStack();
				if(currentVerFileExtDup) tc_strdup(currentVerFileExtDup, &currentVerFileExt);

				printf("\nt5CheckForEmptyNamedRef :: CurrentRev File Ext -- %s || PreviousRev File Ext -- %s\n", currentVerFileExt, prevVerFileExt);fflush(stdout);
				if(atoi(currentVerFileExt) > atoi(prevVerFileExt))
				{
					printf("\nt5CheckForEmptyNamedRef :: Allow to Checkin\n");
				}
				else
				{
					if(AOM_ask_value_string(namedRefTag,"original_file_name",&prevRevOrigFileNameDup)!=ITK_ok) PrintErrorStack();
					if(prevRevOrigFileNameDup) tc_strdup(prevRevOrigFileNameDup, &prevRevOrigFileName);

					if(AOM_ask_value_string(referenced_object,"original_file_name",&CurrentRevOrigFileNameDup)!=ITK_ok) PrintErrorStack();
					if(CurrentRevOrigFileNameDup) tc_strdup(CurrentRevOrigFileNameDup, &CurrentRevOrigFileName);

					printf("\n*** t5CheckForEmptyNamedRef :: ERROR :: The File Extension of dataset [Named References] attached to Current Design Revision [%s] should be greater than dataset [Named References] attached to Previous Design Revision [%s]  ***\n", CurrentRevOrigFileName, prevRevOrigFileName);
					EMH_store_error_s3(EMH_severity_error,ITK_err,"The File Extension of dataset [Named References] attached to Current Design Revision should be greater than dataset [Named References] attached to Previous Design Revision. \nTo Verify :: RIGHT CLICK %s Dataset --> NAMED REFERENCES",CurrentRevOrigFileName, prevRevOrigFileName);
					printf("\nt5CheckForEmptyNamedRef :: 2 Exiting Function\n");fflush(stdout);
					return ITK_err;
				}
			}
			else
			{
				printf("\n*** t5CheckForEmptyNamedRef :: WARNING :: Ignoring the Validation as previous revision Named Reference is NULL ***\n");
			}
		}
	}

	printf("\nt5CheckForEmptyNamedRef :: 3 Exiting Function\n");fflush(stdout);
	return 0;
}

//check and update latest reference drawing
static int t5ChkLatestRefDrg(tag_t rev)
{
	//tag_t item;
	int	ifail=0;
	tag_t *secondary_objects,*rev_secondary_objects;
	tag_t  relation_type = NULLTAG;
	tag_t  rev_relation_type = NULLTAG;
	tag_t  relation_tag = NULLTAG;
	tag_t  new_relation = NULLTAG;
	tag_t  ref_part_no = NULLTAG;
	tag_t  rev_ref_part_no = NULLTAG;
	char *r_name= NULL,*object_type= NULL,*rev_secondary_objects_chname,*chname= NULL,*rev_object_type;
	int count2,s,p,count_rev;
	char *token;

	if(rev)
	{
		CALLAPI(WSOM_ask_name2(rev,&r_name));
		printf("\nt5ChkLatestRefDrg:r_name ---->%s",r_name); fflush(stdout);

		CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type));
		printf("\nt5ChkLatestRefDrg:Here"); fflush(stdout);

		if(relation_type)
		{
			CALLAPI(GRM_list_secondary_objects_only(rev,relation_type,&count2,&secondary_objects));
			printf("\nt5ChkLatestRefDrg:count2 %d",count2);fflush(stdout);
			if (count2 >0)
			{
				for(s=0;s<count2;s++)
				{
					if(secondary_objects[s])
					{
						CALLAPI( WSOM_ask_object_type2(secondary_objects[s],&object_type));
						CALLAPI(AOM_UIF_ask_value(secondary_objects[s],"object_string",&chname));
						printf("\nt5ChkLatestRefDrg:String name=%s",chname);
						printf("\tobject_type =%s\n",object_type);

						printf("\n\tt5ChkLatestRefDrg: %s found in Reference Relation %s Revision\n",object_type,chname);

						token = strtok(chname,"/");
						printf("\nt5ChkLatestRefDrg:token->%s",token);
						CALLAPI(ITEM_find_item(token,&ref_part_no));
						if(ref_part_no)
						{
						CALLAPI(ITEM_ask_latest_rev(ref_part_no,&rev_ref_part_no));
						if(rev_ref_part_no)
							{
							CALLAPI(GRM_find_relation_type("IMAN_specification",&rev_relation_type));
							if(rev_relation_type)
								{
								CALLAPI(GRM_list_secondary_objects_only(rev_ref_part_no,rev_relation_type,&count_rev,&rev_secondary_objects));
								printf("\nt5ChkLatestRefDrg:count_rev %d",count_rev);
								if (count_rev>0)
									{
										for(p=0;p<count_rev;p++)
										{ 
											CALLAPI(WSOM_ask_object_type2(rev_secondary_objects[p],&rev_object_type));
											CALLAPI(AOM_UIF_ask_value(rev_secondary_objects[p],"object_string",&rev_secondary_objects_chname));
											printf("t5ChkLatestRefDrg:rev_secondary_objects_chname=%s\n",rev_secondary_objects_chname);
											printf("t5ChkLatestRefDrg:rev_object_type =%s\n",rev_object_type);
											if((strcmp(rev_object_type,object_type)==0))
											{
											printf("\nt5ChkLatestRefDrg:Matched\n");
											CALLAPI(GRM_find_relation(rev, secondary_objects[s], relation_type, &relation_tag));
											if(relation_tag)
												{
												CALLAPI(GRM_delete_relation(relation_tag));
												CALLAPI(GRM_create_relation(rev,rev_secondary_objects[p],relation_type,NULLTAG,&new_relation));
												if(new_relation)
													{
													CALLAPI(GRM_save_relation(new_relation));
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
//check and update latest reference drawing end

// check milestone live project START
int CheckMilestoneLive(char* sProject)
{
	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t     *MilstonCntrlObjectTag                = NULLTAG;
	tag_t     MilestoneqryTag                              = NULLTAG;
	char    *Milston_qry_entry[1]  = {"SYSCD"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*     Milstoninfo1 = NULL;
	char*     Milstoninfo2 = NULL;

	printf("\n P: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n CheckMilestoneLive--P1:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n CheckMilestoneLive--P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = "Milston";
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n CheckMilestoneLive--P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok) PrintErrorStack();
		printf("\n CheckMilestoneLive--P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok) PrintErrorStack();
		printf("\n CheckMilestoneLive--P4:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

		if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		{
			printf("\n CheckMilestoneLive--P: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n CheckMilestoneLive--P: It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 0;
		}
	
		return 0;               
	}
}
// check milestone live project END

// Validate DR-MileStone START
int tm_PreviousRev_Milestone_Validate(tag_t rev_tag, char* value)
{	
	int     count1    = 0;
	int     iij    = 0;
	char*     rev_id = NULL;
	char*     rev_num = NULL;
	char*     rell_status = NULL;
	char*     ML_Staus = NULL;
	tag_t 	*rev_listt 	= NULL;
	tag_t 	Partrev 	= NULLTAG;
	tag_t 	ITEM_tag 	= NULLTAG;

	if(AOM_ask_value_tag(rev_tag,"items_tag",&ITEM_tag)!=ITK_ok) PrintErrorStack(); 
	
	if (ITEM_tag==NULLTAG)
	{
		printf("\n tm_PreviousRev_Milestone_Validate ITEM not found \n");fflush(stdout);
		return 0;
	}
		if(ITEM_list_all_revs(ITEM_tag, &count1, &rev_listt)!=ITK_ok) PrintErrorStack();
		if(count1 > 0)
		{
			iij=0;
			for(iij=count1-1;iij>=0;iij--)
			{
				printf("\n tm_PreviousRev_Milestone_Validate--Total rev rev_listt: %d.", count1);fflush(stdout);
				Partrev = rev_listt[iij];
				 
				if(AOM_UIF_ask_value(Partrev,"item_id", &rev_num)!=ITK_ok) PrintErrorStack();
				if(AOM_UIF_ask_value(Partrev,"item_revision_id", &rev_id)!=ITK_ok) PrintErrorStack();
				if (AOM_UIF_ask_value(Partrev,"release_status_list", &rell_status)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(Partrev,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();

				printf("\n tm_PreviousRev_Milestone_Validate--rev_id:%s and rell_status:%s", rev_id,rell_status);fflush(stdout);
				if(tc_strstr(rell_status, "ERC Released") !=NULL && tc_strcmp(value,ML_Staus)==0)
				{
					printf("\n tm_PreviousRev_Milestone_Validate--for %s %s  milestone %s ",rev_num,rev_id,ML_Staus);fflush(stdout);
					return 1;
				}
			}
		}
		return 0;
}
int tm_Validate_DR_Milestone_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *DRinfo4 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

	printf("\n tm_Validate_DR_Milestone_OnPart--Project stamped is : %s\n",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n tm_Validate_DR_Milestone_OnPart--P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n tm_Validate_DR_Milestone_OnPart--project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n tm_Validate_DR_Milestone_OnPart--CREVali:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n tm_Validate_DR_Milestone_OnPart--CREVali:Not Found Query ControlObjects \n");fflush(stdout);
		}

		qry_values2[0] = "CREVali";
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n tm_Validate_DR_Milestone_OnPart--CREVali:rsltCount 44:%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{
			if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok) PrintErrorStack();

			printf("\n tm_Validate_DR_Milestone_OnPart--CREVali:DRinfo4:%s",DRinfo4);fflush(stdout);
		}
		if(tc_strstr(DRinfo4,"AHCHK1")==NULL)
		{
			/*UNV0        corresponds to DR1
			UNV1      corresponds to DR1
			Pre-UPV0       corresponds to DR1
			UNV2           corresponds to DR2
			UPV0           corresponds to DR2
			UNV3          corresponds to DR2
			UPV1           corresponds to DR2
			UPV2                corresponds to DR2
			UPV3            corresponds to DR3*/

			printf("\n tm_Validate_DR_Milestone_OnPart--here0 ");fflush(stdout);			
			if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			printf("\n tm_Validate_DR_Milestone_OnPart--PrtDR: [%s] ML_Staus:[%s] REV [%s] \n",PrtDR,ML_Staus,desRev);fflush(stdout);
			if (tc_strcmp(ML_Staus,"")==0)
			{

				flag=1;
				return flag;
				/*EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
				return ITK_err;*/
			}
			if(tc_strstr(desRev,"NR")!=NULL)
			//if (tc_strcmp(desRev,"NR")==0)
			{
				// Check the initial value from controm object for initial value
				int     Milston_rsltCount    = 0;
				int     Milston_n_entry    = 1;
				tag_t     *MilstonCntrlObjectTag                = NULLTAG;
				tag_t     MilestoneqryTag                              = NULLTAG;
				char    *Milston_qry_entry[1]  = {"SYSCD"};
				char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
				char*     Milstoninfo4 = NULL;

				printf("\n tm_Validate_DR_Milestone_OnPart--P: CheckMileston initial value for project\n");fflush(stdout);
				//GETTING mileston obj.
				if(QRY_find2("ControlObjects", &MilestoneqryTag));
				if (MilestoneqryTag)
				{
					printf("\n tm_Validate_DR_Milestone_OnPart--Query MilestoneqryTag \n");fflush(stdout);
				}
				else
				{
					printf("\n tm_Validate_DR_Milestone_OnPart--Not Found Query MilestoneqryTag \n");fflush(stdout);
				}

				Milston_qry_values2[0] = "Milston";
				if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
				printf(" \n tm_Validate_DR_Milestone_OnPart--P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
				if(Milston_rsltCount > 0)
				{
					if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo4",&Milstoninfo4)!=ITK_ok) PrintErrorStack();
					printf("\n tm_Validate_DR_Milestone_OnPart--P4:Milstoninfo4 is : [%s]\n", Milstoninfo4);fflush(stdout);
				}

				//
				if(tc_strstr(Milstoninfo4,ML_Staus) !=NULL)
				{
					printf("\n tm_Validate_DR_Milestone_OnPart--Milestone ok update DR Value  \n"); fflush(stdout);
					if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();

					if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0) 
					{ 
						//if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
					}
					if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					{
						//if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
					}
					if(tc_strcmp(ML_Staus,"UPV3")==0)
					{ 
						//if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
						if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
					}
					if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
					if(AOM_refresh(rev_tag,FALSE)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					printf("\n tm_Validate_DR_Milestone_OnPart--Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
				}
				
				else
				{	
					//error since info4 value and milestone is not matching
					/*EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
					return ITK_err;*/
					flag=5;
					return flag;
				}
			}
			else
			{
				printf("\n tm_Validate_DR_Milestone_OnPart--Milestone ok, update DR Value for other than NR  \n"); fflush(stdout);
				//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
				//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
				if (AOM_lock(rev_tag)!=ITK_ok) PrintErrorStack();
				
				if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0) 
				{ 
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
				}
				if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
				{
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
				}
				if(tc_strcmp(ML_Staus,"UPV3")==0)
				{ 
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
				}
				if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
				if(AOM_unlock(rev_tag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(rev_tag,0)!=ITK_ok) PrintErrorStack();

				if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
				printf("\n tm_Validate_DR_Milestone_OnPart--for non NR Milestone is [%s] and  Part DR is updated to [%s]  \n",ML_Staus,PrtDR);fflush(stdout);
			}
		}
	}
}
// Validate DR-MileStone END

//check and update latest reference drawing end
//**************************************************** Aashish_w ===> check and update latest reference drawing Start **********************************************************************
static int t5ChkLatestRefDrg_A(tag_t rev)
{

	printf("\n t5ChkLatestRefDrg_A--$ Welcome $ *************");	fflush(stdout);
	//tag_t item;
	int	ifail=0;
	tag_t *secondary_objects =NULLTAG;
	tag_t *rev_secondary_objects=NULLTAG;
	tag_t *prerev_secondary_objects=NULLTAG;
	tag_t *referencers=NULLTAG;
	tag_t  relation_type = NULLTAG;
	tag_t  rev_relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t  relation_tag = NULLTAG;
	tag_t  new_relation = NULLTAG;
	tag_t  ref_part_no = NULLTAG;
	tag_t  rev_ref_part_no = NULLTAG;
	char *r_name= NULL;
	char *pr_name= NULL;
	char *rfrnce_name = NULL;
	char *Reference_object_type= NULL;
	char *rev_secondary_objects_chname = NULL;
	char *chname= NULL;
	char *Specification_object_type = NULL;
	char *prerev_object_type = NULL;
	int count2=0;
	int s= 0 ;
	int count_rev=0;
	int count_prerev =0 ;
	int a=0;
	int p= 0;
	char *token;
	tag_t	item	=	NULLTAG;
	int  n_refs= 0;
	int  *levels = 0;
	int  cnt =0;
	char  **relations=NULL;
	//char  rev_id[ITEM_id_size_c+1];
	char *rev_id	=	NULL;
	tag_t *PartPreTags = NULLTAG;
	int   Pre_count=0;
	tag_t			AssyPreTag			= NULLTAG;

//find iman specification relation first..
CALLAPI(GRM_find_relation_type("IMAN_specification",&rev_relation_type));
	if(rev)
	{
		CALLAPI(WSOM_ask_name2(rev,&r_name));
		printf("\nt5ChkLatestRefDrg_A--********Revision_name ---->%s",r_name);	fflush(stdout);

		if(rev_relation_type)
		{
//then find secondary objects of our main chkin rev who have its own CMI2 Drawing in a specification relation...
			  CALLAPI(GRM_list_secondary_objects_only(rev,rev_relation_type,&count_rev,&rev_secondary_objects));

			printf("\nt5ChkLatestRefDrg_A--*********Count of Secondary object of main Revision ====> %d \n",count_rev); fflush(stdout);
			if (count_rev >0)
			{
				for(   p=0; p<count_rev; p++)
				{ 
					CALLAPI(WSOM_ask_object_type2(rev_secondary_objects[p],&Specification_object_type));
// if main rev secondary obj is CMI2Drawing then only go to loop and find previous rev...
					if( tc_strcmp ( Specification_object_type , "CMI2Drawing" ) == 0 )
			  {
//find previous revision of our main revision bcoz main rev dont have any referance with another reference part
					//find previous revision for reference
				GRM_find_relation_type("IMAN_based_on",&relation_type2);
					GRM_list_secondary_objects_only(rev,relation_type2,&Pre_count,&PartPreTags);
				if(Pre_count > 0)
				{
					AssyPreTag=PartPreTags[0];
					ITEM_ask_rev_id2 	( AssyPreTag, &rev_id);
					printf("\nt5ChkLatestRefDrg_A--******* Previous rev_id is  ---->%s\n", rev_id);fflush(stdout);//diplay the previous revision
//here we get previous rev of our chkin object..
// Then find CMI2 Drw of previous revision and find its references
					CALLAPI(GRM_list_secondary_objects_only(AssyPreTag,rev_relation_type,&count_prerev,&prerev_secondary_objects));
					printf("\nt5ChkLatestRefDrg_A--******** Secondary obj of previous revision count---->%d",count_prerev); fflush(stdout);
					if (count_prerev >0)
					{
						for(a=0;a<count_prerev;a++)
						{
							CALLAPI(WSOM_ask_object_type2(prerev_secondary_objects[a],&prerev_object_type));
							printf("\nt5ChkLatestRefDrg_A--********Object type of prev rev dataset ---->%s",prerev_object_type); fflush(stdout);
							if( tc_strcmp ( prerev_object_type , "CMI2Drawing" ) == 0 )
							  {
								printf("\n t5ChkLatestRefDrg_A--I am previous revison's CMI2Drawing\n");
//find referances of prev rev cmi2drawing.. 
								CALLAPI(WSOM_where_referenced2(prerev_secondary_objects[a], 1 ,&n_refs,&levels,&referencers,&relations));
									for (cnt=0;cnt<n_refs ;cnt++ )
									 {
									CALLAPI(WSOM_ask_name2(referencers[cnt],&rfrnce_name));
									if( tc_strcmp ( rfrnce_name , r_name ) != 0 )
										{
//here we get reference rev means our second rev who have first's rev's drawing in a reference relation
										printf("\n t5ChkLatestRefDrg_A--I am Referance revision\n");
										CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type));
										if(relation_type)
											{
												CALLAPI(GRM_list_secondary_objects_only(referencers[cnt],relation_type,&count2,&secondary_objects));
											if (count2 >0)
					{
//we get here all datasets of secondary rev...
												for(s=0;s<count2;s++)
													{
														printf("\n t5ChkLatestRefDrg_A--I am Referance Dataset\n");
														CALLAPI( WSOM_ask_object_type2(secondary_objects[s],&Reference_object_type));
//if object type of 1st dataset and second dataset matched [i.e. CMI2Drawing] then only delete the relation...
													if((strcmp(Specification_object_type,Reference_object_type)==0))
													{
														CALLAPI(AOM_UIF_ask_value(secondary_objects[s],"object_string",&chname));
														CALLAPI(GRM_find_relation(referencers[cnt], secondary_objects[s], relation_type, &relation_tag));
														printf("\n t5ChkLatestRefDrg_A--I am Delete Dataset\n");
														CALLAPI(GRM_delete_relation(relation_tag));
														 AOM_refresh (referencers[cnt], 1);
//create new relation of second rev with our new going to chkin rev Dataset...
														CALLAPI(GRM_create_relation(referencers[cnt],rev_secondary_objects[p],relation_type,NULLTAG,&new_relation));
														AOM_refresh (new_relation, 1);
														if(new_relation)
															{
															CALLAPI(GRM_save_relation(new_relation));
															AOM_refresh (referencers[cnt], 0);
															AOM_refresh (new_relation, 0);
															}
													}
													}
													MEM_free(secondary_objects);
					}
											}

										}
									}
									MEM_free(levels);
									MEM_free(referencers);
									MEM_free(relations);
							  }
						}	
						MEM_free(prerev_secondary_objects);
				}

			}
			  }
			}
			MEM_free(rev_secondary_objects);
		}
	}
		return 0;
}
}
//********************************************************* Aashish_w ===> check and update latest reference drawing End **********************************************************************************
//Check and update ref drg updated


//Check and update ref drg updated
static int t5ChkLatestRefDrg1(tag_t rev)
{
	int ifail = 0;
	tag_t item=NULLTAG,relation_type=NULLTAG,*secondary_objects,relation_tag,related_obj_item_tag,related_obj_latest_rev,*secondary_objects_rev,related_obj_item,new_relation,rev_tag=NULLTAG,*rev_secondary_objects,relation_type1=NULLTAG,tag_object_type;
	char *name,*chname,*related_obj_item_name,*related_obj_latest_rev_name,*object_type_rev,*chname_rev,*token,*rev_id,*id_token,count_id=1,*rev_rev_id,*seq_rev_id,*new_rev_id,*rev_object_type,*rev_chname;
	int count=0,s,count_all=0,i,j,count2,rev_count,rev_s;
	GRM_relation_t * related_object_list	;
	tag_t objTypeTag = NULLTAG;
	//char object_type[TCTYPE_name_size_c+1];
	char *object_type	=	NULL;

		CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type1));

	if(rev)
	{
		CALLAPI(ITEM_ask_item_of_rev(rev,&item)); 
		if (item) 
		{
			CALLAPI(GRM_list_secondary_objects_only(rev,NULLTAG,&count,&secondary_objects));
			printf("\n t5ChkLatestRefDrg1--paridhi count [%d]",count);fflush(stdout);
			if(count>0)
			{
				for(s=0;s<count;s++)
				{
					if(secondary_objects[s])
					{
						printf("\n t5ChkLatestRefDrg1--********s is=%d",s);fflush(stdout);
						//CALLAPI(WSOM_ask_object_type2(secondary_objects[s],&object_type));
						CALLAPI(TCTYPE_ask_object_type(secondary_objects[s],&objTypeTag));
						CALLAPI(TCTYPE_ask_name2(objTypeTag,&object_type));

						CALLAPI(AOM_UIF_ask_value(secondary_objects[s],"object_string",&chname));
						printf("\n t5ChkLatestRefDrg1--String name=%s",chname);fflush(stdout);
						printf("\tobject_type =%s\n",object_type);fflush(stdout);
						if((strcmp(object_type,"PDF")==0) || (strcmp(object_type,"CMI2Drawing")==0) )
						{
							CALLAPI(AOM_UIF_ask_value(rev,"item_revision_id",&rev_id));
							printf("\n t5ChkLatestRefDrg1--latest_rev ---->%s",rev_id); fflush(stdout);
							id_token = strtok(rev_id,";");
							while (id_token != NULL) 
							{
								printf("\n t5ChkLatestRefDrg1--latest_rev ---->%s",id_token); fflush(stdout);
								if(count_id==1)
								{
									rev_rev_id = (char *) MEM_alloc( 5 * sizeof(char) );
									tc_strcpy(rev_rev_id,id_token);
								}
								else if (count_id==2)
								{
									seq_rev_id = (char *) MEM_alloc( 5 * sizeof(char) );
									tc_strcpy(seq_rev_id,id_token);
								}
								id_token = strtok(NULL, ";");
								count_id++;
							}

		//find previous rev
							int x =(atoi(seq_rev_id) -1);
							printf("\n  t5ChkLatestRefDrg1--x [%d]", x);fflush(stdout);
							if(x>=1)
							{
								printf("\n  t5ChkLatestRefDrg1--[%s]", new_rev_id);fflush(stdout);
								new_rev_id = (char *) MEM_alloc( 5 * sizeof(char) );
								sprintf(new_rev_id,"%s;%d", rev_rev_id, x);
								printf("\n  t5ChkLatestRefDrg1--[%s]", new_rev_id);fflush(stdout);
								CALLAPI(ITEM_find_revision(item,new_rev_id,&rev_tag));
								if(rev_tag)
								{
									CALLAPI(GRM_list_secondary_objects_only(rev_tag,NULLTAG,&rev_count,&rev_secondary_objects));
									printf("\n t5ChkLatestRefDrg1--rev_count [%d]",rev_count);fflush(stdout);
									if(rev_count>0)
									{
										for(rev_s=0;rev_s<rev_count;rev_s++)
										{
											if(rev_secondary_objects[rev_s])
											{
												CALLAPI(WSOM_ask_object_type2(rev_secondary_objects[rev_s],&rev_object_type));
												CALLAPI(AOM_UIF_ask_value(rev_secondary_objects[rev_s],"object_string",&rev_chname));
												printf("\n t5ChkLatestRefDrg1--rev_chname name=%s",rev_chname);fflush(stdout);
												printf("\trev_object_type =%s\n",rev_object_type);fflush(stdout);
												if((strcmp(rev_object_type,"PDF")==0) || (strcmp(rev_object_type,"CMI2Drawing")==0))
												{
													CALLAPI(GRM_list_all_related_objects(rev_secondary_objects[rev_s],&count_all,&related_object_list));
													printf("\ncount_all [%d]",count_all);fflush(stdout);
													if(count_all>0)
													{
														for(i=0;i<count_all;i++)
														{
															related_obj_item_tag = related_object_list[i].primary;
															CALLAPI(AOM_UIF_ask_value(related_obj_item_tag,"item_id",&related_obj_item_name));
															printf("*****\n\nrelated_obj_item_name=[%s]********name[%s]",related_obj_item_name,name);fflush(stdout);
															if(strcmp(related_obj_item_name,name)!=0)
															{
																printf("\nsecondary_tag_name=%s",related_obj_item_name);fflush(stdout);
																CALLAPI(ITEM_find_item(related_obj_item_name,&related_obj_item));
																if(related_obj_item)
																{
																	CALLAPI(ITEM_ask_latest_rev(related_obj_item,&related_obj_latest_rev)); 
																	if(related_obj_latest_rev)
																	{
																		CALLAPI(WSOM_ask_name2(related_obj_latest_rev,&related_obj_latest_rev_name));
																		printf("\nrelated_obj_latest_rev_name ---->%s",related_obj_latest_rev_name); fflush(stdout);
																		CALLAPI(GRM_list_secondary_objects_only(related_obj_latest_rev,NULLTAG,&count2,&secondary_objects_rev));
																		printf("\ncount [%d]",count2);fflush(stdout);
																		if(count2>0)
																		{
																			for(j=0;j<count2;j++)
																			{
																				if(secondary_objects_rev[j])
																				{
																					CALLAPI( WSOM_ask_object_type2(secondary_objects_rev[j],&object_type_rev));
																					CALLAPI(AOM_UIF_ask_value(secondary_objects_rev[j],"object_name",&chname_rev));
																					printf("\nt5ChkLatestRefDrg:String name=%s",chname_rev);fflush(stdout);
																					printf("\tobject_type =%s\n",object_type_rev);fflush(stdout);
																					token = strtok(chname_rev,"/");
																					if((strcmp(object_type_rev,"PDF")==0) && (strcmp(token,name)==0))
																					{
																						printf("\nmatched  =%s\n",object_type_rev);fflush(stdout);
																						if(relation_type )
																						{
																							CALLAPI(GRM_find_relation(related_obj_latest_rev, secondary_objects_rev[j], relation_type, &relation_tag)); //need to check
																							if(relation_tag)
																							{
																								CALLAPI(GRM_delete_relation(relation_tag));
																								CALLAPI(GRM_create_relation(related_obj_latest_rev,secondary_objects[s],relation_type,NULLTAG,&new_relation));
																								if(new_relation )
																								{
																									CALLAPI(GRM_save_relation(new_relation));
																								}
																							}
																						}
																					}
																					else 	if((strcmp(object_type_rev,"CMI2Drawing")==0)&& (strcmp(token,name)==0))
																					{
																						printf("\nmatched  =%s\n",object_type_rev);fflush(stdout);
																						if(relation_type1 )
																						{
																							CALLAPI(GRM_find_relation(related_obj_latest_rev, secondary_objects_rev[j], relation_type1, &relation_tag)); //need to check
																							if(relation_tag)
																							{
																								CALLAPI(GRM_delete_relation(relation_tag));
																								CALLAPI(GRM_create_relation(related_obj_latest_rev,secondary_objects[s],relation_type1,NULLTAG,&new_relation));
																								CALLAPI(GRM_save_relation(new_relation));
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
							else
							{
								printf("\n x is 0");fflush(stdout);
							}
						}
					}
				}
			}
		}
	}

		return 0;
}
//Check and update ref drg updated

//DATASET Validation on Check-In
static int t5ValDataset(tag_t object_tag)
{
	int				ifail=0;
	int cnt = 0;
	int cnt1 = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int seqInt = 0;
	//char			relation_name[TCTYPE_name_size_c+1];
	//char			ObjectClassType1[TCTYPE_name_size_c+1];
	//char			ObjectClassType[TCTYPE_name_size_c+1];
	char		   *seqS		= NULL;
	char		   *revS		= NULL;
	char		   *RevSeq		= NULL;
	char		   *ObjectClassType		= NULL;
	char		   *reference_name		= NULL;
	char		   *reference_name1		= NULL;
	char		   *ObjectClassType1		= NULL;
	char *revSeq = NULL;
	char *revSeqDup = NULL;
	char *item_idDup = NULL;
	char *item_id = NULL;
	char *relation_name = NULL;

	tag_t  relation_type = NULLTAG;
	tag_t  objTypeTag = NULLTAG;
	tag_t  dataset = NULLTAG;
	tag_t  dataset1 = NULLTAG;
	tag_t*  attachments = NULLTAG;
	tag_t*  attachments1 = NULLTAG;
	tag_t  tagProPrt = NULLTAG;
	tag_t  tagProAsm = NULLTAG;
	tag_t  tagProDrw = NULLTAG;
	tag_t  rev_tag = NULLTAG;

	AE_reference_type_t my_ref_type;

	printf("\nt5ValDataset :: Inside Function t5ValDataset ");

	if(AOM_ask_value_string(object_tag,"item_revision_id",&revSeqDup)!=ITK_ok) PrintErrorStack();
	if(revSeqDup) tc_strdup(revSeqDup, &revSeq);

	if(AOM_ask_value_string(object_tag,"item_id",&item_idDup)!=ITK_ok) PrintErrorStack();
	if(item_idDup) tc_strdup(item_idDup, &item_id);
	printf("\nt5ValDataset :: Item_ID == %s :: RevSeq == %s ", item_id, revSeq);fflush(stdout);

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if(relation_type)
	{
		CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
		printf("\n t5ValDataset::Relation Type Name: %s ",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n t5ValDataset::Attached Datasets 1: %d ",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
			printf("\nt5ValDataset::Dataset Loop 1 ");
			dataset = attachments[i];

			if (TCTYPE_ask_object_type(dataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(objTypeTag,&ObjectClassType)!=ITK_ok) PrintErrorStack();
			printf("\nt5ValDataset::ObjectClassType 1:: %s ", ObjectClassType);fflush(stdout);

			if(tc_strcmp(ObjectClassType,"ProAsm") == 0 || tc_strcmp(ObjectClassType,"ProPrt") == 0 || tc_strcmp(ObjectClassType,"ProDrw") == 0)
			{
				if(tc_strcmp(revSeq,"NR;1") != 0 && tc_strstr(revSeq,";") != NULL)
				{
					revS = tc_strtok ( revSeq,";") ;
					seqS = tc_strtok ( NULL,";") ;
					printf("\nt5ValDataset::Revision -- %s :: Sequenc is -- %s ", revS, seqS);

					seqInt = atoi(seqS);
					printf("\nt5ValDataset::After Integer Conversion Sequenc of the Object is -- %d ", seqInt);fflush(stdout);

					if(seqInt > 1)
					{
						seqInt = seqInt - 1;
						RevSeq=(char *) MEM_alloc(10);
						sprintf(RevSeq,"%s;%d", revS, seqInt);
						printf("\nt5ValDataset:: Previous RevSeq -- %s", RevSeq);fflush(stdout);

						CALLAPI(ITEM_find_rev(item_id,RevSeq,&rev_tag));
						if(rev_tag)
						{
							CALLAPI(GRM_list_secondary_objects_only(rev_tag,relation_type,&cnt1,&attachments1));
							printf("\nt5ValDataset::Attached Datasets on prev. rev.= %d ",cnt1);fflush(stdout);
							for(j=0;j<cnt1;j++)
							{
								printf("\n t5ValDataset::Inside for loop of dataset [%d] ",j);fflush(stdout);
								dataset1 = attachments1[j];
								if (TCTYPE_ask_object_type(dataset1,&objTypeTag)!=ITK_ok) PrintErrorStack();
								if(objTypeTag)
								{
									if (TCTYPE_ask_name2(objTypeTag,&ObjectClassType1)!=ITK_ok) PrintErrorStack();
								}
								printf("\t ObjectClassType 2:: %s", ObjectClassType1);

								if(tc_strcmp(ObjectClassType1,"ProAsm") == 0)
								{
									printf("\n t5ValDataset:: Inside if class is ProAsm ");fflush(stdout);
									if(tagProAsm == NULLTAG)
									{
										printf("\n t5ValDataset:: Before calling API AE_ask_dataset_named_ref2 ");fflush(stdout);
										if (dataset1)
										{
											printf("\n t5ValDataset:: before calling API AE_ask_dataset_named_ref2 if dataset1 is found ");fflush(stdout);
											//CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "AsmFile", &my_ref_type, &tagProAsm));
											CALLAPI(AE_ask_dataset_named_ref2(dataset1,"AsmFile", &my_ref_type, &tagProAsm));  //Ak 03-12-2024
											printf("\n t5ValDataset:: After calling API AE_ask_dataset_named_ref2 for ProAsm ---AA ");fflush(stdout);
										}
										else
										{
											printf("\n t5ValDataset:: if proasm dataset1 not found AA ");fflush(stdout);
										}
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Assembly Attached to Previous Design Revision [%s-%s]. *** ", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Assembly Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 1 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s  ", item_id, revSeq);
										return ITK_err;
									}
								}
								else if(tc_strcmp(ObjectClassType1,"ProPrt") == 0)
								{
									printf("\n t5ValDataset:: Inside if class is ProPrt ");fflush(stdout);
									if(tagProPrt == NULLTAG)
									{
										printf("\n t5ValDataset:: 1: Before calling API AE_ask_dataset_named_ref2 ");fflush(stdout);
										CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "PrtFile", &my_ref_type, &tagProPrt));
										printf("\n t5ValDataset:: After calling API AE_ask_dataset_named_ref2 for ProPrt ---AA ");fflush(stdout);
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Part Attached to Previous Design Revision [%s-%s]. *** ", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Part Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 2 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s ", item_id, revSeq);
										return ITK_err;
									}
								}
								else if(tc_strcmp(ObjectClassType1,"ProDrw") == 0)
								{
									printf("\n t5ValDataset:: Inside if class is ProDrw ");fflush(stdout);
									if(tagProDrw == NULLTAG)
									{
										printf("\n t5ValDataset:: 2: Before calling API AE_ask_dataset_named_ref2 ");fflush(stdout);
										CALLAPI(AE_ask_dataset_named_ref2(attachments1[j], "DrwFile", &my_ref_type, &tagProDrw));
										printf("\n t5ValDataset:: After calling API AE_ask_dataset_named_ref2 for ProDrw ---AA ");fflush(stdout);
									}
									else
									{
										printf("\n*** t5ValDataset :: WARNING :: More than one Pro/E Drawing Attached to Previous Design Revision [%s-%s]. *** ", item_id, RevSeq);
										EMH_store_error_s3(EMH_severity_error,ITK_err,"More than one Pro/E Drawing Attached to Design Revision. Please contact PLM ADMIN.", item_id, RevSeq);
										printf("\nt5ValDataset :: 3 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s ", item_id, revSeq);
										return ITK_err;
									}
								}
								else
								{
									printf("\t t5ValDataset:: creo dataset not found---> Item_id : [%s] revSeq : [%s]",item_id,revSeq);fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n t5ValDataset:: revision tag found null---> Item_id : [%s] revSeq : [%s]",item_id,revSeq);fflush(stdout);
						}
					}
					else
					{
						printf("\n*** Bypassing as the Item Revision is having Revision as NR;1 or the ; is not present in RevSeq Field. *** ");fflush(stdout);
					}
				}
			}
			
			printf("\n t5CheckForEmptyNamedRef:: Before %s Item_id : [%s] revSeq : [%s] ",ObjectClassType,item_id,revSeq);fflush(stdout);
			if(tc_strcmp(ObjectClassType,"ProAsm") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "AsmFile", tagProAsm));
			}
			else if(tc_strcmp(ObjectClassType,"ProPrt") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "PrtFile", tagProPrt));
			}
			else if(tc_strcmp(ObjectClassType,"ProDrw") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "DrwFile", tagProDrw));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Part") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATPart", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Product") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATProduct", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2Drawing") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATDrawing", NULLTAG));
			}
			else if(tc_strcmp(ObjectClassType,"CMI2AuxPart") == 0)
			{
				CALLAPI(t5CheckForEmptyNamedRef(dataset, ObjectClassType, "CATPart", NULLTAG));
			}
			else
			{
				;
			}
			printf("\n t5CheckForEmptyNamedRef:: After function %s Item_id : [%s] revSeq : [%s] ",ObjectClassType,item_id,revSeq);fflush(stdout);
		}
	}

	if(attachments) MEM_free(attachments);
	if(attachments1) MEM_free(attachments1);

	printf("\nt5ValDataset :: 4 Exiting Function t5ValDataset for Item_ID == %s :: RevSeq == %s \n", item_id, revSeq);
	return 0;
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextMinute(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays,Hour,Minute,nHr,nMin;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;

	struct tm *timeptr1;
	char pAccessDate[30];
	char pAccessDate1[30];
	char cMonth[30];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	strHr[20];
	char	strMin[20];

	temp = time(NULL);
	struct tm* timeptr;
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);

	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);


	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	Hour=(timeptr->tm_hour);
	Minute=(timeptr->tm_min);


	printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);

	ny= year;
	nm= month;
	nd= day;
	nHr=Hour;
	if (Minute==59)
	{
		if (Hour==23)
		{
			nHr=0;
			nMin=0;
			ndays= days( month, year );//calling days function
			if( ++nd > ndays )
			{
			   nd= 1;
			   if ( ++nm > 12 )
			   {
				 nm= 1;
				 ++ny;
				}
			}
		}
		else
		{
			nHr=Hour+1;
			nMin=0;
		}
	}
	else
	{
		nMin=Minute+1;
	}
    printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);
    printf( "Next days date is %d:%d:%d  %d:%d\n", nd, nm, ny ,nHr,nMin);

	sprintf(strDay,"%d",nd);
	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);
	sprintf(strHr,"%d",nHr);
	sprintf(strMin,"%d",nMin);

	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,strHr);
	tc_strcat(cnextAccessDate,":");
	tc_strcat(cnextAccessDate,strMin);
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

//********************** DVA Start ************************

int GetDVAUseCaseFromLibrary(tag_t itemRevTAG, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int	ifail = 0;
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName;
	char* s;
	char* moduleAddressS =NULL;
	char* designgroup =NULL;
	char* Parttype =NULL;
	char* moduleadd =NULL;
	char *partNumber =NULL;
    char *DesignGrp13=NULL;
    char *subGroup=NULL;
	moduleAddressS  = (char *)MEM_alloc(100);
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_PartType",&Parttype));

	if(tc_strcmp(Parttype,"M")==0)
	{

		ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_ModuleAddress",&moduleadd));
		printf("\n tm_action Module Address  :: %s\n",moduleadd);fflush(stdout);

		tc_strcpy(moduleAddressS,"");
		tc_strcat(moduleAddressS,moduleadd);

		printf("\n Module Address After cat in tm_action  :: %s\n",moduleAddressS);fflush(stdout);


		if (strlen(moduleAddressS) == 0)
		{
			printf("\n Module Address should not Blank for Part Typer is Module\n");fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Module Address should not Blank for Part Type is Module");
			return ITK_err;
		}

	}

	if(tc_strcmp(Parttype,"T")==0)
	{

					
            AOM_ask_value_string(itemRevTAG,"item_id",&partNumber);
			printf("\n tm_action :: Part Number = %s",partNumber);
			if(tc_strlen(partNumber)==13 && tc_strcmp(partNumber,"M")!=0)
			{
			  //If Part of Desgin Group Restructuring like 54
			  AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&DesignGrp13);
              printf("\n tm_action ::  Design Group = %s ",DesignGrp13);  
			  subGroup = subString(partNumber,8,4);
			  tc_strcpy(moduleAddressS,"");
			  tc_strcat(moduleAddressS,subGroup);
              printf("\n tm_DVA_Creation After cat Design Group %s\n",moduleAddressS);fflush(stdout);
			  if (strlen(DesignGrp13) == 0)
			 {
				printf("\n  Design Group should not Blank for Part Typer is TPL\n");fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, " Design Group should not Blank for Part Type is TPL");
				return ITK_err;
			 } 
			}
		else
		{

		ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_DesignGrp",&designgroup));
		printf("\n tm_action Design Group  :: %s\n",designgroup);fflush(stdout);

		tc_strcpy(moduleAddressS,"");
		tc_strcat(moduleAddressS,designgroup);

		printf("\n  Design Group After cat in tm_action  :: %s\n",moduleAddressS);fflush(stdout);


		if (strlen(moduleAddressS) == 0)
		{
			printf("\n Design Group should not Blank for Part Typer is Module\n");fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Design Group should not Blank for Part Type is TPL");
			return ITK_err;
		}
	 }  

	}

	queryTag = NULLTAG;
	status = QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	
	if(queryTag)
	{

	  printf("\n DFQ Use case Query found successfully\n");fflush(stdout);
	
	
	}
	
	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	//tc_strcat(documentName, "MB1C01_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "_");  
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	CALLAPI(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0) 
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}

int getBusinessUnitFunc(tag_t itemRevTAG, char** t5_business_unit_typeS)
{
	int	ifail = 0;
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	//char *qry_entries[3] = {"start_last_mod_date","end_last_mod_date","specification_object_type"};
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_ProjectCode",&t5_projectc_code_string));
	printf("\n ProjectCode %s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);
	
	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	ITK_CALL(AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod));
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Business Unit found for -- %s -- %s\n", t5_projectc_code_string, t5_business_unit_type_mod);fflush(stdout);
			MEM_free(s);
			return status;
	}

	*t5_business_unit_typeS = t5_business_unit_type_mod;

	return 0;
}

int t5ValidateDFQRelation(tag_t itemRevTAG)
{
	int	ifail = 0;
	int status = 0;
	int sec_result_count = 0;
	int resultCount1 = 0;
	int j = 0, k=0;
	int create_document=0;
	int pdf_req_flag =0;
	int nFoundpdf= 0;
	int addflag = 0;
	int addflag1 = 0;
	int addflag2 = 0;
	int addflag3 = 0;
	int PdfCnt = 0;
	int DVAobj_count = 0;

	char* s= NULL;
	char* dfq_use_case_uid= NULL;
	char* dfq_available_doc_uid= NULL;
	char* dfq_object_name= NULL;
	char* documentNameS= NULL;
	char* documentNameS1= NULL;
	char* documentNameS2= NULL;
	char* documentNameS3= NULL;
	char* PdfNameS2= NULL;
	char* partTypeS = NULL;
	char* DRStatus = NULL;
	char* checkedOutS = NULL;
	char* Userinfo2dup = NULL;
	char* objecttype = NULL;
	char* usecaseobjecttype = NULL;
	char* object_type55 = NULL;
	char* objectDVA = NULL;
	char* t5_business_unit_typeS =NULL;
	char* t5_dfq_commentS =NULL;

	char* meet_expectations= NULL;
	double design_nominal;
	double defined_target;
	double achieved_nominal;
	double achieved_target;
	double CpkVal;

	tag_t relTypeTag = NULLTAG;
	tag_t GMXqry_tg = NULLTAG;
	tag_t* available_dfq_document_tags = NULLTAG;
	tag_t* dfq_use_case_tags = NULLTAG;
	logical t5_dfq_applicability_logical;

	tag_t* refobjpdf  = NULLTAG;
	tag_t* DVA_object  = NULLTAG;
	
	printf("\n Inside Tm_action on dataset Function \n");
	ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_PartType",&partTypeS));
	printf("\n tm_action partTypeS -%s\n",partTypeS);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(itemRevTAG,"t5_PartStatus",&DRStatus));
	printf("\n  DRStatus - %s\n",DRStatus);fflush(stdout);

	ITK_CALL(getBusinessUnitFunc(itemRevTAG, &t5_business_unit_typeS));
	printf("\n Tm_action t5_business_unit_typeS - %s\n",t5_business_unit_typeS);fflush(stdout);

	//Function to be executed if only Partype as Module

	if (tc_strcmp(partTypeS,"M") == 0 || tc_strcmp(partTypeS,"T") == 0 )
	{ 

		printf("\n Inside Part type is Module or TPL\n");
		
	}
	else
	{
		printf("\n Part type is not Module or TPL\n");
	
	 return 0;
	
	}
	  if(QRY_find2("Control Objects...", &GMXqry_tg));

	char *GMsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **GMsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	GMsc_RelVal[0] = "DVAForm";
	GMsc_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(GMXqry_tg, 2, GMsc_entry1, GMsc_RelVal, &DVAobj_count, &DVA_object));

	printf("\n Query count for DVA form :[%d]\n",DVAobj_count); fflush(stdout);

	if(DVAobj_count >0)
	{

	   ITK_CALL(AOM_ask_value_string(DVA_object[0],"t5_Userinfo2",&Userinfo2dup));
       printf("\n userinfo2 Value[%s]\n",Userinfo2dup); fflush(stdout);

	

	GetDVAUseCaseFromLibrary(itemRevTAG, t5_business_unit_typeS, &resultCount1, &dfq_use_case_tags);
	printf("\n resultCount1 dfq_use_case_tags  %d\n",resultCount1);fflush(stdout);

	if(resultCount1 > 0)
	{
		documentNameS = NULL;
		documentNameS = (char *)MEM_alloc(1000);
		tc_strcpy(documentNameS,"");

		documentNameS1 = NULL;
		documentNameS1 = (char *)MEM_alloc(1000);
		tc_strcpy(documentNameS1,"");

		documentNameS2 = NULL;
		documentNameS2 = (char *)MEM_alloc(1000);
		tc_strcpy(documentNameS2,"");

		documentNameS3 = NULL;
		documentNameS3 = (char *)MEM_alloc(1000);
		tc_strcpy(documentNameS3,"");
		
		PdfNameS2 = NULL;
		PdfNameS2 = (char *)MEM_alloc(1000);
		tc_strcpy(PdfNameS2,"");

		//Get DFQ Document Relation Class Type
		ITK_CALL(GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag));
	
		//Get Attached DFQ Documents
		ITK_CALL(GRM_list_secondary_objects_only(itemRevTAG, relTypeTag, &sec_result_count,&available_dfq_document_tags));
		printf("\n No of Attached DFQ Documetns are :: %d\n",sec_result_count);fflush(stdout);

		//Looping through DFQ Use Cases if DFQ_Applicability is True and DFQ Document is not available
		for (j=0;j<resultCount1 ; j++)
		{
			dfq_use_case_uid = NULL;
			ITK_CALL(AOM_ask_value_string(dfq_use_case_tags[j],"object_type",&usecaseobjecttype));
			 printf("\n  DVA usecaseobjecttype %s \n",usecaseobjecttype);fflush(stdout);
            if(tc_strcmp(usecaseobjecttype,"T5_DFQ_UseCase")==0)
			{

				printf("\n Inside use cases object type \n");fflush(stdout);


			ITK_CALL(AOM_ask_value_logical(dfq_use_case_tags[j],"t5_DfQApplicablility",&t5_dfq_applicability_logical));
			printf("\n t5_dfq_applicability_logical 1 %d\n",t5_dfq_applicability_logical);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(dfq_use_case_tags[j],"object_name",&dfq_use_case_uid));
			printf("\n DVA UID :: %s\n",dfq_use_case_uid);fflush(stdout);
			printf("\n j value of resultCount*********** --- %d \n",j);fflush(stdout);

			//Verifying DFQ Applicability is TRUE [1]
			if(t5_dfq_applicability_logical == 1)
			{

				create_document = 1;
				printf("\n After create_document \n");fflush(stdout);
                printf("\n j value of resultCount1 --- %d \n",j);fflush(stdout);
				//Looping through Available DFQ Documents to ignore creation of available DFQ USE CASE ID.
				for (k=0;k<sec_result_count; k++ )
				{
					dfq_available_doc_uid = NULL;
					printf("\n inside sec_result_count \n");fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"object_type",&object_type55));
					printf("\n DFQ object_type55  %s\n",object_type55);fflush(stdout);

					if(tc_strcmp(object_type55,"T5_DFQ_Document")==0)
					{
						printf("\n Inside object_type55 condition \n");fflush(stdout);
				

						ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQUID",&dfq_available_doc_uid));
						printf("\n DFQ Document UID :: %s\n",dfq_available_doc_uid);fflush(stdout);

						if(tc_strcmp(dfq_available_doc_uid, dfq_use_case_uid) == 0)
						{
							create_document = 0;
							break;
						}

					}
				}

				if(create_document == 1)
				{
					//sprintf(documentNameS,",%s\n",dfq_use_case_uid);
					printf("\n inside create_document 1 \n");fflush(stdout);
					addflag++;
					printf("\n addflag --- %d \n",addflag);fflush(stdout);

					if(addflag==1)
					{
						printf("\n inside addflag 1 \n");fflush(stdout);

						tc_strcpy(documentNameS,dfq_use_case_uid);
						tc_strcat(documentNameS,",");
					}
					else
					{
						printf("\n addflag else --- %d \n",addflag);fflush(stdout);
						tc_strcat(documentNameS,dfq_use_case_uid);
						tc_strcat(documentNameS,",");
					}
				}
				else
				{
					printf("\n DFQ Document already available for USE CASE ID, ignoring.\n");fflush(stdout);
				}
			}
			else
			{
				printf("\n *** DFQ Applicability is FALSE, ignoring creation of DFQ Document. ***\n");fflush(stdout);
			}
		}
         printf("\n After usecaseobjecttype \n");fflush(stdout);

		}
		
		printf("\n Not Available DFQ UID %s\n",documentNameS);fflush(stdout);
		if(strlen(documentNameS) > 0)
		{
			EMH_store_error_s2(EMH_severity_information,ITK_err,"Create DVA Document for Module using File --> New --> Form--> DVA Document Creation form. ", documentNameS);
			return ITK_err;
		}

		//Check DFQ Applicability is having True or False Value. If False then make Comment required.
		if(sec_result_count > 0)
		{
			for (k=0;k<sec_result_count; k++ )
			{
				dfq_available_doc_uid = NULL;
				dfq_object_name = NULL;
				ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"object_type",&objecttype));
			     printf("\n  DVA Document object_type %s \n",objecttype);fflush(stdout);
				 printf("\n userinfo2 Value[%s]\n",Userinfo2dup); fflush(stdout);
                if(tc_strcmp(objecttype,"T5_DFQ_Document")==0 || tc_strcmp(Userinfo2dup,"ON")==0)
				{
					printf("\n inside objecttype T5_DFQ_Document  \n"); fflush(stdout);

				ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQUID",&dfq_available_doc_uid));
				printf("\nDFQ Document UID1 :: %s\n",dfq_available_doc_uid);fflush(stdout);

				CALLAPI(AOM_ask_value_logical(available_dfq_document_tags[k],"t5_DFQApplicablility",&t5_dfq_applicability_logical));
				printf("t5_dfq_applicability_logical 2::%d\n",t5_dfq_applicability_logical);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"object_name",&dfq_object_name));
				printf("dfq_object_name 2::%s\n",dfq_object_name);fflush(stdout); 

//				if(t5_dfq_applicability_logical == 0 || t5_dfq_applicability_logical == 1)
//				{
//					printf("\n Continue ....\n");fflush(stdout);
//				}
//				else
//				{
//					printf("\n ***DFQ Applicabiity value should be either TRUE or FALSE for DFQ Document ***\n");fflush(stdout);
//
//					EMH_clear_errors();
//					EMH_store_error_s1(EMH_severity_error,ITK_err, "DFQ Applicabiity value should be either TRUE or FALSE for DFQ Document.");
//					return ITK_err;
//				}	

				if(t5_dfq_applicability_logical == 0)
				{
					ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQComment",&t5_dfq_commentS));
					printf("Comment :: %s\n",t5_dfq_commentS);fflush(stdout);
					ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"object_type",&objectDVA));
					printf("\n objectDVA %s\n",objectDVA);fflush(stdout);

					if(tc_strcmp(objectDVA,"T5_DFQ_Document")==0)
					{

					if(tc_strlen(t5_dfq_commentS) < 15 )
					{
						addflag1++;
						if(addflag1==1)
						{
							tc_strcpy(documentNameS1,dfq_object_name);
							tc_strcat(documentNameS1,",");
						}
						else
						{
							tc_strcat(documentNameS1,dfq_object_name);
							tc_strcat(documentNameS1,",");
						}

						printf("*** Please Fill Comment at least 15 characters against DFQ Document %s having DFQ Applicabiity as FALSE*** \n",documentNameS1);fflush(stdout);
					}	

					}
				}
				else
				{
					//Add validation if DFQ Document is having DR Status> DR2 then pdf should be present. T5_DFQ_PDF
					printf("\n Inside the DR3 else condition  \n");fflush(stdout);
					
					if (tc_strcmp(DRStatus,"DR3") ==0 || tc_strcmp(DRStatus,"AR3") ==0) 
					{						
						pdf_req_flag =1;
						printf("\n Inside the DR3 condition \n");fflush(stdout); 
					}

					ITK_CALL(AE_ask_all_dataset_named_refs2(available_dfq_document_tags[k],"T5_DFQ_PDF",&nFoundpdf,&refobjpdf));

					printf("*nFoundpdf --- %d* \n",nFoundpdf);fflush(stdout);
					printf("*n pdf_req_flag --- %d* \n",pdf_req_flag);fflush(stdout);


					if((nFoundpdf == 0) && (pdf_req_flag== 1))
					{	

						addflag2++;
						if(addflag2==1)
						{
							tc_strcpy(documentNameS2,dfq_object_name);
							tc_strcat(documentNameS2,",");
						}
						else
						{
							tc_strcat(documentNameS2,dfq_object_name);
							tc_strcat(documentNameS2,",");
						}

						printf("*** FOR DR3 and above DR status,PDF file should be attached to DFQ Document %s *** \n",documentNameS2);fflush(stdout);
					}
					
					if(nFoundpdf >= 2)
					{	
						PdfCnt=1;
						
						if(PdfCnt==1)
						{
							tc_strcpy(PdfNameS2,dfq_object_name);
							tc_strcat(PdfNameS2,",");
						}
						

						printf("*** FOR DR3 and above DR status, Only one PDF file should be attached to DFQ Document %s ********** \n",PdfNameS2);fflush(stdout);
					}


					//AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQUID",&dfq_available_doc_uid);

					//Add QA attributes Validation

					meet_expectations = NULL;

					ITK_CALL(AOM_ask_value_double(available_dfq_document_tags[k],"t5_DFQDesNom",&design_nominal));
					printf("design_nominal ::%f\n",design_nominal);fflush(stdout);
					ITK_CALL(AOM_ask_value_double(available_dfq_document_tags[k],"t5_DNDefTarget",&defined_target));
					printf("defined_target (+/-)::%f\n",defined_target);fflush(stdout); 
					ITK_CALL(AOM_ask_value_double(available_dfq_document_tags[k],"t5_DFQAchNom",&achieved_nominal));
					printf("achieved_nominal ::%f\n",achieved_nominal);fflush(stdout); 
					ITK_CALL(AOM_ask_value_double(available_dfq_document_tags[k],"t5_ANDefTarget",&achieved_target));
					printf("achieved_target (+/-) ::%f\n",achieved_target);fflush(stdout); 
					ITK_CALL(AOM_ask_value_double(available_dfq_document_tags[k],"t5_DFQCpkVal",&CpkVal));
					printf("t5_DFQ_Doc_save_dataset CpkVal ::%f\n",CpkVal);fflush(stdout); 

					ITK_CALL(AOM_ask_value_string(available_dfq_document_tags[k],"t5_DFQMeetExp",&meet_expectations));
					printf("meet_expectations ::%s\n",meet_expectations);fflush(stdout); 
					
					if ((design_nominal == 999.9999) || (defined_target == 999.9999) || (achieved_nominal == 999.9999)  || (achieved_target == 999.9999) || (CpkVal == 999.9999))
					{
						addflag3++;
						if(addflag3==1)
						{
							tc_strcpy(documentNameS3,dfq_object_name);
							tc_strcat(documentNameS3,",");
						}
						else
						{
							tc_strcat(documentNameS3,dfq_object_name);
							tc_strcat(documentNameS3,",");
						}

						printf("*** DFQ Analysis not fill for DFQ Document Name %s *** \n",documentNameS3);fflush(stdout);
					}
				}
			  }
			}
			//ADD 

			if(strlen(documentNameS1) > 0)
			{
				printf("*** Provide DVA Justification Comment at least 15 characters against DFQ Document, if DFQ Applicability set to False for %s *** \n",documentNameS1);fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_information,ITK_err,"Provide DVA Justification Comment at least 15 characters against DVA Document, if DVA Applicability set to False for ", documentNameS1);
				return ITK_err;
			}

			if(strlen(documentNameS2) > 0)
			{
				printf("*** Upload Sign off DVA report PDF under DFQ Document %s *** \n",documentNameS2);fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_information,ITK_err,"Upload Sign off DVA report PDF under DVA Document ", documentNameS2);
				return ITK_err;
			}

			if(strlen(documentNameS3) > 0)
			{
				printf("*** Update DVA Analysis results values for DVA Design Nominal, DVA Defined Target( +/-), DVA Achieved Nominal, DVA Achieved Target(+/-), DVA Cpk Value should not be blank or default value (999.9999) from DVA Documents properties %s . To update (Select DVA Document>>Right Click>>Edit Properties>>Save). *** \n",documentNameS3);fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_information,ITK_err,"Update DVA Analysis results values for DVA Design Nominal, DVA Defined Target( +/-), DVA Achieved Nominal, DVA Achieved Target(+/-), DVA Cpk Value should not be blank or default value (999.9999) for below DVA Documents. To update (Select DVA Document>>Right Click>>Edit Properties>>Save).", documentNameS3);
				return ITK_err;
			}
			if(strlen(PdfNameS2) > 0)
			{
				printf("*** Hard check Only one PDF file should be attached to DFQ Document %s *** \n",PdfNameS2);fflush(stdout);

				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,ITK_err," Please keep only one pdf in named reference of DVA Document. ", PdfNameS2);
				return ITK_err;
			}
					
		}
	}

	}

	printf("\n END Of DVA Check-in With Design Revision \n");
	return 0;
}

//********************** DVA End **************************

extern DLLAPI int checkin_with_dataset(METHOD_message_t *m, va_list args)
{
  	//char			relation_name[TCTYPE_name_size_c+1];
	tag_t			relation_type							= NULLTAG;
	tag_t			*attachments							= NULLTAG;
	tag_t *  	primary_objects;
	tag_t			dataset									= NULLTAG;
	tag_t	 		object_tag								= va_arg (args, tag_t);
	int				ifail=0,cnt=0,i=0,j;
	int cnt1 = 0;
	logical			checkout								= 0;
	//int				BomViewCnt,iVwCnt,count1,checkout1				= 0;//Abhishek
	int				BomViewCnt,iVwCnt,count1;//Abhishek
	tag_t			*BomViewList							= NULLTAG;//Abhishek
	//char			type_name[TCTYPE_name_size_c+1];//Abhishek
	tag_t			objTypeTag								= NULLTAG;//Abhishek
	GRM_relation_t *primary_list1	= NULLTAG;
	tag_t		   primary_object1	= NULLTAG;
	GRM_relation_t *primary_list	= NULLTAG;
	//tag_t                   status_rel                                      = NULLTAG;
	tag_t    tReleaseStatusList=NULLTAG;
	tag_t    process_template = NULLTAG;
	tag_t*    status_list1=NULLTAG;
	//logical retain=true;
	char		*WSO_Name=NULL ;
	tag_t*    attr_tags=NULLTAG;
	tag_t process = NULLTAG;
	int st_count1,n_values,n_values1=0;
	char*				RevisionId		= NULL;
	char*				relation_name		= NULL;
	char*				type_name		= NULL;
	logical
        *is_it_null = NULL,
        *is_it_empty = NULL;
	int		attachTypes[]		= {EPM_target_attachment};
	tag_t			status_rel					= NULLTAG;

	logical			retain							= 0;
	tag_t  CurrentRoleTag = NULLTAG;
    //char       roleName[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
    //char       roleNameVal[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
	char *roleNameVal	=	NULL;


	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		=0;
	int			Rel_cnt					=0;
	tag_t*		relstatus_list			=NULLTAG;
	char		*WSO_Name_RelVal		=NULL ;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	int			n_values_checkin			=0;
	int			cunt1					=	0;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	tag_t		class_id				=     NULLTAG;
	char		*class_name				=    NULL;
	char		*gov_classification		=NULL;
    char   *PlantName=NULL;

	logical		log1;
	logical		checkout1;
	int status = 0;

				//Start Check in SA Code Deepti
				EPM_decision_t decision;

			tag_t item=NULLTAG;
			char *itemRevSeq=NULL;
			char *parttype=NULL;
			char *childPartsOfSA=NULL;
			char *childPartsRevOfSA=NULL;
			char *childPartsTypeOfSA=NULL;
			char *childPartsNoOfWeldSpt=NULL;
			char *childPartsArcCnt=NULL;
			char *childPartsSeaLenght=NULL;
			char *childPartsArcLenght=NULL;
			char *childPartsSeaType=NULL;
			char *info1r=NULL;
			char *info2r=NULL;
			char *info3r=NULL;
			char *info4r=NULL;
			char *info5r=NULL;
			char *info6r=NULL;
			char *info7r=NULL;
			char *projectcodeCheck=NULL;
			char *digitCompCheck=NULL;
			char *sTotalfloatrelQtyProjCode=NULL;
			char *sTotalfloatrelQtyDigit=NULL;
			char *PrtNumStudTemp=NULL;
			char *relQty=NULL;
			char *ChildRelWeldSpotErr=NULL;
			char *ChildRelArcCntErr=NULL;
			char *ChildRelArcLengthErr=NULL;
			char *ChildRelSealErr=NULL;
			char *ChildRelStudErr=NULL;
			char *ChildRelSealLengthErr=NULL;
			int n_values_bvr=0;
			int assbvr=0;
			int nClhd_sa=0;
			int saCCnt=0;
			int stdCnt=0;
			int studLogicmatch=0;
			int iErrCnt=0;
			int iErrCnt1=0;
			int iErrCnt2=0;
			int icountWS=0;
			int icountAcnt=0;
			int icountALngth=0;
			int icountStud=0;
			int icountF=0;
			int icountSeal=0;
			double intchildPartsNoOfWeldSpt=0.00;
			double intchildPartsArcCnt=0.00;
			double intchildPartsSeaLenght=0.00;
			double floatrelQty=0.00;
			double floatrelQtyDigit=0.00;
			double floatrelQtyPrtNo=0.00;
			double intchildPartsArcLenght=0.00;
			double TotalNoOfWeldSpots=0.00;
			double TotalNoOfArcCnt=0.00;
			double TotalNoOfArcLengh=0.00;
			double TotalNoOfSeaLenght=0.00;
			double TotalfloatrelQtyProjCode=0.00;
			double TotalfloatrelQtyDigit=0.00;
			double TotalfloatrelQtyPrtNo=0.00;
			tag_t			*bvr_assy_part= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t			studCntObjTag= NULLTAG;
			tag_t	window_sa 				= NULLTAG;
			tag_t   top_line_sa				=	NULLTAG;
			tag_t  *children_sa;
			tag_t   BOMLinetag=NULLTAG;	
			char	**SetChildRelErrWS	= NULL;
			char	*desidForAPL	= NULL;
			char	*DesgTypAPL	= NULL;
			char	*tempErr =	NULL;
			char	*tempErr1 =	NULL;
			char	*sTotalNoOfWeldSpots =	NULL;
			char	*sTotalNoOfArcCnt =	NULL;
			char	*sTotalNoOfArcLengh =	NULL;
			char	*sTotalNoOfSeaLenght =	NULL;
			char *view_name = NULL;
			char* partTok =NULL;
			char* viewTok =NULL;


			char	**SetChildRelErrAcnt	= NULL;
			char	**SetChildRelErrALngth	= NULL;
			char	**SetChildRelErrFinal	= NULL;
			char	**SetChildRelStudErr	= NULL;
			char	**SetChildRelErrSeal	= NULL;
			char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

			int cntrlcnt=0;
			int flagBVR=0;
			int  control_number_found1=0;

			tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

			tag_t   qryTagCntrl1     = NULLTAG;
			int     n_entryCntrl1    = 3;

			int p = 0;
			int n = 0;
			tag_t s_relation_type = NULLTAG;
			tag_t r_relation_type = NULLTAG;
			char *item_id = NULL;
			char *status1 = NULL;
			char *obj_name = NULL;
			char *item_id1 = NULL;
			char *obj_name1 = NULL;
			char *s_objtype = NULL;
			char *status22 = NULL;
			int ref_count = 0;
			int s_objcount = 0;
			int r_objcount = 0;
			int DVAobj_count = 0;
			char *r_objtype = NULL;
			char *Userinfo1dup = NULL;
			tag_t sec_obj1 = NULLTAG;
			tag_t ref_form_relation = NULLTAG;
			tag_t sec_obj2 = NULLTAG;
			tag_t GMXqry_tg = NULLTAG;
			tag_t* s_sec_obj = NULLTAG;
			tag_t* r_sec_obj = NULLTAG;
			tag_t* DVA_object = NULLTAG;
			tag_t old_form_relation = NULLTAG;

			//End Check in SA Code Deepti

	const char		*reason	= NULL;
	const char		*change_id	= NULL;
	const char		*dir_name = NULL;

	char RvwLCVal[40];	//MBOM implementation for CV TZ-1.69
	char WrkngLCVal[40]; //MBOM implementation for CV TZ-1.69
	char RlzdLcVal[40];	//MBOM implementation for CV TZ-1.69
	char RvwLCActVal[40]; //MBOM implementation for CV TZ-1.69
	char View[40];//MBOM implementation for CV TZ-1.69
	char WrkngActLCVal[40];//MBOM implementation for CV TZ-1.69
	char RlzdActLcVal[40];//MBOM implementation for CV TZ-1.69
	char   *dsgModAddressVal=NULL;//MBOM implementation for CV TZ-1.69
	//char roleName[100];//MBOM implementation for CV TZ-1.69
	char *roleName	=	NULL; //Added for testing by Rohit for 14.3 upgradation
	roleName=(char *)MEM_alloc(100);

	int fndSE=0;	//MBOM implementation for CV TZ-1.70
	int fndWE=0;	//MBOM implementation for CV TZ-1.70
	int saCntM=0;	//MBOM implementation for CV TZ-1.70
	tag_t   BOMLinetagM=NULLTAG;//MBOM implementation for CV TZ-1.70
	char *childPartsOfSAM=NULL;//MBOM implementation for CV TZ-1.70
	char *roleNameDupVal=NULL;//MBOM implementation for CV TZ-1.70
	char *DsgModName=NULL;//MBOM implementation for CV TZ-1.70
	char *childPartsTypeOfSAM=NULL;//MBOM implementation for CV TZ-1.70


    if(QRY_find2("Control Objects...", &GMXqry_tg));

	char *GMsc_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **GMsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	GMsc_RelVal[0] = "DVAForm";
	GMsc_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(GMXqry_tg, 2, GMsc_entry1, GMsc_RelVal, &DVAobj_count, &DVA_object));

	printf("\n Query count for DVA form :[%d]\n",DVAobj_count); fflush(stdout);

	if(DVAobj_count >0)
	{

	   ITK_CALL(AOM_ask_value_string(DVA_object[0],"t5_Userinfo1",&Userinfo1dup));
	   printf("\n userinfo1 DML:[%s]\n",Userinfo1dup); fflush(stdout);
	   ITK_CALL(GRM_find_relation_type("IMAN_specification",&s_relation_type));
	   if(s_relation_type)
	   {
	     printf("\n IMAN_specification tag relation found \n"); fflush(stdout);
	   }
	   		
	   ITK_CALL(GRM_find_relation_type("IMAN_reference",&r_relation_type));
	   			
	   if(r_relation_type)
	   {
	     printf("\n IMAN_reference tag relation found \n"); fflush(stdout);
	   }
	   
	

	if(tc_strcmp(Userinfo1dup,"ON")==0)
	{

	    ITK_CALL(GRM_list_secondary_objects_only(object_tag,s_relation_type,&s_objcount,&s_sec_obj));
     	printf("\n spcification rel count is  %d \n",s_objcount);fflush(stdout);
     
     	//if(tc_strcmp(s_objtype,"T5_DFQDocCreForm")==0)
     
     	 for (p=0;p<s_objcount;p++)
     	 {
     	 	 sec_obj1=s_sec_obj[p];
     	 
     	 	 ITK_CALL(AOM_ask_value_string(sec_obj1,"object_type",&s_objtype));
     	 	
     	 	 if (tc_strcmp(s_objtype,"T5_DFQDocCreForm")==0)
     	 	 {
     			  printf("\n inside Specification relation \n");fflush(stdout);
     	 		 ITK_CALL(AOM_UIF_ask_value(sec_obj1,"t5_ItemID",&item_id));
     	 		 ITK_CALL(AOM_UIF_ask_value(sec_obj1,"object_name",&obj_name));
     			 printf("\n s_objtype2 : %s \n",s_objtype);fflush(stdout);
     	 		 printf("\n item_id : %s \n",item_id);fflush(stdout);
     	 		 printf("\n obj_name: %s \n",obj_name);fflush(stdout);	
     			 //fprintf(fp,"%s,",item_id);fflush(stdout); 
     			 //DVAobjcount++;
     
     			 ITK_CALL(AOM_UIF_ask_value(sec_obj1,"checked_out",&status1));
     			 printf("\n spe form is check-out %s \n",status1);fflush(stdout);
     			
     			 if(tc_strcmp(status1,"Y")==0)
     			 {
     			   printf("\n spec inside form check out \n");fflush(stdout);
     			   ITK_CALL(RES_checkin(sec_obj1));
     			 
     			 }
     			 
     
     			//ITK_CALL(POM_copy_instances(1,&sec_obj1,&new_form));
     			
     			//new_form1 = new_form[0];
     			
     			
     			//if(new_form1 )
     			//{
     			//  printf("\n New form created \n");fflush(stdout);
     			//}
     			
     			//ITK_CALL(POM_save_instances(1,&new_form1,1));
     			
     			//ITK_CALL(GRM_create_relation(tItemRevTag,new_form1,r_relation_type,NULLTAG,&form_relation));
     			
     			//ITK_CALL(GRM_save_relation(form_relation));
     			
     			ITK_CALL(GRM_find_relation(object_tag,sec_obj1,s_relation_type,&old_form_relation));
				ITK_CALL(AOM_lock(old_form_relation));
     			
     			ITK_CALL(GRM_delete_relation(old_form_relation));
				//ITK_CALL(AOM_lock(old_form_relation));
				//ITK_CALL(AOM_delete(old_form_relation));

				ITK_CALL(GRM_save_relation(old_form_relation));
				ITK_CALL(AOM_lock(sec_obj1));
     			
     			//ITK_CALL(POM_delete_instances(1,&sec_obj1)); 
				ITK_CALL(AOM_delete(sec_obj1));
     			printf("\n spec inside form delete2222222222222 \n");fflush(stdout);
     	 	 }
     
     			
     			
     
     	 }
     
     	ITK_CALL(GRM_list_secondary_objects_only(object_tag,r_relation_type,&r_objcount,&r_sec_obj));
     	printf("\n reference rel count is  %d \n",r_objcount);fflush(stdout);
     
     	 for(n=0;n<r_objcount;n++)
     	{
     	  sec_obj2 = r_sec_obj[n];
     
     	  
     	 
     	 	 ITK_CALL(AOM_ask_value_string(sec_obj2,"object_type",&r_objtype));
     	 	
     	 	 if (tc_strcmp(r_objtype,"T5_DFQDocCreForm")==0)
     	 	 {
     
     			 printf("\n inside refrence relation \n");fflush(stdout);
     	 		 ITK_CALL(AOM_UIF_ask_value(sec_obj2,"t5_ItemID",&item_id1));
     	 		 ITK_CALL(AOM_UIF_ask_value(sec_obj2,"object_name",&obj_name1));
     			 printf("\n s_objtype2 : %s \n",r_objtype);fflush(stdout);
     	 		 printf("\n item_id : %s \n",item_id1);fflush(stdout);
     	 		 printf("\n obj_name: %s \n",obj_name1);fflush(stdout);	
     			 //fprintf(fp,"%s,",item_id);fflush(stdout); 
     			 //DVAobjcount++;
     
     			 ITK_CALL(AOM_UIF_ask_value(sec_obj2,"checked_out",&status22));
     			 printf("\n ref form is check-out %s \n",status);fflush(stdout);
     			
     			 if(tc_strcmp(status22,"Y")==0)
     			 {
     				printf("\n ref inside form check out \n");fflush(stdout);
     			   ITK_CALL(RES_checkin(sec_obj2));
     			 
     			 }
				 printf("\n ref form is check-out %s \n",status);fflush(stdout);
     			 
     
     			//ITK_CALL(POM_copy_instances(1,&sec_obj2,&new_formref));
     			
     			//new_form2 = new_formref[0];
     			
     			
     			//if(new_form2 )
     			//{
     			//  printf("\n New form created \n");fflush(stdout);
     			//}
     			
     			//ITK_CALL(POM_save_instances(1,&new_form1,1));
     			
     			//ITK_CALL(GRM_create_relation(tItemRevTag,new_form1,r_relation_type,NULLTAG,&form_relation));
     			
     			//ITK_CALL(GRM_save_relation(form_relation));
     			
     			ITK_CALL(GRM_find_relation(object_tag,sec_obj2,r_relation_type,&ref_form_relation));
				ITK_CALL(AOM_lock(ref_form_relation));

     			
     			//ITK_CALL(AOM_delete(ref_form_relation));
				ITK_CALL(GRM_delete_relation(ref_form_relation));

				ITK_CALL(GRM_save_relation(ref_form_relation));
				//ITK_CALL(AOM_refresh(ref_form_relation,1));


				
     			ITK_CALL(AOM_lock(sec_obj2));
     			//ITK_CALL(POM_delete_instances(1,&sec_obj2)); 
				ITK_CALL(AOM_delete(sec_obj2));
				//ITK_CALL(AOM_save_without_extensions(sec_obj2));
				
     			printf("\n ref inside form delete2222222222 \n");fflush(stdout);
     	 	 }
     	
     	
     	
     }
	}
	}

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if(relation_type)
	{
		CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
		printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  printf("\nin checkin for loop\n");fflush(stdout);
		  dataset = attachments[i];
		  CALLAPI(RES_is_checked_out(dataset,&checkout));
		  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
		  if (checkout==1)
		  {
		  		CALLAPI(RES_checkin(dataset));
				printf("\n %d DataSet Checked In \n",i+1);
		  }

		}
	}

	CALLAPI(SA_ask_current_role(&CurrentRoleTag));  //DEEPTI TZ1.34
	CALLAPI(SA_ask_role_name2(CurrentRoleTag,&roleNameVal));//MBOM implementation for CV TZ-1.69
	tc_strcpy(roleName,roleNameVal);//MBOM implementation for CV TZ-1.69
	printf("\nline 2533\n"); fflush(stdout);
	printf("\n\n  roleNameVal : %s,roleName : %s\n",roleNameVal,roleName); fflush(stdout);//DEEPTI TZ1.34
	
	
	if(tc_strstr(roleName,"MBOM")!=NULL)	//MBOM implementation for CV TZ-1.69
	{
		dsgModAddressVal = strtok (roleNameVal,"_");	//MBOM implementation for CV TZ-1.69
		PlantName = strtok (NULL,"_");
		printf( "dsgModAddressVal:%s\n", dsgModAddressVal); fflush(stdout);
		printf( "PlantName:%s\n", PlantName); fflush(stdout); //MBOM implementation for CV TZ-1.69
	}
	else
	{

		PlantName=subString(roleName,3,4);
	}
	printf( "PlantName:%s\n", PlantName);fflush(stdout);
	
	if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL))	//MBOM implementation for CV TZ-1.69
	{
		get_CtrlVal_RelStateChkInf(PlantName,RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,View);//MBOM implementation for CV TZ-1.69
		printf( "\n RvwLCVal:%s, RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s, RlzdActLcVal:%s,View:%s\n", RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,View);fflush(stdout);//MBOM implementation for CV TZ-1.69
				 
	}

	/*Added By Abhishek For Bom View Revision Checkin on Design Checkin*/
	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	printf("\nTypeName for Checkin is [%s]\n",type_name);fflush(stdout);
	//if (strcmp(type_name,"Design Revision") == 0) //007
	if ((strcmp(type_name,"Design Revision") == 0)||(strcmp(type_name,"T5_SparKitRevision") == 0) ||(strcmp(type_name,"T5_EE_PartRevision") == 0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
	{

	//		printf("\nsseeInside to set Review Status for workflowee\n");fflush(stdout);
	//		//CALLAPI(EPM_find_process_template("ERC Review", &process_template));
	//		CALLAPI(EPM_find_process_template("ERC Review", &process_template));
	//		//EXIT_IF_NULL( process_template );
	//
	//		 CALLAPI(WSOM_ask_object_id_string(object_tag,&RevisionId));
	//
	//				//CALLAPI(WSOM_ask_name(revTag,a_nameRev));
	//
	//		  printf("\n RevisionId %s \n",RevisionId);fflush(stdout);
	//		printf("\nEPM_find_process_template  for workflowpp\n");fflush(stdout);
	//		if(process_template)
	//		{
	//			printf("\n inside found  for workflowwp\n");fflush(stdout);
	//			//EPM_create_process("5421377", "desc", process_template, 1, &rev,      attach_types, &process) );
	//			CALLAPI(EPM_create_process(RevisionId,"Test",process_template,1,&object_tag,attachTypes,&process));
	//			//EXIT_IF_NULL( process_template );
	//		}
			//IFERR_REPORT(EPM_create_process("WFP", "", process_template,n_items,
	          //  items, attach_types, &process));
	//		CALLAPI (RELSTAT_create_release_status("T5_LcsReview",&status_rel));
	//
	//		CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	//		printf("\nst_count1 :%d is\n",st_count1);fflush(stdout);
	//		if(st_count1>0)
	//		{
	//			for (cnt=0;cnt< st_count1;cnt++ )
	//			{
	//				CALLAPI(AOM_ask_name(status_list1[cnt],&WSO_Name));
	//				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
	//				if (strcmp(WSO_Name,"T5_LcsReview")==0)
	//				{
	//					CALLAPI(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&tReleaseStatusList));fflush(stdout);
	//
	//					 CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList, &n_values) );
	//					 printf("\n n_values is :%d\n",n_values);fflush(stdout);
	//					 CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList, 0, n_values1, &attr_tags, &is_it_null, &is_it_empty ));
	//					  printf("\n n_values11 is :%d\n",n_values1);fflush(stdout);
	//
	//					 CALLAPI(POM_remove_from_attr(1,object_tag,tReleaseStatusList,0,1));
	//					   printf("\n removedd is :%d\n",n_values1);fflush(stdout);
	//					 CALLAPI(POM_save_instances(1, &object_tag, true));
	//
	//				}
	//			}
	//		}
	//
	//		CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	//	  printf("\n process created is :%d\n",n_values1);fflush(stdout);

		//CALLAPI(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&tReleaseStatusList));fflush(stdout);

		if( AOM_ask_value_string(object_tag,"gov_classification",&gov_classification)!=ITK_ok) PrintErrorStack();
		printf("\ngov_classification:%s",gov_classification);fflush(stdout);

		if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)
		{
			return ITK_ok;
		}


		if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok) PrintErrorStack();
		printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

		if (BomViewCnt > 0)
		{
			printf("\nCheckin BOM Views Also .............\n");fflush(stdout);
			for(iVwCnt=0;iVwCnt<BomViewCnt;iVwCnt++)
			{
				printf("\nCheckin [%d] View\n",iVwCnt+1);fflush(stdout);
				if (RES_checkin(BomViewList[iVwCnt])!=ITK_ok) PrintErrorStack();

			 if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) //MBOM implementation for CV TZ-1.69
			 {
				 status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], RvwLCVal); //MBOM implementation for CV TZ-1.69
				 printf("\nUpdation of Lifecycle State on Dataset Status for APL-MBOM== %d\n", status);fflush(stdout);
				 /*if(strcmp(PlantName,"APLC")==0)	//MBOM implementation for CV TZ-1.69,commented if-else block
				 {
				printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsAplReview");
    			printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				 }else if(strcmp(PlantName,"APLV")==0)
				 {
				printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsAplvReview");
    			printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				 }*/
			  }else
				{
				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsReview");
				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				}
			}
		}

	printf("\n Before ERC Review.... \n");fflush(stdout);
	//if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();

	/*********Deepti Start for removing Release Status in CHeckIN***************************************/
	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
			printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


			CALLAPI(POM_save_instances(1,&object_tag,1));

			CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

			CALLAPI(AOM_lock(object_tag));

			CALLAPI(AOM_save_without_extensions(object_tag));
			CALLAPI(AOM_refresh(object_tag,1));

		}

		 CALLAPI(AOM_unlock(object_tag));
	}


		/*********Deepti End for removing Release Status in CHeckIN***************************************/
	printf("\n Inside effectivty stamping code\n");
	char*			ReleaseStatus	=NULL;
	logical stat  ;
	char cCurrentAccessDate[20]={0};
	tag_t    	    propEff_tag				    =NULLTAG;
	char*			value					=NULL;
	char cNextDate[30]={0};
	date_t test_date_1;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	char* username;
	tag_t user_tag=NULLTAG;

	POM_get_user(&username,&user_tag);

	 if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) //MBOM implementation for CV TZ-1.69
	 {
		printf("\n APL USer and Its role is %s\n",roleName);fflush(stdout);
		//if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
		   
		    if (RELSTAT_create_release_status(RvwLCVal,&status_rel)!=ITK_ok) PrintErrorStack();	//MBOM implementation for CV TZ-1.69
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();//MBOM implementation for CV TZ-1.69

		   /*if(strcmp(PlantName,"APLC")==0)	//MBOM implementation for CV TZ-1.69,Commented if-else block
		    {
			if (RELSTAT_create_release_status("T5_LcsAplReview",&status_rel)!=ITK_ok) PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();
			}else if (strcmp(PlantName,"APLV")==0)
			{
			if (RELSTAT_create_release_status("T5_LcsAplvReview",&status_rel)!=ITK_ok) PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();
			}*/
	  }else
	  {
			printf("\n Inside else\n");
			//if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
			if (RELSTAT_create_release_status("T5_LcsReview",&status_rel)!=ITK_ok) PrintErrorStack();
			CALLAPI( AOM_ask_name(status_rel, &ReleaseStatus));
			if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();
	  }

	if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
	{
			 if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) //MBOM implementation for CV TZ-1.69
			 {
				//if((strcmp(ReleaseStatus,"APLC Review")==0) || (strcmp(ReleaseStatus,"APL Review")==0) ||strcmp(ReleaseStatus,"T5_LcsAplReview")==0
					// || tc_strcmp(ReleaseStatus, "APLV Review") == 0  || tc_strcmp(ReleaseStatus,"T5_LcsAplvReview")==0)  //MBOM implementation for CV TZ-1.69
				if((tc_strcmp(ReleaseStatus,RvwLCActVal)==0) || (tc_strcmp(ReleaseStatus,RvwLCVal)==0))  //MBOM implementation for CV TZ-1.69
				{
					printf("\n Inside IF effectivty stamping code\n");
					if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;
					printf("\n stat:%d\n",stat);

					if(stat != true)
					{
						printf("\n stat is not true .....\n");
					}
					else
					{
						printf("\n stat is  true .....\n");
					}

					getCurrentDateTime(cCurrentAccessDate);
					//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
					//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
					//if(AOM_UIF_ask_name(propEff_tag,"effectivity_text",&value));
					//printf("\n effectivity_text is value : %s\n",value);

					//getNextDate(cNextDate);
					getNextMinute(cNextDate);
					printf("\n cNextDate:%s",cNextDate);
					//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

					if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
					{
						return ifail;
					}
					start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

					//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

					start_end_date[0] = test_date_1;
					start_end_date[1] = test_date_2;

					if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_rel)))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
					{
						return ifail;
					}

					if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
					{
						return ifail;
					}

					if(ITK_ok != (ifail = AOM_save_without_extensions(status_rel)))
					{
						return ifail;
					}
					if(ITK_ok != (ifail = AOM_refresh( status_rel, 0 )))
					{
						return ifail;
					}

					//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
					////if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
					//if(AOM_UIF_ask_name(propEff_tag,"effectivity_text",&value));
					//printf("\n After setting effectivity_text value : %s\n",value);

					if(ITK_ok != (ifail = AOM_refresh( object_tag, 0 )))
					{
						return ifail;
					}

					/// Previous revison

					tag_t	*rev_list				= NULL;
					tag_t	*status_lst				= NULL;
					tag_t	*effectivities_tag				= NULL;
					int Item_count=0;
					int iiCnt=0;
					int count_status=0,j=0,n_effectivities=0,n_dtes=0;
					char	*rel_status				= NULL;
					char	*cPartNo				= NULL;
					char	*rev_idd				= NULL;
					char	*status_name				= NULL;
					char	*EffvalueAfter				= NULL;
					char	*old_to_date_Rel_date				= NULL;
					logical stat1  ;
					tag_t	LpropEff_tag		= NULLTAG;
					tag_t	AftpropEff_tag		= NULLTAG;
					char 	*Effvalue				= NULL;
					char	*old_to_date			= NULL;
					tag_t   propEff_tagPre				    =NULLTAG;
					tag_t   All_item_tag				    =NULLTAG;
					date_t *Rel_start_end_values	= NULL;
					date_t Rel_Date;
					WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
					logical date_is_valid  ;
					date_t Ltest_date_1;
					date_t Ltest_date_2;
					date_t *Lstart_end_date			= NULL;
					tag_t	Leff_d				= NULLTAG;
					int jj=0;



					//// Going to update effectivity of previous data
					ifail = AOM_UIF_ask_value (object_tag, "item_id", &cPartNo);
					ifail = ITEM_find_item (cPartNo, &All_item_tag);

					ifail = ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list);
					printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

					if(Item_count > 1)
					{
						iiCnt=Item_count-2;
						ifail = AOM_UIF_ask_value (rev_list[iiCnt], "release_status_list", &rel_status);
						printf("\n Eff: Release Status is:%s.", rel_status);fflush(stdout);

						ifail = AOM_UIF_ask_value (rev_list[iiCnt], "item_revision_id", &rev_idd);
						printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);
						//if(tc_strcmp(rel_status, "APLC Review") == 0 || (strcmp(rel_status,"APL Review")==0) || tc_strcmp(rel_status,"T5_LcsAplReview")==0
						//   || tc_strcmp(rel_status, "APLV Review") == 0  || tc_strcmp(rel_status,"T5_LcsAplvReview")==0) //MBOM implementation for CV TZ-1.69
						if((tc_strcmp(rel_status,RvwLCActVal)==0) || (tc_strcmp(rel_status,RvwLCVal)==0))  //MBOM implementation for CV TZ-1.69
						{
							ifail = WSOM_ask_release_status_list (rev_list[iiCnt], &count_status, &status_lst);
							if(count_status > 0)
							{
								for(j=0;j<count_status;j++)
								{
									ifail = AOM_ask_value_string (status_lst[j], "object_name", &status_name);
									printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
									//if((tc_strcmp(status_name,"APLC Review")==0) || (strcmp(status_name,"APL Review")==0)  || tc_strcmp(status_name,"T5_LcsAplReview")==0
								    //|| tc_strcmp(status_name,"APLV Review")==0  || tc_strcmp(status_name,"T5_LcsAplvReview")==0) //MBOM implementation for CV TZ-1.69
									if((tc_strcmp(status_name,RvwLCActVal)==0) || (tc_strcmp(status_name,RvwLCVal)==0))  //MBOM implementation for CV TZ-1.69
									{
										printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
										if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
										printf("\n EFF1:stat1:%d",stat1);fflush(stdout);

										if(stat1 != true)
										{
											printf("\n EFF1:stat1 is not true .....");fflush(stdout);
										}
										else
										{
											printf("\n EFF1:stat1 is  true .....");fflush(stdout);
										}

										//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
										////if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
										//if(AOM_UIF_ask_name(LpropEff_tag,"effectivity_text",&Effvalue));
										//
										//printf("\n EFF1:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
										if(ITK_ok != (ifail = WSOM_status_ask_date_released (status_lst[j],&Rel_Date) )) return ifail;
										if(ITK_ok != (ifail = DATE_date_to_string(Rel_Date,"%d-%b-%Y %H:%M", &old_to_date_Rel_date )))
										{
											return ifail;
										}
										printf("\n Eff:old_to_date_Rel_date:[%s] ",old_to_date_Rel_date);fflush(stdout);

										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_lst[j],effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dtes);fflush(stdout);
												if(n_dtes > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
										}
										else
										{
											if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date_Rel_date, &date_is_valid,&Ltest_date_1 )))return ifail;
											if(date_is_valid != true)
											{
												printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
											}
											else
											{
												printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
											}

										}
										//Current Date

										printf("\n Eff:cCurrentAccessDate is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
										Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
										Lstart_end_date[0] = Ltest_date_1;
										Lstart_end_date[1] = Ltest_date_2;

										printf("\n EFF:Clearing effectivities...");fflush(stdout);

										if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
										{
											return ifail;
										}
										printf("\n EFF:Creating effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
										{
											return ifail;
										}
										printf("\n EFF:Saving effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
										{
											return ifail;
										}
										printf("\n EFF:Saving Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save_without_extensions(status_lst[j])))
										{
											return ifail;
										}
										printf("\n EFF:Refreshing Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
										{
											return ifail;
										}
										//printf("\n EFF:Checking effectivities txt...");fflush(stdout);
										//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))	 return ifail;
										////if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))	 return ifail;
										//
										//if(AOM_UIF_ask_name(AftpropEff_tag,"effectivity_text",&EffvalueAfter));
										//
										//printf("\n Eff:effectivity_text EffvalueAfter : %s\n",EffvalueAfter);fflush(stdout);

										if(ITK_ok != (ifail = AOM_refresh( rev_list[iiCnt], 0 )))
										{
											return ifail;
										}
									}
									else
									{
										printf("\n Eff: Status name:%s for rev:%s\n", status_name, rev_idd); fflush(stdout);
									}
									MEM_free(status_name);
								}
							}
							else
							{
								printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
							}
						}
					}
				}  // End for APL code
			 }
		else if((strcmp(ReleaseStatus,"ERC Review")==0) ||strcmp(ReleaseStatus,"T5_LcsReview")==0) 	// Start for ERC code
		{
			printf("\n Inside IF effectivty stamping code\n");
			if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat)))	 return ifail;
			printf("\n stat:%d\n",stat);

			if(stat != true)
			{
				printf("\n stat is not true .....\n");
			}
			else
			{
				printf("\n stat is  true .....\n");
			}

			getCurrentDateTime(cCurrentAccessDate);
			//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
			////if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
			//if(AOM_UIF_ask_name(propEff_tag,"effectivity_text",&value));
			//printf("\n effectivity_text is value : %s",value);

			//getNextDate(cNextDate);
			getNextMinute(cNextDate);
			printf("\n cNextDate:%s",cNextDate);
			//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

			if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
			{
				return ifail;
			}
			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			//printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_rel)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save_without_extensions(status_rel)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = AOM_refresh( status_rel, 0 )))
			{
				return ifail;
			}

			//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag)))	 return ifail;
			////if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
			//if(AOM_UIF_ask_name(propEff_tag,"effectivity_text",&value));
			//printf("\n After setting effectivity_text value : %s",value);

			if(ITK_ok != (ifail = AOM_refresh( object_tag, 0 )))
			{
				return ifail;
			}

			/// Previous revison

			tag_t	*rev_list				= NULL;
			tag_t	*status_lst				= NULL;
			tag_t	*effectivities_tag				= NULL;
			int Item_count=0;
			int iiCnt=0;
			int count_status=0,j=0,n_effectivities=0,n_dtes=0;
			char	*rel_status				= NULL;
			char	*cPartNo				= NULL;
			char	*rev_idd				= NULL;
			char	*status_name				= NULL;
			char	*EffvalueAfter				= NULL;
			char	*old_to_date_Rel_date				= NULL;
			logical stat1  ;
			tag_t	LpropEff_tag		= NULLTAG;
			tag_t	AftpropEff_tag		= NULLTAG;
			char 	*Effvalue				= NULL;
			char	*old_to_date			= NULL;
			tag_t   propEff_tagPre				    =NULLTAG;
			tag_t   All_item_tag				    =NULLTAG;
			date_t *Rel_start_end_values	= NULL;
			date_t Rel_Date;
			WSOM_open_ended_status_t  	EFFECTIVITY_stock_out ;
			logical date_is_valid  ;
			date_t Ltest_date_1;
			date_t Ltest_date_2;
			date_t *Lstart_end_date			= NULL;
			tag_t	Leff_d				= NULLTAG;
			int jj=0;



			//// Going to update effectivity of previous data
			ifail = AOM_UIF_ask_value (object_tag, "item_id", &cPartNo);
			ifail = ITEM_find_item (cPartNo, &All_item_tag);

			ifail = ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list);
			printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

			if(Item_count > 1)
			{
				iiCnt=Item_count-2;
				ifail = AOM_UIF_ask_value (rev_list[iiCnt], "release_status_list", &rel_status);
				printf("\n Eff: Release Status is:%s.", rel_status);fflush(stdout);

				ifail = AOM_UIF_ask_value (rev_list[iiCnt], "item_revision_id", &rev_idd);
				printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);
				if(tc_strcmp(rel_status, "ERC Review") == 0)
				{
					ifail = WSOM_ask_release_status_list (rev_list[iiCnt], &count_status, &status_lst);
					if(count_status > 0)
					{
						for(j=0;j<count_status;j++)
						{
							ifail = AOM_ask_value_string (status_lst[j], "object_name", &status_name);
							printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
							if((tc_strcmp(status_name,"ERC Review")==0) ||tc_strcmp(status_name,"T5_LcsReview")==0)
							{
								printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
								if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
								printf("\n EFF1:stat1:%d",stat1);fflush(stdout);

								if(stat1 != true)
								{
									printf("\n EFF1:stat1 is not true .....");fflush(stdout);
								}
								else
								{
									printf("\n EFF1:stat1 is  true .....");fflush(stdout);
								}

								//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
								////if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
								//if(AOM_UIF_ask_name(LpropEff_tag,"effectivity_text",&Effvalue));
								//printf("\n EFF1:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

								if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
								if(ITK_ok != (ifail = WSOM_status_ask_date_released (status_lst[j],&Rel_Date) )) return ifail;
								if(ITK_ok != (ifail = DATE_date_to_string(Rel_Date,"%d-%b-%Y %H:%M", &old_to_date_Rel_date )))
								{
									return ifail;
								}
								printf("\n Eff:old_to_date_Rel_date:[%s] ",old_to_date_Rel_date);fflush(stdout);

								printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
								if(n_effectivities > 0)
								{
									for(jj=0;jj<n_effectivities;jj++)
									{
										if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_lst[j],effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
										printf("\n Eff:no of Rel_start_end_value:%d\n", n_dtes);fflush(stdout);
										if(n_dtes > 0)
										{
											if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
											{
												return ifail;
											}
											printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
											if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
											{
												return ifail;
											}
											printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
											if(date_is_valid != true)
											{
												printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
											}
											else
											{
												printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
											}
										}
										else
										{
											printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
										}
									}
								}
								else
								{
									if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date_Rel_date, &date_is_valid,&Ltest_date_1 )))return ifail;
									if(date_is_valid != true)
									{
										printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
									}
									else
									{
										printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									}

								}
								//Current Date

								printf("\n Eff:cCurrentAccessDate is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
								if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
								{
									return ifail;
								}
								printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
								Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								Lstart_end_date[0] = Ltest_date_1;
								Lstart_end_date[1] = Ltest_date_2;

							//	printf("\n EFF:Clearing effectivities...");fflush(stdout);

								if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
								{
									return ifail;
								}
								printf("\n EFF:Creating effectivities...");fflush(stdout);
								if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
								{
									return ifail;
								}
							//	printf("\n EFF:Saving effectivities...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
								{
									return ifail;
								}
								printf("\n EFF:Saving Revision...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_save_without_extensions(status_lst[j])))
								{
									return ifail;
								}
								//printf("\n EFF:Refreshing Revision...");fflush(stdout);
								if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
								{
									return ifail;
								}
								printf("\n EFF:Checking effectivities txt...");fflush(stdout);
								//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))	 return ifail;
								////if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))	 return ifail;
								//if(AOM_UIF_ask_name(AftpropEff_tag,"effectivity_text",&EffvalueAfter));
								//printf("\n Eff:effectivity_text EffvalueAfter : %s",EffvalueAfter);fflush(stdout);

								if(ITK_ok != (ifail = AOM_refresh( rev_list[iiCnt], 0 )))
								{
									return ifail;
								}
							}
							else
							{
								printf("\n Eff: Status name:%s for rev:%s\n", status_name, rev_idd); fflush(stdout);
							}
							MEM_free(status_name);
						}
					}
					else
					{
						printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
					}
				}
			}
		} // End for ERC code
		printf("\n CR-FY24-0020: Standard Part: testing printf1");fflush(stdout);
	}

		printf("\n CR-FY24-0020: Standard Part: testing printf");fflush(stdout);

		if(relation_type)
		{
			CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==0)
			  {
				  printf("\nSetting Lifecycle State as ERC Review  For Dataset\n");
				  	 if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL))	//MBOM implementation for CV TZ-1.69
	                {
						 //status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAplReview");	//MBOM implementation for CV TZ-1.69
						 status = t5UpdateLifecycleStateAD(dataset, RvwLCVal);	//MBOM implementation for CV TZ-1.69
					}else
					  {
					  status = t5UpdateLifecycleStateAD(dataset, "T5_LcsReview");
					  }
				  printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			  }

			}
		}
		//ERROR_CALL(ITK_set_bypass(TRUE));

	////	if(AOM_refresh(object_tag,1)!=ITK_ok) PrintErrorStack();
	//	if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();

	//	if(AOM_unlock(object_tag));
		printf("\n After ERC Review. removed... \n");fflush(stdout);

		//Neha CR-FY24-0020
		char		*userid						= NULL;
		char		*proCode					= NULL;
		char		*prtNum						= NULL;
		char		*desGrpp					= NULL;
		int			istatusCnt					= 0;
		int			istatusCnt1					= 0;
		int			ia							= 0;
		int			ib							= 0;
		int			cunt1						= 0;
		tag_t		*iStatus_list				= NULLTAG;
		tag_t		*iStatus_list1				= NULLTAG;
		tag_t		tReleaseStatusList_checkin	= NULLTAG;
		char		*LatestRevRelSt				= NULL;
		char		*LatestRevRelSt1			= NULL;
		tag_t		status_rel1					= NULLTAG;
		logical     retain_released_date		= TRUE;
		int			CtrEtry						= 1;
		int			QryC						= 0;
		int			n_values_checkin			= 0;
		tag_t		CtrObjQryTag				= NULLTAG;
		tag_t		*CtrObjSet					= NULLTAG;
		tag_t*		attr_tags_checkin			= NULLTAG; 
		logical		*is_it_null_checkin			= NULL;
		logical		*is_it_empty_checkin		= NULL;
		char		*QryEtry[1]					= {"SYSCD"};
		char		**QryVal					= (char **) MEM_alloc(100 * sizeof(char *));
		char		*Supportinfo1				= NULL;

		SA_ask_user_identifier2 (user_tag,&userid);
		printf ("\n checkin_with_dataset Standard Part: Logged in user [%s] [%s] ",userid,username);fflush(stdout);

		//Neha CR-FY24-0020 --start
		ITK_CALL(QRY_find2("ControlObjQry", &CtrObjQryTag));
		if (CtrObjQryTag)
		{
			QryVal[0] = "StdPrtChkIn";
			ITK_CALL(QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet));
		}
		printf("\n checkin_with_dataset Standard Part: StdPrtChkIn Control object found = [%d]",QryC);fflush(stdout);

		if(QryC > 0)
		{
			if(AOM_ask_value_string(CtrObjSet[0],"t5_Userinfo1",&Supportinfo1)!=ITK_ok) PrintErrorStack();
			printf("\n checkin_with_dataset Standard Part: StdPrtChkIn Supportinfo1 is : [%s] \n current Session username : [%s]\t userid = [%s]", Supportinfo1,username,userid);fflush(stdout);

			if(tc_strstr(Supportinfo1,userid))
			{
				if(AOM_ask_value_string(object_tag,"item_id",&prtNum)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(object_tag,"t5_ProjectCode",&proCode)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(object_tag,"t5_DesignGrp",&desGrpp)!=ITK_ok) PrintErrorStack();
				printf("\n checkin_with_dataset Standard Part:Part Numberr[%s]\tProject codee[%s]\tDesign groupp[%s]",prtNum,proCode,desGrpp);fflush(stdout);

				if (WSOM_ask_release_status_list(object_tag,&istatusCnt,&iStatus_list)!=ITK_ok) PrintErrorStack();
				printf("\n checkin_with_dataset Standard Part: iStatus_list: [%d] => ", istatusCnt);fflush(stdout);
				for (ia = 0; ia < istatusCnt ; ia++)
				{
					if (AOM_ask_name(iStatus_list[ia], &LatestRevRelSt)!=ITK_ok) PrintErrorStack();
					printf("\t :%s ", LatestRevRelSt);fflush(stdout);

					if((tc_strcmp(LatestRevRelSt,"T5_LcsErcRlzd")!=0) || (tc_strstr(LatestRevRelSt,"ERC Released") == NULL))
					{
						if(tc_strcmp(proCode,"1111")==0 && tc_strcmp(desGrpp,"11")==0)
						{
							printf("\n checkin_with_dataset Standard Part: Inside if condition of project code is 1111 and design group is 11");fflush(stdout);
							
							CALLAPI(POM_class_of_instance(object_tag,&class_id));
							CALLAPI(POM_name_of_class(class_id,&class_name));
							printf("\n checkin_with_dataset class_name is :%s\n",class_name);fflush(stdout);

							CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

							CALLAPI(POM_unload_instances (1,&object_tag));
							CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
							CALLAPI(POM_is_loaded(object_tag,&log1));
							if(log1 == 1)
							{
								 printf(" checkin_with_dataset : Load Success\n");fflush(stdout);
							}
							else
							{
								printf(" checkin_with_dataset : Load Failure\n" );fflush(stdout);
							}

							CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
							printf(" checkin_with_dataset : n_values is :%d\n",n_values_checkin);fflush(stdout);
							if(n_values_checkin>0)
							{
								CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
								printf(" checkin_with_dataset : n_values11 is :%d\n",n_values_checkin);fflush(stdout);

								for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
								{
									printf(" checkin_with_dataset : Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
									CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
									printf(" checkin_with_dataset : After POM_remove_from_attr \n");fflush(stdout);
									CALLAPI(POM_save_instances(1,&object_tag,1));
									printf(" checkin_with_dataset : After POM_save_instances \n");fflush(stdout);
									CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));
									printf(" checkin_with_dataset : After POM_refresh_instances \n");fflush(stdout);
									CALLAPI(AOM_lock(object_tag));
									printf(" checkin_with_dataset : After AOM_lock \n");fflush(stdout);
									CALLAPI(AOM_save_without_extensions(object_tag));
									printf(" checkin_with_dataset : After AOM_save_without_extensions \n");fflush(stdout);
									CALLAPI(AOM_refresh(object_tag,1));
									printf(" checkin_with_dataset : After AOM_refresh \n");fflush(stdout);
								}
								CALLAPI(AOM_unlock(object_tag));
								printf(" checkin_with_dataset : After AOM_unlock \n");fflush(stdout);
							}
							CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel1));
							CALLAPI(RELSTAT_add_release_status(status_rel1,1,&object_tag,retain_released_date));
							CALLAPI(AOM_refresh(object_tag,1));
							CALLAPI(AOM_save_without_extensions(object_tag));
							printf(" checkin_with_dataset : ****After successfully erc release status stamped****\n");fflush(stdout);
						}
					}
				}
			}
			else
			{
				printf("\n checkin_with_dataset Standard Part: %s user is not available in control object of StdPrtChkIn userinfo1\n",userid);fflush(stdout);
			}
		}

		//Neha CR-FY24-0020 --end
	}

	/*	If Condition added for reason :-
			A] Pro/E Data Should be in Checked Out state on Save.
			B] On Check-In Of Dataset or Design Revision Check-In of Pro/E Dataset should not be affected.
		Also existing functionality of Check-In of Design Revision along with Pro/E Dataset is overridden .
		Added in TZ 1.27 by Anu Nair on 12/12/2017.
	*/
	if((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0) || (strcmp(type_name,"ProDrw")==0))
	{

		if(relation_type)
		{
			CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_primary_objects_only(object_tag,relation_type,&cnt1,&primary_objects));
			printf("\n Primary Objects Count is :%d\n",cnt1);fflush(stdout);
			for(i=0;i<cnt1;i++)
			{
				dataset = primary_objects[i];
				CALLAPI(RES_is_checked_out(dataset,&checkout));
				printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
				if (checkout)
				{
					printf("\nInside If Condition to Check Whether Design Revision is Checked Out..\n");
					if(RES_is_checked_out(object_tag,&checkout1) !=ITK_ok) PrintErrorStack();
					if (!checkout1)
					{
						if (RES_checkout2(object_tag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
						printf("\nDataSet Checked Out \n");

					}
					else
					{
						printf("\nSkipping as DataSet already Checked Out\n");
					}
				}
			}
		}
		//End of Added in TZ 1.27 by Anu Nair.

	//		printf("\n other than DR for skk TypeName for Checkin is [%s]\n",type_name);fflush(stdout);
	//
	//
	//		    if(relation_type)
	//		    {
	//			     printf("\n inside other than DR for skk relation_type for Checkin is [%s]\n",type_name);fflush(stdout);
	//			     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count1,&primary_list1));
	//		    }
	//		if(primary_list1)
	//		{
	//				   printf("\n inside other than DR for skk primary_list1 for Checkin is [%s]\n",type_name);fflush(stdout);
	//				printf("\n\n  primary object Attached to dataset in in checkin_with_dataset:%d\n",count1);
	//
	//				for(j=0;j<count1;j++)
	//				{
	//				   primary_object1 = primary_list1[j].primary;
	//				   if(primary_object1)
	//				   {
	//				 	 printf("\nprimary_object 1in skk checkin :%d\n",j);
	//					  CALLAPI(RES_is_checked_out(primary_object1,&checkout1));
	//				//   if (checkout1==1)
	//				   if (checkout1)
	//				{
	//						 	//PrintErrorStack();
	//						  printf("\n inside DR for ProAsmmmmmmmmmmmmmmmmmm calling CALLAPI2 \n");
	//						    printf("\n PrintErrorStack before  in Design revision for  PROE \n");
	//						 CALLAPI(RES_checkin(primary_object1));
	//						   printf("\n PrintErrorStack  calling CALLAPI2 \n");
	//						  	//PrintErrorStack();
	//						  printf("\n checked in Design revision for  PROE \n");
	//				}
	//				}
	//			  }
	//		 }
	}


	/*Abhishek Code ends here*/
	if ((strcmp(type_name,"T5_TMCAEModelRevision") == 0)||(strcmp(type_name,"T5_TMCAEAnalysisRevision") == 0)) //Adi new
	{
		printf("\n Inside Type Name :%s\n",type_name);fflush(stdout);
		CALLAPI(GRM_find_relation_type("IMAN_reference",&relation_type));
		if(relation_type)
		{
			CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==1)
			  {
					CALLAPI(RES_checkin(dataset));
					printf("\n %d DataSet Checked In \n",i+1);
			  }

			}
		}

		if( AOM_ask_value_string(object_tag,"gov_classification",&gov_classification)!=ITK_ok) PrintErrorStack();
		printf("\ngov_classification:%s",gov_classification);fflush(stdout);
		if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)
		{
						return ITK_ok;
		}


		if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok) PrintErrorStack();
		printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

		if (BomViewCnt > 0)
		{
			printf("\nCheckin BOM Views Also .............\n");fflush(stdout);
			for(iVwCnt=0;iVwCnt<BomViewCnt;iVwCnt++)
			{
				printf("\nCheckin [%d] View\n",iVwCnt+1);fflush(stdout);
				if (RES_checkin(BomViewList[iVwCnt])!=ITK_ok) PrintErrorStack();

				status = t5UpdateLifecycleStateAD(BomViewList[iVwCnt], "T5_LcsReview");
				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			}
		}

		printf("\n Before ERC Review.... \n");fflush(stdout);
		CALLAPI(POM_class_of_instance(object_tag,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

		CALLAPI(POM_unload_instances (1,&object_tag));
		CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
		CALLAPI(POM_is_loaded(object_tag,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
		printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		if(n_values_checkin>0)
		{
			CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
			printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save_without_extensions(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));

			}
			CALLAPI(AOM_unlock(object_tag));
		}

		if (RELSTAT_create_release_status("T5_LcsReview",&status_rel)!=ITK_ok) PrintErrorStack();
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)!=ITK_ok) PrintErrorStack();

		if(relation_type)
		{
			CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
			printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
			CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
			printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
			for(i=0;i<cnt;i++)
			{
			  printf("\nin checkin for loop\n");fflush(stdout);
			  dataset = attachments[i];
			  CALLAPI(RES_is_checked_out(dataset,&checkout));
			  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
			  if (checkout==0)
			  {
				  printf("\nSetting Lifecycle State as ERC Review  For Dataset\n");
				  status = t5UpdateLifecycleStateAD(dataset, "T5_LcsReview");
				  printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			  }

			}
		}
		printf("\n After ERC Review. removed... \n");fflush(stdout);
	}


	
								
		//Deepti Added TZ1.56
		if ((strcmp(type_name,"Design Revision") == 0))
		{
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="MBOMDet";
			qry_valuesCntrl1[1]="CheckIn";
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Control Object Query not Found for MBOMDet during Check in \n");fflush(stdout);
		}
		
		if(control_number_found1>0)
		{
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleNameAPL111 : %s\n",roleName); fflush(stdout);
			if((tc_strstr(roleName,"APL")!=NULL)  || (tc_strstr(roleName,"MBOM")!=NULL))	//MBOM implementation for CV TZ-1.69
			{
			
				printf("\n Control Object Query Found for MBOMDet during Check in \n");fflush(stdout);

				if( AOM_ask_value_string(object_tag,"item_id",&desidForAPL)!=ITK_ok) PrintErrorStack();
				printf("\n desidForAPL is  = [%s]\n", desidForAPL);fflush(stdout);	

				if (AOM_ask_value_string(object_tag,"t5_PartType",&DesgTypAPL)!=ITK_ok) PrintErrorStack();
				printf("\n DesgTypAPL is  = [%s]\n", DesgTypAPL);fflush(stdout);
				



				//venkat TZ-1.82 back end

				char    *fram_entryCntr1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
				char	**frame_valuesCntr1   = (char **) MEM_alloc(5 * sizeof(char *));
				tag_t   framqryTagCntr1						= NULLTAG;
				tag_t*	list_fram_tags						= NULLTAG;
				int     n_entryCntr1						= 3;
				int     frmcntrlcn							= 0;
				int						cntrlcnt_1			=0;
				int						fram_cnt			=0;
				char *partno								= NULL;
				char *f9y01property_values					= NULL;
				char *f9y02parttype					= NULL;
				char *Parttype					= NULL;
				char *ModuleAddress					= NULL;
				char *Module_attribute_name					= NULL;
				char *Module_f9y01					= NULL;

				char	*f9y01Err =	NULL;
				f9y01Err=(char *) MEM_alloc(100);
				if( QRY_find2("Control Objects...", &framqryTagCntr1));
				if (framqryTagCntr1)
				{
					printf("\n venkat query Control Object Frame module is found \n");fflush(stdout);
					frame_valuesCntr1[0]="Framemoduleccheckin";
					frame_valuesCntr1[1]="Postaction";  
					frame_valuesCntr1[2]="0";

					if( AOM_UIF_ask_value(object_tag,"t5_PartType",&f9y02parttype)!=ITK_ok) PrintErrorStack();
					//ITKCALL(AOM_UIF_ask_value(apl_task,"t5_crdesigngroup",&TskDgnGrp));
					if( AOM_UIF_ask_value(object_tag,"item_id",&partno)!=ITK_ok) PrintErrorStack();
					printf("\n venkat query Control Object Frame module  :%s :%s \n",f9y02parttype,partno);fflush(stdout);

					if(QRY_execute(framqryTagCntr1, n_entryCntr1, fram_entryCntr1, frame_valuesCntr1, &fram_cnt, &list_fram_tags));

					if(fram_cnt>0)
					{
						for (frmcntrlcn = 0; frmcntrlcn < fram_cnt; frmcntrlcn++)
						{

							if( AOM_ask_value_string(list_fram_tags[frmcntrlcn], "t5_Userinfo1", &Module_f9y01)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(list_fram_tags[frmcntrlcn], "t5_Userinfo2", &ModuleAddress)!=ITK_ok)PrintErrorStack(); //f9y02
							if( AOM_ask_value_string(list_fram_tags[frmcntrlcn], "t5_Userinfo3", &Module_attribute_name)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(list_fram_tags[frmcntrlcn], "t5_Userinfo4", &Parttype)!=ITK_ok)PrintErrorStack();
						
							printf("\nFrame module part Address : %s part no  : %s  and require attribute name : %s \n",Parttype,partno,Module_attribute_name);fflush(stdout);
								

							printf("\n checkin_method_1--c.modification Desc Part type for parttypn----------------->>> [%s] : %s : %s",f9y02parttype ,partno,Module_f9y01);fflush(stdout);
							if ((tc_strstr(partno,Module_f9y01)!=NULL)&&(strcmp(f9y02parttype,Parttype)==0))
							{
								//ITKCALL(AOM_ask_value_string(object_tag,Module_attribute_name,&f9y01property_values));
								ITKCALL(AOM_UIF_ask_value(object_tag,Module_attribute_name,&f9y01property_values));

								if(strcmp(f9y01property_values,"")==0)
								{
								

										if (!f9y01Err) MEM_free(f9y01Err);
										tc_strcpy (f9y01Err, "Please check the Plant Frame Applicabity :  ");
										
										tc_strcat(f9y01Err,partno);
										printf("\n checkin_method_1-- venkat Part frame applicability flag \n ");fflush(stdout);
										
										EMH_clear_errors();
										
										EMH_store_error_s1(EMH_severity_information, ITK_errStore, f9y01Err);

										decision = EPM_go;
										return decision;


									}
							}
									
						}
					}
				}

				//if(tc_strcmp(DesgTypAPL,"SA" )==0)
				if( (tc_strcmp(DesgTypAPL,"SA" )==0) || ( (tc_strstr(roleName,"MBOM")!=NULL) && (tc_strcmp(DesgTypAPL,"M" )==0) ))		//MBOM implementation for CV TZ-1.70
				{
			
					printf("\n Inside SA/Module Check in \n");fflush(stdout);

					if(tc_strstr(roleName,"MBOM")!=NULL)	//MBOM implementation for CV TZ-1.70 -- CC
					{
						roleNameDupVal = NULL;
						roleNameDupVal=(char *) MEM_alloc(30);
						strcpy(roleNameDupVal,roleName);
						
						DsgModName = strtok(roleNameDupVal,"_");
						PlantName = strtok(NULL,"_");	
						printf( "PlantName:%s ,DsgModName :%s\n",PlantName,DsgModName);fflush(stdout);
					}
					else
					{

						PlantName=subString(roleName,3,4);
						printf( "PlantName:%s\n", PlantName);fflush(stdout);
					}
					
					char	BVRInfo[40];
					char	RRInfo[40];
					char	CRInfo[40];
					char	RlsStInf[40];
					flagBVR=0;
					SetChildRelErrWS = (char**)MEM_alloc( 1 * sizeof *SetChildRelErrWS );
					SetChildRelErrAcnt = (char**)MEM_alloc( 1 * sizeof *SetChildRelErrAcnt );
					SetChildRelErrALngth = (char**)MEM_alloc( 1 * sizeof *SetChildRelErrALngth );
					SetChildRelStudErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelStudErr );

					GetPlantWiseAPLBomInfort(PlantName,BVRInfo,RRInfo,CRInfo,RlsStInf);//MBOM implementation for CV TZ-1.70-Attribute Name Change
					printf("\n BVRInfo %s,RRInfo %s ,CRInfo %s,RlsStInf %s\n",BVRInfo,RRInfo,CRInfo,RlsStInf);fflush(stdout);	

					ITKCALL(ITEM_rev_list_bom_view_revs(object_tag, &n_values_bvr, &bvr_assy_part));
					printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

					if(n_values_bvr==0)
					{
						flagBVR=0;
					}
					else if(n_values_bvr>0)
					{
						printf("\n BVR found");fflush(stdout);
						for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						{
							ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							printf("\n view_name %s",view_name);fflush(stdout);
							partTok = strtok (view_name,"-");
							viewTok = strtok (NULL,"-");
							printf("\n viewTok %s",viewTok);fflush(stdout);
							if(strlen(viewTok)>0)
							{
								//if(tc_strcmp(viewTok,BVR)==0)
								if(tc_strcmp(viewTok,BVRInfo)==0) //MBOM implementation for CV TZ-1.70-CC
								{
									flagBVR=1;
									bvr_tag=bvr_assy_part[assbvr];
									break;
								}
							}
						}
						if(flagBVR!=1)
						{
							for(assbvr=0;assbvr<n_values_bvr;assbvr++)
							{
								ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
								printf("\n view_name %s",view_name);fflush(stdout);
								partTok = strtok (view_name,"-");
								viewTok = strtok (NULL,"-");
								printf("\n viewTok %s",viewTok);fflush(stdout);
								if(strlen(viewTok)>0)
								{
									if(tc_strcmp(viewTok,"View")==0)
									{
										flagBVR=1;
										bvr_tag=bvr_assy_part[assbvr];
										break;
									}
								}
							}
						}

					}
					printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

					char    *qry_entryCntrlformat[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
					char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
					tag_t   qryTagCntrlobj     = NULLTAG;
					int     n_entryCntrlobj    = 3;

					int controlObjfound=0;
					tag_t *list_of_cntrl_tags=NULLTAG;

					if(QRY_find2("Control Objects...", &qryTagCntrlobj));
					if (qryTagCntrlobj)
					{
						printf("\n Control Object Query Found \n");fflush(stdout);
						qry_valuesCntrlformat[0]="StudLogic";
						qry_valuesCntrlformat[1]="Values";
						qry_valuesCntrlformat[2]="0";

						if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
					}
					else
					{
						printf("\n Control Object Query not Found for optional cs carryforward... \n");fflush(stdout);
					}	

					printf("\n controlObjfound for optional cs carryforward is : %d\n",controlObjfound);fflush(stdout);

					tag_t   rule_sa					=	NULLTAG;

					ITKCALL(BOM_create_window (&window_sa));
					printf("\n find occurence..window_sa");fflush(stdout);
					ITKCALL(CFM_find( RRInfo, &rule_sa));
					printf("\n find occurence..rule_sa");fflush(stdout);
					ITKCALL(BOM_set_window_config_rule( window_sa, rule_sa ));
					printf("\n configure occurence..rule_sa");fflush(stdout);
					ITKCALL(BOM_set_window_top_line(window_sa, null_tag,object_tag , bvr_tag, &top_line_sa));
					ITKCALL(BOM_line_ask_child_lines (top_line_sa, &nClhd_sa, &children_sa));
					printf("\n nClhd_sa %d,",nClhd_sa);fflush(stdout);
					if (nClhd_sa >0)
					{
						fndSE=0;	//MBOM implementation for CV TZ-1.70
						fndWE=0;	//MBOM implementation for CV TZ-1.70
						if(tc_strstr(roleName,"MBOM")!=NULL) //MBOM implementation for CV TZ-1.70 Start
						{
							saCntM=0;
							for (saCntM=0;saCntM<nClhd_sa;saCntM++) //MBOM implementation for CV TZ-1.70
							{
								if(BOMLinetagM) BOMLinetagM=NULLTAG;
								BOMLinetagM=children_sa[saCntM];

								childPartsOfSAM=NULL;
								childPartsTypeOfSAM=NULL;

								ITKCALL(AOM_ask_value_string(BOMLinetagM, "bl_item_item_id", &childPartsOfSAM));
								printf("\n childPartsOfSAM:%s",childPartsOfSAM);fflush(stdout);

								//ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_PartType", &childPartsTypeOfSAM));
								ITKCALL(AOM_ask_value_string(BOMLinetagM, "bl_Design_t5_RevPartType", &childPartsTypeOfSAM));//MBOM implementation for CV TZ-1.70
								printf("\n childPartsTypeOfSAM:::%s",childPartsTypeOfSAM);fflush(stdout);
								
								if((tc_strstr(childPartsOfSAM,"_SE")!=NULL) && ((tc_strcmp(childPartsTypeOfSAM,"D")==0) || (tc_strcmp(childPartsTypeOfSAM,"DA")==0)|| (tc_strcmp(childPartsTypeOfSAM,"DC")==0) ))
								{
									fndSE++;									
								}
								if( (tc_strstr(childPartsOfSAM,"_WE")!=NULL) && ((tc_strcmp(childPartsTypeOfSAM,"D")==0) || (tc_strcmp(childPartsTypeOfSAM,"DA")==0)|| (tc_strcmp(childPartsTypeOfSAM,"DC")==0) ))
								{
									fndWE++;
								}

								if((fndSE >0) && (fndWE>0))
								{
									break;
								}
							}							
						}
						//MBOM implementation for CV TZ-1.70 End

						if((tc_strstr(roleName,"APL")!=NULL)  || ( (tc_strstr(roleName,"MBOM")!=NULL) && ( (fndWE>0) || (fndSE>0))))	//MBOM implementation for CV TZ-1.70
						{
							saCCnt=0;
							for (saCCnt=0;saCCnt<nClhd_sa;saCCnt++ )
							{
								studLogicmatch=0;
								if(BOMLinetag) BOMLinetag=NULLTAG;
								BOMLinetag=children_sa[saCCnt];

								childPartsOfSA=NULL;
								childPartsRevOfSA=NULL;
								childPartsTypeOfSA=NULL;

								ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_item_item_id", &childPartsOfSA));
								printf("\n childPartsOfSA:%s",childPartsOfSA);fflush(stdout);

								ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_rev_item_revision_id", &childPartsRevOfSA));
								printf("\n childPartsRevOfSA: %s",childPartsRevOfSA);fflush(stdout);
								
								//ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_PartType", &childPartsTypeOfSA));
								ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design_t5_RevPartType", &childPartsTypeOfSA)); //MBOM implementation for CV TZ-1.70
								printf("\n childPartsTypeOfSA:::%s",childPartsTypeOfSA);fflush(stdout);

								//if( (tc_strcmp(childPartsTypeOfSA,"SA")==0) )	//MBOM implementation for CV TZ-1.70
								if( ((tc_strstr(roleName,"APL")!=NULL) && (tc_strcmp(childPartsTypeOfSA,"SA")==0)) || ( (tc_strstr(roleName,"MBOM")!=NULL) && (((tc_strcmp(childPartsTypeOfSA,"D")==0) || (tc_strcmp(childPartsTypeOfSA,"DA")==0)|| (tc_strcmp(childPartsTypeOfSA,"DC")==0) ) && (tc_strstr(childPartsOfSA,"_WE")!=NULL))))
								{
									
									childPartsNoOfWeldSpt=NULL;
									childPartsArcCnt=NULL;
									childPartsArcLenght=NULL;

									ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_rev_t5_NoOfWeldSpots", &childPartsNoOfWeldSpt));
									printf("\n childPartsNoOfWeldSpt %s",childPartsNoOfWeldSpt);fflush(stdout);
										
									intchildPartsNoOfWeldSpt=atof(childPartsNoOfWeldSpt);				//Total Weld Spot
									printf("\n intchildPartsNoOfWeldSpt :%f",intchildPartsNoOfWeldSpt);fflush(stdout);

									TotalNoOfWeldSpots=TotalNoOfWeldSpots+intchildPartsNoOfWeldSpt;
									printf("\n TotalNoOfWeldSpots :%f",TotalNoOfWeldSpots);fflush(stdout);

									ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_ArcCount", &childPartsArcCnt));
									printf("\n childPartsArcCnt %s",childPartsArcCnt);fflush(stdout);

									intchildPartsArcCnt=atof(childPartsArcCnt);						//Total Arc Count
									printf("\n intchildPartsArcCnt :%f",intchildPartsArcCnt);fflush(stdout);

									TotalNoOfArcCnt=TotalNoOfArcCnt+intchildPartsArcCnt;
									printf("\n TotalNoOfArcCnt :%f",TotalNoOfArcCnt);fflush(stdout);

									ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_ArcWeld", &childPartsArcLenght));
									printf("\n childPartsArcLenght %s",childPartsArcLenght);fflush(stdout);

									intchildPartsArcLenght=atof(childPartsArcLenght);						//Total Arc Length
									printf("\n intchildPartsArcLenght :%f",intchildPartsArcLenght);fflush(stdout);

									TotalNoOfArcLengh=TotalNoOfArcLengh+intchildPartsArcLenght;
									printf("\n TotalNoOfArcLengh :%f",TotalNoOfArcLengh);fflush(stdout);

									printf("\n iErrCnt :%d",iErrCnt);fflush(stdout);


									if (iErrCnt	==	0)
									{
										iErrCnt	=	1;
										
										ChildRelWeldSpotErr=NULL;
										ChildRelWeldSpotErr=(char *)MEM_alloc(300);				//WeldSpot
										tc_strcpy(ChildRelWeldSpotErr,"");
										tc_strcpy(ChildRelWeldSpotErr," WeldSpot Data: \n");
										tc_strcat(ChildRelWeldSpotErr,childPartsOfSA);
										tc_strcat(ChildRelWeldSpotErr,";");
										tc_strcat(ChildRelWeldSpotErr,childPartsRevOfSA);
										tc_strcat(ChildRelWeldSpotErr," : ");
										tc_strcat(ChildRelWeldSpotErr,childPartsNoOfWeldSpt);
										tc_strcat(ChildRelWeldSpotErr,";");
										tc_strcat(ChildRelWeldSpotErr,"\n");

										ChildRelArcCntErr=NULL;
										ChildRelArcCntErr=(char *)MEM_alloc(300);				//Arc Count
										tc_strcpy(ChildRelArcCntErr,"");
										tc_strcpy(ChildRelArcCntErr," Arc Count Data: \n");
										tc_strcat(ChildRelArcCntErr,childPartsOfSA);
										tc_strcat(ChildRelArcCntErr,";");
										tc_strcat(ChildRelArcCntErr,childPartsRevOfSA);
										tc_strcat(ChildRelArcCntErr," : ");
										tc_strcat(ChildRelArcCntErr,childPartsArcCnt);
										tc_strcat(ChildRelArcCntErr,";");
										tc_strcat(ChildRelArcCntErr,"\n");

										ChildRelArcLengthErr=NULL;
										ChildRelArcLengthErr=(char *)MEM_alloc(300);				//Arc Length
										tc_strcpy(ChildRelArcLengthErr,"");
										tc_strcpy(ChildRelArcLengthErr," Arc Length Data: \n");
										tc_strcat(ChildRelArcLengthErr,childPartsOfSA);
										tc_strcat(ChildRelArcLengthErr,";");
										tc_strcat(ChildRelArcLengthErr,childPartsRevOfSA);
										tc_strcat(ChildRelArcLengthErr," : ");
										tc_strcat(ChildRelArcLengthErr,childPartsArcLenght);
										tc_strcat(ChildRelArcLengthErr,";");
										tc_strcat(ChildRelArcLengthErr,"\n");

										setAddStr1(&icountWS,&SetChildRelErrWS,ChildRelWeldSpotErr);
										setAddStr1(&icountAcnt,&SetChildRelErrAcnt,ChildRelArcCntErr);
										setAddStr1(&icountALngth,&SetChildRelErrALngth,ChildRelArcLengthErr);

										printf("\n ChildRelWeldSpotErr :%s",ChildRelWeldSpotErr);fflush(stdout);
										printf("\n ChildRelArcCntErr :%s",ChildRelArcCntErr);fflush(stdout);
										printf("\n ChildRelArcLengthErr :%s",ChildRelArcLengthErr);fflush(stdout);
									}
									else
									{
										ChildRelWeldSpotErr=NULL;
										ChildRelWeldSpotErr=(char *)MEM_alloc(300);			//WeldSpot
										tc_strcpy(ChildRelWeldSpotErr," ");
										tc_strcat(ChildRelWeldSpotErr,childPartsOfSA);
										tc_strcat(ChildRelWeldSpotErr,";");
										tc_strcat(ChildRelWeldSpotErr,childPartsRevOfSA);
										tc_strcat(ChildRelWeldSpotErr," : ");
										tc_strcat(ChildRelWeldSpotErr,childPartsNoOfWeldSpt);
										tc_strcat(ChildRelWeldSpotErr,";");
										tc_strcat(ChildRelWeldSpotErr,"\n");

										ChildRelArcCntErr=NULL;
										ChildRelArcCntErr=(char *)MEM_alloc(300);			//Arc Count
										tc_strcpy(ChildRelArcCntErr," ");
										tc_strcat(ChildRelArcCntErr,childPartsOfSA);
										tc_strcat(ChildRelArcCntErr,";");
										tc_strcat(ChildRelArcCntErr,childPartsRevOfSA);
										tc_strcat(ChildRelArcCntErr," : ");
										tc_strcat(ChildRelArcCntErr,childPartsArcCnt);
										tc_strcat(ChildRelArcCntErr,";");
										tc_strcat(ChildRelArcCntErr,"\n");

										ChildRelArcLengthErr=NULL;
										ChildRelArcLengthErr=(char *)MEM_alloc(300);			//Arc Length
										tc_strcpy(ChildRelArcLengthErr," ");
										tc_strcat(ChildRelArcLengthErr,childPartsOfSA);
										tc_strcat(ChildRelArcLengthErr,";");
										tc_strcat(ChildRelArcLengthErr,childPartsRevOfSA);
										tc_strcat(ChildRelArcLengthErr," : ");
										tc_strcat(ChildRelArcLengthErr,childPartsArcLenght);
										tc_strcat(ChildRelArcLengthErr,";");
										tc_strcat(ChildRelArcLengthErr,"\n");

										setAddStr1(&icountWS,&SetChildRelErrWS,ChildRelWeldSpotErr);
										setAddStr1(&icountAcnt,&SetChildRelErrAcnt,ChildRelArcCntErr);
										setAddStr1(&icountALngth,&SetChildRelErrALngth,ChildRelArcLengthErr);

										printf("\n 111 ChildRelWeldSpotErr :%s",ChildRelWeldSpotErr);fflush(stdout);
										printf("\n 222 ChildRelArcCntErr :%s",ChildRelArcCntErr);fflush(stdout);
										printf("\n 333 ChildRelArcLengthErr :%s",ChildRelArcLengthErr);fflush(stdout);
									}
									
									
								}

								if( ((tc_strstr(roleName,"APL")!=NULL) && (tc_strcmp(childPartsTypeOfSA,"SA")==0)) || ( ((tc_strcmp(childPartsTypeOfSA,"D")==0)|| (tc_strcmp(childPartsTypeOfSA,"DA")==0) ||(tc_strcmp(childPartsTypeOfSA,"DC")==0) ) && (tc_strstr(childPartsOfSA,"_SE")!=NULL)))
								{
									printf("\n Inside Dummy _SE part logic");fflush(stdout);

									childPartsNoOfWeldSpt=NULL;
									childPartsArcCnt=NULL;
									childPartsArcLenght=NULL;


									ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_SealLen", &childPartsSeaLenght));
									printf("\n childPartsSeaLenght %s",childPartsSeaLenght);fflush(stdout);

									intchildPartsSeaLenght=atof(childPartsSeaLenght);						//Total Sealant Length
									printf("\n intchildPartsSeaLenght :%f",intchildPartsSeaLenght);fflush(stdout);

									TotalNoOfSeaLenght=TotalNoOfSeaLenght+intchildPartsSeaLenght;
									printf("\n TotalNoOfSeaLenght :%f",TotalNoOfSeaLenght);fflush(stdout);

									ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_Design Revision_t5_SealantType", &childPartsSeaType));
									printf("\n childPartsSeaType %s",childPartsSeaType);fflush(stdout);

									if (iErrCnt2	==	0)
									{
										iErrCnt2	=	1;
										
										ChildRelSealErr=NULL;
										ChildRelSealErr=(char *)MEM_alloc(300);				//Sealant
										tc_strcpy(ChildRelSealErr,"");
										tc_strcpy(ChildRelSealErr," Sealant Data: \n");
										tc_strcat(ChildRelSealErr,childPartsOfSA);
										tc_strcat(ChildRelSealErr,";");
										tc_strcat(ChildRelSealErr,childPartsRevOfSA);
										tc_strcat(ChildRelSealErr," : ");
										tc_strcat(ChildRelSealErr,childPartsSeaLenght);
										tc_strcat(ChildRelSealErr,";");
										tc_strcat(ChildRelSealErr,"\n");

										setAddStr1(&icountSeal,&SetChildRelErrSeal,ChildRelSealErr);
										
										printf("\n ChildRelSealErr :%s",ChildRelSealErr);fflush(stdout);
									}
									else
									{
										ChildRelSealErr=NULL;
										ChildRelSealErr=(char *)MEM_alloc(300);			//Sealant
										tc_strcpy(ChildRelSealErr," ");
										tc_strcat(ChildRelSealErr,childPartsOfSA);
										tc_strcat(ChildRelSealErr,";");
										tc_strcat(ChildRelSealErr,childPartsRevOfSA);
										tc_strcat(ChildRelSealErr," : ");
										tc_strcat(ChildRelSealErr,childPartsSeaLenght);
										tc_strcat(ChildRelSealErr,";");									
										tc_strcat(ChildRelSealErr,"\n");									

										printf("\n 111 ChildRelSealErr :%s",ChildRelSealErr);fflush(stdout);

										setAddStr1(&icountSeal,&SetChildRelErrSeal,ChildRelSealErr);
										
									}

														
								}

								if(controlObjfound>0)
								{
								
									for (stdCnt=0;stdCnt<controlObjfound ;stdCnt++ ) 
									{
											printf("\n stdCnt:%d",stdCnt);fflush(stdout);
											studCntObjTag  =    list_of_cntrl_tags[stdCnt]; 

											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo1",&info1r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo2",&info2r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo3",&info3r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo4",&info4r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo5",&info5r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo6",&info6r));
											ITKCALL(AOM_ask_value_string(studCntObjTag,"t5_Userinfo7",&info7r));
											
											printf("\n info3r:%s:%s:%s",info1r,info2r,info3r);fflush(stdout);

											if(tc_strcmp(info1r,"")==0)
											{
												projectcodeCheck = tc_strtok(info1r,",");
												digitCompCheck = tc_strtok(NULL,",");
											}

											printf("\n projectcode:%s:%s",projectcodeCheck,digitCompCheck);fflush(stdout);
									
									}

									printf("\n tc_strlen(childPartsOfSA) %d",tc_strlen(childPartsOfSA));fflush(stdout);

									if(tc_strlen(childPartsOfSA)==11)
									{
									
										 PrtNumStudTemp=subString(childPartsOfSA,0,4);
										 printf( "PrtNumStudTemp:%s:projectcode %s\n", PrtNumStudTemp,projectcodeCheck);fflush(stdout);
										 if(tc_strcmp(PrtNumStudTemp,projectcodeCheck)==0)
										 {
											ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_quantity", &relQty));
											printf("\n relQty %s",relQty);fflush(stdout);

											floatrelQty=atof(relQty);

											TotalfloatrelQtyProjCode=TotalfloatrelQtyProjCode+floatrelQty;

											printf("\n TotalfloatrelQtyProjCode %f",TotalfloatrelQtyProjCode);fflush(stdout);

											studLogicmatch++;

										 
										 }
									
									}
									else if(tc_strlen(childPartsOfSA)==12)
									{
									
										 PrtNumStudTemp=subString(childPartsOfSA,8,10);
										 printf( "PrtNumStudTemp:%s:digitComp %s\n", PrtNumStudTemp,digitCompCheck);fflush(stdout);
										 if(tc_strcmp(PrtNumStudTemp,digitCompCheck)==0)
										 {
											ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_quantity", &relQty));
											printf("\n relQty %s",relQty);fflush(stdout);

											floatrelQtyDigit=atof(relQty);

											TotalfloatrelQtyDigit=TotalfloatrelQtyDigit+floatrelQtyDigit;

											printf("\n TotalfloatrelQtyDigit %f",TotalfloatrelQtyDigit);fflush(stdout);

											studLogicmatch++;
										 
										 }
									
									}

									if(studLogicmatch==0)
									{
										if(tc_strstr(childPartsOfSA,info2r)!=NULL)
										{
											ITKCALL(AOM_ask_value_string(BOMLinetag, "bl_quantity", &relQty));
											printf("\n relQty %s",relQty);fflush(stdout);

											floatrelQtyPrtNo=atof(relQty);

											TotalfloatrelQtyPrtNo=TotalfloatrelQtyPrtNo+floatrelQtyPrtNo;

											printf("\n TotalfloatrelQtyPrtNo %f",TotalfloatrelQtyPrtNo);fflush(stdout);

											studLogicmatch++;

											if (iErrCnt1	==	0)
											{
												iErrCnt1	=	1;
												ChildRelStudErr=NULL;
												ChildRelStudErr=(char *)MEM_alloc(300);			//Stud length
												tc_strcpy(ChildRelStudErr,"");
												tc_strcpy(ChildRelStudErr," Stud Data: \n");
												tc_strcat(ChildRelStudErr,childPartsOfSA);
												tc_strcat(ChildRelStudErr,";");
												tc_strcat(ChildRelStudErr,childPartsRevOfSA);
												tc_strcat(ChildRelStudErr," : ");
												tc_strcat(ChildRelStudErr,relQty);
												tc_strcat(ChildRelStudErr,";");
												tc_strcat(ChildRelStudErr,"\n");

												//setAddStr(&icountStud,&SetChildRelStudErr,ChildRelStudErr);
												setAddStr1(&icountStud,&SetChildRelStudErr,ChildRelStudErr);

												printf("\n ChildRelStudErr %s",ChildRelStudErr);fflush(stdout);
											}
											else
											{
												ChildRelStudErr=NULL;
												ChildRelStudErr=(char *)MEM_alloc(300);			//Stud length
												tc_strcpy(ChildRelStudErr," ");
												tc_strcat(ChildRelStudErr,childPartsOfSA);
												tc_strcat(ChildRelStudErr,";");
												tc_strcat(ChildRelStudErr,childPartsRevOfSA);
												tc_strcat(ChildRelStudErr," : ");
												tc_strcat(ChildRelStudErr,childPartsArcLenght);
												tc_strcat(ChildRelStudErr,";");
												tc_strcat(ChildRelStudErr,"\n");
												
												//setAddStr(&icountStud,&SetChildRelStudErr,ChildRelStudErr);
												setAddStr1(&icountStud,&SetChildRelStudErr,ChildRelStudErr);

												printf("\n 111 ChildRelStudErr %s",ChildRelStudErr);fflush(stdout);
											}
										}
									}
								}
							}

							if((tc_strstr(roleName,"APL")!=NULL)  || ( (tc_strstr(roleName,"MBOM")!=NULL) && (fndWE>0)))	//MBOM implementation for CV TZ-1.70
							{
								sTotalNoOfWeldSpots	=	NULL;
								sTotalNoOfWeldSpots	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalNoOfWeldSpots,"");

								sprintf(sTotalNoOfWeldSpots, "%.2f", TotalNoOfWeldSpots);

								ChildRelWeldSpotErr=NULL;
								ChildRelWeldSpotErr=(char *)MEM_alloc(300);				//Total WeldSpot Count
								tc_strcpy(ChildRelWeldSpotErr,"");
								tc_strcpy(ChildRelWeldSpotErr," Total WeldSpot Count:");
								tc_strcat(ChildRelWeldSpotErr,sTotalNoOfWeldSpots);
								tc_strcat(ChildRelWeldSpotErr,";");
								tc_strcat(ChildRelWeldSpotErr,"\n");
							
								printf("\n 333 sTotalNoOfWeldSpots :%s",sTotalNoOfWeldSpots);fflush(stdout);
								setAddStr1(&icountWS,&SetChildRelErrWS,ChildRelWeldSpotErr);


								
								sTotalNoOfArcCnt	=	NULL;
								sTotalNoOfArcCnt	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalNoOfArcCnt,"");

								sprintf(sTotalNoOfArcCnt, "%.2f", TotalNoOfArcCnt);

								ChildRelArcCntErr=NULL;
								ChildRelArcCntErr=(char *)MEM_alloc(300);				//Total Arc Count
								tc_strcpy(ChildRelArcCntErr,"");
								tc_strcpy(ChildRelArcCntErr," Total Arc Count:");
								tc_strcat(ChildRelArcCntErr,sTotalNoOfArcCnt);
								tc_strcat(ChildRelArcCntErr,";");
								tc_strcat(ChildRelArcCntErr,"\n");
							
								printf("\n 333 ChildRelArcCntErr :%s",ChildRelArcCntErr);fflush(stdout);
								setAddStr1(&icountAcnt,&SetChildRelErrAcnt,ChildRelArcCntErr);

								sTotalNoOfArcLengh	=	NULL;
								sTotalNoOfArcLengh	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalNoOfArcLengh,"");

								sprintf(sTotalNoOfArcLengh, "%.2f", TotalNoOfArcLengh);

								ChildRelArcLengthErr=NULL;
								ChildRelArcLengthErr=(char *)MEM_alloc(300);				//Total Arc Length
								tc_strcpy(ChildRelArcLengthErr,"");
								tc_strcpy(ChildRelArcLengthErr," Total Arc Length:");
								tc_strcat(ChildRelArcLengthErr,sTotalNoOfArcLengh);
								tc_strcat(ChildRelArcLengthErr,";");
								tc_strcat(ChildRelArcLengthErr,"\n");
							
								printf("\n 333 ChildRelArcLengthErr :%s",ChildRelArcLengthErr);fflush(stdout);
								setAddStr1(&icountALngth,&SetChildRelErrALngth,ChildRelArcLengthErr);
							}

							if((tc_strstr(roleName,"APL")!=NULL)  || ( (tc_strstr(roleName,"MBOM")!=NULL) && (fndSE>0)))	//MBOM implementation for CV TZ-1.70
							{
								sTotalNoOfSeaLenght	=	NULL;
								sTotalNoOfSeaLenght	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalNoOfSeaLenght,"");

								sprintf(sTotalNoOfSeaLenght, "%.2f", TotalNoOfSeaLenght);

								ChildRelSealLengthErr=NULL;
								ChildRelSealLengthErr=(char *)MEM_alloc(300);				//Total Sealant Length
								tc_strcpy(ChildRelSealLengthErr,"");
								tc_strcpy(ChildRelSealLengthErr," Total Sealant Length:");
								tc_strcat(ChildRelSealLengthErr,sTotalNoOfSeaLenght);
								tc_strcat(ChildRelSealLengthErr,";");
								tc_strcat(ChildRelSealLengthErr,"\n");
							
								printf("\n 333 ChildRelSealLengthErr :%s",ChildRelSealLengthErr);fflush(stdout);
								setAddStr1(&icountSeal,&SetChildRelErrSeal,ChildRelSealLengthErr);

								
								sTotalfloatrelQtyProjCode	=	NULL;
								sTotalfloatrelQtyProjCode	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalfloatrelQtyProjCode,"");
								
								sTotalfloatrelQtyDigit	=	NULL;
								sTotalfloatrelQtyDigit	=	(char *)MEM_alloc(500);
								tc_strcpy(sTotalfloatrelQtyDigit,"");

								sprintf(sTotalfloatrelQtyProjCode, "%.2f", TotalfloatrelQtyProjCode);
								sprintf(sTotalfloatrelQtyDigit, "%.2f", TotalfloatrelQtyDigit);

								 printf("\n TotalfloatrelQtyProjCode :%f",TotalfloatrelQtyProjCode);fflush(stdout);
								 printf("\n sTotalfloatrelQtyDigit :%f",sTotalfloatrelQtyDigit);fflush(stdout);

								if (iErrCnt1	==	0)
								{
									ChildRelStudErr=NULL;
									ChildRelStudErr=(char *)MEM_alloc(300);				//Stud
									tc_strcpy(ChildRelStudErr,"");
									tc_strcpy(ChildRelStudErr," Stud Data: \n");
									tc_strcat(ChildRelStudErr," 1163* :");
									tc_strcat(ChildRelStudErr,sTotalfloatrelQtyProjCode);
									tc_strcat(ChildRelStudErr,";");
									tc_strcat(ChildRelStudErr,"\n");
									tc_strcat(ChildRelStudErr," *88* :");
									tc_strcat(ChildRelStudErr,sTotalfloatrelQtyDigit);
									tc_strcat(ChildRelStudErr,";");
									tc_strcat(ChildRelStudErr,"\n");

									setAddStr1(&icountStud,&SetChildRelStudErr,ChildRelStudErr);
									printf("\n 333 ChildRelStudErr :%s",ChildRelStudErr);fflush(stdout);
								}
								else
								{
									ChildRelStudErr=NULL;
									ChildRelStudErr=(char *)MEM_alloc(300);				//Stud
									tc_strcpy(ChildRelStudErr,"");
									tc_strcat(ChildRelStudErr," 1163* :");
									tc_strcat(ChildRelStudErr,sTotalfloatrelQtyProjCode);
									tc_strcat(ChildRelStudErr,";");
									tc_strcat(ChildRelStudErr,"\n");
									tc_strcat(ChildRelStudErr," *88* :");
									tc_strcat(ChildRelStudErr,sTotalfloatrelQtyDigit);
									tc_strcat(ChildRelStudErr,";");
									tc_strcat(ChildRelStudErr,"\n");

									setAddStr1(&icountStud,&SetChildRelStudErr,ChildRelStudErr);
									printf("\n 444 ChildRelStudErr :%s",ChildRelStudErr);fflush(stdout);
								
								}
							}
							
							
							//=============WELD SPOT============================//
							int iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							for (i=0; i < icountWS; i++)
							{
								tempErr	=	SetChildRelErrWS[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountWS; i++)
							{
								
								tc_strcpy(tempErr,SetChildRelErrWS[i]);
								setAddStr1(&icountF,&SetChildRelErrFinal,tempErr);
								
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							
							//=============ARC CNT============================//
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							for (i=0; i < icountAcnt; i++)
							{
								tempErr	=	SetChildRelErrAcnt[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountAcnt; i++)
							{
								tc_strcpy(tempErr,SetChildRelErrAcnt[i]);
								setAddStr1(&icountF,&SetChildRelErrFinal,tempErr);
								
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							//=================SEALANT========================//
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							for (i=0; i < icountSeal; i++)
							{
								tempErr	=	SetChildRelErrSeal[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountSeal; i++)
							{
								tc_strcpy(tempErr,SetChildRelErrSeal[i]);
								setAddStr1(&icountF,&SetChildRelErrFinal,tempErr);
								
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							//=================ARC Length========================//
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							for (i=0; i < icountALngth; i++)
							{
								tempErr	=	SetChildRelErrALngth[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountALngth; i++)
							{
								tc_strcpy(tempErr,SetChildRelErrALngth[i]);
								setAddStr1(&icountF,&SetChildRelErrFinal,tempErr);
								
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);

							//==============STUD===========================//
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							for (i=0; i < icountStud; i++)
							{
								tempErr	=	SetChildRelStudErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountStud; i++)
							{
								tc_strcpy(tempErr,SetChildRelStudErr[i]);
								setAddStr1(&icountF,&SetChildRelErrFinal,tempErr);
								
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);

							//==============Final Error==========================//
							iLength	=	0;
							if (!tempErr1) MEM_free(tempErr1);
							for (i=0; i < icountF; i++)
							{
								tempErr1	=	SetChildRelErrFinal[i];
								iLength	=	iLength	+	tc_strlen(tempErr1);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr1) MEM_free(tempErr1);
							tempErr1	=	(char *)MEM_alloc(iLength+20);
							for (i=0; i < icountF; i++)
							{
								if(i==0)
								{
									tc_strcpy(tempErr1,SetChildRelErrFinal[i]);
									
								}
								else
								{
									tc_strcat(tempErr1,SetChildRelErrFinal[i]);
								}

								
							}
							printf("\n1111Printing Errors...!!!");fflush(stdout);
							printf("%s",tempErr1);fflush(stdout);

							//=========================================//
							EMH_clear_errors();
							//status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,tempErr1);
							if(tc_strcmp(DesgTypAPL,"SA" )==0)
							{
								EMH_store_error_s2(EMH_severity_information, ITK_errStore, "Check-in Successful.Please check the Stage Assembly Data for information only:",tempErr1);
							}
							else if(tc_strcmp(DesgTypAPL,"M" )==0)
							{
								EMH_store_error_s2(EMH_severity_information, ITK_errStore, "Check-in Successful.Please check the MFG Module Data for information only:",tempErr1);
							}

						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_information, ITK_errStore, "Check-in Successful.");
					
						}

						printf("\n************111 *Inside Information message->APL 1.56=>ITK_Prjerr*************[%d]\n",ITK_errStore);fflush(stdout);
						printf("\n*************111 Inside Information message->APL 1.56=>ITK_ok*************[%d]\n",ITK_ok);fflush(stdout);
						printf("\n*************111 Inside Information message->APL 1.56=>tempErr1*************[%s]\n",tempErr1);fflush(stdout);
						decision = EPM_go;
						return decision;

						
					}
				
				}
			}
		}
		}
		//End Deepti Added TZ1.56

	//**************************** DVA Start *****************************

		if(tc_strcmp(type_name,"Design Revision")== 0)
		{
			printf("\n DVA checkin_with_dataset Inside Type Name :%s\n",type_name);fflush(stdout);
			CALLAPI(GRM_find_relation_type("T5_DesignHasDVA",&relation_type));
			if(relation_type)
			{
				CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
				printf("\n DVA checkin_with_dataset - Relation Type Name:%s\n",relation_name);fflush(stdout);
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
				printf("\n DVA checkin_with_dataset - Attached Datasets:%d\n",cnt);fflush(stdout);
				for(i=0;i<cnt;i++)
				{
				  printf("\n DVA checkin_with_dataset in  for loop\n");fflush(stdout);
				  dataset = attachments[i];
				  CALLAPI(RES_is_checked_out(dataset,&checkout));
				  printf("\n DVA checkin_with_dataset Value of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
				  if (checkout==1)
				  {
						CALLAPI(RES_checkin(dataset));
						printf("\n %d DVA checkin_with_dataset  DataSet Checked In \n",i+1);
						printf("\n DVA checkin_with_dataset Setting Lifecycle State as ERC Review  For Dataset\n");
						//status = t5UpdateLifecycleStateAD(dataset, "T5_LcsReview");
						//printf("\n DVA checkin_with_dataset Updation of Lifecycle State on Dataset Status == %d\n", status);
				  }

				}
			}
		}

	//**************************** DVA End *****************************

	//**************************** Generic Start [Alokesh TZ1.71] *****************************
	if(tc_strcmp(type_name,"Design Revision")== 0)
	{
		char *DesignGrp = NULL;
		char *ProjectCode = NULL;
		char *objtypeDataSet = NULL;
		char *objtypeDataSet2 = NULL;
		char *PartNoInst = NULL;
		int ref_count_d = 0;
		int n_Ins = 0;
		int x = 0;
		int n_Gen = 0;
		int GenCnt = 0;
		tag_t* namRefObject_d = NULLTAG;
		tag_t* CreoInstTags = NULLTAG;
		tag_t* attachments2 = NULLTAG;
		tag_t* CreoGenericTags = NULLTAG;
		tag_t CreoInst = NULLTAG;
		tag_t IPEMRelTag = NULLTAG;
		tag_t dataset2 = NULLTAG;
		tag_t Pro2RelTag = NULLTAG;
		tag_t GenericPart = NULLTAG;
		char *loggedinuser = NULL;

        CALLAPI(POM_get_user_id (&loggedinuser));
        printf("\nGeneric Data Checkin : %s",loggedinuser); fflush(stdout);
		CALLAPI(AOM_ask_value_string(object_tag,"t5_DesignGrp",&DesignGrp));
		CALLAPI(AOM_ask_value_string(object_tag,"t5_ProjectCode",&ProjectCode));
		printf("\nProject Code : %s Design Group : %s",ProjectCode,DesignGrp); fflush(stdout);

		if (tc_strcmp(ProjectCode,"1111")==0 && tc_strcmp(DesignGrp,"11")==0 && tc_strcmp(loggedinuser,"loader")!=0 && tc_strcmp(loggedinuser,"infodba")!=0)
		{
			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
			if(relation_type)
			{
				printf("\nGeneric Dataset"); fflush(stdout);
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
				printf("\nAttached Datasets:%d\n",cnt);fflush(stdout);
				for(i=0;i<cnt;i++)
				{
					printf("\nIn checkin for loop: %d",i);fflush(stdout);
					dataset = attachments[i];
					if( AOM_ask_value_string(dataset,"object_type",&objtypeDataSet)!=ITK_ok);
					if(tc_strcmp(objtypeDataSet,"ProPrt")==0)
					{
						printf("\nProPrt SET is Available");fflush(stdout);
						CALLAPI(AE_ask_dataset_named_refs(dataset,&ref_count_d, &namRefObject_d));
						printf("\nNamed References: %d\n",ref_count_d);fflush(stdout);
						if(ref_count_d>0)
                        {
                        	CALLAPI(GRM_find_relation_type("Pro2_instance",&Pro2RelTag ));
							CALLAPI(GRM_list_secondary_objects_only(dataset,Pro2RelTag,&n_Ins,&CreoInstTags));
							printf("\nTotal Pro2_instance : %d",n_Ins);fflush(stdout);
							for (j = 0; j < n_Ins; ++j)
							{
								CreoInst = CreoInstTags[j];
								CALLAPI(AOM_ask_value_string(CreoInst,"item_id",&PartNoInst));
								CALLAPI(GRM_list_secondary_objects_only(CreoInst,relation_type,&cunt1,&attachments2));
								printf("\nInstance %s -> No of attachments: %d\n",PartNoInst,cunt1);fflush(stdout);
								for (x = 0; x < cunt1; ++x)
								{
									dataset2 = attachments2[x];
									if( AOM_ask_value_string(dataset2,"object_type",&objtypeDataSet2)!=ITK_ok);
									if(tc_strcmp(objtypeDataSet2,"ProPrt")==0)
									{
										printf("\nProPrt SET is Available in Instance Part");fflush(stdout);
										CALLAPI(GRM_find_relation_type("IPEM_master_dependency",&IPEMRelTag ));
										CALLAPI(GRM_list_secondary_objects_only(dataset2,IPEMRelTag,&n_Gen,&CreoGenericTags));
										printf("\nIn Instance Part dataset no of Generics: %d",n_Gen);fflush(stdout);
										for (GenCnt = 0; GenCnt < n_Gen; ++GenCnt)
										{
											tag_t Fndrelation = NULLTAG;
											GenericPart = CreoGenericTags[GenCnt];
											CALLAPI(GRM_find_relation(dataset2,GenericPart,IPEMRelTag,&Fndrelation));
											CALLAPI(GRM_delete_relation(Fndrelation));
											CALLAPI(AOM_refresh(dataset2,1));
										}
										printf(" generic..GRM_create_relation before:\n");fflush(stdout);
										tag_t CreGenRelation = NULLTAG;
										CALLAPI(GRM_create_relation(dataset2,object_tag,IPEMRelTag,NULLTAG,&CreGenRelation));
										printf(" generic..GRM_create_relation Success\n");fflush(stdout);
										if(CreGenRelation)
										{
											CALLAPI(AOM_refresh(dataset2,0));
											printf(" generic..Before GRM_save_relation\n");fflush(stdout);
											CALLAPI(GRM_save_relation(CreGenRelation));
											printf(" generic..GRM_save_relation Success\n");fflush(stdout);
											CALLAPI(AOM_refresh(dataset2,1));
										}
									}
								}
							}
                        }
					}
				}
			}
		}
	}
	//**************************** Generic End *****************************

	CLEANUP:
	printf("\n Inside CLEANUP \n");fflush(stdout);
    return ifail;

}

extern DLLAPI int checkout_prevalidation(METHOD_message_t *m, va_list args)
{
	//Rohit
	//char			relation_name[TCTYPE_name_size_c+1];
	char *relation_name	=	NULL;
	int				ifail=0,cnt=0,i,count2,count12,i2;

	tag_t			object_tag									= va_arg (args, tag_t);
	tag_t			objTypeTag									= NULLTAG;
	tag_t			*CntrlObject_pre							= NULLTAG;
	tag_t			CurrentRoleTag_pre							= NULLTAG;
	tag_t			user_tag_pre								= NULLTAG;
	tag_t			group_tag_pre								= NULLTAG;
	//char			type_name_pre[TCTYPE_name_size_c+1];
	//char			roleName_pre[SA_name_size_c+1];
	char			*username_pre								= NULL;
	char			*type_name_pre								= NULL;
	char			*roleName_pre								= NULL;
	char			*group_name_pre								= NULL;
	tag_t			cvpre_CntrlOBJ								= NULLTAG;
	char			*qry_cvprecntrl[1]							= {"SYSCD"};
	char **qry_valuescvpre										= (char **) MEM_alloc(10 * sizeof(char *));
	qry_valuescvpre[0]											= "CO_Rel_parts_restrict";

	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);
	int				cvpre_entries								=	1;
	int				cvpre_found									=	0;

	CALLAPI(QRY_find2("Control Objects...",&cvpre_CntrlOBJ));
	CALLAPI(QRY_execute(cvpre_CntrlOBJ, cvpre_entries, qry_cvprecntrl, qry_valuescvpre, &cvpre_found, &CntrlObject_pre));
	printf("\n\n  checkout_prevalidation Control Object SYSCD :[%d]\n",cvpre_found);	fflush(stdout);

	if(cvpre_found > 0)
	{
		if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
		if (TCTYPE_ask_name2(objTypeTag,&type_name_pre)!=ITK_ok);
		printf("\n type_name_pre checkout_prevalidation in pre action is = [%s]\n", type_name_pre);fflush(stdout);

		CALLAPI(SA_ask_current_role(&CurrentRoleTag_pre));
		CALLAPI(SA_ask_role_name2(CurrentRoleTag_pre,&roleName_pre));
		CALLAPI(POM_get_user(&username_pre, &user_tag_pre));
		CALLAPI(POM_ask_group(&group_name_pre, &group_tag_pre));
		
		if (((tc_strcmp(username_pre,"infodba")!=0) && (tc_strcmp(username_pre,"loader")!=0)) && (tc_strstr(roleName_pre,"STD")==NULL) && (tc_strstr(roleName_pre,"APL")==NULL) && (tc_strstr(roleName_pre,"MBOM")==NULL) && (tc_strstr(roleName_pre,"Support")==NULL))
		{
			if((tc_strcmp(type_name_pre,"Design Revision") == 0 ) || (tc_strcmp(type_name_pre,"T5_SparKitRevision") == 0 ) || (tc_strcmp(type_name_pre,"T5_EE_PartRevision") == 0 ))
			{
				printf("\n Inside function checkout_prevalidation to checke Des Revision\n"); fflush(stdout);

				char	*vrlsstatus_i_pre			=   NULL;
				
				CALLAPI(AOM_UIF_ask_value(object_tag,"release_status_list",&vrlsstatus_i_pre));
				printf("\n Released status for Design Revision in pre action is [%s] \n",vrlsstatus_i_pre); fflush(stdout);

				if(tc_strstr(vrlsstatus_i_pre,"Released") != NULL) 
				{
					printf("\nYou cannot checkout this part as this is Released in pre action.\n"); fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-Out is not allowed for Selected Released Part .");
					return ITK_err;

				}
			
			}
		}
		else
		{
			printf("\nUser Role is Support , APL, STD, or MBOM , hence bypassed this validation\n"); fflush(stdout);
		}
	}
	return ifail;
}

extern DLLAPI int checkout_with_dataset(METHOD_message_t *m, va_list args)
{
	//char			relation_name[TCTYPE_name_size_c+1];
	tag_t			relation_type								= NULLTAG;
	tag_t			relation_fnd								= NULLTAG;
	tag_t			relation_type_Dsn							= NULLTAG;
	tag_t			relation_dep22								= NULLTAG;
	tag_t			*attachments								= NULLTAG;
	tag_t			dataset										= NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	tag_t			object_tag									= va_arg (args, tag_t);
	tag_t			objTypeTag									= NULLTAG;
	//char			type_name[TCTYPE_name_size_c+1];
	char			*desrevid									= NULL;
	char			*cp_ItemId									= NULL;//Abhishek
	char			*type_name									= NULL;//Abhishek
	char			*relation_name									= NULL;//Abhishek
	tag_t			reln_type									= NULLTAG;//Abhishek
	tag_t			*secondary_objects							= NULLTAG;//Abhishek
	int				n_attchs									= 0;//Abhishek
	tag_t			t_BomLineWindow, t_Rule, t_ItemTag			= null_tag;//Abhishek
	tag_t			t_TopLine,t_Childobject						= NULLTAG;
	tag_t			t_ChildObjType								= NULLTAG;//Abhishek
	tag_t			*t_PartChildren								= NULLTAG;//Abhishek
	tag_t			t_ChildItemRev								= NULLTAG;//Abhishek
	int				i_ChildCount= 0,iChldPrts=0,iItemType=0,iItemRevId=0,iItemId=0,iChildItemTag=0;//Abhishek
	int				i_ChildSeq= 0,iItemChkdOut					= 0;//Abhishek
	logical			b_ChildChkOutValue							= 0;//Abhishek
	//char			ca_ChildType_Name[TCTYPE_name_size_c+1];//Abhishek
	char			*cp_ItemType_str,*Item_id					= NULL;//Abhishek
	char			*cp_ItemID_str								= NULL;//Abhishek
	char			*cp_ItemRev_str								= NULL;//Abhishek
	char			*Ap_owner								= NULL;
	char			*dt_typ_nm								= NULL;
	char			*ca_ChildType_Name								= NULL;
	char			*cp_ChildSeq,*cp_ChildChkOutValue,*Desc_obj	= NULL;//Abhishek
	int				BomViewCnt,iVwCnt							= 0;//Abhishek
	tag_t			*BomViewList								= NULLTAG;//Abhishek
	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);
	//int				ifail=0,cnt=0,i,count2,i2,checkout2=0;
	int				ifail=0,cnt=0,i,count2,count12,i2;
	logical			checkout									= 0;
	GRM_relation_t *primary_list2	= NULLTAG;
	GRM_relation_t *primary_list12	= NULLTAG;
	tag_t                   status_rel                                      = NULLTAG;
	int	   status_count,ii=0,countDep=0,ik=0,countDep11=0;
	int status;
	int main_seq;
	int jk=0,Valid_Ch_Dataset,Ap_owner_Nt_fnd;
	int catfound,proEfound,deleteRel;

	logical retain=false;
	char   *ReleaseStatus=NULL;
	char   *Id_string_val=NULL;
	char   *Id_Pro_val=NULL;
	char   *org_rev_id=NULL;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	int org_seq_id_int=0;
    char   *PlantName=NULL;

	tag_t		   primary_object2	= NULLTAG;
	tag_t* status_list = NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t		   NewRevTag	= NULLTAG;
	tag_t		   NewRevTagAD	= NULLTAG;
	tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	int n_entries = 3;
	int resultCount=0;
	tag_t *rev=NULLTAG;
	tag_t new_itemId_new1=NULLTAG;

	logical	checkoutp1;
	logical	checkout2;

        /***************Adi  ******************/
		tag_t			relation_fnd1	= NULLTAG;
		tag_t			dataset1		= NULLTAG;
		int               ip            = 0; 
		int               cnt1            = 0; 
		logical			checkout1		= 0;
		tag_t			*attachments1	= NULLTAG;
		char			*dt_typ_nm1		= NULL;   
		char			*dt_typ_nm2		= NULL;    
		 /***************Adi ******************/
		 tag_t		relation_tag		= NULLTAG;
		 tag_t		reln_type_tag		= NULLTAG;
		 char*		DsObjNameS			= NULL;


		//tag_t			relation_fnd2	= NULLTAG;  //ALIAS ASSY MANAGEMENT
		//tag_t			relation_fnd3	= NULLTAG;  //ALIAS ASSY MANAGEMENT
		//logical			checkoutX		= 0;	    //ALIAS ASSY MANAGEMENT
		//logical			Aliascheckout	= 0;	    //ALIAS ASSY MANAGEMENT
		//int				n_refs			= 0;		//ALIAS ASSY MANAGEMENT
		//int				rr			    = 0;		//ALIAS ASSY MANAGEMENT
		//int *levels;								//ALIAS ASSY MANAGEMENT
		//tag_t *referencers ;						//ALIAS ASSY MANAGEMENT
		//char **relations=NULL;						//ALIAS ASSY MANAGEMENT
		//char			*Aldesgrp		= NULL;     //ALIAS ASSY MANAGEMENT
		//tag_t objTypeRefTag	   = NULLTAG;			//ALIAS ASSY MANAGEMENT
		//char type_name_ref[TCTYPE_name_size_c+1];   //ALIAS ASSY MANAGEMENT



	/******Deepti Start Variable initialisation***********/
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	/******Deepti End ariable initialisation***********/
		/******Start Deepti TZ1.34***********/
	tag_t  CurrentRoleTag = NULLTAG;
    // char       roleName[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
    // char       roleNameVal[SA_name_size_c+1];//MBOM implementation for CV TZ-1.69
	char *roleNameVal	=	NULL;
	/******End Deepti TZ1.34***********/


	char   *catiasynch=NULL; //Adi CMI
	char   *OwnUser=NULL; //Adi Alias

	double  SealLen;				//Adi 	
	double  SealLenx =  0.0;		//Adi 	
	double  ArcWeld;				//Adi 
	double  ArcWeldx = 0.0;			//Adi 
	int		Stud;					//Adi 
	int		Studx    = 0;			//Adi 
	char   *SealantType = NULL;		//Adi
	char   *revidX		= NULL;		//Adi

	tag_t  reln_type_tagX	    = NULLTAG; //Adi
	int	   n_partsI				= 0;       //Adi
	int	   ix					= 0;       //Adi
	tag_t  relation_tagX		= NULLTAG; //Adi
    char*  DsObjNameSX			= NULL;    //Adi
	tag_t *secondary_obj_tag	= NULLTAG; //Adi 

	char			*partTypeS	= NULL;         //Adi Alias
	tag_t			relation_fndA	= NULLTAG;  //Adi Alias

	//added by ajinkya on 02 june//

	tag_t TagWeControl = NULLTAG,
	*cntr_objectsWe = NULL;
	int	n_entriesWe = 2;
	int n_foundWe = 0;
	char *WErelease_status = NULL;
	char *qry_entriesWe[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_valuesWe[2] = {"WE", "CHECK"};
	char *RefPatRev = NULL;
	char *RefPatSeq = NULL;

	//end
	
	//Added by kalpesh(26_june2020)
	int		ik_sec					= 0;
	int		CCID_count				= 0;
	char	*cp_Parttype			= NULL;
	tag_t	CCID_RelType			= NULLTAG;
	tag_t	CCID_relation			= NULLTAG;
	tag_t	*CCID_objects			= NULLTAG;


	char RvwLCVal[40];	//MBOM implementation for CV TZ-1.69
	char WrkngLCVal[40]; //MBOM implementation for CV TZ-1.69
	char RlzdLcVal[40];	//MBOM implementation for CV TZ-1.69
	char RvwLCActVal[40]; //MBOM implementation for CV TZ-1.69
	char View[40];//MBOM implementation for CV TZ-1.69
	char WrkngActLCVal[40];//MBOM implementation for CV TZ-1.69
	char RlzdActLcVal[40];//MBOM implementation for CV TZ-1.69
	char   *dsgModAddressVal=NULL;//MBOM implementation for CV TZ-1.69
	char roleName[100];

	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};


 	//printf("\n\nIn checkout_with_dataset orignal stamping LC %d \n",LHFlg);

	//anil
	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	printf("\n type_name  = [%s]\n", type_name);fflush(stdout);
	//if(!strcmp(type_name,"Design Revision")) //007 T5_SparKitRevision

	if((strcmp(type_name,"Design Revision")==0)||(strcmp(type_name,"T5_SparKitRevision")==0) || (strcmp(type_name,"T5_EE_PartRevision")==0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
	{


	//		status=WSOM_ask_release_status_list(object_tag,&status_count,&status_list);
	//	    if(status==ITK_ok)
	//		 {
	//			printf("\n number of statuses: %d \n",  status_count);
	//			for (ii = 0; ii < status_count; ii++)
	//			{
	//				AOM_ask_name(status_list[ii], &ReleaseStatus);
	//				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
	//			}
	//		 }
	//
	//		 if((strcmp(ReleaseStatus,"T5ErcPublished")==0) )
	//			{
	//				status=EMH_store_error_s1(EMH_severity_error,ITK_err, "BaseLine Object Cannot Be Checked-out, Please Check-out The Actual Object");
	//				return ITK_err;
	//			}

    /***************Adi - CMI synch *************************/

		//To delete the relation of CCID on check-out of module.
	printf("\nGoing to delete the relationship of CCID with module\n");

	CALLAPI(AOM_ask_value_string(object_tag,"t5_PartType",&cp_Parttype));

	printf("\n Relationship of Part type = [%s]\n", cp_Parttype);fflush(stdout);
	if((tc_strcmp(cp_Parttype, "M") == 0) || (tc_strcmp(cp_Parttype, "EM") == 0) )  //Checked for Parttype(Module)
	{
		printf("\n INSIDE THE MODULE TYPE   \n");fflush(stdout);
	
		CALLAPI(GRM_find_relation_type("T5_IsMemberOfCCID",&CCID_RelType));

		printf("\n After finding RelType \n");fflush(stdout);
		if(CCID_RelType)
		{
			printf("\n Inside the relation tag found.. \n");fflush(stdout);
			CALLAPI(TCTYPE_ask_name2( CCID_RelType, &relation_name));
	        printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
		
			CALLAPI(GRM_list_secondary_objects_only(object_tag,CCID_RelType,&CCID_count,&CCID_objects));
			
			printf("\n Attached CCID :%d\n",CCID_count);fflush(stdout);
			if(CCID_count > 0)
			{
				printf("\n Inside Attached CCID:%d\n",CCID_count);fflush(stdout);
				for(ik_sec=0;ik_sec<CCID_count;ik_sec++)
				{
					printf("\n Inside for loop of ccid :%d\n",CCID_count);fflush(stdout);
									
					GRM_find_relation(object_tag, CCID_objects[ik_sec], CCID_RelType, &CCID_relation);
					printf("\n GRM_find_relation for CCID data \n");fflush(stdout);

					if(CCID_relation)
					{
						printf("\n Inside the CCID_relation found \n");fflush(stdout);
						CALLAPI(GRM_delete_relation(CCID_relation));
						printf("\nRelation Deleted of IS member of CCID...!!\n");
					}
				}
			}
		}
		else
		{
			printf("\nIn else as tag not found for CCID_RelType \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n In else for CCID relationship break  part type is  = [%s]\n", cp_Parttype);fflush(stdout);
	}
	printf("\n CODE END FOR CCID RELATIONSHIP BRAKE   \n");fflush(stdout);
	//CCID relationshp code ends here//

	   if( AOM_ask_value_string(object_tag,"t5_IsCatSynch",&catiasynch) !=ITK_ok) PrintErrorStack();

	   printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

	   if(tc_strcmp(catiasynch ,"Y")==0)
		{
		   printf("\n part has been synched from catia so on checkout setting the value to N \n");fflush(stdout);

           if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
		   if(AOM_set_value_string(object_tag,"t5_IsCatSynch","N")!=ITK_ok) PrintErrorStack();
		   if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
		   if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();

		   printf("\n VALUE set to N  \n");fflush(stdout);
		}
		else
		{
           printf("\n catiasynch value not set to Y \n");fflush(stdout);
		}
	/***************Adi - CMI synch *************************/

	/***************Adi - setting attribute values to null **************************/

	 if( AOM_ask_value_string(object_tag,"item_revision_id",&revidX)!=ITK_ok) PrintErrorStack(); //New
	 printf("\n revidX %s\n", revidX);fflush(stdout);

	 if( AOM_ask_value_double(object_tag,"t5_ArcWeld",&ArcWeld)!=ITK_ok) PrintErrorStack();
	 printf("\n ArcWeld value is -------------- %f \n",ArcWeld);fflush(stdout);

	 if(ArcWeld >0)
		{
		   printf("\n ArcWeld has some value \n");fflush(stdout);

		   if(tc_strcmp(revidX,"NR;1")==0)
			{
			   printf("\n NR;1 so do not make the  ArcWeld value 0 \n");fflush(stdout);
			}
			else
			{
			   if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_set_value_double(object_tag,"t5_ArcWeld",ArcWeldx)!=ITK_ok) PrintErrorStack(); 
			   if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_refresh(object_tag,1)!=ITK_ok) PrintErrorStack();
			   printf("\n ArcWeld value set to 0  \n");fflush(stdout);
			}
		}
		else
		{
           printf("\n ArcWeld value is already 0 \n");fflush(stdout);
		}


	 if( AOM_ask_value_int(object_tag,"t5_Stud",&Stud)!=ITK_ok) PrintErrorStack();
	 printf("\n Stud value is -------------- %d \n",Stud);fflush(stdout);
	 printf("\n Studx -------------- %d \n",Studx);fflush(stdout);

	 if(Stud >0)
		{
		   printf("\n Stud has some value \n");fflush(stdout);

		   if(tc_strcmp(revidX,"NR;1")==0)
			{
			   printf("\n NR;1 so do not make the Stud value 0 \n");fflush(stdout);
			}
			else
			{
			   if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_set_value_int(object_tag,"t5_Stud",Studx)!=ITK_ok) PrintErrorStack();
			   if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_refresh(object_tag,1)!=ITK_ok) PrintErrorStack();
			   printf("\n Stud value set to 0 \n");fflush(stdout);
			}
		}
		else
		{
           printf("\n Stud value is already 0\n");fflush(stdout);
		}


	 if( AOM_ask_value_string(object_tag,"t5_SealantType",&SealantType)!=ITK_ok) PrintErrorStack();
	 printf("\n SealantType value is -------------- %s \n",SealantType);fflush(stdout);

	 if(tc_strcmp(SealantType,"")!=0)
		{
		   printf("\n SealantType has some value \n");fflush(stdout);

		   if(tc_strcmp(revidX,"NR;1")==0)
			{
			   printf("\n NR;1 so do not make the SealantType value blank \n");fflush(stdout);
			}
			else
			{
			   if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_set_value_string(object_tag,"t5_SealantType","")!=ITK_ok) PrintErrorStack();
			   if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();
			   printf("\n SealantType value set to blank  \n");fflush(stdout);
			}
		}
		else
		{
           printf("\n SealantType value is already blank \n");fflush(stdout);
		}


	 if( AOM_ask_value_double(object_tag,"t5_SealLen",&SealLen)!=ITK_ok) PrintErrorStack();
	 printf("\n SealLen value is -------------- %f \n",SealLen);fflush(stdout);

	 if(SealLen>0)
	 	{
		   printf("\n SealLen has some value \n");fflush(stdout);

		   if(tc_strcmp(revidX,"NR;1")==0)
			{
			   printf("\n NR;1 so do not make the SealLen value 0 \n");fflush(stdout);
			}
			else
			{
			   if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_set_value_double(object_tag,"t5_SealLen",SealLenx)!=ITK_ok) PrintErrorStack();
			   if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
			   if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();
			   printf("\n SealLen value set to 0  \n");fflush(stdout);
			}
		}
		else
		{
          printf("\n SealLen value is already o \n");fflush(stdout);
		}

	/***************Adi - setting attribute values to null  *************************/

		 // Added to handle relation b/w ProAsm and Des Rev
				 printf("\n\n Pro2_membership relation new for JproAsm\n");
				 if(relation_dep) relation_dep=NULLTAG;
				 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));

				 if(relation_dep)
				{

					   CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
					  printf("\n Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);

					  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
					  printf("\n Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);

					  CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
					  printf("\n Ckd Out Rev is -->%s\n",org_Item_id); fflush(stdout);

					  CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

					 printf("\n\nProAsm Rel with Des Rev are --->:%d\n",countDep);fflush(stdout);

	//
	//						if(countDep>0)
	//						{
	//							for(ik=0;ik<countDep;ik++)
	//							{
	//							   primary_object11 = primary_list_Dep[ik].primary;
	//							   if(primary_object11)
	//							   {
	//								 printf("\nI value in loop is--->:%d\n",ik);	fflush(stdout);
	//								 CALLAPI(AOM_ask_value_string(primary_object11,"object_name",&Id_string_val));
	//								 printf("\n Proasm where Item Rev is used --->%s\n",Id_string_val);fflush(stdout);
	//
	//								 CALLAPI(AOM_ask_value_string(primary_object11,"protection",&Id_Pro_val));
	//								 printf("\n Proasm unique --->%s\n",Id_Pro_val);fflush(stdout);
	//
	//								  CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep22));
	//
	//								  GRM_find_relation(primary_object11,object_tag,relation_dep22,&relation_test);
	//
	//								 CALLAPI(GRM_delete_relation(relation_test));
	//								 CALLAPI(AOM_refresh(primary_object11,0));
	//								 CALLAPI(AOM_refresh(object_tag,0));
	//
	//								  printf("\n Relation deleted succ\n");fflush(stdout);
	//
	//
	//								  main_seq=org_seq_id_int-1;
	//
	//								  sprintf(NewSeq,"%d",main_seq);
	//
	//								  printf("\n main_seq char value is  -->%s\n",NewSeq); fflush(stdout);
	//
	//								  if(QRY_find2("DesignRevision Sequence", &queryTag));
	//
	//									if (queryTag)
	//									{
	//										printf(" Uni Found Query\n"); fflush(stdout);
	//									}
	//									else
	//									{
	//										printf("Uni Not Found Query\n"); fflush(stdout);
	//									}
	//
	//									qry_values[0] = org_rev_id ;
	//									qry_values[1] = NewSeq;
	//									qry_values[2] = org_Item_id;
	//									if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));
	//
	//									printf(" Obj queried with builder are --->%d\n",resultCount); fflush(stdout);
	//
	//									if(resultCount>0)
	//									{
	//										printf(" Des Rev already exists\n"); fflush(stdout);
	//
	//										for (jk=0;jk<resultCount;jk++ )
	//										{
	//											item_tag_rev = rev[jk];
	//
	//											CALLAPI(GRM_create_relation(primary_object11, item_tag_rev, relation_dep22, NULL, &relation_New));
	//											CALLAPI(AOM_refresh (primary_object11,0));
	//											CALLAPI(AOM_refresh(relation_New,0));
	//											CALLAPI(AOM_refresh(object_tag,0));
	//											CALLAPI(GRM_save_relation(relation_New));
	//											printf("\n GRM_save_relation created succ \n\n"); fflush(stdout);
	//
	//
	//										}
	//									}
	//								}
	//							  }
	//						}
				}

				 CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep11,&primary_list_Dep11));

				printf("\n\n After deleting ProAsm Rel with Des Rev are --->:%d\n",countDep11);fflush(stdout);

				// Ended to handle relation b/w ProAsm and Des Rev

		if( AOM_ask_value_string(object_tag,"item_revision_id",&desrevid)!=ITK_ok) PrintErrorStack();
		printf(" desrevid %s\n", desrevid);fflush(stdout);
		if(strcmp(desrevid,"NR;1")!=0)
		{
			printf("anil start");fflush(stdout);
			if(AOM_lock(object_tag)!=ITK_ok) PrintErrorStack();
			if( AOM_set_value_string(object_tag,"t5_DocRemarks","")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(object_tag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(object_tag)!=ITK_ok) PrintErrorStack();
			printf("anil end");fflush(stdout);
		}

	/**************************************************************************************************************************/
	/*** Check Application_owner and don't allow check out of other datasets.***/
	/*** Also dont't allow check out of JT with design revision ***/
	/**************************************************************************************************************************/


	/**** Checkout usecases testing*/
	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	if(relation_type)
	{      printf("\n 4444 7777777 \n");fflush(stdout);
	CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
	printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
	CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
	printf("\n APOwn rev id-->%s\n",org_rev_id); fflush(stdout);

	CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
	printf("\n  APOwn item iD-->%s\n",org_Item_id); fflush(stdout);
	CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
	printf("\n Attached Datasets:%d\n",cnt);fflush(stdout);
	CALLAPI(AOM_ask_value_string(object_tag,"t5_ApplicationOwner",&Ap_owner));

	CALLAPI(AOM_ask_value_string(object_tag,"t5_PartType",&partTypeS));
	printf("\n  partTypeS --------------->%s\n",partTypeS); fflush(stdout); //new

	for(i=0;i<cnt;i++)
	{
		Valid_Ch_Dataset=0;
		Ap_owner_Nt_fnd=0;
		dt_typ_nm=NULL;
		dt_typ_nm1=NULL;//Adi
		OwnUser=NULL;  //Adi
		//catfound=0;
		//proEfound=0;
		deleteRel=0;

		dataset = attachments[i];
		CALLAPI(RES_is_checked_out(dataset,&checkout));

		printf("\nValue of checkout : %d\n",checkout);fflush(stdout);
		printf("\n Value of checkout : %d\n",checkout);fflush(stdout);

		if (checkout==0)
		{			
			CALLAPI(GRM_find_relation(object_tag, dataset, relation_type, &relation_tag)); //Adi
			if (relation_tag)
			{
				printf("\n inside relation_tag \n");fflush(stdout);
				if(AOM_ask_value_string(dataset,"object_name",&DsObjNameS))
				printf("\n DsObjNameS %s", DsObjNameS);fflush(stdout);
				if(strstr(DsObjNameS,".csv")!=NULL)
				{	
					printf("\n .csv Deletion \n");fflush(stdout);
					CALLAPI(GRM_delete_relation	(relation_tag));
					printf("\n .csv Deletion success \n"); fflush(stdout);
				}
			}                                                                             //Adi

			printf("\n Application owner %s", Ap_owner);fflush(stdout);
			if(Ap_owner)
			{
				CALLAPI(AOM_ask_value_string(dataset,"object_type",&dt_typ_nm));
				printf("\n Iteration [%d] for ApplicationOwner %s and DatasetTyeTpCopmpare %s",i,Ap_owner,dt_typ_nm);fflush(stdout);
				printf("\n IMAN_specification  type_name is %s",dt_typ_nm);

				if(((tc_strstr(Ap_owner,"ProE")!=NULL) || (tc_strstr(Ap_owner,"Creo")!=NULL)) &&	((tc_strstr(dt_typ_nm,"Cat")!=NULL) || (tc_strstr(dt_typ_nm,"CMI")!=NULL) || (tc_strstr(dt_typ_nm,"CAT")!=NULL)))
				{
					printf("\n Catia data found attached Application is %s and revision number %s ",Ap_owner,org_Item_id);
					deleteRel=1;

				}

				else if (((tc_strstr(Ap_owner,"Cat")!=NULL) || (tc_strstr(Ap_owner,"CMI")!=NULL)|| (tc_strstr(Ap_owner,"CAT")!=NULL)) && ((tc_strstr(dt_typ_nm,"ProAsm")!=NULL) || (tc_strstr(dt_typ_nm,"ProDrw")!=NULL) || (tc_strstr(dt_typ_nm,"ProPrt")!=NULL) || tc_strstr(dt_typ_nm,"Creo")!=NULL))
				{
					printf("\n ProE data found attached Application owner is %s and RevisionNUmber %s ",Ap_owner,org_Item_id);
					deleteRel=1;
				}

				else if ((tc_strstr(Ap_owner,"Alias")!=NULL) && ((tc_strstr(dt_typ_nm,"Cat")!=NULL) || (tc_strstr(dt_typ_nm,"CMI")!=NULL) || (tc_strstr(dt_typ_nm,"CAT")!=NULL))) //Adi for Alias
				{
					printf("\n Catia data found attached Application owner is %s and RevisionNUmber %s ",Ap_owner,org_Item_id);
					deleteRel=1;
				}

			}
			else
			{

				printf("\n setting Application owner not found flag");fflush(stdout);
				Ap_owner_Nt_fnd=1;

			}

			printf("\n catfound %d and Dataset is %s ",catfound,dt_typ_nm);fflush(stdout);
			printf("\n proEfound %d and Dataset is %s ",proEfound,dt_typ_nm);fflush(stdout);

				if (deleteRel==1)
			{
				printf("\n inside GRM_find_relation and GRM_delete_relation for %s ",dt_typ_nm);fflush(stdout);
				CALLAPI(GRM_find_relation(object_tag,dataset,relation_type,&relation_fnd));
				if(relation_fnd)
				{
					printf("\n DataSet relation delete \n");
					CALLAPI(GRM_delete_relation	(relation_fnd));
					printf("\n DataSet relation delete success \n");
					continue;
				}
			}

           /**************** Adi ***********************/
			CALLAPI(AOM_ask_value_string(dataset,"object_type",&dt_typ_nm1)); 
			printf("\n dt_typ_nm1=========== %s ",dt_typ_nm1);fflush(stdout);
			if(tc_strcmp(dt_typ_nm1,"T5_Alias")==0)
			{
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt1,&attachments1));
				printf("\n Inside T5_Alias Attached Datasets ======= %d \n",cnt1);fflush(stdout);

				for(ip=0;ip<cnt1;ip++)
				{
					dataset1 = attachments1[ip];
					CALLAPI(RES_is_checked_out(dataset1,&checkout1));

					printf("\n  checkout1 ====== %d\n",checkout1);fflush(stdout);

					CALLAPI(AOM_ask_value_string(dataset1,"object_type",&dt_typ_nm2));
					printf("\n dt_typ_nm2=========== %s ",dt_typ_nm2);fflush(stdout);

					if (checkout1==0)
					{
						if(tc_strcmp(dt_typ_nm2,"CMI2Part")==0)
						{
							printf("\n  CONVERTED CMI2PART FOUND ATTACHED   ====== %d\n");fflush(stdout);
							CALLAPI(GRM_find_relation(object_tag,dataset1,relation_type,&relation_fnd1));
							if(relation_fnd1)
							{
								printf("\n DataSet relation delete CONVERTED CMI2PART \n");
								CALLAPI(GRM_delete_relation	(relation_fnd1));
								printf("\n DataSet relation delete success  CONVERTED CMI2PART\n");
								continue;
							}
						}
					    if(tc_strcmp(dt_typ_nm2,"T5_Alias")==0) //NEW 
						{
							printf("\n  DATASET Alias partTypeS --------------->%s\n",partTypeS); fflush(stdout);					
							if((tc_strcmp(partTypeS,"Dummy Assembly")==0)||tc_strcmp(partTypeS,"DA")==0)
							{
								printf("\n  DATASET Alias partTypeS part type dummy assembly \n"); fflush(stdout);								
								CALLAPI(GRM_find_relation(object_tag,dataset1,relation_type,&relation_fndA));
								if(relation_fndA)
								{
									printf("\n DataSet relation delete T5_Alias \n");
									CALLAPI(GRM_delete_relation	(relation_fndA));
									printf("\n DataSet relation delete success  T5_Alias\n");
									continue;
								}
							}
						}
					}
				}
			} /**************** Adi ***********************/


			printf("\nValid_Ch_Dataset actiononDAtaset %d and Ap_owner_Nt_fnd %d actiononDAtaset \n",Valid_Ch_Dataset,Ap_owner_Nt_fnd);fflush(stdout);


				printf("\nreason:%s\n",reason);fflush(stdout);
				printf("\nchange_id:%s\n",change_id);fflush(stdout);
				printf("\ndir_name:%s\n",dir_name);fflush(stdout);
				printf("\nreservation_type:%d\n",reservation_type);fflush(stdout);
				CALLAPI(RES_checkout2(dataset,reason,change_id,dir_name,reservation_type));
				printf("\n %d DataSet Checked Out \n",dataset);
			}

	}
	}
	else
	{
	printf("IMAN_specification,&relation_type is null");

	}

	//Added by Rohit to stamp working status on BVR Starts

	tag_t CntrlOBJ_coBVR		=	NULLTAG;
	tag_t *CntrlObject_coBVR	=	NULLTAG;
	
	char *qry_cntrl_coBVR[1] = {"SYSCD"};
	char **qry_values_coBVR = (char **) MEM_alloc(10 * sizeof(char *));
	qry_values_coBVR[0] = "CO_BVR_Stamping_ControlObj";
	
	int		entries_coBVR =  1;
	int		found_coBVR	 =	0;
	
	if(QRY_find2("Control Objects...",&CntrlOBJ_coBVR));
	printf("\n\nStamping Review status on BVR while revising Query Found\n\n");	fflush(stdout);	
	
	if(QRY_execute(CntrlOBJ_coBVR, entries_coBVR, qry_cntrl_coBVR, qry_values_coBVR, &found_coBVR, &CntrlObject_coBVR));
	printf("\n\nStamping Review status on BVR while revising control object count is :%d\n",found_coBVR);	fflush(stdout);
	if(found_coBVR > 0 )
	{
		tag_t	objTypeTagR_co				= NULLTAG;
		char	*type_nameR_co				= NULL;
		char	*BVR_Rlstatus_co			= NULL;
		logical	check_out_co				= 0;
		int		bvr_count_co				= 0;
		tag_t	*bvrs_co;
		tag_t	bvr_tag_co					=   NULLTAG;
		tag_t			status_reviewBVR_co					= NULLTAG;

		if (TCTYPE_ask_object_type(object_tag,&objTypeTagR_co)!=ITK_ok) PrintErrorStack();
		if (TCTYPE_ask_name2(objTypeTagR_co, &type_nameR_co)!=ITK_ok) PrintErrorStack();
		printf("\n	Type of part is : [%s] ", type_nameR_co);fflush(stdout);
		if(strcmp(type_nameR_co,"Design Revision")==0)
		{
			printf("\n Inside loop as part type is Design Revision \n"); fflush(stdout); //checked_out
			if(RES_is_checked_out(object_tag, &check_out_co)!=ITK_ok) PrintErrorStack();
			printf("\n*****After RES_is_checked_out***** [%d]\n",check_out_co);fflush(stdout);
			if(check_out_co != 0)
			{
				printf("\nDesign Revision is checked-out, so go on to Update release status on BVR...!!\n");fflush(stdout);

				if(ITEM_rev_list_bom_view_revs( object_tag, &bvr_count_co, &bvrs_co));
				if (bvr_count_co > 0)
				{
					printf("\nTag of BVR found while check-out\n");fflush(stdout);

					bvr_tag_co = bvrs_co[0];

					if(AOM_UIF_ask_value(bvr_tag_co,"release_status_list",&BVR_Rlstatus_co));
					if(tc_strlen(BVR_Rlstatus_co) == 0)
					{
						if(AOM_lock( bvr_tag_co ));

						logical       retain_released_date =TRUE;
											
						printf("\n BEFORE stamping Review status on BVR\n");fflush(stdout);
						if(RELSTAT_create_release_status("T5_LcsWorking",&status_reviewBVR_co));
						if(RELSTAT_add_release_status(status_reviewBVR_co,1,&bvr_tag_co,retain_released_date));
						printf("\n After stamping Review status on BVR\n");fflush(stdout);	

						if(AOM_save_without_extensions( bvr_tag_co ));				  	    
						if(AOM_unlock( bvr_tag_co ));
					}
				}
			}
		}
	}


	//Added by Rohit to stamp working status on BVR Ends

	/*********************Adi Deleting relationship of weld report and qpp pdf from references on checkout****************/

		CALLAPI( GRM_find_relation_type("IMAN_reference",&reln_type_tagX));

		if( reln_type_tagX )
		{			
			CALLAPI(GRM_list_secondary_objects_only( object_tag, reln_type_tagX, &n_partsI, &secondary_obj_tag ));

			printf("\n IMAN_reference for [%d] parts found !! ",n_partsI); fflush(stdout);

			if(n_partsI>0)
			{
				for (ix=0;ix<n_partsI;ix++)
				{
					CALLAPI( GRM_find_relation(object_tag, secondary_obj_tag[ix], reln_type_tagX, &relation_tagX));

					if (relation_tagX)
					{
						CALLAPI(AOM_ask_value_string(secondary_obj_tag[ix],"object_name",&DsObjNameSX));
						
						printf("\n DsObjNameSX [%s] \n", DsObjNameSX);fflush(stdout);
						
						if((tc_strstr(DsObjNameSX,"QPP_Report")!=NULL)||(tc_strstr(DsObjNameSX,"Weld_Report")!=NULL) || (tc_strstr(DsObjNameSX,"PMXU")!=NULL))
						{	
							printf("\n QPP.pdf OR Weld_Report or PMXU found %s \n",DsObjNameSX); fflush(stdout);

							CALLAPI(GRM_delete_relation(relation_tagX));

							printf("\n reference relation of [%s] deleted \n",DsObjNameSX); fflush(stdout);
						}
					}
				}
			}
		}

	/*********************Adi Deleting relationship of weld report and qpp pdf from references on checkout**************/

	/**** Checkout usecases testing end */

	}
	//anil end



	/**************************************************************************************************************************/
	/*** On Assembly Checkout All Child WeldSpot Part Should Checked Out Automatically...... Added By Abhishek (8-Sep-2011) ***/
	/**************************************************************************************************************************/
	//if(!strcmp(type_name,"Design Revision"))//007 T5_SparKitRevision
	if((strcmp(type_name,"Design Revision")==0)||(strcmp(type_name,"T5_SparKitRevision")==0) || (strcmp(type_name,"T5_EE_PartRevision")==0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
	{
		printf("\nIt is Design Part ... So check\n");fflush(stdout);
		//if( AOM_ask_value_string(object_tag,"item_id",&cp_ItemId)!=ITK_ok) PrintErrorStack();
		//printf("ItemId for Checkout is [%s]\n", cp_ItemId);fflush(stdout);

		/*************************ALIAS ASSY MANAGEMENT*************/

	//		if(AOM_UIF_ask_value(object_tag,"t5_DesignGrp",&Aldesgrp)!=ITK_ok) PrintErrorStack();
	//		printf("\n design group value is =====> %s\n",Aldesgrp);fflush(stdout);
	//
	//		if(tc_strcmp(Aldesgrp,"ST")==0)
	//		  {
	//			//WSOM_where_referenced(object_tag,  1,  int * n_referencers,  int ** levels,   tag_t ** 	referencers,  char *** 	relations)					
	//			CALLAPI(WSOM_where_referenced(object_tag, 1 ,&n_refs,&levels,&referencers,&relations));
	//			printf("\n No. of items referenced to :%d\n",n_refs);fflush(stdout);
	//
	//			if(n_refs>0)
	//			 {
	//				for (rr=0;rr<n_refs;rr++)
	//				{
	//				  CALLAPI(TCTYPE_ask_object_type(referencers[rr],&objTypeRefTag));
	//				  CALLAPI(TCTYPE_ask_name2(objTypeRefTag,type_name_ref));
	//				  printf("\n Alias type_name_ref is :%s\n",type_name_ref);fflush(stdout);
	//
	//				  if(tc_strcmp(type_name_ref,"Design Revision")==0)
	//				   {
	//					 CALLAPI(RES_is_checked_out(objTypeRefTag,&Aliascheckout));
	//					// if(Aliascheckout==0)
	//					if(!Aliascheckout)
	//					  {
	//						 EMH_store_error_s1(EMH_severity_error,ITK_err,"The parent assembly is not in checked-out state. Pl checkout the parent assembly and then try to check out this part");
	//						 return ITK_err;			
	//					  }
	//					  else
	//					  {
	//						   printf("\n Alias PARENT is checked out , so allow checkout \n");fflush(stdout);
	//					  }
	//				   }
	//				}
	//			 }
	//		  }
			  /***********************ALIAS ASSY MANAGEMENT***************************/


		if (GRM_list_secondary_objects_only(object_tag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)
		PrintErrorStack();
		if( AOM_ask_value_string(object_tag,"item_id",&Item_id)!=ITK_ok) PrintErrorStack();
		printf("\nTotal Secondary Objects Found for Part [%s] are [%d]\n",Item_id,n_attchs);fflush(stdout);

		if (n_attchs > 0)
		{
			printf("\nThere are some Secondary Objects ... so proceed with checks\n");fflush(stdout);
			/*Getting ChildParts through BOM LINE*/
			if(BOM_create_window (&t_BomLineWindow) !=ITK_ok) PrintErrorStack();
			//printf("\nABHI 1111\n");fflush(stdout);
			if(CFM_find( "Latest Working", &t_Rule )!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 2222\n");fflush(stdout);
			if(BOM_set_window_config_rule( t_BomLineWindow, t_Rule )!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 3333\n");fflush(stdout);
			if(BOM_set_window_pack_all (t_BomLineWindow, true)!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 4444\n");fflush(stdout);
			if(BOM_set_window_top_line (t_BomLineWindow, t_ItemTag, object_tag, null_tag, &t_TopLine)!=ITK_ok) PrintErrorStack();
			//printf("\nABHI 5555\n");fflush(stdout);
			if(BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren)!=ITK_ok) PrintErrorStack();
			printf("\nTotal Child Parts Found in BomLine are [%d]\n",i_ChildCount);fflush(stdout);

			for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
			{
				if(t_Childobject) t_Childobject=NULLTAG;
				t_Childobject=t_PartChildren[iChldPrts];
				if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok) PrintErrorStack();
				if (TCTYPE_ask_name2(t_ChildObjType,&ca_ChildType_Name)!=ITK_ok) PrintErrorStack();
				printf("\n[%d] ChildType is [%s]\n",iChldPrts+1,ca_ChildType_Name);fflush(stdout);

				//if( BOM_line_look_up_attribute ("bl_item_object_type",&iItemType));
				//if(BOM_line_ask_attribute_string(t_Childobject, iItemType, &cp_ItemType_str));

				if( AOM_ask_value_string(t_Childobject,"bl_item_object_type",&cp_ItemType_str));
				printf("\n[%d] Child ItemType is [%s]\n",iChldPrts+1,cp_ItemType_str);

				//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
				//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
				//if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
				//if(BOM_line_ask_attribute_string(t_Childobject, iItemRevId, &cp_ItemRev_str));

				if( AOM_ask_value_string(t_Childobject,"bl_rev_item_revision_id",&cp_ItemRev_str));
				if( AOM_ask_value_string(t_Childobject,"bl_item_item_id",&cp_ItemID_str));
				printf("\n[%d] ItemRevision is [%s] and ItemID is: [%s]\n",iChldPrts+1,cp_ItemRev_str,cp_ItemID_str);

				//if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
				//if(BOM_line_ask_attribute_tag(t_Childobject, iChildItemTag, &t_ChildItemRev));

				if(ITEM_find_item(cp_ItemID_str,&new_itemId_new1));
				CALLAPI(ITEM_find_revision(new_itemId_new1,cp_ItemRev_str,&t_ChildItemRev));

				if(AOM_ask_value_int(t_ChildItemRev,"sequence_id",&i_ChildSeq));
				cp_ChildSeq = (char *) MEM_alloc( 5 * sizeof(char) );
				sprintf(cp_ChildSeq,"%d",i_ChildSeq);
				printf("\n[%d] ItemSequence is [%s]\n",iChldPrts+1,cp_ChildSeq);fflush(stdout);

				//if(BOM_line_look_up_attribute ("bl_rev_checked_out",&iItemChkdOut));
				//if(BOM_line_ask_attribute_string (t_Childobject, iItemChkdOut, &cp_ChildChkOutValue));

				if( AOM_ask_value_string(t_Childobject,"bl_rev_checked_out",&cp_ChildChkOutValue));
				printf("\n[%d] CheckedOut is [%s]\n",iChldPrts+1,cp_ChildChkOutValue);fflush(stdout);

				if (AOM_ask_value_string(t_ChildItemRev,"current_desc",&Desc_obj)!=ITK_ok) PrintErrorStack();
				printf("\n[%d] Description is [%s]\n",iChldPrts+1,Desc_obj);fflush(stdout);

				//if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && ((tc_strcmp(cp_ItemType_str,"WeldSpot")==0)||(tc_strstr(cp_ItemID_str,"_WE") != NULL)))
				if((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && ((tc_strcmp(cp_ItemType_str,"WeldSpot")==0))) 
				{
					printf("\nThis is WeldSpot and is Not Checked out... so auto checkout it\n");fflush(stdout);
					CALLAPI(RES_checkout2(t_ChildItemRev,reason,change_id,dir_name,reservation_type));
				}
			    //if (tc_strstr(cp_ItemID_str,"_WE") != NULL)
			    if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && (tc_strstr(cp_ItemID_str,"_WE")!= NULL)) 
				{
					printf("\n _WE not checked out.. so auto checkout \n");fflush(stdout);
					CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTag));
					CALLAPI(AOM_refresh(t_ChildItemRev,0));
					CALLAPI(AOM_refresh(NewRevTag,0));
				}

				//NSS CR/ERC/MSD/25/0006
				char	*parentPart					= NULL;
				parentPart = (char *)MEM_alloc(50);
				tc_strcpy(parentPart,"");
				tc_strcpy(parentPart,Item_id);
				tc_strcat(parentPart,"_AD");
				printf("\n CR/ERC/MSD/25/0006 parentPart: [%s] cp_ItemID_str: [%s] \n",parentPart,cp_ItemID_str);fflush(stdout);
				//	if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && (tc_strstr(cp_ItemID_str,"_AD")!= NULL)) 
				if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && (tc_strcmp(cp_ItemID_str,parentPart) == 0))
				{
					printf("\n _AD not checked out.. so auto checkout \n");fflush(stdout);
					CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTagAD));
					CALLAPI(AOM_refresh(t_ChildItemRev,0));
					CALLAPI(AOM_refresh(NewRevTagAD,0));
				}

				if ((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) && (tc_strstr(cp_ItemID_str,"_MB")!= NULL)) 
				{
					printf("\n _MB not checked out.. so auto checkout \n");fflush(stdout);
					CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTagAD));
					CALLAPI(AOM_refresh(t_ChildItemRev,0));
					CALLAPI(AOM_refresh(NewRevTagAD,0));
				}

				//ADDED BY ajinkya on 02 Jun//
				printf("\n CHECK FOR WE PART AUTO CHECK OUT FOR SEQ 1 \n");fflush(stdout);

				if(QRY_find2("ControlObjQry", &TagWeControl));

				 if(QRY_execute(TagWeControl, n_entriesWe, qry_entriesWe, qry_valuesWe, &n_foundWe, &cntr_objectsWe));
				 printf("\n Control Object found for WE parts == %d\n", n_foundWe);fflush(stdout);

				 if(n_foundWe==1)
				 {
					 printf("\n ##AS WE Control obejcts found \n");fflush(stdout);

					 printf("\n weIn side control object for we ItemSequence is [%s]\n",cp_ChildSeq);fflush(stdout);

					 printf("\n WE ItemRevision is [%s] \n",cp_ItemRev_str);

					 RefPatRev = strtok ( cp_ItemRev_str, ";" );
					 RefPatSeq = strtok ( NULL, ";" );

					 printf("\n WE REQUIRED  ItemRevision is [%s] \n",RefPatRev);
					 printf("\n WE REQUIRED  ItemSequence is [%s] \n",RefPatSeq);

					 if (AOM_UIF_ask_value(t_ChildItemRev,"release_status_list",&WErelease_status)!=ITK_ok) PrintErrorStack();
					 printf("\n WE release_status:[%s]\n",WErelease_status);fflush(stdout);

					 if (tc_strstr(WErelease_status,"Released")!=NULL)
					 {
						printf("\n ALL CONDITIONS ARE MATCHING FOR AUTO CHECK OUT OF _WE PART TWICE \n");fflush(stdout);

						if(tc_strstr(cp_ItemID_str,"_WE")!= NULL) 
						{
							printf("\n Again _WE not checked out.. so auto checkout \n");fflush(stdout);
							CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTag));
							CALLAPI(AOM_refresh(t_ChildItemRev,0));
							CALLAPI(AOM_refresh(NewRevTag,0));
						}

						//if (tc_strstr(cp_ItemID_str,"_AD")!= NULL)
						//NSS CR/ERC/MSD/25/0006
						if (tc_strcmp(cp_ItemID_str,parentPart) == 0)
						{
							printf("\nAgain _AD not checked out.. so auto checkout \n");fflush(stdout);
							CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTagAD));
							CALLAPI(AOM_refresh(t_ChildItemRev,0));
							CALLAPI(AOM_refresh(NewRevTagAD,0));
						}
						

						if (tc_strstr(cp_ItemID_str,"_MB")!= NULL)
						{
							printf("\nAgain  _MB not checked out.. so auto checkout \n");fflush(stdout);
							CALLAPI(ITEM_copy_rev(t_ChildItemRev,NULL,&NewRevTagAD));
							CALLAPI(AOM_refresh(t_ChildItemRev,0));
							CALLAPI(AOM_refresh(NewRevTagAD,0));
						}

					 }
					 else
					 {
						printf("\nELSE  No condition ARE MATCHING FOR AUTO CHECK OUT OF _WE PART TWICE \n");fflush(stdout);

					 }
					
				 }
				 else
				{
					printf("\nELSE  No Control obejct found \n");fflush(stdout);

				}
				//end//
			}
			 //Muktesh
			 printf("\n Closing Bom Window\n");fflush(stdout);
			if(BOM_close_window (t_BomLineWindow) !=ITK_ok) PrintErrorStack();
			 printf("\n After Closing Bom Window\n");fflush(stdout);
			//BOM_close_window(t_BomLineWindow);
		}
		/*Added By Abhishek For Bom View Revision Checkout on Design Checkout*/
		printf("\nTypeName for Checkout is [%s]\n",type_name);fflush(stdout);
		//if (strcmp(type_name,"Design Revision") == 0)//007 
		if ((strcmp(type_name,"Design Revision") == 0)||((strcmp(type_name,"T5_SparKitRevision") == 0)) || (strcmp(type_name,"T5_EE_PartRevision") == 0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
		{
			 printf("\n going to stamp status\n");fflush(stdout);


			 /*Start  Removing Release Status Code by Deepti*/

			CALLAPI(POM_class_of_instance(object_tag,&class_id));
			CALLAPI(POM_name_of_class(class_id,&class_name));
			printf("\n class_name is :%s\n",class_name);fflush(stdout);

			CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

			CALLAPI(POM_unload_instances (1,&object_tag));
			CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
			CALLAPI(POM_is_loaded(object_tag,&log1));
			if(log1 == 1)
			{
				 printf(" Load Success\n " );
			}
			else
			printf("Load Failure\n"  );

			CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList, &n_values) );
			printf("\n n_values is :%d\n",n_values);fflush(stdout);
			if(n_values>0)
			{
				CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

				for (cunt1 =  0; cunt1 < n_values; cunt1++)
				{
					printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList,0,1));
					printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save_without_extensions(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));

				}

				 CALLAPI(AOM_unlock(object_tag));
			}

			 /*End  Removing Release Status Code by Deepti*/

			  CALLAPI(SA_ask_current_role(&CurrentRoleTag));  //DEEPTI TZ1.34
			 CALLAPI(SA_ask_role_name2(CurrentRoleTag,&roleNameVal));//MBOM implementation for CV TZ-1.69
			 tc_strcpy(roleName,roleNameVal);//MBOM implementation for CV TZ-1.69
			 printf("\nLine 5820\n"); fflush(stdout);
			 printf("\n\n  roleNameVal : %s,roleName : %s\n",roleNameVal,roleName); fflush(stdout);//MBOM implementation for CV TZ-1.69
			  
			  if(tc_strstr(roleName,"MBOM")!=NULL)	//MBOM implementation for CV TZ-1.69
			  {
				dsgModAddressVal = strtok (roleNameVal,"_");	//MBOM implementation for CV TZ-1.69
				PlantName = strtok (NULL,"_");
				printf( "dsgModAddressVal:%s\n", dsgModAddressVal); fflush(stdout);
				printf( "PlantName:%s\n", PlantName); fflush(stdout); //MBOM implementation for CV TZ-1.69
			  }
			  else						 //MBOM implementation for CV TZ-1.69
			  {
					  
					  PlantName=subString(roleName,3,4);
			  }
			  printf( "PlantName:%s\n", PlantName);fflush(stdout);

			//UPdate Lifecycle state on Design Revision
			 //CALLAPI (RELSTAT_create_release_status("T5_LcsWorking",&status_rel));
			 //CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));

			 if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL))	//MBOM implementation for CV TZ-1.69
			 {
				 		
				 get_CtrlVal_RelStateChkInf(PlantName,RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,View);//MBOM implementation for CV TZ-1.69
				 printf( "\n RvwLCVal:%s, RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s, RlzdActLcVal:%s,View:%s\n", RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,View);fflush(stdout);//MBOM implementation for CV TZ-1.69

				 CALLAPI (RELSTAT_create_release_status(WrkngLCVal,&status_rel));	  //MBOM implementation for CV TZ-1.69
				 CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));//MBOM implementation for CV TZ-1.69
				 
				 /*if(strcmp(PlantName,"APLC")==0)	//MBOM implementation for CV TZ-1.69	
		         {
					CALLAPI (RELSTAT_create_release_status("T5_LcsAPLWrkg",&status_rel)); //DEEPTI TZ1.34
					CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));//DEEPTI TZ1.34
				 }
				 else if(strcmp(PlantName,"APLV")==0)	//MBOM implementation for CV TZ-1.69
		         {
					CALLAPI (RELSTAT_create_release_status("T5_LcsAPLvWrkg",&status_rel)); //DEEPTI TZ1.34
					CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));//DEEPTI TZ1.34
				 }*/
			 }
			 else
			 {

				//UPdate Lifecycle state on Design Revision
				CALLAPI (RELSTAT_create_release_status("T5_LcsWorking",&status_rel));
				CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
			 }

			//UPdate Lifecycle state on BOM VIew
			if(ITEM_rev_list_bom_view_revs(object_tag,&BomViewCnt,&BomViewList)!=ITK_ok) PrintErrorStack();
			printf("\nCount of BomView [%d]\n",BomViewCnt);fflush(stdout);

			if (BomViewCnt > 0)
			{
				printf("\nCheckout BOM Views Also .............\n");fflush(stdout);

				if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) //MBOM implementation for CV TZ-1.69
				{
					/*if(strcmp(PlantName,"APLC")==0)		//MBOM implementation for CV TZ-1.69,Commented the if-else block
					{
						printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLWrkg");
						printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
					}
					else if(strcmp(PlantName,"APLV")==0) //MBOM implementation for CV TZ-1.69
					{
					printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
					status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLvWrkg");
					printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
					}*/

					status = t5UpdateLifecycleStateAD(dataset, WrkngLCVal); //MBOM implementation for CV TZ-1.69 ,Added
				}
				else
				{
					printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
					status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
					printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				}

	//				printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
	//				status = t5UpdateLifecycleStateAD(BomViewList[0], "T5_LcsWorking");
	//				printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
			}

			//UPdate Lifecycle state on Dataset
			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
			if(relation_type)
			{
				CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
				printf("\n Checkin- Relation Type Name:%s\n",relation_name);fflush(stdout);
				CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
				printf("\n Checkin- Attached Datasets:%d\n",cnt);fflush(stdout);
				for(i=0;i<cnt;i++)
				{
				  printf("\nin checkin for loop\n");fflush(stdout);
				  dataset = attachments[i];
				  CALLAPI(RES_is_checked_out(dataset,&checkout));
				  printf("\nValue of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);
				  if (checkout==1)
				  {
					  if((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL))	//MBOM implementation for CV TZ-1.69
					  {
						
						 /*if(strcmp(PlantName,"APLC")==0)	//MBOM implementation for CV TZ-1.69,Commented the if-else block
		                {
						printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLWrkg");
						printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
						}else 	if(strcmp(PlantName,"APLV")==0)
		                {
						printf("\nSetting Lifecycle State as APL Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsAPLvWrkg");
						printf("\nUpdation of Lifecycle State as APL Working on Dataset Status == %d\n", status);//DEEPTI TZ1.34
						}*/
						status = t5UpdateLifecycleStateAD(dataset, WrkngLCVal); //MBOM implementation for CV TZ-1.69 ,Added
					  }
					  else
					  {
						printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
						status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
						printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
					  }

					  //printf("\nSetting Lifecycle State as ERC Working  For Dataset\n");
					  //status = t5UpdateLifecycleStateAD(dataset, "T5_LcsWorking");
					  //printf("\nUpdation of Lifecycle State on Dataset Status == %d\n", status);
				  }

				}
			}
		}
	}
	else
	{

		if((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0) || (strcmp(type_name,"ProDrw")==0))
		{
			printf("\n other than DR for skk TypeName for checkout  is [%s]\n",type_name);fflush(stdout);
			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type_Dsn));

			    if(relation_type_Dsn)
			    {
				     CALLAPI(GRM_list_primary_objects(object_tag,relation_type_Dsn,&count2,&primary_list2));
					 printf("\n No:of Des Rev Obj attached to dataset are --> [%d]\n",count2);fflush(stdout);
			    }

			    if(primary_list2)
				{
						printf("\n\nDataset Attached to Primary Object in in checkin_dataset:%d\n",count2);fflush(stdout);

						for(i2=0;i2<count2;i2++)
						{
						   //primary_object2 = primary_list2[i].primary;
						   //primary_object2 = primary_list2[i];
						   primary_object2 = primary_list2[i2].primary;
						   if(primary_object2)
						   {
							 //printf("\nprimary_object2 in skk checkin :%d\n",i);
							 printf("\nprimary_object2 in skk checkin :%d\n",i2);
							 CALLAPI(RES_is_checked_out(primary_object2,&checkout2));
							 	printf("\nValue of checkout2 for primary_object2 : %d\n",checkout2);fflush(stdout);
						//	 printf("\n\nallow_chkin1 in in disallow_checkin_dataset:%d and ObjectClassType 222 :%s and strcmp proasm :%d\n",allow_chkin,ObjectClassType,strcmp(ObjectClassType,"ProPrt"));

							//  if(strcmp(ObjectClassType,"ProPrt")==0)// && (strcmp(ObjectClassType,"ProPrt")!=0))
							//  {
								//if(checkout2==0)
								if(!checkout2)
								{
								  printf("\n inside DR for ProAsmmmmmmmmmmmmmmmmmm \n");
								  CALLAPI(RES_checkout2(primary_object2,reason,change_id,dir_name,reservation_type));
								  //CALLAPI (RELSTAT_create_release_status("T5_LcsWorking",&status_rel));
								  //CALLAPI(RELSTAT_add_release_status(status_rel,1,&primary_object2,retain));
								  printf("\n checkout  in Design revision for  PROE \n");
								 }
							//  }
							 }
					  }
			  }
		 }
	}
	/*************************************************************************************************/
	/********************************** Code End Abhishek (8-Sep-2011) *******************************/
	/*************************************************************************************************/

	//**************************** DVA Start *****************************

	if((strcmp(type_name,"Design Revision")==0))
	{
		count2 =0;
		i2 =0;

		printf("\n DVA checkout_with_dataset TypeName for checkout  is [%s]\n",type_name);fflush(stdout);
		CALLAPI(GRM_find_relation_type("T5_DesignHasDVA",&relation_type_Dsn));

		if(relation_type_Dsn)
		{
			 CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type_Dsn,&count2,&attachments));
			 printf("\n  DVA checkout_with_dataset No:of Des Rev Obj attached to dataset are --> [%d]\n",count2);fflush(stdout);
		}

		if(attachments)
		{
			printf("\n\n DVA checkout_with_dataset Dataset Attached to Primary Object in in checkin_dataset:%d\n",count2);fflush(stdout);

			for(i2=0;i2<count2;i2++)
			{
				primary_object2 = attachments[i2];
				if(primary_object2)
				{
					printf("\n DVA checkout_with_dataset primary_object2 checkin :%d\n",i2);
					CALLAPI(RES_is_checked_out(primary_object2,&checkout2));
					printf("\n  checkout_with_dataset Value of checkout2 for primary_object2 : %d\n",checkout2);fflush(stdout);

					if(!checkout2)
					{
					  printf("\n DVA checkout_with_dataset inside OKKKKKKK \n");
					  CALLAPI(RES_checkout2(primary_object2,reason,change_id,dir_name,reservation_type));
					  printf("\n DVA checkout_with_dataset  in Design revision for  DVA \n");
					}
				}
			}
		}
	}

	//**************************** DVA End *****************************

	//NSS TZ:1.89 CR/ERC/MSD/25/0012
	char	*iGrpName		= NULL;
	tag_t	iGrpTag			= NULLTAG;
	printf(" \n\n checkout_with_dataset [CR/ERC/MSD/25/0012]: type_name [%s]",type_name); fflush(stdout);
	if(tc_strcmp(type_name,"Design Revision")== 0)
	{
		POM_ask_group(&iGrpName, &iGrpTag);
		printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Group Name [%s]\n",iGrpName);fflush(stdout);
		
		if(tc_strstr(iGrpName,"ERC_Designers_Group")!=NULL)
		//if((tc_strstr(iGrpName,"ERC_Designers_Group")!=NULL) || (tc_strstr(iGrpName,"PLM_Support_Group")!=NULL))
		{
			char	*tPrtNum	=	 NULL;

			if(AOM_ask_value_string(object_tag,"object_string",&tPrtNum)!=ITK_ok) PrintErrorStack();
			printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: [%s] ",tPrtNum);fflush(stdout);
			
			tag_t		findNoCtrlO				=	NULLTAG;
			tag_t		*findNoCtrlOS			=	NULLTAG;

			int			iFindNoQryE1			=	1;
			int			iFindNoQryCnt			=	0;

			char		*iFindNoQryE[1]			= {"SYSCD"};
			char		**iFindNoQVal			= (char **) MEM_alloc(100 * sizeof(char *));


			QRY_find2("ControlObjQry", &findNoCtrlO);
			if (findNoCtrlO != NULLTAG)
			{
				iFindNoQVal[0] = "creoCheck_0012";
				QRY_execute(findNoCtrlO, iFindNoQryE1, iFindNoQryE, iFindNoQVal, &iFindNoQryCnt, &findNoCtrlOS);
			}
			printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Control object count size = [%d]",iFindNoQryCnt);fflush(stdout);

			if(iFindNoQryCnt > 0)
			{
				char	*tPrtNum			= NULL;
				char	*iLatestRevSeq		= NULL;
				char	*LatestRevRelSt		= NULL;
				char	*iRelestat			= NULL;
				char	*iLatestRevRlz		= NULL;
				char	*iLatestRevRew		= NULL;
				char	*ParentProjectCode	= NULL;
				char	*type_nameSec		= NULL;
				char	*ProObjName			= NULL;
				char	*ProObjId			= NULL;
				char	*ProjectCode		= NULL;
				char	*prtType			= NULL;

				tag_t	new_relation		= NULLTAG;
				tag_t	relation_tag		= NULLTAG;
				tag_t	iProObjItemMaster	= NULLTAG;
				tag_t	iProObjRev			= NULLTAG;
				tag_t	tLatestRev			= NULLTAG;
				tag_t	tRel_ImanSpec		= NULLTAG;
				tag_t	*iStatus_list		= NULLTAG;
				tag_t	*revListSet			= NULLTAG;
				tag_t	*SecObjs			= NULLTAG;
				tag_t	t_SecObjType		= NULLTAG;
				tag_t	ProRelation_type	= NULLTAG;
				tag_t	*ProAsmMemberstag	= NULLTAG;

				int		istatusCnt,ia,iAlRevCnt,ic,resultt,n_attchsCre,ii,result2,n_attch_asm,ip		= 0;

				

				if(AOM_ask_value_string(object_tag,"object_string",&tPrtNum)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(object_tag,"t5_ProjectCode",&ParentProjectCode)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(object_tag,"t5_PartType",&prtType)!=ITK_ok) PrintErrorStack();
			
				printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Latest revision - [%s] Project code  - [%s] Part Type - [%s]\n\n",tPrtNum,ParentProjectCode,prtType);fflush(stdout);
				
				if ((tc_strcmp(prtType,"A")==0) || (tc_strcmp(prtType,"M")==0) || (tc_strcmp(prtType,"CM")==0) || (tc_strcmp(prtType,"G")==0) || (tc_strcmp(prtType,"T")==0))
				{
					//Creo Members logic
					resultt = GRM_find_relation_type("IMAN_specification", &tRel_ImanSpec);
					if(tRel_ImanSpec)
					{
						ITK_CALL(GRM_list_secondary_objects_only(object_tag, tRel_ImanSpec, &n_attchsCre,&SecObjs));

						if(n_attchsCre>0)
						{
							for (ii=0; ii < n_attchsCre; ii++)
							{
								if(TCTYPE_ask_object_type(SecObjs[ii],&t_SecObjType))PrintErrorStack();
								if(TCTYPE_ask_name2(t_SecObjType,&type_nameSec))PrintErrorStack();
								printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Type_name:[%s]",type_nameSec); fflush(stdout);

								if (tc_strcmp(type_nameSec,"ProAsm")==0)
								{
									result2 = GRM_find_relation_type("Pro2_membership", &ProRelation_type);

									if(GRM_list_secondary_objects_only(SecObjs[ii], ProRelation_type, &n_attch_asm ,&ProAsmMemberstag)!=ITK_ok) PrintErrorStack();
									printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: ProAsmMem from ProAsm dataset:: %d",n_attch_asm);fflush(stdout);

									if(n_attch_asm>0)
									{
										for (ip = 0; ip < n_attch_asm; ip++)
										{
											if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_id",&ProObjName)!=ITK_ok) PrintErrorStack();
											if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_revision_id",&ProObjId)!=ITK_ok) PrintErrorStack();
											if( AOM_ask_value_string(ProAsmMemberstag[ip],"t5_ProjectCode",&ProjectCode)!=ITK_ok) PrintErrorStack();
											printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: ProObjName[%s/%s] Project code  - [%s]\n",ProObjName,ProObjId,ProjectCode); fflush(stdout);
											
											//write a code to find the latest released/review rev
											if(tc_strcmp(ParentProjectCode,ProjectCode) == 0)
											{
												printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Project code matched of [%s] & [%s]\n",tPrtNum,ProObjName); fflush(stdout);
												//exclude the checkout revision and attached the previous ERC review/released revision
												if (ITEM_find_item(ProObjName,&iProObjItemMaster)!=ITK_ok) PrintErrorStack();
												ITK_CALL(ITEM_list_all_revs(iProObjItemMaster,&iAlRevCnt,&revListSet));
												printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: All Revision count is [%d]",iAlRevCnt);fflush(stdout);

												for(ic=(iAlRevCnt-1);ic>=0;ic--)
												{
													ITK_CALL(AOM_UIF_ask_value(revListSet[ic],"release_status_list",&iRelestat));
													printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: iRelestat [%s]  ",iRelestat);fflush(stdout);
													if(iRelestat)
													{
														tLatestRev = revListSet[ic];
														if((tc_strstr(iRelestat,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(iRelestat,"ERC Released") != NULL)) //Get latest ERC released revision
														{
															if( AOM_ask_value_string(tLatestRev,"item_revision_id",&iLatestRevRlz)!=ITK_ok);
															printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Latest Released revision is [%s] ",iLatestRevRlz);fflush(stdout);
															
															if(tc_strcmp(ProObjId,iLatestRevRlz) != 0) //Latest ERC released is not attached
															{
																//Code to add/delete relation of creomembership

																if(GRM_find_relation(SecObjs[ii], ProAsmMemberstag[ip], ProRelation_type, &relation_tag)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: I am Delete dataset of reference \n");
																if(GRM_delete_relation(relation_tag)!=ITK_ok)PrintErrorStack();
																if(AOM_refresh (SecObjs[ii], 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Reference has been deleted from the dataset \n");
																if(GRM_create_relation(SecObjs[ii],tLatestRev,ProRelation_type,NULLTAG,&new_relation)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Again relation is created \n");
																if(AOM_refresh (new_relation, 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 1st refresh \n");
																if(new_relation)
																{
																	if(GRM_save_relation(new_relation)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After Save relation\n");
																	if(AOM_refresh (SecObjs[ii], 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 2nd refresh \n");
																	if(AOM_refresh (new_relation, 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 3rd refresh \n");
																}	
															}
															break;
														}
														else if ((tc_strstr(iRelestat,"T5_LcsReview")!= NULL) || (tc_strstr(iRelestat,"ERC Review") != NULL)) //Get latest ERC review revision
														{
															if( AOM_ask_value_string(tLatestRev,"item_revision_id",&iLatestRevRew)!=ITK_ok);
															printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Latest Review revision is [%s] ",iLatestRevRew);fflush(stdout);
							
															if(tc_strcmp(ProObjId,iLatestRevRew) != 0) //Latest ERC Review is not attached
															{
																//Code to add/delete relation of creomembership
																if(GRM_find_relation(SecObjs[ii], ProAsmMemberstag[ip], ProRelation_type, &relation_tag)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: I am Delete dataset of reference \n");
																if(GRM_delete_relation(relation_tag)!=ITK_ok)PrintErrorStack();
																if(AOM_refresh (SecObjs[ii], 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Reference has been deleted from the dataset \n");
																if(GRM_create_relation(SecObjs[ii],tLatestRev,ProRelation_type,NULLTAG,&new_relation)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Again relation is created \n");
																if(AOM_refresh (new_relation, 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 1st refresh \n");
																if(new_relation)
																{
																	if(GRM_save_relation(new_relation)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After Save relation\n");
																	if(AOM_refresh (SecObjs[ii], 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 2nd refresh \n");
																	if(AOM_refresh (new_relation, 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 3rd refresh \n");
																}	
															}
															break;
														}		
													}
												}
											}
											else
											{
												printf("\n checkin_with_dataset [CR/ERC/MSD/25/0012]: Project code does not matched of [%s] & [%s]\n",tPrtNum,ProObjName); fflush(stdout);
												//attached latest erc released to references
												if (ITEM_find_item(ProObjName,&iProObjItemMaster)!=ITK_ok) PrintErrorStack();
												ITK_CALL(ITEM_list_all_revs(iProObjItemMaster,&iAlRevCnt,&revListSet));
												printf("\n 2. checkout_with_dataset [CR/ERC/MSD/25/0012]: All Revision count is [%d]",iAlRevCnt);fflush(stdout);

												for(ic=(iAlRevCnt-1);ic>=0;ic--)
												{
													ITK_CALL(AOM_UIF_ask_value(revListSet[ic],"release_status_list",&iRelestat));
													printf("\n 2. checkout_with_dataset [CR/ERC/MSD/25/0012]: iRelestat [%s]  ",iRelestat);fflush(stdout);
													if(iRelestat)
													{
														tLatestRev = revListSet[ic];
														if((tc_strstr(iRelestat,"T5_LcsErcRlzd")!= NULL) ||(tc_strstr(iRelestat,"ERC Released") != NULL)) //get latest ERC released revision
														{
															if( AOM_ask_value_string(tLatestRev,"item_revision_id",&iLatestRevRlz)!=ITK_ok);
															printf("\n 2. checkout_with_dataset [CR/ERC/MSD/25/0012]: Latest Released revision is [%s] ",iLatestRevRlz);fflush(stdout);
															
															if(tc_strcmp(ProObjId,iLatestRevRlz) != 0) // Latest ERC released is not attached
															{
																//Code to add/delete relation of creomembership
																if(GRM_find_relation(SecObjs[ii], ProAsmMemberstag[ip], ProRelation_type, &relation_tag)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: I am Delete dataset of reference \n");
																if(GRM_delete_relation(relation_tag)!=ITK_ok)PrintErrorStack();
																if(AOM_refresh (SecObjs[ii], 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Reference has been deleted from the dataset \n");
																if(GRM_create_relation(SecObjs[ii],tLatestRev,ProRelation_type,NULLTAG,&new_relation)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Again relation is created \n");
																if(AOM_refresh (new_relation, 1)!=ITK_ok)PrintErrorStack();
																printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 1st refresh \n");
																if(new_relation)
																{
																	if(GRM_save_relation(new_relation)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After Save relation\n");
																	if(AOM_refresh (SecObjs[ii], 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 2nd refresh \n");
																	if(AOM_refresh (new_relation, 0)!=ITK_ok)PrintErrorStack();
																	printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: After 3rd refresh \n");
																}	
															}
															break;
														}		
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					printf("\n checkout_with_dataset [CR/ERC/MSD/25/0012]: Part type is other than assembly, module, CP module, TPL, group id \n\n");fflush(stdout);
				}
			}
			else
			{
				printf("\n checkin_with_dataset [CR/ERC/MSD/25/0012]: control object not found \n");fflush(stdout);
			}
		}
		else
		{
			printf("\n checkin_with_dataset [CR/ERC/MSD/25/0012]: User is other than ERC_Designer_Group \n");fflush(stdout);
		}
	}
	printf("\n checkin_with_dataset [CR/ERC/MSD/25/0012] Completed...! \n");fflush(stdout);
	//End TZ:1.89 CR/ERC/MSD/25/0012

	return ifail;
}

extern DLLAPI int cancelcheckout_with_dataset(METHOD_message_t *m, va_list args)
{
  	//char		   relation_name[TCTYPE_name_size_c+1];
	tag_t		   relation_type	= NULLTAG;
	tag_t		   *attachments		= NULLTAG;
	tag_t		   dataset			= NULLTAG;
	tag_t		   relation_dep22			= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	logical		   copy_flag		= (logical)   va_arg (args, int);
	int		       ifail=0,cnt=0,i,ij,count=0,count_asm=0;
	GRM_relation_t *primary_list	= NULLTAG;
	char		   *is_chkout		=NULL;
	char		   *is_chkout1		=NULL;
	char		   *relation_name		=NULL;
	char		   *org_rev_id		=NULL;
	char		   *org_item_cat		=NULL;
	char		   *sPartID		=NULL;
	tag_t		   primary_object	= NULLTAG;
	tag_t		   *tags	= NULLTAG;
	tag_t		   objTypeTag = NULLTAG;
	//char		   type_name[TCTYPE_name_size_c+1];
	char   *Id_string_val=NULL;
	char   *type_name=NULL;
	char   *sAsmVer=NULL;
	char   *asm_rev=NULL;
	int main_seq=0;
	char   *Id_Pro_val=NULL;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	int org_seq_id_int=0;
	tag_t		   primary_object2	= NULLTAG;
	tag_t* status_list = NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t queryTagP = NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	int n_entries = 3;
	int n_entries2 = 2;
	int resultCountAsm = 0;
	int resultCount=0,jk=0,countDep11=0;
	tag_t *rev=NULLTAG;
	tag_t *revAsm=NULLTAG;
	WSO_search_criteria_t  	criteria;
	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};

	char *qry_entries5[2] = {"Name","Version Number"},
		 *qry_values5[2]	= {"*","*"};
	printf("\n\nIn cancel_checkout_with_dataset\n");

	CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));

	if (TCTYPE_ask_object_type(object_tag,&objTypeTag)!=ITK_ok);
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	printf("\n type_name  = [%s]\n", type_name);fflush(stdout);

	// Added to handle relation b/w ProAsm and Des Rev
//				 printf("\n\n Pro2_membership relation new11\n");
//
//				 if(strcmp(type_name,"Design Revision")==0 )
//				{
//
//
//				CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//				printf("\n Final Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);
//
//				CALLAPI(AOM_ask_value_string(object_tag,"t5_ItmCategory",&org_item_cat));
//				printf("\n Item Category of Prev Seq is -->%s\n",org_item_cat); fflush(stdout);
//
//				if(strlen(org_item_cat)>0)
//				{
//					sPartID = strtok( org_item_cat, ";" );
//					sAsmVer = strtok( NULL, " " );
//
//					printf("\n sPartID -->%s\n",sPartID); fflush(stdout);
//					printf("\n sAsmVer -->%s\n",sAsmVer); fflush(stdout);
//
//					if(QRY_find2("ProAsm Dataset", &queryTagP));
//
//					if (queryTagP)
//					{
//					printf(" ProAsm Found Query\n"); fflush(stdout);
//					}
//					else
//					{
//					printf("ProAsm Not Found Query\n"); fflush(stdout);
//					}
//
//					qry_values1[0] = sPartID ;
//					qry_values1[1] = sAsmVer;
//					if(QRY_execute(queryTagP, n_entries2, qry_entries5, qry_values1, &resultCountAsm, &revAsm));
//
//					printf("No:of ProAsm Found in DB are -->%d\n",resultCountAsm); fflush(stdout);
//
//
//					asm_rev = revAsm[0];
//
//					CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
//
//					CALLAPI(GRM_create_relation(asm_rev, object_tag, relation_dep, NULL, &relation_New));
//					CALLAPI(AOM_refresh (asm_rev,0));
//					CALLAPI(AOM_refresh(relation_New,0));
//					CALLAPI(AOM_refresh(object_tag,0));
//					CALLAPI(GRM_save_relation(relation_New));
//					printf("\n GRM_save_relation created succ \n\n"); fflush(stdout);
//
//				}
//
//
//
//
//				CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep11,&primary_list_Dep11));
//
//				printf("\n\n After deleting ProAsm Rel with Des Rev are --->:%d\n",countDep11);
//			}

				// Ended to handle relation b/w ProAsm and Des Rev


	//if(!strcmp(type_name,"Design Revision"))//007 T5_SparKitRevision
	if((strcmp(type_name,"Design Revision")==0)||(strcmp(type_name,"T5_SparKitRevision")==0) ||(strcmp(type_name,"T5_EE_PartRevision")==0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
	{
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Attached Datasets rbb111:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  dataset = attachments[i];

		  if( AOM_ask_value_string(dataset,"checked_out",&is_chkout1)!=ITK_ok) PrintErrorStack();
			{

			   printf("\n is_chkout1 ---->%s \n",is_chkout1);

				if(strcmp(is_chkout1,"Y")==0)
				{
					 CALLAPI(RES_cancel_checkout(dataset,copy_flag));
					printf("\n %d Canceled DataSet Check Out \n",dataset);

				}
			}

		}

	}

	if(relation_type)
	{
		CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
		printf("\n Relation Type Name:%s\n",relation_name);fflush(stdout);
		CALLAPI(GRM_list_secondary_objects_only(object_tag,relation_type,&cnt,&attachments));
		printf("\n Attached Datasets rbb:%d\n",cnt);fflush(stdout);
		for(i=0;i<cnt;i++)
		{
		  dataset = attachments[i];

		  if( AOM_ask_value_string(dataset,"checked_out",&is_chkout1)!=ITK_ok) PrintErrorStack();
			{
				printf("\n is_chkout1 ---->%s \n",is_chkout1);

				if(strcmp(is_chkout1,"N")==0)
				{
					CALLAPI(RES_cancel_checkout(dataset,copy_flag));
					printf("\n %d Canceled DataSet Check Out \n",dataset);

				}
			}
		}

//	 CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//	  printf("\n ppcancel Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);

//	  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
//	  printf("\n ppcancel Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);

		if(object_tag)
		{
			printf("\n ppcancel inside if loop  \n"); fflush(stdout);

			CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));

			if(primary_list)
			{
				printf("\n\n Des Rev Attached to Dataset rbb:%d\n",count);

				for(ij=0;ij<count;ij++)
				{
				   primary_object = primary_list[ij].primary;
				   if(primary_object)
				   {
					 printf("\nprimary_object:%d\n",ij);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)!=ITK_ok) PrintErrorStack();
					 {
						if(strcmp(is_chkout,"Y")==0)
						{

							  CALLAPI(RES_cancel_checkout(primary_object,copy_flag));
							  printf("\n\n checked-out sucess:\n");

						}
					 }

				  }
				}
			}
		}

		printf("\n Exitssssssss \n");
	}
    return ifail;
}


extern DLLAPI int disallow_checkin_dataset_only(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	int count = 0,i=0;
	char		   *is_chkout		=NULL;
 	GRM_relation_t *primary_list	= NULLTAG;

	char		   *class_name		= NULL;
	tag_t		   class_id			= NULLTAG;
	char		   *ObjectClassType		= NULL;
	int   allow_chkin = 1;
	//validation on check in
	char	*Desc_obj2	= NULL;
	char   *sObjTagMatDrw=NULL;
	char   *sObjTagDrwInd=NULL;
    char   *sPartStatus	 =NULL;
    char   *sPartType1	 =NULL;
    char   *sCatName	 =NULL;
    char   *sDesignGrp	 =NULL;
    char   *ItemDesc	 =NULL;
	logical	SpareInd1	= false;
	char   *SpareCriteria1	=NULL;
    char   *RefPartNumber1	=NULL;
    char   *MThickness		=NULL;
	char   *TempVal			=NULL;
	char   *EnvelopeDim		=NULL;
	int y		= 0;
	int counter1	= 0;
	double objWeightVal ;
	char wgtstr[100];
	char SealLenstr[100];
	int left=0;
	int right=0;
	char* username;
	tag_t user_tag=NULLTAG;

	sDesignGrp = malloc(10 * sizeof (char *) );
	TempVal=(char *) MEM_alloc(1000);
//validation on check in end

	printf("\n\ndisallow_checkin_dataset_only\n");fflush(stdout);


	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));

	printf("\n\nObject Classname:%s\n",class_name);

	POM_get_user(&username,&user_tag);

   printf("\n\n111111111111111111111111111111111 \n");

	if(strcmp(class_name,"Dataset")==0)
	{
		printf("\n\n1 222222222222222222 \n");fflush(stdout);
        CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }
		if(primary_list)
		{
				printf("\n\nDataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object)
				   {
				 	 printf("\nprimary_object:%d\n",i);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)!=ITK_ok) PrintErrorStack();

					 {
						if(strcmp(is_chkout,"Y")==0)
						{


							printf("adk validations start");fflush(stdout);
							printf("\nusername before validation: %s",username);fflush(stdout);

					//validations
						if(strcmp(username,"loader")!=0)
						{
						if (AOM_ask_value_string(primary_object,"item_revision_id",&Desc_obj2)!=ITK_ok) PrintErrorStack();
							printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);
							//Vitthal start
							if( AOM_ask_value_string(primary_object,"t5_DrawingInd",&sObjTagDrwInd)!=ITK_ok) PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_Material",&sObjTagMatDrw)!=ITK_ok) PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_PartStatus",&sPartStatus)!=ITK_ok) PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_PartType",&sPartType1)!=ITK_ok) PrintErrorStack();
							if( AOM_ask_value_string(primary_object,"t5_CategoryName",&sCatName)!=ITK_ok) PrintErrorStack();
							if(	AOM_UIF_ask_value(primary_object,"t5_DesignGrp",&sDesignGrp)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"object_desc",&ItemDesc)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_logical(primary_object,"t5_SpareInd",&SpareInd1)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_SpareCriteria",&SpareCriteria1)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_RefPartNumber",&RefPartNumber1)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_MThickness",&MThickness)!=ITK_ok) PrintErrorStack();
							if(	AOM_ask_value_string(primary_object,"t5_EnvelopeDimensions",&EnvelopeDim)!=ITK_ok) PrintErrorStack();

							printf("\n Drawing Indicator :%s \n Material In Drawing :%s \n Part Status :%s \n Part Type :%s  \n Design Group ",sObjTagDrwInd,sObjTagMatDrw,sPartStatus,sPartType1,sDesignGrp);fflush(stdout);
							if(strcmp(sPartType1,"C")==0)  // Added condition on 03-11-2023 As per suggest by CREO Team
							{
								if((strcmp(sObjTagDrwInd,"A")==0) || (strcmp(sObjTagDrwInd,"D")==0) )
								{
									if((tc_strcmp(sObjTagMatDrw,"")!=0))
									{
										printf("\n	Material name is present----->> :%s",sObjTagMatDrw);fflush(stdout);
									}
									else
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"If Drawing Indicator is D/A then Material is Mandatory");
										return ITK_err;
									}
								}
							}
							if(strstr(Desc_obj2,"NR") != NULL)
							{
								if((strcmp(sPartStatus,"DR4")==0) || (strcmp(sPartStatus,"DR5")==0) ||(strcmp(sPartStatus,"AR4")==0) || (strcmp(sPartStatus,"AR5")==0) )
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"NR revision part can not be created or updated with DR-status DR4/5 or AR4/5");
									return ITK_err;

								}
							}
							if((strcmp(sPartType1,"C")==0))
							{
								if((tc_strcmp(sObjTagMatDrw,"")!=0))
								{
									printf("\n	Material while Part type comp :%s",sObjTagMatDrw);fflush(stdout);
								}
								else
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Material in drawing can not be NULL for part type Component. Please fill material in drawing");
									return ITK_err;
								}
							}

							/*** modification by Anand starts ***/

							//Material Thickness cannot be NULL for part type Component
							//Material thickness can be only Number or NA
							//DOT should not be more than one
							if((tc_strcmp(MThickness,"")==0))
							{
								printf("\n Material Thickness is NULL \n");fflush(stdout);

								if((strcmp(sPartType1,"C")==0))
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness cannot be NULL for part type Component.");
									return ITK_err;
								}

							}
							else
							{
								if(tc_strcmp(MThickness,"NA"))
								{
									TempVal =strcpy(TempVal,MThickness);

									for(y=0;y<tc_strlen(MThickness);y++)
									{
										if (TempVal[y] < 48 || TempVal[y] > 57)
										{	if (TempVal[y] == 46)
											{
												counter1++;
											}else
											{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness need to have only numbers or it can be NA.");
												return ITK_err;
											}
										}
									}

									if (counter1>0 && counter1<2 && tc_strlen(MThickness)>0 && tc_strlen(MThickness)<2)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Material Thickness need to have only numbers or it can be NA.");
										return ITK_err;
									}

									if(counter1 >1)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DOT should not be more than one for Material Thickness");
										return ITK_err;
									}

								}

							}

							//If Part Category is BTS and Spare Indicator is True, so Party Part number is mandatory
							//if((SpareInd1==1) && tc_strcmp(SpareCriteria1,"BTS")==0 )
							if( tc_strcmp(SpareCriteria1,"BTS")==0 )
							{
								printf("\n Spare Criteria is BTS\n");fflush(stdout);

								if(tc_strcmp(RefPartNumber1,"")==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err, "Part Category is: BTS-Built To Specification, so Party Part number is mandatory");
									return ITK_err;
								}
							}
							//for spare indicator ='Y' envelope dimension should not be null
							if( SpareInd1==1 )
							{
								printf("\n Spare Indicator is True\n");fflush(stdout);

								if(tc_strcmp(EnvelopeDim,"")==0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err, "Envelope Dimensions cannot be null if Spare Indicator is True");
									return ITK_err;
								}
							}

							if(tc_strstr(ItemDesc,"\n"))
							{
								printf("\n	Description of Design %s \n",ItemDesc);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"New Line charecter is not allowed in Desc field.");
								return ITK_err;
							}
							//Ashish

							//Mohan start

							if((tc_strlen(ItemDesc)>40) )
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please Fill Only 40 Character In Description As Per SAP/Denis Standards.");
								return ITK_err;

							}
							//Mohan

							//amol Kale
							if( AOM_ask_value_double(primary_object,"t5_Weight",&objWeightVal)!=ITK_ok) PrintErrorStack();
								{
								printf("\n Action On dataset objWeightVal  = %f\n", objWeightVal);fflush(stdout);
								   if (objWeightVal > 0)
									{
										sprintf(wgtstr,"%0.3f",objWeightVal);
										printf("\n Action On dataset wgtstr  = [%s]\n", wgtstr);fflush(stdout);
										sscanf(wgtstr, "%d.%d", &left, &right);
										printf("\n adk Action On dataset left = [%d] adk right = [%d]", left,right);fflush(stdout);
										if(right>0)
										{
											while (right%10==0)
											{
												right=right/10;
											}
										}
										printf("\n adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
										if(left > 99999 || right > 999)
										{
											printf("\nAction On dataset validation to weight\n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Weight Value should have a maximum of 5 Digits before the Decimal Point and maximum of 3 digits after the Decimal Point.");
											printf("\n Action On dataset after validation to weight\n");fflush(stdout);
										   return ITK_err;


										}
									}

								}
						}
							printf("\n\n 3333333333333333333333333  \n");fflush(stdout);
							//Amol Kale
								//validations end
							allow_chkin = 0;

						}
					 }
					 printf("\n\nallow_chkin1 7777 :%d\n",allow_chkin);
				  }
				}
		}
		else
		{
			allow_chkin=0;
		}
		printf("\n\nallow_chkin2 8888 :%d\n",allow_chkin);

	    if(allow_chkin==0)
	    {
			  if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
			printf("\n\n ObjectClassType in in disallow_checkin_dataset rbb:%s\n",ObjectClassType);
			
			if((strcmp(ObjectClassType,"ProAsm")!=0) || (strcmp(ObjectClassType,"ProPrt")!=0) || (strcmp(ObjectClassType,"ProDrw")!=0) )
			{
				printf("\n\n Inside the updated -Individual checkin not allowed condition:%s\n",ObjectClassType);
				if( (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
				{
				   printf("\n\n Giving error for Individual checkin not allowed :%s\n",ObjectClassType);
				   EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkin of dataset is not allowed.");
				   return ITK_err;
				}
			}
			printf("\n\n Outside the Individual checkin condition as class type :%s\n",ObjectClassType);
	    }

   }
    printf("\n\nallow_chkin:%d\n",allow_chkin);
	return ifail;
}

// 0 !=0  ->false
//-1 !=0 ->false
extern DLLAPI int disallow_checkout_dataset_only(METHOD_message_t *m,va_list args)
{
	int   ifail		= 0;
	int		       org_ver_id_int=0;
	int		       is_prev_seq=0;
	char		       *org_ver_id_int_prev=NULL;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   relation_type_prev	= NULLTAG;
	tag_t		   relation_depp	= NULLTAG;
	tag_t		   relation	= NULLTAG;
	tag_t		   relation_dep	= NULLTAG;
	tag_t		   relation_dep22	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t		   Dfq_primary_object	= NULLTAG;
	tag_t		   primary_object_prev	= NULLTAG;
	tag_t		   primary_object11	= NULLTAG;
	tag_t          relation_type22;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	GRM_relation_t *primary_list	= NULLTAG;
	GRM_relation_t *Dfq_primary_list	= NULLTAG;
	GRM_relation_t *primary_list_prev	= NULLTAG;
	//tag_t *primary_list_Dep	= NULLTAG;
	GRM_relation_t *primary_list_Dep;
	//tag_t *primary_list_Depp	= NULLTAG;
	GRM_relation_t *primary_list_Depp;
	int count = 0,i=0 ,countDep=0,countDepp=0,ik=0,prev_ver_id=0,cmt=0,count_prev=0,Dfqcount=0,df=0;
	char *is_chkout=NULL;
	char *Dfqis_chkout=NULL;
	char *ReleaseStatus=NULL;
	char		   *class_name		= NULL;
	//char		   *Drtype_name		= NULL;
	tag_t		    class_id		= NULLTAG;
	int				allow_chkout		= 1;
	int				status_count		= 0;
	int				status,ii,ref_count		= 0;
	tag_t* status_list = NULLTAG;
	tag_t	master	=	NULLTAG;
	//tag_t	DrObj	=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t	sequence_id_c	=	NULLTAG;
	tag_t	sequence_id_c1	=	NULLTAG;
	tag_t	DrobjTypeTag	=	NULLTAG;
	tag_t	datasettype =  NULLTAG;
	char			*Desc_obj	 = NULL;
	char			*Desc_obj1	 = NULL;
	char			*ITemRevSeq	 = NULL;
	char			*ITemRevSeq1 = NULL;
	char			*Id_string_val = NULL;
	char			*Id_Pro_val = NULL;
	char			*org_object_name = NULL;
	char			**ref_list = NULL;
	char			Drtype_name[TCTYPE_name_size_c+1];
	char   *Item_string=NULL;
	char *p;
	tag_t 	prevDataset= NULLTAG;
	//tag_t 	*ref_list= NULLTAG;

	//LH/RH Attribute declare
	const char		*reason										= va_arg (args, const char*);
	const char		*change_id									= va_arg (args, const char*);
	const char		*dir_name									= va_arg (args, const char*);
	int				reservation_type							= va_arg (args, int);

	char * ItemLhRhInd;
	char * ObjectClassType = NULL;
	char * Dfq_ObjectClassType = NULL;
	int HasSymPrt=0;
	static int	 LHFlg	= -1;
	char *SesUsr = NULL;

	printf("\n\n In checkout_dataset_only New JProAsm \n");fflush(stdout);

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n\nObject Classname JProAsm:%s\n",class_name);

	POM_get_user_id (&SesUsr);
	printf("\n DRCHK: Session user: %s\n",SesUsr); fflush(stdout);

	if(strcmp(class_name,"Design_0_Revision_alt")==0 || (strcmp(class_name,"T5_EE_PartRevision")==0))
	{
		tag_t	relation_Soln=NULLTAG;
		int    TskCnt=0;
		tag_t *TskSO=NULLTAG;
		char*	 taskTempLT= NULL;

		if(tc_strcmp(SesUsr,"infodba") !=0 && tc_strcmp(SesUsr,"loader") !=0)
		{
			CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_Soln));
			if(relation_Soln)
			{
				CALLAPI( GRM_list_primary_objects_only(object_tag,relation_Soln,&TskCnt,&TskSO));
				printf("\n Task Count :-------------------->>>>  %d\n",TskCnt);fflush(stdout);
				if (TskCnt > 0)
				{
					printf("\n Inside validation Task not in add solutrion items \n",taskTempLT);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Design Revison is attached to ERC task. \nCheckout of Design Revison is not allowed.");
					return ITK_err;

					/*
					CALLAPI(AOM_UIF_ask_value(TskSO[0],"fnd0ActuatedInteractiveTsks",&taskTempLT));
					printf("\n primary taskTempLT is : <%s>\n",taskTempLT);fflush(stdout);

					if(tc_strcmp(taskTempLT,"") !=0)
					{
						printf("\n inside primary taskTempLT is : <%s>\n",taskTempLT);fflush(stdout);
						if(tc_strcmp(taskTempLT,"Add solution items") !=0)
						{
							printf("\n Inside validation Task not in add solutrion items \n",taskTempLT);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Design Revison is attached to ERC task.\n ERC task is currently not for 'Add solution Items' assignment.\n Checkout of Design Revison is not allowed.");
							return ITK_err;
						}
					}*/


				}
			}
	    }


		     // Added to handle relation b/w ProAsm and Des Rev
		CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));

		 if(relation_dep)
		{
			 CALLAPI(GRM_list_primary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

			 printf("\n\n JproAsm ProAsm Rel with Des Rev are --->:%d\n",countDep);
		}

		  CALLAPI(AOM_ask_value_int(object_tag,"revision_number",&org_ver_id_int));
		printf("\n Version no org_ver_id_int is -->%d\n",org_ver_id_int); fflush(stdout);
		if (countDep <= 0)
		{

		}
		// Ended to handle relation b/w ProAsm and Des Rev

		/******************************************************************************************
								LH/RH Checked-Out start
		******************************************************************************************/
		printf("\n LHFlg : %d",LHFlg);
		HasSymPrt=0;
		tag_t  	master =	NULLTAG;
		tag_t  *master2 = NULLTAG;
		tag_t relation_type;
		
		tag_t relation_type2;

		int result,n_attch = 0;
		tag_t objTypeTag = NULLTAG;
		//char type_name1[TCTYPE_name_size_c+1];
		char *type_name1	=	NULL;
		logical	checkout2;
		tag_t	latestrev	=	NULLTAG;
		tag_t RevNewSeqTag = NULLTAG;

		CALLAPI(AOM_ask_value_string(object_tag,"t5_LeftRh_Comp",&ItemLhRhInd));
		printf("\n LH/RH Indicator of selected Part :: %s",ItemLhRhInd);fflush(stdout);

			if(ItemLhRhInd==NULL || tc_strcmp(ItemLhRhInd,"NA")==0)
			{
				printf("\n inside NULL/NA of LH/RH Indicator values");fflush(stdout);
				HasSymPrt=0;
			}else
			{
				if(tc_strcmp(ItemLhRhInd,"LH CATIA")==0 || tc_strcmp(ItemLhRhInd,"LH PROE")==0)
			    {
					printf("\n inside LH CATIA OR PROE");fflush(stdout);
					HasSymPrt=1;

					CALLAPI(ITEM_ask_item_of_rev(object_tag, &master));
					printf("\n ITEM_Found......");fflush(stdout);

					result = GRM_find_relation_type("T5_LRReln", &relation_type);
					printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

					if (relation_type)
					{
							CALLAPI(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
							printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

							if(n_attch>0)
							{
								CALLAPI(ITEM_ask_latest_rev(master2[0],&latestrev));
								if (latestrev)
								{
									  printf("\n master2 latest revision found\n");fflush(stdout);
									  if (TCTYPE_ask_object_type(latestrev,&objTypeTag)!=ITK_ok) PrintErrorStack();
									  if (TCTYPE_ask_name2(objTypeTag,&type_name1)!=ITK_ok) PrintErrorStack();
									  printf("\n type_name1 ==> %s\n", type_name1);fflush(stdout);

									  if(tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"ItemRevision")==0 )
									  {
											CALLAPI(RES_is_checked_out(latestrev,&checkout2));
											printf("\n Checked-out Status of selected Object : [%d]\n",checkout2);fflush(stdout);

											if (!checkout2)
											{
												printf("\n LHFlg : %d",LHFlg);
												LHFlg = 1;
												printf("\n LHFlg : %d",LHFlg);

												CALLAPI(ITEM_copy_rev(latestrev,NULL,&RevNewSeqTag));
												CALLAPI(AOM_refresh(latestrev,0));
												printf("\n RH Part get Checked-out.............");fflush(stdout);
											}else
											{
												printf("\n selected LH Part is already checked-out.......\n");fflush(stdout);
											}
									  }else
									  {
											printf("\n Class of LH Part is not matched.......\n");fflush(stdout);
									  }
								}
							}else
							{
								printf("\n LH/RH Part Master relation is not available\n");fflush(stdout);
							}
					}
				}else if(tc_strcmp(ItemLhRhInd,"RH CATIA")==0 || tc_strcmp(ItemLhRhInd,"RH PROE")==0)
				{
					printf("\n RHFlg : %d",LHFlg);
					printf("\n calling RH CATIA/PROE....");fflush(stdout);
					CALLAPI(ITEM_ask_item_of_rev(object_tag, &master));
					printf("\n ITEM_Found......");fflush(stdout);

					result = GRM_find_relation_type("T5_LRReln", &relation_type2);
					printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

					if (relation_type2)
                    {
						CALLAPI(GRM_list_secondary_objects_only(master,relation_type2,&n_attch,&master2));
						printf("\n master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

						if(n_attch>0)
						{
							if(LHFlg<1)
							{
								printf("\n inside EMH_store_error_s2...........");fflush(stdout);
								//EMH_store_error_s2(EMH_severity_error,ITK_err,"In-Valid to Checked-Out RH Part","Pls select LH Part and Checked-Out");
								//return ITK_err;
							}else
							{
								printf("\n RH Part is checked-out........");fflush(stdout);
							}
						}
				  }
				}
			}

	}

	printf("\n\n b4 dataset.........\n");fflush(stdout);

    if(strcmp(class_name,"T5_DFQ_Document")==0)
    {
		char* username = NULL;
		char* DVADocumentproj = NULL;
		char* Userinfo1dup = NULL;
		char* Userinfo2dup = NULL;
		tag_t user_tag=NULLTAG;
		tag_t Progqry_tg=NULLTAG;
		tag_t* Prog_object=NULLTAG;
		tag_t	Dfq_relation_type;                           
		int		Dfq_allow_chkout	= 0;
		int		Dfq_allow_chkoutbypass	= 0;
		int		Progobj_count	= 0;


		if(QRY_find2("Control Objects...", &Progqry_tg));
		printf("\n Inside DVA check-in check-out logic\n");fflush(stdout);

		char *Progsc_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **Progsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		Progsc_RelVal[0] = "DVA_ICheck";
		Progsc_RelVal[1] = "ON";

		ITK_CALL(QRY_execute(Progqry_tg, 2, Progsc_entry1, Progsc_RelVal, &Progobj_count, &Prog_object));
		printf("\n\n DVA_Document control object count :%d \n",Progobj_count);fflush(stdout);

		if(Progobj_count>0)
		{

		CALLAPI(POM_get_user(&username,&user_tag));
		printf("\n\n username :%s\n",username);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(Prog_object[0],"t5_Userinfo1",&Userinfo1dup));
	    printf("\n DVA Userinfo1dup Individual :[%s]\n",Userinfo1dup); fflush(stdout);
		ITK_CALL(AOM_ask_value_string(Prog_object[0],"t5_Userinfo2",&Userinfo2dup));
	    printf("\n DVA Userinfo2dup Individual :[%s]\n",Userinfo2dup); fflush(stdout);

		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0 || strcmp(username,"Ajay Mali")==0 ||  strcmp(username,"amm08983")==0 || strcmp(username,"ab923373.ttl")==0 ||  strcmp(username,"Anvesh Bujule")==0 || strcmp(username,"mukteshg.ttl")==0 ||  strcmp(username,"Muktesh Girdhani")==0 || strcmp(username,"pramodk1.ttl")==0 ||  strcmp(username,"Pramod Koshti")==0 )
		{
			 printf("\n\n\t\t bypass for loader & infodba ==> %s\n", username);fflush(stdout);
		}
		else
		{
						///////////////////////// DFQ individual checkout validation /////////////////////////////

			CALLAPI(GRM_find_relation_type("T5_DesignHasDVA",&Dfq_relation_type));
			if(Dfq_relation_type)
			{
				 CALLAPI(GRM_list_primary_objects(object_tag,Dfq_relation_type,&Dfqcount,&Dfq_primary_list));
				 printf("\n\n DVA Dataset Attached to Primary Object2222:%d\n",Dfqcount);

			}
			else
			{
			  printf("\n T5_DesignHasDVA relation not found  \n");
			
			}

			if (AOM_ask_value_string(object_tag,"object_type",&Dfq_ObjectClassType)!=ITK_ok) PrintErrorStack();
			printf("\n\n disallow_checkout_dataset_only :: Dfq_ObjectClassType in checkout :%s\n",Dfq_ObjectClassType);


			if (AOM_ask_value_string(object_tag,"t5_DFQ_Project_Code",&DVADocumentproj)!=ITK_ok) PrintErrorStack();
			printf("\n  disallow_checkout_dataset_only DVADocumentproj :%s\n",DVADocumentproj);

			if(Dfq_primary_list)
			{
					printf("\n\n Dfq Dataset Attached to Primary Object:%d\n",Dfqcount);

					for(df=0;df<Dfqcount;df++)
					{
					   Dfq_primary_object = Dfq_primary_list[df].primary;
					   if(Dfq_primary_object)
					   {
						 printf("\n Dfq_primary_object:%d \n",df);



						 if( AOM_ask_value_string(Dfq_primary_object,"checked_out",&Dfqis_chkout)!=ITK_ok) PrintErrorStack();
						 {
							if(strcmp(Dfqis_chkout,"Y")!=0)
							{
								printf("\n  Inside the Dfqis_chkout\n");
								Dfq_allow_chkout = 1;

							}
						 }
						 printf("\n Dfq_allow_chkout1:%d \n",Dfq_allow_chkout);
					  }
					}
			}
			else
			{
				if(tc_strcmp(Userinfo2dup,"ON")==0)
				{

					printf("\n  Inside the second condition of code\n");

					//If Added to bypass newly created DFQ Dataset, but this will bypass DFQ Dataset checkout for those not having Design Revision
					if(strcmp(Dfq_ObjectClassType,"T5_DFQ_Document")==0)
					{
						Dfq_allow_chkoutbypass = 1;
					}
					else
					{
						Dfq_allow_chkoutbypass = 0;
					}
				}
			}
			printf("\nDfq_allow_chkout2:%d\n",Dfq_allow_chkout);
			printf("\n Dfq_allow_chkoutbypass %d\n",Dfq_allow_chkoutbypass);

			if(Dfq_allow_chkout==1)
			{
				if(strcmp(Dfq_ObjectClassType,"T5_DFQ_Document")==0)
				{

					printf("\n  Inside the second 88888condition of code\n");

					if(tc_strstr(Userinfo1dup,DVADocumentproj)==NULL)  
					{


					EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkout for DVA document is not allowed.");
					return ITK_err;
					}
				}
			}
			else if(Dfq_allow_chkoutbypass==1)
			{
				printf("\n  Inside the second 444condition of code\n");

				if(strcmp(Dfq_ObjectClassType,"T5_DFQ_Document")==0)
				{
                printf("\n  Inside the second 222condition of code\n");
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkout for DVA document is not allowed.");
				return ITK_err;
				}
			
			
			}


			///////////////////////// DFQ individual checkout validation end /////////////////////////////
		}

		}

    }

	if(strcmp(class_name,"Dataset")==0)
	{

		tag_t	ref_relation=NULLTAG;
		tag_t	refobjTypeTag=NULLTAG;
		tag_t	primary_object_ref=NULLTAG;
		int    refcount=0;
		int    ri=0;
		int    ref_Result=0;
		tag_t *primary_ref_list=NULLTAG;
		//char  reftype_name[TCTYPE_name_size_c+1];
		char   *dmlstatus=NULL;
		char   *reftype_name=NULL;
													
		char* username = NULL;
	    tag_t user_tag=NULLTAG;

	   //Get Session User
 	   CALLAPI(POM_get_user(&username,&user_tag));
       printf("\n\n username :%s\n",username);fflush(stdout);
		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0)
		{
			 printf("\n\n\t\t bypass for loader & infodba ==> %s\n", username);fflush(stdout);
		}
       else
		{
			CALLAPI(GRM_find_relation_type("IMAN_reference",&ref_relation));
			//CALLAPI(GRM_find_relation_type("CMReferences",&ref_relation));
			if(ref_relation)
			{
				 CALLAPI(GRM_list_primary_objects_only(object_tag,ref_relation,&refcount,&primary_ref_list));
			}
            printf("\n\n refcount--->:%d\n",refcount);fflush(stdout);
			if(refcount>0)
			{
					printf("\n\nDataset Attached to Primary Object:%d\n",refcount);

					for(ri=0;ri<refcount;ri++)
					{
						 CALLAPI(TCTYPE_ask_object_type (primary_ref_list[ri], & refobjTypeTag));
						 CALLAPI(TCTYPE_ask_name2( refobjTypeTag, &reftype_name));
						 printf("\n\n\t\t reftype_name ==> %s\n", reftype_name);fflush(stdout);

						 if(tc_strcmp(reftype_name,"ChangeRequestRevision")==0)
							{
								CALLAPI(AOM_UIF_ask_value(primary_ref_list[ri],"release_status_list",&dmlstatus));
								printf("\n\n\t\t dmlstatus ==> %s\n", dmlstatus);fflush(stdout);

								if(strcmp(dmlstatus,"ERC Released")==0)
									 {
									    printf("\n\n\t\t DML is in ERC Released State You cannot  modify referece dataset. ==> %s\n", dmlstatus);fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"DML is in Released State You cannot modify referece dataset.");
						                return ITK_err;
									 }

							}
					}


			  }

		}


		printf("\n\n In dataset loop only \n");fflush(stdout);
		if( AE_ask_dataset_prev_rev	(object_tag,&prevDataset) != ITK_ok) PrintErrorStack();

		//CALLAPI(AE_find_datasettype("ProAsm", &datasettype));
		if(prevDataset)
		{

		//CALLAPI(AOM_UIF_ask_values(prevDataset, "ref_list",&ref_count, &ref_list));
//		//CALLAPI(AE_ask_dataset_named_refs(prevDataset, &ref_count, &ref_list));
		//printf("\n\t Got reference list--->%d",ref_count); fflush(stdout);
//	   //
		// for (i = 0; i < ref_count; i++)
       //    {
       //        printf ("\n named reference %d is <%s>./n", i + 1, ref_list[i]);
       //    }
       //    MEM_free (ref_list);

		 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_depp));
		  if(relation_depp)
			{
				 CALLAPI(GRM_list_secondary_objects(prevDataset,relation_depp,&countDepp,&primary_list_Depp));

				 printf("\n\n countDepp--->:%d\n",countDepp);fflush(stdout);
			}

			//CALLAPI(AOM_ask_value_string(prevDataset,"ref_list",&org_ver_id_int_prev));
			//printf("\n Latest Version no of Prev Dataset isss-->%s\n",org_ver_id_int_prev); fflush(stdout);

			CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type_prev));
			if(relation_type_prev)
			{
				 CALLAPI(GRM_list_primary_objects(prevDataset,relation_type_prev,&count_prev,&primary_list_prev));
			}

			printf("\n\n Prev Dataset Attached to Primary Object:%d\n",count_prev);

			if(primary_list_prev)
			{


					for(i=0;i<count_prev;i++)
					{
					   primary_object_prev = primary_list_prev[i].primary;
					   if(primary_object_prev)
					   {
						 printf("\n going for previous offic rev :%d\n",i);

						 if( AOM_ask_value_int(primary_object_prev,"sequence_id",&is_prev_seq)!=ITK_ok) PrintErrorStack();

						 printf("\n\n prev Dsn Rev Seq:%d\n",is_prev_seq);
					  }
					}
			}

		}

		CALLAPI(AOM_ask_value_int(object_tag,"revision_number",&org_ver_id_int));
		printf("\n Version no for Dataset isss-->%d\n",org_ver_id_int); fflush(stdout);






		 prev_ver_id=org_ver_id_int-1;

		 printf("\n Version no for Dataset isss-->%d\n",prev_ver_id); fflush(stdout);

		 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
		  if(relation_dep)
		{
			 CALLAPI(GRM_list_secondary_objects(object_tag,relation_dep,&countDep,&primary_list_Dep));

			 printf("\n\n JproAsmSecc ProAsm Rel with Des Rev are org_object_name--->:%d\n",countDep);fflush(stdout);
		}
		if (countDep >0)
		{
			for (cmt=0;cmt<countDep ;cmt++ )
			{
//				  DrObj = primary_list_Dep[cmt];
//				CALLAPI (TCTYPE_ask_object_type(DrObj,&DrobjTypeTag));
//				 printf("\n 00Drtype_namess-->%s\n",Drtype_name); fflush(stdout);
//				CALLAPI (TCTYPE_ask_name2(DrobjTypeTag,Drtype_name));
//				 printf("\n Drtype_namess-->%s\n",Drtype_name); fflush(stdout);
//
//				 CALLAPI(AOM_ask_value_string(DrObj,"object_name",&org_object_name));
//				printf("\n org_object_nameee-->%s\n",org_object_name); fflush(stdout);

			}

		}


		CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }


		if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
		printf("\n\n disallow_checkout_dataset_only :: ObjectClassType in checkout :%s\n",ObjectClassType);

		if(primary_list)
		{
				printf("\n\n JproAsm Dataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object)
				   {
				 	 printf("\n JproAsm primary_object:%d\n",i);



					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)!=ITK_ok) PrintErrorStack();
					 {
						if(strcmp(is_chkout,"Y")!=0)
						{
							allow_chkout = 0;

						}
					 }
					 printf("\n\nallow_chkout1:%d\n",allow_chkout);
				  }
				}
		}
		else
		{
			//If Added to bypass newly created Pro/E Dataset, but this will bypass Pro/E Dataset checkout for those not having Design Revision
			if((strcmp(ObjectClassType,"ProAsm")==0) || (strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
			{
				allow_chkout = 1;
			}
			else
			{
				allow_chkout = 0;
			}
		}
		printf("\n\nallow_chkout2:%d\n",allow_chkout);

	    if(allow_chkout==0)
	    {
			if((strcmp(ObjectClassType,"ProAsm")==0) || (strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2AuxPart")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual checkout of dataset is not allowed");
				return ITK_err;
			}
		}
   }


   	if(!strcmp(class_name,"Design_0_Revision_alt"))
	{

		if (AOM_ask_value_string(object_tag,"current_revision_id",&Desc_obj1)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_int(object_tag,"sequence_id",&sequence_id_c1)!=ITK_ok) PrintErrorStack();
		ITemRevSeq1 = (char *) MEM_alloc( 5 * sizeof(char) );
		sprintf(ITemRevSeq1,"%d",sequence_id_c1);

		if ( strcmp(Desc_obj1,"NR")==0 && strcmp(ITemRevSeq1,"1")==0)
		{
			printf("\nPart is NR,1\n");fflush(stdout);
		}




//	else
//	{
//
//		printf("\nDesin is not NR,1\n");fflush(stdout);
//		status=WSOM_ask_release_status_list(object_tag,&status_count,&status_list);
//	    if(status==ITK_ok)
//		 {
//			printf("\n number of statuses: %d \n",  status_count);
//			for (ii = 0; ii < status_count; ii++)
//			{
//				AOM_ask_name(status_list[ii], &ReleaseStatus);
//				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
//			}
//		 }
//
//		 if((strcmp(ReleaseStatus,"T5ErcPublished")==0) )
//			{
//				status=EMH_store_error_s1(EMH_severity_error,ITK_err, "BaseLine Object Cannot Be Checked-out, Please Check-out The Actual Object");
//				return ITK_err;
//			}
//
//			if(ITEM_ask_item_of_rev  ( object_tag,&master) );
//			if(ITEM_ask_latest_rev(master,&latestrev));
//
//			if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj)!=ITK_ok) PrintErrorStack();
//			if(AOM_ask_value_int(latestrev,"sequence_id",&sequence_id_c)) PrintErrorStack();
//			ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
//			sprintf(ITemRevSeq,"%d",sequence_id_c);
////
////			if (AOM_ask_value_string(object_tag,"current_revision_id",&Desc_obj1)!=ITK_ok) PrintErrorStack();
////			if(AOM_ask_value_int(object_tag,"sequence_id",&sequence_id_c1)!=ITK_ok) PrintErrorStack();
////			ITemRevSeq1 = (char *) MEM_alloc( 5 * sizeof(char) );
////			sprintf(ITemRevSeq1,"%d",sequence_id_c1);
//
//			printf("\n Value of Desc_obj :%s and Desc_obj1 : %s\n",Desc_obj,Desc_obj1);fflush(stdout);
//			printf("\n Value of ITemRevSeq :%s and ITemRevSeq1 : %s\n",ITemRevSeq,ITemRevSeq1);fflush(stdout);
//
//				p=strstr(Desc_obj,Desc_obj1);
//				if(p)
//				{
//					printf("\n Revision Matches\n");fflush(stdout);
//					if (strcmp(Desc_obj,".")==0)
//					{
//						printf("\n Desc_obj has . in it\n");fflush(stdout);
//						if ((strcmp(ITemRevSeq,ITemRevSeq1) !=0) )
//						{
//							printf("\n Part Sequence is not latest ,Checkout Failed. \n");fflush(stdout);
//							status=EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Latest Revision is allowed to Checkout,Checkout Failed.");
//							return ITK_err;
//						}
//					}
//				}
//				else
//				{
//					printf("\n Part is not latest ,Checkout Failed. \n");fflush(stdout);
//					status=EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Latest Revision is allowed to Checkout,Checkout Failed.");
//					return ITK_err;
//				}
//
//	}


	}
	
	if(strcmp(class_name,"T5_ERCIndRevision")==0)
	{
		char *sessionusername = NULL;
		//tag_t user_tag=NULLTAG;
	   //Get Session User
 	   //CALLAPI(POM_get_user(&sessionusername,&user_tag));
	   POM_get_user_id (&sessionusername);
       printf("\n\n sessionusername :%s\n",sessionusername);fflush(stdout);
	   
		char *IndWFStatus = NULL;
		char *IndentNo = NULL;
		CALLAPI(AOM_UIF_ask_value(object_tag, "item_id", &IndentNo));
		printf("\n Indent No item_id == [%s]\n", IndentNo);fflush(stdout);
		
		CALLAPI(AOM_UIF_ask_value(object_tag, "fnd0StartedWorkflowTasks", &IndWFStatus));
		printf("\n fnd0StartedWorkflowTasks == [%s]\n", IndWFStatus);fflush(stdout);
		
		char		*IndRelStatus		= NULL;
		CALLAPI(AOM_UIF_ask_value(object_tag,"release_status_list",&IndRelStatus));
		printf("\n Indent No IndRelStatus == [%s]\n", IndRelStatus);fflush(stdout);
		
		printf("\n sessionusername == [%s]\n", sessionusername);fflush(stdout);
		if(strcmp(sessionusername,"loader")==0 || strcmp(sessionusername,"infodba")==0 || strcmp(sessionusername,"ercjsup")==0)
		{
			printf("\nBypass Provided as Login is %s\n", sessionusername);fflush(stdout);
		}
		else
		{
			
			printf("\n cant edit its properties %s\n", sessionusername);fflush(stdout);
			
			tag_t   qryTagWF     = NULLTAG;
			tag_t   *IndCntrlObjTagWF      = NULLTAG;
			char   *qry_entryWF[1]  = {"SYSCD"};
			char   **qry_values2WF     =  (char **) MEM_alloc(10 * sizeof(char *));
			if(QRY_find2("ControlObjects", &qryTagWF));

			int n_entryWF    = 1;
			int  rsltCountWF      =  0;

			if (qryTagWF)
			{
				printf("\n IndWFStep:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n IndWFStep:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2WF[0] = "IndWFStep";

			if(QRY_execute(qryTagWF, n_entryWF, qry_entryWF, qry_values2WF, &rsltCountWF, &IndCntrlObjTagWF));
			printf(" \n IndWFStep:rsltCountWF 44:%d:", rsltCountWF); fflush(stdout);
			
			printf("\n IndWFStatusDup is:: %s Indetnt IndRelStatus[%s]",IndWFStatus,IndRelStatus);fflush(stdout);
			
			if((tc_strstr(IndRelStatus,"ERC Released")!=NULL) ||(tc_strstr(IndRelStatus,"T5_LcsErcRlzd")!=NULL))
			{
				printf("\n Not allow edit its properties user is: [%s] and work flow status is: [%s] and Release  status is: [%s]\n", sessionusername,IndWFStatus,IndRelStatus);fflush(stdout);
				allow_chkout=0;
				EMH_store_error_s2(EMH_severity_error,ITK_err,"Indent is Released.You can not edit Indent Properties.", IndentNo);
				return ITK_err;
			}
			//if((tc_strstr(IndWFStatus,"Chief Eng Review")!=NULL)||(tc_strstr(IndWFStatus,"Proto Ind Review")!=NULL) ||(tc_strstr(IndWFStatus,"New Proto Ind Review 1")!=NULL))
			else if((tc_strstr(IndWFStatus,"Proto Manager Review")!=NULL) ||(tc_strstr(IndWFStatus,"Proto Engineer Review")!=NULL))
			{
				
				printf("\n 11Not allow edit its properties user is: [%s] and work flow status is: [%s]\n", sessionusername,IndWFStatus);fflush(stdout);
				allow_chkout=0;
				EMH_store_error_s2(EMH_severity_error,ITK_err,"At this Step, you can not edit Indent Properties.", IndentNo);
				return ITK_err;
			}
			else if(rsltCountWF > 0)
			{
				char		*IndWFStepinfo1		= NULL;
				char		*IndWFStepinfo2		= NULL;
				
				CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo1",&IndWFStepinfo1));
				printf("\n IndWFStepinfo1 is : [%s]\n", IndWFStepinfo1);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo2",&IndWFStepinfo2));
				printf("\n IndWFStepinfo2 is : [%s]\n", IndWFStepinfo2);fflush(stdout);
			
				if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo1,"")!=0)
				{
					if((tc_strstr(IndWFStatus,IndWFStepinfo1)!=NULL))
					{
						printf("\n 11Not allow edit its properties user is: [%s] and work flow status is: [%s]\n", sessionusername,IndWFStatus);fflush(stdout);
						allow_chkout=0;
						EMH_store_error_s2(EMH_severity_error,ITK_err,"At this Step, you can not edit Indent Properties.", IndentNo);
						return ITK_err;
					}
				}
				else if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo2,"")!=0)
				{
					if((tc_strstr(IndWFStatus,IndWFStepinfo2)!=NULL))
					{
						printf("\n 11Not allow edit its properties user is: [%s] and work flow status is: [%s]\n", sessionusername,IndWFStatus);fflush(stdout);
						allow_chkout=0;
						EMH_store_error_s2(EMH_severity_error,ITK_err,"At this Step, you can not edit Indent Properties.", IndentNo);
						return ITK_err;
					}
				}
				else
				{
					printf("\n 11work flow status is: [%s] IndWFStepinfo1 is: [%s] IndWFStepinfo2 is: [%s]\n",IndWFStatus,IndWFStepinfo1,IndWFStepinfo2);fflush(stdout);
				}
			}
			else
			{
				printf("\n else user is: [%s] and work flow status is: [%s] and Release  status is: [%s]\n", sessionusername,IndWFStatus,IndRelStatus);fflush(stdout);
			}
		}
	}


    printf("\n\nallow_chkout:%d\n",allow_chkout);
	LHFlg=-1;
	return ifail;
}

extern DLLAPI int disallow_cancalcheckout_dataset_only(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	tag_t		   relation_type	= NULLTAG;
	tag_t		   primary_object	= NULLTAG;
	tag_t	 	   object_tag		= va_arg (args, tag_t);
	GRM_relation_t *primary_list	= NULLTAG;
	int count = 0,i=0;
	char			*is_chkout		=NULL;
	char		   *class_name		= NULL;
	tag_t		    class_id		= NULLTAG;
	char		   *ObjectClassType		= NULL;
	int				allow_chkin		= 1;
		tag_t		   item_tag_rev	= NULLTAG;
	tag_t		   relation_New	= NULLTAG;
	tag_t * 	relation_test  = NULLTAG;
	tag_t queryTag = NULLTAG;
	int n_entries = 3;
	int resultCount=0,countDep=0,ik=0;
	tag_t *rev=NULLTAG;
	tag_t			relation_dep									= NULLTAG;
	tag_t			relation_dep22								= NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	char   *Id_Pro_val=NULL;

	char   *org_rev_id=NULL;
	tag_t		   primary_object11	= NULLTAG;
	char   *org_Item_id=NULL;
	char   *NewSeq=NULL;
	char   *CharVer=NULL;
	char   *Id_Obj_val=NULL;
	 int Id_string_val=0;
	char   *ProAsmDetails=NULL;
	int org_seq_id_int=0,main_seq=0,jk=0;
	tag_t		   primary_object2	= NULLTAG;
	GRM_relation_t *primary_list_Dep11	= NULLTAG;
	NewSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	CharVer = (char *) MEM_alloc( 20 * sizeof(char) );
	ProAsmDetails = (char *) MEM_alloc( 20 * sizeof(char) );


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_entries4[3] = {"Revision","Sequence Id","ID"},
		 *qry_values4[3]	= {"*","*","*"};

	printf("\n\nIn disallow_cancalcheckout_dataset_only\n");

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));

	printf("\n\nObject Classname:Jproasm del comment is :%s\n",class_name);

	 // Started for Pro members

//	 if(strcmp(class_name,"Design Revision")==0 || strcmp(class_name,"Design_0_Revision_alt")==0)
//	{
//
//
//	  CALLAPI(AOM_ask_value_int(object_tag,"sequence_id",&org_seq_id_int));
//	  printf("\n Dis Ckd Out seq is -->%d\n",org_seq_id_int); fflush(stdout);
//
//	  CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&org_rev_id));
//	  printf("\n Dis Ckd Out Rev is -->%s\n",org_rev_id); fflush(stdout);
//
//	  CALLAPI(AOM_ask_value_string(object_tag,"item_id",&org_Item_id));
//	  printf("\n Dis Ckd Out Rev is -->%s\n",org_Item_id); fflush(stdout);
//
//	  main_seq=org_seq_id_int-1;
//
//	  sprintf(NewSeq,"%d",main_seq);
//
//	  printf("\n Dis main_seq char value is  -->%s\n",NewSeq); fflush(stdout);
//
//	  if(QRY_find2("DesignRevision Sequence", &queryTag));
//
//		if (queryTag)
//		{
//			printf(" Dis Uni Found Query\n"); fflush(stdout);
//		}
//		else
//		{
//			printf("Uni Not Found Query\n"); fflush(stdout);
//		}
//
//		qry_values[0] = org_rev_id ;
//		qry_values[1] = NewSeq;
//		qry_values[2] = org_Item_id;
//		if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));
//
//		printf(" Dis Obj queried with builder are --->%d\n",resultCount); fflush(stdout);
//
//		if(resultCount>0)
//		{
//			printf("\n Dis Des Rev already exists\n"); fflush(stdout);
//
//			for (jk=0;jk<resultCount;jk++ )
//			{
//				item_tag_rev = rev[jk];
//
//				 CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep));
//
//
//					 CALLAPI(GRM_list_primary_objects(item_tag_rev,relation_dep,&countDep,&primary_list_Dep));
//
//					 printf("\n\n Dis ProAsm Rel with Des Rev are --->:%d\n",countDep);fflush(stdout);
//
//						if(countDep >0)
//						{
//
//							for(ik=0;ik<countDep;ik++)
//							{
//							   primary_object11 = primary_list_Dep[ik].primary;
//							   if(primary_object11)
//							   {
//								 printf("\n Dis I value in loop is--->:%d\n",ik);fflush(stdout);
////								 CALLAPI(AOM_ask_value_string(primary_object11,"object_name",&Id_string_val));
////								 printf("\n Dis Proasm where Item Rev is used --->%s\n",Id_string_val);
//
//								 CALLAPI(AOM_ask_value_int(primary_object11,"revision_number",&Id_string_val));
//								 printf("\n Dis Proasm Rev number --->%d\n",Id_string_val);
//
//								 CALLAPI(AOM_ask_value_string(primary_object11,"object_string",&Id_Obj_val));
//								 printf("\n Dis Proasm Object String --->%s\n",Id_Obj_val);fflush(stdout);
//
//								 sprintf(CharVer,"%d",Id_string_val);
//
//								  printf("\n DCharVer value is --->%s\n",CharVer);fflush(stdout);
//
//								  ProAsmDetails = strcat(Id_Obj_val,";");
//								  ProAsmDetails = strcat(ProAsmDetails,CharVer);
//
//								   printf("\n Dis ProAsmDetails --->%s\n",ProAsmDetails);fflush(stdout);
//
//								  if(AOM_lock(item_tag_rev));
//								if( AOM_set_value_string(item_tag_rev,"t5_ItmCategory",ProAsmDetails)!=ITK_ok) PrintErrorStack();
//								if(AOM_save_without_extensions(item_tag_rev)!=ITK_ok) PrintErrorStack();
//								if(AOM_unlock(item_tag_rev)!=ITK_ok) PrintErrorStack();
//
//								  CALLAPI(GRM_find_relation_type("Pro2_membership",&relation_dep22));
//
//								  GRM_find_relation(primary_object11,item_tag_rev,relation_dep22,&relation_test);
//
//								 CALLAPI(GRM_delete_relation(relation_test));
//								 CALLAPI(AOM_refresh(primary_object11,0));
//								 CALLAPI(AOM_refresh(item_tag_rev,0));
//
//								  printf("\n Dis Relation deleted succ\n");
//							   }
//							}
//						}
//			}
//		}
//}
		  //ended for Pro members

	if(strcmp(class_name,"Dataset")==0)
	{
        CALLAPI(GRM_find_relation_type("IMAN_specification",&relation_type));
	    if(relation_type)
	    {
		     CALLAPI(GRM_list_primary_objects(object_tag,relation_type,&count,&primary_list));
	    }
		if(primary_list)
		{
				printf("\n\nDataset Attached to Primary Object:%d\n",count);

				for(i=0;i<count;i++)
				{
				   primary_object = primary_list[i].primary;
				   if(primary_object)
				   {
				 	 printf("\nprimary_object:%d\n",i);
					 if( AOM_ask_value_string(primary_object,"checked_out",&is_chkout)!=ITK_ok) PrintErrorStack();
					 {
						if(strcmp(is_chkout,"Y")==0)
						{
							allow_chkin = 0;

						}
					 }
					 printf("\n\nallow_chkin1:%d\n",allow_chkin);
				  }
				}
		}
		else
		{
			allow_chkin=0;
		}

		printf("\n\nallow_chkin2:%d\n",allow_chkin);

	    if(allow_chkin==0)
	    {
			  if (AOM_ask_value_string(object_tag,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
			  printf("\n\n ObjectClassType in checkout :%s\n",ObjectClassType);

			  if((strcmp(ObjectClassType,"ProAsm")!=0) && (strcmp(ObjectClassType,"ProPrt")!=0)&& (strcmp(ObjectClassType,"ProDrw")!=0))
			  {
				   EMH_store_error_s1(EMH_severity_error,ITK_err,"Individual cancel-checkout of dataset not allowed");
				   return ITK_err;
			  }
	    }
   }
    printf("\n\nallow_chkin:%d\n",allow_chkin);
	return ifail;
}




extern DLLAPI int CheckIn_validation(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	char		   *class_name		= NULL;
	char		   *PartType		= NULL;
	tag_t		   class_id			= NULLTAG;
	tag_t	 	   DesignRevision		= va_arg (args, tag_t);
	char *object_types;
	tag_t relationTag = NULLTAG;
	int   	count = 0, i =0 , flag = 0;
	tag_t *secondary_objects	;
	//char  type_name[TCTYPE_name_size_c+1];
	//DR Validations
	char *PrtCol = NULL;
	char *type_name = NULL;
	char *Prttyp = NULL;
	char *PrtDR = NULL;
	char *PrtProj = NULL;
	char *DesGrp = NULL;
	char *PrtClass = NULL;
	char *Proj_typ	= NULL;
	tag_t  	PrtCls  = NULLTAG;
		char *DRinfo4=NULL;
	int IsMilestoneLiveFlag=0;
	tag_t   qryTag12     = NULLTAG;
	char   *qry_entry1[1]  = {"SYSCD"};
	char   **qry_values21     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount1      =  0;
	tag_t   *CntrlObjectTag1      = NULLTAG;
	int MilStflg=0;
	tag_t	Project_t = NULLTAG;
	char	*info4	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG;
	tag_t   qryRefDrgTag     = NULLTAG;
	int     n_entry    = 1;
	int     DRValiFlag      =  0;
	char *PrtPrj=NULL;
	int     rsltCount      =  0;
	char    *qry_entry[1]  = {"SYSCD"};
	char    *ref_qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	tag_t	ObjTypProj	= NULLTAG;
	//char   type_Proj[TCTYPE_name_size_c+1];
	char *release_status = NULL;
	char *type_Proj = NULL;
	char* username = NULL;
	tag_t user_tag=NULLTAG;

	char	*info1	= NULL;
	char	*DesgNo	= NULL;//added by hrishikesh and shrivardhan 1.70
	char	*refinfo1	= NULL;
	char	*info2	= NULL;
	tag_t	TagQryContObjSite = NULLTAG, *BypCnObj = NULL;
	int		n_Input = 2,ByPasQCount = 0,CheckBypasFlag=0;
	char	*qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char	*qry_BypVal[2] = {"VALDBYPASS", "DSGPROJ"};
	int n_refqentry = 1;
	char    **qry_refCtrObjct     =  (char **) MEM_alloc(10 * sizeof(char *));
	int rsltRefCount = 0;
	tag_t   *RefCntrlObjectTag      = NULLTAG;

	printf("\nCheckIn_validation\n");fflush(stdout);

	//Get Session User
	CALLAPI(POM_get_user(&username,&user_tag));

	CALLAPI(POM_class_of_instance(DesignRevision,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n\nObject Classname:%s\n",class_name);
	CALLAPI(WSOM_ask_object_type2 	(DesignRevision,&type_name)) 		;
	printf("\n object Type= %s\n",type_name);
	PartType=malloc(50);
	//if(tc_strcmp(type_name,"Design Revision")== 0) //007 T5_SparKitRevision
	if((tc_strcmp(type_name,"Design Revision")== 0)||(tc_strcmp(type_name,"T5_SparKitRevision")== 0) || (tc_strcmp(type_name,"T5_EE_PartRevision")== 0) ||(strcmp(type_name,"T5_DuraFitPartRevision") == 0) ||(strcmp(type_name,"T5_MatEnggPartRevision") == 0))
	{
	if (AOM_UIF_ask_value(DesignRevision,"t5_PartType",&PartType)!=ITK_ok) PrintErrorStack();
	printf("\n PartType is :%s\n",PartType);fflush(stdout);

	//ByPassing Mandetory Attribute Check Validations for APC Group Project Code 2956 and ST Design Group
	if(AOM_ask_value_string(DesignRevision,"t5_ProjectCode",&PrtProj)!=ITK_ok) PrintErrorStack();
	if(AOM_UIF_ask_value(DesignRevision,"t5_DesignGrp",&DesGrp)!=ITK_ok) PrintErrorStack();
	printf("\nRevision Project Code [%s] Design Group :[%s]",PrtProj,DesGrp);fflush(stdout);
	if(strcmp(PrtProj,"")!=0 || strcmp(DesGrp,"")!=0)
	{
		if(QRY_find2("ControlObjQry", &TagQryContObjSite));
		if(TagQryContObjSite)
		{
			 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ByPasQCount, &BypCnObj));
			 printf("\nObjects for Query VALDBYPASS == %d", ByPasQCount);fflush(stdout);
		}
		else
		{
			printf("\nContrlObj not found for SYSCD=VALDBYPASS");fflush(stdout);
		}

		if(ByPasQCount >0)
		{
			if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
			if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();//Project Code

			printf("\nBypass Project Codes List [%s]",info2); fflush(stdout);
			printf("\nBypass Design  Group List [%s]",info1); fflush(stdout);

			if(tc_strstr(info2,PrtProj)!=NULL || tc_strstr(info1,DesGrp)!=NULL)
			{
				CheckBypasFlag=1;	//If found in Control Object check-in validations will be bypassed
			}
		}
		printf("\nCheckBypasFlag : [%d]",CheckBypasFlag);fflush(stdout);
	}

	//DR Validation on CheckIn
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && CheckBypasFlag==0)
		{
			printf("\n Part Checkin validation ...\n"); fflush(stdout);
			if(QRY_find2("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali";
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n CREVali:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
				printf("\n info4 is  = [%s]\n", info4);fflush(stdout);
			}
			if (AOM_ask_value_string(DesignRevision,"t5_ColourInd",&PrtCol)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(DesignRevision,"t5_PartType",&Prttyp)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(DesignRevision,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(DesignRevision,"item_id",&DesgNo)!=ITK_ok) PrintErrorStack();//added by hrishikesh 1.70
			if (AOM_UIF_ask_value(DesignRevision,"release_status_list",&release_status)!=ITK_ok) PrintErrorStack();
			printf("\n CheckIn:Prttyp: [%s] PrtDR: [%s] PrtCol:[%s] release_status:[%s]\n",Prttyp,PrtDR,PrtCol,release_status);fflush(stdout);
			if(POM_class_of_instance(DesignRevision,&PrtCls)!=ITK_ok) PrintErrorStack();
			if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok) PrintErrorStack();
			printf("\n CheckIn:PrtClass :%s",PrtClass); fflush(stdout);
			if (AOM_ask_value_string(DesignRevision,"t5_ProjectCode",&PrtProj)!=ITK_ok) PrintErrorStack();
			printf("\n CheckIn:PrtProj is  = [%s]\n", PrtProj);fflush(stdout);
			DRValiFlag=0;
			if(tc_strcmp(release_status,"")!=0)
			{
				if(tc_strstr(info4,release_status) != NULL)
				{
					DRValiFlag=1;
					printf("\n CheckIn:DRValiFlag  = [%d]\n", DRValiFlag);fflush(stdout);
				}
			}
			if((tc_strcmp(PrtProj,"")!=0)&&(DRValiFlag==0))
			{
				if(ITEM_find_item(PrtProj,&Project_t)!=ITK_ok) PrintErrorStack();
				if (Project_t)
				{
					if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
					if(TCTYPE_ask_name2(ObjTypProj,&type_Proj));
					printf("\n CheckIn:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
					if (strcmp(type_Proj,"T5_Project")==0)
					{
						if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok) PrintErrorStack();
						printf("\n CheckIn:Proj_typ :[%s]\n",Proj_typ);   fflush(stdout);
						if((tc_strcmp(PrtDR,"")!=0) && (tc_strcmp(PrtDR,"NA")!=0))
						{
							if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
							{
								if((tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0)  && (tc_strcmp(PrtDR,"AR2")!=0) &&
								(tc_strcmp(PrtDR,"AR3")!=0) && (tc_strcmp(PrtDR,"AR4")!=0)  &&  (tc_strcmp(PrtDR,"AR5")!=0))
								{
									printf("\n CheckIn:ERROR:1.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly select AR-status from AR0/AR1/AR2/AR3/AR4/AR5.\n Part project type-Engine/GearBox/Clutch/Axles should have AR-value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
									return 1;
								}
							}
							else
							{
							if((tc_strcmp(PrtDR,"DR0")!=0) && (tc_strcmp(PrtDR,"DR1")!=0) && (tc_strcmp(PrtDR,"DR2")!=0) &&
								(tc_strcmp(PrtDR,"DR3")!=0) && (tc_strcmp(PrtDR,"DR4")!=0) && (tc_strcmp(PrtDR,"DR5")!=0) && (tc_strcmp(PrtDR,"DR3P")!=0) &&
								(tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0) && (tc_strcmp(PrtDR,"AR2")!=0) && (tc_strcmp(PrtDR,"AR3")!=0) &&
								(tc_strcmp(PrtDR,"AR3P")!=0) && (tc_strcmp(PrtDR,"AR4")!=0) && (tc_strcmp(PrtDR,"AR5")!=0) && (tc_strcmp(PrtDR,"DVPT")!=0) &&
								(tc_strcmp(PrtDR,"Pre-KO")!=0) && (tc_strcmp(PrtDR,"KO")!=0))
								{
									printf("\n CheckIn:ERROR:2.\n"); fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from DR0/DR1/DR2/DR3/DR3P/DR4/DR5/AR0/AR1/AR2/AR3/AR3P/AR4/AR5/DVPT/Pre-KO/KO.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
									return 1;
								}
							}
								printf("aMilestone for design revisionn check in");fflush(stdout);
								// if (tc_strcmp(type_name,"Design Revision")==0)
								// {
										// if(AOM_get_value_string(DesignRevision,"t5_ProjectCode",&PrtPrj)!=ITK_ok) PrintErrorStack();
										// printf("\nProject stamped is : %s\n",PrtPrj);fflush(stdout);
										// IsMilestoneLiveFlag=0;
										// IsMilestoneLiveFlag = CheckMilestoneLive(PrtPrj);
										// printf("\n P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);
										// if (IsMilestoneLiveFlag >0)
										// {
											// printf("\n project is live check part level Milestone validations");fflush(stdout);
											// if(QRY_find2("ControlObjects", &qryTag12));
											// if (qryTag12)
											// {
												// printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
											// }
											// else
											// {
												// printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
											// }

											// qry_values21[0] = "CREVali";
											// if(QRY_execute(qryTag12, n_entry, qry_entry1, qry_values21, &rsltCount1, &CntrlObjectTag1));
											// printf(" \n CREVali:rsltCount 11:%d:", rsltCount1); fflush(stdout);
											// if(rsltCount1 > 0)
											// {
												// if (AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok) PrintErrorStack();
												// printf("\n CREVali:DRinfo4:%s ",DRinfo4);fflush(stdout);
											// }
											// if(tc_strstr(DRinfo4,"AHCHKNR")==NULL)
											// {
												// printf("\n AHCHKNR is null \n",MilStflg); fflush(stdout);
												// MilStflg = tm_Validate_DR_Milestone_OnPart(DesignRevision);
												// printf("\n after milestone checking %d \n",MilStflg); fflush(stdout);
												// if(MilStflg==1)
												// {
													// EMH_clear_errors();
													// EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
													// return ITK_err;
												// }
												// else if (MilStflg==5)
												// {
													// EMH_clear_errors();
													// EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
													// return ITK_err;
												// }
											// }
										// }
								// }
						}
						else
						{
							//Check Part type..
							//if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
							//(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
							if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
							(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0) && (tc_strstr(DesgNo,"CK")==NULL))//added by hrishikesh and shrivardhan 1.70
							{
								printf("\n CheckIn:ERROR:3..\n"); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly select valid DR/AR-status from drop down list.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
								return 1;
							}
						}
					}
				}
			}
			printf("\n Inside Fun:CheckIn_validation in action_on_dataset: Part type: [%s] to check it's dataset  \n",PartType);fflush(stdout);
			/* Validations as below:
			For part Type = Assembly, CAD module, Module, GID,  Dummy assembly =  CMI2Part is invalid with Iman_Specification relation
			For part Type = Component & Dummy Component = CMI2product is invalid with Iman_Specification relation
			validation is on check in.*/
			if(GRM_find_relation_type("IMAN_specification", &relationTag)!=ITK_ok) PrintErrorStack();
			if(GRM_list_secondary_objects_only(DesignRevision, relationTag, &count, &secondary_objects)!=ITK_ok) PrintErrorStack();

			if(count > 0)
			{
				for (i=0; i<count; i++)
				{
					if (AOM_ask_value_string(secondary_objects[i],"object_type",&object_types)!=ITK_ok) PrintErrorStack();

					printf("\n Inside Fun:CheckIn_validation in action_on_dataset: Object Type: [%s] to check it's dataset  \n",object_types);fflush(stdout);

					if((tc_strcmp(object_types,"CMI2Part") == 0) && ((tc_strcmp(PartType,"Assembly") == 0 || tc_strcmp(PartType,"CAD Module") == 0 || tc_strcmp(PartType,"Module") == 0 || tc_strcmp(PartType,"Group Id") == 0 || tc_strcmp(PartType,"Dummy Assembly") == 0)))
					{
						printf("\n Inside fun:CheckIn_validation in action_on_dataset.c file \n Error: CMI2Part is invalid for Part Type: [%s] \n",PartType);fflush(stdout);
						EMH_store_error_s3(EMH_severity_error,ITK_err,"For Part Type ",PartType,", Dataset type CMI2Part is invalid. Please change Part type to Component / Dummy Component");
						return 1;
					}
					if((tc_strcmp(object_types,"CMI2Product") == 0) && (tc_strcmp(PartType,"Component") == 0 || tc_strcmp(PartType,"Dummy Component") == 0))
					{
						printf("\n Inside fun:CheckIn_validation in action_on_dataset.c file \n Error: CMI2Product is invalid for Part Type: [%s] \n",PartType);fflush(stdout);
						EMH_store_error_s3(EMH_severity_error,ITK_err,"For Part Type ",PartType,", Dataset type CMI2Product is invalid. Please change Part type to other than Component / Dummy Component");
						return 1;
					}

				}
	}

		}
		//DR Validation on Check In end.

//calling function to check if attached drawing is latest or not
/*query ctrl object*/
	if(QRY_find2("ControlObjects", &qryRefDrgTag));
	if (qryRefDrgTag)
	{
		printf("\nqryRefDrgTag:Found Query ControlObjects \n");fflush(stdout);
		qry_refCtrObjct[0] = "t5ChkLatestRefDrg";
		if(QRY_execute(qryRefDrgTag, n_refqentry,	ref_qry_entry, qry_refCtrObjct, &rsltRefCount, &RefCntrlObjectTag));
		printf(" \n*****rsltRefCount :%d:\n", rsltRefCount); fflush(stdout);
		if(rsltRefCount > 0)
		{
			if (AOM_ask_value_string(RefCntrlObjectTag[0],"t5_Userinfo1",&refinfo1)!=ITK_ok) PrintErrorStack();
			printf("\n refinfo1 is.:[%s]\n", refinfo1);fflush(stdout);
			if(tc_strcmp(refinfo1,"Y") == 0)
			{
		//	printf("\ncalling t5ChkLatestRefDrg"); fflush(stdout);
		//			CALLAPI(t5ChkLatestRefDrg(DesignRevision));
		//	printf("\ncalling t5ChkLatestRefDrg1"); fflush(stdout);
		//			CALLAPI(t5ChkLatestRefDrg1(DesignRevision));
		//**********************************Added by Ashish_w ************************************
			printf("\ncalling t5ChkLatestRefDrg_A"); fflush(stdout);
					CALLAPI(t5ChkLatestRefDrg_A(DesignRevision));
			}
		}
	}
			printf("\nqryRefDrgTag ended"); fflush(stdout);

		if(strcmp(username,"loader")==0 || strcmp(username,"infodba")==0)
		{
			printf("\nBypass Provided as Login is %s\n", username);fflush(stdout);
		}
		else
		{
			CALLAPI(t5ValDataset(DesignRevision));

			if(tc_strcmp(type_name,"Design Revision")== 0)
			{
				CALLAPI(t5ValidateDFQRelation(DesignRevision));
			}
		}
	}
	printf("\n CheckIn_validation Function is completed...!");fflush(stdout);
	return ifail;
}

extern int register_checkout_action(int *decision, va_list args)
{
	METHOD_id_t  method;
	METHOD_id_t  method_preCond;
	int	ifail = 0;

    *decision = ALL_CUSTOMIZATIONS;

   printf("\n  register_checkout_action \n");fflush(stdout);
    CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg, &method));
    if (method.id)
    {
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)checkin_with_dataset,NULL));
    }

	CALLAPI(METHOD_find_method(RES_Type, RES_checkout_msg, &method));
	//Rohit
	if (method.id)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)checkout_prevalidation,NULL));
	}
    if (method.id)
    {
        CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)checkout_with_dataset,NULL));
    }

	CALLAPI(METHOD_find_method(RES_Type, RES_cancel_checkout_msg , &method));
    if (method.id)
	{
		CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)cancelcheckout_with_dataset,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg ,&method));
    if (method.id)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_checkin_dataset_only,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_checkout_msg ,&method));
    if (method.id)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_checkout_dataset_only,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_cancel_checkout_msg ,&method));
    if (method.id)
	{
		CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)disallow_cancalcheckout_dataset_only,NULL));
	}

	CALLAPI(METHOD_find_method(RES_Type, RES_checkin_msg ,&method_preCond));
    if (method_preCond.id)
	{
		CALLAPI( METHOD_add_pre_condition(method_preCond,(METHOD_function_t)CheckIn_validation,NULL));
	}
	return ifail;
}

extern DLLAPI int tm_action_on_dataset_register_callbacks()
{
     CUSTOM_register_exit("tm_action_on_dataset", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_checkout_action);

     printf("\nRegister Checkout Custom Exit org\n");

	 return ( ITK_ok );
}
