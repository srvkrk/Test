/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   tm_Check_SVR_WrkFlw.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_Check_SVR_WrkFlw(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	tag_t *taskAttachments=NULLTAG;
	tag_t role_tag;
	char* rolename=NULL;
	char* ObjTyp=NULL;
	tag_t	objTypTag		= NULLTAG;
	char * user_Name;
	tag_t user_tag1;
	char *value;
	//#define PLM_error (EMH_USER_error_base+25)
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_Check_SVR_WrkFlw Function started...");fflush(stdout);
	TC_write_syslog("\n tm_Check_SVR_WrkFlw Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements===>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(POM_get_user(&user_Name,&user_tag1));
			printf("\n\t Starting for user_Name :%s>>>>>>>\n",user_Name);fflush(stdout);
			if (tc_strcmp(user_Name,"Loader")==0)
			{
				printf("\n\t Bypass for user_Name :%s>>>>>>>\n",user_Name);fflush(stdout);
			}
			else
			{
				if(SA_ask_current_role(&role_tag));
				if(SA_ask_role_name2(role_tag,&rolename));
				printf("\n Login user :: Rolename ::  %s\n",rolename);fflush(stdout);

				if(tc_strcmp(rolename,"SVR_Manager")==0)
				{
					printf("\n******* Login user :: Rolename ::  %s ********\n",rolename);fflush(stdout);

					if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

					if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						if(AOM_UIF_ask_value(taskAttachments[i],"t5_rlstype",&value));
						printf("\n >>>>>ERC DML release type:: t5_rlstype ::  %s\n",value);fflush(stdout);
						
						if(tc_strcmp(value,"SVR cluster Release")==0)
						{
							printf("\n\t Bypass for SVR cluster Release>>>>>>>\n");fflush(stdout);
						}
						else
						{
							printf("\n **************inside obj type ***********.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,SVR_WrkFlw_error,"DML Release type not SVR Cluster Release",value);	
							decision = EPM_nogo;
							return decision;
						}
					}
				}
			}
		}
	}
	printf("\n tm_Check_SVR_WrkFlw Function end...");fflush(stdout);
	TC_write_syslog("\n tm_Check_SVR_WrkFlw Function end...");
	return decision;
}