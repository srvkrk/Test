//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_KeyWrdDescLovImpl
//

#ifndef TRL001__T5_KEYWRDDESCLOVIMPL_HXX
#define TRL001__T5_KEYWRDDESCLOVIMPL_HXX

#include <T5_tm_keywordlov/T5_KeyWrdDescLovGenImpl.hxx>

#include <T5_tm_keywordlov/libt5_tm_keywordlov_exports.h>


namespace TRL001
{
    class T5_KeyWrdDescLovImpl; 
    class T5_KeyWrdDescLovDelegate;
}

class  T5_TM_KEYWORDLOV_API TRL001::T5_KeyWrdDescLovImpl
    : public TRL001::T5_KeyWrdDescLovGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_KeyWrdDescLov
    explicit T5_KeyWrdDescLovImpl( T5_KeyWrdDescLov& busObj );

    ///
    /// Destructor
    virtual ~T5_KeyWrdDescLovImpl();

private:
    ///
    /// Default Constructor for the class
    T5_KeyWrdDescLovImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_KeyWrdDescLovImpl( const T5_KeyWrdDescLovImpl& );

    ///
    /// Copy constructor
    T5_KeyWrdDescLovImpl& operator=( const T5_KeyWrdDescLovImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_KeyWrdDescLovDelegate;

};

#include <T5_tm_keywordlov/libt5_tm_keywordlov_undef.h>
#endif // TRL001__T5_KEYWRDDESCLOVIMPL_HXX
