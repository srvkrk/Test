#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

void gentplstrcat(char **src,char* dest)
{
	//printf("\n Inside Function gentplstrcat\n");fflush(stdout);
			
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";
	
	//printf("\n autoresizestrcat src len==%d",strlen(*src));
	//printf("\n autoresizestrcat desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	 //src = MEM_realloc(src, size_ab);
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}
// Code starts here
int tm_GenTplFtn_Call();
int get_child(int count,tag_t *child,FILE *fp,char *inp_level,char* inp_RemoveUnderscorePart,char* inp_Plant,char* inp_StopatF,char* inp_SkipZeroQty,char **output);
int get_top_line_property(tag_t top_line,FILE *fp,char *inp_level,char* inp_RemoveUnderscorePart,char* inp_Plant,char* inp_StopatF,char* inp_SkipZeroQty,char** output);
char* removeSpecialChar(char *in);
char* removeChar(char *in) ;


/*
int ITK_user_main(int argc,char *argv[])
{
	
	int ifail = ITK_ok;

	int z;
	int v;
	int VH_count=0;
	
	tag_t item			 = NULLTAG;
	tag_t rev			 = NULLTAG;
	tag_t VC_rev		 = NULLTAG;
	tag_t* VH_list		 = NULLTAG;
	
	char* s									= NULL;
	char* VH_rev_name						= NULL;
	char *output							= NULL;
	
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	printf("\n ~~~~~~~~~ Inside Program tm_GenTplReport ~~~~~~~~~~~\n");fflush(stdout);
	
	//Init module to login TC
	//ITK_CALL(ITK_init_module("infodba","infodba","dba"));
	char *id						= ITK_ask_cli_argument("-id=");
	char *inp_closure_rule			= ITK_ask_cli_argument("-ic=");
	char *inp_revRule				= ITK_ask_cli_argument("-ir=");
	char *inp_level					= ITK_ask_cli_argument("-il=");
	char *inp_RemoveUnderscorePart	= ITK_ask_cli_argument("-irp=");
	char *inp_Plant					= ITK_ask_cli_argument("-ip=");
	char *inp_StopatF				= ITK_ask_cli_argument("-isf=");
	char *inp_SkipZeroQty			= ITK_ask_cli_argument("-izq=");
	
	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITK_CALL( ITK_init_module("mhn03162","XYT1ESA" ,""));
	//ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);
	ITK_CALL(ITK_set_journalling(TRUE));
	
	if(z==ITK_ok)
	{
		printf("\n ~~~  Login sucessfully ~~~ \n");
	}
	else
	{
		EMH_ask_error_text(z,&s);
		printf("\n Error: %s",s);
	}


	ITK_CALL(ITEM_find_item(id,&item));
	ITK_CALL(ITEM_ask_latest_rev(item,&rev));  

	tm_GenTplFtn_Call_internal( rev, inp_closure_rule, inp_revRule, inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty, &output);
	printf("\n output:%s\n",output);
	return ifail;
}*/

int get_top_line_property(tag_t top_line,FILE *fp,char *inp_level,char* inp_RemoveUnderscorePart,char* inp_Plant,char* inp_StopatF,char* inp_SkipZeroQty,char** output)
{
	char* top_line_name						= NULL;
	char* top_line_object_type				= NULL;
	char* top_line_s						= NULL;
	char* top_line_sChlPrtno				= NULL;
	char* top_line_level					= NULL;
	char* top_line_revision					= NULL;
	char* top_line_AddOn_Description		= NULL;
	char* top_line_Keyword_Description		= NULL;
	char* top_line_Modification_Description	= NULL;
	char* top_line_Description				= NULL;
	char* top_line_TrackTrace				= NULL;
	char* top_line_CTECTS					= NULL;
	char* top_line_ProjectCode				= NULL;
	char* top_line_DesignGrp				= NULL;
	char* top_line_PartType					= NULL;
	char* top_line_PartCode					= NULL;
	char* top_line_Part_Category			= NULL;
	char  top_line_tmp_synopsis[1000];
	char* top_line_Mat_Thickness			= NULL;
	char* top_line_RolledupWt				= NULL;
	char* top_line_Weight					= NULL;
	char* top_line_PartMaterial				= NULL;
	char* top_line_DrawingNo				= NULL;
	char* top_line_DrawingInd				= NULL;
	char* top_line_PartStatus				= NULL;
	char* top_line_Samples_to_be_Approved	= NULL;
	char* top_line_ApplicationOwner			= NULL;
	char* top_line_EnvelopeDimensions		= NULL;
	char* top_line_Comp_Code				= NULL;
	char* top_line_Colour_ID				= NULL;
	char* top_line_ColourInd				= NULL;
	char* top_line_Coated					= NULL;
	char* top_line_Surface_Protection		= NULL;
	char* top_line_MatlClass				= NULL;
	char* top_line_owner					= NULL;
	char* top_line_Unit						= NULL;
	char* top_line_quantity					= NULL;
	char* top_line_CMVR_Cert_Reqd			= NULL;
	char* top_line_Homologation_Reqd		= NULL;
	char* top_line_Spare_Indicator			= NULL;
	char* top_line_Spare_Part				= NULL;
	char* top_line_Validation_Status		= NULL;
	char* top_line_Variant_Formula			= NULL;
	char* top_line_release_status_list		= NULL;
	char* top_line_LastModifiedDate			= NULL;
	char* top_line_last_mod_user			= NULL;
	char* top_line_creation_date			= NULL;
	char* top_line_ModDescription1			= NULL;
	char* top_line_ModDescription2			= NULL;
	char* top_line_Description1				= NULL;
	char* top_line_Description2				= NULL;
	char* top_line_AddOn_Description1		= NULL;
	char* top_line_AddOn_Description2		= NULL;
	char* top_line_KeyWord_Description1		= NULL;
	char* top_line_KeyWord_Description2		= NULL;
	char* top_line_Release_Status1			= NULL;
	char* top_line_Release_Status2			= NULL;
	char* top_line_PartMaterial1			= NULL;
	char* top_line_PartMaterial2			= NULL;
	char* top_line_Part_Category1			= NULL;
	char* top_line_Part_Category2			= NULL;
	char* top_line_MatlClass1				= NULL;
	char* top_line_MatlClass2				= NULL;
	char* top_line_PartTask_Type			= NULL;
	char* top_line_CItemName				= NULL;
	char* top_line_CItemRev					= NULL;
	char* top_line_PartTaskName				= NULL;
	char  top_line_DMLTyp[TCTYPE_name_size_c+1];
	char* top_line_DmlNo					= NULL;
	char* top_line_DmlDRStatus				= NULL;
	char* top_line_DmlReleasedDate			= NULL;
	char* top_line_OwnerDesignUnit			= NULL;
	char* top_line_PlantCS_UI				= NULL;
	char* top_line_PlantCS					= NULL;

	tag_t*	top_line_PartTasks				= NULLTAG;
	tag_t*	top_line_DMLTagg				= NULLTAG;

	tag_t	top_line_PartTask_Class			= NULLTAG;
	tag_t	top_line_PartTask				= NULLTAG;
	tag_t	top_line_relation_type			= NULLTAG;
	tag_t	top_line_TskToDMLRel			= NULLTAG;
	tag_t	top_line_DMLRevTagg				= NULLTAG;
	tag_t	top_line_DMLTypeTag				= NULLTAG;
	tag_t	top_line_bl_rev					= NULLTAG;
	
	logical	top_line_isltstdmll;
	
	int	top_line_CountTask	= 0;
	int	top_line_iTask		= 0;
	int top_line_CountDML	= 0;
	int top_line_iDML		= 0;
	int top_line_StopExpand	= 1;
	int top_line_attr;

	printf("\n Inside Function get_top_line_property \n");fflush(stdout);

	ITK_CALL(BOM_line_look_up_attribute("bl_revision",&top_line_attr));
	ITK_CALL(BOM_line_ask_attribute_tag(top_line,top_line_attr,&top_line_bl_rev));

	ITK_CALL(AOM_UIF_ask_value(top_line_bl_rev,"creation_date",&top_line_creation_date));
	ITK_CALL(AOM_UIF_ask_value(top_line_bl_rev,"last_mod_date",&top_line_LastModifiedDate));
	
	// Getting DML from top_line partnumber
	ITK_CALL(AOM_ask_value_string(top_line_bl_rev,"item_revision_id",&top_line_CItemRev));
	printf("\n child ItemRev => %s \n",top_line_CItemRev);fflush(stdout);

	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&top_line_relation_type));
	ITK_CALL(GRM_list_primary_objects_only(top_line_bl_rev,top_line_relation_type,&top_line_CountTask,&top_line_PartTasks));

	printf("\n top_line_CountTask : %d",top_line_CountTask);fflush(stdout);

	if (top_line_CountTask == 0)
	{
		printf("\n No Task \n");fflush(stdout);
		top_line_DmlNo			 = "NA";
		top_line_DmlDRStatus	 = "NA";
		top_line_DmlReleasedDate = "NA";
	}

	if (top_line_CountTask>0)
	{
		for (top_line_iTask=0;top_line_iTask<top_line_CountTask;top_line_iTask++)
		{
			top_line_PartTask_Class	=	NULLTAG;
			top_line_PartTask_Type	=	NULL;

			top_line_PartTask		=	top_line_PartTasks[top_line_iTask];
			ITK_CALL (TCTYPE_ask_object_type(top_line_PartTask,&top_line_PartTask_Class));
			ITK_CALL (TCTYPE_ask_name2(top_line_PartTask_Class,&top_line_PartTask_Type));
			printf("\n top_line_PartTask_Type : %s",top_line_PartTask_Type);fflush(stdout);

			if(tc_strcmp(top_line_PartTask_Type,"T5_APLTaskRevision")==0)
			{
				top_line_PartTaskName	=	NULL;
				ITK_CALL( AOM_ask_value_string(top_line_PartTask,"item_id",&top_line_PartTaskName));
				printf("\n top_line_PartTaskName : %s",top_line_PartTaskName);fflush(stdout);

				//GetPlantForDMLORTask(PartTaskName,GetPlant1);
				//printf("\n Hi GetPlant : %s",GetPlant);fflush(stdout);
				//printf("\n Hi GetPlant1 : %s",GetPlant1);fflush(stdout);

				//if(tc_strcmp(GetPlant1,GetPlant)==0)
				//{
					top_line_TskToDMLRel	= NULLTAG;
					top_line_DMLRevTagg	= NULLTAG;
					top_line_DMLTypeTag	= NULLTAG;
					
					top_line_CountDML	= 0;
					top_line_iDML		= 0;
					
					printf("\n Test kbb .. \n");fflush(stdout);
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &top_line_TskToDMLRel));
					if (top_line_TskToDMLRel!=NULLTAG)
					{
						ITK_CALL(GRM_list_primary_objects_only(top_line_PartTask,top_line_TskToDMLRel,&top_line_CountDML,&top_line_DMLTagg));
						printf("\n kbb top_line_CountDML : %d",top_line_CountDML);fflush(stdout);

						for (top_line_iDML=0;top_line_iDML<top_line_CountDML ;top_line_iDML++ )
						{
							ITK_CALL(ITEM_rev_sequence_is_latest(top_line_DMLTagg[top_line_iDML],&top_line_isltstdmll));
							printf("\n top_line_isltstdmll : %d\n",top_line_isltstdmll);fflush(stdout);

							if(top_line_isltstdmll != true)
							{
								printf("\n top_line_isltstdmll is not true .....\n");fflush(stdout);
							}
							else
							{
								printf("\n top_line_isltstdmll is  true .....\n");fflush(stdout);
								top_line_DMLRevTagg = top_line_DMLTagg[top_line_iDML];

								ITK_CALL (TCTYPE_ask_object_type(top_line_DMLRevTagg,&top_line_DMLTypeTag));
								ITK_CALL (TCTYPE_ask_name(top_line_DMLTypeTag,top_line_DMLTyp));
								printf("\n top_line_isltstdmll is  true test .....\n");fflush(stdout);

								if(tc_strcmp(top_line_DMLTyp,"T5_APLDMLRevision")==0)
								{
								    top_line_DmlNo				=	NULL;
								    top_line_DmlDRStatus	    =	NULL;
								    top_line_DmlReleasedDate	=	NULL;
									ITK_CALL( AOM_ask_value_string(top_line_DMLRevTagg,"item_id",&top_line_DmlNo));
									printf("\n top_line_DmlNo => %s\n",top_line_DmlNo);fflush(stdout);
									ITK_CALL( AOM_ask_value_string(top_line_DMLRevTagg,"t5_cDRstatus",&top_line_DmlDRStatus));
									printf("\n DmlDRStatus => %s\n",top_line_DmlDRStatus);fflush(stdout);

									if(top_line_DmlDRStatus == NULL )
									{
										top_line_DmlDRStatus = "NA";
									}
									ITK_CALL( AOM_UIF_ask_value(top_line_DMLRevTagg,"date_released",&top_line_DmlReleasedDate));
									printf("\n top_line_DmlReleasedDate => %s\n",top_line_DmlReleasedDate);fflush(stdout);

									if(top_line_DmlReleasedDate == NULL )
									{
										top_line_DmlReleasedDate = "NA";
									}
								}
							}
						}
					}
				}
			}
	}
		
	// Getting Plant CS for top_line
	printf("\n top_line_input Plant ==>  %s \n",inp_Plant);fflush(stdout);
	
	if(strcmp(inp_Plant,"DHARWAD")==0)
	 {
	 	  printf("\n Inside DWD \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_DwdMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"CVBU Pune")==0)
	 {
	 	  printf("\n Inside CVBU Pune \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_PunMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"PUVBU")==0)
	 {
	 	  printf("\n Inside PUVBU \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_PunUVMakeBuyIndicator",&top_line_PlantCS));
	 } 
	 else  if(strcmp(inp_Plant,"CAR")==0)
	 {
	 	  printf("\n Inside CAR \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_CarMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"CVBU JSR")==0)
	 {
	 	  printf("\n Inside CVBU JSR \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_JsrMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"CVBU LKO")==0)
	 {
	 	  printf("\n Inside CVBU LKO \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_LkoMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"SMALLCAR AHD")==0)
	 {
	 	  printf("\n Inside SMALLCAR AHD \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_AhdMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"CVBU PNR")==0)
	 {
	 	  printf("\n Inside CVBU PNR \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_PnrMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else  if(strcmp(inp_Plant,"TMLDL JSR")==0)
	 {
	 	  printf("\n Inside TMLDL JSR \n");fflush(stdout);
	 	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_JdlMakeBuyIndicator",&top_line_PlantCS));
	 }
	 else
	 {
	   	  printf("\n Inside other \n");fflush(stdout);
	   	  ITK_CALL(AOM_ask_value_string(top_line,"bl_Design Revision_t5_PunMakeBuyIndicator",&top_line_PlantCS));
	 }

	// Stop at F
	printf("\n inp_StopatF => %s \n",inp_StopatF);fflush(stdout);
	top_line_StopExpand	= 1;
	if(tc_strcmp(inp_StopatF,"+")==0)
	{
		if (tc_strstr(top_line_PlantCS,"F")!=NULL)
		{
			printf("\n skip F CS \n");fflush(stdout);
			top_line_StopExpand= 0;
		}
		
	}
	
	printf("\n Checking TOP BOM-Line Property \n");fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_level_starting_0",&top_line_level));
	int level1 = atoi(top_line_level);

	ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&top_line_sChlPrtno));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_rev_item_revision_id",&top_line_revision));
	
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_rev_object_desc",&top_line_Description1));

	STRNG_replace_str(top_line_Description1,",",";",&top_line_Description2);
	STRNG_replace_str(top_line_Description2,"\n",";",&top_line_Description);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_Coated",&top_line_Coated));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_ColourInd",&top_line_ColourInd));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PrtCatCode",&top_line_Comp_Code));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_ColourID",&top_line_Colour_ID));
	//
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_uom",&top_line_Unit));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_quantity",&top_line_quantity));
	printf("\n top_line_PlantCS => %s \n",top_line_PlantCS);fflush(stdout); 

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_DocRemarks",&top_line_ModDescription1));
	STRNG_replace_str(top_line_ModDescription1,",",";",&top_line_ModDescription2);
	STRNG_replace_str(top_line_ModDescription2,"\n",";",&top_line_Modification_Description);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_SimVal",&top_line_AddOn_Description1));
	STRNG_replace_str(top_line_AddOn_Description1,",",";",&top_line_AddOn_Description2);
	STRNG_replace_str(top_line_AddOn_Description2,"\n",";",&top_line_AddOn_Description);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_CategoryName",&top_line_KeyWord_Description1));
	STRNG_replace_str(top_line_KeyWord_Description1,",",";",&top_line_KeyWord_Description2);
	STRNG_replace_str(top_line_KeyWord_Description2,"\n",";",&top_line_Keyword_Description);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_ProjectCode",&top_line_ProjectCode));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_DesignGrp",&top_line_DesignGrp));

	//
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_DsgnOwn",&top_line_OwnerDesignUnit));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PartType",&top_line_PartType));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PartCode",&top_line_PartCode));

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_SpareCriteria",&top_line_Part_Category1));
	STRNG_replace_str(top_line_Part_Category1,",",";",&top_line_Part_Category2);
	STRNG_replace_str(top_line_Part_Category2,"\n",";",&top_line_Part_Category);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PartStatus",&top_line_PartStatus));
	printf("\n top_line_DmlDRStatus => %s\n",top_line_DmlDRStatus);fflush(stdout);
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_DrawingInd",&top_line_DrawingInd));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_DrawingNo",&top_line_DrawingNo));

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_Material",&top_line_PartMaterial1));
	STRNG_replace_str(top_line_PartMaterial1,",",";",&top_line_PartMaterial2);
	STRNG_replace_str(top_line_PartMaterial2,"\n",";",&top_line_PartMaterial);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_Weight",&top_line_Weight));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_RolledupWt",&top_line_RolledupWt));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_MThickness",&top_line_Mat_Thickness));

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_MatlClass",&top_line_MatlClass1));
	STRNG_replace_str(top_line_MatlClass1,",",";",&top_line_MatlClass2);
	STRNG_replace_str(top_line_MatlClass2,"\n",";",&top_line_MatlClass);

	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_EnvelopeDimensions",&top_line_EnvelopeDimensions));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_ApplicationOwner",&top_line_ApplicationOwner));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_SamplesToAppr",&top_line_Samples_to_be_Approved));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_PrtValiStatus",&top_line_Validation_Status));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_SPDisposalInstr",&top_line_Spare_Part));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_SpareInd",&top_line_Spare_Indicator));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_HomologationReqd",&top_line_Homologation_Reqd));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_Design Revision_t5_CMVRCertificationReqd",&top_line_CMVR_Cert_Reqd));
	ITK_CALL(AOM_UIF_ask_value(top_line,"awb0RevisionOwningUser",&top_line_owner));
	ITK_CALL(AOM_UIF_ask_value(top_line,"awb0RevisionLastModifiedUser",&top_line_last_mod_user));
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_rev_release_status_list",&top_line_Release_Status1));
	
	STRNG_replace_str(top_line_Release_Status1,",",";",&top_line_Release_Status2);
	STRNG_replace_str(top_line_Release_Status2,"\n",";",&top_line_release_status_list);

	printf("\n top_line_DmlNo => %s\n",top_line_DmlNo);fflush(stdout);
	printf("\n top_line_DmlReleasedDate => %s\n",top_line_DmlReleasedDate);fflush(stdout);

	printf("\n top_line_sChlPrtno:%s \n",top_line_sChlPrtno); fflush(stdout);
	
	fprintf(fp,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",top_line_level,top_line_sChlPrtno,top_line_revision,top_line_Description,top_line_Coated,top_line_ColourInd,top_line_Comp_Code,top_line_Colour_ID,top_line_Unit,top_line_quantity,top_line_PlantCS,top_line_Modification_Description,top_line_AddOn_Description,top_line_Keyword_Description,top_line_ProjectCode,top_line_DesignGrp,top_line_OwnerDesignUnit,top_line_PartType,top_line_PartCode,top_line_Part_Category,top_line_PartStatus,top_line_DmlDRStatus,top_line_DrawingInd,top_line_DrawingNo,top_line_PartMaterial,top_line_Weight,top_line_RolledupWt,top_line_Mat_Thickness,top_line_MatlClass,top_line_EnvelopeDimensions,top_line_ApplicationOwner,top_line_Samples_to_be_Approved,top_line_Validation_Status,top_line_Spare_Part,top_line_Spare_Indicator,top_line_Homologation_Reqd,top_line_CMVR_Cert_Reqd,top_line_owner,top_line_creation_date,top_line_last_mod_user,top_line_LastModifiedDate,top_line_release_status_list,top_line_DmlNo,top_line_DmlReleasedDate);fflush(fp);

	gentplstrcat(output,"\n");
	gentplstrcat(output,top_line_level);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_sChlPrtno);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_revision);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Description);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Coated);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_ColourInd);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Comp_Code);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Colour_ID);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Unit);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_quantity);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_PlantCS);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Modification_Description);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_AddOn_Description);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Keyword_Description);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_ProjectCode);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DesignGrp);
	gentplstrcat(output,",");  
	gentplstrcat(output,top_line_OwnerDesignUnit);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_PartType);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_PartCode);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Part_Category);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_PartStatus);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DmlDRStatus);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DrawingInd);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DrawingNo);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_PartMaterial);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Weight);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_RolledupWt);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Mat_Thickness);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_MatlClass);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_EnvelopeDimensions);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_ApplicationOwner);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Samples_to_be_Approved);
	gentplstrcat(output,",");	
	gentplstrcat(output,top_line_Validation_Status);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Spare_Part);
	gentplstrcat(output,",");  
	gentplstrcat(output,top_line_Spare_Indicator);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_Homologation_Reqd);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_CMVR_Cert_Reqd);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_owner);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_creation_date);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_last_mod_user);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_LastModifiedDate);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_release_status_list);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DmlNo);
	gentplstrcat(output,",");
	gentplstrcat(output,top_line_DmlReleasedDate);


}

char* removeChar(char *in) 
{	
	printf("\n Test Inside Function removeChar \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\n' && in[j] != '\r' )
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

return tmp;
}

char* removeSpecialChar(char *in) 
{	
	printf("\n Test Inside (Space Exclude) Function removeSpecialChar \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\x01' && in[j] != '\x02' && in[j] != '\x03' && in[j] != '\x04' && in[j] != '\x05' && in[j] != '\x06' && in[j] != '\x07' && in[j] != '\x08' && in[j] != '\x09' && in[j] != '\x10' && in[j] != '\x11' && in[j] != '\x12' && in[j] != '\x13' && in[j] != '\x14' && in[j] != '\x15' && in[j] != '\x16' && in[j] != '\x17' && in[j] != '\x18' && in[j] != '\x19' /*&& in[j] != '\x20'*/ && in[j] != '\x21')
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

return tmp;
}

int get_child(int count,tag_t *child,FILE *fp,char *inp_level,char* inp_RemoveUnderscorePart,char* inp_Plant,char* inp_StopatF,char* inp_SkipZeroQty,char** output)
{
	int ifail = ITK_ok;
	int i,z,count1,attr,count3,j,k;

	tag_t *sub_child= NULLTAG;
	tag_t bl_rev	= NULLTAG;

	char* name						= NULL;
	char* object_type				= NULL;
	char* s							= NULL;
	char* sChlPrtno					= NULL;
	char* level						= NULL;
	char* revision					= NULL;
	char* AddOn_Description			= NULL;
	char* Keyword_Description		= NULL;
	char* Modification_Description	= NULL;
	char* Description				= NULL;
	char* TrackTrace				= NULL;
	char* CTECTS					= NULL;
	char* ProjectCode				= NULL;
	char* DesignGrp					= NULL;
	char* PartType					= NULL;
	char* PartCode					= NULL;
	char* Part_Category				= NULL;
	char tmp_synopsis[1000];
	char* Mat_Thickness				= NULL;
	char* RolledupWt				= NULL;
	char* Weight					= NULL;
	char* PartMaterial				= NULL;
	char* DrawingNo					= NULL;
	char* DrawingInd				= NULL;
	char* PartStatus				= NULL;
	char* Samples_to_be_Approved	= NULL;
	char* ApplicationOwner			= NULL;
	char* EnvelopeDimensions		= NULL;
	char* Comp_Code					= NULL;
	char* Colour_ID					= NULL;
	char* ColourInd					= NULL;
	char* Coated					= NULL;
	char* Surface_Protection		= NULL;
	char* MatlClass					= NULL;
	char* owner						= NULL;
	char* Unit						= NULL;
	char* quantity					= NULL;
	char* CMVR_Cert_Reqd			= NULL;
	char* Homologation_Reqd			= NULL;
	char* Spare_Indicator			= NULL;
	char* Spare_Part				= NULL;
	char* Validation_Status			= NULL;
	char* Variant_Formula			= NULL;
	char* release_status_list		= NULL;
	char* LastModifiedDate			= NULL;
	char* last_mod_user				= NULL;
	char* creation_date				= NULL;
	char* ModDescription1			= NULL;
	char* ModDescription2			= NULL;
	char* moddes2					= NULL;
	char* Description1				= NULL;
	char* Description2				= NULL;
	char* AddOn_Description1		= NULL;
	char* AddOn_Description2		= NULL;
	char* KeyWord_Description1		= NULL;
	char* KeyWord_Description2		= NULL;
	char* Release_Status1			= NULL;
	char* Release_Status2			= NULL;
	char* PartMaterial1				= NULL;
	char* PartMaterial2				= NULL;
	char* Part_Category1			= NULL;
	char* Part_Category2			= NULL;
	char* MatlClass1				= NULL;
	char* MatlClass2				= NULL;
	char* Desc2						= NULL;
	char* AddOn_Desc				= NULL;
	char* Keyword_Desc				= NULL;
	char* Part_Cat					= NULL;
	char* Part_Mat					= NULL;
	char* Matl_Class				= NULL;
	char* DrawingNo1				= NULL;
	char* DrawingNo2				= NULL;
	char* Drawing_No				= NULL;

	int level2 = atoi(inp_level);

	//
	int	CountTask	= 0;
	int	iTask		= 0;
	int CountDML	= 0;
	int iDML		= 0;
	int StopExpand	= 1;
	
	tag_t*	PartTasks			= NULLTAG;
	tag_t	PartTask_Class		= NULLTAG;
	tag_t	PartTask			= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	TskToDMLRel			= NULLTAG;
	tag_t	DMLRevTagg			= NULLTAG;
	tag_t	DMLTypeTag			= NULLTAG;
	tag_t*	DMLTagg				= NULLTAG;
	
	char*	PartTask_Type		= NULL;
	char*	CItemName			= NULL;
	char*	CItemRev			= NULL;
	char*	PartTaskName		= NULL;
	char	DMLTyp[TCTYPE_name_size_c+1];
	char*	DmlNo				= NULL;
	char*	DmlDRStatus			= NULL;
	char*	DmlReleasedDate		= NULL;
	char*	OwnerDesignUnit		= NULL;

	logical	isltstdmll;
	char *PlantCS			= NULL;

	//
	
	int ruleConfigByID 	 =0;
	char* rules_configured_by = NULL;
	
	ITK_CALL(BOM_line_look_up_attribute("bl_config_string", &ruleConfigByID));
	
	printf("\n Inside Function get_child \n");fflush(stdout);

	for(i=0;i<count;i++)
	{
		DmlNo		= NULL;
		printf("\n Inside Loop Child %d \n",i+1);fflush(stdout);

		ITK_CALL(BOM_line_ask_attribute_string(child[i], ruleConfigByID, &rules_configured_by));
		printf("\ngetChildObjectsInView:..rules_configured_by: %s \n",rules_configured_by);fflush(stdout);
		if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
		{
		printf("\n skipping as no configured revision: \n");fflush(stdout);	
		continue;
		}
		
		ITK_CALL(BOM_line_look_up_attribute("bl_revision",&attr));
		ITK_CALL(BOM_line_ask_attribute_tag(child[i],attr,&bl_rev));
		
		//ITK_CALL(AOM_ask_value_string(bl_rev,"item_id",&CItemName));
		ITK_CALL(AOM_UIF_ask_value(bl_rev,"creation_date",&creation_date));
		ITK_CALL(AOM_UIF_ask_value(bl_rev,"last_mod_date",&LastModifiedDate));
		
		CItemName		= NULL;
		ITK_CALL(AOM_ask_value_string(child[i],"bl_item_item_id",&CItemName));
		printf("\n child CItemName => %s \n",CItemName);fflush(stdout);
		
		// Getting Plant CS
		printf("\n input Plant ==>  %s \n",inp_Plant);fflush(stdout);
		
		if(strcmp(inp_Plant,"DHARWAD")==0)
	    {
	    	  printf("\n Inside DWD \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_DwdMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"CVBU Pune")==0)
	    {
	    	  printf("\n Inside CVBU Pune \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PunMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"PUVBU")==0)
	    {
	    	  printf("\n Inside PUVBU \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PunUVMakeBuyIndicator",&PlantCS));
	    } 
	    else  if(strcmp(inp_Plant,"CAR")==0)
	    {
	    	  printf("\n Inside CAR \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_CarMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"CVBU JSR")==0)
	    {
	    	  printf("\n Inside CVBU JSR \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_JsrMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"CVBU LKO")==0)
	    {
	    	  printf("\n Inside CVBU LKO \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_LkoMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"SMALLCAR AHD")==0)
	    {
	    	  printf("\n Inside SMALLCAR AHD \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_AhdMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"CVBU PNR")==0)
	    {
	    	  printf("\n Inside CVBU PNR \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PnrMakeBuyIndicator",&PlantCS));
	    }
	    else  if(strcmp(inp_Plant,"TMLDL JSR")==0)
	    {
	    	  printf("\n Inside TMLDL JSR \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_JdlMakeBuyIndicator",&PlantCS));
	    }
	    else
	    {
	    	  printf("\n Inside other \n");fflush(stdout);
	    	  ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PunMakeBuyIndicator",&PlantCS));
			  
	    }

		// Stop at F
		printf("\n inp_StopatF => %s \n",inp_StopatF);fflush(stdout);
		StopExpand	= 1;
		if(tc_strcmp(inp_StopatF,"+")==0)
		{
			if (tc_strstr(PlantCS,"F")!=NULL)
			{
				printf("\n skip F CS \n");fflush(stdout);
				StopExpand= 0;
			}
			
		}

		// Removing UnderScore Parts
		printf("\n inp_RemoveUnderscorePart => %s \n",inp_RemoveUnderscorePart);fflush(stdout);
		if(tc_strcmp(inp_RemoveUnderscorePart,"+")==0)
		{
			if (tc_strstr(CItemName,"_")!=NULL)
			{
				printf("\n Got underscorepart :%s \n",CItemName);fflush(stdout);
				continue;
			}
		}
		// Getting DML from Child partnumber
		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
		ITK_CALL(GRM_list_primary_objects_only(bl_rev,relation_type,&CountTask,&PartTasks));

		printf("\n CountTask : %d",CountTask);fflush(stdout);

		if (CountTask == 0)
		{
			printf("\n No Task \n");fflush(stdout);
			DmlNo			= "NA";
			DmlDRStatus		= "NA";
			DmlReleasedDate = "NA";
		}

		if (CountTask>0)
		{
			for (iTask=0;iTask<CountTask;iTask++)
			{
				PartTask_Class	=	NULLTAG;
				PartTask_Type	=	NULL;

				PartTask		=	PartTasks[iTask];
				ITK_CALL (TCTYPE_ask_object_type(PartTask,&PartTask_Class));
				ITK_CALL (TCTYPE_ask_name2(PartTask_Class,&PartTask_Type));
				printf("\nPartTask_Type : %s",PartTask_Type);fflush(stdout);

				if(tc_strcmp(PartTask_Type,"T5_APLTaskRevision")==0)
				{
					PartTaskName	=	NULL;
					ITK_CALL( AOM_ask_value_string(PartTask,"item_id",&PartTaskName));
					printf("\n PartTaskName : %s",PartTaskName);fflush(stdout);

					//GetPlantForDMLORTask(PartTaskName,GetPlant1);
					//printf("\n Hi GetPlant : %s",GetPlant);fflush(stdout);
					//printf("\n Hi GetPlant1 : %s",GetPlant1);fflush(stdout);

					//if(tc_strcmp(GetPlant1,GetPlant)==0)
					//{
						TskToDMLRel	= NULLTAG;
						DMLRevTagg	= NULLTAG;
						DMLTypeTag	= NULLTAG;
						
						CountDML	= 0;
						iDML		= 0;
						
						printf("\n Test kbb .. \n");fflush(stdout);
						ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
						if (TskToDMLRel!=NULLTAG)
						{
							ITK_CALL(GRM_list_primary_objects_only(PartTask,TskToDMLRel,&CountDML,&DMLTagg));
							printf("\n kbb CountDML : %d",CountDML);fflush(stdout);

							for (iDML=0;iDML<CountDML ;iDML++ )
							{
								ITK_CALL(ITEM_rev_sequence_is_latest(DMLTagg[iDML],&isltstdmll));
								printf("\n isltstdmll : %d\n",isltstdmll);fflush(stdout);

								if(isltstdmll != true)
								{
									printf("\n isltstdmll is not true .....\n");fflush(stdout);
								}
								else
								{
									printf("\n isltstdmll is  true .....\n");fflush(stdout);
									DMLRevTagg = DMLTagg[iDML];

									ITK_CALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
									ITK_CALL (TCTYPE_ask_name(DMLTypeTag,DMLTyp));
									printf("\n isltstdmll is  true test .....\n");fflush(stdout);

									if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
									{
									    DmlNo	        =	NULL;
									    DmlDRStatus	    =	NULL;
									    DmlReleasedDate	=	NULL;
										ITK_CALL( AOM_ask_value_string(DMLRevTagg,"item_id",&DmlNo));
										printf("\n DmlNo => %s\n",DmlNo);fflush(stdout);
										ITK_CALL( AOM_ask_value_string(DMLRevTagg,"t5_cDRstatus",&DmlDRStatus));
										printf("\n DmlDRStatus => %s\n",DmlDRStatus);fflush(stdout);

										if(DmlDRStatus == NULL )
										{
											DmlDRStatus = "NA";
										}
										ITK_CALL( AOM_UIF_ask_value(DMLRevTagg,"date_released",&DmlReleasedDate));
										printf("\n DmlReleasedDate => %s\n",DmlReleasedDate);fflush(stdout);

										if(DmlReleasedDate == NULL )
										{
											DmlReleasedDate = "NA";
										}
									}
								}
							}
						}
					}
				}
		}
		
		printf("\n Checking Child BOM-Line Property \n");fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_level_starting_0",&level));
		printf("\n Test 00.1 \n");fflush(stdout); 
		int level1 = atoi(level);

		printf("\n Test 0.1  \n");fflush(stdout); 

		ITK_CALL(AOM_ask_value_string(child[i],"bl_item_item_id",&sChlPrtno));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_item_revision_id",&revision));
		
		// Description //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_object_desc",&Description1));
		printf("\n Before Description1 => %s \n",Description1);fflush(stdout);
		Description2=removeSpecialChar(Description1);
		STRNG_replace_str(Description2,",",";",&Desc2);
		printf("\n  test Desc2 => %s \n",Desc2);fflush(stdout);
		Description = removeChar(Desc2);
		printf("\n After Description => %s \n",Description);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Coated",&Coated));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ColourInd",&ColourInd));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PrtCatCode",&Comp_Code));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ColourID",&Colour_ID));
		
		printf("\n Test 0.3  \n");fflush(stdout); 
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_uom",&Unit));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_quantity",&quantity));
		
		// Modification_Description //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DocRemarks",&ModDescription1));
		printf("\n Before ModDescription1 => %s \n",ModDescription1);fflush(stdout);
		ModDescription2=removeSpecialChar(ModDescription1);
		STRNG_replace_str(ModDescription2,",",";",&moddes2);
		printf("\n  test moddes2 => %s \n",moddes2);fflush(stdout);
		Modification_Description = removeChar(moddes2);
		printf("\n After Modification_Description => %s \n",Modification_Description);fflush(stdout);
		
		// AddOn_Description //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SimVal",&AddOn_Description1));
		printf("\n Before AddOn_Description1 => %s \n",AddOn_Description1);fflush(stdout);
		AddOn_Description2=removeSpecialChar(AddOn_Description1);
		STRNG_replace_str(AddOn_Description2,",",";",&AddOn_Desc);
		printf("\n  test AddOn_Desc => %s \n",AddOn_Desc);fflush(stdout);
		AddOn_Description = removeChar(AddOn_Desc);
		printf("\n After AddOn_Description => %s \n",AddOn_Description);fflush(stdout);

		// Keyword_Description //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_CategoryName",&KeyWord_Description1));
		printf("\n Before KeyWord_Description1 => %s \n",KeyWord_Description1);fflush(stdout);
		KeyWord_Description2=removeSpecialChar(KeyWord_Description1);
		STRNG_replace_str(KeyWord_Description2,",",";",&Keyword_Desc);
		printf("\n  test Keyword_Desc => %s \n",Keyword_Desc);fflush(stdout);
		Keyword_Description = removeChar(Keyword_Desc);
		printf("\n After Keyword_Description => %s \n",Keyword_Description);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ProjectCode",&ProjectCode));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DesignGrp",&DesignGrp));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DsgnOwn",&OwnerDesignUnit));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartType",&PartType));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartCode",&PartCode));
		
		// Part_Category //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SpareCriteria",&Part_Category1));
		printf("\n Before Part_Category1 => %s \n",Part_Category1);fflush(stdout);
		Part_Category2=removeSpecialChar(Part_Category1);
		STRNG_replace_str(Part_Category2,",",";",&Part_Cat);
		printf("\n  test Part_Cat => %s \n",Part_Cat);fflush(stdout);
		Part_Category = removeChar(Part_Cat);
		printf("\n After Part_Category => %s \n",Part_Category);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartStatus",&PartStatus));
		printf("\n DmlDRStatus => %s\n",DmlDRStatus);fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DrawingInd",&DrawingInd));

		// DrawingNo //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DrawingNo",&DrawingNo1));
		printf("\n Before DrawingNo1 => %s \n",DrawingNo1);fflush(stdout);
		DrawingNo2=removeSpecialChar(DrawingNo1);
		STRNG_replace_str(DrawingNo2,",",";",&Drawing_No);
		printf("\n  test Drawing_No => %s \n",Drawing_No);fflush(stdout);
		DrawingNo = removeChar(Drawing_No);
		printf("\n After DrawingNo => %s \n",DrawingNo);fflush(stdout);

		// PartMaterial //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Material",&PartMaterial1));
		printf("\n Before PartMaterial1 => %s \n",PartMaterial1);fflush(stdout);
		PartMaterial2=removeSpecialChar(PartMaterial1);
		STRNG_replace_str(PartMaterial2,",",";",&Part_Mat);
		printf("\n  test Part_Mat => %s \n",Part_Mat);fflush(stdout);
		PartMaterial = removeChar(Part_Mat);
		printf("\n After PartMaterial => %s \n",PartMaterial);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Weight",&Weight));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_RolledupWt",&RolledupWt));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_MThickness",&Mat_Thickness));
		
		// MatlClass //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_MatlClass",&MatlClass1));
		printf("\n Before MatlClass1 => %s \n",MatlClass1);fflush(stdout);
		MatlClass2=removeSpecialChar(MatlClass1);
		STRNG_replace_str(MatlClass2,",",";",&Matl_Class);
		printf("\n  test Matl_Class => %s \n",Matl_Class);fflush(stdout);
		MatlClass = removeChar(Matl_Class);
		printf("\n After MatlClass => %s \n",MatlClass);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ApplicationOwner",&ApplicationOwner));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SamplesToAppr",&Samples_to_be_Approved));
		
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PrtValiStatus",&Validation_Status));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SPDisposalInstr",&Spare_Part));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SpareInd",&Spare_Indicator));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_HomologationReqd",&Homologation_Reqd));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_CMVRCertificationReqd",&CMVR_Cert_Reqd));
		ITK_CALL(AOM_UIF_ask_value(child[i],"awb0RevisionOwningUser",&owner));
		ITK_CALL(AOM_UIF_ask_value(child[i],"awb0RevisionLastModifiedUser",&last_mod_user));

		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_release_status_list",&Release_Status1));
		STRNG_replace_str(Release_Status1,",",";",&Release_Status2);
		STRNG_replace_str(Release_Status2,"\n",";",&release_status_list);
		
		printf("\n DmlNo => %s\n",DmlNo);fflush(stdout);
		printf("\n DmlReleasedDate => %s\n",DmlReleasedDate);fflush(stdout);

		printf("\n inp_SkipZeroQty => %s\n",inp_SkipZeroQty);fflush(stdout);
		if(tc_strcmp(inp_SkipZeroQty,"+")==0)
		{
			if(atoi(quantity) == 0)
			{
				printf("\n Skipping 0 Qty => %s \n",sChlPrtno);fflush(stdout);	
				continue;
			} 
		}

		printf("\n sChlPrtno:%s \n",sChlPrtno); fflush(stdout);
		
		fprintf(fp,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",level,sChlPrtno,revision,Description,Coated,ColourInd,Comp_Code,Colour_ID,Unit,quantity,PlantCS,Modification_Description,AddOn_Description,Keyword_Description,ProjectCode,DesignGrp,OwnerDesignUnit,PartType,PartCode,Part_Category,PartStatus,DmlDRStatus,DrawingInd,DrawingNo,PartMaterial,Weight,RolledupWt,Mat_Thickness,MatlClass,EnvelopeDimensions,ApplicationOwner,Samples_to_be_Approved,Validation_Status,Spare_Part,Spare_Indicator,Homologation_Reqd,CMVR_Cert_Reqd,owner,creation_date,last_mod_user,LastModifiedDate,release_status_list,DmlNo,DmlReleasedDate);fflush(fp);

		gentplstrcat(output,"\n");
		gentplstrcat(output,level);
		gentplstrcat(output,",");
		gentplstrcat(output,sChlPrtno);
		gentplstrcat(output,",");
		gentplstrcat(output,revision);
		gentplstrcat(output,",");
		gentplstrcat(output,Description);
		gentplstrcat(output,",");
		gentplstrcat(output,Coated);
		gentplstrcat(output,",");
		gentplstrcat(output,ColourInd);
		gentplstrcat(output,",");
		gentplstrcat(output,Comp_Code);
		gentplstrcat(output,",");
		gentplstrcat(output,Colour_ID);
		gentplstrcat(output,",");
		gentplstrcat(output,Unit);
		gentplstrcat(output,",");
		gentplstrcat(output,quantity);
		gentplstrcat(output,",");
		gentplstrcat(output,PlantCS);
		gentplstrcat(output,",");
		gentplstrcat(output,Modification_Description);
		gentplstrcat(output,",");
		gentplstrcat(output,AddOn_Description);
		gentplstrcat(output,",");
		gentplstrcat(output,Keyword_Description);
		gentplstrcat(output,",");
		gentplstrcat(output,ProjectCode);
		gentplstrcat(output,",");
		gentplstrcat(output,DesignGrp);
		gentplstrcat(output,",");  
		gentplstrcat(output,OwnerDesignUnit);
		gentplstrcat(output,",");
		gentplstrcat(output,PartType);
		gentplstrcat(output,",");
		gentplstrcat(output,PartCode);
		gentplstrcat(output,",");
		gentplstrcat(output,Part_Category);
		gentplstrcat(output,",");
		gentplstrcat(output,PartStatus);
		gentplstrcat(output,",");
		gentplstrcat(output,DmlDRStatus);
		gentplstrcat(output,",");
		gentplstrcat(output,DrawingInd);
		gentplstrcat(output,",");
		gentplstrcat(output,DrawingNo);
		gentplstrcat(output,",");
		gentplstrcat(output,PartMaterial);
		gentplstrcat(output,",");
		gentplstrcat(output,Weight);
		gentplstrcat(output,",");
		gentplstrcat(output,RolledupWt);
		gentplstrcat(output,",");
		gentplstrcat(output,Mat_Thickness);
		gentplstrcat(output,",");
		gentplstrcat(output,MatlClass);
		gentplstrcat(output,",");
		gentplstrcat(output,EnvelopeDimensions);
		gentplstrcat(output,",");
		gentplstrcat(output,ApplicationOwner);
		gentplstrcat(output,",");
		gentplstrcat(output,Samples_to_be_Approved);
		gentplstrcat(output,",");	
		gentplstrcat(output,Validation_Status);
		gentplstrcat(output,",");
		gentplstrcat(output,Spare_Part);
		gentplstrcat(output,",");  
		gentplstrcat(output,Spare_Indicator);
		gentplstrcat(output,",");
		gentplstrcat(output,Homologation_Reqd);
		gentplstrcat(output,",");
		gentplstrcat(output,CMVR_Cert_Reqd);
		gentplstrcat(output,",");
		gentplstrcat(output,owner);
		gentplstrcat(output,",");
		gentplstrcat(output,creation_date);
		gentplstrcat(output,",");
		gentplstrcat(output,last_mod_user);
		gentplstrcat(output,",");
		gentplstrcat(output,LastModifiedDate);
		gentplstrcat(output,",");
		gentplstrcat(output,release_status_list);
		gentplstrcat(output,",");
		gentplstrcat(output,DmlNo);
		gentplstrcat(output,",");
		gentplstrcat(output,DmlReleasedDate);

		//Recurrsive Function or Find Multilevel Assembly
		ITK_CALL(BOM_line_ask_all_child_lines(child[i],&count1,&sub_child));
		printf("\n Number Of Sub-Childs => %d",count1);fflush(stdout);
		printf("\n StopExpand => %d\n",StopExpand);fflush(stdout);

		if(count1>0 && level1<level2 && StopExpand == 1 )
		{
			printf("\n Inside Sub-Childs \n");fflush(stdout);
			get_child(count1,sub_child,fp,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty, output);
				
		}
		
	}

	if(PartTasks)
		MEM_free(PartTasks);
	if(DMLTagg)
		MEM_free(DMLTagg);
		
		return ifail;
}

int tm_GenTplFtn_Call_internal(tag_t rev,char* inp_closure_rule,char* inp_revRule,char* inp_level,char* inp_RemoveUnderscorePart,char* inp_Plant,char* inp_StopatF,char* inp_SkipZeroQty,char** output)
{

	int ifail = ITK_ok;
	//Variable Decleration
	int z,i,j,count,countz;
	int rulefound = 0;

	char *s					= NULL;
	char *object_type		= NULL;
	char *item_id			= NULL;
	char *PartType_bl		= NULL;
	char *InputPart			= NULL;
	char *InputPartNumRev	= NULL;
	char *InputPartDesc		= NULL;
	char *InputPartType		= NULL;
	
	tag_t item			= NULLTAG;
	tag_t *child		= NULLTAG;
	tag_t window		= NULLTAG;
	tag_t top_line		= NULLTAG;
	tag_t rule			= NULLTAG;
	tag_t *closurerule	= NULLTAG;
	tag_t close_tag		= NULLTAG;
	
	FILE *fp;

	//
	InputPart		= NULL;
	InputPartNumRev	= NULL;
	ITK_CALL(AOM_ask_value_string(rev,"item_id",&InputPart));
	printf("\n InputPart  => %s \n", InputPart);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(rev,"object_string",&InputPartNumRev));
	printf("\n InputPartNumRev  => %s\n",InputPartNumRev);fflush(stdout);
	
	InputPartDesc	= NULL;
	ITK_CALL(AOM_ask_value_string(rev,"object_desc",&InputPartDesc));
	printf("\n InputPart Description => %s\n", InputPartDesc);fflush(stdout);
	
	InputPartType	= NULL;
	ITK_CALL(AOM_ask_value_string(rev,"t5_PartType",&InputPartType));
	printf("\n InputPart Type => %s\n", InputPartType);fflush(stdout);

	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	time(&now);
	now_tm = localtime(&now);
	//strftime (ReportFiredDate, 26,"%d-%B-%Y", now_tm);
	strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
	printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);

	char*       FileName           = NULL;
	FileName = (char *) MEM_alloc(100 * sizeof(char *));
	
	tc_strcpy(FileName,"/tmp/GenTPL_Report");
	tc_strcat(FileName,"_");
	tc_strcat(FileName,InputPart);
	tc_strcat(FileName,"_");
	tc_strcat(FileName,ReportFiredDate);
	tc_strcat(FileName,".csv");

	fp = fopen(FileName,"w");

	fprintf(fp,"%s",InputPartNumRev);fflush(fp);
	fprintf(fp,"\n %s",InputPartType);fflush(fp);
	fprintf(fp,"\n %s",InputPartDesc);fflush(fp);
	fprintf(fp,"\n %s",inp_closure_rule);fflush(fp);
	fprintf(fp,"\n %s",inp_revRule);fflush(fp);
	fprintf(fp,"\n %s",inp_Plant);fflush(fp);
	fprintf(fp,"\n %s",inp_level);fflush(fp);
	fprintf(fp,"\n %s",inp_StopatF);fflush(fp);
	fprintf(fp,"\n %s",inp_RemoveUnderscorePart);fflush(fp);
	fprintf(fp,"\n %s",inp_SkipZeroQty);fflush(fp);
	fprintf(fp,"\n %s\n",ReportFiredDate);fflush(fp);
	fprintf(fp,"\n");fflush(fp);
	
	//fp= fopen("GenTPL_Report.csv","w"); // OLD

	printf("\n Inside Function tm_GenTplFtn_Call_internal \n");fflush(stdout);

		printf("\n ketan closurerulename  => %s\n", inp_closure_rule);fflush(stdout);
		printf("\n ketan inp_revRule  => %s\n", inp_revRule);fflush(stdout);
		printf("\n ketan inp_level  => %s\n", inp_level);fflush(stdout);
		printf("\n ketan inp_RemoveUnderscorePart  => %s\n", inp_RemoveUnderscorePart);fflush(stdout);
		printf("\n ketan inp_Plant  => %s\n", inp_Plant);fflush(stdout);
		printf("\n ketan inp_StopatF  => %s\n", inp_StopatF);fflush(stdout);
		printf("\n ketan inp_SkipZeroQty  => %s\n", inp_SkipZeroQty);fflush(stdout);

		//ITK_CALL(AOM_UIF_ask_value(rev,"t5_PartType",&PartType_bl));
		ITK_CALL(AOM_ask_value_string(rev,"t5_PartType",&PartType_bl));

		printf ("\n k PartType_bl => %s \n",PartType_bl);fflush(stdout);

		// Find out the window
		ITK_CALL(BOM_create_window(&window));
		// Find revision rule
		ITK_CALL(CFM_find(inp_revRule,&rule));
		// Set revision rule
		ITK_CALL(BOM_set_window_config_rule( window, rule ));
		ITK_CALL(BOM_set_window_pack_all(window, true));
		

		//ITK_CALL(PIE_find_closure_rules( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule ));
		ITK_CALL(PIE_find_closure_rules( inp_closure_rule,PIE_TEAMCENTER, &rulefound, &closurerule )); // Ketan
				
		printf ("\n rule count => %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("\n closure rule found \n");fflush(stdout);				
		}
		if(tc_strcmp(PartType_bl,"Vehicle Combination")!=0)
		{
			printf ("\n Setting closure_rule \n");fflush(stdout);		
			ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));  
		}
		
		// Find out bom line tag
		ITK_CALL(BOM_set_window_top_line(window,item,rev,NULLTAG,&top_line));
		ITK_CALL(BOM_window_hide_unconfigured( window ));
		ITK_CALL(BOM_window_hide_suppressed( window ));
		// Find out the all childs
		ITK_CALL(BOM_line_ask_all_child_lines(top_line,&count,&child));

		printf("\n Number Of Parent's Children %d \n",count);
		// Only For Header
		fprintf(fp,"Level,Component,Revision,Description,Coated,Colour Indicator,Comp Code,Colour ID,Unit,Quantity,CS,Modification Description,AddOn Description,Keyword Description,Project Code,Design Group,Owner Design Unit,Part Type,Part Code,Part Category,Part DR Status,DML DR Status,Drawing Indicator,Drawing No,Part Material,Weight,Rolled Up Weight,Material Thickness,Material Class,Envelope Dimensions,Application Owner,Samples to be Approved,Validation Status,Spare Part,Spare Indicator,Homologation Reqd,CMVR Cert Reqd,Owner,Creation Date,Last Modifying User,Last Modified Date,Release Status,DML Number,DML Closure Date");fflush(fp);
		gentplstrcat(output,"Level,Component,Revision,Description,Coated,Colour Indicator,Comp Code,Colour ID,Unit,Quantity,CS,Modification Description,AddOn Description,Keyword Description,Project Code,Design Group,Owner Design Unit,Part Type,Part Code,Part Category,Part DR Status,DML DR Status,Drawing Indicator,Drawing No,Part Material,Weight,Rolled Up Weight,Material Thickness,Material Class,Envelope Dimensions,Application Owner,Samples to be Approved,Validation Status,Spare Part,Spare Indicator,Homologation Reqd,CMVR Cert Reqd,Owner,Creation Date,Last Modifying User,Last Modified Date,Release Status,DML Number,DML Closure Date");				
		//

		// Getting Topline property
		get_top_line_property(top_line,fp,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty,output);
		
		// Getting Child property
		get_child(count,child,fp,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty,output);

		fclose(fp);
		
		if(window!=NULLTAG)
			BOM_close_window(window);
		///*
		char cmd[200];
		
		sprintf(cmd,"java -jar GenTPLConversion.jar %s",FileName);
		system(cmd); 
		//*/
				
		return ifail;


}

// /*
int tm_GenTplFtn_Call(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	tag_t rev = NULLTAG;

	char *inp_closure_rule			= NULL;
	char *inp_revRule				= NULL;
	char *inp_level					= NULL;
	char *inp_RemoveUnderscorePart	= NULL;
	char *inp_Plant					= NULL;
	char *inp_StopatF				= NULL;
	char *inp_SkipZeroQty			= NULL;
	char *output					= NULL;
			
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	USERARG_get_tag_argument(&rev);									// rev
	USERARG_get_string_argument(&inp_closure_rule);					// closure_rule
	USERARG_get_string_argument(&inp_revRule);						// rev_rule
	USERARG_get_string_argument(&inp_level);						// level
	USERARG_get_string_argument(&inp_RemoveUnderscorePart);			// inp_RemoveUnderscorePart
	USERARG_get_string_argument(&inp_Plant);						// inp_Plant
	USERARG_get_string_argument(&inp_StopatF);						// inp_StopatF
	USERARG_get_string_argument(&inp_SkipZeroQty);					// inp_SkipZeroQty
		
	
	tc_strcpy(output,"");
	
	// ITK_CALL(ITEM_find_item("5701H1A0100021",&item));

	//ITK_CALL(WSOM_ask_name2(item,&item_id));
	//printf("\n item_id:%s \n item_num=000181",item_id,item); fflush(stdout);
	//ITK_CALL(ITEM_ask_latest_rev(item,&rev));                                              

	//tm_GenTplFtn_Call_internal( rev, inp_closure_rule, inp_revRule, inp_level,inp_RemoveUnderscorePart, &output);
	tm_GenTplFtn_Call_internal( rev, inp_closure_rule, inp_revRule, inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty, &output);
	
	printf("output:%s",output);
	
	*((char **) return_data) = 
			   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

			strcpy( *((char **) return_data), output); 
			
			return ifail;

}



extern int AllUserServiceFnGenTplFtn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
	int nargs = 8;
	int retValueType;
	int inputArgTypes[8] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes[0] = USERARG_TAG_TYPE;     // selectedObj
	inputArgTypes[1] = USERARG_STRING_TYPE;  // closureRuleSelected
	inputArgTypes[2] = USERARG_STRING_TYPE;  // ruleSelected
	inputArgTypes[3] = USERARG_STRING_TYPE;  // level
	inputArgTypes[4] = USERARG_STRING_TYPE;  // RemoveUnderscore
	inputArgTypes[5] = USERARG_STRING_TYPE;  // inp_Plant
	inputArgTypes[6] = USERARG_STRING_TYPE;  // inp_StopatF
	inputArgTypes[7] = USERARG_STRING_TYPE;  // inp_SkipZeroQty

	retValueType = USERARG_STRING_TYPE ; 
	printf("\n AllUserServiceFnGenTplFtn before....tm_GenTplFtn");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_GenTplFtn_Call",(USER_function_t)tm_GenTplFtn_Call,nargs,inputArgTypes,retValueType);
 
 return ifail;
 
}

extern DLLAPI int tm_GenTplReport_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_GenTplReport");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_GenTplReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnGenTplFtn);
	printf("\n After registoring userservice....tm_GenTplReport");fflush(stdout);
	return ( ITK_ok );
}
