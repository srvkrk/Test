/********************************************************************************************************
*  File			: create_pcbu_pro_post.c
*  Created By	: Prachi Wade
*  Created On	: 09-May-2011
*  Project		: TCUA 	 
*  Purpose		: Custom user exit for - checkout,checkin and cancelcheckout of an item alongwith dataset
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/
#include "iman_headers.h"
#include "string.h"
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
//PrintErrorStack();

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

int save_object (tag_t     object_tag)
{
    int ReturnCode;

    /*  Save the object.  */
    ReturnCode = AOM_save (object_tag);
    if (ReturnCode != ITK_ok)
    {
        //output_error ("ERROR %d save object.\n", ReturnCode);
        return (ReturnCode);
    }

    /* Unlock the object. */
    ReturnCode = AOM_unlock (object_tag);
    if (ReturnCode != ITK_ok)
    {
        //output_error ("ERROR %d unlock object.\n", ReturnCode);
    }

    return (ReturnCode);
}

 
extern DLLAPI int createpostaction(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	tag_t	 project_tag =NULLTAG;
	char *project_id;
	char *project_type;
	char *bus_unit;
	char *commandstr = NULL;
	int n_items =0;
	tag_t *item_tags= NULLTAG;

	int i=0,cnt=0;
 	tag_t *fld_content  =NULLTAG;
	char* object_name	=NULL;
	//char* object_type	=NULL;
	tag_t newItem=NULLTAG;

	tag_t *prjfld_content  = NULLTAG;
	//WSO_search_criteria_t   criteria;

	char* ootb_ProjectId	=NULL;
 	char* ootb_ProjectName	=NULL;
//	char* ootb_ProjectDesc	=NULL;
	tag_t ootb_Project_tag	=NULLTAG;
	char* temp = NULL;
	 int cnt1 =0;
	 char		   *class_name		= NULL;
	tag_t		    class_id		= NULLTAG;

	char*  	userid;
	tag_t    	    user_tag				    =NULLTAG;

	//char  *envId[WSO_name_size_c+1];
	//char  *envDesc[WSO_desc_size_c+1];	
	
	char  *envId	  = NULL;
	char  *envDesc	  = NULL;
	tag_t envTag	  =NULLTAG;
	tag_t person_tag  =NULLTAG;
	char  *mailId	  = NULL;
 

	TC_write_syslog("\n\nIn createpostaction\n");	
 	project_tag = m->object_tag;
	
 
	  // CALLAPI(POM_class_of_instance(object_tag,&class_id));
	  // CALLAPI(POM_name_of_class(class_id,&class_name));
	  	
	// TC_write_syslog("\n\nObject Classname:%s\n",class_name);

 
	if(project_tag!=NULLTAG)
	{

			//AOM_save(object_tag);  
			
			AOM_ask_value_string(project_tag,"object_name",&project_id);
			AOM_ask_value_string(project_tag,"object_type",&project_type);
			AOM_ask_value_string(project_tag,"t8_BusUnit",&bus_unit);
			
			TC_write_syslog("\nproject_type:%s project_id:%s bus_unit:%s\n",project_type,project_id,bus_unit);fflush(stdout);
			//if(strcmp(bus_unit,"PCBU")==0)
		    //{
					
					//Check if Valid PM

					AOM_ask_value_string(project_tag,"t8_ProjectManager",&userid);
					TC_write_syslog("ProjectManager:%s\n",userid);	fflush(stdout);
					if(userid!=NULL)
				    {
					   CALLAPI(SA_find_user(userid,&user_tag)); 
					}
					if(user_tag!=NULLTAG)
				    {
						
						temp = (char *) MEM_alloc (sizeof (char) * 128);
						ootb_ProjectId = (char *) MEM_alloc (sizeof (char) * 128);
						ootb_ProjectName = (char *) MEM_alloc (sizeof (char) * 128);
						strcpy(temp,project_id);
						TC_write_syslog("\ntemp:%s\n",temp);fflush(stdout);
						
						//30 Characters limit for OOTB ProjectID
						sprintf(ootb_ProjectId,"%.*s", 30,project_id);
						TC_write_syslog("\nootb_ProjectId:%s project_id:%s\n",ootb_ProjectId,project_id);fflush(stdout);
						sprintf(temp,"%.*s", 30,project_id);
						//Dots in OOTB Project Name are replaced with underscore
						STRNG_replace_str(temp,".", "_",&ootb_ProjectName);		 

						TC_write_syslog("\nootb_ProjectId:%s ootb_ProjectName:%s\n",ootb_ProjectId,ootb_ProjectName);fflush(stdout);
						if(ootb_ProjectId != NULL)
						{
							TC_write_syslog("creating OOTB PRoject \n");	fflush(stdout);
							CALLAPI(PROJ_create_project(ootb_ProjectId,ootb_ProjectName,"",&ootb_Project_tag));
							if(ootb_Project_tag == NULLTAG)
							{
								TC_write_syslog("OOTB Project Creation Failed\n");	fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"OOTB Project Creation Failed");	 					 	
								return ITK_err;
							}
							AOM_save(project_tag);
						}
						TC_write_syslog("\nassigning project team\n");fflush(stdout);
						CALLAPI(PROJ_assign_team(ootb_Project_tag,1,&user_tag,user_tag,0,NULLTAG));		
						save_object(project_tag);
						/********************* 
						TC_write_syslog("\nchanging owner\n");fflush(stdout);
						AOM_refresh(project_tag,1);
						CALLAPI(POM_set_owning_user(ootb_Project_tag,user_tag));
                        save_object(project_tag);
						AOM_refresh(project_tag,0);
						 ********************/
						CALLAPI(AOM_ask_value_string(project_tag,"object_name",&envId));
						CALLAPI(AOM_ask_value_string(project_tag,"object_desc",&envDesc));
						CALLAPI(SA_ask_user_person (user_tag,&person_tag));
						if(person_tag!=NULLTAG)
						{
						   CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
						}

						if(mailId != NULL)
						{

							CALLAPI(MAIL_create_envelope(envId,envDesc,&envTag));
							if(envTag!=NULLTAG)
							{
								CALLAPI(MAIL_initialize_envelope(envTag,envId,envDesc));  							 					   
								CALLAPI(FL_insert(envTag,project_tag,1)); 
								CALLAPI(MAIL_add_envelope_receiver(envTag,user_tag));							
								if(mailId !=NULL )
								{
									//CALLAPI(MAIL_add_external_receiver(envTag,MAIL_send_to,mailId));
								}
							//	CALLAPI(MAIL_add_external_receiver(envTag,MAIL_send_cc,"prachi.wade@tatatechnologies.com"));
								CALLAPI(MAIL_send_envelope(envTag));  	
							}
						}
												
						//CALLAPI(PROJ_assign_team(ootb_Project_tag,1,user_tag,user_tag,1,user_tag));		
					}
					else
				    {
						TC_write_syslog("Invalid Project Manager\n");	fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Invalid Project Manager");	 					 	
			  		    return ITK_err;						 
					}

					
					CALLAPI(PROJ_assign_objects(1,&ootb_Project_tag,1,&project_tag));
					AOM_save(project_tag);

					CALLAPI(WSOM_find("PPM Templates",&n_items,&item_tags));
					TC_write_syslog("\n PPM Templates:%d\n",n_items);fflush(stdout);

					CALLAPI(AOM_ask_value_tags(item_tags[0],"contents",&cnt,&fld_content));
					TC_write_syslog("\nPPM Templates - contents:%d\n",cnt);

					if(cnt>0)
					{
							for(i=0;i<cnt;i++)
							{
								CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
								TC_write_syslog("\nobject_name:%s\n",object_name);
								CALLAPI(WSOM_copy(fld_content[i],object_name,&newItem));						
								AOM_save(newItem);
								FL_insert(project_tag,newItem,i);
							}
							AOM_save(project_tag);


							CALLAPI(AOM_ask_value_tags(project_tag,"contents",&cnt1,&prjfld_content));
							TC_write_syslog("\n Assigning %d Documents to Project\n",cnt1);
							CALLAPI(PROJ_assign_objects(1,&ootb_Project_tag,cnt1,prjfld_content));

				   }


				 MEM_free(item_tags);
				 MEM_free(fld_content);				
			//} 

	}
	else
	{
		TC_write_syslog("\nNULL Input tag\n");fflush(stdout);
	}
		  	
	
 
	 
	return ifail;
}


extern DLLAPI int createpreaction(METHOD_message_t *m,va_list args)
{
	int		       ifail=0;
	 
 
	char		   *user_id		= NULL;
	tag_t		   *list		= NULLTAG;
	int				number_found	= 0;

	TC_write_syslog("\n\nIn createpreaction\n");
	
	CALLAPI(POM_get_user_id(&user_id));      
	TC_write_syslog("Currently logged User:%s\n",user_id);

    //"Project Administration","Project Manager"
	CALLAPI(SA_find_groupmember_by_rolename("Project Administrator","Project Administration",user_id,&number_found,&list));
	if(number_found >0)
	{
		return ITK_ok;
	}
	else
	{
	
	       EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create project");	 					 	
		   return ITK_err;
	}

	return ifail;
}


extern int register_createprojpost_action(int *decision, va_list args)
{
	METHOD_id_t  method;
	int	ifail = 0;
    *decision = ALL_CUSTOMIZATIONS;
	
	 
    CALLAPI(METHOD_find_method("T8_Project", ITEM_create_msg , &method));
    if (method.id != NULLTAG)
    {
        CALLAPI(METHOD_add_action(method, METHOD_post_action_type,(METHOD_function_t)createpostaction,NULL));
		TC_write_syslog("\n\nAfter Register T8_Project createpostaction\n");
    } 

	CALLAPI(METHOD_find_method("T8_Project", ITEM_create_msg , &method));
    if (method.id != NULLTAG)
    {
        CALLAPI(METHOD_add_action(method, METHOD_pre_action_type,(METHOD_function_t)createpreaction,NULL));
		TC_write_syslog("\n\nAfter Register T8_Project createpreaction\n");
    } 

    return ifail;
}

extern DLLAPI int pcbu_create_post_register_callbacks()
{
     CUSTOM_register_exit("pcbu_create_post", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_createprojpost_action);
     TC_write_syslog("\nRegister mytest\n");
	 printf("\n ########### pcbu_create_post\n");fflush(stdout);

	 return ( ITK_ok );
}

