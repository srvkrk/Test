
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_CEDCoatedPart.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for CED Part Creation logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 23/09/2019   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>

#define T5_WorkFlowHandlerDcrErr (EMH_USER_error_base + 601)
#define T5_WorkFlowHandlerDcrErr1 (EMH_USER_error_base + 602)
#define DCR_err (EMH_USER_error_base + 405)

#define MAX_LINE_LEN 1024

//#define ITKCALL( argument )                                             \
//{                                                                       \
    //int retcode = argument;                                             \
    //if ( retcode != ITK_ok ) {                                          \
        //char* s;                                                        \
        //printf( " "#argument "\n" );                                    \
        //printf( "  returns [%d]\n", retcode );                          \
        //EMH_ask_error_text (retcode, &s);                               \
        //printf( "  Teamcenter ERROR: [%s]\n", s);           \
        //printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        //if (s != 0) MEM_free (s);                                       \
    //}                                                                   \
//}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 


char *trimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}


void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}




void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	printf("\n **setAddPartModel");fflush(stdout);
}





int relatePrimaryWithSecondaryObj(tag_t primaryTag, tag_t secondaryTag, char* relation )
{
	int ifail = ITK_ok;
	tag_t relation_type = NULLTAG;
	tag_t primSecRelation = NULLTAG;
	CALLAPI(GRM_find_relation_type(relation,&relation_type));
	if(relation_type!=NULLTAG)
	{
		CALLAPI(GRM_create_relation(primaryTag, secondaryTag, relation_type,  NULLTAG, &primSecRelation));
		CALLAPI(GRM_save_relation(primSecRelation));
	}
	else
	{
		printf("\nNo relation %s exists...Please check. Very serious error.\n",relation);fflush(stdout);
	}
	 
	return ifail;
}








int isLiveForMintDCRServ(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nCheck for control object CEDCreVl....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	
	qry_values[0] = "DCRServ";
	qry_values[1] = "DCRServ";
	
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CEDCreVl: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&name));
			CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			
			printf("\nName:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\n",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7);fflush(stdout);
					
			*contrlTag = cntrlObj;
			*result = TRUE;
			
		}
		
	}
	//T5_ControlObject	
	
	return ifail;
}






int tmCreateMintDCRServ(void *retValue)
{
	printf("\n SAN:tmCreateMintDCRServ:Start----tmCreateMintDCRServ....\n");fflush(stdout);
	
	const char	*prog_name 	="tmCreateMintDCRServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t dmlObj = NULLTAG;
	tag_t pdfObj = NULLTAG;
	char* projectCodeStr = NULL;
	char* pdfName = NULL;
	char* drGateStr = NULL;
	char* leadCOCStr = NULL;
	char* programStr = NULL;
	char* dmlSynopsis = NULL;
	char* dmlNoStr = NULL;
	char* pdfNameStr = NULL;
	char* pdfNm = NULL;

	
	USERARG_get_tag_argument(&dmlObj);
	if(dmlObj!=NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(dmlObj,"item_id",&dmlNoStr));
		printf("\nSAN:MintDCR: DML found[%s]\n",dmlNoStr);fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(dmlObj,"object_name",&dmlSynopsis));
		printf("\nSAN:MintDCR: DML dmlSynopsis[%s]\n",dmlSynopsis);fflush(stdout);
		
	}
	
	USERARG_get_tag_argument(&pdfObj);
	if(pdfObj!=NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(pdfObj,"object_name",&pdfNm));
		printf("\nSAN:MintDCR: Pdf Object[%s]\n",pdfNm);fflush(stdout);
	}
	
	
	USERARG_get_string_argument(&pdfNameStr);
	USERARG_get_string_argument(&projectCodeStr);
	USERARG_get_string_argument(&drGateStr);
	USERARG_get_string_argument(&leadCOCStr);
	USERARG_get_string_argument(&programStr);
	
	//get the string array
	int subSysLen=0;
	int affecSysLen=0;
	int reasonDCRLen=0;
	int affVehModelLen=0;
    char** subSysLst=NULL;
	char** affecSysLst=NULL;
	char** reasonDCRLst=NULL;
	char** affVehModelLst=NULL;
	
	USERARG_get_string_array_argument(&subSysLen,&subSysLst);
	USERARG_get_string_array_argument(&affecSysLen,&affecSysLst);
	USERARG_get_string_array_argument(&reasonDCRLen,&reasonDCRLst);
	USERARG_get_string_array_argument(&affVehModelLen,&affVehModelLst);
	
	
	
	
	
	printf("\nSAN MIntDCR: pdf name: %s \n",pdfNameStr);fflush(stdout);
	printf("\nSAN MIntDCR: Project Code selected: %s \n",projectCodeStr);fflush(stdout);
	printf("\nSAN MIntDCR: DR Gateway: %s \n",drGateStr);fflush(stdout);
	printf("\nSAN MIntDCR: lead COC: %s \n",leadCOCStr);fflush(stdout);
	printf("\nSAN MIntDCR: Program Name selected: %s \n",programStr);fflush(stdout);
	
	
	int i =0;
	for(i=0; i<subSysLen; i++)
	{
		printf("subSysLst[%d]==>%s\n", i,subSysLst[i]);fflush(stdout);
	}

	for(i=0; i<affecSysLen; i++)
	{
		printf("affecSysLst[%d]==>%s\n", i,affecSysLst[i]);fflush(stdout);
	}
	for(i=0; i<reasonDCRLen; i++)
	{
		printf("reasonDCRLst[%d]==>%s\n", i,reasonDCRLst[i]);fflush(stdout);
	}
	for(i=0; i<affVehModelLen; i++)
	{
		printf("affVehModelLst[%d]==>%s\n", i,affVehModelLst[i]);fflush(stdout);
	}	
	
	//Check if already DCR object is there with name as pdfNameStr. If yes then throw error.- TBD - try doing in RAC.
	
	//Create DCR Object with the pdf name
	tag_t rev_type_tag = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t dcrMaster = NULLTAG;
	
	TCTYPE_find_type("T5_DChangeReportRevision", NULL, &rev_type_tag);
	if(rev_type_tag!=NULLTAG)
	{
		tag_t dcrObjectTag = NULLTAG;
		TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
		if(dmlSynopsis==NULL) dmlSynopsis = "";
		AOM_set_value_string(rev_create_input_tag, "object_name", dmlSynopsis);
		AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1"); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5projectname", projectCodeStr);//project
		AOM_set_value_string(rev_create_input_tag, "t5_DcrCreSP", drGateStr);
		//AOM_set_value_string(rev_create_input_tag, "t5_DcrCreSP", drGateStr);
		AOM_set_value_string(rev_create_input_tag, "t5_DcrLeadCoc", leadCOCStr);
		AOM_set_value_string(rev_create_input_tag, "t5_DcrGProg", programStr);
		
		TCTYPE_find_type("T5_DChangeReport", NULL, &item_type_tag);
		if(item_type_tag!=NULLTAG)
		{
				printf("\nSAN:MinDCR Cre: item_type_tag Tag Found."); fflush(stdout);
				
		}
        else
		{
			return ifail;
		}			 
		
		TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

		AOM_set_value_string(item_create_input_tag, "item_id", pdfNameStr);
		AOM_set_value_string(item_create_input_tag, "object_name", dmlSynopsis);
		AOM_set_value_string(item_create_input_tag, "object_desc", dmlSynopsis);
		AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);		
		
		TCTYPE_create_object(item_create_input_tag, &dcrMaster);
		
		if(dcrMaster!=NULLTAG)
		{
			printf("\nSAN:MinDCR: Mint DCR Obj created."); fflush(stdout);					 
			AOM_save_without_extensions(dcrMaster);				
		}
		else
		{
			return ifail;
		}
		
		//Get DCR item revision
		tag_t * dcr_rev_list = NULLTAG;
		int dcr_item_count = 0;
		tag_t dcrRevTag = NULLTAG;
		ITEM_list_all_revs (dcrMaster, &dcr_item_count, &dcr_rev_list);
		
		if(dcr_item_count>0)
		{
			dcrRevTag = dcr_rev_list[0];
		}	

		
		//Set the attribute Mautrity, Disposition and status of DCR revision object - TBD
		
		if(dcrRevTag!=NULLTAG)
		{

			tag_t Closure = NULLTAG;
			tag_t Maturity = NULLTAG;
			tag_t Disposition = NULLTAG;
			
			CALLAPI(AOM_lock(dcrRevTag));
			CALLAPI(POM_attr_id_of_attr("CMClosure","T5_DChangeReportRevision",&Closure)); //1.43
			CALLAPI(POM_attr_id_of_attr("CMMaturity","T5_DChangeReportRevision",&Maturity));//1.43
			CALLAPI(POM_attr_id_of_attr("CMDisposition","T5_DChangeReportRevision",&Disposition));//1.43
			CALLAPI(AOM_refresh(dcrRevTag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			
			if(POM_set_attr_string(1,&dcrRevTag,Closure ,"Open"));//1.43
			if(POM_set_attr_string(1,&dcrRevTag,Maturity,"Reviewing"));//1.43
			if(POM_set_attr_string(1,&dcrRevTag,Disposition,"Approved"));//1.43
			
			CALLAPI(AOM_save_without_extensions(dcrRevTag));
			CALLAPI(AOM_unlock(dcrRevTag));	


			//Relate the pdf object to dcrRevTag
			if(pdfObj!=NULLTAG)
			{
				CALLAPI(relatePrimaryWithSecondaryObj(dcrRevTag,pdfObj,"CMReferences"));
				printf("\nPdf object is related to the DCR Object \n");fflush(stdout);	
			}
			
			
		}
		
		
		
		//Relate the DCR object to the dml object
		
		if(dmlObj!=NULLTAG)
		{
			if(dcrRevTag!=NULLTAG)
			{
				CALLAPI(relatePrimaryWithSecondaryObj(dmlObj,dcrRevTag,"CMImplements"));
				printf("\nDCR Rev  %s is related to the DML %s\n",pdfNameStr,dmlNoStr);fflush(stdout);	
			}
						
									
		}
		else
		{
			printf("\nDML object not found...\n");fflush(stdout);
		}

		
	}
	
	//End Creation of DCR Object
	
	
	
	printf("Calling  tmCreateMintDCRServ....\n");fflush(stdout);	
	printf("\n SAN:tmCreateMintDCRServ:End----tmCreateMintDCRServ....\n");fflush(stdout);
	return ifail;	
	
}



int isDR4AboveDMLForDCR(tag_t dmlTag, logical *result)
{
	int ifail = ITK_ok;
	*result = FALSE;
	if(dmlTag != NULLTAG)
	{
		char* objTyp = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&objTyp));
		printf("\nDML object type: [%s]", objTyp);fflush(stdout);
		if(tc_strcmp(objTyp,"ChangeRequestRevision")==0)
		{
			char* relzType = NULL;
			char* dmlProjCode = NULL;
			char* plntToPlnt = NULL;
			char* dmlDrStatus = NULL;
			char* tagetPlant = NULL;
			
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&relzType));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cprojectcode",&dmlProjCode));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_PlntToPlnt",&plntToPlnt));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDrStatus));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_TargetPlant",&tagetPlant));
			printf("\nRelease Type: %s\nDML Project Code: %s\nFromPlantToPlant: %s\nDml Dr Status:%s\nTarget Pant: %s\n",relzType,dmlProjCode,plntToPlnt,dmlDrStatus,tagetPlant);fflush(stdout);
			

			if(dmlDrStatus!=NULL)
			{
				if(tc_strcmp(dmlDrStatus,"DR3")==0 || tc_strcmp(dmlDrStatus,"AR3")==0 ||tc_strcmp(dmlDrStatus,"DR4")==0 || tc_strcmp(dmlDrStatus,"AR4")==0 || tc_strcmp(dmlDrStatus,"DR5")==0 || tc_strcmp(dmlDrStatus,"AR5")==0)
				{
					*result = TRUE;
				}
			}

		}
		else
		{
			printf("\nNot a valid DML Revision object\n");fflush(stdout);
		}
	}		
	
	
	return ifail;
}


int isDMLForCVBUProj(char* projId, logical *result)
{
	int ifail = ITK_ok;
	*result = FALSE;

	int  count 	= 0;
	tag_t *projObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Name";
	
	
	
	qry_values[0] = projId;

	
		
	CALLAPI(QRY_find2("Qury_Project", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &projObjs));
	printf("\n Project Objects count for id [%s]==>%d",projId, count);fflush(stdout);
	
	if(count>0)
	{
		tag_t projObj = NULLTAG;
		char* ProjectClass = NULL;
		char* ProjDesc = NULL;
		char* Proj_PltFrm = NULL;
		char* Proj_BU = NULL;
		char* Proj_Type = NULL;
		projObj = projObjs[0];
		

		CALLAPI(AOM_ask_value_string(projObj,"t5_VehicleClass",&ProjectClass));
		CALLAPI(AOM_ask_value_string(projObj,"object_desc",&ProjDesc));
		CALLAPI(AOM_ask_value_string(projObj,"t5_Program",&Proj_PltFrm));
		CALLAPI(AOM_ask_value_string(projObj,"t5_BussUnitType",&Proj_BU));
		CALLAPI(AOM_ask_value_string(projObj,"t5_ProjectType",&Proj_Type));
		printf("\n SAN: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s] Proj_Type[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU,Proj_Type);fflush(stdout);
		
		if(tc_strcmp(Proj_Type,"V")==0 &&  tc_strcmp(Proj_BU,"CVBU")==0)
		{
			*result = TRUE;
		}
		
		
	}

	
	return ifail;
}



EPM_decision_t tm_CheckDcrForCVBUDmlFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULLTAG;
	int targetobjects_count = 0;
	const char * prog_name ="tm_CheckDcrForCVBUDmlFn";
	tag_t dmlTag = NULLTAG;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
		
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
	
	CALLAPI(isLiveForMintDCRServ(&cntrlObj,&liveFlag));
	
	
	printf("\n Live for DCR check in rule handler ===> %d\n",liveFlag);fflush(stdout);
	
	if(liveFlag && cntrlObj!=NULLTAG)
	{
		logical delInd = FALSE;
		char* userInfo1 = NULL;
		char* userInfo2 = NULL;
		char* userInfo3 = NULL;
		CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		
		if(!delInd && tc_strcmp(userInfo1,"YES")==0)
		{
			printf("\n Live for action handler check for DCR....\n");fflush(stdout);
			if(targetobjects_count > 0)
			{
				int i =0;
				tag_t objectTypeTag = NULLTAG;
				char* type_name= NULL;
				char* dmlReleaseType = NULL;
				char* dmlProjCode = NULL;
				char* dmlBusUnit = NULL;
				char* dmlDrStatus = NULL;
				logical isDR4andAbove = FALSE;
				for(i=0;i<targetobjects_count;i++)
				{
					CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
					CALLAPI(TCTYPE_ask_name2( objectTypeTag,&type_name));
					printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
					if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
					{
												
						CALLAPI(isDR4AboveDMLForDCR(targetobjects[i],&isDR4andAbove));
						
						printf("\nisDR4andAbove:%d\n",isDR4andAbove);	fflush(stdout);
						if(!isDR4andAbove)
						{
							printf("\nSkip the dml as DR status is less than DR3\n");fflush(stdout);
							continue;
						}
						
						
						CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
						CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
						printf("\nDML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
						
						CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_cprojectcode",&dmlProjCode));
						printf("\nDML Project Code:%s\n",dmlProjCode);	fflush(stdout);
						
						

						
						
						
						
						CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_ERCBusiUt",&dmlBusUnit));
						printf("\nDML Business Unite:%s\n",dmlBusUnit);	fflush(stdout);
						
						CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_cDRstatus",&dmlDrStatus));
						printf("\nDML DR/AR Status:%s\n",dmlDrStatus);	fflush(stdout);
						

						
						CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
						CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));

						

						if(userInfo2!=NULL)
						{
							if(tc_strcmp(userInfo2,"")==0)
							{
								userInfo2="MR"; //Module Release type DML
							}
						}
						else
						{
							userInfo2="MR";
						}
						

						if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)
						{
							//To be implemented later based of project code to find the CVBU project
							
													//Get T5_Project
							logical isCVBU = FALSE;
							CALLAPI(isDMLForCVBUProj(dmlProjCode,&isCVBU));
							printf("\nIs CVBU Project===>%d\n",isCVBU);fflush(stdout);
							
							
							if((tc_strcmp(dmlBusUnit,"CVBU")==0 || isCVBU) && isDR4andAbove)
							{
								dmlTag = targetobjects[i];
								break;
							}
						}
						else
						{
							printf("\nNot for CVBU project...\n");fflush(stdout);
						}

						
							
					}
				}
				
				if(dmlTag !=NULLTAG)
				{
					tag_t implemRelationType_t = NULLTAG;
					tag_t* dcrTags = NULLTAG;
					int dcrCnt = 0;
					
					CALLAPI(GRM_find_relation_type("CMImplements",&implemRelationType_t));
					
					if(implemRelationType_t != NULLTAG)
					{
						CALLAPI(GRM_list_secondary_objects_only(dmlTag,implemRelationType_t,&dcrCnt,&dcrTags));
						printf("\nDCR count = %d\n",dcrCnt);fflush(stdout);
						if(dcrCnt<=0)
						{
							printf("\nNo DCR attached to DML, Hence returning EPM_nogo\n");fflush(stdout);
							char* buff = NULL;
							ifail=T5_WorkFlowHandlerDcrErr;
							buff = (char*)MEM_alloc(300*sizeof(char));
							sprintf(buff, "No DCR found for the DML Revision. DCR Is mandatory for this DML.Plz generate a PDF from Mint with name as 995-1-XXXX.pdf.Select it and create a DCR.Use the option File->New-> Document management-->Create Mint-DCR.");//san-tz1.53
							EMH_store_error_s1(EMH_severity_error,ifail,buff);
							decision = EPM_nogo;
							if(buff)MEM_free(buff);
							return decision;
						}
						else
						{
							int j=0;
							tag_t dcrTag = NULLTAG;
							int cnt = 0;
							char* dcrClassName = NULL;
							for(j=0;j<dcrCnt;j++)
							{
								dcrTag = dcrTags[j];
								CALLAPI(AOM_ask_value_string(dcrTag,"object_type",&dcrClassName));
								printf("\nDCR Class Name:%s\n",dcrClassName);	fflush(stdout);	
								if(tc_strcmp(dcrClassName,"T5_DChangeReportRevision")==0 || tc_strcmp(dcrClassName,"DCR Revision")==0)
								{
									printf("\nFound DCR object....\n");fflush(stdout);
									cnt++;
								}
								
							}
							printf("\nDCR cnt==>%d\n",cnt);fflush(stdout);
							if(cnt==0)
							{
								printf("\nNo DCR attached to DML, Hence returning EPM_nogo\n");fflush(stdout);
								char* buff = NULL;
								ifail=T5_WorkFlowHandlerDcrErr;
								buff = (char*)MEM_alloc(200*sizeof(char));
								sprintf(buff, "No DCR found for the DML Revision.");
								EMH_store_error_s1(EMH_severity_error,ifail,buff);
								decision = EPM_nogo;
								if(buff)MEM_free(buff);
								return decision;
							}
						}
						
						
					}
				}
				
				
			}
			
			
	
						
		}
		else
		{
			printf("\n NOT Live for action handler check for DCR....\n");fflush(stdout);
		}
		

	}
	

	return decision;
}


extern int t5MintDCRCreationFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 11;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//Dml Object
	input_arg_type[1]=USERARG_TAG_TYPE;//pdf Object
	input_arg_type[2]=USERARG_STRING_TYPE;//pdf name string
	input_arg_type[3]=USERARG_STRING_TYPE;//Project Code
	input_arg_type[4]=USERARG_STRING_TYPE;//DR-Gateway 
	input_arg_type[5]=USERARG_STRING_TYPE;//Lead COC
	input_arg_type[6]=USERARG_STRING_TYPE;//program
	input_arg_type[7]=USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;//Subsystems
	input_arg_type[8]=USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;//Affected Systems
	input_arg_type[9]=USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;//Reason(s) for DCR
	input_arg_type[10]=USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;//Affected Vehicle Model(s)
	
	ret_value_type = USERARG_VOID_TYPE;
 	
	
	printf("\n t5MintDCRCreationFn: Before registering tmCreateMintDCRServ userservice...");  
	ifail=USERSERVICE_register_method("tmCreateMintDCRServ",(USER_function_t)tmCreateMintDCRServ,n_args,input_arg_type,ret_value_type);
	
	
	printf("\n t5MintDCRCreationFn: After registering tmCreateMintDCRServ userservice....");  
		
	
	
	return ifail;
}


extern int tm_MintDCR_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
   //Define Rule/Action handler here
   	ifail = EPM_register_rule_handler (
							"tm_CheckDcrForCVBUDml",
							"tm_CheckDcrForCVBUDml",
							(EPM_rule_handler_t)tm_CheckDcrForCVBUDmlFn
							);	
	
    return ifail;
}



extern DLLAPI int tm_MintDCR_register_callbacks ()
{	
    int ifail    = ITK_ok;
	printf("\ntm_MintDCR_register_callbacks:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_MintDCR", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_MintDCR_register_method);
	printf("\nttm_CEDCoatedPart_register_callbacks: After registoring....");
	
	printf("\n Started- Registering user service function t5MintDCRCreationFn...");
	ifail=CUSTOM_register_exit ( "tm_MintDCR", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)t5MintDCRCreationFn);
	printf("\n Completed- Registering user service function t5MintDCRCreationFn...");
	
  return ( ITK_ok ); 
}

