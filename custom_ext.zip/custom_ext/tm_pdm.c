/****************************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *-------------------------------------------------------------------------------------
** Filename		:apl.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK
*
* History
*---------------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 05/08/2020   	Akhilesh Mittal			    Initial Code
* Description   This code has been creating project request object prior to Project 
* 				object and informing agencies about it through workflow.
* 29/06/2022	Alokesh Ghosh				CR-FY23-0029 - Organization id Addition on Project creation form in TCUA
* --------------------------------------------------------------------------------------
*******************************************************************************************/


#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

#define TC_MAJOR_VERSION 2007

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;


int PdmCreObjFunc( void *return_data )
{
	int status;
	int				ifail 						= ITK_ok;
	printf("\n********************************************************** I am in PdmCreObjFunc function");fflush(stdout);
	
	return ifail;
	/* Program Logic End*/
}
void  GetProjectUserAccessDetails( char  *Projj , char  *UsrId ,int *Gmcnt ,tag_t	**GmFound)
{
	int		n_entries = 2;
	int		countt=0;

	char	*qry_entries[2] = {"Project ID","Id"};
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t	queryTag   = NULLTAG;

	 char *Object_Name  =  NULL;

	printf("\n********************************************************** In GetProjectUserAccessDetails");

	printf( "Projj:%s\n", Projj);fflush(stdout);
	printf( "UsrId:%s\n", UsrId);fflush(stdout);
	 

				if( QRY_find2("ProjectUserAccessDet", &queryTag));
				printf("\n MT:After Prd_Project:  QRY_find2");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = Projj;
				qry_values[1] = UsrId;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, Gmcnt, GmFound));
				printf("\n MT: Gmcnt : %d\n", *Gmcnt); fflush(stdout);

//                for(countt==0;countt<*Gmcnt;countt++)
//				{
//						Object_Name  =  NULL;
//						ITKCALL(AOM_UIF_ask_value(GmFound[countt],"object_string", &Object_Name));	
//						printf("\n %s",Object_Name);fflush(stdout);
//				}

}

int PDM_SendMail_PrjGrp( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;


	int i=0,j=0,count=0,PrtCount=0;
	char *ProjReqNos=NULL;
	char *PR_PrjChfEng=NULL;
	char *PR_PrgName=NULL;
	char* chfEnggPR=NULL;
	char* OwnerMailId=NULL;
	char* ChfEnggMailId=NULL;
	char  *ObjTyp=NULL;
	tag_t chdEnggUsr = NULLTAG;
	tag_t chdEnggObj = NULLTAG;
	tag_t owning_user = NULLTAG;
	tag_t owningPerson = NULLTAG;
	int iii=0;

	char *EnvData=NULL;
	char *ToFixedMail=NULL;
	char *CCFixedMail=NULL;
	char *MailToSpecialUsers=NULL;
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	tag_t controlObjInfo2 = NULLTAG;
	CALLAPI( QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	qry_values11[0] = "ChiefEnggNotExists";
	qry_values11[1] = "NewProject" ;
	CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	printf("\n Control Object count for ChiefEnggNotExists---------->%d\n",resultCount11);fflush(stdout);
	if(resultCount11>0)
	{
		controlObjInfo2=qry_cntrlobj11[0];
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo2",&MailToSpecialUsers));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo4",&EnvData));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo5",&ToFixedMail));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo6",&CCFixedMail));
		printf("\n--------------User Information 2: %s -- [%s]",MailToSpecialUsers, EnvData);
	}
	else
	{
		tc_strdup("-",&EnvData);
	}

	if (ToFixedMail == NULL)
	{
		tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
	}
	else
	{
		if (tc_strcmp(ToFixedMail,"")==0)
		{
			tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
		}
	}
	if (CCFixedMail == NULL)
	{
		tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
	}
	else
	{
		if (tc_strcmp(CCFixedMail,"")==0)
		{
			tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
		}
	}
	
	printf("\n********************************************************** In PDM_SendMail_PrjGrp");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nPR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&ProjReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n Project Request Number Number: [%s].", ProjReqNos);fflush(stdout);
							
			if(AOM_ask_value_string(objTag,"t5_PrjChfEng",&chfEnggPR)!=ITK_ok)PrintErrorStack();
			printf("\n Chief Engg: [%s].", chfEnggPR);fflush(stdout);
							
			if(SA_find_user2(chfEnggPR, &chdEnggUsr)!=ITK_ok) PrintErrorStack();
			if(SA_ask_user_person(chdEnggUsr, &chdEnggObj)!=ITK_ok) PrintErrorStack();
			if(chdEnggObj != NULLTAG){
				CALLAPI(SA_ask_person_email_address(chdEnggObj,&ChfEnggMailId));
				if(ChfEnggMailId != NULL)
				{
					printf("\nChf Engg Mail: %s\n",ChfEnggMailId);
				}
			}
							
			if( AOM_ask_owner(objTag,&owning_user)!=ITK_ok) PrintErrorStack();
			if(owning_user!=NULLTAG){
				if( SA_ask_user_person(owning_user,&owningPerson)!=ITK_ok) PrintErrorStack();								
				CALLAPI(SA_ask_person_email_address(owningPerson,&OwnerMailId));
				if(OwnerMailId != NULL)
				{
					printf("\nCreator Mail: %s\n",OwnerMailId);
				}
			}
		
			//if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)
			if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)				
			{
					tag_t* Prj = NULL;
					int PrjRelCnt =0;
					int Pcnt =0;
					tag_t PR_Prj_rel_type = NULLTAG;
					
					char* PRObjNos=NULL;
					tag_t	ObjTypPrj	= NULLTAG;
					char*   type_name8 = NULL;
					char* PrjItemId=NULL;
					char* PrjCode=NULL;
					char* PrjDes=NULL;
				
					char* FirLcstate=NULL;
					if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
					

					if (PR_Prj_rel_type!=NULLTAG)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
						printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
						
						if (PrjRelCnt>0)
						{
							
							for (Pcnt=0;Pcnt<PrjRelCnt ;Pcnt++ )
							{	
							
								if(TCTYPE_ask_object_type(Prj[Pcnt],&ObjTypPrj));
								if(TCTYPE_ask_name2(ObjTypPrj,&type_name8));

								if(AOM_ask_value_string(Prj[Pcnt],"item_id",&PrjItemId)!=ITK_ok)PrintErrorStack();
								
							
								if (strcmp(type_name8,"T5_Project")==0)
								{
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectName",&PrjCode)==ITK_ok)
									printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
									
									if( AOM_ask_value_string(Prj[Pcnt],"current_name",&PrjDes)==ITK_ok)
									printf("\n Project Description: [%s]", PrjDes);fflush(stdout);
								
									char  *envSub	  = NULL;
									char  *envDesc	  = NULL;
									//tag_t envTag	  =NULLTAG;
									tag_t person_tag  =NULLTAG;
									char  *mailId = NULL;
									
									char*			Mail_Grp		= NULL;
									char*			eMailCC			= NULL;
									char*			eMailTo			= NULL;
									char*			buff			= NULL;
									char*			MBOMDefrolename = NULL;
									Mail_Grp=(char *) MEM_alloc(100 * sizeof(char *));
									eMailCC=(char *) MEM_alloc(1000 * sizeof(char *));
									eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
									buff=(char *) MEM_alloc(10000 * sizeof(char *));
									
									tag_t			group_tag			= NULLTAG;
									tag_t			user_tag			= NULLTAG;
									tag_t			role_tag		= NULLTAG;
									tag_t*			role_tags			= NULLTAG;
									tag_t*			member_tags			= NULLTAG;

									int				num_of_roles		= 0;
									int				num_of_members		= 0;
									int				i					= 0;
									int				j					= 0;
									
									char			rolename[SA_name_size_c+1];
									tc_strcpy(eMailCC,CCFixedMail);
									tc_strcpy(eMailTo,ToFixedMail);
									
									if(ChfEnggMailId != NULL)
									{
										if(tc_strstr(eMailCC, ChfEnggMailId)==NULL){
											tc_strcat(eMailCC,ChfEnggMailId);
											tc_strcat(eMailCC,",");
										}
									}
										
									if(OwnerMailId != NULL)
									{
										if(tc_strstr(eMailCC, OwnerMailId)==NULL){
											tc_strcat(eMailCC,OwnerMailId);
											tc_strcat(eMailCC,",");
										}
									}
									
									if(MailToSpecialUsers != NULL)
									{
										tc_strcpy(Mail_Grp,MailToSpecialUsers);
										CALLAPI(SA_find_group(Mail_Grp,&group_tag));
										if (group_tag != NULLTAG)
										{
											CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
											if (role_tags != NULLTAG)
											{
												if(num_of_roles>0)
												{
													for (i=0;i<num_of_roles ;i++ )
													{
														role_tag = role_tags[i];
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailCC, mailId)==NULL){
																					tc_strcat(eMailCC,mailId);
																					tc_strcat(eMailCC,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									
									tc_strcpy(Mail_Grp,"TS_Managers");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									
									char* orgnID=NULL;
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&orgnID)==ITK_ok)
									printf("\nOrganization ID: %s",orgnID);
									tc_strcpy(Mail_Grp,"TS_Plant_SPOC_");
									tc_strcat(Mail_Grp,orgnID);
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"APL_PLM_SPOC");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"MBOM");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_ask_role_name2(role_tag,&MBOMDefrolename));
													if (tc_strcmp(MBOMDefrolename,"MBOM_Default")==0)
													{
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailTo, mailId)==NULL){
																					tc_strcat(eMailTo,mailId);
																					tc_strcat(eMailTo,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									
									if (eMailCC != NULL) {
									    int length = tc_strlen(eMailCC);
									    if ((length > 0) && (eMailCC[length - 1] == ',')) {
									        eMailCC[length - 1] = '\0';
									    }
									}
									if (eMailTo != NULL) {
									    int length = tc_strlen(eMailTo);
									    if ((length > 0) && (eMailTo[length - 1] == ',')) {
									        eMailTo[length - 1] = '\0';
									    }
									}
									
									envSub = (char *) MEM_alloc( 1000 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 5000 * sizeof(char) );
									char* objValue=NULL;
									tc_strcpy(envSub,"New Project Request ");
									tc_strcat(envSub,ProjReqNos);
									tc_strcat(envSub," is created in ");
									tc_strcat(envSub,EnvData);
									
									tc_strcpy(envDesc,"Dear All, ");
									tc_strcat(envDesc,"\nNew project code  ' ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc," ' : ' ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectDesc",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"' is created in PLM with below details. Please ensure corresponding star++ project is created and mapped with this barrel to facilitate SOR generation and Group Access creation.");
									tc_strcat(envDesc,"\n\n");
									tc_strcat(envDesc," 1. Project Number			: ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 2. Project Description			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 3. Project Type				: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectType",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 4. Owner Design Unit			: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_DsgnOwn",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_CommercialName",&objValue)==ITK_ok)
									tc_strcat(envDesc," 5. Commercial Name			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_VehicleClass",&objValue)==ITK_ok)
									tc_strcat(envDesc," 6. Project Class				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Program",&objValue)==ITK_ok)
									tc_strcat(envDesc," 7. Program				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Description",&objValue)==ITK_ok)
									tc_strcat(envDesc," 8. Project Reference			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectClassfication",&objValue)==ITK_ok)
									tc_strcat(envDesc," 9. Project Classification			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Status",&objValue)==ITK_ok)
									tc_strcat(envDesc," 10. Status:				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ParentProductLine",&objValue)==ITK_ok)
									tc_strcat(envDesc," 11. Plant Name				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_BussUnitType",&objValue)==ITK_ok)
									tc_strcat(envDesc," 12. Business Unit			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&objValue)==ITK_ok)
									tc_strcat(envDesc," 13. Organization ID			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectID",&objValue)==ITK_ok)
									tc_strcat(envDesc," 14. NPI Ref				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjWoNo",&objValue)==ITK_ok)
									tc_strcat(envDesc," 15. Work Order No			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminPrpBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 16. Prepared By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminChkBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 17. Checked By				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminAppBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 18. Approved By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									
									printf("\n\nMAIL_initialize\n\n");
									sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
									//sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,"alokeshg.ttl@tatamotors.com","alokeshg.ttl@tatamotors.com");
									printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
									system(buff);
															
								}
							}
							
						}
						

					}
			}
		}

	}
return ITK_ok;
}

int PDM_SendMail_PrjGrp_Final( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	
	int i=0,j=0,count=0,PrtCount=0;
	char *ProjReqNos=NULL;
	char *PR_PrjChfEng=NULL;
	char *PR_PrgName=NULL;
	char* chfEnggPR=NULL;
	char* OwnerMailId=NULL;
	char* ChfEnggMailId=NULL;
	char  *ObjTyp=NULL;
	tag_t chdEnggUsr = NULLTAG;
	tag_t chdEnggObj = NULLTAG;
	tag_t owning_user = NULLTAG;
	tag_t owningPerson = NULLTAG;
	int iii=0;

	char *EnvData=NULL;
	char *ToFixedMail=NULL;
	char *CCFixedMail=NULL;
	char *MailToSpecialUsers=NULL;
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	tag_t controlObjInfo2 = NULLTAG;
	CALLAPI( QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	qry_values11[0] = "ChiefEnggNotExists" ;
	qry_values11[1] = "NewProject" ;
	CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	printf("\n Control Object count for ChiefEnggNotExists---------->%d\n",resultCount11);fflush(stdout);
	if(resultCount11>0)
	{
		controlObjInfo2=qry_cntrlobj11[0];
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo2",&MailToSpecialUsers));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo4",&EnvData));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo5",&ToFixedMail));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo6",&CCFixedMail));
		printf("\n--------------User Information 2: %s -- [%s]",MailToSpecialUsers,EnvData);
	}
	else
	{
		tc_strdup("-",&EnvData);
	}

	if (ToFixedMail == NULL)
	{
		tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
	}
	else
	{
		if (tc_strcmp(ToFixedMail,"")==0)
		{
			tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
		}
	}
	if (CCFixedMail == NULL)
	{
		tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
	}
	else
	{
		if (tc_strcmp(CCFixedMail,"")==0)
		{
			tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
		}
	}
	
	printf("\n********************************************************** In PDM_SendMail_PrjGrp_Final");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nPR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&ProjReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n Project Request Number Number: [%s].", ProjReqNos);fflush(stdout);
							
			if(AOM_ask_value_string(objTag,"t5_PrjChfEng",&chfEnggPR)!=ITK_ok)PrintErrorStack();
			printf("\n Chief Engg: [%s].", chfEnggPR);fflush(stdout);
							
			if(SA_find_user2(chfEnggPR, &chdEnggUsr)!=ITK_ok) PrintErrorStack();
			if(SA_ask_user_person(chdEnggUsr, &chdEnggObj)!=ITK_ok) PrintErrorStack();
			if(chdEnggObj != NULLTAG){
				CALLAPI(SA_ask_person_email_address(chdEnggObj,&ChfEnggMailId));
				if(ChfEnggMailId != NULL)
				{
					printf("\nChf Engg Mail: %s\n",ChfEnggMailId);
				}
			}
							
			if( AOM_ask_owner(objTag,&owning_user)!=ITK_ok) PrintErrorStack();
			if(owning_user!=NULLTAG){
				if( SA_ask_user_person(owning_user,&owningPerson)!=ITK_ok) PrintErrorStack();								
				CALLAPI(SA_ask_person_email_address(owningPerson,&OwnerMailId));
				if(OwnerMailId != NULL)
				{
					printf("\nCreator Mail: %s\n",OwnerMailId);
				}
			}
		
			//if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)
			if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)				
			{
					tag_t* Prj = NULL;
					int PrjRelCnt =0;
					int Pcnt =0;
					tag_t PR_Prj_rel_type = NULLTAG;
					
					char* PRObjNos=NULL;
					tag_t	ObjTypPrj	= NULLTAG;
					char*   type_name8 = NULL;
					char* PrjItemId=NULL;
					char* PrjCode=NULL;
					char* PrjDes=NULL;
				
					char* FirLcstate=NULL;
					
					char		**PlantNameList;
					int			num						= 0;
					char*			PLT_CodeS		= NULL;
					int			PlantName_cnt					= 0;
					PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
					char*			LivePlnt		= NULL;
					LivePlnt=(char *) MEM_alloc(100 * sizeof(char *));
					
					AOM_ask_value_strings(objTag,"t5_PrjPlantName",&num,&PlantNameList);
					printf("\n\n\tNumber of plant code is %d\n",num);
					tc_strcpy(LivePlnt,"");
					if(num > 0)
					{
						for(PlantName_cnt=0;PlantName_cnt<num;PlantName_cnt++)
						{
							tc_strcpy(PLT_CodeS,"");
							if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune CV (PCVBU)") == 0)
							{
								tc_strcpy(PLT_CodeS,"PUNE");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune PV (CARPLT)") == 0)
							{
								tc_strcpy(PLT_CodeS,"CAR");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune UV (PUVBU)") == 0)
							{
								tc_strcpy(PLT_CodeS,"UV");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Dharwad (DWD)") == 0)
							{
								tc_strcpy(PLT_CodeS,"DWD");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Sanand (AHD)") == 0)
							{
								tc_strcpy(PLT_CodeS,"AHD");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Jamshedpur (JSR)") == 0)
							{
								tc_strcpy(PLT_CodeS,"JSR");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Lucknow (LKO)") == 0)
							{
								tc_strcpy(PLT_CodeS,"LKO");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pant Nagar (PNR)") == 0)
							{
								tc_strcpy(PLT_CodeS,"UTK");
							}
							else
							{
								printf("\n\n\tOnly ECU Parts release DML can be created with design group 16\n");
							}
							
							tc_strcat(LivePlnt,PLT_CodeS);
							tc_strcat(LivePlnt,",");
							
						}
					}
					if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
					

					if (PR_Prj_rel_type!=NULLTAG)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
						printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
						
						if (PrjRelCnt>0)
						{
							
							for (Pcnt=0;Pcnt<PrjRelCnt ;Pcnt++ )
							{	
							
								if(TCTYPE_ask_object_type(Prj[Pcnt],&ObjTypPrj));
								if(TCTYPE_ask_name2(ObjTypPrj,&type_name8));

								if(AOM_ask_value_string(Prj[Pcnt],"item_id",&PrjItemId)!=ITK_ok)PrintErrorStack();
								
							
								if (strcmp(type_name8,"T5_Project")==0)
								{
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectName",&PrjCode)==ITK_ok)
									printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
									
									if( AOM_ask_value_string(Prj[Pcnt],"current_name",&PrjDes)==ITK_ok)
									printf("\n Project Description: [%s]", PrjDes);fflush(stdout);
								
									char  *envSub	  = NULL;
									char  *envDesc	  = NULL;
									//tag_t envTag	  =NULLTAG;
									tag_t person_tag  =NULLTAG;
									char  *mailId = NULL;
									
									char*			Mail_Grp		= NULL;
									char*			eMailCC		= NULL;
									char*			eMailTo		= NULL;
									char*			buff		= NULL;
									char*			MBOMDefrolename = NULL;
									Mail_Grp=(char *) MEM_alloc(100 * sizeof(char *));
									eMailCC=(char *) MEM_alloc(1000 * sizeof(char *));
									eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
									buff=(char *) MEM_alloc(10000 * sizeof(char *));
									
									tag_t			group_tag			= NULLTAG;
									tag_t			user_tag			= NULLTAG;
									tag_t			role_tag		= NULLTAG;
									tag_t*			role_tags			= NULLTAG;
									tag_t*			member_tags			= NULLTAG;

									int				num_of_roles		= 0;
									int				num_of_members		= 0;
									int				i					= 0;
									int				j					= 0;
									
									char			rolename[SA_name_size_c+1];
									tc_strcpy(eMailCC,CCFixedMail);
									tc_strcpy(eMailTo,ToFixedMail);
									
									if(ChfEnggMailId != NULL)
									{
										if(tc_strstr(eMailCC, ChfEnggMailId)==NULL){
											tc_strcat(eMailCC,ChfEnggMailId);
											tc_strcat(eMailCC,",");
										}
									}
										
									if(OwnerMailId != NULL)
									{
										if(tc_strstr(eMailCC, OwnerMailId)==NULL){
											tc_strcat(eMailCC,OwnerMailId);
											tc_strcat(eMailCC,",");
										}
									}
									
									if(MailToSpecialUsers != NULL){
										tc_strcpy(Mail_Grp,MailToSpecialUsers);
										CALLAPI(SA_find_group(Mail_Grp,&group_tag));
										if (group_tag != NULLTAG)
										{
											CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
											if (role_tags != NULLTAG)
											{
												if(num_of_roles>0)
												{
													for (i=0;i<num_of_roles ;i++ )
													{
														role_tag = role_tags[i];
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailCC, mailId)==NULL){
																					tc_strcat(eMailCC,mailId);
																					tc_strcat(eMailCC,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"TS_Managers");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									
									char* orgnID=NULL;
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&orgnID)==ITK_ok)
									printf("\nOrganization ID: %s",orgnID);
									tc_strcpy(Mail_Grp,"TS_Plant_SPOC_");
									tc_strcat(Mail_Grp,orgnID);
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"APL_PLM_SPOC");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"STDSI_SPOC_");
									tc_strcat(Mail_Grp,orgnID);
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"MBOM");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_ask_role_name2(role_tag,&MBOMDefrolename));
													if (tc_strcmp(MBOMDefrolename,"MBOM_Default")==0)
													{
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailTo, mailId)==NULL){
																					tc_strcat(eMailTo,mailId);
																					tc_strcat(eMailTo,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}

									if (eMailCC != NULL) {
									    int length = tc_strlen(eMailCC);
									    if ((length > 0) && (eMailCC[length - 1] == ',')) {
									        eMailCC[length - 1] = '\0';
									    }
									}
									if (eMailTo != NULL) {
									    int length = tc_strlen(eMailTo);
									    if ((length > 0) && (eMailTo[length - 1] == ',')) {
									        eMailTo[length - 1] = '\0';
									    }
									}
									if (LivePlnt != NULL) {
									    int length = tc_strlen(LivePlnt);
									    if ((length > 0) && (LivePlnt[length - 1] == ',')) {
									        LivePlnt[length - 1] = '\0';
									    }
									}
									
									envSub = (char *) MEM_alloc( 1000 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 5000 * sizeof(char) );
									char* objValue=NULL;
									tc_strcpy(envSub,"New project ");
									tc_strcat(envSub,PrjCode);
									tc_strcat(envSub," is made live in PLM for plant ");
									tc_strcat(envSub,LivePlnt);
									tc_strcat(envSub," [");
									tc_strcat(envSub,EnvData);
									tc_strcat(envSub,"]");
									
									tc_strcpy(envDesc,"Dear All, ");
									tc_strcat(envDesc,"\nNew project code  ' ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc," ' : ' ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectDesc",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"' is made live in PLM for plant '");
									tc_strcat(envDesc,LivePlnt);
									tc_strcat(envDesc,"' \n\n");
									tc_strcat(envDesc," 1. Project Number			: ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 2. Project Description			: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectDesc",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 3. Project Type				: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectType",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 4. Owner Design Unit			: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_DsgnOwn",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_CommercialName",&objValue)==ITK_ok)
									tc_strcat(envDesc," 5. Commercial Name			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_VehicleClass",&objValue)==ITK_ok)
									tc_strcat(envDesc," 6. Project Class				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Program",&objValue)==ITK_ok)
									tc_strcat(envDesc," 7. Program				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Description",&objValue)==ITK_ok)
									tc_strcat(envDesc," 8. Project Reference			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectClassfication",&objValue)==ITK_ok)
									tc_strcat(envDesc," 9. Project Classification			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Status",&objValue)==ITK_ok)
									tc_strcat(envDesc," 10. Status:				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 11. Plant Name				: ");
									tc_strcat(envDesc,LivePlnt);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_BussUnitType",&objValue)==ITK_ok)
									tc_strcat(envDesc," 12. Business Unit			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&objValue)==ITK_ok)
									tc_strcat(envDesc," 13. Organization ID			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectID",&objValue)==ITK_ok)
									tc_strcat(envDesc," 14. NPI Ref				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjWoNo",&objValue)==ITK_ok)
									tc_strcat(envDesc," 15. Work Order No			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminPrpBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 16. Prepared By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminChkBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 17. Checked By				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminAppBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 18. Approved By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 19. Project Request Number		: ");
									tc_strcat(envDesc,ProjReqNos);
									tc_strcat(envDesc,"\n");
									
									printf("\n\nMAIL_initialize\n\n");
									sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
									//sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,"alokeshg.ttl@tatamotors.com","alokeshg.ttl@tatamotors.com");
									printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
									system(buff);
								}
							}
							
						}
						

					}
			}
		}

	}
return ITK_ok;
}

int PDM_SendMail_PrjPlantAdd_Final( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;
	
	int i=0,j=0,count=0,PrtCount=0;
	char *ProjReqNos=NULL;
	char *item_rev_id= NULL;
	char *PR_PrjChfEng=NULL;
	char *PR_PrgName=NULL;
	char* chfEnggPR=NULL;
	char* OwnerMailId=NULL;
	char* ChfEnggMailId=NULL;
	char  *ObjTyp=NULL;
	tag_t chdEnggUsr = NULLTAG;
	tag_t chdEnggObj = NULLTAG;
	tag_t owning_user = NULLTAG;
	tag_t owningPerson = NULLTAG;
	int iii=0;
	char* AlreadyLivePlant = NULL;
	AlreadyLivePlant=(char *) MEM_alloc(200 * sizeof(char *));
	tc_strcpy(AlreadyLivePlant,"");
	
	char *MailToSpecialUsers=NULL;
	char *ToFixedMail=NULL;
	char *CCFixedMail=NULL;
	char *EnvData=NULL;
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	tag_t controlObjInfo2 = NULLTAG;
	CALLAPI( QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	qry_values11[0] = "ChiefEnggNotExists" ;
	qry_values11[1] = "NewProject" ;
	CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	printf("\n Control Object count for ChiefEnggNotExists---------->%d\n",resultCount11);fflush(stdout);
	if(resultCount11>0)
	{
		controlObjInfo2=qry_cntrlobj11[0];
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo2",&MailToSpecialUsers));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo4",&EnvData));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo5",&ToFixedMail));
		CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo6",&CCFixedMail));
		printf("\n--------------User Information 2: %s",MailToSpecialUsers);
	}
	else
	{
		tc_strdup("-",&EnvData);
	}

	if (ToFixedMail == NULL)
	{
		tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
	}
	else
	{
		if (tc_strcmp(ToFixedMail,"")==0)
		{
			tc_strdup("renuka.deshpande@tatamotors.com,",&ToFixedMail);
		}
	}
	if (CCFixedMail == NULL)
	{
		tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
	}
	else
	{
		if (tc_strcmp(CCFixedMail,"")==0)
		{
			tc_strdup("alokeshg.ttl@tatamotors.com,",&CCFixedMail);
		}
	}
	
	printf("\n********************************************************** In PDM_SendMail_PrjGrp_Final");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nPR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&ProjReqNos)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(objTag,"item_revision_id",&item_rev_id)!=ITK_ok)PrintErrorStack();
			printf("\n Project Request Number Number: [%s] [%s].", ProjReqNos,item_rev_id);fflush(stdout);

			//Check Already Exists Plants
			char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
			char **values = (char **) MEM_alloc(1 * sizeof(char *));
			int n_tags_found= 0;
			tag_t *tags_found = NULLTAG;
			attrs[0] ="item_id";
			values[0] = (char *)ProjReqNos;
			CALLAPI(ITEM_find_items_by_key_attributes(1,(const char**)attrs, (const char**)values, &n_tags_found, &tags_found));
			if(n_tags_found > 0)
			{
				int Item_count = 0;
				tag_t *rev_list = NULLTAG;
				tag_t itemPR = NULLTAG;
				tag_t itemPRRev = NULLTAG;
				itemPR = tags_found[0];
				int l = 0;
				char *RevList_rev_id= NULL;
				CALLAPI(ITEM_list_all_revs(itemPR, &Item_count, &rev_list));
				printf("\nTotal No of Project Revision found : %d",Item_count);fflush(stdout);
				for (l = 0; l < Item_count; ++l)
				{
					itemPRRev = rev_list[l];
					if(AOM_ask_value_string(itemPRRev,"item_revision_id",&RevList_rev_id)!=ITK_ok)PrintErrorStack();
					printf("\nRevision List - item_revision_id %s",RevList_rev_id);fflush(stdout);
					if (tc_strcmp(item_rev_id,RevList_rev_id)!=0)
					{
						char **PlantNameList;
						int num = 0;
						int PlantName_cnt = 0;
						AOM_ask_value_strings(itemPRRev,"t5_PrjPlantName",&num,&PlantNameList);
						printf("\n\n\tNumber of plant code is Already Live %d\n",num);
						if(num > 0)
						{
							for(PlantName_cnt=0;PlantName_cnt<num;PlantName_cnt++)
							{
								tc_strcat(AlreadyLivePlant,",");
								if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune CV (PCVBU)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"PUNE");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune PV (CARPLT)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"CAR");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune UV (PUVBU)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"UV");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Dharwad (DWD)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"DWD");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Sanand (AHD)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"AHD");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Jamshedpur (JSR)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"JSR");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Lucknow (LKO)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"LKO");
								}
								else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pant Nagar (PNR)") == 0)
								{
									tc_strcat(AlreadyLivePlant,"UTK");
								}
								else
								{
									tc_strcat(AlreadyLivePlant,"UTK");
								}
							}
						}
					}
				}
			}

							
			if(AOM_ask_value_string(objTag,"t5_PrjChfEng",&chfEnggPR)!=ITK_ok)PrintErrorStack();
			printf("\n Chief Engg: [%s].", chfEnggPR);fflush(stdout);
							
			if(SA_find_user2(chfEnggPR, &chdEnggUsr)!=ITK_ok) PrintErrorStack();
			if(SA_ask_user_person(chdEnggUsr, &chdEnggObj)!=ITK_ok) PrintErrorStack();
			if(chdEnggObj != NULLTAG){
				CALLAPI(SA_ask_person_email_address(chdEnggObj,&ChfEnggMailId));
				if(ChfEnggMailId != NULL)
				{
					printf("\nChf Engg Mail: %s\n",ChfEnggMailId);
				}
			}
							
			if( AOM_ask_owner(objTag,&owning_user)!=ITK_ok) PrintErrorStack();
			if(owning_user!=NULLTAG){
				if( SA_ask_user_person(owning_user,&owningPerson)!=ITK_ok) PrintErrorStack();								
				CALLAPI(SA_ask_person_email_address(owningPerson,&OwnerMailId));
				if(OwnerMailId != NULL)
				{
					printf("\nCreator Mail: %s\n",OwnerMailId);
				}
			}
		
			//if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)
			if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)				
			{
					tag_t* Prj = NULL;
					int PrjRelCnt =0;
					int Pcnt =0;
					tag_t PR_Prj_rel_type = NULLTAG;
					
					char* PRObjNos=NULL;
					tag_t	ObjTypPrj	= NULLTAG;
					char*   type_name8 = NULL;
					char* PrjItemId=NULL;
					char* PrjCode=NULL;
					char* PrjDes=NULL;
				
					char* FirLcstate=NULL;
					
					char		**PlantNameList;
					int			num						= 0;
					char*			PLT_CodeS		= NULL;
					int			PlantName_cnt					= 0;
					PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
					char*			LivePlnt		= NULL;
					LivePlnt=(char *) MEM_alloc(100 * sizeof(char *));
					
					AOM_ask_value_strings(objTag,"t5_PrjPlantName",&num,&PlantNameList);
					printf("\n\n\tNumber of plant code is %d\n",num);
					tc_strcpy(LivePlnt,"");
					if(num > 0)
					{
						for(PlantName_cnt=0;PlantName_cnt<num;PlantName_cnt++)
						{
							printf("\n %s  ---- New: %s",AlreadyLivePlant,PlantNameList[PlantName_cnt]); fflush(stdout);
							tc_strcpy(PLT_CodeS,"");
							if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune CV (PCVBU)") == 0 && tc_strstr(AlreadyLivePlant,",PUNE")==NULL)
							{
								tc_strcpy(PLT_CodeS,"PUNE");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune PV (CARPLT)") == 0 && tc_strstr(AlreadyLivePlant,",CAR")==NULL)
							{
								tc_strcpy(PLT_CodeS,"CAR");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune UV (PUVBU)") == 0 && tc_strstr(AlreadyLivePlant,",UV")==NULL)
							{
								tc_strcpy(PLT_CodeS,"UV");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Dharwad (DWD)") == 0 && tc_strstr(AlreadyLivePlant,",DWD")==NULL)
							{
								tc_strcpy(PLT_CodeS,"DWD");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Sanand (AHD)") == 0 && tc_strstr(AlreadyLivePlant,",AHD")==NULL)
							{
								tc_strcpy(PLT_CodeS,"AHD");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Jamshedpur (JSR)") == 0 && tc_strstr(AlreadyLivePlant,",JSR")==NULL)
							{
								tc_strcpy(PLT_CodeS,"JSR");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Lucknow (LKO)") == 0 && tc_strstr(AlreadyLivePlant,",LKO")==NULL)
							{
								tc_strcpy(PLT_CodeS,"LKO");
							}
							else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pant Nagar (PNR)") == 0 && tc_strstr(AlreadyLivePlant,",UTK")==NULL)
							{
								tc_strcpy(PLT_CodeS,"UTK");
							}
							else
							{
								tc_strcpy(PLT_CodeS,PlantNameList[PlantName_cnt]);
							}
							
							if (tc_strcmp(PLT_CodeS,"") != 0)
							{
								tc_strcat(LivePlnt,PLT_CodeS);
								tc_strcat(LivePlnt,",");
							}
						}
					}
					if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
					

					if (PR_Prj_rel_type!=NULLTAG)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
						printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
						
						if (PrjRelCnt>0)
						{
							
							for (Pcnt=0;Pcnt<PrjRelCnt ;Pcnt++ )
							{	
							
								if(TCTYPE_ask_object_type(Prj[Pcnt],&ObjTypPrj));
								if(TCTYPE_ask_name2(ObjTypPrj,&type_name8));

								if(AOM_ask_value_string(Prj[Pcnt],"item_id",&PrjItemId)!=ITK_ok)PrintErrorStack();
								
							
								if (strcmp(type_name8,"T5_Project")==0)
								{
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectName",&PrjCode)==ITK_ok)
									printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
									
									if( AOM_ask_value_string(Prj[Pcnt],"current_name",&PrjDes)==ITK_ok)
									printf("\n Project Description: [%s]", PrjDes);fflush(stdout);
								
									char  *envSub	  = NULL;
									char  *envDesc	  = NULL;
									//tag_t envTag	  =NULLTAG;
									tag_t person_tag  =NULLTAG;
									char  *mailId = NULL;
									
									char*			Mail_Grp		= NULL;
									char*			eMailCC		= NULL;
									char*			eMailTo		= NULL;
									char*			buff		= NULL;
									char*			MBOMDefrolename = NULL;
									Mail_Grp=(char *) MEM_alloc(100 * sizeof(char *));
									eMailCC=(char *) MEM_alloc(1000 * sizeof(char *));
									eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
									buff=(char *) MEM_alloc(10000 * sizeof(char *));
									
									tag_t			group_tag			= NULLTAG;
									tag_t			user_tag			= NULLTAG;
									tag_t			role_tag		= NULLTAG;
									tag_t*			role_tags			= NULLTAG;
									tag_t*			member_tags			= NULLTAG;

									int				num_of_roles		= 0;
									int				num_of_members		= 0;
									int				i					= 0;
									int				j					= 0;
									
									char			rolename[SA_name_size_c+1];
									tc_strcpy(eMailCC,CCFixedMail);
									tc_strcpy(eMailTo,ToFixedMail);
									
									if(ChfEnggMailId != NULL)
									{
										if(tc_strstr(eMailCC, ChfEnggMailId)==NULL){
											tc_strcat(eMailCC,ChfEnggMailId);
											tc_strcat(eMailCC,",");
										}
									}
										
									if(OwnerMailId != NULL)
									{
										if(tc_strstr(eMailCC, OwnerMailId)==NULL){
											tc_strcat(eMailCC,OwnerMailId);
											tc_strcat(eMailCC,",");
										}
									}
									
									if(MailToSpecialUsers != NULL){
										tc_strcpy(Mail_Grp,MailToSpecialUsers);
										CALLAPI(SA_find_group(Mail_Grp,&group_tag));
										if (group_tag != NULLTAG)
										{
											CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
											if (role_tags != NULLTAG)
											{
												if(num_of_roles>0)
												{
													for (i=0;i<num_of_roles ;i++ )
													{
														role_tag = role_tags[i];
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailCC, mailId)==NULL){
																					tc_strcat(eMailCC,mailId);
																					tc_strcat(eMailCC,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"TS_Managers");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									
									char* orgnID=NULL;
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&orgnID)==ITK_ok)
									printf("\nOrganization ID: %s",orgnID);
									tc_strcpy(Mail_Grp,"TS_Plant_SPOC_");
									tc_strcat(Mail_Grp,orgnID);
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"APL_PLM_SPOC");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"STDSI_SPOC_");
									tc_strcat(Mail_Grp,orgnID);
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
													if (member_tags != NULLTAG)
													{
														if(num_of_members>0)
														{
															for (j=0;j<num_of_members ;j++  )
															{
																CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																if(person_tag!=NULLTAG)
																{
																	tc_strcpy(mailId, NULL);
																	CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																	if(mailId != NULL)
																	{
																		if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																		{
																			printf("\n%s Group: %s",Mail_Grp,mailId);
																			if(tc_strstr(eMailTo, mailId)==NULL){
																				tc_strcat(eMailTo,mailId);
																				tc_strcat(eMailTo,",");
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									tc_strcpy(Mail_Grp,"MBOM");
									CALLAPI(SA_find_group(Mail_Grp,&group_tag));
									if (group_tag != NULLTAG)
									{
										CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
										if (role_tags != NULLTAG)
										{
											if(num_of_roles>0)
											{
												for (i=0;i<num_of_roles ;i++ )
												{
													role_tag = role_tags[i];
													CALLAPI(SA_ask_role_name2(role_tag,&MBOMDefrolename));
													if (tc_strcmp(MBOMDefrolename,"MBOM_Default")==0)
													{
														CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
														if (member_tags != NULLTAG)
														{
															if(num_of_members>0)
															{
																for (j=0;j<num_of_members ;j++  )
																{
																	CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
																	CALLAPI(SA_ask_user_person (user_tag,&person_tag));
																	if(person_tag!=NULLTAG)
																	{
																		tc_strcpy(mailId, NULL);
																		CALLAPI(SA_ask_person_email_address(person_tag,&mailId));
																		if(mailId != NULL)
																		{
																			if(tc_strstr(mailId,".")!=NULL && tc_strstr(mailId,"@")!=NULL)
																			{
																				printf("\n%s Group: %s",Mail_Grp,mailId);
																				if(tc_strstr(eMailTo, mailId)==NULL){
																					tc_strcat(eMailTo,mailId);
																					tc_strcat(eMailTo,",");
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}

									if (eMailCC != NULL) {
									    int length = tc_strlen(eMailCC);
									    if ((length > 0) && (eMailCC[length - 1] == ',')) {
									        eMailCC[length - 1] = '\0';
									    }
									}
									if (eMailTo != NULL) {
									    int length = tc_strlen(eMailTo);
									    if ((length > 0) && (eMailTo[length - 1] == ',')) {
									        eMailTo[length - 1] = '\0';
									    }
									}
									if (LivePlnt != NULL) {
									    int length = tc_strlen(LivePlnt);
									    if ((length > 0) && (LivePlnt[length - 1] == ',')) {
									        LivePlnt[length - 1] = '\0';
									    }
									}
									
									envSub = (char *) MEM_alloc( 1000 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 5000 * sizeof(char) );
									char* objValue=NULL;
									tc_strcpy(envSub,"Project ");
									tc_strcat(envSub,PrjCode);
									tc_strcat(envSub," is made live for New Plant ");
									tc_strcat(envSub,LivePlnt);
									//tc_strcat(envSub,"' [TCUA]");
									tc_strcat(envSub," [");
									tc_strcat(envSub,EnvData);
									tc_strcat(envSub,"]");
									
									tc_strcpy(envDesc,"Dear All, ");
									tc_strcat(envDesc,"\nProject Code  ' ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc," ' : ' ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectDesc",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"' is made live in PLM for New Plant '");
									tc_strcat(envDesc,LivePlnt);
									tc_strcat(envDesc,"' \n\n");
									tc_strcat(envDesc," 1. Project Number			: ");
									tc_strcat(envDesc,PrjCode);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 2. Project Description			: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectDesc",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 3. Project Type				: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectType",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 4. Owner Design Unit			: ");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_DsgnOwn",&objValue)==ITK_ok)
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_CommercialName",&objValue)==ITK_ok)
									tc_strcat(envDesc," 5. Commercial Name			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_VehicleClass",&objValue)==ITK_ok)
									tc_strcat(envDesc," 6. Project Class				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Program",&objValue)==ITK_ok)
									tc_strcat(envDesc," 7. Program				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Description",&objValue)==ITK_ok)
									tc_strcat(envDesc," 8. Project Reference			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectClassfication",&objValue)==ITK_ok)
									tc_strcat(envDesc," 9. Project Classification			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_Status",&objValue)==ITK_ok)
									tc_strcat(envDesc," 10. Status:				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 11. Plant Name				: ");
									tc_strcat(envDesc,LivePlnt);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_BussUnitType",&objValue)==ITK_ok)
									tc_strcat(envDesc," 12. Business Unit			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjOrgnId",&objValue)==ITK_ok)
									tc_strcat(envDesc," 13. Organization ID			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectID",&objValue)==ITK_ok)
									tc_strcat(envDesc," 14. NPI Ref				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjWoNo",&objValue)==ITK_ok)
									tc_strcat(envDesc," 15. Work Order No			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminPrpBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 16. Prepared By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminChkBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 17. Checked By				: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									if( AOM_ask_value_string(Prj[Pcnt],"t5_AdminAppBy",&objValue)==ITK_ok)
									tc_strcat(envDesc," 18. Approved By			: ");
									tc_strcat(envDesc,objValue);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 19. Project Request Number		: ");
									tc_strcat(envDesc,ProjReqNos);
									tc_strcat(envDesc,"\n");
									tc_strcat(envDesc," 20. Already Live in Plants		: ");
									tc_strcat(envDesc,AlreadyLivePlant);
									tc_strcat(envDesc,"\n");
									
									printf("\n\nMAIL_initialize\n\n");
									sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
									//sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,"alokeshg.ttl@tatamotors.com","alokeshg.ttl@tatamotors.com");
									printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
									system(buff);
								}
							}
							
						}
						

					}
			}
		}

	}
return ITK_ok;
}

extern EPM_decision_t DLLAPI Chk_GrpRolePrjUsrAccCre(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;		
	char*  	type_name = NULL;

	tag_t *attachments = NULLTAG;

	tag_t *parents = NULLTAG;
	tag_t PRLcmTag = NULLTAG;
	int i=0;
	tag_t objTypeTag = NULLTAG;


	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	char		**PlantNameList;
	int			num						= 0;
	int			PlantName_cnt					= 0;
	char*			PLT_CodeS		= NULL;
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	int ProjectAccessFound=0;
	
	printf("\n******************************************************************* inside Chk_GrpRolePrjUsrAccCre \n"); fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n inside Chk_GrpRolePrjUsrAccCre \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nSVR DML CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments in Plnat DML check :%d",count);	

	if(count > 0)
	{
		 for(i=0;i<count;i++)
		 {
			PRLcmTag = attachments[i];
			CALLAPI(AOM_ask_value_string(PRLcmTag,"current_name",&t5current_name));
			printf("\n Project Request name:%s",t5current_name);fflush(stdout); 
			
			CALLAPI(TCTYPE_ask_object_type (PRLcmTag, &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
			{
					tag_t* Prj = NULL;
					int PrjRelCnt =0;
					int Pcnt =0;
					tag_t PR_Prj_rel_type = NULLTAG;
					
					char* PRObjNos=NULL;
					tag_t	ObjTypPrj	= NULLTAG;
					char*   type_name8 = NULL;
					char* PrjItemId=NULL;
					char* PrjCode=NULL;
					
					
					char* FirLcstate=NULL;
					if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
					

					if (PR_Prj_rel_type!=NULLTAG)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
						printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
						
						if (PrjRelCnt>0)
						{
							
							for (Pcnt=0;Pcnt<PrjRelCnt ;Pcnt++ )
							{	
							
								if(TCTYPE_ask_object_type(Prj[Pcnt],&ObjTypPrj));
								if(TCTYPE_ask_name2(ObjTypPrj,&type_name8));

								if(AOM_ask_value_string(Prj[Pcnt],"item_id",&PrjItemId)!=ITK_ok)PrintErrorStack();
								
							
								if (strcmp(type_name8,"T5_Project")==0)
								{
									//AOM_UIF_ask_value(Prj[Pcnt],"project_ids",&PrjCode);
									//printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
									if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectName",&PrjCode)==ITK_ok)
									printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
								}
							}
							
						}
						

					}
					AOM_ask_value_strings(attachments[i],"t5_PrjPlantName",&num,&PlantNameList);
					printf("\n\n\tNumber of plant code is %d\n",num);
					
				if(num > 0)
				{
				for(PlantName_cnt=0;PlantName_cnt<num;PlantName_cnt++)
				{
					printf("\n\n\tloop number %d plant code is %s\n",PlantName_cnt,PlantNameList[PlantName_cnt]);
					
					ProjectAccessFound=0;
					
					if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune CV (PCVBU)") == 0)
					{
						tc_strcpy(PLT_CodeS,"PUNE");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune PV (CARPLT)") == 0)
					{
						tc_strcpy(PLT_CodeS,"CAR");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pune UV (PUVBU)") == 0)
					{
						tc_strcpy(PLT_CodeS,"UV");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Dharwad (DWD)") == 0)
					{
						tc_strcpy(PLT_CodeS,"DWD");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Sanand (AHD)") == 0)
					{
						tc_strcpy(PLT_CodeS,"AHD");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Jamshedpur (JSR)") == 0)
					{
						tc_strcpy(PLT_CodeS,"JSR");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Lucknow (LKO)") == 0)
					{
						tc_strcpy(PLT_CodeS,"LKO");
					}
					else if(tc_strcmp(PlantNameList[PlantName_cnt], "Pant Nagar (PNR)") == 0)
					{
						tc_strcpy(PLT_CodeS,"UTK");
					}
					else
					{
						printf("\n\n\tOnly ECU Parts release DML can be created with design group 16\n");
					}
					char*			APL_Plnr_Grp		= NULL;
					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));


					tag_t			group_tag			= NULLTAG;
					tag_t			user_tag			= NULLTAG;
					tag_t			role_tag		= NULLTAG;

					tag_t*			role_tags			= NULLTAG;
					tag_t*			member_tags			= NULLTAG;

					int				num_of_roles		= 0;
					int				num_of_members		= 0;
					int				i					= 0;
					int				j					= 0;
					
					char* rolename = NULL;
					char* userid = NULL;
					int Gmcnt1=0;
					int countt=0;
					tag_t	*GmFound1 = NULLTAG;
					char *Object_Name  =  NULL;
					
					tc_strcpy(APL_Plnr_Grp,"APL");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);
					//tc_strcpy(APL_Plnr_Grp,"00_APLJ_Planner");
					
					printf("\n Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);
					
					CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
					if (group_tag != NULLTAG)
					{
						CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

						printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
						if (role_tags != NULLTAG)
						{
						//flgRoleFnd=false;
							if(num_of_roles>0)
							{
								for (i=0;i<num_of_roles ;i++ )
								{
									CALLAPI( SA_ask_role_name2(role_tags[i],&rolename));
									printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
									if((strstr(rolename,"APL") && strstr(rolename,"Reviewer")) || (strstr(rolename,"APL") && strstr(rolename,"Planner")) || (strstr(rolename,"APL") && strstr(rolename,"Default")==NULL )) 
									{
									role_tag = role_tags[i];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if (member_tags != NULLTAG)
									{
										if(num_of_members>0)
												{
													for (j=0;j<num_of_members ;j++  )
													{
														CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
														CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
														printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
														ProjectAccessFound=0;
														Gmcnt1=0;
														GmFound1 = NULLTAG;
														printf("\n Project Code is: %s \n",PrjCode);fflush(stdout);
														GetProjectUserAccessDetails(PrjCode,userid,&Gmcnt1,&GmFound1);
														printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
														
														countt=0;
														for(countt==0;countt<Gmcnt1;countt++)
														{
																Object_Name  =  NULL;
																CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
																printf("\n after func :  %s",Object_Name);fflush(stdout);
															
																//if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Planner") && strstr(Object_Name,"Default")==NULL) 
																if(strstr(Object_Name,APL_Plnr_Grp) && (strstr(Object_Name,"Planner") || strstr(Object_Name,"Reviewer") || strstr(Object_Name,"Default")==NULL) )
																{
																	printf("\n Condition Satisfy... ");fflush(stdout);
																	ProjectAccessFound=1;
																	break;
																}
																else
																{
																	printf("\n Not Valide :  %s",Object_Name);fflush(stdout);
																}
														}
														if(ProjectAccessFound==1)
														{
															printf("\n Found Group[%s] Role[%s] and user access : [%s] For Plant Name[%s]",APL_Plnr_Grp,rolename,userid,PLT_CodeS);fflush(stdout);
															break;
														}
													}
												}
									}
								}
								else
								{
									printf("\n Not Valide Member %s",rolename);fflush(stdout);
								}
								if(ProjectAccessFound==1)
								{
									printf("\n Found Group[%s] Role[%s] and user access : [%s] For Plant Name[%s]",APL_Plnr_Grp,rolename,userid,PLT_CodeS);fflush(stdout);
									break;
								}
							}
							}
					   }
					   else
						{
							printf("\n Role Not found");fflush(stdout);
						}
					}
					else
					{
						printf("\n Group Not found");fflush(stdout);
					}
					printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
					if(ProjectAccessFound==0)
					{
						printf("\n Access not found ProjectAccessFound:%d for Plant[%s]",ProjectAccessFound,PLT_CodeS);fflush(stdout);
						break;
					}
					else
					{
						printf("\n Access found ProjectAccessFound:%d for Plant[%s]",ProjectAccessFound,PLT_CodeS);fflush(stdout);
					}
				}
				if(ProjectAccessFound==1)
				{
					printf("\n Groups/Role Project Request is created");fflush(stdout);
					decision = EPM_go;	
				}
				else
				{
					printf("\n Either Groups/Role are not available or Users are not mapped for newly created object.You cannot do signoff until & unless users are mapped. ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err," Either Groups/Role are not available or Users are not mapped for newly created object.You cannot do signoff until & unless users are mapped. Raise PFIRST request for APL Group acccess of PROJECT");
					decision = EPM_nogo;
					return decision;
				}
			}
			else
			{
				printf("\n\n\t Plant is not selected.Please select at least one Plant Name.\n");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err," Plant is not selected.Please select at least one Plant Name.");
				decision = EPM_nogo;
				return decision;
			}

					
			}
		}
	 
	}  
		
	
	
	return decision;
}

extern EPM_decision_t DLLAPI Chk_MBOMApplicable(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;		
	char*  	type_name = NULL;

	tag_t *attachments = NULLTAG;

	tag_t *parents = NULLTAG;
	tag_t PRLcmTag = NULLTAG;
	int i=0;
	int j=0;
	tag_t objTypeTag = NULLTAG;
	char *MBOMApp = NULL;
	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	
	printf("\n******************************************************************* inside Chk_MBOMApplicable \n"); fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n inside Chk_MBOMApplicable \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments in check :%d",count);	

	if(count > 0)
	{
		for(i=0;i<count;i++)
		{
			PRLcmTag = attachments[i];
			CALLAPI(AOM_ask_value_string(PRLcmTag,"current_name",&t5current_name));
			printf("\n Project Request name:%s",t5current_name);fflush(stdout); 
			
			CALLAPI(TCTYPE_ask_object_type (PRLcmTag, &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
			{
				CALLAPI(AOM_ask_value_string(attachments[i],"t5_MBOMApplicability",&MBOMApp));
				printf("\nt5_MBOMApplicability -> %s",MBOMApp); fflush(stdout);
				if (MBOMApp != NULL)
				{
					if (tc_strcmp(MBOMApp,"Yes")==0 || tc_strcmp(MBOMApp,"No")==0)
					{
						printf("\n MBOM Applicability Updated");fflush(stdout);
						decision = EPM_go;
					}
					else
					{
						printf("\nt5_MBOMApplicability -> BLANK"); fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Please update the value of MBOM Applicability on Project Request Object. Edit Properties -> All -> Scroll Down -> Click on Show empty properties... -> MBOM Applicability (Yes / No)");
						decision = EPM_nogo;
						return decision;
					}
				}
				else
				{
					printf("\nt5_MBOMApplicability -> NULL"); fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please update the value of MBOM Applicability on Project Request Object. Edit Properties -> All -> Scroll Down -> Click on Show empty properties... -> MBOM Applicability (Yes / No)");
					decision = EPM_nogo;
					return decision;
				}
			}
		}
	}  
	return decision;
}
extern EPM_decision_t DLLAPI Chk_PlantDMLCre(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;		
	char*  	type_name = NULL;

	tag_t *attachments = NULLTAG;

	tag_t *parents = NULLTAG;
	tag_t PRLcmTag = NULLTAG;
	int i=0;
	int j=0;
	tag_t objTypeTag = NULLTAG;


	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	
	printf("\n******************************************************************* inside Chk_PlantDMLCre \n"); fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n inside Chk_PlantDMLCre \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nSVR DML CurrentTask:%s\n",CurrentTask);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments in Plnat DML check :%d",count);	

	if(count > 0)
	{
		for(i=0;i<count;i++)
		{
			PRLcmTag = attachments[i];
			CALLAPI(AOM_ask_value_string(PRLcmTag,"current_name",&t5current_name));
			printf("\n Project Request name:%s",t5current_name);fflush(stdout); 
			
			CALLAPI(TCTYPE_ask_object_type (PRLcmTag, &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
			{
					tag_t* Prj = NULL;
					int PrjRelCnt =0;
					int Pcnt =0;
					tag_t PR_Prj_rel_type = NULLTAG;
					
					char* PRObjNos=NULL;
					tag_t	ObjTypPrj	= NULLTAG;
					char*   type_name8 = NULL;
					char* PrjItemId=NULL;
					char* PrjCode=NULL;
					char		**PlantNameList;
					int			num						= 0;
					int PlantName_cnt = 0;
					char*			PLT_CodeS		= NULL;
					PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	
					char* FirLcstate=NULL;
					if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
					

					if (PR_Prj_rel_type!=NULLTAG)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
						if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
						printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
						
						AOM_ask_value_strings(attachments[i],"t5_PrjPlantName",&num,&PlantNameList);
						printf("\n\n\tNumber of plant code is %d\n",num);
						
							if (PrjRelCnt>0)
							{
								
								for (Pcnt=0;Pcnt<PrjRelCnt ;Pcnt++ )
								{	
								
									if(TCTYPE_ask_object_type(Prj[Pcnt],&ObjTypPrj));
									if(TCTYPE_ask_name2(ObjTypPrj,&type_name8));

									if(AOM_ask_value_string(Prj[Pcnt],"item_id",&PrjItemId)!=ITK_ok)PrintErrorStack();
									
								
									if (strcmp(type_name8,"T5_Project")==0)
									{
										//AOM_UIF_ask_value(Prj[Pcnt],"project_ids",&PrjCode);
										//printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
										
										if( AOM_ask_value_string(Prj[Pcnt],"t5_ProjectName",&PrjCode)==ITK_ok)
										printf("\n Project: [%s]. project code: [%s]", PrjItemId,PrjCode);fflush(stdout);
										
										
										tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
										tag_t cntr_obj = NULLTAG;
										int	n_entries = 3;
										int n_found = 0;
										printf("\n CurrentTask:%s\n",CurrentTask);
										char *qry_entries[3] = {"Name", "SUBSYSCD" , "Delete Indicator"};
										char *qry_values[3] = {"PlantDML", PrjCode , "0"};
										char*			UsrInfo		= NULL;
										char*			infomationStr	= NULL;
										infomationStr=(char *) MEM_alloc(100 * sizeof(char *));
										tc_strcpy(infomationStr,"");
										if( QRY_find2("Control Objects...", &TagQryContObj));

										if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
										printf("\n Objects for Query ControlObjQry == %d", n_found);fflush(stdout);
										if (n_found>0)
										{
											if(num > n_found){
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"All Plant DML is not available in Control Object. Please create Control Object for All Plants before complete the assignment ");
												decision = EPM_nogo;
												return decision;
											}
											else{
												printf("\n Control object for plant DML is created");fflush(stdout);
												decision = EPM_go;
											}											
										}
										else
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err," Plant DML is not created.Please create the PLant DML before complete the assignment ");
											decision = EPM_nogo;
											return decision;
										}
									}
								}
							}
					}
				
			}
		}
	}  
	return decision;
}

extern EPM_decision_t DLLAPI Chk_ProjectRelWithPR(EPM_rule_message_t msg)
{
		int count,i = 0;
		tag_t root_task=NULLTAG;
		EPM_decision_t decision;
		tag_t *attachments = NULL;
		tag_t objTypeTag = NULLTAG;
		tag_t objTypeTagTP = NULLTAG;
	
		 
		char*  	type_name = NULL;
		int ifail=0;
		printf("\n********************************************************** Inside Chk_ProjectRelWithPR");
		CALLAPI(EPM_ask_root_task(msg.task,&root_task));

		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count);	 
		if(count>0)
		{
		  for(i=0;i<count;i++)
		  {			
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n\n\t\t type_name ==> %s\n", type_name);fflush(stdout);

			if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
			{
				
				tag_t* Prj = NULL;
				int PrjRelCnt =0;
				tag_t PR_Prj_rel_type = NULLTAG;
				char* PRObjNos=NULL;
				
				if(GRM_find_relation_type("T5_ProjReqRel", &PR_Prj_rel_type)!=ITK_ok)PrintErrorStack();
				

				if (PR_Prj_rel_type!=NULLTAG)
				{
					if(AOM_ask_value_string(attachments[i],"item_id",&PRObjNos)!=ITK_ok)PrintErrorStack();
					if(GRM_list_secondary_objects_only(attachments[i],PR_Prj_rel_type,&PrjRelCnt,&Prj)!=ITK_ok)PrintErrorStack();
					printf("\n PR Prj: %d",PrjRelCnt);fflush(stdout);
					
					if (PrjRelCnt==0)
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Project is not created. Please create the project.\n");	
						decision = EPM_nogo;						
						return decision;	
					}
					

				}
			}
		  }
		}

		decision = EPM_go;
		return decision;

}

int tm_validate_prjCre( METHOD_message_t *msg, va_list args ){
	int ifail=ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	
	if(new_item != NULLTAG && isnew ==1)
	{
		char *item_id 	   = NULL;
		char *PrjReqNo 	   = NULL;
		char *PrjReqNo1 	   = NULL;
		char *PrjReqChfEng 	   = NULL;
		char *itemRevId 	   = NULL;
		char *type_name = NULL;
		char *BussUnitType = NULL;
		char *ProjWBS = NULL;
		char *projNumStr = NULL;
		//tag_t Fndrelation = NULLTAG;
		int	 num,mad	   = 0;
		tag_t ProjectNum = NULLTAG;
		printf("\n*********************************************************** inside class Pre Action tm_validate_prjCre......\n");fflush(stdout);
		CALLAPI(AOM_ask_value_string( new_item, "item_id", &item_id));
		CALLAPI(AOM_ask_value_string( new_item, "t5_PrjPJReqNO", &PrjReqNo));
		CALLAPI(AOM_ask_value_string( new_item, "t5_BussUnitType", &BussUnitType));
		CALLAPI(AOM_ask_value_string( new_item, "t5_ProjWoNo", &ProjWBS));
		
		if ((SA_ask_current_project(&ProjectNum))!=ITK_ok)PrintErrorStack();
		if(ProjectNum !=NULLTAG)
		{
			if (AOM_ask_value_string(ProjectNum,"object_name",&projNumStr)!=ITK_ok)PrintErrorStack();
			printf("\nProject for login user session : %s\n",projNumStr);fflush(stdout);
			
			if(projNumStr != NULL){
				printf("\nSession Project Number : %s",projNumStr); fflush(stdout);
				if (strcmp(projNumStr,"")!=0){
					printf("\nYou have selected Existing Project Code in your Login Session. Please remove Project Code from your Login Session");
					EMH_store_error_s1(EMH_severity_error,ITK_err, "You have selected Existing Project Code in your Login Session. Please remove Project Code from your Login Session");
					return ITK_err;
				}
			}
		}
	
		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n PrjReqNo : %s\n",PrjReqNo);fflush(stdout);
		printf("\n BussUnitType : %s\n",BussUnitType);fflush(stdout);
		printf("\n ProjWBS : %s\n",ProjWBS);fflush(stdout);	
		
		if(strcmp(BussUnitType,"PCBU")!=0){
			if(ProjWBS != NULL){
				if(strcmp(ProjWBS,"")==0){
					printf("\nPlease enter a valid Work Breakdown Structure(WBS) \n WBS is mandatory for Business Unit other than PCBU");
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Please enter a valid Work Breakdown Structure(WBS) \n WBS is mandatory for Business Unit other than PCBU");
					return ITK_err;
				}
			}
			else{
				printf("\nPlease enter a valid Work Breakdown Structure(WBS) \n WBS is mandatory for Business Unit other than PCBU");
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Please enter a valid Work Breakdown Structure(WBS) \n WBS is mandatory for Business Unit other than PCBU");
				return ITK_err;
			}
		}
		printf("\nAfter WBS Check");
		int number_found,secobjectcnt;
		int	status;
		tag_t *list_of_WSO_tags=NULLTAG;
		WSO_search_criteria_t  	criteria;
		tag_t prjreqobjRev			=	NULLTAG;
		tag_t relation_type = NULLTAG;
		tag_t *secondary_obj = NULLTAG;
			
		CALLAPI(WSOM_clear_search_criteria(&criteria));
		strcpy(criteria.name,PrjReqNo);
		strcpy(criteria.class_name,"T5_ProjectReqRevision");
		CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));			
			
		printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);
			
		if(number_found > 0)
		{
			tag_t objType	= NULLTAG;
			prjreqobjRev=list_of_WSO_tags[0];
				
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "item_id", &PrjReqNo1));
			printf("\n PrjReqNo : %s\n",PrjReqNo1);fflush(stdout);
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "t5_PrjChfEng", &PrjReqChfEng));
			printf("\n PrjReqChfEng : %s\n",PrjReqChfEng);fflush(stdout);
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "item_revision_id", &itemRevId));
			printf("\n item_revision_id : %s\n",itemRevId);fflush(stdout);
			
			if(GRM_find_relation_type("T5_ProjReqRel",&relation_type)!=ITK_ok) PrintErrorStack();
			printf("\nChecking relation_type");
			if(relation_type!= NULLTAG){
				printf("\nChecking Secondary Obj");
				ifail = GRM_list_secondary_objects_only(prjreqobjRev, relation_type, &secobjectcnt, &secondary_obj);
				printf("\nChecking Existing Relation");
				//if(GRM_find_relation( prjreqobjRev, secondary_obj[0], relation_type, &Fndrelation)!=ITK_ok) PrintErrorStack();
				if(secondary_obj != NULLTAG)
				{
					printf("\n\t Relation Already Exist..........\n\n" );fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Project relation already exists in the Project Request.");
					return ITK_err;
				}
				else
				{
					printf("\n\t Relation doesnot Exist..........\n Going to Post Action tm_create_prjrel\n" );fflush(stdout);
					return ITK_ok;
				}
			}
			else{
				printf("\n\t Not Valid relation_type \n\n" );fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err, "T5_ProjReqRel is not a Valid relation_type.");
				return ITK_err;
			}	
		}
		else{
			printf("\nNo valid project found");
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Entered Project Request Number is not valid.");
			return ITK_err;
		}
		MEM_free(list_of_WSO_tags);
	}
	return ITK_ok;
}
int tm_create_prjrel( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	printf("\n Project Created ");fflush(stdout);
	printf("\n Project New %d ",isnew);fflush(stdout);
	
	if(new_item != NULLTAG && isnew ==1)
	{
		char *item_id 	   = NULL;
		char *PrjReqNo 	   = NULL;
		char *PrjReqNo1 	   = NULL;
		char *PrjReqChfEng 	   = NULL;
		char *itemRevId 	   = NULL;
		char *type_name = NULL;
		//tag_t Fndrelation = NULLTAG;
		int	 num,mad	   = 0;
		printf("\n *********************************************************** inside class Post Action tm_create_prjrel......\n");fflush(stdout);
		CALLAPI(AOM_ask_value_string( new_item, "item_id", &item_id));
		CALLAPI(AOM_ask_value_string( new_item, "t5_PrjPJReqNO", &PrjReqNo));
	
		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n PrjReqNo : %s\n",PrjReqNo);fflush(stdout);
		
		int number_found,secobjectcnt;
		int	status;
		tag_t *list_of_WSO_tags=NULLTAG;
		WSO_search_criteria_t  	criteria;
		tag_t prjreqobjRev			=	NULLTAG;
		tag_t relation_type = NULLTAG;
		tag_t *secondary_obj = NULLTAG;
			
		CALLAPI(WSOM_clear_search_criteria(&criteria));
		strcpy(criteria.name,PrjReqNo);
		strcpy(criteria.class_name,"T5_ProjectReqRevision");
		CALLAPI(WSOM_search(criteria, &number_found, &list_of_WSO_tags));			
			
		printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);
			
		if(number_found > 0)
		{
			tag_t objType	= NULLTAG;
			prjreqobjRev=list_of_WSO_tags[0];
				
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "item_id", &PrjReqNo1));
			printf("\n PrjReqNo : %s\n",PrjReqNo1);fflush(stdout);
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "t5_PrjChfEng", &PrjReqChfEng));
			printf("\n PrjReqChfEng : %s\n",PrjReqChfEng);fflush(stdout);
			CALLAPI(AOM_ask_value_string( prjreqobjRev, "item_revision_id", &itemRevId));
			printf("\n item_revision_id : %s\n",itemRevId);fflush(stdout);
			
			if(GRM_find_relation_type("T5_ProjReqRel",&relation_type)!=ITK_ok) PrintErrorStack();
			
			if(relation_type!= NULLTAG){
				ifail = GRM_list_secondary_objects_only(prjreqobjRev, relation_type, &secobjectcnt, &secondary_obj);
				
				//if(GRM_find_relation( prjreqobjRev, secondary_obj[0], relation_type, &Fndrelation)!=ITK_ok) PrintErrorStack();
			
				if(secondary_obj != NULLTAG)
				{
					printf("\n\t Relation Already Exist..........\n\n" );fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Project relation already exists in the Project Request.");
					return ITK_err;
				}
				else
				{
					printf("\n\t Relation doesnot Exist..........\n\n" );fflush(stdout);
					tag_t relation = NULLTAG;
					GRM_create_relation(prjreqobjRev,new_item, relation_type, NULLTAG, &relation);
					printf("\n Relation Created \n");fflush(stdout);
					GRM_save_relation(relation);
					printf("\n Saving Relation finally \n");fflush(stdout);
				}
			}
			else{
				printf("\n\t Not Valid relation_type \n\n" );fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err, "T5_ProjReqRel is not a Valid relation_type.");
				return ITK_err;
			}	
		}
		else{
			printf("\nNo valid project found");
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Entered Project Request Number is not valid.");
			return ITK_err;
		}
		MEM_free(list_of_WSO_tags);
	}
	return ITK_ok;
}

extern EPM_decision_t DLLAPI Chk_PR_active(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	
	char*			Tr_Domain_Approved				=NULL;	
	char*			TR_Domain				=NULL;	
	char*  	type_name = NULL;
	tag_t Attachrelation_type=NULLTAG;
	int cnt1=0;
	tag_t *attachments1;
	tag_t *attachments = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t PRLcmTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	printf("\n********************************************************** Inside Chk_PR_active");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nPDM CurrentTask33333333333:%s\n",CurrentTask);
	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments444444444444:%d",count);	

	if(count > 0)
	{
		PRLcmTag = attachments[0];
		CALLAPI(AOM_ask_value_string(PRLcmTag,"current_name",&t5current_name));
		printf("\n PR name:%s",t5current_name);fflush(stdout); 
		CALLAPI(EPM_ask_active_job_for_target(PRLcmTag,&n_parents,&parents));
		printf("\n PR lifecycle count :%d\n",n_parents); fflush(stdout);

		if (n_parents>1)
		{
			CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
			printf("\n PR already in lifecycle:%s\n",procedure_name); fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Project Request Object already submitted in WorkFlow");
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			decision = EPM_go;
		}

		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		int n_tags_found= 0;
		tag_t *tags_found = NULLTAG;
		attrs[0] ="item_id";
		values[0] = (char *)t5current_name;
		CALLAPI(ITEM_find_items_by_key_attributes(1,(const char**)attrs, (const char**)values, &n_tags_found, &tags_found));
		if(n_tags_found > 0)
		{
			int Item_count = 0;
			tag_t *rev_list = NULLTAG;
			tag_t itemPR = NULLTAG;
			itemPR = tags_found[0];
			CALLAPI(ITEM_list_all_revs(itemPR, &Item_count, &rev_list));
			printf("\nTotal No of Project Revision found : %d",Item_count);fflush(stdout);
			if (Item_count > 1)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "For New Plant addition submit into New Plant Addition Workfow");
				decision = EPM_nogo;
				return decision;
			}
		}

		CALLAPI(TCTYPE_ask_object_type (PRLcmTag, &objTypeTag));
		CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
		printf("\n\n\t\t Submitted Object Type==> %s\n", type_name);fflush(stdout);
		if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
		{
			GRM_find_relation_type("TC_Attaches",&Attachrelation_type);
			if(Attachrelation_type != NULLTAG)
			{
				GRM_list_secondary_objects_only(PRLcmTag,Attachrelation_type,&cnt1,&attachments1);
				printf("\n project request Datasets:%d\n",cnt1);fflush(stdout);
				if(cnt1>0)
				{
					printf("\n project request Datasets found");fflush(stdout);
					decision = EPM_go;
				}
				else
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, "Project Request Object necessary doc is not attached.Please attach and then submit to workFlow.");
					decision = EPM_nogo;
					return decision;
				}
			}
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Invalid Object Type. Select only Project Request Revision and then submit to workFlow.");
			decision = EPM_nogo;
			return decision;
		}
	}
	return decision;
}

extern EPM_decision_t DLLAPI Chk_PR_Plant_active(EPM_rule_message_t msg) 
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;	
	char*			t5current_name				=NULL;	
	logical			t5InProcess;
	char*			procedure_name				=NULL;	
	char*			Tr_Domain_Approved				=NULL;	
	char*			TR_Domain				=NULL;	
	char*  	type_name = NULL;
	tag_t Attachrelation_type=NULLTAG;
	int cnt1=0;
	tag_t *attachments1;
	tag_t *attachments = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t PRLcmTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	char *submit_Rev_id = NULL;

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	printf("\n********************************************************** Inside Chk_PR_Plant_active");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nPDM CurrentTask33333333333:%s\n",CurrentTask);
	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n  of attachments444444444444:%d",count);	

	if(count > 0)
	{
		PRLcmTag = attachments[0];
		CALLAPI(AOM_ask_value_string(PRLcmTag,"current_name",&t5current_name));
		CALLAPI(AOM_ask_value_string(PRLcmTag,"item_revision_id",&submit_Rev_id));
		printf("\n PR name:%s - %s",t5current_name,submit_Rev_id);fflush(stdout); 
		CALLAPI(EPM_ask_active_job_for_target(PRLcmTag,&n_parents,&parents));
		printf("\n PR lifecycle count :%d\n",n_parents); fflush(stdout);

		if (n_parents>1)
		{
			CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
			printf("\n PR already in lifecycle:%s\n",procedure_name); fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Project Request Object already submitted in WorkFlow");
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			decision = EPM_go;
		}

		//Check no of Rev PRLcmTag
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		int n_tags_found= 0;
		tag_t *tags_found = NULLTAG;
		attrs[0] ="item_id";
		values[0] = (char *)t5current_name;
		CALLAPI(ITEM_find_items_by_key_attributes(1,(const char**)attrs, (const char**)values, &n_tags_found, &tags_found));
		if(n_tags_found > 0)
		{
			int Item_count = 0;
			tag_t *rev_list = NULLTAG;
			tag_t itemPR = NULLTAG;
			itemPR = tags_found[0];
			CALLAPI(ITEM_list_all_revs(itemPR, &Item_count, &rev_list));
			printf("\nTotal No of Project Revision found : %d",Item_count);fflush(stdout);
			if (Item_count < 2)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "Revise the Project Request Revision and then submit into Lifecycle");
				decision = EPM_nogo;
				return decision;
			}

			tag_t	latestrev = NULLTAG;
			char *latRevId = NULL;
			CALLAPI(ITEM_ask_latest_rev(itemPR,&latestrev));
			if(AOM_ask_value_string(latestrev,"item_revision_id",&latRevId)!=ITK_ok)PrintErrorStack();
			if (tc_strcmp(submit_Rev_id,latRevId)!=0)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "Select Latest Revision of the Project Request Revision and then submit into Lifecycle");
				decision = EPM_nogo;
				return decision;
			}
		}

		CALLAPI(TCTYPE_ask_object_type (PRLcmTag, &objTypeTag));
		CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
		printf("\n\n\t\t Submitted Object Type==> %s\n", type_name);fflush(stdout);
		if(tc_strcmp(type_name,"T5_ProjectReqRevision")==0)				
		{
			GRM_find_relation_type("TC_Attaches",&Attachrelation_type);
			if(Attachrelation_type != NULLTAG)
			{
				GRM_list_secondary_objects_only(PRLcmTag,Attachrelation_type,&cnt1,&attachments1);
				printf("\n project request Datasets:%d\n",cnt1);fflush(stdout);
				if(cnt1>0)
				{
					printf("\n project request Datasets found");fflush(stdout);
					decision = EPM_go;
				}
				else
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_warning,ITK_err, "Project Request Object necessary doc is not attached.Please attach and then submit to workFlow.");
					decision = EPM_nogo;
					return decision;
				}
			}
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "Invalid Object Type. Select only Project Request Revision and then submit to workFlow.");
			decision = EPM_nogo;
			return decision;
		}
	}
	return decision;
}

int PDM_AutoAssign_ChfAsCE_Manager( EPM_action_message_t msg )
{
	int		ifail				= 0;
	tag_t	root_task			=NULLTAG;

	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;
	tag_t	*attachments		=NULL;


	int i=0,j=0,count=0,PrtCount=0;
	char *ProjReqNos=NULL;
	char *PR_PrjChfEng=NULL;
	char *PR_PrgName=NULL;
	char* ObjTyp = NULL;
	char* type_name7 = NULL;
	int iii=0;
	
	printf("\n********************************************************** Inside PDM_AutoAssign_ChfAsCE_Manager");
	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
 	
	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\nPR Release No of attachments:%d",count);	
	
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			objTag=attachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&ProjReqNos)!=ITK_ok)PrintErrorStack();
			printf("\n TR:DML/Task Number: [%s].", ProjReqNos);fflush(stdout);
		
			if(tc_strcmp(ObjTyp,"T5_ProjectReqRevision")==0)
			{
				
					if(AOM_ask_value_string(objTag,"t5_PrjChfEng",&PR_PrjChfEng)!=ITK_ok)PrintErrorStack();
					printf("\n PR:PrjChfEng: [%s] PrjChfEng: [%s]", ProjReqNos,PR_PrjChfEng);fflush(stdout);
					
					if(AOM_ask_value_string(objTag,"t5_Program",&PR_PrgName)!=ITK_ok)PrintErrorStack();
					printf("\n PR:PrjChfEng: [%s] PrjChfEng: [%s]", ProjReqNos,PR_PrgName);fflush(stdout);
					
		
					tag_t	PR_ChfEng_Party			=  NULLTAG;
					tag_t	PR_ChfEng_Patri_Type			=  NULLTAG;
					
					//tag_t   PR_PrjChfEngtag = NULLTAG;
					//SA_find_user(PR_PrjChfEng,&PR_PrjChfEngtag);
					
					//char				userid[SA_user_size_c+1];
					//CALLAPI(SA_ask_user_identifier2(PR_PrjChfEngtag,userid));
					//printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);


					char	*PR_GrpName			=  NULL;
					char	*PR_roleName			=  NULL;
					tag_t	PR_GrpName_tag		=  NULLTAG;
					tag_t	PR_roleName_tag			=  NULLTAG;
					tag_t	PR_ChfEng_Patricipant			=  NULLTAG;
					tag_t	PR_ChfEng_Patricipant_Type			=  NULLTAG;
					tag_t	*member_tags			=  NULL;
					int num_of_members=0;
					

		
					
					printf("\n PR_PrgName: [%s] ", PR_PrgName);fflush(stdout);
					PR_GrpName = (char	*)MEM_alloc(100);
					tc_strcpy(PR_GrpName,PR_PrgName);
					tc_strcat(PR_GrpName,"_Chf_Grp");

					PR_roleName = (char	*)MEM_alloc(100);
					tc_strcpy(PR_roleName,"CE_Reviewer");

					printf("\n PR_GrpName  1111: [%s] PR_roleName: [%s]", PR_GrpName,PR_roleName);fflush(stdout);


					printf("\n  Finding group ");fflush(stdout);
					if(SA_find_group(PR_GrpName,&PR_GrpName_tag)!=ITK_ok)PrintErrorStack();
					if(PR_GrpName_tag != NULLTAG){
						if(SA_find_role2(PR_roleName,&PR_roleName_tag)!=ITK_ok)PrintErrorStack();
						if(PR_roleName_tag != NULLTAG){
							if(SA_find_groupmember_by_role(PR_roleName_tag,PR_GrpName_tag,&num_of_members,&member_tags)!=ITK_ok)PrintErrorStack();
							printf("\n num_of_members :[%d]",num_of_members);  fflush(stdout);
							printf("\n TR: num_of_members :[%d]",num_of_members);  fflush(stdout);
							if(num_of_members>0)
							{
								
								for(iii=0;iii<num_of_members;iii++)
								{
									tag_t			user_tag			= NULLTAG;
									char* userid = NULL;
									
									CALLAPI(SA_ask_groupmember_user(member_tags[iii],&user_tag));
							
									CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
									printf("\ncompare user :[%s] with Form user :[%s]\n",userid,PR_PrjChfEng);fflush(stdout);
									if(strstr(PR_PrjChfEng,userid))
									{
										printf("\n number of Reviewer in group [%d]",iii);fflush(stdout);
										if(EPM_get_participanttype ("T5_PR_ChfEng",&PR_ChfEng_Patricipant_Type)!=ITK_ok)PrintErrorStack();
										if(EPM_create_participant(member_tags[iii],PR_ChfEng_Patricipant_Type,&PR_ChfEng_Patricipant)!=ITK_ok)PrintErrorStack();
										AOM_lock(objTag);
										tag_t			relation			= NULLTAG;							
										//if(ITEM_rev_add_participant(objTag,PR_ChfEng_Patricipant)!=ITK_ok)PrintErrorStack();
										tag_t			relation_type		= NULLTAG;
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(objTag, PR_ChfEng_Patricipant, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										AOM_save_with_extensions(objTag);
										AOM_unlock(objTag);
									}
								}
							}
						}
					}
					else
						printf("\nNo Group Founf with Name: %s\n",PR_GrpName);
					
					char *ChfEnggNtExistsGrp=NULL;
					char *ChfEnggRoleNm=NULL;
					int n_entries11 =2;
					tag_t	Cntl_obj_Qtag11	=	NULLTAG;
					char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
					char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
					int resultCount11=0;
					tag_t *qry_cntrlobj11= NULLTAG;
					tag_t controlObjInfo2 = NULLTAG;
					CALLAPI( QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
					qry_values11[0] = "ChiefEnggNotExists" ;
					qry_values11[1] = "NewProject" ;
					CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					printf("\n Control Object count for ChiefEnggNotExists---------->%d\n",resultCount11);fflush(stdout);

					if(resultCount11>0)
					{
						controlObjInfo2=qry_cntrlobj11[0];
						CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo1",&ChfEnggNtExistsGrp));
						printf("\n--------------User Information 1: %s",ChfEnggNtExistsGrp);
						CALLAPI(AOM_ask_value_string(controlObjInfo2,"t5_Userinfo3",&ChfEnggRoleNm));
						printf("\n--------------User Information 1: %s",ChfEnggRoleNm);
					}
					tag_t PR_GrpName_tag1 = NULLTAG;
					tag_t PR_roleName_tag1 = NULLTAG;
					if(ChfEnggNtExistsGrp != NULL){
						PR_GrpName = (char	*)MEM_alloc(100);
						tc_strcpy(PR_GrpName,ChfEnggNtExistsGrp);
						PR_roleName = (char	*)MEM_alloc(100);
						tc_strcpy(PR_roleName,ChfEnggRoleNm);
						printf("\n PR_GrpName  1111: [%s] PR_roleName: [%s]", PR_GrpName,PR_roleName);fflush(stdout);
						printf("\n  Finding group ");fflush(stdout);
						if(SA_find_group(PR_GrpName,&PR_GrpName_tag1)!=ITK_ok)PrintErrorStack();
						if(PR_GrpName_tag1 != NULLTAG){
							if(SA_find_role2(PR_roleName,&PR_roleName_tag1)!=ITK_ok)PrintErrorStack();
							if(PR_roleName_tag1 != NULLTAG){
								if(SA_find_groupmember_by_role(PR_roleName_tag1,PR_GrpName_tag1,&num_of_members,&member_tags)!=ITK_ok)PrintErrorStack();
								printf("\n num_of_members :[%d]",num_of_members);  fflush(stdout);
								printf("\n TR: num_of_members :[%d]",num_of_members);  fflush(stdout);
								if(num_of_members>0)
								{
									
									for(iii=0;iii<num_of_members;iii++)
									{
										tag_t			user_tag			= NULLTAG;
										char* userid= NULL;
										
										CALLAPI(SA_ask_groupmember_user(member_tags[iii],&user_tag));
								
										CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
										printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
										printf("\ncompare user :[%s] with Form user :[%s]\n",userid,PR_PrjChfEng);fflush(stdout);
										if(strstr(PR_PrjChfEng,userid))
										{
											printf("\n number of Reviewer in group [%d]",iii);fflush(stdout);
											if(EPM_get_participanttype ("T5_PR_ChfEng",&PR_ChfEng_Patricipant_Type)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(member_tags[iii],PR_ChfEng_Patricipant_Type,&PR_ChfEng_Patricipant)!=ITK_ok)PrintErrorStack();
											AOM_lock(objTag);
											tag_t			relation			= NULLTAG;							
											//if(ITEM_rev_add_participant(objTag,PR_ChfEng_Patricipant)!=ITK_ok)PrintErrorStack();
											tag_t			relation_type		= NULLTAG;
											GRM_find_relation_type("HasParticipant", &relation_type);
											GRM_create_relation(objTag, PR_ChfEng_Patricipant, relation_type,  NULLTAG, &relation);
											GRM_save_relation(relation);
											AOM_save_with_extensions(objTag);
											AOM_unlock(objTag);
										}
									}
								}
							}
						}
					}
					
					AOM_refresh ( objTag,TRUE);
					MEM_free(member_tags);
					
				tag_t PR_Particpant_rel_type;
				tag_t	*PR_Reviewr		=NULL;
				int count=0,i=0,PrtCount=0,n_TR=0,jd=0;
				tag_t	*PR_Particpant		=NULL;
				tag_t	ObjTypPR			=NULLTAG;
				
				if(GRM_find_relation_type("HasParticipant", &PR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
				
				if(GRM_list_secondary_objects_only(objTag,PR_Particpant_rel_type,&PrtCount,&PR_Particpant)!=ITK_ok)PrintErrorStack();
				printf("\n PR: PrtCount count: %d",PrtCount);fflush(stdout);	
				 int jk=0;
				for (jk=0;jk<PrtCount ;jk++ )
				{
					tag_t PR_PartTag = PR_Particpant[jk];
					if(TCTYPE_ask_object_type(PR_PartTag,&ObjTypPR));
					if(TCTYPE_ask_name2(ObjTypPR,&type_name7));
					printf("\n Participants Name: %s", type_name7);fflush(stdout);
					//Checking for proper assign
					if (tc_strcmp(type_name7,"T5_PR_ChfEng")==0)
					{
						if(AOM_UIF_ask_value(PR_PartTag,"fnd0AssigneeUser",&PR_Reviewr)!=ITK_ok)PrintErrorStack();
						printf("\n Project req chief engg Reviewer: [%s] ",PR_Reviewr);fflush(stdout);
					}
				}
				
			}
		}

	}
return ITK_ok;
}

int CheckWFAppliCV(EPM_action_message_t msg)
{
	printf("In CheckWFAppliCV"); fflush(stdout);
	int error_code = ITK_ok;
	tag_t	Cntl_obj_Qtag	=	NULLTAG;
	char* checEnv = NULL;
	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char *qry_values[2] = {"IR","IRBusinessunit"};
	int resultCount=0;
	tag_t* qry_cntrlobj = NULL;
	if( QRY_find2("Control Objects...", &Cntl_obj_Qtag)!=ITK_ok)PrintErrorStack();
	if(QRY_execute(Cntl_obj_Qtag, 2, qry_entries, qry_values, &resultCount, &qry_cntrlobj)!=ITK_ok)PrintErrorStack();
	printf("\n Control Object count for Environment Check---------->%d\n",resultCount);fflush(stdout);
	if(resultCount>0)
	{
		if(AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo1",&checEnv)!=ITK_ok)PrintErrorStack();
		printf("\nUserinfo1: %s",checEnv); fflush(stdout);
		if (tc_strcmp(checEnv,"CVBU") == 0)
		{
			printf("\nEnvironment CVBU: Applicale for WF"); fflush(stdout);
			return 1;
		}
		else
		{
			printf("\nControl Obj Found. Environment not CVBU"); fflush(stdout);
			return 0;
		}
	}
	else
	{
		printf("\nEnvironment not CVBU"); fflush(stdout);
		return 0;
	}

	return error_code;
}

extern int PDMServiceinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	printf("\n ############ After Rigister PDMinitmodule");fflush(stdout);	
	
	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE; 
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ; 
	
	printf("\n PdmCreObjFunc before....PdmCreObjFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method("PdmCreObjFunc",(USER_function_t)PdmCreObjFunc,nargs,inputArgTypes,retValueType);	

	return ifail;	
}


extern int PDM_register_method(int *decision, va_list args)
{
   int ifail=0;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 
	METHOD_id_t  proj_iman_save;
	METHOD_id_t  cntrl_obj_iman_save;

   //if(ITK_ok ==  EPM_register_action_handler ("PDM_AutoAssign_ChfAsCE_Manager","Auto Assign Chf Engg As a CE Reviewer",PR_AutoAsg_ChfAsCEMgr_participants))
	   
   if( ITK_ok == EPM_register_action_handler("PDM_AutoAssign_ChfAsCE_Manager", "", PDM_AutoAssign_ChfAsCE_Manager))
   {
		printf("\t\n Registered Action Handler PDM_AutoAssign_ChfAsCE_Manager \n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler PDM_AutoAssign_ChfAsCE_Manager\n");fflush(stdout);
   }
   if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_PR_Submit","Validate for ProjectRequest Submisson", (EPM_rule_handler_t) Chk_PR_active))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_PR_Submit\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_PR_Submit\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_NewPlant_Submit","Validate for New Plant Add on ProjectRequest", (EPM_rule_handler_t) Chk_PR_Plant_active))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_NewPlant_Submit\n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_NewPlant_Submit\n");fflush(stdout);
   }

    if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_projectRel","Validate for ProjectRequest Submisson", (EPM_rule_handler_t) Chk_ProjectRelWithPR))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_projectRel\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_projectRel\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_MBOMApplicable","Validate for MBOM applicability", (EPM_rule_handler_t) Chk_MBOMApplicable))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_MBOMApplicable\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_MBOMApplicable\n");fflush(stdout);
   }

   if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_PlantDMLCre","Validate for Plant DML creation", (EPM_rule_handler_t) Chk_PlantDMLCre))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_PlantDMLCre\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_PlantDMLCre\n");fflush(stdout);
   }
   
    if(ITK_ok ==  EPM_register_rule_handler ("PDM_CHK_GrpRolePrjUsrAccCre","Validate for GrpRolePrjUsrAccCre", (EPM_rule_handler_t) Chk_GrpRolePrjUsrAccCre))
   {
		printf("\t\n Registered Rule Handler PDM_CHK_GrpRolePrjUsrAccCre\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler PDM_CHK_GrpRolePrjUsrAccCre\n");fflush(stdout);
   }
    if( ITK_ok == EPM_register_action_handler("PDM_SendMail", "", PDM_SendMail_PrjGrp))
   {
		printf("\t\n Registered Action Handler PDM_SendMail_PrjGrp \n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler PDM_SendMail_PrjGrp\n");fflush(stdout);
   }
   if( ITK_ok == EPM_register_action_handler("PDM_SendMailFinal", "", PDM_SendMail_PrjGrp_Final))
   {
		printf("\t\n Registered Action Handler PDM_SendMail_PrjGrp_Final \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler PDM_SendMail_PrjGrp_Final\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("PDM_SendMail_PrjPlantAdd", "", PDM_SendMail_PrjPlantAdd_Final))
   {
		printf("\t\n Registered Action Handler PDM_SendMail_PrjPlantAdd \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler PDM_SendMail_PrjPlantAdd\n");fflush(stdout);
   }
   if( ITK_ok == EPM_register_action_handler("CheckWFAppliCV", "", CheckWFAppliCV))
   {
		printf("\t\n Registered Action Handler CheckWFAppliCV \n");fflush(stdout);
   }
   else
   {
		printf("\t FAILED to register Action Handler CheckWFAppliCV\n");fflush(stdout);
   }
   
    /* Overriding IMAN_Save of Project for creating the  relation between project and project request Object  */	
    CALLAPI(METHOD_find_method("T5_Project", "IMAN_save", &proj_iman_save));	
	if (proj_iman_save.id != NULLTAG)
    {	
		int ifail    = ITK_ok;
		//printf("\n before Rigister pre_action tm_validate_prjCre");fflush(stdout);
		ifail=METHOD_add_action(proj_iman_save, METHOD_pre_action_type,(METHOD_function_t)tm_validate_prjCre,NULL);
		//printf("\n  After Rigister pre_action tm_validate_prjCre");fflush(stdout);
		
		//printf("\n before Rigister post_action tm_create_prjrel");fflush(stdout);
		ifail=METHOD_add_action(proj_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_create_prjrel,NULL);
		//printf("\n  After Rigister post_action tm_create_prjrel");fflush(stdout);
		//return ifail;
    }
	else
	{
		printf("\n After Rigister tm_create_prjrel  == NULL");fflush(stdout);
	}
	/* End overriden */
	
   return ITK_ok;
}


extern DLLAPI int tm_pdm_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registoring userservice....tm_pdm");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_pdm", "USER_init_module", (CUSTOM_EXIT_ftn_t)PDM_register_method);
	//printf("\n After registoring userservice....tm_pdm");fflush(stdout);
	return ( ifail );
}


