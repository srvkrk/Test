/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Amar Kate
*  Module		 :   Show process history of single object
*  Code			 :   tm_ShowProcessHistory.cxx
*  Created on	 :   August 28, 2025
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/workspaceobject.h>
#include <sa/user.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdarg.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grmtype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tc/wsouif_errors.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <epm/signoff.h>
#include <cfm/cfm.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <ps/ps.h>
#include <time.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>


using namespace std;

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


void setAddTagproc(int *count, tag_t **tagSet, tag_t tag)
{
    (*count)++;

    if (*count == 1)
    {
        *tagSet = (tag_t *)malloc((*count) * sizeof(tag_t));
    }
    else
    {
        *tagSet = (tag_t *)realloc(*tagSet, (*count) * sizeof(tag_t));
    }

    (*tagSet)[*count - 1] = tag;
}

void get_Job(tag_t item_rev_tag, int *n_occs, tag_t **occs)
{
	int n_instances = 0;
	int *instance_levels = 0;
	int *instance_where_found = 0;
	int n_classes = 0;
	int *class_levels = 0;
	int *class_where_found;
	tag_t *ref_instances = NULL;
	tag_t *ref_classes = NULL;
	char *pitem_id;

	AOM_ask_value_string(item_rev_tag, "item_id", &pitem_id);

	(POM_referencers_of_instance(item_rev_tag, 1, POM_in_db_only,
								 &n_instances, &ref_instances, &instance_levels,
								 &instance_where_found, &n_classes, &ref_classes, &class_levels,
								 &class_where_found));

	printf("\n *************start_______________ n_instances \n");

	printf("\n *************starttttttttttttt get_Job pitem_id = %s n_instances == %d\n", pitem_id, n_instances);

	if (n_instances > 0)
	{
		int count = 0;

		for (int ii = 0; ii < n_instances; ii++)
		{
			tag_t type_tag = NULLTAG;

			(TCTYPE_ask_object_type(ref_instances[ii], &type_tag));

			char *type_name = NULL;
			
			(TCTYPE_ask_name2(type_tag, &type_name));

			//printf("\n pitem_id = %s type_name = %s \n", pitem_id, type_name);

			//if (type_name != NULL && !strcmp("PSOccurrence", type_name))
			//if (type_name != NULL && !strcmp("Fnd0EPMTarget", type_name))
			if (type_name != NULL && !strcmp("Job", type_name))
			{
				count++;
				if (count == 1)
				{
					(*occs) = (tag_t *)MEM_alloc(sizeof(tag_t));
				}
				else
				{
					(*occs) = (tag_t *)MEM_realloc((*occs), count * sizeof(tag_t));
				}
				(*occs)[count - 1] = ref_instances[ii];
				*n_occs = count;
			}
		}

		if (instance_levels)
			MEM_free(instance_levels);
		if (instance_where_found)
			MEM_free(instance_where_found);
		if (class_levels)
			MEM_free(class_levels);
		if (ref_classes)
			MEM_free(ref_classes);
		if (class_where_found)
			MEM_free(class_where_found);
		if (ref_instances)
			MEM_free(ref_instances);
	}
}


void getSignoffAuditRecords(tag_t task_tag, int *n_records, tag_t **records)
{
    tag_t class_tag = NULLTAG;
    POM_class_id_of_class( "Fnd0WorkflowAudit", &class_tag);
    tag_t object_attr = NULLTAG;
    POM_attr_id_of_attr("fnd0Job", "Fnd0WorkflowAudit", &object_attr);
    tag_t object_type = NULLTAG;
    POM_attr_id_of_attr("object_type", "Fnd0WorkflowAudit", &object_type);
    tag_t userid_attr = NULLTAG;
    POM_attr_id_of_attr("fnd0UserId", "Fnd0WorkflowAudit", &userid_attr);
    tag_t logged_date_attr  = NULLTAG;
    POM_attr_id_of_attr( "fnd0LoggedDate",  "Fnd0WorkflowAudit", &logged_date_attr );

    tag_t find_task = NULLTAG;   
    POM_create_enquiry_on_tag (class_tag, object_attr, POM_is_equal_to, &task_tag, &find_task);

    //tag_t find_task_signoffs = NULLTAG;
    //POM_combine_enquiries( find_task , POM_and , object_type , &find_task_signoffs);

    int n_sort_attrs = 1;
    int sort_order[1] = {POM_order_ascending};
    POM_order_enquiry( find_task, 1, &logged_date_attr, sort_order );
 
    int n_found = 0;
    tag_t *found = NULL;
    POM_execute_enquiry(find_task, &n_found, &found);
    *n_records = n_found;
    (*records) = (tag_t *) MEM_alloc ( sizeof (tag_t) * n_found);
    for(int ii = 0;  ii < n_found; ii++)
    {
        (*records)[ii] = found[ii];
    }  
    if(n_found > 0) MEM_free(found); 
}


int tm_ShowProcessHistory_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	selObjstring				= NULL;
	tag_t InputTag=NULLTAG;
	tag_t record=NULLTAG;
	//char*	Input_PartType					= NULL;
	char*	Input_releaseStatus					= NULL;
	//char 	*retValue			= 	NULL;
	USERSERVICE_array_t 	array_struct;

	int buf_cnt=0;
	int i=0;
	int k=0;
	
	int n_records=0;
	tag_t* records=NULLTAG;

	int buff_cnt=0;              
	tag_t* buffrecords=NULLTAG;

	char* job_name =NULL;
	char* fnd0ObjectDisplayName =NULL;
	char* fnd0EventTypeName =NULL;
	char* fnd0LoggedDate =NULL;
	char* task_result =NULL;
	char* task_state =NULL;
	char* fnd0Comments =NULL;
	char* fnd0UserId =NULL;
	char* responsible_party =NULL;
	char* process_templateDisp =NULL;
	char* fnd0StartDate =NULL;
	char* fnd0AssignedFrom =NULL;
	char* object_type =NULL;

	printf("\n Amar Inside tm_ShowProcessHistory_Call .....\n");
	      
	USERARG_get_tag_argument(&InputTag);          

	
	int PartCnt=0;
	int n_tags_found=0;
	const char *qry_entries[1];
	const char *qry_values[1];

	//qry_entries[0] ="item_id";
	//qry_values[0] = objNum;

	tag_t* tags_found=NULLTAG;

	int j = 0;
	int jj = 0;
	int n_occs = 0;
	tag_t *occs = NULLTAG;
	tag_t *AllWorkflowsTag = NULLTAG;

	char *output = NULL;
	output = (char *)MEM_alloc(100 * sizeof(char));

	char* Workflowsobjtype=NULL;
	char* WorkflowsobjName=NULL;
	char* objtype=NULL;

	int records_count = 0;

	char* fnd0SignoffDecision =NULL;
	
	std::vector<tag_t> process_data;
	std::map<std::string, std::string> completedataProcess;

	ITK_CALL(AOM_ask_value_tags(InputTag,"fnd0AllWorkflows",&PartCnt,&AllWorkflowsTag));

	printf("\n  Amar PartCnt is :: [%d] \n",PartCnt);fflush(stdout);

	for (j=0;j<PartCnt ; j++)
	{

		ITK_CALL(AOM_UIF_ask_value(AllWorkflowsTag[j], "object_name", &WorkflowsobjName));
		printf("\n  properties WorkflowsobjName is [%s] \n",WorkflowsobjName);fflush(stdout);

		get_Job(AllWorkflowsTag[j], &n_occs, &occs);

		printf("\n Amar get_Job n_occs is [%d] \n",n_occs);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(occs[0], "object_type", &objtype));
		printf("\n  objtype is [%s] \n",objtype);fflush(stdout);

		//get_Job_Details(occs[0],&records_count,&output);

		getSignoffAuditRecords( occs[0], &n_records, &records);
		
		printf("\n  n_records is [%d] \n",n_records);

		if (n_records>0)                                                                                                                                                                                                                                                              
		{   

			for (i=0;i<n_records ;i++ ) 
			{
				record = records[i];				

				ITK_CALL(AOM_UIF_ask_value( record, "fnd0EventTypeName", &fnd0EventTypeName));
				ITK_CALL(AOM_UIF_ask_value( record, "fnd0ObjectDisplayName", &fnd0ObjectDisplayName));

				printf("\n fnd0EventTypeName is :: %s and fnd0ObjectDisplayName is::%s\n",fnd0EventTypeName,fnd0ObjectDisplayName);fflush(stdout);

				if ((tc_strcmp(fnd0EventTypeName,"Perform")==0)|| (tc_strcmp(fnd0EventTypeName,"Assign")==0)) 
				{
					printf("\n Skipping perform as Start is present fnd0EventTypeName = %s\n",fnd0EventTypeName);fflush(stdout);
					continue;
				}

				//completedataProcess.insert({std::string(fnd0ObjectDisplayName), std::string(fnd0EventTypeName)});

				//completedataProcess[std::string(fnd0ObjectDisplayName)] = std::string(fnd0EventTypeName);
					
				auto it = completedataProcess.find(std::string(fnd0ObjectDisplayName));
				if (it != completedataProcess.end()) 
				{
					if (tc_strcmp(it->second.c_str(),"Complete")==0)
					{
						 printf("\n Already fnd0EventTypeName is :: %s and fnd0ObjectDisplayName is::%s\n",fnd0EventTypeName,fnd0ObjectDisplayName);fflush(stdout);
					}
					else
					{
						completedataProcess[std::string(fnd0ObjectDisplayName)] = std::string(fnd0EventTypeName);
					}
				}
				else
				{

					completedataProcess[std::string(fnd0ObjectDisplayName)] = std::string(fnd0EventTypeName);
				}
			}

			for (const auto& pair : completedataProcess) 
			{
				std::cout << "Key: " << pair.first << ", Value: " << pair.second << '\n';
			}
			
			printf("\n After  setaddtag ::\n");fflush(stdout);

			for (jj=0;jj<n_records ;jj++ )   
			{
				record = records[jj];				
				char* fnd0EventTypeName1=NULL;

				ITK_CALL(AOM_UIF_ask_value( record, "fnd0SignoffDecision", &fnd0SignoffDecision));
				ITK_CALL(AOM_UIF_ask_value( record, "fnd0ObjectDisplayName", &fnd0ObjectDisplayName));
				ITK_CALL(AOM_UIF_ask_value(record, "process_templateDisp", &process_templateDisp));     

				ITK_CALL(AOM_ask_value_string( record, "object_type", &objtype));
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0EventTypeName", &fnd0EventTypeName1));
				ITK_CALL(AOM_UIF_ask_value( record, "fnd0AssignedFrom", &fnd0AssignedFrom));

				printf("\n Before if check fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s objtype=%s fnd0SignoffDecision=%s \n",fnd0ObjectDisplayName,fnd0EventTypeName1,objtype,fnd0SignoffDecision);fflush(stdout);

				if(tc_strcmp(fnd0EventTypeName1, "Start")==0 || tc_strcmp(fnd0EventTypeName1, "Promote")==0 ||tc_strcmp(fnd0EventTypeName1, "Complete")==0|| tc_strcmp(fnd0EventTypeName1,"End")==0||tc_strcmp(fnd0EventTypeName1,"Approve")==0 || ( fnd0AssignedFrom!=NULL && tc_strlen(fnd0AssignedFrom)>0 && tc_strcmp(fnd0EventTypeName1,"Assign")==0))//||tc_strcmp(fnd0EventTypeName1,"Process Initiated")==0)
				{
					/*if ((tc_strcmp(objtype,"EPMPerformSignoffTask")==0) && ((tc_strcmp(fnd0SignoffDecision, "Acknowledged")==0 || tc_strcmp(fnd0SignoffDecision, "Approved")==0 )||(tc_strcmp(fnd0SignoffDecision, "")==0) || (tc_strcmp(fnd0EventTypeName1, "Promote")==0 )))
					{
						 printf("\n Adding inside if check fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s objtype=%s fnd0SignoffDecision=%s \n",fnd0ObjectDisplayName,fnd0EventTypeName1,objtype,fnd0SignoffDecision);fflush(stdout);
						process_data.push_back(record);
					}
					else*/ //if ((tc_strcmp(objtype,"EPMConditionTask")==0) || (tc_strcmp(objtype,"EPMDoTask")==0) || (tc_strcmp(objtype,"EPMTask")==0) ||(tc_strcmp(objtype,"EPMPerformSignoffTask")==0) && (tc_strcmp(fnd0SignoffDecision, "Acknowledged")==0 || tc_strcmp(fnd0SignoffDecision, "Approved")==0 )|| (tc_strcmp(fnd0EventTypeName1, "Promote")==0 ))
					
					printf("\n  Amar fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s and fnd0EventTypeName1 ::%s\n",objtype,fnd0SignoffDecision,fnd0EventTypeName1);fflush(stdout);

					if ((tc_strcmp(objtype,"EPMConditionTask")==0) || (tc_strcmp(objtype,"EPMDoTask")==0) || (tc_strcmp(objtype,"EPMTask")==0) ||(tc_strcmp(objtype,"EPMPerformSignoffTask")==0)
						&& (tc_strcmp(fnd0SignoffDecision, "Acknowledged")==0 || tc_strcmp(fnd0SignoffDecision, "Approved")==0 )|| (tc_strcmp(fnd0EventTypeName1, "Promote")==0 ||tc_strcmp(fnd0EventTypeName1, "Start")==0 ))
					{
						printf("\n Before  compare fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s \n",fnd0ObjectDisplayName,fnd0EventTypeName1);fflush(stdout);
						printf("\n Amar -- fnd0AssignedFrom is :[%s]\n",fnd0AssignedFrom);fflush(stdout);

						if( fnd0AssignedFrom!=NULL && tc_strlen(fnd0AssignedFrom)>0 && tc_strcmp(fnd0EventTypeName1,"Assign")==0) 
						{
							printf("\n Amar Inside  fnd0AssignedFrom fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s fnd0AssignedFrom::%s \n",fnd0ObjectDisplayName,fnd0EventTypeName1,fnd0AssignedFrom);fflush(stdout);
							process_data.push_back(record);
						}
						else
						{
							auto it = completedataProcess.find(std::string(fnd0ObjectDisplayName));
							if (it != completedataProcess.end()) 
							{
								std::cout << "Key found: " << it->first << " with value: " << it->second << std::endl;
								// Debug: Compare the values
								std::cout << "Comparing: " << it->second << " with " << fnd0EventTypeName1 << std::endl;

							    if ((tc_strcmp(it->second.c_str(), fnd0EventTypeName1) == 0) || (tc_strcmp(objtype,"EPMPerformSignoffTask")==0 && tc_strcmp(fnd0EventTypeName1,"Approve")==0)) 
								{
									printf("\n Inside add fnd0ObjectDisplayName ::%s and fnd0EventTypeName1 is ::%s process_templateDisp==%s \n",fnd0ObjectDisplayName,fnd0EventTypeName1,process_templateDisp);fflush(stdout);
									if(tc_strcmp(fnd0ObjectDisplayName,process_templateDisp)==0)
									{
										 printf("\n Inside equal add fnd0ObjectDisplayName ::%s andn process_templateDisp  is ::%s \n",fnd0ObjectDisplayName,process_templateDisp);fflush(stdout);
										process_data.insert(process_data.begin(), record);
									}
									else{
							        process_data.push_back(record);
									}
							    }
							}
						}
					}
					
					
				}
				
			}


			printf("\n After  setaddtag completed *********::%d\n",buff_cnt);fflush(stdout);

			for(k=0;k<process_data.size();k++)
			{    
				std::cout << "before get \n" ;
				record=process_data[k];    
				std::cout << "After get \n" ;

				                                                                                                                                                                                                                                                                      
				ITK_CALL(AOM_UIF_ask_value(record, "job_name", &job_name));         
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0ObjectDisplayName", &fnd0ObjectDisplayName)); 
				ITK_CALL(AOM_ask_value_string(record, "fnd0ObjectDisplayName", &fnd0ObjectDisplayName)); 
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0EventTypeName", &fnd0EventTypeName));        
				//ITK_CALL(AOM_ask_value_string(record, "fnd0EventTypeName", &fnd0EventTypeName));        
				ITK_CALL(AOM_UIF_ask_value(record, "object_type", &object_type));        
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0LoggedDate", &fnd0LoggedDate));  
				//ITK_date_to_string(fnd0LoggedDate1, &fnd0LoggedDate);                                                                                                                                                                                                               
	                                                                                                                                                                                                                                                                                
				ITK_CALL(AOM_UIF_ask_value(record, "task_result", &task_result));  
				ITK_CALL(AOM_UIF_ask_value(record, "task_state", &task_state));    
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0Comments", &fnd0Comments));  
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0UserId", &fnd0UserId));   
				ITK_CALL(AOM_UIF_ask_value(record, "responsible_party", &responsible_party));     
				ITK_CALL(AOM_UIF_ask_value(record, "process_templateDisp", &process_templateDisp));     
				ITK_CALL(AOM_UIF_ask_value(record, "fnd0StartDate", &fnd0StartDate));       
				//ITK_CALL(AOM_UIF_ask_value(record, "fnd0AssignedFrom", &fnd0AssignedFrom));  
				
				char* uid=NULL;
				ITK__convert_tag_to_uid(record,&uid);
				printf("\n uid is :[%s]\n",uid);fflush(stdout);                                                                                                                                                                                                                                                                      
	                                                                                                                                                                                                                                                                                
				printf("\n JobName of [%d] :job_name is :[%s]\n",k+1,job_name);fflush(stdout);                                                                                                                                                                                        
				printf("\n JobName of [%d] :fnd0ObjectDisplayName is :[%s]\n",k+1,fnd0ObjectDisplayName);fflush(stdout);                                                                                                                                                              
				printf("\n JobName of [%d] :fnd0EventTypeName is :[%s]\n",k+1,fnd0EventTypeName);fflush(stdout);                                                                                                                                                                      
				printf("\n JobName of [%d] :object_type is :[%s]\n",k+1,object_type);fflush(stdout);                                                                                                                                                                                  
				printf("\n JobName of [%d] :fnd0LoggedDate is :[%s]\n",k+1,fnd0LoggedDate);fflush(stdout);                                                                                                                                                                            
				printf("\n JobName of [%d] :task_result is :[%s]\n",k+1,task_result);fflush(stdout);                                                                                                                                                                                  
				printf("\n JobName of [%d] :fnd0Comments is :[%s]\n",k+1,fnd0Comments);fflush(stdout);                                                                                                                                                                                
				printf("\n JobName of [%d] :fnd0UserId is :[%s]\n",k+1,fnd0UserId);fflush(stdout);                                                                                                                                                                                    
				printf("\n JobName of [%d] :responsible_party is :[%s]\n",k+1,responsible_party);fflush(stdout);                                                                                                                                                                      
				printf("\n JobName of [%d] :process_templateDisp is :[%s]\n",k+1,process_templateDisp);fflush(stdout);                                                                                                                                                                
				printf("\n JobName of [%d] :fnd0StartDate is :[%s]\n",k+1,fnd0StartDate);fflush(stdout);                                                                                                                                                                              
				printf("\n JobName of [%d] :fnd0AssignedFrom is :[%s]\n",k+1,fnd0AssignedFrom);fflush(stdout);  
				
				printf("\n JobName of [%d] :UID is :[%s]\n",k+1,uid);fflush(stdout);  
	                                                                                                                                                                                                                                                                                
				if ((tc_strcmp(fnd0EventTypeName,"Promote")==0)||(tc_strcmp(fnd0EventTypeName,"Assign")==0)||(tc_strcmp(fnd0EventTypeName,"Approve")==0)|| (tc_strcmp(fnd0EventTypeName,"Complete")==0)|| (tc_strcmp(fnd0EventTypeName,"Start")==0))                                                                                                                                                                       
				{                                                                                                                                                                                                                                                                     
					if ((tc_strcmp(object_type,"EPMConditionTask")==0) || (tc_strcmp(object_type,"EPMDoTask")==0)  || (tc_strcmp(object_type,"EPMPerformSignoffTask")==0) || (tc_strcmp(object_type,"EPMTask")==0)|| (tc_strcmp(object_type,"EPMAcknowledgeTask")==0))                                                                   
					{                                                                                                                                                                                                                                                                 
					                                                                                                                                                                                                                                                                  
						//fprintf(fpW, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",job_name,fnd0ObjectDisplayName,fnd0EventTypeName,object_type,fnd0LoggedDate,task_result,task_state,fnd0Comments,fnd0UserId,responsible_party,process_templateDisp,fnd0StartDate,fnd0AssignedFrom);    
						//fflush(fpW); 
						
						if (record!=NULLTAG)
						{
							printf("\n Amar Inside record JobName of [%d] :job_name is :[%s]\n",k+1,job_name);fflush(stdout);                                                                                                                                                                                        
							printf("\n Amar Inside record JobName of [%d] :fnd0ObjectDisplayName is :[%s]\n",k+1,fnd0ObjectDisplayName);fflush(stdout);                                                                                                                                                              
							printf("\n Amar Inside record JobName of [%d] :fnd0EventTypeName is :[%s]\n",k+1,fnd0EventTypeName);fflush(stdout);                                                                                                                                                                      
							printf("\n Amar Inside record JobName of [%d] :object_type is :[%s]\n",k+1,object_type);fflush(stdout);                                                                                                                                                                                  
							printf("\n Amar Inside record JobName of [%d] :fnd0LoggedDate is :[%s]\n",k+1,fnd0LoggedDate);fflush(stdout);                                                                                                                                                                            
							printf("\n Amar Inside record JobName of [%d] :task_result is :[%s]\n",k+1,task_result);fflush(stdout);                                                                                                                                                                                  
							printf("\n Amar Inside record JobName of [%d] :fnd0Comments is :[%s]\n",k+1,fnd0Comments);fflush(stdout);                                                                                                                                                                                
							printf("\n Amar Inside record JobName of [%d] :fnd0UserId is :[%s]\n",k+1,fnd0UserId);fflush(stdout);                                                                                                                                                                                    
							printf("\n Amar Inside record JobName of [%d] :responsible_party is :[%s]\n",k+1,responsible_party);fflush(stdout);                                                                                                                                                                      
							printf("\n Amar Inside record JobName of [%d] :process_templateDisp is :[%s]\n",k+1,process_templateDisp);fflush(stdout);                                                                                                                                                                
							printf("\n Amar Inside record JobName of [%d] :fnd0StartDate is :[%s]\n",k+1,fnd0StartDate);fflush(stdout);                                                                                                                                                                              
							printf("\n Amar Inside record JobName of [%d] :fnd0AssignedFrom is :[%s]\n",k+1,fnd0AssignedFrom);fflush(stdout); 

							setAddTagproc(&buff_cnt,&buffrecords,record);
						}
					}                                                                                                                                                                                                                                                                 
				}                                                                                                                                                                                                                                                                     
				                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
			}                                                                                                                                                                                                                                                                         
	                                                                                                                                                                                                                                                                                
	                                                                                                                                                                                                                                                                                
		}
	}
 

	ITK_CALL(USERSERVICE_return_tag_array(buffrecords, buff_cnt, 
        (USERSERVICE_array_t *) return_data));   


	printf("\n Amar End----CommonDMLBetweenReports....\n");fflush(stdout);

	return ifail;
}

extern int tm_ShowProcessHistoryinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for Show Process History

	int nargs1 = 1;
	int retValueType1;
	int inputArgTypes1[1] = {0};
	
	//inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[0] = USERARG_TAG_TYPE;
	
	//retValueType1 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	retValueType1 = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;	
	
	printf("\n tm_ShowProcessHistoryinitmodule before....tm_ShowProcessHistory_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_ShowProcessHistory_Call",(USER_function_t)tm_ShowProcessHistory_Call,nargs1,inputArgTypes1,retValueType1);
	printf("\n End--tm_ShowProcessHistory service call...");fflush(stdout);	

	return ifail;	
}

extern "C" int tm_ShowProcessHistory_register_callbacks()
{	
	int ifail    = ITK_ok;
	printf("\n Amar Before registoring userservice....tm_ShowProcessHistory");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_ShowProcessHistory", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_ShowProcessHistoryinitmodule);
	printf("\n Amar After registoring userservice....tm_ShowProcessHistory");fflush(stdout);
	return ( ITK_ok );
}
