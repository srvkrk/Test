#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h> 
#include <stdlib.h>
#include <string.h>
#include <pie/pie.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ae/ae.h>	
#include <unistd.h>
#include<ps/ps.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pom/pom/pom.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <tccore/tctype.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <map>
#include <base_utils/IFail.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedPtr.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <tccore/tctype.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>
#include <tccore/aom_prop.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

void get_PSOccurrences_of_item(tag_t item_rev_tag, int *n_occs, tag_t **occs, tag_t revRule)
{
	int n_instances = 0;
	int *instance_levels = 0;
	int *instance_where_found = 0;
	int n_classes = 0;
	int *class_levels = 0;
	int *class_where_found;
	tag_t *ref_instances = NULL;
	tag_t *ref_classes = NULL;
	char *pitem_id;

	AOM_ask_value_string(item_rev_tag, "item_id", &pitem_id);

	(POM_referencers_of_instance(item_rev_tag, 1, POM_in_db_only,
								 &n_instances, &ref_instances, &instance_levels,
								 &instance_where_found, &n_classes, &ref_classes, &class_levels,
								 &class_where_found));

	if (n_instances > 0)
	{
		int count = 0;

		for (int ii = 0; ii < n_instances; ii++)
		{
			tag_t type_tag = NULLTAG;
			(TCTYPE_ask_object_type(ref_instances[ii], &type_tag));

			char *type_name = NULL;
			(TCTYPE_ask_name2(type_tag, &type_name));

			if (type_name != NULL && !strcmp("PSOccurrence", type_name))
			{
				count++;
				if (count == 1)
				{
					(*occs) = (tag_t *)MEM_alloc(sizeof(tag_t));
				}
				else
				{
					(*occs) = (tag_t *)MEM_realloc((*occs), count * sizeof(tag_t));
				}
				
				(*occs)[count - 1] = ref_instances[ii];
				*n_occs = count;
			}
		}

		if (instance_levels)
			MEM_free(instance_levels);
		if (instance_where_found)
			MEM_free(instance_where_found);
		if (class_levels)
			MEM_free(class_levels);
		if (ref_classes)
			MEM_free(ref_classes);
		if (class_where_found)
			MEM_free(class_where_found);
		if (ref_instances)
			MEM_free(ref_instances);
	}
}

char* getParents(char *item_id, char *revseq1, char *revRule)
{
	printf("\n ~~~~~~~~~ Inside Program getParents ~~~~~~~~~~~\n");

	int ifail = ITK_ok;
	int n_occs = 0;
	tag_t *occs = NULLTAG;
	int i;
	char *pitem_id1;

	tag_t	relation_type_task = NULLTAG;
	tag_t	tsk_dml_rel_type   = NULLTAG;
	int 	count_task;
	tag_t	*PartTaskTags;
	int 	count_dml;
	tag_t	*DMLRevision_Prt;
	char    *DMLobject;
	char    *DMLobject1;
	int  	 n_parents = 0;
	int * 	 levels;
	tag_t *  parents = NULLTAG;
	char    *object_Type;
	char    *DMLEcnType;
	char    *GetRevRule;
	tag_t   item_rev_tag1;

	tag_t	item_tag        = NULLTAG;
	tag_t	item_rev_tag    = NULLTAG;
	tag_t    rule           = NULLTAG;

	char *parent_part     = NULL;
	char *parent_item_id  = NULL;
	char *desc            = NULL;
	char *revseq          = NULL;
	char *dmlItemID       = NULL;
	char *date_Released   = NULL;

	char *output_buffer = (char *)MEM_alloc(100000); // ~100KB

    int offset = 0;

	offset += sprintf(output_buffer + offset, "parent_part,parent_item_id,desc,revseq,dmlItemID,date_Released,qtyval\n");

	ifail = ITEM_find_item (item_id, &item_tag);

	ifail = ITEM_find_revision(item_tag, revseq1, &item_rev_tag);

	ifail = ITEM_ask_item_of_rev(item_rev_tag, &item_rev_tag1);

	CFM_find(revRule, &rule);

	AOM_ask_value_string(item_rev_tag, "item_id", &pitem_id1);

	get_PSOccurrences_of_item(item_rev_tag1, &n_occs, &occs,rule);

	AOM_UIF_ask_value(rule,"object_name",&GetRevRule);
	
    printf("Revision Rule from Rev rule object is = %s\n",GetRevRule);fflush(stdout);

	if(item_rev_tag != NULLTAG)
	{
		ITKCALL(PS_where_used_configured(item_rev_tag,rule,1,&n_parents,&levels,&parents));
	}
	else
	{
		printf("\nInside Else Condition");
	}

	printf("\nNo of Assy objects are n_parents : %d \n",n_parents);fflush(stdout);

	// Declare the map: parent tag -> qty_value
	std::map<tag_t, double> parents_qty_map;

	for (int i = 0; i < n_occs; i++)
	{
		tag_t parent_bvr = NULLTAG;
		tag_t *item_revs = NULL;
		int n_item_revs = 0;

		AOM_ask_value_tag(occs[i], "parent_bvr", &parent_bvr);

		if (parent_bvr == NULLTAG)
			continue;

		PS_list_owning_revs_of_bvr(parent_bvr, &n_item_revs, &item_revs);

		for (int y = 0; y < n_item_revs; y++)
		{
			double qtyval = 0;

			AOM_ask_value_double(occs[i], "qty_value", &qtyval);

			// Store qty_value in map keyed by parent tag
			parents_qty_map[item_revs[y]] = qtyval;
		}

		if (item_revs)
		{
			MEM_free(item_revs);
		}
	}

	if (n_parents > 0)
	{
		for (i = 0; i < n_parents; i++)
		{
			std::string dml_ids_str = "";
			std::string dml_dates_str = "";

			double qtyval = 0.0;

			//std::cout << "tag_t address: " << parents[i] << std::endl;

			AOM_ask_value_string(parents[i], "object_string", &parent_part);
			printf("\nparent_part == %s", parent_part);fflush(stdout);

			AOM_ask_value_string(parents[i], "item_id", &parent_item_id);
			printf("\nparent_item_id == %s", parent_item_id);fflush(stdout);

			AOM_ask_value_string(parents[i], "object_desc", &desc);
			printf("\nParent Part Description == %s", desc);fflush(stdout);

			AOM_ask_value_string(parents[i], "item_revision_id", &revseq);
			printf("\nRevision == %s", revseq);fflush(stdout);

			// Get quantity from map
			if (parents_qty_map.find(parents[i]) != parents_qty_map.end())
			{
				qtyval = parents_qty_map[parents[i]];
			}

			printf("\nQuantity = %lf", qtyval);fflush(stdout);
            
			GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);

			GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);

			GRM_list_primary_objects_only(parents[i],relation_type_task,&count_task,&PartTaskTags);

			//printf("\nValue of Task Count is %d",count_task);fflush(stdout);
            
			if(count_task > 0)
			{
				// Vectors to hold multiple DML details per parent part
				std::vector<std::string> dml_ids;
				std::vector<std::string> dml_dates;

				for(int i = 0; i<count_task; i++)
				{
					//AOM_ask_value_string(PartTaskTags[i], "object_string", &DMLobject);
					// printf("\nTask Number == %s", DMLobject);fflush(stdout);

					GRM_list_primary_objects_only(PartTaskTags[i],tsk_dml_rel_type,&count_dml,&DMLRevision_Prt);

			        //printf("\nValue of DML Count is %d",count_dml);fflush(stdout);

					if(count_dml > 0)
					{
						//AOM_ask_value_string(DMLRevision_Prt[0], "item_id", &dmlItemID);
						// printf("\ndmlItemID == %s", dmlItemID);fflush(stdout);

						AOM_ask_value_string(DMLRevision_Prt[0], "t5_EcnType", &DMLEcnType);
						//printf("\nDMLEcnType == %s", DMLEcnType);fflush(stdout);

						AOM_ask_value_string(DMLRevision_Prt[0], "object_type", &object_Type);
						// printf("\nobject_Type == %s", object_Type);fflush(stdout);

						if (tc_strcmp(DMLEcnType, "AMDML") == 0 || tc_strcmp(DMLEcnType, "APLSTR") == 0 || tc_strcmp(object_Type, "ChangeRequestRevision") == 0)
						{
							AOM_ask_value_string(DMLRevision_Prt[0], "item_id", &dmlItemID);
						    printf("\ndmlItemID == %s", dmlItemID);fflush(stdout);

							AOM_UIF_ask_value(DMLRevision_Prt[0],"date_released",&date_Released);
							printf("\ndate_Released == %s", date_Released);fflush(stdout);

							dml_ids.push_back(dmlItemID);

							dml_dates.push_back(date_Released);
						}
					}
				}

				// Concatenate vector contents into comma-separated strings
				
				for (size_t idx = 0; idx < dml_ids.size(); ++idx) 
				{
					if (idx > 0) dml_ids_str += "; ";
					dml_ids_str += dml_ids[idx];
				}

				
				for (size_t idx = 0; idx < dml_dates.size(); ++idx) 
				{
					if (idx > 0) dml_dates_str += "; ";
					dml_dates_str += dml_dates[idx];
				}
			}

			offset += sprintf(output_buffer + offset, "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%lf\"\n",
                  parent_part ? parent_part : "N/A",
                  parent_item_id ? parent_item_id : "N/A",
                  desc ? desc : "N/A",
                  revseq ? revseq : "N/A",
				  dml_ids_str.c_str(),
				  dml_dates_str.c_str(),
				  qtyval ? qtyval : 0);

			printf("\n ");
		}
	}
	else if (n_parents == 0)
	{
		printf("\n else occs == %d", n_occs);fflush(stdout);

		offset += sprintf(output_buffer + offset, "\"%s\",\"%d\"\n",pitem_id1 ? pitem_id1 : "N/A",n_parents ? n_parents : 0);
	}
	else
	{
		printf("\n else occs == %d", n_occs);fflush(stdout);
	}

	printf("Output Buffer Length: %d\n", strlen(output_buffer));fflush(stdout);

    printf("Output Buffer Preview:\n%s\n", output_buffer);fflush(stdout);

	output_buffer[offset] = '\0';  // Null-terminate the final string

	return output_buffer;
}

int tm_getParents(void *return_data)
{
	int  ifail   = ITK_ok;

	char *output = NULL;

	int offset = 0;

	printf("\n ~~~~~~~~~ Inside Program tm_getParents ~~~~~~~~~~~\n");

	fflush(stdout);

	char *selected_item = NULL;
	char *inp_RevSeq    = NULL;
	char *inp_revRule   = NULL;
	//char *inp_closure_rule = NULL;

	tag_t selected_itemTag	= NULLTAG;


	USERARG_get_tag_argument(&selected_itemTag);
	USERARG_get_string_argument(&selected_item);
	USERARG_get_string_argument(&inp_RevSeq);
	USERARG_get_string_argument(&inp_revRule);
	//USERARG_get_string_argument(&inp_closure_rule);

	output = getParents(selected_item, inp_RevSeq, inp_revRule);

	printf("Final output is %s",output);fflush(stdout);
	
	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) return_data), output);

	MEM_free(output);

	return ifail;
}

/*
int ITK_user_main(int argc, char *argv[])
{
	int		ifail 		    = ITK_ok;
	char	* userid 		= NULL;
	char	* password		= NULL;
	char	* group		    = NULL;
	char	* item_id		= NULL;
	char	* revseq		= NULL;
	tag_t	item_tag 		= NULLTAG;
	tag_t	rev_tag			= NULLTAG;
	char 	*rev_id			= NULL;
	char    *revRule        = NULL;
	tag_t    rule           = NULLTAG;

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	item_id		    = ITK_ask_cli_argument("-partNumber=");
	revseq          = ITK_ask_cli_argument("-revseq=");
	revRule         = ITK_ask_cli_argument("-revRule=");
	
	ifail = ITK_init_module(userid, password, group);

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!\n");

		printf("\nWelcome to Teamcenter.....!\n");
	}

	printf("item_id %s \n", item_id);

	printf("revseq %s \n", revseq);

	printf("revRule %s \n", revRule);

	ifail = ITEM_find_item (item_id, &item_tag);

	//ifail = ITEM_ask_latest_rev (item_tag, &rev_tag);

	ifail = ITEM_find_revision(item_tag, revseq, &rev_tag);
	
	if(rev_tag == NULLTAG)
	{
		printf("Object not found in TC...!!\n");
		printf("***************************\n");
		printf("Not found\n");
		return 0;
	}
	else
	{	
		ifail = AOM_UIF_ask_value (rev_tag, "item_revision_id", &rev_id);
		CHECK_FAIL;
		printf("\nRevision found is: %s\n",rev_id);
		printf("\n***********************************\n");			
		printf("%s\n",rev_id);
	}

	CFM_find(revRule, &rule);

	//getParents(rev_tag,rule);

	getParents(item_id,revseq,revRule);

	printf("\nProgram Completed \n");
	
	MEM_free(rev_id);

	return ifail;
}
*/

extern int AllUserServiceFntm_Parent_Structure_History_DetailFtn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	
	*decision = ALL_CUSTOMIZATIONS;

	int nargs = 4;
	int retValueType;
	int inputArgTypes[4] = {0};

	inputArgTypes[0] = USERARG_TAG_TYPE;    // Part Number Tag
	inputArgTypes[1] = USERARG_STRING_TYPE; // Part Number
	inputArgTypes[2] = USERARG_STRING_TYPE; // Revision and Sequence
	inputArgTypes[3] = USERARG_STRING_TYPE; // Revision Rule
	//inputArgTypes[3] = USERARG_STRING_TYPE; // Closure Rule

	retValueType = USERARG_STRING_TYPE;
	
	printf("\n AllUserServiceFntm_Parent_Structure_History_DetailFtn before....tm_Parent_Structure_History_DetailFtnFtn");
	fflush(stdout);
	ifail = USERSERVICE_register_method("tm_getParents", (USER_function_t)tm_getParents, nargs, inputArgTypes, retValueType);

	return ifail;
}

extern "C" DLLAPI int tm_Parent_Structure_History_Detail_register_callbacks()
{
	int ifail = ITK_ok;
	printf("\n Before registoring userservice....tm_Parent_Structure_History_Detail");
	fflush(stdout);
	ifail = CUSTOM_register_exit("tm_Parent_Structure_History_Detail", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFntm_Parent_Structure_History_DetailFtn);
	printf("\n After registoring userservice....tm_Parent_Structure_History_Detail");
	fflush(stdout);
	return (ITK_ok);
}