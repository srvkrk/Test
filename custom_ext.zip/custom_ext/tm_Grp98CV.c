#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(x)                                                              \
	{                                                                            \
		int stat;                                                                \
		char *err_string;                                                        \
		if ((stat = (x)) != ITK_ok)                                              \
		{                                                                        \
			EMH_ask_error_text( stat, &err_string);                    \
			printf("ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
			printf("FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
			if (err_string)                                                      \
				MEM_free(err_string);                                            \
			exit(EXIT_FAILURE);                                                  \
		}                                                                        \
	}

// /*
int tm_Grp98CVFtn_Call(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	int n_entryCntrl1=3;
	tag_t rev = NULLTAG;

	char *grp98Type	= NULL;
	char *taskID = NULL;


	//tag_t userID=NULLTAG;
	//tag_t group=NULLTAG;
	// roleName=NULLTAG;

	char *userID	= NULL;
	char *group	= NULL;
	char *roleName = NULL;
	

	USERARG_get_string_argument(&taskID);						// Task revision
	USERARG_get_string_argument(&grp98Type);					// Type - Colour or Non-Colour


	USERARG_get_string_argument(&userID);					// session user
	USERARG_get_string_argument(&group);					// group
	USERARG_get_string_argument(&roleName);					// session role

	//USERARG_get_tag_argument(&userID);					// session user
	//USERARG_get_tag_argument(&group);					// group
	//USERARG_get_tag_argument(&roleName);					// session role

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char     *qry_valuesCntrl1[3]= {"GRP98CV","CVBU","0"};

    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;


    //ITK_CALL(QRY_find("Control Objects...", &qryTagCntrl1));
	ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
       if (qryTagCntrl1)
       {
          // printf("\n Control Object Query Found \n");
		  fflush(stdout);
    

           ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			
			if(control_number_found1>0)
		   {
				char* t5_Userinfo1 = NULL;
				char cmd[100];
				tag_t obj = list_of_WSO_cntrl_tags1[0];
				ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
				sprintf(cmd,"%s %s %s",t5_Userinfo1,taskID,grp98Type);
				printf("Excuting Command = %s",cmd);
				fflush(stdout);
				system(cmd);
				//printf("After executing Command");
				fflush(stdout);
		   }
	   }


	return ifail;

}



extern int AllUserServiceFnGrp98CVFtn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	//int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	// Refer ict_userservice.h for more arg types
	inputArgTypes[0] = USERARG_STRING_TYPE;     // taskID
	inputArgTypes[1] = USERARG_STRING_TYPE;  // grp98Type
	inputArgTypes[2] = USERARG_STRING_TYPE;  // SESSION USER
	inputArgTypes[3] = USERARG_STRING_TYPE;  // Group
	inputArgTypes[4] = USERARG_STRING_TYPE;  // SESSION ROLE
	

	retValueType = USERARG_STRING_TYPE ; 
	//printf("\n AllUserServiceFnGrp98CVFtn before....tm_Grp98CVFtn");
	fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_Grp98CVFtn_Call",(USER_function_t)tm_Grp98CVFtn_Call,nargs,inputArgTypes,retValueType);
 
 return ifail;
 
}

extern DLLAPI int tm_Grp98CV_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registoring userservice....tm_Grp98CV");
	fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_Grp98CV", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnGrp98CVFtn);
	//printf("\n After registoring userservice....tm_Grp98CV");
	fflush(stdout);
	return ( ITK_ok );
}


