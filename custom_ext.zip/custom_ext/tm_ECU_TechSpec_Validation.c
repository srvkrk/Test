#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ics/ics2.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcfile_cache.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <tc/preferences.h>
//#include "participant.h"
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <time.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error6 (EMH_USER_error_base+27)
/*--------------------------------------------------*/

#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}





extern EPM_decision_t DLLAPI ECUTechSpecValidationfun (EPM_rule_message_t msg)
{
		EPM_decision_t decision = EPM_go;
		tag_t *ClsObjTag =NULLTAG;
		int cnt = 0;
		int sp = 0;
		int m = 0;
		int p = 0;
		int i = 0;
		int flag1 = 0;
		int tech_count = 0;
		int progpartcount = 0;
		int noAttachment = 0;
		int Breakdowncount = 0;
		int	VehGCIH85GrtCnt	=0;
		int	objCount	=0;
        char* username = NULL;
        char* AttrKeyValue = NULL;
        char* objType = NULL;
        char* CurrentTask = NULL;
        char* object_releasetype = NULL;
        char* parent_name = NULL;
        char* DesRevid = NULL;
        char* dmlNo = NULL;
		char* dmlTaskNo = NULL;
        char* Busunit = NULL;
        char* TaskId = NULL;
        char* Userinfodup = NULL;
        char* Userinfodup2 = NULL;
        char* DMLReltypeProg = NULL;
		char* VCPart_Type = NULL;
        char* PsPartNum = NULL;
		char*CurrentTaskNam     =NULL;
		char*childParentTaskNam    =NULL;
		char*parent_nameprog    =NULL;
		tag_t rootTask =NULLTAG;
		tag_t Techqry_tg =NULLTAG;
		tag_t DMLRevTag =NULLTAG;
		//tag_t dmlTaskNo =NULLTAG;
		tag_t DMLTag =NULLTAG;
		tag_t objTypTag =NULLTAG;
		tag_t tech_object1 =NULLTAG;
		tag_t ClsObj =NULLTAG;
		tag_t classitemTAG =NULLTAG;
		tag_t relationTag =NULLTAG;
		tag_t* BreakdowncountTags =NULLTAG;
		tag_t* attachments =NULLTAG;
		tag_t* tech_object =NULLTAG;
		//tag_t* Techqry_tg =NULLTAG;
		tag_t* ProgPartTags =NULLTAG;
		tag_t* objList =NULLTAG;
		tag_t PsPartTag =NULLTAG;
		tag_t DML_tag =NULLTAG;
		tag_t Latestrev_Tag =NULLTAG;
		//tag_t rootTask =NULLTAG;
		char*	 AttrKeyValue1		= NULL;
	    char*	 AttrKeyValue2		= NULL;
	    char*	 AttrKeyValue4		= NULL;
		char *DvloGCILessStr1 = (char *) MEM_alloc(sizeof(char)* 200);
		char*ProgScaleBuff=(char*)MEM_alloc(sizeof(char)*100);
		char*ProgramSclNull=(char*)MEM_alloc(sizeof(char)*200);
	    ITK_CALL(POM_get_user_id (&username));
		printf("\n Ecu_techpec Session User is : %s \n",username); fflush(stdout);
		if(QRY_find2("Control Objects...", &Techqry_tg));
		

		char *Tech_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **tech_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		tech_RelVal[0] = "Tech_Check";
		tech_RelVal[1] = "ON";

		ITK_CALL(QRY_execute(Techqry_tg, 2, Tech_entry1, tech_RelVal, &tech_count, &tech_object));
		printf("\n Tech_Check control object count1 :%d \n",tech_count);fflush(stdout);


		if(tech_count>0)
	   {
	
		tech_object1=tech_object[i];
		ITK_CALL(AOM_ask_value_string(tech_object1,"t5_Userinfo1",&Userinfodup));  
		printf("\n tech_object1 t5_Userinfo1:[%s]\n",Userinfodup); fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tech_object1,"t5_Userinfo2",&Userinfodup2));  
		printf("\n tech_object1 t5_Userinfo2:[%s]\n",Userinfodup2); fflush(stdout);

		printf("\n ****************** Tech_Check Control Object for ECU TechSpec found so validation operation started");
		
		
		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n Inside the ECUTechSpec_Validation ...\n");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTaskNam));
		printf("\n ECUTechSpec_Validation- CurrentTask: %s \n",CurrentTaskNam);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&childParentTaskNam));
		printf("\n ECUTechSpec_Validation- childParentTask: %s \n",childParentTaskNam);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_nameprog));
		printf("\n ECUTechSpec_Validation- parent Name: %s \n",parent_nameprog);fflush(stdout);

		ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		printf("\n ECUTechSpec_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);

		

		
		

//			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
//			printf("\n Inside the Ecu_techpec Approved Condition ...\n");fflush(stdout);
//
//			ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
//			printf("\n Ecu_techpec- CurrentTask: %s \n",CurrentTask);fflush(stdout);
//
//			ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
//			printf("\n Ecu_techpec- parent Name: %s \n",parent_name);fflush(stdout);
//
//			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
//			printf("\n Ecu_techpec- Target Attachment:%d \n",noAttachment);fflush(stdout);


			if(noAttachment>0)
			{

			printf("\n Inside ECUTechSpec Validation - Target Attachment:%d \n",noAttachment);fflush(stdout);
			DMLTag = attachments[0];

			if(AOM_ask_value_string(DMLTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
					printf("\n  dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout);

			if(tc_strstr(dmlTaskNo,"_") != NULL)
					 {
						dmlNo=strtok(dmlTaskNo,"_");
						printf("\n dmlNo =====> [%s]", dmlNo);fflush(stdout); //getting dml number here
					 }
					 else
					  {
						 tc_strcpy(dmlNo,dmlTaskNo);
						 printf("\n dmlNo 2=====> [%s]", dmlNo);fflush(stdout);
					  }

			//ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&dmlNo));
			//printf("\n Ecu_TechSpec current- DML No: [%s] \n", dmlNo);fflush(stdout);


			if(ITEM_find_item(dmlNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{
			  printf("\n DML tag is not null for ECU_TechSpec_Attach DML No: [%s] \n", dmlNo);fflush(stdout);

			  if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

			  ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&Busunit));
			  printf("\n  Tech Busunit : [%s]\n", Busunit); fflush(stdout);

			  ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));


			    if(objTypTag!=NULLTAG)
				{
				
				 printf("\n object type found sucessfully \n");fflush(stdout);

				}


				ITK_CALL(TCTYPE_ask_name2(objTypTag,&objType));
			    printf("\n  object_type is %s\n", objType);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLReltypeProg));
				printf("\n  t5_rlstype ecu_techpec is : [%s]\n", DMLReltypeProg); fflush(stdout);

				if((tc_strcmp(Busunit,"CVBU")==0 && tc_strcmp(Userinfodup,"CVBU")==0 ) || (tc_strcmp(Busunit,"PVBU")==0 && tc_strcmp(Userinfodup2,"PVBU")==0))
				{
					printf("\n Inside business unit condition\n");fflush(stdout);


				if(tc_strcmp(objType,"ChangeRequestRevision")==0)   //IMAN_reference
				{

					ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Breakdowncount,&BreakdowncountTags));
					printf("\n Task count %d \n",Breakdowncount);fflush(stdout);

					if (Breakdowncount>0)
					{
						for (m=0;m<Breakdowncount;m++)
						{
							ITK_CALL(AOM_ask_value_string(BreakdowncountTags[m],"item_id",&TaskId));
							printf("\n Tech DML Task [%s]",TaskId);fflush(stdout);

							if(tc_strcmp(DMLReltypeProg,"Veh")==0)
							{

									if (tc_strstr(TaskId,"_00")==NULL)
									{
										printf("\n Tech Skipping Skip for other DML Task [%s] \n",TaskId);fflush(stdout);
										continue;
									}
									
									
									printf("\n Inside dmltype Veh prog\n"); fflush(stdout);
									ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[m],"CMHasSolutionItem",&progpartcount,&ProgPartTags));
									printf("\n CMHasSolutionItem count Task111 [%d] \n",progpartcount);fflush(stdout);

									if(progpartcount>0)
								    {

										for(sp=0;sp<progpartcount;sp++)
										{
											printf("\n Inside progpartcount\n"); fflush(stdout);

										PsPartTag=ProgPartTags[sp];

										   ITK_CALL(AOM_ask_value_string(PsPartTag,"item_id",&PsPartNum));
											
										   ITK_CALL(AOM_ask_value_string(PsPartTag,"t5_PartType",&VCPart_Type));
										   printf("\n  t5_PartType of VC ecu_techp is : [%s]\n", VCPart_Type); fflush(stdout);
										  
										   printf("\n Checking Part type of VC" ); fflush(stdout);

										if(tc_strcmp(VCPart_Type,"V")==0)
										{
										    printf("\n Part type of VC is Vehicle, so checling for ECU Tech Spec" ); fflush(stdout);

											GRM_find_relation_type("T5_Has_ECU_Tech_Spec",&relationTag);
											GRM_list_secondary_objects_only(PsPartTag,relationTag,&objCount,&objList);

											printf("\n Inside ECU TECH SPEC folder count is [%d]........\n",objCount); fflush(stdout);

											for(p=0;p<objCount;p++)
											{
												printf("\n Inside ECU TECH SPEC loop\n"); fflush(stdout);
												ITK_CALL(AOM_ask_value_string(objList[p],"object_type",&object_releasetype));
												printf("\n Ecu_techpec- object type is %s \n",object_releasetype);fflush(stdout);

												  if(tc_strcmp(object_releasetype, "T5_ECU_TSCompRevision") == 0 )
												  {
													  printf("\n ECU TechSpec Revision found \n"); fflush(stdout);
												  }
												  else
												  {
														printf("\n ECU TechSpec Revision not found \n"); fflush(stdout);

														flag1++;

												  }

											}
											if (flag1>0 || objCount==0)
											{
												VehGCIH85GrtCnt=VehGCIH85GrtCnt+1;
												tc_strcat(DvloGCILessStr1,PsPartNum);
												tc_strcat(DvloGCILessStr1,",");

											}
											
																
												
										}	
				


										}


									
									
									
									  }



							}
						
						
						
						
						}
					
					
					
					
					}





				}
			}
			
			
			
			
			}







		}

			if (VehGCIH85GrtCnt > 0)
			{

				printf("\n ...........flag count : %d \n",flag1);fflush(stdout);
				printf("\n ...........Please attach ECU TechSpec in Has ECU Tech Spec folder........... \n");fflush(stdout);
				tc_strcpy(ProgramSclNull,"");
				tc_strcpy(ProgramSclNull,"Please attach ECU TechSpec to 9 digit Vehicle revision : ");
				tc_strcat(ProgramSclNull,ProgScaleBuff);
				tc_strcat(ProgramSclNull,"\nTo create ECU TechSpec -> Select Vehicle Revision -> Right click -> Click on ECU TechSpec Creation option.");

				EMH_store_error_s1(EMH_severity_error,ITK_err,ProgramSclNull);
				decision = EPM_nogo;
				return decision;

			}
		
	   }

	   

		printf("\n tech code end \n");fflush(stdout);

		return decision;


}

//int fetch_TechSpec_details(tag_t DMLTag)
//{
//	int  ifail   = ITK_ok;
//	char* dml_no = NULL;
//	char* DMLItemRev = NULL;
//	tag_t DMLrevDML = NULLTAG;
//
//		if (DMLTag == NULLTAG) 
//		{
//			printf("ERROR: DML tag is NULL.\n");
//			return ITK_general_error;
//		}
//
//	ITEM_ask_latest_rev(DMLTag,&DMLrevDML);
//	
//	ITK_CALL(AOM_ask_value_string(DMLrevDML, "item_id", &dml_no));
//    printf("INFO: Fetching TechSpec for DML [%s]\n", dml_no);
//    MEM_free(dml_no);
//
//	ITK_CALL(AOM_ask_value_string(DMLrevDML,"item_revision_id",&DMLItemRev));
//	printf("\n DMLItemRev: %s ", DMLItemRev);fflush(stdout);
//
//}


extern int register_tm_ECU_TechSpec_Validation(int *decision, va_list args)
{
    *decision = ALL_CUSTOMIZATIONS;
	int	ifail = ITK_ok;

    if(ITK_ok == EPM_register_rule_handler("ECUTechSpecValidation","", (EPM_rule_handler_t) ECUTechSpecValidationfun))
	{

       printf("\t\n Registered rule  Handler ECUTechSpecValidation\n");fflush(stdout); 
	}
	else
	{
        printf("\t FAILED to register rule Handler ECUTechSpecValidation\n");fflush(stdout); 
	}
	return ifail;

}


extern DLLAPI int tm_ECU_TechSpec_Validation_register_callbacks()
{
     CUSTOM_register_exit("tm_ECU_TechSpec_Validation", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_tm_ECU_TechSpec_Validation);

    printf("\n tm_ECU_TechSpec_Validation of ECU TechSpec \n");  

	 return ( ITK_ok );
}


