
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_VCMSB6InventoryReport.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   22-01-2025
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 22-01-2025  	 Amar Kate				    VCMS-B6-Inventory Report

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int tm_VCMSB6InventoryReport_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char*	listVCString				= NULL;
	char*	inp_level					= NULL;
	char*	inp_Plant					= NULL;
	char*	inp_RemoveUnderscorePart	= NULL;
	char*	inp_StopatF					= NULL;
	char*	inp_SkipZeroQty				= NULL;
	char*	isShowSuppressValue			= NULL;
	char*	MailList					= NULL;

	printf("\n Amar Inside tm_VCMSB6InventoryReport_Call .....\n");
	
	USERARG_get_string_argument(&listVCString);          
	USERARG_get_string_argument(&inp_level); 
	USERARG_get_string_argument(&inp_RemoveUnderscorePart); 
	USERARG_get_string_argument(&inp_Plant);
	USERARG_get_string_argument(&inp_StopatF);  
	USERARG_get_string_argument(&inp_SkipZeroQty);     
	USERARG_get_string_argument(&isShowSuppressValue);     
	USERARG_get_string_argument(&MailList);
	 
	printf("\n Amar listVCString => %s\n",listVCString);fflush(stdout);	
	printf("\n Amar inp_level => %s\n",inp_level);fflush(stdout);
	printf("\n Amar inp_RemoveUnderscorePart => %s\n",inp_RemoveUnderscorePart);fflush(stdout);
	printf("\n Amar inp_Plant => %s\n",inp_Plant);fflush(stdout);
	printf("\n Amar inp_StopatF => %s\n",inp_StopatF);fflush(stdout);
	printf("\n Amar inp_SkipZeroQty => %s\n",inp_SkipZeroQty);fflush(stdout);
	printf("\n Amar isShowSuppressValue => %s\n",isShowSuppressValue);fflush(stdout);
	printf("\n Amar MailList => %s\n",MailList);fflush(stdout);

	
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"VCMSB6InventoryReport","CVPROD","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n Amar control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo1 = NULL;
			char cmd[2000];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));	
			sprintf(cmd,"%s/VCMSB6InventoryReport.sh %s %s %s %s %s %s %s %s &",t5_Userinfo1,listVCString,inp_level,inp_RemoveUnderscorePart,inp_Plant,inp_StopatF,inp_SkipZeroQty,isShowSuppressValue,MailList);
			printf("\nAmar Excuting For VCMSB6InventoryReport Command = %s\n",cmd);fflush(stdout);
			system(cmd);
			printf("\nAfter executing Command\n");fflush(stdout);
			//MEM_free(cmd);
	   }
	}
	return ifail;
}

extern int tm_VCMSB6InventoryReportinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for Action Plan Report

	int nargs1 = 8;
	int retValueType1;
	int inputArgTypes1[8] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE;  
	inputArgTypes1[3] = USERARG_STRING_TYPE;  
	inputArgTypes1[4] = USERARG_STRING_TYPE;  
	inputArgTypes1[5] = USERARG_STRING_TYPE;  
	inputArgTypes1[6] = USERARG_STRING_TYPE;  
	inputArgTypes1[7] = USERARG_STRING_TYPE;  

	retValueType1 = USERARG_STRING_TYPE ; 
	
	printf("\n tm_VCMSB6InventoryReportinitmodule before....tm_VCMSB6InventoryReport_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_VCMSB6InventoryReport_Call",(USER_function_t)tm_VCMSB6InventoryReport_Call,nargs1,inputArgTypes1,retValueType1);

	return ifail;	
}

extern DLLAPI int tm_VCMSB6InventoryReport_register_callbacks()
{	
	int ifail    = ITK_ok;
	//printf("\n Amar Before registoring userservice....tm_VCMSB6InventoryReport");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_VCMSB6InventoryReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_VCMSB6InventoryReportinitmodule);
	printf("\n Amar After registoring userservice....tm_VCMSB6InventoryReport");fflush(stdout);
	return ( ITK_ok );
}