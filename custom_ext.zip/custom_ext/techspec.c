

	#include <stdlib.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	#include <tc/iman.h>
	#include <tccore/imantype.h>
	#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>

	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}

	#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
	#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)

	static int report_error(char *file, int line, char *call, int status,
	    logical exit_on_error)
	{
	    if (status != ITK_ok)
	    {
		/*int
		    n_errors = 0,
		    *severities = NULL,
		    *statuses = NULL;
			*/
			int n_errors = 0;
			const int 
				*severities=NULL,
				*statuses=NULL;
		const char
		    **messages;
			


		EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
		if (n_errors > 0)
		{
		    ECHO("\n%s\n", messages[n_errors-1]);
		    EMH_clear_errors();
		}
		else
		{
		    char *error_message_string;
		    EMH_get_error_string (NULLTAG, status, &error_message_string);
		    ECHO("\n%s\n", error_message_string);
		}

		ECHO("error %d at line %d in %s\n", status, line, file);
		ECHO("%s\n", call);

		if (exit_on_error)
		{
		    ECHO("Exiting program!\n");
		    exit (status);
		}
	    }

	    return status;
	}

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
	
int printObject(tag_t objtag)
{

               int                prop_count=0;
               char**             prop_names=NULL;
               int        num_values=0;
               char**     values =NULL;
               tag_t                   class_tag=NULLTAG;
               char                     *class_name=NULL;
               int j=0,k=0;

               logical propConstReqBool=false;

               int ifail=ITK_ok;

               printf("\n printObject()->");fflush(stdout);

     if(objtag==NULLTAG)
     {
                printf("\nNULLTAG");fflush(stdout);
                return ifail;
     }
               /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
               ITK_CALL(POM_name_of_class(class_tag, &class_name) );

*/
     char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

     ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



               ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
               printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
               // printf("\n printObject2 %d",prop_count);fflush(stdout);

               for (k=0;k<prop_count;k++)
               {
               ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values));

               tag_t prop_tag = NULLTAG;
               ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
               printf("\n %s:{,[",prop_names[k]);fflush(stdout);

               propConstReqBool=false;
               char *prop_dispay_name=NULL;
               PROP_value_type_t valtype;
               char *valtypeName=NULL;
               ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

                                                                           printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
                                                                           printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
                                                                           printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
                                                                           printf("\n]\n");fflush(stdout);

               for(j=0;j<num_values;j++)
               {
               printf("\n\t%s,",values[j]);fflush(stdout);
               }

               printf("\n },");fflush(stdout);

               }
               printf("\n]");fflush(stdout);
return ifail;
}

void setFindStr(char **view_list,int count,char *str,int *found)
{


	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

void setFindStrFrom(char **view_list,int count,char *str,int start,int *found)
{


	int k=0;
	*found=0;
	for(k=start;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

		
	int AssignProj(char *ObjProject)
	{	
	tag_t   projobj;
	tag_t			Currproj								= NULLTAG;
	char* username;
	char *ActGmName1 = NULL;
	char *ActGmName = NULL;
	tag_t user_tag=NULLTAG;
	char *DrwName		= NULL;
	char *DrwName1		= NULL;
	char *parent_name	= NULL;
	char *group_name	= NULL;
	char *Role_name		= NULL;
	char *Grp_name		= NULL;
	char *Desc_obj2		= NULL;
	char *item_rev_id	= NULL;
	char *currpro		= NULL;
	char		   *ObjectClassType		= NULL;
	char		   *ObjectName		= NULL;
	char		   *desi_grp		= NULL;
	char *desid = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *DerRoleNme = NULL;
	char *DerRoleNme1 = NULL;
	char *NewDescription = NULL;
	tag_t rev=NULLTAG;
	 char* oojname = NULL;
	logical	promem				= 0;
	int				Gmcnt=0;
	int				Gmcnt1=0;
	int				Gmcnt2=0;
	int				Gmcnt3=0;
	int				Rolflag1=0;
	int 			jkl		=0;
	int				jk=0;
	int				Rolflag=0;
	tag_t			*attachments								= NULLTAG;
	tag_t			*GmFound								= NULLTAG;
	tag_t			*GmFound1								= NULLTAG;
	tag_t			*GmFound2								= NULLTAG;
	tag_t			*GmFound3								= NULLTAG;
	tag_t			ActGm		= NULLTAG;
	tag_t			ActGm1		= NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t			projid					= NULLTAG;
	tag_t			Roletag								= NULLTAG;

	tag_t			primary					= NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t  CurrentRoleTag = NULLTAG;
	tag_t			DesRolTag								= NULLTAG;

tag_t			GroupMem								= NULLTAG;

tag_t			grptag								= NULLTAG;
	char roleName[SA_name_size_c+1];
	printf("\nInside AssignProj Func with ObjProject=%s \n",ObjProject);fflush(stdout);
		POM_get_user(&username,&user_tag);
					SA_ask_current_groupmember(&GroupMem);
					 printf("\nGroupMem: %u username=%s\n",GroupMem,username);fflush(stdout);
			 if(GroupMem !=NULLTAG)
								{
								if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok)PrintErrorStack();
								printf("\ngroup_name session is pare  : %s\n",group_name);fflush(stdout);

									if (SA_ask_groupmember_role(GroupMem,&Roletag) !=ITK_ok)PrintErrorStack();
									if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok)PrintErrorStack();
									 if((Roletag !=NULLTAG) && (Roletag !=NULLTAG))
								{
								if (AOM_ask_value_string(Roletag,"object_name",&Role_name)!=ITK_ok)PrintErrorStack();
								if (AOM_ask_value_string(grptag,"object_name",&Grp_name)!=ITK_ok)PrintErrorStack();
								printf("\nRole_name session is pare  : %s %s\n",Role_name,Grp_name);fflush(stdout);
								    if (AOM_ask_value_string(ObjProject,"t5_DesignGrp",&desi_grp)!=ITK_ok)   PrintErrorStack();

									printf("\n Design group  = [%s]\n", desi_grp);fflush(stdout);

									DerRoleNme=NULL;DerRoleNme=malloc(50);
									strcpy(DerRoleNme,desi_grp);
									strcat(DerRoleNme,"_Designers");
									printf("\n Role name required   = [%s]\n", DerRoleNme);fflush(stdout);

									if (SA_find_role(DerRoleNme,&DesRolTag)!=ITK_ok)PrintErrorStack();

									if (SA_find_groupmember_by_user(user_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();

									//if (SA_find_groupmember_by_rolename (DerRoleNme,"Engineering",username,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
									printf("\n count of  Gmcnt = [%d]\n", Gmcnt);fflush(stdout);


									ITKCALL(SA_ask_current_role(&CurrentRoleTag));
									ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
									printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


									for(jk=0;jk<Gmcnt;jk++)
										{
											ActGm = GmFound[jk];
											if (AOM_ask_value_string(ActGm,"object_name",&ActGmName)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name  = [%s]\n", ActGmName);fflush(stdout);
											if (strstr(ActGmName,DerRoleNme)|| strstr(roleName,"APL") )
											{
                                             Rolflag++;
                                             DerRoleNme1=NULL;DerRoleNme1=malloc(100);
											 strcpy(DerRoleNme1,ActGmName);
											 //break;
											}

										}
										printf("\n count of  Rolflag = [%d]\n", Rolflag);fflush(stdout);
										printf("\n DerRoleNme1 is  = [%s]\n", DerRoleNme1);fflush(stdout);
										if ((Rolflag==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}
								}
								}

			if (AOM_get_value_string(ObjProject,"t5_ProjectCode",&ObjProject))PrintErrorStack();
			 printf("\nProject stamped is  : %s\n",ObjProject);fflush(stdout);

		
		if(strcmp(ObjProject,"")!=0)
			{
				if (PROJ_find(ObjProject,&projobj) !=ITK_ok)PrintErrorStack();

				if(projobj !=NULLTAG)
				{
									//if (TCTYPE_ask_object_type(projobj,&projobj1)!=ITK_ok)PrintErrorStack();

									//if (TCTYPE_ask_name(projobj1,Ptype_name1)!=ITK_ok)PrintErrorStack();
									//printf("\n Proj type_name = %s\n", Ptype_name1);
									printf("\nAssigned to Projecttttttt33\n");fflush(stdout);
									SA_ask_current_project(&Currproj);

						if(Currproj !=NULLTAG)
						{
									if (AOM_ask_value_string(Currproj,"object_name",&parent_name)!=ITK_ok)PrintErrorStack();
									printf("\nExisting session Project is   : %s\n",parent_name);fflush(stdout);
									//if (AOM_UIF_ask_value(Currproj,"workcontext_name",&currpro)!=ITK_ok)PrintErrorStack();
									// if (POM_attr_id_of_attr( "project", "TC_WorkContext", &projid )!=ITK_ok)PrintErrorStack();



				//							if (strcmp(parent_name,ObjProject)==0)
				//							{
				//								printf("\nAssigned to Projecttttttt\n");fflush(stdout);
				//							}
				//							else
								{
									if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

									 if(promem==1)
										  {
											printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
											//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
											//return ITK_err;
											SA_set_current_project(projobj);
										if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

										   for(jkl=0;jkl<Gmcnt1;jkl++)
											{
												ActGm1 = GmFound1[jkl];
												if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
												printf("\n Actual Group Member name1  = [%s]\n", ActGmName1);fflush(stdout);
											if(DerRoleNme1)
												{
												if (strcmp (ActGmName1,DerRoleNme1) == 0)
												{
												   printf("\nValid user to create the part\n");fflush(stdout);
												   Rolflag1++;
												}
												}
											}
												if ((Rolflag1==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
												{
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
												return ITK_err;
												}

										  }
										  else
										  {
												  printf("\ncall error ITK ok2\n");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
										  }



								}
								printf("\nAssigned to Project\n");fflush(stdout);
						}
						else
						 {
						if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

							 if(promem==1)
								  {
									printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
									//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
									//return ITK_err;
									SA_set_current_project(projobj);

									if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

								   for(jkl=0;jkl<Gmcnt1;jkl++)
									{
										ActGm1 = GmFound1[jkl];
										if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
										printf("\n Actual Group Member name1  = [%s] DerRoleNme1=%s\n", ActGmName1,DerRoleNme1);fflush(stdout);
									if(DerRoleNme1)
										{
											printf("\n in if Actual Group Member name1  = [%s] DerRoleNme1=%s\n", ActGmName1,DerRoleNme1);fflush(stdout);
											if (strcmp (ActGmName1,DerRoleNme1) == 0)
											{
											   printf("\nValid user to create the part\n");fflush(stdout);
											   Rolflag1++;
											}
											else
											{
												printf("\nNot Valid user to create the part\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n in Else Actual Group Member name1  = [%s] \n", ActGmName1);fflush(stdout);
										}
									}
										if ((Rolflag1 == 0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
										{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
										return ITK_err;
										}


								  }
								  else
								  {
										  printf("\ncall error ITK ok2\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
									return ITK_err;
								  }
						 }

				}
			}
			else
			{
				printf("\ncall error ITK ok2\n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter the Project code and set the same project in session details");
				   return ITK_err;
			}
	}

int TechSpecCreFun(char *projcode ,char *OwnerDesDept,char *OwnerDesUnit,char *VcClass,char *Desc,char *FilePath)
	   {
				int ifail = ITK_ok;
	           /* tag_t    itemrev = NULLTAG;
				char *srcview=NULL;
				char *desview=NULL;
				char *status=NULL;*/
				tag_t createInputTag = NULLTAG;
				tag_t type = NULLTAG;
			    tag_t item = NULLTAG;
				char *tspartnum=NULL;
				char *tempnum =NULL;
				const char *select_attrs[]={"item_id"};
				int n_rows;
				int n_cols;
				int row;
				int column;
				void ***report;
				char vals[30];
				//char *Item;
				const char *str_list[15];
				 char **FinalItemId = NULL;
	            
				
				printf("\nInside TechSpecCreFun*******");
				*FinalItemId=(char *)MEM_alloc(sizeof(char *)* 32);
				tspartnum=MEM_alloc(30);
				//tempnum=MEM_alloc(30);
				printf("\n Input Parameters projcode=%s OwnerDesDept=%s OwnerDesUnit=%s VcClass=%s Desc=%s FilePath=%s",projcode,OwnerDesDept,OwnerDesUnit,VcClass,Desc,FilePath);
				tc_strcpy(*FinalItemId,"2590");
				tc_strcat(*FinalItemId,projcode);
				tc_strcat(*FinalItemId,"*");
				printf("\n FinalItemId=%s",*FinalItemId);
				
				str_list[0]=*FinalItemId;
				printf("\nstr_list[0]=%s",str_list[0]);
				//Create Start
				
				      printf("\nB4 query Build FinalItemId=%s",*FinalItemId);
					POM_enquiry_create ("find_TechSpec_by_type");
					POM_enquiry_add_select_attrs ("find_TechSpec_by_type","T5_TSComp", 1, select_attrs);
					POM_enquiry_set_string_value ("find_TechSpec_by_type","attrval",1,str_list,POM_enquiry_bind_value);
					POM_enquiry_set_attr_expr ("find_TechSpec_by_type","expr1", "T5_TSComp","item_id",POM_enquiry_like, "attrval");
					POM_enquiry_set_where_expr ("find_TechSpec_by_type","expr1");
					POM_enquiry_add_order_attr( "find_TechSpec_by_type", "T5_TSComp", "item_id", POM_enquiry_desc_order );
					POM_enquiry_execute ("find_TechSpec_by_type", &n_rows, &n_cols,&report);			
					
							printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",*FinalItemId,n_rows,n_cols,report);
						for (row = 0; row < n_rows; row++)
						{
						for (column = 0; column < n_cols; column++)
						printf("\n Query return=%s\t", report[row][column]);
					
						}
						printf("\n Row =%d Column =%d\t", n_rows,n_cols);
						if(n_rows==0 )
						{
						printf("\nInside start Base part=%s",*FinalItemId);
						strcat(*FinalItemId,"0001");
						}
						else
						{
							printf("\nInside Base part increment condition=%s %d",report[0][0],ifail);
							//sprintf(vals,"%3.3d",atoi(mysubstring(reinterpret_cast<const char *>(report[0][0]),8,12))+1);
							printf("\nInside vals=%s",vals);
					     	strcat(*FinalItemId,vals);
						} 
				
					printf("\nto be create part=%s",*FinalItemId);
				//create End
				
				
				
				
				ITK_CALL(TCTYPE_find_type ("T5_TSComp", NULL, &type ));
				ITK_CALL(TCTYPE_construct_create_input ( type , &createInputTag));
				/*
				printf("\n TechSpecCreFun1*******");
			   ITK_CALL( AOM_set_value_tag(createInputTag, "t5_ItemRevision", itemrev));
				ITK_CALL( AOM_set_value_string(createInputTag, "object_name", "gfsdfas"));
				printf("\n TechSpecCreFun2*******");
				

			    ITK_CALL(TCTYPE_create_object(createInputTag, &item));
				printf("\n TechSpecCreFun5*******");
			    ITK_CALL( AOM_save_with_extensions(item));
				printf("\n TechSpecCreFun6*******");
			*/
			return 	ifail;
	   
	   
	   }

// Func to getting Vehicle from Tech Spec Object 
extern DLLAPI int getVehfrmTechSpec(tag_t TechSpecObj,tag_t* VehFrmTS)
{

	 printf("\n Start func getVehfrmTechSpec\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;


	ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relType));

	printf("\n TechSpecObj=%u relType=%u\n",TechSpecObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(TechSpecObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{

		*VehFrmTS = primary_objects[0];
		}

	}
	return ifail;	

	printf("\n End func getVehfrmTechSpec\n");fflush(stdout);

}


	extern DLLAPI int getVehRelationFrmTS(METHOD_message_t * message, va_list args )
	{

	printf("\n Start func getVehRelationFrmTS\n");fflush(stdout);
    int ifail = ITK_ok;
	tag_t *VehTag=NULLTAG;
	

        tag_t TSTag= message->object_tag;

        va_list largs;

        va_copy( largs, args);
        va_arg( largs, tag_t );
        VehTag = va_arg( largs, tag_t*);
        va_end( largs );

		

			printf("\n Calling func getVehfrmTechSpec\n");fflush(stdout);
			ITK_CALL(getVehfrmTechSpec(TSTag,VehTag));

			printf("\n After func call getVehfrmTechSpec VehTag=%u\n",VehTag);fflush(stdout);
			
				
			
			return ifail;	

		
			
	}
int T5TechSpecCre_pre( METHOD_message_t *msg, va_list args )
{

   printf("\n Start Update *****T5TechSpecCre_pre\n");fflush(stdout);

   int ifail = ITK_ok;
   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t item_tag = va_arg(largs, tag_t);
   tag_t item_rev_tag = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	

	char *item_id=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	int count;
	int count1;
	tag_t projtag;
	tag_t *Ownprojtag;
	tag_t userSession=NULLTAG;
	char *Type = va_arg(largs, char *);
	va_end( largs );
   printf("\n Start Update *****T5TechSpecCre_pre111\n");fflush(stdout);
	ITK_CALL( AOM_ask_value_string(item_tag, "object_name",&item_id));
	ITK_CALL( AOM_ask_value_string(item_tag, "t5_ProjectCode",&ProjName));
	ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
	printf("\n count=%d Ownprojtag =%u\n",count1,Ownprojtag);fflush(stdout);
	printf("\n ProjName=%s \n",ProjName);fflush(stdout);
	
   if(ProjName)
   {
	printf("\n Inside the func AssignProj ");fflush(stdout);
	//ITK_CALL(AssignProj(ProjName));   
	ITK_CALL(PROJ_find(ProjName, &projtag));
	printf("\n After PROJ_find=%u",projtag);fflush(stdout);
	SA_set_current_project(projtag);
   }
   
   
   printf("\n Start Update *****T5TechSpecCre_pre item_id=%s projcode=%s \n",item_id,projcode);fflush(stdout);
   return 0;

}

int T5TechSpecCre_post( METHOD_message_t *msg, va_list args )
{

	printf("\n Start Update *****T5TechSpecCre_post\n");fflush(stdout);

	int ifail = ITK_ok;
	/* va_list for BOMLine_add_msg */
	va_list largs;
	va_copy( largs, args );               
	tag_t item_tag = va_arg(largs, tag_t);
	tag_t item_rev_tag = va_arg(largs, tag_t);
	logical  isNew = va_arg(args, int);			    
	tag_t Attachrelation_type=NULLTAG;
	tag_t Attach_type_rel=NULLTAG;
	tag_t *attachments1;
	tag_t		filetag = NULLTAG;
	tag_t		datasettype = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t  	itemrev= NULLTAG;
	tag_t project	 = NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType	= 1;
	char *item_ids=NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *busUnit=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	int count;
	int cnt1;
	int count1;
	int j;
	tag_t projtag = NULLTAG;
	tag_t *Ownprojtag = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		dataset = NULLTAG;
	logical active = TRUE;
	// char *item_type=NULL;
	// char *design_grp=NULL;
	// char *part_type=NULL;
	// char full_group[20];

	// logical hasBypass=false;
	// logical part_found=false;

	tag_t userSession=NULLTAG;
	char *Type = va_arg(largs, char *);
			   //tag_t *newBomline_tag = va_arg(largs, tag_t *);
			   va_end( largs );
			   printf("\n Start Update *****T5TechSpecCre_post111\n");fflush(stdout);
			   ITK_CALL( AOM_ask_value_string(item_tag, "item_id",&item_ids));
				ITK_CALL( AOM_ask_value_string(item_tag, "object_name",&Desc));
				ITK_CALL( AOM_ask_value_string(item_tag, "t5_ProjectCode",&ProjName));
				ITEM_ask_latest_rev(item_tag,&itemrev);
				ITK_CALL( AOM_ask_value_string(itemrev, "item_revision_id",&Itemrevid));
				ITK_CALL( AOM_ask_value_string(itemrev, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tag(item_tag, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
				printf("\n item_id=%s Desc=%s Itemrevid=%s isNew=%d ProjName=%s busUnit=%s\n",item_ids,Desc,Itemrevid,isNew,ProjName,busUnit);fflush(stdout);
				
				if(isNew==0)
				{
					printf("\n TechSpec has already created\n");fflush(stdout);
					return ifail;
					
				}
				
				/*********** START : TechSpec DOCUMENTS Finding/create in attach relation******** */
				GRM_find_relation_type("TC_Attaches",&Attachrelation_type);
				if(Attachrelation_type != NULLTAG)
				{
					   
					GRM_list_secondary_objects_only(item_tag,Attachrelation_type,&cnt1,&attachments1);
					printf("\n TechSpec Docs Datasets:%d\n",cnt1);fflush(stdout);
					if(cnt1>0)
					{
						printf("\n Inside TechSpec Docs found n");fflush(stdout);
						for(j=0;j<cnt1;j++)
						{
							//CE_current_user_session_tag(&userSession);
						   // AOM_ask_value_tag(userSession ,"user", &user);
						   // AOM_ask_value_tag(item_tag ,"owning_group", &group);
							//AOM_set_ownership(attachments[j], user,group);

							//move_dataset_to_WIPVolume(attachments[j]);

						}
					}
					else
					{
						//Create TechSpec Datasets process 
						printf("\n Start Create TechSpec Datasets process");fflush(stdout);
						char *FileLoc;
						char *Filename;
						char *modeltmplate;
						FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
						Filename = (char *) MEM_alloc( 100 * sizeof(char) );
						modeltmplate = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(Filename,item_ids);
						tc_strcat(Filename,".docx");
						printf("\n Filename====>[%s]", Filename);fflush(stdout);
						
						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Filename);
						printf("\n FileLoc====>[%s]", FileLoc);fflush(stdout);
						
						tc_strcpy(modeltmplate,busUnit);
						//tc_strcat(modeltmplate,".docx");
						printf("\n modeltmplate====>[%s]", modeltmplate);fflush(stdout);
						AE_find_dataset	(modeltmplate,&dataset);
						
						printf("\n After dataset get ====>[%u]", dataset);fflush(stdout);
						ITK_CALL( AOM_ask_value_string(dataset, "object_name",&dsetName));
						printf("\n After dataset name ====>[%s]", dsetName);fflush(stdout);
						 ifail = AE_export_named_ref(dataset, "word", FileLoc);
						  //ifail = AE_export_named_ref(dataset, "word", "/tmp/HCV1.docx");
						  printf("\n After AE_export_named_ref FileLoc====>[%s]", FileLoc);fflush(stdout);
						
							
							AE_find_datasettype("MSWordX", &datasettype);
							AE_find_tool("MSWord", &tool);
							AE_create_dataset_with_id(datasettype,Filename,Desc, item_ids, "A", &Newdataset);
							AE_set_dataset_tool(Newdataset,tool);
							AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n MSWordX====>");fflush(stdout);
							AOM_save(Newdataset);							
							
							//ResultStatus rstat;
    
							ifail = AOM_refresh(Newdataset, true);
							AOM_lock(Newdataset);
							
							//char os_path[] = "C:\\Users\\infodba\\Desktop\\junk.txt";   

							// import the dataset from the volume to newly created dataset
							char  auto_assign[] = ""; 
							
							ifail = AE_import_named_ref(Newdataset, "word", FileLoc, auto_assign, SS_BINARY);
							
							ifail = AOM_save(Newdataset);
							ifail = AOM_refresh(Newdataset, FALSE);
							ifail = AOM_unlock(Newdataset);						
							
							//End
							
							printf("\n Inside IMAN_specification relation create");fflush(stdout);
							GRM_find_relation_type("IMAN_specification",&Attach_type_rel);
							if(Newdataset)
							{
								printf("\n Inside IMAN_specification Create rel");fflush(stdout);
								ifail = GRM_create_relation(itemrev, Newdataset, Attach_type_rel,NULLTAG, &relationTag);
								ifail = GRM_save_relation(relationTag);
								printf("\n After IMAN_specification Create rel");fflush(stdout);
								
							}
							
							//Assign project process 
							printf("\n Inside Assign project process with ProjName=%s",ProjName);fflush(stdout);
							//ifail = AOM_lock(item_tag);
							ifail = PROJ_find(ProjName, &projtag);
							printf("\n After PROJ_find");fflush(stdout);
							ifail = PROJ_is_project_active(projtag, &active);	
							printf("\n After PROJ_is_project_active");fflush(stdout);							
							tag_t projtag1[]={projtag};		
							tag_t itemtag1[]={item_tag};									
							printf("\n Before PROJ_assign_objects");fflush(stdout);	
							ifail = PROJ_assign_objects(1, projtag1, 1, itemtag1);
							printf("\n After PROJ_assign_objects");fflush(stdout);	
							ifail = WSOM_assign_to_owning_project(item_tag,projtag);//set owning_project	
							printf("\n After WSOM_assign_to_owning_project");fflush(stdout);								
							//ifail = AOM_save(&item_tag);
							//ifail = AOM_unlock(item_tag);
							printf("\n End Assign project process");fflush(stdout);	
							//IMF_fmsfile_import("/tmp/DML_ERCRelease.txt", "DML_ERCRelease.txt",SS_TEXT, &filetag, &fileDescriptor);
							/*IFERR_REPORT(IMF_fmsfile_import(FileLoc, Filename,SS_TEXT, &filetag, &fileDescriptor));
							if(filetag == NULLTAG)
							{
								printf("file tag not found.....");fflush(stdout);
							}
						*/
						
					}
				}
				
				
			   
			   printf("\n End*****T5TechSpecCre_Post item_id=%s projcode=%s \n",item_ids,projcode);fflush(stdout);
			   return 0;

}

extern int TechSpec_register_methods(int *decision, va_list args)
{
                               
         printf("\n Start  *****TechSpec_register_methods\n");fflush(stdout);       
                 int ifail = ITK_ok;
                 METHOD_id_t  method1;
				METHOD_id_t  method2;
                 
                 
                 *decision = ALL_CUSTOMIZATIONS;


               ERROR_CHECK(METHOD_find_method("T5_TSComp", "IMAN_save", &method1));
			   printf("\n  *****METHOD_find_method\n");fflush(stdout);    

			   printf("\n TMML.c: MyType:method - ");fflush(stdout);			   
				if (method1.id != NULLTAG)
				{
					
					printf("\n  *****b4 METHOD_add_pre_action\n");fflush(stdout);    
					ERROR_CHECK( METHOD_add_action(method1, METHOD_pre_action_type,(METHOD_function_t) T5TechSpecCre_pre, NULL));
					printf("\n  *****After T5TechSpecCre_Validation_pre METHOD_add_action\n");fflush(stdout);
					
					printf("\n  *****b4 METHOD_add_Post_action\n");fflush(stdout);    
					ERROR_CHECK( METHOD_add_action(method1, METHOD_post_action_type,(METHOD_function_t) T5TechSpecCre_post, NULL));
					printf("\n  *****After T5TechSpecCre_Validation_post METHOD_add_action\n");fflush(stdout); 		  

					
					
				}

				printf("\n  b4 METHOD_register_prop_method register\n");fflush(stdout); 		
				ERROR_CHECK(METHOD_register_prop_method("T5_TSCompRevision", "t5_TechSpecForPart",  PROP_ask_value_tag_msg, getVehRelationFrmTS, 0,  &method2 ));
				printf("\n  After METHOD_register_prop_method register\n");fflush(stdout); 	
return ifail;
}

//End


extern DLLAPI int techspec_register_callbacks ()
{
    ECHO("techspec_register_callbacks\n");

	printf("\ntechspec_register_callbacks");fflush(stdout);

	ERROR_CHECK(CUSTOM_register_exit ( "techspec", "USER_init_module",(CUSTOM_EXIT_ftn_t) TechSpec_register_methods ));
	//ERROR_CHECK(CUSTOM_register_exit ( "techspec", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  TechSpec_register_methods));

    return ITK_ok;
}

