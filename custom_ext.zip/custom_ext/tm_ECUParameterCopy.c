/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ECUParameterCopy.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for WCQ Result 7 Report.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   06-08-2025
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 06-08-2025 	 Akshay Toke						    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h> 
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
//#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
//#include <bom/bom.h>
#include <tccore/aom_prop.h>
int FDJcount=0;
int GCIcount=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}



//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}


int create_para_relation(char*, char*, tag_t, char*, char*);
extern int ECUParameterCopy(void *retValue)
{ 

	 //char *output	 = NULL;

	int ifail =ITK_ok;
	int vcattr =0;
	int sec_result_count =0;
	tag_t *statustags = NULLTAG;
	tag_t itemrevtag2 = NULLTAG;
	tag_t Latestrev_Tag = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t designtag = NULLTAG;
	tag_t tRelationFind = NULLTAG;
	tag_t itemrevtag = NULLTAG;
	tag_t itemtag = NULLTAG;
	tag_t Relationtag = NULLTAG;
	

	 char		*sItemId 		= NULL;
	 char		*itemName 		= NULL;
	 char		*Releasestatuspt 		= NULL;
	 char		*releasedate 		= NULL;
	 char		*statusname 		= NULL;
	 char		*revid 		= NULL;
	 
     USERARG_get_string_argument(&sItemId);
	 USERARG_get_string_argument(&revid);

	
     printf("\n selected Item revision %s\n",sItemId);
     printf("\n selected Revision Sequenec %s\n",revid);	


	 char		*sItemId2 		= NULL;
	 char		*revid2 		= NULL;

	 USERARG_get_string_argument(&sItemId2);
	 USERARG_get_string_argument(&revid2);

	  printf("\n Item 2 %s\n",sItemId);
	   printf("\n Item revision 2 %s\n",revid2);

	 tag_t relation_type = NULLTAG;
	 tag_t itemtag2 = NULLTAG;
	// tag_t itemrevtag2 = NULLTAG;
	 tag_t sec_tag_para = NULLTAG;
	 tag_t realRelationTag = NULLTAG;
	 tag_t *rellist = NULLTAG;
	 char		*BitValue 		= NULL;
	 char		*Swtype 		= NULL;
	 char		*Swtype2 		= NULL;
	 char		*type_name				= NULL;
	 char		*type_name2				= NULL;
	 tag_t objTypeTag = NULLTAG;
	 tag_t objTypeTag2 = NULLTAG;

	 int count=0;
	 int i=0;

	  ITK_CALL(ITEM_find_item(sItemId,&itemtag));
	   if (itemtag)
	   {
		ITK_CALL(ITEM_find_revision(itemtag,revid, &itemrevtag));

		ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_SwPartType",&Swtype));
		printf("\n --Swtype= %s  ",Swtype);fflush(stdout);

		ITK_CALL(TCTYPE_ask_object_type(itemrevtag,&objTypeTag));
		ITK_CALL(TCTYPE_ask_name2(objTypeTag, &type_name));
		printf("\n --object_type:%s ", type_name);

        if((tc_strcmp(type_name, "T5_EE_PartRevision") == 0) && (tc_strcmp(Swtype,"PRM")==0))
		 {
             ITK_CALL(ITEM_find_item(sItemId2,&itemtag2));
			 if(itemtag2)
			  {
				ITK_CALL(ITEM_find_revision(itemtag2,revid2, &itemrevtag2));

				ITK_CALL(AOM_ask_value_string(itemrevtag2,"t5_SwPartType",&Swtype2));
				printf("\n --Swtype2= %s  ",Swtype2);fflush(stdout);

				ITK_CALL(TCTYPE_ask_object_type(itemrevtag2,&objTypeTag2));
				ITK_CALL(TCTYPE_ask_name2(objTypeTag2, &type_name2));
				printf("\n --object_type2:%s ", type_name2);

               if((tc_strcmp(type_name2, "T5_EE_PartRevision") == 0) && (tc_strcmp(Swtype2,"PRM")==0))					 
			    {
				   GRM_find_relation_type ("T5_EEPrm", &relation_type);
				   GRM_list_secondary_objects_only(itemrevtag,relation_type, &count, &rellist);

				   printf("\n --parameter count on selected part= %d  ",count);fflush(stdout);

						for (i=0;i<count;i++ )
						{

						  sec_tag_para=rellist[i];
						

						/*	AOM_ask_value_string(sec_tag_para, "object_name", &EP_ID);

							printf("\n checkin_attr_validation--EP_ID: %s ",EP_ID);fflush(stdout);
							AOM_ask_value_string(sec_tag_para, "t5_EPUnit", &EPUnit);
							AOM_ask_value_string(sec_tag_para, "t5_EPLen", &EPLen);
							AOM_ask_value_string(sec_tag_para, "t5_ECUType", &ECUType);
							AOM_ask_value_string(sec_tag_para, "t5_EPDidValue", &EPDidValue);
							AOM_ask_value_string(sec_tag_para, "t5_ECUVendor", &ECUVendor);
							AOM_ask_value_string(sec_tag_para, "t5_ECUVersion", &ECUVersion);*/


							 GRM_find_relation(itemrevtag,sec_tag_para,relation_type,&realRelationTag);
							if(realRelationTag != NULLTAG)
							{
								AOM_ask_value_string(realRelationTag,"t5_BitValue",&BitValue);
								printf("\n user entered value is:%s ", BitValue);

								ITK_CALL(create_para_relation(sItemId2, revid2, sec_tag_para, BitValue, BitValue));

							}
							else
							{
								printf("\n ************ realRelationTag == NULLTAG ************ ");fflush(stdout);
							}



						}
			  }
		    }
			else
			 {
				printf("\n part2 not found:%s ", sItemId2);

			 }
	     }
      }
	  else
	  {
	  printf("\n part2 not found:%s ", sItemId);
	  }


	return ifail; 
}

int create_para_relation(char* part_no, char* rev_id, tag_t object, char* BitValue, char* ParamValue)
{
	int ifail =ITK_ok;
        int                             i                                                       = 0;
        int                             count                                           = 0;

        char                    *obj_string                                     = NULL;

        tag_t                   *sec_tag                                        = NULL;

        tag_t                   ee_part_rev_tag                         = NULLTAG;
        tag_t                   relation_type                           = NULLTAG;
        tag_t                   new_relation                            = NULLTAG;
        tag_t                   rel_exist                                       = NULLTAG;


                int     number_of_types2;

                tag_t *         type_tag3_R;

                tag_t   object_create_input_tag3_R                  = NULLTAG;



        printf("\nGoing to create relation between EE Part and ECU Parameter Master...!!\n");
        ITK_CALL(ITEM_find_rev (part_no, rev_id, &ee_part_rev_tag));
        printf("\npart:%s and rev:%s\n", part_no, rev_id);
        if(ee_part_rev_tag != NULLTAG)
        {
                printf("\nEE part revision found...!!\n");
                ITK_CALL(GRM_find_relation_type ("T5_EEPrm", &relation_type));

                if(relation_type != NULLTAG)
                {

                   /*   ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
                        ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));*/

                        printf("\nRelation type found...!!\n");
                       //////////////////////////////////
						tag_t relation_type=NULLTAG;
						tag_t reltag=NULLTAG;
						tag_t rel2=NULLTAG;
						tag_t *rellist2=NULLTAG;
						int cnt =0;
						char* paraobjname=NULL;
						char* curruntname=NULL;
						int found=0;

					   GRM_find_relation_type ("T5_EEPrm", &relation_type);
					   GRM_list_secondary_objects_only(ee_part_rev_tag,relation_type, &cnt, &rellist2);
					   
					   AOM_ask_value_string(object, "object_name", &curruntname);
					   printf("\n Current Clause name: %s ",curruntname);fflush(stdout);

					   for (int r=0;r<cnt;r++)
					   {
						rel2  = rellist2[r];

						AOM_ask_value_string(rel2, "object_name", &paraobjname);

						printf("\n Clause object name: %s ",paraobjname);fflush(stdout);
						if (tc_strcmp(curruntname,paraobjname)==0)
						{
							found=1;
						}

					   }

					   if (found==1)
					   {
						 
						 printf("\n Clause already available: %s ",curruntname);fflush(stdout);

						/*   GRM_find_relation(ee_part_rev_tag,object,relation_type,&reltag);
						   if (reltag!=NULLTAG)
						   {
							   printf("\n IUpdating User entered value");fflush(stdout);
							   ITK_CALL(AOM_refresh(reltag,1));
							   ITK_CALL(AOM_UIF_set_value(reltag,"t5_BitValue",BitValue));
							    ITK_CALL(AOM_save_without_extensions(reltag));
							   ITK_CALL(AOM_refresh(reltag,0));
							   ITK_CALL(AOM_unlock(reltag));
						   }*/
						   
					   }
					   else
						{
						   printf("\n Clause not available so creating Relation: %s ",curruntname);fflush(stdout);
						ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
						ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));

						}


                }
        }
        return ifail;
}

extern int tm_ECUParameterCopy(int *decision, va_list args)
{	
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    int retValueType;
	int nargs = 4;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) ); 
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ;
	printf("\n tm_ECUParameterCopy before....tm_ECUParameterCopy");fflush(stdout);  
	ifail=USERSERVICE_register_method("ECUParameterCopy",(USER_function_t)ECUParameterCopy,nargs,inputArgTypes,retValueType);
	return ifail;
}


extern DLLAPI int tm_ECUParameterCopy_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ECUParameterCopy");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_ECUParameterCopy", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ECUParameterCopy);
	printf("\n After registering userservice....tm_ECUParameterCopy");fflush(stdout);
	return(ITK_ok);
}


