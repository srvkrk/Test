#include <epm/epm_toolkit_tc_utils.h>

#include "tm_apl_std_common_function.c"
#include <Fnd0Participant/participant.h>
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

/*********************/ 
int cnt = 0;
int cntFlag = 0;


//Start Code to Explode BOM -4

//End Code to Explode BOM -4



static int t5UpdateLifecycleStatePE(tag_t object_tag, char* lifecycleStateName){
	int n_values_checkin	= 0;
	int cunt1				= 0;
	int flag				= 0;
	int	ifail				= 0;
	int st_count1			= 0;

	date_t*	start_end_date	= NULL;
	
	date_t	test_date_1;
	date_t	test_date_2;
	
    char*	value					=NULL;
	char	cNextDate[20]={0};

	char *class_name	 = NULL;
	char *Release_Status = NULL;

	tag_t		class_id					= NULLTAG;
	tag_t		tReleaseStatusList_checkin	= NULLTAG;
	tag_t*		attr_tags_checkin			= NULLTAG;
	tag_t		status_rel					= NULLTAG;
	tag_t*		status_list1				= NULLTAG;
	//tag_t    	propEff_tag				    = NULLTAG;
	tag_t		eff_d						= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical		retain							= 0;
	logical		stat;
    char*    	propEff_tag				    = NULL;
	printf("\n Ketan Inside t5UpdateLifecycleStatePE \n");

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1){
		 printf("\n Load Success \n");
	}
	else{
		printf("\n Load Failure \n");
	}

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0){
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++){
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
		    printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
            if(tc_strcmp(lifecycleStateName,"T5_LcsErcRlzd")==0){
				if(tc_strcmp(Release_Status,"T5_LcsReview")==0 || (tc_strcmp(Release_Status,"T5_LcsWorking")==0) || (strcmp(Release_Status,"ERC Review")==0) || (strcmp(Release_Status,"ERC Working")==0)){
					CALLAPI(POM_unload_instances (1,&object_tag));
					CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
					CALLAPI(POM_is_loaded(object_tag,&log1));

					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
					printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save_without_extensions(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));
					CALLAPI(AOM_unlock(object_tag));
				}
				else{
					flag = flag+1;
				}
			}
		}
	}

	if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
	if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	
	char*	PreRevOnly			= NULL;
	char*	RevOnly				= NULL;
	char*	Part_Rev			= NULL;
	char*	Part_Rev_copy		= NULL;
	char*	Part_rev_Id			= NULL;
	char*	PlantLCSFlag		= NULL;
	char*	Part_clr_ind		= NULL;
	char*	Part_no				= NULL;
	char*	old_to_date			= NULL;
	char*	WSO_Name			= NULL;
	char cCurrentAccessDate[20]={0};

	const char *qry_entries[2];	// Multiple Item Queried Error
	const char *qry_values[2];	// Multiple Item Queried Error

	tag_t*	itemclassp			= NULLTAG;
	tag_t	item				= NULLTAG;
	tag_t*	rev_list			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t*	effectivities_tag	= NULL;
	tag_t*  status_list;
	
	int		Item_count      = 0;
	int     ii				= 0;
	int     RevFlag			= 0;
	int     PreRevFlag		= 0;
	int     st_count		= 0;
	int     iLCS			= 0;
	int     cntLcs			= 0;
	int		n_tags_found	= 0;
	int		jj 				= 0;
	int		n_effectivities = 0;
	int		n_dates		 	= 0;
    
	date_t	Ltest_date_1;
	date_t	Ltest_date_2;
	date_t*	Rel_start_end_values	= NULL;
	date_t*	Lstart_end_date			= NULL;

	logical date_is_valid;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	//if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0 ){
		
		CALLAPI(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime(cCurrentAccessDate);
		//not used below 2 property
		// CALLAPI(AOM_UIF_ask_name(status_rel,"effectivity_text",&propEff_tag));
		// CALLAPI(AOM_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		CALLAPI(WSOM_status_clear_effectivities (status_rel));
		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		CALLAPI(AOM_save_without_extensions(eff_d));
		CALLAPI(AOM_save_without_extensions(status_rel));
		CALLAPI(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		CALLAPI(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		CALLAPI(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0){
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		CALLAPI(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
		if(Item_count > 0){
			RevFlag = 0;
			PreRevFlag = 0;
			for(ii=Item_count-1;ii>=0;ii--){
			   RevOnly = NULL;
			   PreRevOnly = NULL;
			   CALLAPI(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
				printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
				printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
				if(tc_strcmp(Part_Rev,Part_rev_Id)==0){
					RevFlag = 1;
				}
				printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
				if(RevFlag == 1){
				   RevOnly= strtok( Part_Rev_copy, ";" );
				   PreRevOnly= strtok( Part_rev_Id, ";" );
				   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				   if(tc_strcmp(RevOnly,PreRevOnly)!=0){
					  PreRevFlag = 1;
					}
				}
				printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
				if(PreRevFlag == 1){
					CALLAPI(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
					if(st_count == 0){
					printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
					break;
					}
					else{
						for (iLCS=0;iLCS<st_count ;iLCS++ ){
							CALLAPI(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s\n",class_name);fflush(stdout);
							if(tc_strcmp(class_name,lifecycleStateName)==0){
								getCurrentDateTime(cCurrentAccessDate);
								printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
								if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 ))){
									return ifail;
								}
								if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
								printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
								if(n_effectivities > 0){
									for(jj=0;jj<n_effectivities;jj++){
										if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_rel,effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
										printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
										if(n_dates > 0){
											if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date ))){
												return ifail;
											}
											printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
											if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 ))){
												return ifail;
											}
											printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
											if(date_is_valid != true){
												printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
											}
											else{
												printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
											}
										}
										else{
											printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
										}
									}
											
											// //
											// printf("\n KEtan update Value\n");fflush(stdout);
											// 
											// CALLAPI(ITK_string_to_date("25-Jul-2023 00:00", &Ltest_date_1 ));
											// CALLAPI(ITK_string_to_date("28-Jul-2023 00:00", &Ltest_date_2 ));
											// 
											// //
									Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
									Lstart_end_date[0] = Ltest_date_1;
									Lstart_end_date[1] = Ltest_date_2;

									printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
									if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS]))){
										return ifail;
									}
									printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
									if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d ))){
										return ifail;
									}
									printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
									if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d))){
										return ifail;
									}
									printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
									if(ITK_ok != (ifail = AOM_save_without_extensions(status_list[iLCS]))){
										return ifail;
									}
									printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
									if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 ))){
										return ifail;
									}
								}
								break;
							}
						}
					printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
					break;
					}
				}  /// End Prev Rev  Flag Loop
			}
		} /// End Prev Rev
	}
	return 0;
}
void setAddTAG_PE(int *count,tag_t **objlist,tag_t obj ){ // Added By Ketan TZ 1.76
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}
int AssignPEReviewer(tag_t PEdml_tag){	
	char*	PE_DML_No			= NULL;
	char*	PE_Checker			= NULL;
	
	tag_t	relation				= NULLTAG;
	tag_t	participant_tag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	
	int		ifail					= 0;
	
	printf("\n Ketan Inside AssignPEReviewer  \n");fflush(stdout);

	CALLAPI(AOM_ask_value_string(PEdml_tag,"item_id",&PE_DML_No));
	printf("\n AssignPEReviewer :PE_DML_No => %s \n",PE_DML_No);fflush(stdout);

	CALLAPI(AOM_ask_value_string(PEdml_tag,"t5_PeChkr",&PE_Checker));
	printf("\n PE_Checker => %s \n",PE_Checker);fflush(stdout);

	char*			APL_Plnr_Grp		= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			participant_type	= NULLTAG;

	int				num_of_roles		= 0;
	int				i					= 0;
	int				num_of_members		= 0;
	int				b					= 0;
	int				FlaggAssignPERevier	= 0;

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"PE_CVBU");

	printf("\n PE Group Name => [%s]\n",APL_Plnr_Grp);fflush(stdout);

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	
	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags));

	printf("\n PE: No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			
			if(strstr(rolename,"PE") && strstr(rolename,"CAM") && strstr(rolename,"Default")==NULL ) 
			{
				printf("\n Match Found for PE CAM => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n PE : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					
					for (b=0;b<num_of_members ;b++  )
					{
						CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n PE : User ID Name :[%s]\n",userid);
						
						FlaggAssignPERevier = 1;

						TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
						printf("\n ChangeSpecialist1 Test 3333 \n");fflush(stdout);
						setAddTAG_PE(&p1,&ptypes,participant_type);
						printf("\n ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
						setAddTAG_PE(&p2,&ptypes2,member_tags[b]);
						printf("\n ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITKCALL(PARTICIPANT_add_participants(PEdml_tag,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignPERevier==1)
				{
					printf("\n PERevier : Break \n");fflush(stdout);
					break;
				}
			}
			
		}

	}
	
	printf("\n FlaggAssignPERevier for default : [%d]\n",FlaggAssignPERevier);fflush(stdout);
	
	return ITK_ok;

}
int pe_dml_assignment( EPM_action_message_t msg ){

	int		error_code	= ITK_ok;
	int     ifail		= 0;		
		
	char*	item_type			= NULL;
	char*	type_name			= NULL;
	char*	item_id				= NULL;
	char*	Task_no				= NULL;
	char**	DesignGroupList;
	char*	CurrentTask			= NULL;
	char*	parent_name			= NULL;
	char*	ecntypeVal			= NULL;
	char*	tsk_object_name		= NULL ;
	char*	tsk_object_type		= NULL ;
	
	int		count				= 0;
	int		noAttachment		= 0;
	int		noTaskAttachment 	= 0;
	
	tag_t   PEdml_rev_tag        = NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t	rootTask			= NULLTAG;
	tag_t*	attachments		= NULLTAG;

	printf("\n ************** Ketan inside pe_dml_assignment***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n pe_dml_assignment \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		PEdml_rev_tag = attachments[0];
		if(TCTYPE_ask_object_type(PEdml_rev_tag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject => %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_PEECRRevision")==0)
	{
		printf("\n Inside NEW class T5_PEECRRevision......\n");fflush(stdout);
		AOM_ask_value_string( PEdml_rev_tag, "item_id", &item_id);
		AOM_ask_value_string( PEdml_rev_tag, "current_id", &Task_no);

		printf("\n PE DML Number => %s \n",item_id);fflush(stdout);

		if(PEdml_rev_tag != NULLTAG )
		{
			CALLAPI(AssignPEReviewer(PEdml_rev_tag));
		}
	}
	else
	{
	  	printf("\n No proper class T5_PEECRRevision......\n");fflush(stdout);
	}

	return error_code;
}

int pe_dml_release( EPM_action_message_t msg ){
	
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objErcTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t			TaskSVRRevisionTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			TaskSVRRevision		= NULLTAG;
	tag_t*			ERCDMLRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			DerivedsvrRelationTAG= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			ERCDMLTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t Release_date;


	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				countSVR				= 0;
	int				count_erc			= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
    int 	n_instances =1;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
     tag_t 	  *ReleaseDateTgs = NULLTAG;
     tag_t 	  ReleaseDateTg = NULLTAG;
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
     logical * 	date_is_valid  = false;
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char*	type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char   type_name_erc[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	char AplRlzdLc[40] ;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];	
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char	*parttype=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n ************** Ketan Inside pe_dml_release ***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ketan pe_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0){
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);
	}
	
	// Control Object for Calling EXE // Added By Ketan TZ 1.73
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"PE","Stamping","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1){
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0){
		printf("\n Control Object Based Execution \n");fflush(stdout);

	    char* PE_DML_no = NULL;
		
		AOM_ask_value_string( DMLTag,"item_id",&PE_DML_no);

		printf("\n PE_DML_no => %s \n",PE_DML_no);fflush(stdout);

		char* t5_Userinfo1 = NULL;
		char cmd[100];

		tag_t PE_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPI(AOM_ask_value_string(PE_obj,"t5_Userinfo1",&t5_Userinfo1));	
		sprintf(cmd,"%s %s",t5_Userinfo1,PE_DML_no);
		printf("Ketan Excuting Command = %s",cmd);fflush(stdout);
		system(cmd);
		printf("\n PE : After executing Command \n");fflush(stdout);
	}
	else{
		printf("\n Non - Control Object Based Execution \n");fflush(stdout);

		if(strcmp(type_name,"T5_PEECRRevision")==0){
			printf("\n inside class T5_PEECRRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			
			printf("\n PE DML item_id => %s \n",DML_no);

			strcpy(lcsToset,"T5_LcsErcRlzd");

			getCurrentDateTime(cCurrentAccessDate);
			printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
			CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
		  
			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);

			if (DMLTag != NULLTAG){
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						
				CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
				
				printf("\n PE DML to Task Count : %d",count);fflush(stdout);
				TaskRevTag = TaskRevision[TaskCnt];
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ ){
					TaskRevTag = TaskRevision[TaskCnt];

					counted_tag_list_t tlNewTargets = {0};
					int initial_tag_list_size = 16; // Reference PR-8968371 // 26062023
					tlNewTargets.list = (tag_t *)MEM_alloc(initial_tag_list_size * (sizeof(tag_t)));

					CALLAPI(EPM__add_to_tag_list(TaskRevTag, &tlNewTargets));

					CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
					printf("\n object_type is :%s",object_type);fflush(stdout);
					if(strcmp(object_type,"T5_PEECRTaskRevision")==0){
						PartCnt=0;
						//printf("\n Task Stamping \n");fflush(stdout);
						//status = t5UpdateLifecycleStatePE(TaskRevTag, lcsToset);
						CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
						printf("\n PE Task DML PartCnt: %d",PartCnt);fflush(stdout);
						if (PartCnt>0){
							GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
							for (k=0;k<PartCnt ;k++ ){
								printf("\n PE DML for k =:%d",k);fflush(stdout);
								AssyTag=PartTags[k];

								CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n PE DML Part_no is :%s",Part_no);	fflush(stdout);

								CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
								printf("\n PE DML Parttype  is :%s",parttype);	fflush(stdout);

								if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
								if(TCTYPE_ask_name2(objTypeTag,&type_name1));
								printf("\n PE DML AssyTag type_name1 := %s", type_name1);fflush(stdout);

								CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
								printf("\n PE DML AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

								CALLAPI(EPM__add_to_tag_list(AssyTag, &tlNewTargets));
								printf("\n Test 1  \n");fflush(stdout);
							}
						}
						printf("\n Test 2  \n");fflush(stdout);
						int *piAttachTypes = NULL;
						int ii = 0;
						piAttachTypes = (int *) MEM_alloc (tlNewTargets.count * sizeof(int));
						for (ii = 0; ii < tlNewTargets.count; ii++){
							printf("\n Test 2.1  \n");fflush(stdout);
							piAttachTypes[ii] = EPM_target_attachment;
						}
						printf("\n Test 4  \n");fflush(stdout);
						CALLAPI(AOM_refresh(rootTask, TRUE));
						printf("\n Test 3 \n");fflush(stdout);
						
						CALLAPI(EPM_add_attachments(rootTask, tlNewTargets.count, tlNewTargets.list, piAttachTypes));
						printf("\n Test 5  \n");fflush(stdout);
						
						if(piAttachTypes) MEM_free(piAttachTypes);
						
						CALLAPI(AOM_save_without_extensions(rootTask));
						printf("\n Test 6  \n");fflush(stdout);

						for (ii = 0; ii < tlNewTargets.count; ii++){
							printf("\n Stamping : %d\n",ii);fflush(stdout);
							status = t5UpdateLifecycleStatePE(tlNewTargets.list[ii], lcsToset);

						}
						printf("\n Test 7  \n");fflush(stdout);
						CALLAPI(EPM_remove_attachments(rootTask,tlNewTargets.count,tlNewTargets.list));
						printf("\n Test 8 \n");fflush(stdout);
					}

				}  /// Solution Item end
						   
				printf("\n PE DML Stamping \n");fflush(stdout);
				status = t5UpdateLifecycleStatePE(DMLTag, lcsToset); //DML status stamped thru workflow.
			}
		}
		else{
		  	printf("\n No proper class class T5_PEECRRevision......\n");fflush(stdout);
		}
	}

	return error_code;
}

int pe_dml_claim( EPM_action_message_t msg ){
	int		status;
	int		max_char_size = 80;

	char*	CurrentTask			= NULL;
	char*	parent_name			= NULL;
	char*	Part_no				= NULL;
	char*	PartTypeStr			= NULL;
	char*	type_name1			= NULL;
	char*	item_id 			= NULL;
	char*	DML_ReleaseStatus	= NULL;
	char*	Part_ReleaseStatus	= NULL;
	char*	WSO_Name			= NULL;
	char*	type_name			= NULL;
	char*	lcsToset			= NULL;
    char*	lcsTosetR			= NULL;
	char*	object_type			= NULL;
	
	tag_t	rootTask			= NULLTAG;
	tag_t*	PE_TaskRevision		= NULLTAG;
	tag_t*	PartTags			= NULLTAG;
	tag_t	PE_TaskRevTag		= NULLTAG;
	tag_t	AssyTag				= NULLTAG;
	tag_t*  PE_DML_status_list	= NULLTAG;
	tag_t*  PE_Part_status_list	= NULLTAG;
	tag_t	PE_DMLTag			= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t*	attachments			= NULLTAG;
	tag_t   DML_status			= NULLTAG;
	tag_t   Part_status			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;

	int		ifail				= 0;
	int		error_code			= ITK_ok;
	int		num					= 0;
	int		i					= 0;
	int		j					= 0;
	int		ii					= 0;
	int		noAttachment 		= 0;
	int		noTaskAttachment 	= 0;
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;
	int     PE_DML_st_count		= 0;
	int     PE_Part_st_count	= 0;
	int     DML_cnt				= 0;
	int     Part_cnt			= 0;
	int     DMLFlag				= 0;
	int     PartFlag			= 0;

	logical retain=false;
    logical stat  ;
	
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));


    printf("\n ************** Ketan Inside pe_dml_claim ***************\n ");fflush(stdout);

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n pe_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		PE_DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(PE_DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject => %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_PEECRRevision")==0 || strcmp(CurrentTask,"Review The Changes For PE DML")==0)
	{
		printf("\n Inside class T5_PEECRRevision......\n");fflush(stdout);
		AOM_ask_value_string( PE_DMLTag, "item_id", &item_id);
		
		printf("\n PE DML_no => [%s]\n",item_id);

		strcpy(lcsToset,"T5_LcsReview");
		strcpy(lcsTosetR,"T5_LcsWorking");  
    	
		// ITKCALL(WSOM_ask_release_status_list(PE_DMLTag,&PE_DML_st_count,&PE_DML_status_list));
		// printf("\n PE_DML_st_count => %d \n",PE_DML_st_count);fflush(stdout);
		// 
		// if(PE_DML_st_count>0)
		// {
		// 	for (DML_cnt=0;DML_cnt< PE_DML_st_count;DML_cnt++ )
		// 	{
		// 		WSO_Name=NULL;
		// 		ITKCALL(AOM_ask_name(PE_DML_status_list[DML_cnt],&WSO_Name));
		// 		printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
		// 		if(tc_strcmp(WSO_Name,"")!=0)
		// 			{
		// 				if (tc_strcmp(WSO_Name,lcsToset)==0)
		// 				{
		// 					printf("\n Matched \n");fflush(stdout);
		// 					DMLFlag = 1;
		// 				}
		// 			}
		// 	}
		// }

		// if(DMLFlag == 0)
		// {
		// 	printf("\n Inside Release Status Creation of DML \n");fflush(stdout);
		// 	CALLAPI(RELSTAT_create_release_status(lcsToset,&DML_status));
		// 	CALLAPI(AOM_ask_name(DML_status, &DML_ReleaseStatus));
		// 	printf("\n ******************* DML_ReleaseStatus: %s\n",DML_ReleaseStatus);fflush(stdout);
		// 	CALLAPI(RELSTAT_add_release_status(DML_status,1,&PE_DMLTag,retain));
		// }

		if (PE_DMLTag != NULLTAG)
		{
			GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);

			CALLAPI(GRM_list_secondary_objects_only(PE_DMLTag,relation_type,&count,&PE_TaskRevision));
			printf("\n No of Task found in PE DML => %d \n",count);fflush(stdout);

			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				PE_TaskRevTag = PE_TaskRevision[TaskCnt];

				CALLAPI(AOM_ask_value_string(PE_TaskRevTag,"object_type",&object_type));
				printf("\n object_type is => %s \n",object_type);fflush(stdout);

				if(strcmp(object_type,"T5_PEECRTaskRevision")==0)
				{
					printf("\n Inside class T5_PEECRTaskRevision......\n");fflush(stdout);

					PartCnt=0;
					CALLAPI(AOM_ask_value_tags(PE_TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n PE Task PartCnt => %d \n",PartCnt);fflush(stdout);

					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n [%d]. PE Part_no is => %s \n",k+1,Part_no);	fflush(stdout);

							PartFlag = 0;
							ITKCALL(WSOM_ask_release_status_list(AssyTag,&PE_Part_st_count,&PE_Part_status_list));
							printf("\n PE_Part_st_count => %d \n",PE_Part_st_count);fflush(stdout);

							if(PE_Part_st_count>0)
							{
								for (Part_cnt=0;Part_cnt< PE_Part_st_count;Part_cnt++ )
								{
									WSO_Name=NULL;
									ITKCALL(AOM_ask_name(PE_Part_status_list[Part_cnt],&WSO_Name));
									printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
									if(tc_strcmp(WSO_Name,"")!=0)
										{
											//if (tc_strcmp(WSO_Name,lcsToset)==0 || tc_strcmp(WSO_Name,lcsTosetR)==0 )
											if (tc_strcmp(WSO_Name,lcsToset)==0 ) 
											{
												printf("\n Inside PartFlag=1 \n");fflush(stdout);
												PartFlag = 1;
											}
										}
								}
							}

							if(PartFlag == 0)
							{
								printf("\n Inside PartFlag=0 \n");fflush(stdout);
								//CALLAPI(RELSTAT_create_release_status(lcsToset,&Part_status));
								CALLAPI(RELSTAT_create_release_status(lcsToset,&Part_status)); 
								CALLAPI(AOM_ask_name(Part_status, &Part_ReleaseStatus));
								printf("\n ******************* Part_ReleaseStatus => %s\n",Part_ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(Part_status,1,&AssyTag,retain));
							}
						}
					}
				}
			}
		}
	}
	else
	{
	  	printf("\n No proper class class T5_PEECRRevision......\n");fflush(stdout);
	}

	return error_code;
}





extern int DLLAPI pe_dml_part_attach( METHOD_message_t *msg, va_list  args ){
	printf("\n Attach PE Part to PE task");fflush(stdout);
	tag_t  primary_object 				= va_arg(args, tag_t);
	tag_t  secondary_object 			= va_arg(args, tag_t);
	tag_t  relation_type 				= va_arg(args, tag_t);
	tag_t  objTypeTag					= NULLTAG;
	tag_t  objTypeTag2					= NULLTAG;
	tag_t  master 						= NULLTAG;
	tag_t  latestrev					= NULLTAG;

	char  *type_name					= NULL;
	char  *type_name2					= NULL;
	char  *part_type					= NULL;
	char  *LatestPartRevID				= NULL;
	char  *SecObjRevId					= NULL;

	char  *PartTaskMismatchErr			= NULL;
	char  *LatestPartDropErr			= NULL;
	char  *GrpRoleErr					= NULL;
	char  *AttToSolItemErr				= NULL;
	char  *PrtTypeErr					= NULL;

	tag_t  groupTag						= NULLTAG;
	char  *groupname					= NULL;

	char  *relation_name				= NULL;

	logical     InProcess    				= 0;
	

	
	ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n Primary Object Type Name : %s", type_name); fflush(stdout);
	ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
	ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
	printf("\n Secondary Object Type Name : %s", type_name2); fflush(stdout);
	ITKCALL( AOM_ask_value_logical(primary_object,"fnd0InProcess",&InProcess));
	ITKCALL(TCTYPE_ask_name2( relation_type, &relation_name));

	if(tc_strcmp(type_name,"T5_PEECRTaskRevision") == 0 && InProcess == 1){

		POM_ask_group(&groupname, &groupTag);
		// Checking for PE Group access to user and bypassing for PLM_Support_Group
		if (tc_strcmp(groupname,"PE_CVBU") == 0 || tc_strcmp(groupname,"PLM_Support_Group") == 0 || tc_strcmp(groupname,"dba") == 0){
			printf("\n User is in PE CVBU Group");fflush(stdout);
		}
		else{
			GrpRoleErr = (char*)MEM_alloc(100);
			tc_strcpy(GrpRoleErr,"Please set current Group or Role PE \n Current Role : ");
			tc_strcat(GrpRoleErr,groupname);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,GrpRoleErr);
			return ITK_errStore1;
		}
		
		if(tc_strcmp(type_name,"T5_PEECRTaskRevision")== 0 && tc_strcmp(type_name2,"T5_PeDesignRevision") == 0){	// Check if Part and task both belong to PE Group.
			if(tc_strcmp(relation_name,"CMHasSolutionItem")==0){											// Check if user is adding to Solution item only.
				AOM_ask_value_string(secondary_object,"t5_PartType",&part_type);							// Check if part type is PE.
				if(tc_strcmp(part_type,"PE") == 0){
					tag_t 	*ReleaseStatus				= NULLTAG;
					char 	*Rel_Status_List 			= NULL;
					int		 ReleaseStatusCount			= 0;

					char 	*PartRelErr					= NULL;

					if(ITEM_ask_item_of_rev(secondary_object,&master));										// Check for latest revsion in ERC Review.
					if(ITEM_ask_latest_rev(master,&latestrev));
					AOM_UIF_ask_value(latestrev,"item_revision_id",&LatestPartRevID);						// latest Rev of secondary through API
					AOM_UIF_ask_value(secondary_object,"item_revision_id",&SecObjRevId);					// Selected object latest Rev
					ITKCALL(WSOM_ask_release_status_list(secondary_object,&ReleaseStatusCount,&ReleaseStatus));
					if(ReleaseStatusCount > 0){
						ITKCALL(AOM_ask_name(ReleaseStatus[0],&Rel_Status_List));
						if(tc_strcmp(LatestPartRevID,SecObjRevId) == 0 && tc_strcmp(Rel_Status_List,"T5_LcsReview") == 0){
							char   *PE_Task_name				= NULL;
							char   *Current_Mod_WO_No			= NULL;
							char   *WOMismatchErr				= NULL;
							AOM_ask_value_string(primary_object,"current_id",&PE_Task_name);
							AOM_ask_value_string(secondary_object,"t5_WONo",&Current_Mod_WO_No);
							if(tc_strstr(PE_Task_name,Current_Mod_WO_No) != NULL){
								printf("\nPart in ERC Review and also latest rev & seq.\n Part type - PE Part.\n Work Order of PE Part and PE Task is same.");fflush(stdout);
								return ITK_ok;
							}
							else{
								WOMismatchErr = (char*)MEM_alloc(200);
								tc_strcpy(WOMismatchErr,"Please check Work Order of PE Part and PE DML should be same\n Part Work Order No : ");
								tc_strcat(WOMismatchErr,Current_Mod_WO_No);
								tc_strcat(WOMismatchErr,"\n Task Change Request No : ");
								tc_strcat(WOMismatchErr,PE_Task_name);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,WOMismatchErr);
								return ITK_errStore1;
							}
						}
						else{
							LatestPartDropErr 					= (char *)MEM_alloc(500);
							tc_strcpy(LatestPartDropErr,"The Part is not Latest or the part is not in ERC Review\n Only ERC Review parts are allowd to attach in task.\n Part Releaase Status : ");
							tc_strcat(LatestPartDropErr,Rel_Status_List);
							tc_strcat(LatestPartDropErr,"\n Latest Rev is : ");
							tc_strcat(LatestPartDropErr,LatestPartRevID);
							tc_strcat(LatestPartDropErr,"\n Current Revision is : ");
							tc_strcat(LatestPartDropErr,SecObjRevId);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,LatestPartDropErr);
							return ITK_errStore1;
						}
					}
					else{
						PartRelErr = (char*)MEM_alloc(200);
						tc_strcpy(PartRelErr,"Release Status is blank. Kindly check\n If all ok Kindly Raise a DPDS TMS Ticket");
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,PartRelErr);
						return ITK_errStore1;
					}
				}
				else{
					PrtTypeErr = (char*)MEM_alloc(200);
					tc_strcpy(PrtTypeErr,"Part type is not PE Part\n Please Attach only PE Part to PE Task\n Current Part Type is : ");
					tc_strcat(PrtTypeErr,part_type);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore1,PrtTypeErr);
					return ITK_errStore1;
				}
			}
			else{
				AttToSolItemErr = (char*)MEM_alloc(500);
				tc_strcpy(AttToSolItemErr,"Kindly add part to Solution Items only\n Attaching to Folder : ");
				tc_strcat(AttToSolItemErr,relation_name);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,AttToSolItemErr);
				return ITK_errStore1;
			}
		}
		else{
			PartTaskMismatchErr 				= (char *)MEM_alloc(500);
			tc_strcpy(PartTaskMismatchErr,"Task and Part should belong to PE.\n ");
			tc_strcat(PartTaskMismatchErr,"Task Type : ");
			tc_strcat(PartTaskMismatchErr,type_name);
			tc_strcat(PartTaskMismatchErr,"\n Part Type : ");
			tc_strcat(PartTaskMismatchErr,type_name2);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,PartTaskMismatchErr);
			return ITK_errStore1;
		}
	}
	return ITK_ok;
}

extern int pe_dml_assign_register_method(int *decision, va_list args){
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;
	
	
	if( ITK_ok == EPM_register_action_handler("pe_dml_assignment", "", pe_dml_assignment)){
		printf("\t\n Registered Action Handler pe_dml_assignment \n");fflush(stdout);
	}
	else{
		printf("\t FAILED to register Action Handler pe_dml_assignment\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("pe_dml_claim", "", pe_dml_claim)){
		printf("\t\n Registered Action Handler pe_dml_claim \n");fflush(stdout);
	}
	else{
		printf("\t FAILED to register Action Handler pe_dml_claim \n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("pe_dml_release", "", pe_dml_release)){
		printf("\t\n Registered Action Handler pe_dml_release \n");fflush(stdout);
	}
	else{
		printf("\t FAILED to register Action Handler pe_dml_release \n");fflush(stdout);
	}
	
	ifail = METHOD_find_method("CMHasSolutionItem", GRM_create_msg, &method2);
	if( ifail == ITK_ok ){
		if (method2.id != NULL){
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) pe_dml_part_attach, NULL)!=ITK_ok){
				
			}
		}
		else{
			printf("Method not found!GRM_create_msg\n");
		}
	}
	return ITK_ok;
}

extern DLLAPI int tm_pe_dml_assign_register_callbacks(){
	 CUSTOM_register_exit("tm_pe_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)pe_dml_assign_register_method);

     printf("\n ***~**** registered function tm_pe_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}