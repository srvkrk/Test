#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <unistd.h>
char *removeSpaces(char *str);

char* subString(char*,int,int);

static void ECHO(char *format, ...)
{
	char msg[1000];
	va_list args;
	va_start(args, format);
	vsprintf(msg, format, args);
	va_end(args);
	printf(msg);
	TC_write_syslog(msg);
}

char *removeSpaces(char *str)
{
	int i = 0, j = 0;
	while (str[i])
	{
		if (str[i] != ' ')
		   str[j++] = str[i];
		i++;
	}
	str[j] = '\0';
	return str;
}


#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

;
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}

/*******************************4.*******************************************/
extern int dummytoolservicefunc(void *retValue)
{
	int ifail = ITK_ok;
	int t5SemSet=0;
	int Tot_Qty_DmyTool=0;
	int cnt=0;
    int iSequence=0;
	int partlen = 0;


    char        *Indentno = NULL;
	char        *Partno	            = NULL;
	char		*Dummytooltype      = NULL;
	char		*Qtydummytool            = NULL;
	char        *PrtNo          = NULL;
	char        *Prtproj       = NULL;
	char        *t5DummyTTypeDup    = NULL;
	char        *t5DummyTType1      = NULL;
	char        *t5DummyNew         = NULL;
    char        *Dmycount         = NULL;
    char        *PEPartNum         = NULL;
     tag_t	queryTag	=	NULLTAG;	 
	 char 	*keys[1] 	= 	{"creation_date"};
	 int    num_to_sort =	1;
	 int  	orders[1]  	=	{1};
     int		entries					=	2;
	 tag_t *soDummyObjects = NULLTAG;
	 tag_t *Ercpart = NULLTAG;
	 tag_t *Indentobj = NULLTAG;
	 int coutDummyObjects=0;
	 tag_t			PartTag			= NULLTAG;
	 tag_t			tRelationFind			= NULLTAG;
	 tag_t			Indenttag			= NULLTAG;
	 tag_t			soDummyObjecttag			= NULLTAG;
	 tag_t			DummyTTypeTag			= NULLTAG;
	 tag_t			DummyTCreInTag		= NULLTAG;
	 tag_t			DummyTRevTypeTag		= NULLTAG;
	 tag_t			DummyTRevCreInTag		= NULLTAG;
	 tag_t			DummyToolTag			= NULLTAG;
	 tag_t			DummyToolRevTag			= NULLTAG;
     int				n_strings			=	1;
	 int				l_strings			=	500;
	 int				index				=	0;
	 int				n_found			=	0;
	 int				tcnt			=	0;
	 int				Qtydummytoolint			=	0;
	 int                Dmycountint = 0;
	 int				cntt;
	 int				cntp;
	 int				partlength			=	0;
	 int				dmycnt			=	0;
	 char**			stringArrayDummyT		=	NULL;
	 char*			tempStringt			= NULL;
	 char **qry_part_values = (char **) MEM_alloc(10 * sizeof(char *));
     tag_t		   Indent_dummy_rel_type= NULLTAG;
     tag_t         Fndrelation = NULLTAG;
     tag_t         IndentlatRevTag = NULLTAG;
     tag_t         Indent_dummy_rel = NULLTAG;
	 tag_t	indentdmmyrel		=	NULLTAG;
     tag_t	*dmyList		=	NULLTAG;

	 stringArrayDummyT = (char**)malloc( n_strings * sizeof *stringArrayDummyT );
	 for( index=0; index<n_strings; index++ )
	 {
	 	stringArrayDummyT[index] = (char*)malloc( l_strings + 1 );
	 }
    USERARG_get_string_argument(&Indentno);
	USERARG_get_string_argument(&Dummytooltype);
	USERARG_get_string_argument(&Qtydummytool);



	printf("\n \nDummytoolGenterationServiceCalling Registration Successful ****"); fflush(stdout);
	printf("\n *Input From RAC Code Dummytooltype ::%s",Dummytooltype); fflush(stdout);
	printf("\n *Input From RAC Code Indentno::%s",Indentno); fflush(stdout);
	printf("\n* Input From RAC Code Qtydummytool::%s",Qtydummytool); fflush(stdout);

	 ITKCALL(QRY_find2("Item Revision...", &queryTag));
				 
	 char
	  *qry_entry[2] = {"Item ID", "Type"},
	  *qry_vall[2] =  {Indentno,"PE Tool Indent Revision"};
				 
     ITKCALL(QRY_execute(queryTag, 2, qry_entry, qry_vall, &n_found, &Indentobj));
     Indenttag=Indentobj[0];
     ITKCALL(GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&indentdmmyrel));
     ITKCALL(GRM_list_secondary_objects_only(Indenttag,indentdmmyrel,&dmycnt,&dmyList));
	 printf("\n Dummy tool count : %d",dmycnt);fflush(stdout);

	if(dmycnt>0)
    {
       printf("\n As dummy tool already present go ahead for signoff");fflush(stdout);
	}
	else
	   { 

	      Qtydummytoolint=atoi(Qtydummytool);
	      printf("\n Total_Qty_DmyTool is  ======> %d \n", Qtydummytoolint);fflush(stdout);
  
          for(cnt = 0; cnt < Qtydummytoolint; cnt++)
	      
		  {
			  printf("\n check11111111111\n");fflush(stdout);
	      	    queryTag	=	NULLTAG;
				soDummyObjects = NULLTAG;
				
				ITKCALL(QRY_find2("Item Revision...", &queryTag));
				char 	*qry_part_entries[2] = {"Item ID","Type"};
				qry_part_values[0] = "*";
				qry_part_values[1] = "Dummy Tool Revision";
				
				ITKCALL(QRY_execute_with_sort(queryTag, entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &coutDummyObjects, &soDummyObjects));
				printf("coutDummyObjects is : [%d]",coutDummyObjects);fflush(stdout);	
             
				if (coutDummyObjects>0)
				{
                    soDummyObjecttag=NULLTAG;
					soDummyObjecttag = soDummyObjects[coutDummyObjects-1];

					ITKCALL(AOM_ask_value_string(soDummyObjecttag, "t5_DmyCounter", &Dmycount));
					printf("\n dummy tool counter --> : %s\n",Dmycount); fflush(stdout);

							char Dmycountstr[50];
							PEPartNum=NULL;
                            t5DummyTType1=NULL;
							t5DummyTTypeDup=NULL;
							PrtNo=NULL;
							t5DummyNew=NULL;
							t5DummyTType1=NULL;
						
						    ITKCALL(GRM_find_relation_type("T5_PEToolIndentToPartRel",&tRelationFind));
								if (tRelationFind!=NULLTAG)
								{
									ITKCALL(GRM_list_secondary_objects_only(Indenttag,tRelationFind,&tcnt,&Ercpart));	

									printf("\n\t\t ERC part tcnt : %d",tcnt); fflush(stdout);
									if (tcnt>0)
									{
										for(cntp=0; cntp<tcnt; cntp++)
										{	
											PartTag=NULLTAG;
											PartTag=Ercpart[cntp];

										    ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PrtNo));	
											printf("\n  PrtNo is:%s ..............",PrtNo);fflush(stdout);

											ITKCALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&Prtproj));	
											printf("\n  Prtproj is:%s ..............",Prtproj);fflush(stdout);
							                

										}
									}
								}
                             
							   if(Dummytooltype!= NULL && tc_strcmp(Dummytooltype," ")!=0)
						       {
						    	 t5DummyTTypeDup = Dummytooltype;
						    	 printf("\nDummy tool type: %s\n",t5DummyTTypeDup);fflush(stdout);
						        
						    	 if (tc_strcmp(t5DummyTTypeDup,"Cutting Tool")==0)
						    	 {
						    	 	t5DummyTType1 = "CT";
						    	 }
						    	 else if (tc_strcmp(t5DummyTTypeDup,"Tool Types")==0)
						    	 {
						    	 	t5DummyTType1 = "TH";
						    	 }
						    	 else if ( (tc_strcmp(t5DummyTTypeDup,"Punching Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Welding Tool Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Drilling Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Mascot Template")==0) )
						    	 {
						    	 	t5DummyTType1 = "T";
						    	 }
						    	 else
						    	 	t5DummyTType1 = subString(t5DummyTTypeDup,0,1);
						        
						       }
                                partlength = tc_strlen(PrtNo);

								PEPartNum = subString(PrtNo,1,partlength);

								Dmycountint	=	atoi(Dmycount);
			                    Dmycountint	=	Dmycountint+1;			                    
								sprintf(Dmycountstr,"%d",Dmycountint);

                                printf("Dmycountstr and PEPartNum is %s\n", Dmycountstr,PEPartNum);                                 

						        t5DummyNew = (char *)MEM_alloc(150);
					            tc_strcpy(t5DummyNew,t5DummyTType1);
						        tc_strcat(t5DummyNew,"_");
						        tc_strcat(t5DummyNew,PEPartNum);
                                tc_strcat(t5DummyNew,"_");
								tc_strcat(t5DummyNew,Dmycountstr);
						        

						        printf("\n t5DummyNew: [%s]\n",t5DummyNew);fflush(stdout);
                            
							    ITKCALL( TCTYPE_find_type( "T5_DummyTool", NULL, &DummyTTypeTag) );
							    ITKCALL( TCTYPE_construct_create_input( DummyTTypeTag, &DummyTCreInTag) );
                                
							    ITKCALL( TCTYPE_find_type( "T5_DummyToolRevision", NULL, &DummyTRevTypeTag) );
							    ITKCALL( TCTYPE_construct_create_input( DummyTRevTypeTag, &DummyTRevCreInTag) );
							    printf("\t setting dummy tool Id  ...%s\n", t5DummyNew);fflush(stdout);
                               
							    tc_strcpy( stringArrayDummyT[0], t5DummyNew);
									  
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "item_id", 1,(const char**)stringArrayDummyT) );
									  
							 	tc_strcpy( stringArrayDummyT[0], t5DummyNew);
							 		printf("\t setting Object Name Task Id  ...%s\n", t5DummyNew);fflush(stdout);
									  
									  
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "object_name", 1,(const char**)stringArrayDummyT) );
									  
							 	tc_strcpy( stringArrayDummyT[0], t5DummyNew);
							 		printf("\t setting Object Desc Task Id  ...%s\n", t5DummyNew);fflush(stdout);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "object_desc", 1,(const char**)stringArrayDummyT) );
									  
							 	ITKCALL( AOM_tag_to_string(DummyTRevCreInTag, &tempStringt) );
							 	tc_strcpy( stringArrayDummyT[0], tempStringt);
							 	printf("\nTest0.4..[%s]\n",stringArrayDummyT[0]);fflush(stdout);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "revision", 1,(const char**) stringArrayDummyT) );
							 	tc_strcpy( stringArrayDummyT[0], "A");
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayDummyT) );
							 	
							 	tc_strcpy( stringArrayDummyT[0], Prtproj);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayDummyT) );
								
							 	printf("\n Value to set in dummy tool  %s:%s:%s:%s\n",t5DummyNew,tempStringt,Prtproj,t5DummyTTypeDup);fflush(stdout);
									  
							 	ITKCALL( TCTYPE_create_object( DummyTCreInTag, &DummyToolTag) );
							 	ITKCALL( AOM_save_with_extensions(DummyToolTag) );
									  
							 	ITKCALL(ITEM_ask_latest_rev(DummyToolTag,&DummyToolRevTag));


							 	printf("\nSave \n");fflush(stdout);
							 	if (DummyToolTag!=NULLTAG)
							 	{
							 		printf("\nTASK ITEM IS CREATED\n");fflush(stdout);
							 	}
							 	else
							 	{
							 		printf("\nTASK ITEM IS NOT CREATED\n");fflush(stdout);
							 	}
							 	if (DummyToolRevTag!=NULLTAG)
							 	{
							 		printf("\nTASK ITEM REV IS CREATED\n");fflush(stdout);
									
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyToolType",t5DummyTTypeDup));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyTlIdcr","New"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyToolDrwInd","N"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_SuppA","PE-For Manufacturing of Dies etc"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyCounter",Dmycountstr));
							 	}
							 	else
							 	{
							 		printf("\nTASK ITEM REV IS NOT CREATED\n");fflush(stdout);
							 	}
							 	AOM_save_with_extensions(DummyToolTag);
							 	AOM_save_with_extensions(DummyToolRevTag);
                                                            

								GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&Indent_dummy_rel_type);
                                printf("\n\t check1111.\n" );fflush(stdout);
								if(DummyToolRevTag != NULLTAG && Indent_dummy_rel_type != NULLTAG)
								{
										GRM_create_relation(Indenttag, DummyToolRevTag, Indent_dummy_rel_type,  NULLTAG, &Indent_dummy_rel);
										GRM_save_relation(Indent_dummy_rel);
										printf("\n\t programme stop for 5 sec.\n" );fflush(stdout);
										sleep(1);
										printf("\n\t programme start.....\n" );fflush(stdout);
								       // ITKCALL(AOM_set_value_string(Indent_dummy_rel,"t5_Qty1Unit","N"));
								       // ITKCALL(AOM_set_value_int(Indent_dummy_rel,"t5_Qty1","1"));
								        //ITKCALL(AOM_set_value_int(Indent_dummy_rel,"t5_OrdQty1","1"));
                                       // AOM_save_with_extensions(Indent_dummy_rel);										

								}					


				}
				else
					{
					   printf("\nDummy Tool not found\n");fflush(stdout);
					}              			  
		     }	
	         printf("\n ALL dummy tool created\n");fflush(stdout);
         }
          
	  return ifail;
    }


 extern int dummytoolserviceupdationfunc(void *retValue)
 {
	int          ifail              = ITK_ok;
    char        *IndentNo           = NULL;
	char        *DummyPartno	    = NULL;
	char		*Dummyoperatn       = NULL;
	char		*Dummydesc          = NULL;
	char        *Dummyordrqty       = NULL;
	char        *Dummyunitqty       = NULL;
	char        *dummy_id       = NULL;
	int				n_found			=	0;
	int				n_founddmy			=	0;
	int				n_foundoprtn		=	0;
	int				Dmyunitqty			=	0;
	int				Dmyordrqty			=	0;
	int				k			        =	0;
    int				dmmyPartCnt			=	0;
	
	tag_t	queryTag	=	NULLTAG;
    tag_t			Indenttag			= NULLTAG;
	tag_t			Dummytag			= NULLTAG;
	tag_t *Indentobj = NULLTAG;
	tag_t *Dummyobj = NULLTAG;
	tag_t			Operationtag			= NULLTAG;
	tag_t *oprtnobj = NULLTAG;
    tag_t		   DummyOprtn_rel_type= NULLTAG;
	tag_t         dummy_oprtn_rel = NULLTAG;
	tag_t         IndentDummy_rel_type = NULLTAG;
	tag_t         IndentDummy_rel = NULLTAG;
	tag_t         dmmyTag = NULLTAG;
    tag_t	      *dmmyPartTags				=	NULLTAG;
    
     USERARG_get_string_argument(&IndentNo);
	 USERARG_get_string_argument(&DummyPartno);
	 USERARG_get_string_argument(&Dummyoperatn);
	 USERARG_get_string_argument(&Dummyordrqty);
	 USERARG_get_string_argument(&Dummyunitqty);

	printf("\n dummytoolserviceupdationfunc Registration Successful ****"); fflush(stdout);
	printf("\n IndentNo ::%s",IndentNo); fflush(stdout);
	printf("\n DummyPartno::%s",DummyPartno); fflush(stdout);
	printf("\n Dummyoperatn::%s",Dummyoperatn); fflush(stdout);
	printf("\n Dummydesc::%s",Dummydesc); fflush(stdout);
	printf("\n Dummyordrqty::%s",Dummyordrqty); fflush(stdout);
	printf("\n Dummyunitqty::%s",Dummyunitqty); fflush(stdout);

	 ITKCALL(QRY_find2("Item Revision...", &queryTag));
				 
	       char
	        *qry_entry[2] = {"Item ID", "Type"},
	        *qry_vall[2] =  {IndentNo,"PE Tool Indent Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag, 2, qry_entry, qry_vall, &n_found, &Indentobj));
	       printf("\n\t\t Indent tcnt : %d",n_found); fflush(stdout);
          if(n_found>0)
	      {
           Indenttag=Indentobj[0];
	      }
	      
	      char
	        *qry_entrydmy[2] = {"Item ID", "Type"},
	        *qry_valldmy[2] =  {DummyPartno,"Dummy Tool Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag, 2, qry_entrydmy, qry_valldmy, &n_founddmy, &Dummyobj));
	       printf("\n\t\t Dummy part tcnt : %d",n_founddmy); fflush(stdout);
          if(n_founddmy>0)
	      {
           Dummytag=Dummyobj[0];
	      }
	      
	      char
	        *qry_entryoprtn[2] = {"Item ID", "Type"},
	        *qry_valloprtn[2] =  {Dummyoperatn,"Estimate Oprtn Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag, 2, qry_entryoprtn, qry_valloprtn, &n_foundoprtn, &oprtnobj));
	       printf("\n\t\t Operation tcnt : %d",n_foundoprtn); fflush(stdout);
          if(n_foundoprtn>0)
	      {
           Operationtag=oprtnobj[0];
	      }
	      
          		GRM_find_relation_type("T5_DmyToolToOperation",&DummyOprtn_rel_type);
                   printf("\n\t check1111.\n" );fflush(stdout);
	      	if(Dummytag != NULLTAG && Operationtag != NULLTAG && DummyOprtn_rel_type != NULLTAG)
	      	{
	      			GRM_create_relation(Dummytag, Operationtag, DummyOprtn_rel_type,  NULLTAG, &dummy_oprtn_rel);
	      			GRM_save_relation(dummy_oprtn_rel);
	      			printf("\n\t Dummy Opearation Relation Created.\n" );fflush(stdout);                   									
	      
	      	}	

                 Dmyunitqty=atoi(Dummyunitqty);
                 Dmyordrqty=atoi(Dummyordrqty);
                  printf("\n Dummyunitqty::%d",Dmyunitqty); fflush(stdout);
				  printf("\n Dummyunitqty::%d",Dmyordrqty); fflush(stdout);

				  
                  GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&IndentDummy_rel_type);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt,&dmmyPartTags));
					printf("\n\n\t\t Dummy dmmyPartCnt:%d",dmmyPartCnt);fflush(stdout);
					if (dmmyPartCnt>0)
					{
						for (k=0;k<dmmyPartCnt ;k++ )
						{	
							dummy_id=NULL;
							dmmyTag=dmmyPartTags[k];
                            ITKCALL(AOM_ask_value_string(dmmyTag, "item_id", &dummy_id));
                            printf("\n\n\t\t dummy id is =:%s",dummy_id);fflush(stdout);

                            if (tc_strcmp(DummyPartno,dummy_id)==0)
                            {
							    if(Indenttag != NULLTAG && dmmyTag != NULLTAG && IndentDummy_rel_type != NULLTAG)
							    {
								  ITKCALL(GRM_find_relation(Indenttag,dmmyTag,IndentDummy_rel_type,&IndentDummy_rel));
	                              ITKCALL(AOM_set_value_string(IndentDummy_rel,"t5_Qty1Unit","N"));
			                      ITKCALL(AOM_set_value_int(IndentDummy_rel,"t5_Qty1",Dmyunitqty));
			                      ITKCALL(AOM_set_value_int(IndentDummy_rel,"t5_OrdQty1",Dmyordrqty));
                                   printf("\n\t properties updated.\n" );fflush(stdout);
		                           GRM_save_relation(IndentDummy_rel);
							    }

							}
						}
					}

	      
          
	  return ifail;
    }


 extern int toolcostserviceupdationfunc(void *retValue)
 {
	int          ifail              = ITK_ok;
    char        *IndentNo1           = NULL;
	char        *DummyPartno1	    = NULL;
	char		*peoperatn       = NULL;
	char		*peestcost          = NULL;
	char        *Designcost       = NULL;
	char        *Manufactcost       = NULL;
	char        *Totlestcost       = NULL;
	char        *Orderqty       = NULL;
	char        *dummy_id1       = NULL;
	char        *Tooltype       = NULL;
	int				n_found1			=	0;
	int				n_founddmy1			=	0;
	int				n_foundoprtn1		=	0;
	int				Dmyunitqty1			=	0;
	int				ordrqty1			=	0;
	int				k1			        =	0;
    int				dmmyPartCnt1			=	0;
	
	tag_t	queryTag1	=	NULLTAG;
    tag_t			Indenttag1			= NULLTAG;
	tag_t			Dummytag1			= NULLTAG;
	tag_t *Indentobj1 = NULLTAG;
	tag_t         IndentDummy_rel_type1 = NULLTAG;
	tag_t         IndentDummy_rel1 = NULLTAG;
	tag_t         dmmyTag1 = NULLTAG;
    tag_t	      *dmmyPartTags1				=	NULLTAG;
    
     USERARG_get_string_argument(&IndentNo1);
	 USERARG_get_string_argument(&DummyPartno1);
	 USERARG_get_string_argument(&peoperatn);
	 USERARG_get_string_argument(&Designcost);
	 USERARG_get_string_argument(&Manufactcost);
	 USERARG_get_string_argument(&Totlestcost);
	 USERARG_get_string_argument(&Orderqty);
	 USERARG_get_string_argument(&peestcost);

	printf("\n toolcostserviceupdationfunc Registration Successful ****"); fflush(stdout);
	printf("\n IndentNo ::%s",IndentNo1); fflush(stdout);
	printf("\n DummyPartno::%s",DummyPartno1); fflush(stdout);
	printf("\n peoperatn::%s",peoperatn); fflush(stdout);
	printf("\n Designcost::%s",Designcost); fflush(stdout);
	printf("\n Manufactcost::%s",Manufactcost); fflush(stdout);
	printf("\n Totlestcost::%s",Totlestcost); fflush(stdout);
	printf("\n Orderqty::%s",Orderqty); fflush(stdout);
	printf("\n peestcost::%s",peestcost); fflush(stdout);

	 ITKCALL(QRY_find2("Item Revision...", &queryTag1));
				 
	       char
	        *qry_entry[2] = {"Item ID", "Type"},
	        *qry_vall[2] =  {IndentNo1,"PE Tool Indent Revision"};
	      			 
           ITKCALL(QRY_execute(queryTag1, 2, qry_entry, qry_vall, &n_found1, &Indentobj1));
	       printf("\n\t\t Indent tcnt : %d",n_found1); fflush(stdout);
          if(n_found1>0)
	      {
           Indenttag1=Indentobj1[0];
	      }	      	
             ITKCALL(AOM_ask_value_string(Indenttag1, "t5_ToolType", &Tooltype));
			 if((tc_strcmp(Tooltype,"NEW")==0) || (tc_strcmp(Tooltype,"MIX")==0))
			 { 
                 ordrqty1=atoi(Orderqty);
				  printf("\n ordrqty1::%d",ordrqty1); fflush(stdout);
           
				  
                  GRM_find_relation_type("T5_PEToolIndToDmyToolRel1",&IndentDummy_rel_type1);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag1,"T5_PEToolIndToDmyToolRel1",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);
					if (dmmyPartCnt1>0)
					{
						for (k1=0;k1<dmmyPartCnt1 ;k1++ )
						{	
							dummy_id1=NULL;
							dmmyTag1=dmmyPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(dmmyTag1, "item_id", &dummy_id1));
                            printf("\n\n\t\t dummy id is =:%s",dummy_id1);fflush(stdout);

                            if (tc_strcmp(DummyPartno1,dummy_id1)==0)
                            {
							    if(Indenttag1 != NULLTAG && dmmyTag1 != NULLTAG && IndentDummy_rel_type1 != NULLTAG)
							    {
								  ITKCALL(GRM_find_relation(Indenttag1,dmmyTag1,IndentDummy_rel_type1,&IndentDummy_rel1));
								  ITKCALL(AOM_lock(IndentDummy_rel1));
			                      ITKCALL(AOM_set_value_int(IndentDummy_rel1,"t5_OrdQty1",ordrqty1));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_DToolDesignCost",Designcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_DToolManuCost",Manufactcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_PETotalTLCost",Totlestcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_OprN",peoperatn));								 
                                  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_CstEst",peestcost));
								  ITKCALL(AOM_save_with_extensions(IndentDummy_rel1) );
								  ITKCALL(AOM_unlock(IndentDummy_rel1));
                                   printf("\n\t properties updated.\n" );fflush(stdout);
		                           //GRM_save_relation(IndentDummy_rel1);
							    }

							}
						}
					}
			 }
			 
			   if((tc_strcmp(Tooltype,"OLD")==0) || (tc_strcmp(Tooltype,"MIX")==0))
			   {
				   ordrqty1=atoi(Orderqty);
				  printf("\n ordrqty1::%d",ordrqty1); fflush(stdout);
           
				  
                  GRM_find_relation_type("T5_PEToolIndentToPEPrtRel1",&IndentDummy_rel_type1);
                  
				  	ITKCALL(AOM_ask_value_tags(Indenttag1,"T5_PEToolIndentToPEPrtRel1",&dmmyPartCnt1,&dmmyPartTags1));
					printf("\n\n\t\t Dummy dmmyPartCnt1:%d",dmmyPartCnt1);fflush(stdout);
					if (dmmyPartCnt1>0)
					{
						for (k1=0;k1<dmmyPartCnt1 ;k1++ )
						{	
							dummy_id1=NULL;
							dmmyTag1=dmmyPartTags1[k1];
                            ITKCALL(AOM_ask_value_string(dmmyTag1, "item_id", &dummy_id1));
                            printf("\n\n\t\t dummy id is =:%s",dummy_id1);fflush(stdout);

                            if (tc_strcmp(DummyPartno1,dummy_id1)==0)
                            {
							    if(Indenttag1 != NULLTAG && dmmyTag1 != NULLTAG && IndentDummy_rel_type1 != NULLTAG)
							    {
								  ITKCALL(GRM_find_relation(Indenttag1,dmmyTag1,IndentDummy_rel_type1,&IndentDummy_rel1));
								  ITKCALL(AOM_lock(IndentDummy_rel1));
			                      ITKCALL(AOM_set_value_int(IndentDummy_rel1,"t5_OrdQty1",ordrqty1));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_PePartDesignCost",Designcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_PePartManCost",Manufactcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_PETotalTLCost",Totlestcost));
								  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_OprN",peoperatn));								 
                                  ITKCALL(AOM_set_value_string(IndentDummy_rel1,"t5_CstEst",peestcost));
								  ITKCALL(AOM_save_with_extensions(IndentDummy_rel1) );
								  ITKCALL(AOM_unlock(IndentDummy_rel1));
                                   printf("\n\t properties updated for PE part\n" );fflush(stdout);
							    }

							}
						}
					}
			   }
	      
          
	  return ifail;
    }


extern int dummytoolcreateservicefunc(void *retValue)
{
	int ifail = ITK_ok;
	int t5SemSet=0;
	int Tot_Qty_DmyTool=0;
	int cnt=0;
    int iSequence=0;
	int partlen = 0;


    char        *Indentno = NULL;
	char        *Partno	            = NULL;
	char		*Dummytooltype      = NULL;
	char		*Qtydummytool            = NULL;
	char        *PrtNo          = NULL;
	char        *Prtproj       = NULL;
	char        *t5DummyTTypeDup    = NULL;
	char        *t5DummyTType1      = NULL;
	char        *t5DummyNew         = NULL;
    char        *Dmycount         = NULL;
    char        *PEPartNum         = NULL;
     tag_t	queryTag	=	NULLTAG;	 
	 char 	*keys[1] 	= 	{"creation_date"};
	 int    num_to_sort =	1;
	 int  	orders[1]  	=	{1};
     int		entries					=	2;
	 tag_t *soDummyObjects = NULLTAG;
	 tag_t *Ercpart = NULLTAG;
	 tag_t *Indentobj = NULLTAG;
	 int coutDummyObjects=0;
	 tag_t			PartTag			= NULLTAG;
	 tag_t			tRelationFind			= NULLTAG;
	 tag_t			Indenttag			= NULLTAG;
	 tag_t			soDummyObjecttag			= NULLTAG;
	 tag_t			DummyTTypeTag			= NULLTAG;
	 tag_t			DummyTCreInTag		= NULLTAG;
	 tag_t			DummyTRevTypeTag		= NULLTAG;
	 tag_t			DummyTRevCreInTag		= NULLTAG;
	 tag_t			DummyToolTag			= NULLTAG;
	 tag_t			DummyToolRevTag			= NULLTAG;
     int				n_strings			=	1;
	 int				l_strings			=	500;
	 int				index				=	0;
	 int				n_found			=	0;
	 int				tcnt			=	0;
	 int				Qtydummytoolint			=	0;
	 int                Dmycountint = 0;
	 int				cntt;
	 int				cntp;
	 int				partlength			=	0;
	 int				dmycnt			=	0;
	 char**			stringArrayDummyT		=	NULL;
	 char*			tempStringt			= NULL;
	 char **qry_part_values = (char **) MEM_alloc(10 * sizeof(char *));
     tag_t		   Indent_dummy_rel_type= NULLTAG;
     tag_t         Fndrelation = NULLTAG;
     tag_t         IndentlatRevTag = NULLTAG;
     tag_t         Indent_dummy_rel = NULLTAG;
	 tag_t	indentdmmyrel		=	NULLTAG;
     tag_t	*dmyList		=	NULLTAG;

	 stringArrayDummyT = (char**)malloc( n_strings * sizeof *stringArrayDummyT );
	 for( index=0; index<n_strings; index++ )
	 {
	 	stringArrayDummyT[index] = (char*)malloc( l_strings + 1 );
	 }
    USERARG_get_string_argument(&Indentno);
	USERARG_get_string_argument(&Dummytooltype);


	printf("\n dummytoolcreateservicefunc Registration Successful ****"); fflush(stdout);
	printf("\n *Input From RAC Code Dummytooltype ::%s",Dummytooltype); fflush(stdout);
	printf("\n *Input From RAC Code Indentno::%s",Indentno); fflush(stdout);

	 ITKCALL(QRY_find2("Item Revision...", &queryTag));
				 
	 char
	  *qry_entry[2] = {"Item ID", "Type"},
	  *qry_vall[2] =  {Indentno,"PE Tool Indent Revision"};
				 
     ITKCALL(QRY_execute(queryTag, 2, qry_entry, qry_vall, &n_found, &Indentobj));
     Indenttag=Indentobj[0];

			  printf("\n check11111111111\n");fflush(stdout);
	      	    queryTag	=	NULLTAG;
				soDummyObjects = NULLTAG;
				
				ITKCALL(QRY_find2("Item Revision...", &queryTag));
				char 	*qry_part_entries[2] = {"Item ID","Type"};
				qry_part_values[0] = "*";
				qry_part_values[1] = "Dummy Tool Revision";
				
				ITKCALL(QRY_execute_with_sort(queryTag, entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &coutDummyObjects, &soDummyObjects));
				printf("coutDummyObjects is : [%d]",coutDummyObjects);fflush(stdout);	
             
				if (coutDummyObjects>0)
				{
                    soDummyObjecttag=NULLTAG;
					soDummyObjecttag = soDummyObjects[coutDummyObjects-1];

					ITKCALL(AOM_ask_value_string(soDummyObjecttag, "t5_DmyCounter", &Dmycount));
					printf("\n dummy tool counter --> : %s\n",Dmycount); fflush(stdout);

							char Dmycountstr[50];
							PEPartNum=NULL;
                            t5DummyTType1=NULL;
							t5DummyTTypeDup=NULL;
							PrtNo=NULL;
							t5DummyNew=NULL;
							t5DummyTType1=NULL;
						
						    ITKCALL(GRM_find_relation_type("T5_PEToolIndentToPartRel",&tRelationFind));
								if (tRelationFind!=NULLTAG)
								{
									ITKCALL(GRM_list_secondary_objects_only(Indenttag,tRelationFind,&tcnt,&Ercpart));	

									printf("\n\t\t ERC part tcnt : %d",tcnt); fflush(stdout);
									if (tcnt>0)
									{
										for(cntp=0; cntp<tcnt; cntp++)
										{	
											PartTag=NULLTAG;
											PartTag=Ercpart[cntp];

										    ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PrtNo));	
											printf("\n  PrtNo is:%s ..............",PrtNo);fflush(stdout);

											ITKCALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&Prtproj));	
											printf("\n  Prtproj is:%s ..............",Prtproj);fflush(stdout);
							                

										}
									}
								}
                             
							   if(Dummytooltype!= NULL && tc_strcmp(Dummytooltype," ")!=0)
						       {
						    	 t5DummyTTypeDup = Dummytooltype;
						    	 printf("\nDummy tool type: %s\n",t5DummyTTypeDup);fflush(stdout);
						        
						    	 if (tc_strcmp(t5DummyTTypeDup,"Cutting Tool")==0)
						    	 {
						    	 	t5DummyTType1 = "CT";
						    	 }
						    	 else if (tc_strcmp(t5DummyTTypeDup,"Tool Types")==0)
						    	 {
						    	 	t5DummyTType1 = "TH";
						    	 }
						    	 else if ( (tc_strcmp(t5DummyTTypeDup,"Punching Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Welding Tool Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Drilling Template")==0) || (tc_strcmp(t5DummyTTypeDup,"Mascot Template")==0) )
						    	 {
						    	 	t5DummyTType1 = "T";
						    	 }
						    	 else
						    	 	t5DummyTType1 = subString(t5DummyTTypeDup,0,1);
						        
						       }
                                partlength = tc_strlen(PrtNo);

								PEPartNum = subString(PrtNo,1,partlength);

								Dmycountint	=	atoi(Dmycount);
			                    Dmycountint	=	Dmycountint+1;			                    
								sprintf(Dmycountstr,"%d",Dmycountint);

                                printf("Dmycountstr and PEPartNum is %s\n", Dmycountstr,PEPartNum);                                 

						        t5DummyNew = (char *)MEM_alloc(150);
					            tc_strcpy(t5DummyNew,t5DummyTType1);
						        tc_strcat(t5DummyNew,"_");
						        tc_strcat(t5DummyNew,PEPartNum);
                                tc_strcat(t5DummyNew,"_");
								tc_strcat(t5DummyNew,Dmycountstr);
						        

						        printf("\n t5DummyNew: [%s]\n",t5DummyNew);fflush(stdout);
                            
							    ITKCALL( TCTYPE_find_type( "T5_DummyTool", NULL, &DummyTTypeTag) );
							    ITKCALL( TCTYPE_construct_create_input( DummyTTypeTag, &DummyTCreInTag) );
                                
							    ITKCALL( TCTYPE_find_type( "T5_DummyToolRevision", NULL, &DummyTRevTypeTag) );
							    ITKCALL( TCTYPE_construct_create_input( DummyTRevTypeTag, &DummyTRevCreInTag) );
							    printf("\t setting dummy tool Id  ...%s\n", t5DummyNew);fflush(stdout);
                               
							    tc_strcpy( stringArrayDummyT[0], t5DummyNew);
									  
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "item_id", 1,(const char**)stringArrayDummyT) );
									  
							 	tc_strcpy( stringArrayDummyT[0], t5DummyNew);
							 		printf("\t setting Object Name Task Id  ...%s\n", t5DummyNew);fflush(stdout);
									  
									  
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "object_name", 1,(const char**)stringArrayDummyT) );
									  
							 	tc_strcpy( stringArrayDummyT[0], t5DummyNew);
							 		printf("\t setting Object Desc Task Id  ...%s\n", t5DummyNew);fflush(stdout);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "object_desc", 1,(const char**)stringArrayDummyT) );
									  
							 	ITKCALL( AOM_tag_to_string(DummyTRevCreInTag, &tempStringt) );
							 	tc_strcpy( stringArrayDummyT[0], tempStringt);
							 	printf("\nTest0.4..[%s]\n",stringArrayDummyT[0]);fflush(stdout);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTCreInTag, "revision", 1,(const char**) stringArrayDummyT) );
							 	tc_strcpy( stringArrayDummyT[0], "A");
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayDummyT) );
							 	
							 	tc_strcpy( stringArrayDummyT[0], Prtproj);
							 	ITKCALL( TCTYPE_set_create_display_value( DummyTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayDummyT) );
								
							 	printf("\n Value to set in dummy tool  %s:%s:%s:%s\n",t5DummyNew,tempStringt,Prtproj,t5DummyTTypeDup);fflush(stdout);
									  
							 	ITKCALL( TCTYPE_create_object( DummyTCreInTag, &DummyToolTag) );
							 	ITKCALL( AOM_save_with_extensions(DummyToolTag) );
									  
							 	ITKCALL(ITEM_ask_latest_rev(DummyToolTag,&DummyToolRevTag));


							 	printf("\nSave \n");fflush(stdout);
							 	if (DummyToolTag!=NULLTAG)
							 	{
							 		printf("\nTASK ITEM IS CREATED\n");fflush(stdout);
							 	}
							 	else
							 	{
							 		printf("\nTASK ITEM IS NOT CREATED\n");fflush(stdout);
							 	}
							 	if (DummyToolRevTag!=NULLTAG)
							 	{
							 		printf("\nTASK ITEM REV IS CREATED\n");fflush(stdout);
									
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyToolType",t5DummyTTypeDup));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyTlIdcr","New"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyToolDrwInd","N"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_SuppA","PE-For Manufacturing of Dies etc"));
								    
								    ITKCALL(AOM_set_value_string(DummyToolRevTag,"t5_DmyCounter",Dmycountstr));
									
									ITKCALL(AOM_set_value_string(DummyToolRevTag,"object_desc","PE Planner had created Dummy Tool through System at Assign WorkOrder Assignment"));
							 	}
							 	else
							 	{
							 		printf("\nTASK ITEM REV IS NOT CREATED\n");fflush(stdout);
							 	}
							 	AOM_save_with_extensions(DummyToolTag);
							 	AOM_save_with_extensions(DummyToolRevTag);
                                                            

								GRM_find_relation_type("T5_PEToolIndentToDmyToolRel",&Indent_dummy_rel_type);
                                printf("\n\t check1111.\n" );fflush(stdout);
								if(DummyToolRevTag != NULLTAG && Indent_dummy_rel_type != NULLTAG)
								{
										GRM_create_relation(Indenttag, DummyToolRevTag, Indent_dummy_rel_type,  NULLTAG, &Indent_dummy_rel);
										GRM_save_relation(Indent_dummy_rel);								

								}					


				}
				else
					{
					   printf("\nDummy Tool not found\n");fflush(stdout);
					}              			  

	   return ifail;
    }


/*******************************3.*******************************************/
int tm_dummytoolgenerationServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 3;
	int retValueType;
	int *inputArgTypes = (int *)MEM_alloc (nargs *sizeof(int));

	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] =  USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;


	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("dummytoolservicefunc",(USER_function_t)dummytoolservicefunc,nargs,inputArgTypes,retValueType);

	return ifail;


}

int tm_dummytoolUpdationServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 5;
	int retValueType;
	int *inputArgTypes = (int *)MEM_alloc (nargs *sizeof(int));

	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;


	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("dummytoolserviceupdationfunc",(USER_function_t)dummytoolserviceupdationfunc,nargs,inputArgTypes,retValueType);

	return ifail;


}

int tm_toolcostUpdationServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 8;
	int retValueType;
	int *inputArgTypes = (int *)MEM_alloc (nargs *sizeof(int));

	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	inputArgTypes[5] = USERARG_STRING_TYPE;
	inputArgTypes[6] = USERARG_STRING_TYPE;
	inputArgTypes[7] = USERARG_STRING_TYPE;


	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("toolcostserviceupdationfunc",(USER_function_t)toolcostserviceupdationfunc,nargs,inputArgTypes,retValueType);

	return ifail;


}

int tm_dummytoolcreateServiceCalling()
{
	int ifail = ITK_ok;
	int nargs = 2;
	int retValueType;
	int *inputArgTypes = (int *)MEM_alloc (nargs *sizeof(int));

	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;



	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("dummytoolcreateservicefunc",(USER_function_t)dummytoolcreateservicefunc,nargs,inputArgTypes,retValueType);

	return ifail;


}


/*******************************2.*******************************************/

int all_dummytoolService(int *decision,va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;

	tm_dummytoolgenerationServiceCalling();
	tm_dummytoolUpdationServiceCalling();
	tm_toolcostUpdationServiceCalling();
    tm_dummytoolcreateServiceCalling();
	return ifail;

}

/*******************************1.*******************************************/
extern DLLAPI int tm_dummytoolcreation_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....");   
	ifail=CUSTOM_register_exit ( "tm_dummytoolcreation", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)all_dummytoolService);
	return ( ITK_ok );
}

//USERSERVICE_register_methods