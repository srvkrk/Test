/****************************************************************************************************
*  File            :   tm_Mail_Approval.c
*  Created By      :   Anvesh Bujule
*  Created On      :   18 Jul 2025
*  Purpose         :   Mail Approval
*
*  
*****************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcfile_cache.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <tc/preferences.h>
//#include "participant.h"
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <time.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error6 (EMH_USER_error_base+27)
/*--------------------------------------------------*/

#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;
void strrpl(char * a)
{
	int i = 0;
	//while(a[i]!='\0')
	for (i = 0; a[i] != '\0'; i++)
    {
        if(a[i]==',')
        {
            a[i]=';';
        }
		if(a[i]=='\n')
        {
            a[i]=' ';
        }
    }
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}


#define WRONG_USAGE 100001
char* subString (char* mainStringf ,int fromCharf,int toCharf);
//
void dousage()
{
   printf("\nUSAGE: t5ListEmptyVisPdfDesRev -fromDate= -toDate= -sType= -outFile= \n");
   printf("\E.g: t5ListEmptyVisPdfDesRev -fromDate=01-May-2018 -toDate=02-May-2018 -sType=CMI2Part -outFile=out.txt \n");
   return;
}

void lower_string(char s[])
{
	int c = 0;

	while (s[c] != '\0')
	{
		if (s[c] >= 'A' && s[c] <= 'Z')
		{
			s[c] = s[c] + 32;
		}
		c++;
	}
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int Webservice_Mail_approve( EPM_action_message_t msg)
{
 
   
   tag_t* attachments            = NULLTAG;
   tag_t* Webservice_Particpant  = NULLTAG;
   tag_t* subtask                = NULLTAG;
   tag_t* rps                    = NULLTAG;
   tag_t* Memberstag             = NULLTAG;
   tag_t *Web_Particpant         = NULLTAG;
   tag_t *Mail_object            = NULLTAG;


 
   tag_t rootTask                = NULLTAG;
   tag_t tasktag                 = NULLTAG;
   tag_t Web_Particpant_rel_type = NULLTAG;
   tag_t attachments1            = NULLTAG;
   tag_t Usertag            = NULLTAG;
   tag_t persontag            = NULLTAG;
   tag_t Mailqry_tg            = NULLTAG;

   char *CurrentTask        = NULL;
   char *Web_ParticpantNamedup        = NULL;
   char *businessUnit        = NULL;
   char *firsttok        = NULL;
   char *filename        = NULL;
   char *Secondtok        = NULL;
   char *taskStatus        = NULL;
   char *parent_name        = NULL;
   char *objecttype         = NULL;
   char *taskname           = NULL;
   char *objectname         = NULL;
   char *Web_ParticpantName = NULL;
   char *WebserviceShellpath = NULL;
   char *childParentTaskNam = NULL;
   char *workFlowName = NULL;
   char *personmail = NULL;
   char * command    = NULL;
   // char * doublete    = {' " '};
   char *doublete = NULL;
   command = (char *)MEM_alloc(500);
   doublete = (char *)MEM_alloc(500);
   firsttok = (char *)MEM_alloc(50);
   Secondtok = (char *)MEM_alloc(50);



   int participantcount = 0;
   int tskcount         = 0;
   int noAttachment     = 0;
   
   int PrtCount   = 0;
   int Web_count  = 0;
   int rp_count   = 0;
   int Mailobj_count   = 0;

   int i = 0;
   int l = 0;
   int p = 0;
   int j = 0;
   int h = 0;
   int BreakFlag = 0;
  
   tc_strcpy(doublete,"");
   tc_strcat(doublete,"\"");
  // tc_strcat(doublete,"\"");
  

    printf("\n after cat555 %s\n",doublete);fflush(stdout);
    printf("\n Inside the Webservice Mail Approved Function ...\n");fflush(stdout);

    ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
    
		     
    ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n Webservice- CurrentTask: %s \n",CurrentTask);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&workFlowName));
    printf("\n Webservice- workFlowName: %s \n",workFlowName);fflush(stdout);
		     
    ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
    printf("\n Webservice- parent Name: %s \n",parent_name);fflush(stdout);


	//ITK_CALL(EPM_ask_root_task(job_Tag,&rootTask));               					    
    ITK_CALL(EPM_ask_sub_tasks(rootTask,&tskcount,&subtask));
	printf("\n Webservice- tskcount : %d \n",tskcount);fflush(stdout);
	if(QRY_find2("Control Objects...", &Mailqry_tg));

	char *Mail_entry1[2] = {"SYSCD","SUBSYSCD"};
	char **Mail_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	Mail_RelVal[0] = "MailApprovalBusinessUnit";
	Mail_RelVal[1] = "ON";

	ITK_CALL(QRY_execute(Mailqry_tg, 2, Mail_entry1, Mail_RelVal, &Mailobj_count, &Mail_object));

     printf("\n Webservice- Mailobj_count : %d \n",Mailobj_count);fflush(stdout);

	if(Mailobj_count>0)
	{
       ITK_CALL(AOM_ask_value_string(Mail_object[p],"t5_Userinfo1",&businessUnit));
	    printf("\n Webservice- t5_Userinfo1 :%s \n",businessUnit);fflush(stdout);
     

	for(i=0; i<tskcount;i++)
	{


		tasktag=subtask[i];

	 
	   ITK_CALL(AOM_ask_value_string(tasktag,"fnd0Status",&taskStatus));
     
       printf("\n Webservice- taskStatus :%s \n",taskStatus);fflush(stdout);
       printf("\n Webservice- BreakFlag :%d \n",BreakFlag);fflush(stdout);
	   if(BreakFlag==0)
	   {

	   if(tc_strcmp(taskStatus,"Pending")==0)
		{

            ITK_CALL(AOM_ask_value_string(tasktag,"object_name",&taskname));
			printf("\n Webservice- taskname :%s \n",taskname);fflush(stdout);
		     
		    ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		    printf("\n Webservice- Target Attachment:%d \n",noAttachment);fflush(stdout);

			ITK_CALL(AOM_ask_value_tags(tasktag,"fnd0FirstTargetParticipants",&Web_count,&Web_Particpant));
			printf("\n Webservice-  Web_count:%d \n",Web_count);fflush(stdout);




			for(h=0;h<Web_count;h++)
			{
			
			   ITK_CALL(AOM_UIF_ask_value(Web_Particpant[h],"fnd0AssigneeUser",&Web_ParticpantName));
			   printf("\n Webservice--- Web_ParticpantName :%s \n",Web_ParticpantName);fflush(stdout);	
			   tc_strdup(Web_ParticpantName,&Web_ParticpantNamedup);
			   printf("\n Webservice- Web_ParticpantNamedup :%s \n",Web_ParticpantNamedup);fflush(stdout);


			   firsttok=tc_strtok(Web_ParticpantNamedup,"(");    ///Govind Betkar (gbb916241)
			   Secondtok=tc_strtok(NULL,")");
				printf("\n Webservice- firsttok--:------ :%s \n",firsttok);fflush(stdout);
				printf("\n Webservice- Secondtok :-----:%s \n",Secondtok);fflush(stdout);
				ITK_CALL(SA_find_user2(Secondtok,&Usertag));
				ITK_CALL(SA_ask_user_person(Usertag,&persontag));
				ITK_CALL(SA_ask_person_email_address(persontag,&personmail));
				printf("\n Webservice- personmail ---:-------:%s \n",personmail);fflush(stdout);

				///ITK_CALL(SA_find_person2(firsttok,&persontag));
				if(persontag)
				{

				     printf("\n persontag Tag Found \n");

				}
				else
				{
				    printf("\n persontag NOT Tag Found \n");
				
				}

				if(Usertag)
				{
				
				printf("\n User Tag Found \n");
				
				}
				else
				{
				 

				 printf("\n User Tag Not Found \n");
				
				}


				ITK_CALL(PREF_ask_char_value("Mail Apporval Webservice Path", 0 , &WebserviceShellpath ));
				printf("\n Webservice---- WebserviceShellpath %s \n",WebserviceShellpath);fflush(stdout);
			
			 
				for(j=0; j<noAttachment;j++)
				{
				
					attachments1=attachments[j];
						 
					ITK_CALL(AOM_ask_value_string(attachments1,"object_type",&objecttype));
					printf("\n  Webservice object_type %s \n",objecttype);fflush(stdout);  //T5_ParRequestRevision

					  ITK_CALL(AOM_ask_value_string(attachments1,"object_name",&objectname));
					  printf("\n  Webservice objectname %s \n",objectname);fflush(stdout);


					 tc_strcpy(command,"");
					 printf("\n inside pFirst_webservice condition \n");
					 tc_strcat(command,WebserviceShellpath);
					 tc_strcat(command,"pFirst_webservice.sh");
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,objectname);
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,businessUnit);
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					  tc_strcat(command,doublete);
					 tc_strcat(command,workFlowName);
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,Web_ParticpantName);
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,taskname);
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,"/home/ercdev/devgroups/Aditya_ak927337/Shell/sample.xlsx");
					 tc_strcat(command,doublete);
					 tc_strcat(command," ");
					 tc_strcat(command,doublete);
					 tc_strcat(command,personmail);
					 tc_strcat(command,doublete);
					 printf("\n Berfor exicute Command ----------: %s", command);
	                 system(command);


					 BreakFlag=1;
					 
					 

				}

			}
			 printf("\n Break Exected \n");
			//break;
		}
		}

	}

	}
	else
	{
	
	  printf("\n Control Object count is Zero\n");fflush(stdout);
	
	}

	printf("\n END of Web service Handler\n");fflush(stdout);
	

	return ITK_ok;


}

//Ritesh: DCR/DML mail approval
int DCR_Mail_approve( EPM_action_message_t msg)
{ 
	FILE *fd= NULL;
	char		*emailID					=NULL;
	char	* attachname		= NULL;
	char	*AffectedDGrp	=  NULL;
	char	*objectname1	=  NULL;
	char	*Desig_grp			=  NULL;
	char	*dcrStatus			=  NULL;
	char	**design_grp_list	= NULL;
	char	*mint_ref_no			=  NULL;
	char	*pnsc_cat			=  NULL;
	char	*proce_stg_lst			=  NULL;
	char	*projects			=  NULL;
	char	**rel_Aprop			=  NULL;
	char	*revignsID			=  NULL;
	char	*strWFtsk			=  NULL;
	char	*AffectedItem		=  NULL;
	char	*Aggrigte			=  NULL;
	char	*ApproverTD			=  NULL;
	char	*Asuppchange			=  NULL;
	char	*AsyConfRel			=  NULL;
	char	*CE_app			=  NULL;
	char	*Capt				=  NULL;
	char	*CatOfChange		=  NULL;
	char	*Chingmt			=  NULL;
	char	*Chmfgpro			=  NULL;
	char	*Cnh_issu_desc		=  NULL;
	char	*Cre_Date			=  NULL;
	char	*CurrMatthikness			=  NULL;
	char	*CurrRawMatV			=  NULL;
	char	*Currentsupp			=  NULL;
	char	*Currentwt			=  NULL;
	char	*DCRRPTinfo3		=  NULL;
	char	*DCRRPTinfo4		=  NULL;
	char	*DCRRPTinfo5		=  NULL;
	char	*DCRRPTinfo6		=  NULL;
	char	*DMC_inR			=  NULL;
	char	*DcrCPVs			=  NULL;
	char	*DcrComdityAffs			=  NULL;
	char	*DcrEstPrtDevTimes			=  NULL;
	char	*DcrExSvrcCosts			=  NULL;
	char	*DcrExSvrcTimes			=  NULL;
	char	*DcrGrnRptFIRAvails			=  NULL;
	char	*DcrIPTVs			=  NULL;
	char	*DcrInterImpacts			=  NULL;
	char	*DcrMfgTimes			=  NULL;
	char	*DcrNVPs			=  NULL;
	char	*DcrPreValues			=  NULL;
	char	*DcrQltyImpcts			=  NULL;
	char	*DcrServicImpcts			=  NULL;
	char	*DcrTrgIncrCosts			=  NULL;
	char	*DcrTrgIncrImpcts			=  NULL;
	char	*Deschpro			=  NULL;
	char	*Dets_cat_chg		=  NULL;
	char	*Disposit			=  NULL;
	char	*DnDInMonths		=  NULL;
	char	*Dt_pro_Amodifi		=  NULL;
	char	*Dt_relea			=  NULL;
	char	*EnvDimensions		=  NULL;
	char	*Failure_Info		=  NULL;
	char	*OC_Prop			=  NULL;
	char	*ObjTyp				= NULL;
	char	*ObjTyp2				= NULL;
	char	*Obje_Typ			=  NULL;
	char	*PM_app			=  NULL;
	char	*Pro_appli			=  NULL;
	char	*Prt_DR				= NULL;  
	char	*Req_agcy			=  NULL;
	char	*Rison			=  NULL;
	char	*SubAggr			=  NULL;
	char	*Sun_cata			=  NULL;
	char	*VC_numb			=  NULL;
	char	*aq_rem			=  NULL;
	char	*cError				= NULL;
	char	*cab1_inp			=  NULL;
	char	*cab2_inp			=  NULL;
	char	*capexLk			=  NULL;
	char	*cs_rem			=  NULL;
	char	*dcrName			=  NULL;
	char	*dcrNumber		=  NULL;
	char	*dcrRevision		=  NULL;
	char	*dcr_loct			=  NULL;
	char	*dcr_matr				=  NULL;
	char	*dcr_no			=  NULL;
	char	*leadCOC			=  NULL;
	char	*matur				=  NULL;
	char	*me_proc			=  NULL;
	char	*moddetails			= NULL;
	char	*mul_k_info			=  NULL;
	char	*objectname			= NULL;
	char	*objects_			=  NULL;
	char	*owng_pro			=  NULL;
	char	*owng_user			=  NULL;
	char	*partID				= NULL;  
	char	*partNo				= NULL;  
	char	*partdesc			= NULL;  
	char	*particip			=  NULL;
	char	*particip_disp			=  NULL;
	char	*password			=  NULL;
	char	*plans_			=  NULL;
	char	*pro_nm			=  NULL;
	char	*pro_nmDup			=  NULL;
	char	*probms			=  NULL;
	char	*proce_stg			=  NULL;
	char	*projID_			=  NULL;
	char	*proj_code			=  NULL;
	char	*proj_id			=  NULL;
	char	*proj_ids			=  NULL;
	char	*proj_obj			=  NULL;
	char	*prop_soln			=  NULL;
	char	*protn			=  NULL;
	char	*qa_rem			=  NULL;
	char	*ref_itm			=  NULL;
	char	*refrncs			=  NULL;
	char	*regl_nmb			=  NULL;
	char	*req_id_			=  NULL;
	char	*requstr			=  NULL;
	char	*requstr_			=  NULL;
	char	*rtcuana			=  NULL;
	char	*stgOfPr			=  NULL;
	char	*ts_rem			=  NULL;
	char	*tvm_rem			=  NULL;
	char	*usd_potns			=  NULL;
	char	*username			=  NULL;
	char	*usr_rat_val			=  NULL;
	char	*veh_calsifi			=  NULL;
	char	*vehic_for			=  NULL;
	char	*vem_rem			=  NULL;
	char	*vpg_rem			=  NULL;
	char	*weitimp			=  NULL;
	char	*workflow_task			=  NULL;
	char            *eMailTo                    = NULL;
	char            *emailBody	                = NULL;
	char            *emailCC                    = NULL;
	char            *emailSub	                = NULL;
	char * DFMSever = NULL;
	char * PrtPrcub = NULL;
	char * ValImpt = NULL;
	char * aq_per = NULL;
	char * buff = NULL;
	char * cocrmk = NULL;
	char * cs_per = NULL;
	char * qa_per = NULL;
	char * ts_per = NULL;
	char * tvm_per = NULL;
	char * vem_per = NULL;
	char * vpg_per = NULL;
	char * wtchng = NULL;
	char **ref_list;
	char *CAB1comt =  NULL;
	char *CAB2comt =  NULL;
	char *CarMakeby = NULL;
	char *ReqUserId = NULL;
	char *cab1per =  NULL;
	char *cab2per =  NULL;
	char *fndObjTyp =  NULL;
	char *nameofroot =  NULL;
	char *person_namee			= NULL;
	char *revision_id = NULL;
	char *wftaskname =  NULL;
	char *AssignmentName =  NULL;
	int     DCR_n_entry     = 1;
	int     DCR_rsltCount   = 0;
	int     FileFlag   = 0;
	int DsgnGrp = 0;
	int SignStatus			=  0;
	int attachmentCount=0, transfermodeCnt=0;
	int desggroup=0;
	int j=0;
	int n,cnt,tskprtcount,ref_count=0,projcnt=0;
	int propcnt=0;
	int releasecnt=0;
	int revcnt=0,mintcnt =0,Dcrpsccnt=0,processcnt=0;
	int size = 10;
	int sq_id			=  0;
	int sq_lmt			=  0;
	int TaskCount			=  0;
	int status=ITK_ok;
	int taskcount = 0;
	int versi_ltd			=  0;
	int workflowtaskcnt=0;
	int tsktodmlrelcount=0;
	int count=0;
	logical  may_chkOtBy;
	logical probs_modif	;
	logical ref_modifabl		;
	logical usr_cn_unma	;
	struct 	tm when;
	tag_t	         DCRqryTag		        = NULLTAG;
	tag_t	        *participant_list	    = NULLTAG;
	tag_t	*dcr_task			= NULLTAG;
	tag_t	*dcrprts			= NULLTAG;
	tag_t	tsktodmlrel		=  NULLTAG;
	tag_t	RefRel_t		=  NULLTAG;
	tag_t	RefRelation			=  NULLTAG;
	tag_t	TextDataset		=  NULLTAG;
	tag_t	TextLatestDat_t		=  NULLTAG;
	tag_t	TextType			=  NULLTAG;
	tag_t	dcr_Ref_Rel			=  NULLTAG;
	tag_t	filetag		=  NULLTAG;
	tag_t	msWordType			=  NULLTAG;
	tag_t	objTypTag			= NULLTAG;
	tag_t	objTypTag2			= NULLTAG;
	tag_t	person_tagg			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t	relationofpart			= NULLTAG;
	tag_t	relationtype			= NULLTAG;
	tag_t	attachments1				=  NULLTAG;
	tag_t	tool		=  NULLTAG;
	tag_t	Tasktag		=  NULLTAG;
	tag_t	user		= NULLTAG;
	tag_t           *DCRCntrlObjectTag      = NULLTAG;
	tag_t           rootTask_t              = NULLTAG;
	tag_t *DCRForms = NULLTAG;
	tag_t *TaskTags = NULLTAG;
	tag_t *DMLRev = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t DCRObjects = NULLTAG;
	tag_t dcr_tag = NULLTAG;
	tag_t job = NULLTAG;
	tag_t job_type = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t roottask = NULLTAG;
	tag_t wftask = NULLTAG;
	tag_t query = NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG;
	time_t 	now;
    
   // char * doublete    = {' " '};
   char * wbs    = NULL;
   char * Approvername    = NULL;
   char * sInfo1    = NULL;
  // char * sInfo2    = NULL;
   char * sInfo3    = NULL;
   char * sInfo5    = NULL;
   char * sInfo6    = NULL;
   char * command    = NULL;
   char *CurrentTask        = NULL;
   char *Secondtok        = NULL;
   char *Web_ParticpantName = NULL;
   char *Web_ParticpantNamedup        = NULL;
   char *objecttype        = NULL;
   char *WebserviceShellpath = NULL;
   char *childParentTaskNam = NULL;
   char *doublete = NULL;
   char *filename        = NULL;
   char *firsttok        = NULL;
   char *parent_name        = NULL;
   char *personmail = NULL;
   char *taskStatus        = NULL;
   char *taskname           = NULL;
   char *TskReviewr           = NULL;
   char *sInfo2           = NULL;
   char *type_name7           = NULL;
   int BreakFlag = 0;
   int PrtCount   = 0;
   int Web_count  = 0;
   int h = 0;
   int i = 0;
   int noAttachment     = 0;  
   int participantcount = 0;
   int rp_count   = 0;
   int tskcount         = 0;
   int CRBcount         = 0;
   int jk         = 0;
   int PartFlag         = 0;
   tag_t *Web_Particpant         = NULLTAG;
   tag_t Usertag            = NULLTAG;
   tag_t DmlCRBTag            = NULLTAG;
   tag_t ObjTypDmlCRB            = NULLTAG;
   tag_t Web_Particpant_rel_type = NULLTAG;
   tag_t persontag            = NULLTAG;
   tag_t rootTask                = NULLTAG;
   tag_t DMLReviTag                 = NULLTAG;
   tag_t tasktag                 = NULLTAG;
   tag_t* Memberstag             = NULLTAG;
   tag_t* Webservice_Particpant  = NULLTAG;
   tag_t* attachments            = NULLTAG;
   tag_t* rps                    = NULLTAG;
   tag_t* subtask                = NULLTAG;
   tag_t* contrlObjs                = NULLTAG;
   tag_t* DmlCRB                = NULLTAG;

   char *DRstat           = NULL;
   char *Reason           = NULL;
   char *rlstype           = NULL;
   char *plant           = NULL;
   char *VehClass           = NULL;

    char	 FileDown[100]			= "";

	Secondtok = (char *)MEM_alloc(50);
    WebserviceShellpath = (char *)MEM_alloc(500);
    command = (char *)MEM_alloc(5000);
	//FileDown = (char *)MEM_alloc(100);
    doublete = (char *)MEM_alloc(500);
    firsttok = (char *)MEM_alloc(50);
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));
	printf("\n Start of DCR_Mail_approve Handler\n");fflush(stdout);
	TC_write_syslog("\n Start of DCR_Mail_approve Handler...");

   tc_strcpy(doublete,"");
   tc_strcat(doublete,"\"");
  
    printf("\n after cat555 %s\n",doublete);fflush(stdout);
    printf("\n Inside the DCR_Mail_approve Function ...\n");fflush(stdout);

    ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
    
		     
    ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n DCR_Webeservice CurrentTask: %s \n",CurrentTask);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&childParentTaskNam));
    printf("\n DCR_Webeservice childParentTask: %s \n",childParentTaskNam);fflush(stdout);
		     
    ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
    printf("\n DCR_Webeservice parent Name: %s \n",parent_name);fflush(stdout);


	//ITK_CALL(EPM_ask_root_task(job_Tag,&rootTask));               					    
    ITK_CALL(EPM_ask_sub_tasks(rootTask,&tskcount,&subtask));
	printf("\n DCR_Webeservice tskcount : %d \n",tskcount);fflush(stdout);

	//////////////////////////////////
	qry_entries[0] ="SYSCD";
	qry_values[0]  ="AUTOSIGNOFF";
	ITK_CALL(QRY_find2("Control Objects...",&query));
	ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
	printf("\n Control objects : count==>%d \n",count);fflush(stdout);
	if (count>0)
	{
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sInfo1));
		printf("\n L1:sInfo1 is : [%s]  \n",sInfo1);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sInfo2));
		printf("\n L1:sInfo2 is : [%s]  \n",sInfo2);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sInfo3));
		printf("\n L1:sInfo3 is : [%s]  \n",sInfo3);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo5",&sInfo5));
		printf("\n L1:sInfo5 is : [%s]  \n",sInfo5);fflush(stdout);
		ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo6",&sInfo6));
		printf("\n L1:sInfo6 is : [%s]  \n",sInfo6);fflush(stdout);
	}
	/////////////////////////////////
	if(tc_strstr(sInfo1,"Auto001") == NULL)
	{
		for(i=0; i<tskcount;i++)
		{
			tasktag=subtask[i];
			ITK_CALL(AOM_ask_value_string(tasktag,"fnd0Status",&taskStatus));

			printf("\n DCR_Webeservice taskStatus :%s \n",taskStatus);fflush(stdout);
			printf("\n DCR_Webeservice BreakFlag :%d \n",BreakFlag);fflush(stdout);
			if(BreakFlag==0)
			{
				if((tc_strcmp(taskStatus,"Started")==0)||(tc_strcmp(taskStatus,"Pending")==0))
				{
					ITK_CALL(AOM_ask_value_string(tasktag,"object_name",&taskname));
					printf("\n DCR_Webeservice taskname :%s \n",taskname);fflush(stdout);
					 
					ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
					printf("\n DCR_Webeservice Target Attachment:%d \n",noAttachment);fflush(stdout);

					for(j=0; j<noAttachment;j++)
					{
						attachments1=attachments[j];	 
						ITK_CALL(AOM_ask_value_string(attachments1,"object_type",&objecttype));
						printf("\n  Webservice object_type %s \n",objecttype);fflush(stdout); 

						ITK_CALL(TCTYPE_ask_object_type(attachments1, &objTypTag));
						ITK_CALL(TCTYPE_ask_name2(objTypTag, &ObjTyp));
						if((tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)||(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)||(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0))
						{		
							ITK_CALL(AOM_ask_value_string(attachments1,"item_id",&objectname1));
							printf("\n  Webservice objectname1 %s \n",objectname1);fflush(stdout);
							
							//ITK_CALL(AOM_ask_value_tags(tasktag,"fnd0FirstTargetParticipants",&Web_count,&Web_Particpant));
							//printf("\n Webservice-  Web_count:%d \n",Web_count);fflush(stdout);
							//Has participant expand
							
							if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
							if (dml_CRB_rel_type!=NULLTAG)
							{
								printf("\n ADPR:P28:DML to Has participant. \n");fflush(stdout);
								if(GRM_list_secondary_objects_only(attachments1,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
								printf("\n ADPR:CV:P29: DmlCRB count: %d",CRBcount);fflush(stdout);
								for (jk=0;jk<CRBcount ;jk++ )
								{	
									//type_name7=NULL;
									DmlCRBTag = DmlCRB[jk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
									if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
									printf("\n ADPR:CV:P30:CE02: Participants Name: %s", type_name7);fflush(stdout);
									PartFlag=0;
									if(tc_strstr(sInfo1,"Auto101") == NULL)
									{
										printf("\n Automail: type_name7:[%s] taskname:[%s]\n",type_name7,taskname);fflush(stdout);
										if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
										{
											if(tc_strstr(sInfo1,"Auto002") == NULL)
											{
												//if((tc_strstr(taskname,"DCR CAB L1 Review") != NULL)&& (tc_strstr(CurrentTask,"DCR CAB L1 Review") != NULL))
												if(tc_strstr(sInfo5,taskname) != NULL)
												{
													if((tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L1")==0)&& (tc_strcmp(taskname,"DCR CAB L1 Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf("\n CAB1:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto007") == NULL)
											{
												//if((tc_strstr(taskname,"DCR CAB L2 Review") != NULL) && (tc_strstr(CurrentTask,"DCR CAB L2 Review") != NULL))
												if(tc_strstr(sInfo5,taskname) != NULL)
												{
													if ((tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L2")==0) && (tc_strcmp(taskname,"DCR CAB L2 Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf("\n CAB2:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto008") == NULL)
											{
												//if(tc_strstr(taskname,"VLD Review") != NULL)
												if(tc_strstr(sInfo5,taskname) != NULL)
												{
													if ((tc_strcmp(type_name7,"T5_DcrVEH_LINE_DIR")==0)&& (tc_strcmp(taskname,"VLD Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" VLD:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
										if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
										{
											//For DML
											if(tc_strstr(sInfo1,"Auto005") == NULL)
											{
												//DR-Gate way Reviewer
												//if((tc_strstr(taskname,"Review of DR-Gateway") != NULL)|| (tc_strstr(taskname,"DR Gateway Review") != NULL))
												if(tc_strstr(sInfo6,taskname) != NULL)
												{
													if ((tc_strcmp(type_name7,"T5_DRGatewayReviewer")==0) && (tc_strcmp(taskname,"DR Gateway Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" DML:DRGateway:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto004") == NULL)
											{
												//CE Reviewer
												//if((tc_strstr(taskname,"Review of CE") != NULL) || (tc_strstr(taskname,"CVBU CE Review") != NULL))
												if(tc_strstr(sInfo6,taskname) != NULL)
												{
													if ((tc_strcmp(type_name7,"T5_CEReviewer")==0) && (tc_strcmp(taskname,"CVBU CE Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" DML:CE:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
										if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
										{
											//For TASK
											if(tc_strstr(sInfo1,"Auto003") == NULL)
											{
												//Peer Reviewer
												//if(tc_strstr(taskname,"Peer Review") != NULL)
												if(tc_strstr(sInfo6,taskname) != NULL)
												{
													if ((tc_strcmp(type_name7,"T5_PeerReviewer")==0) && (tc_strcmp(taskname,"Peer Review")==0))
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" Task:Peer:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
									}
									else
									{
										if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
										{
											if(tc_strstr(sInfo1,"Auto002") == NULL)
											{
												//if((tc_strstr(taskname,"DCR CAB L1 Review") != NULL)&& (tc_strstr(CurrentTask,"DCR CAB L1 Review") != NULL))
												if((tc_strstr(sInfo5,taskname) != NULL)&& (tc_strstr(sInfo5,taskname) != NULL))
												{
													if (tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L1")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" CAB1:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto007") == NULL)
											{
												//if((tc_strstr(taskname,"DCR CAB L2 Review") != NULL) && (tc_strstr(CurrentTask,"DCR CAB L2 Review") != NULL))
												if((tc_strstr(sInfo5,taskname) != NULL) && (sInfo5,taskname) != NULL)
												{
													if (tc_strcmp(type_name7,"T5_DcrCHNG_AUTH_BRD_L2")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" CAB2:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto008") == NULL)
											{
												//if(tc_strstr(taskname,"VLD Review") != NULL)
												if(tc_strstr(sInfo5,taskname) != NULL)
												{
													if (tc_strcmp(type_name7,"T5_DcrVEH_LINE_DIR")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" VLD:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
										if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
										{
											//For DML
											if(tc_strstr(sInfo1,"Auto005") == NULL)
											{
												//DR-Gate way Reviewer
												//if((tc_strstr(taskname,"Review of DR-Gateway") != NULL)|| (tc_strstr(taskname,"DR Gateway Review") != NULL))
												if((tc_strstr(sInfo6,taskname) != NULL)|| (tc_strstr(sInfo6,taskname) != NULL))
												{
													if (tc_strcmp(type_name7,"T5_DRGatewayReviewer")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" DML:DRGateway:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
											if(tc_strstr(sInfo1,"Auto004") == NULL)
											{
												//CE Reviewer
												//if((tc_strstr(taskname,"Review of CE") != NULL) || (tc_strstr(taskname,"CVBU CE Review") != NULL))
												if((tc_strstr(sInfo6,taskname) != NULL)|| (tc_strstr(sInfo6,taskname) != NULL))
												{
													if (tc_strcmp(type_name7,"T5_CEReviewer")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" DML:CE:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
										if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
										{
											//For TASK
											if(tc_strstr(sInfo1,"Auto003") == NULL)
											{
												//Peer Reviewer
												//if(tc_strstr(taskname,"Peer Review") != NULL)
												if(tc_strstr(sInfo6,taskname) != NULL)
												{
													if (tc_strcmp(type_name7,"T5_PeerReviewer")==0)
													{
														PartFlag=1;
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
														printf(" Task:Peer:reviewer: [%s]\n",TskReviewr);fflush(stdout);
													}
												}
											}
										}
									}
	
									printf("\nFInal: TskReviewr:%s PartFlag:%d ",TskReviewr,PartFlag);fflush(stdout);
									if((tc_strlen(TskReviewr) > 0)&&(PartFlag >0))
									{
										tc_strdup(TskReviewr,&Web_ParticpantNamedup);
										tc_strdup(TskReviewr,&Web_ParticpantName);
										printf("\n Web_ParticpantNamedup:[%s] Web_ParticpantName:[%s] \n",Web_ParticpantNamedup,Web_ParticpantName);fflush(stdout);
										firsttok=tc_strtok(Web_ParticpantNamedup,"(");    ///Govind Betkar (gbb916241)
										Secondtok=tc_strtok(NULL,")");
										printf("\n Webservice- firsttok--:------ :%s \n",firsttok);fflush(stdout);
										printf("\n Webservice- Secondtok :-----:%s \n",Secondtok);fflush(stdout);
										ITK_CALL(SA_find_user2(Secondtok,&Usertag));
										ITK_CALL(SA_ask_user_person(Usertag,&persontag));
										ITK_CALL(SA_ask_person_email_address(persontag,&personmail));
										printf("\n Webservice- personmail ---:-------:%s \n",personmail);fflush(stdout);
										//DCR
										if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
										{
											if(AOM_ask_value_string(attachments1,"item_id",&dcrNumber)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"object_name",&dcrName)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"item_revision_id",&dcrRevision)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrDesgGrp",&AffectedDGrp)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrLeadCoc",&leadCOC)!=ITK_ok)PrintErrorStack();
											printf("\n Size of Affected Design group are %s\n",AffectedDGrp);
											if(AOM_UIF_ask_value(attachments1,"EC_affected_item_rel",&AffectedItem)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrAggregate",&Aggrigte)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrAppNam",&ApproverTD)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_DcrCreCatChng",&CatOfChange)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_DcrDesc",&Cnh_issu_desc)!=ITK_ok)PrintErrorStack();
											strrpl(Cnh_issu_desc);						
											if(AOM_ask_value_string(attachments1,"t5_DcrG3Subch",&Dets_cat_chg)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_int(attachments1,"fnd0DSState",&SignStatus)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_EnvDimension",&EnvDimensions)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreFI",&Failure_Info)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrMaterial",&dcr_matr)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"CMMaturity",&matur)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_MinrefNo",&mint_ref_no)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"fnd0mfkinfo",&mul_k_info)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"fnd0MyWorkflowTasks",&workflow_task)!=ITK_ok)PrintErrorStack();	
											if(AOM_ask_value_string(attachments1,"object_string",&objects_)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"owning_user",&owng_user)!=ITK_ok)PrintErrorStack();						
											if(AOM_UIF_ask_value(attachments1,"requestor_user_id",&ReqUserId)!=ITK_ok)PrintErrorStack();						
											if(AOM_UIF_ask_value(attachments1,"owning_project",&owng_pro)!=ITK_ok)PrintErrorStack();					
											if(AOM_UIF_ask_value(attachments1,"t5_DcrPSCCategory",&pnsc_cat)!=ITK_ok)PrintErrorStack();		
											if(AOM_UIF_ask_value(attachments1,"HasParticipant",&particip)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_string(attachments1,"awp0ShowParticipants",&particip_disp)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"CMHasWorkBreakdown",&plans_)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"CMHasProblemItem",&probms)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_logical(attachments1,"cm0IsProblemsModifiable",&probs_modif)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"MEProcess",&me_proc)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"process_stage",&proce_stg)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"process_stage_list",&proce_stg_lst)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrGProg",&Pro_appli)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrProCode",&proj_code)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_string(attachments1,"t5projectname",&proj_id)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"project_ids",&proj_ids)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"object_desc",&pro_nm)!=ITK_ok)PrintErrorStack();
											strrpl(pro_nm);
											//if(AOM_ask_value_string(attachments1,"t5project",&projID_)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"project_list",&projects)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreProSol",&prop_soln)!=ITK_ok)PrintErrorStack();
											strrpl(prop_soln);
											if(AOM_ask_value_string(attachments1,"protection",&protn)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreRC",&Rison)!=ITK_ok)PrintErrorStack();
											strrpl(Rison);
											if(AOM_UIF_ask_value(attachments1,"IMAN_reference",&refrncs)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrRegNo",&regl_nmb)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreAge",&Req_agcy)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"Requestor",&requstr)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"requestor_user_id",&req_id_)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"revision_list",&revignsID)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrRootCausAnalysis",&rtcuana)!=ITK_ok)PrintErrorStack();
											strrpl(rtcuana);
											if(AOM_ask_value_int(attachments1,"sequence_id",&sq_id)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_int(attachments1,"sequence_limit",&sq_lmt)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreSP",&stgOfPr)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"fnd0StartedWorkflowTasks",&strWFtsk)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrSubAggregate",&SubAggr)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrCreSubCat",&Sun_cata)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Dcrtcpxinl",&capexLk)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrtoImDMC",&DMC_inR)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"object_type",&Obje_Typ)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_logical(attachments1,"user_can_unmanage",&usr_cn_unma)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_string(attachments1,"s2clUserRatingValue",&usr_rat_val)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_DcrVCNo",&VC_numb)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_DcrVehFor",&vehic_for)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_int(attachments1,"revision_limit",&versi_ltd)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DcrWtImpact",&weitimp)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Asuppchange",&Asuppchange)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Chingmt",&Chingmt)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Chmfgpro",&Chmfgpro)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_CurrMatthikness",&CurrMatthikness)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_CurrRawMatV",&CurrRawMatV)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Currentsupp",&Currentsupp)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Currentwt",&Currentwt)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrCPVs",&DcrCPVs)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrComdityAffs",&DcrComdityAffs)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrEstPrtDevTimes",&DcrEstPrtDevTimes)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrExSvrcCosts",&DcrExSvrcCosts)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrExSvrcTimes",&DcrExSvrcTimes)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrGrnRptFIRAvails",&DcrGrnRptFIRAvails)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrIPTVs",&DcrIPTVs)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrInterImpacts",&DcrInterImpacts)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrMfgTimes",&DcrMfgTimes)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrNVPs",&DcrNVPs)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrPreValues",&DcrPreValues)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrQltyImpcts",&DcrQltyImpcts)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrServicImpcts",&DcrServicImpcts)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrTrgIncrCosts",&DcrTrgIncrCosts)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_DcrTrgIncrImpcts",&DcrTrgIncrImpcts)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_Deschpro",&Deschpro)!=ITK_ok)PrintErrorStack();

											printf("\n MT:DCR Number: [%s]", dcrNumber);fflush(stdout);
											printf("\n MT:DCR Revision: [%s]", dcrRevision);fflush(stdout);
											printf("\n MT:DCR Name: [%s]", dcrName);fflush(stdout);
											
											tc_strcpy(FileDown,"");
											tc_strcat(FileDown,"/tmp/");	
											tc_strcat(FileDown,dcrNumber);
											tc_strcat(FileDown,"_Details.csv");
											printf("\nFile created at with name [%s] \n",FileDown);fflush(stdout);
											
											fd = fopen(FileDown,"w+");
											
											if(fd==NULL)
											{
												printf("\nError in opening the file \n");fflush(stdout);
												return 1;
											}
											printf("\nWrite report\nDCR Number	%s",dcrNumber);fflush(stdout);
											n=0;
											fprintf(fd,",--DCR (Design Change Request----)");
											fprintf(fd,"\n\nSr NO., ATTRIBUTES				,VALUES");

											fprintf(fd,"\n%d,Project Name/Desc				,%s",n++,pro_nm);fflush(fd);
											fprintf(fd,"\n%d,DCR Number					,%s",n++,dcrNumber);fflush(fd);
											fprintf(fd,"\n%d,Mint Refernce No				,%s",n++,mint_ref_no);fflush(fd);
											fprintf(fd,"\n%d,Project Code					,%s",n++,proj_code);fflush(fd);
											fprintf(fd,"\n%d,Creator							,%s",n++,owng_user);fflush(fd);
											fprintf(fd,"\n%d,Stage of Program				,%s",n++,stgOfPr);fflush(fd);
											fprintf(fd,"\n%d,Requesting Agency				,%s",n++,Req_agcy); fflush(fd);
											fprintf(fd,"\n%d,Reason						,%s",n++,Rison);fflush(fd);
											fprintf(fd,"\n%d,Failure Information				,%s",n++,Failure_Info);fflush(fd);
											fprintf(fd,"\n%d,Affected Design Groups		,%s",n++,AffectedDGrp); fflush(fd);
											fprintf(fd,"\n%d,Lead CoC					,%s",n++,leadCOC);fflush(fd);
											fprintf(fd,"\n%d,Aggregate						,%s",n++,Aggrigte);fflush(fd);
											fprintf(fd,"\n%d,Change/Issue Description			,%s",n++,Cnh_issu_desc);fflush(fd);
											fprintf(fd,"\n%d,Proposed Solution				,%s",n++,prop_soln);fflush(fd);
											fprintf(fd,"\n%d,Root Cause Analysis				,%s",n++,rtcuana);fflush(fd);

											fprintf(fd,"\n\n,--DCR Cost| Time | Quality Impact Summary Approved by CAB--\n");fflush(fd);

											fprintf(fd,"\n%d,CPV (Rs)					,%s",n++,DcrCPVs);fflush(fd);
											fprintf(fd,"\n%d,Targeted Incremental DMC Impact (Rs)			,%s",n++,DcrTrgIncrImpcts);fflush(fd);
											fprintf(fd,"\n%d,IPTV (Rs)					,%s",n++,DcrIPTVs);fflush(fd);
											fprintf(fd,"\n%d,Estimated part development time including tooling development(Months)			,%s",n++,DcrEstPrtDevTimes);fflush(fd);
											fprintf(fd,"\n%d,QUALITY IMPACT for the Change			,%s",n++,DcrQltyImpcts);fflush(fd);
											fprintf(fd,"\n%d,NPV (In Lakhs)					,%s",n++,DcrNVPs);fflush(fd);
											fprintf(fd,"\n%d,Commodity Affected				,%s",n++,DcrComdityAffs);fflush(fd);
											fprintf(fd,"\n%d,Targeted Incremental Capex including tooling cost (In Lakhs)				,%s ",n++,DcrTrgIncrCosts);fflush(fd);
											fprintf(fd,"\n%d,Perceived Value (Rs)				,%s",n++,DcrPreValues); fflush(fd);
											fprintf(fd,"\n%d,Is there any geometry	change in part?			,%s",n++,Chingmt); fflush(fd);
											fprintf(fd,"\n%d,Current material thickness	,%s",n++,CurrMatthikness);fflush(fd);
											fprintf(fd,"\n%d,Current raw material			,%s",n++,CurrRawMatV);fflush(fd);
											fprintf(fd,"\n%d,Current weight of part		,%s",n++,Currentwt);fflush(fd);
											fprintf(fd,"\n%d,Any change in Supplier?				,%s",n++,Asuppchange); fflush(fd);fflush(fd);
											fprintf(fd,"\n%d,Current supplier				,%s",n++,Currentsupp);fflush(fd);
											fprintf(fd,"\n%d,Any change in part manufacturing process? ,%s",n++,Chmfgpro);fflush(fd);
											fprintf(fd,"\n%d,Describe the changes in process				,%s",n++,Deschpro);fflush(fd);
											fprintf(fd,"\n%d,Total Impact (Capex) in Lakhs.			,%s",n++,capexLk);fflush(fd);	
											fprintf(fd,"\n%d,Extra Service Cost (Rs)				,%s",n++,DcrExSvrcCosts);fflush(fd);
											fprintf(fd,"\n%d,Extra Service Time (Single Man Hour)				,%s ",n++,DcrExSvrcTimes); fflush(fd);
											fprintf(fd,"\n%d,Interchangeability Impact			,%s",n++,DcrInterImpacts);fflush(fd);
											fprintf(fd,"\n%d,Serviceability Impact				,%s",n++,DcrServicImpcts); fflush(fd);

											fprintf(fd,"\n\n,--IMPACT ANALYSIS--\n");

											int p = 0;
											fprintf(fd,"\nSr No,Part No,Part Descriptio, Add/Del/Mod ,Weight increase/decrease(gm),COC Remark,DFMEA severity , Is part procurable?, Validation Impact,Car Make Buy ");
											GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
											GRM_list_secondary_objects_only(attachments1,relation_type,&cnt,&dcr_task);
											printf("\n Task found impacted items : %d\n",cnt);fflush(stdout);
											for(i= 0; i< cnt; i++)
											{
												if(AOM_ask_value_string(dcr_task[i],"object_name",&objectname));
												printf("\n DCR Task name is : %s\n",objectname);fflush(stdout);
												

												GRM_find_relation_type("T5_DcrTskPrt",&relationtype);
												GRM_list_secondary_objects_only(dcr_task[i],relationtype,&tskprtcount,&dcrprts);
												printf("\n [%d] parts are there in DCR Task : %s\n",tskprtcount,objectname);fflush(stdout);
												
												if(tskprtcount > 0)
												{
													fprintf(fd,"\n,--%s--",objectname);
													printf("\n parts in DCR Task : [%s]\n",objectname);fflush(stdout);
													for(j=0; j < tskprtcount; j++)
													{
														p++;

														AOM_ask_value_string(dcrprts[j],"item_id",&partID);
														AOM_UIF_ask_value(dcrprts[j],"item_revision_id",&revision_id);
														printf("\n %d> part [%s] in DCR Task : [%s]\n",p,partID,objectname);fflush(stdout);
														//AOM_ask_value_string(dcrprts[j],"IMAN_master_form_rev",&partNo);
														tc_strcpy(partNo,partID);
														tc_strcat(partNo,"/");
														tc_strcat(partNo,revision_id);
														AOM_ask_value_string(dcrprts[j],"current_desc",&partdesc);
														strrpl(partdesc);

														AOM_UIF_ask_value(dcrprts[j],"t5_CarMakeBuyIndicator",&CarMakeby);

														GRM_find_relation(dcr_task[i],dcrprts[j],relationtype,&relationofpart);
														if(relationofpart != NULLTAG)
														{
															AOM_UIF_ask_value(relationofpart,"t5_ModDetails",&moddetails);
															AOM_UIF_ask_value(relationofpart,"t5_DcrCapImp",&wtchng);
															AOM_UIF_ask_value(relationofpart,"t5_CocRem",&cocrmk);
															strrpl(cocrmk);
															AOM_UIF_ask_value(relationofpart,"t5_DFMSev",&DFMSever);
															AOM_UIF_ask_value(relationofpart,"t5_DcrPrcuPrt",&PrtPrcub);
															AOM_UIF_ask_value(relationofpart,"t5_ValImpact",&ValImpt);
															
															fprintf(fd,"\n%d,%s,%s,%s,%s,%s,%s,%s,%s,%s",p,partNo,partdesc,moddetails,wtchng,cocrmk,DFMSever,PrtPrcub,ValImpt,CarMakeby);
														}
														else
														{
															printf("\n Part to DCR task relation properties not found for: %s & task : %s \n",partID,objectname);fflush(stdout);
														}
													}

												}

											}
											if(EPM_get_current_job(attachments1,&job,&job_type));
											printf("\n after job\n"); fflush(stdout);							

											if (job != NULLTAG)
											{
												ITK_CALL(EPM_ask_root_task(job,&roottask));
												ITK_CALL(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks));

												ITK_CALL(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
												printf("\n inside %s \n",nameofroot);

												if(tc_strcmp(nameofroot,"DCR Workflow Template")==0)
												{
													if (taskcount>0)
													{
														for(j=0;j<taskcount;j++)
														{
															wftask = subtasks[j]; 
															ITK_CALL(AOM_UIF_ask_value(wftask,"object_name",&wftaskname));
															printf("\nDCR task name", wftaskname);fflush(stdout);

															if (tc_strcmp(wftaskname,"Input AQ Values") == 0)
															{
																printf("\n Inside the 'Input AQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&aq_per));
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&aq_rem));
																strrpl(aq_rem);
																printf("\n AQ Comment: [%s] performer [%s]", aq_rem,aq_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input CS Values") == 0)
															{
																printf("\n Inside the 'Input CS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&cs_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&cs_per));
																strrpl(cs_rem);
																printf("\n CS Comment: [%s] performer [%s]", cs_rem,cs_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input QA/FMQ Values") == 0)
															{
																printf("\n Inside the 'Input QA/FMQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&qa_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&qa_per));
																strrpl(qa_rem);
																printf("\n QA/FMQ Comment: [%s] performer [%s]", qa_rem,qa_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input TVM Values") == 0)
															{
																printf("\n Inside the 'Input TVM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&tvm_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&tvm_per));
																strrpl(tvm_rem);
																printf("\n TVM Comment: [%s] performer [%s]", tvm_rem, tvm_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input TS Values") == 0)
															{
																printf("\n Inside the 'Input TS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&ts_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&ts_per));
																strrpl(ts_rem);
																printf("\n TS Comment: [%s] performer [%s]", ts_rem,ts_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input VEM Values") == 0)
															{
																printf("\n Inside the 'Input VEM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vem_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vem_per));
																strrpl(vem_rem);
																printf("\n VEM Comment: [%s] performer [%s]", vem_rem, vem_per);fflush(stdout);
															}
															else if (tc_strcmp(wftaskname,"Input VPG Values") == 0)
															{
																printf("\n Inside the 'Input VPG Values' task of DCR [%s]", dcrNumber);fflush(stdout);
																ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vpg_rem));
																ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vpg_per));
																strrpl(vpg_rem);
																printf("\n VPG Comment: [%s] performer [%s]", vpg_rem, vpg_per);fflush(stdout);
															}
														}
													}
												} 
												printf("\n--Affected Agencies feedback: (As Applicable)--\n");fflush(stdout);
											}
											ITK_CALL(AOM_ask_value_tags(attachments1,"fnd0ActuatedInteractiveTsks",&TaskCount,&TaskTags));
											
											for(i=0;i<TaskCount;i++)
											{
												Tasktag=TaskTags[i];
												ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0AliasTaskName",&AssignmentName));
												ITK_CALL(TCTYPE_ask_object_type(Tasktag, &objTypTag2));
												ITK_CALL(TCTYPE_ask_name2(objTypTag2, &ObjTyp2));
												if((strcmp(ObjTyp2,"Signoff")==0) && (strstr(AssignmentName,"DCR CAB L1 Review")!=NULL))
												{
													ITK_CALL(AOM_UIF_ask_value(Tasktag,"comments",&CAB1comt));
													ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0Performer",&cab1per));
													printf("\n CAB1 reviewer :[%s]Comment: [%s]", cab1per,CAB1comt);fflush(stdout);
												}
												if((strcmp(ObjTyp2,"Signoff")==0) && (strstr(AssignmentName,"DCR CAB L2 Review")!=NULL))
												{
													ITK_CALL(AOM_UIF_ask_value(Tasktag,"comments",&CAB2comt));
													ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0Performer",&cab2per));
													printf("\n CAB2 reviewer :[%s]Comment: [%s]", cab2per,CAB2comt);fflush(stdout);
												}
											}
											fprintf(fd,"\n\n,--Affected Agencies feedback: (As Applicable)--\n");
											fprintf(fd,"\n%d,TS Reviewer					,%s",n++,ts_per);fflush(fd);
											fprintf(fd,"\n%d,TS Remarks					,%s",n++,ts_rem);fflush(fd);
											fprintf(fd,"\n%d,AQ Reviewer					,%s",n++,aq_per);fflush(fd);
											fprintf(fd,"\n%d,AQ Remarks					,%s",n++,aq_rem);fflush(fd);
											fprintf(fd,"\n%d,TVM Reviewer					,%s",n++,tvm_per);fflush(fd);
											fprintf(fd,"\n%d,TVM Remarks					,%s",n++,tvm_rem);fflush(fd);
											fprintf(fd,"\n%d,CS Reviewer					,%s",n++,cs_per);fflush(fd);
											fprintf(fd,"\n%d,CS Remarks					,%s",n++,cs_rem);fflush(fd);
											fprintf(fd,"\n%d,QA/FMQ Reviewer				,%s",n++,qa_per);fflush(fd);
											fprintf(fd,"\n%d,QA/FMQ Remarks				,%s",n++,qa_rem);fflush(fd);
											fprintf(fd,"\n%d,VEM Reviewer					,%s",n++,vem_per);fflush(fd);
											fprintf(fd,"\n%d,VEM Remarks					,%s",n++,vem_rem);fflush(fd);
											fprintf(fd,"\n%d,VPG Reviewer					,%s",n++,vpg_per);fflush(fd);
											fprintf(fd,"\n%d,VPG Remarks					,%s",n++,vpg_rem);fflush(fd);
											fprintf(fd,"\n%d,Chief Engineer					,%s",n++,cab1per);fflush(fd);
											fprintf(fd,"\n%d,Program Manager					,%s",n++,cab2per);fflush(fd);
											fprintf(fd,"\n%d,Input from CAB1					,%s",n++,CAB1comt);fflush(fd);
											fprintf(fd,"\n%d,Input from CAB2					,%s",n++,CAB2comt);fflush(fd);
											printf("\nData copied in file....\n"); fflush(stdout);
										}
				
										//TASK
										if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
										{
											if(GRM_find_relation_type("T5_DMLTaskRelation",&tsktodmlrel)!=ITK_ok)PrintErrorStack();
											if (tsktodmlrel!=NULLTAG)
											{
												
												if(GRM_list_primary_objects_only(attachments1,tsktodmlrel,&tsktodmlrelcount,&DMLRev)!=ITK_ok)PrintErrorStack();
												printf("\n\t T5TaskToPartCreateVal-->DML Revision from Task for MR tsktodmlrelcount : %d",tsktodmlrelcount);fflush(stdout);
												if(tsktodmlrelcount>0)
												{
													DMLReviTag = DMLRev[0];
													if(AOM_ask_value_string(DMLReviTag,"item_id",&dcrNumber)!=ITK_ok)PrintErrorStack();
													//if(AOM_ask_value_string(DMLReviTag,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"object_name",&dcrName)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"item_revision_id",&dcrRevision)!=ITK_ok)PrintErrorStack();
													//if(AOM_ask_value_strings(DMLReviTag,"t5_DcrDesgGrp",&DsgnGrp,&AffectedDGrp)!=ITK_ok)PrintErrorStack();
													//printf("\n DML Size of Affected Design group are %d\n",DsgnGrp);
													

													//if(AOM_UIF_ask_value(DMLReviTag,"EC_affected_item_rel",&AffectedItem)!=ITK_ok)PrintErrorStack();
													if(AOM_UIF_ask_value(DMLReviTag,"t5_ERCAggregate",&Aggrigte)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_cDRstatus",&DRstat)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_DmlReasonDisplay",&Reason)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_rlstype",&rlstype)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_TargetPlant",&plant)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_DmlVClassfctn",&VehClass)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(DMLReviTag,"t5_ERCWBS",&wbs)!=ITK_ok)PrintErrorStack();
													//if(AOM_ask_value_string(DMLReviTag,"t5_DcrAppNam",&ApproverTD)!=ITK_ok)PrintErrorStack();						
													//if(AOM_ask_value_string(DMLReviTag,"t5_DcrCreCatChng",&CatOfChange)!=ITK_ok)PrintErrorStack();						
													if(AOM_ask_value_string(DMLReviTag,"t5_ERCBusiUt",&Cnh_issu_desc)!=ITK_ok)PrintErrorStack();
													//strrpl(Cnh_issu_desc);
													if(AOM_ask_value_string(DMLReviTag,"object_desc",&pro_nm)!=ITK_ok)PrintErrorStack();
													strrpl(pro_nm);

													printf("\n MT:DML Number: [%s]", dcrNumber);fflush(stdout);
													printf("\n MT:DML Revision: [%s]", dcrRevision);fflush(stdout);
													printf("\n MT:DML Name: [%s]", dcrName);fflush(stdout);
													
													tc_strcpy(FileDown,"");
													tc_strcat(FileDown,"/tmp/");	
													tc_strcat(FileDown,dcrNumber);
													tc_strcat(FileDown,"_Details.csv");
													printf("\n DML File created at with name [%s] \n",FileDown);fflush(stdout);
													
													fd = fopen(FileDown,"w+");
													
													if(fd==NULL)
													{
														printf("\nDML Error in opening the file \n");fflush(stdout);
														return 1;
													}
													printf("\nWrite report\n DML Number	%s",dcrNumber);fflush(stdout);
													n=0;

													fprintf(fd,",-- DML Report --\n\n"); fflush(fd);
													fprintf(fd,"\n,--DML (Data Modification List--)");
													fprintf(fd,"\n\nSr NO., ATTRIBUTES				,VALUES");

													fprintf(fd,"\n%d,Project Name/Desc				,%s",n++,pro_nm);fflush(fd);
													fprintf(fd,"\n%d,DML Number					,%s",n++,dcrNumber);fflush(fd);
													fprintf(fd,"\n%d,DR Status				,%s",n++,DRstat);fflush(fd);
													fprintf(fd,"\n%d,Target Plant				,%s",n++,plant);fflush(fd);
													fprintf(fd,"\n%d,Vehicle Classification				,%s",n++,VehClass); fflush(fd);
													fprintf(fd,"\n%d,Reason						,%s",n++,Reason);fflush(fd);
													fprintf(fd,"\n%d,WBS				,%s",n++,wbs);fflush(fd);
													//fprintf(fd,"\n%d,Affected Design Groups		,%s",n++,AffectedDGrp); fflush(fd);
													fprintf(fd,"\n%d,Release Type					,%s",n++,rlstype);fflush(fd);
													fprintf(fd,"\n%d,Aggregate						,%s",n++,Aggrigte);fflush(fd);
													fprintf(fd,"\n%d,Business Unit			,%s",n++,Cnh_issu_desc);fflush(fd);
													
													printf("\nData copied in file....\n"); fflush(stdout);
										
												}
											}
										}
										//DML
										if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
										{
											if(AOM_ask_value_string(attachments1,"item_id",&dcrNumber)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_string(attachments1,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"object_name",&dcrName)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"item_revision_id",&dcrRevision)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_strings(attachments1,"t5_DcrDesgGrp",&DsgnGrp,&AffectedDGrp)!=ITK_ok)PrintErrorStack();
											//printf("\n DML Size of Affected Design group are %d\n",DsgnGrp);
											

											//if(AOM_UIF_ask_value(attachments1,"EC_affected_item_rel",&AffectedItem)!=ITK_ok)PrintErrorStack();
											if(AOM_UIF_ask_value(attachments1,"t5_ERCAggregate",&Aggrigte)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_cDRstatus",&DRstat)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DmlReasonDisplay",&Reason)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_rlstype",&rlstype)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_TargetPlant",&plant)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_DmlVClassfctn",&VehClass)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(attachments1,"t5_ERCWBS",&wbs)!=ITK_ok)PrintErrorStack();
											//if(AOM_ask_value_string(attachments1,"t5_DcrAppNam",&ApproverTD)!=ITK_ok)PrintErrorStack();						
											//if(AOM_ask_value_string(attachments1,"t5_DcrCreCatChng",&CatOfChange)!=ITK_ok)PrintErrorStack();						
											if(AOM_ask_value_string(attachments1,"t5_ERCBusiUt",&Cnh_issu_desc)!=ITK_ok)PrintErrorStack();
											//strrpl(Cnh_issu_desc);
											if(AOM_ask_value_string(attachments1,"object_desc",&pro_nm)!=ITK_ok)PrintErrorStack();
											strrpl(pro_nm);

											printf("\n MT:DML Number: [%s]", dcrNumber);fflush(stdout);
											printf("\n MT:DML Revision: [%s]", dcrRevision);fflush(stdout);
											printf("\n MT:DML Name: [%s]", dcrName);fflush(stdout);
											
											tc_strcpy(FileDown,"");
											tc_strcat(FileDown,"/tmp/");	
											tc_strcat(FileDown,dcrNumber);
											tc_strcat(FileDown,"_Details.csv");
											printf("\n DML File created at with name [%s] \n",FileDown);fflush(stdout);
											
											fd = fopen(FileDown,"w+");
											
											if(fd==NULL)
											{
												printf("\nDML Error in opening the file \n");fflush(stdout);
												return 1;
											}
											printf("\nWrite report\n DML Number	%s",dcrNumber);fflush(stdout);
											n=0;
											fprintf(fd,",-- DML Report --\n\n"); fflush(fd);
											fprintf(fd,"\n,--DML (Data Modification List)");
											fprintf(fd,"\n\nSr NO., ATTRIBUTES				,VALUES");

											fprintf(fd,"\n%d,Project Name/Desc				,%s",n++,pro_nm);fflush(fd);
											fprintf(fd,"\n%d,DML Number					,%s",n++,dcrNumber);fflush(fd);
											fprintf(fd,"\n%d,DR Status				,%s",n++,DRstat);fflush(fd);
											fprintf(fd,"\n%d,Target Plant				,%s",n++,plant);fflush(fd);
											fprintf(fd,"\n%d,Vehicle Classification				,%s",n++,VehClass); fflush(fd);
											fprintf(fd,"\n%d,Reason						,%s",n++,Reason);fflush(fd);
											fprintf(fd,"\n%d,WBS				,%s",n++,wbs);fflush(fd);
											//fprintf(fd,"\n%d,Affected Design Groups		,%s",n++,AffectedDGrp); fflush(fd);
											fprintf(fd,"\n%d,Release Type					,%s",n++,rlstype);fflush(fd);
											fprintf(fd,"\n%d,Aggregate						,%s",n++,Aggrigte);fflush(fd);
											fprintf(fd,"\n%d,Business Unit			,%s",n++,Cnh_issu_desc);fflush(fd);
											
											printf("\nData copied in file....\n"); fflush(stdout);							
										}
										
										//For Approval Mail for DCR and DML
										if((tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0) || (tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0) || (tc_strcmp(ObjTyp,"ChangeRequestRevision")==0))
										{
											tc_strcpy(WebserviceShellpath,"");
											tc_strcpy(WebserviceShellpath,sInfo2);
											printf("\n USING doublete %s\n",doublete);fflush(stdout);
											tc_strcpy(command,"");
											printf("\n inside pFirst_webservice condition \n");
											tc_strcat(command,WebserviceShellpath);
											tc_strcat(command,"pFirst_webservice.sh");
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,objectname1);
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,sInfo3);
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,childParentTaskNam);
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,Web_ParticpantName);
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,taskname);
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											tc_strcat(command,FileDown);//FileDown
											tc_strcat(command,doublete);
											tc_strcat(command," ");
											tc_strcat(command,doublete);
											if(tc_strlen(personmail) > 0)
											{
												tc_strcat(command,personmail);
											}
											else
											{
												tc_strcat(command,"ra922216.ttl@tatamotors.com");
											}
											tc_strcat(command,doublete);
											printf("\n Before Excuted Command : %s", command);fflush(stdout);
											system(command);
											BreakFlag=1;
										}
									}
									else
									{
										printf(".... SKIPPED.\n");fflush(stdout);
									}
								}
							}
						}
					}
				}
				printf("\n Break Exected \n");fflush(stdout);
				//break;		
			}
		}
	}
	printf("\n DCR:END of DCR_Mail_approve Handler\n");fflush(stdout);
	TC_write_syslog("\n END of DCR_Mail_approve Handler...");
	return ITK_ok;
}

extern int register_Mail_Approval(int *decision, va_list args)
{
    *decision = ALL_CUSTOMIZATIONS;
	int	ifail = ITK_ok;
	


   if( ITK_ok == EPM_register_action_handler("Webservice_Mail_approve", "Webservice Mail approve", Webservice_Mail_approve))
   {
	     printf("\n Registered Action Handler Webservice_Mail_approve \n");fflush(stdout);
   }
   else
   {
		printf("\n FAILED to register Action Handler Webservice_Mail_approve\n");fflush(stdout);
   }

   //Ritesh
   if( ITK_ok == EPM_register_action_handler("DCR_Mail_approve", "DCR Mail approve", DCR_Mail_approve))
   {
	     printf("\n Registered Action Handler DCR_Mail_approve \n");fflush(stdout);
   }
   else
   {
		printf("\n FAILED to register Action Handler DCR_Mail_approve\n");fflush(stdout);
   }


	return ifail;

}

extern DLLAPI int tm_Mail_Approval_register_callbacks()
{
     CUSTOM_register_exit("tm_Mail_Approval", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_Mail_Approval);

      printf("\n tm_Mail_Approval Registered \n");

	 return ( ITK_ok );
}