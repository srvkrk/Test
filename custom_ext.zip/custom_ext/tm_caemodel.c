/****************************************************************************************************
*  File            :   tm_caemodel.c
*  Created By      :   Madhusudan Bachhav
*  Created On      :   
*  Purpose         :   TML CAE Model
******************************************************************************************************/
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <user_exits/user_exits.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <tccore/item_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/aom_prop.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <tccore/workspaceobject.h>
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 4)

#define PLM_error (EMH_USER_error_base+25)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

extern DLLAPI int P_Name_Dynamic_lov_pre_action(METHOD_message_t *msg, va_list args);
extern DLLAPI int P_Name_Dynamic_lov_pre_condition(METHOD_message_t *msg, va_list args);
extern DLLAPI int CAE_EPM_action_handler_t(EPM_action_message_t msg);
char* Ask_lov_type_function(char *input);
char* Ask_CAE_Role_function(char *input);

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		for( index=0; index<n_ifails; index++)
		{
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;   
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL; 
	                             
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

extern DLLAPI int CAE_EPM_action_handler_t(EPM_action_message_t msg)
{
	int				Status					= ITK_ok;
	int				count=0;
	tag_t			tag_rootTask			= NULLTAG;
	tag_t			*tag_Attachement		= NULLTAG;
	tag_t			tag_Temp_Attch		    = NULLTAG;
	tag_t			Participant_rel_type	= NULLTAG;
	tag_t			*Participant			= NULLTAG;
	tag_t			*Participant0			= NULLTAG;
	tag_t			hasRel					= NULLTAG;
	tag_t			objTag					= NULLTAG;
	tag_t			Grp_tag					= NULLTAG;
	tag_t			Role_tag				= NULLTAG;
	tag_t			*member_tag				= NULLTAG;
	tag_t			Patri_Type				= NULLTAG;
	tag_t			Created_Party			= NULLTAG;
	char			*sObjectTaskName;
	char			*CAE_Reviewr			= NULL;
	char			*groupName				= "CAE_Group";
	char			*Role					= NULL;
	char			*s,*mem_name;
	char			*sCurrentName;
	char			*sReqDomain				= NULL;
	char			*sObjectType,*sItemId;
	char			*sObjectRootTaskName;
	int				iCountAttch = 0,i=0,j=0,k=0,member=0, iii=0,hasRel_count=0;

	printf("\n\n\n\t INSIDE THE CAE_EPM_action_handler_t()\n");fflush(stdout);
	
	if (EPM_ask_root_task(msg.task,&tag_rootTask) !=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(msg.task,"object_name",&sObjectTaskName) !=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(tag_rootTask,"object_name",&sObjectRootTaskName) !=ITK_ok)   PrintErrorStack();
	printf("\n\t ROOT TASK NAME IS  :%s \n\t TASK NAME IS: %s \n",sObjectRootTaskName,sObjectTaskName);fflush(stdout);

	if (EPM_ask_attachments(tag_rootTask,EPM_target_attachment,&iCountAttch,&tag_Attachement) !=ITK_ok)   PrintErrorStack();
	printf("\n\t No of Attachemnt is:%d \n",iCountAttch);fflush(stdout);
	if(iCountAttch>0)
	{
		for(i=0;i<iCountAttch;i++)
		{
			objTag= tag_Attachement[i];
			
			if (AOM_ask_value_string(objTag,"object_type",&sObjectType) !=ITK_ok)   PrintErrorStack();
			
			if (tc_strcmp(sObjectType,"T5_TMCAEModelRevision")==0)
			{
				if (AOM_ask_value_string(objTag,"t5_sReqDomain",&sReqDomain) !=ITK_ok)   PrintErrorStack();

				Role = Ask_CAE_Role_function(sReqDomain);
				printf("\n\t Group and Role are:  %s  and  %s\n",groupName,Role);fflush(stdout);

				if (GRM_find_relation_type("HasParticipant", &hasRel) !=ITK_ok)   PrintErrorStack();
				if (GRM_list_secondary_objects_only(objTag,hasRel,&hasRel_count,&Participant0) !=ITK_ok)   PrintErrorStack();
				for(k=0;k<hasRel_count;k++)
				{
					AOM_lock(objTag);
					if (ITEM_rev_remove_participant (objTag,Participant0[k]) !=ITK_ok)   PrintErrorStack();
					AOM_save(objTag);
					AOM_unlock(objTag);
				}

				if (SA_find_group(groupName, &Grp_tag) !=ITK_ok)   PrintErrorStack();
				
				if (SA_find_role2(Role,&Role_tag) !=ITK_ok)   PrintErrorStack();
				if (SA_find_groupmember_by_role(Role_tag,Grp_tag,&member,&member_tag) !=ITK_ok)   PrintErrorStack();
				
				printf("\n\t No of member is:%d \n",member);fflush(stdout);
				
				if(member>0)
				{
					for(iii=0;iii<member;iii++)
					{	
						if (AOM_ask_name(member_tag[iii],&mem_name) !=ITK_ok)   PrintErrorStack();
						printf("\n\n\t Member Name is ::: %s\n",mem_name);fflush(stdout);
						if (EPM_get_participanttype ("T5_CAEReviewer",&Patri_Type) !=ITK_ok)   PrintErrorStack();
						if (EPM_create_participant(member_tag[iii],Patri_Type,&Created_Party) !=ITK_ok)   PrintErrorStack();
						
						AOM_lock(objTag);			
						if (ITEM_rev_add_participant(objTag,Created_Party) !=ITK_ok)   PrintErrorStack();
							printf("\n\n\t Participant added\n");fflush(stdout);
						AOM_save(objTag);
						AOM_unlock(objTag);

					}
				}

			}
				
		}
	}

	return ITK_ok;

}
EPM_decision_t EPM_check_responsible_party(EPM_rule_message_t msg)
{
	int s;
	EPM_decision_t decision = EPM_nogo;
	char* userName;
	tag_t aUserTag, responsibleParty;

	s = EPM_ask_responsible_party(msg.task, &responsibleParty);
	if (responsibleParty, NULLTAG)
	{
		decision = EPM_go;
	}

	if(s == ITK_ok && decision == EPM_nogo)
	{
		s = POM_get_user (&userName, &aUserTag);
		MEM_free (userName);

		if (s == ITK_ok)
		{
			if (aUserTag, responsibleParty)
			decision = EPM_go;
		}
	}
	return decision;
}
 // MADHUSUDAN : CAE_MODEL_LOV
extern int Createpost_register_method_CAE(int *decision, va_list args)
{
	int status = ITK_ok;
	int ifail = ITK_ok;
    METHOD_id_t  method_TMCAEModelRev;
    METHOD_id_t  method_TMCAEModel;
	METHOD_id_t  method_id_CV,method_id_PV,method_id_PT;
	METHOD_id_t method_id_cond;
    *decision = ALL_CUSTOMIZATIONS;

	printf("\n\n\t ******* Inside Createpost_register_method_CAE  *****\n");fflush(stdout);


	if ( METHOD_register_method("T5_CAEModelLovTypeCV",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_CV) !=ITK_ok)   PrintErrorStack();
	if ( METHOD_register_method("T5_CAEModelLovTypePV",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_PV) !=ITK_ok)   PrintErrorStack();
	if ( METHOD_register_method("T5_CAEModelLovTypePT",LOV_ask_values_msg,&P_Name_Dynamic_lov_pre_action,0,&method_id_PT) !=ITK_ok)   PrintErrorStack();
//	if ( METHOD_find_method("T5_TMCAEModelRevision","IMAN_save",&method_id_cond) !=ITK_ok)  PrintErrorStack();
	if ( METHOD_find_method("T5_TMCAEModelRevision",IMAN_save_msg,&method_id_cond) !=ITK_ok)  PrintErrorStack();

/*	if (method_id_cond.id != NULLTAG)
    {
        if( METHOD_add_pre_condition(method_id_cond,(METHOD_function_t)P_Name_Dynamic_lov_pre_condition,NULL)!=ITK_ok)
        PrintErrorStack();
		printf("inside 'TML_CAE_Model' file ,Registered as pre-condition for Creation method_id_cond_11/12/18 \n");fflush(stdout);
    }
    else
	{
        printf("method_id_cond not found_11/12/18\n");fflush(stdout);
	}
*/
	if (method_id_cond.id != NULLTAG)
	{
		printf("\nInside method_id_cond...!!\n");
		if( METHOD_add_pre_condition(method_id_cond, (METHOD_function_t) P_Name_Dynamic_lov_pre_condition, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_id_cond\n");fflush(stdout);
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_id_cond tag not found...!!*****************\n");
	}
	status=EPM_register_action_handler("CAE-Manager-Appr","CAE-Manager-Appr",(EPM_action_handler_t)CAE_EPM_action_handler_t);
	printf("\n\n CAE-Manager-Appr registered_11/12/18\n");fflush(stdout);

    //return ITK_ok;
	return ifail;
}

extern DLLAPI int tm_caemodel_register_callbacks ()
{
	printf("\n\n createpost_register_callbacks_11/12/18 ------------ \n\n");fflush(stdout);
    if(CUSTOM_register_exit ( "tm_caemodel", "USER_init_module", (CUSTOM_EXIT_ftn_t)  Createpost_register_method_CAE) !=ITK_ok)
		PrintErrorStack();
  return ( ITK_ok );
}




// MADHUSUDAN CAE MODEL LOV CODE ***************

extern DLLAPI int P_Name_Dynamic_lov_pre_action(METHOD_message_t *msg, va_list args)
{
	tag_t lov_tag = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *info1_value,*subSyscdt_value,*Syscd_value,*token,*item_sequence_id,*Converter,*ValesforLov[200],*Input_Prop;
	int status;

    int ifail= ITK_ok,error_code = ITK_ok, n_entries = 2, c_count=0, n_found, ii, i,k;
	char *lov_name;
	

    tag_t query = NULLTAG, *cntr_objects = NULL;
 
      
	k=0;

	
	
	LOV_ask_name2(lov_tag,&lov_name);
	Input_Prop = Ask_lov_type_function(lov_name);
	printf("\n *******_11/12/18Input Property is %s\n", Input_Prop);fflush(stdout);

	char *qry_entries[2] = {"SUBSYSCD","SYSCD"};
    char *qry_values[2]  =  {"CAE",Input_Prop};

	(QRY_find("KeyWordQry", &query));
	(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n Control objects Found qty: %d", n_found);fflush(stdout);

   for(i=0;i<n_found;i++)
   {
		( AOM_ask_value_string(cntr_objects[i],"t5_Userinfo1",&info1_value));

		token= tc_strtok(info1_value,";");
		
		while (token != NULL) 
		{ 
//			printf("\n ******* LOV_Value's are %s\n", token);
			ValesforLov[k]= token;
			token = tc_strtok(NULL,";");
			k++;
		}

		
		*n_values = k;
	//	 printf("\n n_values is: == %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < k ; ii++)
		{
			(*values)[ii] = (char *) MEM_alloc (tc_strlen(ValesforLov[ii]) + 1);
			tc_strcpy((*values)[ii], ValesforLov[ii]);
		//	printf("\n LOV value is: %s",**values);fflush(stdout);

		}
		
		printf("\n Out of for loop LOV value is: %s",**values);fflush(stdout);
   }

return error_code;
}

extern DLLAPI int P_Name_Dynamic_lov_pre_condition(METHOD_message_t *msg, va_list args)
{
	printf("\n\n\t ******* Inside P_Name_Dynamic_lov_pre_condition  *****\n");fflush(stdout);
	tag_t object=va_arg(args, tag_t);

	int ifail = 0;
	char *value;

	//ifail=AOM_UIF_ask_value(object,"t5_sBusiness_Unit",&value);
	if( AOM_UIF_ask_value(object,"t5_sBusiness_Unit",&value)!=ITK_ok);PrintErrorStack();

	printf("\n\n\t BU Value is:%s\n",value);fflush(stdout);


	if(tc_strcmp(value,"Select BU")==0)
	{
		//EMH_store_error_s2(EMH_severity_error,PLM_error,"Selected Business Unit is wrong","Please Select Proper Business Unit");
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Selected Business Unit is wrong");
		printf("\n\n\t ******* Selected Business Unit is wrong *****\n");fflush(stdout);
		//return(PLM_error);
		return ITK_err;
	}
	else
	{
		printf("\n\n\t ******* Selected Business Unit is ok *****\n");fflush(stdout);
		return ITK_ok;
	}

	return 0;
}

char* Ask_lov_type_function(char* input)
{
	char *prop_value;
	printf("\n\n\t ******* Inside Ask_lov_type_function  *****\n");fflush(stdout);


	if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNameCV")==0)
	{
		prop_value="CV";
		return prop_value;
	}
	else if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNamePV")==0)
	{
		prop_value="PV";
		return prop_value;
	}
	else if(tc_strcmp(input,"T5_CLOV_CAE_ProjectNamePT")==0)
	{
		prop_value="PT";
		return prop_value;
	}
	
}

char* Ask_CAE_Role_function(char* input)
{
	char *prop_value;
	printf("\n\n\t ******* Inside Ask_CAE_Role_function  *****\n");fflush(stdout);

	if(tc_strcmp(input,"DURABILITY")==0)
	{
		prop_value="CAE_Durability_Manager";
		return prop_value;
	}
	else if(tc_strcmp(input,"NVH")==0)
	{
		prop_value="CAE_NVH_Manager";
		return prop_value;
	}
	else if(tc_strcmp(input,"CRASH")==0)
	{
		prop_value="CAE_Crash_Manager";
		return prop_value;
	}
	else if(tc_strcmp(input,"AEROTHERMAL")==0)
	{
		prop_value="CAE_Aerothermal_Manager";
		return prop_value;
	}
	else if(tc_strcmp(input,"MBD")==0)
	{
		prop_value="CAE_MBD_Manager";
		return prop_value;
	}
	
}