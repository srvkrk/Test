#include "TMLLibrary_server_exits.h"

extern EPM_decision_t DLLAPI tm_PWTtskChk(EPM_rule_message_t msg)
{
	int no_attach			= 0;
	int i					= 0;
	int count				= 0;
	int countt				= 0;
	int Deg_n_entry			= 1;
	int Deg_rsltCount		= 0;
	int s16TaskEVFlag		= 0;
	int s26TaskEVFlag		= 0;
	int s39or35TaskEVFlag   = 0;
	int	s0ETaskFlag			= 0;
	int	s21TaskFlag			= 0;
	int	s50TaskFlag			= 0;
	int	s16TaskFlag			= 0;
	int	s26TaskFlag			= 0;
	int	s35or39TaskFlag     = 0;
	int	j                   = 0;
	tag_t roottask			 = NULLTAG;
	tag_t DMLRevTag			 = NULLTAG;
	tag_t query			     = NULLTAG;
	tag_t DegqryTag			 = NULLTAG;
	tag_t objTypTag			 = NULLTAG;
	tag_t tsk_dml_rel_type	 = NULLTAG;
	tag_t DMLtsk_tag	     = NULLTAG;
	tag_t *Attachments			= NULLTAG;
	tag_t *contrlObjs			= NULLTAG;
	tag_t *Deg_CntrlObjectTag	= NULLTAG;
	tag_t *DMLTsk	            = NULLTAG;
	char* sPWTInfo1		= NULL;
	char* dmlno		= NULL;
	char* sPWTInfo2		= NULL;
	char* sPWTInfo3		= NULL;
	char* sPWTInfo4		= NULL;
	char* Deg_info1		= NULL;
	char* Deg_info2		= NULL;
	char* Deg_info3		= NULL;
	char* Deg_info4		= NULL;
	char* Deg_info5		= NULL;
	char* Deg_info6		= NULL;
	char* Deg_info7		= NULL;
	char* Deg_info8		= NULL;
	char* objTypeofTask	= NULL;
	char* sTaskGroups	= NULL;
	char* scprojectcode	= NULL;
	char* sDMLVertical	= NULL;
	char* sTaskName	    = NULL;
    EPM_decision_t decision = EPM_go;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));

	//char **Deg_qry_entry = (char **) MEM_alloc(30 * sizeof(char *));
	char **Deg_qry_values2  = (char **) MEM_alloc(100 * sizeof(char *));

	char    *Deg_qry_entry[1]  = {"SYSCD"};
	
	printf("\n tm_PWTtskChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_PWTtskChk Function started...");

	if(EPM_ask_root_task(msg.task,&roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach,&Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n :INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="PWTCHK";

				ITK_CALL(QRY_find2("Control Objects...",&query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sPWTInfo1));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sPWTInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sPWTInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sPWTInfo4));
					printf("\n L1:sPWTInfo1 is : [%s]  L2:sPWTInfo2 is : [%s]  L3:sPWTInfo3 is : [%s] L4:sPWTInfo4 is : [%s]\n",sPWTInfo1,sPWTInfo2,sPWTInfo3,sPWTInfo4);fflush(stdout);

					if(tc_strstr(sPWTInfo1,"PWTOFF1") == NULL)
					{

						if(QRY_find2("ControlObjects",&DegqryTag));
						if (DegqryTag)
						{
							printf("\n VEHTASK:P10:Found Query ControlObjects.");fflush(stdout);
						}
						else
						{
							printf("\n VEHTASK:P11:Not Found Query ControlObjects.\n\n");fflush(stdout);
						}

						Deg_qry_values2[0] = "VEHTASK";
						if(QRY_execute(DegqryTag, Deg_n_entry, Deg_qry_entry, Deg_qry_values2,&Deg_rsltCount,&Deg_CntrlObjectTag));
						printf(" \n VEHTASK:P12:Deg_rsltCount :%d:", Deg_rsltCount); fflush(stdout);
						if(Deg_rsltCount > 0)
						{
							//FOR EV: 00/16/26/35
							//Veh task design group.:Mandatory tasks: 0E
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo1",&Deg_info1)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info1 is.:[%s]", Deg_info1);fflush(stdout);
							//Veh task design group: 16
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo2",&Deg_info2)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info2 is.:[%s]", Deg_info2);fflush(stdout);
							//Veh task design group: 21
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo3",&Deg_info3)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info3 is.:[%s]", Deg_info3);fflush(stdout);
							//Veh task design group: 50
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo4",&Deg_info4)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info4 is.:[%s]", Deg_info4);fflush(stdout);
							//Veh task design group: 26
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo5",&Deg_info5)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info5 is.:[%s]", Deg_info5);fflush(stdout);
							//Veh task design group:35
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo6",&Deg_info6)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info6 is.:[%s]", Deg_info6);fflush(stdout);

							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo7",&Deg_info7)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info7 is.:[%s]", Deg_info7);fflush(stdout);
							//39 for EV perti project code
							if (AOM_ask_value_string(Deg_CntrlObjectTag[0],"t5_Userinfo8",&Deg_info8)!=ITK_ok)   PrintErrorStack();
							printf("\n VEHTASK:Deg_info8 is.:[%s]", Deg_info8);fflush(stdout);
							//Get tasks from DML

							ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
							printf("\n objtype found \n");fflush(stdout);

							ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
							printf("\n  object_type is %s\n", objTypeofTask);fflush(stdout);

							if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
							{
								ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&dmlno));
								printf("\n VEHTASK:dmlno is.:[%s]", dmlno);fflush(stdout);

								if(tc_strstr(sPWTInfo2,dmlno) == NULL)
								{
								   ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ProductLine",&sDMLVertical));
								   printf("\n VEHTASK:sDMLVertical is.:[%s]", sDMLVertical);fflush(stdout);

								   ITK_CALL(AOM_ask_value_string(DMLRevTag, "t5_cprojectcode",&scprojectcode));
								   printf("\n VEHTASK:scprojectcode is.:[%s]", scprojectcode);fflush(stdout);
								   ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tsk_dml_rel_type));
								   if (tsk_dml_rel_type!=NULLTAG)
								   {
										//if(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
										ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,tsk_dml_rel_type,&countt,&DMLTsk));
										printf("\n tm_Tan_code:DML Revision from Task for : %d",countt);fflush(stdout);

										if(tc_strcmp(sDMLVertical,"EV")==0)
										{
											s16TaskEVFlag=0;
											s26TaskEVFlag=0;
											
											s39or35TaskEVFlag=0;

											for (j=0;j<countt ;j++)
											{
												DMLtsk_tag=DMLTsk[j];

												ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&sTaskName));
												printf("\n sTaskName = %s \n",sTaskName);fflush(stdout);

												printf(" For EV DML.\n");fflush(stdout);
												//_16
												if (tc_strlen(Deg_info2) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info2);
													printf("\n VEHTASK:V:sTaskGroups16EV:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s16TaskEVFlag=1;
														printf("\n VEHTASK:V:s16TaskEVFlag:[%d].",s16TaskEVFlag);fflush(stdout);
													}
												}
												//26
												if (tc_strlen(Deg_info5) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info5);
													printf("\n VEHTASK:V:sTaskGroups26EV:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s26TaskEVFlag=1;
														printf("\n VEHTASK:V:s26TaskEVFlag:[%d].",s26TaskEVFlag);fflush(stdout);
													}
												}
												//39
												if(tc_strstr(Deg_info7,scprojectcode)!=NULL)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info8);
													printf("\n VEHTASK:V:sTaskGroups39EV:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														 s39or35TaskEVFlag=1;
														 printf("\n VEHTASK:V:s39or35TaskEVFlag:[%d].",s39or35TaskEVFlag);fflush(stdout);
													}

												}
												else
												{
													sTaskGroups=(char *) MEM_alloc(30);
													//35
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info6);
													printf("\n VEHTASK:V:sTaskGroups35EV:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s39or35TaskEVFlag=1;
														printf("\n VEHTASK:V:s39or35TaskEVFlag:[%d].",s39or35TaskEVFlag);fflush(stdout);
													}
												}
											}
											//}
											//if ((s16TaskEVFlag==0) ||(s26TaskEVFlag==0)||(s39or35TaskEVFlag==0))
											if(s16TaskEVFlag==0)
											{
												printf("\n need all Veh task \n");fflush(stdout);
												EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,ITK_err,"\n please ensure to attach All madatory task of design group 16,26,35 or 39., please attach it and submit");
												EMH_store_error_s1(EMH_severity_error,ITK_err,"\n please ensure to attach madatory task of design group 16, please attach it and submit");
												decision = EPM_nogo;
												return decision;
											}
										}
										else
										{
											s0ETaskFlag=0;
											s16TaskFlag=0;
											s21TaskFlag=0;
											s50TaskFlag=0;
											s26TaskFlag=0;
											s35or39TaskFlag=0;

											for (j=0;j<countt ;j++)
											{
												DMLtsk_tag=DMLTsk[j];

												ITK_CALL(AOM_ask_value_string(DMLtsk_tag,"item_id",&sTaskName));
												printf("\n sTaskName = %s \n",sTaskName);fflush(stdout);

												printf(" For non EV DML.\n");fflush(stdout);
												if (tc_strlen(Deg_info1) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info1);
													printf("\n VEHTASK:V:sTaskGroups0E:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s0ETaskFlag=1;
														printf("\n VEHTASK:V:s0ETaskFlag:[%d].",s0ETaskFlag);fflush(stdout);
													}
												}
												if (tc_strlen(Deg_info2) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info2);
													printf("\n VEHTASK:V:sTaskGroups16:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s16TaskFlag=1;
														printf("\n VEHTASK:V:s16TaskFlag:[%d].",s16TaskFlag);fflush(stdout);
													}
												}
												if (tc_strlen(Deg_info3) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info3);
													printf("\n VEHTASK:V:sTaskGroups21:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s21TaskFlag=1;
														printf("\n VEHTASK:V:s21TaskFlag:[%d].",s21TaskFlag);fflush(stdout);
													}
												}
												if (tc_strlen(Deg_info4) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info4);
													printf("\n VEHTASK:V:sTaskGroups50:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s50TaskFlag=1;
														printf("\n VEHTASK:V:s50TaskFlag:[%d].",s50TaskFlag);fflush(stdout);
													}
												}

												if (tc_strlen(Deg_info5) > 1)
												{
													sTaskGroups=(char *) MEM_alloc(30);
													tc_strcpy (sTaskGroups,"");
													tc_strcpy (sTaskGroups,"_");
													tc_strcat (sTaskGroups,Deg_info5);
													printf("\n VEHTASK:V:sTaskGroups26:[%s].",sTaskGroups);fflush(stdout);
													if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
													{
														s26TaskFlag=1;
														printf("\n VEHTASK:V:s26TaskFlag:[%d].",s26TaskFlag);fflush(stdout);
													}
												}

												if(tc_strstr(Deg_info7,scprojectcode)!=NULL)
												{
													if (tc_strlen(Deg_info8) > 1)
													{
														sTaskGroups=(char *) MEM_alloc(30);
														tc_strcpy (sTaskGroups,"");
														tc_strcpy (sTaskGroups,"_");
														tc_strcat (sTaskGroups,Deg_info8);
														printf("\n VEHTASK:V:sTaskGroups39:[%s].",sTaskGroups);fflush(stdout);
														if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
														{
															 s35or39TaskFlag=1;
															 printf("\n VEHTASK:V:s35or39TaskFlag:[%d].",s35or39TaskFlag);fflush(stdout);
														}
													}
												}
												else
												{
													if (tc_strlen(Deg_info6) > 1)
													{
														sTaskGroups=(char *) MEM_alloc(30);
														tc_strcpy (sTaskGroups,"");
														tc_strcpy (sTaskGroups,"_");
														tc_strcat (sTaskGroups,Deg_info6);
														printf("\n VEHTASK:V:sTaskGroups35:[%s].",sTaskGroups);fflush(stdout);
														if(tc_strstr(sTaskName,sTaskGroups)!=NULL)
														{
															 s35or39TaskFlag=1;
															 printf("\n VEHTASK:V:s35or39TaskFlag:[%d].",s35or39TaskFlag);fflush(stdout);
														}
													}
												}
											}
											if ((s0ETaskFlag==0) ||(s16TaskFlag==0)||(s21TaskFlag==0)||(s50TaskFlag==0)||(s26TaskFlag==0)||(s35or39TaskFlag==0))
											{
												printf("\n need all Veh task \n");fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"\n please ensure to attach All madatory task of design group 0E,16,21,50,26,35 or 39., please attach it and submit ");
												decision = EPM_nogo;
												return decision;
											}
										}
								   }
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_PWTtskChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_PWTtskChk Function end...");
	return decision;
}
