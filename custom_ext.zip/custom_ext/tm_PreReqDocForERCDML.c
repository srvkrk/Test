

	#include <stdlib.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	#include <tc/iman.h>
	#include <tccore/imantype.h>
	#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <ics/ics2.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>
	
	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}

	#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
	#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
	static int report_error(char *file, int line, char *call, int status,
	    logical exit_on_error)
	{
	    if (status != ITK_ok)
	    {
		/*int
		    n_errors = 0,
		    *severities = NULL,
		    *statuses = NULL;
			*/
			int n_errors = 0;
			const int 
				*severities=NULL,
				*statuses=NULL;
		const char
		    **messages;
			


		EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
		if (n_errors > 0)
		{
		    ECHO("\n%s\n", messages[n_errors-1]);
		    EMH_clear_errors();
		}
		else
		{
		    char *error_message_string;
		    EMH_get_error_string (NULLTAG, status, &error_message_string);
		    ECHO("\n%s\n", error_message_string);
		}

		ECHO("error %d at line %d in %s\n", status, line, file);
		ECHO("%s\n", call);

		if (exit_on_error)
		{
		    ECHO("Exiting program!\n");
		    exit (status);
		}
	    }

	    return status;
	}

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int getContrlObj( char *syscd,char *subsyscd,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries[] = {"SYSCD","SUBSYSCD","Delete Indicator"},
	*qry_values[]       = {syscd,subsyscd,"0"};

	printf("\n in getContrlObj func");fflush(stdout);
	printf("\n\n Input syscd==%s SUBSYSCD=%s \n",syscd,subsyscd);fflush(stdout);
	//printf("\n\n Input SUBSYSCD==%s \n",val);fflush(stdout);
	
	printf("\n b4 Qry getContrlObj");fflush(stdout);

	QRY_find("Control Objects...", &query);
	printf("\n in after qry find getContrlObj");fflush(stdout);
	QRY_execute(query, 3, qry_entries, qry_values, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getContrlObj control object size ==%s \n",n_found);fflush(stdout);

	return ifail;
}


//Start Rule Handler

/*
	Rule Handler		:		CM_Check_PreReqDocForErDML
	Description			:		This Rule handler checks the prerequisite doc for ERC DML during sign-off from Designer end
*/

//int CM_Check_PreReqDocForErDML(EPM_rule_message_t msg)
extern EPM_decision_t DLLAPI CM_Check_PreReqDocForErDML(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int i=0,j=0,k=0,status=ITK_ok;
	int ifail=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	int    noAttachment=0;	
	int Dmlcnt=0;
	int resCnt =0;
	char *id;
	char *DocName;
	char *RelationName=NULL;
	char *revid=NULL;
	char *dmlNo=NULL;
	char *DmlDR=NULL;
	char *DMLtype=NULL;
	char *projectname=NULL;
	char *BusUnit=NULL;
	char *reason=NULL;
	char **reasondesc=NULL;
	char *ReasonVal=NULL;
	int prereqdocflag=0;
	//int k=0;
	char *userinfo1=NULL;
	char *userinfo2=NULL;
	char *userinfo3=NULL;
	char *userinfo4=NULL;
	char *userinfo5=NULL;
	char *userinfo6=NULL;
	char *userinfo7=NULL;
	char *userinfo8=NULL;
	char *userinfo9=NULL;
	char *userinfo10=NULL;
	tag_t tsk_dml_rel_type;
	tag_t *DMLRevision = NULLTAG;
	char *ValidDocList=(char *) MEM_alloc(10 * sizeof(char *));
	char *ErrorMsg=(char *) MEM_alloc(10 * sizeof(char *));
	char *DmlDRCpy=(char *) MEM_alloc(10 * sizeof(char *));
	char *DMLtypeCpy=(char *) MEM_alloc(10 * sizeof(char *));
	char *reasonCpy=(char *) MEM_alloc(10 * sizeof(char *));
	char *obj_type=NULL;
	tag_t  rev=NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;	
	int count;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	tag_t * 	secondary_objects ;
	


 printf("inside CM_Check_PreReqDocForErDML Rule Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	//ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n CM_Check_PreReqDocForErDML attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_Check_PreReqDocForErDML Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=taskAttachments[Itemscnt];
		char *id;
		char *Solid;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);

		
		
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		//ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
		
	
		printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=taskAttachments[Itemscnt];
		
		CALLAPI(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		printf("\n Task_id= %s",id);fflush(stdout);

		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		{
		  CALLAPI(GRM_list_primary_objects_only(taskAttachments[Itemscnt],tsk_dml_rel_type,&Dmlcnt,&DMLRevision));
		  
		}
		printf("\n Dmlcnt= %d",Dmlcnt);fflush(stdout);
		if(Dmlcnt>0)
		{
			CALLAPI(AOM_ask_value_string(*DMLRevision,"item_id" , &dmlNo));
			printf("\n DML No= %s",dmlNo);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(*DMLRevision,"item_revision_id" , &revid));
			printf("\n DML rev= %s",revid);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(*DMLRevision,"t5_cDRstatus",&DmlDR));
			printf("\n\t DmlDR is :%s",DmlDR);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(*DMLRevision,"t5_rlstype",&DMLtype));
			printf("\n\t DMLtype is :%s",DMLtype);fflush(stdout);
			
			CALLAPI(AOM_UIF_ask_value(*DMLRevision,"t5_cprojectcode",&projectname));
			printf("\n Projectname : %s\n",projectname);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(*DMLRevision,"t5_ERCBusiUt",&BusUnit));
			printf("\n DML business unit  :%s \n",BusUnit);fflush(stdout);

			CALLAPI(AOM_ask_value_string(*DMLRevision,"t5_reason",&reason));
			printf("\n DML reason :%s \n",reason);fflush(stdout);
			
			CALLAPI(AOM_ask_displayable_values(*DMLRevision,"t5_reason",&resCnt, &reasondesc));
			//CALLAPI (AOM_ask_value_string(*DMLRevision,"t5_reasondesc",&reasondesc));
			printf("\n  resCnt : %d \n",resCnt); fflush(stdout);
			if(resCnt>0) 
				ReasonVal = reasondesc[0];
			//CALLAPI(AOM_ask_value_string(objtag,"t5_reason",&Reason));
			printf("\n--->>>>> Reason_val>>==%s\n",ReasonVal);fflush(stdout);
			
			printf("\n  reasondesc : %s \n",ReasonVal); fflush(stdout);
			
			
		}
		
			int controlObjCnt=0;
			

			tag_t *CntrlObjTags=NULLTAG;

			tag_t   CntrlObjQry     = NULLTAG;
			int     n_entryCntrl    = 3;
			
			tc_strcpy(DMLtypeCpy,"*");
				tc_strcat(DMLtypeCpy,DMLtype);
				tc_strcat(DMLtypeCpy,"*");
				printf("\n under DMLtypeCpy= %s",DMLtypeCpy);fflush(stdout);
				
				
				
				
			CALLAPI(getContrlObj( BusUnit,DMLtypeCpy,&controlObjCnt ,&CntrlObjTags));
			
			printf("\n valid Business unit & Release type controlObjCnt size : %d\n",controlObjCnt);fflush(stdout);
			
			if(controlObjCnt>0)
			{
				printf("\n Control Object Query Found for business unit [%s] & release Type [%s]\n",BusUnit,DMLtype);fflush(stdout);
				
				controlObjCnt=0;	

				*CntrlObjTags=NULLTAG;
				tc_strcpy(DmlDRCpy,"*");
				tc_strcat(DmlDRCpy,DmlDR);
				tc_strcat(DmlDRCpy,"*");
				printf("\n under DmlDRCpy= %s",DmlDRCpy);fflush(stdout);
				
				tc_strcpy(reasonCpy,"*");
				tc_strcat(reasonCpy,reason);
				tc_strcat(reasonCpy,"*");
				printf("\n under reasonCpy= %s",reasonCpy);fflush(stdout);
				CALLAPI(getContrlObj( reasonCpy,DmlDRCpy,&controlObjCnt ,&CntrlObjTags));
				
				printf("\n valid PreReqDocList controlObjCnt size : %d\n",controlObjCnt);fflush(stdout);
				
				if(controlObjCnt>0)
				{
					
					for(k=0;k<controlObjCnt;k++)
					{
						char *VCClass;
						printf("\n under CntrlObjTags> %d",CntrlObjTags);fflush(stdout);
						
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo1" , &userinfo1));
						printf("\n userinfo1= %s",userinfo1);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo2" , &userinfo2));
						printf("\n userinfo2= %s",userinfo2);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo3" , &userinfo3));
						printf("\n userinfo3= %s",userinfo3);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo4" , &userinfo4));
						printf("\n userinfo4= %s",userinfo4);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo5" , &userinfo5));
						printf("\n userinfo5= %s",userinfo5);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo6" , &userinfo6));
						printf("\n userinfo6= %s",userinfo6);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo7" , &userinfo7));
						printf("\n userinfo7= %s",userinfo7);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo8" , &userinfo8));
						printf("\n userinfo8= %s",userinfo8);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_Userinfo9" , &userinfo9));
						printf("\n userinfo9= %s",userinfo9);fflush(stdout);
						CALLAPI(AOM_ask_value_string(CntrlObjTags[k],"t5_userinfo10" , &userinfo10));
						printf("\n userinfo10= %s",userinfo10);fflush(stdout);
						if(userinfo1)
							{
								tc_strcpy(ValidDocList,userinfo1);				
							
							}
							if(userinfo2)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo2);
							
							}
							if(userinfo3)
							{
								tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo3);
							
							}
							if(userinfo4)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo4);
							
							}
							if(userinfo5)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo5);
							
							}
							if(userinfo6)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo6);
							
							}
							if(userinfo7)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo7);
							
							}
							if(userinfo8)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo8);
							
							}
							if(userinfo9)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo9);
							
							}
							if(userinfo10)
							{
							tc_strcat(ValidDocList,",");
							tc_strcat(ValidDocList,userinfo10);							
							}
							
							printf("\n Final ValidDocList [%s]\n",ValidDocList);fflush(stdout);
							
								
							if(tc_strlen(ValidDocList)<=0)
							{
								printf("\n No PreRequisiteDoc mention in control object for reason [%s] & DR [%s]\n",ReasonVal,DmlDR);fflush(stdout);
								decision = EPM_go;
								return decision;
							}
						//return;
								
					}
					
				}
				else
				{
					printf("\n Control Object Query not Found for reason [%s] & DR [%s]\n",ReasonVal,DmlDR);fflush(stdout);
					decision = EPM_go;
					return decision;
				}

				
			}
			else
			{
				printf("\n Control Object Query not Found for business unit [%s] & release Type [%s]\n",BusUnit,DMLtype);fflush(stdout);
				decision = EPM_go;
				return decision;
			}
			
			
					tc_strcpy(ErrorMsg,"DML having DR status");
					tc_strcat(ErrorMsg," [");
					tc_strcat(ErrorMsg,DmlDR);
					tc_strcat(ErrorMsg,"] ");
					tc_strcat(ErrorMsg,"Release Type");
					tc_strcat(ErrorMsg," [");					
					tc_strcat(ErrorMsg,DMLtype);
					tc_strcat(ErrorMsg,"] ");
					tc_strcat(ErrorMsg,"and ");
					tc_strcat(ErrorMsg,"Reason Type");
					tc_strcat(ErrorMsg," [");
					tc_strcat(ErrorMsg,ReasonVal);
					tc_strcat(ErrorMsg,"] ");
					tc_strcat(ErrorMsg,"\n");
					tc_strcat(ErrorMsg,"must have the folllowing prerequisite docs attached");
					tc_strcat(ErrorMsg,"\n");
					tc_strcat(ErrorMsg," [");
					//tc_strcat(ErrorMsg,dmlNo);
					//tc_strcat(ErrorMsg,"_");
					if(tc_strlen(userinfo1)>0)
					//if(tc_strcmp(userinfo1,"") != 0 || userinfo1 !=NULL)
					{
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo1);
						//tc_strcat(ErrorMsg," OR ");
					}
					//if(tc_strcmp(userinfo2,"") != 0 || userinfo2 !=NULL)
					if(tc_strlen(userinfo2)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo2);
						
					}
					//if(tc_strcmp(userinfo3,"") != 0 || tc_strcmp(userinfo3," ") != 0|| userinfo3 !=NULL)
					if(tc_strlen(userinfo3)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo3);
						
					}
					if(tc_strlen(userinfo4)>0)
					//if(tc_strcmp(userinfo4,"") != 0 || userinfo4 !=NULL)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo4);
						
					}
					//if(tc_strcmp(userinfo5,"") != 0 || userinfo5 !=NULL)
					if(tc_strlen(userinfo5)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo5);
						
					}
					if(tc_strlen(userinfo6)>0)
					//if(tc_strcmp(userinfo6,"") != 0 || userinfo6 !=NULL)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo6);
						//tc_strcat(ErrorMsg," OR ");
					}
					if(tc_strlen(userinfo7)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo7);
						
					}
					if(tc_strlen(userinfo8)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo8);
						
					}
					if(tc_strlen(userinfo9)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo9);
						
					}
					if(tc_strlen(userinfo10)>0)
					{
						tc_strcat(ErrorMsg," OR ");
						tc_strcat(ErrorMsg,dmlNo);
						tc_strcat(ErrorMsg,"_");
						tc_strcat(ErrorMsg,userinfo10);
						
					}
					
					tc_strcat(ErrorMsg,"] ");
					printf("\n %s",ErrorMsg);fflush(stdout);
		
		//CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		//CALLAPI(GRM_find_relation_type("CMReferences",&DmlItemsRelation_t));
		
		CALLAPI(AOM_ask_value_tags(*DMLRevision,"IMAN_reference",&count,&secondary_objects));
		
		//CALLAPI(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
		
		printf("\n count= %d \n",count);fflush(stdout);
		if(count>0)
		{
			prereqdocflag=0;
			for(i=0;i<count;i++)
			{
				char *VCClass;
				printf("\n under loop> %d",i);fflush(stdout);
				CALLAPI(AOM_ask_value_string(secondary_objects[i],"object_string" , &DocName));
				//CALLAPI(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				//CALLAPI(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				//CALLAPI(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				printf("\n Document Name= %s",DocName);fflush(stdout);
				
				if(tc_strstr(DocName,dmlNo)!=NULL)
				{
					if(tc_strstr(DocName,"_")!=NULL)
					{
						if(tc_strstr(DocName,userinfo1)!=NULL || tc_strstr(DocName,userinfo2)!=NULL || tc_strstr(DocName,userinfo3)!=NULL || tc_strstr(DocName,userinfo4)!=NULL || tc_strstr(DocName,userinfo5)!=NULL || tc_strstr(DocName,userinfo6)!=NULL || tc_strstr(DocName,userinfo7)!=NULL || tc_strstr(DocName,userinfo8)!=NULL || tc_strstr(DocName,userinfo9)!=NULL || tc_strstr(DocName,userinfo10)!=NULL)
						{
							printf("\n Valid PreReqDoc available> %s",DocName);fflush(stdout);
							prereqdocflag++;
							break;
						}
					}
				}
				
				/* if(tc_strstr(ValidDocList,DocName)!=NULL)
				{
					printf("\n Valid PreReqDoc available> %s",DocName);fflush(stdout);
					prereqdocflag++;
				}
				 */
				 //return;
				
						
			}
			

					
			
			//printf("\n %s",ErrorMsg);fflush(stdout);
			printf("\n prereqdocflag= %d",prereqdocflag);fflush(stdout);
				if(prereqdocflag>0)
				{
					printf("\n EPM_go for Valid PreReqDoc available");fflush(stdout);
					decision = EPM_go;
					return decision;
				}
				else
				{
					printf("\n EPM_nogo");fflush(stdout);
					printf("\n %s",ErrorMsg);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, ErrorMsg);
					decision = EPM_nogo;
					return decision;
				 
				}
			
			
			printf("\nPreRequisiteDoc checks w.r.t ERC DML has completed");fflush(stdout);

			
			
			
		printf("\nAfter call func report_all_relation_info");fflush(stdout);
		//CALLAPI(BOM_find_variant_rule_and_or_sos(taskAttachments[Itemscnt],vval[0],NULLTAG,true,&n_vtags_found, &vtags_found));
  
		}
		else
		{
			printf("\n EPM_nogo");fflush(stdout);
					printf("\n %s",ErrorMsg);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, ErrorMsg);
					decision = EPM_nogo;
					return decision;
		}

	

		
		
		}
		
	}
}
	decision = EPM_go;
	return decision;
}


//End Rule Handler



int PreReqDocForErDML_register_rule_handlers()
{
	
	TC_write_syslog("going to register PreReqDocForErDML_register_rule_handlers [CM_Check_PreReqDocForErDML]..\n");
	EPM_register_rule_handler("CM_Check_PreReqDocForErDML","Rule handler to check the PreRequisite Docs based on their Release Type ",(EPM_rule_handler_t)CM_Check_PreReqDocForErDML);
	TC_write_syslog("Registered Rule Handler CM_Check_PreReqDocForErDML..\n");
	return ITK_ok;
}




extern int PreReqDocForErDML_register_methods(int *decision, va_list args)
{
                            

         printf("\n Start  *****tm_PreReqDocForErDML_register_methods\n");fflush(stdout);       
                 int ifail = ITK_ok;
                 METHOD_id_t  method1;
				METHOD_id_t  method2;
                 
                 
                 *decision = ALL_CUSTOMIZATIONS;

				 //Registering Rule handler with method which will build with same tm_techspec.so
				 ERROR_CHECK(PreReqDocForErDML_register_rule_handlers());
				 //End Rule handler 
				 
				
return ifail;
}

//End

extern DLLAPI int tm_PreReqDocForErDML_register_callbacks ()
{
    ECHO("tm_PreReqDocForErDML_register_callbacks\n");

	printf("\ntm_PreReqDocForErDML_register_callbacks");fflush(stdout);

	ERROR_CHECK(CUSTOM_register_exit ( "tm_PreReqDocForErDML", "USER_init_module",(CUSTOM_EXIT_ftn_t) PreReqDocForErDML_register_methods ));
	//ERROR_CHECK(CUSTOM_register_exit ( "tm_techspec", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  IcsLovUpdateServiceFunc));

    return ITK_ok;
}

