#include "TMLLibrary_server_exits.h"

int tm_color_PartChk(EPM_action_message_t msg)
{
	int error_code			= ITK_ok;
    int count			    = 0;
    int ClrIndFlag          = 0;    
    int tskcount            = 0;
    int l                   = 0;
    int partcnt             = 0;
    int k                   = 0;
    int no_attach           = 0;
    int i                   = 0;
	tag_t  DMLTag           = NULLTAG;
	tag_t  DMLRevTag        = NULLTAG;
	tag_t  query			= NULLTAG;
	tag_t  TagClassId	    = NULLTAG;
	tag_t  objTypeTag	    = NULLTAG;
	tag_t  AssyTag	        = NULLTAG;
	tag_t  tskreltype	    = NULLTAG;
	tag_t  roottask			= NULLTAG;
    tag_t  *contrlObjs      = NULLTAG;
    tag_t  *tskobjs         = NULLTAG;
    tag_t  *PartsTag        = NULLTAG;
    char *ObjClassName			= NULL;
	char *item_id				= NULL;
    char *businessUnit			= NULL;
	char *releasetype			= NULL;
	char *fromtostatus			= NULL;
	char *sDMLDR				= NULL;
	char *RelTypeCat			= NULL;
	char *type_name			    = NULL;
	char *Object_ClrInd			= NULL;
	char *Part_no			    = NULL;
	char *info1	                = NULL;
	char *info2				    = NULL;
	char *info3				    = NULL;
	char *info4				    = NULL;
	tag_t  DMLTaskTag = NULLTAG;
	logical is_latest;
	char   objTypeofTask[TCTYPE_name_size_c+1];
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_entriesProj = (char **) MEM_alloc(30 * sizeof(char *));
	char **DML_qry_entry = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	char **qry_valuesProj = (char **) MEM_alloc(100 * sizeof(char *));
	char **DML_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));


	tag_t  *Attachments	    = NULLTAG;

	printf("\n tm_color_PartChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_color_PartChk Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\ntm_color_PartChk:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_00TaskCheck:INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];
			if(DMLRevTag != NULLTAG)
			{
			  qry_entries[0] ="SYSCD";
			  qry_values[0]  ="COLPART";
			  
			  ITK_CALL(QRY_find2("Control Objects...", &query));
			  ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
			  printf("\n Control objects : count==>%d \n",count);fflush(stdout);
			  if (count>0)
			  {

				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&info1));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&info2));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&info3));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&info4));
				printf("\n L1:info1 is : [%s]  L2:info2 is : [%s]  L3:info3 is : [%s] L4:info4 is : [%s]\n",info1,info2,info3,info4);fflush(stdout);

				if (tc_strstr(info1,"COLPARTCHKOFF")==NULL)
				{
					ITK_CALL(POM_class_of_instance(DMLRevTag,&TagClassId));	//class=ChangeRequestRevision
					ITK_CALL(POM_name_of_class(TagClassId,&ObjClassName));
					printf("\n ObjClassName: %s",ObjClassName);

					if(tc_strstr(ObjClassName,"ChangeRequestRevision")!=NULL)
					{
						printf("\nclass is ChangeRequestRevision......\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&item_id));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&releasetype));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&businessUnit));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&fromtostatus));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
						printf("\n L1:item_id is : [%s]  L2:releasetype is : [%s]  L3:businessUnit is : [%s] L4:fromtostatus is : [%s]  L5:sDMLDR is : [%s]\n",item_id,releasetype,businessUnit,fromtostatus,sDMLDR);fflush(stdout);
						//printf("\n from to status is : [%s]\n", info2);fflush(stdout);

						RelTypeCat = MEM_alloc(100);
						tc_strcpy(RelTypeCat,"");
						tc_strcpy(RelTypeCat,",");
						tc_strcat(RelTypeCat,releasetype);
						tc_strcat(RelTypeCat,",");
						printf("\n RelTypeCat.:%s \n",RelTypeCat);fflush(stdout);

						if(tc_strstr(info2,RelTypeCat)!=NULL)
						{
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tskreltype));
							ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,tskreltype,&tskcount,&tskobjs));
							printf("\n\n\t\t Now tskcount:%d \n",tskcount);fflush(stdout);
							if(tskcount>0)
							{
								for (l=0;l<tskcount;l++ )
								{
									ITK_CALL(AOM_ask_value_tags(tskobjs[l],"CMHasSolutionItem",&partcnt,&PartsTag));
									printf("\n\n\t\t Now partcnt:%d \n",partcnt);fflush(stdout);
									ClrIndFlag=0;
									if (partcnt>0)
									{
									   for (k=0;k<partcnt ;k++ )
									   {
											printf("\n\n\t\t for k =:%d \n",k);fflush(stdout);
											AssyTag=PartsTag[k];

											ITK_CALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
											printf("\n\n\t\t Part_no  is :%s \n",Part_no);	fflush(stdout);
											//WSOM_ask_object_type(primary_objects[i],object_type);

											ITK_CALL(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
											ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
											printf("\n\n\t\t AssyTag type_name := %s \n",type_name);fflush(stdout);
											//check control object based

											ITK_CALL(AOM_ask_value_string(AssyTag,"t5_ColourInd",&Object_ClrInd));
											printf("\n\n\t\t Object_ClrInd is :<%s>\n",Object_ClrInd);fflush(stdout);

											if(tc_strcmp(Object_ClrInd,"Y")==0)
											{
												ClrIndFlag=1;
												printf("\n\n\t\t ClrIndFlag is : %d \n",ClrIndFlag);fflush(stdout);
												break;
											}
									   }
										if (ClrIndFlag >0)
										{
											printf("\n\n\t\t B1. Breaking first for loop..: %d \n",ClrIndFlag);fflush(stdout);
											break;
										}
									}
								}
							}
						}
						else if ((tc_strcmp(releasetype,"CP")==0) || (tc_strcmp(releasetype,"Colour Part Release")==0))
						{
							if (tc_strstr(info1,"CL001")==NULL)
							{
								ClrIndFlag=0;
								printf("\n\n\t\t ClrIndFlag for CP release OFF : %d \n",ClrIndFlag);fflush(stdout);
							}
							else
							{
								ClrIndFlag=1;
								printf("\n\n\t\t ClrIndFlag for CP release ON : %d \n",ClrIndFlag);fflush(stdout);
							}
						}
						if (ClrIndFlag == 1)
						{
							printf("\n\n\t\t A1. return failure path %d \n",ClrIndFlag);fflush(stdout);
							return 1;
						}
						else
						{
							printf("\n\n\t\t A2. return success path %d\n",ClrIndFlag);fflush(stdout);
							return 0;
						}
					}
					else
					{
						printf("\n\n\t\t B2. Other than DML as input..\n");fflush(stdout);
					}
				}
				else 
				{
					printf("\n\n\t\t return failure path if Control Obj off\n");fflush(stdout);
					return 0;
				}
			  }
			}
		}
	}
	printf("\n tm_color_PartChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_color_PartChk Function end...");
	//return error_code;
	return 0;
}
