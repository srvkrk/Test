/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ECUTechcreate.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for WCQ Result 7 Report.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 28/05/2025  	 Prathmesh Deshmukh						    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h> 
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
//#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
//#include <bom/bom.h>
#include <tccore/aom_prop.h>
int FDJcount=0;
int GCIcount=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}



//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}



extern int ECUTechcreate(void *retValue)
{ 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	 //char *output	 = NULL;

	int ifail =ITK_ok;
	int vcattr =0;
	int sec_result_count =0;
	tag_t *statustags = NULLTAG;
	tag_t itemrevtag2 = NULLTAG;
	tag_t Latestrev_Tag = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t designtag = NULLTAG;
	tag_t tRelationFind = NULLTAG;
	tag_t itemrevtag = NULLTAG;
	tag_t itemTag = NULLTAG;
	tag_t Relationtag = NULLTAG;
	

	 char		*sItemId 		= NULL;
	 char		*itemName 		= NULL;
	 char		*Releasestatuspt 		= NULL;
	 char		*releasedate 		= NULL;
	 char		*statusname 		= NULL;
	 char		*revid 		= NULL;
     USERARG_get_string_argument(&sItemId);
	 USERARG_get_string_argument(&revid);

	 printf("\n inside ECU Autocreate function\n");
     printf("\n Item revision %s\n",sItemId);
     printf("\n Revision Sequenec %s\n",revid);	
	 ITEM_find_item(sItemId, &designtag);
	 ITEM_find_revision(designtag,revid,&Latestrev_Tag);
	//tc_strcpy(itemName,"");
	//tc_strcpy(itemName,"ECUTP");
	//tc_strcat(itemName,sItemId);


	ITEM_create_item("",itemName,"T5_ECU_TSComp","",&itemTag,&itemrevtag2);
	ITEM_save_item(itemTag);
	ITEM_save_item(itemrevtag2);

	ITEM_ask_latest_rev(itemTag,&itemrevtag); 

	if(itemrevtag!=NULLTAG)
	{

	  printf("\n inside value itemrevtag\n");
	 //ITK_CALL(AOM_lock(itemrevtag));
	 ITK_CALL(AOM_refresh(itemrevtag,TRUE));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_VC_NUMBER",sItemId));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_ecuVCno",sItemId));
	 //ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_Model",MODELNAME));
	 //ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_Country",CUSTOMER));
	 //ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_FuelType",FUEL));
	 ITK_CALL(AOM_save_without_extensions(itemrevtag));
	 ITK_CALL(AOM_refresh(itemrevtag,0));
	
	}

	GRM_find_relation_type("T5_Has_ECU_Tech_Spec",&tRelationFind);
	GRM_find_relation(Latestrev_Tag,itemrevtag,tRelationFind,&tRelationExist);
	GRM_create_relation(Latestrev_Tag,itemrevtag,tRelationFind,NULLTAG,&Relationtag);
	GRM_save_relation(Relationtag);

	return ifail; 
}

extern int tm_ECUTechcreate(int *decision, va_list args)
{	
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    int retValueType;
	int nargs = 2;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) ); 
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ;
	printf("\n tm_ECUTechcreate before....tm_ECUTechcreate");fflush(stdout);  
	ifail=USERSERVICE_register_method("ECUTechcreate",(USER_function_t)ECUTechcreate,nargs,inputArgTypes,retValueType);
	return ifail;
}


extern DLLAPI int tm_ECUTechcreate_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ECUTechcreate");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_ECUTechcreate", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ECUTechcreate);
	printf("\n After registering userservice....tm_ECUTechcreate");fflush(stdout);
	return(ITK_ok);
}


